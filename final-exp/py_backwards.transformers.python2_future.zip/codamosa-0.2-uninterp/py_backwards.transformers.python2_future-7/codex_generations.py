

# Generated at 2022-06-18 00:08:20.814969
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:08:25.737248
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('x = 1')) == ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1')

# Generated at 2022-06-18 00:08:33.585823
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import round_trip

    source = """
    import sys
    import os
    import math
    """
    node = get_node(source, ast.Module)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert_source_equal(get_source(new_node), """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import sys
    import os
    import math
    """)
    round_trip

# Generated at 2022-06-18 00:08:37.930833
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.name == 'Python2FutureTransformer'
    assert transformer.description == 'Prepends module with: from __future__ import absolute_import, division, print_function, unicode_literals'
    assert transformer._tree_changed == False


# Generated at 2022-06-18 00:08:49.054268
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:08:54.255625
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:09:03.248357
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source_1 = """
    def foo():
        pass
    """
    source_2 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    module_1 = get_ast(source_1)
    module_2 = get_ast(source_2)
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module_1)
    assert compare_asts(module_2, new_module)

# Generated at 2022-06-18 00:09:09.993645
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse
    from ..utils.ast import get_ast_diff

    source_code = source(imports)
    tree = parse(source_code)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert get_ast_diff(tree, new_tree)

    # Check that the new tree is valid
    dump(new_tree)

# Generated at 2022-06-18 00:09:20.280721
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'

# Generated at 2022-06-18 00:09:24.041063
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.visitor import visit

    source = source(__file__)
    tree = ast.parse(source)
    tree = visit(tree, Python2FutureTransformer)
    dump(tree)

# Generated at 2022-06-18 00:09:35.235325
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from ..utils.source import source
    from ..utils.source import Source
    from ..utils.source import Code
    from ..utils.source import is_equal
    from ..utils.source import to_source
    from ..utils.source import to_ast
    from ..utils.source import to_code
    from ..utils.source import to_tokens
    from ..utils.source import to_gast
    from ..utils.source import to_astor
    from ..utils.source import to_source as t2s
    from ..utils.source import to_ast as s2a

# Generated at 2022-06-18 00:09:41.585618
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source

    code = source(
        """
        def foo():
            pass
        """
    )
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == source(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:10:15.719354
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:25.501581
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import os
        import sys
        import math
        import random
        import datetime
        import time
        import re
        import json
        import logging
        import argparse
        import subprocess
        import multiprocessing
        import threading
        import concurrent.futures
        import collections
        import itertools
        import functools
        import operator
        import contextlib
        import tempfile
       

# Generated at 2022-06-18 00:10:35.508607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:41.955228
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_ast_and_tokens
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_tokens
    from ..utils.source import tokens_to_source
    from ..utils.source import tokens_to_ast
    from ..utils.source import ast_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_tokens
    from ..utils.source import code_to_ast_and_tokens
    from ..utils.source import ast_and_tokens_to_source

# Generated at 2022-06-18 00:10:42.985889
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-18 00:10:46.181065
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-18 00:10:53.099018
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_visitor import ASTVisitorError
    from ..utils.ast_visitor import ASTVisitorTypeError
    from ..utils.ast_visitor import ASTVisitorValueError
    from ..utils.ast_visitor import ASTVisitorWarning
    from ..utils.ast_visitor import ASTVisitorWarningError
    from ..utils.ast_visitor import ASTVisitorWarningTypeError
    from ..utils.ast_visitor import ASTVisitorWarningValueError
    from ..utils.ast_visitor import ASTVisitorWarningWarning
    from ..utils.ast_visitor import ASTVisitorWarningWarningError
    from ..utils.ast_visitor import ASTVisitorWarningWarningTypeError

# Generated at 2022-06-18 00:11:01.717319
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source

    class Visitor(NodeVisitor):
        def visit_Module(self, node):
            self.module = node
            self.generic_visit(node)

    tree = make_test_module('a = 1')
    visitor = Visitor()
    visitor.visit(tree)
    assert source(visitor.module) == 'a = 1'

    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert source(visitor.module) == '\n'.join(imports.get_body(future='__future__')) + '\na = 1'

# Generated at 2022-06-18 00:11:11.165492
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source('python2/future.py')
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert astor.to_source(tree) == get_source('python2/future_transformed.py')

# Generated at 2022-06-18 00:11:18.250666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast

    source_ = source(imports)
    expected_ = source(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        """
    )
    tree = get_ast(source_)
    new_tree = Python2FutureTransformer().visit(tree)
    assert compare_ast(new_tree, get_ast(expected_))

# Generated at 2022-06-18 00:11:27.343474
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code(a, b):
        return a + b

    node = code.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:11:34.542086
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tokens_with_comments
    from ..utils.source import source_to_tokens_without_comments
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree_with_comments
    from ..utils.source import source_to_tree_without_comments
    from ..utils.source import source_to_visit
    from ..utils.source import source_to_visit_with_comments
    from ..utils.source import source_to_visit_without_comments
    from ..utils.source import source_to_walk
    from ..utils.source import source_to

# Generated at 2022-06-18 00:11:37.715180
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:11:44.833910
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'

# Generated at 2022-06-18 00:11:53.893704
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer._tree_changed is False
    assert Python2FutureTransformer._in_function is False
    assert Python2FutureTransformer._in_class is False
    assert Python2FutureTransformer._in_with is False
    assert Python2FutureTransformer._in_async_function is False
    assert Python2FutureTransformer._in_async_with is False
    assert Python2FutureTransformer._in_async_for is False
    assert Python2FutureTransformer._in_async_with is False
    assert Python2FutureTransformer._in_async_with is False
    assert Python2FutureTransformer._in_async_with is False
    assert Python2Future

# Generated at 2022-06-18 00:12:01.943541
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'


# Generated at 2022-06-18 00:12:04.992385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import compare_ast
    from ..utils.ast_helpers import get_ast_diff


# Generated at 2022-06-18 00:12:08.762863
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast
    from ..utils.visitor import dump_visitor

    source_ = source(imports)
    tree = get_ast(source_)
    visitor = Python2FutureTransformer()
    new_tree = visitor.visit(tree)
    assert compare_ast(tree, new_tree)
    assert visitor.tree_changed
    dump_visitor(visitor, source_)

# Generated at 2022-06-18 00:12:24.711030
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:12:34.229708
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def module():
        pass

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        pass

    module_ast = module.get_ast()
    expected_ast = expected.get_ast()

    assert_ast_equal(Python2FutureTransformer().visit(module_ast), expected_ast)

# Generated at 2022-06-18 00:12:44.811184
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
    from ..utils.test_utils import get_ast_node_end_lineno
    from ..utils.test_utils import get_ast_node_end_col_offset
    from ..utils.test_utils import get_ast_node_body
    from ..utils.test_utils import get_ast_node_orelse
    from ..utils.test_utils import get

# Generated at 2022-06-18 00:12:54.038944
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:12:59.838668
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:10.325623
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_node
    from ..utils.source import source

    dummy_node = make_dummy_future_node()
    dummy_node.body = [ast.parse(source('print("Hello, world!")'))]

    transformer = Python2FutureTransformer()
    transformed = transformer.visit(dummy_node)

    assert transformer._tree_changed is True
    assert len(transformed.body) == 5
    assert isinstance(transformed.body[0], ast.ImportFrom)
    assert isinstance(transformed.body[1], ast.ImportFrom)
    assert isinstance(transformed.body[2], ast.ImportFrom)
    assert isinstance(transformed.body[3], ast.ImportFrom)

# Generated at 2022-06-18 00:13:20.268146
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:13:28.978872
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:38.611794
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:40.682570
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False


# Generated at 2022-06-18 00:14:01.636123
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:14:11.310040
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'

# Generated at 2022-06-18 00:14:13.086961
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-18 00:14:14.458409
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:14:24.405162
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import get_ast
    from ..utils.visitor import get_source

    source = """
    def test():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def test():
        pass
    """
    module = make_test_module(source)
    node = get_ast(module)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed is True
    assert dump_ast(new_node)

# Generated at 2022-06-18 00:14:32.010361
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = module.get_ast()
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert node.body == imports.get_body(future='__future__') + module.get_body()

# Generated at 2022-06-18 00:14:33.470579
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:14:44.363724
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast

    source = """
    print('Hello, world!')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello, world!')
    """
    tree = source_to_ast(source)
    Python2FutureTransformer().visit(tree)
    actual = print_ast(tree)
    assert compare_ast(actual, expected)

# Generated at 2022-06-18 00:14:53.750685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target_version = (2, 7)
        code = '''
        def foo():
            pass
        '''
        expected_code = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo():
            pass
        '''

    assert_source_equal(Test)

# Generated at 2022-06-18 00:14:58.582007
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import get_ast

    source = """
    def foo():
        pass
    """
    tree = get_ast(source)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

# Generated at 2022-06-18 00:15:38.339598
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get

# Generated at 2022-06-18 00:15:42.093489
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    assert_node_equal(transformer.visit(ast.parse('')),
                      ast.parse(imports.get_code(future='__future__')))

# Generated at 2022-06-18 00:15:48.407560
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:52.288227
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module is not None
    assert transformer.generic_visit is not None
    assert transformer._tree_changed is False


# Generated at 2022-06-18 00:16:01.082468
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse
    from ..utils.ast import get_first_annotation
    from ..utils.ast import get_last_annotation
    from ..utils.ast import get_first_docstring
    from ..utils.ast import get_last_docstring
    from ..utils.ast import get_first_comment
    from ..utils.ast import get_last_comment
    from ..utils.ast import get_first_stmt
    from ..utils.ast import get_last_stmt
    from ..utils.ast import get_first_expr
    from ..utils.ast import get_last_expr

    source_ = source(imports)
    tree = parse(source_)
    assert isinstance(tree, ast.Module)
    assert get_first

# Generated at 2022-06-18 00:16:12.069364
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:16:18.849791
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:16:27.574788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        def foo():
            pass

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:16:36.408438
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = [ast.Expr(ast.Str('Hello'))]
            return self.generic_visit(node)  # type: ignore

    class TestTransformer2(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = [ast.Expr(ast.Str('World'))]
            return self.generic_visit

# Generated at 2022-06-18 00:16:40.150085
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_and_replace_node

    source_code = source(
        """
        def foo():
            pass
        """
    )
    tree = ast.parse(source_code)
    visit_and_replace_node(tree, Python2FutureTransformer)
    print_python_source(tree)

# Generated at 2022-06-18 00:18:10.490528
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_future import imports
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_vis

# Generated at 2022-06-18 00:18:17.668694
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')