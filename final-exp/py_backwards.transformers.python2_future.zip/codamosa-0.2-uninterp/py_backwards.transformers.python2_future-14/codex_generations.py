

# Generated at 2022-06-18 00:08:22.217296
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:08:31.877247
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = module.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:08:33.623315
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:08:37.930752
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('pass')) == ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
pass
''')

# Generated at 2022-06-18 00:08:38.821629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None)

# Generated at 2022-06-18 00:08:49.993214
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'

# Generated at 2022-06-18 00:08:57.170549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    transform_and_compare(Python2FutureTransformer, source, expected)

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

# Generated at 2022-06-18 00:08:58.963458
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-18 00:09:07.081999
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import run_ast
    from ..utils.ast_helper import run_source
    from ..utils.ast_helper import source_to_ast
    from ..utils.ast_helper import source_to_str
    from ..utils.ast_helper import str_to_ast
    from ..utils.ast_helper import str_to_source

# Generated at 2022-06-18 00:09:11.174360
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:09:22.934631
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source
    from ..utils.source import source

# Generated at 2022-06-18 00:09:34.052574
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:09:44.172851
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:48.890870
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    print('Hello world!')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello world!')
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:10:19.033892
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:25.423181
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import print_visitor

    source_ast = get_ast(source)
    expected_ast = get_ast(imports)

    transformer = Python2FutureTransformer()
    actual_ast = transformer.visit(source_ast)

    assert transformer._tree_changed is True
    assert compare_asts(actual_ast, expected_ast)

    print_visitor(actual_ast, source)

# Generated at 2022-06-18 00:10:33.170232
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source

    tree = make_dummy_tree(source("""
        def foo():
            pass
    """))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source(tree) == source("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    """)

# Generated at 2022-06-18 00:10:40.931514
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from ..utils.source import source
    from ..utils.source import Source
    from ..utils.source import Code
    from ..utils.source import is_equal
    from ..utils.source import to_source
    from ..utils.source import to_ast
    from ..utils.source import to_code
    from ..utils.source import to_tokens
    from ..utils.source import to_gast
    from ..utils.source import to_astor
    from ..utils.source import to_autoflake
    from ..utils.source import to_black
    from ..utils.source import to_isort
   

# Generated at 2022-06-18 00:10:50.238938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        print('Hello, world!')

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert astor.to_source(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:10:56.095256
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:11:00.723436
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:11:08.265184
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    @snippet
    def expected():
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        pass

    module_node = module.get_ast()
    expected_node = expected.get

# Generated at 2022-06-18 00:11:18.494316
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast
    from ..utils.future import future
    from ..utils.visitor import dump_visitor
    from ..utils.visitor import visit
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_children_with_parent
    from ..utils.visitor import visit_children_with_parent_and_siblings
    from ..utils.visitor import visit_with_parent
    from ..utils.visitor import visit_with_parent_and_siblings
    from ..utils.visitor import visit_with_siblings
    from ..utils.visitor import visit_with_siblings_and_parent
    from ..utils.visitor import visit_with_siblings_and_parent_and_

# Generated at 2022-06-18 00:11:29.809786
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:11:40.522764
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:49.409709
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:11:56.252878
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_test_data
    from ..utils.test_utils import get_ast

    test_data = get_test_data('Python2FutureTransformer_visit_Module.py')
    expected_ast = get_ast(test_data['expected'])
    actual_ast = get_ast(test_data['actual'])
    Python2FutureTransformer().visit(actual_ast)
    assert_ast_equal(expected_ast, actual_ast)

# Generated at 2022-06-18 00:12:05.454942
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.source_helper import source_to_ast

    @snippet
    def source():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        print(sys.version)

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        print(sys.version)

    source_ast = source_to_ast(source)

# Generated at 2022-06-18 00:12:06.700807
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-18 00:12:17.250531
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source


# Generated at 2022-06-18 00:12:35.109384
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'


# Generated at 2022-06-18 00:12:36.473830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-18 00:12:46.828939
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode
    from ..utils.source_code import SourceCode

# Generated at 2022-06-18 00:12:55.664753
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer.visit_Module.__module__ == Python2FutureTransformer.__module__

# Generated at 2022-06-18 00:13:03.295020
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source

    source = """
    def foo():
        pass
    """
    node = get_node(source, Python2FutureTransformer)
    assert_source_equal(get_source(node), """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """)

# Generated at 2022-06-18 00:13:13.443581
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_node
    from ..utils.fixtures import make_dummy_module_node
    from ..utils.fixtures import make_dummy_print_node
    from ..utils.fixtures import make_dummy_assign_node
    from ..utils.fixtures import make_dummy_name_node
    from ..utils.fixtures import make_dummy_str_node
    from ..utils.fixtures import make_dummy_expr_node
    from ..utils.fixtures import make_dummy_call_node
    from ..utils.fixtures import make_dummy_arg_node
    from ..utils.fixtures import make_dummy_keyword_node
    from ..utils.fixtures import make_dummy_alias_node
    from ..utils.fixtures import make_

# Generated at 2022-06-18 00:13:22.856141
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:32.565982
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    class TestVisitor(BaseNodeVisitor):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore


# Generated at 2022-06-18 00:13:36.222141
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source(__file__)
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:13:45.020500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:09.863551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'Python2FutureTransformer.visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'


# Generated at 2022-06-18 00:14:20.327777
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:14:27.129777
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    """
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:14:34.122867
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_source
    from ..utils.ast_helpers import get_ast_node_source_location
    from ..utils.ast_helpers import get_ast_node_source_range
    from ..utils.ast_helpers import get_ast_node_value
    from ..utils.ast_helpers import get_ast_node_value_range
    from ..utils.ast_helpers import get_ast_node_value_source
    from ..utils.ast_helpers import get_ast_node_value_source_location
    from ..utils.ast_helpers import get_ast_node_value_source_range

# Generated at 2022-06-18 00:14:42.311903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:14:43.830955
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False


# Generated at 2022-06-18 00:14:44.825296
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:14:50.581546
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast

    source_code = source(imports)
    expected_ast = get_ast(source_code)

    transformer = Python2FutureTransformer()
    actual_ast = transformer.visit(expected_ast)

    assert expected_ast == actual_ast

# Generated at 2022-06-18 00:14:58.655051
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:06.553144
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast

    source_code = source(
        """
        print('Hello world')
        """
    )

    tree = ast.parse(source_code)
    visit_ast(tree)
    print_python_source(tree)
    Python2FutureTransformer().visit(tree)
    visit_ast(tree)
    print_python_source(tree)

# Generated at 2022-06-18 00:15:45.573490
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.snippet import snippet

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        pass

    node = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert_source_equal(imports.get_source(future='__future__') + code.get_source(),
                        ast.unparse(node))

# Generated at 2022-06-18 00:15:55.615832
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_future import imports
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from ..utils.snippet import snippet
    from ..utils.snippet import snippet_to_ast
    from ..utils.snippet import snippet_to_str
    from ..utils.snippet import snippet_to_str_ast
    from ..utils.snippet import snippet_to_str_ast_ast
    from ..utils.snippet import snippet_to_str_ast_ast_ast
    from ..utils.snippet import snippet_to_str_ast_ast_

# Generated at 2022-06-18 00:16:03.852933
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import textwrap
    import unittest
    import unittest.mock

    class TestPython2FutureTransformer(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(ast.AST, 'assertAstEqual')
            self.addTypeEqualityFunc(
                type(None),
                self.assertIsNone
            )

        def assertAstEqual(self, node1, node2, msg=None):
            self

# Generated at 2022-06-18 00:16:14.435886
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import os
        import sys

    node = ast.parse(source(module))
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert source(node) == source(imports.get_body(future='__future__') + module.get_body())

# Generated at 2022-06-18 00:16:21.851856
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import walk

    module = make_test_module(
        """
        def foo():
            pass
        """
    )
    assert dump_source(module) == 'def foo():\n    pass\n'
    assert dump_ast(module) == 'Module(body=[FunctionDef(name=foo, args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])'
    walk(module, Python2FutureTransformer())

# Generated at 2022-06-18 00:16:30.049617
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:16:33.918612
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source

    tree = make_dummy_tree('module', '2.7')
    assert source(tree) == 'module'

    tree = Python2FutureTransformer().visit(tree)
    assert source(tree) == '\n'.join(imports.get_body(future='__future__')) + '\nmodule'

# Generated at 2022-06-18 00:16:40.532381
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def code():
        print('Hello world')

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('Hello world')

    node = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_source(node) == expected.get_source()

# Generated at 2022-06-18 00:16:47.745038
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast

    module = ast.parse('''
    def foo():
        pass
    ''')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    '''
    assert compare_ast(ast.parse(expected), module)
    assert ast_to_str(module) == expected

# Generated at 2022-06-18 00:16:54.655213
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform, compare
    from ..utils.test_utils import get_test_data

    # Get the test data
    test_data = get_test_data('test_python2_future.py')

    # Transform the test data
    new_tree = transform(Python2FutureTransformer, test_data)

    # Compare the test data with the expected output
    compare(new_tree, test_data, 'test_python2_future_expected.py')