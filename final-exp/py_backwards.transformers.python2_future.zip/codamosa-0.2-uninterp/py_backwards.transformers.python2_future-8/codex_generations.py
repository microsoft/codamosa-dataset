

# Generated at 2022-06-18 00:08:17.599797
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast
    from ..utils.fixtures import make_fixtures

    make_fixtures('Python2FutureTransformer', 'visit_Module', globals(),
                  source=source, get_ast=get_ast, compare_ast=compare_ast)

    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(get_ast(source))
    compare_ast(new_tree, get_ast(source, 'visit_Module'))

# Generated at 2022-06-18 00:08:23.765452
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:08:32.959724
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_snippet
    from ..utils.ast_helper import update_position
    from ..utils.ast_helper import visit_ast

    # Test with a simple module
    module = parse_snippet('a = 1')
    expected = parse_snippet('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
    ''')
    transformer = Python2FutureTransformer()

# Generated at 2022-06-18 00:08:43.002784
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast_str
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_source_str
    from ..utils.source import ast_to_source_unicode


# Generated at 2022-06-18 00:08:47.078665
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .utils import get_node

    # Given

# Generated at 2022-06-18 00:08:55.532652
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:09:04.480002
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future_transformer import Python2FutureTransformer
    import astor
    import textwrap
    import unittest

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_visit_Module(self):
            tree = ast.parse(textwrap.dedent('''\
                def foo():
                    pass
                '''))
            transformer = Python2FutureTransformer()
            transformer.visit(tree)

# Generated at 2022-06-18 00:09:13.520235
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_str
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_source_str
    from ..utils.source import ast_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import code_to_ast_str
    from ..utils.source import code_to_source_str
    from ..utils.source import source_to_code_str
    from ..utils.source import code_to_code_str
    from ..utils.source import ast_to_code_str
    from ..utils.source import code_to_code

# Generated at 2022-06-18 00:09:23.347864
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    module = make_test_module(
        """
        def test():
            pass
        """
    )
    transformer = Python2FutureTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:09:33.874061
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    node = get_node(source, ast.Module)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert_source_equal(get_source(new_node), expected)

# Generated at 2022-06-18 00:09:46.035264
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:09:52.762436
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_node_linenos
    from ..utils.source import source_to_node_columns
    from ..utils.source import source_to_node_end_linenos
    from ..utils.source import source_to_node_end_columns
    from ..utils.source import source_to_node_types
    from ..utils.source import source_to_node_names
    from ..utils.source import source_to_node_fields
    from ..utils.source import source_to_node_field_names


# Generated at 2022-06-18 00:09:55.121441
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:10:00.839119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def module():
        a = 1
        b = 2
        c = 3

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == module.get_source(future='__future__')

# Generated at 2022-06-18 00:10:01.598191
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:10:06.885416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tokens_with_comments
    from ..utils.source import source_to_tokens_with_comments_and_newlines
    from ..utils.source import source_to_tokens_with_newlines
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree_with_comments
    from ..utils.source import source_to_tree_with_comments_and_newlines
    from ..utils.source import source_to_tree_with_newlines
    from ..utils.source import source_to_tree_with_newlines_and_comments

# Generated at 2022-06-18 00:10:15.176571
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import ast_pprint
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import visit_ast

    class Visitor(NodeVisitor):
        def visit_Module(self, node: ast.Module) -> None:
            print('Module:')
            print(ast_pprint(node))

    visitor = Visitor()
    visit_ast(source('print("Hello world!")'), visitor)

    transformer = Python2FutureTransformer()
    visit_ast(source('print("Hello world!")'), transformer)
    visit_ast(transformer.tree, visitor)

# Generated at 2022-06-18 00:10:24.912030
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.visitor import visit
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_children_with_types
    from ..utils.visitor import visit_with_types
    from ..utils.visitor import visit_with_types_and_values
    from ..utils.visitor import visit_with_values
    from ..utils.visitor import visit_with_values_and_types
    from ..utils.visitor import visit_with_values_and_types_and_children
    from ..utils.visitor import visit_with_values_and_children
    from ..utils.visitor import visit_with_types_and_children
    from ..utils.visitor import visit_with_children

# Generated at 2022-06-18 00:10:33.814518
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        import os
        import sys

    node = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import sys
""".strip()

# Generated at 2022-06-18 00:10:41.263382
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import ast_equal, dump
    from ..utils.future import future_absolute_import, future_division, future_print_function, future_unicode_literals
    from ..utils.compat import PY2
    from ..utils.visitor import dump_visitor

    if not PY2:
        return


# Generated at 2022-06-18 00:10:46.180924
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:10:53.099937
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_visit
    from ..utils.source import source_to_walk
    from ..utils.source import source_to_pretty
    from ..utils.source import source_to_format
    from ..utils.source import source_to_gast
    from ..utils.source import source_to_source
    from ..utils.source import source_to_source_tree
    from ..utils.source import source_to_source_visit
    from ..utils.source import source_to_source_walk
    from ..utils.source import source_to_source_pretty

# Generated at 2022-06-18 00:11:02.361532
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import TransformerResult
    from .base import TransformerVisitResult

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> TransformerVisitResult:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    class TestVisitor(BaseNodeVisitor):
        def visit_Module(self, node: ast.Module) -> TransformerResult:
            return self.generic_visit(node)  # type:

# Generated at 2022-06-18 00:11:11.865011
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_module
    from ..utils.test_utils import get_node_class
    from ..utils.test_utils import get_node_function
    from ..utils.test_utils import get_node_method
    from ..utils.test_utils import get_node_code
    from ..utils.test_utils import get_node_code_object
    from ..utils.test_utils import get_node_arguments
    from ..utils.test_utils import get_node_arg
    from ..utils.test_utils import get_node_keyword
    from ..utils.test_utils import get_node_return
    from ..utils.test_utils import get_node_assign

# Generated at 2022-06-18 00:11:13.336500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-18 00:11:24.209921
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:27.459287
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module is not None


# Generated at 2022-06-18 00:11:34.620571
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None

# Generated at 2022-06-18 00:11:43.789157
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:50.644840
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:12:06.479770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types

    module = make_test_module(
        """
        def foo():
            pass
        """
    )
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:12:17.141518
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:12:24.787150
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import generate_visitor_test
    from ..utils.test_utils import get_ast

    source = '''
    import os
    import sys
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    '''
    tree = get_ast(source)
    visitor = Python2FutureTransformer()
    visitor.visit(tree)
    assert_source_equal(expected, tree)
    generate_visitor_test(Python2FutureTransformer, 'visit_Module', source, expected)

# Generated at 2022-06-18 00:12:34.276232
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet_to_ast

    source = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    expected = """
    def foo():
        pass
    """
    ast_source = source_to_ast(source)
    ast_expected = snippet_to_ast(expected)
    transformer = Python2FutureTransformer()
    transformer.visit(ast_source)
    assert ast.dump(ast_source) == ast.dump(ast_expected)

# Generated at 2022-06-18 00:12:36.513853
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False


# Generated at 2022-06-18 00:12:46.906338
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import compare_ast
    from ..utils.ast import parse
    from ..utils.ast import get_ast
    from ..utils.ast import get_source
    from ..utils.ast import get_source_segment
    from ..utils.source import source
    from ..utils.source import get_source_segment
    from ..utils.source import get_source_segments
    from ..utils.source import get_source_segment_at
    from ..utils.source import get_source_segments_at
    from ..utils.source import get_source_segment_range
    from ..utils.source import get

# Generated at 2022-06-18 00:12:55.731813
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:06.590269
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source

    module = make_test_module()
    module.body.append(ast.Expr(value=ast.Name(id='x')))
    module.body.append(ast.Expr(value=ast.Name(id='y')))
    module.body.append(ast.Expr(value=ast.Name(id='z')))

    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:13:12.384500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        def foo():
            pass
    ''')
    expected = source('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    ''')

    tree = get_ast(source)
    new_tree = Python2FutureTransformer().visit(tree)
    assert compare_asts(expected, new_tree)

# Generated at 2022-06-18 00:13:22.518757
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_tree
    from ..utils.visitor import get_tree_changed
    from ..utils.visitor import set_tree_changed

    module = make_test_module(
        """
        def foo():
            pass
        """,
        target=(2, 7),
    )
    set_tree_changed(False)
    module = Python2FutureTransformer().visit(module)
    assert get_tree_changed()

# Generated at 2022-06-18 00:13:45.363577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_node
    from ..utils.test_utils import get_source_snippet

    source = get_source_snippet('test_Python2FutureTransformer_visit_Module')
    expected = get_source_snippet('test_Python2FutureTransformer_visit_Module_expected')
    node = get_ast_node(source)
    expected_node = get_ast_node(expected)
    transformer = Python2FutureTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-18 00:13:49.238334
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source

    source_code = source('''
        def foo():
            pass
    ''')
    tree = ast.parse(source_code)
    Python2FutureTransformer().visit(tree)
    print_python_source(tree)

# Generated at 2022-06-18 00:13:57.406930
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.visitor import print_ast

# Generated at 2022-06-18 00:14:08.250787
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass


# Generated at 2022-06-18 00:14:18.386320
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.future import future_absolute_import, future_division, future_print_function, future_unicode_literals
    from ..utils.visitor import dump_visitor
    from ..utils.snippet import snippet
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.future import future_absolute_import, future_division, future_print_function, future_unicode_literals
    from ..utils.visitor import dump_visitor

    source_ = source('''
    def foo():
        pass
    ''')

    expected_ast = get_ast(source_)

# Generated at 2022-06-18 00:14:28.380724
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:14:31.009296
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:14:37.420033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import compare_ast

    source_ast = ast.parse(source('python2', 'future'))
    target_ast = ast.parse(source('python3', 'future'))
    transformer = Python2FutureTransformer()
    result_ast = transformer.visit(source_ast)
    assert compare_ast(result_ast, target_ast)

# Generated at 2022-06-18 00:14:38.326516
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-18 00:14:46.508087
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_node_linenos
    from ..utils.source import source_to_node_col_offsets
    from ..utils.source import source_to_node_end_lineno
    from ..utils.source import source_to_node_end_col_offset
    from ..utils.source import source_to_node_type
    from ..utils.source import source_to_node_names
    from ..utils.source import source_to_node_fields
    from ..utils.source import source_to_node_field

# Generated at 2022-06-18 00:15:18.489629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:15:19.835172
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-18 00:15:29.167676
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.source import source_info

    source_code = source(
        """
        def foo():
            pass
        """
    )
    tree = ast.parse(source_code)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert source_info(tree) == source(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:15:36.310639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.ast_helper import ast_to_str

    @snippet
    def code():
        pass

    node = code.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass
'''

# Generated at 2022-06-18 00:15:44.703098
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source_code
    from ..utils.test_utils import get_source_code_node

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = get_ast(source)
    node = get_ast_node(tree, ast.Module)
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert_ast_

# Generated at 2022-06-18 00:15:55.500417
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    import os
    import sys
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-18 00:16:03.751975
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:16:15.085128
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_tree_diff
    from ..utils.visitor import dump_tree_to_str
    from ..utils.visitor import dump_tree_to_str_diff
    from ..utils.visitor import dump_tree_to_str_diff_color
    from ..utils.visitor import dump_tree_to_str_color
    from ..utils.visitor import dump_tree_to_str_color_diff
    from ..utils.visitor import dump_tree_to_str_color_diff_color
    from ..utils.visitor import dump_tree_to_str_color_diff_color_diff
    from ..utils.visitor import dump_tree_to_str_color_diff_color

# Generated at 2022-06-18 00:16:25.387629
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_node
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_visit
    from ..utils.source import source_to_walk
    from ..utils.source import source_to_string
    from ..utils.source import source_to_format
    from ..utils.source import source_to_json
    from ..utils.source import source_to_yaml
    from ..utils.source import source_to_pickle
    from ..utils.source import source_to_bytes
    from ..utils.source import source_to_file
    from ..utils.source import source_to_path
   

# Generated at 2022-06-18 00:16:34.790718
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer._tree_changed is False
    assert Python2FutureTransformer._changed_targets == set()
    assert Python2FutureTransformer._changed

# Generated at 2022-06-18 00:17:58.750277
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.compare import compare_ast

    source_code = source(imports)
    expected_ast = dump_ast(imports)

    tree = ast.parse(source_code)
    actual_ast = dump_visitor(Python2FutureTransformer, tree)

    assert compare_ast(actual_ast, expected_ast)

# Generated at 2022-06-18 00:18:04.659632
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    assert_source(
        Python2FutureTransformer,
        """
        def foo():
            pass
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:18:11.904316
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_visitor
    from ..utils.test_utils import get_node

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    node = get_node(source, ast.Module)
    visitor = get_visitor(Python2FutureTransformer, node)
    assert_source_equal(expected, visitor)