

# Generated at 2022-06-18 00:08:22.247040
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:08:28.790021
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:08:38.992955
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import ast_pprint
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import visit_Module
    from ..utils.visitor import visit_ImportFrom
    from ..utils.visitor import visit_Import
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_Name
    from ..utils.visitor import visit_Str
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit_alias
    from ..utils.visitor import visit

# Generated at 2022-06-18 00:08:50.210553
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:08:57.261569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_fixers
    from ..utils.source import source_to_visitors
    from ..utils.source import source_to_format
    from ..utils.source import source_to_format_all
    from ..utils.source import source_to_format_code
    from ..utils.source import source_to_format_code_all
    from ..utils.source import source_to_format_tokens
    from ..utils.source import source_to_format

# Generated at 2022-06-18 00:09:04.452856
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.source import source

    @snippet
    def source_code():
        def f():
            pass

    @snippet
    def expected_code():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass

    tree = ast.parse(source_code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert source(tree) == source(expected_code.get_tree())

# Generated at 2022-06-18 00:09:14.121489
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_visit
    from ..utils.source import source_to_walk

    source = """
    def foo():
        pass
    """
    tree = source_to_tree(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert source_to_code(tree) == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    assert source_to_ast

# Generated at 2022-06-18 00:09:23.645590
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:09:34.508355
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    node = ast.parse('print("Hello, World!")')
    TestTransformer().visit(node)

# Generated at 2022-06-18 00:09:44.567024
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:16.582807
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:26.273508
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:10:35.948973
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.fixtures import future_imports, future_imports_with_comments

    @snippet
    def code_snippet():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

    @snippet
    def code_snippet_with_comments():
        # comment
        from __future__ import absolute_import
        # comment
        from __future__ import division
        # comment
        from __future__ import print_function
        # comment
        from __future__ import unicode_literals
        # comment


# Generated at 2022-06-18 00:10:43.869313
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_node

    source = get_source('def f(): pass')
    node = get_ast_node(source, ast.Module)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert_ast_equal(new_node, get_ast(imports.get_source(future='__future__') + source))

# Generated at 2022-06-18 00:10:52.425458
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source
    from ..utils.test_utils import transform_ast
    from ..utils.test_utils import transform_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    """
    module = parse_source(source)

# Generated at 2022-06-18 00:11:01.716598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_and_code
    from ..utils.source import source_to_ast_and_code_and_tree
    from ..utils.source import source_to_ast_and_code_and_tree_and_module
    from ..utils.source import source_to_ast_and_code_and_tree_and_module_and_tree
    from ..utils.source import source_to_ast_and_code_and_tree_and_module_and_tree_and_code
    from ..utils.source import source

# Generated at 2022-06-18 00:11:08.957699
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_tree_types
    from ..utils.visitor import dump_tree_types_source
    from ..utils.visitor import dump_tree_types_source_tokens
    from ..utils.visitor import dump_tree_types_tokens
    from ..utils.visitor import dump_tree_types_tokens_source
    from ..utils.visitor import dump_tree_types_tokens_source_types
    from ..utils.visitor import dump_tree_types

# Generated at 2022-06-18 00:11:19.280653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_tree

    source_1 = """
    import os
    import sys
    import math
    """
    source_2 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import math
    """
    tree_1 = get_ast(source_1)
    tree_2 = get_ast(source_2)
    transformer = Python2FutureTransformer()
    tree_3 = transformer.visit(tree_1)
    print(dump_tree(tree_3))
    assert compare_asts(tree_2, tree_3)

# Generated at 2022-06-18 00:11:30.417149
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:35.447670
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_tree
    from ..utils.snippet import snippet
    from ..utils.fixtures import future_imports_module

    source = source(future_imports_module)
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert compare_asts(tree, new_tree, transformer)
    assert transformer.tree_changed
    assert dump_tree(new_tree) == snippet.get_ast(future_imports_module)

# Generated at 2022-06-18 00:11:45.969217
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import ast_to_source
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import compare_source

    # Given

# Generated at 2022-06-18 00:11:54.471746
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:11:55.848778
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:12:05.070180
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass

    @snippet
    def module_with_imports():
        import os
        import sys
        import math

        def f():
            pass


# Generated at 2022-06-18 00:12:11.546040
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:12:12.644846
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:12:17.062831
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    assert_source(
        Python2FutureTransformer,
        """
        import os
        import sys
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        """
    )

# Generated at 2022-06-18 00:12:22.347704
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:12:28.656549
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:12:39.319267
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass

    tree = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == imports.get

# Generated at 2022-06-18 00:12:54.508143
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_node
    from ..utils.visitor import node_to_source
    from ..utils.compare import compare_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    node = source_to_node(source)
    node = Python2FutureTransformer().visit(node)
    actual = node_to_source(node)
    compare_ast(expected, actual)

# Generated at 2022-06-18 00:13:00.598471
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..transpile import Transpiler
    from ..utils.source import source

    source_code = source(imports)
    tree = ast.parse(source_code)
    transpiler = Transpiler()
    transpiler.register_transformer(Python2FutureTransformer)
    transpiler.transpile_tree(tree)
    assert source_code != source(tree)

# Generated at 2022-06-18 00:13:01.779967
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)


# Generated at 2022-06-18 00:13:11.816320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'


# Generated at 2022-06-18 00:13:21.892727
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:31.264650
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import visit_and_dump_ast
    from ..utils.visitor import visit_and_dump_source

    module = make_test_module()
    module.body = [ast.Expr(value=ast.Str(s='Hello world'))]
    module = visit_and_dump_ast(Python2FutureTransformer, module)
    module = visit_and_dump_source(Python2FutureTransformer, module)

# Generated at 2022-06-18 00:13:40.682201
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:49.205642
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    # Test 1:
    # Check that the transformer prepends the module with the following imports:
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    #
    # The module before transformation:
    #
    # def foo():
    #     pass
    #
    # The module after transformation:
    #
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from

# Generated at 2022-06-18 00:13:56.192015
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import roundtrip

    source = """
    import os
    import sys
    """

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    """

    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert_source_equal(expected, tree)
    roundtrip(tree)

# Generated at 2022-06-18 00:14:03.831238
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.fake import FakeFile
    from ..utils.source import source
    from ..utils.ast import compare_ast

    source = source('''
    def foo():
        pass
    ''')

    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)

    expected = source('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    ''')

    assert compare_ast(FakeFile(expected), tree)

# Generated at 2022-06-18 00:14:28.971063
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import GenericNodeTransformer
    from .base import GenericNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import walk
    from .base import walk_fields
    from .base import walk_generic
    from .base import walk_recursive
    from .base import walk_recursive_to_parent
    from .base import walk_to_parent
    from .base import walk_to_parent_generic
    from .base import walk_to_parent_recursive
    from .base import walk_to_parent_recursive_generic


# Generated at 2022-06-18 00:14:32.988380
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def code():
        print('hello')

    node = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert astor.to_source(node) == imports.get_source(future='__future__') + code.get_source()

# Generated at 2022-06-18 00:14:44.087198
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        pass

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:14:55.903105
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:05.592896
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import AstBuilder
    from ..utils.source_code import SourceCode
    from ..utils.snippet import snippet
    from ..utils.ast_visitor import AstVisitor

    @snippet
    def source():
        pass

    tree = AstBuilder.parse(source.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert SourceCode.from_ast(tree) == imports.get_source(future='__future__') + source.get_source()

# Generated at 2022-06-18 00:15:09.487480
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source

    source = get_source(Python2FutureTransformer)
    node = get_node(Python2FutureTransformer)
    assert_equal_source(Python2FutureTransformer, source, node)

# Generated at 2022-06-18 00:15:12.169410
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:15:24.746427
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:30.515473
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:15:35.502815
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import assert_tree_equal
    from ..utils.test_utils import generate_ast_tree

    tree = generate_ast_tree(imports.get_source(future='__future__'))
    assert_tree_equal(tree, Python2FutureTransformer().visit(tree))

# Generated at 2022-06-18 00:16:16.521225
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    import astor
    import textwrap
    import unittest

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:16:21.223535
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import ast_pprint
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_ImportFrom(self, node):
            print(node.module)

    source = source(imports.get_source(future='__future__'))
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    ast_pprint(tree)
    Visitor().visit(tree)

# Generated at 2022-06-18 00:16:27.931555
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source

    tree = make_dummy_tree(source("""
        def foo():
            pass
    """))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source(tree) == source("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    """)

# Generated at 2022-06-18 00:16:33.758087
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:16:39.603126
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    assert_source_equal(Python2FutureTransformer, TestTransformer)

# Generated at 2022-06-18 00:16:45.214471
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.visit_Module.__module__ == 'typed_astunparse.unparser.Python2FutureTransformer'
    assert transformer.visit_Module.__annotations__ == {'node': 'Module', 'return': 'Module'}


# Generated at 2022-06-18 00:16:50.791021
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:56.690619
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('pass')) == ast.parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'pass'
    )

# Generated at 2022-06-18 00:16:58.081324
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:17:02.159781
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    transformer = Python2FutureTransformer()
    node = ast.parse(source(module))
    node = transformer.visit(node)
    assert source(node) == source(imports(future='__future__')) + source(module)