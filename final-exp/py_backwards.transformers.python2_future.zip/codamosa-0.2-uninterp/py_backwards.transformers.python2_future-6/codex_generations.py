

# Generated at 2022-06-18 00:08:14.825813
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-18 00:08:21.760939
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source
    from ..utils.compare import compare_ast

    tree = make_dummy_tree(source("""
    def foo():
        pass
    """))
    Python2FutureTransformer().visit(tree)
    expected = source("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """)
    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:08:31.444374
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .utils import get_ast_node_or_raise

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        pass

    node = get_ast_node_or_raise(code)
    assert isinstance(node, ast.Module)
    assert node.body == []

    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert isinstance(node, ast.Module)
    assert node.body == imports.get_

# Generated at 2022-06-18 00:08:38.185056
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_tree

    source_ = source(imports(future='__future__'))
    expected = get_ast(source_)

    source_ = source('')
    tree = get_ast(source_)

    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

    assert compare_asts(tree, expected)
    assert transformer.tree_changed is True

    dump_tree(tree)

# Generated at 2022-06-18 00:08:49.326644
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.visit_Module.__module__ == 'future.transforms.standard_library.Python2FutureTransformer'
    assert transformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'
    assert transformer.visit_Module.__annotations__ == {'node': 'Module', 'return': 'Module'}
   

# Generated at 2022-06-18 00:08:56.890607
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import source_to_ast
    from ..utils.ast_helper import source_to_str
    from ..utils.ast_helper import str_to_ast
    from ..utils.ast_helper import str_to_source
    from ..utils.ast_helper import tree_to_str
    from ..utils.ast_helper import tree_to_source
    from ..utils.ast_helper import tree_to_str
    from ..utils.ast_helper import tree_to_source

# Generated at 2022-06-18 00:09:05.717076
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python3_print import Python3PrintTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def test():
        print('Hello world!')

    node = ast.parse(test.get_source())
    Python3PrintTransformer().visit(node)
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == imports.get_source(future='__future__') + test.get_source()

# Generated at 2022-06-18 00:09:13.176499
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import ast_equal

    source_code = """
    def foo():
        pass
    """
    expected_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    source_ast = source.to_ast(source_code)
    expected_ast = source.to_ast(expected_code)
    actual_ast = Python2FutureTransformer().visit(source_ast)
    assert ast_equal(actual_ast, expected_ast)

# Generated at 2022-06-18 00:09:21.358290
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.visit_Module.__module__ == 'typed_astunparse.unparser.transformers.Python2FutureTransformer'


# Generated at 2022-06-18 00:09:32.677340
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:44.482039
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import dump_ast
    from ..utils.visitor import print_ast

    source = """
    def foo():
        pass
    """
    tree = source_to_ast(source)
    print_ast(tree)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    print_ast(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:09:47.202558
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse("pass")) == ast.parse(imports.get_source(future='__future__') + "pass")

# Generated at 2022-06-18 00:10:17.397359
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:26.985644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTest
    from .test_base import transform_and_reload_module

    class Test(BaseNodeTransformerTest):
        target = (2, 7)
        transformer = Python2FutureTransformer

        def test_visit_Module(self):
            module = ast.parse('import os')
            module = self.transformer().visit(module)
            assert_source_equal(module, '''
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
                import os
            ''')

    transform_and_reload_module(Test)

# Generated at 2022-06-18 00:10:36.507357
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        import os
        import sys

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:10:40.005067
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:10:49.469808
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.ast_helper import ast_to_source
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_source(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:10:59.566999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:11:07.301110
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.generic_visit.__module__ == __name

# Generated at 2022-06-18 00:11:10.996774
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:11:25.002838
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import ast_pprint
    from ..utils.visitor import print_visitor
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_ast_up
    from ..utils.visitor import visit_ast_down
    from ..utils.visitor import visit_ast_bottom_up
    from ..utils.visitor import visit_ast_top_down
    from ..utils.visitor import visit_ast_depth_first
    from ..utils.visitor import visit_ast_breadth_first
    from ..utils.visitor import visit_ast_leaves_first
    from ..utils.visitor import visit_ast_leaves_last
    from ..utils.visitor import visit_ast_nodes
    from ..utils.visitor import visit_ast

# Generated at 2022-06-18 00:11:33.938552
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_visit
    from ..utils.source import source_to_walk
    from ..utils.source import source_to_pretty
    from ..utils.source import source_to_format
    from ..utils.source import source_to_gast
    from ..utils.source import source_to_astor
    from ..utils.source import source_to_astunparse
    from ..utils.source import source_to_asttokens
    from ..utils.source import source_to_astpretty
    from ..utils.source import source_to_astformat

# Generated at 2022-06-18 00:11:43.419135
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:11:46.099162
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import parse_ast

    # Given

# Generated at 2022-06-18 00:11:54.557216
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_ast_node
    from ..utils.source import source_to_ast_node_or_error
    from ..utils.source import source_to_ast_node_or_none
   

# Generated at 2022-06-18 00:12:03.068093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import assert_ast_equal
    from ..utils.snippet import snippet

    @snippet
    def before():
        pass

    @snippet
    def after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

    before_ast = ast.parse(before.get_source())
    after_ast = ast.parse(after.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(before_ast)
    assert_ast_equal(before_ast, after_ast)

# Generated at 2022-06-18 00:12:10.185883
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_as_string
    from ..utils.test_utils import get_tree
    from ..utils.test_utils import parse_string
    from ..utils.test_utils import print_node
    from ..utils.test_utils import print_tree
    from ..utils.test_utils import transform_node
    from ..utils.test_utils import transform_tree
    from ..utils.test_utils import transform_tree_to_string
    from ..utils.test_utils import transform_tree_to_string_with_imports
    from ..utils.test_utils import transform_tree_to_string_with_imports_and_future
    from ..utils.test_utils import transform

# Generated at 2022-06-18 00:12:18.577149
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source
    from ..utils.test_utils import compare_ast
    from ..utils.test_utils import dedent_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_name
    from ..utils.test_utils import get_node_type
    from ..utils.test_utils import get_node_lineno
    from ..utils.test_utils import get_node_col_offset
    from ..utils.test_utils import get_node_end_lineno
    from ..utils.test_utils import get_node_end_col_offset

# Generated at 2022-06-18 00:12:25.487561
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_visit
    from ..utils.source import source_to_walk
    from ..utils.source import source_to_node
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_nodes_names
    from ..utils.source import source_to_nodes_types
    from ..utils.source import source_to_nodes_attributes
    from ..utils.source import source_to_nodes_attributes_names
    from ..utils.source import source_to_nodes_attributes_values

# Generated at 2022-06-18 00:12:35.649411
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_fixers
    from ..utils.source import source_to_visitors
    from ..utils.source import source_to_visit_methods
    from ..utils.source import source_to_node_classes
    from ..utils.source import source_to_node_attributes
    from ..utils.source import source_to_node_attribute_names
    from ..utils.source import source_to_node_fields
    from ..utils.source import source_

# Generated at 2022-06-18 00:12:44.267996
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-18 00:12:47.475356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source


# Generated at 2022-06-18 00:12:48.797450
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:12:49.760639
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-18 00:12:57.629818
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory
    from ..utils.source_factory import source_info
    from ..utils.source_factory import source_info_factory
    from ..utils.source_factory import source_info_list
    from ..utils.source_factory import source_info_list_factory
    from ..utils.source_factory import source_list
    from ..utils.source_factory import source_list_factory
    from ..utils.source_factory import source_map
    from ..utils.source_factory import source_map_factory
    from ..utils.source_factory import source_map_list
    from ..utils.source_factory import source_map_

# Generated at 2022-06-18 00:13:00.109395
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-18 00:13:02.836671
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None


# Generated at 2022-06-18 00:13:13.078323
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:22.806386
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_code import SourceCode
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.source_code import SourceCode
    from ..utils.ast_builder import build_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.source_code import SourceCode
    from ..utils.ast_builder import build_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.source_code import SourceCode
    from ..utils.ast_builder import build_ast
    from ..utils.visitor import NodeVisitor

# Generated at 2022-06-18 00:13:24.399817
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:13:46.149052
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_and_reparse
    from ..utils.test_utils import transform_and_reparse_snippet

    # Test constructor
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

    # Test visit_Module
    assert_equal_ast(
        transformer.visit(parse_ast('pass')),
        parse_snippet(imports(future='__future__')) + parse_ast('pass')
    )

    # Test transform_and_reparse

# Generated at 2022-06-18 00:13:52.985075
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:58.047965
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        def foo():
            pass

    node = ast.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:14:03.020955
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast

    source_code = source(
        """
        def f():
            pass
        """
    )
    tree = ast.parse(source_code)
    visit_ast(tree, Python2FutureTransformer)
    print_python_source(tree)

# Generated at 2022-06-18 00:14:11.312222
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_tree

    module = make_test_module(__name__)
    module = Python2FutureTransformer().visit(module)
    assert module is not None

# Generated at 2022-06-18 00:14:21.647381
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_tokens
    from ..utils.source import tokens_to_source
    from ..utils.source import source_to_ast_and_tokens
    from ..utils.source import ast_and_tokens_to_source
    from ..utils.source import ast_to_tokens
    from ..utils.source import tokens_to_ast
    from ..utils.source import ast_and_tokens_to_source
    from ..utils.source import source_to_ast_and_tokens
    from ..utils.source import ast_and_tokens_to_source
    from ..utils.source import ast_and_tokens_to_source

# Generated at 2022-06-18 00:14:31.214354
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:14:42.648322
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_module
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_groups
    from ..utils.source import source_to_token_group_tuples
    from ..utils.source import source_to_token_tuples
    from ..utils.source import source_to_token_values
    from ..utils.source import source_to_token_value_pairs
    from ..utils.source import source_to_token_value_triples
    from ..utils.source import source_to_token_value_quadruples
    from ..utils.source import source_to_

# Generated at 2022-06-18 00:14:48.053914
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_code import SourceCode
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    
    source_code = SourceCode("""
    def f():
        pass
    """)
    tree = build_ast(source_code)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert tree.body[0].name == 'f'
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Pass)
    
    transformer = Python2FutureTransformer()
    tree

# Generated at 2022-06-18 00:14:56.915231
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def module():
        pass

    transformer = Python2FutureTransformer()
    module_node = module.get_ast()
    module_node = transformer.visit(module_node)
    assert ast_to_str(module_node) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass'''

# Generated at 2022-06-18 00:15:37.856419
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source
    from ..utils.source import Source
    from ..utils.source import Code
    from ..utils.source import File
    from ..utils.source import Module
    from ..utils.source import Function
    from ..utils.source import Class
    from ..utils.source import Statement
    from ..utils.source import Expression
    from ..utils.source import Annotation
    from ..utils.source import Comment
    from ..utils.source import BlankLine
    from ..utils.source import dedent
    from ..utils.source import indent
    from ..utils.source import join
    from ..utils.source import split

# Generated at 2022-06-18 00:15:45.808095
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:53.730576
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node
    from ..utils.test_utils import get_node
    from ..utils.test_utils import parse_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    """
    module = parse_ast(source)
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert_node(module, expected)

# Generated at 2022-06-18 00:16:02.310948
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:13.913574
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import round_trip_dump_and_parse

    tree = parse_ast_tree(source="""
    import os
    import sys
    """)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(
        source=round_trip_dump_and_parse(new_tree),
        expected="""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """)

# Generated at 2022-06-18 00:16:21.513501
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_import_node
    from ..utils.fixtures import make_dummy_module_node
    from ..utils.fixtures import make_dummy_print_function_node
    from ..utils.fixtures import make_dummy_unicode_literals_node
    from ..utils.fixtures import make_dummy_absolute_import_node
    from ..utils.fixtures import make_dummy_division_node

    dummy_module_node = make_dummy_module_node()
    dummy_future_import_node = make_dummy_future_import_node()
    dummy_absolute_import_node = make_dummy_absolute_import_node()
    dummy_division_node = make_dummy_division_node()
    dummy_print_function_node = make_

# Generated at 2022-06-18 00:16:26.342910
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse

    source = source(imports)
    tree = parse(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    print(dump(tree))
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:16:34.727923
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source2ast
    from ..utils.visitor import dump_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source2ast
    from ..utils.visitor import dump_ast
    from ..utils.compare import compare_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    """
    tree = source2ast(source)
    tree = Python2FutureTransformer().visit(tree)
    assert compare_ast(dump_ast(tree), expected)

# Generated at 2022-06-18 00:16:41.462684
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import dump_ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target = Python2FutureTransformer.target
        transformer = Python2FutureTransformer

        def test_simple(self):
            tree = ast.parse(source("""
                def f():
                    pass
            """))
            new_tree = self.transform(tree)
            self.assertEqual(
                dump_ast(new_tree),
                source("""
                    from __future__ import absolute_import
                    from __future__ import division
                    from __future__ import print_function
                    from __future__ import unicode_literals
                    
                    def f():
                        pass
                """)
            )



# Generated at 2022-06-18 00:16:44.143219
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source


# Generated at 2022-06-18 00:18:09.615098
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_node_for_version

    # Test that the transformer does not change the tree if the target version is not 2.7
    node = get_node_for_version('def f(): pass', (3, 6))
    assert_tree_not_changed(node, Python2FutureTransformer)

    # Test that the transformer does not change the tree if the target version is 2.7
    node = get_node_for_version('def f(): pass', (2, 7))
    assert_tree_changed(node, Python2FutureTransformer)

    # Test that the transformer prepends the module with the correct imports
