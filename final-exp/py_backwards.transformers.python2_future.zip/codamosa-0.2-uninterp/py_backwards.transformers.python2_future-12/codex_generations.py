

# Generated at 2022-06-18 00:08:22.061286
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    import astunparse
    import textwrap
    import sys
    import os
    import io
    import unittest
    import unittest.mock

    class TestPython2FutureTransformer_visit_Module(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(ast.AST, 'assertAstEqual')
            self.addTypeEqualityFunc(str, 'assertMultiLineEqual')
            self.addTypeEqualityFunc(str, 'assertEqual')

# Generated at 2022-06-18 00:08:30.116211
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal

    source = """
    import os
    import sys
    """.strip()
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """.strip()
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert_source_equal(expected, tree)

# Generated at 2022-06-18 00:08:39.905761
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import print_tree
    from ..utils.visitor import visit_and_assert_tree
    from ..utils.visitor import visit_and_assert_tree_unchanged

    # Test that visit_Module prepends module with:
    #     from __future__ import absolute_import
    #     from __future__ import division
    #     from __future__ import print_function
    #     from __future__ import unicode_literals
    #
    # Test that visit_Module does not prepend module with:
    #     from __future__ import absolute_import
    #     from __future__ import division
    #     from __future__ import print_function
    #     from __future__ import unicode_literals
    # if module already contains:
    #    

# Generated at 2022-06-18 00:08:51.143533
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tree
    from ..utils.visitor import visit_tree
    from ..utils.visitor import visit_tree_recursive


# Generated at 2022-06-18 00:08:54.714419
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from ..utils.source import source
    from ..utils.visitor import dump_Python_AST
    from ..utils.visitor import dump_Python_source

    make_fixtures(__file__,
                  lambda: [(Python2FutureTransformer, source('2to3', 'imports.py'))],
                  globals())

    __test__ = {name: value for name, value in locals().items()
                if name.startswith('test_')}

# Generated at 2022-06-18 00:09:04.103131
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:13.394295
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_ast_module
    from ..utils.visitor import visit_ast_node

    source_text = source(
        """
        def f(x):
            return x + 1
        """
    )
    tree = ast.parse(source_text)
    print_python_source(tree)
    visit_ast(tree, Python2FutureTransformer)
    print_python_source(tree)
    visit_ast_module(tree, Python2FutureTransformer)
    print_python_source(tree)
    visit_ast_node(tree, Python2FutureTransformer)
    print_python_source(tree)

# Generated at 2022-06-18 00:09:23.314486
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'

# Generated at 2022-06-18 00:09:34.348579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_as_ast_node
    from ..utils.test_utils import get_ast_as_source

    source = get_source('def foo():\n    pass')
    expected = get_source('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef foo():\n    pass')
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:09:44.442121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:09:52.835336
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:10:02.028349
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python3_future import Python3FutureTransformer
    from .python3_unicode import Python3UnicodeTransformer
    from .python3_division import Python3DivisionTransformer
    from .python3_print import Python3PrintTransformer
    from .python3_absolute_import import Python3AbsoluteImportTransformer
    from .python3_annotations import Python3AnnotationsTransformer
    from .python3_raise import Python3RaiseTransformer
    from .python3_nonzero import Python3NonzeroTransformer
    from .python3_metaclass import Python3MetaclassTransformer

# Generated at 2022-06-18 00:10:04.672596
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        def test_constructor(self):
            self.assertIsInstance(Python2FutureTransformer(), BaseNodeTransformer)

    Test().test_constructor()


# Generated at 2022-06-18 00:10:12.383241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_body
    from ..utils.ast_helpers import get_ast_module
    from ..utils.ast_helpers import get_ast_source
    from ..utils.ast_helpers import get_ast_source_code
    from ..utils.ast_helpers import get_ast_source_code_from_ast_module
    from ..utils.ast_helpers import get_ast_source_from_ast_module
    from ..utils.ast_helpers import get_ast_source_from_ast_source
    from ..utils.ast_helpers import get_ast_source_from_ast_source_code
    from ..utils.ast_helpers import get_ast_source_from_source_code

# Generated at 2022-06-18 00:10:22.723974
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:30.627709
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:38.665206
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    module = make_test_module(
        """
        def foo():
            pass
        """,
        target=(2, 7)
    )
    transformer = Python2FutureTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:10:48.058304
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import round_trip
    from ..utils.compare_ast import compare_ast
    from ..utils.source import source_to_ast

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = source_to_ast(source)
    new_tree = round_trip(tree, Python2FutureTransformer)
    assert compare_ast(ast.parse(expected), new_tree)

# Generated at 2022-06-18 00:10:59.153710
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_values
    from ..utils.source import source_to_token_offsets
    from ..utils.source import source_to_token_end_offsets
    from ..utils.source import source_to_token_lines
    from ..utils.source import source_to_token_columns
    from ..utils.source import source_to_token_end_columns
    from ..utils.source import source_to_token_line_offsets
    from ..utils.source import source_to_token_line_end_offsets

# Generated at 2022-06-18 00:11:05.307366
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.visit_Module.__module__ == 'future.transforms.standard_library.Python2FutureTransformer'


# Generated at 2022-06-18 00:11:18.936007
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python3_print import Python3PrintTransformer
    from .python3_division import Python3DivisionTransformer
    from .python3_absolute_import import Python3AbsoluteImportTransformer
    from .python3_unicode_literals import Python3UnicodeLiteralsTransformer
    from .python3_raise import Python3RaiseTransformer
    from .python3_nonzero import Python3NonzeroTransformer
    from .python3_metaclass import Python3MetaclassTransformer
    from .python3_dict_iter import Python3DictIterTransformer
    from .python3_dict_view import Python3

# Generated at 2022-06-18 00:11:22.391494
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-18 00:11:30.903943
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    expected = ast.Module(
        body=imports.get_body(future='__future__') + module.get_body()
    )

    actual = Python2FutureTransformer().visit(module.get_ast())

    assert_node_equal(expected, actual)

# Generated at 2022-06-18 00:11:41.123906
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = [ast.parse('print("Hello world")').body[0]]
            return self.generic_visit(node)  # type: ignore

    source = '''
    print("Hello world")
    '''

# Generated at 2022-06-18 00:11:51.615198
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target = (2, 7)
        code = '''
            def foo():
                pass
        '''
        expected_code = '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            def foo():
                pass
        '''

    assert_source_equal(Test)

# Generated at 2022-06-18 00:11:59.242521
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:12:07.158297
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:12:09.850050
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-18 00:12:18.028094
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:12:19.400292
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-18 00:12:36.050173
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import get_node_source
    from ..utils.visitor import get_source_of_node_at_index
    from ..utils.visitor import get_source_of_node_at_lineno
    from ..utils.visitor import get_source_of_node_at_offset
    from ..utils.visitor import get_source_of_node_at_position
    from ..utils.visitor import get_source_of_node_at_range
    from ..utils.visitor import get_source_of_node_at_slice
    from ..utils.visitor import get_source_of_node_at_slices

# Generated at 2022-06-18 00:12:46.473856
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet

# Generated at 2022-06-18 00:12:55.423880
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from ..utils.source import source


# Generated at 2022-06-18 00:12:56.415257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:13:06.724771
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast

    # Given
    transformer = Python2FutureTransformer()
    node = ast.Module(body=[])

    # When
    actual = transformer.visit(node)

    # Then
    expected = ast.Module(body=imports.get_body(future='__future__'))
    assert compare_ast(actual, expected) == True
    assert ast_to_str(actual) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n'

# Generated at 2022-06-18 00:13:16.411403
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:24.015968
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_trees
    from ..utils.test_utils import assert_equal_types
    from ..utils.test_utils import assert_equal_values
    from ..utils.test_utils import assert_is_instance
    from ..utils.test_utils import assert_is_not_instance
    from ..utils.test_utils import assert_is_subclass
    from ..utils.test_utils import assert_is_not_subclass
    from ..utils.test_utils import assert_raises
    from ..utils.test_utils import assert_raises

# Generated at 2022-06-18 00:13:31.567429
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import get_ast

    code = """
    def foo():
        pass
    """
    tree = get_ast(code)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:13:41.080622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source_snippet import source_snippet
    from ..utils.ast_source import ast_source
    from ..utils.ast_compare import compare_asts

    source = source_snippet(
        """
        import os
        import sys
        """,
        filename='<unknown>',
        mode='exec',
    )
    expected = source_snippet(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        """,
        filename='<unknown>',
        mode='exec',
    )
    expected_ast = ast.parse(expected)
    source_ast = ast.parse

# Generated at 2022-06-18 00:13:45.772066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:14:09.666621
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import dump_visitor
    from ..utils.visitor import dump_visitor_tree
    from ..utils.visitor import dump_visitor_tree_changed
    from ..utils.visitor import dump_visitor_tree_changed_only
    from ..utils.visitor import dump_visitor_tree_changed_only_source
    from ..utils.visitor import dump_visitor_tree_changed_source
    from ..utils.visitor import dump_visitor_tree_source
    from ..utils.visitor import dump_visitor_source
    from ..utils.visitor import dump_visitor_tree_source_changed
    from ..utils.visitor import dump_visitor_tree_source_changed_only

# Generated at 2022-06-18 00:14:20.535000
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python3_future import Python3FutureTransformer
    from .python4_future import Python4FutureTransformer
    from .python5_future import Python5FutureTransformer
    from .python6_future import Python6FutureTransformer
    from .python7_future import Python7FutureTransformer
    from .python8_future import Python8FutureTransformer
    from .python9_future import Python9FutureTransformer
    from .python10_future import Python10FutureTransformer
    from .python11_future import Python11FutureTransformer
    from .python12_future import Python12FutureTransformer

# Generated at 2022-06-18 00:14:22.061552
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:14:31.510750
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:38.410197
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
        import sys
        import os
    """
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        import os
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:14:44.729449
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast
    from ..utils.visitor import dump_tree

    source_ = source(imports)
    tree = get_ast(source_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert compare_ast(new_tree, tree) is False
    assert dump_tree(new_tree) == dump_tree(tree)

# Generated at 2022-06-18 00:14:55.979526
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import parse_ast

    # Test that the transformer does not change the tree if the target version is not 2.7
    tree = parse_ast('print("Hello world")')
    transformer = Python2FutureTransformer(target=(3, 6))
    assert_tree_not_changed(transformer, tree)

    # Test that the transformer does not change the tree if the target version is 2.7
    tree = parse_ast('print("Hello world")')
    transformer = Python2FutureTransformer(target=(2, 7))

# Generated at 2022-06-18 00:15:07.578916
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    # Test with no changes
    source = '''
    def foo():
        pass
    '''
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, tree)
    assert_equal_code(new_tree, source)
    assert_equal_source(new_tree, source)

# Generated at 2022-06-18 00:15:14.925401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_str
    from ..utils.source import source_to_code_str
    from ..utils.source import source_to_module_str
    from ..utils.source import source_to_ast_repr
    from ..utils.source import source_to_code_repr
    from ..utils.source import source_to_module_repr
    from ..utils.source import source_to_ast_pprint
    from ..utils.source import source_to_code_pprint
    from ..utils.source import source_to_module_pprint
    from ..utils.source import source_to_ast_pretty

# Generated at 2022-06-18 00:15:23.364448
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    import ast
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(Python2FutureTransformer)
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    new_source = astor.to_source(new_tree)
    assert transformer._tree_changed is True
    assert new_source == source

# Generated at 2022-06-18 00:15:59.618801
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def test_code():
        print('Hello world!')

    expected_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print('Hello world!')
    """

    transformer = Python2FutureTransformer()
    actual_code = ast_to_str(transformer.visit(test_code.get_ast()))
    assert_ast_equal(expected_code, actual_code)

# Generated at 2022-06-18 00:16:05.916191
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import run_transformer

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    """
    node = get_node(source, ast.Module)
    new_node = run_transformer(Python2FutureTransformer, node)
    assert_source(get_source(new_node), expected)

# Generated at 2022-06-18 00:16:10.420217
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None


# Generated at 2022-06-18 00:16:19.012468
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import expect

    source = source('''
        def foo():
            pass
    ''')
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-18 00:16:25.153392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    source = """
    print('Hello World!')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello World!')
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:16:31.303433
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    assert_source(
        Python2FutureTransformer,
        """
        print('Hello World!')
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print('Hello World!')
        """
    )

# Generated at 2022-06-18 00:16:38.319665
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import os
        import sys

    @snippet
    def expected_module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys


# Generated at 2022-06-18 00:16:43.423167
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTest
    from .test_base import get_node

    class Test(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target = (2, 7)
        code = '''
            import os
            import sys
        '''
        expected_code = '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            import os
            import sys
        '''

    assert_source_equal(Test)

# Generated at 2022-06-18 00:16:51.314590
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_from_ast

    source = get_source("""
    import os
    import sys
    """)
    expected = get_source("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """)
    tree = get_ast(source)
    new_tree = transform(tree, Python2FutureTransformer)
    compare_ast(expected, new_tree)
    assert get_source_from_ast(new_tree) == expected

# Generated at 2022-06-18 00:16:57.322444
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    print('Hello world')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello world')
    """
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)