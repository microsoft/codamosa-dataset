

# Generated at 2022-06-18 00:08:16.508920
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_test_data

    source = get_test_data('test_Python2FutureTransformer_visit_Module.py')
    expected = get_test_data('test_Python2FutureTransformer_visit_Module_expected.py')
    transform_and_compare(Python2FutureTransformer, source, expected)

# Generated at 2022-06-18 00:08:23.711560
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast_str
    from ..utils.source import ast_str_to_source
    from ..utils.source import source_to_ast_str_to_source
    from ..utils.source import source_to_ast_to_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    assert source_to_ast_str_to_source(source) == expected
    assert source_to_ast_to_source(source) == expected

# Generated at 2022-06-18 00:08:32.933231
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import get_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    module = make_test_module(source)
    tree = get_ast(module)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert dump_source(tree) == expected

# Generated at 2022-06-18 00:08:43.002682
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast_visit
    from ..utils.source import ast_to_source_visit
    from ..utils.source import source_to_ast_visit_transformer
    from ..utils.source import ast_to_source_visit_transformer
    from ..utils.source import source_to_ast_visit_transformer_class
    from ..utils.source import ast_to_source_visit_transformer_class
    from ..utils.source import source_to_ast_visit_transformer_module
    from ..utils.source import ast_to_source_visit_transformer_module
    from ..utils.source import source_to_ast_visit_transformer_

# Generated at 2022-06-18 00:08:53.217068
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import get_ast
    from ..utils.visitor import get_source
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_source

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    module = make_test_module(source, target=(2, 7))
    module = visit_ast(Python2FutureTransformer, module)
    assert get

# Generated at 2022-06-18 00:08:57.406841
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:08:59.187638
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:09:09.877456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python3 import Python3Transformer
    from .python3future import Python3FutureTransformer
    from .python36 import Python36Transformer
    from .python36future import Python36FutureTransformer
    from .python37 import Python37Transformer
    from .python37future import Python37FutureTransformer
    from .python38 import Python38Transformer
    from .python38future import Python38FutureTransformer
    from .python39 import Python39Transformer
    from .python39future import Python39FutureTransformer
    from .python310 import Python310Transformer
    from .python310future import Python310FutureTransformer
    from .python311 import Python311Transformer

# Generated at 2022-06-18 00:09:20.163243
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import ast_to_source
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import source_to_ast
    from ..utils.ast_helper import source_to_str
    from ..utils.ast_helper import str_to_ast
    from ..utils.ast_helper import str_to_source
    from ..utils.ast_helper import to_source

# Generated at 2022-06-18 00:09:31.818522
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def code():
        def f(x):
            return x + 1

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f(x):
            return x + 1

    node = ast.parse(code.get_source())
    Python2FutureTransformer().visit(node)
    assert ast_to_str(node) == expected.get_source()

# Generated at 2022-06-18 00:09:43.266553
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:51.431392
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_ast_node
    from ..utils.source import source_to_ast_node_or_error
    from ..utils.source import source_to_ast_node_or_error_or

# Generated at 2022-06-18 00:10:00.316121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:04.888436
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:10:12.638799
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:10:23.102639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass

    @snippet
    def module_no_future():
        def foo():
            pass

    # Test with module with __future__ imports

# Generated at 2022-06-18 00:10:30.745847
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory
    from ..utils.ast_source import ast_source
    from ..utils.transformer_util import run_transformer_on_single_file

    source_code = source_factory.get_source(
        """
        def foo():
            pass
        """)
    expected_source_code = source_factory.get_source(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """)
    expected_ast = ast_factory.get_ast

# Generated at 2022-06-18 00:10:33.562309
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_source
    from ..utils.ast_helper import compare_ast


# Generated at 2022-06-18 00:10:41.135099
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import transform_ast
    from ..utils.test_utils import transform_snippet

    # Test with a module
    module = parse_snippet('def foo(): pass')
    expected = parse_snippet('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo(): pass
    ''')
    assert_ast_equal(expected, transform_ast(module, Python2FutureTransformer))

    # Test with a snippet
    snippet = 'def foo(): pass'

# Generated at 2022-06-18 00:10:50.946357
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.source import source

    module = make_test_module(
        """
        def f(x):
            return x
        """,
        target=(2, 7),
    )
    module = Python2FutureTransformer().visit(module)
    assert compare_ast(module, """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f(x):
        return x
    """)

# Generated at 2022-06-18 00:11:01.650909
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    assert_source(
        Python2FutureTransformer,
        """
        import os
        import sys
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys
        """
    )

# Generated at 2022-06-18 00:11:08.906420
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_tree_types
    from ..utils.visitor import dump_tree_types_source
    from ..utils.visitor import dump_tree_types_source_tokens
    from ..utils.visitor import dump_tree_types_source_tokens_types
    from ..utils.visitor import dump_tree_types_tokens
    from ..utils.visitor import dump_tree_types_tokens_types
    from ..utils.visitor import dump_tree_types

# Generated at 2022-06-18 00:11:19.193735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.visitor import visit
    from ..utils.visitor import visit_children

    # Test the constructor
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

    # Test the visit_Module() method
    tree = source.parse('x = 1')
    tree = visit(tree, transformer)

# Generated at 2022-06-18 00:11:29.090310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.generic_visit.__name__ == 'generic_visit'
    assert transformer.generic_visit.__doc__ == 'Called if no explicit visitor function exists for a node.'


# Generated at 2022-06-18 00:11:35.582369
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, dump_ast
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_visitor


# Generated at 2022-06-18 00:11:43.929449
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:11:50.819412
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:11:56.828687
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast

    source = source(__file__)
    tree = ast.parse(source)
    visit_ast(tree)
    print_python_source(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    print_python_source(tree)

# Generated at 2022-06-18 00:12:03.783320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source

    tree = make_dummy_tree(source("""
        def foo():
            pass
    """))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source(tree) == source("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    """)

# Generated at 2022-06-18 00:12:10.680171
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    # Test that the constructor of class Python2FutureTransformer works
    # correctly
    assert_equal_source(Python2FutureTransformer, '', '')
    assert_equal_source(Python2FutureTransformer, 'a', 'a')
    assert_equal_source(Python2FutureTransformer, 'a = 1', 'a = 1')

# Generated at 2022-06-18 00:12:25.258862
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.visitor import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_remove_future
    from ..utils.source import source_add_future
    from ..utils.source import source_remove_imports
    from ..utils.source import source_add_imports
    from ..utils.source import source_remove_comments
    from ..utils.source import source_add_comments
    from ..utils.source import source_remove_docstrings
    from ..utils.source import source_add_docstrings
    from ..utils.source import source_remove_blank_lines
    from ..utils.source import source_add_blank_

# Generated at 2022-06-18 00:12:29.584984
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_test_data

    test_data = get_test_data(__file__, 'test_Python2FutureTransformer_visit_Module.py')
    transform_and_compare(Python2FutureTransformer, test_data)

# Generated at 2022-06-18 00:12:40.265303
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:12:50.345321
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_trees
    from ..utils.test_utils import assert_equal_types
    from ..utils.test_utils import assert_equal_values
    from ..utils.test_utils import assert_is_instance
    from ..utils.test_utils import assert_is_not_instance
    from ..utils.test_utils import assert_is_subclass
    from ..utils.test_utils import assert_is_not_subclass
    from ..utils.test_utils import assert_raises
    from ..utils.test_utils import assert_raises

# Generated at 2022-06-18 00:12:54.038112
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.name == 'Python2FutureTransformer'
    assert transformer.description == 'Prepends module with: from __future__ import absolute_import, division, print_function, unicode_literals'


# Generated at 2022-06-18 00:13:00.055790
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:13:02.795101
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:13:13.049155
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    # Test that the constructor of class Python2FutureTransformer works
    # as expected
    assert_equal_ast(Python2FutureTransformer(), get_ast(''))

    # Test that the constructor of class Python2FutureTransformer works
    # as expected
    assert_equal_ast(Python2FutureTransformer(target=(2, 7)), get_ast(''))

    # Test that the constructor of class Python2FutureTransformer works
    # as expected

# Generated at 2022-06-18 00:13:22.806318
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_node_position
    from ..utils.source import source_to_node_lineno
    from ..utils.source import source_to_node_col_offset
    from ..utils.source import source_to_node_end_lineno
    from ..utils.source import source_to_node_end_col_offset
    from ..utils.source import source_to_node_depth
    from ..utils.source import source_to_node_parent
    from ..utils.source import source_to_node_children


# Generated at 2022-06-18 00:13:32.056406
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:55.523699
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import ast_pprint
    from ..utils.visitor import print_visitor
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_ast_clean

    source_code = source('''
        def foo():
            pass
    ''')

    tree = ast.parse(source_code)
    print_visitor(tree)
    visit_ast(tree)
    visit_ast_clean(tree)
    ast_pprint(tree)

    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    print_visitor(tree)
    visit_ast(tree)
    visit_ast_clean(tree)
    ast_pprint(tree)

# Generated at 2022-06-18 00:14:02.506338
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        def foo():
            pass
    ''')
    expected = source('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo():
            pass
    ''')

    tree = get_ast(source)
    new_tree = Python2FutureTransformer().visit(tree)
    assert compare_asts(expected, new_tree)

# Generated at 2022-06-18 00:14:10.946545
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_visitor
    from ..utils.test_utils import get_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    """
    tree = get_ast(source)
    visitor = get_visitor(Python2FutureTransformer, tree)
    assert_source_equal(expected, visitor)

# Generated at 2022-06-18 00:14:17.615599
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:14:26.129819
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source_1 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import sys
    """
    source_2 = """
    import sys
    """
    module_1 = get_ast(source_1)
    module_2 = get_ast(source_2)
    module_2.body = Python2FutureTransformer().visit(module_2)  # type: ignore
    assert compare_asts(module_1, module_2)

# Generated at 2022-06-18 00:14:27.280306
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-18 00:14:34.211006
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:14:42.078985
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:14:51.820313
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_future
    from ..utils.test_utils import assert_equal_code_with_future_and_print
    from ..utils.test_utils import assert_equal_code_with_future_and_unicode
    from ..utils.test_utils import assert_equal_code_with_future_and_print_and_unicode
    from ..utils.test_utils import assert_equal_code_with_future_and_unicode_and_print
    from ..utils.test_utils import assert_equal_code_with_future_and_

# Generated at 2022-06-18 00:14:57.967923
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast

    source_code = source(
        """
        def foo():
            pass
        """
    )
    tree = get_ast(source_code)
    Python2FutureTransformer().visit(tree)
    assert source(tree) == source(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:15:39.435354
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    import sys
    import unittest

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class TestPython2FutureTransformer(unittest.TestCase):
        """Unit test for constructor of class Python2FutureTransformer"""
        def test_Python2FutureTransformer(self):
            self.assertIsInstance(Python2FutureTransformer(), BaseNodeTransformer)
            self.assertIsInstance(Python2FutureTransformer(), Python2FutureTransformer)

    unittest.main()


# Generated at 2022-06-18 00:15:46.915762
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_code
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_tree_diff
    from ..utils.visitor import dump_tree_diff_stats
    from ..utils.visitor import dump_tree_stats
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_vars
    from ..utils.visitor import dump_walk
    from ..utils.visitor import dump_walk_diff
    from ..utils.visitor import dump_walk_diff_stats
    from ..utils.visitor import dump_walk_

# Generated at 2022-06-18 00:15:52.630257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, ast_to_source
    from ..utils.compare import compare_ast

    source_ = source(imports)
    tree = get_ast(source_)
    Python2FutureTransformer().visit(tree)
    result = ast_to_source(tree)

    assert compare_ast(result, source_)

# Generated at 2022-06-18 00:16:01.383907
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_future import imports
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import assert_source_equal

# Generated at 2022-06-18 00:16:12.559598
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.visit_Module.__module__ == 'typed_astunparse.unparser.Python2FutureTransformer'
    assert transformer.visit_Module.__defaults__ == (None,)
    assert transformer.visit_Module.__kw

# Generated at 2022-06-18 00:16:20.539249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source
    from ..utils.source import source_info
    from ..utils.source import source_debug
    from ..utils.source import source_encoding
    from ..utils.source import source_errors
    from ..utils.source import source_fixer
    from ..utils.source import source_tokens
    from ..utils.source import source_tokenize
    from ..utils.source import source_ast
    from ..utils.source import source_astor
    from ..utils.source import source_unparse
    from ..utils.source import source_compile
    from ..utils.source import source_exec
    from ..utils.source import source_eval
    from ..utils.source import source_inspect
   

# Generated at 2022-06-18 00:16:29.216964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer.visit_Module.__module__ == 'future.transforms.standard_library.Python2FutureTransformer'
    assert transformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'
    assert transformer.visit_Module.__annotations__ == {'node': 'Module', 'return': 'Module'}



# Generated at 2022-06-18 00:16:36.922852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        import sys
        print(sys.version)

    code_ast = ast.parse(code.get_source())
    Python2FutureTransformer().visit(code_ast)
    assert ast_to_str(code_ast) == imports.get_source(future='__future__') + code.get_source()

# Generated at 2022-06-18 00:16:43.115747
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop
    from ..utils.ast_visitor import ASTVisitorNoop

# Generated at 2022-06-18 00:16:51.315876
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           