

# Generated at 2022-06-18 00:08:19.145474
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:08:29.437871
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    code = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
   

# Generated at 2022-06-18 00:08:31.377726
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:08:39.080986
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def test_module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass

    module = ast.parse(test_module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert ast_to_str(module) == test_module.get_source()

# Generated at 2022-06-18 00:08:48.824553
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        pass

    transformer = Python2FutureTransformer()
    tree = build_ast(code)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert tree.body == imports.get_body(future='__future__') + code.get_body()

# Generated at 2022-06-18 00:08:56.600992
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:09:03.283304
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n' \
        '    from __future__ import absolute_import\n' \
        '    from __future__ import division\n' \
        '    from __future__ import print_function\n' \
        '    from __future__ import unicode_literals\n' \
        '        \n' \
        '    '


# Generated at 2022-06-18 00:09:09.713158
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(
        Python2FutureTransformer,
        'print("Hello World!")',
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        'print("Hello World!")',
    )

# Generated at 2022-06-18 00:09:15.778255
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_python_source
    from ..utils.visitor import dump_ast

    module = make_test_module('print("Hello, world!")')
    module = Python2FutureTransformer().visit(module)
    assert dump_python_source(module) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello, world!")
'''

# Generated at 2022-06-18 00:09:23.833801
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__
    assert Python2FutureTransformer.visit_Module.__doc__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'
    assert Python2FutureTransformer.visit_Module.__module__ == 'typed_astunparse.unparser.Python2FutureTransformer'
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': 'Module', 'return': 'Module'}
    assert Python2FutureTransformer.visit_

# Generated at 2022-06-18 00:09:30.178314
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast


# Generated at 2022-06-18 00:09:30.892351
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:09:36.911103
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:40.208745
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module

    @snippet
    def test_module():
        pass

    node = test_module.get_ast()
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert ast_to_str(new_node) == ast_to_str(imports.get_ast(future='__future__') + test_module.get_ast())

# Generated at 2022-06-18 00:10:15.746535
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:25.502203
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:35.508702
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_ast_module
    from ..utils.visitor import visit_ast_node

    # Test constructor
    transformer = Python2FutureTransformer()
    assert transformer is not None

    # Test visit_Module
    module = source.get_ast_module(source.get_source_from_function(test_Python2FutureTransformer))
    assert module is not None
    assert isinstance(module, ast.Module)
    visit_ast_module(module)
    visit_ast(module)
    visit_ast_node(module)
    print_python_source(module)
    module = transformer.visit(module)
    assert module is not None

# Generated at 2022-06-18 00:10:46.038819
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare

# Generated at 2022-06-18 00:10:53.045054
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer.visit_Module.__module__ == Python2FutureTransformer.__module__

# Generated at 2022-06-18 00:11:02.281569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_code import SourceCode
    from ..utils.snippet import snippet
    from ..utils.ast_matcher import ast_matches

    @snippet
    def source_code():
        def foo():
            pass

    source = SourceCode.from_snippet(source_code)
    tree = build_ast(source)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

    @snippet
    def expected_tree():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass

    expected_tree = build_

# Generated at 2022-06-18 00:11:15.893137
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:27.421423
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:34.594349
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare

# Generated at 2022-06-18 00:11:43.758097
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    @snippet
    def module_with_imports():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

    @snippet
    def module_with_imports_and_comments():
        from __future__ import absolute_import


# Generated at 2022-06-18 00:11:50.611869
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:56.831872
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_module
    from ..utils.test_utils import get_node_class
    from ..utils.test_utils import get_node_function
    from ..utils.test_utils import get_node_method
    from ..utils.test_utils import get_node_code
    from ..utils.test_utils import get_node_code_object
    from ..utils.test_utils import get_node_code_object_arguments
    from ..utils.test_utils import get_node_code_object_kwonlyargcount
    from ..utils.test_utils import get_node_code_object_varnames
    from ..utils.test_utils import get_node_code_object

# Generated at 2022-06-18 00:12:05.941648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source_code import SourceCode
    from ..utils.ast_helpers import get_ast_source_code
    from ..utils.ast_helpers import get_ast_source_code_from_node
    from ..utils.ast_helpers import get_ast_source_code_from_node_list
    from ..utils.ast_helpers import get_ast_source_code_from_node_list_with_indent
    from ..utils.ast_helpers import get_ast_source_code_from_node_with_indent
    from ..utils.ast_helpers import get_ast_source_code_from_node_with_indent_and_newline
    from ..utils.ast_helpers import get_ast_source_code_from_node_with_

# Generated at 2022-06-18 00:12:16.444451
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:12:22.933093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source import source

    source_code = source('''
    def foo():
        pass
    ''')
    tree = build_ast(source_code)
    transformer = Python2FutureTransformer()

    # When
    transformer.visit(tree)

    # Then
    assert transformer._tree_changed is True
    assert transformer._source_changed is False
    assert transformer._source == source_code
    assert transformer._tree == tree
    assert transformer._tree.body[0].value.func.id == 'foo'

# Generated at 2022-06-18 00:12:25.354724
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None


# Generated at 2022-06-18 00:12:41.023755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    transformer = Python2FutureTransformer()
    node = ast.parse(module.get_source())
    transformer.visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:12:46.742559
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import dump_ast

    source_code = source(imports)
    tree = ast.parse(source_code)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert dump_ast(new_tree) == dump_ast(tree)

# Generated at 2022-06-18 00:12:55.596994
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.snippet import snippet

# Generated at 2022-06-18 00:13:02.651943
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def source_code():
        pass

    node = ast.parse(source_code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert source(node) == source(source_code.get_body(future='__future__'))

# Generated at 2022-06-18 00:13:08.221275
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    transformer = Python2FutureTransformer()

    # When
    result = transformer.visit(ast.parse(''))

    # Then
    assert result.body[0].value.value == 'absolute_import'
    assert result.body[1].value.value == 'division'
    assert result.body[2].value.value == 'print_function'
    assert result.body[3].value.value == 'unicode_literals'

# Generated at 2022-06-18 00:13:18.166146
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    import sys
    import unittest

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformerTest(unittest.TestCase):
        def test_Python2FutureTransformer(self):
            self.assertEqual(Python2FutureTransformer.target, (2, 7))
            self.assertEqual(Python2FutureTransformer.__name__, 'Python2FutureTransformer')

# Generated at 2022-06-18 00:13:28.393863
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:32.801148
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast

    src = source('''
        def foo():
            pass
    ''')
    tree = get_ast(src)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert transformer.target == (2, 7)

# Generated at 2022-06-18 00:13:36.099053
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(None) is None
    assert transformer.generic_visit(None) is None

# Generated at 2022-06-18 00:13:44.919078
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    import astor
    import textwrap
    import unittest
    
    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
    
    @snippet
    def module():
        print('Hello, world!')
    
    class TestPython2FutureTransformer(unittest.TestCase):
        def test_visit_Module(self):
            tree = ast.parse(textwrap.dedent(module.get_source()))
            transformer = Python2FutureTransformer()

# Generated at 2022-06-18 00:14:02.678135
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:14:09.242722
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n    '


# Generated at 2022-06-18 00:14:19.938742
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:14:22.446292
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse_ast, dump_ast
    from ..utils.test_utils import get_ast_diff


# Generated at 2022-06-18 00:14:29.219311
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:14:34.988737
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source

    source_code = source(
        """
        def foo():
            pass
        """
    )
    tree = ast.parse(source_code)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert new_tree is not tree
    assert new_tree.body[0].name == 'absolute_import'
    assert new_tree.body[1].name == 'division'
    assert new_tree.body[2].name == 'print_function'
    assert new_tree.body[3].name == 'unicode_literals'
    assert new_tree.body[4].name == 'foo'

# Generated at 2022-06-18 00:14:45.272391
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_type
    from ..utils.ast_helpers import get_ast_node_value
    from ..utils.ast_helpers import get_ast_node_lineno
    from ..utils.ast_helpers import get_ast_node_col_offset
    from ..utils.ast_helpers import get_ast_node_end_lineno
    from ..utils.ast_helpers import get_ast_node_end_col_offset
    from ..utils.ast_helpers import get_ast_node_children
    from ..utils.ast_helpers import get_ast_node_child_nodes
    from ..utils.ast_helpers import get_ast

# Generated at 2022-06-18 00:14:56.344243
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_compare import compare_ast
    from ..utils.ast_factory import ast_module
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_source
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor


# Generated at 2022-06-18 00:15:07.778977
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from ..utils.source import Source
    from ..utils.ast_factory import ast_factory
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor
    from ..utils.ast_source_visitor import ASTSourceVisitor

# Generated at 2022-06-18 00:15:15.067568
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:46.851241
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:15:56.754625
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.visitor import dump_visitor

# Generated at 2022-06-18 00:16:04.684896
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_str
    from ..utils.source import source_to_code_str
    from ..utils.source import source_to_module_str
    from ..utils.source import source_to_ast_str_debug
    from ..utils.source import source_to_code_str_debug
    from ..utils.source import source_to_module_str_debug
    from ..utils.source import source_to_ast_debug
    from ..utils.source import source_to_code_debug
    from ..utils.source import source_to_module_debug
    from ..utils.source import source_to_ast_debug_str

# Generated at 2022-06-18 00:16:15.506401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from ..utils.source import source
    from ..utils.source import SourceMap
    from ..utils.source import SourceRange
    from ..utils.source import SourceMarker
    from ..utils.source import SourcePosition
    from ..utils.source import SourceContext
    from ..utils.source import SourceLine
    from ..utils.source import SourceLines
    from ..utils.source import SourceToken
    from ..utils.source import SourceTokens
    from ..utils.source import SourceTokenType
    from ..utils.source import SourceTokenKind
    from ..utils.source import SourceTokenGroup
    from ..utils.source import SourceTokenGroups

# Generated at 2022-06-18 00:16:16.843957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:16:18.233911
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:16:27.443727
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:33.143402
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:16:40.092373
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import run_transformer
    from ..utils.ast_helper import transform_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = parse_ast(source)
    tree = run_transformer(Python2FutureTransformer, tree)
    assert compare_ast(ast_to_str(tree), expected)

# Generated at 2022-06-18 00:16:45.563942
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == Python2FutureTransformer.__module__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'
    assert Python2FutureTransformer.visit_Module

# Generated at 2022-06-18 00:18:10.363909
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:18:17.609005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.visitor import print_ast
    from ..utils.visitor import print_source
    from ..utils.visitor import print_tree
    from ..utils.visitor import visit
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_children_with_parent
    from ..utils.visitor import visit_with_parent
    from ..utils.visitor import walk
    from ..utils.visitor import walk_children
    from ..utils.visitor import walk_children_with_parent
    from ..utils.visitor import walk_with_parent
    from ..utils.visitor import walk_with_parent_and_siblings
    from ..utils.visitor import walk_with_siblings