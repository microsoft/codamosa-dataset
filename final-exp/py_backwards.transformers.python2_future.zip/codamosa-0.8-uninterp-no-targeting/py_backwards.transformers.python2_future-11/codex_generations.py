

# Generated at 2022-06-21 17:46:07.633131
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    transformer = Python2FutureTransformer()
    source = '''
    def f():
        pass
    '''
    tree = ast.parse(source)
    # When
    result = transformer.visit(tree)
    # Then
    assert '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def f():
        pass
    ''' == astor.to_source(result)

# Generated at 2022-06-21 17:46:15.482885
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pathlib import Path
    from ..ast_transformations import transform_source
    from ..utils.source import get_source

    # pylint: disable=unused-import
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Assert

    path = Path(__file__)
    for source_file in (
            path.parent.parent / '..' / '..' / '..' / 'changelog.rst',
            path.parent.parent / '..' / '..' / '..' / 'setup.py') \
            .resolve().expanduser():
        source = get_source(source_file)
        tree = ast.parse(source, filename=str(source_file))
        # pylint: disable=expression-not-assigned

# Generated at 2022-06-21 17:46:18.352840
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    xform = Python2FutureTransformer()
    assert xform.target == (2, 7)
    assert xform.selector == "all"
    assert xform.skip == None
    assert xform._tree_changed == False


# Generated at 2022-06-21 17:46:22.188394
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:46:26.101622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(
        textwrap.dedent("""\
            import sys
            import logging
        """))

# Generated at 2022-06-21 17:46:30.317090
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..testing import transformer_test
    code = f'''{imports}
print("Hello world!")'''
    transformer = Python2FutureTransformer
    assert transformer_test(code, transformer)



# Generated at 2022-06-21 17:46:31.466449
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:46:41.253962
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast as pyast
    snippet = """
    a = 1
    b = 2
    """
    node = pyast.parse(snippet)
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-21 17:46:42.981092
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not N

# Generated at 2022-06-21 17:46:48.774965
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    
    transformer = Python2FutureTransformer(from_version=(3, 6))
    tree = ast.parse('def f(a):\n    return a', mode='exec')
    res = transformer.visit(tree)
    assert res.body[0].lineno == 2
    assert res.body[0].col_offset == 0
    assert res.body[1].lineno == 3
    assert res.body[1].col_offset == 0

# Generated at 2022-06-21 17:46:58.154588
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class mock_ast_module(ast.Module):
        _fields = ['body']
    class mock_ast_body:
        _fields = ['_fields']
    class mock_ast_node(ast.Node):
        _fields = ['_fields']
    test_module = mock_ast_module()
    test_module.body = [mock_ast_body(), mock_ast_node()]
    test_instance = Python2FutureTransformer()
    assert test_instance.visit_Module(test_module)

# Generated at 2022-06-21 17:47:06.280040
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from future.moves import tokenize_rw
    from io import StringIO  # Python 2
    from typed_ast import parse

    code = """\
    # ommitted module docstring
    a = 1
    a += 1
    """
    parse_tree = parse(code)
    transformer = Python2FutureTransformer()
    transformed_parse_tree = transformer.visit(parse_tree)
    code_result = StringIO()
    transformed_parse_tree.show(buf=code_result, offset=0)
    code_result.seek(0)
    assert next(tokenize_rw.tokenize_rw(code_result.readline)) == (2, '\n')

# Generated at 2022-06-21 17:47:14.266597
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent

    code = dedent(
        """        
        from __future__ import print_function
        print('hello')
        """
    )
    expected = dedent(
        """        
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        from __future__ import print_function
        print('hello')
        """
    )
    tr = Python2FutureTransformer(code)
    assert tr.get_output() == expected

# Generated at 2022-06-21 17:47:19.600901
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..transformer.converter import apply_transformer
    from ..utils.parser import parse_code
    from ..utils.snippet import snippet
    from .base import BaseParserTesting
    from .base import BaseTransformerTesting

    
    @snippet
    def importer(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        x = 1

    parser = BaseParserTesting(parse_code(importer))
    assert parser.is_visit_Module()

    transformer = BaseTransformerTesting(Python2FutureTransformer.visit_Module)
    assert transformer.is_visit_Module()

    module = parser.ast_module()

# Generated at 2022-06-21 17:47:28.361344
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(None)
    source_code = "\nif True:\n    pass\n"  # 2 blank lines at the beginning
    expected_source_code = imports.get_source() + "\nif True:\n    pass\n"
    actual_node = transformer.visit(ast.parse(source_code))
    actual_source_code = astor.to_source(actual_node)
    assert actual_source_code == expected_source_code


PYTHON_VERSION_TO_TRANSFORMERS = {
    (2, 7): Python2FutureTransformer
}

# Generated at 2022-06-21 17:47:33.597052
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
    import os

    a = 3
    b = 5
    """
    expected = """
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

    import os

    a = 3
    b = 5
    """
    node = ast.parse(source)
    assert source == to_source(node)
    node = Python2FutureTransformer().visit(node)
    assert expected == to_source(node)

# Generated at 2022-06-21 17:47:40.251886
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import check_visitor_results
    check_visitor_results(Python2FutureTransformer, '''
import foo
import bar
abs = 5
''', '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import foo
import bar
abs = 5
''')

# Generated at 2022-06-21 17:47:47.895016
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import run_on_lines
    from .remove_dunder_all import RemoveDunderAllTransformer
    source = '''
        def f(x):
            print(x)
    '''
    result = run_on_lines(RemoveDunderAllTransformer, source)
    result = run_on_lines(Python2FutureTransformer, result)

# Generated at 2022-06-21 17:47:54.294446
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    nodes = ast.parse("a = 5")
    transformer = Python2FutureTransformer()
    assert transformer.visit(nodes) == ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 5""")

# Generated at 2022-06-21 17:48:02.435698
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import sys
    import os
    sys.path.append(os.path.abspath(os.path.dirname(__file__) + '../../..'))
    from kelte.python_to_python.transformers.python2 import Python2FutureTransformer
    from kelte.utils.snippet import snippet
    @snippet
    def sample():
        import ast
        import os
        import sys
        sys.path.append(os.path.abspath(os.path.dirname(__file__) + '../../..'))
        from kelte.python_to_python.transformers.python2 import Python2FutureTransformer
        from kelte.utils.snippet import snippet
        @snippet
        def sample():
            pass
    
    tree = ast

# Generated at 2022-06-21 17:48:05.430656
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:48:16.163781
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...tests.fixtures.test_ast import ast_test_module_transformer_module
    from ...utils.source import source2ast
    source = source2ast("").body
    source += source2ast("# Comment").body
    source += source2ast("# Comment2").body
    source += source2ast("from __future__ import unicode_literals").body
    source += source2ast("from __future__ import print_function").body
    source += source2ast("from __future__ import division").body
    source += source2ast("from __future__ import absolute_import").body
    source += source2ast("print('hello')").body
    node = ast.Module(body=source)
    assert node == ast_test_module_transformer_module



# Generated at 2022-06-21 17:48:17.112780
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:48:24.805005
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ast_helper import parse as p
    from ast_helper import compare_ast

    node = p('''
        import os
        def f(a):
            a = a + 1
            b = 2
            return a + b''')

    comp_node = p('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        def f(a):
            a = a + 1
            b = 2
            return a + b
        ''')
    res = Python2FutureTransformer().visit(node)
    assert res == comp_node, astor.to_source(res)

    res_ast_str = astor.to_source(res)

# Generated at 2022-06-21 17:48:35.081567
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import sample_code
    x = sample_code.python2_sample
    assert x.__name__ == 'sample_code.python2_sample'
    assert str(x.__code__) == "compile('import sys\nprint(sys.version)\n', '', 'exec')"
    y = Python2FutureTransformer().visit(x)
    assert y.__name__ == 'sample_code.python2_sample'

# Generated at 2022-06-21 17:48:41.126151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.Module([])
    assert m.body == []
    m = Python2FutureTransformer().visit(m)
    assert m.body[0].names[0].name == 'absolute_import'
    assert m.body[1].names[0].name == 'division'
    assert m.body[2].names[0].name == 'print_function'
    assert m.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-21 17:48:44.008728
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    node = ast.parse(
'''
a = 1
''')
    result = transformer.visit(node)
    #assert result #TODO: complete test

# Generated at 2022-06-21 17:48:52.727900
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse("", "<string>", "exec")

    # m is a Module node. We change its body.
    m.body = [ast.Expr(
        value=ast.Subscript(
            value=ast.Name(id="x", ctx=ast.Load()),
            slice=ast.Index(value=ast.Num(n=1)),
            ctx=ast.Load()
        ))]
    # We apply the visit to m. It will return the modified Module node.
    m2 = Python2FutureTransformer().visit(m)
    # The changes are in m2, not in m.
    assert m is not m2
    assert isinstance(m2, ast.Module)
    assert m2.body[0].__class__ == ast.Expr
    assert m2.body[1].__

# Generated at 2022-06-21 17:48:56.715663
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import _ast
    class_def = ast.ClassDef(name='MyClass',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[]
    )
    module = ast.Module(body=[class_def])
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    node = module.body[0]
    assert isinstance(node, _ast.ImportFrom)
    assert node.module == '__future__'



# Generated at 2022-06-21 17:49:00.857776
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("1", mode='eval')
    node2 = Python2FutureTransformer().visit(node)
    assert ast.dump(node2, annotate_fields=False) == '''Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Expr(value=Num(n=1))])'''

# Generated at 2022-06-21 17:49:05.648886
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    b = Python2FutureTransformer()

# Generated at 2022-06-21 17:49:15.805650
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from tests.test_transformer import suite_for, compare_ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
     
    @snippet
    def module():
        def f():
            pass
    
    @snippet
    def expected_module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def f():
            pass

    tree = suite_for(module, imports)
    node = tree.body[0]
    bt = Python

# Generated at 2022-06-21 17:49:24.926990
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    assert isinstance(Python2FutureTransformer, type)
    assert isinstance(Python2FutureTransformer.target, tuple)

# Generated at 2022-06-21 17:49:27.332318
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None)._tree_changed == False  
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-21 17:49:38.496107
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # No changes
    source_code = 'a = 1\n'
    tree = ast.parse(source_code)
    trf = Python2FutureTransformer()
    new_tree = trf.transform(tree)
    assert ast.dump(new_tree) == ast.dump(tree)
    assert trf._tree_changed == False

    # Changes
    source_code = """assert isinstance(left, ast.Str)
assert isinstance(right, ast.Str)
if options.verbose:
    print("{} equals {}".format(left.s, right.s))"""
    tree = ast.parse(source_code)
    trf = Python2FutureTransformer()
    new_tree = trf.transform(tree)
    assert trf._tree_changed == True

# Generated at 2022-06-21 17:49:45.697277
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def python_code(foo):
        pass

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

    node = python_code.get_ast()
    Python2FutureTransformer().visit(node)
    gen = ast.unparse(node)
    assert expected == inspect.cleandoc(next(gen))



# Generated at 2022-06-21 17:49:46.576192
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:49:53.097961
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transforms import TransformerSequence
    transforms = TransformerSequence([Python2FutureTransformer])
    assert transforms.to_source('') == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"
    assert transforms.to_source('import os') == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport os\n"

# Generated at 2022-06-21 17:50:00.831441
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    inp = """
x = 5
"""

    out = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 5
"""

    node = ast.parse(inp)  # type: ast.Module
    t = Python2FutureTransformer()
    new_node = t.visit(node)  # type:ast.Module # noqa: F821
    print(ast.dump(new_node))
    assert ast.dump(new_node) == ast.dump(ast.parse(out))

# Generated at 2022-06-21 17:50:02.376310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer()
    assert class_.target == (2, 7)

# Generated at 2022-06-21 17:50:07.584202
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('a = 1')

# Generated at 2022-06-21 17:50:11.655482
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('x=1')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert isinstance(module, ast.Module)
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.Assign)
    assert module.node_count() == 3

# Generated at 2022-06-21 17:50:22.696142
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from src.python2to3.literal import StringTransformer
    from src.python2to3.literal import UnicodeTransformer
    from src.python2to3.literal import BytesTransformer

    from typed_ast import ast3 as ast
    from .fixtures.module import (
        code_future_sample,
        code_future_sample_expected,
        )
    tree_before = ast.parse(code_future_sample)
    tree_after = ast.parse(code_future_sample_expected)

    transformer = Python2FutureTransformer(target=(2, 7))
    transformer_assert_result(
        transformer,
        tree_before,
        tree_after,
        )

    transformer = Python2FutureTransformer(target=(2, 7))
    transformer.register_transformer(StringTransformer)
    transformer

# Generated at 2022-06-21 17:50:25.120304
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.dummy import DummyTransformer


# Generated at 2022-06-21 17:50:26.068528
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:50:30.349081
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from .base import BaseNodeTransformerTestCase
    
    class Test(BaseNodeTransformerTestCase):
        target = (2, 7)
        transformer = Python2FutureTransformer 
        expected_output = imports()
        input_code = source()

    # Make sure the test case is created
    assert hasattr(Test, 'test_visit_Module')

# Generated at 2022-06-21 17:50:33.654700
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import copy
    import astor
    module = ast.parse('print(1)')
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint(1)'

    module_2 = copy.deepcopy(module)
    Python2FutureTransformer().visit(module_2)
    result = astor.to_source(module_2)
    assert result == expected

# Generated at 2022-06-21 17:50:36.952739
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    Unit test for constructor of class Python2FutureTransformer
    """
    assert Python2FutureTransformer.target == (2, 7)


if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-21 17:50:38.471361
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, Python2FutureTransformer)


# Generated at 2022-06-21 17:50:42.554668
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from pprint import pprint
    from typed_ast import ast3 as ast

    for Snippet in imports.get_matching_classes():
        node = ast.parse(Snippet.template)
        x = Python2FutureTransformer().visit(node)
        code = compile(x, '<test>', 'exec')
        pprint(ast.dump(x))
        pprint(code)
        assert code is not None

# Generated at 2022-06-21 17:50:54.328657
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.example import Example

    example = Example.from_snippet(
        """
        import os

        x = 1
        """
    )
    expected = Example.from_snippet(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os

        x = 1
        """
    )
    met = Python2FutureTransformer()
    met.visit(example.ast_tree)
    assert example.ast_tree == expected.ast_tree

# Generated at 2022-06-21 17:50:55.745084
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-21 17:51:06.617044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..ast_compare import compare_nodes

    module1 = ast.parse('print("1: Hello")')
    module2 = ast.Module(
        body=[
            ast.ImportFrom(
                module='__future__',
                names=[
                    ast.alias(name='absolute_import', asname=None),
                    ast.alias(name='division', asname=None),
                    ast.alias(name='print_function', asname=None),
                    ast.alias(name='unicode_literals', asname=None)
                ],
                level=0),
            ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='1: Hello')], keywords=[]))]
    )
    module1 = Python2FutureTransformer

# Generated at 2022-06-21 17:51:16.057089
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_node = ast.parse("print('Hello World')")
    target = (2, 7)
    assert Python2FutureTransformer(target).visit(ast_node)

# Generated at 2022-06-21 17:51:21.924401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = '''
        def test():
            print('Hello')
    '''
    t = Python2FutureTransformer.run(s)
    assert t == '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def test():
            print('Hello')
    '''.strip()


# skip-undoc

# Generated at 2022-06-21 17:51:25.491432
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from astor import to_source
    tree = ast.parse("x = 1")
    tr = Python2FutureTransformer()
    newtree = tr.visit(tree)
    assert newtree is not None
    code = to_source(newtree)
    assert 'from __future__ import absolute_import' in code
    assert 'x = 1' in code


# Generated at 2022-06-21 17:51:30.460416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source

    from typed_ast import convert, TypeIgnore
    from typed_ast.ast3 import Module
    source_text = source(__file__, 'imports')
    original_tree = convert(source_text)
    assert isinstance(original_tree, Module)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(original_tree)
    assert transformer._tree_changed
    assert isinstance(tree, Module)

# Generated at 2022-06-21 17:51:40.485872
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    module = ast.parse("print('Hello world!')")
    module = t.visit(module)  # type: ignore
    visitor = ast.NodeVisitor()

    @visitor.generic_visit
    def generic_visit(self, node):
        if isinstance(node, ast.Module):
            return node.body

    new = visitor.visit(module)  # type: ignore
    assert new[0].names[0].name == 'absolute_import'
    assert new[1].names[0].name == 'division'
    assert new[2].names[0].name == 'print_function'
    assert new[3].names[0].name == 'unicode_literals'
    assert isinstance(new[4], ast.Expr)

# Generated at 2022-06-21 17:51:41.300294
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:46.985925
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    class _Test(unittest.TestCase):
        def test(self):
            a = imports.get_ast(future='__future__')

# Generated at 2022-06-21 17:52:01.640314
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import parse
    m = parse("x = '\u00e9'")  # character é
    assert isinstance(m, ast.Module)
    assert isinstance(m.body[0].value, ast.Str)
    m2 = Python2FutureTransformer().visit(m)
    assert m2.body[0].value.s == 'é'



# Generated at 2022-06-21 17:52:07.498173
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("""
    import os
    import sys
    """)
    expected_module = ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    """)
    Python2FutureTransformer().visit(module)
    assert ast.dump(module) == ast.dump(expected_module)



# Generated at 2022-06-21 17:52:08.720315
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    Python2FutureTransformer()



# Generated at 2022-06-21 17:52:09.792929
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import get_ast
    import ast

# Generated at 2022-06-21 17:52:19.414172
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed is False
    assert transformer.target == (2, 7)
    assert transformer.future == '__future__'
    #since no tree has been provided
    assert transformer.skipped_modules == set()
    assert transformer.ignored_modules == set()
    #now provide a tree
    transformer = Python2FutureTransformer(tree=ast.parse('pass'))
    assert transformer.tree_changed is False
    assert transformer.target == (2, 7)
    assert transformer.future == '__future__'
    assert transformer.skipped_modules == set()
    assert transformer.ignored_modules == set()


# Generated at 2022-06-21 17:52:22.784761
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .fixtures.native_syntax import python2_native_syntax
    transformer = Python2FutureTransformer(2.7)
    transformed = transformer.visit(ast.parse(python2_native_syntax))
    assert isinstance(transformed, ast.Module)
    assert len(transformed.body) == 5

# Generated at 2022-06-21 17:52:32.600586
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
        import os
        import sys
        import math
        import datetime
        import re
        import time
        import random
        import hashlib
        import urllib2
        import argparse
        import smtplib
        import timeit
        print('hello world')
    """
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        import math
        import datetime
        import re
        import time
        import random
        import hashlib
        import urllib2
        import argparse
        import smtplib
        import timeit
        print('hello world')
    """
    tree = ast.parse(code)

# Generated at 2022-06-21 17:52:42.683884
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code_before = 'print("Hello world!")'
    code_after = '\n'.join([
        'from __future__ import absolute_import\n',
        'from __future__ import division\n',
        'from __future__ import print_function\n',
        'from __future__ import unicode_literals\n',
        code_before])

    node_before = ast.parse(code_before, mode='exec')
    node_after = ast.parse(code_after, mode='exec')
    node_after_ = Python2FutureTransformer().visit(node_before)
    assert node_before != node_after_
    assert ast.dump(node_after) == ast.dump(node_after_)

    module_name = 'test_Python2FutureTransformer_visit_Module'
    sys.modules

# Generated at 2022-06-21 17:52:44.709319
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:52:48.563569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
    def func(a, b, c):
        print(a, b, c)
    """
    module = ast.parse(source)
    Python2FutureTransformer().visit(module)
    assert ast.dump(module) == ast.dump(ast.parse(imports() + source))

# Generated at 2022-06-21 17:53:15.501895
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_module
    from ..utils.visitor import dump_python_source
    mod = make_dummy_module("""
    print("foo")
    """)
    mod2future = Python2FutureTransformer()
    mod2future.visit(mod)
    assert 'from future' in dump_python_source(mod)

# Generated at 2022-06-21 17:53:16.765533
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None



# Generated at 2022-06-21 17:53:22.614035
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visit import source

    py27_node = make_test_module('# nothing to test')
    py2_node = Python2FutureTransformer().visit(py27_node)
    source(py2_node) == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    # nothing to test
    '''

# Generated at 2022-06-21 17:53:23.744941
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

# Generated at 2022-06-21 17:53:28.902161
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import inspect
    from astor.codegen import to_source
    from jupyter_client.kernelspec import KernelSpecManager

    for name, obj in inspect.getmembers(Python2FutureTransformer):
        if callable(obj) and name == 'visit_Module':
            tree = inspect.getsource(obj)
            node = ast.parse(tree)
            Python2FutureTransformer().visit(node)
            assert to_source(node).strip() == imports.get_source(future='__future__').strip()


# Generated at 2022-06-21 17:53:29.626481
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-21 17:53:31.047370
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..unittransformers import Python2FutureTransformer
    instance = Python2FutureTransformer()
    assert instance is not None

# Generated at 2022-06-21 17:53:32.006028
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)



# Generated at 2022-06-21 17:53:33.328186
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with pytest.raises(TypeError):
        Python2FutureTransformer()

# Generated at 2022-06-21 17:53:41.735524
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    class N(ast.AST):
        _fields = ['a', 'b']
        _attributes = ['lineno', 'col_offset']

    class NN(ast.AST):
        _fields = ['c']
        _attributes = ['lineno', 'col_offset']


    class Visitor(ast.NodeVisitor):  # type: ignore
        def visit_N(self, node):
            return N(a=node.a, b=node.b, lineno=node.lineno, col_offset=node.col_offset)

        def visit_NN(self, node):
            return NN(c=node.c, lineno=node.lineno, col_offset=node.col_offset)

        def generic_visit(self, node):
            return node

# Generated at 2022-06-21 17:54:22.207208
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # This is a test for method visit_Module of class Python2FutureTransformer 

    # Setup
    node = ast.parse('print("hi")')  # type: ignore

    # Exercise
    node = Python2FutureTransformer().visit(node)  # type: ignore

    # Verify
    assert node_to_source(node)[0] == '#!/usr/bin/env python'

# Generated at 2022-06-21 17:54:23.650253
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:54:25.984178
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == Python2FutureTransformer.__class__.__name__
    assert Python2FutureTransformer.__doc__ == Python2FutureTransformer.__class__.__doc__


# Generated at 2022-06-21 17:54:31.701815
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .fake import FakePython2Parser
    from .fake import FakePython2Unparser
    
    tree = FakePython2Parser().parse("pass")
    actual = FakePython2Unparser().unparse(Python2FutureTransformer(tree).visit(tree))
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\npass\n"
    assert actual == expected

# Generated at 2022-06-21 17:54:41.742203
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, Str

    m = Module(
        body=[
            Str(s='str1'),
            Str(s='str2'),
            Str(s='str3'),
        ]
    )

    transformed = Python2FutureTransformer().visit(m)

# Generated at 2022-06-21 17:54:48.943350
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import textwrap
    from typed_ast.ast3 import parse

    node_tree = parse(textwrap.dedent('''
if __name__ == '__main__':
    pass
    '''))

    transformer = Python2FutureTransformer()
    transformer.visit(node_tree)


# Generated at 2022-06-21 17:54:51.336741
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    # Check if the object is correctly initialized
    assert obj is not None

# Generated at 2022-06-21 17:54:59.722068
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tester import node_test
    from ..utils.tester import assert_generated_code
    from ..utils.tester import assert_resulting_tree

    # Example-1
    mod = ast.parse('''\
a = 2
print(a)''')
    expected = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


a = 2
print(a)
'''
    # Test
    node_test(Python2FutureTransformer, mod, expected,
              test_visit=False, func_name='visit_Module')

    # Example-2

# Generated at 2022-06-21 17:55:00.487951
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:55:10.240167
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    code = """
    # -*- coding: utf-8 -*-
    def main():
        print(1)
        return None
    if __name__ == '__main__':
        main()
    """
    expected = """
    import astor


    # -*- coding: utf-8 -*-
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def main():
        print(1)
        return None
    if __name__ == '__main__':
        main()
    """

    tree = astor.parse_file(code)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert astor.to_