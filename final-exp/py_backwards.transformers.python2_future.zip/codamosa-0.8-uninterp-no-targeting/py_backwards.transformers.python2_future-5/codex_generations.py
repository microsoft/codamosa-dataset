

# Generated at 2022-06-21 17:46:10.423927
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    p = ast.parse("x = 1")
    v = Python2FutureTransformer()
    v.visit(p)
    assert ast.dump(p) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 1"

# Generated at 2022-06-21 17:46:18.082913
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ... import compile
    from ...utils.visitor import compare_ast

    code = """
import sys
print("hi")
"""
    module = compile(code, '<test>', 'exec', PyVersion=(2, 7), process_tree=Python2FutureTransformer)
    expected_module = compile("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys
print("hi")
""", '<test>', 'exec')
    assert compare_ast(module, expected_module)

# Generated at 2022-06-21 17:46:19.324863
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python_future = Python2FutureTransformer()
    assert python_future is not None

# Generated at 2022-06-21 17:46:30.170848
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent
    from ..utils.fixtures import tree_decorator, future
    from ..utils.source import source_to_module

    @tree_decorator
    def check(tree):
        transformer = Python2FutureTransformer()
        module = source_to_module(dedent(r'''
            module = Module(body=[
                ImportFrom(module='collections', names=[alias(name='OrderedDict', asname=None)], level=0),
                ImportFrom(module='future', names=[alias(name='print_function', asname=None)], level=0),
                Import(names=[alias(name='absolute_import', asname='absolute_import')])
            ])
        '''))
        transformed = transformer.visit(tree)

# Generated at 2022-06-21 17:46:40.164663
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:46:43.561179
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippet_module = snippet.PythonSnippet('test', 'm', source='#test')
    transformer = Python2FutureTransformer(snippet_module)
    assert transformer is not None

# Generated at 2022-06-21 17:46:44.150368
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:46:46.459618
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert repr(t) == 'Python2FutureTransformer(target=(2, 7))'

# Generated at 2022-06-21 17:46:54.411030
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import inspect
    import textwrap

    src = textwrap.dedent(inspect.getsource(ast))
    module = ast.parse(src)
    Python2FutureTransformer().visit(module)
    expected = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import sys
    import _ast
    if sys.version_info[0] < 3:
        from itertools import izip_longest, filterfalse
    else:
        izip_longest = zip_longest
        filterfalse = filter
    
    class AST(object):
    """)

# Generated at 2022-06-21 17:46:55.805957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:47:04.882208
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from jinja2 import Template
    from typed_ast._ast3 import ast
    from typed_ast import ast3 as ast
    #from typed_ast import ConvertedAST
    import typed_ast.ast3
    from typed_astunparse import astunparse
    import sys
    import textwrap
    body_orig= textwrap.dedent('''
        def main():
            pass
    ''')
    #body_orig= 'def main():\n    pass'
    tree = ast.parse(body_orig)
    print(ast.dump(tree))
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    return ast.dump(tree)

# Generated at 2022-06-21 17:47:07.405693
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.sample import sample_module
    from ..utils.codegen import codegen
    from ..utils.parse import parse


# Generated at 2022-06-21 17:47:12.862790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    module_body = [ast.Pass(lineno=2, col_offset=4)]
    module = ast.Module(body=module_body)
    expected_body = [
        ast.ImportFrom(
            module='__future__',
            names=[
                ast.alias(name='absolute_import', asname=None),
                ast.alias(name='division', asname=None),
                ast.alias(name='print_function', asname=None),
                ast.alias(name='unicode_literals', asname=None),
            ],
            level=0,
            lineno=1,
            col_offset=0
        ),
        ast.Pass(lineno=2, col_offset=4)
    ]
    t = Python2FutureTransformer()
    t

# Generated at 2022-06-21 17:47:20.143120
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .sample_ast import sample_ast
    tree = sample_ast.Module_1()
    tree = Python2FutureTransformer().visit(tree)  # type: ignore
    assert len(tree.body) == 6
    first_node = tree.body[0]
    assert isinstance(first_node, ast.ImportFrom)
    assert first_node.module == '__future__'
    assert first_node.names[0].name == 'absolute_import'

# Generated at 2022-06-21 17:47:21.232092
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:47:25.618749
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    out = Python2FutureTransformer().visit(ast.parse('''
        import future
    '''))
    assert ast.dump(ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import future
    ''')) == ast.dump(out)

# Generated at 2022-06-21 17:47:34.868877
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    from ..unparser.unparser import Unparser
    root = ast.parse(
        """
        #!/usr/bin/env python
        
        def main():
            print('Hello world')

        if __name__ == '__main__':
            main()
        """
    )

    node_transformer = Python2FutureTransformer()
    node_transformer.visit(root)
    output = Unparser(root, singleton=False)

# Generated at 2022-06-21 17:47:37.061764
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer()
    assert p.target == (2, 7)

# Generated at 2022-06-21 17:47:44.504717
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..parser import parse_string
    from ..transformers.utils import dump
    """
    class A():
        pass
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    class A():
        pass
    """
    a = parse_string("class A(): pass")
    a1 = Python2FutureTransformer().visit(a)
    assert a1 == parse_string(dump(a1, mode='ast'))



# Generated at 2022-06-21 17:47:53.871577
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source_code import SourceCode
    from .. import get_ast

    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False
    source_code = "assert 2 == 2, 'Assertion error!'\n"
    source = SourceCode(source_code)
    tree = get_ast(code=source_code, target_version=2, transformer=(transformer,))
    assert transformer._tree_changed is True

    # The ast node tree has been changed; therefore, it needs to be
    # regenerated.
    tree = get_ast(code=source_code, target_version=2, transformer=transformer)
    assert transformer._tree_changed is True
    assert tree is not None
    assert tree.body[0].func.value.id == 'assert'

# Generated at 2022-06-21 17:48:02.177885
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    c = Python2FutureTransformer()
    node = ast.parse(
        "a=1\n"
        "print(a)\n"
    )
    expected = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "a=1\n"
        "print(a)\n"
    )
    assert c.visit(node) == expected

# Generated at 2022-06-21 17:48:07.321558
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse('1 + 2')
    transformer = Python2FutureTransformer()
    transformer.visit(module_node)
    assert str(module_node) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

1 + 2'''

# Generated at 2022-06-21 17:48:18.305685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def check(node, expected):
        transformer = Python2FutureTransformer()
        result = transformer.visit(node)
        assert result == expected

    check(ast.Module([ast.ImportFrom(
        module='__future__',
        names=ast.alias(name='absolute_import', asname=None),
        level=0)]), ast.Module([ast.ImportFrom(
        module='__future__',
        names=ast.alias(name='absolute_import', asname=None),
        level=0)]))


# Generated at 2022-06-21 17:48:19.519523
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer._target == (2, 7)

# Generated at 2022-06-21 17:48:20.749449
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:48:22.877287
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pft = Python2FutureTransformer()
    assert pft.target == (2, 7), \
        "Incorrect target version for Python2FutureTransformer."

# Generated at 2022-06-21 17:48:25.900985
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    assert not astor.to_source(Python2FutureTransformer().visit(ast.parse("pass\n"))).startswith("from __future__ import")

# Generated at 2022-06-21 17:48:32.468531
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from ..normalizers import RemoveUnusedImportsNormalizer
    from ..normalizers import SortImportsNormalizer

    # test_Python2FutureTransformer_visit_Module
    source = """print('foo')"""
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('foo')
"""

    tree = ast3.parse(source)  # type: ignore
    Python2FutureTransformer(tree).run()
    tree = RemoveUnusedImportsNormalizer(tree).run()
    tree = SortImportsNormalizer(tree).run()
    result = ast3.unparse(tree)  # type: ignore
    print(result)

    assert result == expected


# Generated at 2022-06-21 17:48:39.682717
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert hasattr(transformer, '_tree_changed')
    assert transformer._tree_changed
    assert node.body[0].value.value == 'absolute_import' #type: ignore
    assert node.body[1].value.value == 'division' #type: ignore
    assert node.body[2].value.value == 'print_function' #type: ignore
    assert node.body[3].value.value == 'unicode_literals' #type: ignore
    print('passed')

if __name__ == "__main__":
    test_Python2FutureTransformer()

# Generated at 2022-06-21 17:48:42.681015
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:48:58.105265
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import textwrap
    from typed_ast.ast3 import Module  # type: ignore
    from typed_ast.ast3 import parse
    from ..test_utils import get_test_data
    from ..test_utils import load_target_snippet
    from itertools import chain

    ft_py2_transformer = Python2FutureTransformer()

# Generated at 2022-06-21 17:49:05.547383
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def test_before(tree):
        tree.body[0].name != 'absolute_import'

    def test_after(tree):
        tree.body[0].name == 'absolute_import'

    snippet = '''def print_function(): pass'''
    tree = ast.parse(snippet)
    Python2FutureTransformer().visit(tree)
    test_before(tree)
    Python2FutureTransformer().visit(tree)
    test_after(tree)

# Generated at 2022-06-21 17:49:12.389427
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer
    """
    body = [ast.Expr(value=ast.Name(id='print', ctx=ast.Load()), lineno=1, col_offset=0)]
    module = ast.Module(body=body, type_ignores=[])
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert transformer.tree_changed is True

# Generated at 2022-06-21 17:49:23.401433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from ...tests.utils import check_in_range
    from ...trees import ast_parse, print_tree
    from ...utils import module_name_from_path

    @snippet
    def module(x, y=3):

        import sys

        def foo():
            return baz()

        def bar():
            return baz()

        def baz():
            return x + y

        return sys.version_info[0] < 3 and foo() or bar()

    tree = ast_parse(module.code)
    tree = Python2FutureTransformer().visit(tree)

    assert module_name_from_path(module.file) == 'snippet'

    print_tree(tree)


# Generated at 2022-06-21 17:49:25.917222
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    transformer.visit(ast.parse('1/2'))


# Generated at 2022-06-21 17:49:36.971622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class MyTransformer(Python2FutureTransformer):
        def visit_Module(self, node):
            self._visit_method = 'visit_Module'
            return self.generic_visit(node)
    
    source = '''
x = 1
print('Hello, %s' % 'World!')
'''
    m = ast.parse(source)
    transformer = MyTransformer()
    transformer.visit(m)
    assert transformer._visit_method == 'visit_Module'
    assert transformer._tree_changed == True
    assert len(m.body) == 5
    assert m.body[0].__class__.__name__ == 'ImportFrom'
    assert len(m.body[0].names) == 4  

# Generated at 2022-06-21 17:49:44.587882
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent(
        '''
        def test():
            print(2)
        '''
    ), mode='exec')
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == textwrap.dedent(
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def test():
            print(2)
        '''
    )

# Generated at 2022-06-21 17:49:46.776923
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import dump


# Generated at 2022-06-21 17:49:50.509091
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  from .tester import node_to_str
  node=ast.parse('x=1')
  Python2FutureTransformer().visit(node)
  assert node_to_str(node)=="""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x=1
"""

# Generated at 2022-06-21 17:49:54.205346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2_future = Python2FutureTransformer()
    assert py2_future.target == (2, 7)
    assert py2_future._tree_changed == False

# Generated at 2022-06-21 17:50:12.373523
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    source = """
# Sample code to validate future imports
print('Hello World')
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

# Sample code to validate future imports
print('Hello World')
"""
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    actual = ast.unparse(tree)
    assert actual == expected

# Generated at 2022-06-21 17:50:14.924392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:50:23.229405
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from astor import codegen
    from textwrap import dedent
    transformer = Python2FutureTransformer()

    root = ast.parse(dedent(u'''\
    def foo():
        return
    '''))
    root_transformed = transformer.visit(root)
    assert root_transformed is not None
    assert root_transformed != root
    assert codegen.to_source(root_transformed) == dedent(u'''\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        return
    ''')

# Generated at 2022-06-21 17:50:24.380817
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-21 17:50:25.831851
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None
    object = Python2FutureTransformer()

# Generated at 2022-06-21 17:50:33.179868
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    ast_node = transformer._visit_Module(ast.parse('''
        def test():
            return True
    '''))

# Generated at 2022-06-21 17:50:41.332757
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pyflakes.api import check
    from ..utils.source import source
    from .meta_transformer import MetaTransformer

    mt = MetaTransformer()
    mt.register_transformer(Python2FutureTransformer())

    tree = mt.visit(source('1+1'))

    # The pyflakes.checker uses the term "undefined" instead of "undeclared".
    # This could be a bug of pyflakes, see https://github.com/PyCQA/pyflakes/issues/392
    # However, "undefined" is the term used in Python official documentation.
    # Therefore, we should do the same.
    msg = "undefined name 'absolute_import'"
    assert msg in check(tree)

# Generated at 2022-06-21 17:50:43.656226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer({})
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False

# Generated at 2022-06-21 17:50:45.162440
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:50:50.681202
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class TestPython2FutureTransformer(Python2FutureTransformer):
        pass
    test_class = TestPython2FutureTransformer()
    assert test_class.__class__.__name__ == 'TestPython2FutureTransformer'
    assert test_class.target == (2, 7)


# Generated at 2022-06-21 17:51:22.741174
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer(None).target == (2, 7)


# Generated at 2022-06-21 17:51:31.031311
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from . import functions
    from . import variables
    from . import classes
    from . import imports
    from . import docstrings


# Generated at 2022-06-21 17:51:32.216332
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7)) is not None

# Generated at 2022-06-21 17:51:41.926160
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    import ast
    import typed_ast.ast3 as typed_ast
    
    # Construct an instance of class Python2FutureTransformer
    python2_future_transformer = Python2FutureTransformer()
    
    # Check the type of variable python2_future_transformer
    assert isinstance(python2_future_transformer, 
                      Python2FutureTransformer)
    
    # Check the type of variable python2_future_transformer._tree_changed
    assert isinstance(python2_future_transformer._tree_changed, 
                      bool)
    
    # Check the value of variable python2_future_transformer._tree_changed
    assert python2_future_transformer._tree_changed == False
    
    # Check the type of variable python2_future_trans

# Generated at 2022-06-21 17:51:44.465456
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('import json')
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert len(module.body) == 7



# Generated at 2022-06-21 17:51:49.202509
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import inspect
    t = Python2FutureTransformer()
    test_func = inspect.getsource(t.visit_Module)
    assert test_func == '        node.body = imports.get_body(future=\'__future__\') + node.body  # type: ignore\n'


# Generated at 2022-06-21 17:51:55.864609
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    from ..parser import parse
    from ..sema import run_sema

    code = """
        foo = 10
    """
    mod = run_sema(parse(code, version='2.7'))
    t = Python2FutureTransformer()
    t._tree_changed = False
    mod = t.visit(mod)
    with pytest.raises(TypeError):
        assert mod == parse(code, version='3.7')
    assert t._tree_changed



# Generated at 2022-06-21 17:51:58.627185
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-21 17:52:00.137735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-21 17:52:01.482107
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:53:09.298701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse

# Generated at 2022-06-21 17:53:11.718767
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = Python2FutureTransformer()
    assert hasattr(node, 'visit_Module')

# Generated at 2022-06-21 17:53:13.676611
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future_imports = Python2FutureTransformer()
    assert future_imports.target == (2,7)

# Generated at 2022-06-21 17:53:16.800877
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('def foo(): pass')
    ast.fix_missing_locations(module)
    transformer = Python2FutureTransformer()
    transformer.visit(module)

# Generated at 2022-06-21 17:53:25.525061
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
    def f():
        return 0
    ''')
    assert ast.dump(node) == '''
    Module(body=[FunctionDef(name='f', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Num(n=0))], decorator_list=[])])
    '''
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-21 17:53:27.277100
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert imports.get_body(future='__future__') is not None
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:53:32.908640
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("a=1\nb=2", mode='eval')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    code = compile(node, "<test>", "exec")
    assert code.co_filename == "<test>"
    assert code.co_firstlineno == 1



# Generated at 2022-06-21 17:53:39.143160
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    module = ast.parse('x = 1')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    result = astor.to_source(module)
    assert result == \
        'from __future__ import absolute_import\n' \
        'from __future__ import division\n' \
        'from __future__ import print_function\n' \
        'from __future__ import unicode_literals\n\n' \
        'x = 1'

# Generated at 2022-06-21 17:53:47.807300
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import astor
    method = Python2FutureTransformer()
    test_filename = os.path.dirname(__file__)+'/samples/sample_2.py'
    node = astor.code_to_ast.parse_file(test_filename)
    node = method.visit_Module(node)
    assert (method.tree_changed)
    assert (node.body[0].value.func.id == "print_function")

# Generated at 2022-06-21 17:53:53.285839
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.examples import Python2Example1
    
    node = ast.parse(Python2Example1)
    Python2FutureTransformer().visit(node)