

# Generated at 2022-06-21 17:46:16.786729
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)
    assert Python2FutureTransformer().generic_visit(None) == None
    tree = ast.parse("")
    tree = Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0)])"

# Generated at 2022-06-21 17:46:18.347234
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(future='__future__').__class__.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-21 17:46:24.311863
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer=Python2FutureTransformer()
    # Check that object created
    assert transformer is not None
    # Check that target set
    assert transformer.target==(2, 7)


# Generated at 2022-06-21 17:46:29.513121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    transformer = Python2FutureTransformer()
    tree = ast.parse('print("foo")')
    expected_tree = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint("foo")')
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 17:46:39.530148
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.testutils import assert_ast_equal
    from ..utils.testutils import make_loc
    node = ast.parse("""
    import sys
    print("Hello")
    """)
    t = Python2FutureTransformer(node)
    t.visit(node)

# Generated at 2022-06-21 17:46:46.514631
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    module = ast.Module([ast.ImportFrom('typed_ast', [ast.alias('ast3', 'ast')], 0)])
    assert transformer.visit(module) == \
"""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from typed_ast import ast3 as ast"""

# Generated at 2022-06-21 17:46:51.004725
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert inspect.getsource(Python2FutureTransformer.visit_Module) == '    def visit_Module(self, node: ast.Module) -> ast.Module:\n        self._tree_changed = True\n        node.body = imports.get_body(future=\'__future__\') + node.body  # type: ignore\n        return self.generic_visit(node)  # type: ignore\n'

# Generated at 2022-06-21 17:46:59.719096
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    source = dedent('''
    def foo(x):
        return x
    ''')
    expected = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def foo(x):
        return x
    ''')

    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    result = unparse(tree)
    assert result == expected

# Generated at 2022-06-21 17:47:04.070885
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for method of class Python2FutureTransformer"""

    # if the source code of Python2FutureTransformer is not changed, we do not need unit
    # test for Python2FutureTransformer.
    assert 1 == 1, "Unit test failed"

if __name__ == "__main__":
    # run all unit tests
    test_Python2FutureTransformer()
    print("All unit tests passed")

# Generated at 2022-06-21 17:47:04.925268
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(None, None, None)

# Generated at 2022-06-21 17:47:09.962930
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print(1)")
    visitor = Python2FutureTransformer()
    visitor.visit(module)
    module = ast.parse("print(1)")
    module.body = imports.get_body(future='__future__') + module.body
    assert ast.dump(visitor.visit(module), annotate_fields=False) == ast.dump(module, annotate_fields=False)

# Generated at 2022-06-21 17:47:13.006178
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import transform, assert_source

    ast_tree = ast.parse('')
    tree_transformed = transform(Python2FutureTransformer, ast_tree)
    assert_source(tree_transformed,
                  '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


''')

# Generated at 2022-06-21 17:47:14.639443
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:47:25.129393
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    import astor
    code_str = '''
x = 1
y = 2
z = x / y
'''
    module = ast.parse(code_str)
    transformed_module = module
    transformed_module = Python2FutureTransformer().visit(# type: ignore
        module)
    code_str_expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1
y = 2
z = x / y
'''
    code_str_actual = astor.to_source(transformed_module)
    assert (code_str_actual == code_str_expected)  # type: ignore

# Generated at 2022-06-21 17:47:27.918969
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert instance.new_future_imports == imports.get_body(future='__future__')


# Generated at 2022-06-21 17:47:37.214479
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    # Given

# Generated at 2022-06-21 17:47:39.229628
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:47:47.017911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    module_ast = ast.parse('''
        import os
        import sys
    ''')
    transformer = Python2FutureTransformer()
    new_module_ast = transformer.visit(module_ast) # type: ignore
    assert new_module_ast.body[0].names[0].name == 'absolute_import'
    assert new_module_ast.body[1].names[0].name == 'division'
    assert new_module_ast.body[2].names[0].name == 'print_function'
    assert new_module_ast.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-21 17:47:49.387516
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    for version in [(2, 7), (2, 8)]:
        transformer = Python2FutureTransformer(version)
        assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:47:57.463749
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, parse
    from typed_ast.extra_visit import ExtraTypeDefVisitor
    from .utils import get_ast_node, get_expected_text

    transformer = Python2FutureTransformer()
    visitor = ExtraTypeDefVisitor(transformer)
    node = parse(get_expected_text())
    transformer._tree_changed = False
    Module(body=[], type_ignores=[])
    visitor.visit(node)
    # Assert that the tree has been changed.
    assert transformer._tree_changed

# Generated at 2022-06-21 17:48:10.762170
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast as py_ast
    from .base import BaseNodeTransformer
    from .ast import ast_to_str
    from .codegen import codegen
    from .unparse import Unparser
    from .codegen import to_source
    from .conversions import py_ast_to_ast
    from ..utils.py2to3 import _fix_indent

    class _AST(py_ast.AST):
        _attributes = ('value',)
        def __init__(self, value: str):
            self.value = value

    class _ASTVisitor(py_ast.NodeVisitor):
        def visit_Str(self, node: py_ast.Str) -> py_ast.Str:
            new_node = _AST(node.s)
            new_node.lineno = node.lineno
            new_

# Generated at 2022-06-21 17:48:18.763312
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    module = ast.parse(textwrap.dedent('''
    print('a')
    '''))
    transformer = Python2FutureTransformer()
    # When
    module = transformer.visit(module)
    # Then
    expected = textwrap.dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print('a')
    ''')
    assert expected == astunparse.unparse(module)

# Generated at 2022-06-21 17:48:25.602199
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from pprint import pprint
    from ..utils.ast_helper import ast_from_snippet, dump_ast, get_func
    from ..transpile import transpile_func
    
    import_test = '''
    def test():
        print(1)
    '''

    print('\n**** Before transpilation ****')
    tree = ast_from_snippet(import_test)
    pprint(dump_ast(tree))

    print('\n**** Transpiled ****')
    func = get_func(tree, 'test')
    transpiled = transpile_func(func, target=(2,))
    pprint(dump_ast(transpiled))
    assert(transpiled.body[0].names[0].name == 'absolute_import')

# Generated at 2022-06-21 17:48:27.686191
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..tt import parse
    from ..utils.dump import dump

# Generated at 2022-06-21 17:48:32.513055
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse(
'''
print(1)
'''
    )
    assert Python2FutureTransformer().visit(node) == ast.parse(
'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(1)
'''
    )

# Generated at 2022-06-21 17:48:34.790340
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from textwrap import dedent

# Generated at 2022-06-21 17:48:44.576367
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = astroid.parse(
        'import os\n'
        'from os.path import join\n'
        '\n'
        'print(1)\n'
        '\n'
    )
    transformer = Python2FutureTransformer()
    transformer.visit(module)

    expected_output = astroid.parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        'import os\n'
        'from os.path import join\n'
        '\n'
        'print(1)\n'
        '\n'
    ).body


# Generated at 2022-06-21 17:48:54.200519
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test a module without any imports
    tree = ast.parse(textwrap.dedent(
        """
        def function():
            pass
        
        if __name__ == '__main__':
            function()
        """
    ))

    expected_tree = ast.parse(textwrap.dedent(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        def function():
            pass
        
        if __name__ == '__main__':
            function()
        """
    ))
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    compare_ast(expected_tree, tree, ignore_order=True)

    # Test a module with existing imports


# Generated at 2022-06-21 17:49:02.035805
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    if sys.version_info.major == 3:
        import unittest.mock as mock
    else:
        import mock
    from ..utils.test_utils import Helper
    transformer = Python2FutureTransformer()
    helper = Helper(transformer, verbose=True)

# Generated at 2022-06-21 17:49:07.884086
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import assertions, utils

    tree = utils.parse("print('hello')")
    result = assertions.expect(Python2FutureTransformer, tree)
    expected = utils.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('hello')''')
    assertions.expect(result, expected)

# Generated at 2022-06-21 17:49:23.333170
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    from typing import List
    from math import isclose
    from ..utils.trees import ast_parse, cmp_ast

    def check(src: str, dst: str, msg: str) -> None:
        src_tree: ast.Module = ast_parse(textwrap.dedent(src))
        dst_tree: ast.Module = ast_parse(textwrap.dedent(dst))
        transformer: Python2FutureTransformer = Python2FutureTransformer()
        dst_transformed: ast.Module = transformer.visit(src_tree)
        assert cmp_ast(dst_transformed, dst_tree, isclose) == True, msg

    # Test simple case
    src = '''
    def f(x):
        return x**2
    '''

# Generated at 2022-06-21 17:49:25.104841
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:49:26.208220
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:49:32.267097
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("")
    new_node = transformer.visit(node)

    from ..utils.nodes import node_to_str
    from ..utils.nodes import list_to_str

    assert node_to_str(node) == ""
    assert list_to_str(new_node.body) == imports.get_body(future='__future__')

# Generated at 2022-06-21 17:49:33.241203
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-21 17:49:35.407278
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = '__future__'
    # Constructor for class Python2FutureTransformer should be called without errors
    Python2FutureTransformer(tree={}, future=future)

# Generated at 2022-06-21 17:49:40.812387
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    assert transformer.visit(parser.parse("x")) == parser.parse(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        x
        """
    )

# Generated at 2022-06-21 17:49:42.759214
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer()
    assert class_.target  == (2, 7)

# Generated at 2022-06-21 17:49:52.673113
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")
    transformed_module = Python2FutureTransformer().visit(module)

    expected_module = ast.Module(
            body=[
                ast.ImportFrom(
                    module='__future__',
                    names=[
                        ast.alias(
                            name='absolute_import',
                            asname=None
                            ),
                        ast.alias(
                            name='division',
                            asname=None
                            ),
                        ast.alias(
                            name='print_function',
                            asname=None
                            ),
                        ast.alias(
                            name='unicode_literals',
                            asname=None
                            ),
                        ]
                    ),
                ],
            )

    assert ast.dump(transformed_module) == ast.dump(expected_module)

# Generated at 2022-06-21 17:49:55.162270
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_transforms import _test_transform
    _test_transform(Python2FutureTransformer, filename='Python2FutureTransformer_visit_Module')

# Generated at 2022-06-21 17:50:04.774418
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()._tree_changed is True


# Generated at 2022-06-21 17:50:08.070872
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    # given,
    code = 'pass'
    # when,
    transformer = Python2FutureTransformer({})
    # then,
    assert transformer.tree is None

# Generated at 2022-06-21 17:50:16.254208
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from flake8_future_import.visitors.base import check_results

    transformer = Python2FutureTransformer()
    tree = parse("print('hello')")
    result = transformer.visit(tree)
    expected = parse('''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('hello')''')
    assert check_results(result, expected) is None

# Generated at 2022-06-21 17:50:17.598279
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-21 17:50:19.338774
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer(target=(2, 7))
    assert x.target == (2, 7)

# Generated at 2022-06-21 17:50:21.113385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-21 17:50:27.788849
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    module = ast.parse("x = 1")
    
    # When
    Python2FutureTransformer(module).visit(module)
    module_transformed = ast.dump(module)
    
    # Then
    assert module_transformed.startswith("Module(body=[ImportFrom("
            "module='__future__', names=[alias("
                "name='absolute_import', asname=None), alias("
                "name='division', asname=None), alias("
                "name='print_function', asname=None), alias("
                "name='unicode_literals', asname=None)], level=0), ")

# Generated at 2022-06-21 17:50:28.649613
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-21 17:50:31.282030
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-21 17:50:36.546673
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert type(trans) == Python2FutureTransformer
    for cls in BaseNodeTransformer.__subclasses__():
        if cls.__name__ == 'Python2FutureTransformer':
            assert cls.__name__ in str(trans)
            break
    assert 'Python2FutureTransformer' in repr(trans)

# Generated at 2022-06-21 17:50:55.538017
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform
    from typed_ast import ast3 as ast
    source = """
    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    print(ast.dump(tree))
    result = transform(Python2FutureTransformer, source)

# Generated at 2022-06-21 17:50:56.531024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-21 17:50:58.725586
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer"""

    assert str(Python2FutureTransformer(None)) == 'Python2FutureTransformer()'

# Generated at 2022-06-21 17:51:04.888768
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
foo = 'bar'
baz = 123
    """
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

foo = 'bar'
baz = 123
    """
    t = Python2FutureTransformer()
    t.visit(ast.parse(source))
    actual = astor.to_source(t.root).strip()
    assert actual == expected

# Generated at 2022-06-21 17:51:08.734411
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    snippet = 'print("Ahoj, svete!")'
    tree = astor.parse_file(snippet)
    mod = Python2FutureTransformer()
    code = mod.visit(tree)

    assert code == imports.strip() + snippet



# Generated at 2022-06-21 17:51:09.995409
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:11.627678
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """ Test to verify that decorator defined in Constructor is configured as expected """
    obj = Python2FutureTransformer()
    assert obj.target == (2, 7)

# Generated at 2022-06-21 17:51:22.894339
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        import astor
    except ImportError:
        return
    # Get the AST tree.
    tree = ast.parse('''
        def func(x):
            return x**3
        print(func(3))
    ''')
    # Get the dedent code.
    code = astor.to_source(tree)
    print(code)
    # Get the AST tree.
    tree = ast.parse('''
        a = 8 / 9
        b = 6 / 7
        c = a ** b
        print(c)
    ''')
    # Get the dedent code.
    code = astor.to_source(tree)
    print(code)
    # Get the AST tree.
    tree = ast.parse('''
        class Foo:
            pass
    ''')


# Generated at 2022-06-21 17:51:28.971690
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = dedent("""
    def func(text: str = 'hello') -> str:
        return text
    """)

    source = ast.parse(code)
    source = Python2FutureTransformer().visit(source)  # type: ignore
    assert source.body[0].name == 'absolute_import'
    assert source.body[1].name == 'division'
    assert source.body[2].name == 'print_function'
    assert source.body[3].name == 'unicode_literals'
    assert source.body[4].name == 'func'

# Generated at 2022-06-21 17:51:32.436261
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    
    # construct
    python2_future_transformer = Python2FutureTransformer()
    
    # check attributes were set correctly
    assert python2_future_transformer.target == (2, 7)


# Generated at 2022-06-21 17:52:12.569180
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.base import BaseNodeTest
    from ..utils.sample import SampleMatch
    from ..utils.source import source

    class Test(BaseNodeTest):
        target = Python2FutureTransformer
        target_version = '2.7'

        def test_single_function(self):
            code = 'def a():\n    pass\n'
            tree = ast.parse(code)
            tree = Python2FutureTransformer().visit(tree)
            val = ast.dump(tree)

# Generated at 2022-06-21 17:52:14.288238
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet.test_to_tree(Python2FutureTransformer(None), imports)

# Generated at 2022-06-21 17:52:19.679241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as typed_ast
    from .fixtures import ast_module as ast_module_fixture

    node = ast_module_fixture
    tree_changed = False
    visitor = Python2FutureTransformer(node)
    visitor.visit(node)
    visitor.generic_visit(node)
    assert visitor.tree_changed == tree_changed
    assert node == typed_ast.parse('import sys\nimport os\n')

# Generated at 2022-06-21 17:52:20.983674
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)


# Generated at 2022-06-21 17:52:27.711106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  import sys
  import os
  sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/..")
  from util import ClickTestCase
  from pythonbuilders.python_builder import transformer_factory
  import ast
  class Python2FutureTransformerTestCase(ClickTestCase):
    def test_visit_Module(self):
      # Arrange
      mod = ast.Module(
        body = [ast.Expr(
          value = ast.Num(
            n = 2
            )
          )
           ]
          ,
        type_ignores = []
        )

# Generated at 2022-06-21 17:52:31.931307
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for class Python2FutureTransformer."""
    test_code = """
    def test():
        return True
    """
    tree = ast.parse(test_code)
    res = ast.dump(Python2FutureTransformer().visit(tree))

# Generated at 2022-06-21 17:52:42.631523
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import textwrap
    from io import StringIO
    from typed_ast import ast3
    from typed_ast.ast3 import Module

    code = textwrap.dedent('''\
    def func():
        pass
    ''')
    tree = ast.parse(code)
    t = ast3.fix_missing_locations(tree)
    transf = Python2FutureTransformer()
    # noinspection PyTypeChecker
    t_new = transf.visit(t)

    assert isinstance(t_new, Module)

    with StringIO() as s:
        ast3.unparse(t_new, s)

# Generated at 2022-06-21 17:52:45.120408
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, Python2FutureTransformer)



# Generated at 2022-06-21 17:52:51.434747
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    # python2
    code = "#!/usr/bin/env python\n# -*- encoding: utf-8 -*-\nprint(42)."
    ast_tree = get_ast(code, 2)
    ast.fix_missing_locations(ast_tree)
    transformer = Python2FutureTransformer()
    ast_tree = transformer.visit(ast_tree)
    assert_source_equal(ast_tree, code, 2)

# Generated at 2022-06-21 17:52:58.649993
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = "print(1)\nprint(2)"
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(1)
print(2)
'''.strip()

    tree = ast.parse(s)  # type: ignore
    transformer = Python2FutureTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-21 17:54:22.663697
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import parse_code, dump_code
    from .nodes import Imports
    code = """\
y = 'hello'
print(y)
"""
    tree = parse_code(code)
    print(tree)
    Python2FutureTransformer().visit(tree)
    print(tree)
    assert tree.__class__.__name__ == 'Module'
    assert len(tree.body) == 3
    assert tree.body[0].__class__.__name__ == 'Expr'
    assert tree.body[1].__class__.__name__ == 'Expr'
    assert tree.body[2].__class__.__name__ == 'Expr'
    assert dump_code(tree.body[0].value) == "imports(future='__future__')"

# Generated at 2022-06-21 17:54:28.699262
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import textwrap

    source = textwrap.dedent('''\
        from my.module import abc
        import sys, os
        
        def func():
            pass
    ''')

    expect = textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        from my.module import abc
        import sys, os
        
        def func():
            pass
    ''')
    
    root = ast.parse(source)
    ast.increment_lineno(root, 2)
    result = ast.dump(root)

    trans = Python2FutureTransformer()
    trans.visit(root)
    result = ast.dump(root)

# Generated at 2022-06-21 17:54:35.273472
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = parse("1 + 2")
    node = Python2FutureTransformer().visit(node)
    assert astor.to_source(node) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import unicode_literals\nfrom __future__ import print_function\n1 + 2"


if __name__ == "__main__":
    # Run the unit tests
    test_Python2FutureTransformer()

# Generated at 2022-06-21 17:54:42.283798
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    test_code = '''
print('Hello, world!')
'''
    expected_ast = ast.parse(imports.get_code() + test_code)  # type:  ignore
    test_ast = ast.parse(test_code)
    node_transformer = Python2FutureTransformer(test_ast)
    result_ast = node_transformer.visit(test_ast)
    assert astor.to_source(expected_ast) == astor.to_source(result_ast)
    assert node_transformer._tree_changed is True
    assert node_transformer.linter_msgs == []

# Generated at 2022-06-21 17:54:49.345033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
import re
import os
import sys
from bs4 import BeautifulSoup

print('hello world')    
"""
    module_node = ast.parse(code, 'data.py')
    module_node = Python2FutureTransformer().visit(module_node)

# Generated at 2022-06-21 17:54:56.172152
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    target = (2, 7)
    visitor = Python2FutureTransformer(target)
    module = ast.parse("def classDef(): pass")
    # Act
    result = visitor.visit(module)
    # Assert

# Generated at 2022-06-21 17:55:02.985072
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse('x = 2')
    Python2FutureTransformer().visit(m)
    assert ast.dump(m) == """\
Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2))])
"""

# Generated at 2022-06-21 17:55:07.101336
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer().visit_Module(ast.parse('pass')) == ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass''')

# Generated at 2022-06-21 17:55:12.392587
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    node = ast.parse('import math')
    node = Python2FutureTransformer.run(node)
    assert codegen.to_source(node) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport math'


# Generated at 2022-06-21 17:55:16.862149
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    expected_first_line = 'from __future__ import absolute_import'
    expected_last_line = 'from __future__ import unicode_literals'

    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)
    with open('tests/fixtures/python2_future/h_plus.py', 'r') as h_plus:
        assert expected_first_line in h_plus.readlines()
        assert expected_last_line in h_plus.readlines()