

# Generated at 2022-06-21 17:46:11.215523
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    node = ast.parse("")
    expected = ast.parse(imports.source)
    assert Python2FutureTransformer.visit_Module(Python2FutureTransformer(), node) == expected

# Generated at 2022-06-21 17:46:18.013749
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Input
    module = ast.parse(textwrap.dedent("""
        print("Hello World!")
        if 4 < 5:
            print("Five is greater than four!")
    """))

    # Transform
    new_module = Python2FutureTransformer().visit(module)

    # Get text from transformed output
    new_source = astor.to_source(new_module).strip()

    # Output
    assert new_source == '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print("Hello World!")
        if 4 < 5:
            print("Five is greater than four!")
    '''.strip()

# Generated at 2022-06-21 17:46:18.913648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TODO
    pass


# Generated at 2022-06-21 17:46:24.705587
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert repr(t) == "Python2FutureTransformer(on_fail=None, on_success=None, target=(2, 7))"

# Generated at 2022-06-21 17:46:34.590217
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    src = """\
        a = 1
        b = 1 + 2
    """
    tree = ast.parse(src)
    expected = ast.parse(src)
    expected.body = imports.get_body(future="__future__") + expected.body  # type: ignore
    tree = t.visit(tree)
    assert tree == expected
    # it should modify node in-place
    assert tree is not expected
    assert tree.body is not expected.body
    assert tree.body[0] is not expected.body[0]
    assert tree.body[1] is not expected.body[1]
    assert tree.body[2] is not expected.body[2]
    assert tree.body[3] is not expected.body[3]
    assert tree.body[4]

# Generated at 2022-06-21 17:46:44.590825
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # dummy class for testing
    import ast
    class Python2FutureTransformer:  # noqa
        def __init__(self):
            self._tree_changed = ''
        def generic_visit(self, node):
            return node
        def visit_Module(self, node):
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore
    # test
    node = ast.parse('print("hi")')  # type: ignore
    expected = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint("hi")')  # type

# Generated at 2022-06-21 17:46:45.716982
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:46:52.378760
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    future_transformer = Python2FutureTransformer()
    
    tree = ast.parse(textwrap.dedent("""\
    def f(x):
        return x + 1
    """))
    expected_output = ast.parse(textwrap.dedent("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def f(x):
        return x + 1
    """))

    future_transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_output)

# Generated at 2022-06-21 17:46:58.585154
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from flake8_future_import.transforms import Python2FutureTransformer
    assert Python2FutureTransformer.target == (2, 7)
    assert hasattr(Python2FutureTransformer, 'visit_Module')
    assert hasattr(Python2FutureTransformer, 'generic_visit')
    assert hasattr(Python2FutureTransformer, '_tree_changed')
    assert isinstance(Python2FutureTransformer(None).target, tuple)



# Generated at 2022-06-21 17:46:59.135246
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:47:07.774803
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = 1')
    assert ast.dump(Python2FutureTransformer().visit(node)) == '''Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])'''

# Generated at 2022-06-21 17:47:17.163149
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
    """
    assert Python2FutureTransformer().visit(ast3.parse("""
        a = 1
        __all__ = ['a']
        """)).body == ast3.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 1
        __all__ = ['a']
        """).body

# Generated at 2022-06-21 17:47:18.352715
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-21 17:47:19.776478
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:47:21.413904
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-21 17:47:30.896143
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test initialization of Python2FutureTransformer
    trans = Python2FutureTransformer()
    assert trans

    # Test with empty code (should do nothing)
    p = trans.transformation_pipeline('', 2, 7)
    assert p == ('')

    # Test with simple code
    p = trans.transformation_pipeline('print("Hello World")', 2, 7)
    assert p == ('from __future__ import absolute_import\n'
                 'from __future__ import division\n'
                 'from __future__ import print_function\n'
                 'from __future__ import unicode_literals\n\n'
                 'print("Hello World")')

# Generated at 2022-06-21 17:47:32.833250
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    result = Python2FutureTransformer().get_transformed_ast('')
    assert result == imports.load()

# Generated at 2022-06-21 17:47:35.249583
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_Base import BaseNodeTransformerTest
    BaseNodeTransformerTest(Python2FutureTransformer)

# Generated at 2022-06-21 17:47:41.285329
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse('print("Hello world!")')
    new_node = transformer.visit(node)
    assert transformer._tree_changed
    assert (
        astor.to_source(new_node) ==
        imports.get_source(future='__future__') + '\nprint("Hello world!")\n'
    )



# Generated at 2022-06-21 17:47:47.900008
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    import astor
    snippet_ast = ast.parse(imports())
    expected = astor.to_source(snippet_ast.body[0])     

    # Exercise
    source = imports()
    tree = ast.parse(source)    
    ast._fix_missing_locations(tree)  # type: ignore
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)  # type: ignore
    actual = astor.to_source(tree).replace('\n', '')

    # Verify
    assert expected == actual



# Generated at 2022-06-21 17:47:56.504176
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
from __future__ import generators
    """
    expected_code = """
from __future__ import absolute_import,division,print_function,unicode_literals
from __future__ import generators
    """
    check_ast(code, expected_code, 2, transformers=[Python2FutureTransformer])


# Generated at 2022-06-21 17:48:01.764952
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...utils.fixtures import make_module_from_code
    from ...utils.test import do_test

    # Test case #1
    inp = "print('Hello World!')"
    expected_out = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('Hello World!')"
    module = make_module_from_code(inp)
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    do_test(module, expected_out)
    # Test case #2

# Generated at 2022-06-21 17:48:12.813454
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    def generic_visit(node):
        return node

    node = ast.Module(["print('Hello World!')"])
    visitor = Python2FutureTransformer(generic_visit)
    node = visitor.visit_Module(node)
    assert node.body[0] == ast.ImportFrom('__future__', [ast.alias('absolute_import', None)], 0)
    assert node.body[1] == ast.ImportFrom('__future__', [ast.alias('division', None)], 0)
    assert node.body[2] == ast.ImportFrom('__future__', [ast.alias('print_function', None)], 0)
    assert node.body[3] == ast.ImportFrom('__future__', [ast.alias('unicode_literals', None)], 0)



# Generated at 2022-06-21 17:48:22.206135
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    input = """
try:
    import urllib.request as urllib2
except:
    import urllib2
"""
    expected_output = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
try:
    import urllib.request as urllib2
except:
    import urllib2
"""
    original_tree = ast.parse(input)
    expected_tree = ast.parse(expected_output)
    
    # Act
    transformer = Python2FutureTransformer()
    result = transformer.visit(original_tree)

    # Assert
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(expected_tree)

# Generated at 2022-06-21 17:48:29.565358
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTransformerTest
    source = """\
    import numpy as np
    print(np.array)
    """
    expected = """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import numpy as np
    print(np.array)
    """
    actual = BaseNodeTransformerTest.run_visitor(Python2FutureTransformer, source)
    assert expected in actual

# Generated at 2022-06-21 17:48:31.278154
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-21 17:48:39.616087
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import tempfile
    import sys

    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_python_file = tempfile.NamedTemporaryFile(dir=tmpdirname, suffix='.py')
        tmp_python_file.write(b'print("Hi")')

        sys.path.insert(0, tmpdirname)

# Generated at 2022-06-21 17:48:40.568426
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:48:50.684566
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from typed_ast import ast3
    from typed_ast import util
    from ..visitors import PythonCodeGenerator
    from ..utils import parse
    import astunparse

    source = """
    print('Hello, world.')
    """
    tree = parse(source)

    node_transformer = Python2FutureTransformer()
    node_transformer.visit(tree)

    if not node_transformer._tree_changed:
        raise ValueError('Tree should be changed')

    utility = util.NodeTransformer()
    utility.visit(tree)
    generated_tree = utility.generic_visit(tree)
    print(astunparse.unparse(generated_tree))

    assert isinstance(generated_tree, ast3.Module)
    assert len(generated_tree.body) == 5


# Generated at 2022-06-21 17:48:55.953565
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer"""
    import astor
    from astor.code_gen import to_source
    from ..utils.syntax_tree import make_syntax_tree
    from ..utils.compare_ast import compare_ast
    from .transformers.python2_future import transformer, imports
    #
    code = '''
        def foo():
            pass

        def bar():
            pass
        '''

# Generated at 2022-06-21 17:49:08.491283
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    node = ast.parse('import math\na = math.ceil(3.1)')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    
    assert transformer.changed
    assert "from __future__ import absolute_import" in ast.dump(node, include_attributes=True)
    assert "from __future__ import division" in ast.dump(node, include_attributes=True)

# Generated at 2022-06-21 17:49:10.092282
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print('Unit test for constructor of class Python2FutureTransformer')
    Python2FutureTransformer()


# Generated at 2022-06-21 17:49:11.333137
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans is not None

# Generated at 2022-06-21 17:49:16.287261
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False
    assert transformer._additional_imports == []
    assert transformer._patch_typing_imports == False


# Generated at 2022-06-21 17:49:20.738093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('print("Hello World!")')

    Python2FutureTransformer().visit(node)
    assert str(node) == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello World!")'''

# Generated at 2022-06-21 17:49:22.567437
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().__class__ == Python2FutureTransformer

# Generated at 2022-06-21 17:49:34.884685
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.name == "Python2FutureTransformer"
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.context_key == "future_imports_added"
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed == False
    #assert transformer.visit_Module.__doc__ == "Prepends module with four lines of __future__ imports."
    assert transformer.visit_Module.__name__ == "visit_Module"
    assert transformer.visit_Module.__qualname__ == "Python2FutureTransformer.visit_Module"
    assert isinstance(transformer.visit_Module, Python2FutureTransformer.visit_Module)
    from typed_ast import ast3 as ast
    module_node = ast.Module(body=list())

# Generated at 2022-06-21 17:49:43.574145
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import FunctionDef
    from typed_ast.ast3 import Assign
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Store
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Str
    from typed_ast.ast3 import List
    from typed_ast.ast3 import Expr
    from typed_ast.ast3 import AugAssign
    from typed_ast.ast3 import Call


# Generated at 2022-06-21 17:49:52.424233
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_source = """
    # Test for method visit_Module of class Python2FutureTransformer
    import os
    import sys
    """
    # output_source = """
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    # import os
    # import sys
    # """
    expected_ast = ast.parse("""
    import os
    import sys
    """)
    input_ast = ast.parse(input_source)
    expected_ast = ast.Module(body=[])
    Python2FutureTransformer.run_test(input_ast, expected_ast)

# Generated at 2022-06-21 17:49:54.066319
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    assert Python2FutureTransformer is not None



# Generated at 2022-06-21 17:50:08.486153
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # test constructor
    Python2FutureTransformer()


# Generated at 2022-06-21 17:50:15.125260
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    test_node = ast.parse("""
    import six  # for python2/3 compatibility
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    """)

    transformer.visit(test_node)

    assert transformer._tree_changed == {}

    

# Generated at 2022-06-21 17:50:17.640062
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .fixtures import python2_module
    from .utils import assert_equal_asts

# Generated at 2022-06-21 17:50:18.623289
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()



# Generated at 2022-06-21 17:50:24.694046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('a = 1')
    visitor = Python2FutureTransformer()
    actual = visitor.visit(module)  # type: ast.Module
    expected = ast.parse('from __future__ import absolute_import\n'
                         'from __future__ import division\n'
                         'from __future__ import print_function\n'
                         'from __future__ import unicode_literals\n'
                         'a = 1')
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-21 17:50:32.451822
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source_code = """
    x = 1
    y = 2
    """
    root_node = ast.parse(source_code)
    node_transformer = Python2FutureTransformer()
    transformed = node_transformer.visit(root_node)
    assert isinstance(transformed, ast.Module)
    assert len(transformed.body) == 5
    imports_node = transformed.body[0]
    assert isinstance(imports_node, ast.ImportFrom)
    assert imports_node.module == '__future__'
    assert imports_node.names[0].name == 'absolute_import'
    assert imports_node.names[1].name == 'division'
    assert imports_node.names[2].name == 'print_function'

# Generated at 2022-06-21 17:50:40.000132
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert imports.get_body(future='__future__') == [
        ast.ImportFrom(module='future',
                       names=[ast.alias(name='absolute_import', asname=None)], level=0),
        ast.ImportFrom(module='future', names=[ast.alias(name='division', asname=None)], level=0),
        ast.ImportFrom(module='future', names=[ast.alias(name='print_function', asname=None)], level=0),
        ast.ImportFrom(module='future', names=[ast.alias(name='unicode_literals', asname=None)], level=0),
    ]

# Generated at 2022-06-21 17:50:46.555101
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse

    # Using a string for the test ast
    module_str = """\n
    import os
    import sys\n
    """
    ast_node = ast.parse(module_str)
    transformed = Python2FutureTransformer().visit(ast_node)
    expected_str = """\n
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import os
    import sys\n
    """
    assert astunparse.unparse(transformed).strip() == expected_str.strip()

# Generated at 2022-06-21 17:50:47.569142
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)
    assert x.priority == 0



# Generated at 2022-06-21 17:50:50.744346
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast3
    import astor
    module = ast3.parse('x = 1')
    visitor = Python2FutureTransformer(None)
    visitor.visit(module)
    result = astor.to_source(module)
    assert result.find('from __future__ import absolute_import') != -1
    assert result.find('from __future__ import division') != -1
    assert result.find('from __future__ import print_function') != -1
    assert result.find('from __future__ import unicode_literals') != -1

# Generated at 2022-06-21 17:51:21.728325
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:27.511742
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module_node = ast.parse(textwrap.dedent("""
        def f(a):
            return a + 1
    """))
    transformer.visit(module_node)

    assert module_node == ast.parse(textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        def f(a):
            return a + 1
    """))

# Generated at 2022-06-21 17:51:34.745273
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source_code = "print('This is Python 2.7')"
    root_node = ast.parse(source_code)
    expected_source_code = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('This is Python 2.7')" # noqa
    tree_changed, root_node = Python2FutureTransformer.run(root_node)
    assert tree_changed is True
    assert astor.to_source(root_node) == expected_source_code

# Generated at 2022-06-21 17:51:40.704457
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    r'''Unit test for constructor of class Python2FutureTransformer'''
    _s = '''\
x = 5
y = 6'''

    module_node = ast.parse(_s)
    xformer = Python2FutureTransformer()
    module_node = xformer.visit(module_node)
    assert module_node
    assert xformer._tree_changed
    assert xformer._changed_line_numbers == [1]

# Generated at 2022-06-21 17:51:42.285755
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().__class__.__name__ == \
        "Python2FutureTransformer"


# Generated at 2022-06-21 17:51:43.279167
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-21 17:51:48.202013
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    # In[1]:
    
    import typed_ast.ast3 as ast
    from typed_astunparse import dump
    from ast_transformer.node_transformer import NodeTransformer, NodeVisitError
    from ast_transformer.transformer import transformer_closure
    from ast_transformer import Python2FutureTransformer
    import textwrap
    
    module_expr = textwrap.dedent("""
    def fn():
        pass
    """)
    
    node = ast.parse(module_expr)
    expected = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    def fn():
        pass
    """)

# Generated at 2022-06-21 17:51:53.220034
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = ast.parse('')
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree).strip() == '''
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
'''.strip()

__transformer__ = Python2FutureTransformer

# Generated at 2022-06-21 17:51:59.093788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class Visitor(ast.NodeVisitor):
        def visit_Module(self, node):
            ret = Python2FutureTransformer().visit_Module(node)
            return ret

    # checking
    node = ast.parse('''
import sys
sys.getrecursionlimit()
    ''')
    
    # checking
    expected = node
    expected.body = imports.get_body(future='__future__') + expected.body
    actual = Visitor().visit(node)
    assert expected == actual
    


# Generated at 2022-06-21 17:52:07.703151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    module_node = ast.parse("x=1")
    Python2FutureTransformer().visit(module_node)
    assert ast.dump(module_node) == "Module(body=[ImportFrom(module='future', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-21 17:53:20.011819
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from .transformers.future import Python2FutureTransformer
    tree = ast.parse("a=2\n")
    t = Python2FutureTransformer()
    tree = t.visit(tree)
    assert t._tree_changed == True
    assert tree is not None


# Generated at 2022-06-21 17:53:25.106983
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("x = 1")
    node = Python2FutureTransformer().visit(node)
    assert node.body[0].value.s == '__future__'
    assert node.body[1].value.s == '__future__'
    assert node.body[2].value.s == '__future__'
    assert node.body[3].value.s == '__future__'
    assert node.body[4].targets[0].id == 'x'

# Generated at 2022-06-21 17:53:31.779518
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(None, None)
    import astor
    source = """
    import os
    import sys
    import abc
    def test(): pass """
    ts = ast.parse(source)
    ts = transformer.visit(ts)  # type: ignore
    codes = astor.to_source(ts)  # type: ignore
    assert 'from __future__ import absolute_import' in codes
    assert 'from __future__ import division' in codes
    assert 'from __future__ import print_function' in codes
    assert 'from __future__ import unicode_literals' in codes
    assert 'import os' in codes
    assert 'import sys' in codes
    assert 'import abc' in codes
    assert 'def test(): pass' in codes

# Generated at 2022-06-21 17:53:33.331841
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.name == 'future'

# Generated at 2022-06-21 17:53:41.765244
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..unittest_tools import assert_code_equal
    from ..unittest_tools import parse_to_ast

    code = """
    def func():
        x = 10
        print(x)
    """

    ast_tree1 = parse_to_ast(code, version="2.7")
    ast_tree2 = parse_to_ast(code, version="3.5")
    expected_tree = parse_to_ast(imports.format(future='__future__') + code)
    transformer = Python2FutureTransformer()
    transformer.visit(ast_tree1)
    assert_code_equal(ast_tree1, expected_tree)
    assert not transformer.is_changed()
    transformer.visit(ast_tree2)
    assert not transformer.is_changed()

# Generated at 2022-06-21 17:53:45.572445
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = dedent('''
        def foo(x):
            return x+1
    ''')
    node = ast.parse(code)
    node = Python2FutureTransformer().visit(node)
    assert ast.dump(node) == dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo(x):
            return x+1
    ''')

# Generated at 2022-06-21 17:53:47.939579
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:53:53.542759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "print('hello')"
    node = ast.parse(code)
    Python2FutureTransformer().visit(node)
    expected_code = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('hello')"
    new_node = ast.parse(expected_code)
    assert ast.dump(node) == ast.dump(new_node)

# Generated at 2022-06-21 17:53:56.593148
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.Module([])
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    transformer.finalize()
    assert transformer.tree_changed is True

# Generated at 2022-06-21 17:54:03.561206
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer().visit_Module(object()) is None

# Unit tests for method Python2FutureTransformer.visit_Module