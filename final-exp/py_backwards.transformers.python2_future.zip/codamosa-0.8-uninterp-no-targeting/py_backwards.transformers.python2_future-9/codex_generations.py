

# Generated at 2022-06-21 17:46:11.637401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import get_all_functions
    transformer = Python2FutureTransformer()
    mod = get_all_functions()
    transformer.visit(mod)
    # print(ast.dump(mod))
    mod = transformer.generic_visit(mod)  # type: ignore
    # print(ast.dump(mod))


# Generated at 2022-06-21 17:46:12.728110
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7))



# Generated at 2022-06-21 17:46:19.812548
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class CollectVisitor(ast.NodeVisitor):
        def __init__(self):
            self.collected = []
        def visit(self, node):
            self.collected.append(node)
            self.generic_visit(node)
    
    import_node = ast.parse('from __future__ import absolute_import')
    mod = ast.Module([import_node])
    visitor = CollectVisitor()
    visitor.visit(mod)
    assert visitor.collected == [mod,
                                 import_node,
                                 import_node.names[0]]

    transformer = Python2FutureTransformer()
    mod = transformer.visit(mod)
    visitor = CollectVisitor()
    visitor.visit(mod)

# Generated at 2022-06-21 17:46:30.171142
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False
    assert transformer.target == (2, 7)
    assert transformer.generic_visit is BaseNodeTransformer.generic_visit
    assert transformer.visit_BinOp is BaseNodeTransformer.visit_BinOp
    assert transformer.visit_bitand is BaseNodeTransformer.visit_bitand
    assert transformer.visit_bitor is BaseNodeTransformer.visit_bitor
    assert transformer.visit_binop is BaseNodeTransformer.visit_binop
    assert transformer.visit_bitxor is BaseNodeTransformer.visit_bitxor
    assert transformer.visit_boolop is BaseNodeTransformer.visit_boolop
    assert transformer.visit_break is BaseNodeTransformer.visit_break

# Generated at 2022-06-21 17:46:31.950265
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-21 17:46:38.105842
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    text = """x = 1; y = '1'; print 3
    """
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


x = 1
y = '1'
print(3)
    """
    tree = ast.parse(text)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-21 17:46:42.085063
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert t.target == (2, 7)
    assert t.visit == t.visit_Module
    assert t.generic_visit == BaseNodeTransformer.generic_visit


# Generated at 2022-06-21 17:46:44.279371
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7), 'Incorrect target version set in Python2FutureTransformer'



# Generated at 2022-06-21 17:46:45.481332
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:46:48.082329
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    
    # This snippet does not have imports added
    assert transformer.transform_tree(imports.get_body(future=None)) == imports.get_body(future='__future__')

# Generated at 2022-06-21 17:46:56.858550
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
from __future__ import print_function
from __future__ import unicode_literals

a = 1

print(a)
    """
    actual = Python2FutureTransformer(code).code
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1

print(a)
    """
    assert expected == actual

# Generated at 2022-06-21 17:46:58.482761
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)

# Generated at 2022-06-21 17:47:06.417493
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import sys
    import ast
    import astor
    from flake8_future_import.transforms import Python2FutureTransformer
    # Type annotations for variables
    source_code: str = '''print("hello")'''
    file_tokens: list = [os.path.basename(__file__)]
    # Logic
    tree: ast.Module = ast.parse(source_code)
    tree = Python2FutureTransformer.visit(tree)
    tree = Python2FutureTransformer.visit(tree)  # idempotent
    transformed_source_code: str = astor.to_source(tree)
    assert Python2FutureTransformer.is_tree_changed is True

# Generated at 2022-06-21 17:47:13.010055
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse, fix_missing_locations, dump
    from .fixtures import Python2FutureTransformer
    
    tree = parse("")
    tree = Python2FutureTransformer(tree).visit(tree)
    tree = fix_missing_locations(tree)
    assert dump(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"

# Generated at 2022-06-21 17:47:18.618823
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class V(ast.NodeVisitor):
        def visit_Module(self, node: ast.Module) -> None:
            print(ast.dump(node))

    tree = ast.parse('def f():\n pass')
    nt = Python2FutureTransformer()
    nt.visit(tree)
    V().visit(tree)

# Generated at 2022-06-21 17:47:19.627689
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None

# Generated at 2022-06-21 17:47:20.264377
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:47:27.756007
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..snippets import imports
    import ast
    import sys

    test_code = '''
    # comment 1
    import os
    import sys
    # comment 2
    from pprint import pprint
    # comment 3
    from collections import Counter
    # comment 4
    '''
    tree: ast.Module = ast.parse(test_code)
    future_transformer = Python2FutureTransformer(tree)
    assert future_transformer.visit(tree) == imports.get_body() + tree.body

# Generated at 2022-06-21 17:47:29.333693
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t._tree_changed is False

# Generated at 2022-06-21 17:47:38.009739
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    from ..transforms.python2 import Python2FutureTransformer
    # test data
    snippet_text = '''
    if a == 0:
        print(b)
    '''
    snippet_ast = ast.parse(snippet_text)
    # run tranformer
    transformer = Python2FutureTransformer()
    transformed_ast = transformer.visit(snippet_ast)
    # compare result
    result_text = astunparse.unparse(transformed_ast)
    expected_text = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


if a == 0:
    print(b)
    '''
    assert result_text == expected_text


# Generated at 2022-06-21 17:47:49.910592
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.context import (
        Context,
        load_module,
    )

    module = make_test_module('def func():\n    return 123')
    tree = load_module(module.source)

    assert module.source == "def func():\n    return 123\n"

    ctx = Context(version='2.7')
    res = Python2FutureTransformer(ctx).visit_Module(tree)
    assert module.source == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef func():\n    return 123\n"

# Generated at 2022-06-21 17:47:57.897237
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    from transform import deparse
    from ...utils.snippet import Snippet

    class MyTransformer(Python2FutureTransformer):
        pass

    snippet = Snippet(
        """
        import codecs
        import os
        import sys
        import unittest
        from datetime import datetime, timedelta
        from pprint import pprint
        """
    )

    node = snippet.get_single_node()

    MyTransformer().visit(node)  # type: ignore
    deparse(node)
    assert True

# Generated at 2022-06-21 17:48:00.591931
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    f = Python2FutureTransformer()
    assert hasattr(f, "target")
    assert hasattr(f, "visit_Module")
    assert hasattr(f, "_tree_changed")
    assert hasattr(f, "generic_visit")

# Generated at 2022-06-21 17:48:10.202648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Test to see if a method can detect the correct version of python 
    """
    module = ast.parse("")
    module = Python2FutureTransformer().visit(module)
    assert(ast.dump(module) == '''Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0)])''')

# Generated at 2022-06-21 17:48:17.064316
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.source import source
    module = ast.parse(source(__file__, "test_Python2FutureTransformer_visit_Module", "data"))
    transformer = Python2FutureTransformer()
    updated_module = transformer.visit(module)
    assert transformer._tree_changed
    assert astor.to_source(updated_module).strip() == source(__file__, "test_Python2FutureTransformer_visit_Module", "expected").strip()

# Generated at 2022-06-21 17:48:18.455429
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:48:23.820574
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
    def test():
        pass
    '''
    expected_code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def test():
        pass
    '''
    r = Python2FutureTransformer().visit(ast.parse(code))
    result = astor.to_source(r).strip()
    assert result == expected_code.strip(), (result, expected_code)

# Generated at 2022-06-21 17:48:25.392979
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-21 17:48:27.586116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:48:32.409168
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x=1')
    trf = Python2FutureTransformer()
    out = trf.visit(node)
    assert isinstance(out, ast.Module)
    assert len(out.body) == 5
    assert out.body[0].names[0].name == 'absolute_import'
    assert isinstance(out.body[0], ast.ImportFrom)

# Generated at 2022-06-21 17:48:36.976333
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    f = Python2FutureTransformer()
    assert f is not None


# Generated at 2022-06-21 17:48:38.473756
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer



# Generated at 2022-06-21 17:48:43.252813
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    Test that the constructor of Python2FutureTransformer correctly sets the class attributes
    """
    p2ft = Python2FutureTransformer()
    assert p2ft.target == (2, 7)
    assert p2ft.version == (3, 6)
    assert p2ft.major == 3
    assert p2ft.minor == 6


# Generated at 2022-06-21 17:48:44.156552
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:48:53.774826
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import sys
    sys.path.append('..')
    from ast_transformer.transformer import Python2FutureTransformer # noqa: E402

    node = ast.parse('import sys\n')


# Generated at 2022-06-21 17:48:56.337930
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import roundtrip

    source = '''
    x = 2
    '''
    tree = roundtrip(source, Python2FutureTransformer)
    expected_source = '''
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
    
    x = 2
    '''
    assert expected_source == tree, tree



# Generated at 2022-06-21 17:48:57.658150
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:49:00.940538
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    t = Python2FutureTransformer()

    # Assert
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-21 17:49:02.006937
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:49:06.792307
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(None)
    # default arguments
    (source, target, node), info = transformer.get_test_cases(ast.Module, imports)
    transformer.generic_visit(node)
    assert info.changed
    assert transformer.tree_changed
    assert source == target
    
    

# Generated at 2022-06-21 17:49:23.481853
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    string = """
try:
    from mock import patch, MagicMock
except ImportError:
    from unittest.mock import patch, MagicMock
    from future import unicode_literals
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
try:
    from mock import patch, MagicMock
except ImportError:
    from unittest.mock import patch, MagicMock
    from future import unicode_literals
"""
    x = Python2FutureTransformer()
    node = ast.parse(string)
    x.visit(node)
    result = astunparse.unparse(node).strip()
    assert result == expected



# Generated at 2022-06-21 17:49:32.212330
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Arrange
    class_ = Python2FutureTransformer()
    class_.version = (2, 7)
    class_.is_pyi = False

    # Act
    result = class_.visit_Module(ast.parse(""))

    # Assert
    assert isinstance(result, ast.Module)
    assert isinstance(result.body, list)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[0].module == '__future__'
    assert result.body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-21 17:49:33.173607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None



# Generated at 2022-06-21 17:49:40.534796
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
    def foo():
        pass
    ''')
    reference = ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass

    ''')
    result = Python2FutureTransformer().visit(node)
    assert ast.dump(result) == ast.dump(reference)



# Generated at 2022-06-21 17:49:42.525507
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""
    assert Python2FutureTransformer()

# Generated at 2022-06-21 17:49:52.460896
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..ast_converter import SympyConverter
    from ..ast_manipulator import AstManipulator
    import ast

    converter = SympyConverter(ast_manipulator=AstManipulator())

    source = '''
from a import b as c
from d import e as f
    
x = 0
y = 1
    '''
    source_node = converter.parse(source)
    target_node = Python2FutureTransformer.run(source_node)
    actual = converter.dump_python_code(ast.Module(body=target_node.body))  # type: ignore
        

# Generated at 2022-06-21 17:49:58.694769
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .fixtures import simple_module
    from .. import dump

    tree = simple_module.get_ast(indent=False)
    Python2FutureTransformer().visit(tree)

    assert dump(tree) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello World!")\
'''

# Generated at 2022-06-21 17:50:07.348089
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.mock import mock
    module = ast.Module(body=[])
    transformer = Python2FutureTransformer(tree=mock(body=[]))
    transformed_module = transformer.visit_Module(module)
    assert transformer._tree_changed
    assert len(transformed_module.body) == 4  # 4 from __future__ import
    for statement in transformed_module.body:
        assert isinstance(statement, ast.ImportFrom)
        assert statement.level == 0
        assert statement.module == '__future__'
        assert statement.names == [
            ast.alias(name=snippet.transformed_statement.names[0].name, asname=None)
        ]

# Generated at 2022-06-21 17:50:11.164120
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..tests.fixtures import make_fixture_from_source
    from ..utils.snippet import snippet
    from ..utils.source import Source
    from ..utils.test_utils import add_transformer_to_test

# Generated at 2022-06-21 17:50:22.260430
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..translate import Translator
    from ..utils.source import source

    code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    from typing import List
    from future.utils import native_str

    def to_text(objects, encoding=native_str, errors='strict'):
        return ','.join(objects)

    def to_list(items):
        return list(items)
    '''

# Generated at 2022-06-21 17:50:36.322157
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print("Test visit_Module")

# Generated at 2022-06-21 17:50:45.867538
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    from .python_transformer_test import run_test_for_class
    from ..utils import filename_for_testfile
    from ..utils.testfile_util import TestFileUtil

    pth = os.path.dirname(os.path.abspath(__file__))
    src = os.path.join(pth, 'python2_transformer_test.py')
    in_doc = TestFileUtil.parse_test_file(src)
    tfm = Python2FutureTransformer()
    tfm.visit(in_doc)
    out_doc = tfm.tree()
    res = TestFileUtil.compare_test_file(filename_for_testfile(__file__, 'test_Python2FutureTransformer_target.py'), out_doc)
    assert res




# Generated at 2022-06-21 17:50:49.202709
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pprint import pprint
    from ..parse import parse
    from ..dump import to_string


# Generated at 2022-06-21 17:50:50.515316
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:50:56.366016
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import convert
    from textwrap import dedent

    x = dedent("""
    class MyClass(object):
        pass
    """)

    tree = convert(ast.parse(x))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    expected = dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    class MyClass(object):
        pass
    """)

    assert expected == astor.to_source(tree)



# Generated at 2022-06-21 17:51:02.961476
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('assert(a == b)')
    transformed_tree = Python2FutureTransformer().visit(tree)
    transformed_source = astor.to_source(transformed_tree).strip()
    expected_source = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

assert(a == b)"""

    assert transformed_source == expected_source

# Generated at 2022-06-21 17:51:07.008985
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse(
        '''
a = 2
b = 4
''')
    node = Python2FutureTransformer().visit(node)
    assert ast.dump(ast.parse(imports.get_body(future='__future__')), annotate_fields=False) \
        == ast.dump(node.body[:4], annotate_fields=False)

# Generated at 2022-06-21 17:51:08.577291
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer()
    assert p.target == (2, 7)
    assert p.current_version == (3, 6)


# Generated at 2022-06-21 17:51:16.334387
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, parse
    from ..utils import parse_ast
    transformer = Python2FutureTransformer()
    tree: Module = parse('print(1 + 1)')
    print(parse_ast(tree))
    transformer.visit(tree)
    print(parse_ast(tree))
    assert parse_ast(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(1 + 1)\n"

# Generated at 2022-06-21 17:51:19.118133
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer

    transformer = Python2FutureTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:51:46.779321
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:51:49.414551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    with pytest.raises(AttributeError):
        Python2FutureTransformer().visit(node)

    assert Python2FutureTransformer().visit(node) is not None

# Generated at 2022-06-21 17:51:55.168330
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x = 5')
    node = Python2FutureTransformer().visit(node)
    expected = ast.parse(
        """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 5
        """
    )
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:51:58.515707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source, assert_tree
    
    tree = assert_tree(source('print 1+1, "hello"'))
    Python2FutureTransformer().visit(tree)
    assert_tree(imports('__future__') + source('print 1+1, "hello"'), tree)

# Generated at 2022-06-21 17:52:03.396077
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_node = ast.Module(body=[])
    module_node = Python2FutureTransformer(module_node)
    assert isinstance(module_node, ast.Module)
    assert len(module_node.body) == 4
    for x in module_node.body:
        assert isinstance(x, ast.ImportFrom)
    assert module_node.body[0].module == '__future__'
    assert module_node.body[1].module == '__future__'
    assert module_node.body[2].module == '__future__'
    assert module_node.body[3].module == '__future__'

# Generated at 2022-06-21 17:52:06.241820
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('a = 1')
    Python2FutureTransformer().visit(module)
    expected_imports = imports.get_body(future='__future__')
    assert module.body[:4] == expected_imports

# Generated at 2022-06-21 17:52:15.041885
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import textwrap
    from ..six import text_type

    code = textwrap.dedent('''\
    x = True
    y = False
    z = None
    ''')
    tree = ast.parse(text_type(code))
    assert ast.dump(tree) == textwrap.dedent('''\
    Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Name(id='True', ctx=Load())), Assign(targets=[Name(id='y', ctx=Store())], value=Name(id='False', ctx=Load())), Assign(targets=[Name(id='z', ctx=Store())], value=Name(id='None', ctx=Load()))])
    ''')
    pt = Python2FutureTransformer

# Generated at 2022-06-21 17:52:23.807248
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os, string, sys
    # input
    input = '''import os
import linecache
import string
print(string.capwords(os.path.basename(__file__)))'''
    # desired output
    output = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import os
import linecache
import string
print(string.capwords(os.path.basename(__file__)))'''
    # create abstract syntax tree
    tree = ast.parse(input)
    # create transformer object
    transformer = Python2FutureTransformer()
    # traverse abstract syntax tree
    transformer.visit(tree)
    # format abstract syntax tree
    code = astor.to_source(tree)    
    # assert output

# Generated at 2022-06-21 17:52:25.313071
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert hasattr(t, 'target')

# Generated at 2022-06-21 17:52:27.167512
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-21 17:53:34.949511
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:53:37.978924
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("")
    tr = Python2FutureTransformer()
    tr.visit(node)

    assert 'print_function' in node.body[2].names  # type: ignore



# Generated at 2022-06-21 17:53:42.051263
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = ast.parse(
        textwrap.dedent(
            '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            a = 1
            '''))
    tree = ast.parse('a = 1')
    tree = Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected)

# EOF

# Generated at 2022-06-21 17:53:47.712408
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    cases = [
        """my_module = 1""",
        """if True:
            my_module = 1
        """,
        """
        from future import absolute_import # This comment is on purpose
        from future import division
        from future import print_function
        from future import unicode_literals
        my_module = 1
        """,
        """
        def func():
            pass
        my_module = 1
        """
    ]
    expected = [case.replace(':', '', 1) for case in cases]
    for case, expected in zip(cases, expected):
        parser = ast.parse(case)
        transformer = Python2FutureTransformer()
        assert transformer.visit(parser) == ast.parse(expected)

# Generated at 2022-06-21 17:53:49.681993
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-21 17:53:52.269359
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = (
        Python2FutureTransformer()
    )
    two_seven = transformer.target
    assert two_seven == (2, 7)

# Generated at 2022-06-21 17:54:02.261536
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    source = """
    # This is a comment
    import os
    import sys
    import re

    # This is a comment

    if 4 is not 5:
        return True
    else:
        return False

    """

# Generated at 2022-06-21 17:54:04.332844
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None)._tree_changed == False

# Generated at 2022-06-21 17:54:05.465666
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:54:06.214545
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

