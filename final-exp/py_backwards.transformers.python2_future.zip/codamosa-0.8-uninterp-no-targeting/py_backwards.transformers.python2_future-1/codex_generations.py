

# Generated at 2022-06-21 17:46:14.004296
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    from typed_ast import ast3 as ast
    from typed_ast import transcoder
    from ..utils.source import source

    source_text = source('''
a = 5
b = 6
    ''')
    tree = ast.parse(source_text)
    expected_text = source('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 5
b = 6
    ''')
    expected_tree = ast.parse(expected_text)
    
    
    transformer = Python2FutureTransformer()
    
    # When
    transformer.visit(tree)
    result_text: str = transcoder.to_source(tree)
    expected_text: str = transcoder.to

# Generated at 2022-06-21 17:46:19.214158
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("a = 1")
    node = Python2FutureTransformer().visit(node)
    assert node.body[0].value.s == '__future__'
    assert node.body[1].value.s == '__future__'
    assert node.body[2].value.s == '__future__'
    assert node.body[3].value.s == '__future__'
    assert node.body[4].targets[0].id == 'a'

# Generated at 2022-06-21 17:46:28.826275
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class _visit_Module(Python2FutureTransformer):
        def visit_Module(self, node):
            # Would normally return `node` but here we return modified node for testing
            return ast.parse('from future import print_function').body[0] # type: ignore

    try:
        from ..utils.test_helpers import assert_ast
        assert_ast(
            code='''
            x = None
            ''',
            expected='''
            from future import print_function
            x = None
            ''',
            node_transformer=_visit_Module
        )
    except ImportError:
        pass


# Generated at 2022-06-21 17:46:39.233754
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import make_example_python_2_source
    from .utils import make_visitor_from_example_python_source
    from .utils import to_source
    source = make_example_python_2_source(r'''
    """This is a comment."""
    class A(object):
        """Another comment."""
        def __init__(self, x, y):
            """Yet another comment."""
            self.x = x
            self.y = y

        def sum(self):
            """Sum the coordinates."""
            return self.x + self.y
    ''')
    visitor_class, module = make_visitor_from_example_python_source(source, 
                                                                    Python2FutureTransformer)
    module = visitor_class().visit(module)
    assert to_

# Generated at 2022-06-21 17:46:39.821971
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:46:50.177994
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = [
        '#!/usr/bin/env python',
        '# -*- coding: utf-8 -*-',
        '',
        'print("Hello world!")'
    ]
    expected_code = [
        '#!/usr/bin/env python',
        '# -*- coding: utf-8 -*-',
        '',
        '',
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
        '',
        'print("Hello world!")'
    ]
    expected_tree = ast.parse('\n'.join(expected_code))
    tree = ast.parse('\n'.join(code))

# Generated at 2022-06-21 17:47:01.315395
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Create a new instance of the transformer
    transformer = Python2FutureTransformer()
    # Create an AST node
    node = ast.Module([])
    # Call the 'visit_Module' method
    result = transformer.visit_Module(node)
    # Assert on the result
    assert isinstance(result, ast.Module)
    # Assert that the 'body' attribute has 4 imports
    assert len(result.body) == 4
    # Assert that the 4 imports correspond to the imports in the imports snippet
    assert isinstance(result.body[0], ast.ImportFrom)
    assert isinstance(result.body[1], ast.ImportFrom)
    assert isinstance(result.body[2], ast.ImportFrom)
    assert isinstance(result.body[3], ast.ImportFrom)

# Generated at 2022-06-21 17:47:07.364915
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    >>> from typed_ast import ast3
    >>> from typed_ast import parse
    >>> from typed_ast import conversion
    >>> node = parse.parse('a=b\\nc=d')
    >>> conv = conversion.Conversion()
    >>> conv.visit(node)
    >>> Python2FutureTransformer().transform(node)
    True
    >>> print(conv.fut_visit(node))
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a=b
    c=d
    """
    pass

# Generated at 2022-06-21 17:47:10.393193
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse("a=1; print(a)")
    t = Python2FutureTransformer()
    t.visit(mod)
    assert str(mod) == imports.get_body(future='__future__') + ["print(a)"]  # type: ignore

# Generated at 2022-06-21 17:47:11.442521
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer



# Generated at 2022-06-21 17:47:14.695560
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:47:25.599251
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    seq = (
        ast.Import(names=[ast.alias(name='bar', asname=None)]),
        ast.FunctionDef(name='foo', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Pass()], decorator_list=[]),
        ast.FunctionDef(name='bar', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Pass()], decorator_list=[])
    )
    tree = ast.Module(body=list(seq))
    transformed_tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-21 17:47:34.868551
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    def test(snippet):
        node = ast.parse(snippet)
        Python2FutureTransformer().visit(node)
        return astor.to_source(node).rstrip()
    assert test('a = 1') == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1'
    assert test('a = 1\n') == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1\n'

# Generated at 2022-06-21 17:47:42.162543
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(
        """def f():
            pass
        """
    )
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == dedent(
        """\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass
        """
    ), "Should prepend __future__ imports."



# Generated at 2022-06-21 17:47:45.539484
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test for snippet:
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        
        def func(x, y):
            print(x + y)
            
    """

# Generated at 2022-06-21 17:47:50.032716
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..test_transformer import CompilerTestCase
    class TestPython2FutureTransformer(CompilerTestCase):
        target = (2, 7)
        def test_visit_Module(self):
            node = ast.Module([])
            with self.assertNoErrors():
                self.check_ast(Python2FutureTransformer, node, """
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
            """)

# Generated at 2022-06-21 17:47:51.633028
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('test')
    Python2FutureTransformer(node).visit(node)

# Generated at 2022-06-21 17:47:53.558720
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import roundtrip

# Generated at 2022-06-21 17:48:02.190941
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # This code should be transformed
    code = """
        x = 1
        print (x)
    """
    module = ast.parse(code)
    assert module.body[0].targets[0].id == 'x'
    assert module.body[1].targets[0].id == 'print'

    a = Python2FutureTransformer()
    a.visit(module)
    assert module.body[0].targets[0].id == 'absolute_import'
    assert module.body[4].targets[0].id == 'x'
    assert module.body[5].targets[0].id == 'print'

    # This code should be transformed
    code = """
        from __future__ import unicode_literals
        x = 1 
    """

# Generated at 2022-06-21 17:48:02.812036
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:48:15.756346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    source = "print('hello')"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('hello')"
    tree = astor.parse_file(source)
    actual = Python2FutureTransformer(source, tree, target=(2,7)).root
    assert astor.to_source(actual) == expected

    source = "def function():\n    print(1)\n    print(2)"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef function():\n    print(1)\n    print(2)"


# Generated at 2022-06-21 17:48:20.016369
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    transformer = Python2FutureTransformer()
    result = transformer.visit(ast.parse("print(5)"))
    assert str(result) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(5)"

# Generated at 2022-06-21 17:48:26.175608
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Cls:
        def __init__(self): # noqa
            pass

        def foo(self): # noqa
            pass

    cls_instance = Cls() # noqa
    two_to_the_power_of_three = 2 ** 3 # noqa

    # Ensure imports are applied
    tree = ast.parse(
        textwrap.dedent("""
            class Cls:
                def __init__(self):
                    pass

                def foo(self):
                    pass

            cls_instance = Cls()
            two_to_the_power_of_three = 2 ** 3
        """),
        mode='exec',
    )

# Generated at 2022-06-21 17:48:28.265793
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert(t.target == (2, 7))
    assert(t._tree_changed == False)
    assert(t._depth == 0)
    
    

# Generated at 2022-06-21 17:48:29.609857
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()



# Generated at 2022-06-21 17:48:38.378857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    """
    Test for method visit_Module for class Python2FutureTransformer:
        Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            
        Input:
            def f(x):
                return x + 42
    """
    node = ast.parse(textwrap.dedent("""
        def f(x):
            return x + 42
        """))
    # Set up a tree visitor and visit the tree
    visitor = Python2FutureTransformer()
    new_node = visitor.visit(node)
    # Compare the node to an expected value

# Generated at 2022-06-21 17:48:39.313287
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-21 17:48:47.583687
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.visitor import format_code
    import pprint
    code = '''
    def foo(x):
        print(x)
    '''
    module = ast.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(module)  # type: ignore
    if transformer._tree_changed:
        code = format_code(module)
        print(code)
    else:
        pprint.pprint(module._fields)

# Generated at 2022-06-21 17:48:56.851424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..main import convert
    from ..test_utils.test_fixture import get_test_fixture
    module_node, _ = get_test_fixture('test.py')
    module_node = Python2FutureTransformer()(module_node)
    source = convert(module_node)
    expected = (
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        '\n'
        'class MyClass(object):\n'
        '    pass\n'
        '\n'
        'def my_func():\n'
        '    return 3\n'
    )
    assert source == expected

# Generated at 2022-06-21 17:49:07.106025
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('def f(): pass', '<test>', 'exec')
    node = tree.body[0]

    transformer = Python2FutureTransformer()
    transformer.visit(node)

    assert transformer._tree_changed
    assert node.body[0].value.func.value.attr == "absolute_import"
    assert node.body[0].value.args == []
    assert node.body[1].value.func.value.attr == "division"
    assert node.body[2].value.func.value.attr == "print_function"
    assert node.body[3].value.func.value.attr == "unicode_literals"
    assert node.body[4].name == "f"

# Generated at 2022-06-21 17:49:14.239740
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)
    assert x.tree_changed == False

# Generated at 2022-06-21 17:49:19.348309
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('import os')
    assert tree.body == [ast.Import(names=[ast.alias(name='os', asname=None)])]
    Python2FutureTransformer(tree).visit(tree)
    assert tree.body[0].names == [ast.alias(name='absolute_import', asname=None)]
    assert 2 <= len(tree.body)

# Generated at 2022-06-21 17:49:20.885528
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..base import BaseNodeTransformerTest
    BaseNodeTransformerTest(Python2FutureTransformer)

# Generated at 2022-06-21 17:49:23.354568
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('x=1')
    m = Python2FutureTransformer()
    m.visit(tree)
    assert ast.dump(tree) == \
        "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None), alias(name='division', asname=None), alias(name='print_function', asname=None), alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-21 17:49:25.523267
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:49:28.439451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)
    assert isinstance(transformer, BaseNodeTransformer)
    return transformer

# Generated at 2022-06-21 17:49:36.320948
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    code = '''
    print(1, 2, 3, sep=';')
    '''
    # noinspection PyUnresolvedReferences
    tree = ast.parse(code)  # type: ast.AST
    transformer.visit(tree)
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(1, 2, 3, sep=';')
'''
    assert src(tree) == expected

# Generated at 2022-06-21 17:49:39.626980
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor  # type: ignore


# Generated at 2022-06-21 17:49:47.865468
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing import assert_text_transformation
    assert_text_transformation(Python2FutureTransformer, """\
    """, """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    """)

    assert_text_transformation(Python2FutureTransformer, """\
    def foo(): pass
    """, """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo(): pass
    """)



# Generated at 2022-06-21 17:49:55.864944
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): 
    from typed_ast import ast3 as ast
    from .test_looper import cflow
    import io
    import textwrap
    source = io.StringIO(textwrap.dedent('''
        b = 6
        c = 6/4
        d = int(6.0)
        e = int("19")
    '''))
    tree = ast.parse(source.read())
    Python2FutureTransformer().visit(tree)
    
    exec(compile(tree, filename="<ast>", mode="exec"))

    assert cflow == [
      0
    ]
    cflow.pop()

# Generated at 2022-06-21 17:50:04.913283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:50:10.116082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transpiler import Transpiler
    from .test_base import Source, target
    from .test_base import check
    from .test_base import transform_check

    class TestTranspiler(Transpiler):
        @property
        def tree_transforms(self):
            return [Python2FutureTransformer]

    check(
        TestTranspiler,
        Source("print('Hello world')"),
        target("from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\nprint('Hello world')\n"),
    )

    # Test that if the file already imports some of __future__, the
    # transformer will not re-add them

# Generated at 2022-06-21 17:50:20.732582
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, parse
    tree = parse('def foo(): pass')
    transformer = Python2FutureTransformer()
    new_tree: Module = transformer.visit(tree)

    from io import StringIO
    from typed_ast.ast3 import dump
    f = StringIO()
    dump(new_tree, f)

# Generated at 2022-06-21 17:50:28.729718
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "import os\nprint('hello')"
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == len(imports.get_body()) + 2  # type: ignore
    assert isinstance(tree.body[0], ast.ImportFrom)  # type: ignore
    assert tree.body[0].module == '__future__'
    assert tree.body[0].names[0].name == 'absolute_import'
    assert tree.body[0].level == 0
    assert isinstance(tree.body[1], ast.ImportFrom)  # type: ignore
    assert tree.body[1].module == '__future__'

# Generated at 2022-06-21 17:50:32.343019
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import Context


# Generated at 2022-06-21 17:50:41.332499
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import unittest
    import astor

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_transformer(self):
            test_input = 'print("Hello World")'
            expected_output = 'from __future__ import absolute_import\n' \
                              'from __future__ import division\n' \
                              'from __future__ import print_function\n' \
                              'from __future__ import unicode_literals\n' \
                              'print("Hello World")'

            expected_module = ast.parse(expected_output)

            actual_module = ast.parse(test_input)
            actual_module = Python2FutureTransformer().visit(actual_module)

            # expected_module = astor.dump_tree(expected_module)
            # actual_module =

# Generated at 2022-06-21 17:50:43.656650
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.tree_changed == False
    assert t.target == (2, 7)


# Generated at 2022-06-21 17:50:44.107031
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:50:54.392907
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    
    class MockFuture(object):
        
        def __init__(self, tree, version):
            self._tree = tree
            self._version = version
            self._changed = False
        
        @property
        def tree(self):
            return self._tree
        
        @property
        def version(self):
            return self._version
        
        @property
        def tree_changed(self):
            return self._changed
        
    class MockModule(object):
        
        def __init__(self, body):
            self._body = body
    
        @property
        def body(self):
            return self._body
        
        @body.setter
        def body(self, value):
            self._changed = True
            self._body = value
    

# Generated at 2022-06-21 17:50:57.620163
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node: ast.Module = ast.parse('')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    print(ast.dump(node, annotate_fields=False))

# Generated at 2022-06-21 17:51:23.837251
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..test import (
        assert_tree,
        parse_ast_tree,
    )

    code = """
        a = 1
        b = 2
        def fib(n):
          if n == 0:
            return 0
          elif n == 1:
            return 1
          return fib(n-1) + fib(n-2)

        if __name__ == "__main__":
          fib(5)
    """
    tree = parse_ast_tree(code)
    new_tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-21 17:51:24.662948
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:51:34.787475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from textwrap import dedent
    from ..transforms import Python2FutureTransformer

# Generated at 2022-06-21 17:51:43.625842
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..base import BaseNodeTransformer
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import dump_ast
    from ..utils.source import render_ast
    from ..utils.source import dump_source
    from ..utils.source import render_source

    python_source = """
foo = 100
print('%s' % foo)
    """

    # Convert source code to unicode
    python_source = source_to_unicode(python_source)

    # Convert source code to AST
    root_node = source_to_ast(python_source)

    # Dump AST
    dump_ast(root_node)

    # Render AST
    render_ast(root_node)

   

# Generated at 2022-06-21 17:51:44.221227
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:51:52.530695
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from ..utils.ast_inspector import AstInspector
    
    class MockTransformer(BaseNodeTransformer):
        """Mock transformer"""
        target = (2, 7)
        def __init__(self):
            super(MockTransformer, self).__init__()
            self._tree_changed = True
            
    transformer = MockTransformer()
    transformer.visit_Module(ast.parse('print("Hello")'))
    ins = AstInspector(transformer.result)
    assert len(ins.get_tree().body) == 2
    assert ins.get_tree().body[0] == imports.get_body(future='__future__')[0]
    assert ins.get_tree().body[1] == ast.parse('print("Hello")').body[0]
    


# Generated at 2022-06-21 17:52:00.438306
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:52:08.918980
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os
    import unittest
    import typed_ast.ast3 as ast
    from typed_ast.transforms.Python2FutureTransformer import Python2FutureTransformer
    
    os_sep = os.sep
    os_getcwd = os.getcwd
    
    class MyTestCase(unittest.TestCase):
        def _test_Python2FutureTransformer_visit_Module(self, module_name):
            # Assume tests are run from Py2to3 subdirectory
            file_name = '../test-data/{}'.format(module_name)
            tree = ast.parse(open(file_name).read())

# Generated at 2022-06-21 17:52:14.406665
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    assert Python2FutureTransformer().visit(node) == ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1')

# Generated at 2022-06-21 17:52:19.455389
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer()
    code = transpiler('print(1)')
    assert code == 'from __future__ import absolute_import\n' \
                   'from __future__ import division\n' \
                   'from __future__ import print_function\n' \
                   'from __future__ import unicode_literals\n' \
                   '\nprint(1)'

# Generated at 2022-06-21 17:53:06.677177
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    "Role of this test is to check if code is inserted at the beginning of file."
    code = '''"test"'''
    tree = ast.parse(code)  # type: ignore
    Python2FutureTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-21 17:53:08.755691
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast

# Generated at 2022-06-21 17:53:14.641276
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..testutils import assert_tree_equal
    assert_tree_equal(Python2FutureTransformer.visit(ast.parse('')), ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n'))

# Generated at 2022-06-21 17:53:16.311569
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

    assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:53:24.806594
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.transform_test_utils import transform
    from ..utils.transform_test_utils import get_visitor_output

    result = transform(
        Python2FutureTransformer,
        '''
from __future__ import division, print_function
from six.moves import range
from past.builtins import str

from x import y
        '''
    )
    assert len(result) == 1

    module = get_visitor_output(result, 'visit_Module')
    assert module.body[0].value.s == 'absolute_import'
    assert module.body[1].value.s == 'division'
    assert module.body[2].value.s == 'print_function'
    assert module.body[3].value.s == 'unicode_literals'

# Generated at 2022-06-21 17:53:32.909219
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    tree = """
        def func_a():
            x = 1
    """
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def func_a():
            x = 1
    """
    expected_node = ast.parse(expected)
    tree_node = ast.parse(tree)
    transformer = Python2FutureTransformer()

    # Act
    result = transformer.visit(tree_node)

    # Assert
    assert ast.dump(result) == ast.dump(expected_node)

# Generated at 2022-06-21 17:53:38.536395
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from autoflake.transformers.python2_future import Python2FutureTransformer
    transformer = Python2FutureTransformer()
    node = ast.parse('x = 1')
    transformer.visit(node)
    assert str(node) == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 1'''

# Generated at 2022-06-21 17:53:39.071626
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:53:47.771274
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    result = Python2FutureTransformer().visit(ast.parse(
        "print('hi')"))
    assert isinstance(result, ast.Module)
    assert len(result.body) == 5
    assert (result, ast.ImportFrom)
    assert (result, ast.ImportFrom)
    assert (result, ast.ImportFrom)
    assert (result, ast.ImportFrom)
    assert (result, ast.Print)

# Generated at 2022-06-21 17:53:52.699107
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as _ast
    from types import ModuleType as _ModuleType

    nodes = (Python2FutureTransformer.visit_Module(_ast.parse(imports.get_code())),)
    assert isinstance(nodes[0], _ast.Module)
    assert isinstance(compile(nodes[0], 'test', 'exec'), _ModuleType)



# Generated at 2022-06-21 17:55:08.933613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_snippet, ast_from_snippet, parse_errors, dump_ast
    from ..utils.compare_ast import compare_ast
    code = make_snippet(__file__, 'imports.get_body', future='__future__')
    assert compare_ast(ast_from_snippet(code), parse_errors(Python2FutureTransformer, code), dump_ast(code))

# Generated at 2022-06-21 17:55:09.938048
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer, type)

# Generated at 2022-06-21 17:55:15.244103
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source

    source_ = source("")
    module = ast.parse(source_)
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    
    import textwrap
    expected = textwrap.dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        """) + "\n" + source_
    assert expected == source(module)

# Generated at 2022-06-21 17:55:20.953565
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..fixer_base import Unit
    from ..fixer_base import fixer_base
    from ..fixer_base import BaseFix
    from ..fixer_base import BaseNodeTransformer

    assert issubclass(Python2FutureTransformer, fixer_base)
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert issubclass(Python2FutureTransformer, BaseFix)

    u = Unit(src='# comment')
    assert Python2FutureTransformer.match(u) == False
    f = Python2FutureTransformer(u)

    src = '''
import sys, os
print(sys.path)
'''
    u = Unit(src=src, name='unit_name')
    assert Python2FutureTransformer.match(u) == True

# Generated at 2022-06-21 17:55:22.345643
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-21 17:55:24.027239
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(target=(2, 7)).target == (2, 7)

# Generated at 2022-06-21 17:55:31.599049
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    lines = [
        '#!/usr/bin/env python',
        'import sys',
        'import sys as _',
        'from sys import version_info as version_info',
        'if version_info.major == 3:',
        '    print("I am py3")',
        'elif version_info.major == 2:',
        '    print("I am py2")',
        'print("hi")'
    ]
    node = astor.parse_file(lines)
    visitor = Python2FutureTransformer()
    visitor.visit(node)

# Generated at 2022-06-21 17:55:32.703269
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:55:33.695614
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:55:42.350417
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse("a = 1 + 1")
    transformed = Python2FutureTransformer().visit(m)
    assert transformed.body[0].value.value == "__future__"
    assert transformed.body[0].value.ctx == ast.Load()
    assert transformed.body[0].targets[0].id == "absolute_import"
    assert transformed.body[1].value.value == "__future__"
    assert transformed.body[1].value.ctx == ast.Load()
    assert transformed.body[1].targets[0].id == "division"
    assert transformed.body[2].value.value == "__future__"
    assert transformed.body[2].value.ctx == ast.Load()
    assert transformed.body[2].targets[0].id == "print_function"
   