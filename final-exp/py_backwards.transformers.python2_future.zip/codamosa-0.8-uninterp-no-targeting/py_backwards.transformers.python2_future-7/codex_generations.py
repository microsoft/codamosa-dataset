

# Generated at 2022-06-21 17:46:11.499098
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:46:15.382390
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer.from_bytecode(disassemble(add))

    assert transformer is not None
    assert transformer.tree is not None
    assert transformer.name == 'add'
    assert transformer.bytecode is not None
    assert transformer.linemap is not None
    assert transformer.ast_node is None

# Generated at 2022-06-21 17:46:25.204291
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import Any
    import numpy as np
    from typed_ast import ast27

    class Dummy(ast27.AST):
        _fields = ()
        _attributes = ()

    code = '''
    a = 7
    '''
    node = ast27.parse(code)
    dummy  = Dummy()
    node.body.insert(0, dummy)
    tr = Python2FutureTransformer()
    tr.visit(node)
    assert(len(node.body) == len(imports.get_body()) + 2)
    assert(np.all([isinstance(x, (ast27.ImportFrom, ast27.Import)) for x in node.body]))

# Generated at 2022-06-21 17:46:35.361150
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    node = ast.Module(body=[])
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert len(node.body) == 4
    for i in range(4):
        assert (
            isinstance(node.body[i], ast.ImportFrom)
            and node.body[i].module == '__future__'
            and node.body[i].names[0].name == imports.get_body(future='__future__')[i].names[0].name
            and node.body[i].names[0].asname == None
        ), node.body[i]

# Generated at 2022-06-21 17:46:37.011593
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-21 17:46:38.282889
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert(Python2FutureTransformer is not None)

# Generated at 2022-06-21 17:46:39.171057
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:46:40.984232
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(2.7)
    assert t.target == (2, 7)

# Generated at 2022-06-21 17:46:45.320241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import refactor_string
    code = """\
    foo=42
    # A comment
    a = 1
    """
    assert refactor_string(Python2FutureTransformer, code) == imports.get_body() + code.split("\n")

# Generated at 2022-06-21 17:46:46.589905
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None



# Generated at 2022-06-21 17:46:58.673893
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = textwrap.dedent('''
        from something import something_else
        import os
        import sys
        import time
    ''')
    expected = textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        from something import something_else
        import os
        import sys
        import time
    ''')
    tree = ast.parse(source)
    Python2FutureTransformer(default_future='__future__').visit(tree)
    result = SourceGenerator.to_source(tree)
    print(result)
    assert result == expected

# Generated at 2022-06-21 17:46:59.552975
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:47:00.803450
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # This test is not implemented
    assert True
    

# Generated at 2022-06-21 17:47:06.935409
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    # Initialize test values
    code = '''
    def fun():
      print('Hello World')
    '''
    future2_expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    
    def fun():
      print('Hello World')
    '''

    # Run test
    node = ast.parse(code)
    t = Python2FutureTransformer()
    node = t.visit(node)
    code = astor.to_source(node)
    assert code == future2_expected

# Generated at 2022-06-21 17:47:15.693044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = """
    a = 2
    b = 3
    print(a + b)
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    # print(astor.to_source(tree))
    assert astor.to_source(tree) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


a = 2
b = 3
print(a + b)
"""


transform = Python2FutureTransformer

# Generated at 2022-06-21 17:47:17.164207
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-21 17:47:26.609259
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..snippets import ast_parse

    before = ast_parse('''
        from __future__ import absolute_import
        # noqa F401
        import os
        from __future__ import annotations
    ''')

    after = ast_parse('''
        from __future__ import absolute_import
        # noqa F401
        import os
        from __future__ import annotations
    ''')

    test = Python2FutureTransformer()
    test.visit(before)
    assert ast.dump(test.tree, include_attributes=True) == ast.dump(after, include_attributes=True)  # type: ignore



# Generated at 2022-06-21 17:47:34.434532
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = """
    import six
    s = six.print_("Hello, world!")
    """
    tree = astor.parse_file(code)
    Python2FutureTransformer().visit(tree)

    new_code = astor.to_source(tree)
    assert new_code == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import six
s = six.print_("Hello, world!")
"""

# Generated at 2022-06-21 17:47:45.071412
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    transformer = Python2FutureTransformer()
    ast_tree = ast.parse(
        """
        def foo():
            pass
        """.strip()
    )
    transformer.visit(ast_tree)

# Generated at 2022-06-21 17:47:47.615633
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print('Hello World!')")
    module = Python2FutureTransformer().visit(module)

    assert module.body[0].value.s == 'Hello World!'

# Generated at 2022-06-21 17:47:56.111336
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing_utils import assert_code_equal
    source = """def main():
    print("Hello")"""

# Generated at 2022-06-21 17:48:02.274084
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # __future__ imports
    from ..utils import peval
    tree = imports.strip_body().parse()
    assert eval(peval(Python2FutureTransformer(tree).module.body[0])) == True
    assert eval(peval(Python2FutureTransformer(tree).module.body[1])) == True
    assert eval(peval(Python2FutureTransformer(tree).module.body[2])) == True
    assert eval(peval(Python2FutureTransformer(tree).module.body[3])) == True
    assert eval(peval(Python2FutureTransformer(tree).module.body[4])) == True

# Generated at 2022-06-21 17:48:13.430431
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    import_future = ast.ImportFrom(
        module='__future__',
        names=[
            ast.alias(
                name='absolute_import'
            ),
            ast.alias(
                name='division'
            ),
            ast.alias(
                name='print_function'
            ),
            ast.alias(
                name='unicode_literals'
            )
        ],
        level = 0,
    )
    
    tree = Python2FutureTransformer().visit(ast.parse("pass"))
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.ImportFrom)
    
    
    for n, node in enumerate(import_future.names):
        assert tree.body[0].names[n].name

# Generated at 2022-06-21 17:48:20.185357
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import transform
    from .assertions import assert_result_is

    source = '''
        def f():
            return 42
        '''
    expect = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        return 42
    '''

    tree = ast.parse(source)
    result = transform(tree, Python2FutureTransformer)
    assert_result_is(result, expect)

# Generated at 2022-06-21 17:48:22.962056
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # arrange
    transformer = Python2FutureTransformer()

    node = ast.Module(body=[])

    # act
    new_node = transformer.visit(node)

    # assert
    expected = ast.Module(body=imports.get_body(future='__future__'))
    assert new_node == expected

# Generated at 2022-06-21 17:48:25.052077
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(None), Python2FutureTransformer)



# Generated at 2022-06-21 17:48:27.685255
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    # TODO: Add tests
    assert Python2FutureTransformer
    assert ast.Module

# Generated at 2022-06-21 17:48:36.934682
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    code = """
a = 1
"""
    node = ast.parse(code, mode="exec")
    result_node = Python2FutureTransformer().visit(node)

# Generated at 2022-06-21 17:48:42.659286
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..common import create_module

    node = create_module('')  
    new_node = Python2FutureTransformer().visit(node)
    assert new_node.body[0].module == '__future__'
    assert new_node.body[1].module == '__future__'
    assert new_node.body[2].module == '__future__'
    assert new_node.body[3].module == '__future__'

# Generated at 2022-06-21 17:48:48.378466
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = 'print("a", "b")'
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree).startswith('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n')

# Generated at 2022-06-21 17:49:03.617066
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from .fix_imports import FixImportsTransformer
    tree = parse("""
    x = 'test'
    """)
    transformer = FixImportsTransformer()
    transformer.visit(tree)
    node = tree.body[0]
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert node.body[0].value.s == "test"

# Generated at 2022-06-21 17:49:07.015152
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test 1
    try: 
        # Test __init__ method
        transformer = Python2FutureTransformer()
        assert transformer.target == (2,7)
    except Exception as ex:
        print(ex)
        assert False



# Generated at 2022-06-21 17:49:12.181966
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    input = """def f(a): return a"""
    tree = ast.parse(input)
    Python2FutureTransformer().visit(tree)

    # When
    output = astor.to_source(tree)

    # Then
    expected_output = textwrap.dedent("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f(a): return a""")

    assert output == expected_output

# Generated at 2022-06-21 17:49:19.024433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from transformer.transformer import get_ast
    m = get_ast('version2/snippet_1.py').body
    assert m[0].value.s == '__future__'
    assert m[1].value.s == 'absolute_import'
    assert m[2].value.s == 'division'
    assert m[3].value.s == 'print_function'
    assert m[4].value.s == 'unicode_literals'

# Generated at 2022-06-21 17:49:20.663468
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for Python2FutureTransformer"""
    a = Python2FutureTransformer()
    assert True

# Generated at 2022-06-21 17:49:24.845873
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.codegen import to_source

    module = ast.parse("True")
    assert to_source(module) == "True"

    transformer = Python2FutureTransformer()
    transformed_module = transformer.visit(module)
    assert to_source(transformed_module) == imports.get_source(
        future='__future__') + "True"

# Generated at 2022-06-21 17:49:28.972182
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transforms_to
    from typed_ast import ast3
    from typed_ast._ast3 import Module

    @transforms_to(Python2FutureTransformer, Module)
    def test():
        pass



# Generated at 2022-06-21 17:49:35.996114
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    source = '''
x = "a"
y = "b"
z = "c"
    '''
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = "a"
y = "b"
z = "c"
    '''
    module = ast.parse(source)
    return transformer.visit_Module(module)

# Generated at 2022-06-21 17:49:40.541560
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"
    assert str(Python2FutureTransformer) == "<Python2FutureTransformer: (2, 7)>"
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-21 17:49:46.875468
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    src = \
    """
    def foo():
        pass
    """
    expected = \
    """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    """
    tree = ast.parse(src)
    node = Python2FutureTransformer().visit(tree)
    assert ast.dump(node) == expected

# Generated at 2022-06-21 17:50:04.321122
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:50:11.146449
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .utils import make_snippet, run_transformer
    from .utils import match_against

    snippet = make_snippet(
        '''
        print("Hello, world!")
        '''
    )
    assert snippet is not None
    assert snippet.body is not None
    assert match_against(snippet, 'Module'), 'Did not match module'

    new_tree = run_transformer(snippet, Python2FutureTransformer)
    assert new_tree is not None
    assert match_against(new_tree, 'Module'), 'Did not match module'

# Generated at 2022-06-21 17:50:20.548609
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    class Test(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    node = ast.parse('''
foo = 1
''')
    res = astor.to_source(Test().visit(node))
    assert res == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

foo = 1
'''

# Generated at 2022-06-21 17:50:22.769378
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t._future_features == ['absolute_import', 'division', 'print_function', 'unicode_literals']

# Generated at 2022-06-21 17:50:27.547552
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import parse
    module = parse('def foo():\n  pass\n')
    module = Python2FutureTransformer()(module)
    assert isinstance(module, ast.Module)
    assert len(module.body) == 1  # type: ignore
    assert len(module.body[0].body) == 1  # type: ignore

# Generated at 2022-06-21 17:50:29.030816
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-21 17:50:35.861052
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse("print('Hi!')")
    n = ast.parse("from __future__ import absolute_import\nprint('Hi!')")
    tr = Python2FutureTransformer()
    assert tr.visit(m) == n

# Test that visit_Module of class Python2FutureTransformer ignores from
# __future__ import absolute_import

# Generated at 2022-06-21 17:50:43.039896
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformerTest
    class Test(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        code_before = 'print("Hello World")'
        code_after = 'import collections\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint("Hello World")'

    test = Test()
    test.test_default_transformer()

# Generated at 2022-06-21 17:50:53.248639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # given a method visit_Module(self, node: ast.Module)
    transformer = Python2FutureTransformer()

    # when I pass a simple module (content "pass")
    node = ast.parse('pass')
    # and I call the method visit_Module
    node = transformer.visit_Module(node)  # type: ignore

    # then I expect the content of the module to be changed to

# Generated at 2022-06-21 17:50:59.316701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('import os')
    transformer = Python2FutureTransformer()
    transformer.visit(module)

    expected_body = imports.get_body(future='__future__') + [
        ast.Import(
            names=[ast.alias(name='os', asname=None)],
        ),
    ]

    assert module.body == expected_body

# Generated at 2022-06-21 17:51:43.626592
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:51:52.279013
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fake_domains import FakeDomain
    from ..utils.testing import compare_ast

    import sys
    import ast
    if sys.version_info < (3, 8):
        # ast.PyCF_ONLY_AST is deprecated as of Python 3.8.
        # You need to use the ast.parse() function instead.
        tree = ast.parse(
            '''
            import future
            from foo.bar import *
            from foo.baz import *
            ''')
    else:
        tree = ast.parse(
            '''
            import future
            from foo.bar import *
            from foo.baz import *
            ''', mode='exec')

    tree = Python2FutureTransformer(FakeDomain()).visit(tree)


# Generated at 2022-06-21 17:51:53.500363
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:51:59.337545
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.visitor import compare_ast

    source = '''a=1\nb=2'''
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a=1
b=2'''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    codeobj = compile(tree, '', 'exec')
    assert expected in codeobj.co_code.decode()
    compare_ast(tree, expected)

# Generated at 2022-06-21 17:52:08.175005
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TODO: use more advanced assertion, like same_source. However, it
    # fails to compare code with __future__ imports
    transformer = Python2FutureTransformer()

# Generated at 2022-06-21 17:52:08.720197
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:52:12.420349
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x._tree_changed is False
    assert x.target == (2, 7)
    assert x.import_from == '__future__'
    assert x.future_imports == ['absolute_import', 'division', 'print_function', 'unicode_literals']

# Generated at 2022-06-21 17:52:22.061980
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("print('hello')")
    tree = Python2FutureTransformer().visit(tree)

    expected = ast.Module(
        body=[
            ast.ImportFrom(module='__future__', names=[
                ast.alias(name='absolute_import', asname=None),
                ast.alias(name='division', asname=None),
                ast.alias(name='print_function', asname=None),
                ast.alias(name='unicode_literals', asname=None)],
                          level=0),
            ast.Expr(value=ast.Str(s='hello')),
            ast.Expr(value=ast.Name(id='None', ctx=ast.Load()))
        ])
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 17:52:24.327258
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:52:30.861999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    t = Python2FutureTransformer()
    assert str(ast.dump(t.visit(ast.parse("""\
    print(1)
    """)))) == str(ast.dump(ast.parse("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print(1)
    """)))

# Generated at 2022-06-21 17:53:53.800906
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert str(t) == '<Python2FutureTransformer [2, 7]>'



# Generated at 2022-06-21 17:53:56.398525
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import check_constr_parameters_defaults

    check_constr_parameters_defaults(Python2FutureTransformer)

# Generated at 2022-06-21 17:54:01.848082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    original_tree = ast.parse('print(0)')
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(original_tree)
    assert astor.to_source(new_tree) == dedent(
        '''\
        # Python 2.7 future imports
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print(0)''')

# Generated at 2022-06-21 17:54:03.624742
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:54:04.756819
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:54:11.228123
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(
        '''
        import os
        print('Hello, World!')
        '''
    )
    module = Python2FutureTransformer().visit(module)
    print(ast.dump(module))

# Generated at 2022-06-21 17:54:22.242177
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    actual = snippet('''
        import future
        import future.standard_library
        x = 1
        if x == 1:
            print('Hello world')
    ''')
    from typed_ast import ast3
    t = Python2FutureTransformer()
    tree = ast3.parse(actual)
    lst = list(ast3.walk(tree))
    for node in lst:
        new_node = t.visit(node)
        if new_node is not None:
            ast3.copy_location(new_node, node)
            ast3.fix_missing_locations(new_node)

# Generated at 2022-06-21 17:54:26.981615
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """
    import sys
    import datetime
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import sys
    import datetime
    """
    t = Python2FutureTransformer()
    tree = ast.parse(code)
    t.visit(tree)
    new_src = astor.to_source(tree)
    assert new_src == expected

# Generated at 2022-06-21 17:54:27.841707
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:54:38.556421
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from asg.models import Tree
    from asg.traversal import TraversalException
    from .context import Context
    from .node_transformer import NodeTransformerException

    class TestNodeTransformer(Python2FutureTransformer):
        def __init__(self, ctx: Context):
            super().__init__(ctx)
            self._tree_changed = False

    tree = Tree.from_str('')
    ctx = Context(tree=tree, logger=tree.logger)
    ctx.logger.setLevel('DEBUG')
    ctx.logger.handlers[0].setLevel('DEBUG')

    transformer = TestNodeTransformer(ctx)