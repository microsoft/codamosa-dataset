

# Generated at 2022-06-21 17:46:12.375017
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-21 17:46:15.562044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse('import ast3')
    node = transformer.visit(node)
    assert ast.dump(node) == "import ast3"
    assert transformer.tree_changed == True



# Generated at 2022-06-21 17:46:19.555483
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # arrange
    node = ast.parse('')
    transformer = Python2FutureTransformer()

    # act
    transformer.visit(node)

    # assert
    assert len(node.body) == 4
    for i in range(4):
        assert isinstance(node.body[i], ast.ImportFrom)
        assert node.body[i].module == '__future__'

# Generated at 2022-06-21 17:46:27.648989
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    actual = Python2FutureTransformer().transform(
        """
        print(1)
        print(2)
        print(3)
        """)
    print(actual)
    assert actual == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    print(1)
    print(2)
    print(3)
    """.strip()


# Generated at 2022-06-21 17:46:34.046141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    module = parse("""
    a = 1
    """)
    module_ = Python2FutureTransformer().visit(module)
    assert str(module_) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1"""


# Generated at 2022-06-21 17:46:43.303149
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Empty module
    tree = ast.parse('')
    # Applying a Python2FutureTransformer
    Python2FutureTransformer(tree=tree).visit(tree)
    tree = ast.parse('')
    # Applying a Python2FutureTransformer
    Python2FutureTransformer(tree=tree).visit(tree)
    tree = ast.parse('')
    # Applying a Python2FutureTransformer
    Python2FutureTransformer(tree=tree).visit(tree)
    # Empty module
    tree = ast.parse('')
    # Applying a Python2FutureTransformer
    Python2FutureTransformer(tree=tree).visit(tree)
    # Empty module
    tree = ast.parse('')
    # Applying a Python2FutureTransformer

# Generated at 2022-06-21 17:46:46.224731
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.Module(body=[])
    transformer = Python2FutureTransformer()

    new_node = transformer.visit_Module(node)
    assert len(new_node.body) == len(imports.get_body(future='__future__'))

# Generated at 2022-06-21 17:46:50.209338
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module, parse
    tree = parse('a=1')
    t = Python2FutureTransformer()
    t.visit(tree)
    assert isinstance(t._tree, Module)
    assert isinstance(t._tree.body[0], ast.ImportFrom)

# Generated at 2022-06-21 17:46:51.921751
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None

# Generated at 2022-06-21 17:46:53.882357
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    cls = Python2FutureTransformer
    assert_equal(cls.__name__, "Python2FutureTransformer")

# Generated at 2022-06-21 17:47:05.589217
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import _ast
    from flake8_future_import.utils.snippet import ast_item_to_str
    from flake8_future_import.utils.snippet import snippet_to_ast_node
    from flake8_future_import.utils.snippet import snippet_to_ast_items

    # First test from a normal (this file) module
    # Module(body=[Import(names=[alias(name='future', asname=None)])])
    module_ast = snippet('from __future__ import absolute_import').get_ast_module()
    transformer = Python2FutureTransformer()
    assert isinstance(transformer.visit(module_ast), _ast.Module)
    assert transformer._tree_changed
    # 'from __future__ import absolute_import'

# Generated at 2022-06-21 17:47:08.095194
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform
    from .future import Python2FutureTransformer
    from .base import BaseNodeTransformer
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:47:11.984876
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert repr(t)

if __name__ == '__main__':
    Python2FutureTransformer.unittest()

# Generated at 2022-06-21 17:47:14.319001
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None


# Generated at 2022-06-21 17:47:21.957635
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transpiler = Python2FutureTransformer()
    code = '''\
x = 1'''
    tree = ast.parse(code)  # type: ignore
    tree = transpiler.visit(tree)  # type: ignore
    code2 = astor.to_source(tree)
    assert code2 == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1'''



# Generated at 2022-06-21 17:47:23.758930
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .pipeline import unit_test_transformer
    unit_test_transformer(Python2FutureTransformer)

# Generated at 2022-06-21 17:47:24.365574
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-21 17:47:26.557802
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    transformer = Python2FutureTransformer(2.7)

# Generated at 2022-06-21 17:47:30.846176
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.takes_future_imports == True
    assert Python2FutureTransformer.takes_standard_library == False

# Generated at 2022-06-21 17:47:38.765791
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..transformer_test import compare_python
    from .python3 import Python3UnicodeTransformer

    class DummyUnicodeTransformer(Python3UnicodeTransformer):
        target = (2, 7)

    # Without UnicodeTransformer
    text = '''\
    # encoding: utf-8
    a = 'a'
    print(a)
    '''
    expected = '''\
    # encoding: utf-8
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    a = 'a'
    print(a)
    '''
    tree = ast.parse(text)

# Generated at 2022-06-21 17:47:52.913903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .python2 import ForTransformer
    from .python2 import PrintTransformer
    from .python2 import FunctionTransformer
    from .python2 import ClassTransformer
    from .python2 import DivisionTransformer
    from .python2 import UnicodeTransformer

    import astor
    from ..converter import Converter

    class TestConverter(Converter):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return ast.copy_location(ast.Module(body=node.body), node)


# Generated at 2022-06-21 17:47:58.791489
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("")
    trans = Python2FutureTransformer()
    new_tree = trans.visit(tree)
    assert new_tree.body[0].lineno == 2
    assert new_tree.body[1].lineno == 3
    assert new_tree.body[2].lineno == 4
    assert new_tree.body[3].lineno == 5
    assert new_tree.body[4].lineno == 6

# Generated at 2022-06-21 17:48:10.496540
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    old_module = ast.parse('a = 1')
    expected = [
        ast.ImportFrom(module='__future__', names=[ast.alias(name='absolute_import', asname=None)], level=0),
        ast.ImportFrom(module='__future__', names=[ast.alias(name='division', asname=None)], level=0),
        ast.ImportFrom(module='__future__', names=[ast.alias(name='print_function', asname=None)], level=0),
        ast.ImportFrom(module='__future__', names=[ast.alias(name='unicode_literals', asname=None)], level=0),
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1)),
    ]


# Generated at 2022-06-21 17:48:16.295426
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse(dedent(
        """
        def test_function():
            print('test')
        """
    ))
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == dedent(
        """
        from __future__ import absolute_import
        
        from __future__ import division
        
        from __future__ import print_function
        
        from __future__ import unicode_literals
        
        def test_function():
            print('test')
        """
    )

# Generated at 2022-06-21 17:48:22.781451
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os
    import astor

    # Prepend path to the project
    sys.path.insert(0, os.path.abspath(os.path.join(__file__, "../../../")))
    from basescript.snippets import snippet_visitor
    snippet = snippet_visitor(Python2FutureTransformer)
    before = """
        import os
        import sys
    """
    after = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
    """
    assert astor.to_source(snippet(before)).strip() == after.strip()

# Generated at 2022-06-21 17:48:25.147703
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:48:26.358657
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:48:34.048707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '''
        def foo():
            """Function foo
            """
            return True
    '''
    source_tree = ast.parse(source)
    expected_tree = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo():
            """Function foo
            """
            return True
    ''')
    transformer = Python2FutureTransformer()
    actual_tree = transformer.visit(source_tree)
    assert actual_tree == expected_tree

# Generated at 2022-06-21 17:48:40.569013
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    source = '''
import sys
import os
'''
    expected = '''
{}
import sys
import os
'''.format(imports.get_source(future='__future__'))  # type: ignore
    node = ast.parse(source)
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert astor.to_source(node) == expected  # type: ignore

# Generated at 2022-06-21 17:48:48.053825
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent
    from ..utils.snippet import UntransformedCode

    code = UntransformedCode(dedent("""\
        import sys
        """))

    Python2FutureTransformer(code).transform()

    assert dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        """) == code.transformed_code

# Generated at 2022-06-21 17:49:00.993156
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print("Hello World")')
    new_node = Python2FutureTransformer().visit(node)
    assert new_node.body[0].value.s == 'Hello World'
    assert new_node.body[1].value.s == 'Hello World'

# Generated at 2022-06-21 17:49:10.395481
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    import sys
    if sys.version_info < (3, 5):
        from typed_ast import fix_missing_locations
    import textwrap
    
    source = textwrap.dedent("""
    def func(a,b):
        return a + b
    """)
    parser = ast.parse(source)
    
    transformer = Python2FutureTransformer()
    tree = transformer.visit(parser)
    
    
    # check if the tree has been modified as expected
    expected = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def func(a,b):
        return a + b
    """)
    

# Generated at 2022-06-21 17:49:12.940106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None)

# Generated at 2022-06-21 17:49:14.240560
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:49:16.180935
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(None), Python2FutureTransformer)



# Generated at 2022-06-21 17:49:19.581957
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    # Set up
    module = astor.parse_file(__file__)
    transformer = Python2FutureTransformer()
    transformer.visit(module)

    # Test
    assert transformer._tree_changed

# Generated at 2022-06-21 17:49:22.437550
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    trans.visit(ast.parse('''
        import os
        import sys

        print('Hello world')
    '''))
    assert trans._tree_changed


__transformer__ = Python2FutureTransformer

# Generated at 2022-06-21 17:49:26.010224
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"
    actual = ast.parse(expected)
    assert ast.dump(actual) == ast.dump(Python2FutureTransformer(None).visit(actual))

# Generated at 2022-06-21 17:49:30.397106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module, parse

    node = Module(body=[])
    Python2FutureTransformer().apply_to_ast(node)
    tree = parse('from __future__ import absolute_import')
    assert node.body[0] == tree.body[0]

# Generated at 2022-06-21 17:49:37.919992
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    def f():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def f():
        pass
    """
    from ..utils import unparse
    from .utils import get_ast

    node = get_ast(code)
    transformed = Python2FutureTransformer().visit(node)
    transformed = unparse(transformed)
    assert transformed == expected

# Generated at 2022-06-21 17:50:01.842792
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.method import assert_equal_ast
    from ..utils.method import method_test_template
    from ..utils.method import parse
    
    base_transformer = Python2FutureTransformer()
    
    def node_method(transformer, node):
        return (transformer.visit_Module(node))
    
    def test_method(input_node, expect_node):
        input_node = parse(input_node)
        assert_equal_ast(expect_node, node_method(base_transformer, input_node))
    
    method_test_template(test_method, base_transformer.visit_Module)

# Generated at 2022-06-21 17:50:03.356973
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:50:04.773427
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:50:12.829164
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typing import List, Tuple
    # Create Python2FutureTransformer instance
    instance = Python2FutureTransformer()
    # Create visitor
    visitor = instance.visitor()
    # Source code
    source = """
    pass
    """
    # Parse AST Node
    node = ast.parse(source)
    # Visit AST Node
    new_node = visitor.visit(node)  # type: ignore
    # Check the node was transformed
    new_node.body[0].__class__.__name__ == 'ImportFrom'
    assert new_node.body[0].names[0].name == 'absolute_import'
    assert new_node.body[1].names[0].name == 'division'
    assert new_node.body[2].names[0].name == 'print_function'
    assert new_node

# Generated at 2022-06-21 17:50:14.582217
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:50:16.353399
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transformer import Transformer
    assert issubclass(Python2FutureTransformer, Transformer)

# Generated at 2022-06-21 17:50:18.441365
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:50:23.312081
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("a = 5")
    tree = transformer.visit(tree)
    assert "absolute_import" in tree._fields
    assert "division" in tree._fields
    assert "print_function" in tree._fields
    assert "unicode_literals" in tree._fields
    assert "a = 5" in tree._fields

# Generated at 2022-06-21 17:50:26.725064
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test for method visit_Module of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    example_node = ast.parse("")
    result_node = transformer.visit(example_node)
    assert result_node == example_node

# Generated at 2022-06-21 17:50:27.920374
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:51:08.824362
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import node_factory
    # Tested code
    input_code = node_factory.build_ast('if True:\n    pass')
    tested_code = input_code
    # Expected output (AST)
    expected_output = node_factory.build_ast('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nif True:\n    pass')
    # Actual output (AST)
    actual_output = Python2FutureTransformer().visit(tested_code)
    # Assert
    assert ast.dump(expected_output) == ast.dump(actual_output)



# Generated at 2022-06-21 17:51:11.301417
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert issubclass(t.__class__, BaseNodeTransformer)
    assert t._tree_changed is False  # pylint: disable=protected-access


# Generated at 2022-06-21 17:51:17.876248
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse(textwrap.dedent('''\
    from itertools import islice, count
    from functools import reduce
    '''))

    actual = Python2FutureTransformer(tree=tree, target_version=Python2FutureTransformer.target).visit(tree)


# Generated at 2022-06-21 17:51:25.378348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from mypy_extensions import Block
    from ..utils.test_utils import generate_from_example, generate_to_example
    
    transformer = Python2FutureTransformer()
    from_example = generate_from_example(transformer)
    to_example = generate_to_example(transformer)
    
    example = from_example(
        name='test',
        module=Block(
              body=[]
        )
    )
    result = transformer.visit_Module(example)

# Generated at 2022-06-21 17:51:31.747444
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = u'''

"""

"""

x = 1

'''
    expected_code = u'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

"""

"""

x = 1

'''
    module = ast.parse(code)
    Python2FutureTransformer().visit(module)
    assert astor.to_source(module) == expected_code

# Generated at 2022-06-21 17:51:33.550028
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(2.7)
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer.target == (2, 7)



# Generated at 2022-06-21 17:51:42.767577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    '''Test our custom change to visit_Module
    '''

    import astor
    # Build the AST

# Generated at 2022-06-21 17:51:49.124535
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ast_tree = ast.parse("2+2")
    expected_ast_tree = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n2+2")
    Python2FutureTransformer().visit(ast_tree)
    assert ast_tree == expected_ast_tree, "python2 future import transformer doesn't work"

# Generated at 2022-06-21 17:51:50.767762
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-21 17:51:57.051612
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    source = """
x = 5
y = 6
z = x + y
"""
    source_tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    transformer.visit(source_tree)
    assert astor.to_source(source_tree) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 5
y = 6
z = x + y
"""

# Generated at 2022-06-21 17:53:24.653768
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('1+1')
    t = Python2FutureTransformer()
    node = t.visit(node)
    assert node.body[0].module == '__future__'
    assert node.body[1].module == '__future__'
    assert node.body[2].module == '__future__'
    assert node.body[3].module == '__future__'
    assert node.body[4].body[0].value.n == 1
    assert node.body[4].body[0].value.lineno == 1
    assert node.body[4].body[0].value.col_offset == 0

# Generated at 2022-06-21 17:53:30.124372
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("")
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed is True
    assert transformer.target == (2, 7)
    assert type(node) is ast.Module
    assert node.body[0].value.names[0] == "absolute_import"
    assert node.body[1].value.names[0] == "division"
    assert node.body[2].value.names[0] == "print_function"
    assert node.body[3].value.names[0] == "unicode_literals"

# Generated at 2022-06-21 17:53:37.264892
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_node

    src = source(imports)
    print(src)

    node = ast.parse(src)
    print_node(node)

    tf = Python2FutureTransformer()
    node = tf.visit(node)
    print_node(node)

    assert tf.tree_changed is True
    src2 = source(node)
    print(src2)
    assert src2 == src

# Generated at 2022-06-21 17:53:39.039541
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed is False
    assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:53:47.437989
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transforms import Python2FutureTransformer
    py2_future_transformer = Python2FutureTransformer()
    assert py2_future_transformer.target == (2, 7)
    assert py2_future_transformer.name == 'Python2FutureTransformer'
    assert py2_future_transformer.visit_Module.__name__ == 'visit_Module'


# Generated at 2022-06-21 17:53:55.494760
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tests.transpilers.base import BaseTranspilerTestCase
    from typed_astunparse import unparse
    from ..utils.snippet import snippet
    import textwrap
    import ast
    import astunparse

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def simple_code():
        from future import absolute_import, division, print_function
        from future import unicode_literals
        import difflib
        difflib.SequenceMatcher()

    code_to_test = simple_code.get_ast(future='__future__')

    class Test(BaseTranspilerTestCase):
        def test_python2_future(self):
            python

# Generated at 2022-06-21 17:53:57.886118
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast3.parse(imports.template)  # type: ignore
    Python2FutureTransformer().visit(tree)  # type: ignore
    expected = ast3.parse(imports.expected)  # type: ignore
    assert ast3.dump(tree, annotate_fields=False) == ast3.dump(expected, annotate_fields=False)  # type: ignore

# Generated at 2022-06-21 17:54:04.795165
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import build_module_from_code
    module = build_module_from_code(code="""
    """)
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert module.body[0].name == 'absolute_import'
    assert module.body[1].name == 'division'
    assert module.body[2].name == 'print_function'
    assert module.body[3].name == 'unicode_literals'

# Generated at 2022-06-21 17:54:13.934003
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
x = "This is a string."
y = b"This is also a string."
z = u"This is a unicode string."
print("Hello, World!")
    """
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = "This is a string."
y = b"This is also a string."
z = u"This is a unicode string."
print("Hello, World!")
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    actual = ast.unparse(tree)
    assert actual == expected

# Generated at 2022-06-21 17:54:20.874311
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("a = 1")
    expected = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1")
    actual = transformer.visit(node)
    assert ast.dump(actual, include_attributes=False) == ast.dump(expected, include_attributes=False)