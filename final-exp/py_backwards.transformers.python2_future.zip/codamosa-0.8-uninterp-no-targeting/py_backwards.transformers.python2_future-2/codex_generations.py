

# Generated at 2022-06-21 17:46:10.789810
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert (Python2FutureTransformer()
            .visit(ast.parse("x = 7"))
            .body  # type: ignore
            ) == (
        imports.get_body(future='__future__')
        + [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
         value=ast.Num(n=7))])  # type: ignore

# Generated at 2022-06-21 17:46:11.719637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-21 17:46:19.918541
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    exec(imports.get_code(future='__future__'), globals())

    tree = ast.parse("""
    def func(name):
        return 'Hello %s!' % name
    """)

    # Show AST before transformation
    print(ast.dump(tree, include_attributes=True))

    expected_tree = ast.parse("""
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

    def func(name):
        return 'Hello %s!' % name
    """)

    # Show AST after transformation
    assert expected_tree == Python2FutureTransformer().visit(tree)
    print(ast.dump(expected_tree, include_attributes=True))


# Generated at 2022-06-21 17:46:24.359239
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x: ast.AST = ast.parse("""def foo(x):
    print(x)
""")
    y: ast.AST = Python2FutureTransformer().visit(x)
    assert y is not None

# Generated at 2022-06-21 17:46:25.824252
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)



# Generated at 2022-06-21 17:46:30.306333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import init_ast, run_transformer

    init_ast('./tests/data/test_py2_future.py')
    run_transformer(Python2FutureTransformer)



# Generated at 2022-06-21 17:46:36.921410
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast3
    from .base import BaseNodeTransformerTestCase
    class Test(BaseNodeTransformerTestCase):
        def test(self):
            s = """x = 1"""
            t = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1"""
            self.check_transform(Python2FutureTransformer, s, t)

    Test().test()

# Generated at 2022-06-21 17:46:44.709060
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    from autofix.Project import Project
    from autofix.config.ProjectConfig import ProjectConfig
    from autofix.state.ProjectState import ProjectState
    from autofix.util.FileSystemUtil import readFileContent
    from autofix.util.VirtualEnvironmentUtil import pip_install_packages

    config = ProjectConfig(package_metadata={})
    project = Project(config, '.', 'Pipfile')
    state = ProjectState(project)

    # Act
    target = Python2FutureTransformer(project, state)

    # Assert
    assert isinstance(target, Python2FutureTransformer)
    assert target._state is state


# Generated at 2022-06-21 17:46:53.327317
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "import os"
    module = ast.parse(code)
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    result = ast.dump(new_module)
    assert result == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Import(names=[alias(name='os', asname=None)])])"

# Generated at 2022-06-21 17:46:56.695519
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Mock(Python2FutureTransformer):
        def __init__(self):
            self._tree_changed = False

    tree = ast.parse("foo")
    trans = Mock()
    res = trans.visit(tree)
    assert isinstance(res, ast.Module)
    assert isinstance(res.body[0], ast.ImportFrom)

# Generated at 2022-06-21 17:47:00.722230
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import python_transformer_factory
    import astor


# Generated at 2022-06-21 17:47:02.497110
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:47:03.369989
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # TODO
    pass

# Generated at 2022-06-21 17:47:04.441018
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:47:06.890098
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing.utils import build_tests_from_snippet
    tests = build_tests_from_snippet(Python2FutureTransformer, imports)
    for test in tests:
        assert isinstance(test.output_ast, ast.Module)

# Generated at 2022-06-21 17:47:08.120438
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(0)
    assert t



# Generated at 2022-06-21 17:47:09.719795
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with pytest.raises(TypeError):
        Python2FutureTransformer()

# Generated at 2022-06-21 17:47:17.878903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.Module([
        ast.Expr(
            value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Str(s='Hello')],
                keywords=[],
                starargs=None,
                kwargs=None
            )
        ),
    ])
    transformed = Python2FutureTransformer().visit(module)
    assert transformed.body == imports.tree.body + module.body
    assert Python2FutureTransformer().visit(transformed) is transformed

# Generated at 2022-06-21 17:47:29.165481
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import collections
    import sys
    import sys
    import sys
    import sys


# Generated at 2022-06-21 17:47:37.919877
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from pprint import pprint
    from .test_utils import generate_code
    from .test_utils import parse_ast

    module = ast.Module([
        ast.ImportFrom(
            module='typed_ast',
            names=[ast.alias(
                name='ast3',
                asname=None
            )],
            level=0
        )
    ])
    pprint(module)
    print(generate_code(module))
    transformer = Python2FutureTransformer()
    result = transformer.visit_Module(module)
    pprint(result)
    print(generate_code(result))
    assert parse_ast(imports(future='__future__') + '\n' + generate_code(module)) == result

# Generated at 2022-06-21 17:47:49.910609
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..transforms.base import (
        BaseNodeTransformer,
        BaseNodeTransformerTestCase,
    )

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)

        def visit_Module(self, node):
            node.body.insert(0, ast.parse('from future import print_function'))
            return node

    class TestCase(BaseNodeTransformerTestCase):
        def test(self):
            module = TestTransformer({}).visit(ast.parse(self.code))
            self.assertEqual(astor.to_source(module), self.after)

    TestCase.add_test("print 3", "from future import print_function\nprint 3")

# Generated at 2022-06-21 17:47:59.242765
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer.__new__(Python2FutureTransformer)
    assert isinstance(transformer, BaseNodeTransformer), \
        f"Expected Python2FutureTransformer instance, but got {type(transformer)}"
    assert isinstance(transformer, Python2FutureTransformer), \
        f"Expected Python2FutureTransformer instance, but got {type(transformer)}"
    assert transformer._tree_changed == False, \
        f"Expected _tree_changed to be False, but got {type(transformer._tree_changed)}"
    assert transformer.target == (2, 7), \
        f"Expected target to be (2, 7), but got {type(transformer.target)}"

# Generated at 2022-06-21 17:48:10.711362
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test module with no imports
    tree = ast.parse("")
    node = tree.body[0]
    transformer = Python2FutureTransformer()
    transformer.visit_Module(node)
    source_code = astor.to_source(node)
    assert source_code == (
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
    )

    # Test module with no imports
    tree = ast.parse("def func():pass")
    node = tree.body[0]
    transformer = Python2FutureTransformer()
    transformer.visit_Module(node)
    source_code = astor.to_source(node)

# Generated at 2022-06-21 17:48:16.579274
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
if True:
    import os
    class Test():
        pass
''')

    node = Python2FutureTransformer.run_pipeline(node)

    module = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

if True:
    import os
    class Test():
        pass
''')

    assert ast.dump(node, include_attributes=True) == ast.dump(module, include_attributes=True)

# Generated at 2022-06-21 17:48:24.526941
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    target = Python2FutureTransformer.target
    # When
    instance = Python2FutureTransformer()
    # Then
    assert isinstance(instance, Python2FutureTransformer)
    assert hasattr(instance, 'target')
    assert isinstance(instance.target, tuple)
    assert instance.target == target
    assert hasattr(instance, '_tree_changed')
    assert instance._tree_changed is False
    assert hasattr(instance, '_future_library')
    assert isinstance(instance._future_library, set)
    assert instance._future_library == set()
    assert hasattr(instance, 'visit_Module')
    assert callable(instance.visit_Module)
    assert hasattr(instance, 'visit_ImportFrom')
    assert callable(instance.visit_ImportFrom)

#

# Generated at 2022-06-21 17:48:34.989694
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    node = ast.parse("x = 3").body
    tree = Python2FutureTransformer().visit(node)
    #print(ast.dump(tree))
    assert ast.dump(tree) == "Module(body=[import_from(module='future', names=[alias(name='absolute_import', asname=None)], level=0), import_from(module='future', names=[alias(name='division', asname=None)], level=0), import_from(module='future', names=[alias(name='print_function', asname=None)], level=0), import_from(module='future', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=3))])"

# Unit test

# Generated at 2022-06-21 17:48:37.937048
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest
    
    suite = unittest.TestSuite()
    
    suite.addTest(Python2FutureTransformerTestCase('test_method_visit_Module'))

    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-21 17:48:46.151278
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import NodeAssertionMixin

    class Test(NodeAssertionMixin):
        CODE = "a = 1; print(a)"
        EXPECTED_CODE = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na = 1; print(a)"

        def test(self):
            node = ast.parse(self.CODE)
            Python2FutureTransformer().visit(node)
            self.assertEqual(
                Python2FutureTransformer().visit(node),
                ast.parse(self.EXPECTED_CODE)
            )

    Test().test()

# Generated at 2022-06-21 17:48:53.205719
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
if __name__ == '__main__':
    pass
    ''')
    t = Python2FutureTransformer(debug=True)
    t.visit(module)
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ImportFrom)
    assert isinstance(module.body[2], ast.ImportFrom)
    assert isinstance(module.body[3], ast.ImportFrom)
    assert isinstance(module.body[4], ast.If)


# Generated at 2022-06-21 17:49:00.208771
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    node = ast.parse('import os')
    node = t.visit(node)
    assert t.tree_changed() is True
    assert node.body
    assert ast.dump(node.body[0]) == 'from __future__ import absolute_import'
    assert ast.dump(node.body[1]) == 'from __future__ import division'
    assert ast.dump(node.body[2]) == 'from __future__ import print_function'
    assert ast.dump(node.body[3]) == 'from __future__ import unicode_literals'
    assert ast.dump(node.body[4]) == 'import os'

# Generated at 2022-06-21 17:49:08.012239
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print(1 + 2)')
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    assert transformer._tree_changed
    assert isinstance(new_module, ast.Module)
    print(ast.dump(new_module))

# Generated at 2022-06-21 17:49:08.916833
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:49:16.550456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Tests visit_Module with:
    - imports
    """
    tree = ast.parse(
        textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        # test imports
        import os  # test
        '''),
        filename='<unknown>',
        mode='exec')

    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

    assert ast.dump(tree) == textwrap.dedent('''
        <_ast.Module object at 0x000001C4F4C4D4E0>
        ''')[1:]



# Generated at 2022-06-21 17:49:17.967441
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer"""
   

# Generated at 2022-06-21 17:49:19.673934
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(None)
    assert t.target == (2, 7)

# Generated at 2022-06-21 17:49:27.671115
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('\n***** test_Python2FutureTransformer_visit_Module *****')
    source_code = """
        def f(x):
            return x**2
    """
    future_imports = ['division', 'unicode_literals', 'print_function', 'absolute_import']
    expected_source_code = """
        from __future__ import division
        from __future__ import unicode_literals
        from __future__ import print_function
        from __future__ import absolute_import
        def f(x):
            return x**2
    """
    node = ast.parse(source_code)
    print_ast(node)
    print("")
    py2future = Python2FutureTransformer(future_imports)
    py2future.visit(node)
    print_ast(node)
   

# Generated at 2022-06-21 17:49:39.163334
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(
        '''
#!/usr/bin/env python
# coding: utf-8
import sys
print(sys.getdefaultencoding())
        '''
    )
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-21 17:49:40.180279
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:49:45.486429
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_ast = ast.parse(
"""def f():
    return 1 / 3
"""
    )
    actual_output = Python2FutureTransformer().visit(input_ast).body

# Generated at 2022-06-21 17:49:53.323323
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  test_case_syntax = """
  var1 = 1
  var2 = 2
  """

  expected_syntax = """
  from __future__ import absolute_import
  from __future__ import division
  from __future__ import print_function
  from __future__ import unicode_literals
  var1 = 1
  var2 = 2
  """
  
  # Transform the code to Python 3
  module_node = ast.parse(test_case_syntax)
  Python2FutureTransformer().visit(module_node)
  generated_syntax = astunparse.unparse(module_node)
  
  assert expected_syntax == generated_syntax
  

# Generated at 2022-06-21 17:50:09.353433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class Test(ast.NodeVisitor):
        def generic_visit(self, node):
            print('generic_visit({})'.format(node.__class__.__name__))
            return node

    source = """
    def foo():
        pass    

    print('hello world')
    """
    module = ast.parse(source)
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    print(ast.dump(module))
    test = Test()
    module = test.visit(module)
    print(module)

# Generated at 2022-06-21 17:50:17.368838
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typing import List
    from ..utils.source import source

    input = '''
print('Hello world!')
    '''
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello world!')
    '''

    node = ast.parse(input)
    Python2FutureTransformer().visit(node)
    assert source(node) == expected

# Generated at 2022-06-21 17:50:23.984764
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    target_ast = ast.parse('from __future__ import absolute_import\n'
                           'from __future__ import division\n'
                           'from __future__ import print_function\n'
                           'from __future__ import unicode_literals\n'
                           '\n'
                           'x = 1')
    actual_ast = ast.parse('x = 1')
    Python2FutureTransformer().visit(actual_ast)
    assert deep_eq(target_ast, actual_ast)



# Generated at 2022-06-21 17:50:30.369533
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""

    # Visit module
    module = ast.parse("")
    Python2FutureTransformer().visit(module)

    # Check for correct imports
    assert len(module.body) == 4
    assert isinstance(module.body[0], ast.ImportFrom)
    assert module.body[0].module == '__future__'
    assert module.body[0].names[0].name == 'absolute_import'
    assert isinstance(module.body[1], ast.ImportFrom)
    assert module.body[1].module == '__future__'
    assert module.body[1].names[0].name == 'division'
    assert isinstance(module.body[2], ast.ImportFrom)
    assert module.body[2].module == '__future__'
   

# Generated at 2022-06-21 17:50:34.049789
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    code = """
    def func(x):
        return x ** 2

    """

    transformer = Python2FutureTransformer()
    module_tree = transformer.visit(ast.parse(code))
    ast.fix_missing_locations(module_tree)

    expected_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def func(x):
        return x ** 2
    """
    assert to_source(module_tree) == expected_code

# Generated at 2022-06-21 17:50:42.322146
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('print("Hello")')
    result = Python2FutureTransformer().visit(node)
    assert isinstance(result, ast.Module)
    assert len(result.body) == 4
    assert isinstance(result.body[0], ast.ImportFrom)
    assert isinstance(result.body[1], ast.ImportFrom)
    assert isinstance(result.body[2], ast.ImportFrom)
    assert isinstance(result.body[3], ast.ImportFrom)
    assert result.body[0].module == '__future__'
    assert result.body[0].names[0].name == 'absolute_import'
    assert result.body[1].module == '__future__'
    assert result.body[1].names[0].name == 'division'

# Generated at 2022-06-21 17:50:43.319957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-21 17:50:50.497726
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the first line of the Python2FutureTransformer class."""
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports

# Generated at 2022-06-21 17:50:52.028922
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tr = Python2FutureTransformer(None, None)
    assert tr.target == (2, 7)

# Generated at 2022-06-21 17:50:54.037534
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    assert astor.to_source(Python2FutureTransformer().visit(imports.get_ast())) == astor.to_source(imports.get_ast())

# Generated at 2022-06-21 17:51:22.379680
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import snippet_to_ast
    from .imports import Imports
    f = Python2FutureTransformer
    assert f.__doc__
    assert isinstance(f(), BaseNodeTransformer)
    i = Imports()
    x = f()
    for l in (0, 1, 2):
        i.lines = l
        node = snippet_to_ast.ast_from_snippet(i.get_body())
        node = x.visit(node)
        assert len([x for x in node.body if x.__class__.__name__ == 'Import']) == 4
        assert len([x for x in node.body if x.__class__.__name__ == 'ImportFrom']) == l

# Generated at 2022-06-21 17:51:25.198046
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # GIVEN
    # A Python2FutureTransformer
    transformer = Python2FutureTransformer()

    # WHEN
    # we create an instance
    instance = transformer.__class__()

    # THEN
    # it is an instance of Python2FutureTransformer
    assert isinstance(instance, Python2FutureTransformer)


# Generated at 2022-06-21 17:51:31.711205
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..upgrade import Python2to3Tool
    body = imports.get_body(future='__future__') + [ast.Expr(ast.Str(''), None)]  # type: ignore
    node = ast.Module(body)

    tool = Python2to3Tool()
    transformer = Python2FutureTransformer(tool)
    result_module = transformer.visit(node)
    assert str(result_module) == str(node)
    assert result_module is not node

# Generated at 2022-06-21 17:51:32.433817
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...config import Config


# Generated at 2022-06-21 17:51:34.580879
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trf = Python2FutureTransformer()
    assert trf._tree_changed is False
    assert trf.target == (2, 7)

# Generated at 2022-06-21 17:51:43.507496
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    #
    # No change to non-module nodes
    #
    assert t.visit(ast.Expr(value=ast.Num(n=42))) == ast.Expr(value=ast.Num(n=42))
    assert t.visit(ast.Module(body=[])) == ast.Module(body=[])
    #
    # Changes to module
    #
    body = [ast.Expr(value=ast.Num(n=42))]
    module = ast.Module(body=body)
    res = t.visit(module)

# Generated at 2022-06-21 17:51:49.413748
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as typed_ast3
    from ..unitutil import MockNode

    # ARRANGE #
    node = MockNode(typed_ast3.Module)
    node.body = []

    # ACT #
    actual = Python2FutureTransformer.visit_Module(node)

    # ASSERT #
    assert actual.body == imports.get_body(future='__future__')

# Generated at 2022-06-21 17:51:53.219849
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transform = Python2FutureTransformer()
    assert transform.target == (2, 7)
    assert transform._tree_changed is False
    assert isinstance(transform, ast.NodeTransformer)



# Generated at 2022-06-21 17:51:56.972509
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert isinstance(instance, Python2FutureTransformer)


# Generated at 2022-06-21 17:52:06.013291
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Given
    tree = ast.parse("x = 1 + 2")
    transform = Python2FutureTransformer()

    # When
    new_tree = transform.visit(tree)

    # Then
    expected_module = ast.Module(body=[
        ast.ImportFrom(
            module='future',
            names=[ast.alias(name=name, asname=None) for name in (
                'absolute_import', 'division', 'print_function', 'unicode_literals'
            )],
            level=0
        ),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.BinOp(
            left=ast.Num(n=1), op=ast.Add(), right=ast.Num(n=2)
        ))
    ])

   

# Generated at 2022-06-21 17:52:50.615813
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    source = '''
    # A simple example
    s = "Python syntax highlighting"
    print(s)
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    # A simple example
    s = "Python syntax highlighting"
    print(s)
    '''
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-21 17:53:00.233068
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    m = ast.parse('def test(name: str) -> None: pass', '<test>', 'exec')
    t = Python2FutureTransformer()
    result = t.visit(m)

# Generated at 2022-06-21 17:53:02.641066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-21 17:53:09.838081
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class Module:
        pass
    class FunctionDef:
        pass
    class Name:
        pass
    class Load:
        pass
    class Store:
        pass
    
    # One possible output of Python2FutureTransformer.visit_Module

# Generated at 2022-06-21 17:53:10.470630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:53:13.461749
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans

if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-21 17:53:22.575782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    from typed_ast import ast3 as ast

    source = (
        '# -*- coding: utf-8 -*-\n'
        '\n'
        '\n'
        'import mymodule'
    )
    expected_source = (
        '# -*- coding: utf-8 -*-\n'
        '\n'
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        '\n'
        '\n'
        'import mymodule'
    )
    root_node = ast.parse(source)

    # When
    Python2FutureTransformer

# Generated at 2022-06-21 17:53:24.017872
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit testing for Python2FutureTransformer.visit_Module

    """

# Generated at 2022-06-21 17:53:31.136657
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from textx import metamodel_from_str
    import textx.scoping.providers as scoping_providers
    from typed_ast.transforms import Py2Future

    # Register the textx metamodel

# Generated at 2022-06-21 17:53:37.264066
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node1 = ast.Module([], lineno=1, col_offset=0)
    transformer = Python2FutureTransformer.from_tree(node1)
    node2 = transformer.tree
    assert node2 is not node1
    assert node2 != node1
    source = source_to_text(node2)
    assert source == imports.get_source()
    assert transformer._tree_changed is True



# Generated at 2022-06-21 17:54:56.368020
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.is_enabled() == True
    assert Python2FutureTransformer.get_priority() == 200
    assert repr(Python2FutureTransformer) == 'Python2FutureTransformer()'
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)
    assert callable(Python2FutureTransformer.generic_visit)


# Generated at 2022-06-21 17:55:04.724848
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def some_module():
        pass

    old_tree = some_module.get_ast()
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(old_tree)

    assert transformer._tree_changed
    assert new_tree.body[0] == imports.get_ast(future='__future__').body[0]
    assert new_tree.body[1] == imports.get_ast(future='__future__').body[1]
    assert new_tree.body[2] == imports.get_ast(future='__future__').body[2]
    assert new_tree.body[3] == imports.get_ast(future='__future__').body[3]
    assert new_tree.body[4] == some_module.get_ast().body[0]

# Generated at 2022-06-21 17:55:10.019985
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """
    import json

    print('Hello, World!')
    """
    tree = ast.parse(code)
    tree = Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import json

print('Hello, World!')"""

# Generated at 2022-06-21 17:55:17.383689
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Test 0: check if the node tree is changed
    transformer = Python2FutureTransformer()
    node = ast.parse('''
        'use six'
    ''')
    transformer.visit(node)
    assert transformer._tree_changed

    # Test 1: check if the __future__ imports are prepended at the begining of the node tree
    transformer = Python2FutureTransformer()
    node = ast.parse('''
        a = 1
    ''')
    actual = transformer.visit(node)
    expected = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
    ''')

# Generated at 2022-06-21 17:55:26.129758
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    x = Python2FutureTransformer()
    assert isinstance(x, ast.NodeVisitor), 'Need to be NodeVisitor'
    assert hasattr(x, 'target'), 'Need to have attribute `target`'
    assert hasattr(x, 'visit_Module'), 'Need to visit module'
    assert hasattr(x, 'visit'), 'Need to have generic visit method'
    assert hasattr(x, 'generic_visit'), 'Need to have generic_visit method'
    
    

# Generated at 2022-06-21 17:55:31.885377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected_visitor = Python2FutureTransformer()
    expected_source = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(1)')
    expected_snippet = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals')
    source = ast.parse('print(1)')
    assert expected_visitor.visit(source) == expected_source
    assert expected_visitor.visit(ast.parse('print(1)')) == expected_snippet

# Generated at 2022-06-21 17:55:33.359766
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:55:38.399471
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""
a = b
""")
    Python2FutureTransformer().visit(node)
    assert str(node) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = b
"""



# Generated at 2022-06-21 17:55:44.919024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    from typed_ast import ast3
    node = ast.Module()
    node.body = [ast.FunctionDef(name='main',
                                 args=ast.arguments(),
                                 body=[ast.Pass()],
                                 decorator_list=[])]
    transformer = Python2FutureTransformer()
    transformed = transformer.visit(node)
    assert isinstance(transformed, ast3.Module)
    assert len(transformed.body) == 5
    assert isinstance(transformed.body[0], ast3.ImportFrom)
    assert transformed.body[0].module == 'future'
    assert transformed.body[0].names == [ast3.alias(
                                                    name='absolute_import',
                                                    asname=None)]

# Generated at 2022-06-21 17:55:50.612104
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse('print("Hello")')
    n = Python2FutureTransformer().visit(module_node)
    module_node_transformed = ast.parse('''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("Hello")''')
    assert ast.dump(n) == ast.dump(module_node_transformed)
# END test_Python2FutureTransformer_visit_Module