

# Generated at 2022-06-21 17:46:19.896628
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import TransformerPipeline
    from ..post_processors import ParentChildNodeLinker
    from ..utils.source_repr import SourceReprGen
    from typed_ast import ast3 as ast
    from typing import List, Union
    from astunparse import unparse
    module = ast.parse('import sys')
    pipeline = TransformerPipeline(Python2FutureTransformer, ParentChildNodeLinker, SourceReprGen)
    new_module = pipeline.transform(module)
    assert unparse(new_module) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport sys'



# Generated at 2022-06-21 17:46:22.629199
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-21 17:46:27.796084
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # data
    expected_module_body: List[Any] = (
        imports.get_body(future='__future__')
        + [ast.Expr(value=ast.Str(s='2.7'))]
    )
    # test procedure
    module_ = ast.parse('2.7')
    assert module_.body[0].value.s == '2.7'
    assert not hasattr(module_, '_tree_changed')
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed is False
    module_ = transformer.visit(module_)
    assert hasattr(module_, '_tree_changed')
    assert transformer.tree_changed is True
    assert module_.body[0].value.s == imports.__name__  # type: ignore
    assert type(module_.body)

# Generated at 2022-06-21 17:46:32.246147
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert (isinstance(trans, Python2FutureTransformer))
    assert (isinstance(trans, BaseNodeTransformer))
    assert (isinstance(trans.visit_Module(ast.Module()), ast.Module))

# Generated at 2022-06-21 17:46:34.309548
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-21 17:46:38.720402
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Example from
    # https://www.python.org/dev/peps/pep-3107/
    code = '''
    def f(a, (b, c), d):
        return a, b, c, d
    '''
    node = ast.parse(code, mode='exec')
    Python2FutureTransformer().visit(node)  # type: ignore

# Generated at 2022-06-21 17:46:47.043904
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from typed_ast.ast3 import parse as py3_parse
    from typed_ast.ast3 import Module, FunctionDef, Name, Load, Store, Assign, \
        Call, Str, Expr, Return, If, BoolOp, Or, Num, UnaryOp, Not, Attribute, \
        Subscript, Index, List, ClassDef, Continue, Pass, Break, For, While, \
        Tuple, BinOp, Add, Mult, Sub, Mod, Div, Pow, BitOr, BitAnd, BitXor, Invert, LShift, RShift, MatMult
    node = py3_parse('''
    def f(x):
        return x
    ''')

# Generated at 2022-06-21 17:46:54.577080
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    
    from typed_astunparse import unparse
    from flake8_py2 import checker
    from flake8_py2.visitor import Python2FutureTransformer
        
    node = ast.parse('print(2)')
    visitor = checker.get_visitor(Python2FutureTransformer(node=node))
    visitor.visit(node)
    
    print(unparse(node))


# Unit test

# Generated at 2022-06-21 17:46:58.758894
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent
    from ..transpile import transpile

    source = dedent("""
    def test():
        if a:
            pass
    """)

    assert transpile(source) == dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def test():
        if a:
            pass
    """)

# Generated at 2022-06-21 17:47:06.657060
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_astunparse import unparse
    source = """
from __future__ import annotations
from __future__ import braces

from future import unicode_literals
from future import print_function
from future import division
from future import absolute_import

print("This is a test")
"""
    expected = """
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import annotations
from __future__ import braces

from future import unicode_literals
from future import print_function
from future import division
from future import absolute_import

print("This is a test")
"""
    node = ast.parse(source)
    Python2FutureTransformer().visit(node)
    actual = unparse(node)
   

# Generated at 2022-06-21 17:47:15.373612
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test snippet
    assert imports == """
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
    """
    # Test class
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    
    
if __name__ == "__main__":
    pass

# Generated at 2022-06-21 17:47:26.497217
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import build_ast
    from ..utils.ast_compare import compare_asts
    from .base import BaseNodeTransformer
    from .base import GenericNodeTransformer

    source = """
    # comment
    '''comment'''
    a: int = 1
    assert a
    """
    expected = """
    # comment
    '''comment'''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a: int = 1
    assert a
    """
    module = build_ast(source, target=(2, 7))
    Python2FutureTransformer.apply(module)
    expected = build_ast(expected, target=(2, 7))
    compare_asts(expected, module)

    #

# Generated at 2022-06-21 17:47:33.136200
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import astor

    tree = astor.parse_file(__file__.replace('.pyc', '.py'))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    tree = transformer.tree
    assert str(tree) == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


import ast
import astor

"""

# Generated at 2022-06-21 17:47:38.487734
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = imports.get_code(future='__future__')
    import astor

    transformer = Python2FutureTransformer()
    tree = ast.parse(code)
    transformer.visit(tree)
    source_after_transformation = astor.to_source(tree)
    assert source_after_transformation == code

# Generated at 2022-06-21 17:47:41.611569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse("a = 1")
    transformer = Python2FutureTransformer(tree)
    transformer.visit(tree)



# Generated at 2022-06-21 17:47:46.398313
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = ''
    target = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
    '''
    sut = Python2FutureTransformer()
    root = ast.parse(source)
    sut.visit(root)
    assert ast.dump(root) == ast.dump(ast.parse(target))

# Generated at 2022-06-21 17:47:53.581497
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast, unittest
    from ast_toolbox.context import Context
    from ast_toolbox import ast2
    
    class Test(unittest.TestCase):
        def test(self):
            src = """
            def f():
                pass
            """

            x = ast2.parse(src)
            context = Context(target=(2, 7))
            x = Python2FutureTransformer(context).visit(x)
            tgt = ast.parse(imports.get_src(future='__future__') + src)
            self.assertEqual(ast.dump(x), ast.dump(tgt))

    Test().test()

# Generated at 2022-06-21 17:47:59.283603
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    src = """
    print('Hello World')
    """

    expected_dst = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    print('Hello World')
    """

    dst_ast = transform(src, Python2FutureTransformer)

    assert expected_dst == astor.to_source(dst_ast)

# Generated at 2022-06-21 17:48:06.989341
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .unittest_tools import assert_conversion, create_node

    # Given
    node = create_node(
"""class Test(object):
    def __init__(self):
        pass
"""
    )

    # When
    result = Python2FutureTransformer().visit(node)

    # Then

# Generated at 2022-06-21 17:48:08.917135
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    print(type(x))
    assert x is not None

# Generated at 2022-06-21 17:48:13.526670
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2futuretransformer = Python2FutureTransformer()
    assert (python2futuretransformer.target == (2, 7))

# Generated at 2022-06-21 17:48:19.892071
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_all_nodes, get_test_data
    from .utils import assert_tree
    from .test_base import BaseNodeTest

    class Test(BaseNodeTest):
        target = (2, 7)
        transformer = Python2FutureTransformer

    test_file_name = get_test_data('future.2to3.py')
    tree = run_all_nodes(test_file_name, only=[Test])
    assert_tree(tree, test_file_name + '.result')

# Generated at 2022-06-21 17:48:20.885647
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:48:25.749539
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'print("Hello, world!")'
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print("Hello, world!")
    '''
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    result = ast.unparse(tree).strip()
    expected = expected.strip()
    assert result == expected

# Generated at 2022-06-21 17:48:27.264178
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None


# Generated at 2022-06-21 17:48:29.933019
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_name = 'Python2FutureTransformer'
    target = (2, 7)

    obj = Python2FutureTransformer(target=target)
    assert obj.target == target



# Generated at 2022-06-21 17:48:32.411973
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import typed_ast.ast3
    from better_torchscript.transformers import Python2FutureTransformer
    assert Python2FutureTransformer(None)

# Generated at 2022-06-21 17:48:38.812076
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from six.moves import range"""
    assert Python2FutureTransformer._target == (2, 7)  # type: ignore
    tree = ast.parse(expected + '\nfor _ in range(10): pass')
    tree = Python2FutureTransformer().visit(tree)  # type: ignore
    assert ast.unparse(tree) == expected + '\nfor _ in range(10):\n    pass'



# Generated at 2022-06-21 17:48:43.471824
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .helper import run_test_node
    from ..utils.code_gen import to_source
    from ..utils import Parser

    code = '''def x(): return 1'''

# Generated at 2022-06-21 17:48:49.783920
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.generic_visit = self.generic_visit_sig.__get__(self, NodeVisitor)  # type: ignore

        def generic_visit_sig(self, node):
            node.body[1].value.value.args[0].n.v += 1
            return self.generic_visit(node)


# Generated at 2022-06-21 17:48:54.933451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future_transformer = Python2FutureTransformer()
    assert future_transformer.target == (2, 7)


# Generated at 2022-06-21 17:48:59.629092
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from ..typed_ast_visitor import TastyASTTransformer
    from .base import BaseNodeTransformer
    from .Python2FutureTransformer import Python2FutureTransformer

    class Mock(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node.body += [ast.Expr(ast.Str("body"))]
            return node

        def visit(self, node: ast.AST) -> ast.AST:
            self.generic_visit(node)
            return node

    node = ast.parse("""\
r = 2
c = 2
""")
    x = Python2FutureTransformer()
    m = Mock()
   

# Generated at 2022-06-21 17:49:03.407145
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    i_node = compile(r'a = 1', '<string>', 'single').body[0]
    t = Python2FutureTransformer()
    assert isinstance(t.visit_Module(i_node), ast.Module)  # type: ignore

# Generated at 2022-06-21 17:49:08.744160
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("a = 'unicode_literals'")
    transform = Python2FutureTransformer()

    actual = transform.visit(node)

# Generated at 2022-06-21 17:49:20.357701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Simple test for trivial case
    tree = ast.parse('# nothing here')
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == '<_ast.Module object at 0x7fd4040f7c10>'

    # Test for adding import statements
    tree = ast.parse('"""A docstring"""\nimport foo')
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-21 17:49:21.239352
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-21 17:49:25.523762
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import round_trip
    a = """import math
    def func():
        pass"""
    b = """from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import math
    def func():
        pass"""
    assert round_trip(a, 2, Python2FutureTransformer) == b

# Generated at 2022-06-21 17:49:36.534476
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .fixtures import load_node
    from ..utils.code_gen import to_source
    from ..transpile import Transpiler
    
    # Load fixtures
    node = load_node('dummy.py')
    # Create a transpiler with the Python2FutureTransformer
    p2t = Transpiler(transformers=[Python2FutureTransformer()])
    p2t.target = (2, 7)
    # Transpile the AST
    p2t.transpile_tree(node)
    # Test transformed code
    source = to_source(node)

# Generated at 2022-06-21 17:49:47.370874
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as std_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast.transforms.decorator_fixer import DecoratorFixer
    from typed_ast import CodeSnippet
    from ast_fixer.transforms.python2_future import Python2FutureTransformer
    snippet = """
    def foo():
        pass
    """
    tree = std_ast.parse(snippet)
    tree = DecoratorFixer().visit(tree)
    tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-21 17:49:54.482949
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    expected = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "1 + 1\n")
    expected.body.insert(0, ast.ImportFrom(module='__future__', names=[ast.alias(name='absolute_import', asname=None)], level=0))
    expected.body.insert(1, ast.ImportFrom(module='__future__', names=[ast.alias(name='division', asname=None)], level=0))

# Generated at 2022-06-21 17:50:08.261696
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    
    code = """
        print("Hello, world!")
    """
    res = roundtrip(code, Python2FutureTransformer)
    assert res == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print("Hello, world!")
    """.lstrip()

# Generated at 2022-06-21 17:50:11.717406
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    transformer = Python2FutureTransformer()
    # When
    node = transformer.visit(ast.parse(''))
    # Then
    assert node.body == imports.get_body(future='__future__')

# Generated at 2022-06-21 17:50:15.776113
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast.ast3 import fix_missing_locations
    node = ast.parse('a=1\nb=2', mode='exec')
    node = fix_missin

# Generated at 2022-06-21 17:50:18.248682
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import TransformerPipeline
    import astor

    pipeline = TransformerPipeline([
        Python2FutureTransformer
    ])


# Generated at 2022-06-21 17:50:23.437613
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = "__future__"
    actual = Python2FutureTransformer().visit(ast.parse(''))
    assert imports.get_body(future).startswith(f'from {future} import absolute_import')
    assert imports.get_body(future).endswith(f'from {future} import unicode_literals')
    assert actual == imports.get_tree(future=future)

# Generated at 2022-06-21 17:50:26.848282
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): 
    module = ast.parse('def foo():\n    print("hello")') 
    print(ast.dump(module)) 
    Python2FutureTransformer().visit(module)
    print(ast.dump(module)) 



# Generated at 2022-06-21 17:50:29.885956
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.Module(
        body=[
            ast.ImportFrom(module='stdlib', names=[ast.alias(name='foo', asname='foo')], level=0)
        ]
    )
    testing_visit(node, Python2FutureTransformer)

# Generated at 2022-06-21 17:50:39.301070
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..nodes import Module, Stmt
    from ..source import Source
    from ..utils import dump
    source = u'print(absolute_import)\nprint(division)\n'
    tree = Module([Stmt(source)])
    assert dump(tree) == dump(Module([Stmt(source)]))
    mt = Python2FutureTransformer(Python2FutureTransformer.target)
    mt.visit(tree)
    assert dump(mt.tree) == dump(Module(imports.get_body(future='__future__') + [Stmt(source)]))
    assert mt.tree is not tree
    assert mt.tree == Module(imports.get_body(future='__future__') + [Stmt(source)])

# Generated at 2022-06-21 17:50:40.385512
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-21 17:50:45.422257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_code, get_ast, get_source
    from .base import BaseNodeTransformer
    
    source_code = source_to_code(imports)
    tree = get_ast(source_code)
    
    python2_future_transformer = Python2FutureTransformer()
    tree = python2_future_transformer.visit(tree)
    
    assert get_source(tree).strip() == source_code.strip()

# Generated at 2022-06-21 17:51:05.687905
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("import sys")
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert isinstance(module.body[0], ast.ImportFrom)
    assert module.body[0].module == "future"
    assert isinstance(module.body[1], ast.Import)
    assert module.body[1].names[0].name == "sys"



# Generated at 2022-06-21 17:51:11.316561
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse("#!python3\n# -*- coding: utf-8 -*-\nfoo = 'bar'")
    assert module_node.body == [ast.ImportFrom(module='__future__',
                                               names=[ast.alias(name='absolute_import', asname=None),
                                                      ast.alias(name='division', asname=None),
                                                      ast.alias(name='print_function', asname=None),
                                                      ast.alias(name='unicode_literals', asname=None)],
                                               level=0),
                                ast.Expr(value=ast.Str(s='bar')),
                                ast.Expr(value=ast.Str(s='bar'))]
    # end assert

# Generated at 2022-06-21 17:51:14.248250
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast import assert_source

# Generated at 2022-06-21 17:51:16.103979
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-21 17:51:20.573179
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    input_node = ast.parse("def f():\n  return 1")

# Generated at 2022-06-21 17:51:22.245903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = ast.parse('pass')
    res = Python2FutureTransformer().visit(node)
    expected = astor.to_source(ast.parse(imports.get())).strip() + '\npass'
    assert astor.to_source(res).strip() == expected

# Generated at 2022-06-21 17:51:23.419424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from .base import BaseNodeTransformer
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)


# Generated at 2022-06-21 17:51:25.478323
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    t = Python2FutureTransformer()
    #t.visit_Module(None)

# Generated at 2022-06-21 17:51:26.664536
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:51:36.914292
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method `visit_Module` of class `Python2FutureTransformer`."""
    tree = ast.parse("""
    # This program adds two numbers
    a = 5
    b = 10
    print(a+b)
    """)
    expected_tree = ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    # This program adds two numbers
    a = 5
    b = 10
    print(a+b)
    """)
    Python2FutureTransformer().visit(tree)
    ast.fix_missing_locations(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 17:52:13.013822
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    instance = Python2FutureTransformer()
    node = ast.parse('''a = 1
b = 2
''')

    # Act
    result = instance.visit(node)

    # Assert
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert isinstance(result.body[1], ast.ImportFrom)
    assert isinstance(result.body[2], ast.ImportFrom)
    assert isinstance(result.body[3], ast.ImportFrom)
    assert isinstance(result.body[4], ast.Assign)
    assert isinstance(result.body[5], ast.Assign)

# Generated at 2022-06-21 17:52:22.133492
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import unittest
    from typed_ast import ast3 as ast

    class Test(unittest.TestCase):
        def test_basic(self):
            node = ast.parse("print(1)")
            t = Python2FutureTransformer()
            t.visit(node)

# Generated at 2022-06-21 17:52:23.959355
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer."""
    Python2FutureTransformer()

# Generated at 2022-06-21 17:52:25.152257
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:52:31.848179
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    from ..utils.source import ast2source

    source = 'x = "foo"'

    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = "foo"
"""

    tree = source2ast(source)
    Python2FutureTransformer().visit(tree)
    actual = ast2source(tree)

    assert actual == expected

# Generated at 2022-06-21 17:52:42.577601
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    module_node = ast.parse(dedent('''\
        def factorial(n):
            if n < 1:
                return 1
            else:
                return n * factorial(n-1)
        '''))
    python2_future_transformer = Python2FutureTransformer()
    python2_future_transformer.visit(module_node)
    python_code = astor.to_source(module_node)

# Generated at 2022-06-21 17:52:51.980099
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from webweb.imports import python2futuretransformer
    from webweb.imports.future import __future__

    # Create two modules: one to edit, another to compare the result to
    original = ast.parse(python2futuretransformer)
    original = ast.Module([
        ast.Import(names=[ast.alias(name='typed_ast', asname=None)]),
        ast.Import(names=[ast.alias(name='ast3', asname='ast')]),
        ast.Import(names=[ast.alias(name='snippet', asname=None)]),
        ast.ImportFrom(
            module='base',
            names=[ast.alias(name='BaseNodeTransformer', asname=None)],
            level=0,
        )
    ])
    expected = ast.parse(python2futuretransformer)


# Generated at 2022-06-21 17:52:53.166239
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:52:54.259204
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:53:05.583867
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:54:19.774581
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('print("Hello")')
    mod = Python2FutureTransformer().visit(module)
    assert mod is not None
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint("Hello")\n'
    assert astor.to_source(mod) == expected
    assert mod is not None  # Checks if transformation returned a module

# Generated at 2022-06-21 17:54:21.048911
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None)


# Generated at 2022-06-21 17:54:24.301588
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    source = """
        def f():
            return 0
    """
    t = Python2FutureTransformer()
    tt = t.transform_module(source)
    assert tt.strip() == "\n".join(imports.get_body(future='__future__')) + "\n" + source

# Generated at 2022-06-21 17:54:25.014745
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:54:35.324714
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.helper import type_comment
    from .helper import ast_equal, roundtrip

    def check(s):
        node = ast.parse(s)
        node = Python2FutureTransformer().visit(node)
        ast_equal(node, parse(type_comment(s)))

    def roundtrip_check(s):
        s_ = roundtrip(s)
        print(s_)
        node = ast.parse(s_)
        node = Python2FutureTransformer().visit(node)
        ast_equal(node, parse(type_comment(s)))

    check('1/2')
    check('1/2 + 1')
    check('print(1, 2)')

# Generated at 2022-06-21 17:54:36.284125
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None

# Generated at 2022-06-21 17:54:38.267137
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("pass")
    result = Python2FutureTransformer().visit(tree)
    assert isinstance(result, ast.Module)

# Generated at 2022-06-21 17:54:43.007548
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import util
    result = util.run_with_string(
        string = """
        # A one liner
        print "Hello"
        """,
        transformer = Python2FutureTransformer)
    assert result == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

# A one liner
print "Hello"
""".lstrip()

# Generated at 2022-06-21 17:54:49.850615
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Arg, FunctionDef, Str, Module, parse
    from mypy import api

    module = Module(
        body=[
            FunctionDef(
                name='get_results',
                args=Arg(arg='self', annotation=None),
                body=[],
                decorator_list=[],
                returns=None,
            ),
            FunctionDef(
                name='get_results',
                args=Arg(arg='self', annotation=None),
                body=[],
                decorator_list=[],
                returns=None,
            ),
        ]
    )
    trans_module = Python2FutureTransformer().visit(module)
    module = parse(ast.unparse(trans_module))

# Generated at 2022-06-21 17:54:58.836486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    src = """
    # -*- coding: utf-8 -*-
    print('Hello, world')
    """

    tree = ast.parse(src)
    Python2FutureTransformer().visit(tree)