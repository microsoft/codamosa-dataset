

# Generated at 2022-06-21 17:46:10.173150
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:46:15.692115
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_name = 'Python2FutureTransformer'
    class_obj = eval(class_name)
    assert class_obj.__name__ == class_name
    instance_obj = class_obj()
    assert isinstance(instance_obj, ast.NodeTransformer)
    assert not instance_obj._tree_changed
    assert instance_obj.target == (2, 7)

# Generated at 2022-06-21 17:46:22.362912
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    mt = Python2FutureTransformer()
    m = ast.parse("")
    mt.visit(m)
    assert str(m) == \
        "from __future__ import absolute_import\n" +\
        "from __future__ import division\n" +\
        "from __future__ import print_function\n" +\
        "from __future__ import unicode_literals"

# Generated at 2022-06-21 17:46:24.274648
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed is False



# Generated at 2022-06-21 17:46:34.281666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    import textwrap

    class Test(BaseNodeTransformerTestCase):
        def test_Python2FutureTransformer_visit_Module(self):
            transformer = Python2FutureTransformer()
            node = ast.parse(
                textwrap.dedent(
                    r"""
                    def test_function():
                        pass

                    """
                )
            )
            node = transformer.visit(node)

# Generated at 2022-06-21 17:46:35.259513
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-21 17:46:36.624621
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(2, 7)
    
    

# Generated at 2022-06-21 17:46:41.709978
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import uast
    from ..utils import get_python_file_parser

    code = '''
    print(2)
    '''

    res = get_python_file_parser().parse_snippet(code)
    if (res is None):
        return

    uast._walk(res, Python2FutureTransformer())
    assert res.future == '__future__'



# Generated at 2022-06-21 17:46:51.262474
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from .base import BaseNodeTest
    class Test(BaseNodeTest):
        target = Python2FutureTransformer.target
        transformer = Python2FutureTransformer
        module_body = [
            ast3.Expr(value=ast3.Name(id='foo', ctx=ast3.Load()), lineno=1, col_offset=12),
        ]
        def test_basic(self):
            new_body = imports.get_body(future='__future__') + self.module_body
            self.check()  # type: ignore

    # test_basic
    module_body = [
        ast3.Expr(ast3.Name('foo', ast3.Load()), lineno=1, col_offset=12),
    ]

# Generated at 2022-06-21 17:47:00.249411
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
x = "I'm an ascii string"
y = u"I'm a unicode string"
    ''')
    tsf = Python2FutureTransformer()
    node = tsf.visit(node)
    assert str(node) == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = "I'm an ascii string"
y = u"I'm a unicode string"
    '''



# Generated at 2022-06-21 17:47:06.924634
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    future = '__future__'
    expected = """
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
    pass
    """
    source = "pass"
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    actual = astor.to_source(new_tree)
    assert actual == expected



# Generated at 2022-06-21 17:47:11.863217
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py3tree = ast.parse('print(3)')
    with pytest.raises(AttributeError):
        assert py3tree.body[0].__dict__.get('filename') is None
    t = Python2FutureTransformer()
    t(py3tree)
    assert py3tree.body[0].__dict__.get('filename') == 'from future import absolute_import'

# Generated at 2022-06-21 17:47:13.528816
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:47:15.214452
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor


# Generated at 2022-06-21 17:47:19.728806
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('a = 1')
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    code = compile(tree, '', mode='exec')
    names = {}
    exec(code, {}, names)
    assert names['a'] == 1

# Generated at 2022-06-21 17:47:31.049160
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    node = ast.parse("""
    print('Hello, World!')
    """)

    # Exercise
    node = Python2FutureTransformer().visit(node)

    # Verify

# Generated at 2022-06-21 17:47:32.715051
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()  # should not raise

# Generated at 2022-06-21 17:47:43.257292
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..test_utils import transform, assert_parses
    from .base import to_source

    source = '''
from __future__ import unicode_literals
from __future__ import print_function
'''
    code = compile(source, '<string>', 'exec')
    tree = ast.parse(code)
    node = tree.body[0]
    assert isinstance(node, ast.ImportFrom)
    assert_parses("from future import unicode_literals")
    assert_parses("from future import print_function")
    new_tree = transform(tree, (Python2FutureTransformer, ))
    assert to_source(new_tree) == to_source(tree)

# Generated at 2022-06-21 17:47:52.238795
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '''
    a = True
    b = 2
    print("Hello, World")
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a = True
    b = 2
    print("Hello, World")
    '''
    tree = ast.parse(source)
    expected_tree = ast.parse(expected)
    transformer = Python2FutureTransformer()
    actual_tree = transformer.visit(tree)
    assert ast.dump(expected_tree) == ast.dump(actual_tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-21 17:47:57.511033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .transformer_test_case import TransformerTestCase
    from typed_ast import ast3 as ast
    import sys
    import os
    
    class TestTransformer(TransformerTestCase):
        module = os.path.dirname(__file__) + '/../fixtures/test_module.py'
        target_version = (2, 7)
        transformer = Python2Futu

# Generated at 2022-06-21 17:48:01.005584
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:48:08.518836
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from astor import code_gen
    from . import snippet

    source = snippet.python2_example
    future_transformer = Python2FutureTransformer()
    tree = future_transformer.transform(ast.parse(source))
    source = code_gen.to_source(tree)

    # print("###############################")
    # print("###### Python2FutureTransformer : Unit Test")
    # print("###############################")
    # print(source)


    expected = snippet.python2_future_example
    assert expected == source, "Should match"



# Generated at 2022-06-21 17:48:16.979833
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    code = """
x = 1
y = 2
z = x + y
print(z)
    """
    tree = parse(code, mode='exec')
    Python2FutureTransformer().visit(tree)
    assert tree == parse(expect_code, mode='exec')

expect_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1
y = 2
z = x + y
print(z)
"""

# Generated at 2022-06-21 17:48:23.882366
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = 'def f(): pass\n'
    expected = (
        '''from __future__ import absolute_import\n''' + 
        '''from __future__ import division\n''' + 
        '''from __future__ import print_function\n''' + 
        '''from __future__ import unicode_literals\n''' + 
        '''def f(): pass\n'''
    )
    tree = ast.parse(input)
    visitor = Python2FutureTransformer()
    visitor.visit(tree)
    assert visitor._tree_changed is True
    output = astor.to_source(tree).strip()
    assert output == expected

# Generated at 2022-06-21 17:48:34.739216
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:48:44.497163
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    transformer = Python2FutureTransformer(target=(2, 6))
    module = ast.parse('''
        from __future__ import with_statement
        
        def foo():
            print('Hello, world!')
        
        def bar():
            pass
    ''')

    # When
    module = transformer.visit(module)  # type: ignore

    # Then
    assert transformer._tree_changed  # type: ignore
    assert transformer.target == (2, 6)

# Generated at 2022-06-21 17:48:50.628826
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def code():
        pass

    tree = code.get_ast(future='__future__')  # type: ignore
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)  # type: ignore

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 4
    assert tree  # to satisfy mypy


"""DisabledContent
"""

# Generated at 2022-06-21 17:48:51.195562
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:48:59.001638
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from . import Tree
    from . import create_ast

    mod = create_ast("""
    # comment
    import pkg
    """)

    tr = Python2FutureTransformer()
    mod = tr.visit(mod)
    assert type(mod) is ast.Module
    tree = Tree(mod)
    assert tree.get_root_node() == 'Module'
    assert tree.get_children(0) == [
        'ImportFrom',
        'ImportFrom',
        'ImportFrom',
        'ImportFrom',
        'Import',
        'Expr',
        'Module']
    assert tr.get_tree_changed() is True


# Generated at 2022-06-21 17:49:07.587452
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..emit import emit
    from ..parse import parse

    source = '''
    import os
    '''
    expected_source = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import os
    '''
    tree = parse(source)  # type: ignore
    assert tree.body[0].names[0].name == 'os'
    tree = Python2FutureTransformer().visit(tree)  # type: ignore

    source = emit(tree)
    assert source == expected_source

# Generated at 2022-06-21 17:49:14.523343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def validate(code: str) -> None:
        code = deindent.dedent(code.strip())
        t = Python2FutureTransformer()
        module = ast.parse(code)
        t.visit(module)
        assert str(module) == imports.get_body(future='__future__') + code

    validate('''
        a = 1
    ''')

    validate('''
        import b
        c = 1
    ''')

# Generated at 2022-06-21 17:49:23.852471
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, Expr
    from ast import Str
    #
    class State:
        tree_changed = False

    #
    file_path = './tests/cases/methods/unittest_Python2FutureTransformer_visit_Module.py'
    tree = Module([Expr(Str('import ast'))])

    #
    Python2FutureTransformer._tree_changed = False
    Python2FutureTransformer.visit(tree)
    State.tree_changed = Python2FutureTransformer._tree_changed
    assert State.tree_changed == True

# Generated at 2022-06-21 17:49:27.754703
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("")
    node = transformer.visit(node)
    assert transformer._tree_changed
    assert transformer.target == (2, 7)

    imports.reset()

# Generated at 2022-06-21 17:49:35.677919
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    source = """
print('hello world!')
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('hello world!')
"""
    node = ast.parse(source)
    transformer = Python2FutureTransformer()  # Act

    # Assert
    actual = transformer.visit(node)
    assert transformer._tree_changed == True
    assert ast.dump(actual) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:49:38.282154
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_fixture
    Python2FutureTransformer(make_dummy_fixture())

# Generated at 2022-06-21 17:49:46.952179
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import misc

    t = Python2FutureTransformer()
    node = ast.Module(body=[])
    node = t.visit(node)
    assert len(node.body) == 4
    for n in node.body:
        assert isinstance(n, ast.ImportFrom)
        assert n.level == 0
        assert n.module == 'future'
        assert n.names[0][0] == n.names[0][1]
        assert n.names[0][1] in {'absolute_import', 'division', 'print_function', 'unicode_literals'}

# Generated at 2022-06-21 17:49:47.789426
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-21 17:49:54.920700
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    from .base import PythonCode
    from .fixed_point import FixedPointNodeTransformer

    transformer = FixedPointNodeTransformer(Python2FutureTransformer)
    code = PythonCode('value = 10')

    # Act
    result = transformer.transform(code)

    # Assert
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nvalue = 10'
    assert result.code == expected

# Generated at 2022-06-21 17:49:55.967462
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-21 17:49:57.515759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("pass")
    Python2FutureTransformer(tree)

# Generated at 2022-06-21 17:50:03.814365
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert(isinstance(t, BaseNodeTransformer))
    assert(t.target == (2, 7))



# Generated at 2022-06-21 17:50:12.596683
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('def f(): return 1/2')
    Python2FutureTransformer(2, 7).visit(node)

# Generated at 2022-06-21 17:50:19.201818
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_statement = ast.ImportFrom('__future__', [ast.alias('absolute_import', None),
                                                     ast.alias('division', None),
                                                     ast.alias('print_function', None),
                                                     ast.alias('unicode_literals', None)],
                                      level=0)

    module = ast.Module([import_statement], type_ignores=[])
    assert Python2FutureTransformer(module) == module

# Generated at 2022-06-21 17:50:21.542031
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a = ast.parse("pass")
    b = Python2FutureTransformer(a)
    assert b.tree_changed is True

# Generated at 2022-06-21 17:50:29.084868
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os
    import unittest
    from io import StringIO
    from unittest.mock import patch

    from typed_ast import ast3 as ast
    from typed_astunparse import unparse

    from transpyle.general import Python2FutureTransformer

    class TestPython2FutureTransformer(unittest.TestCase):
        maxDiff = None

        def setUp(self):
            self.stdout = sys.stdout
            self.tokenize = ast.tokenize
            self.parse = ast.parse

        def tearDown(self):
            sys.stdout = self.stdout
            ast.tokenize = self.tokenize
            ast.parse = self.parse

        def test_simple(self):
            code = 'import sys'

# Generated at 2022-06-21 17:50:35.123766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert_equal(Python2FutureTransformer().visit(ast.parse('1')),
                 ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
1
'''))

# Generated at 2022-06-21 17:50:36.456685
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:50:40.466756
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("print('Hello, world')")
    Python2FutureTransformer().visit(module)
    assert module.body[0] == imports.get_body(future='__future__')[0]  # type: ignore

# Generated at 2022-06-21 17:50:44.617283
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse(
        """
        def f():
            pass
        """
    )
    transformer.visit(node)
    expected = ast.parse(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def f():
            pass
        """
    )
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:50:50.078518
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    Test if Python2FutureTransformer writes the correct imports to the code.
    """
    fut = Python2FutureTransformer()
    code = "print('Hello world')"
    tree = ast.parse(code)
    fut.visit(tree)
    assert fut.get_source() == \
           "from __future__ import absolute_import\n" + \
           "from __future__ import division\n" + \
           "from __future__ import print_function\n" + \
           "from __future__ import unicode_literals\n" + \
           "print('Hello world')"

# Generated at 2022-06-21 17:51:06.495817
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from matchpy import Pattern

    from typed_ast import ast3

    p = Python2FutureTransformer()
    source = "def foo():\n pass"
    tree = ast3.parse(source, mode="exec")
    p.visit(tree)
    assert isinstance(tree, ast3.Module)
    assert hasattr(tree, 'body')
    assert isinstance(tree.body[0], ast3.ImportFrom)
    assert tree.body[0].module == 'future'
    assert tree.body[0].names[0].name == 'absolute_import'  # type: ignore
    assert tree.body[0].names[0].asname is None  # type: ignore
    assert tree.body[1].names[0].name == 'division'  # type: ignore

# Generated at 2022-06-21 17:51:07.787227
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:51:14.417915
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''if __name__ == "__main__":
        print("Hello world!")'''
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

if __name__ == "__main__":
    print("Hello world!")'''
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    new_code = astor.to_source(tree)
    assert new_code == expected

# Generated at 2022-06-21 17:51:18.883040
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    node = ast.Module(body=[])
    result = transformer.visit(node)
    assert isinstance(result, ast.Module)
    assert len(result.body) == 4

# Generated at 2022-06-21 17:51:19.819428
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:51:21.308939
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:27.128583
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    tt = ast.parse('a = 2')
    tt = Python2FutureTransformer().visit(tt)
    assert isinstance(tt, ast.Module)
    assert len(tt.body) == 4
    assert isinstance(tt.body[0], ast.ImportFrom)
    assert isinstance(tt.body[1], ast.ImportFrom)
    assert isinstance(tt.body[2], ast.ImportFrom)
    assert isinstance(tt.body[3], ast.ImportFrom)

# Generated at 2022-06-21 17:51:31.104549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert isinstance(trans._tree_changed, bool) and not trans._tree_changed
    assert isinstance(trans.target, tuple) and trans.target[0] == 2 and trans.target[1] == 7
    assert isinstance(trans.visit_Module, types.MethodType)

# Generated at 2022-06-21 17:51:39.119303
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_transformer_on_string
    import ast
    import astor
    stmts = '''4/2
4//2
'''
    expected_transformed = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

1
2
'''
    actual_transformed = run_transformer_on_string(
        Python2FutureTransformer, stmts)
    assert astor.to_source(ast.parse(expected_transformed)) == actual_transformed

# Generated at 2022-06-21 17:51:41.625653
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(2, 7)
    assert t is not None

# Generated at 2022-06-21 17:52:03.022013
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("1 + 1")
    transformer.visit(node)
    source = transformer.get_source()
    assert source == ("from __future__ import absolute_import\n"
                      "from __future__ import division\n"
                      "from __future__ import print_function\n"
                      "from __future__ import unicode_literals\n"
                      "\n"
                      "1 + 1")



# Generated at 2022-06-21 17:52:11.378475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    result = transformer.visit(
        ast.parse('''
        import sys
        import os
        import random
        ''')
    )
    # Module(body=[Import(names=[alias(name='sys', asname=None)]), Import(names=[alias(name='os', asname=None)]), Import(names=[alias(name='random', asname=None)])])
    assert isinstance(result.body[0], ast.Import)
    assert isinstance(result.body[1], ast.Import)
    assert isinstance(result.body[2], ast.Import)
    assert isinstance(result.body[3], ast.ImportFrom)
    assert isinstance(result.body[4], ast.ImportFrom)

# Generated at 2022-06-21 17:52:21.726865
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    p = Python2FutureTransformer()
    assert isinstance(p, Python2FutureTransformer)

    node = ast.parse(
        "try:\n"
        "    print('hello')\n"
        "except Exception as e:\n"
        "    print('world')\n"
        "else:\n"
        "    print('!')\n",
        mode="exec"
    )
    assert isinstance(node, ast.Module)
    p.visit(node)

    assert isinstance(node, ast.Module)

    import astor
    result = astor.to_source(node)
    lines = result.strip().split('\n')
    assert lines[0] == "from __future__ import absolute_import"
    assert lines[1] == "from __future__ import division"
    assert lines

# Generated at 2022-06-21 17:52:28.251784
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .. import transform
    import sys
    module_def = ast.Module()
    module_def.body = [ast.Print(dest=None,values=[ast.Str(s=str('Hello world!'))],nl=True)]
    transformer = Python2FutureTransformer()
    transformer.visit(module_def)
    transform(module_def,transformer,stage=0)
    print(ast.dump(module_def))

# Generated at 2022-06-21 17:52:29.213525
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-21 17:52:35.064270
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  p2f = Python2FutureTransformer()
  assert p2f.target == (2, 7)
  assert p2f._tree_changed == False
  assert p2f.visit_Module(ast.parse('pass')) == ast.Module(body=[ast.ImportFrom(module='__future__', 
                                                                              names=[ast.alias(name='absolute_import', asname=None), 
                                                                                     ast.alias(name='division', asname=None), 
                                                                                     ast.alias(name='print_function', asname=None), 
                                                                                     ast.alias(name='unicode_literals', asname=None)], 
                                                                              level=0)])

# Generated at 2022-06-21 17:52:37.879769
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test docstring."""
    m = ast.parse('print("Hello")')
    m_trans = Python2FutureTransformer().visit(m)
    imports.assert_equals(m_trans)

# Generated at 2022-06-21 17:52:41.594945
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module, parse
    from .test_backport_future import sample_code

    module = parse(sample_code)
    transformer = Python2FutureTransformer()
    result = transformer.visit_Module(module)
    assert result.__class__.__name__ == 'Module'

# Generated at 2022-06-21 17:52:49.166417
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixture
    from ..utils.source import source

    # Given
    transformer: Python2FutureTransformer = Python2FutureTransformer()
    source_ast: ast.AST = make_fixture('Python2FutureTransformer_visit_Module', source)

    expected_result: ast.Module = make_fixture('Python2FutureTransformer_visit_Module', source)

    # When
    result: ast.Module = transformer.visit_Module(source_ast)  # type: ignore

    # Then
    assert result == expected_result

# Generated at 2022-06-21 17:52:59.809976
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..composite import CompositeNodeTransformer
    from ..remove_comments import RemoveCommentsTransformer
    from ..remove_docstrings import RemoveDocstringsTransformer
    from ..remove_unused_variables import RemoveUnusedVariablesTransformer
    from ..test.test_utils import assert_equal_ast
    ast_tree = ast.parse(dedent('''
    def __init__(self, *args, **kwargs):
        super(Foo, self).__init__(*args, **kwargs)
        data = json.load(open('file'))
    '''))

# Generated at 2022-06-21 17:53:37.341042
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    n = ast.parse('import math')
    print(astor.to_source(n))
    n = t.visit(n)
    print(astor.to_source(n))

# Generated at 2022-06-21 17:53:38.461424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-21 17:53:42.880175
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None).tree_changed == False
    assert Python2FutureTransformer(None, None).target == (2, 7)


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)
    #doctest: +ELLIPSIS
    #doctest: +NORMALIZE_WHITESPACE
    #doctest: +IGNORE_EXCEPTION_DETAIL
    #Traceback (most recent call last):

# Generated at 2022-06-21 17:53:49.953962
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast

    mod = ast.parse("""
l = 1
""")
    mod = Python2FutureTransformer().visit(mod)
    print(astor.dump_tree(mod))

    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


l = 1
"""

    assert astor.dump_tree(mod) == expected

# Generated at 2022-06-21 17:53:56.539126
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..visitor import to_source
    from ..utils.snippet import _snippet_repr
    from ..utils.ast import parse
    from . import check, run_transformer

    # Unit test for method `visit_Module`
    transformer = run_transformer(Python2FutureTransformer)

    # DONE: Test with an empty module
    # ast.Module(body=[])

# Generated at 2022-06-21 17:54:02.167755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_snippet

    source = make_snippet(
        """def f():
            pass
        """
    )
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed == True

# Generated at 2022-06-21 17:54:04.866740
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    # Act
    obj = Python2FutureTransformer()
    # Assert
    assert obj is not None


# Generated at 2022-06-21 17:54:11.275020
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_nodes
    from ..utils.visitor import dump_AST
    from ..utils.source import source2ast

    mod = make_dummy_nodes.test_module4()
    dump_AST(mod, msg='---- Original tree:')

    transformer = Python2FutureTransformer()
    mod = transformer.visit(mod)
    dump_AST(mod, msg='---- Transformed tree:')

    src = source2ast.ast2source(mod).strip()

# Generated at 2022-06-21 17:54:13.273490
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    trans.transform('')

# Generated at 2022-06-21 17:54:23.441178
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List
    from typed_ast import ast3 as ast

    # Given
    module = ast.parse('''
    a = 5
    b = 6
    ''')
    # When
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    # Then
    assert transformer._tree_changed == True
    assert type(module) == ast.Module
    assert len(module.body) == 7
    assert type(module.body[0]) == ast.ImportFrom
    assert module.body[0].module == '__future__'
    assert module.body[0].names[0].name == 'absolute_import'
    assert module.body[0].names[0].asname == None
    assert type(module.body[1]) == ast.ImportFrom

# Generated at 2022-06-21 17:55:41.256606
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    @source: from __future__ import absolute_import
    """
    before = ast.parse("from __future__ import absolute_import")
    after = ast.parse("from __future__ import absolute_import")
    assert before != after
    transformer = Python2FutureTransformer([])
    actual = transformer.visit(before)
    assert before != actual
    assert after == actual



# Generated at 2022-06-21 17:55:42.204478
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None



# Generated at 2022-06-21 17:55:51.800109
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..test_files.module.test_module import one
    from ..utils import code
    from textwrap import dedent
    from ..utils.ast_factory import ast_from_json
    from ..utils.snippet import snippet
    from ..transformer import python2
    

# Generated at 2022-06-21 17:56:02.465411
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.py2_source_to_ast import py2_source_to_ast
    from ..utils.py2_ast_to_source import py2_ast_to_source
    from .base import BaseNodeTransformer
    source1=("""
from __future__ import unicode_literals
from __future__ import print_function
""")
    source2=("""
from __future__ import print_function
from __future__ import unicode_literals
""")
    source3=("""
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import division
from __future__ import absolute_import
""")

# Generated at 2022-06-21 17:56:06.259865
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('2 + 2')
    module_ = transformer.visit(module)
    code = compile(module_, '', 'exec')
    exec(code)


# Generated at 2022-06-21 17:56:08.627272
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tf = Python2FutureTransformer(None)
    assert tf.target == (2, 7)