

# Generated at 2022-06-21 17:46:08.512038
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(target=(2, 7))
    assert isinstance(t, BaseNodeTransformer)
    assert t.target == (2, 7)


# Generated at 2022-06-21 17:46:11.668917
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Checks that modulo and future imports are added to beginning of file."""
    import astor

    from py2to3.main import transform_file
    from py2to3.tests.test_transformer import TEMP_PY2

    transform_file(TEMP_PY2)
    with open(TEMP_PY2, 'r') as f:
        text = f.read()

 

# Generated at 2022-06-21 17:46:20.093425
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..parser import Parser
    pt = Parser()

    # The tree representation of the following code:
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    # def test_function():
    #     pass
    #
    # from __future__ import print_function
    # from __future__ import unicode_literals
    # from __future__ import absolute_import
    # from __future__ import division
    # some_code()
    #
    # from __future__ import print_function, unicode_literals, absolute_import, division
    # anything()

# Generated at 2022-06-21 17:46:22.422647
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(None)

# Generated at 2022-06-21 17:46:24.317520
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:46:27.732610
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.node_utils import node_from_text
    from ..utils.ast_utils import parse_to_ast


# Generated at 2022-06-21 17:46:32.942641
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_tree
    from ..utils.visitor import compare_transformer

    tree = make_dummy_future_tree()
    transformer = Python2FutureTransformer()
    compare_transformer(transformer, tree, expected_tree=tree)
# Unit test end

# Generated at 2022-06-21 17:46:36.517501
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = astor.parse_file('./tests/code/python2_code.py')
    transformer = Python2FutureTransformer()
    ast.fix_missing_locations(transformer.visit(node))
    print(astor.to_source(node))

# Generated at 2022-06-21 17:46:43.587363
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    tree = ast.parse('pass')
    tree_new = Python2FutureTransformer().visit(tree)
    import _ast
    assert isinstance(tree_new, ast.Module) and len(list(ast.walk(tree_new))) == 2, \
        'One node of AST must be added to the tree'
    assert tree_new._fields == tree._fields, \
        'Node must not be changed, only added'
    assert isinstance(tree_new.body[1], ast.Pass), \
        'The second node of the AST must be an instace of ast.Pass'

# Generated at 2022-06-21 17:46:48.359634
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from textwrap import dedent
    from ..utils import parse

    source = dedent('''
    import os
    ''')

    expected = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    ''')

    tree = parse(source)
    assert tree is not None, 'Invalid input'

    Python2FutureTransformer().visit(tree)
    assert expected == astor.to_source(tree)

# Generated at 2022-06-21 17:46:52.643263
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_helpers import assert_source


# Generated at 2022-06-21 17:46:56.757538
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import compare_ast
    dummy = """
        assert 2 == 3, 'This is a unit test.'
    """
    expected = """
        from __future__ import absolute_import, division, print_function, unicode_literals
        assert 2 == 3, 'This is a unit test.'
    """
    actual = Python2FutureTransformer().visit(ast.parse(dummy))
    compare_ast(actual, expected)

# Generated at 2022-06-21 17:46:57.584961
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:46:58.520338
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:47:03.852213
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "print (3 / 2)"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint (3 / 2)\n"
    module = ast.parse(code)
    tree = Python2FutureTransformer().visit(module)
    result = compile(tree, filename='<ast>', mode='exec')
    assert expected == result.co_consts[0]

# Generated at 2022-06-21 17:47:10.280989
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .mocks import Module, Name, ImportFrom, ImportStatement
    from ..utils.testing import cmp_ast
    from ..utils.testing import get_tree

    tree = get_tree('x = 1')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

# Generated at 2022-06-21 17:47:16.746989
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    from ..nodes import Module
    # print(sys.version_info)
    assert (2, 7) == sys.version_info
    assert '2' == sys.version[0]
    mod = Module()
    assert mod.body == []
    p2tf = Python2FutureTransformer()
    mod = p2tf.visit(mod)
    assert mod.body != []

# Generated at 2022-06-21 17:47:23.406432
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    tree = ast3.parse('print(\'a\')')
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    expected = ast3.parse('''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('a')''')
    assert ast3.dump(tree) == ast3.dump(expected)

# Generated at 2022-06-21 17:47:33.234096
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    with open(os.path.join(os.path.dirname(__file__), '..', '..', 'example', 'python2.7', 'foo.py')) as f:
        tree = ast.parse(f.read(), filename='foo.py')
    Python2FutureTransformer().visit(tree)
    expected = '\n'.join([
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
        "",
        "def foo():",
        "    print('foo')",
        ""
    ])
    assert codegen.to_source(tree) == expected

# Generated at 2022-06-21 17:47:41.092296
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_node = ast.parse("from __future__ import print_function\ndef fn():\n pass")
    expected_node = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\ndef fn():\n pass")
    actual_node = Python2FutureTransformer().visit(test_node)

    assert ast.dump(expected_node) == ast.dump(actual_node)

# Generated at 2022-06-21 17:47:46.556390
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import fixtures
    assert fixtures.bytescode == fixtures.module.visit(Python2FutureTransformer)  # type: ignore

# Generated at 2022-06-21 17:47:55.333046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_utils import ast_equal
    from .python2_import_transformer import Python2ImportTransformer

    code = """
    import sys
    import datetime
    from os import path
    from future import print_function

    def test(): pass
    """
    ref_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import sys
    import datetime
    from os import path
    from future import print_function

    def test(): pass
    """

    ref_tree = ast.parse(ref_code)
    tree = ast.parse(code)

    Python2FutureTransformer(tree).visit(tree)

# Generated at 2022-06-21 17:47:59.133293
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '# -*- coding: utf-8 -*-\nfoo\nbar\n'
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    output = format(tree)
    expected = '# -*- coding: utf-8 -*-\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfoo\nbar\n'
    assert output == expected

# Generated at 2022-06-21 17:48:02.756375
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Tests the visit_Module method of the Python2FutureTransformer snippet."""
    import astor
    from ..utils.transform import transform


# Generated at 2022-06-21 17:48:08.468059
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = 'print("Hello world!")'
    expected_output = 'from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\n\nprint("Hello world!")'
    transformer = Python2FutureTransformer()
    actual_output = transformer.visit(ast.parse(input))
    assert astor.to_source(actual_output) == expected_output

# Generated at 2022-06-21 17:48:09.863024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-21 17:48:12.196230
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2future = Python2FutureTransformer()
    assert py2future.target == (2, 7)

# Generated at 2022-06-21 17:48:14.945266
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    

# Generated at 2022-06-21 17:48:16.733866
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)


# Generated at 2022-06-21 17:48:21.496757
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Build AST
    module = ast.parse(imports.get_code(future='__future__'))
    # Transform
    trans = Python2FutureTransformer()
    module = trans.visit(module)
    # Assert
    assert isinstance(module, ast.Module)
    assert len(module.body) == 0
    assert trans._tree_changed
    assert not trans._error_raised

# Generated at 2022-06-21 17:48:33.770217
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    result = Python2FutureTransformer('').transpile()
    # Note: PythonTestCase cannot be used due to Py2's 2to3 issue
    assert result == '\n'.join([
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
    ])

# Generated at 2022-06-21 17:48:35.028861
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    import ast

# Generated at 2022-06-21 17:48:40.111111
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .test_BaseNodeTransformer import BaseNodeTransformer_test_visit_Module
    from lookyloo.transformers import Python2FutureTransformer
    m = ast.parse('pass')
    gen = Python2FutureTransformer()
    BaseNodeTransformer_test_visit_Module(gen, m)

# Generated at 2022-06-21 17:48:49.259418
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os
    import unittest
    import astor
    from typed_astunparse import ast2py
    from typed_astunparse import dump
    # from typed_astunparse import typed_astunparse
    from ..utils.base import BaseTestCase
    from ..utils.base import compare_ast
    from ..utils.base import compare_source


    class Python2FutureTransformerTestCase(BaseTestCase):

        def test_basic_usage(self):
            # Test case for method `visit_Module` of class `Python2FutureTransformer`
            source = 'import os'
            expected_source = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os'''

# Generated at 2022-06-21 17:48:58.420850
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    root = ast.parse(textwrap.dedent("""
        import sys
        sys.path.append('..')
        from aquests.athreads import call
        from aquests.broker import aqueue
    """))
    expected = ast.parse(textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        sys.path.append('..')
        from aquests.athreads import call
        from aquests.broker import aqueue
    """))
    Python2FutureTransformer().visit(root)
    print (ast.dump(root, annotate_fields=False, include_attributes=False))

# Generated at 2022-06-21 17:49:08.090069
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    transformer = Python2FutureTransformer()
    test_ast = ast.parse('# test-only\nprint(42)')
    actual = transformer.visit(test_ast)
    expected = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
# test-only
print(42)
''')  # noqa
    assert len(actual.body) == len(expected.body)
    for actual_node, expected_node in zip(actual.body, expected.body):
        assert astor.to_source(actual_node) == astor.to_source(expected_node)

# Generated at 2022-06-21 17:49:10.916533
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pyfe = Python2FutureTransformer()
    assert pyfe.name == 'Python2FutureTransformer'
    assert pyfe.target == (2, 7)
    assert pyfe.priority == 20

# Generated at 2022-06-21 17:49:22.841057
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_name = 'test_Python2FutureTransformer_visit_Module'

    @snippet
    def snippet_0(future, module_name):
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        class A(object):
            def b(self):
                pass
        class X(object):
            def y(self):
                pass

    @snippet
    def snippet_1():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        class A(object):
            def b(self):
                pass
        class X(object):
            def y(self):
                pass

# Generated at 2022-06-21 17:49:31.678599
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = dedent("""
    def main():
        x = 'hello'
    """)
    expected = dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    def main():
        x = 'hello'
    """)

    module = ast.parse(source)
    Python2FutureTransformer().visit(module)
    assert astor.to_source(module) == expected

# Generated at 2022-06-21 17:49:33.525117
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()

    assert isinstance(x, Python2FutureTransformer)


# Generated at 2022-06-21 17:49:48.511208
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)



# Generated at 2022-06-21 17:49:50.933397
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer.from_version(target_version=2, file_encoding='utf-8')
    assert transformer.target == (2, 7)
    assert transformer.file_encoding == 'utf-8'



# Generated at 2022-06-21 17:50:01.516885
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-21 17:50:03.401521
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    #assert isinstance(x, Python2FutureTransformer)  # pass

# Generated at 2022-06-21 17:50:11.502592
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_candidate = "print('Hello World!')\n"
    candidate = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello World!')
"""
    candidate_ast = ast.parse(candidate)
    
    node_transformer = Python2FutureTransformer()
    result = node_transformer.visit(ast.parse(snippet_candidate))
    assert ast.dump(result, include_attributes=True) == ast.dump(candidate_ast, include_attributes=True)
    assert node_transformer._tree_changed == True

# Generated at 2022-06-21 17:50:22.569341
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List

    from typed_ast import ast3 as ast
    from typed_ast.transforms.future import Python2FutureTransformer
    from ..utils.typed_ast_test_utils import assert_read_only_ast_equal, assert_code_equal

    assert_read_only_ast_equal(Python2FutureTransformer(target=(2, 7)).visit(ast.parse("a = 1")), ast.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 1
    """).body)
    

# Generated at 2022-06-21 17:50:26.852340
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2_future = Python2FutureTransformer()
    py2_future.target = (2, 7)
    assert py2_future.target == (2, 7)
    assert py2_future._tree_changed
    assert py2_future.target == (2, 7)
    assert py2_future.generic_visit(py2_future.visit_Module(
        ast.parse('def f(): pass')))

# Generated at 2022-06-21 17:50:33.876751
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    """
    mock testing
    """
    import astor
    import itertools
    import unittest
    import astor
    import textwrap
    import itertools
    import astunparse
    from ..utils import get_patched_astunparse
    astunparse_patched = get_patched_astunparse()

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_simple_function(self):
            t = Python2FutureTransformer()
            module = ast.parse(textwrap.dedent("""\
                def hello():
                    return 'hello'
                """))
            print(astor.to_source(module))
            module = t.visit(module) # type: ignore

# Generated at 2022-06-21 17:50:39.765726
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import roundtrip
    code = "print('hello')"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('hello')"
    tree = ast.parse(code) # type: ignore
    Python2FutureTransformer().visit(tree)
    result = roundtrip(tree)
    assert result == expected


# Generated at 2022-06-21 17:50:44.096810
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    src = "import os"
    new_src = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os"
    root = ast.parse(src)
    transformer = Python2FutureTransformer()
    node_transformed = transformer.visit(root)
    new_src_ast = ast.parse(new_src)
    assert ast.dump(node_transformed) == ast.dump(new_src_ast)

# Generated at 2022-06-21 17:51:18.079900
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test method."""
    Python2FutureTransformer()



# Generated at 2022-06-21 17:51:21.184579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3


# Generated at 2022-06-21 17:51:22.092046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass # test is in test_python2 module

# Generated at 2022-06-21 17:51:30.418648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import pytest
    from typed_ast import ast3 as ast

    code = (
        "import os\n"
        "def func():\n"
        "    pass"
    )
    tree = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    tree = Python2FutureTransformer().visit(tree)  # type: ignore
    # Check imports
    assert tree.body[0].body[0].lineno == imports.start_lineno + 1
    # Check function
    assert tree.body[1].lineno == imports.end_lineno + 2



# Generated at 2022-06-21 17:51:32.059859
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler: Python2FutureTransformer = Python2FutureTransformer()
    assert transpiler

# Generated at 2022-06-21 17:51:40.912186
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .utils import make_module_and_context
    from .utils import parse_ast

    class DummyNodeTransformer(BaseNodeTransformer):
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            return node

    module, context = make_module_and_context(parse_ast("print('hello world')"))
    transformer = DummyNodeTransformer(module, context)
    node = transformer.visit(module)
    expected_imports = imports.get_body(future='__future__')
    assert node.body == expected_imports + module.body

# Generated at 2022-06-21 17:51:45.257696
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import Any
    from ... import parse

    ast_tree = parse('def foo():\n    pass\n')
    expected_tree = parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\ndef foo():\n    pass\n')
    transformer = Python2FutureTransformer()
    transformer.visit(ast_tree)
    assert ast_tree == expected_tree
    assert transformer._tree_changed, 'Expected tree to change'

# Generated at 2022-06-21 17:51:50.771790
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_name = Python2FutureTransformer.__name__
    instance = Python2FutureTransformer()

    assert isinstance(instance, BaseNodeTransformer)
    assert hasattr(instance, 'target')
    assert isinstance(instance.target, tuple)
    assert hasattr(instance, '_tree_changed')
    assert callable(getattr(instance, 'visit_%s' % class_name, None))



# Generated at 2022-06-21 17:51:53.108005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:52:04.909255
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from typed_ast.ast3 import ParserError
    from textwrap import dedent
    import astor
    from .test_BaseNodeTransformer import BaseNodeTransformerImpl

    code = dedent("""
    def foo():
        pass
    """)

    if StrictVersion(typed_ast.__version__) >= StrictVersion('1.3'):
        node = parse(code, feature_version=sys.version_info[:2])
    else:
        node = parse(code)

    expected_code = dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """)

    transformer = Python2FutureTransformer

# Generated at 2022-06-21 17:53:22.070137
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class Dummy:
        def visit_Module(self):
            return ""
    x = Python2FutureTransformer(Dummy())
    assert x.target == (2, 7)
    assert x._tree_changed is False
    assert x.visit_Module("") == ""



# Generated at 2022-06-21 17:53:29.626195
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import textwrap
    from ..utils.get_ast import get_ast
    from .fix_import_order import FixImportOrderTransformer
    from .remove_imports import RemoveImportsTransformer

    source = textwrap.dedent("""
        import sys
        import os
        import ast

        import six
        import typed_ast.ast3 as ast

        if True:
            import os
    """)
    mod = get_ast(source, mode='exec')
    assert isinstance(mod, ast.Module)
    mod = FixImportOrderTransformer().visit(mod)
    mod = RemoveImportsTransformer().visit(mod)
    assert isinstance(mod, ast.Module)
    mod = Python2FutureTransformer().visit(mod)
    assert isinstance(mod, ast.Module)

# Generated at 2022-06-21 17:53:31.444630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-21 17:53:33.072408
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test with good input
    assert Python2FutureTransformer(target=(2,7))

# Generated at 2022-06-21 17:53:37.149476
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(
        '''
print('hello')
'''
    )

    transformer = Python2FutureTransformer(verbosity=0)
    node = transformer.visit(module)

    assert not transformer.tree_changed
    assert len(node.body) == 1

# Generated at 2022-06-21 17:53:43.341622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from .fixtures import python_module
    module = ast.parse(python_module)
    expected = ast.Module(
        body=[
            ast.ImportFrom(
                module='__future__', names=[
                    ast.alias(name='absolute_import', asname=None),
                    ast.alias(name='division', asname=None),
                    ast.alias(name='print_function', asname=None),
                    ast.alias(name='unicode_literals', asname=None),
                ],
                level=0),
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=42)),
        ]
    )
    transformer = Python2FutureTransformer()

# Generated at 2022-06-21 17:53:46.228454
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # given,
    cls = Python2FutureTransformer

    # expect
    assert cls.target == (2, 7)

# Generated at 2022-06-21 17:53:54.625236
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import FunctionDef
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import Pass
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Store
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Assign
    from typed_ast.ast3 import Expr
    from typed_ast.ast3 import Num
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Attribute
    from typed_ast.ast3 import Subscript
    from typed_ast.ast3 import Index
    from typed_ast.ast3 import List
    from typed_ast.ast3 import Tuple

# Generated at 2022-06-21 17:54:01.288052
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('print(1)')
    module = transformer.visit(module)
    assert transformer.tree_changed
    # Note that order of imports is reversed
    assert to_source(module) == ('from __future__ import unicode_literals\n'
                                 'from __future__ import print_function\n'
                                 'from __future__ import division\n'
                                 'from __future__ import absolute_import\n'
                                 'print(1)\n')

# Generated at 2022-06-21 17:54:04.412392
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    p = ast.parse("1 + 2")
    c = Python2FutureTransformer()
    c.visit(p)
    assert c.tree_changed

