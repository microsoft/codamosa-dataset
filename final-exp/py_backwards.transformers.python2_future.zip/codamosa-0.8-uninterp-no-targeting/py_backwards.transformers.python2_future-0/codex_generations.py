

# Generated at 2022-06-21 17:46:09.732684
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    code = "def inc(x):\n    return x + 1"

    # Act
    py3_node = ast.parse(code, '', 'exec', include_future_absolute_import=True)
    py2_transformer = Python2FutureTransformer()
    py2_node = py2_transformer.visit(py3_node)

    # Assert
    assert py2_node.body[0].names[0].name == 'absolute_import'
    assert py2_node.body[0].names[1].name == 'division'
    assert py2_node.body[0].names[2].name == 'print_function'
    assert py2_node.body[0].names[3].name == 'unicode_literals'

# Generated at 2022-06-21 17:46:13.989427
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from .fixtures.single_module import source
    future_transformer = Python2FutureTransformer()
    future_transformer.visit(ast.parse(source))
    assert astor.to_source(future_transformer.module) == source



# Generated at 2022-06-21 17:46:16.652152
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import CodeTransformer
    instance = CodeTransformer(
        Python2FutureTransformer
    )
    assert isinstance(instance._visitors['2.7'][0], Python2FutureTransformer)

# Generated at 2022-06-21 17:46:20.973049
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    original_code = """
        import os
    """
    expected_code = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
    """
    node = parse(original_code)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    result_code = unparse(new_node)
    assert expected_code == result_code

# Generated at 2022-06-21 17:46:27.737460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import _test_transform
    from typed_ast import ast3 as ast

    _test_transform(Python2FutureTransformer, '''
    1+2
    ''', '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    1+2
    ''', '''
    assert isinstance(node, ast.Module)
    ''')

# Generated at 2022-06-21 17:46:37.413905
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..sixer import Sixer
    from sys import version_info
    if version_info.major >= 3:
        return

    sixer = Sixer()
    sixer.add_transformer(Python2FutureTransformer())
    sixer.fix_file('tests/data/py2/foo_py2.py')

    with open('tests/data/py2/foo_py2.py') as f:
        txt = f.read()

    assert 'from __future__ import absolute_import' in txt
    assert 'from __future__ import division' in txt
    assert 'from __future__ import print_function' in txt
    assert 'from __future__ import unicode_literals' in txt

# Generated at 2022-06-21 17:46:38.375668
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:46:41.666630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer()

    assert isinstance(transformer, ast.NodeTransformer)
    assert transformer._tree_changed is False
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:46:45.992573
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    module = ast.parse("", filename="fake.py", mode="exec")
    imports_node = imports.get_body(future='__future__')
    assert t.visit(module).body == imports_node



# Generated at 2022-06-21 17:46:46.547546
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:46:50.775053
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(None)
    assert t.target == (2, 7)
    assert t.visit_Module

# Generated at 2022-06-21 17:46:53.039701
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_astunparse
    # type: ignore

# Generated at 2022-06-21 17:46:54.030631
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:47:02.414732
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert (Python2FutureTransformer().visit_Module(
        ast.parse(''))) == ast.parse('''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
        ''')
    assert (Python2FutureTransformer().visit_Module(
        ast.parse('a = 1'))) == ast.parse('''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            a = 1
        ''')

# Generated at 2022-06-21 17:47:07.492687
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    from ..utils.snippet import from_file

    HERE = os.path.dirname(__file__)
    source = from_file(os.path.join(HERE, '..', 'test', 'files', 'python27.py'))
    expected = from_file(os.path.join(HERE, '..', 'test', 'files', 'python27_future.py'))

    transformer = Python2FutureTransformer(source)
    assert transformer.tree_changed
    assert transformer.source == expected

# Generated at 2022-06-21 17:47:16.853473
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """import six
from six import moves
from six.moves import range
from six.moves import reduce"""

    transformer = Python2FutureTransformer()
    node = ast.parse(code)
    transformer.visit(node)

    expected_code = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import six
from six import moves
from six.moves import range
from six.moves import reduce"""

    expected = ast.parse(expected_code)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:47:23.507548
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import get_ast

    actual = get_ast(Python2FutureTransformer, """
        a = 1
        b = 2
    """, target=(2, 7))

    expected = get_ast("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    a = 1
    b = 2
    """)

    assert actual == expected

# Generated at 2022-06-21 17:47:34.525683
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ast_tree = ast.parse("x = 1", "<test>", "exec")
    t = Python2FutureTransformer(ast_tree, None)
    node = t.visit_Module(ast_tree)
    assert(isinstance(node, ast.Module))
    assert(len(node.body) == 7)
    assert(isinstance(node.body[0], ast.ImportFrom))
    assert(node.body[0].module == "__future__")
    assert(node.body[0].names[0].name == "absolute_import")
    assert(node.body[0].names[0].asname == None)
    assert(node.body[1].names[0].name == "division")
    assert(node.body[2].names[0].name == "print_function")

# Generated at 2022-06-21 17:47:45.111808
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-21 17:47:46.534500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-21 17:47:56.199239
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = Python2FutureTransformer().visit_Module(ast.parse("\ndef foo():\n    pass\n"))
    assert str(node) == dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo():
            pass
    """)

# Generated at 2022-06-21 17:47:58.163296
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()

    assert t.target == (2, 7)
    assert t._tree_changed is False


# Generated at 2022-06-21 17:48:01.279964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test case for `transpyle.plugins.Python2FutureTransformer`
    
    """
    from transpyle.plugins import Python2FutureTransformer
    
    clazz = Python2FutureTransformer
    clazz.target = None
    instance = clazz()
    assert hasattr(instance, 'visit_Module')

# Generated at 2022-06-21 17:48:12.256618
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Arrange
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    transformer = Python2FutureTransformer()

    # Act
    nodes = transformer.visit(ast.parse('print(1)'))

    # Assert
    assert isinstance(nodes , Module)
    assert transformer._tree_changed == True      # pylint: disable=protected-access
    assert transformer.target == (2, 7)
    assert len(nodes.body) == 5
    assert isinstance(nodes.body[0], ast.ImportFrom)
    assert nodes.body[0].names[0].name == 'absolute_import'
    assert nodes.body[0].names[0].asname is None
    assert nodes.body[1].names[0].name == 'division'

# Generated at 2022-06-21 17:48:19.852072
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from distutils.version import LooseVersion
    import sys
    if LooseVersion(sys.version) < LooseVersion('3.8.0'):
        from typed_astunparse import unparse as unparse_ast
    else:
        from typed_astunparse import dump as unparse_ast

    module = parse('''
        def foo():
            pass
    ''')

    module = Python2FutureTransformer().visit(module)


# Generated at 2022-06-21 17:48:24.926349
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    t = ast.parse('a = 1\n')
    Python2FutureTransformer().visit(t)

    old = ast.parse('a = 1\n')
    new = ast.parse('from __future__ import absolute_import\n'
                    'from __future__ import division\n'
                    'from __future__ import print_function\n'
                    'from __future__ import unicode_literals\n'
                    'a = 1\n')
    assert_ast_eq(t, new)

# Generated at 2022-06-21 17:48:26.637705
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    target = (2, 7)
    assert target == Python2FutureTransformer().target

# Generated at 2022-06-21 17:48:34.989548
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = dedent("""
    import sys
    import os
    
    class A(object):
        pass
    """)

    node = ast.parse(code)
    node = Python2FutureTransformer().visit(node)
    code_target = dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import sys
    import os
    
    class A(object):
        pass
    """)
    node_target = ast.parse(code_target)
    assert ast.dump(node) == ast.dump(node_target)

# Generated at 2022-06-21 17:48:44.616047
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    visitor = Python2FutureTransformer()
    module = ast.Module([], type_ignores=[])
    updated_module = visitor.visit_Module(module)
    assert updated_module is not None
    assert isinstance(updated_module, ast3.Module)
    assert updated_module.body is not None
    assert len(updated_module.body) == 4
    assert updated_module.body[0].names[0].name == 'absolute_import'
    assert updated_module.body[1].names[0].name == 'division'
    assert updated_module.body[2].names[0].name == 'print_function'
    assert updated_module.body[3].names[0].name == 'unicode_literals'



# Generated at 2022-06-21 17:48:49.216613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class TS(Python2FutureTransformer):
        def __init__(self):
            self.i = 0
        def visit_Module(self, node):
            self.i = 1
            return super(TS, self).visit_Module(node)

    node = ast.parse('print(1)')
    TS().visit(node)
    assert TS.i == 1

# Generated at 2022-06-21 17:49:07.712478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    '''Test adding correct future imports'''
    test_node = ast.Module(body=[ast.Pass()])
    result_node = Python2FutureTransformer.run(test_node)
    if len(result_node.body) != 5:
        raise AssertionError('Transformer not adding 4 lines at start of module')
    if result_node.body[0].__class__ != ast.ImportFrom:
        raise AssertionError('Transformer not adding import at start of module')
    if result_node.body[1].__class__ != ast.ImportFrom:
        raise AssertionError('Transformer not adding import at start of module')

# Generated at 2022-06-21 17:49:16.279314
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from . import util
    tree = util.ext_module("")
    Python2FutureTransformer().visit(tree)
    assert "from __future__ import absolute_import" in astor.to_source(tree)
    assert "from __future__ import division" in astor.to_source(tree)
    assert "from __future__ import print_function" in astor.to_source(tree)
    assert "from __future__ import unicode_literals" in astor.to_source(tree)
    
    
    

# Generated at 2022-06-21 17:49:22.718093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    source = 'import re'
    expected = """
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

import re"""
    tree = ast.parse(source)
    t = Python2FutureTransformer()
    new_tree = t.visit(tree)
    actual = astor.to_source(new_tree)
    assert actual == expected
test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-21 17:49:25.368801
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:49:31.006506
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ast import parse
    from typed_ast import ast3 as ast
    module = ast.parse("x = 1")
    assert isinstance(module, ast.Module)
    assert isinstance(module.body[0], ast.Assign)
    transformer = Python2FutureTransformer()
    transformed_module = transformer.visit(module)
    print(transformed_module)

# Generated at 2022-06-21 17:49:42.194226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_tree = ast.parse('print(1)')
    transformer = Python2FutureTransformer()
    tree_changed = transformer.visit(ast_tree)
    assert tree_changed == True
    # ast.dump(ast_tree)  # -> "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Expr(value=Call(func=Name(id='print', ctx

# Generated at 2022-06-21 17:49:45.697334
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    m = astor.parse_file('test.py')
    m = Python2FutureTransformer().visit(m)
    assert astor.to_source(m).startswith(imports.get_source(future='__future__').strip())

# Generated at 2022-06-21 17:49:47.293512
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """test for constructor of Python2FutureTransformer"""
    f = Python2FutureTransformer()
    assert f._tree_changed == False
    assert isinstance(f, Python2FutureTransformer)
    

# Generated at 2022-06-21 17:49:51.213221
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import transform
    input = u'''
import os
'''
    expected_output = u'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
'''
    actual_output = transform(Python2FutureTransformer, input)
    assert actual_output == expected_output

# Generated at 2022-06-21 17:49:56.793228
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print(test_Python2FutureTransformer_visit_Module.__doc__)

    ts = Python2FutureTransformer()
    node = ast.Module()
    result = ts.visit_Module(node)
    assert result == node
    assert node.body == imports.get_body(future='__future__')



# Generated at 2022-06-21 17:50:18.486304
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    module_node = ast.parse('print("Hello world")')
    Python2FutureTransformer().visit(module_node)
    assert astor.to_source(module_node).rstrip() == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello world")
'''.strip()

# Generated at 2022-06-21 17:50:22.307672
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = Module('', [Import(names=[alias('abc', None), alias('efg', None)])])
    output = Python2FutureTransformer.run_pipeline(input)
    assert output.body[0].names[0].name == '__future__'

# Generated at 2022-06-21 17:50:26.022985
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    checker = Python2FutureTransformer(target_version=(2, 7)).visit
    assert checker(ast.parse("""1""")) == ast.parse("""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

1
"""
)

# Generated at 2022-06-21 17:50:29.444527
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import _ast3

    mods = ast.parse("a = \"\\x00\"")
    mods = Python2FutureTransformer().visit(mods)
    assert mods.body[0].value.s == u"a = \"\""

# Generated at 2022-06-21 17:50:32.083294
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer({})


# Generated at 2022-06-21 17:50:37.781790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import myia.api
    print(myia.parse(r'''
        import os 
    ''').code)
    print(myia.api.transform(r'''
        import os 
    ''', {'Python2FutureTransformer'}).code)
    print(myia.api.transform(r'''
        from __future__ import absolute_import
    ''', {'Python2FutureTransformer'}).code)

# Generated at 2022-06-21 17:50:46.339991
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    node = parse("x=1")
    # print(ast.dump(node))
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    # print(ast.dump(new_node))
    assert transformer._tree_changed
    assert isinstance(new_node, ast.Module)
    assert node != new_node
    first_body_node = new_node.body[0]
    assert isinstance(first_body_node, ast.ImportFrom)
    assert first_body_node.module == "__future__"
    assert first_body_node.names[0].name == "absolute_import"
    second_body_node = new_node.body[1]

# Generated at 2022-06-21 17:50:53.177517
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from astunparse import unparse
    transformer = Python2FutureTransformer()
    module_node = ast.parse('print(2/3)')
    target_ast = ast.parse('''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(2/3)''')
    assert unparse(transformer.visit(module_node)) == unparse(target_ast)

# Generated at 2022-06-21 17:50:55.091619
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:51:01.903907
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # given
    input = """\
print('hello')
"""
    expected_output = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('hello')
"""
    # when
    output = Python2FutureTransformer().visit_Module(ast.parse(input))
    # then
    assert ast.dump(output) == ast.dump(ast.parse(expected_output))

# Generated at 2022-06-21 17:51:40.522619
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.testutils import transform

    code = '''
        def foo():
            pass
    '''

    expected_code = r'''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo():
            pass
    '''

    assert transform(Python2FutureTransformer, code) == expected_code  # type: ignore

# Generated at 2022-06-21 17:51:41.545765
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer



# Generated at 2022-06-21 17:51:47.150001
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    class_ = Python2FutureTransformer()
    node = ast.parse("""
    x = [1, 2, 3]
    d = {1:2}
    """)

    # When 
    class_.visit(node)

    # Then
    assert class_.tree_changed is True

# Generated at 2022-06-21 17:51:49.377818
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys, io
    from contextlib import redirect_stdout
    f = io.StringIO()
    with redirect_stdout(f):
        print("Hello World")


# Generated at 2022-06-21 17:51:58.598606
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import pytest
    from typed_ast import ast3 as ast

    class Python2FutureTransformerMock(Python2FutureTransformer):
        def __init__(self, tree):
            self._tree_changed = False
            self._tree = tree

    node = import_parser("import x; y = 6;")
    node = Python2FutureTransformerMock(node).visit(node)
    print(ast.dump(node))
    assert ast.dump(node) == """Module(body=[Import(names=[alias(name='x', asname=None)]), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=6))])"""
    assert Python2FutureTransformerMock(node).tree_changed


# Generated at 2022-06-21 17:52:01.932163
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2future = Python2FutureTransformer()
    module = ast.parse('pass')
    python2future.visit(module)
    python2future.visit(module)
    module = ast.parse('class X:\n  pass')
    python2future.visit(module)

# Generated at 2022-06-21 17:52:10.222543
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import inspect
    class Python2FutureTransformerSub(Python2FutureTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            print('visit Module: {}'.format(node))
            m = inspect.getmodule(type(self))
            if m:
                global Python2FutureTransformer
                Python2FutureTransformer = type(self)
            return super().visit_Module(node)
    assert Python2FutureTransformerSub is not Python2FutureTransformer
    assert Python2FutureTransformerSub.visit_Module is not Python2FutureTransformer.visit_Module
    assert Python2FutureTransformerSub.visit_Module.__code__.co_filename != Python2FutureTransformer.visit_Module.__code__.co_filename
    assert Python2FutureTransformerSub.visit_

# Generated at 2022-06-21 17:52:18.870435
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    node = ast.parse('x = 1', mode='exec')
    expected_node = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1', mode='exec')

    # Exercise
    actual_node = transformer.visit(node)

    # Verify
    assert str(actual_node) == str(expected_node)

# Generated at 2022-06-21 17:52:24.229416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_snippet, future_absolute_import, future_division, future_print_function, future_unicode_literals
    module = ast.parse(make_snippet(lambda: 'pass'))
    expected = ast.parse(make_snippet(lambda: None, future_absolute_import, future_division, future_print_function, future_unicode_literals))
    transformer = Python2FutureTransformer()
    assert transformer.visit_Module(module) == expected
    assert transformer.tree_changed

# Generated at 2022-06-21 17:52:26.865458
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    original = ast.parse('test = lambda: None')
    future = Python2FutureTransformer()
    final = future.visit(original)
    assert final.body[0].__class__.__name__ == "ImportFrom"
    assert final.body[1].__class__.__name__ == "Assign"

# Generated at 2022-06-21 17:53:52.874935
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import collections
    import textwrap
    import typed_ast.ast3 as ast

    input = textwrap.dedent('''
        a = 2
    ''')

    output = textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 2
    ''')

    transformer = Python2FutureTransformer()
    tree = ast.parse(input)
    transformer.visit(tree)
    output_tree = ast.parse(output)

    assert collections.Counter(ast.dump(tree)) == collections.Counter(ast.dump(output_tree))

# Generated at 2022-06-21 17:54:00.466999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import roundtrip, compare_nodes

    tree = ast.parse('def a(): return 1')
    t = Python2FutureTransformer()
    newtree = t.visit(tree)  # type: ignore
    compare_nodes(newtree, ast.parse(imports.get_source(future='__future__') + 'def a(): return 1'))

    assert roundtrip(tree, Python2FutureTransformer) == roundtrip(newtree, Python2FutureTransformer)

# Generated at 2022-06-21 17:54:06.959719
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.assert_code import assert_code_equal
    from .fixtures import python_2_future_node
    transformer = Python2FutureTransformer()
    res = transformer.visit(python_2_future_node)  # type: ignore

# Generated at 2022-06-21 17:54:09.548250
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..nodes import ast3_to_ast

    node = ast.parse('print(x)')
    node = ast3_to_ast(node)
    obj = Python2FutureTransformer()
    obj.visit(node)
    print(ast.dump(node))



# Generated at 2022-06-21 17:54:16.466516
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
foo = 'bar'
    """
    expected_output = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

foo = 'bar'

    """
    transformer = Python2FutureTransformer(source)
    result = transformer.visit(transformer.tree)
    assert expected_output == result
    assert transformer._tree_changed is True

# Generated at 2022-06-21 17:54:22.459108
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from .. import transform

    for snippet in [
            "",
            "print('Hello World')",
            "def foo(a,b):\n    return a+b\n",
        ]:
        print(snippet)
        module = ast.parse(snippet)
        transform(module, Python2FutureTransformer)  # does not raise



__transformer__ = Python2FutureTransformer

# Generated at 2022-06-21 17:54:28.588147
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # This check ensures that the required attributes are present in the class before running the tests on it.
    required_attrs = {"target", "visit_Module"}
    class_attrs = set(dir(Python2FutureTransformer))
    assert required_attrs <= class_attrs, \
        "Missing required attributes. Add the following attributes: " + ", ".join(required_attrs - class_attrs)
    
    # Define some generic input value
    node = None
    # Construct the object that is to be tested
    transformer = Python2FutureTransformer()
    # Invoke method that is to be tested
    actual_out = transformer.visit_Module(node)
    # Check if we get the correct output
    assert actual_out is not None, "Wrong output - actual_out is None."
    # Define some generic expected value

# Generated at 2022-06-21 17:54:30.705897
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # GIVEN
    # WHEN
    t = Python2FutureTransformer()
    # THEN
    assert isinstance(t, Python2FutureTransformer)

# Generated at 2022-06-21 17:54:37.373674
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import run_transformer
    
    source = '''
from functools import reduce
from future import unicode_literals
print(__future__.absolute_import)
print(__future__.print_function)
x = range(100)
print("Hello World")
'''
    tree = ast.parse(source)
    new_tree = run_transformer(Python2FutureTransformer, tree)
    assert compile(new_tree, '<test>', 'exec')

# Generated at 2022-06-21 17:54:43.408680
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module
    from ast_tools.macros import make_visitor

    p = Python2FutureTransformer()
    m = Module('\n'.join(['a = 1', 'def x():\n    pass']))
    print(ast.dump(m))
    # Test constructor
    assert p._tree_changed is False and p._tree_exhausted is False
    assert not p.visit(m)
    assert p._tree_changed is True and p._tree_exhausted is True
    print(ast.dump(m))
