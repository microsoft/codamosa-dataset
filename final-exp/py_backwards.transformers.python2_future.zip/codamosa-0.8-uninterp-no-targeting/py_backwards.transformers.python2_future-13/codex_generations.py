

# Generated at 2022-06-21 17:46:11.344346
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import assert_node_equals
    from ..utils.ast_factory import ast_factory
    from .comments import CommentUpdater

    source =  '''
        def foo(a, b):
            return a + b
    '''

    expected =  '''
        # from __future__ import absolute_import
        # from __future__ import division
        # from __future__ import print_function
        # from __future__ import unicode_literals
        def foo(a, b):
            return a + b
    '''
    transformer = Python2FutureTransformer()
    tree = ast.parse(source, 'example.py')
    tree = transformer.visit(tree)
    assert transformer.tree_changed
    tree = CommentUpdater().visit(tree)

# Generated at 2022-06-21 17:46:15.605377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor  # type: ignore
    tree_in = ast.parse(imports.spur(future='__future__') + "pass")
    tree_out = Python2FutureTransformer(tree_in).get_tree()
    assert astor.to_source(tree_in) == astor.to_source(tree_out)

# Generated at 2022-06-21 17:46:18.816107
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import os.path
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ..main import main


# Generated at 2022-06-21 17:46:28.552194
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import transformer
    
    code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from collections import defaultdict
from collections import namedtuple
    """
    tree = ast.parse(code)
    # ast.fix_missing_locations(tree)
    tree = Python2FutureTransformer().visit(tree)
    assert transformer.to_source(tree) == transformer.to_source(ast.parse(imports.get_body(future='__future__') + code))  # type: ignore

# Generated at 2022-06-21 17:46:30.618169
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-21 17:46:35.396380
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('')
    trans = BaseNodeTransformer()
    trans.visit(tree)
    trans = BaseNodeTransformer()
    assert trans.target == (2, 7)
    trans.visit(tree)
    trans = Python2FutureTransformer()
    trans.visit(tree)


# Generated at 2022-06-21 17:46:36.450830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:46:38.829551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    sample = ""
    expected = imports.get_source(future='__future__')
    actual = Python2FutureTransformer.run(sample)
    assert actual == expected

# Generated at 2022-06-21 17:46:42.405090
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_transformer = Python2FutureTransformer()
    test_transformer.visit(None)
    assert isinstance(test_transformer, object)
    assert isinstance(test_transformer, BaseNodeTransformer)
    assert isinstance(test_transformer, Python2FutureTransformer)

# Generated at 2022-06-21 17:46:43.768662
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-21 17:46:51.852238
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = dedent('''
    import numpy
    import pandas
    import sys
    ''')
    expected = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import numpy
    import pandas
    import sys
    ''')
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree) 
    actual = astunparse.unparse(tree)
    assert source != actual
    assert expected == actual

# Generated at 2022-06-21 17:46:56.249041
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    sample_source = "import os"

    def test(transformer, source):
        node = ast.parse(source)
        transformer.visit(node)
        assert source != node

    transformer = Python2FutureTransformer()
    test(transformer, sample_source)

# Generated at 2022-06-21 17:47:01.274091
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree_before = ast.parse('exists')
    tree_after = ast.parse(imports(future='__future__') + 'exists')
    transformer = Python2FutureTransformer()
    transformer.visit(tree_before)
    assert compare_ast(tree_before, tree_after)



# Generated at 2022-06-21 17:47:02.104245
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-21 17:47:10.366364
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, Load, Name
    from .test_BaseNodeTransformer import BaseNodeTransformerTester
    from .snippets import snippet_to_ast, snippet_to_source
    from .test_BaseNodeTransformer import EXPECTING_TREE_CHANGED

    tree = snippet_to_ast(
            imports, future='__future__')


# Generated at 2022-06-21 17:47:17.213977
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from darglint.transformers.python_2_future import (
        Python2FutureTransformer,
    )
    tree = ast.parse('def f() -> None: pass')
    transformer = Python2FutureTransformer()
    tree2 = transformer.visit(tree)
    assert transformer.tree_changed == True
    assert tree2.body[0].name == 'absolute_import'

# Generated at 2022-06-21 17:47:22.661794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse("print('hello world')")
    Python2FutureTransformer().visit(tree)
    assert (tree == ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint('hello world')"))

# Generated at 2022-06-21 17:47:28.358760
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..codegen import to_source
    from . import parse_module

    code = imports.get_code(future='__future__')
    node = parse_module(code)

    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)

    new_code = to_source(new_node)
    assert new_code == code

# Generated at 2022-06-21 17:47:31.519853
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    class_name = "Python2FutureTransformer"
    # Act
    instance = eval(class_name + "()")
    # Assert
    assert isinstance(instance, Python2FutureTransformer)

# Generated at 2022-06-21 17:47:42.932717
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_processing.ast_utils import AstProcessor

    class Py2Future:
        """Example of Python 2 file with __future__ imports"""
        target = (2, 7)

        @snippet
        def snippet(future):
            from future import absolute_import
            from future import division
            from future import print_function
            from future import unicode_literals

            class ExampleClass:
                def __init__(self):
                    self.a = 1 + 1
                    self.b = 1 / 1
                    self.c = 1 / 2
                    self.d = 'test'
                    self.e = b'test'

    class Py2FutureExpected:
        """Example of Python 2 file with __future__ imports"""
        target = (2, 7)


# Generated at 2022-06-21 17:47:53.871802
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(imports.get_source(future='__future__') + "\nx = 10")
    assert str(module) == "<Module object at 0x10f0e8e48>"
    Python2FutureTransformer.run(module)

# Generated at 2022-06-21 17:48:00.494476
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    source = "print('hello')"
    expected_source = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(\'hello\')'
    source_ast = ast.parse(source)
    transformed_ast = transformer.visit(source_ast)  # type: ignore
    assert astor.to_source(transformed_ast) == expected_source

# Generated at 2022-06-21 17:48:11.340365
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """\
a = 1
b = '2'
"""
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 17:48:12.960358
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)


# Generated at 2022-06-21 17:48:15.661293
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Basic constructor test.
    """
    transformer = Python2FutureTransformer()
    assert transformer.target[0] == 2
    assert transformer.target[1] == 7

# Generated at 2022-06-21 17:48:17.777451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer(*Python2FutureTransformer.target)
    assert isinstance(transpiler, Python2FutureTransformer)

# Generated at 2022-06-21 17:48:19.105125
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()
  
__all__ = ['Python2FutureTransformer']

# Generated at 2022-06-21 17:48:23.786113
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer('/home/liwei/git_repos/snippet-collector/demo/python2.py')
    assert transformer.target == (2, 7)
    assert transformer.filename == '/home/liwei/git_repos/snippet-collector/demo/python2.py'
    assert transformer._tree_changed == False
    assert transformer.visit_Module(ast.Module(body=[])) == ast.Module(body=[imports.get_body()])


# Generated at 2022-06-21 17:48:28.561281
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().visit(ast.parse('1')) == \
"""\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

1"""

# Generated at 2022-06-21 17:48:32.919887
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3

    code = """\
x = 1
y = 2
"""
    node = ast3.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert transformer._tree_changed
    assert node.body[0].__class__ == ast3.ImportFrom


# Generated at 2022-06-21 17:48:41.689680
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys, os
    myPath = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, myPath + '/../')
    from python2to3 import transform
    from ..utils.sample_snippets import snippet_imports, snippet_imports_future
    snippet = transform(snippet_imports)
    assert snippet == snippet_imports_future

# Generated at 2022-06-21 17:48:43.255320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test whether the constructor works with valid input
    """
    Python2FutureTransformer()

# Generated at 2022-06-21 17:48:44.204562
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:48:49.469934
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert node.body[0].names[0].name == 'absolute_import'
    assert node.body[1].names[0].name == 'division'
    assert node.body[2].names[0].name == 'print_function'
    assert node.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-21 17:48:58.617892
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    trans = Python2FutureTransformer()
    assert hasattr(trans, 'target')
    assert trans.target == (2, 7)
    assert hasattr(trans, '_visit_functions')
    assert hasattr(trans, 'visit')
    assert hasattr(trans, '_visit_functions')
    assert hasattr(trans, 'visit_Module')
    assert hasattr(trans, 'generic_visit')
    module = astor.parse_file(os.path.join(os.path.dirname(__file__), '../../tests/example_parsed_1.py'))
    module = trans.visit(module)
    statement_in_module = module.body[0]
    assert isinstance(statement_in_module, ast.ImportFrom)
    assert statement

# Generated at 2022-06-21 17:49:08.132476
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..lexer.tokens import Token
    
    source = '''
    import os
    import sys
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    '''
    node = ast.parse(source)
    node_transformed = Python2FutureTransformer().visit(node)
    assert ast.dump(node_transformed) == ast.dump(ast.parse(expected))


if __name__ == '__main__':
    print(test_Python2FutureTransformer_visit_Module())

# Generated at 2022-06-21 17:49:16.480058
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test of method visit_Module of class Python2FutureTransformer."""

    # Set-up test data
    NodeTransformer = Python2FutureTransformer()
    NodeTransformer._tree_changed = False
  
    test_data = {
      "Module_1" :
        {
          "input": ast.parse("""
import os
print(os.getcwdu())
"""),
          "expected_output": ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import os
print(os.getcwdu())
"""),
          "expected_tree_changed": True
        }
    }

    # Code to test

# Generated at 2022-06-21 17:49:17.469228
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippet.unit_test(__file__)

# Generated at 2022-06-21 17:49:25.677255
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from ..utils.ast_maker import ast_maker


# Generated at 2022-06-21 17:49:32.971963
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""

    from lib2to3 import refactor

    code = """
        print("Hello")
    """
    print("\n", code)

    # Set refactoring tool up
    rt = refactor.RefactoringTool(
        [Python2FutureTransformer], {}, explicit=True)

    # Run the refactoring tool
    rt.refactor_string(code, "test.py")

    assert(rt.errors == [])



# Generated at 2022-06-21 17:49:47.220478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = dedent('''
        from __future__ import absolute_import
        print 3
    ''')
    from typed_ast import ast3
    tree = ast3.parse(code)
    Python2FutureTransformer().visit(tree)
    expected_code = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print 3
    ''')
    expected_tree = ast3.parse(expected_code)
    assert tree == expected_tree



# Generated at 2022-06-21 17:49:50.643243
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = FUTURE_PARSER.parse_args(['1.0.0'])
    parser = Python2FutureTransformer(future)
    assert parser.target == (2, 7)
    assert parser._tree_changed == False
    assert parser.future == future
    assert parser.next_version == 3



# Generated at 2022-06-21 17:50:01.385611
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    tmpdir = py.test.ensuretemp('test_python2_future_transformer_')
    tmpdir.join('test.py').write(textwrap.dedent('''\
    # coding: utf-8
    
    
    foo = 1
    '''))
    with tmpdir.as_cwd():
        result = invoke_piper('-l py:2.7 -r python2-future-transformer test.py')
        expected = textwrap.dedent('''\
        # coding: utf-8


        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        
        foo = 1
        ''')

# Generated at 2022-06-21 17:50:11.277943
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.transforms import Python2FutureTransformer
    from typed_ast.transforms import Python2GeneratorTransformer

    source = "pass"
    tree = ast.parse(source, mode='exec')
    expected_tree = """Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Pass()])"""

    tree = Python2

# Generated at 2022-06-21 17:50:15.318501
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('print("Hello World !")\nx = 5')
    improved_tree = Python2FutureTransformer().transform(tree)
    assert ast.dump(tree) != ast.dump(improved_tree)

# Generated at 2022-06-21 17:50:22.211225
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_snippet = '''
#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys

if __name__ == "__main__":
    sys.exit(main(sys.argv))
'''
    node = ast.parse(test_snippet)
    Python2FutureTransformer().visit(node)


# Generated at 2022-06-21 17:50:27.400385
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source_code = "print('test')"
    node_tree = ast.parse(source_code)
    Python2FutureTransformer().visit(node_tree)
    transformed_code = astor.to_source(node_tree)
    assert transformed_code == """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('test')""", "Failure at method visit_Module of class Python2FutureTransformer"

# Generated at 2022-06-21 17:50:32.562042
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    from inspect import cleandoc

    from typed_ast import ast3 as ast

    from snoop.fmt import Python2FutureTransformer
    from snoop.fmt.indent import IndentVisitor

    code = cleandoc('''
        from __future__ import print_function
        from abc import abstractmethod


        def factorial(n):
            fac = 1
            for i in range(2, n + 1):
                fac *= i
            return fac
    ''')
    tree = ast.parse(code, filename='<unknown>')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    print(ast.dump(tree))
    IndentVisitor().visit(tree)

# Generated at 2022-06-21 17:50:38.148596
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""
        def foo():\n
            pass
    """)

    expected_node = ast.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():\n
            pass
    """)

    assert Python2FutureTransformer().visit(node) == expected_node

# Generated at 2022-06-21 17:50:42.113905
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse('print("hello world")')
    module_node_with_future = ast.Module(body=imports.get_body(future='__future__')
                                         + module_node.body)
    assert Python2FutureTransformer().visit(module_node) == module_node_with_future

# Generated at 2022-06-21 17:50:59.706803
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    visitor = Python2FutureTransformer({})
    snippets = [
        # 0
        '',
        # 1
        'import future',
        # 2
        'import __future__',
        # 3
        'from future import *',
        # 4
        'from __future__ import *',
        # 5
        'from future import absolute_import',
        # 6
        'from __future__ import absolute_import',
        # 7
        'from __future__ import division',
        # 8
        'print(1)',
    ]
    for index, snippet in enumerate(snippets):
        tree = ast.parse(snippet)
        visitor.visit(tree)
        assert(visitor._tree_changed == (index > 0))
        visitor._tree_changed = False

# Generated at 2022-06-21 17:51:01.056430
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:51:03.509117
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_tree = ast.parse('print("Hello")')
    Python2FutureTransformer()(ast_tree)
    assert 'Hello' in astor.to_source(ast_tree)

# Generated at 2022-06-21 17:51:12.686897
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from ..utils.source import dedent
    from ..utils.visitor import dump
    
    source = dedent("""
    a = 1
    b = 2
    """)
    with make_fixtures(globals(), source) as (t, expected):
        visitor = t(input_tree=input_tree)
        module = visitor.visit(input_tree)

# Generated at 2022-06-21 17:51:19.600817
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = ast.parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literal\n'
        '\n'
        'import sys'
    )
    assert format_ast(Python2FutureTransformer().visit(ast.parse('import sys'))) == format_ast(expected)

# Generated at 2022-06-21 17:51:25.995167
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("print('foo')")
    tree.body[0].value.func.id = 'print_function'
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print_function('foo')
    """))

# Generated at 2022-06-21 17:51:27.672411
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the validity of the constructor of class
    Python2FunctorTransformer.
    """
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:32.638939
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert 'from __future__ import absolute_import' in imports.get_body(future=
                                                                       '__future__')
    assert 'from __future__ import division' in imports.get_body(future='__future__')
    assert 'print_function' in imports.get_body(future='__future__')
    assert 'unicode_literals' in imports.get_body(future='__future__')

# Generated at 2022-06-21 17:51:41.086745
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ast_toolbox.utils import ast_dump
    import textwrap

    raw_code = textwrap.dedent('''
        def foo():
            pass
    ''')
    root_node = ast.parse(raw_code)
    transformer = Python2FutureTransformer()
    root_node = transformer.visit(root_node)
    assert transformer.tree_changed == True
    dumped = ast_dump(root_node, include_attributes=True)
    from .test_parser import Python2ParserTestCase  # avoid circular import
    assert dumped == Python2ParserTestCase.dump_tree(root_node)

# Generated at 2022-06-21 17:51:49.342059
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent('''\
        def foo():
            pass
    '''))
    nt = Python2FutureTransformer()
    result = nt.visit(node)
    expected = textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo():
            pass
    ''')
    assert astunparse.unparse(result).strip() == expected

# Generated at 2022-06-21 17:52:18.950535
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert isinstance(obj, Python2FutureTransformer)



# Generated at 2022-06-21 17:52:20.531222
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert(transformer is not None)



# Generated at 2022-06-21 17:52:27.376728
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..tests.resources.source.python2 import PY2_MODULE_SOURCE
    from ..utils.ast import print_ast
    from ..utils.source import ast_to_source
    from .Python2FutureTransformer import Python2FutureTransformer
    from .Python2FutureTransformer import Python2FutureTransformer

    tree = source_to_ast(PY2_MODULE_SOURCE)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    source = ast_to_source(tree)
    print(source)
    assert transformer._tree_changed == True
    p = parser.expr("2+2")
    t = ast.Expression(body=p.expr)

# Generated at 2022-06-21 17:52:28.013707
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:52:32.190210
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    f = open("_test_Python2FutureTransformer.py", mode='w')
    f.write("print(2 / 3)")
    f.close()
    with open("_test_Python2FutureTransformer.py", "r") as source:
        tree = ast.parse(source.read())
    pt = Python2FutureTransformer()
    pt.visit(tree)
    s = astor.codegen.to_source(tree, indent_with=' '*4)
    # print(s)
    assert s == """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(2 / 3)
"""
    os.remove("_test_Python2FutureTransformer.py")

# Generated at 2022-06-21 17:52:42.682983
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import textwrap
    from ..utils.example_code_transformer import ExampleCodeTransformer
    from .Python2FutureTransformer import Python2FutureTransformer

    snippet = textwrap.dedent('''
        def f(x):
            return x + 1
    ''')
    expected_snippet = textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def f(x):
            return x + 1
    ''')
    tree = ast.parse(snippet)
    expected_tree = ast.parse(expected_snippet)
    ExampleCodeTransformer.apply(tree, [Python2FutureTransformer])
   

# Generated at 2022-06-21 17:52:44.709142
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import get_node


# Generated at 2022-06-21 17:52:53.134608
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    # 1. Test on a Module object
    m = astor.parse_file(__file__.replace('.py', '.snippet.py'))
    transformer = Python2FutureTransformer()
    transformer.visit(m)
    assert transformer._tree_changed is True
    assert astor.to_source(m).count('from future') == 4
    # 2. Test on an incorrect type, that should raise a TypeError
    transformer = Python2FutureTransformer()
    with pytest.raises(TypeError) as err:
        transformer.visit(ast.ClassDef())
    assert err.match('expected a <class \'typed_ast.ast3.Module\'>, '
                     'got a <class \'typed_ast.ast3.ClassDef\'> instead')
    # 3. Test on an incorrect

# Generated at 2022-06-21 17:52:54.027504
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""

    Python2FutureTransformer()

# Generated at 2022-06-21 17:52:56.613732
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): 
    Python2FutureTransformer()



# Generated at 2022-06-21 17:54:06.253966
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    example = ("import os\n" +
               "x = 'hello world \\n'\n"
               "z = '''another hello \\n'''\n")
    output = Python2FutureTransformer.run(example)
    assert output.strip() == (imports.get_body(future='__future__') +
                              example).strip()
    assert ast.parse(example).body == ast.parse(output).body

# Generated at 2022-06-21 17:54:09.640142
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    import ast
    node = ast.parse('print "Hello World!"')
    print(ast.dump(node))
    new_node = transformer.visit(node)  # type: ignore
    print(ast.dump(new_node))


if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-21 17:54:13.413899
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert (
        Python2FutureTransformer.visit_Module(Python2FutureTransformer(), ast.parse('pass'))
        ==
        imports.get_ast(future='__future__')
    )

# Generated at 2022-06-21 17:54:15.311331
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)


# Generated at 2022-06-21 17:54:17.029845
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer()
    assert transpiler.target == (2, 7)



# Generated at 2022-06-21 17:54:17.800465
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:54:25.713883
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("a = 3\nb = '4'")
    t = Python2FutureTransformer()
    new_tree = t.visit(tree)
    assert isinstance(new_tree, ast.Module)
    assert hasattr(new_tree, 'body')
    assert isinstance(new_tree.body[0], ast.ImportFrom)
    assert isinstance(new_tree.body[1], ast.ImportFrom)
    assert isinstance(new_tree.body[2], ast.ImportFrom)
    assert isinstance(new_tree.body[3], ast.ImportFrom)
    assert isinstance(new_tree.body[4], ast.Assign)

# Generated at 2022-06-21 17:54:31.115862
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from test_app.fixtures.snippets import python2
    transformer = Python2FutureTransformer(target_info=None)
    result = transformer.visit(python2.get_ast())
    assert isinstance(result, ast.Module)
    assert len(result.body) == 5
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-21 17:54:31.941772
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:54:40.675664
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("class A:\n    pass")
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert len(module.body) == 6
    assert module.body[0].body[0].value.s == "absolute_import"
    assert module.body[1].body[0].value.s == "division"
    assert module.body[2].body[0].value.s == "print_function"
    assert module.body[3].body[0].value.s == "unicode_literals"
    assert module.body[4].name == "A"
    assert module.body[5].name == "Pass"