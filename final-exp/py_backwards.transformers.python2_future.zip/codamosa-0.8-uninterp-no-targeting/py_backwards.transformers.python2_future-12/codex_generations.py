

# Generated at 2022-06-21 17:46:06.890173
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True

# Generated at 2022-06-21 17:46:11.865637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    transformer = Python2FutureTransformer()
    module = ast.parse('print("Hello World!")\n')
    module = transformer.visit(module)
    assert transformer._tree_changed
    assert module.body[0].module == '__future__'
    assert module.body[1].module == '__future__'
    assert module.body[2].module == '__future__'
    assert module.body[3].module == '__future__'

# Generated at 2022-06-21 17:46:12.820031
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tr = Python2FutureTransformer()
    assert tr.target == (2, 7)


# Generated at 2022-06-21 17:46:20.665663
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_object = Python2FutureTransformer()
    assert class_object._tree_changed is False

    node = ast.Module()
    node = class_object.visit_Module(node)
    assert class_object._tree_changed is True
    assert len(node.body) == 4
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ImportFrom)
    assert isinstance(node.body[2], ast.ImportFrom)
    assert isinstance(node.body[3], ast.ImportFrom)
    assert node.body[0].module == 'future'
    assert node.body[1].module == 'future'
    assert node.body[2].module == 'future'
    assert node.body[3].module == 'future'
    assert node.body

# Generated at 2022-06-21 17:46:28.862050
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("for x in range(0, 10):\n    print(x)\n", "<string>")
    t = Python2FutureTransformer()
    t.visit(tree)
    expected = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
for x in range(0, 10):
    print(x)
""", "<string>")
    assert ast.dump(tree, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-21 17:46:39.235685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    # Setup
    node = ast.parse('x = 2')
    node.body = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    transformer = Python2FutureTransformer()

    # Act
    transformed_node = transformer.visit(node)

    # Assert
    assert type(transformed_node.body[0]) == ast.ImportFrom
    assert type(transformed_node.body[0].names[0]) == ast.alias
    assert transformed_node.body[0].names[0].name == 'absolute_import'
    assert type(transformed_node.body[0].names[1]) == ast.alias
    assert transformed

# Generated at 2022-06-21 17:46:40.044509
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:46:44.816325
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import get_test_data
    from ..utils import get_ast
    source = get_test_data('test_python_2/test_python_2_future_import.py')
    expected = get_test_data('test_python_2/test_python_2_future_import_out.py')
    assert Python2FutureTransformer.get_transformed_ast(source) == get_ast(expected)

# Generated at 2022-06-21 17:46:45.859789
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:46:48.461386
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class Python2FutureTransformerTest():
        def test_init(self):
            pt = Python2FutureTransformer({})

    obj = Python2FutureTransformerTest()
    obj.test_init()


# Generated at 2022-06-21 17:46:54.723943
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, ast.NodeTransformer)
    assert isinstance(x, Python2FutureTransformer)
    assert x.tree_changed == False
    assert x.target == (2, 7)

# Generated at 2022-06-21 17:47:02.989645
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    sample_input_code = """
    x = 2
    """
    expected_output_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 2
    """
    expected_program_tree = parse(expected_output_code)
    program_tree = parse(sample_input_code)
    transformer = Python2FutureTransformer()
    new_program_tree = transformer.visit(program_tree)
    assert new_program_tree == expected_program_tree

# Generated at 2022-06-21 17:47:06.068444
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse("print('foo')")
    assert Python2FutureTransformer().visit(m).body[0].value.s == "foo"
    assert Python2FutureTransformer().visit(m).body[0].s == "foo"


# Generated at 2022-06-21 17:47:11.885133
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def check(code):
        expected_code = imports() + code
        ast_obj = ast.parse(code)
        new_ast_obj = Python2FutureTransformer().visit(ast_obj)  # type: ignore
        new_code = astunparse.unparse(new_ast_obj)
        assert new_code == expected_code

    # 1. Test code with only variables and function calls
    check('')
    check('abs(-1)\n')
    check('a = abs(-1)\n')
    check('a = abs(-1)\nb = abs(-1)*2\n')
    check('def foo(a):\n    return a**2\n')
    check('def foo(a):\n    return a**2\n\ndef bar(a):\n    return a**3\n')



# Generated at 2022-06-21 17:47:14.212344
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-21 17:47:23.861122
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """
    x = 1
    y = 2
    z = x + y
    print(z)
    """

    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree).startswith('from __future__ import absolute_import')
    assert astor.to_source(tree).startswith('from __future__ import division')
    assert astor.to_source(tree).startswith('from __future__ import print_function')
    assert astor.to_source(tree).startswith('from __future__ import unicode_literals')
    print(astor.to_source(tree))

# Generated at 2022-06-21 17:47:24.862137
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()

# Generated at 2022-06-21 17:47:35.595574
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_test_case = {'args': [(ast.Module(
        body=[ast.Expr(value=ast.Str(s='test'))]), {'future': '__future__'})]}
    snippet_test_case_ref = {'result': [ast.Module(body=[
        ast.ImportFrom(module='__future__', names=[
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)
        ], level=0),
        ast.Expr(value=ast.Str(s='test'))
    ])], 'target': (2, 7)}

# Generated at 2022-06-21 17:47:41.138005
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import check_transformer, module_header

    check_transformer(Python2FutureTransformer, module_header, """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        # Hello world
        print("Hello world")
    """)

# Generated at 2022-06-21 17:47:47.524565
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def sample_input(future):
        def foo():
            pass

    @snippet
    def sample_output(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

        def foo():
            pass

    transformer = Python2FutureTransformer()
    node = ast.parse(sample_input.dedent())
    transformer.visit(node)
    expected = ast.parse(sample_output.dedent())
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:47:54.438237
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Tests that the Python2FutureTransformer is constructed properly."""
    f = Python2FutureTransformer()
    assert f.target == (2, 7)


# Generated at 2022-06-21 17:47:55.641700
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:48:02.612580
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('import sys')
    Python2FutureTransformer().visit(module)
    assert ast.dump(module) == \
        "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Import(names=[alias(name='sys', asname=None)])])"

# Generated at 2022-06-21 17:48:10.761415
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('assert(True)')
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Assert)

    t = Python2FutureTransformer()
    new_node = t.visit(node)

    assert isinstance(new_node.body[0], ast.ImportFrom)
    assert new_node.body[0].module == '__future__'
    assert len(new_node.body[0].names) == 4
    assert isinstance(new_node.body[1], ast.Assert)

# Generated at 2022-06-21 17:48:20.099075
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import Transformer
    from ..parser import parse
    import textwrap
    source = textwrap.dedent("""
    def func():
        pass
    """)
    tree = parse(source, 2)  # type: ignore
    tree = Transformer(Python2FutureTransformer).visit(tree)
    assert tree.body[0].body[0].name == 'absolute_import'
    assert tree.body[0].body[1].name == 'division'
    assert tree.body[0].body[2].name == 'print_function'
    assert tree.body[0].body[3].name == 'unicode_literals'
    assert tree.body[1].name == 'func'

# Generated at 2022-06-21 17:48:25.778508
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import astor
    tree_before = ast.parse("print('Hello')")
    tree_after = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('Hello')\n")
    t = Python2FutureTransformer()
    tree_new = t.visit(tree_before)
    assert astor.to_source(tree_new) == astor.to_source(tree_after)
    assert t._tree_changed

# Generated at 2022-06-21 17:48:30.950669
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("print('71')")
    b = Python2FutureTransformer()
    b.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\n\nprint('71')"))

# Generated at 2022-06-21 17:48:33.058235
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False
    assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:48:38.775347
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import parse

    tree = parse('x = 5')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert tree.body[0].value.s == 'absolute_import'
    assert tree.body[1].value.s == 'division'
    assert tree.body[2].value.s == 'print_function'
    assert tree.body[3].value.s == 'unicode_literals'
    assert tree.body[4].value == 5
    
        

# Generated at 2022-06-21 17:48:40.486560
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:48:53.731036
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('1 + 1')
    t = Python2FutureTransformer()
    assert t.visit(tree) == ast.parse(
        'from __future__ import absolute_import\nfrom __future__ import division\n'
        'from __future__ import print_function\nfrom __future__ import unicode_literals\n1 + 1'
    )

# Generated at 2022-06-21 17:48:59.154755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import get_ast

    source = """
    pass
    """.strip()

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    pass
    """.lstrip()

    ast = get_ast(source)
    transformed = Python2FutureTransformer().visit(ast)
    transformed = astor.tostring(transformed)
    assert transformed == expected

# Generated at 2022-06-21 17:49:06.270634
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("print('hello world')")
    Python2FutureTransformer().visit(node)
    expected_node = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('hello world')")
    assert ast.dump(node, annotate_fields=False) == ast.dump(expected_node, annotate_fields=False)


# Generated at 2022-06-21 17:49:14.806465
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..exceptions import TransformError
    from ..utils.ast import to_source

    tree = ast.parse("""
    print('Hello, World!')
    """)
    try:
        node = Python2FutureTransformer()(tree)
    except TransformError:
        pass
    else:
        raise RuntimeError('should raise TransformError')
    assert to_source(node) == """
# coding: utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


print('Hello, World!')
"""

# Generated at 2022-06-21 17:49:16.278599
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-21 17:49:17.717077
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-21 17:49:23.156041
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import python_modernize

    t = Python2FutureTransformer
    assert type(t) == type
    assert t.target == (2, 7)
    assert t.target_versions == {(2, 7): python_modernize.PY27}

    t = Python2FutureTransformer()
    assert type(t) == t


# Unit tests for methods of class Python2FutureTransformer

# Generated at 2022-06-21 17:49:26.841629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the constructor of the class Python2FutureTransformer"""
    trans = Python2FutureTransformer(2.7)
    assert trans.target == (2, 7)



# Generated at 2022-06-21 17:49:35.216116
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    import textwrap
    from ufo.utils.testing import normalize_ast_dump

    node = ast3.parse("""
    import sys
    import os
    x = 5
    """)

    expected = ast3.parse(textwrap.dedent("""
    
    import sys
    import os
    x = 5
    """).lstrip())

    transformer = Python2FutureTransformer()
    actual = transformer.visit(node)
    assert normalize_ast_dump(actual) == normalize_ast_dump(expected)



# Generated at 2022-06-21 17:49:36.267589
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()


# Generated at 2022-06-21 17:49:59.222842
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    node = ast.parse("""
    import urllib
    import this
    """)
    # When
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    # Then
    assert transformer._tree_changed
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import urllib
import this"""
    assert clean_generated_code(node) == expected



# Generated at 2022-06-21 17:50:01.064663
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:50:02.553718
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:50:04.775016
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    c1 = Python2FutureTransformer()
    assert c1.target == (2, 7)



# Generated at 2022-06-21 17:50:08.182896
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    from ..utils import roundtrip_with_transformer

    code1 = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


x = 3
"""

    tree1 = roundtrip(code1, 'Module')
    tree2 = roundtrip_with_transformer(Python2FutureTransformer, code1, 'Module')
    assert tree1 == tree2


# Generated at 2022-06-21 17:50:16.253879
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source1 = """\
a = '1'
b = 2
    """
    source2 = """\
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals
a = '1'
b = 2
    """
    tree1 = ast.parse(source1)
    tree1 = Python2FutureTransformer().visit(tree1)
    tree2 = ast.parse(source2)
    assert ast_equals(tree1, tree2)


# Generated at 2022-06-21 17:50:23.352382
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    line = 'x=1\n'
    node = ast.parse(line)

    trans = Python2FutureTransformer()
    new_node = trans.visit(node)

    assert trans._tree_changed

    line2 = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx=1\n'
    node2 = ast.parse(line2)

    assert ast.dump(new_node) == ast.dump(node2)



# Generated at 2022-06-21 17:50:24.662751
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()



# Generated at 2022-06-21 17:50:25.943120
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 17:50:28.981260
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed == False
    assert transformer.target == (2, 7)
    assert repr(transformer) == 'Python2FutureTransformer()'

# Generated at 2022-06-21 17:51:05.537082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform
    s = """
        import sys
    """
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import sys
    """
    assert expected == transform(s, [Python2FutureTransformer])

# Generated at 2022-06-21 17:51:11.380401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer, Snippet

    class DummyImports(snippet, BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = self.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    before = ast.parse('''
if __name__ == "__main__":
    print("Hello, World!")
''')


# Generated at 2022-06-21 17:51:21.098419
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from testing.utils import update_dict
    from ..utils import get_name

    source = '''
    import os
    import sys
    '''
    tree = astor.parse_file(source)

    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)

    assert transformer._tree_changed is True

    # Get name of new module
    module = get_name(new_tree)


# Generated at 2022-06-21 17:51:21.778704
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-21 17:51:23.898733
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...tests import test_transformer
    from ..tests import test_python_2_future
    test_transformer(Python2FutureTransformer, 'future', test_python_2_future.__file__)

# Generated at 2022-06-21 17:51:31.683013
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Note: we assume Python 2
    # assert sys.version_info.major == 2

    # Test that we don't have the imports
    _, l_ext_imports = imports.get_tree(future='__future__',
                                        ext_imports=['s'])
    assert ast.dump(l_ext_imports) == (
        "[Import(names=[alias(name='s', asname=None)])]"
    )

    # Test that we can add the imports
    _, l_ext_imports = imports.get_tree(future='__future__',
                                        ext_imports=['s'])
    assert ast.dump(l_ext_imports) == (
        "[Import(names=[alias(name='s', asname=None)])]"
    )

# Generated at 2022-06-21 17:51:41.441109
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from onmt.inputters.text_dataset import _get_fields
    from onmt.utils.logging import init_logger, logger
    import onmt.opts as opts  # NOQA
    import onmt.inputters.text_dataset
    import onmt.translate.translator
    import onmt.modules.Embeddings
    import onmt.modules.GlobalAttention
    init_logger()
    opt = opts.parse_opt_test()

    onmt.inputters.text_dataset._get_fields = _get_fields
    opt.mode = "test"
    opt.model = "model"
    opt.src = "src.txt"
    opt.output = "output"
    opt.batch_size = 1
    opt.n_best = 1
    opt

# Generated at 2022-06-21 17:51:49.379004
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    
    assert hasattr(Python2FutureTransformer, 'target')
    assert hasattr(Python2FutureTransformer, 'visit_Module')
    
    tr = Python2FutureTransformer()
    mod = ast.parse('')
    expected_mod = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
    ''')
    assert mod == expected_mod

# Generated at 2022-06-21 17:51:57.052249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    future = ast.ImportFrom(module='__future__', 
        names=[
        ast.alias(
            name='absolute_import', 
            asname=None
        ), 
        ast.alias(
            name='division', 
            asname=None
        ), 
        ast.alias(
            name='print_function', 
            asname=None
        ), 
        ast.alias(
            name='unicode_literals', 
            asname=None
        )
    ], 
    level=0
)
    assert Python2FutureTransformer().visit_Module(future) == future


# Generated at 2022-06-21 17:51:58.910106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(ast.Module(body=[]))

# Generated at 2022-06-21 17:53:19.768405
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('print(1)')
    res = transformer.visit(tree)
    assert ast.dump(res) == ast.dump(ast.parse(imports('__future__') + ast.dump(tree)))

# Generated at 2022-06-21 17:53:25.816287
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source_code_to_ast import source_code_to_ast
    from asttokens import ASTTokens

    source = """def func():
    pass
"""
    atok = ASTTokens(source, parse=True)
    node = source_code_to_ast(atok)
    Python2FutureTransformer(atok).visit(node)

# Generated at 2022-06-21 17:53:30.440512
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    from ..utils.annotation_visitor import AnnotationVisitor

    transformer = AnnotationVisitor(
        ast.Module, Python2FutureTransformer
    )
    mod = ast.parse('x = 1')
    transformer.visit(mod)
    assert transformer.is_changed() == True



# Generated at 2022-06-21 17:53:32.353539
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-21 17:53:36.269403
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import ast
    import textwrap

    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    from typed_astunparse import dump
    from ast_transformer.transformer import Transformer


# Generated at 2022-06-21 17:53:42.992770
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:53:53.184260
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from typed_ast import ast3

    text = '''
import pandas as pd
print("This is method visit_Module of Python2FutureTransformer")'''

    tree = parse(text)
    future_transformer = Python2FutureTransformer()
    future_transformer.visit(tree)

    assert isinstance(tree, ast3.Module)
    assert len(tree.body) == 4
    assert isinstance(tree.body[0], ast3.ImportFrom)
    assert tree.body[0].names[0].name == 'absolute_import'
    assert isinstance(tree.body[1], ast3.ImportFrom)
    assert tree.body[1].names[0].name == 'division'
    assert isinstance(tree.body[2], ast3.ImportFrom)

# Generated at 2022-06-21 17:53:54.966813
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:53:56.779057
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()

# Generated at 2022-06-21 17:54:03.002144
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast3
    from ast_tools.passes.base import BaseNodeTransformer

    class NodeTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast3.Module) -> ast3.Module:
            self._tree_changed = True
            node.body = [ast3.Expr(ast3.Call(ast3.Name('test', ast3.Load()), [], []))] + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore
