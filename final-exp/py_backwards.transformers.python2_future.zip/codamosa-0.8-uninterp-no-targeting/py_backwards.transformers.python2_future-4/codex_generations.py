

# Generated at 2022-06-21 17:46:10.069542
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert not Python2FutureTransformer.tree_changed
    assert Python2FutureTransformer.target == (2, 7)
    asser

# Generated at 2022-06-21 17:46:19.623605
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class TestVisitor(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            node.body = [make_print('hello')] + node.body
            return self.generic_visit(node)  # type: ignore
    source = """
    a = 'a'
    b = 'b'
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print 'hello'
    a = 'a'
    b = 'b'
    """
    source = source.lstrip('\n')
    expected = expected.lstrip('\n')
    tree = ast.parse(source)
    Python2FutureTransformer().vis

# Generated at 2022-06-21 17:46:22.627902
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)

# Generated at 2022-06-21 17:46:27.796340
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('pass')
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer.target == (2, 7)
    assert isinstance(new_tree, ast.Module)
    assert len(new_tree.body) == len(imports.get_body()) + 1
    assert new_tree.body[0].module == '__future__'
    assert new_tree.body[0].names[0].name == 'absolute_import'
    assert new_tree.body[1].module == '__future__'
    assert new_tree.body[1].names[0].name == 'division'
    assert new_tree.body[2].module == '__future__'

# Generated at 2022-06-21 17:46:34.187288
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = parse("""
if True:
    pass
""")
    Python2FutureTransformer().visit(tree)
    expected_tree = parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
if True:
    pass
""")
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-21 17:46:41.441418
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module, Str
    from typed_astunparse import unparse
    import sys
    if sys.version_info[:2] == (3, 5):
        # astunparse is broken on Python 3.5
        return
    node = Module(
        body=[Str('Python2FutureTransformer')]
    )
    Python2FutureTransformer().visit(node)
    expected = imports.get_source(future='__future__').strip() + '\n\'Python2FutureTransformer\'' + '\n'
    actual = unparse(node).strip()
    assert expected == actual

# Generated at 2022-06-21 17:46:48.815236
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fake import FakeFile

    content = """
    """
    file = FakeFile(content, path="a.py")
    ast_tree = file.ast
    v = Python2FutureTransformer()  # type: ignore
    v.visit(ast_tree)
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

    """
    assert ast_tree.body == ast.parse(expected).body
    assert file.path == "a.py"



# Generated at 2022-06-21 17:46:51.371161
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..registry import registry
    t = Python2FutureTransformer(registry)
    assert t.target == (2, 7)


# Generated at 2022-06-21 17:46:56.967370
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import node_visit, fix_missing_locations

    ast_tree = ast.parse(imports.get_source(future='__future__'))
    assert node_visit(Python2FutureTransformer, ast_tree)
    fix_missing_locations(ast_tree)
    assert node_visit(Python2FutureTransformer, ast_tree) == ast_tree

# Generated at 2022-06-21 17:47:00.578411
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse
    code = """
    print('Hello World')
    print 2
    """
    module = ast.parse(code)
    Python2FutureTransformer(module).visit(module)
    ast.fix_missing_locations(module)
    print(astunparse.unparse(module))

# Generated at 2022-06-21 17:47:10.582737
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    import ast
    from ast import Module
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports

# Generated at 2022-06-21 17:47:22.318794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import dump_ast, strip_whitespaces
    from .fixtures import Python2FutureTransformer_visit_Module

    source = strip_whitespaces(Python2FutureTransformer_visit_Module.source)
    expected = strip_whitespaces(Python2FutureTransformer_visit_Module.expected)

    source_ast = ast.parse(source)
    expected_ast = ast.parse(expected)
    transformer = Python2FutureTransformer()
    assert transformer.is_target_version(2, 7)
    assert transformer.is_target_version(3, 3)
    assert transformer.is_target_version(3, 7)
    assert transformer.is_target_version(3, 8)
    assert not transformer.is_target_version(3, 9)


# Generated at 2022-06-21 17:47:30.594090
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    mod = ast.parse("print('hello, world!')")
    mod = Python2FutureTransformer().visit(mod)  # type: ignore
    expected = ast.parse("from __future__ import absolute_import\n"
                         "from __future__ import division\n"
                         "from __future__ import print_function\n"
                         "from __future__ import unicode_literals\n"
                         "\n"
                         "print('hello, world!')")
    assert astor.to_source(mod) == astor.to_source(expected)

# Generated at 2022-06-21 17:47:31.977429
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:47:41.673646
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    transformer = Python2FutureTransformer()
    module = astor.parse_file('tests/fixtures/files/Python2.py')
    new_module = transformer.visit_Module(module)
    assert astor.to_source(new_module) == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
    
import sys, os
if __name__ == "__main__":
    print("Hello World")
    for _ in range(10):
        print("Have a nice day")
    raise ImportError("Error")
'''

# Generated at 2022-06-21 17:47:43.393746
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import test_transformer
    test_transformer.test(Python2FutureTransformer)

# Generated at 2022-06-21 17:47:45.533949
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.future == '__future__'

# Generated at 2022-06-21 17:47:53.871556
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    node = ast.parse("x = 3")
    transformer = Python2FutureTransformer()

    # When
    transformer.visit(node)

    # Then
    imports_node = node.body[0]
    assert isinstance(imports_node, ast.ImportFrom)
    assert imports_node.module == '__future__'
    assert len(imports_node.names) == 4
    assert imports_node.names[0].name == 'absolute_import'
    assert imports_node.names[1].name == 'division'
    assert imports_node.names[2].name == 'print_function'
    assert imports_node.names[3].name == 'unicode_literals'



# Generated at 2022-06-21 17:47:59.638315
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    source = 'class Foo: pass'  
    tree = ast.parse(source)
    tx = Python2FutureTransformer()  # type: ignore
    tx.visit(tree)
    target_source = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nclass Foo: pass"
    assert target_source == ast.unparse(tree)

# Generated at 2022-06-21 17:48:08.310938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    source = """#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
a = 1
"""
    tree = ast.parse(source)
    expected_source = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
a = 1
"""
    expected_tree = ast.parse(expected_source)
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 17:48:14.078233
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # class should be defined with name Python2FutureTransformer
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"



# Generated at 2022-06-21 17:48:17.884200
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    tree = parse('module()')
    actual = Python2FutureTransformer().visit(tree)
    expected = parse(str(imports.get_body(future='__future__') + tree.body))  # type: ignore
    assert astor.to_source(actual) == astor.to_source(expected)


# Generated at 2022-06-21 17:48:20.253738
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(python_version=(2, 7))
    assert transformer._tree_changed is False
    module = ast.Module()
    assert transformer.visit(module) == module
    assert transformer._tree_changed is True



# Generated at 2022-06-21 17:48:27.719387
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformerTest
    import ast
    class Module(ast.AST):
        _fields = ('body',)

    class Str(ast.AST):
        _fields = ('s',)

    class Pass(ast.AST):
        pass

    class Print(ast.AST):
        _fields = ('dest', 'values', 'nl')
    
    class FunctionDef(ast.AST):
        _fields = ('name', 'args', 'body', 'decorator_list', 'returns')

    class Assign(ast.AST):
        _fields = ('targets', 'value')

    class BinOp(ast.AST):
        _fields = ('left', 'op', 'right')


# Generated at 2022-06-21 17:48:29.084944
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7)) is not None


# Generated at 2022-06-21 17:48:33.057282
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..python_tool_test import PythonToolTest
    test = PythonToolTest(Python2FutureTransformer)

# Generated at 2022-06-21 17:48:40.878902
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    module = ast.parse("""
    print("Hello world")
    """)
    module = transformer.visit(module)

    result = ast.dump(module)


# Generated at 2022-06-21 17:48:47.542112
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("")
    new_node = transformer.visit(node)
    assert "absolute_import" in ast.dump(new_node)
    assert "division" in ast.dump(new_node)
    assert "print_function" in ast.dump(new_node)
    assert "unicode_literals" in ast.dump(new_node)

# Generated at 2022-06-21 17:48:53.818555
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # given
    code = "import six\nfrom six.moves import map"

    # when
    module = ast.parse(code)
    Python2FutureTransformer(module).visit(module)

    # then
    assert str(module).strip() == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport six\nfrom six.moves import map"



# Generated at 2022-06-21 17:48:59.357417
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    from pprint import pprint
    from future.utils import PY2
    if not PY2:
        print("Need Python 2 for this test")
        sys.exit(0)

    from astor.codegen import to_source
    from astor import code_to_ast
    from ..transformer import MetaAstWrapper


# Generated at 2022-06-21 17:49:07.713058
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'import ast'
    t = Python2FutureTransformer().visit(ast.parse(code, '<test>'))
    ref = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport ast'
    assert astor.to_source(t).strip() == ref.strip()

# Generated at 2022-06-21 17:49:08.526850
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-21 17:49:17.415228
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import tempfile
    from typed_ast import ast3 as ast

    current_dir = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(current_dir, '../transformers/sample.py')

    with open(file_path) as f:
        code = f.read()

    try:
        tree = ast.parse(code)
        visitor = Python2FutureTransformer()
        visitor.visit(tree)
        assert visitor._tree_changed == True
    except Exception as e:
        raise e

# Generated at 2022-06-21 17:49:23.263042
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('print("hello world", end="")')
    expected = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\n' + 'print("hello world", end="")')
    actual = Python2FutureTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-21 17:49:29.442754
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""class Test:
    pass""")
    tree = Python2FutureTransformer().visit(tree)
    # Test that __future__ is added to the module

# Generated at 2022-06-21 17:49:40.813292
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    from typed_ast import ast3 as ast

    body = [
        ast.Assign(
            targets=[
                ast.Name(id='a', ctx=ast.Store())],
            value=ast.Num(n=42)),
        ast.FunctionDef(
            name='foo',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwarg=None,
                defaults=[]),
            body=[
                ast.Pass()],
            decorator_list=[],
            returns=None)
    ]
    node = ast.Module(
            body=body)

    # Act
    result = Python2FutureTransformer().visit(node)  # type: ignore

    # Assert
    assert isinstance(result, ast.Module)

# Generated at 2022-06-21 17:49:46.453963
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    module = ast.Module([])
    module_new = transformer.visit(node=module)
    assert isinstance(module_new, ast.Module)
    assert module_new.body == imports.get_body(future='__future__')
    assert transformer._tree_changed is True
    assert transformer._error_flag is False

# Generated at 2022-06-21 17:49:52.973706
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os; print(os.listdir())
    ''')
    n = Python2FutureTransformer().visit(m)
    o = ast.parse('''
    import os
    
    
    import os; print(os.listdir())
    ''')
    assert ast.dump(o) == ast.dump(n)

# Generated at 2022-06-21 17:49:57.568237
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")
    transformed = Python2FutureTransformer().visit(module)  # type: ignore
    future = ast.parse(imports(future='__future__'))  # type: ignore
    assert transformed.body[0:4] == future.body  # type: ignore

# Generated at 2022-06-21 17:50:04.819794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # import typing
    node_to_transform = ast.parse("import typing")
    expected_result = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport typing")
    tr = Python2FutureTransformer(ast.Module([node_to_transform]))
    ast_result = tr.visit(node_to_transform)
    assert ast.dump(ast_result) == ast.dump(expected_result)
    assert tr._tree_changed is True

# Generated at 2022-06-21 17:50:20.637138
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..mock import mock_ast_node
    from .test_base import BaseNodeTransformerTest
    from ast_tools import parse
    from ast_tools import ast_pprint
    from ast_tools.transforms import Python2FutureTransformer
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals


# Generated at 2022-06-21 17:50:22.481372
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj.target == (2,7)


# Generated at 2022-06-21 17:50:27.922025
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('assert True')
    node = transformer.visit(tree)
    assert ast.dump(node) == ast.dump(ast.parse('from __future__ import absolute_import\n' +
                                                'from __future__ import division\n' +
                                                'from __future__ import print_function\n' +
                                                'from __future__ import unicode_literals\n' +
                                                '\n' +
                                                'assert True'))

# Generated at 2022-06-21 17:50:29.831312
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:50:38.313463
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    a = 'a'
    b = 'b'
    c = 'c'
    """
    tree = ast.parse(code)  # type: ast.Module
    Python2FutureTransformer().visit(tree)
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    a = 'a'
    b = 'b'
    c = 'c'
    """
    actual = astunparse.unparse(tree).strip()
    assert actual == expected

# Generated at 2022-06-21 17:50:42.886075
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    python_version = (2, 7)
    transformer = Python2FutureTransformer(python_version)
    # When
    result = transformer.translate_tree(ast.parse('1 + 1'))
    # Then
    assert result == '# -*- coding: utf-8 -*-\n"Imports from __future__"\n1 + 1'

# Generated at 2022-06-21 17:50:50.143629
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import generate_code
    from .base import BaseNodeTransformerTestCase
    from .identity import IdentityTransformer
    
    class TestCase(BaseNodeTransformerTestCase):
        target = (2, 7)
        transformer = Python2FutureTransformer
        
        def test_Module(self):
            """Test that it prepends module with imports from __future__."""
            node = ast.parse('''\
a = 1
''')
            node = self.transformer(target=2, transformer=IdentityTransformer).visit(node)

# Generated at 2022-06-21 17:50:55.715547
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse
    python2_module = ast.parse(
        '''
        a = 1
        b = 2
        print(a + b)
        '''
    )
    python2_module_transformed = Python2FutureTransformer().visit(python2_module)
    assert astunparse.unparse(python2_module_transformed) == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
b = 2
print(a + b)'''

# Generated at 2022-06-21 17:51:05.503416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse

    node_tree = parse('print(0)')
    expected_tree = parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(0)')
    expected_changed = True

    transformer = Python2FutureTransformer(node_tree)
    result_tree = transformer.visit(node_tree)
    result_changed = transformer.tree_changed()

    expected_tree = ast.fix_missing_locations(expected_tree)
    result_tree = ast.fix_missing_locations(result_tree)
    assert ast.dump(result_tree) == ast.dump(expected_tree)
    assert result_changed == expected_changed

# Generated at 2022-06-21 17:51:06.273980
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:23.172670
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_module_from_code
    from ..utils.fake_future import fake_future
    
    source = "print('a')"
    module, _ = make_module_from_code(source)
    module_transformed = Python2FutureTransformer(fake_future).visit(module)
    
    assert module_transformed == fake_future.get_module(source)

# Generated at 2022-06-21 17:51:29.221853
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse("print('hello world')")
    Python2FutureTransformer().transform(mod)
    assert str(mod) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint('hello world')"

# Generated at 2022-06-21 17:51:30.301368
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-21 17:51:40.338023
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class ModuleNode(ast.Module):
        def __init__(self, body):
            self.body = body

    class PrintNode(ast.Print):
        def __init__(self, value):
            self.values = value

    class StrNode(ast.Str):
        def __init__(self, value):
            self.s = value

    print_node = PrintNode([StrNode('Hello, World!')])
    module_node = ModuleNode([print_node])

# Generated at 2022-06-21 17:51:44.395291
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import FunctionDef, Name, Attribute, Str, Load
    from pprint import pprint
    import typed_astunparse

    node = Module([])
    res = Python2FutureTransformer().visit(node)
    pprint(res)
    assert typed_astunparse.dump(res) == imports.get_code(future='__future__')

# Generated at 2022-06-21 17:51:46.547044
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-21 17:51:52.128093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    transformer = Python2FutureTransformer(None)
    node = ast.parse("x = 2")
    transformer.visit_Module(node)

    assert transformer.tree_changed is True
    assert transformer._tree_changed is True  # pylint: disable=protected-access

    expected = ast.parse(inspect.cleandoc(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        x = 2
        """
    ))

    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:51:55.984544
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('var1 = 1')
    updated_tree = transformer.visit(tree)
    print(astor.to_source(updated_tree))
    assert astor.to_source(updated_tree).startswith("from __future__ import absolute_import\n")

# Generated at 2022-06-21 17:51:59.779425
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
        Tests the constructor of the class Python2FutureTransformer to ensure that it sets the
        _tree_changed flag to false as well as the nodes attribute to None. This would indicate
        that the object was properly initialized.
    """
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed == False
    assert transformer.nodes == None


# Generated at 2022-06-21 17:52:04.046049
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from py2to3.main import Python2to3
    tree = parse('print(3/2)', mode='exec')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    code = compile(tree, '', mode='exec')
    exec(code)

# Generated at 2022-06-21 17:52:30.799909
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass
    # TODO: write unit-test for method visit_Module in class Python2FutureTransformer

# Generated at 2022-06-21 17:52:41.803944
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test case verifies the output of `Python2FutureTransformer`
    """

    assert Python2FutureTransformer(target=(2, 7)).target == (2, 7)
    assert Python2FutureTransformer(target=(2, 0)).target == (2, 0)

    transformer = Python2FutureTransformer(target=(2, 7))
    transformer._tree_changed = False
    node = transformer.visit_Module(ast.parse('import numpy as np'))

    assert transformer._tree_changed == True

    src_code = compile(node, filename='<ast>', mode='exec')

# Generated at 2022-06-21 17:52:48.654070
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class EmptyTransformer(BaseNodeTransformer):
        target = (2, 7)

        def visit_Module(self, node):
            # ensure Module node is returned for assertion
            return node

    node = ast.parse("import sys")
    expected = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport sys")

    assert expected.body == EmptyTransformer().visit(node).body

# Generated at 2022-06-21 17:52:51.395779
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # GIVEN
    pt = ast.parse('def test():\n    pass')
    pt = ast.fix_missing_locations(pt)
    transformer = Python2FutureTransformer
    # WHEN
    transformed_tree = transformer(pt)
    # THEN
    assert transformed_tree._tree_changed
    assert imports.get_body(future='__future__') == [i.value for i in transformed_tree.body[0:4]]

# Generated at 2022-06-21 17:53:01.740023
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..tree import parse
    from .printing import Printer
    from .unflatten import Unflattener
    from .to_function_assignments import ToFunctionAssignments
    from .to_single_assignments import ToSingleAssignments
    from .to_async_function_assignments import ToAsyncFunctionAssignments
    from .to_async_generator_function_assignments import ToAsyncGeneratorFunctionAssignments
    from .to_sync_function_assignments import ToSyncFunctionAssignments
    from .to_sync_generator_function_assignments import ToSyncGeneratorFunctionAssignments
    from .to_async_for import ToAsyncFor
    from .to_async_with import ToAsyncWith
    from .to_while import ToWhile

# Generated at 2022-06-21 17:53:05.040905
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    node = ast.Module()
    assert isinstance(node, ast.Module)

    transformer = Python2FutureTransformer(node)
    assert isinstance(transformer, Python2FutureTransformer)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:53:06.817659
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-21 17:53:18.064184
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("pass")
    node = ast.fix_missing_locations(node)
    tr = Python2FutureTransformer()
    tr.visit(node)
    node = ast.parse(tr.get_code())
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ImportFrom)
    assert isinstance(node.body[2], ast.ImportFrom)
    assert isinstance(node.body[3], ast.ImportFrom)
    assert node.body[0].module == "__future__"
    assert node.body[0].names[0].name == "absolute_import"
    assert node.body[1].names[0].name == "division"
    assert node.body[2].names[0].name == "print_function"

# Generated at 2022-06-21 17:53:24.538164
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ast_ = ast.parse('print("hello, world!")')
    t = Python2FutureTransformer()
    r = t.visit(ast_)
    assert r.body[0].names == [ast.alias(name='absolute_import', asname=None),
                               ast.alias(name='division', asname=None),
                               ast.alias(name='print_function', asname=None),
                               ast.alias(name='unicode_literals', asname=None)]
    assert r.body[1].value == ast.Str(s='hello, world!')

# Generated at 2022-06-21 17:53:26.803881
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.disabled is False
    assert transformer.ctx is None


# Generated at 2022-06-21 17:54:20.389549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor  # type: ignore
    import typed_ast.ast3  # type: ignore
    p2ft = Python2FutureTransformer()

# Generated at 2022-06-21 17:54:22.206706
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None
    assert transformer.target == (2, 7)


# Generated at 2022-06-21 17:54:27.168046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    src = """
x = 6
"""
    tr = Python2FutureTransformer()
    new_tree = tr.visit(ast.parse(src))
    assert "from __future__ import absolute_import" in astunparse.unparse(new_tree)
    assert "from __future__ import division" in astunparse.unparse(new_tree)
    assert "from __future__ import print_function" in astunparse.unparse(new_tree)
    assert "from __future__ import unicode_literals" in astunparse.unparse(new_tree)

# Generated at 2022-06-21 17:54:37.785302
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-21 17:54:38.679946
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-21 17:54:43.083339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """\
"""

    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
"""

    node = ast.parse(source)
    Python2FutureTransformer().visit(node)
    assert_source(node, expected)



# Generated at 2022-06-21 17:54:44.154264
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-21 17:54:49.598409
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..convert import Python2FutureTransformer
    import ast
    import textwrap
    source = textwrap.dedent("""
        def get_file(self):
            return self._file
    """)
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)  # type: ignore
    assert tree == ast.parse(textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def get_file(self):
            return self._file
    """))

# Generated at 2022-06-21 17:54:55.282325
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    ast_node = ast.parse('print(2)')
    import_node = Python2FutureTransformer()
    import_node.visit(ast_node) # type: ignore

    assert type(ast_node) == ast.Module
    assert len(ast_node.body) == 5

# Generated at 2022-06-21 17:54:59.508125
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("import os")
    trans = Python2FutureTransformer()
    trans.visit_Module(node)
    assert compile(node, filename="test", mode="exec")
    assert (trans.result() == 
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "import os\n"
        )