

# Generated at 2022-06-21 04:40:27.855756
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E9%9B%80%E9%9B%80%E9%9B%80%E9%9B%80') == u'\u96e0\u96e0\u96e0\u96e0'
    assert unicode_urldecode(u'%E9%9B%80%E9%9B%80%E9%9B%80%E9%9B%80', 'utf-8') == u'\u96e0\u96e0\u96e0\u96e0'

# Generated at 2022-06-21 04:40:29.605868
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    result = filter_obj.filters()
    assert result['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:40:39.959425
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foobar') == u'foobar'
    assert unicode_urldecode(u'foo%25bar') == u'foo%bar'
    assert unicode_urldecode(u'foo%3Abar') == u'foo:bar'
    assert unicode_urldecode(u'foo+bar') == u'foo+bar'
    assert unicode_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode(u'foo%2bb%61r') == u'foo+b%61r'
    assert unicode_urldecode(u'foo%2bb%61r') == u'foo+b%61r'

# Generated at 2022-06-21 04:40:48.967816
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo.org/') == u'http%3A//foo.org/'
    assert unicode_urlencode('http://foo.org/bar') == u'http%3A//foo.org/bar'
    assert unicode_urlencode('http://foo.org/bar?a=1&b=2') == u'http%3A//foo.org/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo.org/\u2603') == u'http%3A//foo.org/%E2%98%83'
    assert unicode_urlencode('http://foo.org/\u2603') == u'http%3A//foo.org/%E2%98%83'

# Generated at 2022-06-21 04:40:57.179804
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo.com/x?a=b c&d#bar') == b'http%3A//foo.com/x%3Fa%3Db%20c%26d%23bar'
    assert unicode_urlencode(u'http://foo.com/x?a=b c&d#bar', for_qs=True) == b'http%3A//foo.com/x%3Fa%3Db+c%26d%23bar'
    assert unicode_urlencode(u'!@#$') == b'%21%40%23%24%25'
    assert unicode_urlencode(u'!@#$', for_qs=True) == b'%21%40%23%24%25'
    assert unicode_urlencode(u'')

# Generated at 2022-06-21 04:41:04.328780
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode(u'/foo') == '/foo'
    assert unicode_urlencode(u'foo /bar') == 'foo+%2Fbar'
    assert unicode_urlencode(u'foo+bar') == 'foo%2Bbar'


# Unit tests for function unicode_urldecode

# Generated at 2022-06-21 04:41:13.720902
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_module_filter_module_class = FilterModule
    filters = ansible_module_filter_module_class.filters(ansible_module_filter_module_class)

    assert type(filters) is dict
    assert len(filters) == 2
    assert type(filters['urldecode']) is type(FilterModule.filters)  # pylint: disable=protected-access
    for filter in filters:
        assert callable(filters[filter])

# Generated at 2022-06-21 04:41:17.704278
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # urldecode test
    # TODO: Add urldecode tests
    # urlencode test
    # TODO: Add urlencode tests
    pass  # noqa

# Generated at 2022-06-21 04:41:25.570439
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    # Expected results for different test strings
    expected_results = {
        u'test': u'test',
        u'test%20test': u'test test',
        u'test+test': u'test test',
        u'%25%20%25': u'%25 %25',
    }
    # Actually run the tests
    for test_string, result in iteritems(expected_results):
        assert result == do_urldecode(test_string)

# Generated at 2022-06-21 04:41:34.100670
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('some%20test%C2%A0%20string%20') == u'some test\xa0 string '
    assert unicode_urldecode('some-test-string') == u'some-test-string'
    assert unicode_urldecode('some+test+string') == u'some+test+string'
    assert unicode_urldecode('%7Esome+test%2Dstring%24') == u'~some+test-string$'



# Generated at 2022-06-21 04:41:37.707288
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Hello%20World%21') == 'Hello World!'

# Generated at 2022-06-21 04:41:40.428970
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urldecode' in fm.filters()



# Generated at 2022-06-21 04:41:51.197579
# Unit test for function do_urlencode
def test_do_urlencode():
    import unittest

    class TestDoUrlencode(unittest.TestCase):
        # Tests for python2.7
        if not PY3:
            def test_urlencode_unicode(self):
                ustring = u'https://github.com/ansible/ansible/issues/10229?aaaaaaa=bbbbbbb'
                self.assertEqual(do_urlencode(ustring), ustring)

            def test_urlencode_unicode_bytes(self):
                ustring = u'https://github.com/ansible/ansible/issues/10229?aaaaaaa=bbbbbbb'
                self.assertEqual(do_urlencode(ustring.encode('utf-8')), ustring)

            def test_urlencode_unicode_list(self):
                u

# Generated at 2022-06-21 04:42:00.954984
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20d+f') == 'abc d f'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc+def') == 'abc def'
    assert unicode_urldecode('abc%2Fdef') == 'abc/def'
    assert unicode_urldecode('abc%2Fdef%20ghi') == 'abc/def ghi'
    assert unicode_urldecode('abc%2Bdef%20ghi') == 'abc+def ghi'
    assert unicode_urldecode('abc%c3%b1def%20ghi') == 'abcñdef ghi'

# Generated at 2022-06-21 04:42:01.773100
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert (True)

# Generated at 2022-06-21 04:42:03.891493
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:42:05.553692
# Unit test for constructor of class FilterModule
def test_FilterModule():
   filtermodule = FilterModule()
   assert filtermodule is not None


# Generated at 2022-06-21 04:42:09.842986
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'/') == u'%2F'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode(u'%2F') == u'/'

# Generated at 2022-06-21 04:42:15.232231
# Unit test for function do_urlencode
def test_do_urlencode():
    assert '2%2B2' == do_urlencode('2+2')
    assert 'k=v' == do_urlencode(dict(k='v'))
    assert 'k=v' == do_urlencode(('k', 'v'))

# Generated at 2022-06-21 04:42:22.136163
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('%20') == u' '
    if PY3:
        assert unicode_urldecode('Z%C3%BCrich') == u'Zürich'
    else:
        assert unicode_urldecode('Z%C3%BCrich') == u'Z\xc3\xbcrich'


# Generated at 2022-06-21 04:42:31.399528
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus as urldecode
    assert do_urldecode(u'dag%20wieers') == urldecode(u'dag%20wieers')
    assert do_urldecode(u'%2Fdag%2Fwieers%2F') == urldecode(u'%2Fdag%2Fwieers%2F')
    assert do_urldecode(u'%2Fdag%2Fwieers%2F') == urldecode(u'%2Fdag%2Fwieers%2F')

# Generated at 2022-06-21 04:42:37.616236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert f.filters()['urlencode'] == do_urlencode


# Unit tests for method unicode_urldecode of class FilterModule

# Generated at 2022-06-21 04:42:44.296542
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_text
    fm = FilterModule()
    assert fm.filters()['urldecode']('foo') == 'foo'
    assert fm.filters()['urldecode']('foo%20bar') == 'foo bar'
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('foo') == 'foo'
        assert fm.filters()['urlencode']('foo bar') == 'foo+bar'
        assert fm.filters()['urlencode'](u'fiø') == to_text(u'fi%C3%B8')
        assert fm.filters()['urlencode']('foo^bar') == u'foo%5Ebar'

# Generated at 2022-06-21 04:42:58.695044
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils.urlesc import (
        get_decoded_str,
        get_encoded_str,
        unquote,
        unquote_str,
    )

    assert get_decoded_str("charset%3Dutf-8") == "charset=utf-8"
    assert get_encoded_str("charset=utf-8") == "charset%3Dutf-8"
    assert unquote("charset%3Dutf-8") == "charset=utf-8"
    assert unquote("%5B%5D") == "[]"
    assert get_decoded_str("%5B%5D") == "[]"
    assert get_encoded_str("[]") == "%5B%5D"

# Generated at 2022-06-21 04:43:03.373733
# Unit test for function do_urlencode
def test_do_urlencode():
    cases = [
        'hello world',
        'hello@example.com',
        'hello+world',
        'hello++world',
        u'こんにちは',
        {'hello': 'world'},
        (('hello', 'world'),),
    ]
    for case in cases:
        try:
            assert do_urlencode(case) == do_urlencode(unicode(case)) == do_urlencode(to_text(case))
        except TypeError:
            assert False, 'urlencode failed in case %s' % case



# Generated at 2022-06-21 04:43:17.147889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2.filters
    jinja2.filters.FILTERS['urldecode'] = do_urldecode
    if not HAS_URLENCODE:
        jinja2.filters.FILTERS['urlencode'] = do_urlencode
    assert (jinja2.filters.FILTERS['urldecode']('%20') == ' ')
    assert (jinja2.filters.FILTERS['urlencode'](' ') == '%20')
    assert (jinja2.filters.FILTERS['urlencode']({'x':'&'}) == 'x=%26')


if __name__ == '__main__':
    # Unit test FilterModule.filters()
    test_FilterModule_filters()

# Generated at 2022-06-21 04:43:24.330600
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    filters = test.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] is do_urldecode
    assert filters['urlencode'] is do_urlencode



# Generated at 2022-06-21 04:43:31.019857
# Unit test for function do_urlencode
def test_do_urlencode():
    print(do_urlencode('foo bar'))
    print(do_urlencode('привет, мир!'))
    print(do_urlencode('foo=bar&biz=baz'))
    a = {'foo': 'bar', 'biz': 'baz'}
    print(do_urlencode(a))


# Generated at 2022-06-21 04:43:43.647850
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%EC%9E%90%EB%B0%94%20%EC%95%84%EB%A6%AC%EB%9D%BC') == u'자바 아리라'
    assert unicode_urldecode('%D7%99%D7%A8%D7%95%D7%A9%D7%9C%D7%99%D7%9D') == u'ירושלים'
    assert unicode_urldecode('%C3%89%C3%A9%C3%A9%20%E4%B8%96%E7%95%8C') == u'Ééé 世界'



# Generated at 2022-06-21 04:43:53.496273
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) is None
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo&bar') == u'foo&bar'
    assert unicode_urldecode(u'foo%26bar') == u'foo&bar'
    assert unicode_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode(u'foo%25bar') == u'foo%bar'



# Generated at 2022-06-21 04:44:06.172098
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\ud55c\uae00') == u'%ED%95%9C%EA%B8%80'
    assert unicode_urlencode(u'\u30c6\u30b9\u30c8') == u'%E3%83%86%E3%82%B9%E3%83%88'
    assert unicode_urlencode(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82'

# Generated at 2022-06-21 04:44:12.896286
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert do_urldecode('c%20c') == u'c c'
    assert do_urlencode(u'c c') == 'c+c'
    assert do_urlencode({'c c': 'd d'}) == 'c+c=d+d'

# Unit tests for methods of class FilterModule

# Generated at 2022-06-21 04:44:17.133601
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urlencode({"user": "foo", "password": "bar"}) == "user=foo&password=bar"



# Generated at 2022-06-21 04:44:18.621167
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    res = unicode_urldecode(b'%E4%B8%AD%E6%96%87')
    assert res == u'中文'



# Generated at 2022-06-21 04:44:22.491317
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%3A+%22%23%27+%40%7E%7E') == u' : "#\' @~~'



# Generated at 2022-06-21 04:44:31.693313
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('string') == 'string'
    assert unicode_urldecode('%') == '%'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%b') == '%b'
    assert unicode_urldecode('%f') == '%f'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%EF%BF%BD') == '\ufffd'
    assert unicode_urldecode('%EF%BF%BD%') == '\ufffdd'
    assert unicode_urldecode('%EF%BF%BD%2') == '\ufffd2'

# Generated at 2022-06-21 04:44:38.660860
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module is not None

    # We have a urlencode filter
    assert "urlencode" in module.filters()

    # We have a urldecode filter
    assert "urldecode" in module.filters()
    assert module.filters()["urldecode"] is not None



# Generated at 2022-06-21 04:44:48.924589
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("foo%2Fbar") == u'foo/bar'
    assert unicode_urldecode("foo%2fbar") == u'foo/bar'
    assert unicode_urldecode("foo+bar") == u'foo bar'
    assert unicode_urldecode("foo%20bar") == u'foo bar'
    assert unicode_urldecode("foo%20%21%22bar%23") == u'foo !"bar#'


# Generated at 2022-06-21 04:45:00.155764
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    for i, o in [
        (u'foo', u'foo'),
        (u'foo/bar', u'foo%2Fbar'),
        (u'foo bar', u'foo%20bar'),
        (u'foo bar/baz', u'foo%20bar%2Fbaz'),
        (u'foo bar/baz:quux', u'foo%20bar%2Fbaz%3Aquux'),
    ]:
        assert unicode_urlencode(i) == o
        assert unicode_urlencode(i, for_qs=True) == o
        assert unicode_urldecode(o) == i

# Generated at 2022-06-21 04:45:14.246209
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://de.wikipedia.org/wiki/Elf (Begriffsklärung)') == \
        'http%3A//de.wikipedia.org/wiki/Elf%20%28Begriffskl%C3%A4rung%29'
    assert do_urlencode(u'http://de.wikipedia.org/wiki/Elf') == \
        'http%3A//de.wikipedia.org/wiki/Elf'
    assert do_urlencode(u'http://host.example.com/path?a=1&b=1') == \
        'http%3A//host.example.com/path%3Fa%3D1%26b%3D1'

# Generated at 2022-06-21 04:45:25.191160
# Unit test for function do_urldecode
def test_do_urldecode():
    for input, expected in (
        ('abc', 'abc'),
        ('abc%20def%26', 'abc def&'),
        ('abc%2520def%26', 'abc%20def&'),
        ('abc%2Zdef', 'abc%2Zdef'),
        ('abc%2zdef', 'abc%2zdef'),
        ('%E6%B1%89%E8%AF%AD', u'汉语'),
        ('%E6%B1%89%E8%AF%AD%2Z', u'汉语%2Z'),
    ):
        value = do_urldecode(input)
        assert value == expected

        # Test that do_urldecode() is idempotent
        assert do_urldecode(value) == value


# Generated at 2022-06-21 04:45:26.804751
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert isinstance(test, FilterModule)



# Generated at 2022-06-21 04:45:27.685393
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters



# Generated at 2022-06-21 04:45:32.812583
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%C3%A9') == '\u00e9'

    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('\u00e9') == '%C3%A9'

# Generated at 2022-06-21 04:45:44.726879
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Test that do_urldecode() returns the expected output.
    '''
    # positive test cases
    assert do_urldecode("Hello%20World") == u'Hello World'
    assert do_urldecode("Hello World") == u'Hello World'
    assert do_urldecode("Hello%2DWorld") == u'Hello-World'
    assert do_urldecode("Hello%2BWorld") == u'Hello+World'
    assert do_urldecode("Hello%7EWorld") == u'Hello~World'

# Generated at 2022-06-21 04:45:47.106802
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo%20bar%25') == u'foo bar%'


# Generated at 2022-06-21 04:45:54.228372
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b+c') == u'a b c'
    assert unicode_urldecode('%C3%A4') == u'\xe4'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC') == u'\xe4 \xf6 \xfc'


# Generated at 2022-06-21 04:46:02.076741
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('') == ''
    assert do_urldecode('a') == 'a'
    assert do_urldecode('%') == '%'
    assert do_urldecode('%%20%') == '% %'
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%20%20') == '  '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2Ffoo%2F%2F') == '//foo//'

# Generated at 2022-06-21 04:46:12.841473
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo=bar') == 'foo=bar'

    assert do_urlencode({'k': 'foo bar'}) == 'k=foo%20bar'
    assert do_urlencode({'k': {'k2': 'foo bar'}}) == 'k=%7B%27k2%27%3A+%27foo+bar%27%7D'
    assert do_urlencode([('k', 'foo bar')]) == 'k=foo%20bar'


# Generated at 2022-06-21 04:46:26.278405
# Unit test for function do_urlencode
def test_do_urlencode():
    # This is the example from https://docs.python.org/2/library/urllib.html#url-quoting
    assert do_urlencode('http://café.example.org/') == 'http://caf%C3%A9.example.org/'
    # This example shows string with spaces, but safe for use in query-string
    assert do_urlencode('Paris & Heidelberg') == 'Paris+%26+Heidelberg'
    # This example shows string with spaces not safe for use in query-string
    assert do_urlencode('Paris & Heidelberg', for_qs=True) == 'Paris+%26+Heidelberg'
    # This example has a different behavior with unicode_urlencode vs do_urlencode

# Generated at 2022-06-21 04:46:36.343891
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    data = fm.filters()
    assert 'urldecode' in data


# Generated at 2022-06-21 04:46:39.543746
# Unit test for function unicode_urldecode
def test_unicode_urldecode():


    assert unicode_urldecode(u'L%C3%A5dan+f%C3%B6r+hemma') == u'Lådan för hemma'

# Generated at 2022-06-21 04:46:44.246356
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode filter
    assert do_urldecode('foo%20bar%20') == 'foo bar '

    # Test urlencode filter
    assert do_urlencode('foo bar') == u'foo+bar'
    assert do_urlencode({'foo': 'bar baz'}) == u'foo=bar+baz'
    assert do_urlencode(['foo', 'bar baz']) == u'foo&bar+baz'

# Generated at 2022-06-21 04:46:54.378408
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    """Test for function unicode_urlencode"""
    # Reference tests taken from jinja2/testsuite/test_filters.py
    assert(unicode_urlencode(u'foo bar') == u'foo+bar')
    assert(unicode_urlencode(u'foo+bar') == u'foo%2Bbar')
    assert(unicode_urlencode(u'foo%bar') == u'foo%25bar')
    assert(unicode_urlencode(u'foo bar', True) == u'foo+bar')
    assert(unicode_urlencode(u'foo+bar', True) == u'foo%2Bbar')
    assert(unicode_urlencode(u'foo%bar', True) == u'foo%25bar')

# Generated at 2022-06-21 04:47:00.688954
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(None) == u''
    assert unicode_urlencode(u'abc123') == u'abc123'
    assert unicode_urlencode(u'abc 123') == u'abc%20123'
    assert unicode_urlencode(u'abc/123') == u'abc%2F123'
    assert unicode_urlencode(u'abc/123', for_qs=True) == u'abc%2F123'


# Generated at 2022-06-21 04:47:03.558077
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%0A%0A%0D") == "\n\n\r"


# Generated at 2022-06-21 04:47:17.547106
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class ModuleMock(object):
        def __init__(self):
            self.fail_json = self.fail_json_mock
            self.fail_json_mock_called = False

        def _exec(self, cmd):
            print(cmd)

        def fail_json_mock(self, msg):
            self.fail_json_mock_called = True

    mymodule = ModuleMock()
    assert FilterModule().filters()['urldecode']('%20') == ' '
    # assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'


# Generated at 2022-06-21 04:47:22.367501
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    a = filter_module.filters()
    a['urldecode'].__doc__ == 'Return the urlencode-ed form of the argument.'
    a['urldecode'].__name__ == 'urldecode'
    if HAS_URLENCODE:
        a['urlencode'].__doc__ == 'Return the urlencode-ed form of the argument.'
        a['urlencode'].__name__ == 'urlencode'

# Generated at 2022-06-21 04:47:25.242039
# Unit test for constructor of class FilterModule
def test_FilterModule():
  fm = FilterModule()


# Generated at 2022-06-21 04:47:26.374938
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f

# Generated at 2022-06-21 04:47:41.978378
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://server.com/~user') == u'http%3A//server.com/~user'
    assert unicode_urlencode('http://server.com/%7Euser') == u'http%3A//server.com/~user'
    # NOTE: '/' is encoded differently in Python 2 vs Python 3
    assert unicode_urlencode('http://server.com/a space') == u'http%3A//server.com/a+space'
    assert unicode_urlencode('http://server.com/a space', for_qs=True) == u'http%3A%2F%2Fserver.com%2Fa+space'


# Generated at 2022-06-21 04:47:51.431000
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("") == ""
    assert do_urlencode(" ") == "%20"
    assert do_urlencode("/") == "/"
    assert do_urlencode("foo") == "foo"
    assert do_urlencode("foo bar") == "foo%20bar"
    assert do_urlencode("foo/bar") == "foo/bar"
    assert do_urlencode("foo bar/baz") == "foo%20bar/baz"
    assert do_urlencode("foo bar/baz/") == "foo%20bar/baz/"
    assert do_urlencode("foo bar/baz?") == "foo%20bar/baz?"

# Generated at 2022-06-21 04:48:03.469741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    def test_do_urldecode():
        assert do_urldecode(u'x=%2B1+2') == u'x=+1 2'

    def test_do_urlencode():
        assert do_urlencode(u'x=+1 2') == u'x%3D%2B1+2'
        assert do_urlencode([(u'a', u'b'), (u'c', u'd')]) == u'a=b&c=d'
        assert do_urlencode({u'a': u'b', u'c': u'd'}) == u'a=b&c=d'

    def test_FilterModule_filters():
        fm = FilterModule()

# Generated at 2022-06-21 04:48:07.365867
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcd efgh') == 'abcd%20efgh'
    assert unicode_urlencode(u'abcd efgh', True) == 'abcd+efgh'


# Generated at 2022-06-21 04:48:15.565725
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import MutableMapping

    # A dict whose string representation contains a = sign is tricky
    x = dict(a='b')
    x.__str__ = lambda: "c=d"
    assert do_urlencode(x) == "a=b"
    assert do_urlencode(x, for_qs=True) == "a=b"

    # A dict whose repr contains a = sign is tricky
    x = dict(a='b')
    x.__repr__ = lambda: "c=d"
    assert do_urlencode(x) == "a=b"
    assert do_urlencode(x, for_qs=True) == "a=b"



# Generated at 2022-06-21 04:48:27.622768
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%58') == u'X'
    assert do_urldecode(b'%58') == u'X'
    assert do_urldecode(u'X') == u'X'
    assert do_urldecode(b'X') == u'X'
    assert do_urldecode(u'%2B') == u'+'
    assert do_urldecode(b'%2B') == u'+'
    assert do_urldecode(u'+') == u'+'
    assert do_urldecode(b'+') == u'+'
    assert do_urldecode(u'%3D') == u'='
    assert do_urldecode(b'%3D') == u'='
   

# Generated at 2022-06-21 04:48:36.520647
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode('/bin/sh') == '%2Fbin%2Fsh'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'
    assert do_urlencode({'a': ['b', 'c']}, True) == 'a=b&a=c'
    assert do_urlencode({'x': ['y', 'z']}, for_qs=True) == 'x=y&x=z'
    assert do_urlencode({u'a': [u'b', u'c']}) == u'a=b&a=c'

# Generated at 2022-06-21 04:48:47.438456
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:48:50.255394
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-21 04:48:56.315373
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    t = "The quick brown fox jumps over the lazy dog."
    assert not t == filters['urldecode'](t)
    assert not t == filters['urlencode'](t)

# Generated at 2022-06-21 04:49:05.153963
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    # convert to dict for iteration
    filters = dict(module.filters())

    assert len(filters) == 2

    assert filters['urldecode'] == do_urldecode

    # Note: FilterModule.filters() will only return 'urlencode' if Jinja2 is older than v2.7
    assert HAS_URLENCODE == ('urlencode' in filters)
    assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:49:16.622419
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F/%20') == '// '
    assert do_urldecode('%2F%2F%20') == '// '
    assert do_urldecode('%2F%2f%20') == '// '
    assert do_urldecode('%2f%2f%20') == '// '
    assert do_urldecode('%2f%2F%20') == '// '


# Generated at 2022-06-21 04:49:22.334734
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urldecode' in filter_module.filters()
    assert 'urlencode' in filter_module.filters()
    assert 'test_FilterModule_filters' not in filter_module.filters()

# Generated at 2022-06-21 04:49:31.240266
# Unit test for function do_urldecode
def test_do_urldecode():
    import sys
    import platform
    import unittest

    class Test(unittest.TestCase):

        def test_urldecode(self):
            self.assertEqual(do_urldecode('foo'), u'foo')
            self.assertEqual(do_urldecode('bar%20baz'), u'bar baz')
            self.assertEqual(do_urldecode('foo++bar'), u'foo  bar')
            self.assertEqual(do_urldecode('Gr%C3%BCn'), u'Grün')
            self.assertEqual(do_urldecode('h%20i'), u'h i')

        def test_urlencode(self):
            self.assertEqual(do_urlencode('foo'), u'foo')

# Generated at 2022-06-21 04:49:37.235672
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        "urldecode": do_urldecode,
    }

    if not HAS_URLENCODE:
        assert filter_module.filters() == {
            "urldecode": do_urldecode,
            "urlencode": do_urlencode,
        }


# Generated at 2022-06-21 04:49:44.980186
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%21%22%23%24%25%26%27%28%29%2A%2B%2C%2F%3A%3B%3D%3F%40%5B%5D%20') == '!%22#$%&\'()*+,/:;=?@[] '


# Generated at 2022-06-21 04:49:53.525749
# Unit test for function do_urlencode
def test_do_urlencode():
    # Empty string
    assert do_urlencode('') == u''
    assert do_urlencode(u'') == u''
    # String with Unicode characters
    assert do_urlencode('€') == u'%E2%82%AC'
    assert do_urlencode(u'€') == u'%E2%82%AC'
    assert do_urlencode('€'.encode('utf-8')) == u'%E2%82%AC'
    # Integer
    assert do_urlencode(1234) == u'1234'
    # Dictionary
    assert do_urlencode({'a': '1', 'b': '2'}) == u'a=1&b=2'
    assert do_urlencode({'a': [1, 2], 'b': '2'})

# Generated at 2022-06-21 04:50:01.471011
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Ensure that unicode_urldecode encodes back to original string
    '''
    encoded = u'https%3A%2F%2Fansible.com%2Fdemo'
    decoded = unicode_urldecode(encoded)
    assert decoded == u'https://ansible.com/demo'


if __name__ == "__main__":
    # Run the unit test
    import sys
    if len(sys.argv) > 1:
        globals()['test_' + sys.argv[1]]()
    else:
        for test in globals():
            if test.startswith('test_'):
                globals()[test]()

# Generated at 2022-06-21 04:50:09.107564
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http://example.com/?foo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'


# Generated at 2022-06-21 04:50:16.587509
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http://server/path%20with%20space') == u'http://server/path with space'
    assert unicode_urldecode(u'http://server/path%2520with%2520space') == u'http://server/path%20with%20space'
