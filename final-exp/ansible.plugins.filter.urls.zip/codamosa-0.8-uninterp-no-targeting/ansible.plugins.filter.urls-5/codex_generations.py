

# Generated at 2022-06-21 04:40:22.942047
# Unit test for constructor of class FilterModule
def test_FilterModule():
   urldecode_test = FilterModule().filters()['urldecode']
   assert urldecode_test('%20') == ' '
   # assert urldecode_test('%C2%A9 2018 Ansible') == '© 2018 Ansible'
   assert urldecode_test('%2520') == '%20'

# Generated at 2022-06-21 04:40:35.503580
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    of = FilterModule().filters()
    assert of['urldecode']("Unspaced string") == "Unspaced string"
    assert of['urldecode']("Spaced%20string") == "Spaced string"
    assert of['urldecode']("%7B%22a%22%3A%22b%22%7D") == '{"a":"b"}'
    if HAS_URLENCODE:
        assert of['urlencode']("Unspaced string") == "Unspaced+string"
        assert of['urlencode']("Spaced string") == "Spaced+string"
        assert of['urlencode']({"a": "b"}) == "a=b"
        assert of['urlencode']([1,2]) == "1&2"
    else:
        assert of

# Generated at 2022-06-21 04:40:42.511105
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'string with spaces') == u'string+with+spaces'
    assert unicode_urlencode(u'string with spaces', for_qs=True) == u'string%2Bwith%2Bspaces'
    assert unicode_urlencode(u'é') == u'%C3%A9'
    assert unicode_urlencode(u'é', for_qs=True) == u'%C3%A9'


# Generated at 2022-06-21 04:40:53.219248
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if HAS_URLENCODE:
        assert unicode_urldecode('a+b') == 'a b'
        assert unicode_urldecode('a%20b') == 'a b'
        assert unicode_urldecode('a b') == 'a b'
        assert unicode_urldecode('a+b') == do_urldecode('a+b')
        assert unicode_urldecode('a%20b') == do_urldecode('a%20b')
        assert unicode_urldecode('a b') == do_urldecode('a b')


# Generated at 2022-06-21 04:40:57.868374
# Unit test for function do_urldecode
def test_do_urldecode():
    test_string = "abcdef+1234%20"
    result = do_urldecode(test_string)
    expected_result = "abcdef 1234 "
    assert result == expected_result


# Generated at 2022-06-21 04:41:07.781730
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u"http://ansible.com/?"
    result = unicode_urlencode(string)
    assert result == u"http%3A%2F%2Fansible.com%2F%3F"
    result = unicode_urlencode(string, for_qs=True)
    assert result == u"http%3A%2F%2Fansible.com%2F%3F"

    # Test unicode string
    string = u"http://ansible.com/?a=\u00fc"
    result = unicode_urlencode(string)
    assert result == u"http%3A%2F%2Fansible.com%2F%3Fa%3D%C3%BC"
    result = unicode_urlencode(string, for_qs=True)
    assert result == u

# Generated at 2022-06-21 04:41:17.477472
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    global HAS_URLENCODE
    HAS_URLENCODE = False

    fm = FilterModule()
    assert isinstance(fm, FilterModule)

    filters = fm.filters()
    assert isinstance(filters, dict)
    assert isinstance(filters['urldecode'], type(do_urldecode))
    assert isinstance(filters['urlencode'], type(do_urlencode))

    HAS_URLENCODE = True
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert not isinstance(filters['urldecode'], type(do_urldecode))
    assert 'urlencode' not in filters
    assert isinstance(filters['urlencode'], type(do_urlencode))

# Unit

# Generated at 2022-06-21 04:41:25.740879
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2F") == "/"
    assert unicode_urldecode("%2f") == "/"
    assert unicode_urldecode("%26") == "&"
    assert unicode_urldecode("%26&%2F") == "&/&/"
    assert unicode_urldecode("%26&%2F%26") == "&/&/&"
    assert unicode_urldecode("%26&%2F%2F%2F%26") == "&/&//&/"


# Generated at 2022-06-21 04:41:29.169392
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%7B') == '{'
    assert do_urldecode('%2A') == '*'
    assert do_urldecode('%3C') == '<'
    assert do_urldecode('%3E') == '>'
    assert do_urldecode('%40') == '@'
    assert do_urldecode('%7B') == '{'
    assert do_urldecode('%7D') == '}'



# Generated at 2022-06-21 04:41:32.513090
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A5%C3%A6%C3%B8%C3%A5%C3%A6%C3%B8') == 'åæøåæø'


# Generated at 2022-06-21 04:41:42.793154
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    data = [
        u'',
        u'abc',
        u'a b c',
        u'/',
        u'a0B/c 1&#',
    ]
    for item in data:
        out1 = unicode_urlencode(item)
        out2 = unicode_urlencode(item, for_qs=True)
        print(item, '=>', out1, out2)



# Generated at 2022-06-21 04:41:51.237793
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' urlencode '''
    assert do_urlencode('http://www.example.com/') == 'http%3A%2F%2Fwww.example.com%2F'
    assert do_urlencode('fästen') == 'f%C3%A4sten'
    assert do_urlencode('fästen:') == 'f%C3%A4sten%3A'
    assert do_urlencode('fästen: båten') == 'f%C3%A4sten%3A+b%C3%A5ten'
    assert do_urlencode('fästen:båten') == 'f%C3%A4sten%3Ab%C3%A5ten'

# Generated at 2022-06-21 04:42:00.981156
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("/etc/passwd & /etc/shadow") == "/etc/passwd%20%26%20/etc/shadow"
    assert unicode_urlencode("/etc/passwd & /etc/shadow", True) == "/etc/passwd+%26+/etc/shadow"
    assert unicode_urlencode("Hello World!") == "Hello%20World!"
    assert unicode_urlencode("Hello World!", True) == "Hello+World%21"
    assert unicode_urlencode("mydict=%7B%22a%22%3A1%2C%22b%22%3A2%7D") == "mydict=%7B%22a%22%3A1%2C%22b%22%3A2%7D"
    assert unicode_

# Generated at 2022-06-21 04:42:11.093580
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('test%2Ftest') == 'test/test'
    if not HAS_URLENCODE:
        assert do_urldecode('test/test') == 'test/test'
    assert do_urldecode(u'test%2Ftest') == 'test/test'
    # NOTE: On Python 2 the following would throw a UTF-8 error
    # assert do_urldecode(u'test/test') == 'test/test'
    assert do_urldecode(b'test%2Ftest') == 'test/test'
    # NOTE: On Python 2 the following would throw a UTF-8 error
    # assert do_urldecode(b'test/test') == 'test/test'



# Generated at 2022-06-21 04:42:20.584428
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit test for method filters of class FilterModule
    # No inputs, no outputs
    assert FilterModule().filters() is not None
    # No inputs, one output
    assert FilterModule().filters() is not None
    # One input, one output
    assert FilterModule().filters() is not None
    # No inputs, two outputs
    assert FilterModule().filters() is not None
    # Two inputs, one output
    assert FilterModule().filters() is not None
    # Two inputs, two outputs
    assert FilterModule().filters() is not None
    # Three inputs, one output
    assert FilterModule().filters() is not None
    # One input, no outputs
    assert FilterModule().filters() is not None
    # Two inputs, no outputs
    assert FilterModule().filters() is not None
    # Three inputs, no outputs

# Generated at 2022-06-21 04:42:29.902714
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%21') == '!'
    assert do_urldecode('%21%20%2A%20%28%20%29') == '! * ( )'
    assert do_urldecode('%21%20%2A%20%28%20%29') == '! * ( )'
    assert do_urldecode('%E5%98%98') == u'嘘'
    assert do_urldecode('%E5%98%98') == u'嘘'



# Generated at 2022-06-21 04:42:35.760768
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters, 'urldecode is not in filters'
    assert 'urlencode' in filters, 'urlencode is not in filters'

# Generated at 2022-06-21 04:42:40.390144
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'François & jinja2') == u'Fran%C3%A7ois+%26+jinja2'
    assert unicode_urlencode(u'François & jinja2', for_qs=True) == u'Fran%C3%A7ois+%26+jinja2'

# Generated at 2022-06-21 04:42:49.940138
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    filter_module = FilterModule()
    assert 'urldecode' in filter_module.filters()
    assert 'urlencode' in filter_module.filters()
    assert 'basic' in dir(filter_module.filters()['urldecode'])
    assert 'basic' in dir(filter_module.filters()['urlencode'])
    assert type(filter_module.filters()['urldecode']).__name__ == 'function'
    assert type(filter_module.filters()['urlencode']).__name__ == 'function'



# Generated at 2022-06-21 04:43:02.014404
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.org/') == u'http%3A//www.example.org/'
    assert unicode_urlencode(u'http://www.example.org/', for_qs=True) == u'http%3A%2F%2Fwww.example.org%2F'
    # Unhandled error
    assert unicode_urlencode(u'http://www.exämple.org/') == u'http%3A//www.ex%C3%A4mple.org/'
    assert unicode_urlencode(u'http://www.exämple.org/', for_qs=True) == u'http%3A%2F%2Fwww.ex%C3%A4mple.org%2F'
   

# Generated at 2022-06-21 04:43:17.412738
# Unit test for function do_urldecode
def test_do_urldecode():
    assert(do_urldecode('%2F%3F%23%5B%5D%40%21%24%26%27%28%29%2A%2B%2C%3B%3D%5E%7B%7D%7C%5C%22%3C%3E%3F%5C') == unicode_urldecode('%2F%3F%23%5B%5D%40%21%24%26%27%28%29%2A%2B%2C%3B%3D%5E%7B%7D%7C%5C%22%3C%3E%3F%5C'))

# Generated at 2022-06-21 04:43:23.514265
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # call the class constructor
    ansible_filter = FilterModule()

    # see if it properly initialized
    assert ansible_filter
    assert ansible_filter.filters()
    assert len(ansible_filter.filters()) > 0

# Generated at 2022-06-21 04:43:31.898668
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.module_utils.urls as urls

    class ClassFilterModule(FilterModule):
        def filters(self):
            filters = super(ClassFilterModule, self).filters()
            filters['urlencode'] = urls.urlencode
            filters['urldecode'] = urls.urldecode
            return filters

    classfilter = ClassFilterModule()
    filter = {}
    filter.update(classfilter.filters())
    assert filter['urlencode'] == do_urlencode
    assert filter['urldecode'] == do_urldecode


# Unit tests for urldecode method

# Generated at 2022-06-21 04:43:39.469108
# Unit test for function do_urldecode
def test_do_urldecode():
    string = u'a%40b%2Bc%23d%2F%3Df%3Fg%3A%3Bh%5Ex%26z%25'
    string2 = u'a@b+c#d/=f?g:;h^x&z%'
    assert string2 == do_urldecode(string)



# Generated at 2022-06-21 04:43:40.951071
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module

# Generated at 2022-06-21 04:43:41.973228
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcdef') == 'abcdef'

# Generated at 2022-06-21 04:43:52.336415
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode(u'foo+bar') == u'foo bar'
    assert do_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert do_urldecode(u'foo+bar%2Bbaz') == u'foo bar+baz'
    assert do_urldecode(u'foo%2Bbar+baz') == u'foo+bar baz'



# Generated at 2022-06-21 04:44:02.094027
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # mimick class object:
    class FilterModule(object):
        def filters(self):
            return {'urldecode': do_urldecode, 'urlencode': do_urlencode}

    fm = FilterModule()
    assert fm.filters()['urldecode']('a+b=c') == 'a b=c'
    assert fm.filters()['urlencode']({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Generated at 2022-06-21 04:44:09.275784
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    d = fm.filters()
    assert d['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert d['urlencode'] == do_urlencode
    else:
        assert d['urlencode'] != do_urlencode



# Generated at 2022-06-21 04:44:16.387312
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/test') == '/test'
    assert do_urlencode(u'a&b') == 'a%26b'
    assert do_urlencode(set([])) == ''
    assert do_urlencode([]) == ''
    assert do_urlencode({}) == ''
    assert do_urlencode(['1', '2']) == '1&2'
    assert do_urlencode({'a': '1', 'b': '2'}) == 'a=1&b=2'



# Generated at 2022-06-21 04:44:28.941976
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_values = [('abc123%%20%26%3D%3F', u'abc123 % & = ?'),
                   (u'abc123%%20%26%3D%3F', u'abc123 % & = ?'),
                   ('abc123%%20%26%3D%3F', u'abc123 % & = ?'),
                   (u'abc123%%20%26%3D%3F', u'abc123 % & = ?'),
                   (b'abc123%%20%26%3D%3F', u'abc123 % & = ?'),
                   (b'abc123%%20%26%3D%3F', u'abc123 % & = ?')
                  ]

    for in_value, out_value in test_values:
        assert unicode_urldecode(in_value) == out_value

# Generated at 2022-06-21 04:44:31.802382
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert(isinstance(f, FilterModule))


# Generated at 2022-06-21 04:44:33.997326
# Unit test for constructor of class FilterModule
def test_FilterModule():
    myFilterModule = FilterModule()
    assert myFilterModule is not None

# Generated at 2022-06-21 04:44:40.564048
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters()["urldecode"]("%3C%3E%26%22%25") == "<>&\"%"
    assert x.filters()["urlencode"]("<>&\"%") == "%3C%3E%26%22%25"



# Generated at 2022-06-21 04:44:43.348809
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-21 04:44:46.781360
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'@') == u'%40', u'@ does not urlencode to %40'
    assert do_urlencode(u'+') == u'%2B', u'+ does not urlencode to %2B'
    assert do_urlencode(u'&') == u'%26', u'& does not urlencode to %26'

# Generated at 2022-06-21 04:45:00.415499
# Unit test for function do_urldecode
def test_do_urldecode():
    assert u'key=value' == do_urldecode('key%3Dvalue')

# Generated at 2022-06-21 04:45:14.528995
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(None) == ''
    assert do_urlencode(False) == ''
    assert do_urlencode(True) == ''
    assert do_urlencode(0) == '0'
    assert do_urlencode(1) == '1'
    assert do_urlencode(1.1) == '1.1'
    assert do_urlencode([]) == ''
    assert do_urlencode([1]) == '1'
    assert do_urlencode([1, 2]) == '1&2'
    assert do_urlencode(["1", "2"]) == '1&2'
    assert do_urlencode([[1, 2], [3, 4], [5, 6]]) == '1&2&3&4&5&6'
    assert do_

# Generated at 2022-06-21 04:45:20.779250
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode(u"%E4%B8%AD%E6%96%87%E5%AD%97%E7%AC%A6%E4%B8%B2") == u"中文字符串"
    assert unicode_urldecode(u"one=1&two=2") == u"one=1&two=2"



# Generated at 2022-06-21 04:45:22.610316
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm is not None)


# Generated at 2022-06-21 04:45:37.052449
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('unicode') == 'unicode'
    assert unicode_urlencode('unicode?test1=1&test2=2') == 'unicode%3Ftest1%3D1%26test2%3D2'
    assert unicode_urlencode({'test1': '1', 'test2': '2'}) == 'test1=1&test2=2'
    assert unicode_urlencode(('test1', '1')) == 'test1=1'
    assert unicode_urlencode(('test1', '1', 'test2', '2')) == 'test1=1&test2=2'

# Generated at 2022-06-21 04:45:40.695426
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    # We always encode non-ASCII text
    assert unicode_urlencode(u'føø') == u'f%C3%B8%C3%B8'
    # We never double-encode
    assert unicode_urlencode(u'f%C3%B8%C3%B8') == u'f%C3%B8%C3%B8'



# Generated at 2022-06-21 04:45:47.730620
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo bar', True) == u'foo+bar'
    assert unicode_urlencode(u'føø bår') == u'f%C3%B8%C3%B8%20b%C3%A5r'
    assert unicode_urlencode(u'føø bår', True) == u'f%C3%B8%C3%B8+b%C3%A5r'

# Generated at 2022-06-21 04:45:58.195125
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    from ansible.module_utils import basic

    filter = FilterModule()
    assert filter.filters()['urldecode']('foo%2Fbar') == 'foo/bar'
    if not HAS_URLENCODE:
        assert filter.filters()['urlencode']('foo/bar') == 'foo%2Fbar'
    assert filter.filters()['urlencode']({'a': 'foo', 'b': 'bar'}) == 'a=foo&b=bar'

# Generated at 2022-06-21 04:46:08.622972
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22foo%22%3A%20%5B%7B%22baz%22%3A%20%5B1%2C%202%2C%203%5D%7D%5D%7D') == u"{\"foo\": [{\"baz\": [1, 2, 3]}]}"
    assert unicode_urldecode('%7B%22foo%22%3A%20%5B%7B%22baz%22%3A%20%5B1%2C%20%22a%22%2C%203%5D%7D%5D%7D') == u"{\"foo\": [{\"baz\": [1, \"a\", 3]}]}"

# Generated at 2022-06-21 04:46:11.891881
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    fm = FilterModule()
    filters = fm.filters()
    urlencode = '~' * 1024
    assert filters['urldecode'](
        filters['urlencode'](urlencode)) == urlencode

# Generated at 2022-06-21 04:46:13.819708
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(b'hostname%3Dmyhost%26port%3D22') == 'hostname=myhost&port=22'

# Generated at 2022-06-21 04:46:25.289799
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%5B%7B%22name%22%3A%22testhost%22%7D%2C%7B%22name%22%3A%22secondhost%22%7D%5D') == '%5B%7B%22name%22%3A%22testhost%22%7D%2C%7B%22name%22%3A%22secondhost%22%7D%5D'.decode('utf-8')


# Generated at 2022-06-21 04:46:34.157244
# Unit test for function do_urldecode
def test_do_urldecode():

    assert do_urldecode('%3Ca%20href%3D%22%2F%22%3EHome%3C%2Fa%3E') == u'<a href="/">Home</a>'
    assert do_urldecode('%3A%40%3A') == u':@:'
    assert do_urldecode('%25') == u'%'



# Generated at 2022-06-21 04:46:44.046217
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u'%20'
    assert unicode_urldecode(u'%2B') == u'%2B'
    assert unicode_urldecode(u'%25') == u'%25'
    assert unicode_urldecode(u'%25%20') == u'%25%20'
    assert unicode_urldecode(u'%25%2B') == u'%25%2B'
    assert unicode_urldecode(u'%25%25') == u'%25%25'
    assert unicode_urldecode(u'+') == u'+'
    assert unicode_urldecode(u'%2B') == u'%2B'
    assert unicode_urld

# Generated at 2022-06-21 04:46:47.748100
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')


# Generated at 2022-06-21 04:46:50.255586
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("a+b%20c") == "a b c"



# Generated at 2022-06-21 04:46:54.738587
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    class MyFilterModule(FilterModule):
        pass

    fm = MyFilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert 'urlencode' in fm.filters()  # Jinja2 v2.7 and later have urlencode


# self test

# Generated at 2022-06-21 04:47:05.059489
# Unit test for function do_urldecode
def test_do_urldecode():
    assert b'foo=bar' == do_urldecode(b'foo=bar')
    assert u'föö=bår' == do_urldecode(u'f%C3%B6%C3%B6'
                                      u'=b%C3%A5r')
    assert u'föö=bår' == do_urldecode(u'f%c3%b6%c3%b6'
                                      u'=b%c3%a5r')
    assert [u'föö=bår'] == do_urldecode([u'f%C3%B6%C3%B6'
                                         u'=b%C3%A5r'])
    assert [u'föö=bår'] == do_urld

# Generated at 2022-06-21 04:47:12.344920
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%3A") == u':', "surrogates not supported"
    assert do_urldecode("%3a") == u':', "lowercase not supported"
    assert do_urldecode("a%20b+c") == u'a b c', "spaces not supported"


# Generated at 2022-06-21 04:47:22.439107
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:47:27.460210
# Unit test for function do_urldecode
def test_do_urldecode():
    s = u'string with spaces'
    url_encoded_s = u'string+with+spaces'
    assert do_urldecode(url_encoded_s) == s



# Generated at 2022-06-21 04:47:33.377416
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Given a UTF-8 string that has been encoded in UTF-8
    assert '¢' == unicode_urldecode('%C2%A2')
    # Given a unicode character
    assert '¢' == unicode_urldecode('¢')
    # Given a UTF-8 string that has been encoded in UTF-8 and contains
    # spaces, that are encoded as '+'
    assert '¢ ¢' == unicode_urldecode('%C2%A2+%C2%A2')


# Generated at 2022-06-21 04:47:44.346905
# Unit test for function do_urlencode
def test_do_urlencode():
    exception = None
    try:
        import sys
        import jinja2
    except ImportError as e:
        exception = e
    if exception:
        print("Unable to import jinja2 for testing: %s" % (exception,))
        return
    if jinja2.__version__ >= '2.7':
        return

    import copy

# Generated at 2022-06-21 04:47:52.000569
# Unit test for function do_urldecode
def test_do_urldecode():

    assert do_urldecode('abc%2Bdef+%2F%26+ghi') == 'abc+def /& ghi'
    assert do_urldecode('abc+def+%2F%26+ghi') == 'abc+def /& ghi'
    assert do_urldecode('abc+def+%2F%26+ghi%2Bjkl') == 'abc+def /& ghi+jkl'
    assert do_urldecode('abc%20def%20ghi') == 'abc def ghi'
    assert do_urldecode('abc%20def%20ghi%20') == 'abc def ghi '
    assert do_urldecode('abc%20def%20ghi%2B') == 'abc def ghi+'
    assert do_urld

# Generated at 2022-06-21 04:48:03.297674
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar', True) == 'foo+bar'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', True) == '%2F'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar', True) == 'foo%2Fbar'
    assert unicode_urlencode({'foo bar': 'foo bar'}) == 'foo+bar=foo+bar'

# Generated at 2022-06-21 04:48:08.075236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters

# Generated at 2022-06-21 04:48:13.784058
# Unit test for function do_urlencode
def test_do_urlencode():
    url = 'http://example.org/test?arg=test&arg2=test'
    result = do_urlencode(url)
    assert result == 'http%3A%2F%2Fexample.org%2Ftest%3Farg%3Dtest%26arg2%3Dtest'

    url = 'http://example.org/test?arg=test&arg2=test2'
    result = do_urlencode(url)
    assert result == 'http%3A%2F%2Fexample.org%2Ftest%3Farg%3Dtest%26arg2%3Dtest2'

    url = 'http://example.org/test?arg=test&arg2=test3'
    result = do_urlencode('?arg=test&arg2=test3')

# Generated at 2022-06-21 04:48:18.535017
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urldecode' in fm.filters()
    assert 'urlencode' in fm.filters()



# Generated at 2022-06-21 04:48:25.482470
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:48:26.416142
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule())


# Generated at 2022-06-21 04:48:30.333343
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters


# Generated at 2022-06-21 04:48:32.568333
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/test') == u'/test'

# Generated at 2022-06-21 04:48:45.891624
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('/') == '/')
    assert(do_urlencode('/a') == '/a')
    assert(do_urlencode('a%') == 'a%25')
    assert(do_urlencode('a_') == 'a_')
    assert(do_urlencode('a+') == 'a+')
    assert(do_urlencode('a a') == 'a+a')
    assert(do_urlencode('_ a') == '_+a')
    assert(do_urlencode('_a') == '_a')
    assert(do_urlencode('a+') == 'a+')
    assert(do_urlencode('/a+') == '/a+')
    assert(do_urlencode('/a%') == '/a%25')

# Generated at 2022-06-21 04:48:48.068162
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(FilterModule()), dict)


# Generated at 2022-06-21 04:48:54.356008
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a b') == u'a%20b'



# Generated at 2022-06-21 04:48:55.840940
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()

# Generated at 2022-06-21 04:49:00.967253
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%7B%7D') == ' { }'

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-21 04:49:09.868550
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """do_urlencode()
    """
    assert do_urlencode('http://www.github.com/') == 'http%3A//www.github.com/'
    assert do_urlencode('/var/lib/mailman/lists/mailman/') == '/var/lib/mailman/lists/mailman/'
    assert do_urlencode('/usr/lib/python2.7/') == '/usr/lib/python2.7/'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode('foo') == 'foo'

# Generated at 2022-06-21 04:49:16.555568
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'hello+world') == u'hello world'
    assert do_urldecode(u'%2Fdev%2Fnull') == u'/dev/null'
    assert do_urldecode(u'%C3%A5%C3%A6%C3%B8') == u'åæø'


# Generated at 2022-06-21 04:49:27.343171
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    """ urlencode should not touch strings. """
    assert unicode_urldecode('https://www.google.com') == 'https://www.google.com'
    assert unicode_urlencode('https://www.google.com') == 'https://www.google.com'
    assert unicode_urlencode('https://www.google.com', for_qs=True) == 'https%3A%2F%2Fwww.google.com'
    assert unicode_urldecode('https%3A%2F%2Fwww.google.com') == 'https://www.google.com'


# Generated at 2022-06-21 04:49:38.837377
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://example.com/foo?&') == 'http%3A//example.com/foo%3F%26'
    assert do_urlencode('http://example.com/foo') == 'http%3A//example.com/foo'
    assert do_urlencode('http://example.com/foo?x=1&y=2') == 'http%3A//example.com/foo%3Fx%3D1%26y%3D2'
    assert do_urlencode({'x': '1', 'y': '2'}) == 'x=1&y=2'
    assert do_urlencode('http://example.com/foo') == 'http%3A//example.com/foo'

# Generated at 2022-06-21 04:49:50.542403
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    s = 'a/b/c'
    assert unicode_urlencode(s, for_qs=False) == 'a%2Fb%2Fc'
    assert unicode_urlencode(s, for_qs=True) == 'a%2Fb%2Fc'
    assert unicode_urlencode(s) == 'a%2Fb%2Fc'
    assert unicode_urlencode('/a/b/c/') == '%2Fa%2Fb%2Fc%2F'
    assert unicode_urlencode('/a/b c/') == '%2Fa%2Fb%20c%2F'

# Generated at 2022-06-21 04:49:58.390292
# Unit test for function do_urldecode
def test_do_urldecode():
    test_string = 'lucy%20lucy%2Fmichi%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F'
    assert do_urldecode(test_string) == 'lucy lucy/michi///////////////'


# Generated at 2022-06-21 04:50:11.046767
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import collections
    import datetime
    import decimal
    import doctest
    import re
    import sys
    from random import randint

    module = FilterModule()

    # Ensure we have unicode strings to test against
    if sys.version_info[0] < 3:
        def u(x):
            return unicode(x, 'unicode_escape')
    else:
        def u(x):
            return x

    ############################################################################
    # Test data
    ############################################################################
    # Construct a test dataset
    TestData = collections.namedtuple('TestData', ['value', 'result'])

# Generated at 2022-06-21 04:50:23.944542
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20space') == 'a space'
    assert do_urldecode('some%20thing%20else') == 'some thing else'
    assert do_urldecode('%3A%3B%3C%3D%3E%3F%40') == ':;<=>?@'
    assert do_urldecode('%30%31%32%33%34%35%36%37%38%39') == '0123456789'