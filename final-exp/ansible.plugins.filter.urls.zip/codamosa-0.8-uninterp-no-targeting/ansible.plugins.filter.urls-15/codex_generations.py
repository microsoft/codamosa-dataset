

# Generated at 2022-06-21 04:40:22.975505
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not HAS_URLENCODE
    assert isinstance(FilterModule().filters(), dict)

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-21 04:40:35.501318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils._text import to_bytes, to_list
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.json_utils import _json_param_loads
    from ansible.module_utils.urls import url_argument_spec
    from ansible.module_utils.urls import open_url

    raw_params = {'k1': 'key1',
                  'd': {'k2': 'key2'},
                  'k3': {'k4': 'key4'}}
    params = _json_param_loads(raw_params)
    params = open_url.argument_spec

# Generated at 2022-06-21 04:40:43.226877
# Unit test for function do_urldecode
def test_do_urldecode():
    test_tags = [
        (u'a%2Fb%3Fc', u'a/b?c'),
        (u'a%2Fb%3Fc%3D1%26d%3D2', u'a/b?c=1&d=2'),
        ('a%2Fb%3Fc%3D1%26d%3D2', b'a/b?c=1&d=2'),
    ]

    for (inp, expected) in test_tags:
        assert do_urldecode(inp) == expected


# Generated at 2022-06-21 04:40:55.343414
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test') == 'test'
    assert unicode_urlencode(u'test/') == 'test%2F'
    assert unicode_urlencode(u'test', for_qs=True) == 'test'
    assert unicode_urlencode(u'test/', for_qs=True) == 'test%2F'
    assert unicode_urlencode(u'aäöb') == 'a%C3%A4%C3%B6b'
    assert unicode_urlencode(u'a=&b') == 'a%3D%26b'
    assert unicode_urlencode(u'a=&b', for_qs=True) == 'a%3D%26b'

# Generated at 2022-06-21 04:41:00.915785
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%41%58%43') == 'AXC'
    assert unicode_urldecode('%45%6E%63%6F%73%69%6D%65') == 'Encosim'


# Generated at 2022-06-21 04:41:07.390863
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/påfølgende') == u'http%3A%2F%2Fwww.example.com%2Fp%C3%A5f%C3%B8lgende'
    assert unicode_urlencode(u'http://www.example.com/påfølgende', True) == u'http%3A%2F%2Fwww.example.com%2Fp%C3%A5f%C3%B8lgende'



# Generated at 2022-06-21 04:41:17.452731
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not HAS_URLENCODE:
        assert unicode_urlencode("/") == "%2F"
        assert unicode_urlencode("/", for_qs=True) == "%2F"
        assert unicode_urlencode("a+b=c") == "a%2Bb%3Dc"
        assert unicode_urlencode("a+b=c", for_qs=True) == "a%2Bb%3Dc"
        assert unicode_urlencode("?a=1&b=2") == "%3Fa%3D1%26b%3D2"
        assert unicode_urlencode("?a=1&b=2", for_qs=True) == "%3Fa=1%26b=2"

# Generated at 2022-06-21 04:41:20.485367
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule.filters(FilterModule)[0],dict)

# Unit test with valid urldecode example

# Generated at 2022-06-21 04:41:28.249622
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'"') == u'%22'
    assert unicode_urlencode(u'!') == u'%21'
    assert unicode_urlencode('%') == u'%25'
    assert unicode_urlencode('&') == u'%26'
    assert unicode_urlencode(u'(') == u'%28'
    assert unicode_urlencode(u')') == u'%29'
    assert unicode_urlencode(u'*') == u'%2A'
    assert unicode_urlencode(u'+') == u'%2B'
    assert unicode_urlencode(u',') == u'%2C'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_url

# Generated at 2022-06-21 04:41:29.700366
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unquoted = b'\xc2\xa3 \xe2\x82\xac'
    assert unquoted == unicode_urldecode(b'%C2%A3+%E2%82%AC')


# Generated at 2022-06-21 04:41:32.879012
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-21 04:41:45.092937
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('Dag%20Wieers') == u'Dag Wieers'
    assert do_urlencode('Dag Wieers') == u'Dag+Wieers'
    assert do_urlencode('Dag Wieers') == u'Dag%20Wieers'
    assert do_urlencode({'user': 'Dag Wieers', 'pass': '12345'}) == u'user=Dag+Wieers&pass=12345'
    assert do_urlencode(['Dag Wieers', '12345']) == u'Dag+Wieers&12345'

# Generated at 2022-06-21 04:41:51.599041
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    filters = m.filters()

    assert filters is not None
    assert 'urldecode' in filters

    if not HAS_URLENCODE:
        assert 'urlencode' in filters

# Generated at 2022-06-21 04:41:56.395186
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Unit test for class FilterModule
    """
    fm = FilterModule()
    assert(fm.filters is not None)
    assert(fm.filters() is not None)
    assert(len(fm.filters()) == 2)

# Generated at 2022-06-21 04:41:58.405231
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-21 04:42:07.605532
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2F%3Fquery%3Dtest%26more%3D1') == 'http://example.com/?query=test&more=1'
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2F%3Fquery%3Dtest%26more%3D1') == 'http://example.com/?query=test&more=1'


# Generated at 2022-06-21 04:42:19.185923
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(u'a%20space') == 'a space'
    assert do_urldecode(u'a+plus') == 'a plus'
    assert do_urlencode(u'a space') == u'a%20space'
    assert do_urlencode(u'a plus') == u'a+plus'

    assert do_urlencode({'a': 'b', 'c': 'd'}) == u'a=b&c=d'

    assert do_urlencode(('a', 'b', 'c', 'd')) == u'a&b&c&d'

# Generated at 2022-06-21 04:42:30.450908
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'a': 'b c'}) == 'a=b%20c'
    assert do_urlencode('a=b c') == 'a%3Db%20c'
    assert do_urlencode({'a': ['b', 'c', 'd']}) == 'a=b&a=c&a=d'
    assert do_urlencode({'a': {'b': 'c', 'd': 'e'}}) == 'a%5Bb%5D=c&a%5Bd%5D=e'
    assert do_urlencode(['a', 'b', 'c']) == '0=a&1=b&2=c'


# Generated at 2022-06-21 04:42:41.843111
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # Test string
    string = 'https://10.1.1.1/api/v1/networks/L_10013456577790966077/vlans'
    result = unicode_urlencode(string, for_qs=True)
    assert result == b'https%3A%2F%2F10.1.1.1%2Fapi%2Fv1%2Fnetworks%2FL_10013456577790966077%2Fvlans'

    # Test dict
    dict = {'key1': 'value1', 'key2': 'value2'}
    result = unicode_urlencode(dict)
    assert result == b'key1=value1&key2=value2'

    # Test list

# Generated at 2022-06-21 04:42:50.211726
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs, parse_qsl
    from ansible.module_utils.six.moves.urllib_parse import urlencode, unquote_plus
    fm = FilterModule()

    # test do_urlencode
    assert fm.filters()['urlencode']('foo bar') == 'foo%20bar'
    assert fm.filters()['urlencode']('foo+bar') == 'foo%2Bbar'
    assert fm.filters()['urlencode']('/foo?bar=') == '%2Ffoo%3Fbar%3D'

# Generated at 2022-06-21 04:42:59.379035
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic

    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo%2Fbar') == 'foo/bar'
    assert unicode_urldecode('%68%6F%6F') == 'foo'
    assert unicode_urldecode('foo%62a%72') == 'foobar'
    assert unicode_urldecode('foo%2Bbar') == 'foo+bar'
    assert unicode_urldecode('foo%25bar') == 'foo%bar'
    assert unicode_urldecode('foo%C3%A1') == u'fooá'



# Generated at 2022-06-21 04:43:08.190987
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    strings = [
        u'test_string',
        u'@!#$%^&*()_+-={}[]|\/",.><~;:?\u4f60\u597d',
        u'\u4f60\u597d',
    ]
    for string in strings:
        assert unicode_urlencode(string) == do_urlencode(string)



# Generated at 2022-06-21 04:43:21.753207
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%20def%20%26%20xyz') == u'abc def & xyz'
    assert unicode_urldecode('c%2B%2B') == u'c++'
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc%20def') == u'abc def'
    assert unicode_urldecode(u'abc%20def%20%26%20xyz') == u'abc def & xyz'
    assert unicode_urldecode(u'c%2B%2B') == u

# Generated at 2022-06-21 04:43:32.253569
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test empty string
    assert '' == unicode_urldecode('')

    # Test normal ASCII string
    assert 'foo' == unicode_urldecode('foo')

    # Test normal ASCII string with spaces
    assert 'foo bar' == unicode_urldecode('foo bar')

    # Test utf-8 encoded characters
    assert u'\u2303' == unicode_urldecode('%E2%8C%83')

    # Test uppercase hexadecimal encoded characters
    assert u'\u00E9' == unicode_urldecode('%E9')

    # Test lowercase hexadecimal encoded characters
    assert u'\u00E9' == unicode_urldecode('%e9')

    # Test invalid encoded characters

# Generated at 2022-06-21 04:43:44.209236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common.collections import ImmutableDict

    # Create an instance of class FilterModule
    filters = FilterModule()

    # Test urldecode filter
    urldecode_string = 'foo+%3D+bar%3D+%3D+baz'
    assert unicode_urldecode(urldecode_string) == u'foo = bar= == baz'

    # Test urlencode filter
    urlencode_string = 'foo = bar= == baz'
    assert unicode_urlencode(urlencode_string) == u'foo%20%3D%20bar%3D%20%3D%20baz'

    # Test urlencode filter with a dict

# Generated at 2022-06-21 04:43:46.224048
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f.filters(), dict)

# Generated at 2022-06-21 04:43:49.033198
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-21 04:43:50.996311
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)



# Generated at 2022-06-21 04:43:54.691889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode
    }


# Generated at 2022-06-21 04:44:05.116446
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abcd') == u'abcd'
    assert do_urlencode(u'ab cd') == u'ab%20cd'
    assert do_urlencode(u'ab@cd') == u'ab%40cd'
    assert do_urlencode({u'key': u'value'}) == u'key=value'
    assert do_urlencode({u'key1': u'value1', u'key2': u'value2'}) == u'key1=value1&key2=value2'
    assert do_urlencode(((u'key1', u'value1'), (u'key2', u'value2'))) == u'key1=value1&key2=value2'

# Generated at 2022-06-21 04:44:16.569542
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'

    assert unicode_urldecode(u'foo%20bar%') == u'foo bar%'
    assert unicode_urldecode(u'foo+bar%') == u'foo bar%'

    assert unicode_urldecode(u'foo%2fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo/bar') == u'foo/bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'


# Generated at 2022-06-21 04:44:21.610664
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode(u'abc') == u'abc')
    assert(unicode_urldecode(u'foo+%20bar') == u'foo bar')



# Generated at 2022-06-21 04:44:23.650545
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    tests = [
        (u"http://foo bar", u'http%3A//foo%20bar'),
        (u"http://foo bar?query=1&a=2", u'http%3A//foo%20bar%3Fquery%3D1%26a%3D2'),
    ]
    for string, expect in tests:
        assert unicode_urlencode(string) == expect
        assert unicode_urlencode(string, for_qs=True) == expect

# Generated at 2022-06-21 04:44:34.453976
# Unit test for function do_urlencode
def test_do_urlencode():
    test_cases = [
        ('foo', 'foo'),
        (u'fØØ', 'f%C3%98%C3%98'),
        ([u'foo', u'bar'], 'foo&bar'),
        ({u'foo': u'fØØ', u'bar': u'bær'}, 'bar=b%C3%A6r&foo=f%C3%98%C3%98'),
    ]

    for test_input, expected_result in test_cases:
        assert expected_result == do_urlencode(test_input)

# Generated at 2022-06-21 04:44:35.967199
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert m is not None

# Generated at 2022-06-21 04:44:43.984650
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.compat.tests import unittest
    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except ImportError:
        HAS_URLENCODE = False

    class TestFilterModule(unittest.TestCase):

        def setUp(self):
            self.test = FilterModule()

        def test_FilterModule_filters_urldecode_str(self):
            self.assertEqual(self.test.filters()['urldecode']('a+b'), 'a b')
            self.assertEqual(self.test.filters()['urldecode']('a%20b'), 'a b')

# Generated at 2022-06-21 04:44:48.420305
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    cm = basic.AnsibleModule(argument_spec={})
    fm = FilterModule()
    assert len(fm.filters()) == len(cm.plain_dict())

# Generated at 2022-06-21 04:44:55.873139
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'foo%20bar') == u'foo bar'
    assert unicode_urldecode(b'') == u''
    assert unicode_urldecode(b'%3E') == u'>'
    assert unicode_urldecode(b'foo%5Ebar') == u'foo^bar'


# Generated at 2022-06-21 04:44:58.939567
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_object = FilterModule()
    assert test_object.filters()["urldecode"] == do_urldecode

# Generated at 2022-06-21 04:45:11.473122
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%E0%B8%A7%E0%B8%B5%E0%B8%A2%E0%B8%AB%E0%B8%B2%E0%B8%AA%E0%B8%B2%E0%B8%A2%E0%B9%84%E0%B8%8B%E0%B8%A7%E0%B8%A5%E0%B8%B9%E0%B8%95') == u'วียหาสายไซวลูต'


# Generated at 2022-06-21 04:45:16.877739
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    expected = u'http://ascii.example.com/foo?bar=baz&baz=bar'
    result = unicode_urldecode('http%3A%2F%2Fascii.example.com%2Ffoo%3Fbar%3Dbaz%26baz%3Dbar')
    assert expected == result
    # Test for quoted-printable
    expected = u'http://www.test.de/test me'
    result = unicode_urldecode('http://www.test.de/test=20me')
    assert expected == result


# Generated at 2022-06-21 04:45:21.645673
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2A') == '*'
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('+') == '+'


# Generated at 2022-06-21 04:45:22.871485
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module

# Generated at 2022-06-21 04:45:34.236262
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%7E') == '~'
    assert do_urldecode('%7e') == '~'
    assert do_urldecode('~') == '~'

    assert do_urldecode('Hello%20World%21') == 'Hello World!'
    assert do_urldecode('Hello%20World!') == 'Hello World!'
    assert do_urldecode('Hello World!') == 'Hello World!'

    assert do_urldecode('%E2%98%83') == u'☃'
    assert do_urldecode('☃') == u'☃'

    assert do_urldecode(u'%E2%98%83') == u'☃'
    assert do_urldecode(u'☃') == u

# Generated at 2022-06-21 04:45:38.341950
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test do_urldecode '''
    assert do_urldecode('https%3A%2F%2Fwww.urlencoder.org%2F') == 'https://www.urlencoder.org/'

# Generated at 2022-06-21 04:45:46.855436
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc ABC 123') == 'abc%20ABC%20123'
    assert unicode_urlencode('/a/b/c') == '/a/b/c'
    assert unicode_urlencode('/a/b/c', for_qs=True) == '%2Fa%2Fb%2Fc'
    assert unicode_urlencode(u'\ud83d') == '%F0%9F%8D%83'

# Generated at 2022-06-21 04:46:00.869376
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E6%9D%B1%E4%BA%AC") == u"東京"
    assert unicode_urldecode("%E6%9D%B1%E4%BA%AC%E6%BC%A2") == u"東京漢"
    assert unicode_urldecode("%E6%9D%B1%E4%BA%AC-%E6%BC%A2") == u"東京-漢"
    assert unicode_urldecode(b"%E6%9D%B1%E4%BA%AC%E6%BC%A2") == u"東京漢"

# Generated at 2022-06-21 04:46:08.864559
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test function do_urldecode '''

    result = do_urldecode('This string should be decoded')
    assert type(result) is str

    # Test if do_urldecode works with unicode strings
    result = do_urldecode(u'This string should also be decoded')
    assert type(result) is unicode

    # Test if do_urldecode raises exception with integers
    try:
        result = do_urldecode(123)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 04:46:17.656642
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    # test: urldecode
    test = FilterModule().filters()['urldecode']
    assert test('') == ''
    assert test('abc') == 'abc'
    assert test('a+b') == 'a b'
    assert test('a b') == 'a b'
    assert test('http://foo.bar') == 'http://foo.bar'
    assert test('http://foo-bar') == 'http://foo-bar'
    assert test('http://foo.bar/a+b') == 'http://foo.bar/a b'
    assert test('http://foo.bar/a b') == 'http://foo.bar/a b'
    assert test('http://foo.bar/a%20b') == 'http://foo.bar/a b'

# Generated at 2022-06-21 04:46:25.566441
# Unit test for function do_urldecode
def test_do_urldecode():

    assert do_urldecode(u'key1=val1&key2=val2&key3=val3') == u'key1=val1&key2=val2&key3=val3'
    assert do_urldecode(u'key1=val1&key2=va%20l2&key3=val3') == u'key1=val1&key2=va l2&key3=val3'


# Generated at 2022-06-21 04:46:35.128215
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3C') == u'<'
    assert unicode_urldecode('%3c') == u'<'
    assert unicode_urldecode('%3C%20') == u'< '



# Generated at 2022-06-21 04:46:44.403807
# Unit test for function do_urlencode
def test_do_urlencode():
    '''
    Test the urlencode function
    '''
    # This is the same test as in the Jinja2 source
    assert 'foo%20bar=baz%20spam' == do_urlencode({'foo bar': 'baz spam'})
    assert 'foo=bar+baz&foo=spam' == do_urlencode([('foo', 'bar baz'), ('foo', 'spam')])
    assert 'foo%20bar=baz+spam' == do_urlencode([('foo bar', 'baz spam')])
    assert 'foo="bar&baz"' == do_urlencode([('foo', '"bar&baz"')])
    assert 'foo="bar&amp;baz"' == do_urlencode([('foo', '"bar&amp;baz"')])


# Generated at 2022-06-21 04:46:54.415602
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Create containers for output and expected output
    o = []
    eo = []

    # Test cases

# Generated at 2022-06-21 04:46:56.335591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_string = FilterModule().filters()['urldecode']
    assert filter_string is do_urldecode


# Generated at 2022-06-21 04:47:00.751114
# Unit test for function do_urlencode
def test_do_urlencode():
    value = {'habibi': 'ashq mabaash', 'key2': 2}
    expected = 'habibi=ashq+mabaash&key2=2'
    result = do_urlencode(value)
    assert result == expected



# Generated at 2022-06-21 04:47:08.798921
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # unicode_urlencode string
    assert unicode_urlencode(u'Bär') == 'B%C3%A4r'
    assert unicode_urlencode(u'Bär', True) == 'B%C3%A4r'
    assert unicode_urlencode(b'B\xc3\xa4r') == 'B%C3%A4r'
    assert unicode_urlencode(b'B\xc3\xa4r', True) == 'B%C3%A4r'
    # unicode_urlencode dict
    assert unicode_urlencode({'a': 'Bär'}) == 'a=B%C3%A4r'

# Generated at 2022-06-21 04:47:19.638716
# Unit test for function do_urldecode
def test_do_urldecode():

    # Test simple cases
    assert do_urldecode(u'a+b+c') == u'a b c'
    assert do_urldecode(u'a%20b%20c') == u'a b c'
    assert do_urldecode(u'a%2Ab%2Bc') == u'a*b+c'
    assert do_urldecode(u'%C3%A9') == u'é'
    assert do_urldecode(u'%C3%A9%20%C3%A9') == u'é é'

    # Test dict
    assert do_urldecode(u'a=b&c=d') == u'a=b&c=d'

# Generated at 2022-06-21 04:47:28.336608
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2Ffoo%2Fbar') == '/foo/bar'
    assert do_urlencode('/foo/bar') == '%2Ffoo%2Fbar'
    assert do_urlencode('/foo/bar#ansible') == '%2Ffoo%2Fbar%23ansible'
    assert do_urlencode({'foo': '/bar/baz'}) == 'foo=%2Fbar%2Fbaz'
    assert do_urlencode([('foo', '/bar/baz')]) == 'foo=%2Fbar%2Fbaz'
    assert do_urlencode({'foo': '/bar/baz#ansible'}) == 'foo=%2Fbar%2Fbaz%23ansible'

# Generated at 2022-06-21 04:47:32.932683
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%23%24') == '#$'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%3D') == '//='
    assert do_urldecode('%2F%2F%3D%23') == '//=#'


# Generated at 2022-06-21 04:47:36.256428
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert type(fm) == FilterModule
    assert 'urlencode' in fm.filters()


# Generated at 2022-06-21 04:47:43.694552
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-21 04:47:44.857926
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None


# Generated at 2022-06-21 04:47:52.325165
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('%20%21%22%24%25%26%27%2A%2B%2C%2F%3A%3B%3D%3F%40') == ' !"$%&\'*+,/:;=?@'
    assert do_urldecode('%C3%B6%C3%A4%C3%BC') == 'öäü'
    assert do_urldecode('h%C3%B6h%C3%B6h%C3%B6') == 'höhöhö'

# Generated at 2022-06-21 04:47:57.608081
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic
    from . import filters

    assert filters.unicode_urldecode('%C2%A1Hola%20Se%C3%B1or!') == '\xc2\xa1Hola Se\xc3\xb1or!'
    assert filters.unicode_urldecode('Hello%20World%21') == 'Hello World!'
    assert filters.unicode_urldecode('%20') == ' '
    assert filters.unicode_urldecode('abc%2d%2d%2d%2d%2d123') == 'abc-----123'



# Generated at 2022-06-21 04:47:59.867574
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    assert 'urldecode' in filters

# Generated at 2022-06-21 04:48:01.143520
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm
    assert fm.filters

# Generated at 2022-06-21 04:48:04.061558
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%2Fworld') == u'hello/world'



# Generated at 2022-06-21 04:48:12.126335
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import re
    module = FilterModule()
    jinja2env = dict()
    for name, method in module.filters().items():
        regex = r'^%s$' % name
        assert re.match(regex, str(method)), 'FilterModule.filters(): method %s does not match regex %s' % (method, regex)
    assert type(module.filters()) is dict, 'FilterModule.filters(): module is not dict, but %s' % type(module.filters())


# Generated at 2022-06-21 04:48:24.352537
# Unit test for function do_urldecode
def test_do_urldecode():
    # Unicode tests
    assert do_urldecode(u'foo+bar') == u'foo bar'
    assert do_urldecode(u'foo+bar') == u'foo bar'
    assert do_urldecode(u'foo%20bar') == u'foo bar'
    assert do_urldecode(u'foo+%20bar') == u'foo  bar'
    assert do_urldecode(u'foo++bar') == u'foo  bar'
    assert do_urldecode(u'foo%2B+bar') == u'foo+ bar'
    # Bytes tests
    assert do_urldecode(b'foo+bar') == u'foo bar'
    assert do_urldecode(b'foo+bar') == u'foo bar'
    assert do

# Generated at 2022-06-21 04:48:35.920374
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode(u'foo%3Abar') == u'foo:bar'
    assert do_urldecode(u'foo%3abar') == u'foo:bar'
    assert do_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert do_urldecode(u'foo%2fbar') == u'foo/bar'
    assert do_urldecode(u'foo%253abar') == u'foo%3abar'
    assert do_urldecode(u'foo%2bbar') == u'foo+bar'
    assert do_urldecode(u'foo+bar') == u'foo+bar'
    assert do_ur

# Generated at 2022-06-21 04:48:48.913170
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'a/b&c=d') == u'a%2Fb%26c%3Dd'
    assert do_urlencode(u'a/b&c=d') == do_urldecode(do_urlencode(u'a/b&c=d'))
    assert do_urlencode({u'a/b': u'c&d'}) == u'a%2Fb=c%26d'
    assert do_urlencode([u'a/b', u'c&d']) == u'a%2Fb&c%26d'

# Generated at 2022-06-21 04:48:57.902508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    arg = {'a': 'foo', 'b': 'bar'}
    assert 'a=foo&b=bar' == basic.jsonify(arg)

    assert do_urldecode('a=1%2B2') == 'a=1+2'

    if not HAS_URLENCODE:
        assert do_urlencode('/a/b c') == '%2Fa%2Fb%20c'

# Generated at 2022-06-21 04:49:00.603375
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Unit test for constructor of class FilterModule
    """
    module = FilterModule()
    assert module is not None

# Generated at 2022-06-21 04:49:01.612361
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() is not None

# Generated at 2022-06-21 04:49:09.431871
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%20b') == u'a b'
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a++b') == u'a  b'



# Generated at 2022-06-21 04:49:14.671170
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-21 04:49:17.923219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fobj = FilterModule()
    assert fobj.filters()['urldecode']('Hello%20World!') == 'Hello World!'
    if not HAS_URLENCODE:
        assert fobj.filters()['urlencode']('Hello World!') == 'Hello%20World%21'

# Generated at 2022-06-21 04:49:28.761032
# Unit test for function do_urlencode
def test_do_urlencode():
    import pytest
    # Test string input
    assert do_urlencode(u'http://www.example.com/foo/bar') == u'http%3A%2F%2Fwww.example.com%2Ffoo%2Fbar'
    assert do_urlencode(u'http://www.example.com/foo/bar?a=b&c=d') == u'http%3A%2F%2Fwww.example.com%2Ffoo%2Fbar%3Fa%3Db%26c%3Dd'
    assert do_urlencode(u'a=b&c=d') == u'a%3Db%26c%3Dd'
    # Test unicode string

# Generated at 2022-06-21 04:49:34.820598
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print(unicode_urldecode('Sweden%3A+g%C3%B6taland'))
    assert unicode_urldecode('Sweden%3A+g%C3%B6taland') == u'Sweden: götaland'


# Generated at 2022-06-21 04:49:41.184658
# Unit test for function do_urlencode
def test_do_urlencode():
    '''Check that urlencode is properly encoding strings
    with special characters.'''

# Generated at 2022-06-21 04:49:55.432455
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(FilterModule), dict)


# Generated at 2022-06-21 04:50:02.627564
# Unit test for function do_urlencode
def test_do_urlencode():
    # Generated with: http://meyerweb.com/eric/tools/dencoder/
    # and http://www.blooberry.com/indexdot/html/topics/urlencoding.htm
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'%') == u'%25'
    assert do_urlencode(u'&') == u'%26'
    assert do_urlencode(u'dag@wieers.com') == u'dag%40wieers.com'

# Generated at 2022-06-21 04:50:12.123839
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%E5%98%89') == u'嘉'
    assert unicode_urldecode('%E5%98%89%20%2B%20%E5%A5%BD') == u'嘉 + 好'
    assert unicode_urldecode('%E5%98%89?%20+%E5%A5%BD') == u'嘉? +好'

# Generated at 2022-06-21 04:50:16.091767
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters()
    assert 'urlencode' in f.filters()



# Generated at 2022-06-21 04:50:25.110672
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Test function do_urldecode
    '''
    assert do_urldecode('a%3D1+%26+b%3D2') == 'a=1 & b=2'
    assert do_urldecode('slash%2F%2Bplus%2Fescaped') == 'slash/+plus/escaped'