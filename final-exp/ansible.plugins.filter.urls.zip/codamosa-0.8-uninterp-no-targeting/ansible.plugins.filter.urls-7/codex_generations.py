

# Generated at 2022-06-21 04:40:26.191275
# Unit test for function do_urldecode
def test_do_urldecode():
    # about to be obsoleted in Ansible 2.11
    assert unicode_urldecode(u"foo") == u"foo"
    assert unicode_urldecode(u"foo%20bar") == u"foo bar"
    assert unicode_urldecode(u"foo%2Bbar") == u"foo+bar"

    # New in Ansible 2.11
    assert do_urldecode(u"foo") == u"foo"
    assert do_urldecode(u"foo%20bar") == u"foo bar"
    assert do_urldecode(u"foo%2Bbar") == u"foo+bar"


# Generated at 2022-06-21 04:40:33.965416
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    itemiter_false_list = [
            {1:2, 3:4},
            [1, 2],
            ('a', 'b'),
            u'a',
            b'a',
    ]
    for item in itemiter_false_list:
        assert unicode_urlencode(item) is not None

if __name__ == '__main__':
    test_unicode_urlencode()

# Generated at 2022-06-21 04:40:37.918058
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(None) == u''
    assert unicode_urlencode(False) == u'False'
    assert unicode_urlencode(True) == u'True'
    assert unicode_urlencode(2) == u'2'
    assert unicode_urlencode(3.14) == u'3.14'
    assert unicode_urlencode('/') == u'%2F'
    assert unicode_urlencode('/foo') == u'%2Ffoo'
    assert unicode_urlencode('/foo/') == u'%2Ffoo%2F'
    assert unicode_urlencode('/foo/bar') == u'%2Ffoo%2Fbar'

# Generated at 2022-06-21 04:40:42.070028
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'{0}/test?test_one=test&test_two=test'.format(unichr(214))
    expected = u'%C2%D4/test?test_one=test&test_two=test'

    assert(unicode_urlencode(string) == expected)

# Generated at 2022-06-21 04:40:55.111603
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'abc def ' == unicode_urldecode(u'abc+def+')
    assert u'abc def ' == unicode_urldecode(u'abc%20def%20')
    assert u'abc def ' == unicode_urldecode(u'abc%2Bdef%2B')
    assert u'abc def ' == unicode_urldecode(u'abc+def%20')
    assert u'abc def ' == unicode_urldecode(u'abc%20def+')
    assert u'abc def ' == unicode_urldecode(u'abc+def')
    assert u'abc def ' == unicode_urldecode(u'abc%20def')
    assert u'abc def ' == unicode_urldecode(u'abc%2Bdef')

# Generated at 2022-06-21 04:41:06.748791
# Unit test for function do_urlencode
def test_do_urlencode():
    do_urlencode("{\"fake\" : \"json\"}")
    do_urlencode("{'real' : 'json'}")
    do_urlencode("{'key': 'value'}")
    do_urlencode("{\"key\": \"value\"}")
    do_urlencode("{\"fake\" : \"[json]\"}")
    do_urlencode("{\"fake\" : \"{json}\"}")
    do_urlencode("{\"fake\" : \"{json}\"}")
    do_urlencode("{\"fake\" : \"{json}\"}")
    do_urlencode("{\"fake\" : \"\\\"json}\"}")
    do_urlencode("{\"fake\" : \"json\"}")

# Generated at 2022-06-21 04:41:07.846781
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()

# Generated at 2022-06-21 04:41:09.014376
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None

# Generated at 2022-06-21 04:41:16.475187
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Unreserved characters remain the same (RFC 3986 Section 2.3)
    pass_cases = [
        'abcdefghijklmnopqrstuvwxyz',
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        '0123456789',
        '-._~',
    ]
    for test_case in pass_cases:
        assert unicode_urldecode(test_case) == test_case

    # Percent-encoded octets are decoded

# Generated at 2022-06-21 04:41:19.465227
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    for f in module.filters():
        assert f in ['urldecode', 'urlencode']



# Generated at 2022-06-21 04:41:26.286944
# Unit test for function do_urldecode
def test_do_urldecode():
    data = [
        ("aa%3dbb", "aa=bb"),
        ("aa%3Abb", "aa:bb"),
        ("aa%2Fbb", "aa/bb"),
        ("foo%20bar", "foo bar"),
        ("%20", " "),
        ("", ""),
    ]
    for string, expected_string in data:
        assert do_urldecode(string) == expected_string, 'do_urldecode did not decode properly'



# Generated at 2022-06-21 04:41:28.158199
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters.filters() is not None

# Generated at 2022-06-21 04:41:37.801437
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'foo' == do_urlencode("foo")
    assert 'foo' == do_urlencode(u"foo")
    assert 'foo+bar%3D' == do_urlencode("foo bar=")
    assert 'a%3D1%26b%3D2' == do_urlencode({"a": 1, "b": 2})
    assert 'a%3D1%26b%3D2%26c%3D3' == do_urlencode(("a=", "b", "c"), {"a": 1, "b": 2, "c": 3})
    assert 'foo%2Bbar%3D' == do_urlencode({"foo+bar=": "baz"})

# Generated at 2022-06-21 04:41:48.237074
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode(1) == '1'
    assert do_urlencode(None) == ''
    assert do_urlencode({1:2}) == '1=2'
    assert do_urlencode([{'a': 'b'}, {'c': 'd'}]) == 'a=b&c=d'
    assert do_urlencode({'a': 'b&c=d'}) == 'a=b%26c%3Dd'
    assert do_urlencode({'a': 'c=d'}) == 'a=c%3Dd'
    assert do_urlencode({'a': 'c=d&e=f'})

# Generated at 2022-06-21 04:41:54.038474
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'a': 'b'}) == u'a=b'
    assert do_urlencode(['a', 'b']) == u'a&b'
    assert do_urlencode('foobar') == u'foobar'

# Generated at 2022-06-21 04:42:01.546364
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    import sys

    assert do_urlencode('http://www.google.com') == 'http%3A%2F%2Fwww.google.com'
    assert do_urlencode('http://www.google.com') != 'http://www.google.com'
    assert do_urldecode('http%3A%2F%2Fwww.google.com') == 'http://www.google.com'
    assert do_urldecode('http%3A%2F%2Fwww.google.com') != 'http%3A%2F%2Fwww.google.com'

    print(json.dumps(
        dict(),
        sort_keys=True, indent=4,
    ))

# Generated at 2022-06-21 04:42:10.179126
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Demonstrate unit testing of the jinja2 filters in filters/core.py
    '''
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%3B') == ';'
    assert unicode_urldecode('%3B%3A') == ';:'
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode('a%20b') == 'a b'
    assert unicode_urldecode('a%2Bb') == 'a+b'

# Generated at 2022-06-21 04:42:16.881923
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == '%2F'
    assert do_urlencode({'a': 'b c', 'd': '/'}) == 'a=b%20c&d=%2F'
    assert do_urlencode(['a', 'b c', '/']) == 'a&b%20c&%2F'

# Generated at 2022-06-21 04:42:17.850102
# Unit test for constructor of class FilterModule
def test_FilterModule():
	pass

# Generated at 2022-06-21 04:42:22.840758
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25F6%25C4%25A2%25E6%25BB%259A%25E7%258F%258D%25E6%2587%258D') == 'öÄ¢æ»šçÏ­æ°­'
    assert unicode_urldecode('abc123') == 'abc123'

if __name__ == '__main__':
    test_unicode_urldecode()

# Generated at 2022-06-21 04:42:28.945002
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20world') == u'hello world'
    assert unicode_urldecode(u'hello+world') == u'hello world'
    assert unicode_urldecode(u'hello%20%22world%22') == u'hello "world"'


# Generated at 2022-06-21 04:42:40.494584
# Unit test for function do_urldecode
def test_do_urldecode():
    assert b'a=b' == do_urldecode(b'a=b')
    assert b'a=b' == do_urldecode('a=b')
    assert u'http://example.com/' == do_urldecode(u'http://example.com/')
    assert u'http://example.com/' == do_urldecode('http%3A%2F%2Fexample.com%2F')
    assert u'a=%2Fb' == do_urldecode('a%3D%2Fb')
    assert u'a=b' == do_urldecode(u'a%3Db')


# Generated at 2022-06-21 04:42:50.962712
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode: \u20ac') == 'unicode%3A%20%E2%82%AC'
    assert unicode_urlencode(u'unicode: \u20ac\u20ac') == 'unicode%3A%20%E2%82%AC%E2%82%AC'
    assert unicode_urlencode(u'unicode: \u20ac', for_qs=True) == 'unicode%3A%20%E2%82%AC'
    assert unicode_urlencode(u'unicode: \u20ac\u20ac', for_qs=True) == 'unicode%3A%20%E2%82%AC%E2%82%AC'


# Generated at 2022-06-21 04:42:52.907203
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%0A') == u'\n'


# Generated at 2022-06-21 04:43:02.633424
# Unit test for function do_urlencode
def test_do_urlencode():
    if HAS_URLENCODE:
        # Basic test
        assert do_urlencode('/foo/') == '/foo/'

        # Test with a list
        assert do_urlencode(['a', 'b']) == 'a&b'

        # Test with a dict
        assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'
    else:
        # Basic test
        assert do_urlencode('/foo/') == '/foo/'

        # Test with a list
        assert do_urlencode(['a', 'b']) == 'a&b'

        # Test with a dict
        assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'



# Generated at 2022-06-21 04:43:14.103615
# Unit test for function do_urldecode
def test_do_urldecode():
    # Sample usage from https://docs.python.org/2/library/urllib.html
    assert unicode_urldecode('http%3A//www.example.com/space+1') == u'http://www.example.com/space 1'
    assert unicode_urldecode('http%3A//www.example.com/query?foo=bar&baz=qux') == u'http://www.example.com/query?foo=bar&baz=qux'
    assert unicode_urldecode('http%3A//www.example.com/path%3Fwith%3Fmany%3Fquestions%3F') == u'http://www.example.com/path?with?many?questions?'



# Generated at 2022-06-21 04:43:15.625715
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)



# Generated at 2022-06-21 04:43:23.625161
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'hi there') == u'hi%20there'
    assert unicode_urlencode(u'paul fäßler') == u'paul%20f%C3%A4%C3%9Fler'
    assert unicode_urlencode(u'汉') == u'%E6%B1%89'



# Generated at 2022-06-21 04:43:28.828044
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc+def') == u'abc def'


# Generated at 2022-06-21 04:43:33.431883
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E5%93%88%E5%93%88') == u'哈哈'


# Generated at 2022-06-21 04:43:44.857390
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("foo bar baz") == "foo+bar+baz"
    assert unicode_urlencode("wieers.com") == "wieers.com"
    assert unicode_urlencode("dag@wieers.com") == "dag%40wieers.com"
    assert unicode_urlencode("foo-bar") == "foo-bar"
    assert unicode_urlencode("foo_bar") == "foo_bar"
    assert unicode_urlencode("/wieers.com/") == "%2Fwieers.com%2F"
    assert unicode_urldecode("%2Fwieers.com%2F") == "/wieers.com/"

# Generated at 2022-06-21 04:43:54.967463
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A//example.com/foo%20bar'
    assert unicode_urlencode(u'foo?&=bar') == u'foo%3F%26%3Dbar'
    assert unicode_urlencode(u'foo?&=bar', True) == u'foo%3F%26%3Dbar'



# Generated at 2022-06-21 04:44:00.087040
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:44:03.520176
# Unit test for function do_urldecode
def test_do_urldecode():
    string = to_text("https://www.ansible.com/products?id=123%26456%2F789")
    assert do_urldecode(string) == "https://www.ansible.com/products?id=123&456/789"



# Generated at 2022-06-21 04:44:17.938658
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test unicode_urlencode '''
    assert unicode_urlencode(u'a b c d') == u'a%20b%20c%20d'
    assert unicode_urlencode(u'a b c d', for_qs=True) == u'a+b+c+d'
    assert unicode_urlencode(u'a/b c d') == u'a%2Fb%20c%20d'
    assert unicode_urlencode(u'a/b c d', for_qs=True) == u'a/b+c+d'
    assert unicode_urlencode(u'a&b c d') == u'a%26b%20c%20d'

# Generated at 2022-06-21 04:44:20.090267
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filtermodule = FilterModule()
    filtermodule.filters()


# Generated at 2022-06-21 04:44:23.527207
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'test_test%201' == unicode_urlencode('test test 1')


# Generated at 2022-06-21 04:44:25.372978
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert(f.filters() is not None)

# Generated at 2022-06-21 04:44:29.962088
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters !=None
    assert to_text(filters['urldecode']('a+b')) == 'a b'

# Generated at 2022-06-21 04:44:32.913535
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule), \
        "FilterModule instance not created properly!"

# Generated at 2022-06-21 04:44:43.334295
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import tests.utils as utils

    module = FilterModule()

# Generated at 2022-06-21 04:44:58.618795
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # str
    assert u'a b' == unicode_urldecode(u'a%20b')
    assert u'a+b' == unicode_urldecode(u'a+b')
    assert u'/' == unicode_urldecode(u'/')
    assert u'a b' == unicode_urldecode(b'a%20b')
    assert u'a+b' == unicode_urldecode(b'a+b')
    assert u'/' == unicode_urldecode(b'/')

    # bytes
    assert 'a b' == unicode_urldecode('a%20b')
    assert 'a+b' == unicode_urldecode('a+b')
    assert '/' == unicode_urldecode('/')
   

# Generated at 2022-06-21 04:45:08.061851
# Unit test for function do_urlencode
def test_do_urlencode():
    # Happy path
    assert do_urlencode('http://example.com/') == 'http%3A//example.com/'
    assert do_urlencode(u'http://example.com/') == u'http%3A//example.com/'

    # All possible encodings of a /
    assert do_urlencode('/') == '%2F'
    assert do_urlencode(u'/') == u'%2F'
    assert do_urlencode(b'/') == b'%2F'
    assert do_urlencode(u'/'.encode('utf8')) == u'%2F'
    assert do_urlencode(u'/'.encode('ascii')) == u'%2F'

    # All possible encodings of a :
    assert do_url

# Generated at 2022-06-21 04:45:12.885576
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3Dbah') == u'http://example.com/?foo=bar&baz=bah'



# Generated at 2022-06-21 04:45:17.973668
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'\u05d0\u05d5\u05e1\u05e4\u05d4') == u'%D7%90%D7%95%D7%A1%D7%A4%D7%94'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode(u'foo') == u'foo'

# Generated at 2022-06-21 04:45:22.236616
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fexample.com%2Ftest%3Ftest%3Dtest') == 'https://example.com/test?test=test'



# Generated at 2022-06-21 04:45:27.009811
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Unit test for ansible.module_utils.urls.do_urldecode '''
    assert do_urldecode('example%40example.com') == u'example@example.com'


# Generated at 2022-06-21 04:45:37.641720
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%2E%2E/%2E%2E/bin/bash") == "../../bin/bash"
    assert do_urldecode("/%2E%2E/%2E%2E/") == "/../../"
    assert do_urldecode("%2F%2F%2F") == "///"
    assert do_urldecode("etc/passwd") == "etc/passwd"
    assert do_urldecode("%2D%2D%2D") == "---"
    assert do_urldecode("%5B%5D%5C") == "[]\\"
    assert do_urldecode("%27%60") == "'`"

# Generated at 2022-06-21 04:45:47.576240
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test') == u'test'
    assert unicode_urlencode(42) == u'42'
    assert unicode_urlencode(u'/some/path') == u'/some/path'
    assert unicode_urlencode(u'with spaces') == u'with+spaces'
    assert unicode_urlencode(u'with+plus') == u'with%2Bplus'
    assert unicode_urlencode(u'expect%20spaces') == u'expect%20spaces'
    assert unicode_urlencode(u'with_special_&_chars_!_=_&_~') == u'with_special_%26_chars_!_=_%26_~'



# Generated at 2022-06-21 04:45:55.699487
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7Ejdoe') == u'~jdoe'
    assert unicode_urldecode('!#$&*') == u'!#$&*'
    assert unicode_urldecode('%21%23%24%26%27%28%29%2A') == u'!#$&\'()*'



# Generated at 2022-06-21 04:46:09.481620
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'

# Generated at 2022-06-21 04:46:18.142109
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    fn = unicode_urldecode
    assert fn('%20') == u'%20'
    assert fn('%25') == u'%'
    assert fn('%2B') == u'+'
    assert fn('%2F') == u'/'

    assert fn('%2F') == u'/'
    assert fn('%2Ffoo%2F') == u'/foo/'
    assert fn('%2Ffoo%2Fbar%2F') == u'/foo/bar/'
    assert fn('%2Ffoo%2Fbar%2Fbaz%2F') == u'/foo/bar/baz/'
    assert fn('%2Ffoo%2Fbar%2Fbaz%2Fqux%2F') == u'/foo/bar/baz/qux/'
    assert fn

# Generated at 2022-06-21 04:46:23.244292
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Please run:
    python -m ansible.module_utils.core.basic.FilterModule
    """

    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-21 04:46:37.288554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    ansible_urlencode = fm.filters()['urlencode']
    assert u'%3C%20%3E%23%25%22%27' == ansible_urlencode(u'< >#%\'"')
    assert u'%3C%20%3E%23%25%22%27' == ansible_urlencode({'a': u'< >#%\'"'})
    assert u'x=%3C%20%3E%23%25%22%27' == ansible_urlencode((('x', u'< >#%\'"'),))



# Generated at 2022-06-21 04:46:39.894304
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'This is a string!'
    result = unicode_urlencode(string)
    assert result == "This%20is%20a%20string%21"


# Generated at 2022-06-21 04:46:46.243376
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    assert unicode_urldecode(None) == None
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(b'abc') == u'abc'
    assert unicode_urldecode(u'abc xyz') == u'abc xyz'
    assert unicode_urldecode(u'abc%20xyz') == u'abc xyz'
    assert unicode_urldecode(u'abc+xyz') == u'abc xyz'
    assert unicode_urldecode(b'abc+xyz') == u'abc xyz'

# Generated at 2022-06-21 04:46:50.743889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Prepare test
    f = FilterModule()
    test_filters = f.filters()

    # Test without Jinja
    assert test_filters['urlencode'] == do_urlencode
    assert test_filters['urldecode'] == do_urldecode


# Generated at 2022-06-21 04:47:01.152522
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'foo bar baz' == unicode_urldecode('foo+bar+baz')
    assert u' foo bar baz' == unicode_urldecode('+foo+bar+baz')
    assert u' foo bar baz ' == unicode_urldecode('+foo+bar+baz+')
    assert u'foo bar baz ' == unicode_urldecode('foo+bar+baz+')
    assert u'foo bar baz' == unicode_urldecode('foo%20bar%20baz')
    assert u' foo bar baz' == unicode_urldecode('%20foo%20bar%20baz')
    assert u' foo bar baz ' == unicode_urldecode('%20foo%20bar%20baz%20')
   

# Generated at 2022-06-21 04:47:04.646058
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('abc%20def') == 'abc def'
    assert do_urldecode('abc+def') == 'abc+def'


# Generated at 2022-06-21 04:47:19.934057
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # TODO: This should be done as part of test_utils_jinja2.py
    # FIXME: This may require utf-8 encoded files, but that should be OK
    import os
    import json
    import sys

    if PY3:
        module_dir = 'lib3/ansible_collections/ansible/collections/ansible/plugins/filters'
    else:
        module_dir = 'lib/ansible_collections/ansible/collections/ansible/plugins/filters'

    # NOTE: This is a workaround to simulate importing a library in the same
    # directory as the test. This is needed to import the jinja2 module, which
    # in turn is needed to import the urlencode filter.

# Generated at 2022-06-21 04:47:32.178485
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert callable(fm.filters)
    assert callable(fm.filters()['urldecode'])
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert callable(fm.filters()['urlencode'])
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:47:42.406361
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''Function unicode_urlencode'''
    assert unicode_urlencode("a&b") == "a&b"
    assert unicode_urlencode("a&b", for_qs=True) == "a%26b"
    assert unicode_urlencode("a&b", for_qs=False) == "a%26b"
    assert unicode_urlencode("/foo") == "%2Ffoo"
    assert unicode_urlencode("/foo", for_qs=True) == "%2Ffoo"
    assert unicode_urlencode("/foo", for_qs=False) == "%2Ffoo"
    assert unicode_urlencode("/foo/bar") == "%2Ffoo%2Fbar"

# Generated at 2022-06-21 04:47:46.369854
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test FilterModule module '''

    # Test init of class FilterModule
    filter_module = FilterModule()
    assert filter_module
    assert filter_module.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-21 04:47:58.484070
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20world') == u'hello world'
    assert unicode_urldecode(u'%F0%90%8C%BC') == u'𐌼'

# Generated at 2022-06-21 04:48:02.247065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urldecode' in filter_module.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in filter_module.filters()


# Generated at 2022-06-21 04:48:11.957177
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' make sure urldecode works as expected '''
    assert do_urldecode('%25%2a%2A') == '%*%2A'
    assert do_urldecode('%2C+%2C+%2C') == ', , ,'
    assert do_urldecode('%25%2c%2C+%2C+%2C') == '%%, , ,'
    assert do_urldecode('%2C+%2C+%2C') == ', , ,'

# Generated at 2022-06-21 04:48:24.308392
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert type(unicode_urlencode('/ä/')) == str
    assert unicode_urlencode('/ä/') == u'/%C3%A4/'
    assert unicode_urlencode('/ä/', for_qs=True) == u'/%C3%A4/'
    assert unicode_urlencode(u'/ä/') == u'/%C3%A4/'
    assert unicode_urlencode(u'/ä/', for_qs=True) == u'/%C3%A4/'
    assert unicode_urlencode('/a&b/') == u'/a%26b/'
    assert unicode_urlencode('/a&b/', for_qs=True) == u'/a%26b/'

# Generated at 2022-06-21 04:48:32.382809
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' urldecode unicode strings '''
    assert unicode_urldecode('wieers') == 'wieers'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2520') == '%20'



# Generated at 2022-06-21 04:48:34.484857
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("%3C%3E%26") == u'<>&'
    assert do_urlencode(u"<>&") == u'%3C%3E%26'

# Generated at 2022-06-21 04:48:40.336773
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%23%2F%C3%A4') == u' #/ä'



# Generated at 2022-06-21 04:48:58.204583
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import unittest


# Generated at 2022-06-21 04:49:06.109148
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == do_urlencode('foo')
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 1}) == 'foo=bar&baz=1'


# Generated at 2022-06-21 04:49:17.223764
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'\u4e2d\u6587'
    assert unicode_urldecode(u'%3C%3E') == u'<>'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%25') == u'%'



# Generated at 2022-06-21 04:49:24.609074
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == u'foo'
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'föö') == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'föö'.encode('utf-8')) == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'föö'.encode('iso-8859-1')) == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'föö') == u'f%C3%B6%C3%B6'

# Generated at 2022-06-21 04:49:31.470392
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    # Test urldecode
    assert 'abcd' == fm.filters()['urldecode']('abcd')
    if not HAS_URLENCODE:
        assert 'abcd' == fm.filters()['urlencode']('abcd')
        assert 'abc%26d=%2B' == fm.filters()['urlencode']('abc&d=+')
        assert 'a=A&b=B' == fm.filters()['urlencode']({'a': 'A', 'b': 'B'})
        assert 'a=A&b=B&c=C' == fm.filters()['urlencode'](['a=A', 'b=B', 'c=C'])

# Generated at 2022-06-21 04:49:36.379831
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Unit test for constructor of class FilterModule"""
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-21 04:49:47.048545
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test valid UTF-8 characters
    assert unicode_urldecode('%E2%82%AC') == '€'
    # Test invalid UTF-8 characters
    assert unicode_urldecode('%A0') == u'\xa0'
    # Test unicode characters
    assert unicode_urldecode(u'%E2%82%AC') == '€'
    # Test unicode strings
    assert unicode_urldecode(u'€'.encode('utf-8')) == '€'

# Generated at 2022-06-21 04:49:58.239962
# Unit test for function do_urlencode
def test_do_urlencode():
    test_string = 'This is a test!'
    test_unicode = u'This is a unicode test with a non-ascii character: \u20ac'
    assert do_urlencode(test_string) == 'This%20is%20a%20test%21'
    assert do_urlencode(test_unicode) == 'This%20is%20a%20unicode%20test%20with%20a%20non-ascii%20character%3A%20%E2%82%AC'

# Generated at 2022-06-21 04:50:00.161507
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urldecode' in FilterModule.filters(None)

# Generated at 2022-06-21 04:50:09.284459
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(['a=1', 'b=2']) == 'a%3D1&b%3D2'
    assert do_urlencode({'a': '1 2'}) == 'a=1%202'
    assert do_urlencode({'a': '1 2'}) == 'a=1%202'
    assert do_urlencode({'a': '1+2'}) == 'a=1%2B2'