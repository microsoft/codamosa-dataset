

# Generated at 2022-06-21 04:40:23.657178
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-21 04:40:35.744087
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    def urldecode(string):
        return filters.get('urldecode')(string)

    def urlencode(value):
        return filters.get('urlencode')(value)

    assert 'foobar' == urldecode('foobar')
    assert 'Hello Dolly' == urldecode('Hello%20Dolly')
    assert 'Hello Dolly' == urldecode('Hello%2BDolly')
    assert 'foo@bar' == urldecode('foo%40bar')

    assert 'foobar' == urlencode('foobar')
    assert 'Hello+Dolly' == urlencode('Hello Dolly', True)
    assert 'Hello+Dolly' == urlencode('Hello+Dolly', True)


# Generated at 2022-06-21 04:40:44.670216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # (ansible.module_utils.common.FilterModule) -> dict[str, func]
    #
    # A function that returns the filters to be registered by this plugin instance.
    #
    # It is required that the returned dict's values are callables (usually functions)
    # and that the keys are strings. The callables must accept one argument and return
    # a single value.

    assert FilterModule.filters.__code__.co_argcount == 1

    assert isinstance(FilterModule.filters(None), dict)
    assert all(isinstance(v, (type(None), type(do_urldecode))) for v in FilterModule.filters(None).values())



# Generated at 2022-06-21 04:40:48.713408
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Call function to test
    f = FilterModule()

    # Error: class does not have method 'filters'
    assert hasattr(f, 'filters') == True



# Generated at 2022-06-21 04:40:57.084036
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # The test vectors in RFC 3986 section 2.4.1
    vectors = {
        'abcABC123': u'abcABC123',
        '-._~': u'-._~',
        '%21%7E%7E%21': u'!~~!',
        '%7E%21%7E': u'~!~',
        '%2A': u'*',
        '%7E': u'~',
        '%80%FF': u'\u0080\u00ff',
        '+': u' ',
        '%80': u'\u0080',
        '%FF': u'\u00ff',
    }


# Generated at 2022-06-21 04:41:07.521834
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test@example.com') == u'test%40example.com'
    assert unicode_urlencode(u'test@example.com', for_qs=True) == u'test%40example.com'
    assert unicode_urlencode(u'test@example.com', for_qs=False) == u'test%40example.com'
    assert unicode_urlencode(u'test@example.com', True) == u'test%40example.com'
    assert unicode_urlencode(u'test@example.com', False) == u'test%40example.com'
    assert unicode_urlencode(u'http://www.example.com') == u'http%3A//www.example.com'

# Generated at 2022-06-21 04:41:10.539171
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%20a%20b%20%23c') == u' a b #c'


# Generated at 2022-06-21 04:41:14.035835
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# unit-tests for the FilterModule
if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 04:41:22.605006
# Unit test for function do_urlencode
def test_do_urlencode():
    x = {'key 1': 'value A', 'key 2': 'value B'}
    y = 'key 1=value A&key 2=value B'
    assert do_urlencode(x) == y

    x = ['key 1=value A', 'key 2=value B']
    y = 'key%201%3Dvalue%20A&key%202%3Dvalue%20B'
    assert do_urlencode(x) == y


# Generated at 2022-06-21 04:41:24.110232
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-21 04:41:28.022338
# Unit test for function do_urldecode
def test_do_urldecode():
    assert u'foo bar' == do_urldecode(u'foo%20bar')



# Generated at 2022-06-21 04:41:37.507940
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a=%2B') == 'a=+'
    assert unicode_urldecode('a%20b') == 'a b'
    assert unicode_urldecode('a%40b') == 'a@b'
    # The unquote_plus function does not seem to work correctly for URLs with a + inside a path.
    # assert unicode_urldecode('a+b') == 'a+b'



# Generated at 2022-06-21 04:41:41.448154
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("hello%20there") == "hello there"
    assert unicode_urldecode("hello+there") == "hello there"


# Generated at 2022-06-21 04:41:45.563004
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc+def') == u'abc def'
    assert unicode_urldecode(u'abc+def') == u'abc def'


# Generated at 2022-06-21 04:41:47.239865
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'invalid%20input') == u'invalid input'

# Generated at 2022-06-21 04:41:59.527226
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('') == ''
    assert do_urldecode('A') == 'A'
    assert do_urldecode('A B') == 'A B'
    assert do_urldecode('A+B') == 'A B'
    assert do_urldecode('A%20B') == 'A B'
    assert do_urldecode('A%2FB') == 'A/B'
    assert do_urldecode('A%2bB') == 'A+B'
    assert do_urldecode('%C3%A9') == u'é'
    assert do_urldecode('%3c') == '<'
    assert do_urldecode('%3C') == '<'

# Generated at 2022-06-21 04:42:01.990380
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule.filters(FilterModule)
    #assert result == 'bar'
    assert result != 'foo'

# Generated at 2022-06-21 04:42:10.851329
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode(['foo', u'bar']) == u'foo&bar'
    assert do_urlencode(('foo', u'bar')) == u'foo&bar'
    assert do_urlencode({u'foo': u'bar', u'baz': u'qux'}) == u'baz=qux&foo=bar'


# Generated at 2022-06-21 04:42:20.812561
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd') == 'abcd'
    assert unicode_urlencode(u'abcd') == 'abcd'
    assert unicode_urlencode('ab cd') == 'ab%20cd'
    assert unicode_urlencode(u'ab cd') == 'ab%20cd'
    assert unicode_urlencode('ab/cd') == 'ab%2Fcd'
    assert unicode_urlencode(u'ab/cd') == 'ab%2Fcd'
    assert unicode_urlencode('ab?cd') == 'ab%3Fcd'
    assert unicode_urlencode(u'ab?cd') == 'ab%3Fcd'
    assert unicode_urlencode('ab cd', for_qs=True) == 'ab+cd'

# Generated at 2022-06-21 04:42:32.687595
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.org%2F') == 'http://example.org/'
    assert unicode_urldecode('http%3A%2F%2Fexample.org%2F%7Euser%2F') == 'http://example.org/~user/'
    assert unicode_urldecode('http%3A%2F%2Fexample.org%2F%7Euser%2F%C3%BC') == 'http://example.org/~user/ü'
    assert unicode_urldecode('http%3A%2F%2Fexample.org%2F%7Euser%2F%C3%9C') == 'http://example.org/~user/Ü'


# Generated at 2022-06-21 04:42:37.384818
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''
    Unit test for constructor of class FilterModule
    '''
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-21 04:42:39.970302
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' test for FilterModule class '''
    filterModule = FilterModule()
    filters = filterModule.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters


# Generated at 2022-06-21 04:42:45.945000
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a b') == u'a%20b'
    assert unicode_urlencode('a b', for_qs=True) == u'a+b'
    assert unicode_urlencode(u'é') == u'%C3%A9'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'é', for_qs=True) == u'%C3%A9'


# Generated at 2022-06-21 04:43:00.444937
# Unit test for function unicode_urldecode

# Generated at 2022-06-21 04:43:02.359394
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''FilterModule()'''
    f = FilterModule()


# Generated at 2022-06-21 04:43:10.778170
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"http://abc.com/foo?bar=1/2") == u"http%3A//abc.com/foo%3Fbar=1/2"
    assert unicode_urlencode(u"http://abc.com/foo?bar=1/2", for_qs=True) == u"http%3A//abc.com/foo%3Fbar%3D1%2F2"



# Generated at 2022-06-21 04:43:20.140160
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"http%3A//user%40example.com%3A9080") == u"http://user@example.com:9080"
    assert unicode_urldecode(u"http%3A//user%40example.com%3A9080/%C3%A0%C3%B4%C3%A8%C3%A9") == u"http://user@example.com:9080/àôèé"



# Generated at 2022-06-21 04:43:22.604430
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Generated at 2022-06-21 04:43:34.072233
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Hello/World') == u'Hello%2FWorld'
    assert unicode_urlencode(u'Hello there') == u'Hello+there'
    assert unicode_urlencode(u'Hello/World', for_qs=True) == u'Hello%2FWorld'
    assert unicode_urlencode(u'Hello there', for_qs=True) == u'Hello+there'
    assert unicode_urlencode(u'Hello=World', for_qs=True) == u'Hello%3DWorld'

    if PY3:
        assert unicode_urlencode(u'Hello/World') == 'Hello%2FWorld'
        assert unicode_urlencode(u'Hello there') == 'Hello+there'

# Generated at 2022-06-21 04:43:36.543294
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' constructor of class FilterModule '''
    # pass
    assert True

# Generated at 2022-06-21 04:43:43.886659
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b') == u'a b'
    assert unicode_urldecode('a%20b') == u'a b'


# Generated at 2022-06-21 04:43:50.352248
# Unit test for function unicode_urldecode

# Generated at 2022-06-21 04:43:55.561375
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%25') == '%'
    assert do_urldecode('%20') == ' '
    assert do_urldecode('+') == ' '
    assert do_urldecode('abc%2Bdef') == 'abc+def'
    assert do_urldecode('98%3D96%3D0A') == '98=96=0A'
    assert do_urldecode('%E4%BD%A0%E5%A5%BD') == '你好'

# Generated at 2022-06-21 04:43:59.225524
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'/%20') == u'/ '

# Generated at 2022-06-21 04:44:05.870551
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello_world') == 'hello_world'
    assert unicode_urldecode('hello%2Fworld') == 'hello%2Fworld'
    assert unicode_urldecode('hello+world') == 'hello+world'
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('hello+%2F+world') == 'hello+%2F+world'
    assert unicode_urldecode('hello%20%2F%20world') == 'hello / world'


# Generated at 2022-06-21 04:44:10.917963
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('this+is%20a+test') == u'this is a test'
    assert unicode_urldecode('%F0%9F%98%82') == u'\U0001f602'

# Generated at 2022-06-21 04:44:17.014475
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('foobar') == u'foobar'
    assert unicode_urldecode('foobar') == u'foobar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo+bar') == u'foobar'
    assert unicode_urldecode('foo%5B1%5D') == u'foo[1]'
    assert unicode_urldecode('foo%2Bbar') == u'foo+bar'


# Generated at 2022-06-21 04:44:19.010969
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(None),dict)


# Generated at 2022-06-21 04:44:21.206933
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()

# Generated at 2022-06-21 04:44:26.612280
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    if PY3:
        assert unicode_urlencode(b'abc def', for_qs=True) == u'abc+def'



# Generated at 2022-06-21 04:44:34.151964
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
    assert 'urldecode' in filters



# Generated at 2022-06-21 04:44:36.881570
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    filtermodule.filters()



# Generated at 2022-06-21 04:44:39.019290
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    result = obj.filters()
    assert result is not None, "Expected result for filters"


# Generated at 2022-06-21 04:44:49.119072
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u'', 'Empty string must return empty string'
    assert unicode_urlencode(u'foo') == u'foo', 'String without special characters must return exact string'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar', 'String with spaces must return string with percent encoding'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar', 'String with slashes must return string with percent encoding'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar', 'String with slashes must return string with percent encoding'
    assert unicode_urlencode(u'foo+bar') == u'foo+bar', 'String with plus must return exact string'

# Generated at 2022-06-21 04:45:01.881226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule. '''

    # This is a test string.
    test_string = u'This is a test string.'

    # Create an instance of FilterModule class.
    filter_module_obj = FilterModule()

    # Get the filters method of FilterModule class.
    filters_method = filter_module_obj.filters

    # Call filters method of FilterModule class.
    filters_method_result = filters_method()

    # Get the urldecode filter from the dictionary filters_method_result.
    urldecode_filter = filters_method_result['urldecode']

    # Invoke urldecode_filter() with test_string as argument.
    urldecode_filter_result = urldecode_filter(test_string)

    # Assert that the result should be

# Generated at 2022-06-21 04:45:13.276150
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' test urlsafe_b64decode filter'''
    unicode_strings = [
        u'https%3A%2F%2Fwww.google.com%2F%3Fq%3Dfoobar%26t%3D1',
        u'https%3A%2F%2Fwww.google.com%2F%3Fq%3Dfoobar%26t%3D1',
        u'https://www.google.com/?q=foobar&t=1',
    ]
    for s in unicode_strings:
        decoded_string = unicode_urldecode(s)

# Generated at 2022-06-21 04:45:23.442300
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(b'a=b&c') == u'a%3Db%26c'
    assert do_urlencode(u'a=b&c') == u'a%3Db%26c'
    assert do_urlencode(u'/') == u'/'
    assert do_urlencode({'a': u'b'}) == u'a=b'
    assert do_urlencode({'a': u'b', 'c': u'd'}) == u'a=b&c=d'
    assert do_urlencode((('a', u'b'), ('c', u'd'))) == u'a=b&c=d'
    assert do_urlencode([('a', u'b'), ('c', u'd')]) == u'a=b&c=d'

# Generated at 2022-06-21 04:45:33.787262
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo%26bar') == 'foo&bar'
    assert unicode_urldecode('foo%2Fbar') == 'foo/bar'
    assert unicode_urldecode('foo%2F%2Fbar') == 'foo//bar'
    assert unicode_urldecode('%2C%27%5B%5D%5D%5D%5D%5B%5B%5B%5B%2C%27') == ',\'][]]][[[,\''
    assert unicode_urldecode('foo%25bar') == 'foo%bar'


# Generated at 2022-06-21 04:45:37.989884
# Unit test for function do_urlencode
def test_do_urlencode():
    assert u'foo=bar' == do_urlencode([('foo', 'bar')])
    assert u'foo=bar%26kung' == do_urlencode([('foo', 'bar&kung')])



# Generated at 2022-06-21 04:45:39.982959
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'&' == unicode_urldecode(u'%26')


# Generated at 2022-06-21 04:45:47.584557
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:45:59.453318
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd') == 'abcd'
    assert unicode_urlencode('abcdé') == 'abcd%C3%A9'
    assert unicode_urlencode('abcdé', for_qs=True) == 'abcd%C3%A9'
    assert unicode_urlencode('abcdé&pq=xyz') == 'abcd%C3%A9&pq=xyz'
    assert unicode_urlencode('abcdé&pq=xyz', for_qs=True) == 'abcd%C3%A9&pq=xyz'
    assert unicode_urlencode(['abcd', 'pqrs']) == 'abcd&pqrs'

# Generated at 2022-06-21 04:46:13.606207
# Unit test for function do_urlencode
def test_do_urlencode():
    ansible_unquoted_s = '(A)(B)(C)'
    ansible_quoted_s = '%28A%29%28B%29%28C%29'
    ansible_unquoted_d = {
        'A': '(A)',
        'B': '(B)',
        'C': '(C)',
    }
    ansible_quoted_d = {
        'A': '%28A%29',
        'B': '%28B%29',
        'C': '%28C%29',
    }
    ansible_quoted_d_qs = 'A=%28A%29&B=%28B%29&C=%28C%29'

    assert do_urlencode(ansible_unquoted_s) == ansible_quoted_s

# Generated at 2022-06-21 04:46:20.332830
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u"%20" == unicode_urlencode(u" ")
    assert u"%C3%80" == unicode_urlencode(u"\xc0")
    assert u"%25" == unicode_urlencode(u"%")
    assert u"%26" == unicode_urlencode(u"&")
    assert u"%2B" == unicode_urlencode(u"+")
    assert u"%0A" == unicode_urlencode(u"\n")
    assert u"%20" == unicode_urlencode(u" ")
    assert u"%7E" == unicode_urlencode(u"~")
    assert u"%21" == unicode_urlencode(u"!")
    assert u"%23" == unicode

# Generated at 2022-06-21 04:46:29.113483
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' jinja2 tests '''
    assert do_urlencode('string') == 'string'
    assert do_urlencode('key=value') == 'key%3Dvalue'
    assert do_urlencode(['key1=value1', 'key2=value2']) == 'key1%3Dvalue1&key2%3Dvalue2'
    assert do_urlencode({'key1': 'value1', 'key2': 'value2'}) == 'key1%3Dvalue1&key2%3Dvalue2'
    assert do_urlencode(('key1=value1', 'key2=value2')) == 'key1%3Dvalue1&key2%3Dvalue2'

# Generated at 2022-06-21 04:46:38.469802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert type(filters) is dict
    assert len(filters) == 2
    assert type(filters['urldecode']) is type(do_urldecode)
    if not HAS_URLENCODE:
        assert type(filters['urlencode']) is type(do_urlencode)
    else:
        assert 'urlencode' not in filters


# Generated at 2022-06-21 04:46:46.065515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%21%25%26%5B%5D%5C%20%24%20%26') == u'!%&[]\\ $ &'
    assert unicode_urldecode('foo%40bar%40baz') == u'foo@bar@baz'
    assert unicode_urldecode('foo@bar@baz') == u'foo@bar@baz'



# Generated at 2022-06-21 04:46:56.221172
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("~!@#$%^&*()_+`1234567890-=[]{}\\|;:'\",./<>? abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") == \
        u"~!%40%23%24%25%5E%26*()_+%601234567890-%3D%5B%5D%7B%7D%5C%7C%3B%3A%27%22,.%2F%3C%3E%3F%20abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

# Generated at 2022-06-21 04:47:06.269296
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'/') == '%2F'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode(b'/', for_qs=True) == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode(b'foo') == 'foo'
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode(b'foo', for_qs=True) == 'foo'
    assert unicode_urlencode('foo', for_qs=True) == 'foo'
    assert unicode_urlencode(b'foo bar') == 'foo%20bar'

# Generated at 2022-06-21 04:47:09.833377
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert 'urldecode' in filters
    assert 'urlencode' in filters

# Generated at 2022-06-21 04:47:14.198795
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:47:20.440265
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    for test_string in (
        u'%3C%3E%C3%B6%C3%BC%C3%9F%E2%82%AC%C2%A3%C2%A5%23%40%25%5E%26%2A',
        u'%EF%BF%BD%EF%BF%BD'
    ):
        assert unicode_urldecode(test_string) == u'<>öüß€£¥#@%^&*'



# Generated at 2022-06-21 04:47:21.383362
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:47:22.713759
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:47:31.368433
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters
    assert filters.get('urldecode')
    if not HAS_URLENCODE:
        assert filters.get('urlencode')
    assert filters.get('urldecode')('foo%20bar') == 'foo bar'
    assert isinstance(filters.get('urldecode')('foo%2Fbar'), basestring)


# Generated at 2022-06-21 04:47:41.147568
# Unit test for function do_urlencode
def test_do_urlencode():
    # Ordinary strings should work
    assert do_urlencode('hello') == 'hello'

    # Lists should work as well
    assert do_urlencode(["hello", "world"]) == 'hello&world'

    # Dictionaries should work
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'

    # Dictionaries with lists should work
    assert do_urlencode({'foo': ['bar', 'baz']}) == 'foo=bar&foo=baz'

    # Non-string dictionaries should work
    assert do_urlencode({1: 'bar'}) == '1=bar'

# Generated at 2022-06-21 04:47:43.186299
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_module_utils = FilterModule()
    return ansible_module_utils


# Generated at 2022-06-21 04:47:45.123284
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%BA%BA') == u'\u4eba'

# Generated at 2022-06-21 04:47:57.537713
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.facts import Facts

    module_args = {}
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    result_dict = {
        'urldecode': {
            'task': {}
        }
    }


# Generated at 2022-06-21 04:47:59.714407
# Unit test for constructor of class FilterModule
def test_FilterModule():
    o = FilterModule()
    o.filters()


# Generated at 2022-06-21 04:48:03.645279
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f,FilterModule)

# Generated at 2022-06-21 04:48:12.821745
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a&b') == u'a%26b'
    assert unicode_urlencode(u'a&b', for_qs=True) == u'a%26b'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'/', for_qs=True) == u'%2F'
    assert unicode_urlencode({u'a': u'b'}) == u'a=b'
    assert unicode_urlencode([u'a', u'b']) == u'a&b'

# Generated at 2022-06-21 04:48:25.224563
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert b'abc def' == unicode_urldecode('abc+def')
    assert b'abc def' == unicode_urldecode('abc%20def')
    assert b'abc def' == unicode_urldecode('abc%20def')
    assert u'abc def' == unicode_urldecode('abc+def')
    assert u'abc def' == unicode_urldecode('abc%20def')
    assert u'<<💩>>' == unicode_urldecode('%3c%3c%f0%9f%92%a9%3e%3e')
    assert u'<<💩>>' == unicode_urldecode('%3c%3c\xf0\x9f\x92\xa9%3e%3e')



# Generated at 2022-06-21 04:48:26.937196
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    assert isinstance(a.filters(), dict)


# Generated at 2022-06-21 04:48:37.222286
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://foo/bar baz/?a=1&b=2') == 'http%3A%2F%2Ffoo%2Fbar%20baz%2F%3Fa%3D1%26b%3D2'
    assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'



# Generated at 2022-06-21 04:48:45.119895
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test that do_urldecode decodes differently
    assert(unicode_urldecode('Foo%2A%2A%2A') == "Foo***")

    # Test that do_urlencode encodes differently
    assert(unicode_urlencode('Foo***') == 'Foo%2A%2A%2A')
    assert(unicode_urlencode('Foo***', True) == 'Foo%2A%2A%2A')

# Generated at 2022-06-21 04:48:54.994518
# Unit test for function do_urlencode
def test_do_urlencode():
    """
    unit test for urlencode filter
    """
    # simple string input
    data = "test"
    assert do_urlencode(data) == u'test'

    # non-string input
    data = ['test', 'test2']
    assert do_urlencode(data) == u'test=test2'

    # dict input
    data = {'test': 'test2'}
    assert do_urlencode(data) == u'test=test2'

# Generated at 2022-06-21 04:49:00.586144
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test simple strings
    value = u'Test string'
    if do_urlencode(value) != u'Test%20string':
        raise Exception('urlencode: Test string was not properly URL encoded')

    # Test empty string
    value = u''
    if do_urlencode(value) != u'':
        raise Exception('urlencode: Empty string was not properly URL encoded')

    # Test complex strings
    value = u'Test%20string'
    if do_urlencode(value) != u'Test%2520string':
        raise Exception('urlencode: Complex string was not properly URL encoded')

    # Test dictionaries
    value = {u'Test': u'string', u'Wieers': u'Dag'}

# Generated at 2022-06-21 04:49:01.904874
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x is not None

# Generated at 2022-06-21 04:49:17.186103
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert not PY3, 'This test only applies to Python 2.x'

    # test urlencode filter
    value = u'key=value'
    expected_result = 'key%3Dvalue'
    actual_result = filter_module.filters['urlencode'](value)
    assert expected_result == actual_result

    value = u'key=value&key2=value%20here'
    expected_result = 'key%3Dvalue%26key2%3Dvalue%2520here'
    actual_result = filter_module.filters['urlencode'](value)
    assert expected_result == actual_result

    # test urldecode filter
    value = 'key%3Dvalue'
    expected_result = u'key=value'

# Generated at 2022-06-21 04:49:31.016850
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'admin:secret') == u'admin%3Asecret'
    assert do_urlencode(u'admin:se cret') == u'admin%3Ase%20cret'
    assert do_urlencode([u'admin:secret', u'admin:se cret']) == u'admin%3Asecret&admin%3Ase%20cret'
    assert do_urlencode({u'user': u'admin:secret', u'password': u'admin:se cret'}) == u'user=admin%3Asecret&password=admin%3Ase%20cret'
    assert do_urlencode(u'admin:secrét') == u'admin%3Asecr%C3%A9t'


# Generated at 2022-06-21 04:49:39.466593
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('{') == '%7B'
    assert unicode_urlencode('}') == '%7D'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('~') == '~'

    assert unicode_urlencode('{', True) == '%7B'
    assert unicode_urlencode('}', True) == '%7D'
    assert unicode_urlencode('/', True) == '%2F'
    assert unicode_urlencode('~', True) == '%7E'

# Generated at 2022-06-21 04:49:43.159235
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A") == u"あいうえお"
    assert unicode_urldecode("%E2%82%AC%C2%A3%C2%A5%E2%82%AC%C2%A2") == u"€£¥€¢"


# Generated at 2022-06-21 04:49:57.430438
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a&b') == u'a%26b'
    assert unicode_urlencode(u'a&b', for_qs=True) == u'a%26b'
    assert unicode_urldecode(u'a%26b') == u'a&b'
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a%20b') == u'a b'
    assert unicode_urldecode(u'a%3db') == u'a=b'
    assert unicode_urldecode(u'a%3Db') == u'a=b'

# Generated at 2022-06-21 04:50:00.500567
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'a+b%20c') == u'a+b c'

# Generated at 2022-06-21 04:50:11.851760
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/foo') == u'/foo'
    assert do_urlencode('foo') == u'foo'
    assert do_urlencode('foo&bar') == u'foo%26bar'
    assert do_urlencode('a@b.com') == u'a%40b.com'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode([u'foo=bar', u'foo2=bar2']) == u'foo%3Dbar&foo2%3Dbar2'
    assert do_urlencode((u'foo=bar', u'foo2=bar2')) == u'foo%3Dbar&foo2%3Dbar2'

# Generated at 2022-06-21 04:50:17.630478
# Unit test for constructor of class FilterModule
def test_FilterModule():
  print ('Unit test for constructor of class FilterModule')
  print ('Tested method: filters')
  filters = FilterModule().filters()
  assert (filters['urldecode'] == do_urldecode)
  assert ('urlencode' in filters)


# Generated at 2022-06-21 04:50:22.639089
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] is do_urldecode
    assert filters['urldecode']('%C2%B5') == 'µ'

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] is do_urlencode
        assert filters['urlencode']('µ') == '%C2%B5'