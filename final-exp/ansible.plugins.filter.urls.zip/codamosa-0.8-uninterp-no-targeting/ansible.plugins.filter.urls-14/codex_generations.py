

# Generated at 2022-06-21 04:40:23.826023
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    result = module.filters()
    assert result['urldecode'] == do_urldecode
    if HAS_URLENCODE:
        assert 'urlencode' in result
    else:
        assert result['urlencode'] == do_urlencode


# Unit tests for function do_urldecode

# Generated at 2022-06-21 04:40:35.787804
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import string
    import random
    import pytest

    rnd = random.Random()
    chars = string.ascii_letters + string.digits + '-_.~'

    def urllib_urlencode(value):
        q = quote if isinstance(value, str) else quote_plus
        return q(value)

    def generate_val(length=10, type=unicode):
        return type(''.join(rnd.choice(chars) for _ in range(length)))


# Generated at 2022-06-21 04:40:40.557111
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'https://github.com/ansible/ansible/pull/44193') == u'https%3A%2F%2Fgithub.com%2Fansible%2Fansible%2Fpull%2F44193'


# Generated at 2022-06-21 04:40:48.246138
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcd') == 'abcd'
    assert unicode_urldecode('ab%2Bde') == 'ab+de'
    assert unicode_urldecode('ab+de') == 'ab de'
    assert unicode_urldecode('ab%20de') == 'ab de'
    assert unicode_urldecode('ab%20de%2B') == 'ab de+'
    assert unicode_urldecode('ab%20de+') == 'ab de '
    assert unicode_urldecode('%3B') == ';'
    assert unicode_urldecode('%7C') == '|'



# Generated at 2022-06-21 04:40:57.026597
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26test%255B%255D%3Dtest') == 'http://example.com/?foo=bar&test[]=test'
    assert unicode_urldecode('%3Ffoo%3Dbar%26test%255B%255D%3Dtest') == '?foo=bar&test[]=test'

# Generated at 2022-06-21 04:40:59.046617
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # pass
    print("FilterModule object: ", FilterModule)


# Generated at 2022-06-21 04:41:05.584749
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Test the FilterModule class.
    """
    filter_module = FilterModule()
    assert filter_module is not None
    assert isinstance(filter_module, object)
    assert hasattr(filter_module, 'filters')
    assert callable(filter_module.filters)
    filters = filter_module.filters()
    assert filters is not None
    assert isinstance(filters, dict)
    assert len(filters) > 0

# Generated at 2022-06-21 04:41:20.352349
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert(unicode_urlencode("%%") == "%25%25")
    assert(unicode_urlencode("foo bar") == "foo+bar")
    assert(unicode_urlencode("foo+bar") == "foo%2Bbar")
    assert(unicode_urlencode("foo%2Bbar") == "foo%252Bbar")
    assert(unicode_urlencode("/foo+bar") == "%2Ffoo%2Bbar")
    assert(unicode_urlencode("/foo bar") == "%2Ffoo+bar")
    assert(unicode_urlencode("/") == "%2F")

    assert(unicode_urlencode("%%", for_qs=True) == "%25%25")

# Generated at 2022-06-21 04:41:28.206202
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:41:30.466458
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass
# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-21 04:41:41.047809
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/foo/bar/') == b'http%3A%2F%2Fexample.com%2Ffoo%2Fbar%2F'
    assert do_urlencode(u'http://example.com/foo/bar/été') == b'http%3A%2F%2Fexample.com%2Ffoo%2Fbar%2F%C3%A9t%C3%A9'
    assert do_urlencode(u'http://example.com/foo/bar/?a=é&b=&c=') == b'http%3A%2F%2Fexample.com%2Ffoo%2Fbar%2F%3Fa%3D%C3%A9%26b%3D%26c%3D'
   

# Generated at 2022-06-21 04:41:43.667789
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo+bar') == u'foo bar'

# Generated at 2022-06-21 04:41:49.874964
# Unit test for function do_urlencode
def test_do_urlencode():
    s = do_urlencode("my cat's name")
    assert s == "my+cat%27s+name", s
    s = do_urlencode("/my cat's name")
    assert s == "%2Fmy+cat%27s+name", s
    s = do_urlencode("my cat's name/")
    assert s == "my+cat%27s+name%2F", s

    l = ['my cat', "'s name"]
    s = do_urlencode(l)
    assert s == "my+cat&%27s+name", s

    d = {"my cat": "'s name"}
    s = do_urlencode(d)
    assert s == "my+cat=%27s+name", s

# Generated at 2022-06-21 04:41:55.012090
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('abc%20def') == 'abc def'
    else:
        assert unicode_urldecode('abc%20def') == u'abc def'


# Generated at 2022-06-21 04:41:56.355730
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:42:09.930312
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # We want to test the do_urldecode and do_urlencode functions without
    # depending on the Jinja2 version, so we replace the FilterModule methods
    # with our own functions (only for the test cases)

    # The following global variables have been set in ansible.module_utils.urls
    # They are now set so they can be used in this test file
    ansible_module_utils_urls_FilterModule_filters_do_urldecode = do_urldecode
    ansible_module_utils_urls_FilterModule_filters_do_urlencode = do_urlencode


# Generated at 2022-06-21 04:42:11.279807
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-21 04:42:19.383000
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%25bar') == u'foo%bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'



# Generated at 2022-06-21 04:42:28.255669
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expected = {
        'urldecode': do_urldecode,
        'uniq': set,
        'unique': set,
        'to_yaml': to_yaml,
        'to_json': to_json,
    }

    if not HAS_URLENCODE:
        expected['urlencode'] = do_urlencode

    assert expected == FilterModule().filters()

# Generated at 2022-06-21 04:42:34.245840
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fexample%2Ecom%2Fstuff%2F%3Fa%3D1%26b%3D2') == u'http://example.com/stuff/?a=1&b=2'

# Generated at 2022-06-21 04:42:40.670200
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters().keys()
    assert callable(f.filters()['urldecode'])
    if not HAS_URLENCODE:
        assert 'urlencode' in f.filters().keys()
        assert callable(f.filters()['urlencode'])

# Generated at 2022-06-21 04:42:51.240561
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode('http://example.com/foo url') == 'http%3A%2F%2Fexample.com%2Ffoo%20url'
    assert do_urlencode(['http://example.com/foo url']) == '0=http%3A%2F%2Fexample.com%2Ffoo%20url'
    assert do_urlencode(['http://example.com/foo url', 'http://example.com/bar url']) == '0=http%3A%2F%2Fexample.com%2Ffoo%20url&1=http%3A%2F%2Fexample.com%2Fbar%20url'

# Generated at 2022-06-21 04:42:54.771075
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%2Bc%2Fd') == 'a+c/d'
    assert do_urldecode('%E5%A4%A7%E4%BA%BA') == u'大人'


# Generated at 2022-06-21 04:43:04.869573
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'a%26b%3Dc' == do_urlencode('a&b=c')
    assert '%26' == do_urlencode('&')

    assert 'a=1%26b%3Dc%3Dd' == do_urlencode({'a': '1&b=c=d'})
    assert 'a=b%26c%3Dd' == do_urlencode({'a': 'b&c=d'})
    assert 'a%26b=c%3Dd' == do_urlencode({'a&b': 'c=d'})


# Generated at 2022-06-21 04:43:07.555379
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    assert isinstance(filterModule, FilterModule)


# Generated at 2022-06-21 04:43:10.483753
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    res = unicode_urldecode("%E4%BD%A0%E5%A5%BD")
    assert res == u"你好"



# Generated at 2022-06-21 04:43:17.911108
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(b'') == u''
    assert unicode_urldecode(u'url%20encoded%20string') == u'url encoded string'
    assert unicode_urldecode(b'url%20encoded%20string') == u'url encoded string'


# Generated at 2022-06-21 04:43:31.277848
# Unit test for function do_urlencode
def test_do_urlencode():
    assert u'' == do_urlencode(None)
    assert u'a' == do_urlencode(u'a')
    assert u'a%3D%3D' == do_urlencode(u'a==')
    assert u'a%3D%2Fa' == do_urlencode(u'a=/a')
    assert u'a%3D%2F%2Fa' == do_urlencode(u'a=//a')
    assert u'%3D%2Fa' == do_urlencode(u'=//a')
    assert u'a%3D%2F%2F' == do_urlencode(u'a=//')
    assert u'a%3Db' == do_urlencode(u'a=b')

# Generated at 2022-06-21 04:43:35.380565
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters()['urldecode']("a"), str)
    assert isinstance(FilterModule().filters()['urldecode']("a"), str)

# Generated at 2022-06-21 04:43:36.620497
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:43:39.694253
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print(FilterModule)

# Generated at 2022-06-21 04:43:44.652758
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ustring = u'\nThis is a test'
    try:
        assert unicode_urlencode(ustring) == u'%0AThis%20is%20a%20test'
        assert unicode_urlencode(ustring, for_qs=True) == u'%0AThis+is+a+test'
    except AssertionError:
        raise AssertionError('unicode_urlencode(%s) failed' % repr(ustring))



# Generated at 2022-06-21 04:43:49.024227
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%40b%2Bc%C3%A4') == u'a@b+cä', 'unicode_urldecode failed'


# Generated at 2022-06-21 04:44:02.534190
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import inspect
    import imp
    import unittest

    class FilterModule_TestCase(unittest.TestCase):
        def setUp(self):
            # Load the module
            self.module = imp.load_source('FilterModule', os.path.join(os.path.abspath(os.path.dirname(inspect.getfile(inspect.currentframe()))), 'FilterModule.py'))
            self.instance = self.module.FilterModule()

        def tearDown(self):
            pass

        def test_urldecode(self):
            self.assertEqual(self.instance.filters()['urldecode']('foo%2Fbar%2Fbaz'), u'foo/bar/baz')


# Generated at 2022-06-21 04:44:15.327117
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Tested with Python v2.7, v3.4 and v3.5
    assert unicode_urlencode('http://example.com/~user') == 'http%3A%2F%2Fexample.com%2F~user'
    assert unicode_urlencode('/url?a=1&b=2&c=x+y%20z') == '%2Furl%3Fa%3D1%26b%3D2%26c%3Dx%2By%2520z'
    assert unicode_urlencode(b'http://example.com/~user') == 'http%3A%2F%2Fexample.com%2F~user'

# Generated at 2022-06-21 04:44:18.455155
# Unit test for function do_urldecode
def test_do_urldecode():
    # assert do_urldecode(u'%20') == u' '
    # assert do_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert do_urldecode('%2520') == u'%20'
    assert do_urldecode('%252B') == u'%2B'


# Generated at 2022-06-21 04:44:28.881230
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # These tests are only relevant for Python 2
    if PY3:
        return
    assert unicode_urldecode('abc%20def') == to_text(unquote_plus('abc%20def'))
    assert unicode_urldecode('abc+def') == to_text(unquote_plus('abc+def'))
    assert unicode_urldecode('abc%%20def') == to_text(unquote_plus('abc%%20def'))
    assert unicode_urldecode('%C3%BC') == to_text(unquote_plus('%C3%BC'))
    assert unicode_urldecode('abc%ffdef') == to_text(unquote_plus('abc%ffdef'))


# Generated at 2022-06-21 04:44:42.196994
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode('/ip4/10.0.1.17/tcp/4001/ipfs/QmVecX9tfLJBmAiMhQ2aKu14YRJvUEiPvy8V7Q2dGMLaUg') == '/ip4/10.0.1.17/tcp/4001/ipfs/QmVecX9tfLJBmAiMhQ2aKu14YRJvUEiPvy8V7Q2dGMLaUg'

# Generated at 2022-06-21 04:44:51.926602
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('this is a test') == 'this%20is%20a%20test'
    assert unicode_urlencode('this? is a test') == 'this%3F%20is%20a%20test'
    assert unicode_urlencode('th%is is a test') == 'th%25is%20is%20a%20test'
    assert unicode_urlencode('this is a test', for_qs=True) == 'this%20is%20a%20test'
    assert unicode_urlencode('this? is a test', for_qs=True) == 'this%3F%20is%20a%20test'

# Generated at 2022-06-21 04:44:52.815357
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:45:01.566985
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()  # Class instantiation
    filters = filter_module.filters()  # Method call
    assert filters is not None
    assert isinstance(filters, dict)
    assert 'urldecode' in filters.keys()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters.keys()
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:45:03.109087
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'param=a+b') == u'param=a%2Bb'

# Generated at 2022-06-21 04:45:05.845022
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule().filters()['urldecode'], type(do_urldecode)))
    assert(isinstance(FilterModule().filters()['urlencode'], type(do_urlencode)))


# Generated at 2022-06-21 04:45:08.354195
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%3A%3A%3D") == u"::="


# Generated at 2022-06-21 04:45:15.121402
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.compat.tests import unittest

    class TestDoUrlEncode(unittest.TestCase):
        pass

    def generator(*args):
        for x in args:
            yield x

    def test_urlencode_value(self):
        self.assertEqual(do_urlencode('a'), 'a')
        self.assertEqual(do_urlencode('ab'), 'ab')
        self.assertEqual(do_urlencode('abc'), 'abc')

    def test_urlencode_dict_value(self):
        # FIXME: This test is broken and trying to fix it makes other tests
        #        fail. Please fix it before 2.9 is released.
        pass


# Generated at 2022-06-21 04:45:19.198435
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    sample_string = '%C3%84+%C3%96+%C3%9C'
    expected_string = u'Ä Ö Ü'
    assert unicode_urldecode(sample_string) == expected_string

# Generated at 2022-06-21 04:45:21.449484
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_filter_module = FilterModule()
    assert(isinstance(ansible_filter_module, FilterModule))

# Generated at 2022-06-21 04:45:28.507257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(u'abc%20def') == to_text(u'abc def')
    assert do_urlencode(u'abc def') == to_text(u'abc+def')
    assert do_urlencode({'a': 'A', 'b': 'B'}) == to_text(u'a=A&b=B')

# Generated at 2022-06-21 04:45:32.675731
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters() == {'urldecode': do_urldecode,
                                'urlencode': do_urlencode}


# Generated at 2022-06-21 04:45:36.413023
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert hasattr(obj, "filters")
    result = obj.filters()
    assert result is not None


# Generated at 2022-06-21 04:45:43.105953
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    # pylint: disable=protected-access
    assert callable(x._filters['urldecode'])
    assert callable(x._filters['urlencode'])



# Generated at 2022-06-21 04:45:47.942086
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'%28%3B%3A%2F%3F%23%5B%5D%40%26%3D%2B%24%2C%20') == u'();:/?#[]@&=+$, '
    assert unicode_urldecode(u'%C3%80%20') == u'\u00c0 '


# Generated at 2022-06-21 04:45:54.845857
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'"hello world"') == u'"hello%20world"'
    assert do_urlencode({'a': 'b'}) == u'a=b'
    assert do_urlencode([('a', 'b')]) == u'a=b'



# Generated at 2022-06-21 04:45:59.776030
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-21 04:46:13.960829
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2B%2B%2B') == '+++'
    assert unicode_urldecode('%2B%2B%2B%5C') == '+++\\'
    assert unicode_urldecode('%2B%2B%2B%2B') == '++++'
    assert unicode_urldecode('%5C%5C%5C%5C') == '\\\\\\\\'
    assert unicode_urldecode('%5C%5C%5C%5C%40%40%40%40') == '\\\\\\\\@@@@'

# Generated at 2022-06-21 04:46:22.294899
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E8%8B%B1%E8%AA%9E') == u'英語'
    assert unicode_urldecode(u'%C3%A8%C3%A8%C3%A8') == u'èèè'



# Generated at 2022-06-21 04:46:25.603383
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-21 04:46:40.543063
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/path/to/file') == '/path/to/file'
    assert do_urlencode('/path/to/file with spaces') == '/path/to/file%20with%20spaces'
    assert do_urlencode('/path/to/file&with&symbols') == '/path/to/file%26with%26symbols'
    assert do_urlencode('/path/to/file#with#hash') == '/path/to/file#with#hash'

# Generated at 2022-06-21 04:46:43.050154
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%41%42%43') == 'ABC'


# Generated at 2022-06-21 04:46:45.663671
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule().filters()
    assert test['urldecode'] == do_urldecode
    assert test['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:46:58.653726
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%2Ftmp%2Fansible-test") == "/tmp/ansible-test"
    assert do_urldecode("%2Ftmp%2Fansible%2Ftest") == "/tmp/ansible/test"
    assert do_urldecode("%2Ftmp%2Fansible%2Ftest%2F") == "/tmp/ansible/test/"
    assert do_urldecode("%2Ftmp%2Fansible%2Ftest%2F%2F") == "/tmp/ansible/test//"


# Generated at 2022-06-21 04:46:59.219121
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:47:08.009571
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == 'foo%2Fbar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode(u'foo:bar') == 'foo:bar'
    assert unicode_urlencode(u'foo:bar', for_qs=True) == 'foo%3Abar'
    assert unicode_urlencode(u'foo|bar') == 'foo|bar'
    assert unicode

# Generated at 2022-06-21 04:47:11.342629
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a/b+c') == u'a%2Fb%2Bc'
    assert unicode_urlencode(u'a/b+c', for_qs=True) == u'a%2Fb%2Bc'


# Generated at 2022-06-21 04:47:19.411873
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo+foobar') == u'foo%2Bfoobar'
    assert unicode_urlencode(u'foo foobar') == u'foo%20foobar'
    assert unicode_urlencode(u'foo+foobar', for_qs=True) == u'foo%2Bfoobar'
    assert unicode_urlencode(u'foo foobar', for_qs=True) == u'foo+foobar'



# Generated at 2022-06-21 04:47:31.318238
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    from ansible.module_utils.six.moves import urllib

    # Save the initial state
    filters_initial = FilterModule.filters.__get__(FilterModule, FilterModule)

    # Define a simple filter set
    filter_set_simple = dict(
        urlencode=unicode_urlencode,
        urldecode=unicode_urldecode,
    )

    # Define a filter set that implements urlencode using Jinja2
    if HAS_URLENCODE:
        filter_set_jinja2 = dict(
            urldecode=unicode_urldecode,
        )

    # Define a filter set that does not implement urldecode

# Generated at 2022-06-21 04:47:41.167405
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'

    assert unicode_urlencode('\x01\x02\x03') == '%01%02%03'

    assert unicode_urlencode('\x01\x02\x03', for_qs=True) == '%01%02%03'

    assert unicode_urlencode({'a': 'b'}) == 'a=b'

    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

    assert unicode_urlencode([('a', 'b'), ('c', 'd')]) == 'a=b&c=d'

    assert unicode_urlencode('a b') == 'a%20b'


# Generated at 2022-06-21 04:47:41.820858
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-21 04:47:47.158563
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    if sys.version_info >= (3, 0):
        assert unicode_urldecode('%5B1%5D') == '[1]'
        assert unicode_urldecode('%7B1%3A%20%27one%27%2C%202%3A%20%27two%27%7D') == "{1: 'one', 2: 'two'}"
    else:
        assert unicode_urldecode('%5B1%5D') == u'[1]'
        assert unicode_urldecode('%7B1%3A%20%27one%27%2C%202%3A%20%27two%27%7D') == u"{1: 'one', 2: 'two'}"



# Generated at 2022-06-21 04:47:59.683714
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'a&b') == 'a%26b'
    assert do_urlencode(u'é') == '%C3%A9'
    assert do_urlencode(u'a&b') == 'a%26b'
    assert do_urlencode(u'a&b') == 'a%26b'
    assert do_urlencode(u'a&b') == 'a%26b'
    assert do_urlencode({'a': u'b&c', 'é': u'f'}) == 'a=b%26c&%C3%A9=f'

# Generated at 2022-06-21 04:48:06.367407
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode



# Generated at 2022-06-21 04:48:08.460661
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # check all filters
    assert FilterModule().filters()



# Generated at 2022-06-21 04:48:09.911392
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:48:12.419380
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Hello%2C%20World%21') == u'Hello, World!'
    assert do_urldecode('%E4%BD%A0%E5%A5%BD') == u'\u4f60\u597d'


# Generated at 2022-06-21 04:48:16.058421
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('h%20i') == u'h i'


# Generated at 2022-06-21 04:48:24.971413
# Unit test for function unicode_urlencode

# Generated at 2022-06-21 04:48:33.838178
# Unit test for function do_urlencode
def test_do_urlencode():
    import sys

    assert sys.version_info < (3, 6)

    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode(u'foo') == 'foo'
    assert do_urlencode(u'fooà') == 'foo%C3%A0'
    assert do_urlencode(u'foo bar') == 'foo%20bar'
    assert do_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert do_urlencode(u'fo/o') == 'fo%2Fo'

# Generated at 2022-06-21 04:48:46.516741
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class UrlDecodeTestCase(unittest.TestCase):
        def test_unicode_urldecode(self):
            self.assertEqual(unicode_urldecode('%E4%BA%91%E9%9B%B7%20ansible'), u'\u4e91\u96f7 ansible')
            self.assertEqual(unicode_urldecode('%E4%BA%91%E9%9B%B7%2Bansible'), u'\u4e91\u96f7+ansible')

# Generated at 2022-06-21 04:48:52.163454
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()

    assert do_urldecode == filters['urldecode']

    if not HAS_URLENCODE:
        assert do_urlencode == filters['urlencode']

# Generated at 2022-06-21 04:48:54.855382
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert len(filter_module.filters()) == 2


# Generated at 2022-06-21 04:49:00.896465
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-21 04:49:09.431479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import pytest
    import six

    if six.PY2:
        pytest.skip("Skipping FilterModule tests for Python 2.")
        return

    # unit tests for filters
    # Input data for the tests
    examples = [
        ({'a': 'b'}, 'a=b'),
        ({'q': 'a space'}, 'q=a+space'),
        ({'q': 'a+plus'}, 'q=a%2Bplus'),
        ({'q': 'a%percent'}, 'q=a%25percent'),
    ]
    # Run the tests
    f = FilterModule()
    for example in examples:
        assert f.filters()['urlencode'](example[0]) == example[1]

# Generated at 2022-06-21 04:49:21.947414
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('\u2713') == '%E2%9C%93'
    assert do_urlencode(u'foo bar') == 'foo+bar'
    assert do_urlencode({'key': 'value'}) == 'key=value'
    assert do_urlencode({'key': 'value', 'foo': 'bar'}) == 'key=value&foo=bar'
    assert do_urlencode(['key', 'value']) == 'key&value'
    assert do_urlencode(['key', 'value', 'foo', 'bar']) == 'key&value&foo&bar'
    assert do_urlencode(123) == '123'
    assert do_urlencode(True) == 'True'
    assert do_urlencode(False) == 'False'

# Generated at 2022-06-21 04:49:24.369694
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2Fusr%2Fbin%2F') == '/usr/bin/'

# Generated at 2022-06-21 04:49:27.685230
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not HAS_URLENCODE
    assert callable(FilterModule().filters().get('urldecode'))


# Generated at 2022-06-21 04:49:39.465844
# Unit test for function do_urlencode
def test_do_urlencode():
    # From JINJA documentation module for urlencode
    a_dict = {
        'foo': 'bar;',
        'price': 34,
        'multi': ['a', 'b', 12],
    }
    assert do_urlencode(a_dict) == u'foo=bar%3B&multi=a&multi=b&multi=12&price=34'
    assert do_urlencode(foo='bar;', price=34, multi=['a', 'b', 12]) == 'foo=bar%3B&price=34&multi=a&multi=b&multi=12'
    assert do_urlencode(['foo', 'bar;']) == u'foo&bar%3B'
    assert do_urlencode('foo bar;') == 'foo+bar%3B'
    assert do_urld

# Generated at 2022-06-21 04:49:48.831195
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%C3%A9') == 'é'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%26%3D') == '&='
    assert unicode_urldecode('%24%25%40') == '$%@'


# Generated at 2022-06-21 04:49:56.727085
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    # assert x.filters() == {'urldecode': <function do_urldecode at 0x7facd8a48378>}
    assert 'urldecode' in x.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in x.filters()


# Generated at 2022-06-21 04:50:01.193700
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc def') == u'abc+def'
    assert do_urlencode(u'abc def') == 'abc+def'
    assert do_urlencode(u'\u20ac') == u'%E2%82%AC'
    assert do_urlencode((('a', 'b'), ('c', 'd'), ('e', 'f'))) == u'a=b&c=d&e=f'


# Generated at 2022-06-21 04:50:13.061271
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("foo bar") == "foo%20bar"
    assert unicode_urlencode("foo bar", for_qs=True) == "foo+bar"
    assert unicode_urlencode("foo+bar", for_qs=True) == "foo%2Bbar"
    assert unicode_urlencode("/") == "%2F"
    assert unicode_urlencode("/?/\\/") == "%2F%3F%2F%5C%2F"
    assert unicode_urlencode("/?/\\/", for_qs=True) == "%2F%3F%2F%5C%2F"
