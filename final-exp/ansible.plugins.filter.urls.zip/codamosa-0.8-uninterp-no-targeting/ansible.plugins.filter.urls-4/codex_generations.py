

# Generated at 2022-06-21 04:40:21.348606
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:40:26.414837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters()['urldecode'](u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3D%E3%82%A4%E3%82%A8%26buzz%3Dp%E3%81%BF%E3%81%A4%E3%81%8B%E3%81%A4%E3%82%8A') == u'http://example.com/?foo=bar&baz=いエ&buzz=pみつかつり'

# Generated at 2022-06-21 04:40:30.481997
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter = FilterModule()
    assert isinstance(test_filter, object)


# Generated at 2022-06-21 04:40:33.917027
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('email+address@example.com') == u'email address@example.com'


# Generated at 2022-06-21 04:40:41.172554
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%c3%a9') == u'é'


# Generated at 2022-06-21 04:40:49.529785
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Use real urlparse, mostly to test compatibility with Jinja2 filter
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

# Generated at 2022-06-21 04:41:01.384646
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    assert filters['urldecode']('a%20b%20c') == u'a b c'
    assert filters['urlencode']('a b c') == 'a%20b%20c'
    assert filters['urlencode']({'a b c': 'd e f'}) == 'a%20b%20c=d%20e%20f'
    assert filters['urlencode'](['a b c', 'd e f']) == 'a%20b%20c&d%20e%20f'


# Generated at 2022-06-21 04:41:02.755766
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:41:03.301298
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return

# Generated at 2022-06-21 04:41:06.474503
# Unit test for constructor of class FilterModule
def test_FilterModule():
    my_filter = FilterModule()
    assert isinstance(my_filter, FilterModule)



# Generated at 2022-06-21 04:41:11.678838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c = FilterModule()
    assert c.filters()['urldecode'] == do_urldecode



# Generated at 2022-06-21 04:41:14.340834
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc+%26+%3D+%2F+%3F') == u'abc & = / ?'


# Generated at 2022-06-21 04:41:15.698971
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:41:26.450237
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'€') == u'%E2%82%AC'
    assert unicode_urlencode(u'&') == u'%26'
    assert unicode_urlencode(u'&', for_qs=True) == u'%26'
    assert unicode_urlencode(u'&&', for_qs=True) == u'%26%26'
    assert unicode_urlencode(u'/') == u'%2F'
    assert unicode_urlencode(u'//') == u'%2F%2F'
    assert unicode_urlencode({'a': u'b', 'c': u'€', 'd': u'&'}) == u'a=b&c=%E2%82%AC&d=%26'

# Generated at 2022-06-21 04:41:35.095319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%c3%a5%c3%a5') == u'åå'
    assert unicode_urldecode(u'%c3%a5%c3%a5'.encode('utf-8')) == u'åå'
    assert unicode_urldecode('%c3%a5%c3%a5') == u'åå'
    if not PY3:
        assert unicode_urldecode(b'%c3%a5%c3%a5') == u'åå'


# Generated at 2022-06-21 04:41:37.190408
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert hasattr(f, 'filters')

# Generated at 2022-06-21 04:41:45.251557
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Testing unicode_urldecode
    assert unicode_urldecode('%3C') == '<'
    assert unicode_urldecode('%3c') == '<'
    assert unicode_urldecode('%3C+%2F+%3E') == '< / >'
    assert unicode_urldecode('%3c+%2f+%3e') == '< / >'


# Generated at 2022-06-21 04:41:56.588100
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%20%20') == u'  '
    assert do_urldecode('foo%20bar%20baz') == u'foo bar baz'
    assert do_urldecode('foo+bar+baz') == u'foo+bar+baz'
    assert do_urldecode('foo%2Bbar%2Bbaz') == u'foo+bar+baz'



# Generated at 2022-06-21 04:42:10.072044
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat.tests.test_urllib_parse import TestUrllibParseUrlQuotes as TestUrllibParseUrlQuotes


# Generated at 2022-06-21 04:42:19.861780
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'abc%2Bdef' == unicode_urlencode('abc+def')
    assert 'abc%2Bdef%3D' == unicode_urlencode('abc+def=')
    assert 'abc%2Bdef%3D%3F' == unicode_urlencode('abc+def=?')

    # when not PY3, ensure strings are converted to byte strings
    if not PY3:
        item=[(u'abc', u'def', u'ghi')]
        ret = unicode_urlencode(item)
        assert 'abc%3Ddef%26ghi' == ret
        item=[(u'abc', u'def', u'ghi')]
        ret = unicode_urlencode(item, for_qs=True)

# Generated at 2022-06-21 04:42:27.779836
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%40b') == u'a@b'
    assert do_urldecode('a%2Fb') == u'a/b'
    assert do_urldecode('a+b') == u'a b'
    assert do_urldecode('a b') == u'a b'



# Generated at 2022-06-21 04:42:33.192738
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:42:39.752750
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a b') == u'a%20b'
    assert unicode_urlencode(u'/a b') == u'%2Fa%20b'
    assert unicode_urlencode(u'a b', for_qs=True) == u'a+b'



# Generated at 2022-06-21 04:42:46.058433
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(b'foo') == u'foo'
    assert unicode_urldecode(b'foo+bar') == u'foo bar'
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('foo+bar') == u'foo bar'


# Generated at 2022-06-21 04:43:00.583339
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import sys

# Generated at 2022-06-21 04:43:09.707976
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert 'urldecode' in filters
    assert callable(filters['urldecode'])
    assert filters['urldecode']('%20') == ' '
    assert filters['urldecode']('%7B%7B%20ansible_managed%20%7D%7D') == '{{ ansible_managed }}'

# Generated at 2022-06-21 04:43:15.764087
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fdict = fm.filters()
    assert fdict['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fdict['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:43:18.176880
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert not HAS_URLENCODE or (fm.filters()['urlencode'] == do_urlencode)
    assert fm.filters()['urldecode'] == do_urldecode


# Generated at 2022-06-21 04:43:26.606084
# Unit test for function do_urlencode
def test_do_urlencode():
    f = FilterModule()
    assert f.filters()['urlencode']('foo=bar&baz=foobar') == 'foo%3Dbar%26baz%3Dfoobar'
    assert f.filters()['urlencode']({'baz': 'foo', 'foo': 'bar'}) == 'baz=foo&foo=bar'


# Generated at 2022-06-21 04:43:38.208906
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import re
    x = FilterModule()
    assert isinstance(x.filters(), dict)
    assert isinstance(x.filters()['urldecode'], type(do_urldecode))

    # Ensure only one filter exists if Jinja2 supports urlencode
    if HAS_URLENCODE:
        assert not re.match(r'^Filters\(.*2.*\)$', str(x.filters()))
    else:
        assert isinstance(x.filters()['urlencode'], type(do_urlencode))

# Generated at 2022-06-21 04:43:50.998206
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20b%20c%20d%20e') == 'a b c d e'
    assert do_urldecode('a+b+c+d+e') == 'a b c d e'
    assert do_urldecode('%7B%22a%22%3A+%22b%22%7D') == '{"a": "b"}'


# Generated at 2022-06-21 04:43:58.089623
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("&") == "%26"
    assert do_urlencode("&=") == "%26%3D"
    assert do_urlencode("&=&=") == "%26%3D%26%3D"
    assert do_urlencode("&=&a=") == "%26%3D%26a%3D"
    assert do_urlencode("&=&a=b") == "%26%3D%26a%3Db"
    assert do_urlencode("&=&a=b&") == "%26%3D%26a%3Db%26"
    assert do_urlencode("&=&a=b&=&") == "%26%3D%26a%3Db%26%3D%26"


# Generated at 2022-06-21 04:44:05.149190
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'key': 'value'}) == 'key=value'
    assert do_urlencode({'key': ['value1', 'value2']}) == 'key=value1&key=value2'
    assert do_urlencode({'key1': 'value1', 'key2': 'value2'}) == 'key1=value1&key2=value2'
    assert do_urlencode(['value1', 'value2']) == 'value1&value2'
    assert do_urlencode('key') == 'key'

# Generated at 2022-06-21 04:44:10.848491
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # constructor
    f = FilterModule()

    # test result
    assert f.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert f.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:44:16.620939
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F/%2F') == u'/%2F'


# Generated at 2022-06-21 04:44:21.130407
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters


# Generated at 2022-06-21 04:44:30.952148
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode_urlencode') == u'unicode_urlencode'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo\x00bar') == u'foo%00bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo\x00bar', for_qs=True) == u'foo%00bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u'/') == u'/'

# Generated at 2022-06-21 04:44:40.366699
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    assert 'urldecode' in fm.filters()
    urldecode = fm.filters()['urldecode']

    assert urldecode('') == ''
    assert urldecode('%20%40') == u' @'
    assert urldecode('A+B+C') == u'A B C'
    assert urldecode('A%2BB%2BC') == u'A+B+C'

# Generated at 2022-06-21 04:44:43.081009
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode



# Generated at 2022-06-21 04:44:58.380835
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    string = u'Hello World'
    fm = FilterModule()
    res = fm.filters()['urldecode'](string)
    assert res == u'Hello World'
    assert res == to_text(unicode_urldecode(string))

    res = fm.filters()['urldecode'](string + u'%20')
    assert res == u'Hello World '
    assert res == to_text(unicode_urldecode(string + u'%20'))

    string = u'Hello World%20'
    res = fm.filters()['urldecode'](string)
    assert res == u'Hello World '

    assert fm.filters()['urlencode'](string) == u'Hello%20World%2520'

# Generated at 2022-06-21 04:45:12.608277
# Unit test for function do_urlencode
def test_do_urlencode():
    # Simple string
    assert do_urlencode('test') == 'test'

    # String with space
    assert do_urlencode('test%20test') == 'test%20test'

    # List
    assert do_urlencode(['test', 'test2']) == 'test&test2'

    # Dictionary
    assert do_urlencode({'param': 'test', 'param2': 'test2'}) == \
        'param=test&param2=test2'

    # Dictionary with space
    assert do_urlencode({'param': 'test%20test', 'param2': 'test2'}) == \
        'param=test%20test&param2=test2'

# Test for function unicode_urlencode

# Generated at 2022-06-21 04:45:23.594351
# Unit test for function do_urldecode
def test_do_urldecode():
    # Test strings
    plaintext = "A string with spaces"
    hextext = "Another string with %20"
    octtext = "A%20string%20with%20%5Cx20"
    octhescapedtext = "A%20string%20with%20%5C%5Cx20"

    # Check encoding
    assert(do_urldecode(plaintext) == plaintext)
    assert(do_urldecode(hextext) == plaintext)
    assert(do_urldecode(octtext) == plaintext)
    assert(do_urldecode(do_urlencode(octhescapedtext)) == plaintext)

    assert(do_urldecode(plaintext.encode('utf-8')) == plaintext)

# Generated at 2022-06-21 04:45:31.190445
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a%20b') == u'a b'
    assert unicode_urldecode(u'%C3%BC') == u'ü'
    assert unicode_urldecode(u'%C3%BC%20%24') == u'ü $'


# Generated at 2022-06-21 04:45:35.035771
# Unit test for function do_urldecode
def test_do_urldecode():
    if do_urldecode('Hello%20World') != 'Hello World':
        raise Exception('do_urldecode failed')


# Generated at 2022-06-21 04:45:39.031845
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http://example.com') == u'http://example.com'
    assert do_urldecode('http%3A%2F%2Fexample.com') == u'http://example.com'


# Generated at 2022-06-21 04:45:41.526083
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Hello%%20World') == u'Hello World'


# Generated at 2022-06-21 04:45:43.104882
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters() is not None


# Generated at 2022-06-21 04:45:46.092391
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%253D') == '%3D'



# Generated at 2022-06-21 04:45:58.826773
# Unit test for function do_urlencode
def test_do_urlencode():
    def check_urlencode(val, res):
        assert do_urlencode(val) == res

    check_urlencode('http://www.example.com/path name?arg=val1&arg=val2', 'http%3A%2F%2Fwww.example.com%2Fpath%20name%3Farg%3Dval1%26arg%3Dval2')
    check_urlencode('café', 'caf%C3%A9')
    check_urlencode('こんにちは', '%E3%81%93%E3%82%93%E3%81%AB%E3%81%A1%E3%81%AF')

# Generated at 2022-06-21 04:46:09.354264
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert '%20' == unicode_urlencode(' ')
    assert '%3D' == unicode_urlencode('=')
    assert '%2F' == unicode_urlencode('/')
    assert '%40' == unicode_urlencode('@')
    assert '%2B' == unicode_urlencode('+')
    assert '%40' == unicode_urlencode('@')
    assert '%2B' == unicode_urlencode('+')
    assert '%C2%A3' == unicode_urlencode(u'\xa3')
    assert '%E2%82%AC' == unicode_urlencode(u'\u20ac')

# Generated at 2022-06-21 04:46:23.083064
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']('%40') == '@'
    if not HAS_URLENCODE:
        assert filters['urlencode']('@') == '%40'

# Generated at 2022-06-21 04:46:31.533414
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%F0%9F%8D%AC%5Cn%5Cn') == u'\U0001f34c\n\n'
    assert unicode_urldecode(u'%F0%9F%8D%AC%5Cn%5Cn') != u'\n\n'


# Unit tests for class FilterModule

# Generated at 2022-06-21 04:46:42.866132
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test that unicode_urldecode decodes UTF-8 '''
    input = u'%C3%A6%C3%B8%C3%A5%C3%A5%C3%A5%20%C3%B8%C3%A5%C3%B8%C3%A5%C3%B8%C3%A5%C3%B8%C3%A5%C3%B8%C3%A5%C3%B8%C3%A5'
    output = u'æøååå øåøåøåøåøå'

# Generated at 2022-06-21 04:46:53.486815
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_strings = dict()
    test_strings['%20']=' '
    test_strings['%2B']='+'
    test_strings['%3A']=':'
    test_strings['%3a']=':'
    test_strings['%09']='\t'
    test_strings['%09%09']='\t\t'
    test_strings['+']=' '
    test_strings['hello']='hello'
    test_strings['hello%09%09']='hello\t\t'
    test_strings['%c3%9f']=u'ss'
    test_strings['%c3%a4']=u'a'
    test_strings['%c3%a4%c3%9f']=u'ass'

# Generated at 2022-06-21 04:47:04.746217
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(123) == '123'
    assert do_urlencode('a=b') == 'a%3Db'
    assert do_urlencode(u'a=b') == 'a%3Db'
    assert do_urlencode(['a', 'b']) == 'a&b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    if PY3:
        assert do_urlencode('~') == '~'
        assert do_urlencode(u'~') == '~'
    else:
        assert do_urlencode('~') == '%7E'
        assert do_urlencode(u'~') == '%7E'


# Generated at 2022-06-21 04:47:19.991485
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abc def') == 'abc%20def'
    assert do_urlencode('abc def&') == 'abc%20def%26'
    assert do_urlencode('/') == '%2F'
    assert do_urlencode('/?') == '%2F%3F'
    assert do_urlencode('/ ') == '%2F%20'
    assert do_urlencode('/%') == '%2F%25'
    assert do_urlencode('/?') == '%2F%3F'
    assert do_urlencode('/?=&') == '%2F%3F%3D%26'
    assert do_urlencode({'abc': 'def'}) == 'abc=def'


# Generated at 2022-06-21 04:47:21.297952
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urlencode' in FilterModule.filters(FilterModule)



# Generated at 2022-06-21 04:47:29.691092
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.utils.unicode import to_unicode
    assert unicode_urldecode('%7B%22a%22:%22b%22%7D') == u'{"a":"b"}'
    assert unicode_urldecode('%7B%22a%22:%22b%22%7D%7B%22a%22:%22b%22%7D') == u'{"a":"b"}{"a":"b"}'


# Generated at 2022-06-21 04:47:33.608888
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'



# Generated at 2022-06-21 04:47:36.334714
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%2B1') == 'abc+1'


# Generated at 2022-06-21 04:47:49.439239
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters["urldecode"]('%23%25%20%E2%82%AC%26') == '#% €&'
    if not HAS_URLENCODE:
        assert filters["urlencode"]('#% €&') == '%23%25%20%E2%82%AC%26'
        assert filters["urlencode"]({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Generated at 2022-06-21 04:48:02.247023
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:48:10.111865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%E5%95%8F%E9%A1%8C') == u'問題'
    if not HAS_URLENCODE:
         assert FilterModule().filters()['urlencode']('問題') == '%E5%95%8F%E9%A1%8C'


# Generated at 2022-06-21 04:48:11.931458
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert 'urldecode' in module.filters()
    assert 'urlencode' not in module.filters()

# Generated at 2022-06-21 04:48:15.690547
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wieers') == u'dag wieers'

# Generated at 2022-06-21 04:48:21.990491
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    for k, v in iteritems(m.filters()):
        if k != 'urlencode' or not HAS_URLENCODE:
            assert v() == ''

# Generated at 2022-06-21 04:48:30.785728
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    """ Unit test for method filters of class FilterModule """

    filters = FilterModule().filters()
    assert int(filters['urldecode']('%7B%22a%22%3A%22b%22%7D')) == {u'a': u'b'}

    if not HAS_URLENCODE:
        assert filters['urlencode']({u'a': u'b'}) == u'a=b'

# Generated at 2022-06-21 04:48:42.247071
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('hello world') == 'hello%20world'
    assert do_urlencode(['hello', 'world']) == 'hello&world'
    assert do_urlencode('hello world') == 'hello%20world'
    assert do_urlencode(['hello', 'world']) == 'hello&world'
    assert do_urlencode(['hello=world', 'foo=bar']) == 'hello%3Dworld&foo%3Dbar'
    assert do_urlencode(['hello=world', 'foo bar']) == 'hello%3Dworld&foo%20bar'
    assert do_urlencode({'hello': 'world', 'foo': 'bar'}) == 'hello=world&foo=bar'

# Generated at 2022-06-21 04:48:48.963802
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%00") == "\x00"
    assert do_urldecode("%20") == " "
    assert do_urldecode("%23") == "#"
    assert do_urldecode("%2F") == "/"
    assert do_urldecode("%2f") == "/"
    assert do_urldecode("%5E") == "^"
    assert do_urldecode("%5e") == "^"
    assert do_urldecode("%7E") == "~"
    assert do_urldecode("%7e") == "~"
    assert do_urldecode("%2B") == "+"
    assert do_urldecode("%2b") == "+"

# Generated at 2022-06-21 04:48:55.673080
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    utf8str = '%C3%B6'
    str = unicode_urldecode(utf8str)
    assert str == u'ö'


# Generated at 2022-06-21 04:49:05.593525
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+%20bar+baz') == u'foo bar baz'



# Generated at 2022-06-21 04:49:18.177375
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test method filters of class FilterModule without Jinja2
    filt = FilterModule()
    filters = filt.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode
    # Test method filters of class FilterModule with Jinja2 2.6 or older
    filters['urlencode'] = do_urlencode
    filters['urldecode'] = do_urldecode
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode
    assert filters['urlencode'] is not do_urlencode
    # Test method filters of class FilterModule with Jinja2 2.7 or newer
    filters['urlencode'] = do_urlencode

# Generated at 2022-06-21 04:49:28.866694
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo bar baz') == u'foo%20bar%20baz'
    assert do_urlencode(u'foo bar baz') == u'foo%20bar%20baz'
    assert do_urlencode({'foo': 'bar', 'baz': u'台灣'}) == u'foo=bar&baz=%E5%8F%B0%E7%81%A3'

# Generated at 2022-06-21 04:49:35.423819
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test is not None
    assert test.filters() is not None
    assert isinstance( test.filters() , dict)
    assert 'urldecode' in test.filters().keys()
    assert 'urlencode' in test.filters().keys() # Ansible 2.5 removed this filter

# Generated at 2022-06-21 04:49:36.071833
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:49:37.220253
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None


# Generated at 2022-06-21 04:49:49.977798
# Unit test for function do_urlencode
def test_do_urlencode():
    # Unit tests when not supported
    string = 'http://github.com/dagwieers?a=1&b=2'
    assert do_urlencode(string) == 'http%3A%2F%2Fgithub.com%2Fdagwieers%3Fa%3D1%26b%3D2'

    # Unit tests with string vs list
    assert do_urlencode('http://github.com/dagwieers?a=1&b=2') == 'http%3A%2F%2Fgithub.com%2Fdagwieers%3Fa%3D1%26b%3D2'

# Generated at 2022-06-21 04:49:56.726293
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'\u00e4'
    assert unicode_urldecode('a%C3%A4c') == u'a\u00e4c'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == u'\u00e4\u00f6\u00fc'
    assert unicode_urldecode('a%C3%A4b%C3%B6c%C3%BCd') == u'a\u00e4b\u00f6c\u00fcd'


# Generated at 2022-06-21 04:49:57.623575
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None


# Generated at 2022-06-21 04:50:01.205912
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'


# Generated at 2022-06-21 04:50:10.468465
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20%20+%20%20') == '  +   '


# Generated at 2022-06-21 04:50:14.436410
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert u'urldecode' in filters


# Generated at 2022-06-21 04:50:23.298473
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert('a' == unicode_urlencode('a'))
    assert('b' == unicode_urlencode('b'))
    assert(u'a=b' == unicode_urlencode((u'a', u'b')))
    assert(u'a=b' == unicode_urlencode([u'a', u'b']))
    assert(u'a=b' == unicode_urlencode({u'a': u'b'}))
    assert(u'a=b' == unicode_urlencode({u'a': u'b'}, for_qs=True))
    assert(u'a%3Db' == unicode_urlencode(u'a=b'))