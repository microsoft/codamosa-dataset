

# Generated at 2022-06-21 04:40:23.658151
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"foo+bar") == u"foo bar"
    assert unicode_urldecode(u"foo%20bar") == u"foo bar"
    assert unicode_urldecode(u"foo+bar%20") == u"foo bar "
    assert unicode_urldecode(u"%7B%7B uri.query.foo %7D%7D") == u"{{ uri.query.foo }}"


# Generated at 2022-06-21 04:40:35.745669
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleFilterError

    # Method is called without any parameters
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert 'urldecode' in filters

    if HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in filters

    assert filters['urldecode'] == do_urldecode

    # Method is called with parameters
    # Invalid number of parameters (0)

# Generated at 2022-06-21 04:40:38.048734
# Unit test for function do_urldecode
def test_do_urldecode():
    test_data = [
        (u'foo+bar%20spam', u'foo bar spam'),
        (u'foo', u'foo'),
    ]
    for string, expected in test_data:
        assert do_urldecode(string) == expected



# Generated at 2022-06-21 04:40:44.243850
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert (unicode_urldecode(b'foo%20bar%2Bbaz') == 'foo bar+baz')
    assert (unicode_urldecode('foo%20bar%2Bbaz') == 'foo bar+baz')



# Generated at 2022-06-21 04:40:54.425521
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    assert fm.filters()['urldecode']('%2Ftest') == '/test'

    # Check that we can add our own urlencode filter when Jinja2 is older than v2.7
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('/test') == '%2Ftest'
        assert fm.filters()['urlencode']({ 'test': '/test' }) == 'test=%2Ftest'
        assert fm.filters()['urlencode'](['test', '/test']) == 'test=%2Ftest'

# Generated at 2022-06-21 04:41:06.467280
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%e9') == u'é'
    assert unicode_urldecode('%80%80') == u'€'
    assert unicode_urldecode('%u2020') == u'†'
    assert unicode_urldecode('%20%20') == u'  '
    assert unicode_urldecode('%20%20') != '  '
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%e9') == u'é'
    assert unicode_urldecode(u'%80%80') == u'€'
    assert unicode

# Generated at 2022-06-21 04:41:21.263383
# Unit test for function do_urlencode
def test_do_urlencode():

    if not PY3:
        def to_bytes(s):
            return s


# Generated at 2022-06-21 04:41:28.237735
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20%21%22%23%24%25%26%27%28%29%2A%2B%2C%2F%30') == ' !"#$%&\'()*+,-/0'

# Generated at 2022-06-21 04:41:29.207834
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'Hello%2BWorld%21') == u'Hello+World!'



# Generated at 2022-06-21 04:41:38.860824
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test do_urldecode
    assert do_urldecode('abc%20def') == 'abc def'
    assert do_urldecode('abc%2Fdef') == 'abc/def'

    # test do_urlencode
    assert do_urlencode('abc def') == 'abc+def'
    assert do_urlencode('abc@def') == 'abc%40def'
    assert do_urlencode(dict(a='b', c='d')) == 'a=b&c=d'
    assert do_urlencode(['a', 'b', 'c', 'd']) == 'a&b&c&d'



# Generated at 2022-06-21 04:41:42.572588
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urldecode' in FilterModule().filters()

# Generated at 2022-06-21 04:41:51.217794
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Note that Jinja2 must be installed to run this test.
    import ansible_collections.ansible.community.plugins.filter.core as filter_module
    import jinja2.filters
    import jinja2.runtime
    filter_modobj = filter_module.FilterModule()
    jinja2_filters = jinja2.runtime.FILTERS
    # Test some filters for which we provide our own implementation.
    for filter_name in ('urldecode', 'urlencode'):
        assert filter_name in filter_modobj.filters(), ('Filter %s not defined' % filter_name)
        if filter_name in jinja2_filters:
            def my_urlencode(s):
                return filter_modobj.filters()[filter_name](s)
            jin

# Generated at 2022-06-21 04:41:54.394365
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    """
    >>> test_unicode_urldecode()
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 04:42:02.065235
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    """
    Ensure that unicode_urlencode works as expected
    """

    # Simple key value
    assert unicode_urlencode('key') == 'key'
    assert unicode_urlencode('key-value') == 'key-value'
    assert unicode_urlencode('key value') == 'key+value'

    # Simple key value pairs
    assert unicode_urlencode({'key': 'value'}) == 'key=value'
    assert unicode_urlencode({'key-value': 'value'}) == 'key-value=value'
    assert unicode_urlencode({'key value': 'value'}) == 'key+value=value'
    assert unicode_urlencode({'key': 'value value'}) == 'key=value+value'

# Generated at 2022-06-21 04:42:04.924521
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert hasattr(f, "filters")

# Generated at 2022-06-21 04:42:06.455431
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)
    assert isinstance(FilterModule(), object)


# Generated at 2022-06-21 04:42:13.719830
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    string_to_encode = u"apa/bepa"
    expected_output = u"apa%2Fbepa"

    assert unicode_urlencode(string_to_encode) == expected_output

    string_to_encode = u"apa/bepa bepa"
    expected_output = u"apa%2Fbepa%20bepa"

    assert unicode_urlencode(string_to_encode) == expected_output

    string_to_encode = u"apa/bepa bepa"
    expected_output = u"apa%2Fbepa+bepa"

    assert unicode_urlencode(string_to_encode, for_qs=True) == expected_output



# Generated at 2022-06-21 04:42:27.818474
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abcd efgh') == u'abcd%20efgh'
    assert do_urlencode(u'abcd/efgh') == u'abcd%2Fefgh'
    assert do_urlencode(u'abcd,efgh') == u'abcd%2Cefgh'
    assert do_urlencode(u'abcd&efgh') == u'abcd%26efgh'
    assert do_urlencode(u'abcd=efgh') == u'abcd=efgh'
    assert do_urlencode(u'abcd efgh ijkl') == u'abcd%20efgh%20ijkl'

# Generated at 2022-06-21 04:42:37.823485
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' urldecode should decode a string using unquote_plus '''
    assert unicode_urldecode('%20%21%0A%0D') == u' !\n\r'
    assert unicode_urldecode('%20%21%0A%0D'.encode('utf-8')) == u' !\n\r'
    assert unicode_urldecode('%20%21%0A%0D'.decode('utf-8')) == u' !\n\r'



# Generated at 2022-06-21 04:42:44.420233
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:42:50.291310
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    expected = u'Aardvark / Antelope'
    actual = unicode_urldecode(u'Aardvark+%2F+Antelope')
    assert actual == expected


# Generated at 2022-06-21 04:42:58.670987
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-21 04:43:05.054408
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('s%20d') == 's d'
    assert do_urldecode('s+d') == 's d'
    assert do_urldecode('%3A%2F%2F') == '://'
    assert do_urlencode('s d') == 's%20d'
    assert do_urlencode('s+d') == 's%2Bd'
    assert do_urlencode({'k1': 'v1', 'k2': 'v2'}) == 'k1=v1&k2=v2'
    assert do_urlencode(['k1=v1', 'k2=v2']) == 'k1%3Dv1&k2%3Dv2'

# Generated at 2022-06-21 04:43:15.598926
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%2Bb%2Bc') == 'a+b+c'
    assert do_urldecode('a+b+c') == 'a+b+c'
    assert do_urldecode('a%2bb%2bc') == 'abbc'
    assert do_urldecode('a b c') == 'a b c'

    assert do_urldecode(['a%2Bb%2Bc', 'a%2bb%2bc', 'a+b+c', 'a b c']) == ['a+b+c', 'abbc', 'a+b+c', 'a b c']


# Generated at 2022-06-21 04:43:19.863083
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode
    assert filter_module.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:43:30.898638
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('@') == u'%40'
    assert unicode_urlencode('!') == u'%21'
    assert unicode_urlencode('$') == u'%24'
    assert unicode_urlencode('@') == u'%40'
    assert unicode_urlencode('#') == u'%23'
    assert unicode_urlencode('%') == u'%25'
    assert unicode_urlencode('^') == u'%5E'
    assert unicode_urlencode('&') == u'%26'
    assert unicode_urlencode('+') == u'%2B'

# Generated at 2022-06-21 04:43:42.643742
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%7Eusername') == '~username'
    assert do_urldecode('%7eusername') == '~username'
    assert do_urldecode('%7eusername') == '~username'
    assert do_urldecode('%7eusername') == '~username'
    assert do_urldecode('%7Eusername%40example.com') == '~username@example.com'
    assert do_urldecode('%7Eusername%2Bsomething') == '~username+something'
    assert do_urldecode('%7Eusername%3Fsomething') == '~username?something'



# Generated at 2022-06-21 04:43:44.487819
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj


# Generated at 2022-06-21 04:43:45.334804
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()

# Generated at 2022-06-21 04:44:00.578536
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' ', "do_urldecode('%20') == ' '"
    assert do_urldecode('%21') == '!', "do_urldecode('%21') == '!'"
    assert do_urldecode('%7E') == '~', "do_urldecode('%7E') == '~'"
    assert do_urldecode('%2F') == '/', "do_urldecode('%2F') == '/'"
    assert do_urldecode('%2f') == '/', "do_urldecode('%2f') == '/'"
    assert do_urldecode('%40') == '@', "do_urldecode('%40') == '@'"
    assert do_urldec

# Generated at 2022-06-21 04:44:14.823523
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http://example.com') == u'http://example.com'
    assert do_urldecode('http://example.com/%20') == u'http://example.com/ '
    assert do_urldecode('http://example.com/%2F') == u'http://example.com/'
    assert do_urldecode('http://example.com/%252F') == u'http://example.com/%2F'


# Generated at 2022-06-21 04:44:19.843967
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello%2C%20World%21') == 'Hello, World!'
    assert unicode_urldecode('Hello+World!') == 'Hello World!'
    assert unicode_urldecode('Hello%20World!') == 'Hello World!'
    assert unicode_urldecode('%41pple') == 'Apple'
    assert unicode_urldecode('%41=%42+%43') == 'A=B+C'
    assert unicode_urldecode('%41%42%43') == 'ABC'
    assert unicode_urldecode('') == ''



# Generated at 2022-06-21 04:44:29.575018
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'Hello World') == u'Hello%20World'
    assert unicode_urlencode(u'Hellö Wörld') == u'Hell%C3%B6%20W%C3%B6rld'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'//') == u'%2F%2F'
    assert unicode_urlencode(u'/', for_qs=True) == u'/'
    assert unicode_urlencode(u'//', for_qs=True) == u'%2F%2F'
    assert unicode_urlencode([u'foo', u'bar']) == u'foo&bar'


# Generated at 2022-06-21 04:44:38.097028
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%20%24%3F%3D%2F%2B%26') == ' $?=/+&'


# Generated at 2022-06-21 04:44:50.881621
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://example.com/ test/') == r'http%3A%2F%2Fexample.com%2F%20test%2F'
    assert do_urlencode('http://example.com/ test') == r'http%3A%2F%2Fexample.com%2F%20test'
    assert do_urlencode('/ test') == r'%2F%20test'
    assert do_urlencode(u'/ test') == r'%2F%20test'
    assert do_urlencode('/') == r'%2F'
    assert do_urlencode(u'/') == r'%2F'

# Generated at 2022-06-21 04:45:02.781284
# Unit test for function do_urldecode

# Generated at 2022-06-21 04:45:07.635055
# Unit test for function do_urlencode
def test_do_urlencode():
    """Test do_urlencode."""

    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode({'a b': 'c d'}) == 'a+b=c+d'

# Generated at 2022-06-21 04:45:11.894146
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    >>> test_do_urldecode()
    '''
    assert do_urldecode('%2B') == u'+'
    assert do_urldecode('%2b') == u'+'
    assert do_urldecode('%2f') == u'/'


# Generated at 2022-06-21 04:45:14.209150
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    print("python version:", sys.version)
    print("filter module: {0}".format(filter_module))


# Generated at 2022-06-21 04:45:22.728256
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'f/o/o') == u'f%2Fo%2Fo'
    assert do_urlencode(['f', 'o', 'o']) == u'f=o=o'
    assert do_urlencode([u'f', u'o', u'o']) == u'f=o=o'
    assert do_urlencode({u'f': u'o', u'o': None}) == u'f=o=None'
    assert do_urlencode({u'f': u'o', u'o': [u'bar', u'baz']}) == u'f=o=bar=baz'

# Generated at 2022-06-21 04:45:40.275445
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == '', "unicode_urlencode() test failed"
    assert unicode_urlencode(u'foo') == 'foo', "unicode_urlencode() test failed"
    assert unicode_urlencode(u'foo bar') == 'foo%20bar', "unicode_urlencode() test failed"
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar', "unicode_urlencode() test failed"
    assert unicode_urlencode(u'foo/?bar') == 'foo%2F%3Fbar', "unicode_urlencode() test failed"
    assert unicode_urlencode(u'foo?bar') == 'foo?bar', "unicode_urlencode() test failed"
    assert unicode_

# Generated at 2022-06-21 04:45:42.059768
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)

# Generated at 2022-06-21 04:45:49.435943
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode('string') == 'string'
    assert do_urlencode('/path/to/something') == '%2Fpath%2Fto%2Fsomething'
    assert do_urlencode('{') == '%7B'
    assert do_urlencode('}') == '%7D'
    assert do_urlencode('@') == '%40'
    assert do_urlencode('+') == '%2B'
    # Hint: urlencode is not unicode compliant when using a unicode string
    #assert do_urlencode(u'\u4e2d\u6587') == '%E4%B8%AD%E6%96%87'

# Generated at 2022-06-21 04:45:59.549443
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%20") == u" "
    assert unicode_urldecode(u"%E2%82%AC") == u"€"
    assert unicode_urldecode(u"%E2%82%AC%E2%9C%A8") == u"€✨"
    assert unicode_urldecode(u"%2F") == u"/"
    assert unicode_urldecode(u"%E2%82%AC%E2%9C%A8") == u"€✨"
    assert unicode_urldecode(u"%a") == u"%a"

# Generated at 2022-06-21 04:46:12.091365
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('string') == 'string'
    assert unicode_urlencode('a/string') == 'a%2Fstring'
    assert unicode_urlencode('a/string', for_qs=True) == 'a%2Fstring'
    assert unicode_urlencode('a+string') == 'a+string'
    assert unicode_urlencode('a+string', for_qs=True) == 'a%2Bstring'
    assert unicode_urlencode('a/string') == 'a%2Fstring'
    assert unicode_urlencode('a/string', for_qs=True) == 'a%2Fstring'


# Generated at 2022-06-21 04:46:19.624670
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import pytest
    import ansible.module_utils.six as six
    from ansible.module_utils.six import PY3

    fm = FilterModule()
    filters = fm.filters()

    if not PY3:
        assert 'urldecode' in filters
        assert 'urlencode' in filters

    assert 'urldecode' in filters
    urldecode = filters['urldecode']
    assert urldecode('%C3%A8') == u'\xe8'

    if not PY3:
        assert urldecode('%C3%A8') == u'\xe8'
        assert urldecode('%25C3%25A8') == u'%25C3%25A8'

        assert 'urlencode' in filters

# Generated at 2022-06-21 04:46:25.290296
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing %s()" % unicode_urldecode.__name__)
    assert unicode_urldecode(u'foo%40bar') == u'foo@bar'



# Generated at 2022-06-21 04:46:34.866890
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert 'urldecode' in filters
    assert 'urlencode' in filters

    aa = '@'
    ab = '%40'
    assert filters['urldecode'](ab) == aa
    assert filters['urlencode'](ab) == ab
    if HAS_URLENCODE:
        assert filters['urlencode'](aa) == ab

# Generated at 2022-06-21 04:46:38.593407
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%8Atre') == 'étré'
    assert unicode_urldecode('a+b') == 'a b'


# Generated at 2022-06-21 04:46:43.656231
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('abcdefgh') == 'abcdefgh')
    assert(do_urlencode('abc def ghi') == 'abc%20def%20ghi')
    assert(do_urlencode(['a', 'b', 'c d']) == 'a&b&c%20d')
    assert(do_urlencode({1: 'a', 'b': 'c d'}) == '1=a&b=c%20d')

# Generated at 2022-06-21 04:46:59.223588
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('k%C3%BCche') == u'küche'


# Generated at 2022-06-21 04:47:08.040450
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': ['bar', 'baz']}) == 'foo=bar&foo=baz'
    assert do_urlencode(['foo', ['bar', 'baz']]) == 'foo&bar&baz'
    assert do_urlencode(['foo&bar', ['bar', 'baz']]) == 'foo%26bar&bar&baz'

# Generated at 2022-06-21 04:47:09.539271
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    filterModule.filters()
    filterModule.filters()

# Generated at 2022-06-21 04:47:10.011830
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:47:20.713857
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo?bar=') == '/foo%3Fbar%3D'
    assert unicode_urlencode('/foo?bar=') == '/foo%3Fbar%3D'
    assert unicode_urlencode('/foo?bar=/') == '/foo%3Fbar%3D/'
    assert unicode_urlencode('/foo?bar=/') == '/foo%3Fbar%3D/'



# Generated at 2022-06-21 04:47:32.419210
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode(['a', 'b']) == 'a&b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode({'c': 'd', 'a': 'b'}) == 'c=d&a=b'
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'
    assert do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'
   

# Generated at 2022-06-21 04:47:38.914479
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "hello%20%20world%21"
    expected = "hello  world!"
    output = unicode_urldecode(string)
    if output != expected:
        print("_(" + string + ") = " + output + " != " + expected)
        return False
    return True


# Generated at 2022-06-21 04:47:44.858300
# Unit test for function do_urldecode
def test_do_urldecode():
    urlencoded = 'This+string%26has%3D%25some%2Fstuff%20in+it%21'
    urldecoded = 'This string&has=%some/stuff in it!'
    assert do_urldecode(urlencoded) == urldecoded


# Generated at 2022-06-21 04:47:52.324773
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'bob', for_qs=False) == u'bob'
    assert unicode_urlencode(u'bob', for_qs=True) == u'bob'
    assert unicode_urlencode(u'test space', for_qs=False) == u'test%20space'
    assert unicode_urlencode(u'test space', for_qs=True) == u'test+space'
    assert unicode_urlencode(u'test=string', for_qs=False) == u'test%3Dstring'
    assert unicode_urlencode(u'test=string', for_qs=True) == u'test%3Dstring'

# Generated at 2022-06-21 04:47:58.381916
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    This function tests unicode_urlencode against known Python 2 and 3 output
    '''
    import sys


# Generated at 2022-06-21 04:48:17.539878
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test creating FilterModule class
    module = FilterModule()
    # Test creating filters
    filters = module.filters()
    # Check if filters is dict
    assert isinstance(filters, dict) == True


# Generated at 2022-06-21 04:48:21.405947
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('/my-%2Fpath/') == '/my-/path/'


# Generated at 2022-06-21 04:48:25.839686
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters().get('urldecode', 'Fail') != 'Fail'
    assert FilterModule().filters().get('urlencode', 'Fail') != 'Fail'



# Generated at 2022-06-21 04:48:31.808997
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urlencode']('some@thing%20else') == 'some%40thing%2520else'
    assert filters['urldecode']('some%40thing%2520else') == 'some@thing%20else'



# Generated at 2022-06-21 04:48:39.422705
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2Fhome%2F') == u'/home/'


# Generated at 2022-06-21 04:48:40.738111
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm  # silence code check

# Generated at 2022-06-21 04:48:54.855602
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.com/foo/bar') == u'http%3A//www.example.com/foo/bar'
    assert unicode_urlencode('http://www.example.com/foo/bar', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://www.example.com/foo/bar') == u'http%3A//www.example.com/foo/bar'
    assert unicode_urlencode(u'http://www.example.com/foo/bar', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2Ffoo%2Fbar'
    assert unicode_

# Generated at 2022-06-21 04:49:00.570510
# Unit test for function do_urlencode
def test_do_urlencode():
    test_str = '/someurl/ %s'
    assert unicode_urlencode('some/sombrero') == 'some%2Fsombrero'
    assert unicode_urlencode('some/sombrero', for_qs=True) == 'some%2Fsombrero'
    assert unicode_urlencode(test_str) == test_str
    assert unicode_urlencode(test_str, for_qs=True) == test_str
    assert unicode_urlencode({'some' : 'thing/else'}) == 'some=thing%2Felse'
    assert unicode_urlencode({'some' : 'thing/else'}, for_qs=True) == 'some=thing%2Felse'

# Generated at 2022-06-21 04:49:09.737483
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence

    # Test dict
    dict_test = {'test_key': 'test_value'}
    encoded_test = 'test_key=test_value'

    fm = FilterModule()
    for filter_name, _filter in iteritems(fm.filters()):
        if filter_name == 'urldecode':
            assert dict_test == _filter(encoded_test)
        elif filter_name == 'urlencode':
            assert encoded_test == _filter(dict_test)
        else:
            assert NotImplementedError(filter_name)

    # Test list
    list_test = ['test_key', 'test_value']

# Generated at 2022-06-21 04:49:11.197110
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()


# Generated at 2022-06-21 04:49:30.961508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit test of ``FilterModule.filters()``'''
    import pytest

    # create object with ``filters()`` method
    obj = FilterModule()

    # get ``filters()`` return value and verify data type
    ret = obj.filters()
    assert isinstance(ret, dict), \
        "Return type of ``filters()`` method is ``dict``."

    # verify expected filters are present
    assert 'urldecode' in ret, \
        "``urldecode`` filter is present."
    if not HAS_URLENCODE:
        assert 'urlencode' in ret, \
            "``urlencode`` filter is present."



# Generated at 2022-06-21 04:49:39.465973
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("foo") == "foo"
    assert do_urlencode("foo bar") == "foo%20bar"
    assert do_urlencode("foo+bar") == "foo%2Bbar"
    assert do_urlencode("http://www.example.com/foo?a=b") == "http%3A%2F%2Fwww.example.com%2Ffoo%3Fa%3Db"
    assert do_urlencode("http://www.example.com/foo/+") == "http%3A%2F%2Fwww.example.com%2Ffoo%2F%2B"
    assert do_urlencode({'a': 'b'}) == 'a=b'

# Generated at 2022-06-21 04:49:45.609401
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import unittest

    class mock_object(object):
        def __init__(self, hash):
            self.hash = hash
        def __iter__(self):
            return iter(self.hash)

    class mock_dict(dict):
        pass

    class mock_string(str):
        pass

    class mock_bytes(bytes):
        pass

    class TestFilterModule(unittest.TestCase):
        def setUp(self):
            self.module = FilterModule()

        def test_FilterModule_filters_urldecode(self):
            self.assertTrue('+' in do_urldecode('%2B'))
            self.assertTrue('you%20are%20here' in do_urldecode('you+are+here'))

# Generated at 2022-06-21 04:49:47.360536
# Unit test for constructor of class FilterModule
def test_FilterModule():
    dict1 = {}
    dict2 = {}
    FilterModule()
    assert dict1 == dict2

# Generated at 2022-06-21 04:50:00.347355
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('key=val') == 'key%3Dval'
    assert do_urlencode('key=val&foo=bar') == 'key%3Dval&foo%3Dbar'
    assert do_urlencode({'key': 'val'}) == 'key%3Dval'
    assert do_urlencode({'key': 'val', 'foo': 'bar'}) == 'key%3Dval&foo%3Dbar'
    assert do_urlencode(['key=val', 'foo=bar']) == 'key%3Dval&foo%3Dbar'
    assert do_urlencode(('key=val', 'foo=bar')) == 'key%3Dval&foo%3Dbar'

# Generated at 2022-06-21 04:50:11.816517
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Studio%20A%26B') == u'Studio A&B'

# Unit test it with Python2
if PY3 is False:
    # Unit test for function unicode_urlencode
    def test_unicode_urlencode():
        assert unicode_urlencode(u'Studio A&B', for_qs=False) == 'Studio%20A%26B'
        assert unicode_urlencode(u'Studio A&B', for_qs=True) == 'Studio+A%26B'

    def test_do_urldecode():
        assert do_urldecode(u'Studio A&B') == u'Studio A&B'

    def test_do_urlencode():
        assert do_urlencode(u'Studio A&B') == u

# Generated at 2022-06-21 04:50:22.559869
# Unit test for function do_urldecode
def test_do_urldecode():
    if not PY3:
        assert do_urldecode('%25') == u'%'
        assert do_urldecode('%2D') == u'-'
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%20') == u' '
    assert do_urldecode('a%20b%20c') == u'a b c'
    assert do_urldecode('a+b+c') == u'a b c'
    assert do_urldecode('banana%2Fapple') == u'banana/apple'
    assert do_urldecode('a%5B0%5D') == u'a[0]'