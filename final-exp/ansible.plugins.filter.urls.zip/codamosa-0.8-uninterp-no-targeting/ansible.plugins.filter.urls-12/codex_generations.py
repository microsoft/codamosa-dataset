

# Generated at 2022-06-21 04:40:23.404118
# Unit test for function do_urldecode
def test_do_urldecode():
    test_string = 'a%20string%20with%20spaces%20and%20%24%24'
    expected_string = 'a string with spaces and $$'
    assert do_urldecode(test_string) == expected_string


# Generated at 2022-06-21 04:40:35.671622
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' ansible.module_utils.basic.FilterModule.filters '''
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    # Tests for jinja2.filter
    if HAS_URLENCODE:
        filterfunc = do_urlencode
    else:
        filterfunc = do_urlencode


# Generated at 2022-06-21 04:40:44.484436
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils.urls import url_argument_spec
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    FilterModule._templar = Templar(loader=None, variables=None)

    cls = FilterModule()
    assert hasattr(cls, "filters")
    assert callable(cls.filters)
    assert hasattr(cls.filters(), "_filters")
    assert callable(cls.filters()._filters)

    context = PlayContext()

# Generated at 2022-06-21 04:40:55.702238
# Unit test for function unicode_urldecode

# Generated at 2022-06-21 04:41:06.982154
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u"a=1&b=2" == unicode_urlencode({'a': 1, 'b': 2}, True)
    assert u"a=1&b=2" == unicode_urlencode([('a', 1), ('b', 2)], True)
    assert u"a=1&b=2" == unicode_urlencode(u"a=1&b=2", True)
    assert u"a=%2F" == unicode_urlencode(u"a=/")
    assert u"a=1%20" == unicode_urlencode(u"a=1 ")
    assert u"a=1%20" == unicode_urlencode(u"a=1 ")

# Generated at 2022-06-21 04:41:17.319480
# Unit test for function do_urlencode
def test_do_urlencode():
    if HAS_URLENCODE:
        return
    import pytest
    from jinja2 import Environment, StrictUndefined
    env = Environment(undefined=StrictUndefined)
    env.filters['urlencode'] = do_urlencode
    v = env.from_string('{{ "" | urlencode }}').render()
    assert v == ''
    v = env.from_string('{{ "a" | urlencode }}').render()
    assert v == 'a'
    v = env.from_string('{{ "!@#$" | urlencode }}').render()
    assert v == '%21%40%23%24'
    with pytest.raises(TypeError) as excinfo:
        env.from_string('{{ ["a"] | urlencode }}').render()

# Generated at 2022-06-21 04:41:27.104569
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        # Python 2 implementation
        # The quoted string is identical on Python 2, except that it's a
        # bytestring on Python 2 and a unicode string on Python 3
        assert(unicode_urlencode(u'unicode string') == 'unicode%20string')
        assert(unicode_urlencode(u'/path') == '%2Fpath')
        assert(unicode_urlencode(u'path/') == 'path%2F')
        assert(unicode_urlencode(u'path/') == 'path%2F')
        assert(unicode_urlencode(u'abcd #$%&ä') == 'abcd%20%23%24%25%26%C3%A4')

# Generated at 2022-06-21 04:41:37.294923
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import unittest
    from ansible.module_utils import basic

    class TestFilterModule(unittest.TestCase):

        def test_urldecode(self):
            """This would normally be written as: class TestClass(unittest.TestCase),
            but since we are dynamically generating class methods, there is no other way to do it.
            """
            fm = FilterModule()

            # test known good

# Generated at 2022-06-21 04:41:45.964851
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://site.com/some%20page') == u'http%3A//site.com/some%2520page'
    assert unicode_urlencode(u'http://site.com/some page') == u'http%3A//site.com/some%20page'
    assert unicode_urlencode(u'http://site.com/some page', for_qs=True) == u'http%3A%2F%2Fsite.com%2Fsome+page'

# Generated at 2022-06-21 04:41:56.626685
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == ''
    assert do_urlencode(' ') == ' '
    assert do_urlencode('?') == '%3F'

    assert do_urlencode('UTF-8') == 'UTF-8'
    assert do_urlencode([1, 'two', '3']) == '1&two&3'
    assert do_urlencode({'1': 'one', '2': 'two'}) == '1=one&2=two'

# Generated at 2022-06-21 04:42:10.670343
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://whatever') == 'http%3A%2F%2Fwhatever'
    assert unicode_urlencode(u'http://whatever', for_qs=True) == 'http%3A%2F%2Fwhatever'
    assert unicode_urlencode(b'http://whatever') == 'http%3A%2F%2Fwhatever'
    assert unicode_urlencode(b'http://whatever', for_qs=True) == 'http%3A%2F%2Fwhatever'
    assert unicode_urlencode(u'http://whatever/foo/bar') == 'http%3A%2F%2Fwhatever%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://whatever/foo/bar', for_qs=True)

# Generated at 2022-06-21 04:42:20.451537
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert unicode_urldecode('foo+%2C+bar%3D%5B%5D%5E%60') == 'foo , bar=[ ]^`'
    assert unicode_urldecode('%5B%5D%5E%60') == '[]^`'
    assert unicode_urldecode('%5B') == '['
    assert unicode_urldecode('%5D') == ']'
    assert unicode_urldecode('%5E') == '^'
    assert unicode_urldecode('%60') == '`'
    assert unicode_urldecode('foo%2Cbar') == 'foo,bar'
    assert unicode_urldecode('foo%2cbar') == 'foo,bar'
    assert unicode_urldec

# Generated at 2022-06-21 04:42:32.361724
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves.urllib.parse import parse_qs, unquote

    x = FilterModule()
    assert x.filters() is not None

    s = '_%25_%C3%A8_'
    assert x.filters()['urldecode'](s) == '_%_è_'
    assert x.filters()['urldecode'](unquote(s)) == '_%_è_'

    # Checks for urlencode filter
    s = '_%_è_'
    if not HAS_URLENCODE:
        assert x.filters()['urlencode'](s) == '_%25_%C3%A8_'

# Generated at 2022-06-21 04:42:34.376591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('foo') == 'foo'

# Generated at 2022-06-21 04:42:36.424120
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Generated at 2022-06-21 04:42:46.057546
# Unit test for function do_urldecode

# Generated at 2022-06-21 04:42:57.616781
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%bar') == 'foo%25bar'
    assert do_urlencode('foo bar baz') == 'foo%20bar%20baz'
    assert do_urlencode('foo+bar+baz') == 'foo%2Bbar%2Bbaz'
    assert do_urlencode('foo%bar%baz') == 'foo%25bar%25baz'
    assert do_urlencode('foo bar baz å') == 'foo%20bar%20baz%20%C3%A5'

# Generated at 2022-06-21 04:42:59.986286
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert type(f) is FilterModule


# Generated at 2022-06-21 04:43:02.079288
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' FilterModule.__init__()'''
    FilterModule()

# Generated at 2022-06-21 04:43:07.486946
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%26') == '&'


# Generated at 2022-06-21 04:43:15.832170
# Unit test for function do_urldecode
def test_do_urldecode():
    string = '%E6%B5%8B%E8%AF%95w%3D%26%23x%3b'
    assert do_urldecode(string) == u'测试w=&#x;'


# Generated at 2022-06-21 04:43:19.637206
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo?&=') == 'foo%3F%26%3D'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'


# Generated at 2022-06-21 04:43:30.064101
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'
    assert unicode_urldecode('%E2%82%AC') == u'\u20ac'
    assert unicode_urldecode('%f0%9d%8c%86') == u'\U00013386'
    try:
        unicode_urldecode('%E2%82')
    except UnicodeDecodeError:
        assert True
    else:
        assert False

# Unit tests for function unicode_urlencode

# Generated at 2022-06-21 04:43:33.188949
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Generated at 2022-06-21 04:43:38.033719
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Hello%20World%21') == 'Hello World!'


if __name__ == '__main__':
    # Verify that the function works
    test_do_urldecode()

# Generated at 2022-06-21 04:43:46.207715
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert do_urlencode(u'foo+bar/bam') == 'foo%2Bbar%2Fbam'
    assert do_urlencode({u'a': u'b', u'c': u'd'}) == 'a=b&c=d'
    assert do_urlencode([u'a', u'b', u'c']) == 'a&b&c'
    assert do_urlencode(u'foo++bar') == 'foo%2B%2Bbar'

# Generated at 2022-06-21 04:43:53.680497
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # We expect to be able to decode a unicode string with
    # unicode characters
    if PY3:
        assert unicode_urldecode('%C3%80') == '\u00c0'
    else:
        assert unicode_urldecode('%C3%80') == u'\u00c0'



# Generated at 2022-06-21 04:44:05.181193
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def _str_test(string, expected, for_qs=False):
        result = unicode_urlencode(string, for_qs)
        assert result == expected

    _str_test('string', 'string', for_qs=True)
    _str_test('string', 'string')
    _str_test('sp ace', 'sp+ace', for_qs=True)
    _str_test('sp ace', 'sp%20ace')
    _str_test('/', '%2F')
    _str_test('/', '', for_qs=True)
    _str_test('1+1', '1%2B1', for_qs=True)
    _str_test('1+1', '1+1')
    _str_test('?', '?', for_qs=True)
    _

# Generated at 2022-06-21 04:44:16.451662
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode(None) == ''
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%40%40') == '@@'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%2B%2B') == '++'
   

# Generated at 2022-06-21 04:44:28.288667
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def unit(string, expected, for_qs=False):
        actual = unicode_urlencode(string, for_qs)
        assert actual == expected, 'expected %s, got %s' % (expected, actual)

    unit(u'abc', u'abc')
    unit(u'abc def', u'abc%20def')
    unit(u'abc def', u'abc+def', for_qs=True)

    unit(u'http://example.com/', u'http://example.com/')
    unit(u'http://example.com/?a=1&b=2', u'http://example.com/?a=1&b=2')


# Generated at 2022-06-21 04:44:40.956777
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'Van%20der%20Graaf%20Generator') == u'Van der Graaf Generator'
    assert unicode_urldecode(u'http%3A%2F%2Fwww.google.com%2F') == u'http://www.google.com/'
    assert unicode_urldecode(u'http%3a%2f%2fwww.google.com%2f') == u'http://www.google.com/'



# Generated at 2022-06-21 04:44:42.810130
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-21 04:44:49.090232
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a=1%3B+delete+from+users') == 'a=1; delete from users'
    assert do_urldecode('a=1%2B2+%2B+3%3D+10') == 'a=1+2 + 3= 10'


# Generated at 2022-06-21 04:44:54.252432
# Unit test for function do_urldecode
def test_do_urldecode():
    assert 'test' == do_urldecode('test')
    assert 'test+test' == do_urldecode('test+test')
    assert 'test test' == do_urldecode('test%20test')


# Generated at 2022-06-21 04:44:59.644815
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('s/s') == 's%2Fs'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'


# Generated at 2022-06-21 04:45:12.547428
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode('foo@example.com') == 'foo%40example.com'
    assert do_urlencode('foo@example.com', for_qs=True) == 'foo@example.com'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'

# Generated at 2022-06-21 04:45:17.142780
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar%4baz@quux.com') == 'foo barKbaz@quux.com', 'do_urldecode failed'


# Generated at 2022-06-21 04:45:25.165453
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/')
    assert(do_urldecode(u'http%3A%2F%2Fexample.com%2F') == u'http://example.com/')
    assert(unicode_urlencode({u'a': u'b'}) == u'a=b')
    assert(unicode_urlencode(['a', 'b'], for_qs=True) == u'a=b')
    assert(unicode_urlencode(['a', 'b'], for_qs=False) == u'a&b')
    assert(unicode_urlencode([(u'a', u'b')], for_qs=True) == u'a=b')

# Generated at 2022-06-21 04:45:27.824985
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert (f.filters()['urldecode'] == do_urldecode)

# Generated at 2022-06-21 04:45:36.774742
# Unit test for function unicode_urlencode

# Generated at 2022-06-21 04:45:48.658104
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test for python3 to python3
    if PY3:
        assert unicode_urldecode('a+b%2Bc') == 'a+b+c'
        assert unicode_urldecode('a%2Bb+c') == 'a+b c'

    # test for python2 to python2
    else:
        assert unicode_urldecode('a+b%2Bc') == u'a+b+c'
        assert unicode_urldecode('a%2Bb+c') == u'a+b c'

    # test for python2 to python3
    assert unicode_urldecode(u'a+b%2Bc') == 'a+b+c'

# Generated at 2022-06-21 04:45:50.143049
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule()) == FilterModule


# Generated at 2022-06-21 04:46:00.807469
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("hello world") == u"hello%20world"
    assert unicode_urlencode(u"hello world") == u"hello%20world"
    assert unicode_urlencode("hello world!") == u"hello%20world%21"
    assert unicode_urlencode("Tyrannosaurus Rex & Triceratops") == \
        u"Tyrannosaurus%20Rex%20%26%20Triceratops"
    assert unicode_urlencode("/foo bar/") == u"%2Ffoo%20bar%2F"
    assert unicode_urlencode("100%") == u"100%25"
    assert unicode_urlencode(42) == u"42"

# Generated at 2022-06-21 04:46:03.360419
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    filters = module.filters()
    assert filters['urldecode']
    assert filters['urlencode']

# Generated at 2022-06-21 04:46:17.844253
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test with empty string
    assert do_urlencode('') == ''

    # Test with string
    assert do_urlencode('/my_path/') == '/my_path/'
    assert do_urlencode('my_name =') == 'my_name+%3D'

    # Test with number
    assert do_urlencode(123) == '123'
    assert do_urlencode(123.0) == '123.0'

    # Test with list
    assert do_urlencode([1, 2, 3]) == '1&2&3'
    assert do_urlencode([1, '2', [3]]) == '1&2&3'

    # Test with dictionary

# Generated at 2022-06-21 04:46:21.789466
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:46:32.692137
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule.filters)
    filters = FilterModule.filters(None)
    assert callable(filters['urldecode'])
    if not HAS_URLENCODE:
        assert callable(filters['urlencode'])
    assert 'urldecode' in filters
    assert filters['urldecode'].__name__ == 'do_urldecode'
    if not HAS_URLENCODE:
        assert filters['urlencode'].__name__ == 'do_urlencode'



# Generated at 2022-06-21 04:46:41.348760
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'Lärm'
    result = u'L%C3%A4rm'
    assert(unicode_urlencode(string) == result)
    assert(unicode_urlencode(string, for_qs=True) == result)
    assert(unicode_urlencode({u'foo': u'bar baz'}) == u'foo=bar+baz')
    assert(unicode_urlencode([u'foo', u'bar baz']) == u'foo&bar+baz')


# Generated at 2022-06-21 04:46:45.395437
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert do_urldecode == filters['urldecode']
    if not HAS_URLENCODE:
        assert do_urlencode == filters['urlencode']

# Generated at 2022-06-21 04:46:59.479336
# Unit test for function do_urlencode
def test_do_urlencode():
    # verify we produce the same output as the jinja2 function for string values
    assert do_urlencode('extravagant') == do_urlencode('extravagant')

    # verify we produce the same output as the jinja2 function for lists (iterables)
    assert do_urlencode(['extravagant', 'magnificent']) == do_urlencode(['extravagant', 'magnificent'])

    # verify we produce the same output as the jinja2 function for dicts (iterables with keys)
    assert do_urlencode({'word': 'extravagant', 'sentence': 'magnificent'}) == do_urlencode({'word': 'extravagant', 'sentence': 'magnificent'})

    # verify we produce a string where the jinja2

# Generated at 2022-06-21 04:47:19.915727
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test that unicode_urlencode behaves like urlencode
    try:
        # urlencode is not available in Python3
        from urllib import urlencode
    except ImportError:
        assert not HAS_URLENCODE
        from six.moves.urllib.parse import urlencode
    assert unicode_urlencode("") == urlencode("")
    assert unicode_urlencode("abc") == urlencode("abc")
    assert unicode_urlencode("a+b") == urlencode("a+b")
    assert unicode_urlencode("a+b b+a") == urlencode("a+b b+a")
    assert unicode_urlencode(u"a+b b+a") == urlencode(u"a+b b+a")
    assert unicode

# Generated at 2022-06-21 04:47:20.622080
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x

# Generated at 2022-06-21 04:47:22.148293
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%20") == " "

# Generated at 2022-06-21 04:47:33.329038
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:47:42.738890
# Unit test for function do_urldecode

# Generated at 2022-06-21 04:47:44.504885
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().__module__.endswith('.jinja2_filters')


# Generated at 2022-06-21 04:47:52.105765
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Tests that do_urlencode() behaves the same as Jinja's urlencode when
    # Jinja2 is older than v2.7
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%20bar') == 'foo%2520bar'
    assert do_urlencode('foo@bar') == 'foo%40bar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo=bar') == 'foo%3Dbar'
    assert do_urlencode('') == ''
    assert do_urlencode('å') == '%C3%A5'

# Generated at 2022-06-21 04:47:53.428942
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass


# Generated at 2022-06-21 04:47:54.952038
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:48:06.816177
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import (unquote_plus, urlencode as stdlib_urlencode)

# Generated at 2022-06-21 04:48:16.981539
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    assert FilterModule().filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:48:25.500282
# Unit test for function do_urlencode
def test_do_urlencode():
    '''
    Testcases for do_urlencode
    '''
    # test case 1: integer type
    test_int = 123
    assert do_urlencode(test_int) == "123"

    # test case 2: string type
    test_str = "abc"
    assert do_urlencode(test_str) == "abc"

    # test case 3: unicode string type
    test_unic_str = u"def"
    assert do_urlencode(test_unic_str) == "def"

    # test case 4: list type
    test_list = ['ab', 'cd']
    assert do_urlencode(test_list) == "ab&cd"

    # test case 5: dict type
    test_dict = {'ab': 'cd', 'ef': 'gh'}

# Generated at 2022-06-21 04:48:27.470593
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters('') == {'urldecode': do_urldecode}
    assert FilterModule.filters('') != {}


# Generated at 2022-06-21 04:48:35.785613
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def urlencode(value):
        return unicode_urlencode(value, for_qs=True)

    assert urlencode('foo') == u'foo'
    assert urlencode('foo bar') == u'foo+bar'
    assert urlencode('foo%20bar') == u'foo%20bar'
    assert urlencode(u'⚡') == u'%E2%9A%A1'
    assert urlencode(u'❤') == u'%E2%9D%A4'
    assert urlencode(u'✈') == u'%E2%9C%88'

# Generated at 2022-06-21 04:48:46.958304
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('https%3A%2F%2Fgalaxy.ansible.com%2Flist%3Fpage%3D1%26page_size%3D20') == u'https://galaxy.ansible.com/list?page=1&page_size=20'
    assert do_urldecode('https%3A%2F%2Fgalaxy.ansible.com%2Flist%3Fpage%3D1%26page_size%3D20%26order_by%3D-download_count%26format%3Djson') == u'https://galaxy.ansible.com/list?page=1&page_size=20&order_by=-download_count&format=json'


# Generated at 2022-06-21 04:48:55.694379
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode
        assert filters['urlencode'] != do_urlencode
    assert not HAS_URLENCODE or filters['urlencode'] == do_urlencode


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-21 04:48:57.941774
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x

# Generated at 2022-06-21 04:49:01.719792
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%C3%9Cber+%F0%9F%92%A9') == u'Über 💩'



# Generated at 2022-06-21 04:49:08.132633
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%20") == " "
    assert unicode_urldecode("foo+bar") == "foo bar"
    assert unicode_urldecode("foo bar") == "foo bar"


# Generated at 2022-06-21 04:49:22.151395
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://såkø.com/') == u'http%3A%2F%2Fs%C3%A5k%C3%B8.com%2F'
    assert unicode_urlencode(u'http://såkø.com/?a=5&b=6') == u'http%3A%2F%2Fs%C3%A5k%C3%B8.com%2F%3Fa%3D5%26b%3D6'

# Generated at 2022-06-21 04:49:41.356948
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'a': 'b c'}) == 'a=b+c'
    assert do_urlencode("foo bar") == "foo+bar"

    assert do_urlencode("~") == "%7E"
    assert do_urlencode("%") == "%25"
    assert do_urlencode("=") == "%3D"
    assert do_urlencode("+") == "%2B"
    assert do_urlencode("&") == "%26"

    assert do_urlencode("foo bar", for_qs=True) == "foo+bar"

    assert do_urlencode("~", for_qs=True) == "%7E"
    assert do_urlencode("%", for_qs=True) == "%25"

# Generated at 2022-06-21 04:49:46.319205
# Unit test for function do_urldecode
def test_do_urldecode():
    assert "abc" == do_urldecode("abc")
    assert "abc def" == do_urldecode("abc%20def")
    assert "abc def" == do_urldecode("abc+def")
    assert "abc+def" == do_urldecode("abc%2Bdef")
    assert "abc+def" == do_urldecode("abc%2bdef")
    assert "abc+def" == do_urldecode("abc+def")
    assert "abc def" == do_urldecode("abc def")
    assert "'abc' 'def'" == do_urldecode("'abc'+'def'")


# Generated at 2022-06-21 04:50:00.856463
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc123') == 'abc123'
    assert do_urlencode(u'abc 123') == 'abc%20123'
    assert do_urlencode(u'abc? 123') == 'abc%3F%20123'
    assert do_urlencode(u'abc?/ 123') == 'abc%3F%2F%20123'
    assert do_urlencode(u'abc+ 123') == 'abc%2B%20123'
    assert do_urlencode(u'abc+?/ 123') == 'abc%2B%3F%2F%20123'
    assert do_urlencode({'a': 'b'}) == 'a=b'

# Generated at 2022-06-21 04:50:01.830317
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:50:14.262176
# Unit test for function do_urldecode
def test_do_urldecode():
    print("Testing function do_urldecode")

    assert do_urldecode("a+b") == "a b"
    assert do_urldecode("a%2Bb") == "a+b"
    assert do_urldecode("a%20b") == "a b"
    assert do_urldecode("a%2b%2f%2Fb") == "a+//b"
    assert do_urldecode("a%2b%2f%2Fb") == "a+//b"
    assert do_urldecode("a%2b%2f%2Fb%25") == "a+//b%"



# Generated at 2022-06-21 04:50:19.643943
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('+') == u'+'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%') == u'%'
