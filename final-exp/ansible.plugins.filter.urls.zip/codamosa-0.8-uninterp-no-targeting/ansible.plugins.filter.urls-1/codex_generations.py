

# Generated at 2022-06-21 04:40:21.990358
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%BC') == u'\xfc'


# Generated at 2022-06-21 04:40:24.906329
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test is not None


# Generated at 2022-06-21 04:40:36.074974
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test') == 'test'
    assert unicode_urlencode('test ') == 'test+'
    assert unicode_urlencode('tést') == 't%C3%A9st'
    assert unicode_urlencode('tést ') == 't%C3%A9st+'
    assert unicode_urlencode('this is a test') == 'this+is+a+test'
    assert unicode_urlencode('this is a test ') == 'this+is+a+test+'
    assert unicode_urlencode('this is a tést') == 'this+is+a+t%C3%A9st'

# Generated at 2022-06-21 04:40:41.455023
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%ed%ed%e5%ed%f4%ae%c4%e9%9f'
                             '%ee%f1%ae%f8%e5%ed%e8%ea%e0') == \
        u'святые отцы'

# Generated at 2022-06-21 04:40:49.820422
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b') == u'a b'
    assert unicode_urldecode('a%20b') == u'a b'
    assert unicode_urldecode('a%2Bb') == u'a+b'
    assert unicode_urldecode('a%2bb') == u'a+b'


# Generated at 2022-06-21 04:40:52.225102
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

if __name__ == "__main__":
    test_FilterModule_filters()

# Generated at 2022-06-21 04:40:56.811020
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t = FilterModule()
    filters = t.filters()
    assert u'%40' == filters['urldecode'](u'%40')



# Generated at 2022-06-21 04:41:06.226973
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://foo/?a=1&b=2') == 'http%3A%2F%2Ffoo%2F%3Fa%3D1%26b%3D2'
    assert do_urlencode('http://foo/') == 'http%3A%2F%2Ffoo%2F'
    assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'
    assert do_urlencode({'a': 1, 'b': 2}, for_qs=True) == 'a%3D1%26b%3D2'



# Generated at 2022-06-21 04:41:17.489693
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Unquote strings correctly '''
    r = unicode_urldecode('abcdef')
    assert to_text(r) == 'abcdef'

    r = unicode_urldecode('%00abcdef')
    assert to_text(r) == '\u0000abcdef'

    r = unicode_urldecode('a+bcdef')
    assert to_text(r) == 'a bcdef'

    r = unicode_urldecode('%3Fa+bcdef%3F')
    assert to_text(r) == '?a bcdef?'



# Generated at 2022-06-21 04:41:26.516677
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo%2Fbar') == 'foo/bar'
    assert unicode_urldecode('foo%2fbar') == 'foo/bar'
    assert unicode_urldecode('foo%252Fbar') == 'foo%2Fbar'
    assert unicode_urldecode('foo%2Bbar') == 'foo+bar'
    assert unicode_urldecode('foo+bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'



# Generated at 2022-06-21 04:41:33.069096
# Unit test for function do_urlencode
def test_do_urlencode():
    input = "abcd ef"
    expected = "abcd%20ef"
    test_string = unicode_urlencode(input)
    assert test_string == expected, "Test failed: %s != %s" % (test_string, expected)


# Generated at 2022-06-21 04:41:46.626344
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import sys

    import pytest

    assert unicode_urlencode(u'euro sign €') == u'euro%20sign%20%E2%82%AC'
    assert unicode_urlencode(u'euro sign €', for_qs=True) == u'euro+sign+%E2%82%AC'

    # check that we don't convert non-ASCII strings that are already utf-8 to unicode
    val = 't\xc3\xa9st'
    if PY3:
        val = bytes(val, 'utf-8')
        assert unicode_urlencode(val) == val
    else:
        val = unicode(val, 'utf-8')

# Generated at 2022-06-21 04:41:54.893740
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.module_utils.six.moves.urllib.parse import urlparse, parse_qs

    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_urlencode = filters['urlencode']
    filter_urldecode = filters['urldecode']

    # test urlencode
    result = filter_urlencode('')
    assert result == ''

    result = filter_urlencode('/')
    assert result == '/'

    result = filter_urlencode('foo')
    assert result == 'foo'

    result = filter_urlencode('foo bar')
    assert result == 'foo+bar'

    result = filter_urlencode(42)
    assert result == '42'

    result = filter_urlencode(['foo=bar'])

# Generated at 2022-06-21 04:41:59.365933
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('a&b=c') == 'a%26b%3Dc'
    assert do_urlencode({'a': 'a&b=c'}) == 'a=a%26b%3Dc'
    assert do_urlencode(['a', 'a&b=c']) == 'a=a%26b%3Dc'

# Generated at 2022-06-21 04:42:10.685614
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:42:20.451525
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'param1') == u'param1'
    assert unicode_urldecode(u'param2=value2') == u'param2=value2'
    assert unicode_urldecode(u'param3=value3&param4=value4') == u'param3=value3&param4=value4'
    assert unicode_urldecode(u'param5=value 5') == u'param5=value 5'
    assert unicode_urldecode(u'param6=value6  ') == u'param6=value6  '
    assert unicode_urldecode(u'param7=%20value7%20and%20more') == u'param7= value7 and more'

# Generated at 2022-06-21 04:42:32.366326
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(b'hello') == u'hello'
    assert do_urldecode(b'foo%20bar') == u'foo bar'
    assert do_urldecode(b'%3B') == u';'
    assert do_urldecode(b'%2F') == u'/'
    assert do_urldecode(u'foo%20bar') == u'foo bar'
    assert do_urldecode(u'%3B') == u';'
    assert do_urldecode(u'%2F') == u'/'
    assert do_urldecode('foo%20bar') == u'foo bar'
    assert do_urldecode('%3B') == u';'
    assert do_urldecode('%2F') == u

# Generated at 2022-06-21 04:42:40.363999
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'\u201c\u201d') == u'\u201c\u201d'
    assert unicode_urldecode(u'%E2%80%9C%E2%80%9D') == u'\u201c\u201d'
    assert unicode_urldecode(u'\u201c\u201d') == u'\u201c\u201d'
    assert unicode_urldecode(u'%22') == u'"'
    assert unicode_urldecode(u'%22%23') == u' "%23"'
    assert unicode_urldecode(u'blah') == u'blah'
    assert unicode_urldecode(u'%25') == u'%'

# Generated at 2022-06-21 04:42:48.730221
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%3A+bar%3B+baz') == u'foo: bar; baz'
    assert do_urldecode({'spam': 'eggs'}) == u'spam=eggs'
    assert do_urldecode(['foo', 'bar', 'baz']) == u'foo&bar&baz'
    assert do_urldecode('foo+bar+baz') == u'foo+bar+baz'

# Generated at 2022-06-21 04:43:01.541778
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode(u'Opa%C3%A7%C3%A3o') == u'Opação'
    assert unicode_urldecode(u'Opação') == u'Opação'
    assert unicode_urldecode(u'Opa%E7%E3o') == u'Opação'
    assert unicode_urldecode(u'Opa%E7o') == u'Opaço'
    assert unicode_urldecode(u'Opa%C3%A7ao') == u'Opaçao'
    assert unicode_urldecode(u'Opa%C3o') == u'Opa%C3o'

# Generated at 2022-06-21 04:43:08.156060
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'http://www.öü.de/') == u'http%3A%2F%2Fwww.%C3%B6%C3%BC.de%2F')
    assert(unicode_urlencode(u'http://www.öü.de/', for_qs=True) == u'http%3A%2F%2Fwww.%C3%B6%C3%BC.de%2F')
    assert(unicode_urlencode(u'test+test', for_qs=True) == u'test%2Btest')

# Generated at 2022-06-21 04:43:16.768429
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://github.com/dagwieers/ansible-modules-core') == u'http%3A//github.com/dagwieers/ansible-modules-core'
    assert unicode_urlencode(u'http://github.com/dagwieers/ansible-modules-core', for_qs=True) == u'http%3A%2F%2Fgithub.com%2Fdagwieers%2Fansible-modules-core'

# Generated at 2022-06-21 04:43:19.862308
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test is not None

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-21 04:43:31.793236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys

    # Save the command line arguments
    args = sys.argv

    # Clear the command line arguments
    sys.argv = []

    # Set the command line arguments that this unit test expects
    sys.argv.append('ansible-test')
    sys.argv.append('filter')
    sys.argv.append('jinja2_filters.py')
    sys.argv.append('--python-version')

    # Import ansible test
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create the ansible test object
    ansible_test = basic.AnsibleModuleTest()

    # Test the FilterModule class
    filter_module = FilterModule()

    # Here we only test the jinja2 filters that are defined in the FilterModule

# Generated at 2022-06-21 04:43:41.152940
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('http://www.example.com/index.php?example=%E3%81%82') == 'http://www.example.com/index.php?example=\xe3\x81\x82'
    assert FilterModule().filters()['urldecode']('http://www.example.com/index.php?example=%20') == 'http://www.example.com/index.php?example= '


# Generated at 2022-06-21 04:43:54.310824
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode({'foo': 'bar'}) == u'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == u'foo=bar&baz=qux'
    assert do_urlencode([('foo', 'bar'), ('baz', 'qux')]) == u'foo=bar&baz=qux'

# Generated at 2022-06-21 04:43:59.824596
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    test = u'@ < > = \n'
    expected = u'%40+%3C+%3E+%3D+%0A'

    assert unicode_urlencode(test) == expected



# Generated at 2022-06-21 04:44:03.667141
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Return True when do_urldecode a string
    '''
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode(1234) == unicode(1234)

# Generated at 2022-06-21 04:44:08.426246
# Unit test for constructor of class FilterModule
def test_FilterModule():
    #pylint: disable=no-member
    assert 'urldecode' in FilterModule.filters
    if not HAS_URLENCODE:
        assert 'urlencode' in FilterModule.filters



# Generated at 2022-06-21 04:44:17.593392
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Test cases for unicode_urlencode
    '''

    assert unicode_urlencode(u'a=b') == u'a%3Db'
    assert unicode_urlencode(u'a=b', for_qs=True) == u'a%3Db'
    assert unicode_urlencode(u'ab') == u'ab'
    assert unicode_urlencode(u'a/b') == u'a%2Fb'
    assert unicode_urlencode({u'q': u'a b', u'id': u'9'}) == u'id=9&q=a+b'
    assert unicode_urlencode([u'a', u'b']) == u'a&b'

# Generated at 2022-06-21 04:44:29.365414
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Initialize instance of FilterModule class
    f = FilterModule()
    filters = f.filters()

    # Test urldecode filter
    assert filters['urldecode']('%20') == u' '
    assert filters['urldecode']('%7B%22color%22%3A%22blue%22%7D') == u'{"color":"blue"}'

    # Test urlencode filter
    if not HAS_URLENCODE:
        assert filters['urlencode'](' ') == '%20'
        assert filters['urlencode']('{"color":"blue"}') == '%7B%22color%22%3A%22blue%22%7D'
        assert filters['urlencode']({'color': 'blue'}) == 'color=blue'

# Generated at 2022-06-21 04:44:42.381807
# Unit test for function do_urlencode
def test_do_urlencode():

    assert(do_urlencode('abc') == 'abc')
    assert(do_urlencode('abc def') == 'abc%20def')
    assert(do_urlencode('abc def') == 'abc%20def')
    assert(do_urlencode('abc def') == 'abc%20def')
    assert(do_urlencode({'name': 'Dag'}) == 'name=Dag')
    assert(do_urlencode({'name': 'John & Dag'}) == 'name=John%20%26%20Dag')
    assert(do_urlencode({'name': 'Dag', 'surname': 'Wieers'}) == 'name=Dag&surname=Wieers')

# Generated at 2022-06-21 04:44:49.026057
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'http%3A%2F%2Ffoo.com%2Fbar%2Fbaz%2F') == u'http://foo.com/bar/baz/'
    assert do_urldecode(u'http://foo.com/bar/baz/') == u'http://foo.com/bar/baz/'
    assert do_urldecode(b'http%3A%2F%2Ffoo.com%2Fbar%2Fbaz%2F') == u'http://foo.com/bar/baz/'
    assert do_urldecode(b'http://foo.com/bar/baz/') == u'http://foo.com/bar/baz/'



# Generated at 2022-06-21 04:45:01.092689
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == ''
    assert do_urlencode('/') == '/'
    assert do_urlencode('a=b') == 'a=b'
    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode('a,b') == 'a%2Cb'
    assert do_urlencode('a, b') == 'a%2C+b'
    assert do_urlencode('a,b ') == 'a%2Cb+'
    assert do_urlencode('a, b ') == 'a%2C+b+'
    assert do_urlencode('a=b%c') == 'a=b%25c'
    assert do_urlencode('a&b') == 'a%26b'
   

# Generated at 2022-06-21 04:45:12.726487
# Unit test for function do_urldecode
def test_do_urldecode():
    test_string_1 = '%CF%87%CE%B5%CF%81%CF%84%CE%B5+%CE%BB%CE%AD%CE%B3%CE%B5+%CE%B1%CE%B9%CE%B4%CF%89%CE%BD%CE%B9%CE%BA%CE%AE+%CF%86%CF%89%CE%BB%CE%B7%CE%B1%CF%82'

# Generated at 2022-06-21 04:45:15.187944
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert len(f.filters()) == 2
    assert 'urldecode' in f.filters()
    assert 'urlencode' in f.filters()

# Generated at 2022-06-21 04:45:24.083563
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'http://www.ansible.com/') == u'http://www.ansible.com/'
    assert do_urldecode(u'http://www.ansible.com/test?a=b') == u'http://www.ansible.com/test?a=b'
    assert do_urldecode(u'http%3A%2F%2Fwww.ansible.com%2F') == u'http://www.ansible.com/'
    assert do_urldecode(u'http%3A%2F%2Fwww.ansible.com%2Ftest%3Fa%3Db') == u'http://www.ansible.com/test?a=b'


# Generated at 2022-06-21 04:45:31.676706
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('&=') == '%26%3D'
    assert unicode_urlencode({'&': '='}) == '%26=%3D'
    assert unicode_urlencode({'&': '=&'}, for_qs=True) == '%26=%26%26=%3D'
    assert unicode_urlencode('&=', for_qs=True) == '%26%3D'

# Generated at 2022-06-21 04:45:33.883871
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    f.filters()



# Generated at 2022-06-21 04:45:45.470996
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import sys
    assert unicode_urlencode('string') == 'string'
    assert unicode_urlencode(u'string') == 'string'
    assert unicode_urlencode(u'unicode_string_é') == 'unicode_string_%C3%A9'
    # str(sys.maxunicode) returns different values on different platforms, and
    # it's not clear what the right thing to do is here, so I'm doing this.
    max_str = str(unichr(sys.maxunicode))
    if PY3:
        max_str = unichr(sys.maxunicode)
    assert unicode_urlencode(max_str) == str(sys.maxunicode).encode('utf-8').hex()

# Generated at 2022-06-21 04:46:01.722583
# Unit test for function do_urlencode
def test_do_urlencode():
    value = u'https://dl.fedoraproject.org/pub/alt/pki-ca-2017.1.1-1.noarch.rpm'
    encoded = do_urlencode(value)
    assert encoded == 'https%3A//dl.fedoraproject.org/pub/alt/pki-ca-2017.1.1-1.noarch.rpm'
    assert do_urldecode(encoded) == value

    value = {'a': 'b', 'c': 'd'}
    encoded = do_urlencode(value)
    assert encoded == 'a=b&c=d'
    assert do_urldecode(encoded) == 'a=b&c=d'

    value = [('a', 'b'), ('c', 'd')]
    encoded = do

# Generated at 2022-06-21 04:46:12.500519
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode(u'') == u''
    assert do_urlencode(u'123') == u'123'
    assert do_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert do_urlencode(u'http://www.example.com/foo/bar') == u'http%3A//www.example.com/foo/bar'

    # Test for non-string
    assert do_urlencode([u'http://www.example.com/foo/bar']) == u'http%3A//www.example.com/foo/bar'
    assert do_urlencode(['http://www.example.com/foo/bar']) == u'http%3A//www.example.com/foo/bar'

# Generated at 2022-06-21 04:46:15.754489
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%7B%22%5B%7D=%3E%5D%22%3A%5B%22%3E%22%5D%7D') == u'{"[}=>"]":[">"]}'


# Generated at 2022-06-21 04:46:27.246597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    filters = FilterModule().filters()
    f_urldecode = filters['urldecode']
    assert f_urldecode('Green%20Fox') == u'Green Fox'
    if 'urlencode' in filters:
        f_urlencode = filters['urlencode']
        assert f_urlencode("Green Fox") == u'Green%20Fox'
        assert f_urlencode("Denys Van Kempen") == u'Denys%20Van%20Kempen'
        assert f_urlencode({'name': 'Denys Van Kempen', 'email': 'denys@vankempen.org'}) == u'name=Denys%20Van%20Kempen&email=denys@vankempen.org'

# Generated at 2022-06-21 04:46:37.002443
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%5C') == '\\'
    assert do_urldecode('%5c') == '\\'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'

# Generated at 2022-06-21 04:46:37.963237
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule != None


# Generated at 2022-06-21 04:46:43.764501
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar') == u'foo bar'


# Generated at 2022-06-21 04:46:54.195513
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    def assert_urlencode(expected, result):
        if PY3:
            assert expected == result
        else:
            assert expected == result.encode('UTF-8')

    assert_urlencode("foo", unicode_urlencode('foo'))
    assert_urlencode("foo%20bar", unicode_urlencode('foo bar'))
    assert_urlencode("foo%2Fbar", unicode_urlencode('foo/bar'))
    assert_urlencode("%2Fpath", unicode_urlencode('/path'))
    assert_urlencode("foo%26bar", unicode_urlencode('foo&bar'))
    assert_urlencode("foo=bar", unicode_urlencode('foo=bar', for_qs=True))

# Generated at 2022-06-21 04:46:55.333228
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    print(module)

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-21 04:46:59.284380
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_value = u'xn--3alq7byb18g.xn--p1ai'
    assert unicode_urldecode(unicode_urlencode(test_value)) == test_value


# Generated at 2022-06-21 04:47:08.240996
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("abcd=1&def=2") == "abcd%3D1%26def%3D2"
    assert unicode_urlencode("abcd=1&def=2", True) == "abcd%3D1%26def%3D2"
    kwargs = {'def': '2', 'abcd': '1'}
    assert unicode_urlencode(kwargs, True) == "def=2&abcd=1"

# Generated at 2022-06-21 04:47:16.134460
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'中国') == u'中国'
    assert do_urldecode('%E4%B8%AD%E5%9B%BD') == u'中国'
    assert do_urldecode('%E4%B8%AD%E5%9B%BD') == do_urldecode('%E4%B8%AD%E5%9B%BD')

if __name__ == "__main__":
    test_do_urldecode()

# Generated at 2022-06-21 04:47:21.030100
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs

    assert do_urldecode("a=b&c=d") == "a=b&c=d", "Simple compare"

    assert parse_qs(do_urldecode("a=b&c=d")) == { "a": ["b"], "c": ["d"] }, "Parse as query, compare as dict"

# Generated at 2022-06-21 04:47:22.192217
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:47:33.346594
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode(u'foo?bar') == 'foo%3Fbar'
    assert unicode_urlencode(u'foo?bar') == 'foo%3Fbar'
    assert unicode_urlencode(u'foo&bar') == 'foo%26bar'

# Generated at 2022-06-21 04:47:36.997828
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'simple string') == u'simple%20string'
    assert unicode_urlencode(u'需要编码') == u'%E9%9C%80%E8%A6%81%E7%BC%96%E7%A0%81'



# Generated at 2022-06-21 04:47:44.771879
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_filter = FilterModule()
    assert test_filter.filters()['urldecode']('https%3A%2F%2Fwww.google.com%2F%3Fq%3Dexample') == 'https://www.google.com/?q=example'
    assert test_filter.filters()['urlencode']('"') == '%22'

# Generated at 2022-06-21 04:47:48.298461
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo%20bar%20baz') == 'foo bar baz'
    if not HAS_URLENCODE:
        assert do_urlencode('foo bar baz') == 'foo+bar+baz'

# Generated at 2022-06-21 04:48:01.171203
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat.tests.mock import Mock, patch

    # This dict containing unicode characters may be used for additional tests
    # unicode_dict = {u'føø': u'bår', u'bam': None, u'fuu\u20ac': 2, u'baz': [1, 2, 3]}

    not_unicode = "not unicode"
    unicode_string = u"føø"
    unicode_string_2 = u"føø bår"
    unicode_string_3 = u"føø?bår"
    unicode_string_4 = u"føø&bår"
    unicode_string_5 = u"føø;bår"

# Generated at 2022-06-21 04:48:12.894434
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Simple case
    assert unicode_urldecode('jose%40example.com') == u'jose@example.com'
    # ASCII-incompatible encoding (which python-requests can generate)
    assert unicode_urldecode('jose%C3%B1@example.com') == u'jose\xf1@example.com'
    # UTF8
    assert unicode_urldecode('jose%C3%B1@example.com') == u'jose\xf1@example.com'
    # Invalid UTF8
    assert unicode_urldecode(b'jose%C3%B1@example.com') == u'jose\ufffd@example.com'


# Generated at 2022-06-21 04:48:23.312310
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%3D%3D') == '=='
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%26%26') == '&&'

# Generated at 2022-06-21 04:48:30.331478
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils._text import to_bytes
    to_bytes('\nfoo') # for pyflakes
    if PY3:
        assert unicode_urldecode(b'a+b') == 'a b'
    else:
        assert unicode_urldecode(b'a+b') == u'a b'

# Generated at 2022-06-21 04:48:36.896301
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        def e(s, for_qs=False):
            return unicode_urlencode(to_bytes(s), for_qs=for_qs)
    else:
        def e(s, for_qs=False):
            return unicode_urlencode(s, for_qs=for_qs)

    assert e('/var/www/fÃ¶Ä¶/fÃ¥Å.html') == u'/var/www/f%C3%A3%C2%B6%C3%84%C3%96/f%C3%A3%C2%A5%C3%85.html'
    assert e('/var/www/foo/fÅ?a=1') == u'/var/www/foo/f%C3%85?a=1'

# Generated at 2022-06-21 04:48:47.575848
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_bytes, to_text

    # Just testing one case for now, open for improvements
    if PY3:
        # Unicode strings and Python 3
        assert unicode_urlencode('a1_#') == 'a1_%23'
        assert unicode_urlencode('一二三') == '%E4%B8%80%E4%BA%8C%E4%B8%89'
    else:
        # Unicode strings and Python 2
        assert unicode_urlencode(u'a1_#') == u'a1_%23'
        assert unicode_urlencode(u'a1_#') == 'a1_%23'

# Generated at 2022-06-21 04:48:55.402864
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    filters = filterModule.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters

    assert filters['urldecode'](u"1+%C3%A9") == u"1 é"
    assert filters['urlencode'](u"1 é") == u"1+%C3%A9"

# Generated at 2022-06-21 04:49:02.277449
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'abc') == 'abc'
    # This should work
    assert do_urldecode(u'abc%2Fdef') == 'abc/def'
    # This shouldn't work
    # assert do_urldecode(u'abc/def') == 'abc/def'

# Generated at 2022-06-21 04:49:17.261615
# Unit test for function do_urlencode
def test_do_urlencode():

    # json-like string
    data = {
        'foo': 'bar',
        'baz': 'foobar',
    }
    assert do_urlencode(data) == 'foo=bar&baz=foobar'

    # list of tuples
    data = [('foo', 'bar'), ('baz', 'foobar')]
    assert do_urlencode(data) == 'foo=bar&baz=foobar'

    # string
    data = 'http://www.example.com'
    assert do_urlencode(data) == 'http%3A%2F%2Fwww.example.com'

    # string with whitespaces
    data = '  foo bar baz  '

# Generated at 2022-06-21 04:49:22.644670
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a/b') == u'a%2Fb'
    assert unicode_urlencode(u'a/b', for_qs=True) == u'a%2Fb'
    assert unicode_urlencode(u'a b') == u'a%20b'
    assert unicode_urlencode(u'a b', for_qs=True) == u'a+b'


# Generated at 2022-06-21 04:49:30.010481
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%20%C3%A9%20%C3%A0%20%C3%AB%20%C3%AF%20%C3%AC%20%C3%AA%20%C3%AD%20%C3%B6%20%C3%B9%20%C3%BA%20%C3%BC%20%C3%BD') == u'ä é à ë ï ì ê í ö ù ú ü ý'


# Generated at 2022-06-21 04:49:39.466552
# Unit test for function do_urldecode
def test_do_urldecode():
    import sys
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2f') == u'/'
    assert do_urldecode(u'%2f') == u'/'
    if sys.version_info >= (3,0):
        assert do_urldecode(b'%2f') == u'/'
        assert do_urldecode('%F0%9F%92%A9') == u'\U0001f4a9'
    else:
        assert do_urldecode(b'%2f') == '/'
        assert do_urldecode('%F0%9F%92%A9') == u'\xf0\x9f\x92\xa9'

# Generated at 2022-06-21 04:49:51.710135
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import unittest

    class UnicodeUrldecodeTestCase(unittest.TestCase):
        def test_is_octet_safe(self):
            actual = unicode_urldecode(u'%7F')
            expected = u'\u007f'
            self.assertEqual(actual, expected)

        def test_is_not_octet_safe(self):
            actual = unicode_urldecode(u'+%7F')
            expected = u'+\u007f'
            self.assertEqual(actual, expected)

    unittest.main()



# Generated at 2022-06-21 04:49:54.849764
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%2Bb') == 'a+b'


# Generated at 2022-06-21 04:49:58.780016
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(u'%2B') == u'+'
    else:
        assert unicode_urldecode(u'%2B') == '+'



# Generated at 2022-06-21 04:50:11.215804
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        # Using non-ASCII characters in Python 2
        assert unicode_urlencode(u'\u043f\u0440\u0438\u0432\u0435\u0442') == '%D0%BF%D0%B0%D1%82%D0%B8%D0%B2%D0%B5%D1%82'
        assert unicode_urlencode(u'\u043f\u0440\u0438\u0432\u0435\u0442') == to_bytes(quote(u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')))

# Generated at 2022-06-21 04:50:22.452057
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == u'/'
    assert do_urlencode('/foo+bar') == u'/foo%2Bbar'
    assert do_urlencode('/foo bar') == u'/foo%20bar'
    assert do_urlencode(u'/föö bär') == u'/f%C3%B6%C3%B6%20b%C3%A4r'
    assert do_urlencode(u'fööbär') == u'f%C3%B6%C3%B6b%C3%A4r'
    assert do_urlencode({'foo': 'bar'}) == u'foo=bar'