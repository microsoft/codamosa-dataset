

# Generated at 2022-06-21 04:40:20.478273
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == to_text('é')


# Generated at 2022-06-21 04:40:27.623296
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    m = basic.AnsibleModule(
        argument_spec=dict(),
    )

    results = doctest.testmod(
        m._load_params(),
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS,
    )
    assert results.failed == 0

    fm = FilterModule()
    for name, function in iteritems(fm.filters()):
        assert not hasattr(unquote_plus, name)  # Safety net
        assert unquote_plus(to_bytes(name)) == to_bytes(function.__name__)

# Generated at 2022-06-21 04:40:28.972315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'](fm.filters()['urlencode']('string_to_encode')) == 'string_to_encode'

# Generated at 2022-06-21 04:40:38.619412
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("http://www.example.com/foo?bar=baz#qux") == "http%3A//www.example.com/foo%3Fbar%3Dbaz%23qux"
    assert do_urlencode("http://www.example.com/foo?bar=baz#qux", True) == "http%3A%2F%2Fwww.example.com%2Ffoo%3Fbar%3Dbaz%23qux"
    assert do_urlencode("/beg?amp=foo&amp;bar=baz") == "/beg%3Famp=foo&amp%3Bbar=baz"

# Generated at 2022-06-21 04:40:43.413679
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters

    # PY2
    assert filters['urldecode']('%2F1%2F1') == '/1/1'
    assert filters['urlencode']('/1/1') == '%2F1%2F1'
    assert filters['urlencode']({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert filters['urlencode']({'a': 'b', 'c': 'd e'}) == 'a=b&c=d+e'
    # PY3
    assert filters['urldecode']('%2F1%2F1') == '/1/1'
   

# Generated at 2022-06-21 04:40:53.517540
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9') == u'русский'
    assert unicode_urldecode('%F0%9F%98%8F') == u'\U0001f60f'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%27') == u"'"
    assert unicode_urldecode('%E2%80%99') == u'\u2019'

# Generated at 2022-06-21 04:41:05.247392
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    testcases = [
        (u'', u'%00'),
        (u'This is a test', u'This%20is%20a%20test'),
        (u'This is a test', u'This%20is%20a%20test'),
        (u'This is a test', u'This%20is%20a%20test'),
        (u'This is a test', u'This%20is%20a%20test'),
        (u'This is a test', u'This%20is%20a%20test'),
        (u'+', u'%2B'),
    ]

    for (data, expected) in testcases:
        assert unicode_urlencode(data) == expected

# Generated at 2022-06-21 04:41:19.424531
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'arg1=value1&arg2=value2'
    assert unicode_urldecode(string) == 'arg1=value1&arg2=value2'

    string = 'arg1=%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A+%E3%81%8C%E3%81%8E%E3%81%90%E3%81%92%E3%81%94&arg2=%E3%80%82'
    assert unicode_urldecode(string) == u'arg1=あいうえお がぎぐげご&arg2=。'


# Generated at 2022-06-21 04:41:21.950653
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20string') == 'a string'


# Generated at 2022-06-21 04:41:26.080747
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('a%2Bb%20c') == 'a+b c'
    assert unicode_urldecode('%C3%A9%C3%A9') == 'éé'

    assert unicode_urldecode(unicode('%C3%A9%C3%A9', 'utf-8')) == unicode('éé', 'utf-8')

# Generated at 2022-06-21 04:41:34.636567
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'hello%20world') == u'hello world'
    assert do_urldecode(b'hello%20world') == u'hello world'
    assert do_urldecode('hello%20world') == u'hello world'


# Generated at 2022-06-21 04:41:37.336528
# Unit test for function do_urldecode
def test_do_urldecode():
    assert "a+a" == unicode_urldecode("a%20a")


# Generated at 2022-06-21 04:41:48.099201
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test unicode_urlencode
    assert unicode_urlencode(u'abc') == 'abc'
    assert unicode_urlencode(u'a%20c') == 'a%20c'
    assert unicode_urlencode(u'a+c') == 'a%2Bc'
    assert unicode_urlencode(u'a/c') == 'a%2Fc'
    assert unicode_urlencode(u'a+c', for_qs=True) == 'a%2Bc'
    assert unicode_urlencode(u'a/c', for_qs=True) == 'a%2Fc'

    # Test do_urldecode
    assert do_urldecode(u'abc') == 'abc'

# Generated at 2022-06-21 04:41:50.849311
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%3D%3F%2B%2F%2C') == u'=?+/,'
    assert do_urldecode('%0A') == u'\n'


# Generated at 2022-06-21 04:41:57.436927
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # We call FilterModule.filters() to be able to unit test the filters
    # without needing to create an instance of FilterModule
    from ansible.module_utils.common.dict_transformations import _unicode_urlencode
    filters = FilterModule.filters(FilterModule())
    assert _unicode_urlencode == filters['urlencode']
    assert _unicode_urlencode == filters['urldecode']

# Generated at 2022-06-21 04:42:10.250497
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'Hello%20World') == u'Hello World'
    assert unicode_urldecode(u'%41') == u'A'
    assert unicode_urldecode(u'%E2%9C%93') == u'✓'
    assert unicode_urldecode(u'%F0%9F%91%8D') == u'👍'
    assert unicode_urldecode(b'foo') == u'foo'
    assert unicode_urldecode(b'Hello%20World') == u'Hello World'
    assert unicode_urldecode(b'%41') == u'A'

# Generated at 2022-06-21 04:42:15.094901
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo+bar%2f') == u'foo bar/'
    assert do_urldecode(u'foo+%26+bar%2f') == u'foo & bar/'



# Generated at 2022-06-21 04:42:22.400763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http://www.example.com/foo/?bar=baz&spam=eggs') == u'http://www.example.com/foo/?bar=baz&spam=eggs'
    assert unicode_urldecode(u'http://www.example.com/foo/?bar=baz&spam=eggs') == u'http://www.example.com/foo/?bar=baz&spam=eggs'


# Generated at 2022-06-21 04:42:26.929547
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("b%27Hello%20World%27") == "b'Hello World'"
    assert do_urldecode("b%22Hello%2BWorld%22") == 'b"Hello+World"'

# Generated at 2022-06-21 04:42:29.958906
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()

# Unit tests for function/method do_urldecode

# Generated at 2022-06-21 04:42:42.342432
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import pytest
    assert unicode_urlencode('/foo/bar') == u'/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == u'/foo/bar'
    assert unicode_urlencode('foo /bar') == u'foo%20%2Fbar'
    assert unicode_urlencode('foo /bar', for_qs=True) == u'foo+%2Fbar'
    assert unicode_urlencode('baz=qux;quux=foo/bar') == u'baz=qux;quux=foo%2Fbar'
    assert unicode_urlencode('baz=qux;quux=foo/bar', for_qs=True) == u'baz=qux&quux=foo+%2Fbar'


# Generated at 2022-06-21 04:42:44.085363
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == u'/'



# Generated at 2022-06-21 04:42:45.373570
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-21 04:42:49.002319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == 'äöü'



# Generated at 2022-06-21 04:42:49.795997
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:43:02.325768
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'string with spaces') == u'string%20with%20spaces'
    assert unicode_urlencode(u'unicode string with spaces Кириллица') == u'unicode%20string%20with%20spaces%20%D0%9A%D0%B8%D1%80%D0%B8%D0%BB%D0%BB%D0%B8%D1%86%D0%B0'
    assert unicode_urlencode(u'string@withàtld', for_qs=True) == u'string%40with%C3%A0tld'
    assert unicode_urlencode(u'string$with://path') == u'string%24with:/path'

# Generated at 2022-06-21 04:43:14.226852
# Unit test for function do_urlencode
def test_do_urlencode():
    if do_urlencode == do_urldecode:
        print("do_urlencode is not available")
    else:
        print("do_urlencode tests")
        assert do_urlencode(u'http://example.org/\u20ac/?q=\u20ac') == u'http%3A%2F%2Fexample.org%2F%E2%82%AC%2F%3Fq%3D%E2%82%AC'
        assert do_urlencode({u'a': u'/\u20ac/', u'b': u'\u20ac'}) == u'a=%2F%E2%82%AC%2F&b=%E2%82%AC'

# Generated at 2022-06-21 04:43:24.946817
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('a') == 'a'
    assert FilterModule().filters()['urldecode']('%21') == '!'
    assert FilterModule().filters()['urldecode']('%26') == '&'
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2C') == ','
    assert FilterModule().filters()['urldecode']('%3A') == ':'
    assert FilterModule().filters()['urldecode']('%3B') == ';'
    assert FilterModule().filters()['urldecode']('%3D') == '='

# Generated at 2022-06-21 04:43:33.571283
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test urlencoding a dict
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert unicode_urlencode({b'a': b'b', b'c': b'd'}) == 'a=b&c=d'
    assert unicode_urlencode({u'a': u'b', u'c': u'd'}) == 'a=b&c=d'
    assert unicode_urlencode({b'a': u'b', u'c': b'd'}) == 'a=b&c=d'

    # Test urlencoding a list
    assert unicode_urlencode(['a', 'b', 'c', 'd']) == 'a&b&c&d'
    assert unicode_

# Generated at 2022-06-21 04:43:44.346367
# Unit test for function unicode_urldecode

# Generated at 2022-06-21 04:43:56.037329
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import unittest

    class TestFilterModule_filters(unittest.TestCase):
        def setUp(self):
            self.old_stdout = sys.stdout
            sys.stdout = open('/dev/null', 'w')

        def tearDown(self):
            sys.stdout.close()
            sys.stdout = self.old_stdout

        def test_FilterModule_filters(self):
            from ansible.module_utils.common.collections import is_iterable
            mod = FilterModule()
            filters = mod.filters()
            self.assertTrue(is_iterable(filters))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestFilterModule_filters)

# Generated at 2022-06-21 04:44:05.965148
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2
    from ansible.module_utils import basic

    fm = FilterModule()
    f_dict = fm.filters()
    env = basic.AnsibleModule._load_environment()
    env.filters.update(f_dict)

    # Test urldecode
    t = env.from_string("{{ 'https://www.example.com/foo/bar.html?x=42&y=43' | urldecode }}")
    assert t.render() == 'https://www.example.com/foo/bar.html?x=42&y=43'

    # Test urlencode
    t = env.from_string("{{ 'https://www.example.com/foo/bar.html?x=42&y=43' | urlencode }}")
    assert t.render()

# Generated at 2022-06-21 04:44:15.392018
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = u'a=%C3%A1&b=%C3%A9&c=%C3%AD&d=%C3%B3&e=%C3%BA&f=%C3%B1'
    assert unicode_urldecode(string) == u'a=á&b=é&c=í&d=ó&e=ú&f=ñ'
    assert unicode_urldecode(u'a=%C3%A1') == u'a=á'
    assert unicode_urldecode(u'%C3%A1') == u'á'


# Generated at 2022-06-21 04:44:17.643174
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create FilterModule object and invoke filters() method.
    f = FilterModule().filters()
    # Assert on f type and length of f.
    assert isinstance(f, dict)
    assert len(f) == 2


# Generated at 2022-06-21 04:44:20.387682
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C5%8D') == u'ō'



# Generated at 2022-06-21 04:44:30.725214
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # Test standard encoding
    assert unicode_urlencode(u'?') == u'%3f'
    assert unicode_urlencode(u'&') == u'%26'
    assert unicode_urlencode(u' /') == u'%20%2f'
    assert unicode_urlencode(u' /') == u'%20%2f'
    assert unicode_urlencode(u'a=b') == u'a%3db'
    assert unicode_urlencode(u'a = b') == u'a%20%3d%20b'
    assert unicode_urlencode(u'a, b') == u'a%2c%20b'

# Generated at 2022-06-21 04:44:38.495280
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    data = {
        'string': 'abc',
        'int': 1,
    }

    fm = FilterModule()
    result = fm.filters()

    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode
    assert result['urldecode'] == do_urldecode


# Generated at 2022-06-21 04:44:50.076809
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # utf-8
    assert unicode_urldecode(u'%D0%A2%D0%B5%D1%81%D1%82') == u'Тест'
    # latin-1
    assert unicode_urldecode(u'%E0%F6%F9%A3%FC') == u'àöù£ü'
    # unicode
    assert unicode_urldecode(u'%u0422%u0435%u0441%u0442') == u'Тест'
    # empty
    assert unicode_urldecode(u'') == u''



# Generated at 2022-06-21 04:44:51.510066
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

# Generated at 2022-06-21 04:45:01.702317
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result = unicode_urlencode('http://www.ansible.com/')
    assert 'http%3A//www.ansible.com/' == result
    result = unicode_urlencode('http://www.ansible.com/', for_qs=True)
    assert 'http%3A%2F%2Fwww.ansible.com%2F' == result
    result = unicode_urlencode({'foo': u'bar baz'})
    assert 'foo=bar+baz' == result
    result = unicode_urlencode({'foo[]': u'bar baz'})
    assert 'foo%5B%5D=bar+baz' == result
    result = unicode_urlencode([('foo', 'bar baz'), ('foo[]', 'bar')])

# Generated at 2022-06-21 04:45:12.117858
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode
    else:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-21 04:45:18.923550
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test empty string
    assert unicode_urldecode("") == ""

    # Test good string
    assert unicode_urldecode("%2B%88%C0") == u'+øÀ'

    # Test invalid string
    assert unicode_urldecode("%7X") == u'%7X'



# Generated at 2022-06-21 04:45:25.245772
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%E4%B8%89%20%E5%A4%A7%E5%9D%8A") == u"\u4e09 \u5927\u5730\u7403"


# Generated at 2022-06-21 04:45:28.264635
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    assert FilterModule is not None


# Generated at 2022-06-21 04:45:36.987461
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.ietf.org/rfc/rfc3986.txt') == u'http%3A%2F%2Fwww.ietf.org%2Frfc%2Frfc3986.txt'
    assert unicode_urlencode(u'http://www.ietf.org/rfc/rfc3986.txt', for_qs=True) == u'http%3A%2F%2Fwww.ietf.org%2Frfc%2Frfc3986.txt'

# Generated at 2022-06-21 04:45:44.383400
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert unicode_urlencode(u'http://ansible.com?x=łukasz') == 'http%3A//ansible.com%3Fx%3D%C5%82ukasz'
    else:
        assert unicode_urlencode(u'http://ansible.com?x=łukasz') == 'http%3A%2F%2Fansible.com%3Fx%3D%C5%82ukasz'



# Generated at 2022-06-21 04:45:50.881091
# Unit test for function do_urlencode
def test_do_urlencode():
    data = {'foo': 'bar', 'baz': 'buzz'}
    assert do_urlencode('myvar') == "myvar"
    assert do_urlencode(data) == "baz=buzz&foo=bar"
    assert do_urlencode("foo bar") == "foo%20bar"
    assert do_urlencode("foo+bar") == "foo%2Bbar"
    assert do_urlencode("foo:bar") == "foo:bar"
    assert do_urlencode("foo/bar") == "foo%2Fbar"
    assert do_urlencode("foo&bar") == "foo&bar"
    assert do_urlencode("foo;bar") == "foo;bar"
    assert do_urlencode("foo=bar") == "foo=bar"

# Generated at 2022-06-21 04:45:54.616093
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }


# Generated at 2022-06-21 04:46:00.930801
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("TEST: unicode_urldecode")
    assert unicode_urldecode("Test+%C3%A7a") == u"Test+ça"
    assert unicode_urldecode("Test+%C3%A7a") == unicode_urldecode("Test+%C3%A7a".encode("utf-8"))
    assert unicode_urldecode("Test+%C3%A7a") == unicode_urldecode(u"Test+%C3%A7a")


# Generated at 2022-06-21 04:46:04.324654
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"I%20love%20you%3A%20%E2%99%A5") == u"I love you: ♥"



# Generated at 2022-06-21 04:46:12.755544
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("hello world!") == "hello%20world%21"
    assert do_urlencode("http://example.com") == "http%3A//example.com"
    assert do_urlencode("http://example.com/a b") == "http%3A//example.com/a%20b"

# Generated at 2022-06-21 04:46:16.315876
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b%20c') == 'a b c'
    assert do_urldecode('a%2Cb+c') == 'a,b c'
    assert do_urldecode('a%2Cb%20c') == 'a,b c'


# Generated at 2022-06-21 04:46:28.270544
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Function unicode_urlencode tests '''
    from distutils.version import LooseVersion
    assert unicode_urlencode('a&b') == 'a%26b'
    assert unicode_urlencode('a&b', for_qs=True) == 'a%26b'
    if LooseVersion(jinja2.__version__) < LooseVersion('2.7'):
        assert unicode_urlencode('/a&b') == '%2Fa%26b'
    else:
        assert unicode_urlencode('/a&b') == '/a%26b'
    if LooseVersion(jinja2.__version__) < LooseVersion('2.8'):
        assert unicode_urlencode({'a': 'b'}) == 'a=b'

# Generated at 2022-06-21 04:46:41.751629
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('f/o+b&a=r') == 'f%2Fo%2Bb%26a%3Dr'
    assert do_urlencode({'f/o': 'b&a'}) == 'f%2Fo=b%26a'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

    # This test will fail when Jinja2 v2.7+ is installed because
    # it will not matter that we override the urlencode filter.
    # When we do not override the urlencode filter, do_urlencode
    # will be called from do_urlencode which will change the result.
    assert do_urlencode('f/o+b&a=r') == 'f/o+b&a=r'


# Unit test

# Generated at 2022-06-21 04:46:49.990257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == u""
    assert unicode_urldecode("%") == u"%"
    assert unicode_urldecode("%xx") == u"%xx"
    assert unicode_urldecode("%20") == u" "
    assert unicode_urldecode("+") == u" "
    assert unicode_urldecode("+%20+") == u"  "
    assert unicode_urldecode("%E4%BB%8B%E6%AF%94") == u"介比"


# Generated at 2022-06-21 04:47:00.338523
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode('http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode('http://example.com/?foo=bar baz') == u'http%3A//example.com/%3Ffoo%3Dbar%20baz'
    assert unicode_urlencode('http://example.com/?foo=bar+baz') == u'http%3A//example.com/%3Ffoo%3Dbar%2Bbaz'

# Generated at 2022-06-21 04:47:07.656186
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'plain string') == u'plain%20string'
    assert do_urlencode(u'utf8-string-ⓐⓑⓒ') == u'utf8-string-%E2%93%90%E2%93%91%E2%93%92'
    assert do_urlencode({u'a': 1, u'b': 2, u'c': 3}) == u'a=1&c=3&b=2'
    assert do_urlencode([u'a', u'b', u'c', u'd']) == u'a&b&c&d'



# Generated at 2022-06-21 04:47:13.106281
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    string = 'foo%7Cbar%3Dbaz'
    assert filters['urldecode'](string) == u'foo|bar=baz'
    assert HAS_URLENCODE or 'urlencode' in filters


# Generated at 2022-06-21 04:47:23.579504
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    testModule = FilterModule()
    testFilters = testModule.filters()
    # test filters that depends on import from jinja2.filters
    test_do_urldecode = testFilters['urldecode']
    assert test_do_urldecode
    assert isinstance(test_do_urldecode, (type(test_FilterModule_filters), type(test_FilterModule_filters)))
    assert test_do_urldecode('%C3%9C%C3%BC%C3%A4%C3%B6%C3%B1') == u'Üüäöñ'
    if HAS_URLENCODE:
        # test do_urlencode
        test_do_urlencode = testFilters['urlencode']

# Generated at 2022-06-21 04:47:27.292474
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instant = FilterModule()
    assert isinstance(instant, FilterModule)
    assert instant.__class__.__name__ == 'FilterModule'

# Generated at 2022-06-21 04:47:39.177926
# Unit test for function do_urlencode
def test_do_urlencode():
    a = {
        'a': 'b',
        'c': 'd',
        'e': {
            'f': 'g',
            'h': 'i',
        }
    }

    b = do_urlencode(a)

    assert b == u'a=b&c=d&e=f%3Dg%26h%3Di'

# Generated at 2022-06-21 04:47:43.088478
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode


# Generated at 2022-06-21 04:47:51.267537
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # https://w3techs.com/technologies/overview/character_encoding/all
    # https://cloud.google.com/text-to-speech/docs/reference/rest/v1beta1/synthesize#AudioEncoding
    # https://en.wikipedia.org/wiki/Percent-encoding
    assert unicode_urlencode(u'per cént') == u'per%20c%C3%A9nt'
    assert unicode_urlencode(u'per cént', for_qs=True) == u'per+c%C3%A9nt'

# Generated at 2022-06-21 04:47:55.832640
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-21 04:48:01.522381
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    mystring = u"Hello%2C%20world%21+%26+%C3%A9l%C3%A9phant"
    mystring = unicode_urldecode(mystring)
    mystring = to_text(mystring)
    assert mystring == "Hello, world! & éléphant"


# Generated at 2022-06-21 04:48:04.519793
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # FilterModule is a class
    assert (issubclass(FilterModule, object))


# Generated at 2022-06-21 04:48:14.641180
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import unittest
    from ansible.module_utils._text import to_bytes

    class TestUnicodeUrlEncode(unittest.TestCase):
        def test_unicode_uridecode_ascii(self):
            test_str = u'Bob:%20Bob'
            expected = u'Bob: Bob'
            self.assertEqual(expected, unicode_urldecode(test_str))

        def test_unicode_uridecode_unicode(self):
            test_str = u'Bob:%20Bob'
            expected = u'Bob: Bob'
            self.assertEqual(expected, unicode_urldecode(test_str))

        def test_unicode_uridecode_bytes(self):
            test_str = b'Bob:%20Bob'

# Generated at 2022-06-21 04:48:27.622767
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == ''
    assert do_urlencode('abcd123') == 'abcd123'
    assert do_urlencode('/abcd') == '%2Fabcd'
    assert do_urlencode('abcd/') == 'abcd%2F'
    assert do_urlencode('abcd/efgh') == 'abcd%2Fefgh'
    assert do_urlencode('+') == '%2B'
    assert do_urlencode(' ') == '+'
    assert do_urlencode('a+b') == 'a%2Bb'
    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode('a=b&c=d') == 'a%3Db%26c%3Dd'

# Generated at 2022-06-21 04:48:33.769720
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc+123') == u'abc 123'
    assert unicode_urldecode(u'abc%2B123') == u'abc%2B123'



# Generated at 2022-06-21 04:48:43.260556
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == u'foo'
    assert do_urldecode('foo+bar') == u'foo bar'
    assert do_urldecode('foo%20bar') == u'foo bar'
    assert do_urldecode('foo%2Fbar') == u'foo/bar'
    assert do_urldecode('foo%%2Fbar') == u'foo%/bar'


# Generated at 2022-06-21 04:48:58.252621
# Unit test for function do_urlencode
def test_do_urlencode():
    # Check if '%' is encoded or decoded
    assert do_urlencode('%') == "%25"

    # Check if '+' is encoded or decoded
    assert do_urlencode('+') == '%2B'
    assert do_urldecode('%2B') == '+'

    assert do_urlencode('/') == '/'
    assert do_urldecode('/') == '/'

    # Check if '&' is encoded or decoded
    assert do_urlencode('&') == '%26'
    assert do_urldecode('%26') == '&'
    data = {'a': 'A', 'b': 'B'}
    assert do_urlencode(data) == 'a=A&b=B'

    # Check if '&=' is encoded

# Generated at 2022-06-21 04:49:05.833380
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('hello world') == 'hello world'
    assert do_urldecode('hello+world') == 'hello world'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('%7B%22a%22%3A1%2C%22b%22%3A2%7D') == '{"a":1,"b":2}'


# Generated at 2022-06-21 04:49:18.260125
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('hello/world') == 'hello%2Fworld'
    assert unicode_urlencode(u'hello/world') == 'hello%2Fworld'
    assert unicode_urlencode(u'hello/world', for_qs=True) == 'hello%2Fworld'
    assert unicode_urlencode({'key': 'val'}) == 'key=val'
    assert unicode_urlencode({'key': 'val', 'key2': 'val2'}) == 'key=val&key2=val2'
    assert unicode_urlencode({'key': 'val', 'key2': 'va=l2'}) == 'key=val&key2=va%3Dl2'
    assert unicode_urlencode({u'key': u'va/l'})

# Generated at 2022-06-21 04:49:26.000621
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("test%2520+%26+test") == "test%20 & test"
    assert unicode_urldecode("test+%2520+%26+test") == "test %20 & test"
    assert unicode_urldecode("test+%2520+%26+test%25") == "test %20 & test%"


# Generated at 2022-06-21 04:49:38.250511
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing unicode_urldecode")

    # Unicode
    assert unicode_urldecode("%C3%A5%C3%A6%C3%B8") == to_text("åæø")

    # Percent-encoded octets which represent non-ASCII octets
    assert unicode_urldecode("%25") == to_text("%")

    # Percent-encoded octets which represent ASCII octets
    assert unicode_urldecode("%2B") == to_text("+")

    # UTF-8 characters encoded into octets
    assert unicode_urldecode("%C3%A5%C3%A6%C3%B8") == to_text("åæø")

    # UTF-16 characters encoded into octets
    assert unicode_urldec

# Generated at 2022-06-21 04:49:47.775057
# Unit test for function do_urlencode
def test_do_urlencode():
    for for_qs, test in ((False, 'http://foo.bar/?foo=bar&baz=bar'),
                         (True, 'foo=bar&baz=bar')):
        assert do_urlencode(test) == test
        assert do_urlencode({'foo': 'bar', 'baz': 'bar'}) == test
        assert do_urlencode(['foo', 'bar', 'baz', 'bar']) == test
        assert do_urlencode(('foo', 'bar', 'baz', 'bar')) == test

# Generated at 2022-06-21 04:49:54.273732
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%E2%82%AC') == u'€'


# Generated at 2022-06-21 04:49:59.307349
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Ffoo%20bar%2Fbaz%26blurb%3D%20spam%3Fparam%3D%25e2%2582%25ac') == 'http://foo bar/baz&blurb= spam?param=€'


# Generated at 2022-06-21 04:50:07.378022
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    argument_spec = dict()
    fm = FilterModule()
    assert fm is not None
    method = 'filters'
    filters = basic.AnsibleModule(argument_spec=argument_spec, supports_check_mode=False).run_command(method, fm)
    assert len(filters) != 0

# Generated at 2022-06-21 04:50:14.987268
# Unit test for function do_urlencode