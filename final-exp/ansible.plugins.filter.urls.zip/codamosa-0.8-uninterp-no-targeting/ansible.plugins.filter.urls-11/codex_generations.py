

# Generated at 2022-06-21 04:40:27.522446
# Unit test for function do_urlencode
def test_do_urlencode():
    string_values = ['shrug ¯\\\\_(ツ)_/¯', 'My test string', 'My test string with a space']
    for string in string_values:
        assert(do_urlencode(string) == unicode_urlencode(string))

    dict_values = [{'a': '1', 'b': '2'}, {'foo': 'bar'}, {'username': 'admin', 'password': 'password'}]
    for dict_val in dict_values:
        assert(do_urlencode(dict_val) == unicode_urlencode(dict_val))

    string_values = ['shrug ¯\\\\_(ツ)_/¯', 'My test string', 'My test string with a space']

# Generated at 2022-06-21 04:40:36.830200
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    # test urldecode
    assert filters['urldecode']('https://github.com/ansible/ansible/issues/4034') == 'https://github.com/ansible/ansible/issues/4034', 'test urldecode failed'
    assert filters['urldecode']('https%3A%2F%2Fgithub.com%2Fansible%2Fansible%2Fissues%2F4034') == 'https://github.com/ansible/ansible/issues/4034', 'test urldecode failed'
    # test urlencode

# Generated at 2022-06-21 04:40:48.866113
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%20def%20ghi') == u'abc def ghi'
    assert unicode_urldecode('abc+def') == u'abc+def'
    assert unicode_urldecode('abc+def+ghi') == u'abc+def+ghi'

if __name__ == '__main__':
    from ansible.module_utils.six import PY3
    if PY3:
        from ansible.module_utils.six.moves import unittest
    else:
        import unittest
    unitt

# Generated at 2022-06-21 04:40:51.519005
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('c%20c') == 'c c'


# Generated at 2022-06-21 04:41:00.176334
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode([('foo', 'bar')]) == 'foo=bar'
    assert do_urlencode('foo-bar') == 'foo-bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'

# Generated at 2022-06-21 04:41:06.655305
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'+++') == u'%2B%2B%2B'
    assert unicode_urlencode(u'+++', for_qs=True) == u'%2B%2B%2B'
    assert unicode_urlencode(b'+++') == u'%2B%2B%2B'
    assert unicode_urlencode(b'+++', for_qs=True) == u'%2B%2B%2B'


# Generated at 2022-06-21 04:41:14.273871
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"") == ""
    assert unicode_urldecode(u"%20%21%24%26%27%28%29%2A%2B%2C%3B%3D") == " !$&'()*+,;="
    assert unicode_urldecode(u"%C3%A9") == u"é"


# Generated at 2022-06-21 04:41:17.287571
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.com') == 'http%3A//www.example.com'



# Generated at 2022-06-21 04:41:20.808661
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }


# Generated at 2022-06-21 04:41:25.218488
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_data = '%E2%82%AC%20%E2%82%AC%20%E2%82%AC%20%E2%82%AC'
    expected_result = u'€ € € €'
    result = unicode_urldecode(test_data)
    assert result == expected_result



# Generated at 2022-06-21 04:41:28.766458
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mod = FilterModule()
    assert mod is not None

# Generated at 2022-06-21 04:41:38.036529
# Unit test for function do_urlencode
def test_do_urlencode():
    import pytest

# Generated at 2022-06-21 04:41:48.318992
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils._text import to_unicode
    assert do_urlencode(1) == u'1'
    assert do_urlencode('1') == u'1'
    assert do_urlencode(to_unicode('1')) == u'1'
    assert do_urlencode({'a': 'b'}) == u'a=b'
    assert do_urlencode(['a', 'b']) == u'a&b'
    assert do_urlencode(('a', 'b')) == u'a&b'
    assert do_urlencode(u'a=bc') == u'a%3Dbc'
    assert do_urlencode({u'a': u'bc'}) == u'a=bc'

# Generated at 2022-06-21 04:41:55.816789
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    assert hasattr(m, 'filters')
    assert callable(getattr(m, 'filters', None))
    assert isinstance(m.filters(), dict)
    assert 'urldecode' in m.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in m.filters()



# Generated at 2022-06-21 04:42:06.218953
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils.common.text.converters import to_unicode
    assert do_urldecode('a+b%2Bc') == 'a+b+c'
    assert do_urldecode(u'a+b%2Bc') == to_unicode('a+b+c')
    assert do_urldecode('a+b%2Bc') == to_unicode('a+b+c')
    assert do_urldecode('/a%2Fb/c%2Fd') == 'a/b/c/d'
    assert do_urldecode('/a%2Fb/c%2Fd') == to_unicode('a/b/c/d')

# Generated at 2022-06-21 04:42:13.502256
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test all non method filter of class FilterModule
    # (using class FilterModule directly)
    filters = FilterModule().filters()

    # Test urldecode
    assert (filters['urldecode']("a%2Bb") == "a+b")

    # Test urlencode
    assert (filters['urlencode']("a+b") == "a%2Bb")

# Generated at 2022-06-21 04:42:17.421963
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == u'foo bar'
    assert do_urldecode('foo bar') == u'foo bar'


# Generated at 2022-06-21 04:42:19.116863
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == u' '


# Generated at 2022-06-21 04:42:29.884749
# Unit test for function do_urldecode
def test_do_urldecode():
    link_normal = 'https://www.google.com/?q=abc+def#abc'
    result_normal = 'https://www.google.com/?q=abc+def#abc'

    link_encoded = 'https%3A%2F%2Fwww.google.com%2F%3Fq%3Dabc%2Bdef%23abc'
    result_encoded = 'https://www.google.com/?q=abc+def#abc'

    assert do_urldecode(link_normal) == result_normal
    assert do_urldecode(link_encoded) == result_encoded



# Generated at 2022-06-21 04:42:39.807865
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'Hello / That\u2019s Cool') == u'Hello / That\u2019s Cool'
    assert do_urldecode(b'Hello / That\xe2\x80\x99s Cool') == u'Hello / That\u2019s Cool'

    assert do_urldecode(u'Hello / That%27s Cool') == u"Hello / That's Cool"
    assert do_urldecode(b'Hello / That%27s Cool') == u"Hello / That's Cool"


# Generated at 2022-06-21 04:42:51.466684
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def assertEqual(a, b):
        assert a == b, "%r != %r" % (a, b)

    # Py2
    assertEqual(unicode_urlencode(""), "")
    assertEqual(unicode_urlencode("/"), "%2F")
    assertEqual(unicode_urlencode("+"), "%2B")
    assertEqual(unicode_urlencode(" "), "+")
    assertEqual(unicode_urlencode('\\'), "%5C")
    assertEqual(unicode_urlencode(u'\u20ac'), "%E2%82%AC")
    assertEqual(unicode_urlencode({'a': 'b'}), "a=b")

# Generated at 2022-06-21 04:42:59.811797
# Unit test for function do_urlencode
def test_do_urlencode():
    test_data = {
        'key': 'value',
        'key space': 'value space',
        'key:multivalue': ['value1', 'value2'],
        'key:multivalue space': ['value1', 'value2 space'],
        'key:unordered': {'1': 'value1', '2': 'value2'},
        'key:unordered space': {'1': 'value1', '2 space': 'value2'},
    }


# Generated at 2022-06-21 04:43:12.923874
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'  # Basic usage
    assert unicode_urldecode(u' ') == u' '      # Space
    assert unicode_urldecode(u'+') == u' '      # Should be space
    assert unicode_urldecode(u'%20') == u' '    # Percent encoded space
    assert unicode_urldecode(u'%2B') == u'+'    # Percent encoded plus
    assert unicode_urldecode(u'foo+') == u'foo '
    assert unicode_urldecode(u'foo%20') == u'foo '

    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode(' ') == u' '

# Generated at 2022-06-21 04:43:24.382109
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'test') == u'test'
    assert do_urldecode(u'x%20y') == u'x y'
    assert do_urldecode(u'x+y') == u'x+y'
    assert do_urldecode(u'x%2B%2B%2B%2By') == u'x+++y'
    assert do_urldecode(u'x.y') == u'x.y'
    assert do_urldecode(u'x%2Cz') == u'x,z'
    assert do_urldecode(u'x%2ey') == u'x.y'
    assert do_urldecode(u'x%2Fy') == u'x/y'
    assert do_

# Generated at 2022-06-21 04:43:34.164449
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'

# Generated at 2022-06-21 04:43:35.617256
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert issubclass(FilterModule, object)

# Generated at 2022-06-21 04:43:39.068575
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%82%B3%E3%83%9A') == 'コペ'



# Generated at 2022-06-21 04:43:44.259735
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a/b') == 'a%2Fb'
    assert unicode_urlencode(u'a/b', for_qs=True) == 'a%2Fb'
    assert unicode_urlencode(u'a b') == 'a+b'
    assert unicode_urlencode(u'a b', for_qs=True) == 'a+b'



# Generated at 2022-06-21 04:43:45.679447
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()


# Generated at 2022-06-21 04:44:00.961998
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode'](' ') == ' '
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'](' ') == '%20'
        assert fm.filters()['urlencode']('%20') == '%20'
    if not PY3:
        assert fm.filters()['urldecode'](u'%20') == u' '
        if not HAS_URLENCODE:
            assert fm.filters()['urlencode'](u' ') == u'%20'
            assert fm.filters()['urlencode'](u'%20') == u'%20'

# Generated at 2022-06-21 04:44:13.054767
# Unit test for function do_urldecode

# Generated at 2022-06-21 04:44:24.796809
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo%20bar') == u'foo bar'
    assert do_urldecode(u'abc%2B%24%25') == u'abc+$%'
    assert do_urldecode(u'%E4%BA%BA%E6%B0%91') == u'\u4eba\u6c11'
    assert do_urldecode(u'%F0%9F%98%8D') == u'\U0001f60d'
    assert do_urldecode(u'%2F') == u'/'


# Generated at 2022-06-21 04:44:38.633226
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test decoding a string
    test1 = 'ABC+%2B+%2F+%21%40%23%24%25%5E%26*()'
    expected1 = 'ABC+ + / !@#$%^&*()'
    assert unicode_urldecode(test1) == expected1, "Decoded string is different"

    # Test decoding a unicode string
    test2 = u'ABC+%2B+%2F+%21%40%23%24%25%5E%26*()'
    expected2 = u'ABC+ + / !@#$%^&*()'
    assert unicode_urldecode(test2) == expected2, "Decoded string is different"



# Generated at 2022-06-21 04:44:51.012759
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%E6%96%87%E5%AD%97%E7%AC%A6%E4%B8%B2") == u"文字符串"
    assert unicode_urldecode(u"%D6%D0%CE%C4%2B%B5%C4") == u"中文+的"
    assert unicode_urldecode(u"%D6%D0%CE%C4+%B5%C4") == u"中文+的"
    assert unicode_urldecode(u"%D6%D0%CE%C4%B5%C4") == u"中文的"

# Generated at 2022-06-21 04:45:02.868464
# Unit test for function do_urldecode
def test_do_urldecode():
    # Examples from https://docs.python.org/2/library/urllib.html
    # The string was first urlencoded and then urldecoded (to get back the original string)
    assert do_urldecode(b"foo") == "foo"
    assert do_urldecode(b"foo+bar") == "foo bar"
    assert do_urldecode(b"foo%20bar") == "foo bar"
    assert do_urldecode("foo") == "foo"
    assert do_urldecode("foo+bar") == "foo bar"
    assert do_urldecode("foo%20bar") == "foo bar"
    # In Python 3, unquote plus should return unicode

# Generated at 2022-06-21 04:45:08.023012
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%7B%22foo%22%3A+%22bar%22%7D') == u'{"foo": "bar"}'
    assert do_urldecode('%7B%22foo%22%3A+%22bar%22%7D') == u'{"foo": "bar"}'



# Generated at 2022-06-21 04:45:11.560401
# Unit test for function do_urldecode
def test_do_urldecode():
    string = "hello%2C+world%21"
    assert do_urldecode(string) == "hello, world!"



# Generated at 2022-06-21 04:45:20.485036
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test urldecode filter '''
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%7E') == '~'
    assert do_urldecode('+') == ' '
    assert do_urldecode('%22') == '"'
    assert do_urldecode('%40') == '@'
    assert do_urldecode('%23') == '#'
    assert do_urldecode('%24') == '$'
    assert do_urldecode('%2C') == ','
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%3A') == ':'
    assert do_urldecode('%3B') == ';'

# Generated at 2022-06-21 04:45:34.625722
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%s') == u'%s'
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%2f') == u'/'
    assert do_urldecode('%E3%81%82') == u'あ'
    assert do_urldecode('%E3%80%80') == u'　'
    assert do_urldecode('%E4%BB%8A%E6%97%A5%E3%81%AF%E4%B8%80%E6%97%A5') == u'今日は一日'
    assert do_urldecode('%35') == u'5'


# Generated at 2022-06-21 04:45:40.070906
# Unit test for function do_urlencode
def test_do_urlencode():

    value = {'special*-._': 'chars'}
    result = do_urlencode(value)
    assert(result == 'special%2A-._=chars')

    value = 'test@test.test'
    result = do_urlencode(value)
    assert(result == 'test%40test.test')

# Generated at 2022-06-21 04:45:49.288049
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''test_filter_module_filters'''
    assert do_urldecode('%2Fusr%2Flib%2Fpython2.7%2Fdist-packages%2Fansible%2Fmodule_utils%2Fnetconf.py') \
        == '/usr/lib/python2.7/dist-packages/ansible/module_utils/netconf.py'
    assert do_urlencode({'a': 'A', 'b': 'B'}) == 'a=A&b=B'
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'
    assert do_urlencode(['a=b']) == 'a%3Db'

# Generated at 2022-06-21 04:45:50.343851
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test is not None

# Generated at 2022-06-21 04:46:03.494153
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'\u2713' == unicode_urldecode('%e2%9c%93')
    assert u'A%2B+B' == unicode_urldecode('A%2B+B')
    assert u'A+B' == unicode_urldecode('A+B')
    assert u'A+B' == unicode_urldecode('A%20B')
    assert u'A+B' == unicode_urldecode('A%20+B')
    assert u'A+B' == unicode_urldecode('A%20+%20B')
    assert u'A+B' == unicode_urldecode('A%20%2b%20B')

# Generated at 2022-06-21 04:46:09.140451
# Unit test for function do_urlencode
def test_do_urlencode():

    assert 'a%20string' == do_urlencode('a string')
    assert 'a%20string%26' == do_urlencode('a string&')
    assert 'a%20string=a%20list' == do_urlencode({'a string': 'a list'})
    assert 'a%20string=a%20list' == do_urlencode([('a string', 'a list')])

# Generated at 2022-06-21 04:46:17.871564
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test strings
    '''
    test_strings = dict(
        simple_ascii=b'abcd1234',
        simple_nonascii=b'#\xc3\xa9\xe2\x82\xac',
        complex='http://www.google.com/search?q=ansible+%23automation_hate',
        complex_nonascii=u'http://www.googl\u00e9.com/search?q=ansibl\u00e9+%23automation_hat\u00e9',
        empty=u'',
        none=None,
    )


# Generated at 2022-06-21 04:46:22.401850
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('key%20=%20value%21') == 'key = value!'
    assert do_urldecode('key+%20=+%20value+%21') == 'key = value!'


# Generated at 2022-06-21 04:46:27.453675
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert f.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:46:33.786410
# Unit test for function do_urlencode
def test_do_urlencode():
    '''Test urlencode function'''
    data = {'Test key': 'Test value'}
    expected_result = 'Test%20key=Test%20value'
    result = do_urlencode(data)
    assert result == expected_result


# Generated at 2022-06-21 04:46:43.905616
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'pandas & giraffes') == u'pandas+%26+giraffes'
    assert do_urlencode(u'c1=a,c2=b') == u'c1=a%2Cc2%3Db'
    assert do_urlencode(u'c++') == u'c%2B%2B'
    assert do_urlencode([u'c++', u'ruby']) == u'c%2B%2B&ruby'
    assert do_urlencode({u'a': 1, u'b': 2}) == u'a=1&b=2'

# Generated at 2022-06-21 04:46:45.837271
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b%20c') == u'a b c'


# Generated at 2022-06-21 04:46:50.699163
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2b') == u'+'


# Generated at 2022-06-21 04:47:01.106404
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import os
    import json
    import pytest
    import ansible.constants as C
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode

    # Capture results to check output
    results = []

    os.environ[b'ANSIBLE_CONFIG'] = to_bytes(C.DEFAULT_CONFIG_FILE)
    display = Display()
    display.verbosity = 4

    class Capture:
        def __init__(self, method):
            self.method = method


# Generated at 2022-06-21 04:47:04.248566
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%2Bb') == u'a+b'
    assert do_urldecode('a+b') == u'a+b'


# Generated at 2022-06-21 04:47:16.420044
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == u''
    assert do_urlencode('foo bar') == u'foo%20bar'
    assert do_urlencode({'baz': 'bam'}) == u'baz=bam'
    assert do_urlencode(['foo', 'bar']) == u'foo&bar'
    assert do_urlencode({'baz': 'bam'}, for_qs=True) == u'baz=bam'
    assert do_urlencode(['foo', 'bar'], for_qs=True) == u'foo&bar'

# Generated at 2022-06-21 04:47:28.333794
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("/foo bar/") == "/foo%20bar/"
    assert do_urlencode(["/foo bar/"]) == "/foo%20bar/"
    assert do_urlencode("/foo bar/") == do_urlencode("/foo bar/")
    assert do_urlencode("/foo bar/") == do_urlencode("/foo bar/")
    assert do_urlencode("/foo bar/") == do_urlencode("/foo bar/")
    assert do_urlencode("/foo bar/") == do_urlencode("/foo bar/")
    assert do_urlencode("/foo bar/") == do_urlencode("/foo bar/")

# Generated at 2022-06-21 04:47:35.950496
# Unit test for function do_urlencode
def test_do_urlencode():
    string = '&'
    encoded_string = '%26'
    assert do_urlencode(string) == encoded_string
    assert do_urldecode(encoded_string) == string

    string = 'fédéré'
    encoded_string = 'f%C3%A9d%C3%A9r%C3%A9'
    assert do_urlencode(string) == encoded_string
    assert do_urldecode(encoded_string) == string

    string = 'fédéré'
    encoded_string = 'f%C3%A9d%C3%A9r%C3%A9'
    assert do_urlencode(string) == encoded_string
    assert do_urldecode(encoded_string) == string


# Generated at 2022-06-21 04:47:41.497676
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('STRING%20with%20+spaces') == 'STRING with spaces'
    assert unicode_urldecode('STRING%20with%20+spaces') == unicode_urldecode(u'STRING%20with%20+spaces')
    assert unicode_urldecode(to_bytes('STRING%20with%20+spaces')) == unicode_urldecode(to_bytes(u'STRING%20with%20+spaces'))



# Generated at 2022-06-21 04:47:44.596138
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode(u'hello%20world') == u'hello world'



# Generated at 2022-06-21 04:47:46.609371
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Examples from RFC 3986
    assert unicode_urldecod

# Generated at 2022-06-21 04:47:59.337809
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test the unicode_urlencode filter '''
    assert unicode_urlencode(0) == u'0'
    assert unicode_urlencode('foo') == u'foo'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo/bar') == u'foo/bar'
    assert unicode_urlencode('foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode('foo?bar') == u'foo%3Fbar'
    assert unicode_urlencode('foo') == u'foo'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo/bar') == u'foo/bar'
    assert unic

# Generated at 2022-06-21 04:48:11.286954
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urlencode' in filter_module.filters()
    assert 'urldecode' in filter_module.filters()
    assert 'urlencode' in filter_module.filters()
    assert 'urldecode' in filter_module.filters()
    assert filter_module.filters()['urldecode'] == do_urldecode
    assert filter_module.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:48:24.071802
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def urlencode(s):
        return unicode_urlencode(s.encode('utf-8')).decode('utf-8')

    assert urlencode('a') == 'a'
    assert urlencode('ab') == 'ab'
    assert urlencode('a b') == 'a+b'
    assert urlencode('a+b') == 'a%2Bb'
    assert urlencode('a=b') == 'a%3Db'
    assert urlencode('a&b') == 'a%26b'
    assert urlencode('a/b') == 'a%2Fb'
    assert urlencode('a;b') == 'a%3Bb'

    assert urlencode('\u20ac') == '%E2%82%AC'

# Generated at 2022-06-21 04:48:28.295620
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('+&+') == u' & '


# Generated at 2022-06-21 04:48:29.413094
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:48:34.276627
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    # Assert normal
    assert test.filters()['urldecode'] is do_urldecode
    # Assert custom
    if not HAS_URLENCODE:
        assert test.filters()['urlencode'] is do_urlencode


# Generated at 2022-06-21 04:48:44.427373
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test 1: try to decode a non-unicode string
    result = unicode_urldecode('%F3%BC%E3%80%80%F3%BE%80%80%F3%BE%80%81%F3%BE%80%82%F3%BE%80%83%F3%BE%80%84%F3%BE%80%85%F3%BE%80%86%F3%BE%80%87%F3%BE%80%88%F3%BE%80%89%F3%BE%80%8A%F3%BE%80%8B%F3%BE%80%8C%F3%BE%80%8D')

# Generated at 2022-06-21 04:48:57.509579
# Unit test for function do_urlencode
def test_do_urlencode():
    def test_value(value):
        expected = do_urlencode(value)
        result = do_urlencode(value)
        assert expected == result


# Generated at 2022-06-21 04:49:01.320473
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    for filter_n, filter_f in fm.filters().items():
        assert filter_n
        assert filter_f


# Generated at 2022-06-21 04:49:03.691951
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_filter = FilterModule()
    assert ansible_filter is not None



# Generated at 2022-06-21 04:49:10.718526
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test for Python 2 use case
    source = u'é'
    encoded = unicode_urlencode(source)
    assert encoded == u'%C3%A9'
    assert isinstance(encoded, unicode)

    # Test for Python 3 use case
    source = u'é'
    encoded = unicode_urlencode(source)
    assert encoded == '%C3%A9'

    # Test for Python 2 use case, generating query strings
    source = u'é'
    encoded = unicode_urlencode(source, for_qs=True)
    assert encoded == u'%C3%A9'
    assert isinstance(encoded, unicode)

    # Test for Python 3 use case, generating query strings
    source = u'é'

# Generated at 2022-06-21 04:49:18.507283
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('a%2B%2B%2Bb') == u'a+++b'
    if not HAS_URLENCODE:
        assert do_urlencode(u'a+++b') == u'a%2B%2B%2Bb'
        assert do_urlencode(u'a+++b') == 'a%2B%2B%2Bb'

# Generated at 2022-06-21 04:49:24.850097
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_module_class_dict = {}
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:49:29.780882
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20world%21') == u'hello world!'
    assert unicode_urldecode(u'hello world!') == u'hello world!'
    assert unicode_urldecode(u'hello+world%21') == u'hello world!'
    assert unicode_urldecode('hello%20world%21') == u'hello world!'
    assert unicode_urldecode('hello world!') == u'hello world!'
    assert unicode_urldecode('hello+world%21') == u'hello world!'


# Generated at 2022-06-21 04:49:36.672095
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tester = FilterModule()
    filters = tester.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in filters

# Generated at 2022-06-21 04:49:44.887984
# Unit test for function do_urlencode
def test_do_urlencode():
    assert (do_urlencode("some-words") ==
            do_urlencode("some-words"))
    assert (do_urlencode("some words") ==
            do_urlencode("some+words"))
    assert (do_urlencode("/some/words/") ==
            do_urlencode("/some/words/"))
    assert (do_urlencode("some words here and there") ==
            do_urlencode("some+words+here+and+there"))
    assert not do_urlencode({"x": "y"}) == do_urlencode({"x": "z"})
    assert (do_urlencode({"x": "y"}) ==
            do_urlencode({"x": "y"}))

# Generated at 2022-06-21 04:49:50.785153
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert unicode_urlencode('Dag Wieers') == 'Dag%20Wieers'
    assert unicode_urlencode('Dag Wieers', for_qs=True) == 'Dag+Wieers'
    assert unicode_urldecode('Dag%20Wieers') == 'Dag Wieers'
    assert unicode_urldecode(unicode_urlencode('Dag Wieers')) == 'Dag Wieers'



# Generated at 2022-06-21 04:50:00.032142
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Call method
    result = FilterModule().filters()
    
    # Verify the result
    assert isinstance(result, dict)
    assert 'urldecode' in result
    assert isinstance(result['urldecode'], types.FunctionType)

if __name__ == "__main__":
    import sys
    import nose2
    # Run the unit tests
    nose2.main(argv=[sys.argv[0], '-v', '--with-coverage', '--cover-package=ansible.module_utils.urls'] + sys.argv[1:])

# Generated at 2022-06-21 04:50:11.703124
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # The code below is for Python 2.6-2.6.8, which have a bug in unicode handling
    # This code is adapted from http://bugs.python.org/issue2637, which contains
    # a testcase
    import sys
    if sys.version_info[:3] >= (2, 6, 9):
        return

    # We cannot use unicode_urldecode directly because we need to fool it
    # into thinking we are using Python 2.6
    # So we replace unicode_urldecode with its content
    from ansible.module_utils.urls import unicode_urldecode as urldecode
    global unquote_plus
    unquote_plus = urldecode.unquote_plus
    global to_text
    to_text = urldecode.to_text
   

# Generated at 2022-06-21 04:50:17.560825
# Unit test for function do_urldecode
def test_do_urldecode():
    string = 'dag+%21+%23+%24+%25+%26+%27+%28+%29+%30'
    result = do_urldecode(string)
    assert result == 'dag ! # $ % & \' ( ) 0'

