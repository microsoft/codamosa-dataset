

# Generated at 2022-06-21 04:40:25.010017
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%2fbar%3D') == u'foo/bar='
    # Verify that arespecial characters are properly decoded
    assert unicode_urldecode('%21%2A%27%28%29%3B%3A%40%26%3D%2B%24%2C%2F%3F%25%23%5B%5D') == u'!*\'();:@&=+$,/?%#[]'


# Generated at 2022-06-21 04:40:28.097819
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == u'foo'


# Generated at 2022-06-21 04:40:32.167148
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'https%3A%2F%2Fwww.google.be%2Fsearch%3Fq%3D%2522Abbaye+de%2BWegimont%2522%26ie%3Dutf-8%26oe%3Dutf-8%26gfe_rd%3Dcr%26ei%3DJdTKWZTQKsTd8weU-a6gBg') == u'https://www.google.be/search?q=%22Abbaye+de+Wegimont%22&ie=utf-8&oe=utf-8&gfe_rd=cr&ei=JdTKWZTQKsTd8weU-a6gBg'

# Generated at 2022-06-21 04:40:34.870324
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Make sure we properly decode strings '''
    assert do_urldecode('one%20%26%20two') == 'one & two'
    assert do_urldecode('one%2Ftwo') == 'one/two'


# Generated at 2022-06-21 04:40:41.701514
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%E6%96%87') == u'\u6587'
    assert do_urldecode('%3F%3F%3F') == u'???', '3F is safe char'
    assert do_urldecode('%2f%2F') == u'//', '2f is safe char'
    assert do_urldecode('%25') == u'%'


# Generated at 2022-06-21 04:40:51.871215
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test basic string
    assert unicode_urlencode("foo bar") == "foo%20bar"

    # Test unicode input
    assert unicode_urlencode(u'\u1234') == '%E1%88%B4'

    # Test list
    assert unicode_urlencode(["foo", "bar"]) == 'foo&bar'

    # Test dict
    assert unicode_urlencode({"foo": "bar"}) == 'foo=bar'

# Generated at 2022-06-21 04:40:57.868398
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expected = {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }
    inst = FilterModule()
    actual = inst.filters()
    assert expected == actual


# Generated at 2022-06-21 04:41:07.781566
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert hasattr(filter, 'filters')
    Filters = filter.filters()

    ##
    ## urldecode
    ##
    assert 'urldecode' in Filters
    assert Filters['urldecode'] == do_urldecode

    assert Filters['urldecode']('hello%20world%21') == 'hello world!'
    assert Filters['urldecode']('hello+world%21') == 'hello world!'
    assert Filters['urldecode']('hello+world%21') == 'hello world!'
    assert Filters['urldecode']('hello%20%C3%A0%20world%21') == u'hello à world!'
    assert Filters['urldecode']('hello%20à%20world%21') == u

# Generated at 2022-06-21 04:41:17.939831
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://ansible.com:80/?arg1=foo%20bar') == 'http%3A//ansible.com%3A80/%3Farg1%3Dfoo%20bar'
    assert unicode_urlencode('http://ansible.com:80/?arg1=foo%20bar', for_qs=True) == 'http%3A%2F%2Fansible.com%3A80%2F%3Farg1%3Dfoo%20bar'



# Generated at 2022-06-21 04:41:27.332836
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'test_do_urlencode') == 'test_do_urlencode'
    assert do_urlencode(u'test/test') == 'test%2Ftest'
    assert do_urlencode(u'test?test') == 'test%3Ftest'
    assert do_urlencode(u'test&test') == 'test%26test'
    assert do_urlencode(u'test+test') == 'test%2Btest'
    assert do_urlencode(u'test=test') == 'test%3Dtest'
    assert do_urlencode(u'test:test') == 'test:test'
    assert do_urlencode(u'test;test') == 'test;test'
    assert do_urlencode(u'test#test')

# Generated at 2022-06-21 04:41:38.274946
# Unit test for constructor of class FilterModule
def test_FilterModule():

    filters = FilterModule().filters()
    assert filters['urldecode'](u'%7D') == u'}'
    assert filters['urldecode'](u'%7C') == u'|'
    assert filters['urldecode'](u'%7E') == u'~'
    assert filters['urldecode'](u'%40') == u'@'
    assert filters['urldecode'](u'%20') == u' '
    if not HAS_URLENCODE:
        assert filters['urlencode'](u'}') == u'%7D'
        assert filters['urlencode'](u'|') == u'%7C'
        assert filters['urlencode'](u'~') == u'%7E'

# Generated at 2022-06-21 04:41:46.109018
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    'Test unicode_urlencode'

    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo+bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode('foo+bar', for_qs=True) == 'foo%2Bbar'



# Generated at 2022-06-21 04:41:51.926702
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print('unicode_urldecode("abc") = "%s"' % repr(unicode_urldecode("abc")))
    print('unicode_urldecode("abc%20def") = "%s"' % repr(unicode_urldecode("abc%20def")))
    print('unicode_urldecode("%0A") = "%s"' % repr(unicode_urldecode("%0A")))
    print('unicode_urldecode("%E2%82%AC") = "%s"' % repr(unicode_urldecode("%E2%82%AC")))
    print('unicode_urldecode("%E2%82%AC%0A") = "%s"' % repr(unicode_urldecode("%E2%82%AC%0A")))

# Generated at 2022-06-21 04:41:57.178316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_class = FilterModule
    object_instance = module_class()
    object_class = object_instance.filters()
    filters = object_class
    assert hasattr(filters, 'urldecode')
    assert hasattr(filters, 'urlencode')

# Generated at 2022-06-21 04:42:08.467595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    assert f['urldecode']('%2Fsomething%2Fhere') == '/something/here'
    try:
        from jinja2.filters import do_urlencode
    except ImportError:
        # skip if jinja2 is too old
        return
    assert f['urlencode'](u'/some/thing/here') == '%2Fsome%2Fthing%2Fhere'
    assert f['urlencode'](u'/some/thing/here') == '%2Fsome%2Fthing%2Fhere'


# Generated at 2022-06-21 04:42:13.974415
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_class = FilterModule(object())
    filters = module_class.filters()

    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters



# Generated at 2022-06-21 04:42:27.932950
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.google.com/') == u'http%3A//www.google.com/'
    assert unicode_urlencode('http://www.google.com/?a=1&b=2') == u'http%3A//www.google.com/?a=1&b=2'
    assert unicode_urlencode('http://www.google.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fwww.google.com%2F%3Fa%3D1%26b%3D2'

# Generated at 2022-06-21 04:42:29.889870
# Unit test for function do_urldecode
def test_do_urldecode():
    assert(do_urldecode('%20') == ' ')


# Generated at 2022-06-21 04:42:38.566462
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'

# Generated at 2022-06-21 04:42:46.254860
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Testing') == 'Testing'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode(['a', 'b']) == 'a&b'
    assert do_urlencode({'a': ('b', 'c')}) == 'a=b&a=c'

# Generated at 2022-06-21 04:42:50.317071
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'

# Generated at 2022-06-21 04:42:59.613611
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fexample.com%2Ffoo%2Fbar%3Fbaz%3Dqux%2520quux%26corge%2F%2F') == 'http://example.com/foo/bar?baz=qux%20quux&corge//'


if __name__ == '__main__':
    test_do_urldecode()

# Generated at 2022-06-21 04:43:12.815100
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test basic string
    assert unicode_urlencode('foo') == u'foo'

    # Test bytearray
    assert unicode_urlencode(bytearray(b'foo')) == u'foo'

    # Test nothing to encode
    assert unicode_urlencode('/') == u'/'

    # Test encode for /
    assert unicode_urlencode(u'/', for_qs=False) == u'%2F'

    # Test encode for +
    assert unicode_urlencode(u'+', for_qs=True) == u'%2B'

    # Test space for +
    assert unicode_urlencode(u' ', for_qs=True) == u'+'

    # Test space for %20

# Generated at 2022-06-21 04:43:18.904041
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u"abc123") == u"abc123"
    assert do_urldecode(u"abc%2B123") == u"abc+123"
    assert do_urldecode(u"%C3%A9") == u"é"



# Generated at 2022-06-21 04:43:30.512634
# Unit test for constructor of class FilterModule
def test_FilterModule():
    text = FilterModule()
    if not isinstance(text.filters(), dict):
        raise Exception("Expected dict")

    if not isinstance(text.filters()['urldecode'], type(do_urldecode)):
        raise Exception("Expected type")

    if HAS_URLENCODE:
        if text.filters()['urlencode'] != do_urlencode:
            raise Exception("Expected do_urlencode")
    else:
        if not isinstance(text.filters()['urlencode'], type(do_urlencode)):
            raise Exception("Expected type")


# Generated at 2022-06-21 04:43:43.590248
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_unicode
    text = u'https://example.com/api/v1/jobs/?foo=bar&baz=foobar'
    assert unicode_urlencode(text) == u'https%3A%2F%2Fexample.com%2Fapi%2Fv1%2Fjobs%2F%3Ffoo%3Dbar%26baz%3Dfoobar'
    # Test input is text
    assert unicode_urlencode(to_unicode(text)) == u'https%3A%2F%2Fexample.com%2Fapi%2Fv1%2Fjobs%2F%3Ffoo%3Dbar%26baz%3Dfoobar'
    # Test input is bytes

# Generated at 2022-06-21 04:43:55.114952
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = {
        'a': 'http://www.google.com/search?q=test&sourceid=1',
        'b': 'http://node1.test.ansible.com:22/?a=b&c=d',
        'c': 'http://www.google.com/search?q=test',
        'd': 'http://node1.test.ansible.com:22/?a=b',
        'e': {'f': 'g'},
    }
    fm = FilterModule()

    for k, v in x.items():
        # Python 2
        assert(to_text(fm.filters()['urldecode'](to_text(v))) == k)
        # Python 3

# Generated at 2022-06-21 04:44:05.620153
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Check for ASCII string
    if unicode_urlencode('string') != u'string':
        raise Exception('Unit test for unicode_urlencode fails')

    # Check for Unicode string
    if unicode_urlencode(u'\u043a\u043b\u0438\u043a') != u'%D0%BA%D0%BB%D0%B8%D0%BA':
        raise Exception('Unit test for unicode_urlencode fails')

    # Check for Unicode list
    if unicode_urlencode(['\u043a\u043b\u0438\u043a', 'string']) != u'%D0%BA%D0%BB%D0%B8%D0%BA&string':
        raise Exception('Unit test for unicode_urlencode fails')

# Generated at 2022-06-21 04:44:10.010022
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic
    from ansible.module_utils.urls import url_argument_spec
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus

    from ansible.modules.web_infrastructure.hashi_vault import Vault

    m = Vault()
    m.params = {
        'consumer_key': 'consumer_key',
        'consumer_secret': 'consumer_secret',
        'access_key': 'access_key',
        'access_secret': 'access_secret',
    }


# Generated at 2022-06-21 04:44:13.015081
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    text = u'name+with+spaces'
    result = unicode_urldecode(text)
    assert result == u'name with spaces'


# Generated at 2022-06-21 04:44:21.279576
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('Testing FilterModule.filters()')
    filters = FilterModule().filters()
    assert filters is not None
    assert len(filters) == 2
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:44:22.606868
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule)


# Generated at 2022-06-21 04:44:31.325038
# Unit test for function do_urlencode
def test_do_urlencode():
    assert '%D6%D1' == do_urlencode('ÖÑ')
    assert 'foo' == do_urlencode('foo')
    assert '' == do_urlencode('')
    assert '%21' == do_urlencode('!')
    assert 'a+b=c' == do_urlencode(dict(a='b', c='c'))
    assert '' == do_urlencode(dict())
    assert '' == do_urlencode([])
    assert 'foo' == do_urlencode('foo')
    assert 'foo' == do_urlencode(['foo'])
    assert 'foo' == do_urlencode(('foo',))

# Generated at 2022-06-21 04:44:37.764933
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urldecode': do_urldecode}
    assert to_text(filter_module.filters()['urldecode']('url+encoded')) == 'url encoded'

# Generated at 2022-06-21 04:44:49.494874
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'áéîöú') == u'%C3%A1%C3%A9%C3%AE%C3%B6%C3%BA'
    assert unicode_urlencode(u'áéîöú', for_qs=True) == u'%C3%A1%C3%A9%C3%AE%C3%B6%C3%BA'
    assert unicode_urlencode(u'áéîöú') != unicode_urlencode(u'áéîöú', for_qs=True)


# Generated at 2022-06-21 04:44:55.752015
# Unit test for function do_urldecode
def test_do_urldecode():
    # Basic
    assert do_urldecode('hello+world') == 'hello world'

    # Unicode
    assert do_urldecode('Hello%20W%C3%BCrld') == 'Hello Würld'

    # Fails for dict and list
    try:
        do_urldecode({'hello': 'world'})
    except TypeError:
        pass
    else:
        assert False
    try:
        do_urldecode(['hello', 'world'])
    except TypeError:
        pass
    else:
        assert False

    assert do_urldecode({'hello': 'world'}, True) == 'hello=world'
    assert do_urldecode(['hello', 'world'], True) == 'hello&world'



# Generated at 2022-06-21 04:45:01.452430
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Initialize the module with argument_spec
    fm = FilterModule()

    # Get the actual filters functions
    filters = fm.filters()

    # Assert one by one
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode
    assert len(filters) == 2

# Generated at 2022-06-21 04:45:03.313012
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # test on FilterModule
    fm = FilterModule()
    # test on filters
    assert callable(fm.filters())

# Generated at 2022-06-21 04:45:09.995012
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("hej šđžćč +& /hejdå") == "hej%20%C5%A1%C4%91%C5%BE%C4%87%C4%8D%20%2B%26%20%2Fhejd%C3%A5"



# Generated at 2022-06-21 04:45:23.307486
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six import binary_type, text_type
    assert unicode_urlencode(u'string with spaces') == u'string%20with%20spaces'
    assert unicode_urlencode(u'русский') == u'%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9'
    assert unicode_urlencode(u'汉语/漢語') == u'%E6%B1%89%E8%AF%AD%2F%E6%BC%A2%E8%AA%9E'

# Generated at 2022-06-21 04:45:35.714203
# Unit test for function do_urlencode
def test_do_urlencode():
    import sys
    import pytest

    def assert_urlencode(orig, expected):
        assert do_urlencode(orig) == expected

    # Make sure urlencode works for strings (and safe characters)
    assert_urlencode('abcd', 'abcd')
    assert_urlencode('abcd/', 'abcd%2F')
    assert_urlencode('ab cd', 'ab+cd')
    assert_urlencode('?', '%3F')
    assert_urlencode('/', '%2F')

    # Make sure urlencode works for lists
    assert_urlencode(['foo', 'bar'], 'foo&bar')

    # Make sure urlencode works for tuples

# Generated at 2022-06-21 04:45:46.534900
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/', for_qs=True) == u'%2F'
    assert unicode_urlencode('foo bar baz') == u'foo%20bar%20baz'
    assert unicode_urlencode('foo bar baz', for_qs=True) == u'foo+bar+baz'

    assert unicode_urlencode({'x': 'foo bar baz'}) == u'x=foo%20bar%20baz'
    assert unicode_urlencode([('x', 'foo bar baz')]) == u'x=foo%20bar%20baz'


# Generated at 2022-06-21 04:45:49.560306
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }


# Generated at 2022-06-21 04:45:56.046887
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ff = FilterModule()
    ll = ff.filters()
    assert 'urldecode' in ll
    assert ll['urldecode'] == do_urldecode

    if has_do_urlencode:
        assert 'urlencode' in ll
        assert ll['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in ll

# Generated at 2022-06-21 04:46:00.510836
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({"a": "b"}) == "a=b"
    assert do_urlencode(["a", "b"]) == "a&b"
    assert do_urlencode("a") == "a"
    assert do_urlencode(42) == "42"

# Generated at 2022-06-21 04:46:03.039975
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)
    assert isinstance(FilterModule.filters(FilterModule()), dict)


# Generated at 2022-06-21 04:46:12.776953
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode({'foo': [1, 2, 3]}) == 'foo=1&foo=2&foo=3'

# Generated at 2022-06-21 04:46:16.657796
# Unit test for function do_urldecode
def test_do_urldecode():
    # unit tests should avoid using assert
    # https://hynek.me/articles/testing-packaging/
    def _test_do_urldecode_assert_equal(x, y):
        if x != y:
            raise AssertionError(
                '%r != %r' % (x, y))

    # do_urldecode should decode to an unicode string
    _test_do_urldecode_assert_equal(
        unicode_urldecode('Hello%20World'),
        u'Hello World')
    _test_do_urldecode_assert_equal(
        unicode_urldecode('Hello%20World%21'),
        u'Hello World!')
    
    from ansible.module_utils._text import to_bytes, to_text
    _test_do

# Generated at 2022-06-21 04:46:24.691899
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/ å') == 'http%3A%2F%2Fexample.com%2F+%C3%A5'
    assert do_urlencode({'key': u'value å'}) == 'key=value+%C3%A5'
    assert do_urlencode([u'list', u'tuple']) == 'list&tuple'

# Generated at 2022-06-21 04:46:33.449755
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode(u'%2b') == u'+'
    assert unicode_urldecode(u'+') == u' '



# Generated at 2022-06-21 04:46:43.276909
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode string') == 'unicode%20string'

# Generated at 2022-06-21 04:46:48.342062
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_bytes, to_text
    from random import randint
    for i in range(0, 100):
        for for_qs in [True, False]:
            teststring = u' '.join([u'%d' % randint(0, 9) for _ in range(0, randint(1, 10))])
            testbytes = to_bytes(teststring)
            if for_qs:
                assert unicode_urlencode(teststring, True) == u'%26'.join([u'%253d' % int(x) for x in testbytes])
            else:
                assert unicode_urlencode(teststring) == u'%2f'.join([u'%253d' % int(x) for x in testbytes])



# Generated at 2022-06-21 04:46:59.659834
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'
    assert unicode_urlencode({'k1': 'v1', 'k2': 'v2'}) == 'k1=v1&k2=v2'

# Generated at 2022-06-21 04:47:07.415032
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('R%26D') == u'R&D'
    assert unicode_urldecode('R%26D%93') == u'R&D“'
    assert unicode_urldecode('%C2%90') == u'‚'
    assert unicode_urldecode('%C2%94') == u'„'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%84%A2') == u'™'
    assert unicode_urldecode('%E2%80%A6') == u'…'


# Generated at 2022-06-21 04:47:18.478331
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == 'test'
    assert do_urlencode('test@example.com') == 'test%40example.com'
    assert do_urlencode('/usr/bin') == '/usr/bin'
    assert do_urlencode(u'/usr/bin') == '/usr/bin'
    assert do_urlencode('test&test') == 'test%26test'
    assert do_urlencode('&/=') == '%26/%3d'
    assert do_urlencode(u'/usr/bin') == '/usr/bin'
    assert do_urlencode({'k1': 'v1', 'k2': 'v2'}) == 'k1=v1&k2=v2'

# Generated at 2022-06-21 04:47:27.865029
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar:baz') == 'foo+bar%3Abaz'
    assert do_urlencode('foo bar:baz') == 'foo+bar%3Abaz'
    assert do_urlencode({'foo': 'bar', 'baz': 1}) == 'foo=bar&baz=1'
    assert do_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'



# Generated at 2022-06-21 04:47:31.124047
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = unicode_urldecode('I%20l%C3%B8ve%20%F0%9F%92%9B')
    assert s == u'I l\xf8ve \U0001f49b'



# Generated at 2022-06-21 04:47:41.734084
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import pytest
    assert u'abc' == unicode_urlencode(u'abc')
    assert u'%C3%A9' == unicode_urlencode(u'é')
    assert u'a+b' == unicode_urlencode(u'a b')
    assert u'a%20b' == unicode_urlencode(u'a b', for_qs=True)
    assert to_text(u'a+b') == unicode_urlencode('a b')
    assert to_text(u'a%20b') == unicode_urlencode('a b', for_qs=True)

    with pytest.raises(TypeError):
        unicode_urlencode(42)

# Generated at 2022-06-21 04:47:44.099959
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule())
    assert "urldecode" in filters
    assert "urlencode" in filters

# Generated at 2022-06-21 04:47:46.417787
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('blah+blah') == 'blah blah'


# Generated at 2022-06-21 04:48:01.957440
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'This is a test') == u'This+is+a+test'
    assert do_urlencode(u'This is a test&') == u'This+is+a+test%26'
    assert do_urlencode(u'This is a test/') == u'This+is+a+test%2F'
    assert do_urlencode(u'This is a test+') == u'This+is+a+test%2B'
    assert do_urlencode(u'This is a test ') == u'This+is+a+test+'
    assert do_urlencode(u'This is a test\n') == u'This+is+a+test%0A'

    assert do_urlencode(u'foo') == u'foo'
   

# Generated at 2022-06-21 04:48:13.709070
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    def check_filter(filter_name, expected, actual):
        "Helper function to validate a filter"
        if expected != actual:
            raise AssertionError(
                'Filter %s returned %s instead of %s' % (
                    filter_name, repr(actual), repr(expected)))

    core_filters = FilterModule().filters()

    test_urlencode = """
        {% set one = "A and B" %}
        {% set two = { "one": 1, "two" : 2 } %}
        {{ one | urlencode() }}
        {{ two | urlencode() }}
        """
    template = core_filters['template'](test_urlencode)

# Generated at 2022-06-21 04:48:24.873326
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode!=str') == u'unicode%21%3Dstr'
    assert unicode_urlencode(u'unicode!=str', for_qs=True) == u'unicode%21%3Dstr'
    assert unicode_urlencode(['unicode!=str']) == u'%5B%27unicode%21%3Dstr%27%5D'
    assert unicode_urlencode(['unicode!=str'], for_qs=True) == u'%5B%27unicode%21%3Dstr%27%5D'
    assert unicode_urlencode({'k': 'unicode!=str'}) == u'k=unicode%21%3Dstr'

# Generated at 2022-06-21 04:48:31.568354
# Unit test for function do_urldecode
def test_do_urldecode():
    import ansible.module_utils.urls as urls
    import urllib
    # Test valid input
    assert urls.do_urldecode("%41%42+%43") == u"AB+C"
    assert urls.do_urldecode("%41%42+%43") == "AB+C"
    # Test invalid input
    assert urls.do_urldecode("ABC") == "ABC"
    assert urls.do_urldecode("%41%42+%43") != urllib.quote("%41%42+%43")


# Generated at 2022-06-21 04:48:34.116789
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    filters = mod.filters()
    assert 'urldecode' in filters

    if not HAS_URLENCODE:
        assert 'urlencode' in filters



# Generated at 2022-06-21 04:48:42.247071
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%23def') == u'abc#def'
    assert unicode_urldecode('abc%25def') == u'abc%def'
    assert unicode_urldecode('abc%5Bdef') == u'abc[def'


# Generated at 2022-06-21 04:48:45.787150
# Unit test for function do_urldecode
def test_do_urldecode():
    a = u'%ED%95%9C%EA%B8%80'
    assert do_urldecode(a) == u'한글'
    assert do_urldecode(a.encode('utf-8')) == u'한글'



# Generated at 2022-06-21 04:48:48.774237
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test') == u'test'



# Generated at 2022-06-21 04:48:57.692994
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(to_text('This is a test')) == u'This is a test'
    assert do_urldecode(to_text('This+is+a+test')) == u'This is a test'
    assert do_urldecode(to_text('R%C3%A9sum%C3%A9')) == u'R\xe9sum\xe9'



# Generated at 2022-06-21 04:48:58.558978
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:49:04.330482
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fo = FilterModule()
    filters = fo.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:49:07.016328
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%40def') == u'abc@def'
    assert unicode_urldecode('abc%3Fdef') == u'abc?def'


# Generated at 2022-06-21 04:49:15.457942
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2B') == u'+'
    assert do_urldecode('%25') == u'%'
    assert do_urldecode('%25') == u'%'
    assert do_urldecode('%C2%B2') == u'²'


# Generated at 2022-06-21 04:49:24.804080
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode(u'string') == u'string'
    assert do_urlencode('string with spaces') == 'string%20with%20spaces'
    assert do_urlencode(u'string with spaces') == u'string%20with%20spaces'
    assert do_urlencode('string with / slashes') == 'string%20with%20%2F%20slashes'
    assert do_urlencode(u'string with / slashes') == u'string%20with%20%2F%20slashes'
    assert do_urlencode([u'a', '1', u'c', '2']) == u'a=1&c=2'

# Generated at 2022-06-21 04:49:28.613553
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    result = fm.filters()
    assert result['urldecode'](u'a%20b') == u'a b'
    if not HAS_URLENCODE:
        assert result['urlencode'](u'a b') == u'a+b'

# Unit tests for function do_urldecode

# Generated at 2022-06-21 04:49:33.973479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    for key, filter_func in filter_module.filters().items():
        if key == 'urldecode':
            assert filter_func("%7B%22user_id%22%3A%222064739%22%2C%22first_name%22%3A%22Serg%22%2C%22username%22%3A%22Serg%22%2C%22last_name%22%3A%22%22%7D") == '{"user_id":"2064739","first_name":"Serg","username":"Serg","last_name":""}'
        elif key == 'urlencode':
            assert filter_func("A string with spaces") == 'A+string+with+spaces'

# Generated at 2022-06-21 04:49:41.610743
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%25C3%25A9') == '%25C3%25A9'



# Generated at 2022-06-21 04:49:45.941528
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('http%3A%2F%2Ffoo%20bar%2Fbaz') == u'http://foo bar/baz'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode({'bar': 'baz', 'foo': 'qux'}) == u'bar=baz&foo=qux'
    assert do_urlencode([('bar', 'baz'), ('foo', 'qux')]) == u'bar=baz&foo=qux'

# Generated at 2022-06-21 04:49:49.917145
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule, object))

# Generated at 2022-06-21 04:49:57.291899
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tester = FilterModule()
    filters = tester.filters()
    # Test do_urldecode()
    assert filters['urldecode']('a%20b') == 'a b'
    # Test do_urlencode()
    assert filters['urlencode']('a b') == 'a+b'


# Generated at 2022-06-21 04:50:11.885753
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Basic tests showing decode of key + value seperator
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('&') == '&'
    assert unicode_urldecode('a=') == 'a='

    # Basic tests with single values, which have no encoding
    assert unicode_urldecode('a') == 'a'
    assert unicode_urldecode('ab') == 'ab'

    # Show decode of key + value seperator surrounded by encoded values
    assert unicode_urldecode('a=b') == 'a=b'
    assert unicode_urldecode('&a=b&') == '&a=b&'

# Generated at 2022-06-21 04:50:14.650841
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert FilterModule().filters()['urldecode']('test%26') == u'test&'



# Generated at 2022-06-21 04:50:22.184233
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({"test": "one&two", "@test": "one+two"}) == "%40test=one%2Btwo&test=one%26two"
    assert do_urlencode({"test": "one_two"}) == "test=one_two"
    assert do_urlencode("@test=one_two") == "@test%3Done_two"
    assert do_urlencode({"test": "one_two", "test1": "three&four"}) == "test=one_two&test1=three%26four"

