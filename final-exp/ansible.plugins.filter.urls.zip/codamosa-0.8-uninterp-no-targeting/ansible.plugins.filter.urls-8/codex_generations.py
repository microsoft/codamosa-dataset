

# Generated at 2022-06-21 04:40:25.022649
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Testing `unicode_urlencode` '''
    assert 'a' == unicode_urlencode('a')
    assert 'a%7E%C3%B0%C3%A2%C3%B1d' == unicode_urlencode(u'a~ðâñd')
    assert 'a%7E%C3%B0%C3%A2%C3%B1d' == unicode_urlencode(u'a~ðâñd'.encode('utf-8'))

    # Test generation of query strings
    assert 'a=1' == unicode_urlencode({'a': 1}, for_qs=True)
    assert 'a=1&b=2' == unicode_urlencode({'a': 1, 'b': 2}, for_qs=True)

# Generated at 2022-06-21 04:40:34.722165
# Unit test for function do_urldecode
def test_do_urldecode():
    # Decode string
    assert 'foo bar baz' == do_urldecode('foo%20bar%20baz')
    # Decode string with spaces
    assert 'foo bar baz' == do_urldecode('foo bar baz')
    # Decode list
    assert ['foo', 'bar', 'baz'] == do_urldecode(['foo', 'bar', 'baz'])
    # Decode dict
    assert {'foo': 'bar', 'baz': None} == do_urldecode({'foo': 'bar', 'baz': None})

# Generated at 2022-06-21 04:40:40.458754
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode("%41%42%43") == "ABC"
    else:
        assert unicode_urldecode("%41%42%43") == u"ABC"


# Generated at 2022-06-21 04:40:49.102535
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'http://example.com/path/to/file.txt' == unicode_urlencode(u'http://example.com/path/to/file.txt')
    assert u'http://example.com/path/to/%20file.txt' == unicode_urlencode(u'http://example.com/path/to/ file.txt')
    assert u'http://example.com/path/to/%20file.txt' == unicode_urlencode(u'http://example.com/path/to/ file.txt', for_qs=True)
    assert u'foo=bar' == unicode_urlencode({'foo': u'bar'})
    assert u'foo=bar%20baz' == unicode_urlencode({'foo': u'bar baz'})

# Generated at 2022-06-21 04:40:50.935203
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%25') == '%'



# Generated at 2022-06-21 04:40:56.690069
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    urldecode = filters.get('urldecode')
    urlencode = filters.get('urlencode')

    assert urldecode == do_urldecode
    if not HAS_URLENCODE:
        assert urlencode == do_urlencode


# Generated at 2022-06-21 04:41:04.049818
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("abc") == "abc"
    assert do_urldecode("abc%23123") == "abc#123"
    assert do_urldecode("abc%3D3%26moo%3D1") == "abc=3&moo=1"
    assert do_urldecode("%3D3") == "=3"


# Generated at 2022-06-21 04:41:14.274364
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b"%C3%A7") == u'\xe7'
    assert unicode_urldecode(b"%C3%A7%C3%B1") == u'\xe7\xf1'
    assert unicode_urldecode("%C3%A7%C3%B1") == u'\xe7\xf1'
    assert unicode_urldecode(u"%C3%A7%C3%B1") == u'\xe7\xf1'

# Generated at 2022-06-21 04:41:17.847447
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Do nothing for now
    pass


if __name__ == '__main__':
    # Unit test for constructor of class FilterModule
    test_FilterModule()

# Generated at 2022-06-21 04:41:18.620468
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:41:28.229347
# Unit test for function unicode_urldecode

# Generated at 2022-06-21 04:41:38.275048
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Simple unit test of do_urldecode
    '''
    test_data = [
        ('Some text with spaces', 'Some text with spaces'),
        (b'Some text with spaces', 'Some text with spaces'),
        ('Some text with %20spaces', 'Some text with  spaces'),
        (b'Some text with %20spaces', 'Some text with  spaces'),
        ('Some text with %2520spaces', 'Some text with %20spaces'),
        (b'Some text with %2520spaces', 'Some text with %20spaces'),
    ]

    for string, expected in test_data:
        result = do_urldecode(string)
        assert result == expected

# Generated at 2022-06-21 04:41:46.107994
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u'%20'
    assert unicode_urldecode(u'%2520') == u'%20'
    assert unicode_urldecode(u'%25%20') == u'% %20'
    assert unicode_urldecode(u'%25%2520') == u'%%20'
    assert unicode_urldecode(u'%25%25%2520') == '% %'


# Generated at 2022-06-21 04:41:51.670193
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == u''
    assert unicode_urlencode('unicode_string') == u'unicode_string'
    assert unicode_urlencode('unicode_string and spaces') == u'unicode_string%20and%20spaces'
    assert unicode_urlencode(u'unicode_string and spaces') == u'unicode_string%20and%20spaces'
    assert unicode_urlencode(u'unicode_string and spaces', for_qs=True) == u'unicode_string+and+spaces'
    assert unicode_urlencode('unicode_string and spaces', for_qs=True) == u'unicode_string+and+spaces'



# Generated at 2022-06-21 04:41:56.738257
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({}) == ''
    assert do_urlencode({'key1': 'value1'}) == 'key1=value1'
    assert do_urlencode([('key1', 'value1')]) == 'key1=value1'

# Generated at 2022-06-21 04:42:10.144236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert u'abc' == filters['urldecode'](u'abc')
    assert u'abc%20def' == filters['urldecode'](u'abc+def')

    assert 'urlencode' in filters
    assert filters['urlencode'] == do_urlencode
    assert u'abc' == filters['urlencode'](u'abc')
    assert u'abc%20def' == filters['urlencode'](u'abc def')
    assert u'abc+def' == filters['urlencode'](u'abc def', for_qs=True)

# Generated at 2022-06-21 04:42:14.956627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert not HAS_URLENCODE

    filterModule = FilterModule()
    assert filterModule.filters()['urlencode'] == do_urlencode
    assert filterModule.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-21 04:42:20.436735
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('%E2%80%93') == '–'
    else:
        assert unicode_urldecode('%E2%80%93') == u'–'

# Generated at 2022-06-21 04:42:30.391483
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%5C') == '\\'
    assert unicode_urldecode('%5C%2F') == '\\/'
    assert unicode_urldecode('%5C%2F%25%20') == '\\/% '
    assert unicode_urldecode('%3A%3A%3A') == ':::'


# Generated at 2022-06-21 04:42:34.087282
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert 'foobar' == x.filters()['urldecode']('foobar')



# Generated at 2022-06-21 04:42:41.896885
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()

    assert f.filters()['urldecode']('a%20b') == 'a b'
    if not HAS_URLENCODE:
        assert f.filters()['urlencode']('a b') == 'a%20b'
        assert f.filters()['urlencode']({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Unit test function

# Generated at 2022-06-21 04:42:43.700637
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('test+test%21+test%21') == u'test test! test!'


# Generated at 2022-06-21 04:42:45.944246
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo bar'


# Generated at 2022-06-21 04:42:47.251957
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule()) == FilterModule

# Generated at 2022-06-21 04:42:49.499410
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """ Unit test for constrctor of class FilterModule
    """
    actual = FilterModule()

# Generated at 2022-06-21 04:43:00.192793
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test urldecode filter with unicode characters '''

    module = None
    string = u"http://cyberciti.biz/?page_id=2996&lang=\u0939\u093f\u0928\u094d\u0926\u0940"
    assert unicode_urldecode(string) == u"http://cyberciti.biz/?page_id=2996&lang=\u0939\u093f\u0928\u094d\u0926\u0940"


# Generated at 2022-06-21 04:43:11.889292
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%D8%B9%D9%84%D9%85%20%D8%A7%D9%84%D8%B1%D9%8A%D8%A7%D8%B6%D9%8A') == u'علم الرياضي'
    assert unicode_urldecode('%E7%B4%A2%E8%B4%B4%E4%BA%BA') == u'索贴人'
    assert unicode_urldecode('%C2%B5') == u'µ'


# Generated at 2022-06-21 04:43:18.600120
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result_dict = FilterModule.filters(FilterModule)
    assert 'urldecode' in result_dict
    assert result_dict['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in result_dict
        assert result_dict['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:43:27.690301
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Test%3F') == 'Test%3F'
    assert do_urldecode('%7B%22foo%22%3A%2237%22%7D') == '{"foo":"37"}'
    assert do_urldecode('%7B%22foo%22%3A%2237%22%7D%3D%3D%27foo%27') == '{"foo":"37"}==\'foo\''
    assert do_urldecode('%7B%22foo%22%3A%2237%22%7D%3D%3D%27foo%27%26%26%27foo%27%3D%3D%27foo%27') == '{"foo":"37"}==\'foo\'&&\'foo\'==\'foo\''
    assert do_ur

# Generated at 2022-06-21 04:43:42.554445
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%2B%2F') == u'/+/'
    assert unicode_urldecode('%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85') == u'العالم'
    assert unicode_urldecode('%E6%96%87%E8%A8%80') == u'文言'
    assert unicode_urldecode('%40%41') == u'@A'  # @ and A are not encoded by quote()
    assert unicode_urldecode('%C3%A6%C3%B8%C3%A5') == u'æøå'



# Generated at 2022-06-21 04:43:54.783915
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert len(filters) == 2
    assert 'urldecode' in filters
    assert 'urlencode' in filters



# Generated at 2022-06-21 04:44:01.180589
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()

    assert isinstance(module.filters(), dict)
    assert len([k for k in module.filters() if k == "urldecode"]) == 1
    assert len([k for k in module.filters() if k == "urlencode"]) == 1



# Generated at 2022-06-21 04:44:03.297885
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test default constructor
    try:
        assert(FilterModule())
    except:
    # Unit test with param
        assert(FilterModule(1))

#Test module

# Generated at 2022-06-21 04:44:16.553900
# Unit test for function do_urldecode
def test_do_urldecode():
    # This is the string that we want to decode
    encoded_url = "name=Dag%20Wieers&os=Linux%20Mint%2017.2&spam=eggs%20spam&url=http%3A%2F%2Fdag.wieers.com%2Fblog%2Fabout%2Fanaconda%2F"

    # We encode the string with urllib and jinja2 to see if we get the same string back
    # We know that we use the correct urlencode function when the encoded_decoded_url is the same as the encoded_url
    encoded_decoded_url = do_urldecode(encoded_url)
    assert encoded_url == encoded_decoded_url



# Generated at 2022-06-21 04:44:25.862379
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode
    assert do_urldecode('http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar') == 'http://www.example.com/?foo=bar'
    # Test urlencode
    assert do_urlencode('http://www.example.com/?foo=bar') == 'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'
    # Test urlencode dict
    assert do_urlencode({'foo': 'bar baz'}) == 'foo=bar+baz'

# Generated at 2022-06-21 04:44:40.514883
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('hello') == 'hello'
    assert do_urlencode('hello/world') == 'hello%2Fworld'
    assert do_urlencode('hello world') == 'hello+world'

    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'
    assert do_urlencode({'key with': 'spaces'}) == 'key+with=spaces'

# Generated at 2022-06-21 04:44:47.179368
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a') == 'a'
    assert unicode_urlencode(u'a b') == 'a%20b'
    assert unicode_urlencode(u'a b', for_qs=True) == 'a+b'


# Generated at 2022-06-21 04:44:53.800407
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('hello world') == 'hello%20world'
    assert do_urlencode('hello world #1') == 'hello%20world%20%231'
    assert do_urlencode('hello/world#1') == 'hello/world%231'
    assert do_urlencode({'foo': '!@#$%^&*()'}) == 'foo=%21%40%23%24%25%5E%26%2A%28%29'
    assert do_urlencode({'foo': '!@#$%^&*()', 'bar': 'hello world #1'}) == 'foo=%21%40%23%24%25%5E%26%2A%28%29&bar=hello%20world%20%231'

# Generated at 2022-06-21 04:44:57.529039
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print("test of FilterModule.__init__()")
    fm = FilterModule()
    assert fm
    print("FilterModule.__init__() ... PASS")


# Generated at 2022-06-21 04:45:06.317737
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(to_text('foo+bar')) == u'foo bar'
    assert do_urldecode(to_text('foo%7Ebar')) == u'foo~bar'
    assert do_urldecode(to_text('foo%2Bbar')) == u'foo+bar'
    assert do_urldecode(to_text('foo%2Fbar')) == u'foo/bar'

    assert do_urldecode(to_bytes('foo+bar')) == u'foo bar'
    assert do_urldecode(to_bytes('foo%7Ebar')) == u'foo~bar'
    assert do_urldecode(to_bytes('foo%2Bbar')) == u'foo+bar'

# Generated at 2022-06-21 04:45:17.243755
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    res = obj.filters()
    assert do_urldecode == res['urldecode']
    assert do_urlencode == res['urlencode']

# Generated at 2022-06-21 04:45:17.682163
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-21 04:45:22.325968
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    urldecode = module.filters()['urldecode']
    assert urldecode('a+b%2Fc') == 'a b/c'
    if not HAS_URLENCODE:
        urlencode = module.filters()['urlencode']
        assert urlencode('a b/c') == 'a+b%2Fc'

# Generated at 2022-06-21 04:45:23.435549
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print(FilterModule().filters())



# Generated at 2022-06-21 04:45:30.626080
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible import errors
    from ansible.plugins.loader import filter_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = None

    x = filter_loader._create_filters(loader=loader, inventory=inventory)
    if not isinstance(x, dict):
        raise errors.AnsibleFilterError('The filter module must construct a dictionary of filters.')

# Generated at 2022-06-21 04:45:36.611767
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20b%20c') == 'a b c'
    assert do_urldecode('a+b+c') == 'a b c'


# Generated at 2022-06-21 04:45:40.768617
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2520') == u'%20'
    assert unicode_urldecode(u'%252520') == u'%2520'



# Generated at 2022-06-21 04:45:45.185538
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('This%20is%20a%20test%20string.') == u'This is a test string.'
    assert unicode_urldecode('%F0%9F%A4%96') == u'\U0001f496'


# Generated at 2022-06-21 04:45:55.100977
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('hello world') == 'hello%20world'
    assert unicode_urlencode('@#$%^*()') == '%40%23%24%25%5E*()'
    assert unicode_urlencode({1: 'foo'}) == '1=foo'
    assert unicode_urlencode('你好世界') == '%E4%BD%A0%E5%A5%BD%E4%B8%96%E7%95%8C'

# Generated at 2022-06-21 04:45:57.466624
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters


# Generated at 2022-06-21 04:46:16.197702
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'http%3A%2F%2Fwww.foo.bar%2F') == u'http://www.foo.bar/'
    assert unicode_urldecode(u'http%3A%2F%2Fwww.foo.bar%2F') == u'http://www.foo.bar/'


# Generated at 2022-06-21 04:46:17.533847
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:46:21.885601
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(42) == '42'
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode({'x': 1}) == 'x=1'
    assert do_urlencode(['x', 1]) == 'x=1'
    assert do_urlencode({'x': [1, 2, 3]}) == 'x=1&x=2&x=3'
    assert do_urlencode({'x': [1, 2, 3]}, True) == 'x=1&x=2&x=3'
    assert do_urlencode({'x': [1, 2, 3]}, False) == 'x=1&x=2&x=3'

# Generated at 2022-06-21 04:46:28.832949
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Note: We do not use the core function urldecode
    # See: https://github.com/ansible/ansible/issues/20538
    # And: https://github.com/ansible/ansible/pull/25490
    assert unicode_urldecode(u'a%20space') == u'a space'
    assert unicode_urldecode(u'a_under') == u'a_under'
    assert unicode_urldecode(u'a%25percent') == u'a%percent'
    assert unicode_urldecode(u'a+plus') == u'a plus'

# Generated at 2022-06-21 04:46:40.885097
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/path/to/file') == '%2Fpath%2Fto%2Ffile'
    assert do_urlencode('param1=value1&param2=value2') == \
           'param1%3Dvalue1%26param2%3Dvalue2'
    assert do_urlencode({'param1': 'value1', 'param2': 'value2'}) == \
           'param1=value1&param2=value2'
    assert do_urlencode(('key1', 'value1', 'key2', 'value2')) == \
           'key1=value1&key2=value2'

# Generated at 2022-06-21 04:46:55.887077
# Unit test for function do_urlencode
def test_do_urlencode():
    """Unit test for function do_urlencode"""
    assert do_urlencode(u'@') == u'%40'
    assert do_urlencode(u' ') == u'%20'
    assert do_urlencode(u'a') == u'a'
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode(u'"a') == u'%22a'
    assert do_urlencode(u'a b') == u'a%20b'
    assert do_urlencode(u'a/b') == u'a/b'
    assert do_urlencode(u'a,b') == u'a,b'
    assert do_urlencode(u'a?b') == u'a%3Fb'

# Generated at 2022-06-21 04:47:04.508328
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    test = FilterModule()
    filters = test.filters()

    # Test urldecode filter
    assert filters['urldecode'](u'foo%26bar') == u'foo&bar'

    # Test urlencode filter
    # If 'urlencode' already exists, we cannot test
    if 'urlencode' in filters:
        return
    assert filters['urlencode'](u'foo&bar') == u'foo%26bar'

    # Test urlencode with string
    assert filters['urlencode']('/dev/vg_root/lv_root') == '/dev/vg_root/lv_root'

# Generated at 2022-06-21 04:47:05.648680
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urldecode' in FilterModule().filters()

# Generated at 2022-06-21 04:47:20.356425
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == 'test'
    assert do_urlencode('test/') == 'test%2F'
    assert do_urlencode('test&') == 'test%26'
    assert do_urlencode('test=') == 'test%3D'
    assert do_urlencode('?') == '%3F'
    assert do_urlencode('é') == '%C3%A9'
    assert do_urlencode(u'test/') == 'test%2F'
    assert do_urlencode(u'test&') == 'test%26'
    assert do_urlencode(u'test=') == 'test%3D'
    assert do_urlencode(u'?') == '%3F'

# Generated at 2022-06-21 04:47:32.135707
# Unit test for function unicode_urlencode

# Generated at 2022-06-21 04:48:13.423483
# Unit test for function do_urlencode

# Generated at 2022-06-21 04:48:17.120979
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B') == u'{'


# Generated at 2022-06-21 04:48:25.536378
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode('http://example.com/:@') == 'http%3A%2F%2Fexample.com%2F%3A%40'
    assert unicode_urlencode('http://example.com/?foo=bar') == 'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'
    assert unicode_urlencode('foo=bar', for_qs=True) == 'foo%3Dbar'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo#bar') == 'foo%23bar'
    assert unicode

# Generated at 2022-06-21 04:48:26.983898
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'



# Generated at 2022-06-21 04:48:36.684541
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Using a dict is deprecated, use a list of tuples
    assert unicode_urlencode({'a': 'b'}) == u'a=b'
    assert unicode_urlencode([('a', 'b')]) == u'a=b'
    assert unicode_urlencode(u'a=b') == u'a%3Db'
    assert unicode_urlencode('a=b') == u'a%3Db'



# Generated at 2022-06-21 04:48:47.497187
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == b'%2F'
    assert unicode_urlencode('/', for_qs=True) == b'%2F'
    assert unicode_urlencode(u'/') == b'%2F'
    assert unicode_urlencode(u'/', for_qs=True) == b'%2F'
    assert unicode_urlencode('/path') == b'/path'
    assert unicode_urlencode(u'/path') == b'/path'
    assert unicode_urlencode('/path', for_qs=True) == b'/path'
    assert unicode_urlencode(u'/path', for_qs=True) == b'/path'

# Generated at 2022-06-21 04:48:49.125347
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:48:54.855267
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__name__ == 'FilterModule'

# Generated at 2022-06-21 04:48:58.225581
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo/bar') == 'foo/bar'
    assert do_urldecode('foo%2Fbar') == 'foo/bar'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%2Bbar') == 'foo+bar'



# Generated at 2022-06-21 04:49:01.455233
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    result = fm.filters()
    assert type(result) == dict, "Should be a dictionary"

# Generated at 2022-06-21 04:49:36.134303
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Verify all keys are present and correct, but do not verify all
    # values to avoid breaking tests when a value changes
    assert 'urldecode' in FilterModule.filters(None)

    if not HAS_URLENCODE:
        assert 'urlencode' in FilterModule.filters(None)


# Generated at 2022-06-21 04:49:49.440900
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.module_utils.six as six

# Generated at 2022-06-21 04:49:55.578128
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_instance = FilterModule()
    filters = filters_instance.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:49:58.849463
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-21 04:50:11.244935
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None)['urldecode']('') == ''
    assert FilterModule.filters(None)['urldecode']('a') == 'a'
    assert FilterModule.filters(None)['urldecode']('%20') == ' '
    assert FilterModule.filters(None)['urldecode']('a%20') == 'a '
    assert FilterModule.filters(None)['urldecode']('%2F') == '/'
    assert FilterModule.filters(None)['urldecode']('a%2F') == 'a/'
    assert FilterModule.filters(None)['urldecode']('%2Fb') == '/b'
    assert FilterModule.filters(None)['urldecode']('a%2Fb')

# Generated at 2022-06-21 04:50:22.451278
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'simple' == unicode_urldecode('simple')
    assert 'space before' == unicode_urldecode('space%20before')
    assert 'space after' == unicode_urldecode('space%20after')
    assert 'space before and after' == unicode_urldecode('space%20before%20and%20after')
    assert '%20' == unicode_urldecode('%2520')
    assert 'äöü' == unicode_urldecode('%C3%A4%C3%B6%C3%BC')
    assert '€' == unicode_urldecode('%E2%82%AC')
    assert u'\U0001F4A9' == unicode_urldecode('%F0%9F%92%A9')