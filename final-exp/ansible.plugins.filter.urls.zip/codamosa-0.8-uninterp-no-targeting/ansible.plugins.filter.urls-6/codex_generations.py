

# Generated at 2022-06-21 04:40:27.749619
# Unit test for function unicode_urlencode

# Generated at 2022-06-21 04:40:29.946890
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('+') == ' '
    assert unicode_urldecode('http%3A//example.com') == 'http://example.com'

    assert do_urldecode('+') == ' '
    assert do_urldecode('http%3A//example.com') == 'http://example.com'



# Generated at 2022-06-21 04:40:39.511032
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://example.org/') == u'http%3A%2F%2Fexample.org%2F'
    assert do_urlencode('/') == u'%2F'
    assert do_urlencode({'foo':'bar'}) == u'foo=bar'
    assert do_urlencode({'foo':'bar', 'baz':'boo'}) == u'foo=bar&baz=boo'
    assert do_urlencode({'foo':1, 'baz':2}) == u'foo=1&baz=2'
    assert do_urlencode({'foo':None}) == u'foo='

# Generated at 2022-06-21 04:40:45.420799
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foobar') == u'foobar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    if PY3:
        assert do_urlencode({'foo': 'bar'}) == u'foo=bar'
        assert do_urlencode({'foo': u'bår'}) == u'foo=b%C3%A5r'
        assert do_urlencode([('foo', 'bar')]) == u'foo=bar'
        assert do_urlencode([(u'føø', u'bår')]) == u

# Generated at 2022-06-21 04:40:47.320780
# Unit test for constructor of class FilterModule
def test_FilterModule():
    nf = FilterModule()
    print('Filters:', nf.filters())

# Generated at 2022-06-21 04:41:02.826382
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wieers') == u'dag wieers'
    assert unicode_urldecode(u'%7B%7B%20somevar%20%7D%7D') == u'{{ somevar }}'
    assert unicode_urldecode(u'%7B%7B%20somevar%20%7D%7D%20%7B%7B%20anothervar%20%7D%7D') == u'{{ somevar }} {{ anothervar }}'

# Generated at 2022-06-21 04:41:03.721502
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule, object))

# Generated at 2022-06-21 04:41:16.131165
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import pytest

    # Currently supported
    assert unicode_urlencode('a') == u'a'
    assert unicode_urlencode('a b') == u'a%20b'
    assert unicode_urlencode('a/b') == u'a/b'
    assert unicode_urlencode('a%20b') == u'a%20b'
    assert unicode_urlencode('http://example.org?foo=a b') == u'http://example.org?foo=a%20b'

    # Specifically not supported
    with pytest.raises(TypeError) as error:
        unicode_urlencode(u'a b')
    assert to_text(error.value.args[0]) == 'Cannot use u\'a b\' (type str) as a bytes or buffer'


# Generated at 2022-06-21 04:41:21.101231
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Hello+World%21') == u'Hello World!'
    assert do_urldecode('Hello+China%E5%9B%BD%21') == u'Hello China国!'



# Generated at 2022-06-21 04:41:28.158900
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    fail_dict = {
        to_text(b'unicode-string'): u'unicode-string',
        u'unicode-string': to_text(b'unicode-string'),
        u'unicode-string': to_text(b'unicode-string'),
        [u'unicode-string']: to_text(b'unicode-string'),
    }
    for key, value in iteritems(fail_dict):
        try:
            unicode_urlencode(key, for_qs=False)
        except UnicodeDecodeError:
            pass
        else:
            raise AssertionError("Did not fail with UnicodeDecodeError as expected")
        try:
            unicode_urlencode(value, for_qs=False)
        except UnicodeDecodeError:
            pass

# Generated at 2022-06-21 04:41:35.588286
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%27') == u"'"
    assert unicode_urldecode('%2B') == u'+'



# Generated at 2022-06-21 04:41:47.446618
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Check unicode_urlencode supports all data types
    '''
    assert unicode_urlencode('A mötley crüe of characters') == 'A%20m%C3%B6tley%20cr%C3%BCe%20of%20characters'
    assert unicode_urlencode(['A', 'mötley', 'crüe', 'of', 'characters']) == 'A%26m%C3%B6tley%26cr%C3%BCe%26of%26characters'
    assert unicode_urlencode({'A': 'mötley', 'crüe': 'of', 'characters': ''}) == 'A=m%C3%B6tley&cr%C3%BCe=of&characters='
    assert unic

# Generated at 2022-06-21 04:41:54.935885
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    # This function does not work for Python 2, because it does not accept
    # unicode strings.
    if PY3:
        m = AnsibleModule(argument_spec={
            'unicode_string': dict(required=True, type='str'),
            'bytes_string': dict(required=True, type='bytes'),
        })
        assert do_urlencode(m.params['unicode_string']) == 'the%20unicode%20string'
        with pytest.raises(TypeError):
            do_urlencode(m.params['bytes_string'])

# Generated at 2022-06-21 04:42:01.469148
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import imp
    import pytest
    if sys.version_info >= (3, 0):
        pytest.skip("Does not work on Python 3")
    f, filename, desc = imp.find_module('ansible.plugins.filter.core')
    imp.load_module('ansible.plugins.filter.core', f, filename, desc)
    import ansible.plugins.filter.core
    fm = ansible.plugins.filter.core.FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] is do_urldecode
    assert filters['urlencode'] is do_urlencode


# Generated at 2022-06-21 04:42:10.916097
# Unit test for function do_urlencode
def test_do_urlencode():
    def u(string):
        return to_text(string)

    def b(string):
        return to_bytes(string)

    assert u('abcdef') == b('abcdef')
    assert do_urlencode(u('abcdef')) == b('abcdef')
    assert do_urlencode(b('abcdef')) == b('abcdef')

    assert u('a=b') == b('a=b')
    assert do_urlencode(u('a=b')) == b('a%3Db')
    assert do_urlencode(b('a=b')) == b('a%3Db')

    assert u('abc def') == b('abc def')
    assert do_urlencode(u('abc def')) == b('abc%20def')

# Generated at 2022-06-21 04:42:11.768561
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-21 04:42:17.300760
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('@', safe='/') == '%40'
    assert do_urlencode('@') == '@'
    assert do_urlencode(['key', 'value']) == 'key=value'
    assert do_urlencode({'key': 'value'}) == 'key=value'

# Generated at 2022-06-21 04:42:24.855102
# Unit test for function do_urlencode
def test_do_urlencode():
    '''Test do_urlencode'''
    assert do_urlencode('string') == u'string'

    assert do_urlencode({'one': 1, 'two': 2}) == u'one=1&two=2'
    assert do_urlencode([('one', 1), ('two', 2)]) == u'one=1&two=2'
    assert do_urlencode(('one', 1, 'two', 2)) == u'one=1&two=2'

    assert do_urlencode('string with spaces') == u'string%20with%20spaces'
    assert do_urlencode('/path/with/slashes') == u'/path/with/slashes'

# Generated at 2022-06-21 04:42:26.571259
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, object)


# Generated at 2022-06-21 04:42:40.938577
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.vault import VaultSecret

    module = basic.AnsibleModule(
        argument_spec = dict(),
    )

    # Test with Jinja2 >= 2.7 (has urlencode filter)
    filters = FilterModule().filters()
    assert filters['urldecode']('foo') == u'foo'
    assert filters['urldecode']('foo%20bar') == u'foo bar'

# Generated at 2022-06-21 04:42:57.679669
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%3C") == '<'
    assert do_urldecode("%3D") == '='
    assert do_urldecode("%3E") == '>'
    assert do_urldecode("%3F") == '?'
    assert do_urldecode("%40") == '@'
    assert do_urldecode("%5B") == '['
    assert do_urldecode("%5C") == '\\'
    assert do_urldecode("%5D") == ']'
    assert do_urldecode("%5E") == '^'
    assert do_urldecode("%5F") == '_'
    assert do_urldecode("%60") == '`'
    assert do_urldec

# Generated at 2022-06-21 04:43:03.669287
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode(u'a') == u'a'
    assert unicode_urldecode(u'A') == u'A'
    assert unicode_urldecode(u'a/') == u'a/'
    assert unicode_urldecode(u'a/b') == u'a/b'
    assert unicode_urldecode(u'a%20b') == u'a b'
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a&b') == u'a&b'
    assert unicode_urldecode(u'a&b') == u'a&b'
    assert unicode_urldecode(u'a=b') == u

# Generated at 2022-06-21 04:43:17.479701
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc %#') == u'abc+%25%23'
    assert unicode_urlencode(u'abc %#', for_qs=True) == u'abc+%25%23'
    assert unicode_urlencode('') == u''
    assert unicode_urlencode('abc') == u'abc'
    assert unicode_urlencode('abc %#') == u'abc+%25%23'
    assert unicode_urlencode('abc %#', for_qs=True) == u'abc+%25%23'
    assert unicode_urlencode(u'abc ') == u'abc+'

# Generated at 2022-06-21 04:43:18.916614
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:43:23.380430
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2Fapi%2Fv3') == '/api/v3'


# Generated at 2022-06-21 04:43:32.711047
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('hello') == 'hello'
    assert unicode_urldecode('hello') == 'hello'
    assert unicode_urlencode('hello/world') == 'hello%2Fworld'
    assert unicode_urldecode('hello%2Fworld') == 'hello/world'
    assert unicode_urldecode('hello/world') == 'hello/world'
    assert unicode_urlencode('héllö') == 'h%C3%A9ll%C3%B6'
    assert unicode_urldecode('h%C3%A9ll%C3%B6') == 'héllö'
    assert unicode_urlencode('hello&world') == 'hello%26world'

# Generated at 2022-06-21 04:43:36.983941
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = '%C3%A0'
    ans = u'à'

    res = unicode_urldecode(s)

    assert res == ans


# Generated at 2022-06-21 04:43:45.087939
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar baz') == u'foo%20bar%20baz'
    assert unicode_urlencode(u'/') == u'%2F'
    assert unicode_urlencode(u'/', for_qs=True) == u'%2F'
    assert unicode_urlencode(u'hello world', for_qs=True) == u'hello+world'

# Generated at 2022-06-21 04:43:47.667589
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo+bar') == 'foo bar'


# Generated at 2022-06-21 04:43:52.057227
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:44:01.744254
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Unit tests for do_urldecode

# Generated at 2022-06-21 04:44:04.360311
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)

# Generated at 2022-06-21 04:44:07.442052
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Ffoo') == 'http://foo'


# Generated at 2022-06-21 04:44:08.316491
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:44:22.483792
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Hi!') == 'Hi%21'
    assert do_urlencode('Hi? Blah!') == 'Hi%3F%20Blah%21'
    assert do_urlencode('/') == '%2F'

    assert do_urlencode({'Hi': 'Blah!'}) == 'Hi=Blah%21'
    assert do_urlencode({'Hi!': 'Blah!'}) == 'Hi%21=Blah%21'
    assert do_urlencode({'Hi': 'Blah!', 'Yo': 'Blah?'}) == 'Hi=Blah%21&Yo=Blah%3F'

    assert do_urlencode(('Hi', 'Blah!')) == 'Hi=Blah%21'

# Generated at 2022-06-21 04:44:29.033576
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    cls = FilterModule()
    filters = cls.filters()
    assert 'urlencode' in filters
    assert filters['urlencode'] == do_urlencode
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode


# Generated at 2022-06-21 04:44:29.897804
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:44:33.457882
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert({'urldecode': do_urldecode}.items() == FilterModule.filters(FilterModule()).items())

# Generated at 2022-06-21 04:44:42.876396
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_cases = [
        (u'a space', u'a%20space'),
        (u'a+sign', u'a%2Bsign'),
        (u'a sign', u'a%20sign'),
        (u'a/slash', u'a%2Fslash'),
        (u'a+sign/slash', u'a%2Bsign%2Fslash'),
    ]
    for (input, expected) in test_cases:
        actual = unicode_urlencode(input)
        assert expected == actual, 'Input %s Expected %s Actual %s' % (input, expected, actual)

    safe = b'/'
    for (input, expected) in test_cases:
        actual = unicode_urlencode(input, safe=safe)

# Generated at 2022-06-21 04:44:55.457164
# Unit test for function do_urldecode
def test_do_urldecode():
    expected_output = {
        u'foo+bar': u'foo bar',
        u'foo%2Bbar': u'foo+bar',
        u'foo%2Fbar': u'foo/bar',
        u'foo': u'foo',
        u'foo%': u'foo%',
        u'foo%2': u'foo%2',
        u'foo%1': u'foo%1',
    }

    for output, expected in expected_output.items():
        assert do_urldecode(output) == expected



# Generated at 2022-06-21 04:45:10.788818
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("Ansible+is+awesome") == "Ansible is awesome"
    assert do_urldecode("Search+%3D+Ansible+%26+%28open%7Cclosed%29") == "Search = Ansible & (open|closed)"
    assert do_urldecode("Ansible+is+%3Cb%3Eawesome%3C%2Fb%3E") == "Ansible is <b>awesome</b>"



# Generated at 2022-06-21 04:45:16.980106
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert "ab/c" == unicode_urldecode("ab%2Fc")
    assert "ab/c" == unicode_urldecode("ab/c")


# Generated at 2022-06-21 04:45:19.386923
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert fm
    assert('urldecode' in fm.filters())



# Generated at 2022-06-21 04:45:33.413340
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a+string') == u'a string'
    assert unicode_urldecode(u'a%20string') == u'a string'
    assert unicode_urldecode(u'a%2525string') == u'a%25string'
    assert unicode_urldecode(u'a%2525%20%2525string') == u'a%25%25 string'
    assert unicode_urldecode(u'a+string') == u'a string'
    assert unicode_urldecode(u'a+string') == u'a string'
    assert unicode_urldecode(u'a+string') == u'a string'
    assert unicode_urldecode(u'a+string') == u'a string'

# Generated at 2022-06-21 04:45:39.136924
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test with a one common string (just a word)
    value = u'David'
    result = unicode_urlencode(value)
    assert result == u'David'
    assert type(result) is unicode

    # Test with a one common string (a sentence)
    value = u"Let's have a look at the situation"
    result = unicode_urlencode(value)
    assert result == u"Let's+have+a+look+at+the+situation"
    assert type(result) is unicode

    # Test with a list of common strings (words)
    value = [u'one', u'two', u'three']
    result = unicode_urlencode(value)
    assert result == u'one&two&three'
    assert type(result) is unicode

    # Test with

# Generated at 2022-06-21 04:45:48.343787
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b%20%26c%20d%20%24e%20f%20+g') == 'a b &c d $e f  g'
    assert unicode_urldecode('a b') == 'a b'
    assert unicode_urldecode(u'a b') == u'a b'
    assert unicode_urldecode(u'a b'.encode('utf-8')) == u'a b'


# Generated at 2022-06-21 04:45:52.194215
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-21 04:45:55.408135
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('hello%2Fworld') == 'hello/world'
    assert do_urldecode('hello%2Fworld') == 'hello/world'


# Generated at 2022-06-21 04:46:00.281448
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/some&') == '%2Fsome%26'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'baz=qux&foo=bar'

# Generated at 2022-06-21 04:46:03.325828
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module_cls = FilterModule()
    assert module_cls is not None
    assert module_cls.filters is not None


# Generated at 2022-06-21 04:46:13.574307
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urlencode' in fm.filters()
    assert 'urldecode' in fm.filters()
    assert 'to_json' in fm.filters()


# Generated at 2022-06-21 04:46:19.697298
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urldecode('http%3A%2F%2Ffoo.org%2F') == 'http://foo.org/'
    assert do_urlencode('http://foo.org/') == 'http%3A%2F%2Ffoo.org%2F'
    assert do_urlencode('http://foo.org/') == do_urlencode(unicode('http://foo.org/'))
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode('foo') == 'foo'

# Generated at 2022-06-21 04:46:28.891476
# Unit test for function do_urldecode
def test_do_urldecode():
    for x in [
        'this+is%20a%20test',
        'this+is+a+test',
        'this+is+a+test%3F+%26+this+is+a+test%21',
        'this+is+a+test%26this+is+a+test%21',
    ]:
        assert do_urldecode(x) == \
            'this is a test'
        assert do_urldecode(u'%s' % x) == \
            'this is a test'


# Generated at 2022-06-21 04:46:31.156865
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:46:38.971149
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('http%3A%2F%2Fexample.com%2Fapi%2Fv1%2F') == 'http://example.com/api/v1/'
    assert FilterModule().filters()['urlencode']('http://example.com/api/v1/') == 'http://example.com/api/v1/'



# Generated at 2022-06-21 04:46:45.924980
# Unit test for function do_urldecode
def test_do_urldecode():

    # Regular %2F decode
    assert do_urldecode(u'%2F') == u'/'

    # Regular %2F decode (bytes)
    assert do_urldecode(b'%2F') == u'/'

    # Unicode decode
    assert do_urldecode(u'%C2%B5') == u'μ'

    # Unicode decode (bytes)
    assert do_urldecode(b'%C2%B5') == u'μ'

    # Bytes decode
    assert do_urldecode(b'%F0%9D%84%9E') == u'𝄞'

    # Unicode decode with character
    assert do_urldecode(u'%C2%B5n') == u'μn'

    # Unicode decode with character (bytes)

# Generated at 2022-06-21 04:46:59.191156
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode({u'abc': u'def', u'ghi': u'jkl'}) == u'abc=def&ghi=jkl'
    assert unicode_urlencode((u'abc', u'def')) == u'abc=def'
    assert unicode_urlencode([u'abc', u'def']) == u'abc=def'
    assert unicode_urlencode(u'abc def') == unicode_urlencode(u'abc def', for_qs=True)

# Generated at 2022-06-21 04:47:04.286500
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('foobar') == u'foobar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode('foo+bar') == u'foo+bar'


# Generated at 2022-06-21 04:47:08.155317
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode({}) == ''
    assert unicode_urlencode('some string') == 'some%20string'
    assert unicode_urlencode('some string', for_qs=True) == 'some+string'
    assert unicode_urlencode({'x': 'abc', 'y': 'xyz'}) == 'x=abc&y=xyz'



# Generated at 2022-06-21 04:47:19.037127
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat.tests import unittest
    import sys


# Generated at 2022-06-21 04:47:34.535001
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus, unquote_plus
    if PY3:
        assert quote_plus(u'foo+bar') == b'foo%2Bbar'
        assert unquote_plus(b'foo%2Bbar') == u'foo+bar'
    else:
        assert quote_plus(u'foo+bar') == b'foo%2Bbar'
        assert unquote_plus(b'foo%2Bbar') == u'foo+bar'
    f = FilterModule().filters()
    assert f['urldecode'](u'foo+bar') == u'foo bar'


# Generated at 2022-06-21 04:47:46.705466
# Unit test for function unicode_urlencode

# Generated at 2022-06-21 04:47:52.923747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'hello%20world' == do_urlencode('hello world')
    assert 'hello+world' == do_urlencode('hello world', True)
    assert dict(hello='world') == do_urlencode(dict(hello='world'))
    assert 'hello=world&foo=bar' == do_urlencode([('hello', 'world'), ('foo', 'bar')])

    assert 'hello world' == do_urldecode('hello%20world')
    assert 'hello world' == do_urldecode('hello+world')
    assert 'hello world' == do_urldecode(dict(hello='world'))
    assert 'hello world' == do_urldecode([('hello', 'world')])
    assert 'hello world' == do_urldecode(u'hello%20world')


# Generated at 2022-06-21 04:48:00.554491
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(hasattr(FilterModule, "filters"))
    fm = FilterModule()
    assert(hasattr(fm, "filters"))
    assert(callable(fm.filters))
    assert(fm.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode})

test_FilterModule()

# Generated at 2022-06-21 04:48:07.563331
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc def') == 'abc+def'
    assert unicode_urlencode('abc def', True) == 'abc+def'
    assert unicode_urlencode('100%') == '100%25'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', True) == '%2F'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'



# Generated at 2022-06-21 04:48:13.283992
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = (
        (u'foo%3Abar', u'foo:bar'),
        (u'foo%2Bbar', u'foo+bar'),
        (u'foo%21bar', u'foo!bar'),
        (u'foo%23bar', u'foo#bar'),
    )
    for tc in test_cases:
        yield (check_unicode_urldecode, ) + tc


# Generated at 2022-06-21 04:48:24.769502
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'/?:@-._~!$&\'()*+,;=') == u'/?:@-._~!$&\'()*+,;='
    assert do_urlencode(u'foo@bar') == u'foo%40bar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo/bar') == u'foo/bar'

# Generated at 2022-06-21 04:48:30.345256
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http://example.com/') == u'http://example.com/'
    assert unicode_urldecode(u'http://example.com/?x=\u20ac') == u'http://example.com/?x=\u20ac'
    assert unicode_urldecode(u'http://example.com/?x=\u20ac'.encode('utf-8')) == u'http://example.com/?x=\u20ac'


# Generated at 2022-06-21 04:48:35.761936
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urldecode': do_urldecode}
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-21 04:48:39.483412
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%26bar%3D') == 'foo&bar='



# Generated at 2022-06-21 04:48:57.558020
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2F+%2B%3F') == u'/ +?'
    # exactly 2 hex digits after %
    assert do_urldecode('%2') == u'%2'
    assert do_urldecode('%fg') == u'%fg'
    assert do_urldecode(u'%2F') == u'/'
    assert do_urldecode(None) == None
    # the following is invalid but the stdlib unquote_plus() should cope
    if PY3:
        assert do_urldecode('\u2603') == u'☃'
    assert do_urldecode('\u2603') == u'\u2603'


# Generated at 2022-06-21 04:49:08.650846
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'kéy') == u'k%C3%A9y'
    assert do_urlencode(u'kéy=') == u'k%C3%A9y%3D'
    assert do_urlencode([u'kéy', u'välue']) == u'k%C3%A9y=v%C3%A4lue'
    assert do_urlencode({u'kéy': u'välue'}) == u'k%C3%A9y=v%C3%A4lue'
    assert do_urlencode(True) == u'True'
    assert do_urlencode(123) == u'123'
    assert do_urlencode(u'kéy=välue')

# Generated at 2022-06-21 04:49:15.598910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u'%20'
    if PY3:
        assert unicode_urldecode(b'%20') == u'%20'
    else:
        assert unicode_urldecode(b'%20') == '%20'


# Generated at 2022-06-21 04:49:23.600492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from unittest import TestCase, main as unittest_main

    class FilterModule_test(TestCase):

        def test_FilterModule_filters(self):
            # We need the tmpdir fixture here. However the module
            # is not using them (yet).
            # We define the setUp and tearDown methods here that
            # reuse the methods from the tmpdir fixture to create
            # and remove a temporary directory.
            from tempfile import mkdtemp
            from shutil import rmtree
            import os

            def setUp(self):
                if not hasattr(self, 'tmpdir'):
                    self.tmpdir = mkdtemp()

            def tearDown(self):
                if hasattr(self, 'tmpdir'):
                    rmtree(self.tmpdir)

            FilterModule = FilterModule()

# Generated at 2022-06-21 04:49:25.272869
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-21 04:49:35.556613
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(u'abc%2B123') == u'abc+123'
    assert do_urldecode(b'abc%2B123') == u'abc+123'
    assert do_urldecode(123) == u'123'
    assert do_urldecode(u'123') == u'123'
    assert do_urldecode(b'123') == u'123'
    assert do_urldecode({'a': 1, 'b': 2}) == u'a=1&b=2'
    assert do_urldecode([1, 2]) == u'1&2'
    assert do_urldecode(u'abc+123') == u'abc 123'

# Generated at 2022-06-21 04:49:36.588644
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-21 04:49:42.850943
# Unit test for function do_urldecode
def test_do_urldecode():
    import sys
    string = 'key%20one%26key%20two'
    result = do_urldecode(string)
    if sys.version_info[0] >= 3:
        assert result == 'key one&key two'


# Generated at 2022-06-21 04:49:57.146719
# Unit test for constructor of class FilterModule
def test_FilterModule():  # pylint: disable=too-many-branches
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.facts.system.distribution import Distribution as distro
    from ansible.module_utils.facts.filesystem import FileSystem as filesystem
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system import System as system
    import json
    import platform

    filters = FilterModule()
    filters = filters.filters()
    assert 'urldecode' in filters
    assert 'urlencode' not in filters
    assert 'urlencode' in filters
    assert 'urldecode'

# Generated at 2022-06-21 04:50:02.983538
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    from ansible.module_utils.common.collections import is_mapping

    def legacy_urldecode(in_value):
        try:
            return to_text(unquote_plus(to_bytes(in_value)))
        except Exception as e:
            raise ValueError("Failed to url decode input: %s" %in_value)

    class LegacyFilterModule():
        ''' Ansible core jinja2 filters '''

        def filters(self):
            filters = {
                'urldecode': legacy_urldecode,
            }

            return filters


# Generated at 2022-06-21 04:50:21.990742
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # PY2
    assert unicode_urlencode('foo bar') == 'foo%20bar', 'Encoding string in Python 2 failed'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar', 'Encoding string in Python 2 failed'
    assert unicode_urlencode(to_text('foo bar')) == 'foo%20bar', 'Encoding string in Python 2 failed'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar', 'Encoding string in Python 2 failed'
    assert unicode_urlencode('foo+bar', for_qs=True) == 'foo%2Bbar', 'Encoding string in Python 2 failed'