

# Generated at 2022-06-21 04:40:25.289337
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u2713') == '%E2%9C%93'
    assert unicode_urlencode(u'\u2713', True) == '%E2%9C%93'
    assert unicode_urlencode(u'\u2713 foo bar') == '%E2%9C%93+foo+bar'
    assert unicode_urlencode(u'\u2713 foo bar', True) == '%E2%9C%93%20foo%20bar'


# Generated at 2022-06-21 04:40:30.623694
# Unit test for constructor of class FilterModule
def test_FilterModule():

    module = FilterModule()
    assert isinstance(module, FilterModule)

    assert module.filters()


# Unit tes for function unicode_urldecode

# Generated at 2022-06-21 04:40:33.953498
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'abcd efgh') == u'abcd%20efgh')
    assert(unicode_urlencode(u'abcd efgh', for_qs=True) == u'abcd+efgh')

# Generated at 2022-06-21 04:40:35.289269
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:40:39.614230
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode(u'%20') == ' '
    assert do_urldecode(u'%C3%A4') == u'ä'


# Generated at 2022-06-21 04:40:43.257260
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    filters = m.filters()
    assert filters.get('urldecode') == do_urldecode

    if not HAS_URLENCODE:
        assert filters.get('urlencode') == do_urlencode
    else:
        assert filters.get('urlencode') != do_urlencode

# Generated at 2022-06-21 04:40:55.343672
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'%26%23%2B%C3%A4') == u'&#+ä'
    if PY3:
        assert isinstance(unicode_urldecode(u'%20'), str)
        assert isinstance(unicode_urldecode(u'abc'), str)
        assert isinstance(unicode_urldecode(u'%26%23%2B%C3%A4'), str)
    else:
        assert isinstance(unicode_urldecode(u'%20'), unicode)

# Generated at 2022-06-21 04:41:06.841220
# Unit test for function do_urlencode
def test_do_urlencode():
    import random

    for for_qs in range(2):
        # Test of some corner cases
        assert do_urlencode('') == ''
        assert do_urlencode(' ') == '%20' if for_qs else '%2F'
        assert do_urlencode('/') == '%2F'
        assert do_urlencode('\u2603') == '%E2%98%83'
        assert do_urlencode(8) == '8'
        assert do_urlencode([8]) == '8'

        # Test random combinations of letters, digits and interesting symbols

# Generated at 2022-06-21 04:41:17.262167
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('hello%20world%2C%20how%20are%20you%3F') == 'hello world, how are you?'
    assert unicode_urldecode('hello%20world%2C%20how%20are%20you%3F%20%A9%202018%20me') == 'hello world, how are you? © 2018 me'
    assert unicode_urldecode('hello%20world%2C%20how%20are%20you%3F%20%A9%202018%20me%20%F0%9F%98%8D%20') == 'hello world, how are you? © 2018 me 😍 '


# Generated at 2022-06-21 04:41:25.902646
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('key=value') == u'key=value'
    assert do_urldecode('key%60=%7Evalue') == u"key`=~value"
    assert do_urldecode('key=%61%62%2B%2F%3Dvalue') == u'key=ab+/=value'
    assert do_urldecode('key%3Dvalue') == u"key=value"
    assert do_urldecode('%6B%65%79%3D%76%61%6C%75%65') == u'key=value'


# Generated at 2022-06-21 04:41:31.339281
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print("\nTest case : test_FilterModule")
    assert FilterModule() is not None

# Unit test case to test the filters() method of class FilterModule

# Generated at 2022-06-21 04:41:37.678225
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # pylint: disable=too-many-locals
    filter_module = FilterModule()

    assert hasattr(filter_module, 'filters')
    assert callable(filter_module.filters)

    filter_collection = filter_module.filters()
    assert isinstance(filter_collection, dict)

    assert 'urldecode' in filter_collection
    assert callable(filter_collection['urldecode'])

    if not HAS_URLENCODE:
        assert 'urlencode' in filter_collection
        assert callable(filter_collection['urlencode'])



# Generated at 2022-06-21 04:41:46.732011
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a&b') == 'a%26b'
    assert unicode_urlencode('a+b') == 'a%2Bb'
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('a/b') == 'a%2Fb'
    assert unicode_urlencode('a b', for_qs=True) == 'a%20b'
    assert unicode_urlencode('a/b', for_qs=True) == 'a%2Fb'



# Generated at 2022-06-21 04:42:01.054730
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%7D') == u'{}'
    assert unicode_urldecode('%7B%7D%7B%7D') == u'{}{}'

    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'

    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_ur

# Generated at 2022-06-21 04:42:01.920692
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:42:08.316570
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode
    else:
        assert filters['urlencode'] == do_urlencode()


# Unit tests for do_urldecode function

# Generated at 2022-06-21 04:42:12.249155
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    test_filter_module.filters()
    assert True

test_FilterModule()


# Generated at 2022-06-21 04:42:13.458150
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-21 04:42:16.726413
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert('Ansible core jinja2 filters' == FilterModule().filters().__doc__)


# Test for function do_urldecode

# Generated at 2022-06-21 04:42:29.373771
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six import PY2
    from . import utils

    fm = FilterModule()
    for name, method in iteritems(fm.filters()):
        globals()['test_FilterModule_' + name] = utils.generate_filtermodule_tests(method, globals()[name.upper() + '_TESTS'])


# Generated at 2022-06-21 04:42:39.286125
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc') == 'abc'
    assert do_urlencode(u'abc def') == 'abc%20def'
    assert do_urlencode(u'1+2=3') == '1%2B2%3D3'
    assert do_urlencode(u'/?&') == '%2F%3F%26'
    assert do_urlencode(u'a=b') == 'a=b'
    assert do_urlencode(u'a=b&c=d') == 'a=b&c=d'
    assert do_urlencode(u'a=b&c=') == 'a=b&c='
    assert do_urlencode(u'a=b&c') == 'a=b&c'
    assert do_urlen

# Generated at 2022-06-21 04:42:50.814639
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('/a/b/c') == '%2Fa%2Fb%2Fc')
    assert(do_urlencode('a=b&c=d') == 'a%3Db%26c%3Dd')
    assert(do_urlencode('abc') == 'abc')
    assert(do_urlencode(['a', 'b', 'c']) == 'a&b&c')
    assert(do_urlencode(['a', 'b', 'c'], True) == 'a&b&c')
    assert(do_urlencode(('a', 'b', 'c')) == 'a&b&c')
    assert(do_urlencode(('a', 'b', 'c'), True) == 'a&b&c')

# Generated at 2022-06-21 04:42:55.480706
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/bar') == 'http%3A%2F%2Ffoo%2Fbar'



# Generated at 2022-06-21 04:43:01.603843
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert (unicode_urldecode('%cf%80') == u'\u03c0')
    assert (unicode_urldecode('%cf%80'.encode('utf-8')) == u'\u03c0')



# Generated at 2022-06-21 04:43:07.555703
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:43:13.857929
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(
        u"http%3A%2F%2Fdocs.ansible.com%2Fansible%2Flatest%2Fmodules%2Fpostgresql_db_module.html") == \
        u"http://docs.ansible.com/ansible/latest/modules/postgresql_db_module.html"


# Generated at 2022-06-21 04:43:20.784935
# Unit test for function do_urldecode
def test_do_urldecode():
    """
    This test is the same as the test run by the Jinja2 test suite,
    however it is currently not executed at run-time. If you want to
    execute this, remove the "if 0" in front of the function
    definition (below)
    """
    if 0:
        def do_urldecode(x):
            return x
        assert do_urldecode('foo') == 'foo'

# Generated at 2022-06-21 04:43:31.846747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2Furl%2Fpath%2F') == '/url/path/'
    assert do_urlencode('~') == '%7E'
    assert do_urlencode('~*') == '%7E*'
    assert do_urlencode('a&b') == 'a%26b'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode(('a', 'b')) == 'a=b'
    assert do_urlencode(('a', 'b', 'c')) == 'a=b&a=c'

# Generated at 2022-06-21 04:43:32.598623
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-21 04:43:44.324052
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # given
    string = 'Hello World ! @ # $ % ^ & * ( ) _ + ~ ` | \\ , . ?'
    expected_encoded_string = 'Hello%20World%20!%20%40%20%23%20%24%20%25%20%5E%20%26%20%2A%20%28%20%29%20_%20%2B%20~%20%60%20%7C%20%5C%20%2C%20.%20%3F'
    # when
    actual_encoded_string = unicode_urlencode(string)
    # then
    assert actual_encoded_string == expected_encoded_string
    # given

# Generated at 2022-06-21 04:43:56.337281
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    source = u'http%3A%2F%2Fexample.org%2F%3Fid%3D123%26type%3Dservice'
    result = u'http://example.org/?id=123&type=service'
    assert result == do_urldecode(source)
    assert result == do_urldecode(to_bytes(source))
    assert do_urldecode(AnsibleUnsafeText(to_bytes(source))) == result

# Generated at 2022-06-21 04:44:05.392030
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Returns the unicode url-decoded version of a given string '''
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode(u'%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%25C3%25A9') == '%C3%A9'
    assert unicode_urldecode(u'%25C3%25A9') == '%C3%A9'


# Generated at 2022-06-21 04:44:13.703957
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('https%3A%2F%2Fgithub.com%2Fwillthames%2Fansibullbot') \
        == u'https://github.com/willthames/ansibullbot'
    assert do_urldecode('https://github.com/willthames/ansibullbot') \
        == u'https://github.com/willthames/ansibullbot'
    assert do_urldecode('') == u''


# Generated at 2022-06-21 04:44:19.379921
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    text_string = 'this is a text string'
    text_unicode = u'this is a unicode string'
    text_unicode_with_accent = u'this is a unicode string with \xe1ccent'

    assert unicode_urldecode(unicode_urlencode(text_string)) == text_string
    assert unicode_urldecode(unicode_urlencode(text_unicode)) == text_unicode
    assert unicode_urldecode(unicode_urlencode(text_unicode_with_accent)) == text_unicode_with_accent

# Generated at 2022-06-21 04:44:29.444873
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('abcd efgh') == 'abcd+efgh')
    assert(do_urlencode('abcd@efgh') == 'abcd%40efgh')
    assert(do_urlencode(u'abcd\u1234efgh') == 'abcd%E1%88%B4efgh')
    assert(do_urlencode(u'abcd\U00012345efgh') == 'abcd%F0%92%8D%85efgh')
    assert(do_urlencode(['abcd', 'efgh']) == 'abcd&efgh')
    assert(do_urlencode(('abcd', 'efgh')) == 'abcd&efgh')

# Generated at 2022-06-21 04:44:40.270549
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Test function FilterModule.filters

    This function is left here for testing purpose. It
    is called in test_jinja2.py
    """
    module = FilterModule()
    filters = module.filters()

    # test urldecode filter
    assert 'a+b' == filters['urldecode']('a%2Bb')

    # test urlencode filter
    if not HAS_URLENCODE:
        assert 'a%2Bb' == filters['urlencode']('a+b')



# Generated at 2022-06-21 04:44:43.352969
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:44:53.862114
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%3F') == u'!#$&\'()*+,;=?'
    assert unicode_urldecode(u'%20%2F%40%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%3F') == u' /@!#$&\'()*+,;=?'


# Generated at 2022-06-21 04:45:03.660354
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc+def') == u'abc%2Bdef'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc+def', for_qs=True) == u'abc%2Bdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'

# Generated at 2022-06-21 04:45:14.832863
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://foo.bar.example/baz qux') == 'http%3A//foo.bar.example/baz%20qux'
    assert do_urlencode('http://foo.bar.example/baz qux/') == 'http%3A//foo.bar.example/baz%20qux%2F'
    assert do_urlencode('http://foo.bar.example/baz qux?a=b') == 'http%3A//foo.bar.example/baz%20qux%3Fa%3Db'

# Generated at 2022-06-21 04:45:25.428053
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar', True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar/baz?one=1&two=2') == u'foo%2Bbar%2Fbaz%3Fone%3D1%26two%3D2'

# Generated at 2022-06-21 04:45:35.964995
# Unit test for function do_urlencode
def test_do_urlencode():
    # basic string
    assert do_urlencode(u'http://example.com/a/b/c') == u'http%3A%2F%2Fexample.com%2Fa%2Fb%2Fc'
    assert do_urlencode(u'/a/b/c http://example.com/') == u'%2Fa%2Fb%2Fc%20http%3A%2F%2Fexample.com%2F'
    assert do_urlencode('http://example.com/a/b/c') == u'http%3A%2F%2Fexample.com%2Fa%2Fb%2Fc'

# Generated at 2022-06-21 04:45:39.466884
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20') == u'foo '
    assert unicode_urldecode('foo%20') == u'foo '



# Generated at 2022-06-21 04:45:48.655176
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'dag') == u'dag'
    assert unicode_urlencode(u'dag wieers') == u'dag+wieers'
    assert unicode_urlencode(u'dag wieers', for_qs=True) == u'dag%20wieers'
    assert unicode_urlencode(u'één €') == u'%C3%A9n%20%E2%82%AC'
    assert unicode_urlencode(u'één €', for_qs=True) == u'%C3%A9n%20%E2%82%AC'
    assert unicode_urlencode(u'p%c3%a9ter') == u'p%C3%A9ter'

# Generated at 2022-06-21 04:46:00.063628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'abc') == u'abc'
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(b'a%20b%20c') == u'a b c'
    assert unicode_urldecode(u'a%20b%20c') == u'a b c'
    assert unicode_urldecode(b'a+b+c') == u'a b c'
    assert unicode_urldecode(u'a+b+c') == u'a b c'
    assert unicode_urldecode(b'a%C3%BCb%C3%A9c') == u'aübéc'

# Generated at 2022-06-21 04:46:01.561953
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b%2Fc') == 'a b/c'


# Generated at 2022-06-21 04:46:03.488804
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import pytest

    with pytest.raises(TypeError):
        FilterModule()

# Generated at 2022-06-21 04:46:11.109280
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # utf-8
    assert unicode_urldecode(quote_plus('%5B%7B%22name%22%3A+%22test%22%7D%5D')) == u'[{"name": "test"}]'
    # iso-8859-1
    assert unicode_urldecode(quote_plus('%5B%7B%22name%22%3A+%22t%E9st%22%7D%5D'), encoding='iso-8859-1') == u'[{"name": "tést"}]'

# Generated at 2022-06-21 04:46:13.070850
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello') == u'Hello'
    if PY3:
        assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'
    else:
        assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'.encode('utf-8')


# Generated at 2022-06-21 04:46:17.723375
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("invalid/url") == u'invalid%2Furl'
    # NOTE: Order of keys is not deterministic
    assert sorted(do_urlencode({"a": 1, "b": 2}).split('&')) == \
        [u'a=1', u'b=2']
    assert do_urlencode([1, 2, 3]) == u'1&2&3'


# Generated at 2022-06-21 04:46:28.793693
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert do_urldecode('key=value') == u'key=value'
    assert do_urlencode('key=value') == u'key=3Dvalue'


# Generated at 2022-06-21 04:46:39.894346
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('hello%20world') == 'hello world'
    assert do_urldecode('hello%2Bworld') == 'hello+world'
    assert do_urldecode('hello%20world%2B') == 'hello world+'
    assert do_urldecode('hello%20world%2Bsuccess') == 'hello world+success'
    assert do_urldecode('hello%20world%2Bsuccess&%2Fsuccess') == 'hello world+success&/success'


# Generated at 2022-06-21 04:46:47.611067
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('dag%20wieers') == 'dag wieers'

    assert do_urlencode('dag wieers') == 'dag%20wieers'
    assert do_urlencode('dag wieers') == 'dag%20wieers'
    assert do_urlencode(b'dag wieers') == 'dag%20wieers'
    assert do_urlencode({'dag': 'wieers'}) == 'dag=wieers'
    assert do_urlencode(('dag', 'wieers')) == 'dag=wieers'

# Generated at 2022-06-21 04:46:51.193527
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("hello%2C%20world%21") == "hello, world!"
    assert do_urlencode("hello, world!") == "hello%2C+world%21"

# Generated at 2022-06-21 04:46:59.642226
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('test+test') == 'test test'
    assert do_urldecode('test%2Btest') == 'test+test'

# Standard Ansible jinja2 test for filter urlencode

# Generated at 2022-06-21 04:47:08.184447
# Unit test for function do_urlencode
def test_do_urlencode():
    """Function do_urlencode should pass these tests."""
    import unittest
    class TestDoUrlEncode(unittest.TestCase):
        def test_urlencode_text(self):
            string = 'a+b c&d'
            result = 'a%2Bb+c%26d'
            self.assertEqual(do_urlencode(string), result)

        def test_urlencode_text_safe(self):
            string = 'a/b'
            result = 'a/b'
            self.assertEqual(do_urlencode(string), result)

        def test_urlencode_text_qs_safe(self):
            string = 'a/b'
            result = 'a%2Fb'

# Generated at 2022-06-21 04:47:14.684885
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    def testclass(object):
        def __init__(self):
            self.do_urldecode = do_urldecode
            self.do_urlencode = do_urlencode

    obj = testclass()
    assert obj.do_urldecode('%20') == u' '
    assert obj.do_urlencode(' ') == u'%20'



# Generated at 2022-06-21 04:47:26.095738
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('+') == '%2B'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode('~') == '%7E'
    assert unicode_urlencode('=') == '%3D'
    assert unicode_urlencode(unicode('/')) == '/'
    assert unicode_urlencode(unicode('+')) == '%2B'
    assert unicode_urlencode(unicode(' ')) == '%20'
    assert unicode_urlencode(unicode('~')) == '%7E'
    assert unicode_urlencode(unicode('=')) == '%3D'


# Generated at 2022-06-21 04:47:31.084533
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo%20bar') == u'foo bar'
    assert do_urldecode(u'foo+bar') == u'foo bar'
    assert do_urldecode(b'foo%20bar') == u'foo bar'
    assert do_urldecode(b'foo+bar') == u'foo bar'


# Generated at 2022-06-21 04:47:39.189459
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode'] == do_urlencode
    else:
        assert filter_module.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-21 04:48:01.705953
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test for string.
    assert unicode_urlencode('string') == 'string'
    # Test for unicode.
    assert unicode_urlencode(u'unicode') == u'unicode'
    # Test for tuple.
    assert unicode_urlencode((u'foo', u'bar')) == u'foo&bar'
    # Test for list.
    assert unicode_urlencode([u'foo', u'bar']) == u'foo&bar'
    # Test for dictionary.
    assert unicode_urlencode({'foo': u'bar'}) == u'foo=bar'

# Generated at 2022-06-21 04:48:05.791219
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert 'urldecode' in test.filters().keys()
    assert 'urlencode' in test.filters().keys()



# Generated at 2022-06-21 04:48:15.061720
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from sys import version_info
    str_type = str if version_info[0] == 3 else unicode
    assert unicode_urlencode('') == u''
    assert unicode_urlencode(b'') == u''
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode(b'/') == u'/'
    assert unicode_urlencode('/foo') == u'/foo'
    assert unicode_urlencode(b'/foo') == u'/foo'
    assert unicode_urlencode('/foo bar') == u'/foo%20bar'
    assert unicode_urlencode(b'/foo bar') == u'/foo%20bar'
    assert unicode_urlencode(u'/foo bar') == u'/foo%20bar'
    assert unic

# Generated at 2022-06-21 04:48:21.318472
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%20b%20c%21") == "a b c!"


# Generated at 2022-06-21 04:48:25.108423
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%22%23%24%25%26%27%28%29') == '"#$%&\'()'


# Generated at 2022-06-21 04:48:28.946134
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert 'urldecode' in obj.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in obj.filters()

# Generated at 2022-06-21 04:48:36.829101
# Unit test for function do_urldecode
def test_do_urldecode():
    urls_ok = [
        (r"a", "a"),
        (r"a%2Fb", "a/b"),
        (r"a%2fb", "a/b"),
        (r"a%09b", "a\tb"),
        (r"a%08b", "a\bb"),
        (r"a%0Ab", "a\nb"),
        (r"a%0Db", "a\rb"),
        (r"a%0Cb", "a\fb"),
        (r"a%00b", "a\x00b"),
        (r"a%20b", "a b"),
        (r"a+b", "a b"),
        (r"a%3Ab", "a:b"),
    ]


# Generated at 2022-06-21 04:48:41.972763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b"%40%20") == u"@ "
    assert unicode_urldecode("%40%20") == u"@ "



# Generated at 2022-06-21 04:48:56.348557
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo@bar.com') == 'foo%40bar.com'
    assert do_urlencode("A 'quote' is <b>bold</b>") == "A+%27quote%27+is+%3Cb%3Ebold%3C%2Fb%3E"
    assert do_urlencode("/foo?a=b&c=d") == "%2Ffoo%3Fa%3Db%26c%3Dd"

    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Generated at 2022-06-21 04:48:58.867205
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-21 04:49:13.660870
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-21 04:49:23.421815
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import warnings

    if sys.version_info[0] < 3:
        # To make sure we don't import Python 3.x code
        reload(sys)
        sys.setdefaultencoding('utf-8')

    import inspect
    import types
    import unittest
    import urlparse
    import jinja2
    from ansible.module_utils import core as module_utils

    class TestFilterModule(unittest.TestCase):
        def test_FilterModule_filters(self):
            # Check if function FilterModule.filters is callable
            self.assertTrue(callable(getattr(FilterModule, 'filters', None)),
                            msg='FilterModule.filters() is not callable')

            # Call function FilterModule.filters

# Generated at 2022-06-21 04:49:31.277694
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%7B%22%3Ckey%3E%22%3A%22%3Cvalue%3E%22%7D') == u'{"<key>":"<value>"}'
    assert do_urldecode(u'%7B%22%3Ckey%3E%22%3A%22%3Cvalue%3E%22%7D') != u'{"<key>":"<value>"}'
    assert do_urldecode(u'%3C%3C%3C%3C%3C%3C%3C%3C%3C%3C%3C%3C%3C') == u'<<<<<<<<<<<<<'

# Generated at 2022-06-21 04:49:32.700786
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('code') == u'code'
    assert unicode_urldecode('%43%6F%64%65') == u'code'



# Generated at 2022-06-21 04:49:40.032791
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a=1&b=2') == u'a=1&b=2'
    assert do_urldecode('a=%3C1%3E&b=%3C2%3E') == u'a=<1>&b=<2>'
    assert do_urldecode({'a': '<1>', 'b': '<2>'}) == u'a=%3C1%3E&b=%3C2%3E'
    assert do_urldecode(['a=1', 'b=2']) == u'a=1&b=2'

# Generated at 2022-06-21 04:49:46.197910
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    method_filters = fm.filters()
    assert method_filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert method_filters['urlencode'] == do_urlencode


# Generated at 2022-06-21 04:49:57.131559
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import sys
    if sys.version_info[0] < 3:
        assert do_urldecode("b3AgbW9yZSB0aGFuIGEgZ3JlYXQgc3RyaW5n") == "o a more than a great string"
        assert do_urlencode("o a more than a great string") == "o+a+more+than+a+great+string"
        assert do_urlencode({"b": "o", "a": "a more than a great string"}) == "b=o&a=a+more+than+a+great+string"

# Generated at 2022-06-21 04:49:59.515814
# Unit test for constructor of class FilterModule
def test_FilterModule():
    data = FilterModule()
    assert data is not None



# Generated at 2022-06-21 04:50:02.782838
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'foo bar' == unicode_urldecode('foo+bar')


# Generated at 2022-06-21 04:50:09.541142
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http://www.example.com/%7Eusername/') == u'http://www.example.com/~username/'
