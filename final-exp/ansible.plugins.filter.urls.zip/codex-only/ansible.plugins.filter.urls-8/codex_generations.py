

# Generated at 2022-06-23 10:15:56.039585
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Unit tests for function do_urldecode '''
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    assert do_urldecode(u'a+b') == unquote_plus(u'a+b')
    assert do_urldecode(u'a%20b') == unquote_plus(u'a%20b')



# Generated at 2022-06-23 10:16:03.653240
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%25') == '%'
    assert do_urldecode('%3F') == '?'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2B%25%3F%2F') == '+%?/'



# Generated at 2022-06-23 10:16:14.811611
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:16:19.641507
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert do_urldecode is filters['urldecode']
    if not HAS_URLENCODE:
        assert do_urlencode is filters['urlencode']
    return True


# Generated at 2022-06-23 10:16:28.796162
# Unit test for function do_urldecode
def test_do_urldecode():
    import unittest
    import ansible.module_utils.six.moves.urllib.parse as parser

    class Test(unittest.TestCase):
        data = {
            'spam+eggs': 'spam eggs',
            'spam%2Beggs': 'spam+eggs',
            '%7E': '~',
            '~': '~',
            '%0A': '\n',
            '%0D%0A': '\r\n',
            '%20': ' ',
            '\n': '\n',
            '\r\n': '\r\n',
            ' ': ' ',
        }


# Generated at 2022-06-23 10:16:33.546736
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == to_text('abc')
    assert unicode_urlencode(u'abc def') == to_text('abc%20def')
    assert unicode_urlencode(u'abc def', for_qs=True) == to_text('abc%20def')


# Generated at 2022-06-23 10:16:41.409916
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode(u'a') == u'a')
    assert(do_urlencode({'a': 'b'}) == u'a=b')
    assert(do_urlencode({'a': 'b', 'c': 'd'}) == u'a=b&c=d')
    assert(do_urlencode(u'a/b') == u'a%2Fb')
    assert(do_urlencode(u'a b') == u'a+b')
    assert(do_urlencode([u'a', u'b']) == u'a&b')

# Generated at 2022-06-23 10:16:48.288244
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test for UnicodeEncodeError for non unicode input
    # Example: https://github.com/ansible/ansible/issues/8735
    assert unicode_urlencode('\x90') == '%90'

    # Test for broken unicode_urlencode() in Jinja2 <2.7
    # Example: https://github.com/ansible/ansible/issues/14247
    assert unicode_urlencode({u'1': u'a/b'}) == '1=a%2Fb'

# Generated at 2022-06-23 10:16:57.906660
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'key': 'value'}) == u'key=value'
    assert do_urlencode([('key', 'value')]) == u'key=value'
    assert do_urlencode('/index.php?name=foo+bar') == u'%2Findex.php%3Fname%3Dfoo%2Bbar'
    assert do_urlencode({'url': '/index.php?name=foo+bar'}) == u'url=%2Findex.php%3Fname%3Dfoo%2Bbar'
    assert do_urlencode([('url', '/index.php?name=foo+bar')]) == u'url=%2Findex.php%3Fname%3Dfoo%2Bbar'

# Generated at 2022-06-23 10:17:02.813220
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%BC') == u'ü'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC=%C3%BC') == u'€=ü'
    assert unicode_urldecode('+') == u'+'
    assert unicode_urldecode('+%0d+') == u'+\r+'


# Generated at 2022-06-23 10:17:11.357084
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest


# Generated at 2022-06-23 10:17:12.413136
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-23 10:17:13.301424
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:17:23.763713
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(to_text(b'%3A%2B%2C%3D%3F%40')) == u':+,'
    assert do_urldecode(to_text('%3A%2B%2C%3D%3F%40')) == u':+,'

    assert do_urlencode(u':+,') == u'%3A%2B%2C'
    assert do_urlencode(':+,') == u'%3A%2B%2C'

    assert do_urlencode({'a:b': 'c+d'}) == u'a%3Ab=c%2Bd'

# Generated at 2022-06-23 10:17:30.196200
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import re
    import sys
    charset = 'utf-8'
    # Python3's quote() function is encoding aware and only accepts unicode objects;
    # since Jinja2 2.7, it is using the function directly and this is the expected
    # behaviour.
    quote_char = '%20' if PY3 else '+'
    if sys.version_info[1] > 6:
        expected = re.compile('%\w{2}')
    else:
        expected = re.compile('%(?:2B|2b|20)')
    # Try a simple string
    assert re.match(expected, unicode_urlencode('foo'))
    # Try a simple unicode string
    assert re.match(expected, unicode_urlencode(b'foo'.decode(charset)))


# Generated at 2022-06-23 10:17:35.556232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode']('%53%53') == 'SS'
    assert filter_module.filters()['urldecode']('%53%53', 'SS2') == 'SS2'
    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode']('SS') == 'SS'

# Generated at 2022-06-23 10:17:38.510411
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:17:44.049310
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testFilterModule = FilterModule()
    assert testFilterModule.filters() == {
            'urldecode': do_urldecode,
            'urlencode': do_urlencode
        }


# Generated at 2022-06-23 10:17:47.873186
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:17:52.890330
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo/bar') == u'foo/bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo%2bbar') == u'foo+bar'


# Generated at 2022-06-23 10:17:56.243337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert f.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:18:04.404912
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fdocs.python.org%2F') == 'http://docs.python.org/'
    assert do_urldecode('http%3A%2F%2Fdocs.python.org%2F2%2Flibrary%2Furllib.html%23urlencode-objects') == 'http://docs.python.org/2/library/urllib.html#urlencode-objects'
    assert do_urldecode('%7B%22username%22%3A%20%22admin%22%2C%20%22password%22%3A%20%22password%22%7D') == '{"username": "admin", "password": "password"}'



# Generated at 2022-06-23 10:18:16.030278
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Test function unicode_urlencode
    '''
    try:
        unicode_urlencode(u'hello')
    except NameError:
        unicode_urlencode = do_urlencode

    assert unicode_urlencode(u'hello') == u'hello'
    assert unicode_urlencode(u'spàce') == u'sp%C3%A0ce'
    assert unicode_urlencode(u'\u03b1\u03b2\u03b3') == u'%CE%B1%CE%B2%CE%B3'
    assert unicode_urlencode(u'\xfc') == u'%C3%BC'

    assert unicode_urlencode(u'hello', for_qs=True) == u'hello'


# Generated at 2022-06-23 10:18:26.307181
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo bar/?foo=bar') == '/foo%20bar/?foo=bar'
    assert unicode_urlencode('/foo bar/?foo=bar&fooz=') == '/foo%20bar/?foo=bar&fooz='
    assert unicode_urlencode('/foo bar/?foo=bar&fooz=&fooy=') == '/foo%20bar/?foo=bar&fooz=&fooy='

    # Test for function unicode_urlencode with argument for_qs=True

# Generated at 2022-06-23 10:18:35.483034
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('ab c d') == 'ab%20c%20d'
    assert do_urlencode('ab%20c d') == 'ab%20c%20d'
    assert do_urlencode(u'ab_c d') == u'ab_c+d'
    assert do_urlencode({1: 2}) == '1=2'
    assert do_urlencode([(1, 2), (3, 4)]) == '1=2&3=4'
    assert do_urlencode(u'ab&c=d') == u'ab%26c%3Dd'
    assert do_urlencode(u'ab c/d') == u'ab%20c%2Fd'

# Generated at 2022-06-23 10:18:45.730852
# Unit test for function do_urlencode
def test_do_urlencode():
    import pytest
    from collections import namedtuple

    test_data = [
        namedtuple('TestData', 'input expected'),
        TestData(input=b'This is a test', expected=b'This+is+a+test'),
        TestData(input=b'This is another test', expected=b'This+is+another+test'),
        TestData(input='This is a test', expected='This+is+a+test'),
        TestData(input='This is another test', expected='This+is+another+test'),
        TestData(input='This / is a test', expected='This+%2F+is+a+test'),
        TestData(input='This / is another test', expected='This+%2F+is+another+test'),
    ]

    for test in test_data:
        result = do

# Generated at 2022-06-23 10:18:47.825794
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2F%2F%2F') == u'///'



# Generated at 2022-06-23 10:18:57.482188
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.jinja2.filters import FilterModule
    with patch.multiple(FilterModule, filters=['filter']):
        mock_result = {'filter': 'mock_string'}
        FilterModule().filters = lambda: mock_result
        filters = FilterModule().filters()
        assert filters == mock_result
    mock_result = {'filter': 'mock_string'}
    filters = FilterModule().filters()
    assert filters == mock_result


# Generated at 2022-06-23 10:19:09.477182
# Unit test for function do_urlencode
def test_do_urlencode():

    # Empty string
    assert do_urlencode(u'') == u''

    # Unicode string
    assert do_urlencode(u'A+') == u'A%2B'

    # Bytes string
    assert do_urlencode(to_bytes('A+')) == 'A%2B'

    # Unicode string with non-ascii characters
    assert do_urlencode(u'\xC0') == u'%C3%80'

    # Bytes string with non-ascii characters
    assert do_urlencode(to_bytes('\xC0')) == u'%C3%80'

    # Unicode string with non-ascii characters
    assert do_urlencode(u'\xFC') == u'%C3%BC'

    # Bytes string with non-

# Generated at 2022-06-23 10:19:14.383387
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('a+') == 'a '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('+a') == ' a'


# Generated at 2022-06-23 10:19:20.609581
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(None) is None
    assert do_urldecode(True) is True
    assert do_urldecode(42) == 42
    assert do_urldecode('abcd') == 'abcd'
    assert do_urldecode('%21') == '!'
    assert do_urldecode('%21%22%23%24%25') == '!"#$%'
    assert do_urldecode('%2525%26%27%28%29%2a') == '%&\'()*'


# Generated at 2022-06-23 10:19:28.451680
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("foo bar") == u'foo%20bar'
    assert unicode_urlencode("foo/bar") == u'foo%2Fbar'
    assert unicode_urlencode("foo/bar", True) == u'foo%2Fbar'
    assert unicode_urlencode("foo bar", True) == u'foo+bar'
    assert unicode_urlencode("foo bar", False) == u'foo%20bar'



# Generated at 2022-06-23 10:19:37.882270
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    urldecode = unicode_urldecode

    assert urldecode(u'') == u''
    assert urldecode('%') == u''
    assert urldecode('%%') == u'%'
    assert urldecode('%2') == u'%2'
    assert urldecode('%2%3') == u'%2%3'
    assert urldecode('%%2') == u'%2'
    assert urldecode('%2%') == u'%2'
    assert urldecode('%2%3') == u'%2%3'
    assert urldecode('%25') == u'%'
    assert urldecode('%252') == u'%2'

# Generated at 2022-06-23 10:19:43.111981
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b') == 'a b'
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode('a%2Bb') == 'a+b'


# Generated at 2022-06-23 10:19:47.987078
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test for issue 6529
    assert 'foo bar' == unicode_urldecode('foo%20bar')
    assert 'foo bar' == unicode_urldecode('foo+bar')
    assert 'foo bar!' == unicode_urldecode('foo%20bar%21')
    assert 'foo bar!' == unicode_urldecode('foo+bar%21')
    assert 'foo+bar' == unicode_urldecode('foo%2Bbar')


# Generated at 2022-06-23 10:19:54.820039
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%21') == u'!'
    assert unicode_urldecode(u'%21+%20%21') == u'! !'
    assert unicode_urldecode(u'%21%2B%20%21') == u'!+ !'
    assert unicode_urldecode(u'%42%6f%6f%20%42%61%72%20%21') == u'Boo Bar !'


# Generated at 2022-06-23 10:19:57.593249
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test do_urldecode '''
    res = do_urldecode('%2Ffoo%2Fbar%2B%20baz%20')
    assert res == '/foo/bar+ baz '



# Generated at 2022-06-23 10:20:09.114688
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("TESTING jinja2.filters")

    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types

    FilterModule_instance = FilterModule()

    filters_dict = FilterModule_instance.filters()
    assert is_sequence(filters_dict)

    """
    for filter_name, filter_func in filters_dict.items():
        assert isinstance(filter_name, string_types)
        assert callable(filter_func)
    """

    urldecode = filters_dict['urldecode']


# Generated at 2022-06-23 10:20:18.999597
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"") == u""
    assert unicode_urlencode(u"abcd") == u"abcd"
    assert unicode_urlencode(u"abcd/") == u"abcd%2F"
    assert unicode_urlencode(u"abcd/", for_qs=True) == u"abcd%2F"
    assert unicode_urlencode(u"ab/cd") == u"ab%2Fcd"
    assert unicode_urlencode(u"a b/cd") == u"a%20b%2Fcd"
    assert unicode_urlencode(u"a b/c d") == u"a%20b%2Fc%20d"

# Generated at 2022-06-23 10:20:21.993482
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters()['urldecode'] == do_urldecode


# Generated at 2022-06-23 10:20:25.221663
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.module_utils import jinja2_filters

    jinja2_filters = jinja2_filters.FilterModule()
    print(jinja2_filters)

# Generated at 2022-06-23 10:20:33.693787
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcd') == u'abcd'
    assert unicode_urlencode(u'http://example.com/?abc') == u'http%3A//example.com/%3Fabc'
    assert unicode_urlencode(u'http://example.com/?abc', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fabc'
    assert unicode_urlencode(u'http://example.com/?a b c') == u'http%3A//example.com/%3Fa%20b%20c'

# Generated at 2022-06-23 10:20:34.697147
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-23 10:20:36.848832
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%22%C3%A9%22') == '"é"'


# Generated at 2022-06-23 10:20:44.869824
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%BB%E3%81%92') == u'ほげ'
    assert unicode_urldecode('%E3%81%BB') == u'ほ'
    assert unicode_urldecode('%E3%81%BB%E3%81%92%E3%81%BB%E3%81%92') == u'ほげほげ'


# Generated at 2022-06-23 10:20:45.426410
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:20:47.067501
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:20:49.428310
# Unit test for function do_urldecode
def test_do_urldecode():
    assert u'foo bar baz' == do_urldecode('foo+bar+baz')


# Generated at 2022-06-23 10:20:59.981842
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test basic string encoding
    assert unicode_urlencode('x') == 'x'
    assert unicode_urlencode('http://example.com') == 'http%3A//example.com'
    assert unicode_urlencode('/') == '/'

    # Test dictionary encoding
    assert unicode_urlencode({'a': 'b'}) == 'a=b'
    assert unicode_urlencode({'q': ['a', 'b']}) == 'q=a&q=b'
    assert unicode_urlencode({'q': 'a', 'x': 'b'}) == 'q=a&x=b'
    assert unicode_urlencode({'q': 'a', 'x': ['b', 'c']}) == 'q=a&x=b&x=c'

    #

# Generated at 2022-06-23 10:21:11.314032
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:21:16.114593
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('name=foo&old=bar') == 'name=foo&old=bar'
    assert do_urldecode('ansible.builtin.get_url/ssl-error.pem') == 'ansible.builtin.get_url/ssl-error.pem'



# Generated at 2022-06-23 10:21:18.963299
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert isinstance(filter_module, FilterModule)


# Generated at 2022-06-23 10:21:20.786596
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None

# Generated at 2022-06-23 10:21:25.323572
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert type(filters) is dict
    assert len(filters) == 2

# Generated at 2022-06-23 10:21:31.651192
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(1) == u'1'
    assert do_urlencode('a') == u'a'
    assert do_urlencode('a@b') == u'a%40b'
    assert do_urlencode('http://acme/') == u'http%3A%2F%2Facme%2F'
    assert do_urlencode({'a': 'b'}) == u'a=b'
    assert do_urlencode(['a=c', 'b=d']) == u'a%3Dc&b%3Dd'
    assert do_urlencode({'a': ['b', 'c']}) == u'a=b&a=c'

# Generated at 2022-06-23 10:21:39.512890
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode('abcABC123') == 'abcABC123'
    assert do_urlencode('résumé') == 'r%C3%A9sum%C3%A9'
    assert do_urlencode(u'résumé') == 'r%C3%A9sum%C3%A9'
    assert do_urlencode('relative/path') == 'relative/path'
    assert do_urlencode('/absolute/path') == '/absolute/path'

    assert do_urlencode([42]) == '0=42'
    assert do_urlencode({'a': 42, 'b': 43}) == 'a=42&b=43'
    assert do_urlencode({42: 43}) == '42=43'

# Generated at 2022-06-23 10:21:46.801999
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode([('foo', 'bar'), ('baz', 'bam')]) == 'foo=bar&baz=bam'
    assert do_urlencode({'foo': ['bar', 'baz']}) == 'foo=bar&foo=baz'

# Generated at 2022-06-23 10:21:55.889566
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:22:03.040065
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode(dict(foo='bar')) == 'foo=bar'
    assert do_urlencode(dict(blah=['foo', 'bar'])) == 'blah=foo&blah=bar'
    assert do_urlencode(dict(blah=('foo', 'bar'))) == 'blah=foo&blah=bar'


# Generated at 2022-06-23 10:22:14.195420
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == u""
    assert unicode_urldecode("%") == u"%"
    assert unicode_urldecode("%2") == u"%"
    assert unicode_urldecode("%%20") == u"% "
    assert unicode_urldecode("%25") == u"%"
    assert unicode_urldecode("%09") == u"\t"
    assert unicode_urldecode("%3a") == u":"
    assert unicode_urldecode("%3A") == u":"
    assert unicode_urldecode("%2F") == u"/"
    assert unicode_urldecode("%encode") == u"%encode"

# Generated at 2022-06-23 10:22:16.434818
# Unit test for constructor of class FilterModule
def test_FilterModule():  # lgtm[py/similar-function]
    ''' Unit tests for FilterModule() '''
    assert FilterModule()

# Generated at 2022-06-23 10:22:26.776364
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(None) is None
    assert do_urldecode(u'test') == u'test'
    assert do_urldecode(u'%24') == u'$'
    assert do_urldecode(u'%2f') == u'/'
    assert do_urldecode(u'a%2fb') == u'a/b'
    assert do_urldecode(u'a%2f%2fb') == u'a//b'
    assert do_urldecode(u'a%2f%2fb%24') == u'a//b$'
    assert do_urldecode(u'ansible%20rocks') == u'ansible rocks'



# Generated at 2022-06-23 10:22:28.222590
# Unit test for function do_urldecode
def test_do_urldecode():
    assert ': ' == do_urldecode('%3A%20')


# Generated at 2022-06-23 10:22:36.564774
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode
    assert do_urldecode('abc') == 'abc'
    assert do_urldecode('abc+def') == 'abc def'
    assert do_urldecode('abc%20def') == 'abc def'
    assert do_urldecode('abc%2Bdef') == 'abc+def'

    # Test urlencode
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc def') == 'abc+def'
    assert unicode_urlencode('abc ') == 'abc+'
    assert unicode_urlencode({'abc def': '0123'}) == 'abc%20def=0123'
    assert unicode_urlencode({'abc ': '0123'}) == 'abc+=0123'

# Generated at 2022-06-23 10:22:40.553563
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("abc123") == "abc123"
    assert do_urldecode("abc%20%26%20123") == "abc & 123"
    assert do_urldecode("abc%20%26%20123") == u"abc & 123"

# Generated at 2022-06-23 10:22:47.677862
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo[bar]') == u'foo%5Bbar%5D'
    assert do_urlencode(u'foo=bar') == u'foo=bar'
    assert do_urlencode(u'foo/bar') == u'foo/bar'
    assert do_urlencode(u'foo;bar') == u'foo;bar'
    assert do_urlencode(u'foo?bar') == u'foo?bar'
    assert do_urlencode(u'foo:bar')

# Generated at 2022-06-23 10:22:49.264296
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testcase = FilterModule()
    testcase.filters()
    assert True


# Generated at 2022-06-23 10:22:59.628259
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    import ansible.module_utils.urls as ansible_urls
    import ansible.module_utils.unicode as ansible_unicode


    filterModule = FilterModule()
    filter_filters = filterModule.filters()

    class Inputs(object):
        '''
        All the inputs that should be tested.
        I.e. the urlencode, urldecode, ...
        '''
        urldecode = {
            'input': {'encoded': '%7B%22encoded%22%3A%20true%7D'},
            'expected': {'encoded': '{"encoded": true}'}
        }



# Generated at 2022-06-23 10:23:03.844984
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Unit test for constructor of class FilterModule
    """
    filters = FilterModule().filters()
    assert filters['urldecode']
    assert filters['urlencode']

# Generated at 2022-06-23 10:23:06.406414
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import jinja2
    assert jinja2.filters.FILTERS['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:23:14.904145
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def assertEqual(result, expected, message='Assertion failed'):
        if result != expected:
            raise ValueError("%s: '%s' != '%s'" % (message, result, expected))
    assertEqual(unicode_urlencode('foo bar'), 'foo%20bar')
    assertEqual(unicode_urlencode('foo/bar'), 'foo%2Fbar')
    assertEqual(unicode_urlencode('foo/bar', for_qs=True), 'foo%2Fbar')
    assertEqual(unicode_urlencode('foo bar', for_qs=True), 'foo+bar')

# Generated at 2022-06-23 10:23:16.987833
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test class constructor
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:23:19.935829
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # check for the constructor of FilterModule
    # assert if it is raising any exceptions
    fm = FilterModule()
    assert fm.filters() is not None

# Generated at 2022-06-23 10:23:24.202200
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    # Unit: FilterModule.filters() > 'urldecode' filter
    assert filter_module.filters()['urldecode']('test') == u'test'

    # Unit: FilterModule.filters() > 'urlencode' filter
    assert filter_module.filters()['urlencode']({'test': 'test'}) == u'test=test'

    # Unit: FilterModule.filters()
    assert filter_module.filters()['urlencode']('test') == u'test'


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-23 10:23:28.866000
# Unit test for function do_urlencode
def test_do_urlencode():
    import six

    # Basic usage
    assert do_urlencode('unicode_test') == 'unicode_test'
    assert do_urlencode('unicode %2B test') == 'unicode%20%2B%20test'

    # PY3 dicts are iterable
    if six.PY3:
        assert do_urlencode({'unicode': 'test'}) == 'unicode=test'

    # Lists are iterable
    assert do_urlencode(['unicode', 'test']) == 'unicode&test'

# Generated at 2022-06-23 10:23:36.902367
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_value = {'key_1&%[]': 'value_1&%[]'}
    assert unicode_urlencode(test_value) == 'key_1&%25%5B%5D=value_1&%25%5B%5D'
    assert unicode_urlencode(test_value, for_qs=True) == 'key_1%26%25%5B%5D=value_1%26%25%5B%5D'
    test_value = 'test & %[]'
    assert unicode_urlencode(test_value) == 'test%20%26%20%25%5B%5D'
    assert unicode_urlencode(test_value, for_qs=True) == 'test%20%26%20%25%5B%5D'

# Generated at 2022-06-23 10:23:45.580694
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2
    env = jinja2.Environment()
    env.filters['urldecode'] = unicode_urldecode
    env.filters['urlencode'] = unicode_urlencode
    t = env.from_string('{{ urldecode_string | urldecode }}')
    assert t.render(urldecode_string='%E4%BD%A0%E5%A5%BD') == u'你好'
    t = env.from_string('{{ urlencode_string | urlencode(True) }}')
    assert t.render(urlencode_string=u'你好') == '%E4%BD%A0%E5%A5%BD'


if __name__ == '__main__':
    test_Filter

# Generated at 2022-06-23 10:23:52.105175
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    """This test does not aim at being complete."""
    assert unicode_urlencode(u'你好') == '%E4%BD%A0%E5%A5%BD'
    assert unicode_urlencode(u'你好 /') == '%E4%BD%A0%E5%A5%BD%20%2F'
    assert unicode_urlencode(u'你好 /', for_qs=True) == '%E4%BD%A0%E5%A5%BD+%2F'
    assert unicode_urlencode(u'你好') == unicode_urlencode(to_text(u'你好'))

# Generated at 2022-06-23 10:23:54.489762
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of FilterModule class
    filtermodule = FilterModule()
    # Ensure FilterModule_filters() method returns the expected dictionary
    result = filtermodule.filters()
    # Check for the urldecode key in the returned dictionary
    assert 'urldecode' in result
    # Check for the urlencode key in the returned dictionary
    if not HAS_URLENCODE:
        assert 'urlencode' in result

# Generated at 2022-06-23 10:23:56.462202
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%2Bdef') == 'abc+def'

# Generated at 2022-06-23 10:24:07.011028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import json
    if sys.version_info[0] >= 3:
        unicode = str
    fm = FilterModule()
    filters = fm.filters()
    # unicode_urldecode
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('abc') == 'abc'
    # The following are normally taken care of by urllib.unquote_plus
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('+') == ' '
    # unicode_urlencode
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode(' ') == '%20'
    assert unic

# Generated at 2022-06-23 10:24:13.344549
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # This is an example of a garbled UTF-8 string
    # that is url-encoded and then url-decoded.
    # This is the only way to represent this string in a URL
    decoded = u'pouet \ud83d\udc7bpouet'
    urlencoded = u'pouet%20%F0%9F%91%BBpouet'
    assert unicode_urldecode(urlencoded) == decoded

# Generated at 2022-06-23 10:24:15.478243
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("apples%2Foranges") == "apples/oranges"
    assert unicode_urldecode("apples+oranges") == "apples oranges"


# Generated at 2022-06-23 10:24:17.795964
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'


# Generated at 2022-06-23 10:24:21.296106
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20') == u'é '
    assert unicode_urldecode('%C3%A9%0A') == u'é\n'
    assert unicode_urldecode(u'%C3%A9%0A') == u'é\n'


# Generated at 2022-06-23 10:24:22.044569
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), object)


# Generated at 2022-06-23 10:24:33.738602
# Unit test for function do_urldecode
def test_do_urldecode():
    # test 1
    encoded_string = 'Hello%20Dolly'
    decoded_string = do_urldecode(encoded_string)
    assert decoded_string == 'Hello Dolly'

    # test 2
    encoded_string = 'Hello%20Dolly%40%40'
    decoded_string = do_urldecode(encoded_string)
    assert decoded_string == 'Hello Dolly@@'

    # test 3
    encoded_string = '%C8%85%20%C8%A7%C8%A8%C8%A9%C8%A6%C8%A7%C8%A6'
    decoded_string = do_urldecode(encoded_string)

# Generated at 2022-06-23 10:24:39.311007
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%3C%3E') == '<>'
    assert do_urldecode('%3c%3e') == '<>'
    assert do_urldecode('%25') == '%'
    assert do_urldecode('\n') == '\n'


# Generated at 2022-06-23 10:24:44.231848
# Unit test for function do_urldecode
def test_do_urldecode():
    s = "L%C3%B6wenzahn%2F%20%28Taraxacum%20officinale%29%20"
    e = u"L\xf6wenzahn/(Taraxacum officinale) "
    assert do_urlencode(e) == s



# Generated at 2022-06-23 10:24:56.721317
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%25') == u'%'
    assert do_urldecode('%5E') == u'^'
    assert do_urldecode('%3D') == u'='
    assert do_urldecode('%7E') == u'~'
    assert do_urldecode('%26') == u'&'
    assert do_urldecode('%2B') == u'+'
    assert do_urldecode('%60') == u'`'
    assert do_urldecode('%7B') == u'{'
    assert do_urldecode('%7D') == u'}'
    assert do_urldecode('%7C') == u'|'
    assert do_urldecode('%3B')

# Generated at 2022-06-23 10:25:05.185136
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Hello world!') == u'Hello+world%21'
    assert unicode_urlencode(u'Hello world!', True) == u'Hello%20world%21'


# Generated at 2022-06-23 10:25:14.834464
# Unit test for function do_urldecode
def test_do_urldecode():
    """
    The test case is from https://docs.djangoproject.com/en/2.2/ref/urls/#url-quoting-rules
    """
    assert do_urldecode('/blog/') == '/blog/'
    assert do_urldecode('/blog/post/1') == '/blog/post/1'
    assert do_urldecode('/blog/post/1/') == '/blog/post/1/'
    assert do_urldecode('/blog/post/1//') == '/blog/post/1//'
    assert do_urldecode('/blog/post//1/') == '/blog/post//1/'
    assert do_urldecode('/blog/post/1?') == '/blog/post/1?'
    assert do_urld

# Generated at 2022-06-23 10:25:19.745471
# Unit test for function do_urldecode
def test_do_urldecode():
    encoded = '%20%3Cfish%3E%2B%3D%7B%3A%5B%22%27%5D%7D%C2%A9%E2%82%AC'
    decoded = u' <fish>+={:["\']}©€'
    assert decoded == do_urldecode(encoded)


# Generated at 2022-06-23 10:25:30.915389
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('this is a [test]') == 'this+is+a+%5Btest%5D'
    assert do_urlencode('this is a #test') == 'this+is+a+%23test'
    assert do_urlencode('this is a # test') == 'this+is+a+%23+test'
    assert do_urlencode('this is a $test') == 'this+is+a+%24test'
    assert do_urlencode('this is a $ test') == 'this+is+a+%24+test'
    assert do_urlencode('this is a £test') == 'this+is+a+%C2%A3test'

# Generated at 2022-06-23 10:25:35.217122
# Unit test for function do_urldecode
def test_do_urldecode():
    result = do_urldecode('a%2Bb')
    assert result == 'a+b'
    result = do_urldecode(u'a%2Bb')
    assert result == u'a+b'


# Generated at 2022-06-23 10:25:42.774414
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'/foo') == u'/foo'
    assert unicode_urlencode(u'/foo', True) == u'/foo'
    assert unicode_urldecode(u'/foo') == u'/foo'
    assert unicode_urldecode(u'/foo') == u'/foo'
    assert unicode_urlencode(u'foo%bar') == u'foo%25bar'
    assert unicode_urldecode(u'foo%25bar') == u'foo%bar'


# Generated at 2022-06-23 10:25:48.562449
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    f = x.filters()
    assert type(f) is dict
    assert 'urldecode' in f.keys()
    assert 'urlencode' in f.keys() if not HAS_URLENCODE else 'urlencode' not in f.keys()