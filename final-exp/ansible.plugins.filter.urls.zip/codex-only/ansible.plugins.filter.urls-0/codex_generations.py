

# Generated at 2022-06-23 10:16:01.374936
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'a=b&c=d') == u'a%3Db%26c%3Dd'
    assert do_urlencode(u'a=b & c=d') == u'a%3Db%20%26%20c%3Dd'
    assert do_urlencode(u'a=b&c=d') == u'a%3Db%26c%3Dd'
    assert do_urlencode(u'a=b&c=d') == u'a%3Db%26c%3Dd'
    assert do_urlencode('a=b&c=d') == u'a%3Db%26c%3Dd'

# Generated at 2022-06-23 10:16:13.287443
# Unit test for function do_urldecode
def test_do_urldecode():
    utf8_str = u'%E4%B8%AD%E6%96%87'
    utf16_str = u'%FE%FF%00%E4%00%B8%00%AD%00%96%00%87'
    utf32_str = u'%00%00%FE%FF%00%00%00%E4%00%00%00%B8%00%00%00%AD%00%00%00%96%00%00%00%87'

    assert do_urldecode(utf8_str) == u'中文'
    assert do_urldecode(utf16_str) == u'中文'
    assert do_urldecode(utf32_str) == u'中文'


# Generated at 2022-06-23 10:16:19.134358
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc123') == u'abc123'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2F') == u'/'


# Generated at 2022-06-23 10:16:26.923467
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # We need to know that the result is a unicode string,
    # not an 8-bit string, otherwise we have to use to_text()
    result = unicode_urldecode('foo_%25_%21')
    assert result == 'foo_%_!'
    assert type(result) == type(u'')


# Generated at 2022-06-23 10:16:33.275272
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("http://www.example.com/") == b'http%3A//www.example.com/'
    assert do_urlencode("http://www.example.com/&a=b c?foo=bar#123") == b'http%3A//www.example.com/%26a%3Db%20c%3Ffoo%3Dbar%23123'
    assert do_urlencode(["http://www.example.com/", "&a=b c?foo=bar#123"]) == b'http%3A//www.example.com/&%26a%3Db%20c%3Ffoo%3Dbar%23123'

# Generated at 2022-06-23 10:16:42.372419
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'a%2F') == u'a%2F'
    assert unicode_urldecode(u'a%2f') == u'a/'
    assert unicode_urldecode(u'a%2f+') == u'a/+'
    assert unicode_urldecode(u'a%2f%20') == u'a/%20'
    assert unicode_urldecode(u'a%2F+') == u'a%2F+'
    assert unicode_urldecode(u'a%2f+%2f') == u'a/+/'


# Generated at 2022-06-23 10:16:48.639253
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo%20bar%20baz') == 'foo bar baz'

    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode({'foo': 'bar baz'}) == 'foo=bar+baz'
    assert do_urlencode({'foo': 'bar baz', 'arg': 'value'}) == 'foo=bar+baz&arg=value'

# Generated at 2022-06-23 10:16:51.893546
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    assert 'urldecode' in fm.filters()
    assert 'urlencode' in fm.filters()

# Generated at 2022-06-23 10:16:59.975340
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic


# Generated at 2022-06-23 10:17:07.560735
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_FilterModule = FilterModule()
    #assert ansible_FilterModule.filters().has_key('urlencode'), "urlencode key doesn't exist in filters"
    #assert ansible_FilterModule.filters().has_key('urldecode'), "urldecode key doesn't exist in filters"
    assert hasattr(ansible_FilterModule.filters(), 'urlencode'), \
        "urlencode key doesn't exist in filters"
    assert hasattr(ansible_FilterModule.filters(), 'urldecode'), \
        "urldecode key doesn't exist in filters"

# Generated at 2022-06-23 10:17:16.253357
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.urls import _unicode_urldecode
    from ansible.module_utils.urls import _unicode_urlencode
    from ansible.module_utils.urls import _urlencode_unicode_dict
    from ansible.module_utils.urls import _urlencode_unicode_dict_items
    from ansible.module_utils.urls import _urlencode_unicode_sequence
    assert FilterModule.filters(None)['urldecode'] == _unicode_urldecode
    assert FilterModule.filters(None)['urlencode'] == _unicode_urlencode
    assert FilterModule.filters(None)['urlencode'] == _urlencode_unicode_dict

# Generated at 2022-06-23 10:17:26.477878
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # ansible/module_utils/urls.py
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%25') == '%'
    assert FilterModule().filters()['urldecode']('http%3A%2F%2Fexample.org%2F%25') == 'http://example.org/%'

# Generated at 2022-06-23 10:17:34.957827
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+%27bar%27') == 'foo \'bar\''
    assert do_urldecode('foo%20%27bar%27') == 'foo \'bar\''



# Generated at 2022-06-23 10:17:42.207010
# Unit test for function do_urlencode
def test_do_urlencode():
    assert u'foo%2Fbar%2Fbaz' == do_urlencode('foo/bar/baz')
    assert u'foo%20bar' == do_urlencode('foo bar')
    assert u'foo%20bar%2F' == do_urlencode('foo bar/')
    assert u'foo%20bar%3Dbaz' == do_urlencode('foo bar=baz')
    assert u'foo%3Dbar' == do_urlencode('foo=bar')
    assert u'foo%3Dbaz' == do_urlencode('foo=baz')
    assert u'foo%3D%3Dbar' == do_urlencode('foo==bar')
    assert u'foo%26%25bar' == do_urlencode('foo&%bar')

# Generated at 2022-06-23 10:17:50.884717
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc+def') == u'abc def'
    assert unicode_urldecode(u'abc%20def') == u'abc def'
    assert unicode_urldecode(u'abc%27def') == u"abc'def"
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc+def') == u'abc def'


# Generated at 2022-06-23 10:17:53.486372
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2F%2F%2F%2F') == u'////'


# Generated at 2022-06-23 10:17:57.342160
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a%2Bb') == u'a+b'

# Generated at 2022-06-23 10:18:03.826450
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # strings
    assert (unicode_urlencode('&') == '%26')
    assert (unicode_urlencode('&') == u'%26')

    # check that spaces are encoded as '+' instead of '%20%' when for_qs is true
    assert (unicode_urlencode(' ', for_qs=True) == '+')

    # dicts
    assert (unicode_urlencode({'key': 'value'}) == 'key=value')

    # lists
    assert (unicode_urlencode(['key', 'value']) == 'key=value')



# Generated at 2022-06-23 10:18:10.915488
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+%20%2B%20bar') == 'foo  +  bar'


# Generated at 2022-06-23 10:18:22.104055
# Unit test for function do_urlencode
def test_do_urlencode():
    from StringIO import StringIO
    from ansible.module_utils.six.moves.urllib.request import pathname2url
    from ansible.module_utils.six.moves.urllib.parse import urlencode

    inp = {'always_encoded': '&', 'space_encoded': ' ', 'special': '@:&:#+$'}
    out_qs = urlencode(inp, True)
    out = urlencode(inp, False)

    assert ' ' not in out
    assert ' ' in out_qs
    if ':' in out:
        assert '+' not in out
        assert '+' in out_qs
    if '@' in out:
        assert '%40' in out
        assert '@' not in out
        assert '%40' in out

# Generated at 2022-06-23 10:18:33.616291
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode(u'foo') == u'foo')
    assert(do_urlencode(u'foo bar') == u'foo%20bar')
    assert(do_urlencode(u'foo=bar') == u'foo%3Dbar')
    assert(do_urlencode(u'foo bar=baz') == u'foo%20bar%3Dbaz')
    assert(do_urlencode({u'foo': u'bar', u'baz': u'qux'}) == u'baz=qux&foo=bar')
    assert(do_urlencode((u'foo', u'bar', u'baz', u'qux')) == u'0=foo&1=bar&2=baz&3=qux')

# Generated at 2022-06-23 10:18:44.912686
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' do_urlencode should correctly urlencode the given argument '''

    # Given a string, do_urlencode should return the string percent encoded
    assert do_urlencode('ansible') == 'ansible'
    assert do_urlencode('ansible/rocks') == 'ansible%2Frocks'
    assert do_urlencode('ansible rocks') == 'ansible+rocks'
    assert do_urlencode('ansi ble rocks') == 'ansi+ble+rocks'
    assert do_urlencode('ansi ble? rocks') == 'ansi+ble%3F+rocks'
    assert do_urlencode('ansi ble@ rocks') == 'ansi+ble%40+rocks'

# Generated at 2022-06-23 10:18:56.637893
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('f o o') == 'f%20o%20o'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foobar+baz') == 'foobar%2Bbaz'
    assert do_urlencode('foo/bar+baz') == 'foo%2Fbar%2Bbaz'
    assert do_urlencode('foo/bar baz') == 'foo%2Fbar%20baz'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo%20bar%2Fbaz'


# Generated at 2022-06-23 10:19:08.145276
# Unit test for function do_urlencode
def test_do_urlencode():
    '''
    unit tests for Ansible function do_urlencode
    '''
    assert (do_urlencode('key1=value1&key2=value2') ==
            'key1=value1&key2=value2')
    assert (do_urlencode('?key1=value1&key2=value2') ==
            '%3Fkey1=value1&key2=value2')
    assert (do_urlencode('/open?key1=value1&key2=value2') ==
            '%2Fopen%3Fkey1=value1&key2=value2')

# Generated at 2022-06-23 10:19:11.528803
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'dag%20wieers+%u0161') == u'dag wieers š'
    assert do_urldecode(u'dag%2bwieers') == u'dag+wieers'


# Generated at 2022-06-23 10:19:20.696310
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('/') == '/')
    assert(do_urlencode('/?') == '/%3F')
    assert(do_urlencode('http://example.com/foo%3D?bar%3D') == 'http%3A%2F%2Fexample.com%2Ffoo%253D%3Fbar%253D')
    assert(do_urlencode('/?') == '/%3F')
    assert(do_urlencode('/') == '/')
    assert(do_urlencode({'spaces' : 1, 'safe' : '/', 'unsafe' : '?'}) == 'spaces=1&safe=%2F&unsafe=%3F')

# Generated at 2022-06-23 10:19:26.894748
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({"a": "b"}) == "a=b"
    assert do_urlencode([["a", "b"], ["c", "d"]]) == "a=b&c=d"
    assert do_urlencode(["a", "b", "c", "d"]) == "a=b&c=d"

# Generated at 2022-06-23 10:19:33.435441
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ## test empty string
    assert FilterModule().filters()['urldecode']("") == ""
    assert FilterModule().filters()['urldecode']("abc") == "abc"
    assert FilterModule().filters()['urldecode']("a%2Fb%2Fc") == "a/b/c"
    assert FilterModule().filters()['urldecode']("a%2F%2Fb") == "a//b"
    assert FilterModule().filters()['urldecode']("a+b") == "a b"

    assert isinstance(FilterModule().filters()['urldecode']("a%2Fb%2Fc"), str)

# Generated at 2022-06-23 10:19:36.680146
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'\u00e9'


# Generated at 2022-06-23 10:19:42.212945
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'abc') == u'abc')
    assert(unicode_urlencode(u'abc def') == u'abc+def')
    assert(unicode_urlencode(u'/abc/def') == u'%2Fabc%2Fdef')
    assert(unicode_urlencode(u'/abc/def', for_qs=True) == u'%2Fabc%2Fdef')


# Generated at 2022-06-23 10:19:43.537914
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    obj.filters()
    return True

# Generated at 2022-06-23 10:19:50.250641
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%1%2%3%4') == '%1%2%3%4'
    assert do_urldecode('%25') == '%'
    assert do_urldecode('%%35') == '%35'
    assert do_urldecode('%1a%2b%3c%4d') == '%1a+%2b,%3c-%4d'
    assert do_urldecode('%e3%81%82%e3%81%84%e3%81%86%e3%81%88') == 'あいうえお'



# Generated at 2022-06-23 10:19:57.521546
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://wiki.example.org/some page') == 'http%3A%2F%2Fwiki.example.org%2Fsome+page'
    assert do_urlencode({'a': u'b', u'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode(u'a=b=c&d') == 'a%3Db%3Dc%26d'
    assert do_urlencode(u'a=b&b=c&d') == 'a=b&b=c&d'

# Generated at 2022-06-23 10:19:59.906692
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()



# Generated at 2022-06-23 10:20:01.751704
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # We have to have one assert in this test, so that it isn't stripped by PyInstaller
    assert FilterModule is not None

# Generated at 2022-06-23 10:20:02.351448
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:20:11.378709
# Unit test for function do_urlencode
def test_do_urlencode():
    # The function do_urlencode should behave exactly the same as
    # jinja2.filters.do_urlencode, which was introduced in Jinja2 v2.7.
    if HAS_URLENCODE:
        print('OK: The test_do_urlencode unit test was omitted as Jinja2 v2.7+ is available.')
        return


# Generated at 2022-06-23 10:20:14.544584
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # In python2.7, there is no test for this function
    pass



# Generated at 2022-06-23 10:20:22.648422
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' Make sure this filter behaves like Jinja2.'''

    # Make sure the two versions return the same result
    test_inputs = [
        (None, ''),
        (True, 'True'),
        (False, 'False'),
        ({'a': 1}, 'a=1'),
        ({'a': 1, 'b': '2'}, 'a=1&b=2'),
        (['a', 'b'], 'a&b'),
    ]

    for in_data, out_data in test_inputs:
        assert do_urlencode(in_data) == out_data

        if HAS_URLENCODE:
            assert do_urlencode(in_data) == do_urlencode.jinja2.filters['urlencode'](in_data)

    # The following is a test of

# Generated at 2022-06-23 10:20:29.731259
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%C3%BCmlat") == u"ümlat"
    assert unicode_urldecode(u"%C3%BCmlat%20test") == u"ümlat test"
    assert unicode_urldecode(u"%25C3%25BCmlat%2520test") == u"%C3%BCmlat%20test"
    assert unicode_urldecode(u"%C3%BCmlat%20%25%20test") == u"ümlat % test"


# Generated at 2022-06-23 10:20:32.438710
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('+') == ' '
    assert unicode_urldecode('%3A+') == ': '


# Generated at 2022-06-23 10:20:34.392900
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-23 10:20:38.342827
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('bar%20baz') == 'bar baz'
    assert do_urldecode(u'bar%20baz') == u'bar baz'
    assert do_urldecode(b'bar%20baz') == u'bar baz'


# Generated at 2022-06-23 10:20:43.366329
# Unit test for function do_urldecode
def test_do_urldecode():
    string1 = 'This+thing+%26+that+thing'
    string2 = 'That%20thing%20%26%20this%20thing'
    test_string1 = do_urldecode(string1)
    test_string2 = do_urldecode(string2)
    string3 = 'This thing & that thing'
    string4 = 'That thing & this thing'
    assert test_string1 == string3
    assert test_string2 == string4


# Generated at 2022-06-23 10:20:55.522235
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test string
    assert do_urlencode('/path/to?foo=bar') == '%2Fpath%2Fto%3Ffoo%3Dbar'

    # Test string with escape character
    assert do_urlencode('/path/to?foo=bar&') == '%2Fpath%2Fto%3Ffoo%3Dbar%26'

    # Test dict
    assert do_urlencode({"foo": "bar"}) == 'foo=bar'

    # Test dict with multiple values
    assert do_urlencode({"foo": "bar", "arg": "val"}) == 'foo=bar&arg=val'

    # Test dict with list
    assert do_urlencode({"foo": ["bar", "baz"]}) == 'foo=bar&foo=baz'

    # Test list

# Generated at 2022-06-23 10:21:01.822565
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    value = to_text(filters['urldecode']('%E5%93%88%E5%93%88'))
    assert value == u'哈哈'
    value = to_text(filters['urldecode']('%E5%93%88+%E5%93%88'))
    assert value == u'哈 哈'

# Generated at 2022-06-23 10:21:02.785836
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-23 10:21:08.597198
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('hello world/') == 'hello+world%2F'
    assert do_urlencode('hello world/') == do_urlencode(b'hello world/')
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'

# Generated at 2022-06-23 10:21:18.567568
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:21:29.229770
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:21:38.112249
# Unit test for function do_urlencode
def test_do_urlencode():
    from tempfile import mkstemp
    from shutil import move
    from os import remove, close

    # Create temp file
    fh, abs_path = mkstemp()
    new_file = open(abs_path, 'w')
    old_file = open('filter/core.py', 'r')

    new_file.write("# Copyright: (c) 2012, Dag Wieers (@dagwieers) <dag@wieers.com>\n")
    new_file.write("# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)\n")
    new_file.write("\n")
    new_file.write("# Make coding more python3-ish\n")

# Generated at 2022-06-23 10:21:43.584192
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.com') == 'http%3A%2F%2Fwww.example.com'
    assert unicode_urlencode('http://www.example.com', for_qs=True) == 'http%3A%2F%2Fwww.example.com'
    assert unicode_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'
    assert unicode_urlencode('a=1&b=2') == 'a%3D1%26b%3D2'

# Generated at 2022-06-23 10:21:50.067802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    testobj = FilterModule()
    result = testobj.filters()
    assert type(result) is dict
    assert 'urldecode' in result
    assert result['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in result
        assert result['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:22:00.607084
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus
    from ansible.module_utils._text import to_bytes, to_text

    filters = FilterModule().filters()

# Generated at 2022-06-23 10:22:04.952765
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t1 = FilterModule()

    assert '%D7%90' == t1.filters()['urlencode'](u'א')
    assert '%D7%90' == t1.filters()['urlencode']('א')
    assert u'א' == t1.filters()['urldecode'](u'%D7%90')
    assert u'א' == t1.filters()['urldecode']('%D7%90')

# Generated at 2022-06-23 10:22:07.555923
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:22:14.920686
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'a&b') == u'a%26b'
    assert do_urlencode({'k1': u'a&b', 'k2': u'c&d'}) == u'k1=a%26b&k2=c%26d'
    assert do_urlencode([u'k1=a&b', u'k2=c&d']) == u'k1%3Da%26b&k2%3Dc%26d'

# Generated at 2022-06-23 10:22:17.107977
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u"a%20b") == u"a b"


# Generated at 2022-06-23 10:22:27.834102
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert("a=b&c=d" == do_urlencode({'a': 'b', 'c': 'd'}))
    assert("c%3Dd&a%3Db" == do_urlencode({'a': 'b', 'c': 'd'}))
    assert("a=b&c=d" == do_urlencode(['a=b', 'c=d']))
    assert("a%3Db&c%3Dd" == do_urlencode(['a=b', 'c=d']))
    assert("a%3Db" == do_urlencode('a=b'))
    assert("a=b" == do_urlencode('a=b', True))

# Generated at 2022-06-23 10:22:36.071670
# Unit test for function do_urlencode
def test_do_urlencode():
    assert u'very secret' == do_urlencode(u'very secret')
    assert u'hello%20world' == do_urlencode(u'hello world')
    assert u'hello%20world' == do_urlencode(u'hello world')
    assert u'hello%2Bworld' == do_urlencode(u'hello+world')
    assert u'hello%26world' == do_urlencode(u'hello&world')
    assert u'hello%3Dworld' == do_urlencode(u'hello=world')
    assert u'hello%3Fworld' == do_urlencode(u'hello?world')
    assert u'hello%25world' == do_urlencode(u'hello%world')

# Generated at 2022-06-23 10:22:41.894093
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    pass

if __name__ == '__main__':
    print("Testing FilterModule()")
    obj = FilterModule()
    print("Successfully constructed FilterModule Object")
    print("Filters available: \n" + str(obj.filters()))

# Generated at 2022-06-23 10:22:53.583514
# Unit test for function do_urldecode
def test_do_urldecode():
    # This is a simple test to verify we can urldecode strings
    assert do_urldecode('test%2Ftest') == u'test/test'

    # Unicode characters should be decoded as well
    assert do_urldecode('абвгд') == u'абвгд'

    # Bytes objects must be decoded to unicode first
    if PY3:
        assert do_urldecode(b'test%2Ftest') == u'test/test'
    else:
        assert do_urldecode(b'test%2Ftest') == u'test%2Ftest'

    # The urllib.parse.unquote_plus function does not decode '+' to spaces
    # when it is not part of a percent-encoded sequence
    assert do_

# Generated at 2022-06-23 10:23:02.117548
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import types
    from ansible.module_utils._text import to_bytes

    assert isinstance(FilterModule.filters(FilterModule), types.DictType)

    ansible_module_filters = FilterModule.filters(FilterModule)
    assert 'urldecode' in ansible_module_filters
    assert 'urlencode' in ansible_module_filters

    assert '%C2%A9' == unicode_urldecode('%C2%A9')
    assert '©' == do_urldecode('%C2%A9')
    assert '%C2%A9' == unicode_urlencode('©')
    assert '%C2%A9' == unicode_urlencode('©', for_qs=True)

# Generated at 2022-06-23 10:23:07.785401
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%48%65%6c%6c%6f%21%20%41%6e%73%69%62%6c%65%21') == 'Hello! Ansible!'
    assert do_urldecode('Hello%26%21+Ansible%26%21') == 'Hello&! Ansible&!'



# Generated at 2022-06-23 10:23:12.965622
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''FilterModule.filters()'''
    import pytest

    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode'] == do_urlencode
    else:
        assert filter_module.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:23:17.488493
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters

    # Jinja2 is new enough
    if not HAS_URLENCODE:
        assert 'urlencode' in filters



# Generated at 2022-06-23 10:23:27.134048
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%21') == u'!'
    assert do_urldecode(u'%2B') == u'+'
    assert do_urldecode(u'%25') == u'%'
    assert do_urldecode(u'%7F') == u'\x7f'
    assert do_urldecode(u'%7f') == u'\x7f'
    assert do_urldecode(u'%7b') == u'{'
    assert do_urldecode(u'%7B') == u'{'
    assert do_urldecode(u'%7C') == u'|'
    assert do_urldecode(u'%7d') == u'}'
    assert do_urldec

# Generated at 2022-06-23 10:23:35.605561
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    import jinja2
    env = jinja2.Environment()

    assert FilterModule().filters() == { 'urldecode': do_urldecode }
    assert 'urldecode' in env.filters

    env.filters['urldecode'] = do_urldecode
    assert 'urldecode' in env.filters
    assert do_urldecode == env.filters['urldecode']



# Generated at 2022-06-23 10:23:43.130050
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"\"Aardvarks lurk, OK?\"") == u'%22Aardvarks%20lurk%2C%20OK%3F%22'
    assert do_urlencode(u"Æbelø") == u'%C3%86bel%C3%B8'
    assert do_urlencode(u"Jägermeister") == u'J%C3%A4germeister'
    assert do_urlencode(u"κάβο") == u'%CE%BA%E1%B8%8D%E1%B8%B2%CE%BF'

# Generated at 2022-06-23 10:23:46.037612
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Tests if all filters can be imported
    from ansible.module_utils.hashivault import filters


# Generated at 2022-06-23 10:23:49.224207
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%40%23+%25+%3f+%2f+%26'
    assert unicode_urldecode(string) == '@23 % ? / &'



# Generated at 2022-06-23 10:24:01.349815
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic
    import sys
    if sys.version_info < (3, 0):
        basic.ANSIBLE_PYTHON_INTERPRETER = '/usr/bin/env python2'
    else:
        basic.ANSIBLE_PYTHON_INTERPRETER = '/usr/bin/env python3'
    b_ansible_python_interpreter = basic.to_bytes(basic.ANSIBLE_PYTHON_INTERPRETER)
    output = basic._json_loads(basic._executor(b_ansible_python_interpreter + b" -c 'import urllib,sys;"
                                       b"print(urllib.quote_plus(sys.argv[1]))'", (to_bytes("/'?=&"),)))

# Generated at 2022-06-23 10:24:11.429105
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('%') == '%'
    assert unicode_urldecode('%%20') == '% '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%C3%A9') == 'é'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('a+b') == 'a+b'
    assert unicode_urldecode('%3D') == '='

# Generated at 2022-06-23 10:24:14.440493
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:24:27.145824
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Taken from tests in urllib.parse
    assert unicode_urlencode('http://www.example.com/~user/') == 'http%3A%2F%2Fwww.example.com%2F~user%2F'
    assert unicode_urlencode('http://www.example.com/~user/?foo=bar') == 'http%3A%2F%2Fwww.example.com%2F~user%2F%3Ffoo%3Dbar'
    assert unicode_urlencode('http://www.example.com/~user/?foo=bar', for_qs=True) == 'http%3A%2F%2Fwww.example.com%2F~user%2F%3Ffoo%3Dbar'

# Generated at 2022-06-23 10:24:32.705605
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test for method filters of class FilterModule
    module = FilterModule()

    assert module.filters()['urldecode']("hello%20world") == "hello world"
    assert module.filters()['urldecode']("hello+world") == "hello world"
    assert module.filters()['urldecode']("hello world") == "hello world"

# Generated at 2022-06-23 10:24:41.133031
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    test_cases = [
        (u'abc', u'abc'),
        (u'a+b', u'a%2Bb'),
        ([u'a', u'b', u'c'], u'a&b&c'),
        ({u'a': u'b', u'c': u'd'}, u'a=b&c=d'),
        ({u'a': u'b c', u'd': u' '}, u'a=b+c&d=+'),
    ]
    for test_input, expected in test_cases:
        actual = unicode_urlencode(test_input)

# Generated at 2022-06-23 10:24:44.360814
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters



# Generated at 2022-06-23 10:24:46.798988
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule()
    filters = o.filters()
    assert filters['urldecode'] == do_urldecode


# Generated at 2022-06-23 10:24:59.056111
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert '%C3%A7%C3%B5%C3%A9%C3%A0%C3%B1%C3%A8%C3%AA%C3%AD' == unicode_urlencode(u'çõéàñèêí')
    assert '%C3%A7%C3%B5%C3%A9%C3%A0%C3%B1%C3%A8%C3%AA%C3%AD' == unicode_urlencode(u'çõéàñèêí'.encode('utf-8'))

# Generated at 2022-06-23 10:25:01.918499
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert isinstance(unicode_urlencode('false'), str)


# Generated at 2022-06-23 10:25:03.454761
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')

# Generated at 2022-06-23 10:25:13.751809
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'àéîöü') == u'%C3%A0%C3%A9%C3%AE%C3%B6%C3%BC'
    assert do_urlencode({ u'àéîöü': u'àéîöü' }) == u'%C3%A0%C3%A9%C3%AE%C3%B6%C3%BC=%C3%A0%C3%A9%C3%AE%C3%B6%C3%BC'

# Generated at 2022-06-23 10:25:21.422597
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'föö') == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo ') == u'foo+'
    assert do_urlencode(u' foo') == u'+foo'
    assert do_urlencode(u' foo ') == u'+foo+'
    assert do_urlencode(u"foo's bar") == u"foo's+bar"
    assert do_urlencode(u'foo=bar&foo=baz') == u'foo=bar&foo=baz'
    assert do_urlencode(u'http://example.com') == u'http%3A//example.com'
    assert do_url

# Generated at 2022-06-23 10:25:29.096574
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2F%2B%20') == u'/+ '



# Generated at 2022-06-23 10:25:33.932497
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+bar%25') == 'foo bar%'


# Generated at 2022-06-23 10:25:40.516354
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'test%20string') == u'test string'
    assert unicode_urldecode(u'%F0%9F%92%A9') == u'\U0001f4a9'
    assert unicode_urldecode('test string') == u'test string'
    assert unicode_urldecode('%F0%9F%92%A9') == u'\U0001f4a9'


# Generated at 2022-06-23 10:25:47.344620
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('&') == '%26')
    assert(do_urlencode('&&') == '%26%26')
    assert(do_urlencode(['&']) == '%26')
    assert(do_urlencode(('&',)) == '%26')
    assert(do_urlencode(('&', '&&')) == '%26&%26%26')
    assert(do_urlencode([('&', '&&')]) == '%26=%26%26')
    assert(do_urlencode([('&', '&&'), ('&', '&')]) == '%26=%26%26&%26=%26')
    assert(do_urlencode({'&': '&'}) == '%26=%26')

# Generated at 2022-06-23 10:25:52.610243
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    assert isinstance(f, dict)
    assert 'urldecode' in f
    assert f['urldecode'] == do_urldecode
    assert 'urlencode' in f
    assert f['urlencode'] == do_urlencode

