

# Generated at 2022-06-23 10:15:56.169811
# Unit test for function do_urldecode
def test_do_urldecode():
    if PY3:
        expected = u'data=%5BJavaScript+can+be+a+pain%5D'
    else:
        expected = u'data=[JavaScript can be a pain]'
    assert unicode_urldecode(u'data%3D%5BJavaScript+can+be+a+pain%5D') == expected


# Generated at 2022-06-23 10:16:06.299934
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'wieers.com') == u'wieers.com'
    assert do_urlencode(u'wieers.com/a&b?') == u'wieers.com%2Fa%26b%3F'
    assert do_urlencode([u'wieers.com', u'a&b?']) == u'wieers.com&a%26b%3F'
    assert do_urlencode({u'w': u'wieers.com', u'a': u'a&b?'}) == u'w=wieers.com&a=a%26b%3F'

# Generated at 2022-06-23 10:16:08.309706
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()

# Generated at 2022-06-23 10:16:12.492686
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fm_filters = fm.filters()
    assert isinstance(fm_filters, dict)
    assert len(fm_filters) == 2
    assert 'urldecode' in fm_filters
    assert 'urlencode' in fm_filters


# Generated at 2022-06-23 10:16:24.709209
# Unit test for function do_urlencode
def test_do_urlencode():
    assert b"/a%3Fb/c%26d" == do_urlencode('/a?b/c&d')
    assert b"/a%3Fb/c%26d" == do_urlencode('/a?b/c&d')
    assert "a=c%21&b=d%2B" == do_urlencode({'b': 'd+', 'a': 'c!'})
    assert "a=c%21&a=d%2B" == do_urlencode([('a', 'c!'), ('a', 'd+')])
    assert "a=c%21&a=d%2B" == do_urlencode(set([('a', 'c!'), ('a', 'd+')]))
    assert "a=2&a=1" == do_

# Generated at 2022-06-23 10:16:26.257471
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:16:31.356668
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"http://example.com/some/path?a=1&b=2") == u"http://example.com/some/path?a=1&b=2", "urlencode (1)"
    assert unicode_urlencode(u"http://example.com/some/path?a=1&b=2", for_qs=True) == u"http%3A//example.com/some/path%3Fa%3D1%26b%3D2", "urlencode (2)"

# Generated at 2022-06-23 10:16:32.890744
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    assert isinstance(filtermodule.filters(), dict)



# Generated at 2022-06-23 10:16:37.697174
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    actual = filter_module.filters()
    assert actual['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert actual['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:16:45.930152
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # testing method urldecode of class FilterModule
    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except ImportError:
        HAS_URLENCODE = False

    class MockFilterModule(object):
        def filters(self):
            filters = {
                'urldecode': do_urldecode,
            }

            if not HAS_URLENCODE:
                filters['urlencode'] = do_urlencode

            return filters

    mock_FilterModule = MockFilterModule()
    assert(mock_FilterModule)

    results = mock_FilterModule.filters()
    assert(results)
    assert(type(results) == dict)

    # testing method do_urldecode
    test_string = 'Wayne%27s+World'

# Generated at 2022-06-23 10:16:52.365815
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('foo') == 'foo')
    assert(do_urlencode('foo bar') == 'foo%20bar')
    assert(do_urlencode('foo+bar') == 'foo%2Bbar')
    assert(do_urlencode('foo/bar') == 'foo/bar')
    assert(do_urlencode('foo?bar') == 'foo%3Fbar')
    assert(do_urlencode(u'H\xe9l\xf2o') == u'H%C3%A9l%C3%B2o')
    assert(do_urlencode('foo=bar') == 'foo%3Dbar')
    assert(do_urlencode('foo&bar') == 'foo%26bar')

# Generated at 2022-06-23 10:17:00.257840
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%26') == '&'

    assert do_urldecode('%25') == '%'
    assert do_urldecode('%2525') == '%25'

    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%252B') == '%2B'

    assert do_urldecode('%2F') == '/'
    assert do_urldecode('/%2F') == '/'

# Generated at 2022-06-23 10:17:02.130263
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    assert filterModule is not None

# Generated at 2022-06-23 10:17:08.197798
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/var/www/f%') == '%2Fvar%2Fwww%2Ff%25'
    assert unicode_urlencode('/var/www/f%', for_qs=True) == '%2Fvar%2Fwww%2Ff%25'
    assert unicode_urlencode(u'unicode') == u'unicode'


# Generated at 2022-06-23 10:17:14.252369
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'key': 'value'}) == 'key=value'
    assert do_urlencode({'key': 'value', 'foo': 'bar'}) == 'key=value&foo=bar'
    assert do_urlencode({'key': ['value', 'foo']}) == 'key=value&key=foo'
    assert do_urlencode(['key=value', 'foo=bar']) == 'key%3Dvalue&foo%3Dbar'
    assert do_urlencode('key=value') == 'key%3Dvalue'


# Generated at 2022-06-23 10:17:24.676797
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'this+that') == u'this%2Bthat'
    assert unicode_urlencode(u'@') == u'%40'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'



# Generated at 2022-06-23 10:17:29.232481
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.module_utils.jinja2

    fm = ansible.module_utils.jinja2.FilterModule()
    filters = fm.filters()

    assert 'urldecode' in filters
    assert not getattr(filters['urldecode'], '__self__')
    assert callable(filters['urldecode'])

    assert 'urlencode' in filters
    assert not getattr(filters['urlencode'], '__self__')
    assert callable(filters['urlencode'])

# Generated at 2022-06-23 10:17:36.215137
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fwww.example.com') == u'http://www.example.com'
    assert unicode_urldecode(u'http%3a%2f%2fwww.example.com') == u'http://www.example.com'


# Generated at 2022-06-23 10:17:46.293941
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_list = [
        ['a%20b%20c', 'a b c'],
        ['a%C3%A4b', 'aäb'],
        ['%F0%9F%99%83%F0%9F%8C%A3', '\U0001F643\U0001F30B'],
    ]
    for unescaped, escaped in test_list:
        assert unicode_urldecode(escaped) == unescaped
        assert unicode_urldecode(unescaped) == unescaped


# Generated at 2022-06-23 10:17:50.599517
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%40') == '@'
    assert do_urldecode(u'%E3%81%82'.encode('utf-8')) == u'あ'


# Generated at 2022-06-23 10:17:55.550208
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('abc+def') == 'abc def'
    assert do_urldecode('abc%2Bdef') == 'abc+def'
    assert do_urldecode({'a': 'b+c', 'd': 'e f'}) == 'a=b c&d=e+f'


# Generated at 2022-06-23 10:18:00.873720
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%2f') == u'/'
    assert do_urldecode('%2f') != u'%2f'
    assert do_urldecode('/') == u'/'
    assert do_urldecode('/') != u'%2f'



# Generated at 2022-06-23 10:18:07.618931
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/?bar=baz') == u'http%3A//foo/%3Fbar%3Dbaz'
    assert unicode_urlencode({'bar': 'baz'}) == u'bar=baz'
    assert unicode_urlencode({'bar': 'baz', 'boo': 'boz'}) == u'bar=baz&boo=boz'
    assert unicode_urlencode({'bar': ['baz', 'boz']}) == u'bar=baz&bar=boz'

# Generated at 2022-06-23 10:18:18.608458
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:18:27.524883
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Tests
    assert unicode_urlencode('test') == 'test'
    assert unicode_urlencode('test test') == 'test%20test'
    assert unicode_urlencode('test/test') == 'test%2Ftest'
    assert unicode_urlencode('test test', for_qs=True) == 'test+test'
    assert unicode_urlencode('test/test', for_qs=True) == 'test%2Ftest'
    assert unicode_urlencode('@ test') == '%40%20test'
    assert unicode_urlencode('@ test', for_qs=True) == '%40+test'
    assert unicode_urlencode('one+two&three=four') == 'one%2Btwo%26three%3Dfour'
    assert unicode

# Generated at 2022-06-23 10:18:35.453460
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import sys
    import warnings

    obj = FilterModule()
    try:
        obj.filters()
    except Exception as exc:
        if PY3:
            if not issubclass(exc.__class__, DeprecationWarning):
                raise
        else:
            warnings.warn("FilterModule_filters", DeprecationWarning, stacklevel=2)
            if not issubclass(exc.__class__, DeprecationWarning):
                raise
    else:
        pass
    return



# Generated at 2022-06-23 10:18:45.652057
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('key') == 'key'
    assert unicode_urlencode('key with spaces') == 'key%20with%20spaces'
    assert unicode_urlencode('key+with+pluses') == 'key%2Bwith%2Bpluses'
    assert unicode_urlencode('key with /slashes') == 'key%20with%20%2Fslashes'
    assert unicode_urlencode('key with ?query') == 'key%20with%20%3Fquery'
    assert unicode_urlencode('key with ?query') == 'key%20with%20%3Fquery'
    assert unicode_urlencode('key with &ampersands') == 'key%20with%20%26ampersands'

# Generated at 2022-06-23 10:18:47.086517
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        x = FilterModule()
    except Exception as err:
        print(str(err))
        assert False
    assert True


# Generated at 2022-06-23 10:18:56.524369
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%25') == '%'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f%2F%25') == '//%'
    assert do_urldecode('%2f%2F%25%2') == '//%'
    assert do_urldecode(u'%2f%2F%25%2') == u'//%'
    assert do_urldecode(u'%2f%2F%25%') == u'//%'


# Generated at 2022-06-23 10:19:02.194425
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('hello world') == 'hello%20world'
    assert do_urlencode('hello% world') == 'hello%25%20world'
    assert do_urlencode({'hello world': 1337}) == 'hello%20world=1337'
    assert do_urlencode([{'hello world': 1337}]) == 'hello%20world=1337'



# Generated at 2022-06-23 10:19:12.029204
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'a=1 2') == u'a%3D1%202'
    assert do_urlencode(u'a=1 2') == u'a%3D1%202'

    assert do_urlencode({'a': 1, 'b': 2}) == u'a=1&b=2'
    assert do_urlencode({'a': 1, 'b': 2}) == u'a=1&b=2'
    assert do_urlencode([('a', 1), ('b', 2)]) == u'a=1&b=2'
    assert do_urlencode([('a', 1), ('b', 2)]) == u'a=1&b=2'

# Generated at 2022-06-23 10:19:19.640640
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import pytest

    assert unicode_urlencode('/path/with spaces') == '/path/with%20spaces'
    assert unicode_urlencode('/path/with spaces', for_qs=True) == '/path/with+spaces'
    assert unicode_urlencode('/path/with+spaces', for_qs=True) == '/path/with%2Bspaces'
    assert unicode_urlencode('/path/with%20spaces', for_qs=True) == '/path/with%20spaces'
    assert unicode_urlencode(123) == '123'
    if PY3:
        with pytest.raises(TypeError):
            unicode_urlencode(b'/path/with spaces')
        with pytest.raises(TypeError):
            unicode_

# Generated at 2022-06-23 10:19:31.666492
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})

    assert "eyJoZWxsbyI6d2VhciJ9" == module.do_urlencode("{\"hello\":wear}")
    assert "eyJoZWxsbyI6d2VhciJ9" == module.do_urlencode(module.from_json("{\"hello\":wear}"))
    assert "eyJoZWxsbyI6d2VhciJ9" == module.do_urlencode({u"hello": u"wear"})
    assert "Hello%20Wear" == module.do_urlencode("Hello Wear")
    assert "Hello%20Wear" == module.do_urlencode(u"Hello Wear")


# Generated at 2022-06-23 10:19:33.000659
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter.filters()

# Generated at 2022-06-23 10:19:43.836643
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('&') == u'%26'
    assert unicode_urlencode('nick@example.com') == u'nick@example.com'
    assert unicode_urlencode('this is %20 text') == u'this%20is%20%20text'
    assert unicode_urlencode('!@#$%^&*()') == u'%21%40%23%24%25%5E%26%2A%28%29'
    assert unicode_urlencode('http://example.com') == u'http%3A//example.com'

# Generated at 2022-06-23 10:19:45.847091
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()
# test_FilterModule()


# Generated at 2022-06-23 10:19:53.023408
# Unit test for function do_urlencode
def test_do_urlencode():
    # Success test cases
    value = 'www.google.com'
    result = do_urlencode(value)
    assert result == to_text('www.google.com')

    value = {'q': 'iPhone 11'}
    result = do_urlencode(value)
    assert result == to_text('q=iPhone+11')

    value = {'q': 'iPhone 11', 'client': 'firefox'}
    result = do_urlencode(value)
    assert result == to_text('q=iPhone+11&client=firefox')

    # Failure test cases
    value = None
    result = do_urlencode(value)
    assert result == to_text('')

    value = 0
    result = do_urlencode(value)
    assert result == to_text('')



# Generated at 2022-06-23 10:19:54.702845
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%7Echris%21') == '~chris!'


# Generated at 2022-06-23 10:19:56.568409
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Test FilterModule constructor
    """

    test_filter_module = FilterModule()
    assert(test_filter_module is not None)

# Generated at 2022-06-23 10:19:58.408369
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule is not None
    assert filtermodule.filters is not None

# Generated at 2022-06-23 10:20:09.151406
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    examples = [
        (u'abc', b'abc'),
        (u'abc def', b'abc+def'),
        (u'http://server.example.com/resource%20one/foo?a=b&c=d', b'http%3A%2F%2Fserver.example.com%2Fresource%2520one%2Ffoo%3Fa%3Db%26c%3Dd'),
        (u'http://server.example.com/resource%20one/foo?a=b;c=d', b'http%3A%2F%2Fserver.example.com%2Fresource%2520one%2Ffoo%3Fa%3Db%3Bc%3Dd'),
    ]


# Generated at 2022-06-23 10:20:14.143615
# Unit test for function do_urlencode
def test_do_urlencode():
    # NOTE: The following tests have been copied from Jinja2's urlencode filter
    assert do_urlencode(u'') == u''
    assert do_urlencode(u'test') == u'test'
    assert do_urlencode(u'test&blah') == u'test%26blah'
    assert do_urlencode(u'test&blah') == u'test%26blah'
    assert do_urlencode(u'test&amp;blah') == u'test%26amp%3Dblah'
    assert do_urlencode({u'foo': u'bar', u'blub': u''}) == u'foo=bar&blub='

# Generated at 2022-06-23 10:20:17.629180
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20space%20char') == 'a space char'
    assert unicode_urldecode(u'a%20space%20char') == u'a space char'



# Generated at 2022-06-23 10:20:27.434208
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("abc") == u'abc'
    assert do_urldecode("abc123,./") == u'abc123,./'
    assert do_urldecode("%20%21%2A%27%28%29") == u' !*\'()'
    assert do_urldecode("%25") == u'%'
    assert do_urldecode("%C3%A9") == u'é'
    assert do_urldecode("%2525") == u'%25'
    assert do_urldecode("%252525") == u'%25%25'


# Generated at 2022-06-23 10:20:41.243730
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import ansible.module_utils.core.filters
    import dictdiffer

    assert ansible.module_utils.core.filters.FilterModule
    assert FilterModule

    filter_module_class = ansible.module_utils.core.filters.FilterModule
    filter_module_instance = filter_module_class()

    filter_module_filters_dict = filter_module_instance.filters()

    filter_module_filters_attributes = dir ( filter_module_instance )
    filter_module_filters_attributes = [ item for item in filter_module_filters_attributes if item.endswith('filters') and not item.startswith('_') ]

    assert filter_module_filters_attributes == [ 'filters' ]
    assert list(filter_module_filters_dict) == list

# Generated at 2022-06-23 10:20:47.251673
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    filter = FilterModule()
    filters = filter.filters()
    assert filters['urldecode']("%20%22%2A") == " %22*"
    assert filters['urldecode']("%20%22%2A") == " %22*"
    if hasattr(filters, 'urlencode'):
        assert filters['urlencode']("%20%22%2A") == "%20%22%2A"
        assert filters['urlencode'](" %22*") == "%20%22*"

# Generated at 2022-06-23 10:20:49.528834
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo=bar') == 'foo=bar'
    assert unicode_urldecode('ansible%2Btest') == 'ansible+test'


# Generated at 2022-06-23 10:20:55.609983
# Unit test for function do_urldecode
def test_do_urldecode():

    assert(unicode_urldecode("test%20&%20test") == "test & test")
    assert(unicode_urldecode("test+%26+test") == "test+&+test")
    assert(unicode_urldecode("test%2F%2Ftest") == "test//test")
    assert(unicode_urldecode("test/%2F/test") == "test//test")



# Generated at 2022-06-23 10:20:59.897835
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import types
    fm = FilterModule()

    assert isinstance(fm, FilterModule)
    assert isinstance(fm.filters, types.FunctionType)
    assert 'urldecode' in fm.filters().keys()
    assert 'urlencode' in fm.filters().keys()
    return True

# Generated at 2022-06-23 10:21:09.718893
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode('foo+bar', for_qs=True) == 'foo%2Bbar'
    assert unicode_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'


# Generated at 2022-06-23 10:21:14.147917
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('fr%C3%A9d%C3%A9ric') == u'frédéric'
    assert unicode_urldecode('fr%E9d%E9ric') == u'frédéric'


# Generated at 2022-06-23 10:21:20.879519
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%20bar') == 'foo%2520bar'
    assert do_urlencode('foo bar/baz') == 'foo%20bar/baz'
    assert do_urlencode('foo bar/baz') == 'foo%20bar/baz'
    assert do_urlencode({'foo': 'bar', 'spam': 'eggs'}) == 'foo=bar&spam=eggs'
    assert do_urlencode([('foo', 'bar'), ('spam', 'eggs')]) == 'foo=bar&spam=eggs'


# Generated at 2022-06-23 10:21:24.108570
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert type(unicode_urldecode('Hello%20World')) is unicode
    assert unicode_urldecode('Hello%20World') == 'Hello World'



# Generated at 2022-06-23 10:21:28.623636
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {
        'urlencode': do_urlencode,
        'urldecode': do_urldecode,
    }

# Generated at 2022-06-23 10:21:40.072191
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    examples = [
        {'encoded': 'example.com', 'decoded': u'example.com'},
        {'encoded': 'ex%20amp%3b%3d%3f', 'decoded': u'ex amp&=?'},
        {'encoded': 'example.com%2fpath%2f', 'decoded': u'example.com/path/'},
        {'encoded': '%26%26%26%26', 'decoded': u'&&&&'},
        {'encoded': '', 'decoded': u''},
    ]

    for example in examples:
        assert unicode_urlencode(example['decoded']) == example['encoded']
        assert unicode_urldecode(example['encoded']) == example['decoded']



# Generated at 2022-06-23 10:21:43.187155
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-23 10:21:50.410542
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def?a=1') == u'abc%2Fdef%3Fa%3D1'
    assert unicode_urlencode(u'abc/def?a=1', for_qs=True) == u'abc%2Fdef%3Fa%3D1'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'


# Generated at 2022-06-23 10:21:52.351400
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:21:58.028589
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import ansible.module_utils.core as core

    # Test url decode filter
    assert core.FilterModule().filters()['urldecode']('test1%3D%3Dtest2%26test3~') == 'test1==test2&test3~'

    # Test url encode filter
    assert core.FilterModule().filters()['urlencode']({'test1': 'value1'}) == 'test1=value1'
    assert core.FilterModule().filters()['urlencode']('test1=value1') == 'test1%3Dvalue1'

# Generated at 2022-06-23 10:22:04.967967
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:22:16.744750
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:22:19.642414
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import ansible.plugins.filter.core
    assert isinstance(ansible.plugins.filter.core.FilterModule(), FilterModule)

# Unit tests for function unicode_urldecode

# Generated at 2022-06-23 10:22:22.132597
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == dict(urldecode=do_urldecode, urlencode=do_urlencode)


# Generated at 2022-06-23 10:22:31.261535
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_seq_of_strings
    assert not HAS_URLENCODE

    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert isinstance(filters, dict)

    assert filters[u'urldecode'] is do_urldecode
    assert filters[u'urlencode'] is do_urlencode

    assert do_urldecode(u'%24') == u'$'
    assert do_urldecode(u'%3a') == u':'
    assert do_urldecode(u'abc') == u'abc'

    assert do_urlencode(u'%') == u'%25'
    assert do_urlencode

# Generated at 2022-06-23 10:22:39.390803
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == 'foo'
    assert do_urlencode(u'foo\nbar') == 'foo%0Abar'
    assert do_urlencode([(u'foo', 42), (u'bar', 43), u'foo']) == 'foo=42&bar=43&foo'
    assert do_urlencode({u'foo': 42, u'bar': 43}) == 'foo=42&bar=43'

# Generated at 2022-06-23 10:22:40.907072
# Unit test for constructor of class FilterModule
def test_FilterModule():
    do_urldecode("https://ansible.com/test")

# Generated at 2022-06-23 10:22:47.820753
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%82%A2%E3%81%84%E3%81%BF') == u'あいみ'
    assert unicode_urldecode('%E3%82%A2%E3%81%84%E3%81%BF') == u'あいみ'
    assert unicode_urldecode('%e3%82%a2%e3%81%84%e3%81%bf') == u'あいみ'
    assert unicode_urldecode('%E3%82%A2%C2%A0%E3%81%BF') == u'あ み'
    assert unicode_urldecode('%E3%82%A2%C2%A0%E3%81%BF')

# Generated at 2022-06-23 10:22:55.773570
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode(u'abc def') == u'abc%20def'
    assert do_urlencode(u'abc def') == u'abc%20def'
    assert do_urlencode(u'abc/def') == u'abc%2Fdef'
    assert do_urlencode(u'abc/def?') == u'abc%2Fdef%3F'
    assert do_urlencode({'x': 1}) == u'x=1'
    assert do_urlencode({'x': 1, 'y': 2}) == u'x=1&y=2'
    assert do_urlencode({'x': u'a b'}) == u'x=a%20b'
    assert do_urlen

# Generated at 2022-06-23 10:22:57.412544
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%20b+%C3%A9") == u"a b é"

# Generated at 2022-06-23 10:22:59.309204
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = u'æøå'
    assert unicode_urldecode(unicode_urlencode(s)) == s


# Generated at 2022-06-23 10:23:05.407268
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'+') == u'%2B'
    assert unicode_urlencode(u'hello world') == u'hello%20world'
    assert unicode_urlencode(u'hello world', for_qs=True) == u'hello+world'


# Generated at 2022-06-23 10:23:07.195368
# Unit test for constructor of class FilterModule
def test_FilterModule():

    result=FilterModule()
    result.filters()

    return "Success"


# Generated at 2022-06-23 10:23:15.367286
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode({u'foo': u'bar', u'baz': u'qux'}) == u'baz=qux&foo=bar'
    assert do_urlencode(((u'foo', u'bar'), (u'baz', u'qux'))) == u'foo=bar&baz=qux'
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode(42) == u'42'

# Generated at 2022-06-23 10:23:25.955792
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"/") == u"/"
    assert do_urlencode(u"/asdf") == u"/asdf"
    assert do_urlencode({u'a': u'foo', u'b': u'bar'}) == u'a=foo&b=bar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode(u"/asdf/?a=foo&b=bar") == u"/asdf/?a=foo&b=bar"
    assert do_urlencode(u"/asdf/?a=foo&b=bar/") == u"/asdf/?a=foo&b=bar"
    assert do_urlencode([u"a", u"b", u"c"])

# Generated at 2022-06-23 10:23:31.520996
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode({"a":"a","b":"b"}) == "a=a&b=b"
    assert unicode_urlencode(["ab","cd"]) == "ab&cd"
    assert unicode_urlencode("ab") == "ab"

# Generated at 2022-06-23 10:23:41.017953
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:23:49.737931
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import ansible

    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except ImportError:
        HAS_URLENCODE = False

    x = FilterModule()
    assert x.filters().get('urldecode')('foo') == 'foo'
    if not HAS_URLENCODE:
        assert x.filters().get('urlencode')({'a': 'b'}) == 'a=b'



# Generated at 2022-06-23 10:23:57.730172
# Unit test for function do_urldecode
def test_do_urldecode():
    # basic tests
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%40') == u'@'
    assert do_urldecode('%25') == u'%'

    # Test whether the string is left unchanged if it's not in the right format
    assert do_urldecode('nothing to decode') == u'nothing to decode'

    # Test the quoting of special characters
    assert do_urldecode('%5E%60%7B%7C%7D%7E') == u'^`{|}~'

    # Test the functionality of the decoding of +, space should be replaced with +
    assert do_urldecode('%2B%20') == u'+ '

    # Test the functionality of the decoding of +, space should be replaced with

# Generated at 2022-06-23 10:24:08.164161
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/abc') == '/abc'
    assert unicode_urlencode('?') == '%3F'
    assert unicode_urlencode('?') == '%3F'
    assert unicode_urlencode('?/') == '%3F/'
    assert unicode_urlencode('*/') == '*/'
    assert unicode_urlencode('/a b') == '/a%20b'
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('/a b') == '/a%20b'

# Generated at 2022-06-23 10:24:14.305391
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert fm.filters()['urldecode']('a+%C3%BC+&c+') == u'a ü &c '
    assert fm.filters()['urldecode']('a+%C3%BC+&c+') == u'a ü &c '

    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('a ü &c ') == u'a+%C3%BC+&c+'
        assert fm.filters()['urlencode']({'a ü': '&c '}) == u'a+%C3%BC=&c+'

# Generated at 2022-06-23 10:24:18.083075
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' FilterModule.__init__() units tests'''
    assert 'urldecode' in FilterModule().filters()
    assert 'urlencode' in FilterModule().filters()

# Generated at 2022-06-23 10:24:29.708530
# Unit test for function do_urldecode
def test_do_urldecode():
    def test_do_urldecode_value(expected, value):
        result = do_urldecode(value)
        assert result == expected, "'%s' != '%s'" % (result, expected)

    test_do_urldecode_value('\u00e4', '%C3%A4')
    test_do_urldecode_value('\u20ac', '%E2%82%AC')
    test_do_urldecode_value('\u00e4\u20ac', '%C3%A4%E2%82%AC')
    test_do_urldecode_value('\u00e4\u20ac', '%C3%A4%E2%82%AC')


# Generated at 2022-06-23 10:24:31.893476
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode
    }


# Generated at 2022-06-23 10:24:40.069344
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("hello world") == "hello%20world"
    assert do_urlencode("hello   world") == "hello%20%20%20world"
    assert do_urlencode("hello / world") == "hello%20/%20world"
    assert do_urlencode("hello&world") == "hello%26world"
    assert do_urlencode("hello&world") == "hello%26world"
    assert do_urlencode({"test": "hello world"}) == "test=hello%20world"
    assert do_urlencode(["test", "hello world"]) == "test&hello%20world"
    assert do_urlencode("hello&world") == "hello%26world"

# Generated at 2022-06-23 10:24:52.068395
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%20") == " ", "Failed decoding %20 to \" \"."
    assert do_urldecode("%3A") == ":", "Failed decoding %3A to \":\"."
    assert do_urldecode("%22") == "\"", "Failed decoding %22 to \"\\\"\"."
    assert do_urldecode("%2C") == ",", "Failed decoding %2C to \",\"."
    assert do_urldecode("%7B") == "{", "Failed decoding %7B to \"{{\"."
    assert do_urldecode("%7D") == "}", "Failed decoding %7D to \"}}\"."

# Generated at 2022-06-23 10:24:56.249483
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fgithub.com%2Fansible%2Fansible') == 'https://github.com/ansible/ansible'

# Generated at 2022-06-23 10:25:03.768409
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'one%3Dtwo%3Dthree' == do_urlencode({'one': 'two=three'})
    assert 'one%2Ctwo%2Cthree' == do_urlencode(['one', 'two', 'three'])
    assert 'one%26two%26three' == do_urlencode('one&two&three')
    assert 'one%2Btwo%2Bthree' == do_urlencode('one+two+three')
    assert 'one%2Ctwo%2Cthree' == do_urlencode('one,two,three')
    assert 'one%3Atwo%3Athree' == do_urlencode('one:two:three')



# Generated at 2022-06-23 10:25:14.052757
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%3Db%26c%3Dd") == "a=b&c=d"
    assert unicode_urldecode("a=b&c=d") == "a=b&c=d"
    assert unicode_urldecode("a=b%26c=d") == "a=b&c=d"
    assert unicode_urldecode("a%26b=c%26d") == "a&b=c&d"
    assert unicode_urldecode("a%3db=c%3dd") == "a=b=c=d"
    assert unicode_urldecode("1abc_._~-") == "1abc_._~-"

# Generated at 2022-06-23 10:25:26.370506
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:25:37.842721
# Unit test for function do_urlencode
def test_do_urlencode():
    import copy
    import collections


# Generated at 2022-06-23 10:25:42.514103
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("a%2Bb+%C3%A9%C3%A9+c%2Bd") == u"a+b éé c+d"
    assert do_urldecode("a+b+c%2Bd") == u"a b c+d"


# Generated at 2022-06-23 10:25:55.076142
# Unit test for function do_urldecode