

# Generated at 2022-06-23 10:15:59.426094
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo bar foo') == u'foo%20bar%20foo'
    assert do_urlencode(u'foo/bar/foo') == u'foo%2Fbar%2Ffoo'
    assert do_urlencode(u'foo bar foo') == do_urlencode('foo bar foo')
    assert do_urlencode({u'foo': [u'bar', u'baz']}) == u'foo=bar&foo=baz'
    assert do_urlencode([u'foo', {u'bar': u'baz'}]) == u'foo=&bar=baz'
    assert do_urlencode([u'foo', {u'bar': u'baz'}]) == do_urlencode(u'foo&bar=baz')
    assert do_

# Generated at 2022-06-23 10:16:07.723562
# Unit test for function do_urldecode
def test_do_urldecode():
    a_url = 'http://localhost:8080/api/v1/namespaces/openshift-infra/replicationcontrollers?labelSelector=%2Fredhat.com%2Fdeployment%2Fapp%2Fname%2Fhost-monitoring&fieldSelector=.metadata.name%3D%3D%3Dhost-monitoring-v3-kn831'
    assert a_url == do_urldecode(do_urlencode(a_url))

# Generated at 2022-06-23 10:16:09.838657
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """ test FilterModule's constructor """
    import inspect
    assert inspect.isclass(FilterModule)


# Generated at 2022-06-23 10:16:13.982515
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Jinja2 will call this function only with unicode strings, so we need
    # a unicode string
    u = u'\xe9'
    if PY3:
        expected = quote_plus(u)
    else:
        expected = quote_plus(to_bytes(u))
    assert unicode_urlencode(u) == expected


# Generated at 2022-06-23 10:16:17.080174
# Unit test for constructor of class FilterModule
def test_FilterModule():
    tm = FilterModule()
    assert "urldecode" in list(tm.filters().keys())


# Generated at 2022-06-23 10:16:27.381744
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("España") == u"Espa%C3%B1a"
    assert unicode_urlencode("https://example.com/foo/bar?the=query") == u"https%3A%2F%2Fexample.com%2Ffoo%2Fbar%3Fthe%3Dquery"
    assert unicode_urlencode("https://example.com/foo/bar?the=query", for_qs=True) == u"https%3A%2F%2Fexample.com%2Ffoo%2Fbar%3Fthe%3Dquery"
    assert unicode_urlencode("hello *.* world") == u"hello+%2A.%2A+world"
    assert unicode_urlencode("hello *.* world", for_qs=True)

# Generated at 2022-06-23 10:16:39.304535
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("!*'();:@&=+$,/?#[]") == u'!*\'();:@&=+$,/?#[]'
    assert unicode_urlencode("azAZ09_!*'();:@&=+$,/?#[]-") == u'azAZ09_!*\'();:@&=+$,/?#[]-'

    assert unicode_urlencode("http://example.com:8080/a/b?a=b&c=d#foo?baz#bar", for_qs=True) == u'http%3A%2F%2Fexample.com%3A8080%2Fa%2Fb%3Fa%3Db%26c%3Dd%23foo%3Fbaz%23bar'

# Generated at 2022-06-23 10:16:47.202382
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == '/'
    assert do_urlencode('%') == '%25'
    assert do_urlencode('/%') == '/%25'
    assert do_urlencode(u'/%') == '/%25'
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode(u'foo') == 'foo'
    assert do_urlencode(u'/foo/bar') == '/foo/bar'
    assert do_urlencode(u'/foo/bar?a=b') == '/foo/bar?a=b'
    assert do_urlencode(u'/foo/bar?a=b&c=d') == '/foo/bar?a=b&c=d'

# Generated at 2022-06-23 10:16:51.267928
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert do_urldecode('%7B%22a%22%3A1%2C%22b%22%3A2%7D') == u'{"a":1,"b":2}'
    assert do_urlencode('{"a":1,"b":2}') == u'%7B%22a%22%3A1%2C%22b%22%3A2%7D'


if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:16:52.297153
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-23 10:16:54.870297
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' function unicode_urldecode returns a string '''

    assert(isinstance(unicode_urldecode(b''), string_types))


# Generated at 2022-06-23 10:16:58.972697
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode('foo%2F%2Fbar') == u'foo//bar'
    assert unicode_urldecode(u'foo%2F%2Fbar') == u'foo//bar'



# Generated at 2022-06-23 10:17:08.969098
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%C3%A9') == 'é'
    assert FilterModule().filters()['urldecode']('%25C3%25A9') == '%C3%A9'
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('é') == '%C3%A9'
        assert FilterModule().filters()['urlencode']('%C3%A9') == '%25C3%25A9'
        assert FilterModule().filters()['urlencode']('%25C3%25A9') == '%2525C3%2525A9'

# Generated at 2022-06-23 10:17:10.789859
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('This%20is%20a%20test') == 'This is a test'


# Generated at 2022-06-23 10:17:23.132600
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.compat import unittest
    from ansible.module_utils._text import to_bytes, to_text

    class TestFilterModule(unittest.TestCase):
        ''' Test class to hold unit tests for FilterModule() '''

        def setUp(self):
            self.FilterModule = FilterModule()

        def test_FilterModule_filters(self):
            ''' Test FilterModule.filters() '''
            self.assertEqual(self.FilterModule.filters(),
                             {'urldecode': do_urldecode,
                              'urlencode': do_urlencode})
    TestFilterModule().setUp()
    suite = unittest.TestLoader().loadTestsFromTestCase(TestFilterModule)

# Generated at 2022-06-23 10:17:25.797789
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == u'foo bar'


# Generated at 2022-06-23 10:17:37.641789
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    fltr = FilterModule()

    # Generate a dict of filter names and methods
    filters_dict = dict(fltr.filters())

    # Test do_urldecode filter
    result = filters_dict.get('urldecode').__call__("http%3A%2F%2Fwww.example.com%2F%3Fa%3D1%26b%3D2")
    assert result == "http://www.example.com/?a=1&b=2"

    if PY2:
        assert basic.is_bytes(result)

    # Test do_urlencode filter

# Generated at 2022-06-23 10:17:39.805245
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f.filters(), dict)

# Generated at 2022-06-23 10:17:46.045755
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b%20c') == 'a b c'
    assert unicode_urldecode('a+b+c') == 'a b c'
    assert unicode_urldecode('a%2Bb%2Bc') == 'a+b+c'


# Generated at 2022-06-23 10:17:55.907889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.jinja2.filters import FilterModule
    from ansible.module_utils.six import PY3

    fm = FilterModule()
    fm_dict = fm.filters()

    test_string_decode_utf8 = "this%20should%20be%20%C3%A0%20string%20%C3%A8"
    test_string_decode_latin1 = b"this%20should%20be%20%C3%A0%20string%20%C3%A8".decode('latin1')
    test_string_decode_latin1_py3 = "this%20should%20be%20%C3%A0%20string%20%C3%A8"
    urldecode_utf8 = fm

# Generated at 2022-06-23 10:18:00.520712
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'sa%3D') == u'sa='
    assert do_urldecode(u'sa%3D&%3Dsb') == u'sa=&=sb'
    assert do_urldecode(u'sa=&=sb') == u'sa=&=sb'


# Generated at 2022-06-23 10:18:07.874736
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(b'%22%20%23%24%25%5E%26%2A%28%29%3D%3B%3F%3A%3C%3E%2C%2F') == u'" #$%^&*()=;?:<>,/'
    assert do_urldecode(u'%22%20%23%24%25%5E%26%2A%28%29%3D%3B%3F%3A%3C%3E%2C%2F') == u'" #$%^&*()=;?:<>,/'


# Generated at 2022-06-23 10:18:18.871597
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a=b') == 'a=b'
    assert unicode_urldecode('a=b&c=d') == 'a=b&c=d'
    assert unicode_urldecode('%7B') == '{'
    assert unicode_urldecode('%7Ca=b') == '|a=b'
    assert unicode_urldecode('%7C') == '|'
    assert unicode_urldecode('a%20b') == 'a b'
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode('a%5Cb') == 'a\\b'

# Generated at 2022-06-23 10:18:27.686719
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Assume we have ansible.module_utils.six installed
    from ansible.module_utils.six import PY3

    # Prepare test data
    string = 'example'
    test_dict = {'key': 'value'}
    test_list = ['value1', 'value2', 'value3']

    # Instantiate class
    filter_module = FilterModule()
    filters = filter_module.filters()

    # Test urldecode
    assert filters['urldecode'](string) == 'example'
    assert filters['urldecode']('example%20') == 'example '
    assert filters['urldecode']('example+') == 'example '
    assert filters['urldecode'](test_dict) == "'key': 'value'"

# Generated at 2022-06-23 10:18:31.708468
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test the urldecode filter for correctness
    '''
    assert unicode_urldecode('%20%40') == u' @'
    assert unicode_urldecode('%20%40') == to_text(unquote_plus(b'%20%40'))



# Generated at 2022-06-23 10:18:33.316327
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('abc%2fxyz') == 'abc%2Fxyz'



# Generated at 2022-06-23 10:18:39.597231
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' do_urldecode should return an empty string on None,
        a unicode string on a unicode string, and a decoded
        unicode string on a encoded one
    '''

    assert do_urldecode(None) == ''
    assert do_urldecode('test') == u'test'
    assert do_urldecode('%C3%A9') == u'\xe9'

# Generated at 2022-06-23 10:18:45.957558
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:18:57.981804
# Unit test for function do_urlencode
def test_do_urlencode():
    input_data = {
        "some data": "some data",
        "примітка": "примітка",
        "a?b": "a?b",
        "name": "John Smith",
        "address": "125 Main Street",
        "dob": "10/06/1980",
        "loves": "pizza"
    }

# Generated at 2022-06-23 10:19:01.141588
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%C3%A4b') == u'a\xe4b'
    assert unicode_urldecode(u'a+b') == u'a b'


# Generated at 2022-06-23 10:19:07.487259
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode('spa ce') == 'spa+ce'
    assert do_urlencode('slash/') == 'slash%2F'
    assert do_urlencode('one,two') == 'one%2Ctwo'


# Generated at 2022-06-23 10:19:12.604114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%2B') == '+'
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('+') == '%2B'
        assert fm.filters()['urlencode']({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Generated at 2022-06-23 10:19:13.995264
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Unit test for the FilterModule constructor"""
    assert isinstance(FilterModule(), object)

# Generated at 2022-06-23 10:19:21.238598
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Check if the function implements a valid decoding
    decoding_test = [
        (u'a+b+c', u'a b c'),
        (u'%22test%22', u'"test"'),
        (u'%22test%22%20%23%20tag', u'"test" # tag')
    ]
    for string, expected in decoding_test:
        assert unicode_urldecode(string) == expected

    # Check if the function decodes any string
    for string in (u'test', u'15350', u'', u'%25'):
        assert unicode_urldecode(string) == string



# Generated at 2022-06-23 10:19:25.404303
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:19:27.445370
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-23 10:19:30.527936
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('%20') == '%2520'
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('a b', for_qs=True) == 'a+b'


# Generated at 2022-06-23 10:19:37.908390
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(b'%20%30') == u' 0'
    assert do_urldecode(u'%20%30') == u' 0'
    assert do_urldecode(u'%2F%3B') == u'/;'
    assert do_urldecode(u'%2f%3B') == u'%2f%3B'
    assert do_urldecode(u'abc%2F%3B') == u'abc%2F%3B'


# Generated at 2022-06-23 10:19:41.637747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-23 10:19:49.392584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) == u''
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%20c%20d') == u'abc c d'
    assert unicode_urldecode('abc%20c%20d%3') == u'abc c d%3'
    assert unicode_urldecode('abc%20c%20d%3%') == u'abc c d%3%'
    assert unicode_urldecode('%ab%20c%20d%a') == u'%ab c d%a'
    assert unicode_urldecode('%ab%20c%20d%a%') == u'%ab c d%a%'


# Generated at 2022-06-23 10:19:55.713663
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' test do_urlencode '''
    url = do_urlencode(dict(key='value',c='/',d=';'))
    assert url == u'key=value&c=%2F&d=%3B'
    url = do_urlencode(['a','b','c'])
    assert url == u'a&b&c'
    url = do_urlencode('c')
    assert url == u'c'
    url = do_urlencode(dict(c='/', d=';'))
    assert url == u'c=%2F&d=%3B'
    url = do_urlencode(dict(auch='tier'))
    assert url == u'auch=tier'


# Generated at 2022-06-23 10:20:03.078371
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%') == '%'
    assert do_urldecode('%2') == '%2'
    assert do_urldecode('%2a') == '*'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%23') == '#'
    assert do_urldecode('%24') == '$'
    assert do_urldecode('%25') == '%'

# Generated at 2022-06-23 10:20:11.714398
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except ImportError:
        HAS_URLENCODE = False

    fm = FilterModule()
    filters = fm.filters()

    assert (filters['urldecode']('foo')) is not None
    assert (filters['urldecode']('%40')) == u'@'
    assert (filters['urldecode']('%25')) == u'%'
    assert (filters['urldecode']('%2B')) == u'+'
    assert (filters['urldecode']('%2F')) == u'/'
    assert (filters['urldecode']('%5F')) == u'_'

# Generated at 2022-06-23 10:20:15.524088
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    expected_result = '%C3%A9'
    assert unicode_urlencode(expected_result) == expected_result

# Generated at 2022-06-23 10:20:23.124859
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('') == ''
    assert do_urldecode('redis://%40localhost/0') == 'redis://@localhost/0'
    assert do_urldecode('redis://localhost/%230') == 'redis://localhost/0'
    assert do_urldecode('redis://localhost/%2f') == 'redis://localhost/'
    assert do_urldecode('redis://%2flocalhost/%2f') == 'redis:///localhost/'
    assert do_urldecode('redis:///localhost/%2f') == 'redis:///localhost/'

# Generated at 2022-06-23 10:20:32.336491
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == u'foo'
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo%20bar') == u'foo%2520bar'
    assert unicode_urlencode(u'foo%20bar') == u'foo%2520bar'
    assert unicode_urlencode('foo@bar') == u'foo%40bar'
    assert unicode_urlencode(u'foo@bar') == u'foo%40bar'
    assert unicode_urlencode('foo/bar') == u'foo/bar'

# Generated at 2022-06-23 10:20:38.283238
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test with normal string
    assert unicode_urlencode('hello world') == 'hello%20world'

    # Test with string that requires encoding
    assert unicode_urlencode('hello world!') == 'hello%20world%21'

    # Test with integer
    assert unicode_urlencode(123) == '123'

    # Test that forward slash is not encoded
    assert unicode_urlencode('/usr/local/bin/') == '/usr/local/bin/'

    # Test that a forward slash is not encoded in query string
    assert unicode_urlencode('/usr/local/bin/', for_qs=True) == '%2Fusr%2Flocal%2Fbin%2F'

    # Test with dict

# Generated at 2022-06-23 10:20:41.849160
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'example%20%C3%A9xample') == u'example éxample'
    return 0


# Generated at 2022-06-23 10:20:44.836665
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()

    # Test return of method filters
    str_filters = str(obj.filters())
    assert str_filters == "{'urldecode': <function do_urldecode at 0x7f5f5e8f3268>, 'urlencode': <function do_urlencode at 0x7f5f5e8f3730>}"


# Generated at 2022-06-23 10:20:55.989163
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # PY2
    assert unicode_urlencode(u'hello world') == 'hello%20world'
    assert unicode_urlencode(u'hello world', for_qs=True) == 'hello+world'
    assert unicode_urlencode(u'/hello world') == '%2Fhello%20world'
    assert unicode_urlencode(u'hello / world') == 'hello%20%2F%20world'
    assert unicode_urlencode(u'hello%20world') == 'hello%2520world'

    # PY3
    assert unicode_urlencode('hello world') == 'hello%20world'
    assert unicode_urlencode('hello world', for_qs=True) == 'hello+world'

# Generated at 2022-06-23 10:20:57.368316
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:20:57.965138
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:21:05.769650
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('\x08') == '%08'
    assert do_urlencode('/tmp') == '%2Ftmp'
    assert do_urlencode('/tmp/?a=1&b=2') == '%2Ftmp%2F%3Fa%3D1%26b%3D2'
    assert do_urlencode({'a': '1', 'b': '2'}) == 'a=1&b=2'
    assert do_urlencode({'b': '2', 'a': '1'}) == 'b=2&a=1'
    assert do_urlencode(('b', '2', 'a', 1)) == 'b=2&a=1'

# Generated at 2022-06-23 10:21:11.190246
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'hello+world') == u'hello world'
    assert do_urldecode(u'hello%20world') == u'hello world'
    assert do_urldecode(u'hello%2Fworld') == u'hello/world'
    assert do_urldecode(u'hello%25world') == u'hello%world'


# Generated at 2022-06-23 10:21:13.790110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters


# Generated at 2022-06-23 10:21:23.976062
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    f = fm.filters()
    assert 'urldecode' in f
    assert 'urlencode' in f

    try:
        assert f['urldecode'] == do_urldecode
    except AssertionError:
        assert f['urldecode'] == do_urlencode

    try:
        assert f['urlencode'] == do_urlencode
    except AssertionError:
        assert f['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:21:26.778378
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert len(f.filters()) == 2

# Generated at 2022-06-23 10:21:33.620805
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%e2%82%ac') == u'\u20ac'
    assert unicode_urldecode(u'%e2%82%ac%20') == u'\u20ac '
    assert unicode_urldecode(u'%e2%82%ac+') == u'\u20ac+'
    assert unicode_urldecode(u'%e2%82%ac%20+') == u'\u20ac +'


# Generated at 2022-06-23 10:21:43.614026
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode(u'foo', for_qs=False) == 'foo'

    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=False) == u'foo%20bar'

    assert unicode_urlencode(u'/foo bar') == u'/foo%20bar'
    assert unicode_urlencode(u'/foo bar', for_qs=False) == u'/foo bar'

    assert unicode_urlencode(u'foo/bar') == u'foo/bar'
    assert unicode_urlencode(u'foo/bar', for_qs=False) == u'foo/bar'

    assert unic

# Generated at 2022-06-23 10:21:54.580895
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_filter_module = FilterModule()
    filters = ansible_filter_module.filters()
    assert filters['urldecode'](None) == 'None'
    assert filters['urldecode']('%20') == ' '
    assert filters['urldecode']('http%3A%2F%2Fexample.com%2F') == 'http://example.com/'
    if not HAS_URLENCODE:
        assert filters['urlencode'](' ') == '%20'
        assert filters['urlencode']('http://example.com/') == 'http%3A%2F%2Fexample.com%2F'
        assert filters['urlencode']({'key': 'value'}) == 'key=value'

# Generated at 2022-06-23 10:21:58.409985
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo+bar'
    assert do_urldecode('%7B%22a%22%3A%7B%22b%22%3A%5B1%5D%7D%7D') == '{"a":{"b":[1]}}'


# Generated at 2022-06-23 10:22:00.607451
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('hello%20world%25') == 'hello world%'

if __name__ == '__main__':
    test_do_urldecode()

# Generated at 2022-06-23 10:22:02.221411
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters()
    assert 'urlencode' in f.filters()

# Generated at 2022-06-23 10:22:13.550976
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ.-_~:/?#[]@!$&\'()*+,;=') == 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ.-_~:/?#[]@!$&\'()*+,;='

# Generated at 2022-06-23 10:22:24.282764
# Unit test for function do_urlencode
def test_do_urlencode():

    import sys
    import pytest

    if sys.version_info < (2, 7):
        pytestmark = pytest.mark.skipif(True, reason="requires Python 2.7")

    assert do_urlencode(u"foo") == u'foo'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode({u'c': u'f', u'd': u'e'}) == u'c=f&d=e'
    assert do_urlencode({u'a': [u'b', u'c']}) == u'a=b&a=c'

# Generated at 2022-06-23 10:22:29.854504
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"abcd efg") == u'abcd+efg'
    assert do_urlencode(u"abcd?efg") == u'abcd%3Fefg'
    assert do_urlencode(u"abcd=efg") == u'abcd%3Defg'
    assert do_urlencode(u"abcd&efg") == u'abcd%26efg'

# Generated at 2022-06-23 10:22:42.952051
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.urls import url_argument_spec
    from unittest import TestCase

    class MyTest(TestCase):
        @staticmethod
        def test_urlencode(string, for_qs=False):
            safe = b'' if for_qs else b'/'
            if for_qs:
                quote_func = quote_plus
            else:
                quote_func = quote
            if PY3:
                return quote_func(string, safe)
            return to_text(quote_func(to_bytes(string), safe))

        @staticmethod
        def test_urldecode(string):
            if PY3:
                return unquote_plus(string)
            return to_text(unquote_plus(to_bytes(string)))


# Generated at 2022-06-23 10:22:45.921744
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urldecode': do_urldecode}

# Generated at 2022-06-23 10:22:51.877294
# Unit test for function do_urldecode
def test_do_urldecode():
  if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
      print("Usage: %s STRING_TO_URL_DECODE" % (sys.argv[0]))
      sys.exit(1)
    print("%s" % (do_urldecode(sys.argv[1])))
    sys.exit(0)

# Generated at 2022-06-23 10:22:57.499064
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Hello World!') == 'Hello%20World%21'
    assert do_urlencode('Hello World!') == do_urlencode('Hello World!')
    a = do_urlencode(u'Hello World!')
    b = do_urlencode('Hello World!')
    assert isinstance(a, string_types) and isinstance(b, string_types)
    assert a == b



# Generated at 2022-06-23 10:23:03.631244
# Unit test for function do_urldecode
def test_do_urldecode():
    string = 'foo%2F%2Fbar'
    assert do_urldecode(string) == 'foo//bar'
    assert do_urldecode(string) == 'foo//bar'
    assert do_urldecode(string) == do_urldecode(string) == do_urldecode(string)



# Generated at 2022-06-23 10:23:13.390710
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Construct a FilterModule
    fm = FilterModule()

    # Assert the filters function returns a dict
    # assert isinstance(fm.filters(), dict)
    assert type(fm.filters()) is dict

    # Assert the dict has a urldecode key
    assert 'urldecode' in fm.filters()

    # Assert the dict has a urlencode key if HAS_URLENCODE is False
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()

    # Assert urldecode returns a string
    assert type(fm.filters()['urldecode']('Test')) is str

    # Assert urlencode returns a string if HAS_URLENCODE is False

# Generated at 2022-06-23 10:23:18.910701
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'%20') == u'%2520'
    assert unicode_urlencode(u'%2520') == u'%252520'
    assert unicode_urldecode(u'%252520') == u'%2520'


# Generated at 2022-06-23 10:23:27.092869
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    assert filters['urldecode']('test') == 'test'
    assert filters['urldecode']('test%20test') == 'test test'
    assert filters['urldecode']('test+test') == 'test test'

    assert filters['urlencode']('test') == 'test'
    assert filters['urlencode']('test test') == 'test+test'
    assert filters['urlencode']({'key': 'value'}) == 'key=value'
    assert filters['urlencode']({'key': 'value', 'key2': 'value2'}) == 'key=value&key2=value2'

# Generated at 2022-06-23 10:23:39.166622
# Unit test for function do_urldecode
def test_do_urldecode():
    tests = [
        ('', ''),
        ('%41', 'A'),
        ('%', ''),
        ('%2d', '-'),
        ('%2d+%2d', '- -'),
        ('%2d+%2d+', '- - '),
        ('%2D', '-'),
        ('%2D%2D', '--'),
        ('%2D  %2D', '--  --'),
        (u'%2D  %2D', u'--  --'),
        (u'ß', u'ß'),
        (u'A%2D', u'A-'),
        (u'A%41', u'AA'),
        (u'A%41%41', u'AAA'),
    ]
    for before, after in tests:
        assert do_urld

# Generated at 2022-06-23 10:23:51.262642
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test unicode_urldecode function '''
    from sys import version_info
    if version_info.major < 3:
        from urllib import quote, quote_plus, unquote_plus
    else:
        from urllib.parse import quote, quote_plus, unquote_plus

    # Test with ASCII string
    test_string = 'testing'
    assert do_urldecode(quote(test_string)) == test_string
    assert do_urldecode(quote_plus(test_string)) == test_string

    # Test with non-ASCII string
    test_string = u'€testing'
    assert do_urldecode(quote(test_string)) == test_string
    assert do_urldecode(quote_plus(test_string)) == test_string

    # Test with

# Generated at 2022-06-23 10:23:58.698032
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test') == u'test'
    assert unicode_urlencode(u'test&test') == u'test%26test'
    assert unicode_urlencode(u'test&test', for_qs=True) == u'test%26test'
    assert unicode_urlencode(u'test/test') == u'test%2Ftest'
    assert unicode_urlencode(u'test/test', for_qs=True) == u'test%2Ftest'
    assert unicode_urlencode(u'test%test') == u'test%25test'
    assert unicode_urlencode(u'test%test', for_qs=True) == u'test%25test'

# Generated at 2022-06-23 10:24:03.114634
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    expected = u'abcdef歟涼'
    observed = unicode_urldecode(b'abcdef%E6%AD%9F%E6%B6%BC')
    assert expected == observed, (expected, observed)



# Generated at 2022-06-23 10:24:08.365846
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode({u'a': u'b'}) == 'a=b'
    assert do_urlencode({u'a': u'b', u'c': u'd'}) == 'a=b&c=d'



# Generated at 2022-06-23 10:24:13.591154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    # test string filters
    assert filters['urldecode']('foo%2Bbar%2Bbaz') == 'foo+bar+baz'
    # test dict filters
    assert filters['urldecode']({'a': 'foo+bar+baz'}) == 'foo bar baz'
    # test iterable filters
    assert filters['urldecode']({'a': 'foo+bar+baz', 'b': 'biz+baz'}) == 'foo bar baz&biz baz'

# Generated at 2022-06-23 10:24:16.381468
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  f = FilterModule()
  assert 'urldecode' in f.filters()


# Generated at 2022-06-23 10:24:24.812536
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%25%E2%99%A8%26%25') == u'%*&%'
    # Ensure python 2 does not convert unicode characters
    if not PY3:
        assert type(unicode_urldecode(u'%25%E2%99%A8%26%25')) == unicode
    else:
        assert type(unicode_urldecode(u'%25%E2%99%A8%26%25')) == str


# Generated at 2022-06-23 10:24:27.257466
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%40%21%24%26%27') == u'@!$&\''
    assert do_urldecode('%40!$&\'') == u'@!$&\''


# Generated at 2022-06-23 10:24:30.600950
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%25') == '%'
    assert do_urldecode('+') == ' '
    assert do_urldecode('%7E') == '~'


# Generated at 2022-06-23 10:24:38.251523
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  assert(unicode_urldecode('%2Fapi%2Fv1%2Fconfiguration%2Fpolicies%3Flimit%3D50%26offset%3D0%26sort%3Dname%2Basc%26fields%3Dname') == '/api/v1/configuration/policies?limit=50&offset=0&sort=name+asc&fields=name')

# Generated at 2022-06-23 10:24:44.470317
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'ou=1,ou=2,ou=3', for_qs=True) == u'ou=1%2Cou=2%2Cou=3'
    assert unicode_urlencode(u'/path/to/nowhere/') == u'%2Fpath%2Fto%2Fnowhere%2F'

# Generated at 2022-06-23 10:24:46.897617
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert "http://ansible.com" == unicode_urldecode("http%3A%2F%2Fansible.com")


# Generated at 2022-06-23 10:24:48.552521
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(object)


# Generated at 2022-06-23 10:24:58.915916
# Unit test for function do_urlencode
def test_do_urlencode():
    # Empty string
    assert do_urlencode('') == ''

    # Encoding a string
    assert do_urlencode('Hello world') == 'Hello+world'
    assert do_urlencode('Jinja2 is beautiful !') == 'Jinja2+is+beautiful+%21'

    # Encoding a dict
    assert sorted(do_urlencode({'a': '1', 'b': '2'}).split('&')) == ['a=1', 'b=2']

    # Encoding a list
    assert sorted(do_urlencode(['a=1', 'b=2'])) == ['a%3D1', 'b%3D2']

# Generated at 2022-06-23 10:25:05.408662
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(['foo', 'bar']) == u'foo&bar'
    assert do_urlencode(['foo', ('bar', 'baz')]) == u'foo&bar=baz'
    assert do_urlencode(1) == u'1'
    assert do_urlencode('+-&=') == u'%2B-%26%3D'
    assert do_urlencode(unicode_urlencode(u'+-&=', for_qs=True)) == u'%252B-%2526%253D'
    assert do_urlencode({'foo': 'abc', 'bar': 'def'}) == u'foo=abc&bar=def'

# Generated at 2022-06-23 10:25:10.352852
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2F%25') == 'http://example.com/%'
    assert unicode_urldecode(b'http%3A%2F%2Fexample.com%2F%25') == 'http://example.com/%'

# Generated at 2022-06-23 10:25:14.534022
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'%80' == unicode_urldecode(u'%C2%80')
    assert u'\u20ac' == unicode_urldecode(u'%E2%82%AC')


# Generated at 2022-06-23 10:25:26.791030
# Unit test for function unicode_urldecode

# Generated at 2022-06-23 10:25:32.121591
# Unit test for function do_urldecode
def test_do_urldecode():
    string = '%20%5B%7B%22hostname%22%3A%20%22host02%22%2C%20%22os%22%3A%20%22Linux%22%7D%5D'
    assert do_urldecode(string) == u' [{"hostname": "host02", "os": "Linux"}]'


# Generated at 2022-06-23 10:25:42.425222
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils.six import PY3
    if PY3:
        itemiter = iter(dict(a=1, b=2).items())
        unquote_plus(b'%7B%22a%22%3A1%2C%22b%22%3A2%7D')
    else:
        itemiter = iter({'a': 1, 'b': 2}.iteritems())
        unquote_plus('%7B%22a%22%3A1%2C%22b%22%3A2%7D')

    do_urldecode = FilterModule().filters()['urldecode']

# Generated at 2022-06-23 10:25:52.458442
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Hello, world!') == u'Hello%2C%20world%21'
    assert unicode_urlencode(u'Hello, world!', for_qs=True) == u'Hello%2C+world%21'
    assert unicode_urlencode(u'/in/the/path') == u'/in/the/path'
    assert unicode_urlencode(u'/in/the/path', for_qs=True) == u'/in/the/path'
