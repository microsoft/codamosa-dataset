

# Generated at 2022-06-23 10:15:51.655561
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == u'foo bar'



# Generated at 2022-06-23 10:15:52.709096
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert FilterModule().filters is not None

# Generated at 2022-06-23 10:16:03.071785
# Unit test for function do_urldecode
def test_do_urldecode():
    # Test for single argument
    assert do_urldecode('%20') == ' '

    # Test for single argument with two items
    assert do_urldecode('%20%20') == '  '

    # Test for single dict argument
    assert do_urldecode({'%20': '%20'}) == '%20=%20'

    # Test for single list argument
    assert do_urldecode(['%20', '%20']) == '%20&%20'

    # Test for simple dict argument
    assert do_urldecode({'k1': 'v1', 'k2': 'v2'}) == 'k1=v1&k2=v2'

    # Test for simple list argument

# Generated at 2022-06-23 10:16:07.620690
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' urldecode should return an empty string when the input is the empty string
    >>> test_do_urldecode()
    '''
    assert do_urldecode('') == ''



# Generated at 2022-06-23 10:16:16.104371
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/test') == '/test'
    assert do_urlencode('/test/') == '/test/'
    assert do_urlencode('/test/a') == '/test/a'
    assert do_urlencode('/test/a/') == '/test/a/'
    assert do_urlencode('/test/a/b') == '/test/a/b'
    assert do_urlencode('/test/a/b/') == '/test/a/b/'
    assert do_urlencode('/test/a/b/c') == '/test/a/b/c'
    assert do_urlencode('/test/a/b/c/') == '/test/a/b/c/'


# Generated at 2022-06-23 10:16:26.549471
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test strings
    assert do_urlencode('') == u''
    assert do_urlencode(' ') == u'%20'
    assert do_urlencode('@') == u'%40'
    assert do_urlencode('?') == u'%3F'
    assert do_urlencode('*') == u'%2A'
    assert do_urlencode('!') == u'%21'
    assert do_urlencode('#') == u'%23'
    assert do_urlencode('$') == u'%24'
    assert do_urlencode('%') == u'%25'
    assert do_urlencode('&') == u'%26'
    assert do_urlencode('+') == u'%2B'
    assert do_urlencode

# Generated at 2022-06-23 10:16:30.412297
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # FilterModule.filters()
    module = FilterModule()
    assert('urldecode' in module.filters() and callable(module.filters()['urldecode']))
    if not HAS_URLENCODE:
        assert('urlencode' in module.filters() and callable(module.filters()['urlencode']))



# Generated at 2022-06-23 10:16:38.443839
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo?bar') == 'foo%3Fbar'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'



# Generated at 2022-06-23 10:16:41.446720
# Unit test for function do_urlencode
def test_do_urlencode():
    # This is not a full test of do_urlencode(), but it is
    # representative of the issue addressed by the change
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode('hi') == 'hi'

# Generated at 2022-06-23 10:16:49.082725
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('hans=wurst') == 'hans=wurst'
    assert do_urldecode('hans%3Dwurst') == 'hans=wurst'


# Generated at 2022-06-23 10:16:52.701215
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = b'%C3%B6%C3%A4%C3%BC%C3%9F%20%3C%3E%20%26%25'
    assert unicode_urldecode(s) == 'öäüß <> &%'

# Generated at 2022-06-23 10:16:54.138740
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule() is not None)


# Generated at 2022-06-23 10:16:55.239785
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # This function is not directly testable, but is used by other test cases
    pass


# Generated at 2022-06-23 10:17:07.212400
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'nl%20nl') == u'nl nl'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%E4%BD%A0%E4%B8%BA%E4%BB%80%E4%B9%88') == u'\u4f60\u4e3a\u4ec0\u4e48'
    assert unicode_urldecode(u'%e4%bd%a0%e4%b8%ba%e4%bb%80%e4%b9%88') == u'\u4f60\u4e3a\u4ec0\u4e48'



# Generated at 2022-06-23 10:17:14.102821
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert len(filters) == 2

    assert filters['urldecode']('foo') == 'foo'
    assert filters['urldecode']('foo%20bar%3B') == 'foo bar;'

    if not HAS_URLENCODE:
        assert filters['urlencode']('foo') == 'foo'
        assert filters['urlencode']('foo bar;') == 'foo+bar%3B'
        assert filters['urlencode']({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'

# Generated at 2022-06-23 10:17:26.778735
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six import text_type
    assert unicode_urlencode(text_type("hello world")) == u'hello%20world'
    assert unicode_urlencode(text_type("/hello world")) == u'/hello%20world'
    assert unicode_urlencode(text_type("/hello world"), True) == u'%2Fhello%20world'
    assert unicode_urlencode(text_type("hello world/"), True) == u'hello%20world%2F'
    assert unicode_urlencode(text_type("/hello world/")) == u'/hello%20world/'
    assert unicode_urlencode(text_type("/hello world/"), True) == u'%2Fhello%20world%2F'
    assert unicode_urlencode

# Generated at 2022-06-23 10:17:38.704839
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # In Python 2.7, we use urllib.quote_plus and urllib.unquote_plus
    if PY3:
        from urllib.parse import quote_plus, unquote_plus
    else:
        from urllib import quote_plus, unquote_plus

    class DummyModule(object):
        def __init__(self, text):
            self.params = dict(text=text)
            self.fail_json = self.exit_json = lambda **kwargs: None

        def fail_json(self, **kwargs):
            self.exit_json(**kwargs)

        def exit_json(self, **kwargs):
            self.result = kwargs

    def assert_filter(name, text, expected):
        module = DummyModule(text)
        FilterModule.filters()

# Generated at 2022-06-23 10:17:49.801812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils import basic

    fm = FilterModule()
    filters = fm.filters()

    assert 'urldecode' in filters
    f_urldecode = filters['urldecode']
    assert f_urldecode('%3F+%2F%3F%23%26%3D') == '? /?#&='

    assert 'urlencode' in filters
    f_urlencode = filters['urlencode']
    assert f_urlencode('? /?#&=') == '%3F+%2F%3F%23%26%3D'


# Generated at 2022-06-23 10:17:54.810419
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # test constructor
    assert isinstance(FilterModule().filters(), dict)

    # test for url decode filter
    assert FilterModule.filters(FilterModule())['urldecode']('%23') == '#'

    # test for url encode filter
    assert FilterModule.filters(FilterModule())['urlencode']('#') == '%23'

# Generated at 2022-06-23 10:17:59.272444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.plugins.filter.core
    f = ansible.plugins.filter.core.FilterModule()
    assert f.filters()['urldecode'] == do_urldecode
    assert f.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:18:02.246610
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert isinstance(x, FilterModule)
    assert hasattr(x, 'filters')
    assert isinstance(x.filters, object)


# Generated at 2022-06-23 10:18:04.086178
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Unit test for FilterModule class
    """

    filter_module = FilterModule()

    assert filter_module

# Generated at 2022-06-23 10:18:07.255767
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mytest = FilterModule()
    mytest.filters()

# Generated at 2022-06-23 10:18:08.736687
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test is not None


# Generated at 2022-06-23 10:18:19.679238
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo/bar') == u'foo/bar'
    assert do_urlencode(u'foo/bar') == u'foo/bar'
    assert do_urlencode('foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(['foo', 'bar']) == u'foo&bar'
    assert do_urlencode({'foo': 'bar'}) == u'foo=bar'
    assert do_urlencode('Foo>bar') == u'Foo%3Ebar'
    assert do_urlencode(u'Foo>bar') == u'Foo%3Ebar'

# Generated at 2022-06-23 10:18:24.752652
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    string = '%2f%2b%2B%2F%21%23%24%26%27%28%29%2a%2A%2b%2c-.%2f'
    if PY3:
        assert unicode_urldecode(string) == \
            '/+%2B/!%23$%26\'()*%2A,-.%2F'
    else:
        assert unicode_urldecode(string) == \
            u'/+%2B/!%23$%26\'()*%2A,-.%2F'


# Generated at 2022-06-23 10:18:31.442248
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'a=a%26b%3Dc' == do_urlencode({u'a': u'a&b=c'})
    assert 'a=a%26b%3Dc' == do_urlencode([['a', u'a&b=c']])
    assert 'a=a%26b%3Dc' == do_urlencode(u'a&b=c')
    assert 'a=1&a=2&a=3' == do_urlencode([['a', 1], ['a', 2], ['a', 3]])
    assert 'a=1|2|3' == do_urlencode([['a', u'1|2|3']])

# Generated at 2022-06-23 10:18:35.025043
# Unit test for function do_urldecode
def test_do_urldecode():
    string = 'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3Dbah'
    assert do_urldecode(string) == 'http://example.com/?foo=bar&baz=bah'


# Generated at 2022-06-23 10:18:40.530866
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b%2Bc%2b') == u'a b+c+'
    assert do_urldecode('a+b%2Bc%2b', safe='') == u'a+b+c+'
    assert do_urldecode('a+b%2Bc%2b', safe='/') == u'a+b%2Bc%2b'


# Generated at 2022-06-23 10:18:45.542473
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode(42) == '42'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(dict(a=1, b=2)) == 'a=1&b=2'

# Generated at 2022-06-23 10:18:50.891865
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'http%3A//www.yaml.org/spec/1.2/spec.html') == u'http://www.yaml.org/spec/1.2/spec.html'
    assert do_urldecode('http%3A%2F%2Fwww.yaml.org%2Fspec%2F1.2%2Fspec.html') == u'http://www.yaml.org/spec/1.2/spec.html'
    assert do_urldecode(u'http://www.yaml.org/spec/1.2/spec.html') == u'http://www.yaml.org/spec/1.2/spec.html'

# Generated at 2022-06-23 10:18:54.230620
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Check basic usage
    assert unicode_urlencode(u'http://ansible.com/') == u'http%3A%2F%2Fansible.com%2F'
    assert unicode_urlencode(u'http://ansible.com/', for_qs=True) == u'http%3A%2F%2Fansible.com%2F'
    assert unicode_urlencode(u'ansible.com') == u'ansible.com'
    assert unicode_urlencode(u'ansible.com', for_qs=True) == u'ansible.com'

    # Check decoding with reserved characters
    assert unicode_urldecode(u'http%3A%2F%2Fansible.com%2F') == u'http://ansible.com/'

# Generated at 2022-06-23 10:19:03.658747
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'dag') == 'dag'
    assert unicode_urlencode(u'dag@wieers.com') == 'dag%40wieers.com'
    assert unicode_urlencode(u'http://dag.wieers.com/') == 'http%3A//dag.wieers.com/'
    assert unicode_urlencode(u'http://dag.wieers.com/', for_qs=True) == 'http%3A%2F%2Fdag.wieers.com%2F'
    assert unicode_urlencode(u'Dag Wieers') == 'Dag%20Wieers'

# Generated at 2022-06-23 10:19:06.731452
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters

# Generated at 2022-06-23 10:19:09.475432
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module_instance = FilterModule()
    assert filter_module_instance.filters()['urldecode'] is not None



# Generated at 2022-06-23 10:19:19.487135
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'http%3A/%2Fexample.com/%20%2F' == do_urlencode('http://example.com/ /')
    assert 'a%3D1%26b%3D2%26c%3D3' == do_urlencode({'a': 1, 'b': 2, 'c': 3})
    assert 'a%3D1%26b%3D2%26c%3D3' == do_urlencode(['a=1', 'b=2', 'c=3'])

# Generated at 2022-06-23 10:19:24.272683
# Unit test for constructor of class FilterModule
def test_FilterModule():
    value = {'a': 'A&B', 'b': 'C/D'}
    fmc = FilterModule()
    fm = fmc.filters()
    assert fm['urldecode']('a=A%26B&b=C%2FD') == value
    assert fm['urldecode']('a=A&B&b=C/D') == value
    if not HAS_URLENCODE:
        assert fm['urlencode']('a=A&B&b=C/D') == 'a=A%26B&b=C%2FD'
        assert fm['urlencode'](value) == 'a=A%26B&b=C%2FD'


# Generated at 2022-06-23 10:19:34.899635
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test/') == 'test%2F'
    assert unicode_urlencode('test/', for_qs=True) == 'test%2F'
    assert unicode_urlencode('test?') == 'test%3F'
    assert unicode_urlencode('test?', for_qs=True) == 'test%3F'

    assert unicode_urlencode({"a": "b"}) == 'a=b'
    assert unicode_urlencode([1, 2]) == '1&2'
    assert unicode_urlencode(["1", "2"]) == '1&2'
    assert unicode_urlencode(('1', '2')) == '1&2'

# Generated at 2022-06-23 10:19:40.183085
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://ansible.com') == u'http%3A%2F%2Fansible.com'
    assert unicode_urlencode(u'http://ansible.com', True) == u'http%3A%2F%2Fansible.com'
    assert unicode_urlencode(u'/hello/world/') == u'/hello/world/'
    assert unicode_urlencode(u'/hello/world/', True) == u'%2Fhello%2Fworld%2F'


# Generated at 2022-06-23 10:19:46.830657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters, "Expected to find urldecode in filter methods, but missing"
    if not HAS_URLENCODE:
        assert 'urlencode' in filters, "Expected to find urlencode in filter methods, but missing"
    else:
        assert 'urlencode' not in filters, "Expected not to find urlencode in filter methods, but found"


# Generated at 2022-06-23 10:19:57.372502
# Unit test for function do_urldecode
def test_do_urldecode():

    input_list = [
        'abc%20def',
        'abc++def',
        'abc%2B%2Bdef',
        '%6C',
        '%6c',
        '%6C+',
        '%6c+',
        '%6c%2C',
        '%6c%2c',
        '%6c%2C+',
        '%6c%2c+',
    ]

    expected_list = [
        'abc def',
        'abc  def',
        'abc++def',
        'l',
        'l',
        'l ',
        'l ',
        'l,',
        'l,',
        'l, ',
        'l, ',
    ]


# Generated at 2022-06-23 10:20:08.961691
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    cyrillic = u"Превед, медвед!"
    cyrillic_data = {
        "cyrillic": cyrillic,
        "cyrillic_list": [cyrillic, cyrillic],
        "cyrillic_dict": {
            "cyrillic_key": cyrillic,
            "cyrillic_list": [cyrillic, cyrillic],
            "cyrillic_dict": {
                "cyrillic_key": cyrillic,
            },
        },
    }

# Generated at 2022-06-23 10:20:11.395397
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('%A1') == '\xe1'


# Generated at 2022-06-23 10:20:12.324328
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x is not None

# Generated at 2022-06-23 10:20:17.206413
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%9C') == u'\xdc'
    assert unicode_urldecode('%C3%9C+%C2%A9') == u'\xdc \xa9'

# Generated at 2022-06-23 10:20:18.443356
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module


# Generated at 2022-06-23 10:20:22.857713
# Unit test for function do_urlencode
def test_do_urlencode():
    result = do_urlencode('a&b')
    if PY3:
        assert result == 'a%26b'
    else:
        assert result == u'a%26b'


test_do_urlencode()

# Generated at 2022-06-23 10:20:29.557526
# Unit test for function do_urlencode
def test_do_urlencode():

    # Simple test
    assert do_urlencode("val") == "val"

    # Test with dictionary
    assert do_urlencode({"a": "A", "b": "B"}) == "a=A&b=B"

    # Test with list
    assert do_urlencode(['a', 'b']) == "a&b"

    # Test with list of tuples
    assert do_urlencode([('a', 'A'), ('b', 'B')]) == "a=A&b=B"



# Generated at 2022-06-23 10:20:35.581457
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(do_urldecode('abcd+efgh%25ijkl') == 'abcd efgh%ijkl')

    if not HAS_URLENCODE:
        assert do_urlencode('abcd efgh%ijkl') == 'abcd+efgh%25ijkl'

        assert(do_urlencode({'q': 'abcd efgh%ijkl', 'rst': 'uvw xyz'}) == 'q=abcd+efgh%25ijkl&rst=uvw+xyz')

    fm = FilterModule()
    assert hasattr(fm, 'filters')
    assert hasattr(fm.filters(), 'keys')

    assert(fm.filters().keys() == ['urldecode'])


# Generated at 2022-06-23 10:20:46.102273
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'query': 'urlencode'}) == u'query=urlencode'
    assert do_urlencode([('query', 'urlencode')]) == u'query=urlencode'
    assert do_urlencode({'url': 'http://www.example.com/p?a=1&b=2'}) == u'url=http%3A%2F%2Fwww.example.com%2Fp%3Fa%3D1%26b%3D2'
    assert do_urlencode(u'\u2661') == u'%E2%99%A1'

# Generated at 2022-06-23 10:20:57.627041
# Unit test for function do_urldecode
def test_do_urldecode():
    """
    Tests do_urldecode()
    """
    # Test for empty string
    assert ''.encode('utf-8') == do_urldecode('')

    # Test for string with nothing to decode
    assert 'test'.encode('utf-8') == do_urldecode('test')

    # Test for url encoded string
    assert ' '.encode('utf-8') == do_urldecode('%20')

    # Test for url encoded string with encoded '+'
    assert ' '.encode('utf-8') == do_urldecode('%20')

    # Test for a simple dictionary

# Generated at 2022-06-23 10:21:08.796839
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    dict = {'foo': 'bar'}
    assert filter_module.filters()['urldecode']('foo') == 'foo'
    assert filter_module.filters()['urldecode']('foo+bar') == 'foo bar'
    assert filter_module.filters()['urldecode']('foo%20bar') == 'foo bar'
    assert filter_module.filters()['urldecode']('foo%2Fbar') == 'foo%2Fbar'
    assert filter_module.filters()['urlencode']('foo') == 'foo'
    assert filter_module.filters()['urlencode']('foo bar') == 'foo+bar'

# Generated at 2022-06-23 10:21:14.908131
# Unit test for function do_urldecode
def test_do_urldecode():
    import os

    assert do_urldecode(b'foo%40bar%3D') == u'foo@bar='
    assert do_urldecode(u'foo%40bar%3D') == u'foo@bar='
    assert do_urldecode('foo%40bar%3D') == u'foo@bar='


# Generated at 2022-06-23 10:21:24.109979
# Unit test for function do_urlencode
def test_do_urlencode():
    import tests.utils as utils
    script_args = {}
    args = [{'name': 'myvar', 'value': 'foo bar'}, {'name': 'myvar', 'value': 'foo+bar'}]

    results = list()
    for arg in args:
        results.append(utils.run_filter(do_urlencode, arg['value'], script_args))

    assert results[0] == 'foo+bar'
    assert results[1] == 'foo%2Bbar'

# Generated at 2022-06-23 10:21:34.210006
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u013f\u00e9\u00fd\u0123\u0145') == b'%C7%BF%C3%A9%C3%BD%C4%A3%C4%85'
    assert unicode_urlencode(u'/') == b'/'
    assert unicode_urlencode(u'?foo=\u013f\u00e9\u00fd\u0123\u0145&bar=abc123') == b'%3Ffoo%3D%C7%BF%C3%A9%C3%BD%C4%A3%C4%85%26bar%3Dabc123'


# Generated at 2022-06-23 10:21:42.291224
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('/%20') == '/ '
    assert do_urldecode('/%2b') == '/+'
    assert do_urldecode('/%7e') == '/~'
    assert do_urldecode('/%c0%80') == '/\x00\x00'
    assert do_urldecode('/%c0%80%20%c0%80') == '/\x00\x00 \x00\x00'
    assert do_urldecode('/%C0%80') == '/\x00\x00'



# Generated at 2022-06-23 10:21:47.169295
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input_ = "https%3A%2F%2Fgithub.com%2Fansible%2Fansible"
    expected_decoded = "https://github.com/ansible/ansible"
    decoded = unicode_urldecode(input_)
    assert decoded == expected_decoded, "%s should have been decoded to %s" % (input_, expected_decoded)


# Generated at 2022-06-23 10:21:56.109495
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import inspect

    import ansible
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus

    text = to_text if PY3 else to_bytes

    ########################################################################################
    # getattr(object, name[, default])
    #
    # Return the value of the named attribute of object. name must be a string. If the
    # string is the name of one of the object’s attributes, the result is the value of that
    # attribute. For example, getattr(x, 'foobar') is equivalent to x.foobar. If the named
    # attribute does not exist, default is returned if provided, otherwise Att

# Generated at 2022-06-23 10:22:02.690390
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import tempfile
    from ansible.config.data import ConfigData

    root = tempfile.mkdtemp()

    ansible_cfg = os.path.join(root, 'ansible.cfg')
    with open(ansible_cfg, 'wt') as f:
        f.write('[defaults]\n')
        f.write('lookup_plugins = %s\n' % os.path.join(root, 'lookup_plugins'))
        f.write('roles_path = %s\n' % os.path.join(root, 'roles'))
        f.write('module_utils_path = %s\n' % os.path.join(root, 'module_utils'))

    # Mock Ansible's config instance
    ConfigData()
    ConfigData.set_config_root

# Generated at 2022-06-23 10:22:13.784624
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == '%20'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%') == '%'
    assert do_urldecode('%X') == '%X'
    assert do_urldecode('foo bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo+bar'
    assert do_urldecode('foo%20bar') == 'foo%20bar'
    assert do_urldecode('foo%2Fbar') == 'foo%2Fbar'
    assert do_urldecode('foo%2fbar') == 'foo%2fbar'
    assert do_ur

# Generated at 2022-06-23 10:22:17.420377
# Unit test for function do_urldecode
def test_do_urldecode():
    expected_result = u'spam, egg'
    returned_result = do_urldecode(u'spam%2C+egg')
    assert(returned_result == expected_result)



# Generated at 2022-06-23 10:22:27.727011
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == '%2F'
    assert do_urlencode('/foo/bar?baz=:') == '%2Ffoo%2Fbar%3Fbaz%3D%3A'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode([[['a', 'b'], 'c'], 'd']) == 'a=b&c&d'
    assert do_urlencode(u'\xa0') == '%C2%A0'
    assert do_urlencode(u'/') == '%2F'

# Generated at 2022-06-23 10:22:32.167392
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20b%20c') == 'a b c'
    assert do_urldecode('a+b+c') == 'a b c'
    assert do_urldecode('abc') == 'abc'
    assert do_urldecode('a%10b%10c') == 'a\x08b\x08c'


# Generated at 2022-06-23 10:22:39.850197
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from jinja2 import Environment, StrictUndefined

    env = Environment(undefined=StrictUndefined)

    string = 'http%3A%2F%2Fexample.com%2F%E6%97%A5%E6%9C%AC%E8%AA%9E'

    assert unicode_urldecode(string) == u'http://example.com/{0}'.format(u'日本語')



# Generated at 2022-06-23 10:22:44.291003
# Unit test for function do_urldecode
def test_do_urldecode():
    # Totally boring case
    assert do_urldecode('simple') == 'simple'

    # Some fun with characters
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%3D=%3D') == '=='
    assert do_urldecode('a%20b%20c') == 'a b c'
    assert do_urldecode('a%2Bb%2Bc') == 'a+b+c'
    assert do_urldecode('a%26b%26c') == 'a&b&c'
    assert do_urldecode('%7Ba%7Bb%7D%7D') == '{a{b}}'
    assert do_ur

# Generated at 2022-06-23 10:22:48.668047
# Unit test for constructor of class FilterModule
def test_FilterModule():
    cls = FilterModule()
    assert cls.filters()['urldecode'] == do_urldecode
    assert cls.filters()['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:22:58.987926
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native

    fm = FilterModule()
    assert 'urldecode' in fm.filters()

    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()
    else:
        pytest.skip("Skipping because we're using Jinja2 2.7+")


# Generated at 2022-06-23 10:23:10.853911
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode(['list']) == 'list'
    assert do_urlencode({'dict': 'value'}) == 'dict=value'
    assert do_urlencode({'dictA': 'valueA', 'dictB': 'valueB'}) == 'dictA=valueA&dictB=valueB'
    assert do_urlencode({'dictA': 'value A', 'dictB': 'value B'}) == 'dictA=value+A&dictB=value+B'
    assert do_urlencode({'dictA': 'á', 'dictB': 'b'}) == 'dictA=%C3%A1&dictB=b'

# Generated at 2022-06-23 10:23:18.192846
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Tests for Python 3
    if PY3:
        # Empty string
        assert unicode_urlencode('') == ''
        # Empty string, for_qs
        assert unicode_urlencode('', for_qs=True) == ''
        # String with spaces
        assert unicode_urlencode(' ') == '%20'
        # String with spaces, for_qs
        assert unicode_urlencode(' ', for_qs=True) == '%20'
        # String with many spaces
        assert unicode_urlencode('  ') == '%20%20'
        # String with many spaces, for_qs
        assert unicode_urlencode('  ', for_qs=True) == '%20%20'
        # String with many spaces (no-break space)
        assert unicode_urlen

# Generated at 2022-06-23 10:23:27.538377
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo@bar') == u'foo%40bar'
    assert do_urlencode(u'foo:bar') == u'foo:bar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode([u'foo', u'bar bar']) == u'foo&bar%20bar'

# Generated at 2022-06-23 10:23:30.350417
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()



# Generated at 2022-06-23 10:23:40.503905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.compat import ntoc
    assert FilterModule.filters(None)['urldecode']('a%20b%20c') == 'a b c'
    assert FilterModule.filters(None)['urldecode']('a%C3%80b%20c') == ntoc('a\xc3\x80b c')
    if not HAS_URLENCODE:
        assert FilterModule.filters(None)['urlencode']('a b c') == 'a+b+c'
        assert FilterModule.filters(None)['urlencode']('a%20b%20c') == 'a%20b%20c'

# Generated at 2022-06-23 10:23:47.437141
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module  = FilterModule()
    assert filter_module != None
    assert filter_module.filters() != None
    assert filter_module.filters()["urldecode"] == do_urldecode
    if not HAS_URLENCODE:
        assert filter_module.filters()["urlencode"] == do_urlencode


# Generated at 2022-06-23 10:23:52.855200
# Unit test for function do_urldecode
def test_do_urldecode():

    try:
        from jinja2.filters import do_urldecode
    except ImportError:
        # not available or broken on this platform
        return True

    encoded = b'foo%20bar%2Bbaz'
    decoded = u'foo bar+baz'
    if PY3:
        encoded = to_text(encoded)
    assert do_urldecode(encoded) == decoded
    return True

# Generated at 2022-06-23 10:24:04.902224
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:24:07.745904
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert fm.filters()['urlencode'] is do_urlencode

# Generated at 2022-06-23 10:24:14.629554
# Unit test for function do_urlencode
def test_do_urlencode():
    import sys
    args = {
        'string': "String with spaces",
        'for_qs': False,
        'value': {'key': 'value with spaces', 'key2': 123},
        'iterable': ['hello', 'world']
    }

    def assert_result(expected, result):
        if sys.version_info[0] == 3:
            expected = expected.decode()
        assert expected == result

    assert_result('%20'.join(args['iterable']),
                  do_urlencode(args['iterable']))
    assert_result('key=value+with+spaces&key2=123',
                  do_urlencode(args['value']))
    assert_result('String%20with%20spaces',
                  do_urlencode(args['string']))

# Generated at 2022-06-23 10:24:27.301410
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    with patch.multiple(FilterModule, filters=lambda self: {'urldecode': do_urldecode}):
        from ansible.plugins.filter import urldecode

    class TestUrldecode(unittest.TestCase):

        def setUp(self):
            self.possible_encodings = ["utf-8", "ISO-8859-1"]

        def test_do_urldecode(self):
            self.assertEqual(urldecode("%20"), " ")
            self.assertEqual(urldecode("%3A"), ":")
            self.assertEqual(urldecode("%2B"), "+")
            self.assertEqual

# Generated at 2022-06-23 10:24:32.462028
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E9%A6%96%E9%A1%B5') == u'\u9996\u9801'
    assert unicode_urldecode(u'%7e%2f%2e%2e%2f') == '~/../'


# Generated at 2022-06-23 10:24:37.061460
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('ab%0Ac') == 'ab\nc'
    assert unicode_urldecode('ab%2Fc') == 'ab/c'
    assert unicode_urldecode('%') == '%'


# Generated at 2022-06-23 10:24:39.577313
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    result = unicode_urldecode('%7B%22branch%22%3A%22master%22%7D')

    assert result == u'{"branch":"master"}'


# Unit tests for function unicode_urlencode

# Generated at 2022-06-23 10:24:51.378320
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('name=dag&age=23') == u'name=dag&age=23'
    assert not isinstance(do_urldecode('name=dag&age=23'), string_types)
    assert do_urldecode(u'name=dag&age=23') == u'name=dag&age=23'
    assert isinstance(do_urldecode(u'name=dag&age=23'), string_types)
    assert do_urldecode({'name': 'dag', 'age': 23}) == u'name=dag&age=23'
    assert do_urldecode([('name', 'dag'), ('age', 23)]) == u'name=dag&age=23'



# Generated at 2022-06-23 10:25:02.106931
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('A1+B2') == 'A1%2BB2'
    assert unicode_urlencode('A1+B2', True) == 'A1%2BB2'
    assert unicode_urlencode(u'A1+B2') == 'A1+B2'
    assert unicode_urlencode(u'A1+B2', True) == 'A1%2BB2'

# Generated at 2022-06-23 10:25:13.305544
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import json
    import re

    # filter tests that work with both Python2 and Python3
    fm = FilterModule()
    filters = fm.filters()
    assert filter(lambda f: 'urldecode' == f, filters)
    assert not filter(lambda f: 'urlencode' == f, filters)

    # NOTE: All urlencode tests are either of the form:
    #  1. Normal: somestring => somestring
    #  2. Normal with filters: somestring | urlencode => somestring
    #  3. Python2, Python3: 123 => '123'
    #  4. Python2, Python3 with filters: 123 | urlencode => '123'
    #  5. Normal long: somestring with spaces => somestring+with+spaces
    #  6. Normal

# Generated at 2022-06-23 10:25:15.270229
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)


# Generated at 2022-06-23 10:25:17.077824
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello%20World%21') == 'Hello World!'



# Generated at 2022-06-23 10:25:28.937754
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('') == '')
    assert(do_urlencode('abc=def') == 'abc=def')
    assert(do_urlencode('abcdef') == 'abcdef')
    assert(do_urlencode('abc def') == 'abc+def')
    assert(do_urlencode('abc@def') == 'abc%40def')
    assert(do_urlencode(['abcdef']) == 'abcdef')
    assert(do_urlencode(('abc', 'def')) == 'abc&def')
    assert(do_urlencode(('abc', 'def')) == 'abc&def')
    assert(do_urlencode({'abc': 'def'}) == 'abc=def')

# Generated at 2022-06-23 10:25:40.558113
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:25:48.944376
# Unit test for function do_urlencode
def test_do_urlencode():
    # test that we generate the same string as jinja2 2.7
    try:
        from jinja2.filters import do_urlencode as do_urlencode_jinja2
    except ImportError:
        return
