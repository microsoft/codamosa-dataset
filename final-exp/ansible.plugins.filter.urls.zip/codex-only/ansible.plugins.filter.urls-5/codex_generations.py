

# Generated at 2022-06-23 10:15:55.505091
# Unit test for function do_urldecode
def test_do_urldecode():
    assert 'foo' == do_urldecode('foo')
    assert 'foo bar' == do_urldecode('foo+bar')
    assert u'föo bar' == do_urldecode('f%C3%B6o+bar')
    assert 'foo bar' == do_urldecode('foo%20bar')


# Generated at 2022-06-23 10:16:06.600494
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u"foo"
    assert do_urldecode(u'foo bar') == u"foo bar"
    assert do_urldecode(u'foo+bar') == u"foo bar"
    assert do_urldecode(u'foo%20bar') == u"foo bar"
    assert do_urldecode(u'foo%2Bbar') == u"foo+bar"
    assert do_urldecode(u'foo%252Bbar') == u"foo%2Bbar"
    assert do_urldecode(u'/foo/var/log') == u"/foo/var/log"
    assert do_urldecode(u'/foo/var/log/') == u"/foo/var/log/"
    assert do_ur

# Generated at 2022-06-23 10:16:15.981637
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3a%2f%2fwww.urltest.com%2f') == u'http://www.urltest.com/'
    assert do_urldecode('%83e%83X%83g') == u'セキュリティ'
    assert do_urldecode(u'%83e%83X%83g') == u'セキュリティ'
    assert do_urldecode(b'%83e%83X%83g') == u'セキュリティ'
    assert do_urldecode('http://www.urltest.com/?a=%83e%83X%83g') == u'http://www.urltest.com/?a=セキュリティ'


# Generated at 2022-06-23 10:16:17.564573
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test.filters() is not None


# Generated at 2022-06-23 10:16:27.683549
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'a&b') == u'a%26b'
    assert do_urlencode(u'a&b=') == u'a%26b%3D'
    assert do_urlencode([u'a', u'b', u'c']) == u'a&b&c'
    assert do_urlencode([u'a', u'b', [u'c', u'd']]) == u'a&b&c&d'
    assert do_urlencode({u'a': u'b'}) == u'a=b'
    assert do_urlencode({u'a': u'b', u'c': u'd'}) == u'c=d&a=b'

# Generated at 2022-06-23 10:16:29.749213
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fwww.example.com%2F') == 'http://www.example.com/'


# Generated at 2022-06-23 10:16:31.697748
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)


# Generated at 2022-06-23 10:16:32.538910
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule)

# Generated at 2022-06-23 10:16:33.633650
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:16:34.917602
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '


# Generated at 2022-06-23 10:16:44.352129
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'chad') == u'chad'

    result = unicode_urlencode({
        'a': 1,
        'b': 2,
    })
    assert result == u'a=1&b=2'

    result = unicode_urlencode([
        [u'a', 1],
        [u'b', 2],
    ])
    assert result == u'a=1&b=2'

    for_qs = unicode_urlencode(u'chad', for_qs=True)
    assert for_qs == u'chad'

    for_qs = unicode_urlencode(u'chad+is+cool', for_qs=True)
    assert for_qs == u'chad%2Bis%2Bcool'

    encoded = do

# Generated at 2022-06-23 10:16:55.046800
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'Hello World') == u'Hello%20World'
    assert do_urlencode(u'Hello World!') == u'Hello%20World%21'
    assert do_urlencode(u'Hello/World') == u'Hello%2FWorld'
    assert do_urlencode(u'Hello World') == u'Hello%20World'
    assert do_urlencode(u'Hello World!') == u'Hello%20World%21'
    assert do_urlencode(u'Hello/World') == u'Hello%2FWorld'
    assert do_urlencode({'Hello': 'World'}) == u'Hello=World'
    assert do_urlencode({'Hello': 'World', 'Suffix': ''}) == u'Suffix=&Hello=World'


# Generated at 2022-06-23 10:16:59.300670
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert type(x.filters()) is dict
    x.filters()

# Unit test

# Generated at 2022-06-23 10:17:09.243982
# Unit test for function do_urldecode
def test_do_urldecode():
    test_data = (
        ('', ''),
        ('foo+bar', 'foo bar'),
        ('foo(bar)', 'foo(bar)'),
        ('foo/bar', 'foo/bar'),
        ('foo%2Fbar', 'foo/bar'),
        ('foo%2fbar', 'foo/bar'),
        ('foo%21bar', 'foo!bar'),
        ('foo%20bar', 'foo bar'),
        ('foo%21%22%23%24%25%26%27%28%29', 'foo!"#$%&\'()'),
        ('foo+%21%22%23%24%25%26%27%28%29', 'foo !#$%&\'()'),
        ('foo', 'foo'),
        ('foo+', 'foo '),
        ('+foo', ' foo'),
    )
   

# Generated at 2022-06-23 10:17:12.662731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)

    urldecode = filters['urldecode']
    assert callable(urldecode)

    urlencode = filters['urlencode']
    assert callable(urlencode)


# Generated at 2022-06-23 10:17:14.496616
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3Cstrong%3E') == u'<strong>'



# Generated at 2022-06-23 10:17:22.834136
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar') == 'foo%2Bbar'



# Generated at 2022-06-23 10:17:27.609476
# Unit test for function do_urldecode
def test_do_urldecode():
    tests = [
        ('%20', u' '),
        (u'%20', u' '),
        ('', ''),
        ('%2520', u'%20'),
    ]
    for t in tests:
        assert do_urldecode(t[0]) == t[1]


# Generated at 2022-06-23 10:17:38.816242
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc/def') == 'abc%2Fdef'
    assert unicode_urlencode('abc def') == 'abc+def'
    assert unicode_urlencode('abc def', for_qs=True) == 'abc+def'
    assert unicode_urlencode('abc+def') == 'abc%2Bdef'
    assert unicode_urlencode('abc+def', for_qs=True) == 'abc%2Bdef'
    assert unicode_urlencode('abc123$%') == 'abc123%24%25'
    assert unicode_urlencode('abc123$%', for_qs=True) == 'abc123%24%25'

# Generated at 2022-06-23 10:17:51.151552
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    """Test with data from https://en.wikipedia.org/wiki/Percent-encoding
    and https://tools.ietf.org/html/rfc3986#page-12
    """


# Generated at 2022-06-23 10:18:01.413538
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == '', "Failed literal empty string"
    assert unicode_urldecode('%') == '%', "Failed literal percent"
    assert unicode_urldecode('%%') == '%%', "Failed literal percent %"
    assert unicode_urldecode('+') == ' ', "Failed literal plus"
    assert unicode_urldecode('%2B') == '+', "Failed literal encoded plus"
    assert unicode_urldecode('%2b') == '+', "Failed literal encoded plus"
    assert unicode_urldecode('%3d') == '=', "Failed literal encoded equal"
    assert unicode_urldecode('%3D') == '=', "Failed literal encoded equal"
    assert unic

# Generated at 2022-06-23 10:18:13.112253
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus
    if PY2:
        assert FilterModule().filters()['urldecode']('%2F') == to_text(unquote_plus('%2F'))
        assert FilterModule().filters()['urldecode']('%C3%B6') == to_text(unquote_plus('%C3%B6'))
    else:
        assert FilterModule().filters()['urldecode']('%2F') == unquote_plus('%2F')

# Generated at 2022-06-23 10:18:17.487090
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters



# Generated at 2022-06-23 10:18:25.827176
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Simple string
    assert unicode_urlencode('test') == 'test'
    # Non-ASCII string
    assert unicode_urlencode('àéç') == '%C3%A0%C3%A9%C3%A7'
    # Unicode non-ASCII string
    assert unicode_urlencode(u'àéç') == '%C3%A0%C3%A9%C3%A7'
    # Number
    assert unicode_urlencode(1) == '1'
    # Boolean
    assert unicode_urlencode(True) == 'True'
    # List of strings
    assert unicode_urlencode(['a', 'b']) == 'a&b'
    # Tuple of strings

# Generated at 2022-06-23 10:18:35.181456
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc+de') == u'abc%2Bde'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/?def') == u'abc%2F%3Fdef'
    assert unicode_urlencode(u'abc?def') == u'abc%3Fdef'
    assert unicode_urlencode(u'abc?def', for_qs=True) == u'abc%3Fdef'

# Generated at 2022-06-23 10:18:45.435825
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import sys

    # Test Python unicode urlencoding
    assert unicode_urlencode(u'http://foo/bar') == 'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar?a=b&c=d') == 'http%3A//foo/bar%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://foo/bar?a=b&c=d', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar%3Fa%3Db%26c%3Dd'

    # Test Python bytes urlencoding
    assert unicode_urlencode(b'http://foo/bar') == 'http%3A//foo/bar'
    assert unic

# Generated at 2022-06-23 10:18:56.860626
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' urlencode() is the same as urllib.urlencode '''
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    assert unicode_urlencode(u'a') == urlencode(u'a')
    assert unicode_urlencode(u'a&b') == urlencode(u'a&b')
    assert unicode_urlencode(u'a') == u'a'
    assert unicode_urlencode(u'a&b') == u'a%26b'
    assert unicode_urlencode(u'a+b') == u'a%2Bb'
    assert unicode_urlencode(u' ') == u'+'

# Generated at 2022-06-23 10:19:02.631114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    # TODO: Find a better way to check for the module imports
    if HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:19:12.875624
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a b/c') == u'a%20b%2Fc'
    assert unicode_urlencode(u'a b/c', True) == u'a+b%2Fc'
    assert unicode_urlencode(u'\xdf') == u'%DF'
    assert unicode_urlencode(u'\u2713') == u'%E2%9C%93'
    assert to_text(unicode_urlencode(u'1')) == u'1'
    assert to_text(unicode_urlencode(u'\u2713')) == u'%E2%9C%93'
    # Python bug: http://bugs.python.org/issue1712522
    if not PY3:
        assert unicode_

# Generated at 2022-06-23 10:19:13.858508
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)

# Generated at 2022-06-23 10:19:15.807329
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:19:17.322661
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert isinstance(filter_module.filters(), dict)


# Generated at 2022-06-23 10:19:23.490339
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('a') == 'a'
    assert do_urlencode('1') == '1'
    assert do_urlencode('a 1') == 'a+1'
    assert do_urlencode('a+1') == 'a%2B1'
    assert do_urlencode('a b+c') == 'a+b%2Bc'
    assert do_urlencode('a b c') == 'a+b+c'
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'
    assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'



# Generated at 2022-06-23 10:19:26.794238
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode(b'\xc3\xa4') == '%C3%A4'
    else:
        assert unicode_urlencode(u'\xc3\xa4') == '%C3%A4'



# Generated at 2022-06-23 10:19:36.715413
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%2Bb%2Bc') == u'a+b+c'
    assert do_urldecode('a+b+c') == u'a+b+c'
    assert do_urldecode(u'a+b+c') == u'a+b+c'
    assert do_urldecode(u'a%2Bb%2Bc') == u'a+b+c'
    assert do_urldecode('a/b/c') == u'a/b/c'
    assert do_urldecode('a%2Fb%2Fc') == u'a%2Fb%2Fc'
    assert do_urldecode('a%2fb%2fc') == u'a%2fb%2fc'


# Generated at 2022-06-23 10:19:41.809671
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "This+is%20a+test%21"
    assert unicode_urldecode(string) == "This is a test!"


# Generated at 2022-06-23 10:19:49.521817
# Unit test for function do_urlencode
def test_do_urlencode():
    (ret, out, err) = assert_bash_exec('''python -c 'print("{"_":"_"}".encode("utf-8"));' | sed 's/+/%2B/g' | python -c 'import sys, urllib.parse; print(urllib.parse.unquote_plus(sys.stdin.read()))' ''')
    assert ret == 0, "unquote_plus failed:\n%s" % err
    orig = to_text(out, errors='surrogate_or_strict').strip()


# Generated at 2022-06-23 10:19:55.007219
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' Test function do_urlencode '''
    assert do_urlencode(u'https://www.example.com/p?a=1&b=2') == u'https%3A%2F%2Fwww.example.com%2Fp%3Fa%3D1%26b%3D2'
    assert do_urlencode(u'中文') == u'%E4%B8%AD%E6%96%87'
    assert do_urlencode({'a': u'中文', 'b': u'a'}) == u'a=%E4%B8%AD%E6%96%87&b=a'

# Generated at 2022-06-23 10:20:01.701076
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(to_text(b'foo/bar')) == 'foo%2Fbar'
    assert unicode_urlencode(to_text(b'foo/bar'), for_qs=True) == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'


# Generated at 2022-06-23 10:20:11.045960
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%7B%22status%22%3A%20%22ok%22%2C%20%22data%22%3A%20%7B%22token%22%3A%20%22d7f3866d76717e7482c9fe9e9dfdcb57%22%7D%7D') == u'{"status": "ok", "data": {"token": "d7f3866d76717e7482c9fe9e9dfdcb57"}}'

# Generated at 2022-06-23 10:20:21.238100
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(b'foo bar') == u'foo+bar'
    assert do_urlencode('foo bar') == u'foo+bar'
    assert do_urlencode([b'foo', u'bar']) == u'foo&bar'
    assert do_urlencode(['foo', 'bar']) == u'foo&bar'
    assert do_urlencode(b'fo%20o&bar') == u'fo%20o%26bar'
    assert do_urlencode('fo%20o&bar') == u'fo%20o%26bar'
    assert do_urlencode(b'foo=') == u'foo%3D'
    assert do_urlencode('foo=') == u'foo%3D'

# Generated at 2022-06-23 10:20:21.911688
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-23 10:20:31.592385
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_string = u'%s@€–¶ñż' % u'\u05EA\u05E8\u05D1\u05D9'
    assert unicode_urlencode(test_string) == u'%E2%80%A2%D7%AA%D7%A8%D7%91%D7%99@%E2%82%AC%E2%80%93%C2%B6%C3%B1%C5%BC'

# Generated at 2022-06-23 10:20:36.296367
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%21%20bar') == u'foo!!bar'
    assert unicode_urldecode(u'foo%21+bar') == u'foo! bar'



# Generated at 2022-06-23 10:20:44.446470
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic
    if not basic.AnsibleModule:
        from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'decode_me': {'required': False}})
    string = module.params['decode_me']
    result = unicode_urldecode(string)
    module.exit_json(changed=True, result=result)



# Generated at 2022-06-23 10:20:52.763619
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode({u'foo': u'bar', u'key': u'value'}) == u'foo=bar&key=value'

# Generated at 2022-06-23 10:21:02.308002
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(123) == '123'
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('ab+c') == 'ab%2Bc'
    assert unicode_urlencode(u'ab+c') == 'ab%2Bc'
    assert unicode_urlencode(u'ab+c') == 'ab%2Bc'
    assert unicode_urlencode(u'ab++c') == 'ab%2B%2Bc'
    assert unicode_urlencode({'x': 'y'}) == 'x=y'
    assert unicode_urlencode([1, 2]) == '1=2'
    assert unicode_urlencode([1, 2], for_qs=True) == '1&2'
   

# Generated at 2022-06-23 10:21:06.885447
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test urldecode '''
    assert do_urldecode('foo%20bar') == u'foo bar'
    assert do_urldecode('%C3%A8') == u'è'

# Generated at 2022-06-23 10:21:10.652870
# Unit test for function do_urldecode
def test_do_urldecode():
    result = do_urldecode('http%3A%2F%2Ffoo%20bar%2Fbaz%20')
    assert result == 'http://foo bar/baz '

# Generated at 2022-06-23 10:21:19.377546
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == 'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo?a=1&b=2') == 'http%3A%2F%2Ffoo%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo?a=1&b=2', for_qs=True) == 'http%3A%2F%2Ffoo%3Fa%3D1%26b%3D2'


# Generated at 2022-06-23 10:21:26.476282
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%E2%99%A5') == u'♥'
    assert unicode_urldecode('%E2%99%A5%20%E2%99%A5') == u'♥ ♥'
    assert unicode_urldecode('%E2%99%A5+%E2%99%A5') == u'♥ ♥'


# Generated at 2022-06-23 10:21:36.297129
# Unit test for function do_urldecode
def test_do_urldecode():
    # NOTE: We run these tests because of the limitations in the Jinja2
    # library. Jinja2 library provides a urlencode filter but does not
    # provide the inverse.
    #
    # The following is taken from:
    # http://stackoverflow.com/questions/16584551/python-urllib-parse-unquote-vs-url-decode
    # and the legacy unit tests in ansible with minor modifications
    assert do_urldecode("foo") == u"foo"
    assert do_urldecode("param=foo") == u"param=foo"
    assert do_urldecode("param=%20foo") == u"param= foo"
    assert do_urldecode("param+foo=%20foo") == u"param+foo= foo"
    assert do_urld

# Generated at 2022-06-23 10:21:47.528009
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(42) == u'42'
    assert unicode_urlencode(42, for_qs=True) == u'42'
    assert unicode_urlencode(u'héllo') == u'h%C3%A9llo'
    assert unicode_urlencode(u'héllo', for_qs=True) == u'h%C3%A9llo'
    assert unicode_urlencode(u'/héllo') == u'/h%C3%A9llo'
    assert unicode_urlencode(u'/héllo', for_qs=True) == u'/h%C3%A9llo'
    assert unicode_urlencode(u'héllo/?var=val') == u'h%C3%A9llo/?var=val'

# Generated at 2022-06-23 10:21:53.315938
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] is do_urldecode



# Generated at 2022-06-23 10:21:58.369914
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('uri') == 'uri')
    assert(do_urlencode('uri with blanks') == 'uri%20with%20blanks')
    assert(do_urlencode({'a': 'b'}) == 'a=b')
    assert(do_urlencode(['a=1', 'b=2']) == 'a%3D1&b%3D2')

# Generated at 2022-06-23 10:22:05.702629
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode(1) == '1'
    assert do_urlencode(False) == 'false'
    assert do_urlencode({}) == ''
    assert do_urlencode([]) == ''
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode([('a', 'b')]) == 'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode([('a', 'b'), ('c', 'd')]) == 'a=b&c=d'

# Generated at 2022-06-23 10:22:09.233570
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo=bar') == u'foo%3Dbar'
    assert do_urlencode('bär') == u'b%C3%A4r'
    assert do_urlencode({'foo': 'bar', 'baz': 'bäh'}) == u'foo=bar&baz=b%C3%A4h'

# Generated at 2022-06-23 10:22:18.986675
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        from unittest import TestCase
    except ImportError:
        import unittest

        TestCase = unittest.TestCase
    import ansible.utils.unsafe_proxy


# Generated at 2022-06-23 10:22:19.907454
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:22:27.725393
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"Hello World") == u"Hello%20World"
    assert do_urlencode(u"Hello*World") == u"Hello%2AWorld"
    assert do_urlencode(u"Hello/World") == u"Hello/World"
    assert do_urlencode(u"Hello/Worlδ") == u"Hello/Worl%CE%B4"
    assert do_urlencode(u"Hello/Worlδ", for_qs=True) == u"Hello/Worl%CE%B4"

# Generated at 2022-06-23 10:22:31.041850
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_module_instance = FilterModule()
    assert ansible_module_instance.filters() == {
        'urldecode': do_urldecode,
    }
    assert ansible_module_instance.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-23 10:22:43.027402
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('ůůů') == '%C5%AF%C5%AF%C5%AF'
    assert unicode_urlencode('ůůů', for_qs=True) == '%C5%AF%C5%AF%C5%AF'
    assert unicode_urlencode(u'\u043f\u0440\u0438\u0432\u0456\u0442') == '%D0%BF%D1%80%D0%B8%D0%B2%D1%96%D1%82'

# Generated at 2022-06-23 10:22:48.950257
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'http%3A%2F%2Fwww.example.com%2F') == u'http://www.example.com/'
    assert do_urldecode(u'Bad%20value') == u'Bad%20value'


# Generated at 2022-06-23 10:22:50.670576
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)

# Generated at 2022-06-23 10:23:00.392925
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%7E%21%40%23%24%25%5E%26*%28%29_%2B') == "~!@#$%^&*()_+"
    assert do_urldecode(u'%7E%21%40%23%24%25%5E%26*%28%29_%2B') == u"~!@#$%^&*()_+"
    assert do_urldecode('%7e%21%40%23%24%25%5e%26*%28%29_%2b') == "~!@#$%^&*()_+"

# Generated at 2022-06-23 10:23:06.756604
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc 123') == u'abc 123'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2B') == u'+'


# Generated at 2022-06-23 10:23:09.352235
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['urldecode'] == do_urldecode
# --


# Generated at 2022-06-23 10:23:17.782466
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    #
    # Test urldecode filter
    urldecode = filters['urldecode']

    assert urldecode('%20') == ' '
    assert urldecode('%23') == '#'
    assert urldecode('%26') == '&'
    assert urldecode('%3D') == '='
    assert urldecode('%3F') == '?'
    assert urldecode('%5B') == '['
    assert urldecode('%5D') == ']'
    assert urldecode('+') == ' '

    assert urldecode('%25') == '%'
    assert urldecode('%257B') == '%7B'

# Generated at 2022-06-23 10:23:27.303887
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import numbers

    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'a') == u'a'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'+') == u'%2B'
    assert unicode_urlencode(u' ') == u'+'
    assert unicode_urlencode(u' ~/') == u'%20~%2F'
    assert unicode_urlencode(u'a/~') == u'a%2F~'
    assert unicode_urlencode(u'a+b~') == u'a%2Bb~'
    assert unicode_urlencode(u'?') == u'%3F'
    assert unicode_url

# Generated at 2022-06-23 10:23:32.856111
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('%2C') == ','
    else:
        assert unicode_urldecode('%2C') == to_text(b',')



# Generated at 2022-06-23 10:23:37.124362
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import ansible.module_utils.six
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:23:44.102412
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from jinja2 import DictLoader, Environment
    filter_module = FilterModule()
    filters = filter_module.filters()
    env = Environment(loader=DictLoader({'fixtures.j2': '{{ { "var1": "val1" } | urlencode }}',
                                         'fixtures2.j2': '{{ test | urldecode }}'}))
    env.filters.update(filters)
    assert to_text(env.get_template('fixtures.j2').render()) == u'var1=val1'
    assert to_text(env.get_template('fixtures2.j2').render(test=u'val1%3Dval2')) == u'val1=val2'


# Generated at 2022-06-23 10:23:45.579725
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-23 10:23:52.105002
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from jinja2 import DictLoader


# Generated at 2022-06-23 10:23:53.349435
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    return True

# Generated at 2022-06-23 10:24:02.740564
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'Hello world') == u'Hello%20world'
    assert do_urlencode(u'Hello world') != u'Hello world'
    assert do_urlencode(u'Hello world') != u'Hello%20World'
    assert do_urlencode(u'Hello world') == u'Hello+world'
    assert do_urlencode([u'Hello world', u'Foo bar']) == u'Hello%20world&Foo%20bar'
    assert do_urlencode({u'Hello world': 1, u'Foo bar': 2}) == u'Hello%20world=1&Foo%20bar=2'

# Generated at 2022-06-23 10:24:10.692729
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    args = {
        "arg1": "arg1",
        "arg2": "arg2",
        "arg3": "arg3",
        "arg4": {"arg4_1": "arg4_1", "arg4_2": "arg4_2"},
        "arg5": "arg5",
    }
    obj = FilterModule()
    assert obj.filters()["urldecode"]("%E8%BF%99%E5%B1%B1%E7%88%B1%E7%9A%84%E8%BF%99%E6%AC%A1%E6%98%9F") == u"这山爱的这次星"

# Generated at 2022-06-23 10:24:18.087894
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.org/foo/bar') == u'http%3A//example.org/foo/bar'
    assert unicode_urlencode(u'http://example.org/foo/bar', for_qs=True) == u'http%3A%2F%2Fexample.org%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://example.org/foo bar') == u'http%3A//example.org/foo%20bar'
    assert unicode_urlencode(u'http://example.org/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.org%2Ffoo+bar'

# Generated at 2022-06-23 10:24:30.031987
# Unit test for function do_urldecode
def test_do_urldecode():
  from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 10:24:38.044669
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/%7Euser') == "http%3A//example.com/%7Euser"
    assert unicode_urlencode(u'http://example.com/%7Euser', True) == "http%3A%2F%2Fexample.com%2F%257Euser"
    assert unicode_urlencode(u'http://example.com/?user=1&user=2') == "http%3A//example.com/?user%3D1&user%3D2"
    assert unicode_urlencode({'user': '1', 'user2': '2'}) == "user=1&user2=2"

# Generated at 2022-06-23 10:24:42.932242
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2Fhczptl-%7B%7D') == '/hczptl-{}'
    assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'

# Generated at 2022-06-23 10:24:45.223098
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urlencode': do_urlencode, 'urldecode': do_urldecode}



# Generated at 2022-06-23 10:24:48.697710
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo%20bar') == 'foo bar'
    if HAS_URLENCODE:
        assert do_urlencode('foo bar') == 'foo%20bar'

# Generated at 2022-06-23 10:24:57.959402
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%C3%BC") == u"ü"
    assert unicode_urldecode("%C3%BC%20%C3%A9") == u"ü é"
    assert unicode_urldecode("%C3%BC%20%C3%A9%20%e2%82%ac") == u"ü é €"
    assert unicode_urldecode(u"%C3%BC%20%C3%A9%20%e2%82%ac") == u"ü é €"


# Generated at 2022-06-23 10:25:01.160992
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:25:12.905632
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:25:25.589856
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:25:26.204146
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:25:28.186495
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20b+%25c%25d') == 'a b %c%d'


# Generated at 2022-06-23 10:25:33.009304
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test urldecode
    '''
    assert unicode_urldecode(u'"abcd"') == (u'"abcd"')
    assert unicode_urldecode(u'%22abcd%22') == (u'"abcd"')


# Generated at 2022-06-23 10:25:34.236195
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    f.filters()

# Generated at 2022-06-23 10:25:43.713015
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from datetime import date
    from time import time

    t1 = time()
    d1 = date.today()

    assert do_urlencode(u'{ "version": 1.0, "data": [ "abc", 42, true ] }') == u'%7B%20%22version%22%3A%201.0%2C%20%22data%22%3A%20%5B%20%22abc%22%2C%2042%2C%20true%20%5D%20%7D'
    assert do_urlencode(u'Hello world!') == u'Hello%20world%21'

# Generated at 2022-06-23 10:25:50.601308
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'https://example.com/foo/bar') == u'https://example.com/foo/bar'
    assert do_urldecode(u'https://example.com/foo%20bar%2Fbaz') == u'https://example.com/foo bar/baz'
