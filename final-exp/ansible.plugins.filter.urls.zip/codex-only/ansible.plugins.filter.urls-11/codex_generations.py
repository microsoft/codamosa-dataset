

# Generated at 2022-06-23 10:16:00.492245
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo=bar') == 'foo%3Dbar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo&bar=john doe') == 'foo%26bar%3Djohn+doe'

    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar john doe'}) == 'foo=bar+john+doe'

# Generated at 2022-06-23 10:16:01.459035
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:16:04.552810
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    urldecode = filters.get('urldecode')

    assert urldecode != None

# Generated at 2022-06-23 10:16:15.173189
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:16:20.165174
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("a b c") == 'a+b+c'
    assert do_urlencode("a+b+c") == 'a+b+c'
    assert do_urlencode("&=") == '%26%3D'
    assert do_urlencode("S&P 500") == 'S%26P+500'
    assert do_urlencode("foo=bar&baz=fuzz") == 'foo%3Dbar%26baz%3Dfuzz'
    assert do_urlencode("foo=bar&baz=fuzz") == 'foo%3Dbar%26baz%3Dfuzz'

# Generated at 2022-06-23 10:16:24.494043
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(b'foo%3cbar%3e') == u'foo<bar>'
    assert do_urldecode('foo%3cbar%3e') == u'foo<bar>'
    assert do_urldecode(u'foo%3cbar%3e') == u'foo<bar>'

# Generated at 2022-06-23 10:16:27.540233
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%2F') == u'/'


# Generated at 2022-06-23 10:16:39.557674
# Unit test for function do_urldecode
def test_do_urldecode():

    assert do_urldecode('') == ''
    assert do_urldecode('%00') == '\x00'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f/%2F') == '//'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%7E') == '~'
    assert do_urldecode('%21') == '!'
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%40') == '@'
    assert do_urldecode('%23') == '#'

# Generated at 2022-06-23 10:16:41.708872
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%C4%8C%C4%87') == u'/Čć'


# Generated at 2022-06-23 10:16:52.466962
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('string') == 'string'
    assert unicode_urlencode(u'æøå') == u'%C3%A6%C3%B8%C3%A5'
    assert unicode_urlencode('%c3%a6') == '%25c3%25a6'
    assert unicode_urlencode(u'%c3%a6') == u'%25c3%25a6'
    assert unicode_urlencode(u'ę') == u'%C4%99'
    assert unicode_urlencode('%c4%99') == '%25c4%2599'
    assert unicode_urlencode(u'ę') == u'%C4%99'

# Generated at 2022-06-23 10:17:00.341767
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%3Ca%20href%3D%22%2F%22%3EHome%3C%2Fa%3E'
    unicode_string = '%3Ca%20href%3D%22%2F%22%3EHome%3C%2Fa%3E'
    if PY3:
        assert unicode_urldecode(string) == u'%3Ca%20href=%22/%22%3EHome%3C/a%3E'
    else:
        assert unicode_urldecode(string) == u'%3Ca%20href=%22/%22%3EHome%3C/a%3E'

# Generated at 2022-06-23 10:17:07.157896
# Unit test for function do_urldecode
def test_do_urldecode():
    """ Test docs for do_urldecode function """
    # string without symbols,  nothing to decode
    assert do_urldecode('validstring') == 'validstring'
    # string with symbols, decode them
    assert do_urldecode('%5B%7B%5D%7D') == '[{]}'
    # string with spaces
    assert do_urldecode('%20') == ' '
    # string with comma
    assert do_urldecode('%2C') == ','


# Generated at 2022-06-23 10:17:15.889057
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('A&B') == u'A%26B'
    assert do_urlencode('A&B&C=D') == u'A%26B%26C=D'
    assert do_urlencode(['A', 'B']) == u'A&B'
    assert do_urlencode(['A', 'B', 'C']) == u'A&B&C'
    assert do_urlencode({'A': 'A', 'B': 'B'}) == u'A=A&B=B'
    assert do_urlencode({'A': 'A', 'B': 'B', 'C': 'C'}) == u'A=A&B=B&C=C'

# Generated at 2022-06-23 10:17:22.324425
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for method filters of class FilterModule """

    filter_module = FilterModule()

    filters = filter_module.filters()

    assert filters['urldecode'](u'a' * 1024) == u'a' * 1024

    if not HAS_URLENCODE:
        assert filters['urlencode'](u'a' * 1024) == u'a' * 1024

# Generated at 2022-06-23 10:17:32.495684
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 'a b'}) == 'a=a+b'
    assert do_urlencode([('a', 'b')]) == 'a=b'
    assert do_urlencode([('a', 'a b')]) == 'a=a+b'
    assert do_urlencode('abc def') == 'abc+def'
    assert do_urlencode(u'aé') == u'a%C3%A9'
    assert do_urlencode(u'aé'.encode('utf-8')) == u'a%C3%A9'

# Generated at 2022-06-23 10:17:40.686721
# Unit test for function do_urlencode
def test_do_urlencode():
    def assert_urlencode(value, expected):
        actual = do_urlencode(value)
        msg_template = 'do_urlencode is broken: our version of jinja should have been used but is not.\n'
        msg_template += '\n'
        msg_template += 'Value: %s\n'
        msg_template += 'Expected: %s\n'
        msg_template += 'Actual:   %s'
        assert actual == expected, msg_template % (value, expected, actual)

    assert_urlencode('/path/?foo=bar&baz=quux.abc/def', '/path/?foo%3Dbar%26baz%3Dquux.abc/def')

# Generated at 2022-06-23 10:17:44.989270
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None
    if not HAS_URLENCODE:
        assert 'urlencode' in FilterModule.filters(None)


if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:17:53.713749
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo+bar') == 'foo bar'
    assert unicode_urldecode('foo%2Bbar') == 'foo+bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%25bar') == 'foo%bar'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2') == '%2'
    assert unicode_urldecode('%') == '%'



# Generated at 2022-06-23 10:18:03.060707
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import pytest

    class TC:
        value = u'http://example.com/x=1&y=2'
        expected = 'http%3A%2F%2Fexample.com%2Fx%3D1%26y%3D2'
        expectqs = 'http%3A%2F%2Fexample.com%2Fx%3D1%26y%3D2'

        @pytest.fixture(autouse=True)
        def setup(self, monkeypatch):
            monkeypatch.setattr('ansible.module_utils.six.PY3', True)

        def test_urlencode_string(self):
            actual = unicode_urlencode(self.value)
            assert actual == self.expected


# Generated at 2022-06-23 10:18:05.689050
# Unit test for function do_urldecode
def test_do_urldecode():
    # Set the module name to test_do_urldecode
    value = 'test_do_urldecode'

    # Return the result of the test
    return do_urldecode(value)

# Generated at 2022-06-23 10:18:16.761656
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    import sys
    fm = FilterModule()
    for i in fm.filters():
        f = getattr(fm.filters(), i)
        # test for str type
        if sys.version_info >= (3, 0):
            assert isinstance(f(""), str), "%s: not a str" % i
        # test for bytes type
        else:
            assert isinstance(f(""), bytes), "%s: not a bytes" % i
    # test urldecode
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2F') == '/'
    # test encode

# Generated at 2022-06-23 10:18:24.777308
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'asdf+') == u'asdf%2B'
    assert unicode_urlencode(u'àçdf') == u'%C3%A0%C3%A7df'
    assert unicode_urlencode(u'àçdf', for_qs=True) == u'%C3%A0%C3%A7df'
    assert unicode_urlencode(u'asdf/') == u'asdf%2F'
    assert unicode_urlencode(u'asdf/', for_qs=True) == u'asdf%2F'

    # Inputs which are already strings are passed unchanged.
    assert unicode_urlencode('asdf+') == 'asdf%2B'

# Generated at 2022-06-23 10:18:31.442253
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils import basic

    assert basic.do_urldecode('http://example.org/%7Ejohndoe/') == 'http://example.org/~johndoe/'
    assert basic.do_urldecode('http%3A%2F%2Fexample.org%2F%257Ejohndoe%2F') == 'http://example.org/~johndoe/'
    assert basic.do_urldecode('http%3A%2F%2Fexample.org%2F%257Ejohndoe%2F') == 'http://example.org/~johndoe/'
    assert basic.do_urldecode('http%3A%2F%2Fexample.org%2F%257Ejohndoe%2F')

# Generated at 2022-06-23 10:18:39.371740
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u2603') == u'%E2%98%83'
    assert unicode_urlencode(u'\u2603', for_qs=True) == u'%E2%98%83'
    assert unicode_urlencode(u'unicode string') == u'unicode+string'
    assert unicode_urlencode(u'unicode string', for_qs=True) == u'unicode+string'
    assert unicode_urlencode(u'unicode string: /foo') == u'unicode+string%3A+%2Ffoo'
    assert unicode_urlencode(u'unicode string: /foo', for_qs=True) == u'unicode+string%3A+%2Ffoo'
    assert unicode_urlen

# Generated at 2022-06-23 10:18:41.984635
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-23 10:18:53.114818
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Avengers: Endgame') == 'Avengers%3A+Endgame'
    assert do_urlencode(u'Avengers: Endgame') == 'Avengers%3A+Endgame'
    assert do_urlencode(b'Avengers: Endgame') == 'Avengers%3A+Endgame'
    assert do_urlencode({'A': 'B'}) == 'A=B'
    assert do_urlencode([('A', 'B')]) == 'A=B'
    assert do_urlencode([('A', 'B'), ('C', 'D')]) == 'A=B&C=D'
    assert do_urlencode(['A', 'B']) == 'A&B'

# Generated at 2022-06-23 10:19:03.316287
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u"%3Chttp://www.example.com/%3E") == u"<http://www.example.com/>", "Failed to decode %3Chttp://www.example.com/%3E"
    assert do_urldecode(u"abc123_-.:~") == u"abc123_-.:~", "Failed to decode hex string."
    assert do_urldecode(u"%E4%B8%AD%E5%9B%BD") == u"中国", "Failed to decode unicode string."
    assert do_urldecode(u"%C3%A4%C3%B6%C3%BC") == u"äöü", "Failed to decode utf-8 string."


# Generated at 2022-06-23 10:19:06.177074
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() is not None
    assert callable(module.filters()['urldecode'])

# Generated at 2022-06-23 10:19:10.928986
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ascii_str = u"hello world"
    assert unicode_urlencode(ascii_str) == u"hello%20world"
    unicode_str = u"été"
    assert unicode_urlencode(unicode_str) == u"%C3%A9t%C3%A9"



# Generated at 2022-06-23 10:19:14.930217
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello+world') == u'hello world'
    assert unicode_urldecode('%E8%B0%B7%E6%AD%8C') == u'\u8c37\u6b4c'


# Generated at 2022-06-23 10:19:20.493890
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc "def"') == u'abc%20%22def%22'
    assert unicode_urlencode(u'abc+def') == u'abc%20def'
    multi_value = u'''a=1&b=2&b=3&b=a+b+c'''
    assert unicode_urlencode({u'a': 1, u'b': [2, 3, u'a b c']}) == multi_value


# Generated at 2022-06-23 10:19:31.975958
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:19:40.292440
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # None, None
    assert unicode_urldecode(None) is None
    # u'unicode', u'unicode'
    assert unicode_urldecode(u'unicode') == u'unicode'
    # u'unicode', str
    assert unicode_urldecode('unicode') == u'unicode'
    # u'unicode', bytes
    assert unicode_urldecode(b'unicode') == u'unicode'
    # u'%1F', str
    assert unicode_urldecode('%1f') == u'\x1f'
    # u'%1F', bytes
    assert unicode_urldecode(b'%1f') == u'\x1f'
    # u'%1F', str
    assert unicode_

# Generated at 2022-06-23 10:19:41.213570
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a

# Generated at 2022-06-23 10:19:44.776881
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('abc') == 'abc'
    assert do_urldecode('abc%20def') == 'abc def'
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2') == '%2'



# Generated at 2022-06-23 10:19:51.795876
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('abc 123') == 'abc%20123')
    assert(do_urlencode('abc <>') == 'abc%20%3C%3E')
    assert(do_urlencode('abc /') == 'abc%20%2F')
    assert(do_urlencode('abc / def ?') == 'abc%20%2F%20def%20%3F')
    assert(do_urlencode({'key1': 'value1', 'key2': 'value2'}) == 'key1=value1&key2=value2')
    assert(do_urlencode({'key1': 'value1/value2', 'key2': 'value3'}) == 'key1=value1%2Fvalue2&key2=value3')

# Generated at 2022-06-23 10:19:59.426553
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('a c') == 'a+c'
    assert do_urlencode('a/c') == 'a%2Fc'
    assert do_urlencode('a+c') == 'a%2Bc'
    assert do_urlencode('a&c') == 'a%26c'
    assert do_urlencode('a?c') == 'a%3Fc'


# Generated at 2022-06-23 10:20:00.936470
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters()


# Generated at 2022-06-23 10:20:03.937446
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcd%2F%2F1%2F%2Fefgh') == u'abcd//1//efgh'



# Generated at 2022-06-23 10:20:11.953252
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == 'test'
    assert do_urlencode('é') == '%C3%A9'
    assert do_urlencode('1,2,3') == '1%2C2%2C3'
    assert do_urlencode('http://foo.com/bar') == 'http%3A//foo.com/bar'
    assert do_urlencode(['a', 'b']) == 'a&b'
    assert (do_urlencode({'a': 'b', 'c': 'd'}) ==
            'a=b&c=d')

    assert do_urlencode({'a': 'b c'}) == 'a=b+c'

    # Uneven iterable
    assert do_urlencode(('a', )) == 'a'


# Generated at 2022-06-23 10:20:22.120185
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:20:24.192959
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urldecode'] == unicode_urldecode


# Generated at 2022-06-23 10:20:27.854293
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:20:36.346671
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    # Test class has filters() method
    filters = fm.filters()
    assert(filters['urldecode'].__module__ == do_urldecode.__module__)
    assert(filters['urldecode'].__name__ == do_urldecode.__name__)

# Generated at 2022-06-23 10:20:40.524796
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%BC') == u'ü'



# Generated at 2022-06-23 10:20:46.174727
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.com/hello world') == 'http%3A//www.example.com/hello%20world'
    assert unicode_urlencode({'q': 'hello world'}) == 'q=hello%20world'
    assert unicode_urlencode([('q', 'hello world')]) == 'q=hello%20world'
    assert unicode_urlencode(['hello world']) == 'hello+world'


# Generated at 2022-06-23 10:20:51.641985
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert do_urldecode('foo%3Fbar%26baz%3Dboo%3Dfoo') == 'foo?bar&baz=boo=foo'
    assert do_urlencode('foo?bar&baz=boo=foo') == 'foo%3Fbar%26baz%3Dboo%3Dfoo'

# Generated at 2022-06-23 10:20:52.775946
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test.filters() is not None


# Generated at 2022-06-23 10:20:55.449010
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    >>> test_do_urldecode()
    '''

    tests = [
        ('a%20b', 'a b'),
        ('a+b', 'a b'),
        ('a+b+c', 'a b c'),
    ]

    for (in_, out) in tests:
        assert do_urldecode(in_) == out


# Generated at 2022-06-23 10:21:04.380262
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test function do_urldecode '''
    assert do_urldecode('a%20space%21') == u'a space!'
    assert do_urldecode('%20%21') == u' !'
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2f') == u'/'
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%2F1%2F2') == u'/1/2'
    assert do_urldecode('%2F1%2F2') == u'/1/2'

# Generated at 2022-06-23 10:21:16.462784
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode({u'foo': [u'bar', u'baz']}) == u'foo=bar&foo=baz'
    assert do_urlencode({u'foo': [u'bar', u'baz']}) == u'foo=bar&foo=baz'

# Generated at 2022-06-23 10:21:22.755401
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urldecode'] is do_urldecode
    # This is a partial unit test for `do_urlencode`()
    assert FilterModule().filters()['urlencode']({'a': 'b'}) == 'a=b'



# Generated at 2022-06-23 10:21:32.478621
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode({'foo': 'bar baz'}) == 'foo=bar+baz'
    assert do_urlencode({'a': 'b/c d'}) == 'a=b%2Fc+d'
    assert do_urlencode(('a', 'b/c d')) == 'a&b%2Fc+d'

# Generated at 2022-06-23 10:21:43.262519
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('this & that') == u'this%20%26%20that'
    assert do_urlencode('http://foo.com/bar') == u'http%3A//foo.com/bar'
    assert do_urlencode(u'http://foo.com/bar') == u'http%3A//foo.com/bar'
    assert do_urlencode({'a': '/', 'b': {'c': '/', 'd': '//'}}) == u'a=%2F&b=c%3D%2F%3Bd%3D%2F%2F'
    assert do_urlencode(['/', '//']) == u'0=%2F&1=%2F%2F'

# Generated at 2022-06-23 10:21:51.225241
# Unit test for function do_urlencode
def test_do_urlencode():
    import json
    no_uri_chars = '#%&;{}[]+$*()/\,?~`|!@<>'
    no_uri_chars_unicode = no_uri_chars.decode('utf-8')
    assert json.loads(do_urlencode(no_uri_chars)) == no_uri_chars, 'Do not urlencode URI/URL characters'
    assert json.loads(do_urlencode(no_uri_chars_unicode)) == no_uri_chars_unicode, 'Do not urlencode URI/URL Unicode'
    assert do_urlencode({'yes': 'no'}) == 'yes=no'
    assert do_urlencode(['yes', 'no']) == 'yes&no'

# Generated at 2022-06-23 10:22:01.066721
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('{') == '%7B'
    assert do_urlencode('}') == '%7D'
    assert do_urlencode('/') == '%2F'
    assert do_urlencode(';') == '%3B'

    assert do_urlencode('{}') == '%7B%7D'
    assert do_urlencode('{}', True) == '%7B%7D'
    assert do_urlencode('/;', True) == '%2F%3B'

    # NOTE: We need a helper class that does not define __iter__
    class Dummy(object):
        def __init__(self, d):
            self.d = d

        def __getitem__(self, key):
            return self.d[key]



# Generated at 2022-06-23 10:22:10.359022
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test when dict is given
    test_dict = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
    }
    assert unicode_urlencode(test_dict) == 'key1=value1&key2=value2&key3=value3&key4=value4'

    # Test when list is given
    test_list = ['element1', 'element2', 'element3', 'element4']
    assert unicode_urlencode(test_list) == 'element1&element2&element3&element4'

# Generated at 2022-06-23 10:22:21.558670
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(b'hello%2fworld') == u'hello/world'
    assert do_urldecode(b'hello%2Fworld') == u'hello/world'
    assert do_urldecode(b'hello%5Bworld%5D') == u'hello[world]'
    assert do_urldecode(b'hello%20world') == u'hello world'
    assert do_urldecode(u'hello%20world') == u'hello world'
    assert do_urldecode(u'hello%2Fworld') == u'hello/world'
    assert do_urldecode(u'hello%5Bworld%5D') == u'hello[world]'
    assert do_urldecode(u'hello+world') == u'hello world'

# Generated at 2022-06-23 10:22:30.814248
# Unit test for function do_urldecode
def test_do_urldecode():
    assert to_bytes('a%40') == 'a@', "URL encoded character a@ is not preserved"
    assert do_urldecode('a%40b%20c%26d%3D') == u'a@b c&d=', "URL encoded character a@b c&d= is not preserved"
    assert u'a@b c&d=' == do_urldecode('a%40b%20c%26d%3D'), "URL encoded character a@b c&d= is not preserved"

# Generated at 2022-06-23 10:22:33.687134
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert instance


# Generated at 2022-06-23 10:22:44.313249
# Unit test for function do_urlencode
def test_do_urlencode():
    import pytest
    assert do_urlencode('mystring') == 'mystring'
    assert do_urlencode('my string') == 'my%20string'
    assert do_urlencode({'mystring': 'mystring'}) == 'mystring=mystring'
    assert do_urlencode({'mystring': 'my string'}) == 'mystring=my%20string'
    assert do_urlencode({'my string': 'my string'}) == 'my%20string=my%20string'
    assert do_urlencode({'mystring': ('1', '2')}) == 'mystring=1&mystring=2'
    assert do_urlencode({'mystring': ['1', '2']}) == 'mystring=1&mystring=2'

# Generated at 2022-06-23 10:22:47.846075
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2') == '%2'


# Generated at 2022-06-23 10:22:51.654803
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()

    assert filters['urldecode']('f%20o%20o') == 'f o o'
    if not HAS_URLENCODE:
        assert filters['urlencode']('f o o') == 'f%20o%20o'

# Generated at 2022-06-23 10:22:53.530468
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('xxx%2Byyy') == 'xxx+yyy')


# Generated at 2022-06-23 10:22:58.196804
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils._text import to_bytes, to_text
    unicode_urldecode('abc%21')
    unicode_urldecode(to_bytes('abc%21'))
    unicode_urldecode(to_text('abc%21'))
    unicode_urldecode(u'abc%21')


# Generated at 2022-06-23 10:22:59.068552
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:23:10.924633
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'здравствуйте'
    assert unicode_urlencode(string) == '%D0%B7%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5'
    assert unicode_urlencode(string, for_qs=True) == '%D0%B7%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5'



# Generated at 2022-06-23 10:23:16.139348
# Unit test for function do_urldecode
def test_do_urldecode():
    assert 'dag' == do_urldecode('dag')
    assert 'dag' == do_urldecode('dag%')
    assert 'dag wieers' == do_urldecode('dag+wieers')
    assert 'dag wieers' == do_urldecode('dag%20wieers')
    assert 'dag wieers' == do_urldecode('dag%2Bwieers')


# Generated at 2022-06-23 10:23:26.245212
# Unit test for function do_urlencode
def test_do_urlencode():
    if HAS_URLENCODE:
        do_urlencode_assert = do_urlencode
    else:
        do_urlencode_assert = unicode_urlencode
    assert do_urlencode_assert(None) == ''
    assert do_urlencode_assert('') == ''
    assert do_urlencode_assert('/') == '/'
    assert do_urlencode_assert('a') == 'a'
    assert do_urlencode_assert('aA0_') == 'aA0_'
    assert do_urlencode_assert('a b') == 'a+b'
    assert do_urlencode_assert(1) == '1'
    assert do_urlencode_assert(True) == 'True'

# Generated at 2022-06-23 10:23:27.253226
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-23 10:23:38.579140
# Unit test for function do_urlencode
def test_do_urlencode():
    import ansible.module_utils.urls as urls

    for item in urls.FILTER_DATA:
        # py27 does not support dicts in assert items
        if not isinstance(item, dict):
            continue

        test = item.get('test')
        if not isinstance(test, dict):
            continue

        result = item.get('result')
        if not isinstance(result, dict):
            continue

        for (test_input, test_result_value) in iteritems(test):
            test_result = result.get(test_input)
            assert do_urlencode(test_input) == test_result_value
            assert do_urlencode(test_input) == test_result


# Generated at 2022-06-23 10:23:41.210575
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%21%7E%2A%27()%20%22%25%3B%3A%2B%2C%2F') == '!~*\'() "%3B:+,/'


# Generated at 2022-06-23 10:23:53.186731
# Unit test for function do_urlencode
def test_do_urlencode():
    # Empty string
    assert do_urlencode('') == ''

    # Basic string
    assert do_urlencode('test') == 'test'

    # Encoded string
    assert do_urlencode('abc+') == 'abc%2B'

    # String with space
    assert do_urlencode('a b') == 'a+b'

    # String with unicode character
    assert do_urlencode(u'\u2603') == '%E2%98%83'

    # Dict
    assert do_urlencode({'a': '1', 'b': '2'}) == 'a=1&b=2'

    # List of pairs
    assert do_urlencode([('a', '1'), ('b', '2')]) == 'a=1&b=2'

    # List

# Generated at 2022-06-23 10:23:59.549361
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode(u'/') == '%2F'
    assert unicode_urlencode(u'/', True) == '%2F'
    assert unicode_urlencode(u'@') == '@'
    assert unicode_urlencode(u'@', True) == '%40'
    assert unicode_urlencode(u'a=b') == 'a%3Db'
    assert unicode_urlencode(u'a=b', True) == 'a%3Db'
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', True) == 'foo%2Fbar'
    assert unicode

# Generated at 2022-06-23 10:24:08.942036
# Unit test for function do_urlencode
def test_do_urlencode():
    func_name = 'do_urlencode'

# Generated at 2022-06-23 10:24:11.736233
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-23 10:24:18.516197
# Unit test for function do_urldecode
def test_do_urldecode():
    cases = [
        ('%25%20%3a%3a%20%25', '% :: %'),
        ('%25', '%'),
    ]
    for case in cases:
        assert do_urldecode(case[0]) == case[1]



# Generated at 2022-06-23 10:24:21.880470
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode']('%20%21') == ' !'
    assert filters['urlencode'](' !') == '%20%21'

# Generated at 2022-06-23 10:24:24.256598
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%2Fbar') == 'foo/bar'


# Generated at 2022-06-23 10:24:35.195790
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:24:43.741777
# Unit test for function do_urlencode
def test_do_urlencode():

    testcases = {
        u'foo': u'foo',
        u'foo/bar': u'foo%2Fbar',
        u'foo/bar/': u'foo%2Fbar%2F',
        u'foo/bar/with_space': u'foo%2Fbar%2Fwith_space',
        u'foo&bar': u'foo&bar',
        u'foo&bar&baz': u'foo&bar&baz'
    }

    # testdict is a dictionary of dictionaries
    testdict = {
        u'foo': {u'bar': u'baz'},
        u'foo/bar': {u'foo/bar': u'baz'}
    }

    # testlist is a list of lists

# Generated at 2022-06-23 10:24:56.298973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # url encode is tested in a test_jinja2_filters
    # test because it has to be tested with a Jinja2
    # version that has it
    assert unicode_urldecode(unicode_urlencode(u'foo/bar')) == u'foo/bar'
    assert unicode_urldecode(unicode_urlencode(u'foo/äöü')) == u'foo/äöü'
    assert unicode_urldecode(unicode_urlencode(u'foo/бла')) == u'foo/бла'

    assert do_urldecode('foo%2Fbar') == u'foo/bar'
    assert do_urldecode('foo%2Fäöü') == u'foo/äöü'
    assert do_

# Generated at 2022-06-23 10:25:03.270450
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    testcases = [
        (u"abc", u"abc"),
        (u"%20abc%20", u" abc "),
        (u"abc=123", u"abc=123"),
        (u"abc%2B123", u"abc%2B123"),
        (u"abc+123", u"abc 123"),
        (u"abc%2b123", u"abc+123"),
        (u"abc%7C123", u"abc|123"),
    ]
    for (inp, expected) in testcases:
        assert unicode_urldecode(inp) == expected



# Generated at 2022-06-23 10:25:04.995296
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    assert mod.filters()['urldecode'] == do_urldecode
    assert mod.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:25:10.822801
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('key=value') == 'key%3Dvalue'
    assert do_urlencode(['key=value']) == 'key%3Dvalue'
    assert do_urlencode({'key': 'value'}) == 'key=value'
    assert do_urlencode({'key': 'value with spaces'}) == 'key=value%20with%20spaces'

# Generated at 2022-06-23 10:25:11.813655
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:25:16.637092
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode(b'foo%20bar') == u'foo bar'



# Generated at 2022-06-23 10:25:19.436331
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    raw_str = "tmp var file"
    encoded_str = unicode_urlencode(raw_str)
    assert encoded_str == "tmp%20var%20file"


# Generated at 2022-06-23 10:25:29.597681
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://ansible.com/') == u'http%3A//ansible.com/'
    assert unicode_urlencode(u'http://ansible.com/?a=1&b=2') == u'http%3A//ansible.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://ansible.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fansible.com%2F%3Fa%3D1%26b%3D2'



# Generated at 2022-06-23 10:25:40.014056
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%2Fbar') == 'foo/bar'
    assert do_urldecode('foo%2Fbar') == 'foo/bar'
    assert do_urldecode('foo%5Ebar') == 'foo^bar'
    assert do_urldecode('foo%5Ebar') == 'foo^bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo+bar'
    assert do_urldecode('foo+bar') == 'foo+bar'


# Generated at 2022-06-23 10:25:46.260872
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("abcdef") == u"abcdef"
    assert do_urldecode("%2E%2E%2F") == u"../../"
    assert do_urldecode("%2E%2E/") == u"../../"
    assert do_urldecode("%2E%2E%2F%2E%2E%2F%2E%2E%2F") == u"../../../../"
    assert do_urldecode("%2E%2E/%2E%2E/%2E%2E/") == u"../../../../"


# Generated at 2022-06-23 10:25:52.371742
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc/def') == 'abc%2Fdef'
    assert unicode_urlencode('abc/def?x=1;y=2') == 'abc%2Fdef%3Fx%3D1%3By%3D2'
    assert unicode_urlencode('测试') == u'%E6%B5%8B%E8%AF%95'
