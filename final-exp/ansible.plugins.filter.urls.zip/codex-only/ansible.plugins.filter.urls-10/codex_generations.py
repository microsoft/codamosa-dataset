

# Generated at 2022-06-23 10:15:52.076882
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)

# Generated at 2022-06-23 10:16:02.353698
# Unit test for function do_urlencode
def test_do_urlencode():
    # do_urlencode
    assert do_urlencode(u'hello world') == u'hello%20world'
    assert do_urlencode(u'hello world') == do_urlencode(['hello', 'world'])
    assert do_urlencode(u'hello world') == do_urlencode({u'k': u'hello', u'v': u'world'})

    # unicode_urlencode
    assert unicode_urlencode(u'hello world') == u'hello%20world'
    assert unicode_urlencode(u'hello world') == unicode_urlencode(['hello', 'world'])
    assert unicode_urlencode(u'hello world') == unicode_urlencode({u'k': u'hello', u'v': u'world'})

# Generated at 2022-06-23 10:16:13.996579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common.text.converters import to_nice_yaml
    from ansible.module_utils.common.text.converters import to_nice_json
    from ansible.module_utils.common.text.converters import to_nice_text
    from ansible.module_utils.common.text.converters import to_nice_html
    from ansible.module_utils.common.text.converters import to_nice_xml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    ''' Test the filters method of class FilterModule. '''

    filters = FilterModule().filters()

    # Test urldecode

# Generated at 2022-06-23 10:16:25.255860
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"http://www.example.com/foo?bar=1&baz=1") == u'http%3A//www.example.com/foo%3Fbar%3D1%26baz%3D1'
    assert unicode_urlencode(u"http://www.example.com/foo?bar=1&baz=1", for_qs=True) == u'http%3A//www.example.com/foo%3Fbar%3D1%26baz%3D1'
    assert unicode_urlencode(u'http://www.example.com/foo bar?bar=1&baz=1') == u'http%3A//www.example.com/foo%20bar%3Fbar%3D1%26baz%3D1'


# Generated at 2022-06-23 10:16:34.877884
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test for unicode_urldecode
    assert unicode_urldecode("fred%20fred%20fred") == u"fred fred fred"
    assert unicode_urldecode("fred+fred+fred") == u"fred fred fred"
    assert unicode_urldecode("fred%20fred+fred") == u"fred fred fred"
    assert unicode_urldecode(u"ä+ä+ä") == u"ä ä ä"
    assert unicode_urldecode(u"ä%20ä%20ä") == u"ä ä ä"

# Generated at 2022-06-23 10:16:39.843035
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%27%27') == u"''"
    assert unicode_urldecode('%27%20%27') == u"''"
    assert unicode_urldecode('%27%20%27%20%27') == u"'''"


# Generated at 2022-06-23 10:16:42.016855
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # use the module
    module = FilterModule()
    # test the results
    assert 'urldecode' in module.filters()



# Generated at 2022-06-23 10:16:43.109024
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:16:43.698867
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:16:54.389932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%40') == '@'
    assert do_urlencode(do_urldecode('%40')) == '%40'
    assert do_urldecode(do_urlencode('@')) == '@'
    assert do_urlencode([1, 2, 3]) == '1=1&2=2&3=3'
    assert do_urlencode([1, 2, 3]) == '1=1&2=2&3=3'
    assert do_urldecode(do_urlencode([1, 2, 3])) == '1=1&2=2&3=3'
    assert do_urldecode(do_urlencode({'a': 'b', 'c': 'd'})) == 'a=b&c=d'

# Generated at 2022-06-23 10:17:01.289243
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_urldecode = filters.get('urldecode')
    if filter_urldecode is not None:
        assert filter_urldecode('a%2Bb') == 'a+b'
        assert filter_urldecode('a+b') == 'a+b'
        assert filter_urldecode(u'a%2Bb') == u'a+b'
        assert filter_urldecode(u'a+b') == u'a+b'
        assert filter_urldecode(u'a+b'.encode('utf-8')) == u'a+b'
    filter_urlencode = filters.get('urlencode')

# Generated at 2022-06-23 10:17:11.069679
# Unit test for function do_urlencode
def test_do_urlencode():
    assert unicode_urlencode(u'Hello world') == 'Hello+world'
    assert unicode_urlencode(u'sp ace') == 'sp+ace'
    assert unicode_urlencode(u'/sp ace') == '%2Fsp+ace'
    assert unicode_urlencode(u'/?sp ace') == '%2F%3Fsp+ace'
    assert unicode_urlencode(u'?/sp ace') == '%3F%2Fsp+ace'
    assert unicode_urlencode(u'key=value') == 'key%3Dvalue'
    assert unicode_urlencode(u'key = value') == 'key+%3D+value'

    assert do_urlencode({'key': 'value'}) == 'key=value'
    assert do_url

# Generated at 2022-06-23 10:17:15.412009
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # When: I create an instance of FilterModule
    filter_module = FilterModule()

    # When: I call filter on the instance
    # Then: I get expected filter
    assert filter_module.filters() == {'urldecode': do_urldecode}

# Generated at 2022-06-23 10:17:17.397472
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__doc__ == ''' Ansible core jinja2 filters '''
    assert FilterModule.filters.__doc__ == 'Return a mapping of filters to methods.'


# Generated at 2022-06-23 10:17:29.128678
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def encode(string, for_qs=False):
        return unicode_urlencode(string, for_qs)

    assert encode(u"hello world") == u'hello%20world'
    assert encode(u"hello world", True) == u'hello+world'
    assert encode(u"/") == u'/'
    assert encode(u"this is a string") == u'this%20is%20a%20string'
    assert encode(u"this is a string", True) == u'this+is+a+string'
    assert encode(u"this is a string", True) != u'this%20is%20a%20string'
    assert encode(u"this is a string") != u'this+is+a+string'


# Generated at 2022-06-23 10:17:40.097091
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%2Bdef') == u'abc+def'
    assert unicode_urldecode('abc+def') == u'abc def'
    assert unicode_urldecode('abc%2B%2Bdef') == u'abc++def'
    assert unicode_urldecode('/a/b/c') == u'/a/b/c'
    assert unicode_urldecode('/a/b/c/') == u'/a/b/c/'
    assert unicode_urldecode('%2Fa%2Fb%2Fc%2F') == u'/a/b/c/'

# Generated at 2022-06-23 10:17:50.721681
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar+baz') == 'foo%2Bbar%2Bbaz'
    assert do_urlencode(u'fóo') == 'f%C3%B3o'
    assert do_urlencode({"a": "b"}) == 'a=b'
    assert do_urlencode(["a", "b"]) == 'a=b'
    assert do_urlencode(("a", "b")) == 'a=b'
    assert do_urlencode(None) == ''
    assert do_urlencode(object()) == ''


# Generated at 2022-06-23 10:18:00.798498
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urldecode'].__name__ == do_urldecode.__name__
    assert FilterModule().filters()['urldecode'].__doc__ == do_urldecode.__doc__
    try:
        assert FilterModule().filters()['urlencode'].__name__ == do_urlencode.__name__
        assert FilterModule().filters()['urlencode'].__doc__ == do_urlencode.__doc__
    except:
        assert FilterModule().filters()['urlencode'].__name__ == do_urlencode.__name__
        assert FilterModule().filters()['urlencode'].__doc__ == do_urlencode.__doc__


# Generated at 2022-06-23 10:18:03.341579
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2Fetc%2Fmotd') == '/etc/motd'
    assert do_urldecode('%2Fetc%2Fpasswd') == '/etc/passwd'



# Generated at 2022-06-23 10:18:05.653487
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("%2Ftest") == "/test"
    assert do_urldecode("%2Ftest") == "/test"


# Generated at 2022-06-23 10:18:16.698240
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"http://www.example.com/%7Eusername/") == u"http%3A//www.example.com/%7Eusername/"
    assert unicode_urlencode(u"http://www.example.com/~username/") == u"http%3A//www.example.com/%7Eusername/"
    assert unicode_urlencode(u"http://www.example.com/%7Eusername/?q=%7E") == u"http%3A//www.example.com/%7Eusername/?q=~"
    assert unicode_urlencode(u"http://www.example.com/~username/?q=~") == u"http%3A//www.example.com/%7Eusername/?q=~"


# Generated at 2022-06-23 10:18:26.644164
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils import basic

    filter_module = FilterModule()
    filters = filter_module.filters()

    assert type(filters).__name__ == 'dict'
    assert 'urldecode' in filters
    assert 'urlencode' in filters

    assert type(filters['urldecode']).__name__ == 'function'
    assert type(filters['urlencode']).__name__ == 'function'

    string = '%0a%23%40%20%25%3B%2F%3F%2B%26'
    assert filters['urldecode'](string) == '\n#@ %;/?+&'

    string = '\n#@ %;/?+&'
    string

# Generated at 2022-06-23 10:18:30.442632
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urldecode' in FilterModule().filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in FilterModule().filters()

# Generated at 2022-06-23 10:18:32.400233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters() is not None



# Generated at 2022-06-23 10:18:37.040367
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A5') == u'\xe5'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'



# Generated at 2022-06-23 10:18:42.254373
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """This test is for FilterModule constructor

        Args:
            None
        Returns:
            None
        Raises:
            None
    """
    assert FilterModule().filters()

# Generated at 2022-06-23 10:18:48.492170
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def test(s):
        assert unicode_urlencode(s) == do_urldecode(do_urlencode(s))
    test(u'foo')
    test(u'foo/bar')
    test(u'foo+bar')
    test(u'föö')
    test(u'foo/bär')
    test(u'föö/bär')

# Generated at 2022-06-23 10:18:58.033437
# Unit test for function do_urldecode
def test_do_urldecode():
    assert 'https://www.example.com/?query=1&name=foo+bar' == do_urldecode('https%3A%2F%2Fwww.example.com%2F%3Fquery%3D1%26name%3Dfoo%20bar')
    assert 'https://www.example.com/?query=1&name=foo+bar' == do_urldecode(b'https%3A%2F%2Fwww.example.com%2F%3Fquery%3D1%26name%3Dfoo%20bar')


# Generated at 2022-06-23 10:19:00.897894
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2Fusr%2Flocal%2Fbin') == u'/usr/local/bin'



# Generated at 2022-06-23 10:19:09.779899
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(1) == u'1'
    assert do_urlencode('http://www.google.com/q=test/') == u'http%3A%2F%2Fwww.google.com%2Fq%3Dtest%2F'
    assert do_urlencode({'a': '1', 'b': '2'}) == u'a=1&b=2'
    assert do_urlencode(['a', '1']) == u'a=1'
    assert do_urlencode(('a', '1')) == u'a=1'

# Generated at 2022-06-23 10:19:16.567886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of FilterModule
    fm = FilterModule()

    # Test the urldecode function of FilterModule
    assert 'n=1&s=abc' == fm.filters().get('urldecode')('n%3D1%26s%3Dabc')

    # Test the urlencode function of FilterModule
    assert 'n%3D1%26s%3Dabc' == fm.filters().get('urlencode')('n=1&s=abc')

# Generated at 2022-06-23 10:19:22.828391
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' unit test for function unicode_urldecode '''
    assert unicode_urldecode(u'https%3A%2F%2Fgithub.com%2Fansible%2Fansible') == u'https://github.com/ansible/ansible'
    assert unicode_urldecode(u'https://github.com/ansible/ansible') == u'https://github.com/ansible/ansible'
    assert unicode_urldecode(u'https://github.com/ansible/ansible/%7B%7D') == u'https://github.com/ansible/ansible/{}'



# Generated at 2022-06-23 10:19:26.894739
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo%20%23bar') == 'foo #bar'


# Generated at 2022-06-23 10:19:36.819263
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    fm = FilterModule()
    test_data = {
        "urldecode": [
            {
                "input": "%F0%9D%8C%8E%F0%9D%8C%86%F0%9D%8C%86",
                "output": u"𝌎𝌆𝌆"
            },
            {
                "input": "%20",
                "output": u" "
            }
        ]
    }
    for test_name, test_data_list in iteritems(test_data):
        for test_data in test_data_list:
            fm_filter = fm.filters()[test_name]
            # NOTE: Python3 returns byte string, we convert to unicode string

# Generated at 2022-06-23 10:19:45.556067
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("Testing FilterModule.filters()")
    to_decode = "http%3A%2F%2Fgoogle.com%2F"
    to_decode_parsed = "http://google.com/"
    to_encode = "http://google.com/"
    to_encode_parsed = "http%3A%2F%2Fgoogle.com%2F"
    fm = FilterModule()
    filters = fm.filters()
    if filters['urldecode'](to_decode) != to_decode_parsed:
        raise AssertionError("urldecode failed")
    if filters['urlencode'](to_encode) != to_encode_parsed:
        raise AssertionError("urlencode failed")

# Run unit tests

# Generated at 2022-06-23 10:19:47.198334
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urldecode' in module.filters().keys()



# Generated at 2022-06-23 10:19:52.498167
# Unit test for function do_urlencode
def test_do_urlencode():
    test_input = (
        (b'hello world', b'hello%20world'),
        (b'hello+world', b'hello%2Bworld'),
    )

    for i, o in test_input:
        result = do_urlencode(to_text(i))
        assert result == to_text(o)


# Generated at 2022-06-23 10:20:01.174369
# Unit test for function do_urldecode
def test_do_urldecode():
    # Test basic functionality
    my_string = 'a%2Bb%2Fc'
    my_actual = unicode_urldecode(my_string)
    my_expected = 'a+b/c'
    if my_actual != my_expected:
        print("Expected '%s', got '%s'" % (my_expected, my_actual))
        return 1

    # Test None
    my_actual = unicode_urldecode(None)
    if my_actual is not None:
        print("Expected None, got '%s'" % my_actual)
        return 1

    # Test number
    my_string = 12345
    my_actual = unicode_urldecode(my_string)
    my_expected = '12345'

# Generated at 2022-06-23 10:20:03.789121
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)


# Unit tests for class FilterModule function do_urlencode

# Generated at 2022-06-23 10:20:11.892249
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode(u'/bar') == '%2Fbar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'bar+foo') == 'bar%2Bfoo'
    assert unicode_urlencode(u'foo&bar') == 'foo&bar'
    assert unicode_urlencode(u'foo=bar') == 'foo=bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode(u'bar+foo', for_qs=True) == 'bar%2Bfoo'

# Generated at 2022-06-23 10:20:22.046769
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(u'fôo' == unicode_urldecode('f%C3%B4o'))
    assert(u'/fôo/bár' == unicode_urldecode('/f%C3%B4o/b%C3%A1r'))
    assert(u'fôo' == unicode_urldecode('f%c3%b4o'))
    assert(u'/fôo/bár' == unicode_urldecode('/f%c3%b4o/b%c3%a1r'))
    assert(u'fôo' == unicode_urldecode(b'f%C3%B4o'))

# Generated at 2022-06-23 10:20:30.122570
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.filters(FilterModule()) == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }
    assert FilterModule.filters(FilterModule())['urldecode']('%26%2343%3B') == u'&#43;'
    assert FilterModule.filters(FilterModule())['urlencode'](u'%&_') == u'%25%26%5F'
    assert FilterModule.filters(FilterModule())['urlencode']({'key': u'+'}) == u'key=%2B'



# Generated at 2022-06-23 10:20:33.536166
# Unit test for function do_urlencode
def test_do_urlencode():
    # Simple tests
    assert do_urlencode('') == ''
    assert do_urlencode('a') == 'a'
    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode('a+b') == 'a%2Bb'
    assert do_urlencode('a%2Bb') == 'a%252Bb'
    assert do_urlencode('a/b') == 'a%2Fb'
    assert do_urlencode('a&b') == 'a%26b'

    # dicts
    assert do_urlencode({}) == ''
    assert do_urlencode({'a': 'b'}) == 'a=b'

    # lists
    assert do_urlencode([]) == ''

# Generated at 2022-06-23 10:20:40.581927
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test FilterModule.filters()
    fm = FilterModule()
    assert isinstance(fm,FilterModule)

    fm_filters = fm.filters()
    assert 'urldecode' in fm_filters
    assert 'urlencode' in fm_filters

    # Test FilterModule.filters()
    assert isinstance(fm_filters['urldecode'], type(do_urldecode))
    assert isinstance(fm_filters['urlencode'], type(do_urlencode))


# Generated at 2022-06-23 10:20:45.032684
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/a/b/c/') == '/a%2Fb%2Fc%2F'
    assert do_urlencode(['/a/b/c/', '/d/e/f/']) == '/a%2Fb%2Fc%2F&/d%2Fe%2Ff%2F'

# Generated at 2022-06-23 10:20:55.431966
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == u'foo'
    assert unicode_urlencode('foo bar') == u'foo+bar'
    assert unicode_urlencode('foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode('foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode('foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode({'a': 1, 'b': 2}) == u'a=1&b=2'
    assert unicode_urlencode(['a', 1, 'b', 2]) == u'a=1&b=2'


# Generated at 2022-06-23 10:20:56.036066
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:21:04.794453
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    expected_do_urlencode_dict = 'ansible=awesome&j2=rocks'
    expected_do_urlencode_array = 's=1&s=2&s=3'
    expected_do_urlencode_string = 'test+string'

    filter_ = FilterModule()
    filter_keys = filter_.filters().keys()
    assert 'urldecode' in filter_keys

    if not HAS_URLENCODE:
        assert 'urlencode' in filter_keys

    assert do_urlencode({'ansible': 'awesome', 'j2': 'rocks'}) == expected_do_urlencode_dict
    assert do_urlencode(['1', '2', '3']) == expected_do_urlencode_array
    assert do_urlencode('test string')

# Generated at 2022-06-23 10:21:07.983033
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
   assert unicode_urlencode('foo/bar') == u'foo%2Fbar'
   assert unicode_urlencode('foo/bar', for_qs=True) == u'foo%2Fbar'



# Generated at 2022-06-23 10:21:12.154829
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%BA%AC%E4%BA%AC') == u'京京'



# Generated at 2022-06-23 10:21:13.093438
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:21:20.363801
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Simple string with no special characters
    assert unicode_urldecode('foobar') == u'foobar'

    # String with a single percent character
    assert unicode_urldecode('foo%bar') == u'foo%bar'

    # Test string with percent character and following hexadecimal
    assert unicode_urldecode('foo%2Ebar') == u'foo.bar'
    assert unicode_urldecode('foo%4Abar') == u'foo:bar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'

    # Test string with multiple encoded characters
    assert unicode_urldecode('foo%2Ebar%7C%20foobar') == u'foo.bar| foobar'

    # Test string with multiple encoded characters
    assert unic

# Generated at 2022-06-23 10:21:27.394668
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode(b'unicode: \xe2\x98\x83\n') == u'unicode%3A+%E2%98%83%0A'
    assert do_urlencode(u'unicode: \u2603\n') == u'unicode%3A+%E2%98%83%0A'

    assert do_urlencode({'x': 'y'}) == u'x=y'
    assert do_urlencode([('x', 'y'), ('x', 'y')]) == u'x=y&x=y'

# Generated at 2022-06-23 10:21:36.934526
# Unit test for function do_urldecode
def test_do_urldecode():
    # Test case when the parameter is a string
    assert do_urldecode('abc') == 'abc'
    assert do_urldecode('a+b%20c') == 'a b c'
    assert do_urldecode('a+b%20c%2Fd') == 'a b c/d'
    assert do_urldecode('a+b%20c%2Fd%3Df') == 'a b c/d=f'
    assert do_urldecode('a+b%20c%2Fd%3Df%26g') == 'a b c/d=f&g'
    assert do_urldecode('%7B%7B%20myvar%20%7D%7D') == '{{ myvar }}'

    # Test case when the parameter is a

# Generated at 2022-06-23 10:21:47.701383
# Unit test for function do_urlencode
def test_do_urlencode():
    # encode string
    assert do_urlencode("string") == "string"
    # encode integer
    assert do_urlencode(42) == "42"
    # encode nested dictionary
    assert do_urlencode({'key1': {'key2': 'value2'}}) == "key1=%7B%27key2%27%3A+%27value2%27%7D"
    # encode list of strings
    assert do_urlencode(["string1", "string2", "string3"]) == "string1&string2&string3"
    # encode list of dictionaries

# Generated at 2022-06-23 10:21:53.318013
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert(hasattr(module, 'filters'))
    filters = module.filters()
    assert('urldecode' in filters)



# Generated at 2022-06-23 10:22:00.756522
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\xe4\xf6\xfc') == u'%C3%A4%C3%B6%C3%BC'
    assert unicode_urlencode(u'\xe4\xf6\xfc', for_qs=True) == u'%C3%A4%C3%B6%C3%BC'
    assert unicode_urlencode(u'\xe4&\xf6=\xfc') == u'%C3%A4%26%C3%B6%3D%C3%BC'
    assert unicode_urlencode(u'\xe4&\xf6=\xfc', for_qs=True) == u'%C3%A4%26%C3%B6%3D%C3%BC'
   

# Generated at 2022-06-23 10:22:02.077437
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None
    assert callable(filter_module.filters)

# Generated at 2022-06-23 10:22:03.261447
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-23 10:22:14.812920
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo@bar') == u'foo%40bar'
    assert unicode_urlencode(u'foo@bar', for_qs=True) == u'foo%40bar'

    # Non-ASCII unicode
    assert unicode_urlencode(u'\u20AC') == u'%E2%82%AC'
    assert unicode_urlencode(u'\u20AC', for_qs=True) == u'%E2%82%AC'

    # Non-ASCII str (Latin-1)

# Generated at 2022-06-23 10:22:19.907515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C2%A9') == u'\u00A9'
    assert unicode_urldecode('%25C2%25A9') == u'%C2%A9'
    assert unicode_urldecode('%2FC2%2FA9') == u'%2FC2%2FA9'



# Generated at 2022-06-23 10:22:29.891129
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("string") == 'string'
    assert do_urlencode("'") == '%27'
    assert do_urlencode("&&") == '%26%26'
    assert do_urlencode("string ' ' string") == 'string+%27+%27+string'

    assert do_urlencode(["string"]) == 'string'
    assert do_urlencode(("string",)) == 'string'
    assert do_urlencode(("string", "string")) == 'string&string'
    assert do_urlencode(("string", "string", "string")) == 'string&string&string'
    assert do_urlencode(("string", "string", "string"), for_qs=True) == 'string&string&string'

# Generated at 2022-06-23 10:22:42.952961
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit test for method filters of class FilterModule'''
    import os
    import io
    import tempfile
    import shutil
    import unittest
    import ansible.constants as C
    import ansible.utils.template as template
    import ansible.plugins.filter.core as filter_core

    from ansible.compat.tests import mock

    class TestFilterModule(unittest.TestCase):
        '''Class for testing filters of class FilterModule'''

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.flags(module_path=[self.test_dir])

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def _make_module(self, module_name, module_code):
            module_code

# Generated at 2022-06-23 10:22:45.309970
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_filter = FilterModule()
    ansible_filter.filters()


# Generated at 2022-06-23 10:22:55.047579
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'My Name') == u'My Name'
    assert do_urldecode(u'My+Name') == u'My Name'
    assert do_urldecode(u'My%20Name') == u'My Name'
    assert do_urldecode(u'My%26Name') == u'My&Name'
    assert do_urldecode(u'My%2BName') == u'My+Name'
    assert do_urldecode(u'My%25Name') == u'My%Name'
    assert do_urldecode(u'%3e%3d+1') == u'>= 1'
    assert do_urldecode(u'%3C%3D+2') == u'<= 2'



# Generated at 2022-06-23 10:23:00.098847
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('http%3A%2F%2Ffoo.example.org%2F') == 'http://foo.example.org/'
    assert do_urlencode('http://foo.example.org/') == 'http%3A%2F%2Ffoo.example.org%2F'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'

# Generated at 2022-06-23 10:23:11.555967
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # Test string encoding
    input_data = u'Totò'
    output_data = unicode_urlencode(input_data)
    assert output_data == u'Tot%C3%B2'

    # Test dict encoding
    input_data = {'a':u'Totò', 'b':u'Sotto'}
    output_data = unicode_urlencode(input_data)
    assert output_data == u'a=Tot%C3%B2&b=Sotto'

    # Test list encoding
    input_data = [u'Totò', u'Sotto']
    output_data = unicode_urlencode(input_data)
    assert output_data == u'Tot%C3%B2&Sotto'

    return


# Generated at 2022-06-23 10:23:23.484187
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(None) is None
    assert do_urldecode('a') == 'a'
    assert do_urldecode(b'a') == 'a'
    assert do_urldecode('foo bar') == 'foo bar'
    assert do_urldecode('+') == ' '
    assert do_urldecode(b'+') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%22') == '"'
    assert do_urldecode('%25') == '%'
    assert do_urldecode('%2C') == ','

# Generated at 2022-06-23 10:23:26.704726
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert 'urlencode' in filters
    assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:23:33.693145
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test filter module
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert callable(filters['urldecode'])
    assert callable(filters['urlencode'])


# Generated at 2022-06-23 10:23:42.108648
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Given an empty string
    string = ''
    # When we url-encode it
    result = unicode_urlencode(string)
    # Then expect an empty string
    assert result == ''

    # Given an non-string (int)
    string = 100
    # When we url-encode it
    result = unicode_urlencode(string)
    # Then expect an empty string
    assert result == '100'

    # Given a string containing chars
    string = 'abc-áéíóú'
    # When we url-encode it
    result = unicode_urlencode(string)
    # Then expect a string containing the converted chars
    assert result == 'abc-%C3%A1%C3%A9%C3%AD%C3%B3%C3%BA'

    # Given

# Generated at 2022-06-23 10:23:46.584139
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in f.filters()


# Generated at 2022-06-23 10:23:55.226628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2f%2f%2f') == u'///'
    assert unicode_urldecode(u'%2f%2f%2f') == u'///'
    assert unicode_urldecode(u'%2f%2f%2f') == u'///'
    assert unicode_urldecode(u'%2F%2F%2F') == u'///'
    assert unicode_urldecode(u'+++') == u'+++'
    assert unicode_urldecode(u'+++') == u'+++'
    assert unicode_urldecode(u'+++') == u'+++'


# Generated at 2022-06-23 10:24:00.166256
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' Return Encoded URL '''
    actual_urlencode = do_urlencode(['http://test.com/?foo=bar&foo=baz'])
    expected_urlencode = u'http%3A%2F%2Ftest.com%2F%3Ffoo%3Dbar%26foo%3Dbaz'
    assert actual_urlencode == expected_urlencode

# Generated at 2022-06-23 10:24:03.380639
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == '\u00e9'
    assert unicode_urldecode('%25C3%25A9') == '%C3%A9'


# Generated at 2022-06-23 10:24:10.967893
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    # Examples from https://docs.python.org/2/library/urllib.html#urllib.quote_plus
    assert unicode_urlencode(u'foo bar') == quote_plus(b'foo bar')
    assert unicode_urlencode(u'paris & orléans') == quote_plus(b'paris & orl\xc3\xa9ans')
    assert unicode_urlencode(u'foo b&ar') == quote_plus(b'foo b&ar')
    # Examples from https://docs.python.org/2/library/urllib.html#urllib.quote

# Generated at 2022-06-23 10:24:22.031626
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'A+B') == u'A%20B'
    assert do_urlencode([u'A', u'B']) == u'A&B'
    assert do_urlencode({'A': 'B'}) == u'A=B'
    assert do_urlencode({u'A': u'B C'}) == u'A=B%20C'
    assert do_urlencode({u'A': u'B C'}) == u'A=B%20C'



# Generated at 2022-06-23 10:24:29.987489
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/foo/bar') == '%2Ffoo%2Fbar'
    assert do_urlencode('/foo/bar/') == '%2Ffoo%2Fbar%2F'
    assert do_urlencode({'a': 'f=a&b', 'b': 'bar'}) == 'a=f%3Da%26b&b=bar'
    assert do_urlencode(['foo', 'bar=baz']) == 'foo&bar%3Dbaz'

# Generated at 2022-06-23 10:24:38.044389
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('hello world') == 'hello%20world'
    assert do_urlencode('http://foo.com') == 'http%3A%2F%2Ffoo.com'
    assert do_urlencode('http://foo.com/') == 'http%3A%2F%2Ffoo.com%2F'
    assert do_urlencode('http://foo.com/?') == 'http%3A%2F%2Ffoo.com%2F%3F'
    assert do_urlencode('http://foo.com/?') == 'http%3A%2F%2Ffoo.com%2F%3F'

# Generated at 2022-06-23 10:24:50.283283
# Unit test for function do_urldecode
def test_do_urldecode():
    # Test various arguments and the handling of None
    assert do_urldecode(None) is None
    assert do_urldecode('') == ''
    assert do_urldecode('%5C') == '\\'
    assert do_urldecode('%5b') == '['
    assert do_urldecode('%5B') == '['
    assert do_urldecode('%5D') == ']'
    assert do_urldecode('%5d') == ']'
    assert do_urldecode('%60') == '`'
    assert do_urldecode('%7B') == '{'
    assert do_urldecode('%7b') == '{'
    assert do_urldecode('%7D') == '}'
    assert do

# Generated at 2022-06-23 10:25:01.323548
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.jinja2 import AnsibleJ2
    from ansible.utils.vars import merge_hash
    import yaml

    # urldecode
    wrapped_filter_func = AnsibleJ2.get_filter_func(None, 'urldecode')
    assert wrapped_filter_func(u'foo') == u'foo'
    assert wrapped_filter_func(u'foo%44bar') == u'foo,bar'
    assert wrapped_filter_func(u'foo%20bar') == u'foo bar'

    # urlencode
    if not HAS_URLENCODE:
        wrapped_filter_func = AnsibleJ2.get_filter_func(None, 'urlencode')
        assert wrapped_filter_func(u'foo') == u'foo'
        assert wrapped_filter

# Generated at 2022-06-23 10:25:07.566045
# Unit test for function do_urlencode
def test_do_urlencode():
    _assert_equal(do_urlencode(u'fôö'), u'f%C3%B4%C3%B6')
    _assert_equal(do_urlencode(u'fôö'), do_urlencode(u'fôö'.encode('utf-8')))
    _assert_equal(do_urlencode(u'fôö'.encode('utf-8')), do_urlencode(u'fôö'.encode('utf-8')))

    _assert_equal(do_urlencode({'fôö': u'bå'}), u'f%C3%B4%C3%B6=b%C3%A5')

# Generated at 2022-06-23 10:25:12.798519
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:25:17.764569
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abcABC123') == 'abcABC123'
    assert do_urlencode('abcABC 123#$') == 'abcABC%20123%23%24'
    assert do_urlencode('abcABC 123#$') == 'abcABC+123%23%24'

    assert (do_urlencode({'a': 'b', 'c': 'd'}) == u'a=b&c=d')

    assert (do_urlencode({'a': ' '}) == 'a=+')

    assert (do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c')
    assert (do_urlencode({'a': 'b', 'c': ['d', 'e']}) == 'a=b&c=d&c=e')

# Generated at 2022-06-23 10:25:23.875295
# Unit test for function do_urlencode
def test_do_urlencode():
    """
        Unit test for function do_urlencode
    """
    from ansible.module_utils import basic

    assert do_urlencode('test') == u'test'
    assert do_urlencode('test/test') == u'test%2Ftest'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == u'a=b&c=d'
    assert do_urlencode(['a', 'b', 'c']) == u'a&b&c'
    assert do_urlencode(('a', 'b', 'c')) == u'a&b&c'
    assert do_urlencode('test/test') == u'test%2Ftest'

    assert do_urlencode(u'test') == u'test'
    assert do_

# Generated at 2022-06-23 10:25:26.268448
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    type = FilterModule
    module = FilterModule()
    assert(type.filters(type) == module.filters())

# Generated at 2022-06-23 10:25:37.302151
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.foo.com/') == 'http%3A//www.foo.com/'
    assert unicode_urlencode('http://www.foo.com/', for_qs=True) == 'http%3A%2F%2Fwww.foo.com%2F'
    assert unicode_urlencode({'a': 'b'}) == 'a=b'
    assert unicode_urlencode({'a': 'b'}, for_qs=True) == 'a=b'
    assert unicode_urlencode([('a', 'b')]) == 'a=b'
    assert unicode_urlencode([('a', 'b')], for_qs=True) == 'a=b'


# Generated at 2022-06-23 10:25:42.103755
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc+123') == u"abc 123"
    assert unicode_urldecode(u'%20') == u" "
    assert unicode_urldecode(u'%C3%A0%C3%A1') == u"àá"


# Generated at 2022-06-23 10:25:54.810636
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo bar&baz') == u'foo+bar%26baz'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'foo bar=baz') == u'foo+bar%3Dbaz'
    assert do_urlencode(u'foo&bar=baz') == u'foo%26bar%3Dbaz'
    assert do_urlencode(u'foo bar&baz=qux') == u