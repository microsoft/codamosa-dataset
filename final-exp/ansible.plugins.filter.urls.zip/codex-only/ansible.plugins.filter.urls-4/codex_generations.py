

# Generated at 2022-06-23 10:16:00.376222
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == '', 'do_urlencode with empty string'
    assert do_urlencode('a') == 'a', 'do_urlencode with one letter'
    assert do_urlencode('ab') == 'ab', 'do_urlencode with two letters'
    assert do_urlencode('a b') == 'a+b', 'do_urlencode with spaces'
    assert do_urlencode('a+b') == 'a%2Bb', 'do_urlencode with +'
    assert do_urlencode(['a', 'b']) == 'a&b', 'do_urlencode with list'
    assert do_urlencode(('a', 'b')) == 'a&b', 'do_urlencode with tuple'
    assert do_urlen

# Generated at 2022-06-23 10:16:01.776616
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-23 10:16:05.367303
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == b'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == b'foo+bar'

# Generated at 2022-06-23 10:16:11.053241
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    string = '+'
    obj1 = unicode_urldecode(string)
    obj2 = do_urldecode(string)
    assert obj1 == obj2

    string = '+'
    obj1 = unicode_urlencode(string)
    obj2 = do_urlencode(string)
    assert obj1 == obj2

# Generated at 2022-06-23 10:16:16.597600
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'+') == u'+'
    assert unicode_urlencode(u'%') == u'%25'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'+', for_qs=True) == u'%2B'
    assert unicode_urlencode(u'%', for_qs=True) == u'%25'
    assert unicode_urlencode(u'/', for_qs=True) == u'%2F'



# Generated at 2022-06-23 10:16:23.302922
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' Basic tests of urlencode filter '''
    assert do_urlencode('/path') == '%2Fpath'
    assert do_urlencode('/path?query') == '%2Fpath%3Fquery'
    assert do_urlencode({'key': 'value'}) == 'key=value'
    assert do_urlencode({'key': 'value', 'k2': 'v2'}) == 'key=value&k2=v2'

# Generated at 2022-06-23 10:16:28.512939
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'&=' == unicode_urldecode('%26%3D')
    assert u'中文测试' == unicode_urldecode('%E4%B8%AD%E6%96%87%E6%B5%8B%E8%AF%95')


# Generated at 2022-06-23 10:16:33.163434
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%2Fusr%2Fbin%2Fpython') == u'/usr/bin/python'



# Generated at 2022-06-23 10:16:34.067511
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:16:42.096078
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fwww.example.com%2F') == 'http://www.example.com/'
    assert do_urldecode('http%3A%2F%2Fwww.example.com%2F%20bar') == 'http://www.example.com/ bar'
    assert do_urldecode('http%3A%2F%2Fwww.example.com%2F%20bar%3Ffoo%3D%26baz%3D') == 'http://www.example.com/ bar?foo=&baz='



# Generated at 2022-06-23 10:16:49.522170
# Unit test for function do_urlencode
def test_do_urlencode():
    import unittest

    class TestUrlEncode(unittest.TestCase):
        def test_urlencode_string(self):
            self.assertEqual(unicode_urlencode("hello"), "hello")
            self.assertEqual(unicode_urlencode("hello/you"), "hello%2Fyou")
            self.assertEqual(unicode_urlencode("hello/you"), "hello%2Fyou")
            self.assertEqual(unicode_urlencode("hello you"), "hello+you")
        def test_urlencode_dict(self):
            self.assertEqual(unicode_urlencode({"a": "1", "b": "2"}), "a=1&b=2")

# Generated at 2022-06-23 10:16:58.484990
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert '%2F' == unicode_urlencode('/')
    assert '%2fa' == unicode_urlencode('/a')
    assert '%2Fa' == unicode_urlencode('/A')
    assert '%C3%B6' == unicode_urlencode('ö')
    assert '%c3%b6' == unicode_urlencode('ö')
    assert 'a%20b' == unicode_urlencode('a b')
    assert 'a%20b%20c' == unicode_urlencode('a b c')
    assert '%2Fa%20b%20c%2F' == unicode_urlencode('/a b c/')
    assert '%25' == unicode_urlencode('%')

# Generated at 2022-06-23 10:17:00.488839
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'ansible%20test') == u'ansible test'


# Generated at 2022-06-23 10:17:01.868770
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # constructor of class FilterModule
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:17:05.300372
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'



# Generated at 2022-06-23 10:17:13.773760
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    # Test urldecode
    assert filters['urldecode']('a%20b%2Bc%2Fd%3F%23%25') == 'a b+c/d?#%'

    # Test urlencode
    if not HAS_URLENCODE:
        value = ['a b+c/d', '?#%']
        assert filters['urlencode'](value) == 'a+b%2Bc%2Fd&%3F%23%25'
        value = {'a b': 'c/d', '?': '#%'}
        assert filters['urlencode'](value) == 'a+b=c%2Fd&%3F=%23%25'

# Generated at 2022-06-23 10:17:15.157417
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
 

# Generated at 2022-06-23 10:17:18.491257
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('%09') == u'\t'
    assert unicode_urldecode(u'%09') == u'\t'
    assert unicode_urldecode(u'%40%41%42') == u'@AB'
    assert unicode_urldecode(u'%E6%88%91%E7%88%B1%E4%BD%A0') == u'\u6211\u7231\u4f60'



# Generated at 2022-06-23 10:17:29.888949
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abcd') == 'abcd'
    assert do_urlencode(u'abc d') == 'abc%20d'
    assert do_urlencode(u'a+b') == 'a%2Bb'
    assert do_urlencode(u'a b') == 'a%20b'
    assert do_urlencode(u'a=b') == 'a%3Db'
    assert do_urlencode(u'/') == '%2F'
    assert do_urlencode(u'a/b') == 'a%2Fb'
    assert do_urlencode(u'a/b/c') == 'a%2Fb%2Fc'

# Generated at 2022-06-23 10:17:32.441614
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    test_filter_module = FilterModule()
    assert isinstance(test_filter_module.filters(), dict)



# Generated at 2022-06-23 10:17:33.863067
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters() is not None


# Generated at 2022-06-23 10:17:34.757579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-23 10:17:38.963123
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://www.example.com/x?a=1&b=2') == u'http%3A//www.example.com/x%3Fa%3D1%26b%3D2'
    assert do_urlencode({'a': '1', 'b': '2'}) == u'a=1&b=2'

# Generated at 2022-06-23 10:17:45.201729
# Unit test for function do_urlencode
def test_do_urlencode():
    '''Return the bytes-string URL encoded version of a string'''
    assert do_urlencode(u'http://www.ansible.com/') == u'http%3A%2F%2Fwww.ansible.com%2F'

    assert do_urlencode(u'dag@wieers.com') == u'dag%40wieers.com'
    assert do_urlencode(u'~dag') == u'~dag'
    assert do_urlencode(u'é') == u'%C3%A9'
    assert do_urlencode(u'€') == u'%E2%82%AC'
    assert do_urlencode(u'<') == u'%3C'
    assert do_urlencode(u':') == u'%3A'

# Generated at 2022-06-23 10:17:50.721486
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'/usr/bin/echo+%E4%BD%A0%E5%A5%BD%21') == u'/usr/bin/echo 你好!'
    assert unicode_urldecode(u'/usr/bin/echo+%F0%A4%AD%A2') == u'/usr/bin/echo 𤭢'



# Generated at 2022-06-23 10:18:01.112932
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.urls import do_urlencode
    assert do_urlencode('/') == '/'
    assert do_urlencode('/foo/bar') == '/foo/bar'
    assert do_urlencode('/foo/bar/') == '/foo/bar/'
    assert do_urlencode('/foo/bar?a=b') == '/foo/bar?a=b'
    assert do_urlencode('/foo/bar#a=b') == '/foo/bar#a=b'
    assert do_urlencode('/foo/bar&a=b') == '/foo/bar&a=b'
    assert do_urlencode('/foo/bar&a=b?c=d') == '/foo/bar&a=b?c=d'
    assert do_url

# Generated at 2022-06-23 10:18:09.635711
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('https://www.google.com/search?q=ansible+string+urldecode') == u'https://www.google.com/search?q=ansible+string+urldecode'
    assert do_urldecode('https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dansible%2Bstring%2Burldecode') == u'https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dansible%2Bstring%2Burldecode'

# Generated at 2022-06-23 10:18:10.719471
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters.filters()

# Generated at 2022-06-23 10:18:11.698719
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:18:18.507753
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%3A') == ':'
    assert do_urldecode('%3a') == ':'
    assert do_urldecode(u'%E2%82%AC') == u'€'


# Generated at 2022-06-23 10:18:26.937907
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc%E4%B8%AD%E6%96%87') == u'abc中文'
    assert unicode_urldecode(u'abc%E4%B8%AD%20%E6%96%87') == u'abc中 文'
    assert unicode_urldecode(u'abc%20%E4%B8%AD%20%E6%96%87') == u'abc 中 文'
    assert unicode_urldecode(u'abc%7E%2B%2F') == u'abc~+/'



# Generated at 2022-06-23 10:18:39.053787
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo@bar') == 'foo%40bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode(u'foo@bar', for_qs=True) == 'foo%40bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == 'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar') == 'foo+bar'
    assert unicode_urlencode(u'foo') == u'foo'

# Generated at 2022-06-23 10:18:42.796911
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD') == u'你好'


# Generated at 2022-06-23 10:18:53.857584
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test string
    assert do_urlencode(u'abc 123 \u2603') == u'abc+123+%E2%98%83'

    # Test list
    assert do_urlencode([u'abc', u'123', u'\u2603']) == u'abc&123&%E2%98%83'

    # Test tuple
    assert do_urlencode((u'abc', u'123', u'\u2603')) == u'abc=123=%E2%98%83'

    # Test dict
    assert do_urlencode({u'abc': u'123', u'\u2603': u'abc'}) == u'abc=123&%E2%98%83=abc'


# Generated at 2022-06-23 10:18:58.626406
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('abc%20def') == u'abc def'
    assert do_urldecode('abc%20%23def') == u'abc #def'
    assert do_urldecode('abc%20%23%20def') == u'abc # def'


# Generated at 2022-06-23 10:19:05.015828
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # We can verify that the FilterModule is an object
    assert isinstance(FilterModule, object)

    # We can verify that the filters method returns a
    # dictionary of filters
    assert isinstance(FilterModule.filters(FilterModule), dict)

    # We can create an instance for test filtering
    filters = FilterModule.filters(FilterModule)

    # We can verify that the urldecode filter
    # is defined in Python 2.6
    assert 'urldecode' in filters

    # We can verify that the urlencode filter
    # is defined in Python 2.6
    if not HAS_URLENCODE:
        assert 'urlencode' in filters



# Generated at 2022-06-23 10:19:14.258862
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'føø') == u'f%C3%B8%C3%B8'
    assert unicode_urlencode(u'føø', for_qs=True) == u'f%C3%B8%C3%B8'
    assert unicode_urlencode(u'foo=bar', for_qs=True) == u'foo%3Dbar'
    assert unicode_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert unicode_urlencode({u'foo': u'bar baz'}) == u'foo=bar+baz'
    assert unicode_urlencode([u'foo', u'bar']) == u'foo&bar'

# Generated at 2022-06-23 10:19:22.267914
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:19:27.397033
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b%20c%2520d') == 'a b c%20d'
    assert do_urldecode('a+b%20c%2520d') == u'a b c%20d'


# Generated at 2022-06-23 10:19:29.273923
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%3A') == u':'



# Generated at 2022-06-23 10:19:40.341094
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        import sys
        assert unicode_urlencode('test') == 'test'
        assert unicode_urlencode('test/test') == 'test/test'
        assert unicode_urlencode('test with spaces') == 'test+with+spaces'
        assert unicode_urlencode('test%with%spaces') == 'test%25with%25spaces'
        assert unicode_urlencode('{0}'.format(sys.version_info)) == '3%281%2C+5%2C+0%2C+'
        assert unicode_urlencode('{0}'.format(sys.version_info), for_qs=True) == '3%281%2C+5%2C+0%2C+'

# Generated at 2022-06-23 10:19:42.552050
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%2Fb%2Fc%2Fd') == u'a/b/c/d'


# Generated at 2022-06-23 10:19:49.241518
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%41%42%43') == 'ABC'
    assert unicode_urldecode('ABC') == 'ABC'
    assert unicode_urldecode('%') == '%'
    assert unicode_urldecode('%B') == '%B'
    assert unicode_urldecode('%B0%B1%B2') == '0 1 2'
    assert unicode_urldecode('%B0 1%B2%') == '01%'
    assert unicode_urldecode('%B0 1%B2%B') == '01%B'
    assert unicode_urldecode('%B0%B1\n%B2') == '012'


# Generated at 2022-06-23 10:19:55.800026
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.com/foo/') == u'http%3A%2F%2Fwww.example.com%2Ffoo%2F'
    assert unicode_urlencode('/foo/bar/?baz=1') == u'/foo/bar/%3Fbaz%3D1'
    assert unicode_urlencode('foo/bar/?baz=1') == u'foo/bar/%3Fbaz%3D1'
    assert unicode_urlencode('/foo/bar?baz=1') == u'/foo/bar?baz=1'
    assert unicode_urlencode('foo/bar?baz=1') == u'foo/bar?baz=1'

# Generated at 2022-06-23 10:20:07.163888
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' urlencode tests '''
    # Single string
    assert do_urlencode('hello') == u'hello'
    assert do_urlencode(u'hello') == u'hello'
    assert do_urlencode('hello world!') == u'hello+world%21'
    assert do_urlencode(u'hello world!') == u'hello+world%21'
    assert do_urlencode('hello world!') == do_urlencode('hello world!')
    # Single int
    assert do_urlencode(0) == u'0'
    assert do_urlencode(1) == u'1'
    assert do_urlencode(0) == do_urlencode(0)
    # List

# Generated at 2022-06-23 10:20:17.390334
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'foo' == unicode_urlencode(u'foo')
    assert u'foo%2Fbar' == unicode_urlencode(u'foo/bar')
    assert u'foo%3Fbar' == unicode_urlencode(u'foo?bar')
    assert u'foo%20bar' == unicode_urlencode({'foo': 'bar'})
    assert u'foo%3Dbar' == unicode_urlencode(['foo', 'bar'])
    assert u'foo%3Dbar' == unicode_urlencode((('foo', 'bar'),))
    assert u'foo%3Dbar' == unicode_urlencode((('foo', 'bar'),))
    assert u'foo%3Dbar' == unicode_urlencode(u'foo=bar')

# Generated at 2022-06-23 10:20:17.931216
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:20:29.161549
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    # Generate test data of FilterModule.filters
    base_url = '/api/json'
    filters = {
        'urldecode': do_urldecode,
    }

    # Test ansible.module_utils.common.urltools with input data
    res = '{"action":"getBuilds","project":"testjob","offset":0,"depth":5}'
    urldecoded_string = res
    urlencoded_string = quote_plus(res)
    for key, value in iteritems(filters):
        if key == 'urldecode':
            decoded_filter = do_urldecode(urldecoded_string)
            decoded_filter = decoded_filter.replace("['", '{"')

# Generated at 2022-06-23 10:20:32.273177
# Unit test for function do_urlencode
def test_do_urlencode():
    original = u"café?foo=bar&baz=båz"
    encoded = do_urlencode(original)
    print("original:", original)
    print("encoded:", encoded)
    assert encoded == u'caf%C3%A9?foo=bar&baz=b%C3%A5z'
    decoded = do_urldecode(encoded)
    print("decoded:", decoded)
    assert decoded == original

# Generated at 2022-06-23 10:20:41.822234
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.jinja2.filters import do_urlencode
    assert do_urlencode(u'user:passwd') == u'user%3Apasswd'
    assert do_urlencode(u'user:passwd with space') == u'user%3Apasswd+with+space'
    assert do_urlencode((u'user', u'passwd')) == u'user=passwd'
    assert do_urlencode((u'user', u'passwd with space')) == u'user=passwd+with+space'
    assert do_urlencode([u'user', u'passwd']) == u'user&passwd'
    assert do_urlencode([u'user', u'passwd with space']) == u'user&passwd+with+space'

# Generated at 2022-06-23 10:20:43.173075
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import jinja2
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-23 10:20:43.728845
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:20:54.832037
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    # Test with urldecode filter
    filters = fm.filters()
    assert 'urldecode' in filters
    urldecode = filters['urldecode']

    assert isinstance(urldecode, type(do_urldecode))
    assert urldecode('abcdef') == 'abcdef'
    assert urldecode('abc+def') == 'abc def'
    assert urldecode('abc%20def') == 'abc def'
    assert urldecode('abc%25def') == 'abc%def'

    # Test with urlencode filter
    assert 'urlencode' in filters
    urlencode = filters['urlencode']

    asser

# Generated at 2022-06-23 10:20:59.190321
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('hello+world') == 'hello world'
    assert unicode_urldecode('hello%20%3A+%21') == 'hello : !'



# Generated at 2022-06-23 10:21:10.191082
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert unicode_urlencode('hello') == 'hello'
    assert unicode_urlencode('hello, world') == 'hello%2C%20world'
    assert unicode_urldecode('hello%2C%20world') == 'hello, world'

    assert do_urlencode({'name': 'value'}) == 'name=value'
    assert do_urlencode({'name': 'foo bar'}) == 'name=foo+bar'
    assert do_urlencode({'name': 'foo+bar'}) == 'name=foo%2Bbar'
    assert do_urlencode({'name': ['foo', 'bar']}) == 'name=foo&name=bar'

# Generated at 2022-06-23 10:21:12.306808
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testFilterModule = FilterModule()
    print(testFilterModule)


# Generated at 2022-06-23 10:21:17.184562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of class
    obj = FilterModule()
    # Get the filters of class
    filters = obj.filters()
    # Check the filters of class
    expected = {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }
    assert filters == expected


if __name__ == '__main__':
    # Test
    test_FilterModule_filters()

# Generated at 2022-06-23 10:21:28.617613
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test basic conversion
    assert unicode_urldecode('%41%62%63') == 'Abc'
    assert unicode_urldecode('abc') == 'abc'

    # Test conversion of invalid utf-8 bytes
    assert unicode_urldecode('%E0%80%80') == u'\u3000'
    assert unicode_urldecode('%E0%80%81') == u'\u3001'
    assert unicode_urldecode('%E0%80%82') == u'\u3002'
    assert unicode_urldecode('%E0%80%83') == u'\uFFFD'
    assert unicode_urldecode('%E0%80%84') == u'\uFFFD'

    # Test conversion of invalid unic

# Generated at 2022-06-23 10:21:34.045731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urlencode(' ') == '%20'

    assert do_urlencode('/') == '/'
    assert do_urlencode('?') == '%3F'
    assert do_urlencode('/?') == '/%3F'
    assert do_urlencode({'/?': '/'}) == '%2F%3F=%2F'

# Generated at 2022-06-23 10:21:43.643376
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print('\n> Unit test: jinja2 filters')

    real_dict = {'a': 'A', 'b': 'B', 'c': 'C'}

    assert unicode_urldecode(u'a=A&amp;b=B&amp;c=C') == 'a=A&b=B&c=C'
    assert unicode_urlencode(real_dict) == 'a=A&b=B&c=C'
    assert unicode_urlencode(u'a=A&amp;b=B&amp;c=C') == 'a%3DA%26amp%3Bb%3DB%26amp%3Bc%3DC'

# Generated at 2022-06-23 10:21:47.879129
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test.filter()['urldecode'](r'%2F%2F%2F%2F%2F%2F') == '//////'

# Generated at 2022-06-23 10:21:56.532469
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test known good urlencoded combinations
    assert unicode_urldecode('%7e') == u'~'
    assert unicode_urldecode('%2E') == u'.'
    assert unicode_urldecode('%2e') == u'.'
    assert unicode_urldecode('%34') == u'4'
    assert unicode_urldecode('%c4%84') == u'Ą'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%a%c4%84') == u'aĄ'

    # test known bad urlencoded combinations, these should raise an exception
    assert unicode_urldecode('%') == u'%'

# Generated at 2022-06-23 10:22:03.002037
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'foo%20bar' == unicode_urlencode(u'foo bar')
    assert b'foo%20bar' == to_bytes(unicode_urlencode(u'foo bar'))
    assert u'foo%20bar' == to_text(unicode_urlencode(u'foo bar'))
    assert u'foo/bar' == unicode_urlencode(u'foo/bar')
    assert b'foo/bar' == to_bytes(unicode_urlencode(u'foo/bar'))
    assert u'foo%2Fbar' == unicode_urlencode(u'foo/bar', for_qs=True)
    assert u'foo%2Fbar' == to_text(unicode_urlencode(u'foo/bar', for_qs=True))
    assert b

# Generated at 2022-06-23 10:22:12.768317
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.utils.unicode import to_unicode
    assert unicode_urldecode('Hello%2C%20World%21') == to_unicode(b'Hello, World!')
    assert unicode_urldecode('%7Eroot') == to_unicode(b'~root')
    assert unicode_urldecode("%E5%AD%97%E5%B9%95%E6%94%BE%E5%87%BA%E5%95%8F%E9%A1%8C") == to_unicode("字幕放出問題")


# Generated at 2022-06-23 10:22:18.592131
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
  assert unicode_urlencode(u'http://foo / bar') == u'http%3A%2F%2Ffoo%20%2F%20bar'
  assert unicode_urlencode(u'http://foo / bar', True) == u'http%3A%2F%2Ffoo+%2F+bar'


# Generated at 2022-06-23 10:22:22.132507
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc+123') == u'abc 123'
    assert unicode_urldecode('abc%20def') == u'abc def'



# Generated at 2022-06-23 10:22:24.914730
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible = FilterModule()
    assert str(ansible) == '<ansible.utils.filter_plugins.FilterModule object at 0x7fbe04cc9518>'

# Generated at 2022-06-23 10:22:33.016454
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://ȦȧƈƈḗḗƞŧḗḗԀ.com/') == u'http%3A//%C8%A6%C8%A7%C6%88%C6%88%E1%B8%97%E1%B8%97%C6%9E%C7%A3%C7%9D%C7%9D%C4%A0.com/'
    assert unicode_urlencode(u'http://example.com/%c8%a7') == u'http%3A//example.com/%C8%A7'
    assert unicode_urlencode(u'@%€') == u'%40%25%E2%82%AC'
    assert unicode

# Generated at 2022-06-23 10:22:35.227494
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test FilterModule.filters().
    assert FilterModule().filters()


# Generated at 2022-06-23 10:22:39.349488
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%22CASE%20SENSITIVE%22%20') == '"CASE SENSITIVE" '


# Generated at 2022-06-23 10:22:47.254561
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import json

# Generated at 2022-06-23 10:22:49.755282
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'a': 'b'}) == u'a=b&'
    assert do_urldecode(u'a=%20') == u'a= '

# Generated at 2022-06-23 10:22:59.902468
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode(u'test') == 'test'
        assert unicode_urlencode(u'%') == '%25'
        assert unicode_urlencode(u'+') == '%2B'
        assert unicode_urlencode(u'&') == '%26'
        assert unicode_urlencode(u'&', for_qs=True) == '%26'
        assert unicode_urlencode(u'/') == '/'
        assert unicode_urlencode(u'/', for_qs=True) == '%2F'
        assert unicode_urlencode([u'foo', u'bar']) == 'foo&bar'
        assert unicode_urlencode({u'foo': u'bar'}) == 'foo=bar'


# Generated at 2022-06-23 10:23:09.072132
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit test of method 'filters' of class 'FilterModule'
    class TestFilterModule(object):
        ''' Test class for FilterModule '''
        def filters(self):
            ''' Test method for filters '''
            return {'urldecode': do_urldecode}

    # Create a TestFilterModule object
    test_filtermodule = TestFilterModule()

    # Asserts
    assert test_filtermodule is not None
    assert isinstance(test_filtermodule, TestFilterModule)


# Unit tests for module filters

# Generated at 2022-06-23 10:23:17.581680
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    fm = FilterModule()
    context = {
        'good_key': 'good value',
        'bad_key': 'bad value',
        'other_bad_key': 'other bad value',
        'nested_dict': {
            'test_value': 'some string with spaces',
        }
    }

# Generated at 2022-06-23 10:23:27.183922
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%7B%22environment%22%3A+%22%7B%5C%22production%5C%22%3A+%7B%5C%22hostname%5C%22%3A+%5C%22%7B%5C%22%7Dagrant%7B%5C%22%7D%5C%22%2C+%5C%22port%5C%22%3A+%7B%5C%22%7D8888%7B%5C%22%7D%7D%7D%22%7D') == u'{"environment": "{\\"production\\": {\\"hostname\\": \\"{\\\\\\"}agrant{\\\\\\"}\\", \\"port\\": {\\"}}}"}'

# Generated at 2022-06-23 10:23:33.154928
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No filter
    assert len(FilterModule().filters()) == 1

    # With Jinja2 v2.7, we get the urlencode method
    assert len(FilterModule().filters(hostvars={'ansible_jinja2_version': '2.7'})) == 2

# Generated at 2022-06-23 10:23:41.828179
# Unit test for function do_urldecode
def test_do_urldecode():
    """
    Test that urldecode does the expected thing.
    """
    assert do_urldecode('abc') == 'abc'
    assert do_urldecode('abc/') == 'abc/'
    assert do_urldecode('abc%2F') == 'abc/'
    assert do_urldecode('abc%252F') == 'abc%2F'
    assert do_urldecode('abc%2Fdef') == 'abc/def'
    assert do_urldecode('abc%2Fdef%2F') == 'abc/def/'
    assert do_urldecode('abc%252Fdef%252F') == 'abc%2Fdef%2F'
    assert do_urldecode('abc+def') == 'abc def'
    assert do_urldec

# Generated at 2022-06-23 10:23:48.973910
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo+bar%20baz') == u'foo bar baz'
    assert do_urldecode('W3Jvb3Q=') == u'W3Jvb3Q='
    assert do_urldecode('%C3%A1ba') == u'\xe1ba'

# Unit tests for function unicode_urldecode

# Generated at 2022-06-23 10:23:57.229755
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic
    from ansible.module_utils.jinja2 import Template
    from jinja2.runtime import UndefinedError

    assert do_urlencode('http://foo') == 'http%3A%2F%2Ffoo'
    assert do_urlencode('http://foo?bar') == 'http%3A%2F%2Ffoo%3Fbar'

    assert do_urlencode({
        'foo': ['bar', 'baz'],
    }) == 'foo=bar&foo=baz'

    assert do_urlencode({
        'foo': [1, 2, 3],
    }) == 'foo=1&foo=2&foo=3'


# Generated at 2022-06-23 10:23:59.128292
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urlencode('Hello World') == 'Hello%20World'
    assert do_urldecode('Hello%20World') == 'Hello World'

# Generated at 2022-06-23 10:24:09.499874
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'user:pass') == u'user%3Apass'
    assert unicode_urlencode(u'ééé') == u'%C3%A9%C3%A9%C3%A9'
    assert unicode_urlencode(u'%C3%A9%C3%A9%C3%A9') == u'%25C3%25A9%25C3%25A9%25C3%25A9'
    assert unicode_urlencode(u'ééé', for_qs=True) == u'%C3%A9%C3%A9%C3%A9'

# Generated at 2022-06-23 10:24:11.995237
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters



# Generated at 2022-06-23 10:24:25.893430
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat import unittest

    class TestUnicodeUrlEncode(unittest.TestCase):
        def test_unicode_urlencode(self):
            self.assertEqual(unicode_urlencode(u'test'), u'test')
            self.assertEqual(unicode_urlencode(u'foo bar'), u'foo%20bar')
            self.assertEqual(unicode_urlencode(u'%20'), u'%20')

            self.assertEqual(unicode_urlencode(u'test', True), u'test')
            self.assertEqual(unicode_urlencode(u'foo bar', True), u'foo+bar')
            self.assertEqual(unicode_urlencode(u'%20', True), u'%20')



# Generated at 2022-06-23 10:24:33.459418
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3C%3D+%3E') == u'<= >'
    assert unicode_urldecode('+%3C%3D+%3E') == u' <= >'
    assert unicode_urldecode('%3C%3D%20%3E') == u'<= >'
    assert unicode_urldecode('+%3C%3D%20%3E') == u' <= >'


# Generated at 2022-06-23 10:24:37.302338
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo%2Fbar') == 'foo/bar'


# Generated at 2022-06-23 10:24:39.253858
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(FilterModule()), dict)

# Generated at 2022-06-23 10:24:51.125554
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%25ansible') == '%ansible'
    assert do_urldecode('%2Bansible') == '+ansible'
    assert do_urldecode('%2bansible') == '+ansible'
    assert do_urldecode('%3Dansible') == '=ansible'
    assert do_urldecode('%3Dansible%25') == '=ansible%'
    assert do_urldecode('%2Fansible') == '/ansible'
    assert do_urldecode('%3Fansible') == '?ansible'
    assert do_urldecode('%23ansible') == '#ansible'
    assert do_urldecode('%26ansible') == '&ansible'
    assert do

# Generated at 2022-06-23 10:24:53.946110
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    print(filter_module.filters())


# Generated at 2022-06-23 10:24:58.192346
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+bar%2Bbaz') == 'foo bar+baz'
    assert not unicode_urldecode('foo+bar%2Bbaz') != 'foo+bar%2Bbaz'


# Generated at 2022-06-23 10:25:11.879077
# Unit test for function do_urlencode
def test_do_urlencode():
    print('Testing function do_urlencode')
    test_cases = {
        'string': 'a=b&c=d',
        'dict': {'a': 'b', 'c': 'd'},
        'list': ['a=b', 'c=d'],
        'list_dict': [{'a': 'b'}, {'c': 'd'}],
    }

    for type, value in iteritems(test_cases):
        if do_urlencode(value) != test_cases['string']:
            print('%s != %s' % (do_urlencode(value), test_cases['string']))
            raise Exception('do_urlencode(%s) failed' % type)

    print('do_urlencode Passed')

# Generated at 2022-06-23 10:25:18.944880
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+%2C+b') == 'a , b'
    assert do_urldecode('a+%2c+b') == 'a , b'
    assert do_urldecode('a+%2C+b+%3D%3D+c') == 'a , b == c'
    assert do_urldecode('a+%2C+b+%3d%3d+c') == 'a , b == c'


# Generated at 2022-06-23 10:25:24.957967
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'foo bar' == unicode_urldecode('foo%20bar')
    assert 'foo+bar' == unicode_urldecode('foo%2Bbar')
    assert '1 2 3' == unicode_urldecode('1%202%203')



# Generated at 2022-06-23 10:25:31.329189
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode(u'a b c') == u'a+b+c'
    assert do_urlencode([u'a', u'b', u'c']) == u'a&b&c'
    assert do_urlencode((u'a', u'b', u'c')) == u'a&b&c'
    assert do_urlencode({u'a': u'b', u'c': u'd'}) == u'a=b&c=d'

# Generated at 2022-06-23 10:25:35.616844
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import unittest.mock
    fm = FilterModule()
    # setup context
    fm.filters()
    # assert if the do_urlencode function is called
    assert do_urlencode(u'test')

# Generated at 2022-06-23 10:25:45.071923
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Normal
    test = 'a+b'
    expected = 'a b'
    actual = unicode_urldecode(test)
    assert expected == actual, "Expected {0}, got {1} from {2}".format(expected, actual, test)

    # With spaces
    test = 'a%20b'
    expected = 'a b'
    actual = unicode_urldecode(test)
    assert expected == actual, "Expected {0}, got {1} from {2}".format(expected, actual, test)

    # With special characters
    test = 'c%20%7B%20%5B%27a%27%5D%20%3A%20%27b%27%20%7D'
    expected = 'c { [\'a\'] : \'b\' }'
   

# Generated at 2022-06-23 10:25:56.057975
# Unit test for function unicode_urldecode