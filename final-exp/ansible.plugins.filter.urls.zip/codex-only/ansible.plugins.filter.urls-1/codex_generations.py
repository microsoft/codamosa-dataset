

# Generated at 2022-06-23 10:15:52.279038
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'

# Generated at 2022-06-23 10:15:56.382959
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert len(f.filters()) == 2
    assert f.filters()['urldecode'] == do_urldecode
    assert f.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:15:58.589130
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode(b'foo') == u'foo'


# Generated at 2022-06-23 10:16:02.045251
# Unit test for constructor of class FilterModule
def test_FilterModule():
    urldecode_obj = FilterModule().filters()['urldecode']

    # Test urldecode function
    assert urldecode_obj('Dag%20Wieers') is 'Dag Wieers'

# Generated at 2022-06-23 10:16:13.774341
# Unit test for function do_urlencode
def test_do_urlencode():
    testcases = {
        'spam and eggs': 'spam%20and%20eggs',
        'foo/bar': 'foo%2Fbar',
        'foo bar': 'foo%20bar',
        u'☃': u'%E2%98%83',
        {'spam': 'foo', 'eggs': 'bar'}: 'spam=foo&eggs=bar',
        {'spam': ['foo', 'bar']}: 'spam=foo&spam=bar',
        [('spam', 'foo'), ('eggs', 'bar')]: 'spam=foo&eggs=bar',
        [('spam', 'foo'), ('eggs', ['foo', 'bar'])]: 'spam=foo&eggs=foo&eggs=bar',
    }


# Generated at 2022-06-23 10:16:20.441297
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_var = "hello+world"
    test_decoded = unicode_urldecode(test_var)
    assert test_decoded == "hello world"

    test_var = "hello%20world"
    test_decoded = unicode_urldecode(test_var)
    assert test_decoded == "hello world"



# Generated at 2022-06-23 10:16:29.332643
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == u''
    assert unicode_urlencode(None) == u''
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'/var/log/app.log') == u'/var/log/app.log'
    assert unicode_urlencode(u'/var/log/app.log', for_qs=True) == u'/var/log/app.log'
    assert unicode_urlencode(u'[]:;|\@&$%()') == u'%5B%5D%3A%3B%7C%40%26%24%25%28%29'
    assert unicode_urlencode(u'[]:;|\@&$%()', for_qs=True)

# Generated at 2022-06-23 10:16:40.453764
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters()
    assert 'urlencode' in f.filters()
    assert do_urldecode('http://www.example.com') == u'http://www.example.com'
    assert do_urldecode('http%3A%2F%2Fwww.example.com') == u'http://www.example.com'
    assert do_urlencode('http://www.example.com') == u'http%3A%2F%2Fwww.example.com'
    assert do_urlencode(u'http://www.example.com') == u'http%3A%2F%2Fwww.example.com'
    assert do_urlencode({'a': 'b'}) == u'a=b'

# Generated at 2022-06-23 10:16:49.697125
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%3d') == '='
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%7E') == '~'
    assert do_urldecode('%7e') == '~'


# Generated at 2022-06-23 10:16:55.221709
# Unit test for function do_urldecode

# Generated at 2022-06-23 10:16:59.586351
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a.filters().keys() == ['urldecode', 'urlencode']


# Generated at 2022-06-23 10:17:00.688009
# Unit test for constructor of class FilterModule
def test_FilterModule():
    flt = FilterModule()
    assert flt != None

# Generated at 2022-06-23 10:17:10.289920
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus


# Generated at 2022-06-23 10:17:14.401276
# Unit test for function do_urldecode
def test_do_urldecode():
    import unittest
    string1 = "%2F%2B"
    string2 = "+"
    class TestUrldecode(unittest.TestCase):
        def test_urlencode(self):
            assert do_urldecode(string1) == u"/+"
            assert do_urldecode(string2) == u" "
    unittest.main()

# Generated at 2022-06-23 10:17:19.732114
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dwho%2527s%2Bon%2Bfirst') == u'https://www.google.com/search?q=who\'s on first'



# Generated at 2022-06-23 10:17:30.554362
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode('foo') == u'foo'
    if not PY3:
        assert do_urldecode(b'foo') == u'foo'

    assert do_urldecode(u'foo+bar') == u'foo bar'
    assert do_urldecode('foo+bar') == u'foo bar'
    if not PY3:
        assert do_urldecode(b'foo+bar') == u'foo bar'

    assert do_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert do_urldecode('foo%2Fbar') == u'foo/bar'
    if not PY3:
        assert do_urldecode

# Generated at 2022-06-23 10:17:40.744690
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%2Fbar%2Fbaz') == u'foo/bar/baz'
    assert unicode_urldecode('foo%25bar%25baz') == u'foo%bar%baz'
    assert unicode_urldecode('foo%25bar%25baz%25') == u'foo%bar%baz%'
    assert unicode_urldecode('foo%2F') == u'foo/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('') == u''



# Generated at 2022-06-23 10:17:51.881063
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == '', '1: empty string'
    assert unicode_urlencode(u'unicode_urlencode') == 'unicode_urlencode', '2: simple string'
    assert unicode_urlencode(u'unicode_urlencode', True) == 'unicode_urlencode', '3: simple string'
    assert unicode_urlencode(u'unicode_urlencode', False) == 'unicode_urlencode', '4: simple string'
    assert unicode_urlencode(u'unicode_urlencode', None) == 'unicode_urlencode', '5: simple string'

# Generated at 2022-06-23 10:17:53.958676
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'

# Generated at 2022-06-23 10:18:03.249902
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:18:10.466100
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%21%2A%27%28%29%3B%3A%40%26%3D%2B%24%2C%2F%3F%23%5B%5D') == '!*\'();:@&=+$,/?#[]'
    assert do_urlencode('!*\'();:@&=+$,/?#[]') == '%21%2A%27%28%29%3B%3A%40%26%3D%2B%24%2C%2F%3F%23%5B%5D'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Generated at 2022-06-23 10:18:17.733536
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    for fn in FilterModule().filters():
        try:
            assert callable(getattr(FilterModule().filters(), fn))
        except AssertionError:
            assert False, "FilterModule().filters() is missing %s, which is a callable property of FilterModule().filters()" % fn


# Generated at 2022-06-23 10:18:21.577597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("ansible") == "ansible"
    assert do_urlencode("ansible") == "ansible"

# vim:set ft=python sw=4 et sts=4 ts=4 tw=79:

# Generated at 2022-06-23 10:18:31.318768
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc def') == 'abc+def'
    assert do_urlencode(u'abc_def') == 'abc_def'
    assert do_urlencode(u'abc+def') == 'abc%2Bdef'
    assert do_urlencode(u'abc%def') == 'abc%25def'
    assert do_urlencode(u'abc def') == 'abc+def'
    assert do_urlencode(u'abc def') == 'abc+def'
    assert do_urlencode(u'abc def') == 'abc+def'



# Generated at 2022-06-23 10:18:37.132458
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+bar') == u'foo bar'
    assert unicode_urldecode('foo+%3Fbar') == u'foo ?bar'
    assert unicode_urldecode('foo+%26bar') == u'foo &bar'
    assert unicode_urldecode('01%2C01%2C01') == u'01,01,01'
    assert unicode_urldecode('1+2%2C3+4') == u'1 2,3 4'


# Generated at 2022-06-23 10:18:46.812272
# Unit test for function do_urlencode
def test_do_urlencode():
    test_data = {
        u'1': u'1',
        u'a': u'a',
        u'こんにちは': u'%E3%81%93%E3%82%93%E3%81%AB%E3%81%A1%E3%81%AF',
        u'~': u'~',
    }

    for k, v in iteritems(test_data):
        assert unicode_urlencode(k) == v
        assert unicode_urlencode(v) == v


# Generated at 2022-06-23 10:18:53.081571
# Unit test for function do_urldecode
def test_do_urldecode():
    assert isinstance(do_urldecode('%2Fhome%2Fuser%2F'), str)
    assert do_urldecode('%2Fhome%2Fuser%2F') == u'/home/user/'
    assert do_urldecode(u'%2Fhome%2Fuser%2F') == u'/home/user/'

# Generated at 2022-06-23 10:18:54.215178
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:19:03.658736
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('abc def') == 'abc+def'
    assert do_urlencode('abc+def') == 'abc%2Bdef'
    assert do_urlencode('abc def') == 'abc+def'
    assert do_urlencode('abc def') == 'abc+def'
    assert do_urlencode(u'\u03b1') == u'%CE%B1'
    assert do_urlencode(['a', 'b']) == 'a&b'
    assert do_urlencode(('a', 'b')) == 'a&b'
    assert do_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'

# Generated at 2022-06-23 10:19:13.267430
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_cases = (
        (
            dict(
                string='test+test',
                expected='test test',
            ),
            dict(
                string='test%2Btest',
                expected='test+test',
            ),
            dict(
                string='test%2Btest',
                expected='test+test',
                for_qs=True,
            ),
            dict(
                string='test+test',
                expected='test test',
                for_qs=True,
            ),
        ),
    )

    obj = FilterModule()
    filters = obj.filters()
    assert 'urldecode' in filters
    urldecode = filters['urldecode']
    if HAS_URLENCODE:
        assert 'urlencode' in filters
        urlencode = filters['urlencode']

   

# Generated at 2022-06-23 10:19:14.226727
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:19:15.561051
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule)


# Generated at 2022-06-23 10:19:17.041725
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    assert isinstance(filtermodule.filters(), dict)


# Generated at 2022-06-23 10:19:23.023520
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') != '//'
    assert unicode_urlencode('/') != '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/', for_qs=True) != '%252F'


# Generated at 2022-06-23 10:19:26.253664
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    assert(type(test_filter_module) == FilterModule)



# Generated at 2022-06-23 10:19:28.045189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode



# Generated at 2022-06-23 10:19:34.555866
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # ASCII characters
    assert unicode_urldecode('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxyz'
    assert unicode_urldecode('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert unicode_urldecode('0123456789') == '0123456789'
    assert unicode_urldecode('!@#$%^&*()-=+[]{}\'\\|;:\",./<>? ') == '!@#$%^&*()-=+[]{}\'\\|;:\",./<>? '

# Generated at 2022-06-23 10:19:39.976484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()["urldecode"]("Ansible%20Core%20Jinja2%20Filters") == "Ansible Core Jinja2 Filters"
    assert fm.filters()["urlencode"]("Ansible Core Jinja2 Filters") == "Ansible+Core+Jinja2+Filters"

# Generated at 2022-06-23 10:19:44.224481
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    assert do_urldecode('p%F4ng') == 'p\xf4ng' # unquote_plus
    assert '%' not in do_urldecode('c%2B%2B') # unquote_plus



# Generated at 2022-06-23 10:19:46.656844
# Unit test for constructor of class FilterModule
def test_FilterModule():
   my_class = FilterModule()
   assert(my_class.filters()['urldecode'] is do_urldecode)



# Generated at 2022-06-23 10:19:50.672519
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'https://example.com/a/%2F-%2F') == u'https://example.com/a//-/'



# Generated at 2022-06-23 10:19:55.735797
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http://www.example.com/?a%5Bb%5D=helloworld') == \
        'http://www.example.com/?a[b]=helloworld'
    assert do_urldecode('http://www.example.com/?a%5Bb%5D=hello%20world') == \
        'http://www.example.com/?a[b]=hello world'



# Generated at 2022-06-23 10:20:00.766435
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'unicode') == u'unicode'
    assert do_urlencode(u'unicode/unicode') == u'unicode%2Funicode'
    assert do_urlencode(['unicode', 'unicode']) == u'unicode&unicode'
    assert do_urlencode(dict(key=u'u\u2070')) == u'key=u%E2%81%B0'

# Generated at 2022-06-23 10:20:10.468190
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        (u'%A1', u'\xa1'),
        (u'%C3%A1', u'\xe1'),
        (u'%E2%98%83', u'\u2603'),
        (u'%F0%9F%92%A9', u'\U0001F4A9'),
        (u'%C0%80', u'\x00'),
        (u'%E0%A0%80', u'\u0080'),
        (u'%F0%90%80%80', u'\U00010000'),
        (u'%F8%88%80%80%80%80', u'\U00100000'),
    ]

# Generated at 2022-06-23 10:20:14.822917
# Unit test for function do_urldecode
def test_do_urldecode():
    '''Returns string with input values decoded to bytes'''
    assert '%E7%9A%84' == do_urldecode('%E7%9A%84')


# Generated at 2022-06-23 10:20:22.823168
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode('foo bar') == 'foo%20bar'
        assert unicode_urlencode('foo bar', True) == 'foo+bar'
        assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
        assert unicode_urlencode('foo/bar', True) == 'foo%2Fbar'
    else:
        assert unicode_urlencode(u'foo bar') == 'foo%20bar'
        assert unicode_urlencode(u'foo bar', True) == 'foo+bar'
        assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'
        assert unicode_urlencode(u'foo/bar', True) == 'foo%2Fbar'



# Generated at 2022-06-23 10:20:28.447121
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('') == ''
    assert do_urldecode('abc') == 'abc'
    assert do_urldecode('abc def') == 'abc def'
    assert do_urldecode('%20') == ' '
    assert do_urldecode('+') == ' '
    assert do_urldecode('a%2fb') == 'a/b'


# Generated at 2022-06-23 10:20:41.315076
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('A%20space%20encoded%20with%20%2520') == 'A space encoded with %20'
    assert unicode_urldecode('A%2Bplus%2Bsign%2Bencoded%2Bwith%2B%25252B') == 'A+plus+sign+encoded+with+%2B'
    assert unicode_urldecode('A%26amp%3Bencoded%26amp%3Bwith%26amp%3B%2526amp%253B') == 'A&amp;encoded&amp;with&amp;%26amp%3B'

# Generated at 2022-06-23 10:20:46.798766
# Unit test for function do_urldecode
def test_do_urldecode():
    print("Testing do_urldecode")

    assert do_urldecode("dag%20wieers") == "dag wieers"
    assert do_urldecode("dag+wieers") == "dag wieers"
    assert do_urldecode("dag+wieers%2Fdagwieers") == "dag wieers/dagwieers"

    print("do_urldecode: pass")


# Generated at 2022-06-23 10:20:49.196408
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('FOO%20BAR') == u'FOO BAR'



# Generated at 2022-06-23 10:20:51.538984
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    x = "%C3%A9"
    assert unicode_urldecode(x) == u'é'



# Generated at 2022-06-23 10:20:54.739966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%2F%24') == u' /$'
    assert unicode_urldecode('%20%2F%24') == ' /$'


# Generated at 2022-06-23 10:21:00.138139
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'a+b%20c') == u'a+b c'
    assert do_urldecode(u'a+b%2Bc') == u'a+b+c'
    assert do_urldecode(u'a%2Bb%2b2%2B1') == u'a+b+2+1'



# Generated at 2022-06-23 10:21:09.996887
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://www.test.com/test?test=test') == u'http%3A%2F%2Fwww.test.com%2Ftest%3Ftest%3Dtest'
    assert do_urlencode({'a': 'b'}) == u'a=b'
    assert do_urlencode({u'a': u'b'}) == u'a=b'
    assert do_urlencode(u'http://www.test.com/test?test=test') == u'http%3A%2F%2Fwww.test.com%2Ftest%3Ftest%3Dtest'


# Generated at 2022-06-23 10:21:16.862943
# Unit test for function do_urldecode
def test_do_urldecode():
    assert u'abc+def' == do_urldecode(u'abc%20def')
    assert u'abc def' == do_urldecode(u'abc+def')
    assert u'a=b+c' == do_urldecode(u'a=b%20c')
    assert u'a=b c' == do_urldecode(u'a=b+c')
    assert u'+%' == do_urldecode(u'%2B%25')



# Generated at 2022-06-23 10:21:28.093554
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Test do_urldecode function
    '''
    cases = [
        ('', ''),
        ('a', 'a'),
        ('ab', 'ab'),
        ('abc', 'abc'),
        ('abcd', 'abcd'),
        ('%41B', 'AB'),
        ('%41b', 'Ab'),
        ('%61B', 'aB'),
        ('%61b', 'ab'),
        ('%41%42%43', 'ABC'),
        ('%41%42%43%44', 'ABCD'),
        ('%41%42%43%44%00', 'ABCD\x00'),
    ]
    for case in cases:
        assert do_urldecode(case[0]) == case[1]


# Generated at 2022-06-23 10:21:33.576327
# Unit test for function do_urldecode
def test_do_urldecode():
    # from test_do_urlencode
    qs = u'foo=first&foo=second&foo=third&bar=baz&baz=foo&Ω=µ'
    assert do_urldecode(qs) == {
        'foo': ['first', 'second', 'third'],
        'bar': 'baz',
        'baz': 'foo',
        'Ω': 'µ',
    }



# Generated at 2022-06-23 10:21:38.388576
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'urldecode' in fm.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()

# Generated at 2022-06-23 10:21:44.759369
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert unicode_urldecode('/a/b/c') == u'/a/b/c'
    assert unicode_urlencode(u'/a/b/c') == '/a/b/c'
    assert unicode_urlencode(u'/a/b/c', for_qs=True) == '/a/b/c'
    assert unicode_urlencode(u'a/b/c') == 'a/b/c'
    assert unicode_urlencode(u'a/b/c', for_qs=True) == 'a%2Fb%2Fc'
    assert unicode_urlencode({'a': 'b/c'}) == 'a=b%2Fc'

# Generated at 2022-06-23 10:21:54.936855
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20%21%22%23%24%25%26%27%28%29%2A%2B%2C%2D%2E%2F%3A%3B%3C%3D%3E%3F%40%5B%5C%5D%5E%5F%60%7B%7C%7D%7E') == u' !\"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'

# Generated at 2022-06-23 10:21:58.166193
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('apple%2Bbanana%20peach') == u'apple+banana peach'
    assert do_urldecode('apple+banana%20peach') == u'apple banana peach'



# Generated at 2022-06-23 10:22:02.324218
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%2F%2E%40%23%24%26%27%28%29%2A%2B%2C%3A%3B%3D%3F%40%5B%5D%7B%7D') == u' /.@#$&\'()*+,:;=?@[]{}'


# Unit tests for function unicode_urlencode

# Generated at 2022-06-23 10:22:13.591430
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == 'test'
    assert do_urlencode('/test') == '%2Ftest'
    assert do_urlencode('/test?') == '%2Ftest%3F'
    assert do_urlencode('/test?foo') == '%2Ftest%3Ffoo'
    assert do_urlencode('/test?foo=bar') == '%2Ftest%3Ffoo%3Dbar'
    assert do_urlencode('/test?foo=') == '%2Ftest%3Ffoo%3D'
    assert do_urlencode('/test?foo=bar&bar=foo') == '%2Ftest%3Ffoo%3Dbar%26bar%3Dfoo'
    assert do_urlencode({'foo': 'bar'})

# Generated at 2022-06-23 10:22:24.282932
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('\u20ac') == '%E2%82%AC'
    assert do_urlencode('/') == '%2F'
    assert do_urlencode({'foo': 'bar baz'}) == 'foo=bar+baz'
    assert do_urlencode(['foo', 'bar baz']) == 'foo&bar+baz'
    assert do_urlencode(('foo', 'bar baz')) == 'foo&bar+baz'
    assert do_urlencode({'foo': ['bar', 'baz']}) == 'foo=bar&foo=baz'
    assert do_urlencode([('foo', 'bar'), ('foo', 'baz')]) == 'foo=bar&foo=baz'

# Generated at 2022-06-23 10:22:26.669593
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters


# Generated at 2022-06-23 10:22:30.966972
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'a%2Fc' == do_urlencode('a/c')
    assert 'a/c' == do_urldecode('a%2Fc')
    assert 'a%c' == do_urlencode(u'a\u1234')
    assert 'a\u1234' == do_urldecode('a%c')

# Generated at 2022-06-23 10:22:34.285879
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters().keys()

# Generated at 2022-06-23 10:22:35.960912
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Test if FilterModule contructor is working
    """
    obj = FilterModule()
    return True

# Generated at 2022-06-23 10:22:45.502685
# Unit test for function do_urldecode
def test_do_urldecode():
    assert(do_urldecode(':') == u'%3A')
    assert(do_urldecode('%3A') == u':')
    assert(do_urldecode('%3a') == u':')
    assert(do_urldecode('%26%2360%3B') == u'&#60;')
    assert(do_urldecode('%3D%3D') == u'==')
    assert(do_urldecode('%3D') == u'=')
    assert(do_urldecode('%3d') == u'=')
    assert(do_urldecode('%25') == u'%')
    assert(do_urldecode('%') == u'%25')

# Generated at 2022-06-23 10:22:47.947546
# Unit test for constructor of class FilterModule
def test_FilterModule():
    cf = FilterModule()
    assert cf is not None
# EOF

# Generated at 2022-06-23 10:22:51.729484
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'a=%20' == unicode_urlencode({u'a': u' '}, for_qs=True)
    assert u'abc' == unicode_urlencode(u'abc')
    assert u'foo%20bar' == unicode_urlencode(u'foo bar')

# Generated at 2022-06-23 10:22:57.368740
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    test_string = u'Iñtërnåtiônàlizætiøn'
    assert filters['urldecode'](unicode_urlencode(test_string)) == test_string
    if not HAS_URLENCODE:
        assert filters['urlencode'](test_string) == unicode_urlencode(test_string)

# Generated at 2022-06-23 10:23:01.110007
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%20") == " "
    assert unicode_urldecode("%40") == "@"
    assert unicode_urldecode("%7B") == "{"
    assert unicode_urldecode("%7D") == "}"

# Generated at 2022-06-23 10:23:11.917356
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc def/') == 'abc%20def%2F'
    assert unicode_urlencode('abc def/', for_qs=True) == 'abc+def%2F'
    assert unicode_urlencode(u'föö') == 'f%C3%B6%C3%B6'
    assert unicode_urlencode(u'föö') == 'f%C3%B6%C3%B6'

# Generated at 2022-06-23 10:23:23.199408
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo?bar') == u'foo%3Fbar'
    assert unicode_urlencode(u'foo?bar', for_qs=True) == u'foo%3Fbar'



# Generated at 2022-06-23 10:23:24.645894
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    assert filters is not None

# Generated at 2022-06-23 10:23:31.721389
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a space') == u'a%20space'
    assert unicode_urlencode('unicode: юникод') == u'unicode%3A%20%D1%8E%D0%BD%D0%B8%D0%BA%D0%BE%D0%B4'

# Generated at 2022-06-23 10:23:41.121463
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test1=string1&test2=string2') == 'test1%3Dstring1%26test2%3Dstring2'
    assert do_urlencode('test1=string1&test3=string3') == 'test1%3Dstring1%26test3%3Dstring3'
    assert do_urlencode('test1=string1') == 'test1%3Dstring1'
    assert do_urlencode('test1') == 'test1'
    assert do_urlencode(['test1', 'test2=string2']) == 'test1%26test2%3Dstring2'
    assert do_urlencode({'test1': 'string1'}) == 'test1=string1'

# Generated at 2022-06-23 10:23:53.106833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'][0]('some string') == unicode_urldecode('some string')
    assert FilterModule().filters()['urldecode'][0]('some%20string') == unicode_urldecode('some%20string')
    assert FilterModule().filters()['urldecode'][0]('some%26string') == unicode_urldecode('some%26string')
    assert FilterModule().filters()['urldecode'][0]('foo%3Abar') == unicode_urldecode('foo%3Abar')
    assert FilterModule().filters()['urldecode'][0]('foo%3A%26bar') == unicode_urldecode('foo%3A%26bar')

# Generated at 2022-06-23 10:23:59.067672
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%26') == u'&'
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%7B') == u'{'
    assert do_urldecode('%C3%A9') == u'é'
    assert do_urldecode('%7B%26%20%7D') == u'{& }'
    assert do_urldecode('<omg>+%C3%A9') == u'<omg>+é'
    assert do_urldecode('<omg>%2B%C3%A9') == u'<omg>+é'


# Generated at 2022-06-23 10:24:08.882038
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'') == u''
    assert do_urldecode(u'abc') == u'abc'
    assert do_urldecode(u'abc%20') == u'abc '
    assert do_urldecode(u'abc%20def') == u'abc def'
    assert do_urldecode(u'%20') == u' '
    assert do_urldecode(u'%20%20') == u'  '
    assert do_urldecode(u'%2f') == u'/'
    assert do_urldecode(u'%252f') == u'%2f'
    if not PY3:
        assert do_urldecode(u'abc%20'.encode('utf-8')) == u'abc '

# Generated at 2022-06-23 10:24:12.698218
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] is do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] is do_urlencode

# Generated at 2022-06-23 10:24:25.988366
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'a') == u'a'
    assert unicode_urlencode(u' ') == u'%20'
    assert unicode_urlencode(u'\n') == u'%0A'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'?') == u'%3F'
    assert unicode_urlencode(u'?') == u'%3F'
    assert unicode_urlencode(u'%') == u'%25'
    assert unicode_urlencode(u'&') == u'%26'
    assert unicode_urlencode(u'=') == u'%3D'

# Generated at 2022-06-23 10:24:37.185806
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.plugin_docs import get_filter_plugins

    fm = FilterModule()
    assert fm is not None
    assert isinstance(fm.filters(), dict)

    # Make sure we have the correct filters

# Generated at 2022-06-23 10:24:45.459233
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar+baz') == u'foo bar baz'
    assert unicode_urldecode(u'foo%2Fbar+baz') == u'foo/bar baz'
    assert unicode_urldecode(u'foo%2fbar+baz') == u'foo/bar baz'
    assert unicode_urldecode(u'foo%2Fbar%2Fbaz') == u'foo/bar/baz'
    assert unicode_urldecode(u'foo%2fbar%2f%2fbaz') == u'foo/bar///baz'

# Generated at 2022-06-23 10:24:48.014392
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode(u'foo%26bar') == u'foo&bar'
    assert do_urldecode(u'foo%2bbar') == u'foo+bar'


# Generated at 2022-06-23 10:24:59.883196
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.plugins.filter import FilterModule
    import pytest

    fm = FilterModule()
    assert 'urldecode' in fm.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()
    assert not hasattr(fm, 'filter_urldecode')
    assert not hasattr(fm, 'filter_urlencode')
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2f') == '/'

# Generated at 2022-06-23 10:25:12.332700
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test jinja2 urlencode
    my_filter = FilterModule()
    assert my_filter.filters()['urlencode']('Hello World') == 'Hello+World'
    assert my_filter.filters()['urlencode']('Hello World') == 'Hello+World'

    assert my_filter.filters()['urlencode']('Hello World') == 'Hello+World'
    assert my_filter.filters()['urlencode']('Hello World') == 'Hello+World'

    # test jinja2 urldecode
    assert my_filter.filters()['urldecode']('Hello+World') == 'Hello World'
    assert my_filter.filters()['urldecode']('Hello+World') == 'Hello World'

    # test custom urlencode
    assert my_filter.fil

# Generated at 2022-06-23 10:25:14.730494
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()
    assert c is not None

# Unit tests for urldecode

# Generated at 2022-06-23 10:25:26.971181
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E2%9C%88') == u'✈'
    assert unicode_urldecode(u'%E2%9C%88%E2%9C%88') == u'✈✈'
    assert unicode_urldecode(u'%E2%9C%88+%E2%9C%88') == u'✈✈'
    assert unicode_urldecode(u'%E2%9C%88%20%E2%9C%88') == u'✈✈'
    assert unicode_urldecode(u'%E2%9C%88%09%E2%9C%88') == u'✈✈'

# Generated at 2022-06-23 10:25:29.081810
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'http%3A%2F%2Fgithub.com') == u'http://github.com'



# Generated at 2022-06-23 10:25:40.686260
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert quote('foo/bar') == quote_plus('foo/bar')
    assert quote('foo+bar') == quote_plus('foo+bar')
    assert unquote_plus('foo%2Fbar') == 'foo/bar'
    assert unquote_plus('foo%2Bbar') == 'foo+bar'
    assert fm.filters()['urldecode']('foo%2Fbar') == 'foo/bar'
    assert fm.filters()['urldecode']('foo%2Bbar') == 'foo+bar'
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('foo/bar') == 'foo%2Fbar'

# Generated at 2022-06-23 10:25:42.557710
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fmodule = FilterModule()
    assert fmodule is not None


# Generated at 2022-06-23 10:25:51.644865
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(1) == '1'
    assert do_urlencode('a=b') == 'a%3Db'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode([('a', 'b'), ('b', 'c')]) == 'a=b&b=c'
    assert do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'