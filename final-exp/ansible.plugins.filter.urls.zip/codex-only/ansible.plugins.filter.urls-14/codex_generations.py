

# Generated at 2022-06-23 10:16:02.045343
# Unit test for function do_urlencode
def test_do_urlencode():

    # Test string input
    assert do_urlencode("test1") == "test1"
    assert do_urlencode("test 2") == "test%202"
    assert do_urlencode("test??") == "test%3F%3F"

    # Test dictionary input
    d1 = {'test': 'test1', 'test 2': 'test 2'}
    assert do_urlencode(d1) == "test 2=test%202&test=test1"

    # Test list input
    l1 = range(5)
    assert do_urlencode(l1) == "0=0&1=1&2=2&3=3&4=4"

    # Test tuple input
    t1 = (1,2,3)

# Generated at 2022-06-23 10:16:06.547220
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    for i in iter(fm.filters().items()):
        if i[0] == 'urlencode':
            assert i[1] == do_urlencode
            return
    assert False

# Generated at 2022-06-23 10:16:08.567402
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)



# Generated at 2022-06-23 10:16:16.762696
# Unit test for function do_urldecode
def test_do_urldecode():
    assert 'a=1&b=2' == do_urldecode('a=1&b=2')
    assert 'a=1&b=2' == do_urldecode({'a': '1', 'b': '2'})
    assert 'a=1&b=2' == do_urldecode(['a=1', 'b=2'])
    assert 'a=1&b=2' == do_urldecode(('a=1', 'b=2'))
    assert 'foo%20bar' == do_urldecode('foo bar')
    assert 'foo%20bar%20baz' == do_urldecode('foo bar baz')

# Generated at 2022-06-23 10:16:27.145980
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('ab c') == 'ab%20c'
    assert unicode_urlencode('ab%20c') == 'ab%2520c'
    assert unicode_urlencode('ab+c') == 'ab+c'
    assert unicode_urlencode('ab+c', for_qs=True) == 'ab%2Bc'
    assert unicode_urlencode({'one': 'two'}) == 'one=two'
    assert unicode_urlencode({'one': 'two', 'three': 'four'}) == 'three=four&one=two'
    assert unicode_urlencode([('three', 'four'), ('one', 'two')]) == 'three=four&one=two'

# Unit

# Generated at 2022-06-23 10:16:37.757619
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('asdf') == 'asdf'
    assert unicode_urlencode('asdf=') == 'asdf%3D'
    assert unicode_urlencode('asdf=/') == 'asdf%3D%2F'
    assert unicode_urlencode('asdf=') == 'asdf%3D'
    assert unicode_urlencode('asdf=') == 'asdf%3D'
    assert unicode_urlencode('asdf') == 'asdf'
    assert unicode_urlencode('asdf?') == 'asdf%3F'
    assert unicode_urlencode('asdf?=') == 'asdf%3F%3D'

# Generated at 2022-06-23 10:16:47.981079
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:16:50.981414
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert "abc def" == unicode_urldecode("abc%20def")
    assert "abc def" == unicode_urldecode("abc+def")


# Generated at 2022-06-23 10:16:59.363065
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%%%2F') == u'%%%2F'
    assert unicode_urldecode('%%2F') == u'%%2F'
    assert unicode_urldecode('%25%25') == u'%%'
    assert unicode_urldecode('%25%25%2F') == u'%%%2F'
    assert unicode_urldecode('%25%25%2F%25%25') == u'%%%2F%%'
    assert unicode_urldecode(u'%25%25%2F%25%25') == u'%%%2F%%'

# Generated at 2022-06-23 10:17:00.878204
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)


# Generated at 2022-06-23 10:17:10.681770
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    module = AnsibleModule(
        argument_spec=dict(),
    )


# Generated at 2022-06-23 10:17:12.586046
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() is not None

# Generated at 2022-06-23 10:17:21.520627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  # Test with Jinja2 >= 2.7
  if HAS_URLENCODE:
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode
  # Test with Jinja2 < 2.7
  else:
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:17:24.670179
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    assert 'urldecode' in FilterModule.filters(FilterModule())
    if not HAS_URLENCODE:
        assert 'urlencode' in FilterModule.filters(FilterModule())

# Generated at 2022-06-23 10:17:25.987991
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x.filters()

# Generated at 2022-06-23 10:17:37.397862
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'@', for_qs=True) == u'%40'
    assert unicode_urlencode(u'&', for_qs=True) == u'%26'
    assert unicode_urlencode(u'+', for_qs=True) == u'%2B'
    assert unicode_urlencode(u'/', for_qs=False) == u'%2F'
    assert unicode_urlencode(u'=', for_qs=True) == u'%3D'
    assert unicode_urlencode(u'%', for_qs=True) == u'%25'



# Generated at 2022-06-23 10:17:50.269372
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo=bar') == unicode_urlencode('foo=bar')
    assert do_urlencode('foo bar') == unicode_urlencode('foo bar')
    assert do_urlencode('/?-') == unicode_urlencode('/?-')
    assert do_urlencode('/') == unicode_urlencode('/')
    assert do_urlencode('/') != unicode_urlencode('/', for_qs=True)
    assert do_urlencode({'foo': 'bar'}) == unicode_urlencode({'foo': 'bar'})
    assert do_urlencode({'foo': 'bar'}) == unicode_urlencode(('foo', 'bar'))
    assert do_urlencode(('foo', 'bar')) == unicode

# Generated at 2022-06-23 10:17:56.292748
# Unit test for function do_urlencode
def test_do_urlencode():
    params = {'a': 'b', 'c': 'd', 'e': None}
    assert do_urlencode(params) == 'a=b&c=d'

    params = ['a', 'b', {'c': 'd'}, 'e', None, ['f', 'g']]
    assert do_urlencode(params) == 'a=b&c=d&e&f=g'


# Generated at 2022-06-23 10:18:04.609647
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    >>> test_unicode_urlencode()
    '''
    from jinja2.filters import do_urlencode as jinja_urlencode
    from jinja2.filters import do_urlencode as jinja_urlencode_qs


# Generated at 2022-06-23 10:18:16.068609
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs, parse_qsl
    import unittest

    class TestDoUrlencode(unittest.TestCase):

        def test_simple_string(self):
            s = do_urlencode('simple string')
            self.assertEqual(s, 'simple+string')

        def test_one_string_in_list(self):
            s = do_urlencode(['simple string'])
            self.assertEqual(s, 'simple+string')

        def test_list_of_strings(self):
            s = do_urlencode(['string1', 'string2'])
            self.assertEqual(s, 'string1&string2')

        def test_dict_of_strings(self):
            s

# Generated at 2022-06-23 10:18:26.344896
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('%') == '%25'
    assert unicode_urlencode('%25') == '%2525'
    assert unicode_urlencode('%X') == '%25X'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/abc') == '%2Fabc'
    assert unicode_urlencode('/abc', for_qs=True) == '%2Fabc'
    assert unicode_urlencode('/%') == '%2F%25'

# Generated at 2022-06-23 10:18:35.519900
# Unit test for function do_urlencode
def test_do_urlencode():
    import ansible.utils.urlesc as ue

    # Test 1: string
    assert do_urlencode("Hello world!") == "Hello+world%21"

    # Test 2: list
    assert do_urlencode(["Hello", "world!"]) == "Hello&world%21"

    # Test 3: tuple
    assert do_urlencode(("Hello", "world!")) == "Hello&world%21"

    # Test 4: dict
    assert do_urlencode({"Hello": "world!"}) == "Hello=world%21"

    # Test 5: int
    try:
        do_urlencode(42)
        assert False, "do_urlencode(42) should fail with a TypeError"
    except TypeError:
        pass

    # Test 6: integer + non-ASCII
   

# Generated at 2022-06-23 10:18:36.747092
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert type(result).__name__ == "FilterModule"

# Generated at 2022-06-23 10:18:42.649566
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ff = FilterModule()

    # urldecode
    assert ff.filters()['urldecode']('%77%77%77%2e%67%6f%6f%67%6c%65%2e%63%6f%6d') == 'www.google.com'
    assert ff.filters()['urldecode']('%41%42%43') == 'ABC'
    assert ff.filters()['urldecode']('%E4%BD%A0%E5%A5%BD') == '你好'
    assert ff.filters()['urldecode']('A%5C+%5C+B+%5C+C%5C') == 'A\\  B \\C\\'

    # urlencode

# Generated at 2022-06-23 10:18:54.035926
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:18:57.622030
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("dag%2f") == 'dag/'
    assert do_urldecode("%E6%BF%95") == u'濕'



# Generated at 2022-06-23 10:19:09.475064
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('key=value') == u'key=value'
    assert do_urldecode('%21') == u'!'
    assert do_urldecode('%26') == u'&'
    assert do_urldecode('%27') == u"'"
    assert do_urldecode('%28') == u'('
    assert do_urldecode('%29') == u')'
    assert do_urldecode('%25') == u'%'
    assert do_urldecode('%3D') == u'='
    assert do_urldecode('%2B') == u'+'
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%7E') == u'~'


# Generated at 2022-06-23 10:19:14.748341
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3D%3D') == '=='
    assert unicode_urldecode('%3D%3D', True) == '%3D%3D'
    assert unicode_urldecode('%3D%3D', False) == '%3D%3D'



# Generated at 2022-06-23 10:19:16.657330
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''

    filter_module = FilterModule()
    assert(filter_module.filters() == {'urldecode': do_urldecode})

# Generated at 2022-06-23 10:19:23.687804
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

    assert filters['urldecode']('a%2Bb%2Bc') == 'a+b+c'
    if PY3:
        assert filters['urldecode']('a+b+c') == 'a b c'
    assert filters['urlencode']('a b c') == 'a+b+c'
    assert filters['urlencode']('a+b+c') == 'a%2Bb%2Bc'

# Generated at 2022-06-23 10:19:33.600003
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%3A%2F%2F') == '://'
    assert do_urldecode('%3A%2F%2F%2F') == ':///'
    assert do_urldecode('%22string%22') == '"string"'
    assert do_urldecode('%7B%22key%22%3A%22value%22%7D') == '{"key":"value"}'
    assert do_urldecode('%5B%22item%22%5D') == '["item"]'
    assert do_urldecode('%3A') == ':'
    assert do_urldecode('%2F') == '/'


# Generated at 2022-06-23 10:19:43.874861
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'x') == u'x'
    assert unicode_urlencode(u'xx') == u'xx'
    assert unicode_urlencode(u'a a') == u'a+a'
    assert unicode_urlencode(u'=') == u'%3D'
    assert unicode_urlencode(u'&') == u'%26'
    assert unicode_urlencode(u';') == u';'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'?') == u'%3F'
    assert unicode_urlencode(u'?') == u'%3F'
    assert unicode_urlencode(u'#') == u'%23'


#

# Generated at 2022-06-23 10:19:53.882270
# Unit test for function do_urlencode
def test_do_urlencode():
    # test for a list of tuples
    data = [('key', 'value'),
            ('key2', 'value2')]
    # NOTE: The order of key/value pairs is not defined
    assert do_urlencode(data) == 'key=value&key2=value2' or do_urlencode(data) == 'key2=value2&key=value'

    # test for a string
    assert do_urlencode('key=value') == 'key%3Dvalue'

    # test for a dict
    data = {'key': 'value',
            'key2': 'value2'}
    # NOTE: The order of key/value pairs is not defined

# Generated at 2022-06-23 10:20:01.932434
# Unit test for function do_urldecode
def test_do_urldecode():
    import unittest
    from tempfile import TemporaryFile
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 10:20:09.222796
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc+def') == u'abc def'
    assert unicode_urldecode('abc%2Bdef') == u'abc+def'
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%25def') == u'abc%def'
    assert unicode_urldecode('abc%2525def') == u'abc%25def'


# Generated at 2022-06-23 10:20:12.753010
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urldecode' in FilterModule().filters()

    # Test urldecode()
    assert do_urldecode("%32%34%36") == "246"

# Generated at 2022-06-23 10:20:22.257391
# Unit test for function do_urldecode
def test_do_urldecode():
    assert(do_urldecode('a%20b%20') == 'a b ')
    assert(do_urldecode('a+b+') == 'a b ')
    assert(do_urldecode('a+b%20') == 'a b ')
    assert(do_urldecode('a%20b+') == 'a b ')
    assert(do_urldecode('a%20b%20') == 'a b ')
    assert(do_urldecode('%20a%20b%20') == ' a b ')
    assert(do_urldecode('%20a%20b%20%20') == ' a b  ')
    assert(do_urldecode('%20') == ' ')

# Generated at 2022-06-23 10:20:31.815029
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("a/b") == 'a%2Fb'
    assert do_urlencode("a,b") == 'a%2Cb'
    assert do_urlencode("a&b") == 'a%26b'
    assert do_urlencode("a%b") == 'a%25b'
    assert do_urlencode("a+b") == 'a%2Bb'
    assert do_urlencode("a+b/c") == 'a%2Bb%2Fc'
    assert do_urlencode("a"*1000) == "a"*1000
    assert do_urlencode({"a": 1, "b": 2}) == 'a=1&b=2'

# Generated at 2022-06-23 10:20:33.638647
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None

# Generated at 2022-06-23 10:20:42.556512
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    import sys
    if sys.version_info < (2, 7):
        basic.ANSIBLE_TEST_AS_LIBC = True
    else:
        basic.ANSIBLE_TEST_AS_LIBC = False
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY3
    fm = FilterModule()

    assert fm.filters()['urldecode']('hello%20world') == 'hello world'

    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('hello world') == 'hello+world'
        assert fm.filters()['urlencode']('hello:world') == 'hello%3Aworld'

    # Jinja 2

# Generated at 2022-06-23 10:20:49.529734
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"foo") == u"foo"
    assert do_urlencode(u"foo bar") == u"foo+bar"
    assert do_urlencode(u"foo+bar") == u"foo%2Bbar"
    assert do_urlencode(u"foo bar/baz") == u"foo+bar%2Fbaz"
    assert do_urlencode(u"foo+bar/baz") == u"foo%2Bbar%2Fbaz"
    assert do_urlencode(u"foo bar=baz") == u"foo+bar%3Dbaz"
    assert do_urlencode(u"foo+bar=baz") == u"foo%2Bbar%3Dbaz"

# Generated at 2022-06-23 10:21:00.058839
# Unit test for function do_urlencode
def test_do_urlencode():
    a = u'abc'
    assert do_urlencode(a) == u'abc'

    a = u'Hello world!'
    assert do_urlencode(a) == u'Hello%20world%21'

    a = u'Hello\nworld\r!'
    assert do_urlencode(a) == u'Hello%0Aworld%0D%21'

    d = {
        u'a': u'Hello',
        u'b': u'world!',
    }
    assert do_urlencode(d) == u'a=Hello&b=world%21'

    # Do not forget list
    l = [
        u'a=Hello',
        u'b=world!',
    ]

# Generated at 2022-06-23 10:21:03.095630
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B6') == u'ö'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'



# Generated at 2022-06-23 10:21:08.835122
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == 'foo+bar'
    assert unicode_urlencode(u'foo bar', True) == 'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar', True) == 'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == 'foo/bar'
    assert unicode_urlencode(u'foo/bar', True) == 'foo%2Fbar'
    assert unicode_urlencode(u'foo=bar') == 'foo%3Dbar'
    assert unicode_urlencode(u'foo=bar', True) == 'foo%3Dbar'

# Generated at 2022-06-23 10:21:15.232940
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(1) == '1'
    assert do_urlencode(('a', 'b')) == 'a&b'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode(['a=b']) == 'a%3Db'
    assert do_urlencode(['a', 'b']) == 'a&b'

# Generated at 2022-06-23 10:21:22.037163
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urldecode'].__name__ == 'do_urldecode'
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'].__name__ == 'do_urlencode'

# Generated at 2022-06-23 10:21:34.821886
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Basic test of utf-8
    assert unicode_urlencode('test\u2003test') == u"test%C2%A0test"

    def encode_with_safe(safe):
        return unicode_urlencode("test?test", safe)
    assert encode_with_safe("/") == u"test%3Ftest"
    assert encode_with_safe("") == u"test?test"
    assert encode_with_safe("?") == u"test?test"
    assert encode_with_safe("/?") == u"test?test"

    # Test for unicode integers in python 2
    assert unicode_urlencode(u"test\u00E9test") == u"test%C3%A9test"

    # Test for non ascii string
    assert unicode_urlen

# Generated at 2022-06-23 10:21:36.221686
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)


# Generated at 2022-06-23 10:21:38.878403
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode('Test%20Test+Test%20Test')
    assert result == 'Test Test Test Test'

# Generated at 2022-06-23 10:21:41.910173
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fwww.abc.com%2F%3Fx%3D2%26y%3D4') == \
        u'http://www.abc.com/?x=2&y=4'


# Generated at 2022-06-23 10:21:50.058248
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20+%21%22%23%24%25%26%27%28%29%2A%2B%2C%2D%2E%2F%30') == u' +!"#$%&\'()*+,-./0'
    assert do_urldecode('%31%32%33%34%35%36%37%38%39%3A%3B%3C%3D%3E%3F%40') == u'123456789:;<=>?@'
    assert do_urldecode('%41%42%43%44%45%46%47%48%49%4A%4B%4C%4D%4E%4F%50') == u'ABCDEFGHIJKLMNOP'
    assert do_urldec

# Generated at 2022-06-23 10:21:56.617793
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello%2C+World%21') == u'Hello, World!'
    assert unicode_urldecode('Hello%2C%20World%21') == u'Hello, World!'
    assert unicode_urldecode('Hello%2C+World%21%2FSub%2F') == u'Hello, World!/Sub/'



# Generated at 2022-06-23 10:21:57.826454
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_ = FilterModule()
    assert test_.filters()

# Generated at 2022-06-23 10:22:04.273158
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('key1=val1&key2=val2') == 'key1%3Dval1%26key2%3Dval2'
    assert do_urlencode('key1=val1&key2=va l2') == 'key1%3Dval1%26key2%3Dva%20l2'

    assert do_urlencode(['key1=val1', 'key2=va l2']) == 'key1%3Dval1&key2%3Dva%20l2'
    assert do_urlencode({'key1': 'val1', 'key2': 'va l2'}) == 'key1%3Dval1&key2%3Dva%20l2'



# Generated at 2022-06-23 10:22:09.149901
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('https%3A%2F%2Fgithub.com%2Fansible%2Fansible%2Fissues%2F47495') == 'https://github.com/ansible/ansible/issues/47495'


# Generated at 2022-06-23 10:22:15.518559
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'\x01\x02\x03\x04\x05') == '%01%02%03%04%05'
    assert do_urlencode(u'\x01/\x02\x03\x04\x05') == '%01/%02%03%04%05'


if __name__ == '__main__':
    test_do_urlencode()

# Generated at 2022-06-23 10:22:20.355562
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('%7B%22key%22%3A%22value%22%7D') == '{"key":"value"}'
    else:
        assert unicode_urldecode('%7B%22key%22%3A%22value%22%7D') == u'{"key":"value"}'


# Generated at 2022-06-23 10:22:30.209400
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:22:40.265575
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test encoding
    string = u'Das ist ein Test mit einer Umlaut \xc3\xbc.'
    result = u'Das+ist+ein+Test+mit+einer+Umlaut+%C3%BC.'
    assert unicode_urldecode(result) == string

    string = u'Das ist ein Test mit einer Umlaut %C3%BC.'
    result = u'Das+ist+ein+Test+mit+einer+Umlaut+%C3%BC.'
    assert unicode_urldecode(result) == string

    string = u'Das ist ein Test mit einer Umlaut \xc3\xbc.'

# Generated at 2022-06-23 10:22:47.545252
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo%2Fbar') == u'foo%252Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo%2Bbar') == u'foo%252Bbar'

# Generated at 2022-06-23 10:22:50.618909
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    test for function urlencode
    :return:
    """
    x = FilterModule()
    assert x.filters()['urlencode']({})

# Generated at 2022-06-23 10:23:00.357752
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        return 'Cannot run unicode_urlencode unit tests under python 2'

# Generated at 2022-06-23 10:23:04.712994
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    for name, method in iteritems(filters):
        assert hasattr(fm, name)
        assert callable(method)


# Generated at 2022-06-23 10:23:13.893451
# Unit test for function do_urlencode
def test_do_urlencode():
    for string, for_qs, result in [
            ('string', False, 'string'),
            ('key=value', False, 'key%3Dvalue'),
            ('key=val+ue', False, 'key%3Dval%2Bue'),
            ('key=val ue', True, 'key%3Dval+ue'),
            # Test both dict and iter
            ({'key': 'val ue'}, True, 'key=val+ue'),
            (('key', 'val ue'), True, 'key=val+ue'),
            ([('key', 'val ue')], True, 'key=val+ue'),
    ]:
        assert unicode_urlencode(string, for_qs) == result, \
            'unicode_urlencode returned unexpected result for %s' % string



# Generated at 2022-06-23 10:23:25.065606
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a b') == u'a+b'
    assert unicode_urlencode(u'a+b') == u'a%2Bb'
    assert unicode_urlencode(u'a b', for_qs=True) == u'a+b'

    # input string with non-ASCII character
    nonascii_str = u'\u4e2d\u56fd'
    # if for_qs is False, and if the input is a unicode string, utf-8 is used for url encoding
    assert unicode_urlencode(nonascii_str) == u'%E4%B8%AD%E5%9B%BD'
    # if for_qs is True, and if the input is a unicode string, iso-8859-1

# Generated at 2022-06-23 10:23:27.225837
# Unit test for constructor of class FilterModule
def test_FilterModule():
    w_obj_FilterModule = FilterModule()
    assert w_obj_FilterModule
    if (w_obj_FilterModule):
        print ("Success: FilterModule() instantiated")



# Generated at 2022-06-23 10:23:39.245833
# Unit test for function do_urlencode
def test_do_urlencode():
    print("FilterModule: function do_urlencode()")

    class TestAnsibleModule(object):
        def __init__(self, source=None):
            self.params = source

    res = FilterModule().filters()
    assert res['urlencode']('abcd') == 'abcd'
    assert res['urlencode']('abcd/efgh') == 'abcd%2Fefgh'
    assert res['urlencode']([1, 2, 3]) == '1&2&3'
    assert res['urlencode']({'key1': 'val1', 'key2': 'val2'}) == 'key1=val1&key2=val2'

    module = TestAnsibleModule(source={"key1": "val1", "key2": "val2"})

# Generated at 2022-06-23 10:23:49.224218
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''
    Test constructor of class FilterModule
    '''
    obj = FilterModule()
    if not PY3:
        assert obj.filters()['urldecode'].__self__.__class__ == FilterModule
        assert obj.filters()['urlencode'].__self__.__class__ == FilterModule
    else:
        assert obj.filters()['urldecode'].__self__.__class__.__name__ == 'FilterModule'
        assert obj.filters()['urlencode'].__self__.__class__.__name__ == 'FilterModule'



# Generated at 2022-06-23 10:23:54.961329
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urldecode']('%26') == '&'

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode
        assert filters['urlencode']('&') == '%26'


# Generated at 2022-06-23 10:24:01.010278
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b') == 'a b'
    assert do_urldecode('a%20b') == 'a b'
    assert do_urldecode('a%2Bb') == 'a+b'
    assert do_urldecode(do_urlencode({'a b': 'c+d'})) == u'a+b=c%2Bd'

if __name__ == '__main__':
    test_do_urldecode()

# Generated at 2022-06-23 10:24:11.182762
# Unit test for function do_urlencode
def test_do_urlencode():
    result = do_urlencode('foo=bar')
    assert result == 'foo%3Dbar'

    result = do_urlencode('foo=bar&bar=baz')
    assert result == 'foo%3Dbar&bar%3Dbaz'

    result = do_urlencode(dict(foo='bar', bar='baz'))
    assert result == 'foo%3Dbar&bar%3Dbaz'

    result = do_urlencode(('foo', 'bar'))
    assert result == 'foo&bar'

    result = do_urlencode(dict(foo=list(range(10))))

# Generated at 2022-06-23 10:24:18.390551
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%7B%22en%22%3A%5B%22And%22%2C%22this%22%5D%7D') == u'{"en":["And","this"]}'


# Generated at 2022-06-23 10:24:19.211860
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:24:22.910696
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('ab=cd') == 'ab%3Dcd', 'urlencoding failed'
    assert do_urlencode(u'ab=cd') == 'ab%3Dcd', 'urlencoding failed'


# Generated at 2022-06-23 10:24:25.940426
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    assert FilterModule().filters()['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:24:27.402859
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()



# Generated at 2022-06-23 10:24:34.142682
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic

    arg_spec = dict(
        value=dict(required=True),
        for_qs=dict(type='bool', default=False),
        quote_via=dict(type='str', choices=['quote', 'quote_plus']),
    )

    m = basic.AnsibleModule(argument_spec=arg_spec)

    m.exit_json(changed=False, stdout=do_urlencode(m.params['value']))

# Generated at 2022-06-23 10:24:45.875733
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('/foo/bar') == '%2Ffoo%2Fbar'
    assert unicode_urlencode('foo bar') == 'foo+bar'
    assert unicode_urlencode('foo bar', True) == 'foo+bar'
    assert unicode_urlencode('foo=bar') == 'foo%3Dbar'
    assert unicode_urlencode('foo=bar', True) == 'foo%3Dbar'
    assert unicode_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert unicode_urlencode({'foo1': 'bar1', 'foo2': 'bar2'})

# Generated at 2022-06-23 10:24:48.548490
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b%2b%C3%A9%d0%a0') == 'a b+éр'

# Generated at 2022-06-23 10:24:52.188557
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        assert FilterModule()
    except:
        raise AssertionError

__all__ = ['FilterModule', 'unicode_urldecode', 'unicode_urlencode']

# Generated at 2022-06-23 10:25:02.561418
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:25:12.806713
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo/bar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'¿Cómo estás?') == u'%C2%BF%C3%93mo%20est%C3%A1s%3F'


# Generated at 2022-06-23 10:25:19.592087
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'a+b+c') == u'a b c'
    assert do_urldecode(u'a%20b%20c') == u'a b c'
    assert do_urldecode(u'a+b%20c') == u'a b c'
    assert do_urldecode(u'%C3%A5+b%20c') == u'å b c'


# Generated at 2022-06-23 10:25:25.692099
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%3Db') == 'a=b'
    assert unicode_urldecode('%26%23%25') == '&#%'
    assert unicode_urldecode('+%2B+') == ' + '



# Generated at 2022-06-23 10:25:31.051194
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"café") == u'caf%C3%A9'
    # Check that it works with multiple items
    assert do_urlencode([('abc',1),('def',2)]) == u'abc=1&def=2'
    assert do_urlencode({'abc':1,'def':2}) == u'abc=1&def=2'



# Generated at 2022-06-23 10:25:32.958357
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))



# Generated at 2022-06-23 10:25:37.653442
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    fm = FilterModule()
    assert isinstance(fm, FilterModule)

    filters = fm.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode



# Generated at 2022-06-23 10:25:45.815201
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:25:49.156399
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.utils.unicode import to_unicode
    correct = u'hello%2Fthere'
    assert correct == unicode_urlencode(to_unicode('hello/there'))

# Generated at 2022-06-23 10:25:50.595265
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm=FilterModule()



# Generated at 2022-06-23 10:25:59.252666
# Unit test for function unicode_urldecode