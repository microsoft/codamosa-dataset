

# Generated at 2022-06-23 10:15:53.715233
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Unit tests for do_urldecode

# Generated at 2022-06-23 10:15:57.430124
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters.get('urldecode') is do_urldecode
    if not HAS_URLENCODE:
        assert filters.get('urlencode') is do_urlencode

# Generated at 2022-06-23 10:16:06.608246
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo') == u'http%3A%2F%2Ffoo'
    assert unicode_urlencode(u'http://foo', for_qs=True) == u'http%3A%2F%2Ffoo'
    assert unicode_urlencode(u'http://foo', for_qs=True) == u'http%3A%2F%2Ffoo'
    assert unicode_urlencode(u'http://foo/') == u'http%3A%2F%2Ffoo%2F'
    assert unicode_urlencode(u'http://foo/', for_qs=True) == u'http%3A%2F%2Ffoo%2F'

# Generated at 2022-06-23 10:16:10.964860
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert 'urldecode' in f.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in f.filters()
    else:
        assert 'urlencode' not in f.filters()


# Generated at 2022-06-23 10:16:13.849528
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urldecode' in fm.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()

# Generated at 2022-06-23 10:16:20.202918
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    vault_secret = VaultSecret('dummy', 1)
    vault = VaultLib([('dummy', vault_secret)], 1)
    tmpl_vars = dict(
        vault=vault,
        inventory_hostname='dummy',
        ansible_host='dummy',
    )
    env = jinja2.Environment(undefined=jinja2.StrictUndefined, extensions=['jinja2.ext.loopcontrols'])
    env.filters.update(FilterModule().filters())
    assert env.filters['urldecode']('Hello%2C%20World%21') == 'Hello, World!'

# Generated at 2022-06-23 10:16:23.479867
# Unit test for function unicode_urldecode

# Generated at 2022-06-23 10:16:31.652372
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcabcabc') == u'abcabcabc'
    assert unicode_urldecode('abc%26%26%26abc') == u'abc&&&abc'
    assert unicode_urldecode('%7B%7D%5B%5D') == u'{}[]'
    assert unicode_urldecode('%25%25') == u'%%'
    assert unicode_urldecode('%26%26%26') == u'&&&'
    assert unicode_urldecode('+abc+abc+') == u' abc abc '
    assert unicode_urldecode('hello world') == u'hello world'



# Generated at 2022-06-23 10:16:42.015514
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test function for unicode_urldecode
    '''
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%c3%a4%c3%b6%c3%bc%c3%9f') == u'äöüß'
    assert unicode_urldecode('%25C3%25A4%25C3%25B6%25C3%25BC%25C3%259F') == '%25C3%25A4%25C3%25B6%25C3%25BC%25C3%259F'
    assert unicode_urldecode('%unreserved_chars')

# Generated at 2022-06-23 10:16:46.709555
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode']('a%20b%3f') == 'a b?'
    assert f.filters()['urldecode']('a+b%3F') == 'a b?'
    assert (f.filters()['urldecode']('a%20b%26c%3Fd%3Dfoo') ==
            'a b&c?d=foo')

# Generated at 2022-06-23 10:16:57.018959
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode(b'abc' if PY3 else u'abc') == 'abc'
    assert unicode_urlencode('abc?def') == 'abc%3Fdef'
    assert unicode_urlencode(b'abc?def' if PY3 else u'abc?def') == 'abc%3Fdef'
    assert unicode_urlencode('abc?def/') == 'abc%3Fdef%2F'
    assert unicode_urlencode(b'abc?def/' if PY3 else u'abc?def/') == 'abc%3Fdef%2F'
    assert unicode_urlencode('abc?def/', for_qs=True) == 'abc%3Fdef%2F'
   

# Generated at 2022-06-23 10:17:08.012635
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == 'test'
    assert do_urlencode(42) == '42'
    assert do_urlencode(['foo', 42, 'bar']) == 'foo&42&bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': ['bar', 42]}) == 'foo=bar&foo=42'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo?bar=foobar') == 'foo%3Fbar=foobar'

# Generated at 2022-06-23 10:17:16.473484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    # Test urldecode
    assert filter_module.filters()['urldecode']('hello%20world') == u'hello world'

    # Test urlencode
    assert filter_module.filters()['urlencode']('hello world') == u'hello%20world'
    assert filter_module.filters()['urlencode']('hello+world') == u'hello%2Bworld'
    assert filter_module.filters()['urlencode']('hello world') == \
           filter_module.filters()['urlencode'](u'hello world')
    assert filter_module.filters()['urlencode'](['hello', 'world']) == u'hello&world'

    # Test do_urlencode
    assert do_urlencode('hello world')

# Generated at 2022-06-23 10:17:21.671371
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'string%20with%20spaces') == u'string with spaces'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'\u4e2d\u6587'


# Generated at 2022-06-23 10:17:26.477584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('%20+%2F%3F%25%23%26%3D%2A%24') == u'%20 /?%#&=*$'



# Generated at 2022-06-23 10:17:35.596636
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert u'abc%20%2F%25' == unicode_urlencode('abc /%')
        assert u'a%2Bb%2Bc' == unicode_urlencode('a+b+c')
    assert 'abc%20%2F%25' == unicode_urlencode('abc /%')
    assert 'a%2Bb%2Bc' == unicode_urlencode('a+b+c')



# Generated at 2022-06-23 10:17:42.731099
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test') == u'test'
    assert unicode_urlencode(u'\u2603') == u'%E2%98%83'
    assert unicode_urlencode(u'\xf6') == u'%C3%B6'
    assert unicode_urlencode(u'test', for_qs=True) == u'test'
    assert unicode_urlencode(u'\u2603', for_qs=True) == u'%E2%98%83'
    assert unicode_urlencode(u'\xf6', for_qs=True) == u'%C3%B6'
    assert unicode_urlencode(u'te st', for_qs=True) == u'te+st'


# Generated at 2022-06-23 10:17:52.986361
# Unit test for function do_urlencode
def test_do_urlencode():
    # We just test for cases where we handle something that jinja2 doesn't
    # (like lists and tuples). Otherwise we expect that the default jinja2
    # urlencode will handle most other cases.
    #
    # We don't handle complex cases like nested lists and dicts because
    # do_urlencode is not designed to handle them (and they're not easily
    # urlencoded in any case)

    assert do_urlencode([]) == ''
    assert do_urlencode(()) == ''
    assert do_urlencode('') == '%27%27'
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do

# Generated at 2022-06-23 10:17:59.310535
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%E8%A8%88%E7%AE%97%E5%9C%96%E7%B6%B2') == u'計算圖網'
    assert do_urldecode('%E8%A8%88%E7%AE%97%E5%9C%96%E7%B6%B2') == u'計算圖網'


# Generated at 2022-06-23 10:18:08.426157
# Unit test for function do_urlencode
def test_do_urlencode():
    url_dict = {'a': 1, 'b': '2', 'c': None, 'd': 'dag,wieers'}
    assert do_urlencode(url_dict) == b'a=1&b=2&d=dag%2Cwieers'

    assert do_urlencode(' ') == b'%20'
    assert do_urlencode(None) == b''

    assert do_urlencode('dag,wieers') == b'dag%2Cwieers'
    assert do_urlencode('dag,wieers', for_qs=True) == b'dag%2Cwieers'

    assert do_urlencode('dag|wieers') == b'dag%7Cwieers'

# Generated at 2022-06-23 10:18:09.816724
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)

# Generated at 2022-06-23 10:18:11.257077
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter


# Generated at 2022-06-23 10:18:23.011753
# Unit test for function do_urlencode
def test_do_urlencode():
    assert unicode_urlencode('a b c') == 'a%20b%20c'
    assert unicode_urlencode(1) == '1'
    assert unicode_urlencode([1, 2, 3]) == '1&2&3'
    assert unicode_urlencode({'a': 'b c'}) == 'a=b%20c'
    assert unicode_urlencode({'a b': 'c'}) == 'a%20b=c'
    assert unicode_urlencode({'a': {'b':'c'}}) == 'a=b=c'
    assert unicode_urlencode({'a': {'b':'c', 'd': 'e'}}) == 'a=b=c&a=d=e'

# Generated at 2022-06-23 10:18:29.874759
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('x%24y%2Bz') == 'x$y+z'
    assert do_urlencode('x$y+z') == 'x%24y%2Bz'
    assert do_urlencode({'x': '$y+z'}) == 'x=%24y%2Bz'



# Generated at 2022-06-23 10:18:35.484344
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test unicode urldecode function
    '''

    data = [
        ('%25', '%'),
        ('%2525', '%%'),
        ('%26', '&'),
        ('%3D', '='),
        ('%252B', '+'),
        ('%252F', '/'),
    ]

    for inp, out in data:
        test_out = unicode_urldecode(inp)
        assert test_out == out


# Generated at 2022-06-23 10:18:45.651465
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com?foo=bar') == u'http%3A//example.com%3Ffoo%3Dbar'
    assert unicode_urlencode(u'foo?bar') == u'foo%3Fbar'
    assert unicode_urlencode(u'foo&bar') == u'foo%26bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unic

# Generated at 2022-06-23 10:18:50.953796
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%27') == u"'"
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%00') == u'\x00'
    assert unicode_urldecode(u'%30') == u'0'
    assert unicode_urldecode(u'%3f') == u'?'
    assert unicode_urldecode(u'%3F') == u'?'
    assert unicode_urldecode(u'%26') == u'&'
    assert unicode_urldecode(u'%27') == u"'"

# Generated at 2022-06-23 10:19:01.683820
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test for Python 2
    if not PY3:
        unicode_urlencode_test_1 = unicode_urlencode(u'\u00e9')
        assert unicode_urlencode_test_1 == u'%C3%A9'

        unicode_urlencode_test_2 = unicode_urlencode(u'\u00e9', True)
        assert unicode_urlencode_test_2 == u'%C3%A9'
    # Test for Python 3
    else:
        unicode_urlencode_test_3 = unicode_urlencode('\u00e9')
        assert unicode_urlencode_test_3 == '%C3%A9'


# Generated at 2022-06-23 10:19:12.204396
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%40%3A%3C%3D%3E%5B%5D%5E%60%7B%7C%7D%7E') == u'@:<=>[]^`{|}~'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%C3%9F') == u'ß'
    assert unicode_urldecode('%5D%5E%60%7B%7C%7D%7E') == u']^`{|}~'
    assert unicode_urldecode('%3A%3C%3D%3E%5B') == u':<=>['
    assert unicode_urldecode('%40%7B%7D')

# Generated at 2022-06-23 10:19:15.087719
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'å') == u'%C3%A5'
    assert unicode_urlencode(u'&') == u'%26'


# Generated at 2022-06-23 10:19:21.611448
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('fo%o') == 'fo%o'
    assert do_urldecode('fo%20o') == 'fo o'
    assert do_urldecode('fo+o') == 'fo+o'
    assert do_urldecode('fo%0Ao') == 'fo\no'
    assert do_urldecode('fo%7Co') == 'fo|o'
    assert do_urldecode('fo%5C%7Co') == 'fo\\|o'
    assert do_urldecode('fo%5C%5C%7Co') == 'fo\\|o'
    assert do_urldecode('fo%25o') == 'fo%o'
    assert do_urld

# Generated at 2022-06-23 10:19:26.433334
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert FilterModule.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:19:30.700974
# Unit test for function do_urlencode
def test_do_urlencode():
    if not HAS_URLENCODE:
        assert do_urlencode(u'foo=bar&baz=föö&zöö=bar') == u'foo=bar&baz=f%C3%B6%C3%B6&z%C3%B6%C3%B6=bar'


# Generated at 2022-06-23 10:19:34.239922
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('&') == '%26'


# Test string with all printable ASCII chars
ASCII_STRING = """`~!@#$%^&*( )_-+=[ ]{{ }};:'"\|,<.>/?"""


# Generated at 2022-06-23 10:19:44.183106
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://localhost/test') == u'http%3A//localhost/test'
    assert do_urlencode(u'http://localhost/t%20est') == u'http%3A//localhost/t%20est'
    assert do_urlencode(u'http://localhost/t est') == u'http%3A//localhost/t%20est'
    assert do_urlencode(u'http://localhost/t+est') == u'http%3A//localhost/t+est'
    assert do_urlencode(u'http://localhost/t est') == u'http%3A//localhost/t%20est'

# Generated at 2022-06-23 10:19:47.020918
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'https://github.com/ansible/ansible/issues?%E2%88%92=%E2%88%92') == u'https://github.com/ansible/ansible/issues?−=−'


# Generated at 2022-06-23 10:19:54.840513
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test valid type
    if PY3:
        test_encode = '%5B%5D'
    else:
        test_encode = '%5B%5D'
    assert test_encode == unicode_urlencode("[]")

    # Test invalid type
    if PY3:
        test_encode = '%5B%5D'
    else:
        test_encode = '%5B%5D'
    assert test_encode == unicode_urlencode(dict([('test', '[]')]))

# Generated at 2022-06-23 10:20:01.216343
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(b'') == u''
    assert unicode_urldecode(b'foo') == u'foo'
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(b'foo') == u'foo'
    assert unicode_urldecode('%2F%26%3D') == u'/&='
    assert unicode_urldecode('%C3%BC') == u'ü'


# Generated at 2022-06-23 10:20:10.772930
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('%2B') == '%2B'
    assert do_urldecode('%2b') == '%2b'
    assert do_urldecode('%2B', '%') == '+'
    assert do_urldecode('%2b', '%') == '+'
    assert do_urldecode('%2B%2B') == '++'
    assert do_urldecode('%2B%2B', '%') == '++'
    assert do_urldecode('%2B%2b%2B%2B') == '++++'

# Generated at 2022-06-23 10:20:11.887699
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert FilterModule().filters()

# Generated at 2022-06-23 10:20:17.446623
# Unit test for function do_urlencode
def test_do_urlencode():
    assert '%22' == do_urlencode(u'"')
    assert '%22' == do_urlencode([u'%22'])
    assert '%22' == do_urlencode({"%22": u'a:b'})
    assert 'a%3Ab' == do_urlencode({"a:b": u'a:b'})
    assert 'a%3Ab' == do_urlencode([u'a', u':', u'b'])

# Generated at 2022-06-23 10:20:18.947384
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:20:27.992596
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f1 = FilterModule()
    res1 = 'ansible_test'
    res2 = f1.filters()['urldecode'](res1)
    res3 = f1.filters()['urlencode'](res1)
    # check whether the class FilterModule is successfully generated
    if res2 == 'ansible_test' and res3 == 'ansible_test' and HAS_URLENCODE == False:
        print('Unit test for constructor of class FilterModule is passed')
    else:
        print('Unit test for constructor of class FilterModule is failed')

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:20:35.548189
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar') == u'foo bar'
    assert do_urldecode('foo+bar') == u'foo bar'
    assert do_urldecode('foo bar') == u'foo bar'


# Generated at 2022-06-23 10:20:39.851916
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/', for_qs=True) == b'/'
    assert unicode_urlencode('/', for_qs=False) == b'%2F'
    assert unicode_urlencode(u'中文') == b'%E4%B8%AD%E6%96%87'



# Generated at 2022-06-23 10:20:44.793846
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Example') == 'Example'
    assert do_urlencode('Example&') == 'Example%26'
    assert do_urlencode({'name': 'Example'}) == 'name=Example'
    assert do_urlencode({'name': 'Example', 'key': 'ansible'}) == 'key=ansible&name=Example'

# Generated at 2022-06-23 10:20:45.761936
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test

# Generated at 2022-06-23 10:20:52.351099
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testInput = FilterModule()
    testExpected = '''{'filters': {'urldecode': <function do_urldecode at 0x7f6c803a1840>, 'urlencode': <function do_urlencode at 0x7f6c7bab1b00>}}'''
    assert testInput.filters() == eval(testExpected)


# Generated at 2022-06-23 10:21:02.016492
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u'', 'Failed to encode empty string'
    assert unicode_urlencode(u'a') == u'a', 'Failed to encode a'
    assert unicode_urlencode(u'a b') == u'a%20b', 'Failed to encode a b'
    assert unicode_urlencode(u'a+b') == u'a%2Bb', 'Failed to encode a+b'
    assert unicode_urlencode(u'a=b') == u'a%3Db', 'Failed to encode a=b'
    assert unicode_urlencode(u'a&b') == u'a%26b', 'Failed to encode a&b'


# Generated at 2022-06-23 10:21:12.782051
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    urlencode_filter = f.filters()['urlencode']
    urldecode_filter = f.filters()['urldecode']

    assert urlencode_filter is not None
    assert urldecode_filter is not None

    assert urlencode_filter('http://localhost') == 'http%3A%2F%2Flocalhost'
    assert urldecode_filter('http%3A%2F%2Flocalhost') == 'http://localhost'

    assert urlencode_filter('What is the answer to life, the universe and everything?') == 'What+is+the+answer+to+life%2C+the+universe+and+everything%3F'

# Generated at 2022-06-23 10:21:14.454954
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('Hello+World%21') == u'Hello World!'



# Generated at 2022-06-23 10:21:22.806451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    assert fm is not None

    filters = fm.filters()
    assert filters is not None
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:21:28.247625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert fm.filters()['urlencode'] is do_urlencode
    assert fm.filters()['urldecode'] is do_urldecode


# Generated at 2022-06-23 10:21:30.202391
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20cba') == 'abc cba'


# Generated at 2022-06-23 10:21:35.290550
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello%2C%20World%21') == u'Hello, World!'
    assert unicode_urldecode('Hello%2C%20World%21%20%E2%98%BA') == u'Hello, World! \u263a'
    assert unicode_urldecode('%F0%9F%92%A9') == u'\U0001f4a9'


# Generated at 2022-06-23 10:21:39.739245
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result = unicode_urlencode(u'http://localhost/a%2Fb')
    if result != u'http%3A//localhost/a%252Fb':
        raise AssertionError("Failed to urlencode %s, returned %s" % (u'http://localhost/a%2Fb', result))

    result = unicode_urlencode(u'http://localhost/a%2Fb', for_qs=True)
    if result != u'http%3A%2F%2Flocalhost%2Fa%252Fb':
        raise AssertionError("Failed to urlencode %s, returned %s" % (u'http://localhost/a%2Fb', result))



# Generated at 2022-06-23 10:21:42.227318
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    source = u'åçèñtødø'
    target = u'%C3%A5%C3%A7%C3%A8%C3%B1t%C3%B8d%C3%B8'
    assert unicode_urlencode(source) == target


# Generated at 2022-06-23 10:21:45.692589
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:21:54.195796
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'a%20space') == u'a space'
    assert do_urldecode(u'a+plus') == u'a plus'
    assert do_urldecode(u'foo%21bar%7Bbaz%7D') == u'foo!bar{baz}'
    assert do_urldecode(b'a%20space') == u'a space'
    assert do_urldecode(b'a+plus') == u'a plus'
    assert do_urldecode(b'foo%21bar%7Bbaz%7D') == u'foo!bar{baz}'



# Generated at 2022-06-23 10:22:01.028804
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo%2Fbar', for_qs=True) == u'foo%252Fbar'
    assert unicode_urlencode(u'foo%252Fbar', for_qs=True) == u'foo%25252Fbar'



# Generated at 2022-06-23 10:22:06.641532
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%252F') == '%2F'
    assert FilterModule().filters()['urldecode']('/') == '/'

    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'](' ') == u'%20'
        assert FilterModule().filters()['urlencode']('%20') == u'%2520'
        assert FilterModule().filters()['urlencode']('/') == u'%2F'
        assert FilterModule().filters()['urlencode']('%2F') == u'%252F'

# Generated at 2022-06-23 10:22:14.956500
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'*') == u'%2A', 'urlencode: *'
    assert unicode_urlencode(u'+') == u'%2B', 'urlencode: +'
    assert unicode_urlencode(u'\'') == u'%27', 'urlencode: \''
    assert unicode_urlencode(u'@') == u'%40', 'urlencode: @'
    assert unicode_urlencode(u'&') == u'%26', 'urlencode: &'



# Generated at 2022-06-23 10:22:20.794781
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a&b') == 'a%26b'
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('%20') == '%2520'
    assert unicode_urlencode('a b', for_qs=True) == 'a+b'
    assert unicode_urlencode('%20', for_qs=True) == '%20'

# Generated at 2022-06-23 10:22:23.827605
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert not isinstance(fm, object)
    assert isinstance(fm.filters, object)
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-23 10:22:32.281122
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'x+y') == u'x y'
    assert do_urldecode(u'x%20y') == u'x y'
    assert do_urldecode(u'x&y') == u'x&y'
    assert do_urldecode(u'x%26y') == u'x&y'
    assert do_urldecode(u'%5Bx%5D') == u'[x]'
    assert do_urldecode(u'x%5By%5Dy') == u'x[y]y'
    assert do_urldecode(u'%5Bx%5D%5By%5D') == u'[x][y]'

# Generated at 2022-06-23 10:22:43.830943
# Unit test for function do_urlencode
def test_do_urlencode():
    # Empty
    assert do_urlencode(None) == ""
    assert do_urlencode(()) == ""
    assert do_urlencode([]) == ""

    # Dictionary
    assert do_urlencode(dict(a='b')) == "a=b"
    assert do_urlencode(dict(a='b', c='d')) == "a=b&c=d"
    assert do_urlencode(dict(a=['b', 'c'])) == "a=b&a=c"

    # List
    assert do_urlencode(['a=b']) == "a%3Db"
    assert do_urlencode(['a=b', 'b=c']) == "a%3Db&b%3Dc"

# Generated at 2022-06-23 10:22:53.939130
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'@=&') == u'%40%3D%26'
    assert unicode_urlencode(u'[]:#') == u'%5B%5D%3A%23'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'



# Generated at 2022-06-23 10:23:01.074977
# Unit test for constructor of class FilterModule
def test_FilterModule():
    utf8 = 'La Pe\xf1a'
    f = FilterModule()
    assert unicode_urldecode(u'La+Pe%C3%B1a') == utf8
    assert do_urldecode(u'La+Pe%C3%B1a') == utf8
    assert do_urlencode(utf8) == u'La+Pe%C3%B1a'
    if not HAS_URLENCODE:
        assert f.filters()['urldecode'] == do_urldecode
        assert f.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:23:05.048724
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)
    assert isinstance(obj.filters(), dict)
    assert "urldecode" in obj.filters().keys()

# Generated at 2022-06-23 10:23:06.456127
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' do_FilterModule_filters() '''
    pass

# Generated at 2022-06-23 10:23:07.052501
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:23:10.321146
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    string = 'a+b'
    assert unicode_urldecode(string) == 'a b'
    string = 'a%20b'
    assert unicode_urldecode(string) == 'a b'



# Generated at 2022-06-23 10:23:16.987839
# Unit test for function do_urldecode
def test_do_urldecode():

    data = u''
    expected = u''
    res = do_urldecode(data)
    assert res == expected

    data = u'a'
    expected = u'a'
    res = do_urldecode(data)
    assert res == expected

    data = u'a b'
    expected = u'a b'
    res = do_urldecode(data)
    assert res == expected

    data = u'a+b'
    expected = u'a b'
    res = do_urldecode(data)
    assert res == expected

    data = u'a%20b'
    expected = u'a b'
    res = do_urldecode(data)
    assert res == expected

    data = u'a%2fb'

# Generated at 2022-06-23 10:23:19.463809
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    filters = module.filters()
    assert HAS_URLENCODE or 'urlencode' in filters.keys()

# Generated at 2022-06-23 10:23:22.853606
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    ret = filter_module.filters()
    assert ret['urldecode'] is do_urldecode
    assert ret['urlencode'] is do_urlencode


# Generated at 2022-06-23 10:23:26.674585
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test the class constructor
    fm = FilterModule()
    assert fm.filters() is not None
    assert fm.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode
    }



# Generated at 2022-06-23 10:23:31.183254
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }

# Generated at 2022-06-23 10:23:40.815494
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert "toto-titi" == unicode_urldecode(u"toto-titi")
    assert "toto-titi" == unicode_urldecode("toto-titi")
    assert u"toto-titi" == unicode_urldecode(u"toto-titi")
    assert u"toto-titi" == unicode_urldecode("toto-titi")
    assert u"toto-titi" == unicode_urldecode(b"toto-titi")
    assert "toto-titi" == unicode_urldecode(b"toto-titi")
    assert "toto-titi" == unicode_urldecode(b"toto-titi")
    assert "toto-titi" == unic

# Generated at 2022-06-23 10:23:52.727428
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a=1%20%3C%3E') == u'a=1 <>'
    assert do_urldecode('a=1%20%3C%3E%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F') == u'a=1 <>//////////'
    assert (do_urldecode({'a': '1%20%3C%3E'})
            == u"a=1%20%3C%3E" or do_urldecode({'a': '1%20%3C%3E'}) == u"a='1%20%3C%3E'")

# Generated at 2022-06-23 10:23:58.920520
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fwww.ecommercetemplates.com%2Fsupport%2Ftopic.asp%3FTOPIC_ID%3D71623') == 'http://www.ecommercetemplates.com/support/topic.asp?TOPIC_ID=71623'


# Generated at 2022-06-23 10:24:08.852063
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert unicode_urlencode(to_text(u'abcd efg')) == to_text(u'abcd%20efg')
        assert unicode_urlencode(to_text(u'abcd+efg')) == to_text(u'abcd%2Befg')
        assert unicode_urlencode(to_text(u'abcd/efg')) == to_text(u'abcd/efg')
    else:
        assert unicode_urlencode('abcd efg') == 'abcd%20efg'
        assert unicode_urlencode('abcd+efg') == 'abcd%2Befg'
        assert unicode_urlencode('abcd/efg') == 'abcd/efg'


# Unit

# Generated at 2022-06-23 10:24:14.082545
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    except ImportError:
        import re
        unquote_plus = lambda s: s
    fm = FilterModule()
    assert fm.filters()['urldecode']('Test%2BOne%21') == unquote_plus('Test%2BOne%21')

# Generated at 2022-06-23 10:24:26.720938
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'http%3A%2F%2Fansible.com%2F' == unicode_urlencode('http://ansible.com/')
    assert 'http%3A%2F%2Fansible.com%2F' == unicode_urlencode('http://ansible.com/', for_qs=True)
    assert 'http%3A%2F%2Fansible.com%2F' == unicode_urlencode(to_bytes('http://ansible.com/'))
    assert 'http%3A%2F%2Fansible.com%2F' == unicode_urlencode(to_bytes('http://ansible.com/'), for_qs=True)
    assert 'http%3A%2F%2Fansible.com%2F' == unicode_url

# Generated at 2022-06-23 10:24:29.446121
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert {'urldecode': do_urldecode} == fm.filters()

# Generated at 2022-06-23 10:24:37.697899
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello') == u'hello'
    assert unicode_urldecode(u'hello%20world') == u'hello world'
    assert unicode_urldecode(u'söme text') == u'söme text'
    assert unicode_urldecode(u'%E4%BD%A0%E5%A5%BD') == u'你好'
    assert unicode_urldecode(u'%D0%B4%D0%B0%D0%B2%D1%88%D0%B5%D0%B9') == u'давшей'
    assert unicode_urldecode(u'hello+world') == u'hello world'
    assert unicode_urldec

# Generated at 2022-06-23 10:24:38.242552
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:24:42.333529
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%20bar%20baz') == 'foo bar baz'
    assert do_urldecode('foo%2fbaz') == 'foo/baz'


# Generated at 2022-06-23 10:24:52.118980
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%5C%E5%BC%8F%E5%AD%97%E7%AC%A6%5C") == u"\\式字符\\"
    assert unicode_urldecode("%5C%E5%AF%AC%5C") == u"\\寬\\"
    assert unicode_urldecode("%5C%E4%B8%AD%5C") == u"\\中\\"
    assert unicode_urldecode("%5C%E7%B9%81%5C") == u"\\繁\\"


# Generated at 2022-06-23 10:24:54.435615
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert type(result.filters) == dict

# Generated at 2022-06-23 10:24:56.518580
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible = FilterModule()
    assert ansible.filters() is not None, "FilterModule is not working."

# Generated at 2022-06-23 10:25:04.703391
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("test+test@test.test") == 'test%2Btest%40test.test'
    assert do_urlencode(["test+test@test.test", "test test"]) == 'test%2Btest%40test.test&test+test'
    assert do_urlencode({"test": "test+test@test.test", "test2": ["test test", "test+test"]}) == 'test=test%2Btest%40test.test&test2=test+test&test2=test%2Btest'

# Generated at 2022-06-23 10:25:12.630191
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('ab%2Bcd') == 'ab+cd'
    #assert unicode_urldecode('ab+cd') == 'ab cd'
    assert unicode_urldecode('ab%C3%BCcd') == u'ab\xfc\x63\x64'
    assert unicode_urldecode('ab%c3%bc%63d') == u'ab\xfc\x63d'
    assert unicode_urldecode('ab%c3%bccd') == u'ab\xfc\x63\x64'


# Generated at 2022-06-23 10:25:23.089407
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''Function unicode_urlencode'''

    assert(unicode_urlencode(u'~') == u'%7E')
    assert(unicode_urlencode(u'/') == u'/')
    assert(unicode_urlencode(u'a/b') == u'a%2Fb')
    assert(unicode_urlencode(u'a/b', for_qs=True) == u'a%2Fb')

    # Cannot use assertRaises
    try:
        unicode_urlencode(None)
        raise AssertionError('Coding error')
    except TypeError:
        pass


# Generated at 2022-06-23 10:25:31.449733
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils.urls import url_argument_spec
    import ansible.plugins.filter.core
    test = ansible.plugins.filter.core.FilterModule()
    test_url = 'https://www.google.be/search?q=+HAHA+++I+AM+A+TEST&ie=utf-8&oe=utf-8&gws_rd=ssl'

    # Testing do_urldecode
    result = test.filters()['urldecode'](test_url)
    assert result == 'https://www.google.be/search?q= HAHA   I AM A TEST&ie=utf-8&oe=utf-8&gws_rd=ssl'

# Generated at 2022-06-23 10:25:37.301677
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.plugins.filter.core import FilterModule

    fm = FilterModule()
    filters = fm.filters()

    assert 'urldecode' in filters

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
    else:
        assert 'urlencode' not in filters



# Generated at 2022-06-23 10:25:37.997445
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:25:46.425387
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    from ansible.module_utils.six.moves.urllib.parse import urlencode, unquote
    import ansible.module_utils.basic
    imports = ansible.module_utils.basic.MODULE_IMPORTS

    fm = FilterModule()
    assert isinstance(fm, object)
    assert hasattr(fm, 'filters')
    assert hasattr(fm.filters, '__call__')
    assert isinstance(fm.filters(), dict)

    f = fm.filters()
    assert isinstance(f, dict)
    if 'urldecode' in f and 'urlencode' in f:
        s = 'a&b=c'
        t = 'a=b&c=d'
        u = 'a=b&c=d&e=f'

# Generated at 2022-06-23 10:25:47.678832
# Unit test for constructor of class FilterModule
def test_FilterModule():
  filter_module = FilterModule()
  assert filter_module

# Generated at 2022-06-23 10:25:57.423058
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'привет мир') == u'%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82%20%D0%BC%D0%B8%D1%80'
    assert unicode_urlencode(u'1/2') == u'1%2F2'
    assert unicode_urlencode(u'1/2', for_qs=True) == u'1%2F2'
    assert unicode_urlencode(u'hello world!') == u'hello%20world%21'
    assert unicode_urlencode(u'hello world!', for_qs=True) == u'hello+world%21'
    assert unicode_urlen