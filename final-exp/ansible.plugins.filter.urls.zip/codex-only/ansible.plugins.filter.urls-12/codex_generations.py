

# Generated at 2022-06-23 10:15:52.028701
# Unit test for function do_urldecode
def test_do_urldecode():

    # test the functionality of do_urldecode()
    assert do_urldecode('foo%20bar') == 'foo bar'


# Generated at 2022-06-23 10:15:53.619370
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%21') == '!'


# Generated at 2022-06-23 10:16:04.007330
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # An ascii urlencoded string
    ascii_urlencoded = 'hello%20there'

    # An unicode string
    unicode_str = u'hello there'

    # An utf-8 encoded string
    utf8_str_bytes = u'hello there'.encode('utf8')

    # An unicode object from the utf8 string
    utf8_str_unicode = to_text(utf8_str_bytes, 'utf8')

    # An unicode object from the urlencoded ascii string
    ascii_str_unicode = to_text(ascii_urlencoded)

    # An utf-8 encoded bytes object from the urlencoded ascii string
    ascii_urlencoded_bytes = to_bytes(ascii_urlencoded)



# Generated at 2022-06-23 10:16:06.600189
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%20b') == u'a b'

# Generated at 2022-06-23 10:16:15.980640
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'%C3%A9') == u'%C3%A9'
    assert unicode_urlencode(u'\xe9') == u'%C3%A9'
    assert unicode_urlencode(u'\u00e9') == u'%C3%A9'
    assert unicode_urlencode(u'%C3%A9', for_qs=True) == u'%25C3%25A9'
    assert unicode_urlencode(u'%E9', for_qs=True) == u'%25E9'
    assert unicode_urlencode(u'\xe9', for_qs=True) == u'%25C3%25A9'

# Generated at 2022-06-23 10:16:21.306779
# Unit test for constructor of class FilterModule
def test_FilterModule():

    test1 = FilterModule()
    assert test1.filters()['urldecode'] is do_urldecode

    if not HAS_URLENCODE:
        assert test1.filters()['urlencode'] is do_urlencode
    else:
        assert 'urlencode' not in test1.filters()

# Generated at 2022-06-23 10:16:28.268348
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test = b'a%2Fb+%2B+c%2Fd'
    assert unicode_urldecode(test) == u'a/b + c/d'
    test = u'a%2Fb+%2B+c%2Fd'
    assert unicode_urldecode(test) == u'a/b + c/d'



# Generated at 2022-06-23 10:16:31.113813
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == 'hello world'



# Generated at 2022-06-23 10:16:32.034487
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:16:35.345772
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%20b%20c') == 'a b c'
    assert do_urldecode('%3C%3E%3A%22') == '<>:"'


# Generated at 2022-06-23 10:16:44.646993
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils._text import to_bytes, to_text
    if PY3:
        assert unicode_urldecode('abc') == 'abc'
        assert isinstance(unicode_urldecode('abc'), str)
    else:
        assert unicode_urldecode('abc') == u'abc'
        assert isinstance(unicode_urldecode('abc'), unicode)  # noqa

    if PY3:
        assert unicode_urldecode('%C3%BC') == 'ü'
        assert isinstance(unicode_urldecode('%C3%BC'), str)
    else:
        assert unicode_urldecode('%C3%BC') == u'ü'

# Generated at 2022-06-23 10:16:55.296064
# Unit test for function do_urldecode
def test_do_urldecode():
    test_data = (
        (u'test%20with%20space', u'test with space'),
        (u'test%C3%A8%C3%A9%C3%AC%C3%B2%C3%B9%20percent%20encoded', u'testèéìòù percent encoded'),
        (b'test%20with%20space', u'test with space'),
        (b'test%C3%A8%C3%A9%C3%AC%C3%B2%C3%B9%20percent%20encoded', u'testèéìòù percent encoded'),
    )
    for test_input, expected_output in test_data:
        assert do_urldecode(test_input) == expected_output

# Generated at 2022-06-23 10:17:01.776740
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcdefg') == 'abcdefg'
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc#def') == 'abc%23def'

    assert unicode_urlencode('abc def', for_qs=True) == 'abc+def'
    assert unicode_urlencode('abc#def', for_qs=True) == 'abc%23def'

    assert unicode_urlencode(['a', 'b']) == 'a&b'
    assert unicode_urlencode(('a', 'b')) == 'a&b'
    assert unicode_urlencode({'a': 'b'}) == 'a=b'

# Generated at 2022-06-23 10:17:09.254542
# Unit test for function do_urldecode
def test_do_urldecode():
    assert '?' not in do_urldecode('%3F')
    assert '?' not in do_urldecode('%3f')
    assert '?' in do_urldecode('%3f', safe='?')
    assert '香' in do_urldecode('%E9%A6%99')
    assert '香' in do_urldecode('%e9%a6%99')
    assert '香 is not 馘' in do_urldecode('%e9%a6%99%20is%20not%20%e9%a6%98')



# Generated at 2022-06-23 10:17:15.332118
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode(u'http://www.example.com/~user/') == u'http%3A//www.example.com/~user/')
    assert(do_urlencode(u'foo=bar&baz=qux') == u'foo%3Dbar%26baz%3Dqux')
    assert(do_urlencode(u'foo=bar&baz=qux&foo=quux') == u'foo%3Dbar%26baz%3Dqux%26foo%3Dquux')
    assert(do_urlencode({u'foo': [u'bar', u'qux']}) == u'foo%3Dbar%26foo%3Dqux')

# Generated at 2022-06-23 10:17:20.892259
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    def assertEval(value, expected):
        assert unicode_urldecode(value) == expected

    assertEval("abc", "abc")
    assertEval("a%20c", "a c")
    assertEval("a+c", "a c")
    assertEval("%41%20%43", "A C")
    assertEval("a%40c", "a@c")
    assertEval("%61%40c", "a@c")
    assertEval("a%40c", "a@c")
    assertEval("%2B17771234567%2B17771234567", "++17771234567+17771234567")
    assertEval("%2B17771234567", "+17771234567")

# Generated at 2022-06-23 10:17:29.073934
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Unit test for do_urldecode()
    '''
    import os
    import sys
    import unittest

    if sys.version_info[0] >= 3:
        os.environ['PYTHONIOENCODING'] = 'ASCII'

    class TestUrldecode(unittest.TestCase):
        '''
        Unit tests for do_urldecode()
        '''

        def test_simple_strings(self):
            '''
            Test do_urldecode() for simple strings
            '''
            self.assertEqual(do_urldecode('username%3dadmin'),
                             'username=admin')
            self.assertEqual(do_urlencode('username=admin'),
                             'username%3Dadmin')


# Generated at 2022-06-23 10:17:36.942877
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    from ansible.module_utils.six import assertRegex

    inst = FilterModule()
    filters = inst.filters()

    assert isinstance(filters, dict)
    # test that urldecode filter exists
    assert callable(filters['urldecode'])

    if not HAS_URLENCODE:
        # test that urlencode filter exists
        assert callable(filters['urlencode'])

# Generated at 2022-06-23 10:17:50.016356
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(None) == ''
    assert do_urlencode(123) == '123'
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode(u'fôo') == u'f%C3%B4o'
    assert do_urlencode([u'fôo', 'bar']) == u'f%C3%B4o=bar'
    assert do_urlencode({u'fôo': 'bar'}) == u'f%C3%B4o=bar'

# Generated at 2022-06-23 10:17:55.741315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert ('urldecode' in fm.filters())
    assert ('urlencode' in fm.filters())

    assert (fm.filters()['urldecode'] == do_urldecode)
    if not HAS_URLENCODE:
        assert (fm.filters()['urlencode'] == do_urlencode)



# Generated at 2022-06-23 10:18:04.301120
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test against example in documentation at http://jinja.pocoo.org/docs/2.10/templates/#urlize
    test = unicode_urldecode(u'http://example.com/foo?a=1&b=2')
    assert test == u'http://example.com/foo?a=1&b=2'

    test2 = unicode_urlencode(test, for_qs=True)
    assert test2 == u'http%3A%2F%2Fexample.com%2Ffoo%3Fa%3D1%26b%3D2'

    test3 = unicode_urlencode(test)
    assert test3 == u'http%3A%2F%2Fexample.com%2Ffoo%3Fa%3D1%26b%3D2'




# Generated at 2022-06-23 10:18:16.028630
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test string
    str = u'https://www.google.com/search?q=cisco+csr+1000v+data+center+bridging+(cdb)+vs.+open+flow&oq=cisco+csr+1000v+data+center+bridging+(cdb)+vs.+open+flow&aqs=chrome..69i57j69i60l4.4651j0j8&sourceid=chrome&ie=UTF-8'

# Generated at 2022-06-23 10:18:26.307472
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc def', for_qs=True) == 'abc+def'
    assert unicode_urlencode(u'\u81ea\u7531') == u'%E8%87%AA%E7%94%B1'
    assert unicode_urlencode(u'\u81ea\u7531', for_qs=True) == u'%E8%87%AA%E7%94%B1'
    assert unicode_urlencode({'abc': 'def', 'ghi': 'jkl'}) == 'abc=def&ghi=jkl'

# Generated at 2022-06-23 10:18:30.449896
# Unit test for function do_urldecode
def test_do_urldecode():
    assert 'Hello there!  This is a URL: http://foo.com/' == do_urldecode(b'Hello+there%21+%0AThis+is+a+URL%3A+http%3A%2F%2Ffoo.com%2F')


# Generated at 2022-06-23 10:18:31.148936
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:18:40.603012
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode("abc%20%7B%25%20xyz") == "abc {% xyz"
    assert unicode_urldecode("abc%2520%7B%25%20xyz") == "abc%20{% xyz"
    assert unicode_urldecode("abc&%20%7B%25%20xyz") == "abc& {% xyz"
    assert unicode_urldecode("abc&%20%7B%25%20xyz") == "abc& {% xyz"
    assert unicode_urldecode("abc&%20%7B%25%20xyz") == "abc& {% xyz"


# Generated at 2022-06-23 10:18:46.896925
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Unit test for FilterModule
    """
    # Fails on python2.6
    from ansible.utils.display import Display
    display = Display()
    test_FilterModule = FilterModule()
    assert isinstance(
        test_FilterModule,
        FilterModule
    )

    assert isinstance(
        test_FilterModule.filters(),
        dict
    )

    for key, value in iteritems(test_FilterModule.filters()):
        display.display(key)

# Generated at 2022-06-23 10:18:57.580433
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/path/to/file') == u'/path/to/file'
    assert unicode_urlencode({'one': 'two', 'three': 'four'}) == u'one=two&three=four'
    assert unicode_urlencode('/path/to/file', for_qs=True) == u'/path/to/file'
    assert unicode_urlencode('one=two&three=four', for_qs=True) == u'one%3Dtwo%26three%3Dfour'
    assert unicode_urlencode(['one', 'two']) == u'one&two'
    assert unicode_urlencode(['one=two', 'three=four'], for_qs=True) == u'one%3Dtwo&three%3Dfour'
   

# Generated at 2022-06-23 10:19:01.990653
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo+bar') == u'foo bar'


# Generated at 2022-06-23 10:19:11.269310
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%2Fname%2Fwith%2Fslash') == \
        '/name/with/slash'
    assert do_urldecode('%2Fname%20with%20spaces') == \
        '/name with spaces'
    assert do_urldecode(u'/name/with/unicode/föö') == \
        u'/name/with/unicode/föö'
    # The following is a special-case where raw strings are always decoded
    assert do_urldecode(r'%2Fname%20with%20spaces') == \
        '/name with spaces'



# Generated at 2022-06-23 10:19:20.494008
# Unit test for function do_urlencode
def test_do_urlencode():

    import ansible.module_utils.urls

    if hasattr(ansible.module_utils.urls, 'do_urlencode'):
        del ansible.module_utils.urls.do_urlencode

    from ansible.module_utils.urls import do_urlencode
    import random

    assert (do_urlencode("") == "")
    assert (do_urlencode("abc") == "abc")
    assert (do_urlencode("a b") == "a+b")
    assert (do_urlencode("a+b") == "a%2Bb")
    assert (do_urlencode("a b") == "a+b")
    assert (do_urlencode("a=b;c") == "a%3Db%3Bc")

# Generated at 2022-06-23 10:19:21.467496
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:19:32.746372
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import parse_qsl

# Generated at 2022-06-23 10:19:39.251542
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unittest.TestCase()
    assert unicode_urldecode('asdf%20%2F%20fdsa') == 'asdf%20%2F%20fdsa'
    assert unicode_urldecode('asdf%20%2F%20fdsa') == u'asdf%20%2F%20fdsa'


# Generated at 2022-06-23 10:19:47.925782
# Unit test for function do_urldecode
def test_do_urldecode():
    assert(do_urldecode('foo') == 'foo')
    assert(do_urldecode('foo+bar') == 'foo bar')
    assert(do_urldecode('foo+b%C3%A1r') == 'foo bár')
    assert(do_urldecode('foo%2Fbar') == 'foo/bar')
    assert(do_urldecode('foo%2Fb%C3%A1r') == 'foo/bár')
    assert(do_urldecode(do_urlencode('foo')) == 'foo')
    assert(do_urldecode(do_urlencode('foo bar')) == 'foo bar')

# Generated at 2022-06-23 10:19:48.595953
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:19:49.681349
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-23 10:19:50.587085
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule



# Generated at 2022-06-23 10:19:55.020429
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("a%20space") == "a space"
    assert do_urldecode("a%20+%2B%3D%3D%26%26%23%23%24%24%25%25%26%26") == "a +==&&##$$%%&&"



# Generated at 2022-06-23 10:19:56.270476
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a+b') == 'a b'


# Generated at 2022-06-23 10:20:05.636032
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    if HAS_URLENCODE:
        test_filters = FilterModule().filters()
        assert test_filters['urlencode'] == do_urlencode
    else:
        test_filters = FilterModule().filters()
        assert test_filters['urlencode'] == do_urlencode

    test_urldecode = test_filters['urldecode']

    assert test_urldecode('foo=bar') == 'foo=bar'
    assert test_urldecode(u'foo=bar') == 'foo=bar'

# Generated at 2022-06-23 10:20:11.597591
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == 'foo/bar'
    assert unicode_urlencode(u'foo+bar', True) == 'foo%2Bbar'
    assert unicode_urlencode(u'foo bar', True) == 'foo+bar'
    assert unicode_urlencode(u'foo/bar', True) == 'foo%2Fbar'


# Generated at 2022-06-23 10:20:13.495423
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:20:14.605866
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:20:15.995832
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-23 10:20:23.870772
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode(u'foo') == 'foo'

    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar') == 'foo%2Fbar'

    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'

    assert unicode_urlencode('foo?bar=yes') == 'foo%3Fbar%3Dyes'
    assert unicode_urlencode(u'foo?bar=yes') == 'foo%3Fbar%3Dyes'


# Generated at 2022-06-23 10:20:27.574174
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u"%2B" == unicode_urldecode("%2B")
    assert "+" == unicode_urldecode("%2B")
    assert u"\u2B06" == unicode_urldecode("%2b06")


# Generated at 2022-06-23 10:20:35.135445
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('%3C%3E%26%20%22%23%25%7B%7D%7C%5E%5B%5D%60%2B%20%3D%3B%2C%2F%3F%40') == u'<>& "#%{}|^[]`+ =;,/?@'
    assert unicode_urldecode('%3C%3E%26%20%22%23%25%7B%7D%7C%5E%5B%5D%60%2B%20%3D%3B%2C%2F%3F%40') == u'<>& "#%{}|^[]`+ =;,/?@'

# Generated at 2022-06-23 10:20:44.406189
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'a b') == u'a+b'


# Generated at 2022-06-23 10:20:45.941438
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert '%20' == do_urlencode(' ')

# Generated at 2022-06-23 10:20:50.623104
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2b+%2B') == u'+ +'


# Generated at 2022-06-23 10:20:58.838448
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if to_text(b'\xc3\xa4', errors='surrogate_or_strict') != u'\u00e4':
        raise Exception("Conversion to unicode failed")
    if to_bytes(u'\u00e4', errors='surrogate_or_strict') != b'\xc3\xa4':
        raise Exception("Conversion to bytes failed")

    s = u'\u00e4'
    encoded = '%C3%A4'
    decoded = unicode_urldecode(encoded)
    assert_equal(s, decoded)


# Generated at 2022-06-23 10:21:05.799290
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abc') == u'abc'
    assert do_urlencode('abc def') == u'abc%20def'
    assert do_urlencode('abc def/') == u'abc%20def%2F'
    assert do_urlencode({'a': '1', 'b': '2'}) == u'a=1&b=2'
    assert do_urlencode(('a', '1')) == u'a=1'

# Generated at 2022-06-23 10:21:16.673329
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'"Python" is a programming language and "Golang" is a programming language') == u'%22Python%22%20is%20a%20programming%20language%20and%20%22Golang%22%20is%20a%20programming%20language'
    assert do_urlencode(u'・ど・す') == u'%E3%83%BB%E3%81%A9%E3%83%BB%E3%81%99'
    assert do_urlencode(u'文字化け') == u'%E6%96%87%E5%AD%97%E5%8C%96%E3%81%91'

# Generated at 2022-06-23 10:21:18.810764
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__doc__ is not None, 'filter module docstring exists'

# Generated at 2022-06-23 10:21:24.663486
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'mystring') == 'mystring'
    assert do_urlencode({'a': 'b', u'c': u'd'}) == 'a=b&c=d'
    assert do_urlencode([u'a=b', u'c=d']) == 'a%3Db&c%3Dd'

# Generated at 2022-06-23 10:21:27.126216
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:21:36.745224
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%3Dbar') == 'foo=bar'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%24') == '$'
    assert unicode_urldecode('%28') == '('
    assert unicode_urldecode('%29') == ')'
    assert unicode_urldecode('%2A') == '*'
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%3B') == ';'

# Generated at 2022-06-23 10:21:39.186083
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    obj = mod.filters()

    assert obj['urldecode'] == do_urldecode

# Generated at 2022-06-23 10:21:46.192362
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Tests for Python 2/3 compatibility
    assert unicode_urldecode('%F6') == u'ö'
    assert unicode_urldecode('%F6') != to_text('ö')
    assert unicode_urldecode('%F6') != u'%F6'
    assert unicode_urldecode('%F6') != '%F6'



# Generated at 2022-06-23 10:21:47.209152
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert isinstance(result, FilterModule)

# Unit tests for urldecode

# Generated at 2022-06-23 10:21:49.397108
# Unit test for function do_urldecode
def test_do_urldecode():
    value = do_urldecode('%2F')
    assert value.find('/') != -1


# Generated at 2022-06-23 10:21:57.687962
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == u'foo/bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    # Now with some bytes in non-ascii:

# Generated at 2022-06-23 10:22:00.874891
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('j%C3%A9%C3%A9') == 'jéé'
    assert unicode_urldecode('j%C3%A9%C3%A9%5D') == 'jéé]'


# Generated at 2022-06-23 10:22:07.387155
# Unit test for function do_urlencode
def test_do_urlencode():
    value = 'an URL with spaces'
    assert do_urlencode(value) == 'an+URL+with+spaces'
    value = 'another URL with spaces'
    assert do_urlencode(value) == 'another+URL+with+spaces'
    value = 'an URL with spaces and "quotes"'
    assert do_urlencode(value) == 'an+URL+with+spaces+and+%22quotes%22'
    value = 'a string with unicode: \u2714'
    assert do_urlencode(value) == 'a+string+with+unicode%3A+%E2%9C%94'
    value = [
        ('foo', 'bar'), ('foo', 'baz'), ('spam', 'eggs')
    ]

# Generated at 2022-06-23 10:22:18.288238
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%E4%B8%AD%E6%96%87') == u'abc中文'
    assert unicode_urldecode('%E9%80%BB%E6%98%8E%E6%B5%8B%E8%AF%95') == u'逻明测试'
    assert unicode_urldecode('%3Fa%3D1%26b%3D2') == u'?a=1&b=2'
    assert unicode_urldecode('%E2%80%AE') == u'®'
    assert unicode_urldecode('%26') == u'&'


# Generated at 2022-06-23 10:22:26.519534
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm_filters = fm.filters()
    assert fm_filters['urldecode'] == do_urldecode
    # We don't expect urlencode filter to be available if imported from jinja2
    assert 'urlencode' not in fm_filters
    assert do_urldecode(u'abc') == u'abc'
    assert do_urldecode(u'abc%20') == u'abc '
    assert do_urldecode(u'abc%20+%20def') == u'abc  +  def'


# Generated at 2022-06-23 10:22:38.180575
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' FilterModule.filters() unit test '''
    # initialize the object
    fm = FilterModule()

    # test for FilterModule.filters() return value
    assert fm.filters() == {
        'urldecode': do_urldecode
    }, fm.filters()
    # test for FilterModule.filters() return value
    assert fm.filters() == {
        'urldecode': do_urldecode
    }, fm.filters()

# Generated at 2022-06-23 10:22:39.542710
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:22:43.718035
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert ('%D6%D0%CE%C4%20%D7%F7%C9%FA%D6%C6%20%C2%ED'
            == unicode_urlencode(to_text('中文 空格 乱码')))



# Generated at 2022-06-23 10:22:51.309100
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        (
            "%2F+%2F+%25+%27+%28+%29",
            "//%+'()"
        ),
        (
            "%2F%2F%25%27%28%29",
            "//%'()"
        )
    ]
    for (urldecode_input, expected) in test_cases:
        assert unicode_urldecode(urldecode_input) == expected



# Generated at 2022-06-23 10:23:00.781147
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # pylint: disable=unused-argument,unused-variable,missing-docstring
    # pylint: disable=redefined-outer-name,redefined-variable-type

    assert unicode_urldecode(u'string%20with%20spaces') == u'string with spaces'
    assert unicode_urldecode(u'%E1%88%B4%E1%8A%95%E1%88%B4') == u'ሴንሴ'

# Generated at 2022-06-23 10:23:11.790324
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("foo") == u'foo'
    assert unicode_urlencode("foo bar") == u'foo%20bar'
    assert unicode_urlencode("foo+bar") == u'foo%2Bbar'

    assert unicode_urlencode("foo", for_qs=True) == u'foo'
    assert unicode_urlencode("foo bar", for_qs=True) == u'foo+bar'
    assert unicode_urlencode("foo+bar", for_qs=True) == u'foo%2Bbar'

    assert unicode_urlencode("foo/bar") == u'foo%2Fbar'
    assert unicode_urlencode("foo/bar", for_qs=True) == u'foo%2Fbar'

    assert unicode_urlencode

# Generated at 2022-06-23 10:23:16.479396
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc+def') == u'abc def'
    assert unicode_urldecode('abc+%F0%9F%98%80') == u'abc 😀'



# Generated at 2022-06-23 10:23:19.884819
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo%27bar%20%2B%25%20baz%20%26%20qux') == u"foo'bar +% baz & qux"


# Generated at 2022-06-23 10:23:21.428061
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() is not None

# Generated at 2022-06-23 10:23:29.177085
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit: filters without urlencode
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert len(filters) == 1
    assert filters['urldecode'] == do_urldecode

    # Unit: filters with urlencode
    filters = FilterModule().filters()
    assert len(filters) == 2
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode

    # Unit: urldecode
    assert do_urldecode('%21') == '!'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%7E') == '~'

    # Unit: urlencode

# Generated at 2022-06-23 10:23:39.166440
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('key=value') == 'key%3Dvalue'
    assert do_urlencode('key=value&key2=value2') == 'key%3Dvalue%26key2%3Dvalue2'
    assert do_urlencode({'key': 'value', 'key2': 'value2'}) == 'key%3Dvalue%26key2%3Dvalue2'
    assert do_urlencode(['key=value', 'key2=value2']) == 'key%3Dvalue%26key2%3Dvalue2'
    assert do_urlencode(('key=value', 'key2=value2')) == 'key%3Dvalue%26key2%3Dvalue2'


# Generated at 2022-06-23 10:23:41.985576
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert 'urlencode' in filters
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:23:49.461692
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']("https%3A%2F%2Fexample.com%2Ftest+%23") == "https://example.com/test #"
    assert filters['urldecode']("https%3A%2F%2Fexample.com%2Ftest+%23") == "https://example.com/test #"

# Generated at 2022-06-23 10:23:55.187748
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('key1=value1&key2=value 2') == 'key1=value1&key2=value+2'
    assert do_urlencode('key1=value1&key2=value 2') == do_urlencode(dict(key1='value1', key2='value 2'))
    assert do_urlencode('key1=value1&key2=value 2') == do_urlencode(['key1=value1', 'key2=value 2'])

# Generated at 2022-06-23 10:23:58.451432
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    b = a.filters()
    assert b['urldecode'] is do_urldecode
    if not HAS_URLENCODE:
        assert b['urlencode'] is do_urlencode
    return True

# Generated at 2022-06-23 10:24:02.650855
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode']('%20') == u' '
    assert f.filters()['urldecode']('%2F') == u'/'



# Generated at 2022-06-23 10:24:11.923958
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import sys

    assert unicode_urlencode('abcd') == u'abcd'
    assert unicode_urlencode('abcd  ') == u'abcd%20%20'
    assert unicode_urlencode('abcd  ') == u'abcd%20%20'
    assert unicode_urlencode(u'☃') == u'%E2%98%83'
    assert unicode_urlencode(u'☃☃') == u'%E2%98%83%E2%98%83'
    assert unicode_urlencode(u'☃  ') == u'%E2%98%83%20%20'

    # Test the argument "for_qs"

# Generated at 2022-06-23 10:24:25.893054
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"") == u""
    assert unicode_urlencode(u"\u20ac") == u"%E2%82%AC"
    assert unicode_urlencode(u"a") == u"a"
    assert unicode_urlencode(u"a b") == u"a+b"
    assert unicode_urlencode(u"/") == u"/"
    assert unicode_urlencode(u"/", for_qs=True) == u"%2F"
    assert unicode_urlencode(u"/", for_qs=True) == u"%2F"
    assert unicode_urlencode(u"foo=bar") == u"foo=bar"

# Generated at 2022-06-23 10:24:28.791340
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%EA") == u"\u00ea", "unicode_urldecode failed"


# Generated at 2022-06-23 10:24:31.105466
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        filter_obj = FilterModule()
    except Exception as e:
        print("FilterModule exception:", e)

# Generated at 2022-06-23 10:24:38.450621
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'f:%C3%BC@oo') == (u'f:ü@oo')
    assert do_urldecode(r'f:%C3%BC@oo') == (r'f:%C3%BC@oo')
    assert do_urldecode(u'f:%c3%bc@oo') == (u'f:ü@oo')
    assert do_urldecode(u'f:%C3%Bc@oo') == (u'f:%C3%Bc@oo')


# Generated at 2022-06-23 10:24:50.528871
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == to_text('')
    assert unicode_urlencode(u' ') == to_text('%20')
    assert unicode_urlencode(u'/') == to_text('%2F')
    assert unicode_urlencode(u'?') == to_text('%3F')
    assert unicode_urlencode(u'&') == to_text('%26')
    assert unicode_urlencode(u'+') == to_text('%2B')
    assert unicode_urlencode(u'=') == to_text('%3D')
    assert unicode_urlencode(u'％') == to_text('%EF%BC%85')

# Generated at 2022-06-23 10:25:01.210923
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == u'hello world'
    assert unicode_urldecode('hello|world') == u'hello|world'
    assert unicode_urldecode('hello world') == u'hello world'
    assert unicode_urldecode('hello+world') == u'hello world'
    assert unicode_urldecode(u'hello+world') == u'hello world'
    assert unicode_urldecode('hello+p%C3%A9p%C3%A9') == u'hello pépé'
    assert unicode_urldecode(u'hello+p%C3%A9p%C3%A9') == u'hello pépé'


# Generated at 2022-06-23 10:25:09.894408
# Unit test for function do_urlencode
def test_do_urlencode():
    r = do_urlencode(u'abc')
    assert r == 'abc'
    r = do_urlencode(u'a+b c')
    assert r == 'a%2Bb+c'
    r = do_urlencode(['a', 'b', 'c'])
    assert r == 'a=b=c'
    r = do_urlencode({'a': 'b', 'c': 'd'})
    assert r == 'a=b&c=d'

# Generated at 2022-06-23 10:25:12.894642
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('hello%20world') == 'hello world'
    assert do_urldecode('hello+world') == 'hello world'


# Generated at 2022-06-23 10:25:14.882162
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:25:18.085694
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u"a+%C3%A9+%26+%2F+b" == unicode_urlencode(u"a é & / b")
    assert u"a%26b%3Dc" == unicode_urlencode({u'a': u'b=c'})


# Generated at 2022-06-23 10:25:24.053626
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"http://www.example.com/foo bar") == u"http://www.example.com/foo%20bar"
    assert do_urlencode(u"http://www.example.com/foo/bar/baz") == u"http://www.example.com/foo/bar/baz"
    assert do_urlencode(u"http://www.example.com/foo&<>bar#baz") == u"http://www.example.com/foo%26%3C%3Ebar%23baz"

# Generated at 2022-06-23 10:25:33.009567
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Verify we can unquote unicode strings containing special characters (\u00e9)
    assert unicode_urldecode(u'%C3%A9') == u'\xe9'
    assert unicode_urldecode(u'%C3%A9%20') == u'\xe9 '
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'\xe9 \xe9'
    assert unicode_urldecode(u'%E2%82%AC') == u'\u20ac'
    assert unicode_urldecode(u'%E2%82%AC%20') == u'\u20ac '

# Generated at 2022-06-23 10:25:37.707468
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'some/path') == u'some%2Fpath'
    assert do_urlencode(u'some@path') == u'some%40path'
    assert do_urlencode(u'some+path') == u'some%20path'



# Generated at 2022-06-23 10:25:38.286402
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:25:46.616949
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:25:52.721865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    jinja2_urlencode = pytest.importorskip("jinja2.filters")

    fm = FilterModule()
    assert hasattr(fm, "filters")
    f = fm.filters()
    assert type(f) is dict
    fkeys = f.keys()
    for k in ("urldecode", "urlencode"):
        assert k in fkeys
