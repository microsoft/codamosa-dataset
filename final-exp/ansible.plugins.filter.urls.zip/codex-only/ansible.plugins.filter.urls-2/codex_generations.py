

# Generated at 2022-06-23 10:15:58.868216
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' Test the do_urldecode function '''

    # basic encode-decode
    assert do_urldecode(do_urlencode(u"some string")) == u"some string"

    # dictionary
    assert do_urldecode(do_urlencode({u"key": u"value"})) == u"key=value"

    # lists
    assert do_urldecode(do_urlencode([u"key", u"value"])) == u"key=value"

    # lists of dictionaries
    assert do_urldecode(do_urlencode([{u"key": u"value"}, {u"key": u"value"}])) == u"key=value&key=value"

# Generated at 2022-06-23 10:16:03.021411
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_ = FilterModule()
    res = filter_.filters()
    assert res['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert res['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:16:04.373933
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:16:11.607925
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # dict() initializes a dict
    ansiblefilters = dict()
    ansiblefilters = FilterModule()
    # 'assertEqual(a, b)' verifies if a and b are equal
    print('Test 1: verify if the class FilterModule is imported successfully by checking if the dict is initialized')
    if isinstance(ansiblefilters, dict):
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-23 10:16:18.341574
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # simple test
    assert unicode_urldecode("Hello World") == "Hello World"
    # try a few special characters
    assert unicode_urldecode("%2B") == "+"
    assert unicode_urldecode("%2b") == "+"
    assert unicode_urldecode("%20") == " "
    assert unicode_urldecode("%27") == "'"
    assert unicode_urldecode("%28") == "("
    assert unicode_urldecode("%29") == ")"
    # try an encoding for a unicode character
    assert unicode_urldecode("Vi%C3%B0%C3%A1%C3%B0ur") == "Viðáður"
    # try a string uniformly encoded with quote_plus


# Generated at 2022-06-23 10:16:20.342003
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B1') == 'ñ'



# Generated at 2022-06-23 10:16:27.869851
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'
    assert do_urlencode(['a=b', 'b=c', 'c=d']) == 'a%3Db&b%3Dc&c%3Dd'
    assert do_urlencode({'a': 'b', 'b': 'c', 'c': 'd'}) == 'a=b&b=c&c=d'
    assert do_urlencode('a=b') == 'a%3Db'
    assert do_urlencode('a=') == 'a%3D'

# Generated at 2022-06-23 10:16:30.720947
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert isinstance(m.filters(), dict)

# Generated at 2022-06-23 10:16:38.625352
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'abcdefghij') == u'abcdefghij'
    assert do_urldecode(u'abcdefghij/') == u'abcdefghij/'
    assert do_urldecode(u'abcdefghij%2F') == u'abcdefghij/'
    assert do_urldecode(u'abcdefghij%2f') == u'abcdefghij/'
    assert do_urldecode(u'abcdefghij%2F/') == u'abcdefghij//'


# Generated at 2022-06-23 10:16:46.676189
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value1 = u'10.0.0.1'
    value2 = u'10.0.0.2'
    value3 = u'10.0.0.3'

    assert unicode_urlencode(value1) == u'10.0.0.1'
    assert unicode_urlencode(value1, for_qs=True) == u'10.0.0.1'

    assert unicode_urlencode([value1, value2]) == u'10.0.0.1%0A10.0.0.2'
    assert unicode_urlencode([value1, value2], for_qs=True) == u'10.0.0.1%0A10.0.0.2'


# Generated at 2022-06-23 10:16:56.978803
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('fo%2Fo') == u'fo/o'
    assert unicode_urldecode('fo%2Bo') == u'fo+o'
    assert unicode_urldecode('fo%20o') == u'fo o'
    assert unicode_urldecode('fo%27o') == u"fo'o"
    assert unicode_urldecode('fo%C3%A9') == u'foé'
    assert unicode_urldecode('fo%C3%A9%C3%A9') == u'foéé'

# Generated at 2022-06-23 10:17:02.130549
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('example%20example') == u'example example'
    assert do_urldecode('example+example') == u'example example'
    assert do_urldecode('example%2fexample') == u'example/example'


# Generated at 2022-06-23 10:17:10.999248
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode(u'abc def') == u'abc%20def'
    assert do_urlencode(u'abc/def') == u'abc%2Fdef'

    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode({u'foo': u'bar', u'foo1': u'bar1'}) == u'foo=bar&foo1=bar1'
    assert do_urlencode({u'foo': u'bar/bar'}) == u'foo=bar%2Fbar'
    assert do_urlencode({u'foo/foo': u'bar'}) == u'foo%2Ffoo=bar'
    assert do_urlencode

# Generated at 2022-06-23 10:17:17.208721
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'foo/bar' == unicode_urldecode('foo%2Fbar')
    assert u'foo/bar' == unicode_urldecode('foo/bar')
    assert u'foo/bar' == unicode_urldecode(b'foo%2Fbar')
    assert u'foo/bar' == unicode_urldecode(b'foo/bar')



# Generated at 2022-06-23 10:17:28.970998
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode('string') == 'string'
        assert unicode_urlencode('Foo Bar') == 'Foo%20Bar'
        assert unicode_urlencode('/') == '%2F'
        assert unicode_urlencode('/Foo Bar') == '%2FFoo%20Bar'
        assert unicode_urlencode('/Foo Bar/') == '%2FFoo%20Bar%2F'
        assert unicode_urlencode(';') == ';'
        assert unicode_urlencode(';Foo Bar') == ';Foo%20Bar'
        assert unicode_urlencode(';Foo Bar;') == ';Foo%20Bar;'

# Generated at 2022-06-23 10:17:38.889762
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode(u'hören & saͤgen') == u'h%C3%B6ren%20%26%20sa%C6%B4gen'
    assert unicode_urlencode(u'hören & saͤgen', for_qs=True) == u'h%C3%B6ren+%26+sa%C6%B4gen'
    assert unicode_urlencode(u'foo.bar') == u'foo.bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'

# Generated at 2022-06-23 10:17:46.045759
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # data = [
    #     {
    #         'name': 'FilterModule.filters()',
    #         'params': {},
    #         'assert': {},
    #     },
    # ]
    data = []
    for item in data:
        assert item['assert'] == FilterModule(item['params']).filters()[item['name']]

# Generated at 2022-06-23 10:17:51.847327
# Unit test for function do_urlencode
def test_do_urlencode():
    cases = [
        ('a1ę2ł3ó4', 'a1%C4%992%C5%823%C3%B64'),
        ({'a': 'a1', 'ę': '2ł'}, 'a=a1&%C4%99=2%C5%82'),
        ('test/test', 'test%2Ftest'),
    ]
    for case, expect in cases:
        assert unicode_urlencode(case) == expect

# Generated at 2022-06-23 10:18:02.021866
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'%3C') == u'<'
    assert do_urldecode(u'%3c') == u'<'
    assert do_urldecode(u'%2f') == u'/'
    assert do_urldecode(u'%2F') == u'/'
    assert do_urldecode(u'%3A') == u':'
    assert do_urldecode(u'%3a') == u':'
    assert do_urldecode(u'%2B') == u'+'
    assert do_urldecode(u'%2b') == u'+'
    assert do_urldecode(u'%40') == u'@'

# Generated at 2022-06-23 10:18:13.111517
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    d = unicode_urldecode("abc%20def")
    assert d == "abc def", "Return value of unicode_urldecode for %s is %s" % ("abc%20def", d)

    d = unicode_urldecode("abc+def")
    assert d == "abc+def", "Return value of unicode_urldecode for %s is %s" % ("abc+def", d)

    # Check that unicode is preserved
    d = unicode_urldecode(u"äbc+def")
    assert d == u"äbc+def", "Return value of unicode_urldecode for %s is %s" % (u"äbc+def", d)


# Generated at 2022-06-23 10:18:22.304302
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'test') == u'test')
    assert(unicode_urlencode(u'test/test') == u'test%2Ftest')
    assert(unicode_urlencode(u'test/test', True) == u'test%2Ftest')
    assert(unicode_urlencode(u'test test') == u'test+test')
    assert(unicode_urlencode(u'test test', True) == u'test+test')

if __name__ == '__main__':
    test_unicode_urlencode()

# Generated at 2022-06-23 10:18:31.228086
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode(u'foo') == 'foo'
    assert unicode_urldecode(b'foo') == 'foo'
    assert unicode_urldecode('Hello%2C+world%21') == 'Hello, world!'
    assert unicode_urldecode(u'Hello%2C+world%21') == 'Hello, world!'
    assert unicode_urldecode(b'Hello%2C+world%21') == 'Hello, world!'


# Generated at 2022-06-23 10:18:39.195041
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'a=b' == do_urlencode([('a', 'b')])
    assert 'a=b' == do_urlencode([('a', u'b')])
    assert 'a=b' == do_urlencode(('a', 'b'))
    assert 'a=b' == do_urlencode(('a', u'b'))
    assert 'a=b' == do_urlencode({'a': 'b'})
    assert 'a=b' == do_urlencode({'a': u'b'})
    assert 'a=b&c=d%2Fz' == do_urlencode([('a', 'b'), ('c', 'd/z')])

# Generated at 2022-06-23 10:18:43.908817
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    result = obj.filters()
    assert isinstance(result, dict)
    assert result.has_key('urldecode')
    assert result.has_key('urlencode') == False



# Generated at 2022-06-23 10:18:52.482554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['urldecode']('a%2Bb%2Bc') == 'a+b+c'
    assert filters['urldecode']('a+b+c') == 'a b c'

    if not HAS_URLENCODE:
        assert filters['urlencode']('a+b+c') == 'a%2Bb%2Bc'
        assert filters['urlencode']('a b c') == 'a+b+c'



# Generated at 2022-06-23 10:19:00.202652
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("a&%20b") == "a b"
    assert do_urldecode("a%%20b") == "a% b"
    assert do_urlencode("a b") == "a+b"
    assert do_urlencode("a% b") == "a%25+b"
    assert do_urlencode("a b") == "a+b"
    assert do_urlencode("a&%20b") == "a%26%2520b"



# Generated at 2022-06-23 10:19:04.868072
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("abc") == "abc"
    assert unicode_urldecode(u"abc") == "abc"
    assert unicode_urldecode("a%20b%20c%20d") == "a b c d"
    assert unicode_urldecode("a+b+c+d") == "a b c d"
    assert unicode_urldecode("a%2b+c%2Bd") == "a+ +c+d"


# Generated at 2022-06-23 10:19:06.085601
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()



# Generated at 2022-06-23 10:19:08.728801
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'



# Generated at 2022-06-23 10:19:14.569502
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Testing unicode_urldecode. '''
    # Here we only test Python3, because Python2's urllib
    # auto-decodes byte strings.
    assert unicode_urldecode('%7B%22a%22%3A+1%7D') == '{"a": 1}'

# Generated at 2022-06-23 10:19:22.458929
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode('/') == '/'
        assert unicode_urlencode('/', for_qs=True) == '%2F'
        assert unicode_urlencode('/ ') == '%2F%20'
        assert unicode_urlencode('/ ', for_qs=True) == '%2F%20'
        assert unicode_urlencode(u'a/b') == 'a%2Fb'
        assert unicode_urlencode(u'a/b', for_qs=True) == 'a%2Fb'
        assert unicode_urlencode('a/b') == 'a%2Fb'
        assert unicode_urlencode('a/b', for_qs=True) == 'a%2Fb'

# Generated at 2022-06-23 10:19:24.255209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:19:34.901677
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()["urldecode"](
        "https://www.google.com/webhp?sourceid%3Dchrome-instant%26ion%3D1%26espv%3D2%26ie%3DUTF-8%23q%3Dhttp%26es_sm%3D91") == \
        "https://www.google.com/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=http&es_sm=91"

# Generated at 2022-06-23 10:19:44.258366
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('café') == 'caf%C3%A9'
    assert unicode_urlencode('café', for_qs=True) == 'caf%C3%A9'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('?') == '%3F'
    assert unicode_urlencode('?', for_qs=True) == '%3F'
    assert unicode_urlencode('&') == '%26'
    assert unicode_urlencode('&', for_qs=True) == '%26'


# Generated at 2022-06-23 10:19:51.143777
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except ImportError:
        HAS_URLENCODE = False

    fm = FilterModule()
    filters = fm.filters()
    assert len(filters) == 1
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
    else:
        assert 'urlencode' not in filters


# Generated at 2022-06-23 10:19:53.343144
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unicode_urldecode('Hello%2C+World%21') == u'Hello, World!'


# Generated at 2022-06-23 10:19:55.349755
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('key=%2F%2Fvalue') == u'key=//value'
    assert do_urldecode('key=%2F%2Fvalue%2F%2F') == u'key=//value//'

# Generated at 2022-06-23 10:19:57.104274
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 10:20:00.488093
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert hasattr(filter_module, "filters")


# Generated at 2022-06-23 10:20:02.697142
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    assert filters is not None
    assert 'urldecode' in filters
    assert 'urlencode' in filters

# Generated at 2022-06-23 10:20:10.432235
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar', True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo bar', True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar', True) == u'foo%2Fbar'


# Generated at 2022-06-23 10:20:15.995838
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' test do_urldecode filter '''
    assert do_urldecode('http%3A%2F%2Fexample.com') == u'http://example.com'
    assert do_urldecode('hel%C3%B6') == u'helö'



# Generated at 2022-06-23 10:20:20.971059
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert do_urlencode("value") == 'value'
    assert unicode_urlencode("value") == 'value'
    item = {'key': 'value'}
    assert unicode_urlencode(item) == 'key=value'
    assert do_urldecode("value") == 'value'
    assert unicode_urldecode("value") == 'value'
    assert unicode_urldecode('%2D') == '-'

# Generated at 2022-06-23 10:20:24.096249
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    filters = mod.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters



# Generated at 2022-06-23 10:20:27.188987
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' unit test for function unicode_urlencode '''
    urlencoded = unicode_urlencode('/')
    assert to_text(urlencoded) == u'%2F'



# Generated at 2022-06-23 10:20:40.622373
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo', for_qs=True) == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode('foo + bar') == 'foo%20%2B%20bar'
    assert unicode_urlencode('foo + bar', for_qs=True) == 'foo+%2B+bar'



# Generated at 2022-06-23 10:20:47.935563
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    tests = {
        b'foo+bar': b'foo bar',
        b'foo%20bar': b'foo bar',
        b'foo%2520bar': b'foo%20bar',
        'foo+bar': u'foo bar',
        'foo%20bar': u'foo bar',
        'foo%2520bar': u'foo%20bar',
        u'foo+bar': u'foo bar',
        u'foo%20bar': u'foo bar',
        u'foo%2520bar': u'foo%20bar',
    }

    for input, output in iteritems(tests):
        assert unicode_urldecode(input) == output


# Generated at 2022-06-23 10:20:58.793579
# Unit test for function do_urlencode
def test_do_urlencode():
    if HAS_URLENCODE:
        return

    assert(do_urlencode(u'abcXYZ123') == u'abcXYZ123')
    assert(do_urlencode(u'abc[]XYZ') == u'abc%5B%5DXYZ')
    assert(do_urlencode(u'abc&XYZ') == u'abc%26XYZ')
    assert(do_urlencode(u'abc+XYZ') == u'abc%2BXYZ')
    assert(do_urlencode(u'abc XYZ') == u'abc+XYZ')
    assert(do_urlencode(u'abc/XYZ') == u'abc/XYZ')
    assert(do_urlencode(u'abc?XYZ') == u'abc%3FXYZ')

# Generated at 2022-06-23 10:21:06.271143
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'') == '', 'The empty string is not properly encoded'
    assert do_urlencode(u'abc') == 'abc', 'abc is not properly encoded'
    assert do_urlencode(u'foo bar') == 'foo%20bar', 'string with space is not properly encoded'
    assert do_urlencode(u'foo/bar') == 'foo%2Fbar', 'string with slash is not properly encoded'
    assert do_urlencode(dict(a=1, b=2)) == 'a=1&b=2', 'dict is not properly encoded'
    assert do_urlencode(['a=1', 'b=2']) == 'a%3D1&b%3D2', 'list is not properly encoded'


# Generated at 2022-06-23 10:21:12.767639
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('sudo dnf install ansible') == u'sudo%20dnf%20install%20ansible'
    assert unicode_urlencode('sudo dnf install ansible', True) == u'sudo+dnf+install+ansible'


# Generated at 2022-06-23 10:21:14.104786
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() is not None

# Generated at 2022-06-23 10:21:16.265910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+') == u'a '
    assert unicode_urldecode('a%2B') == u'a+'


# Generated at 2022-06-23 10:21:28.206635
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2f') == '/'
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4%2f') == u'ä/'
    assert unicode_urldecode(u'%C3%A4%E2%82%AC') == u'ä€'
    assert unicode_urldecode(u'%C3%A4%E2%82%AC%2f') == u'ä€/'
    assert unicode_urldecode(u'%C3%A4%E2%82%AC%2f') == u'ä€/'

# Generated at 2022-06-23 10:21:37.479623
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'a') == u'a'
    assert unicode_urlencode(u'a/b') == u'a%2Fb'
    assert unicode_urlencode(u'a/b', for_qs=True) == u'a%2Fb'
    assert unicode_urlencode(u'a b') == u'a+b'
    assert unicode_urlencode(u'a b', for_qs=True) == u'a+b'
    assert unicode_urlencode(u'a b c') == u'a+b+c'
    assert unicode_urlencode(u'a b c', for_qs=True) == u'a+b+c'
   

# Generated at 2022-06-23 10:21:44.490434
# Unit test for function unicode_urldecode

# Generated at 2022-06-23 10:21:52.362733
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    if sys.version_info[0] == 2:
        assert unicode_urldecode(u'foo%E2%9C%93') == u'foo\u2713'
        assert unicode_urldecode(u'foo%2B+') == u'foo+ +'
    else:
        assert unicode_urldecode(u'foo%E2%9C%93') == 'foo\u2713'
        assert unicode_urldecode(u'foo%2B+') == 'foo+ +'


# Generated at 2022-06-23 10:22:00.685867
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u"/") == b"%2F")
    assert(unicode_urlencode(u"/", for_qs=True) == b"%2F")
    assert(unicode_urlencode(u"/a") == b"/a")
    assert(unicode_urlencode(u"/a", for_qs=True) == b"/a")
    assert(unicode_urlencode(u"/a%2F") == b"/a%252F")
    assert(unicode_urlencode(u"/a%2F", for_qs=True) == b"%2Fa%252F")


# Generated at 2022-06-23 10:22:03.485011
# Unit test for function do_urldecode
def test_do_urldecode():
    assert unquote_plus("abc%20abc") == do_urldecode("abc%20abc")
    assert unquote_plus("abc+abc") == do_urldecode("abc+abc")
    assert unquote_plus("abc%7Eabc") == do_urldecode("abc%7Eabc")


# Generated at 2022-06-23 10:22:09.841292
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo bar/baz') == 'foo%20bar%2Fbaz'
    assert unicode_urlencode('foo bar/baz', for_qs=True) == 'foo+bar%2Fbaz'
    assert unicode_urlencode(u'foo bar/baz', for_qs=True) == 'foo+bar%2Fbaz'


# Generated at 2022-06-23 10:22:20.874642
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%20") == " ", "Failed to decode '%20' to whitespace"
    assert unicode_urldecode("%2B") == "+", "Failed to decode '%2B' to '+'"
    assert unquote_plus("%2B") == "+", "Failed to decode '%2B' to '+'"
    assert unquote_plus("%2B", ' ') == "+", "Failed to decode '%2B' to '+'"
    assert unquote_plus("%2B", '%') == "+", "Failed to decode '%2B' to '+'"
    # NOTE: When decoding for Query Strings, ' ' should be allowed
    assert unquote_plus("%20") == " ", "Failed to decode '%20' to whitespace"


# Generated at 2022-06-23 10:22:24.333023
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('%7E%3A%3D%3F%26%25') == u'~:=?&%'



# Generated at 2022-06-23 10:22:32.524831
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    ansible_module_X = basic.AnsibleModule(argument_spec=dict())
    ansible_module_X.ansible_module.params = dict(
        value=dict(
            hello='world',
            foo='bar baz',
            qux='hello world',
        ),
    )

    filters = FilterModule().filters()

    for k, v in dict(
        urldecode=dict(
            hello='world',
            foo='bar baz',
            qux='hello world',
        ),
        urlencode=dict(
            hello='hello=world',
            foo='foo=bar+baz',
            qux='qux=hello+world',
        ),
    ).items():
        for key, value in v.items():
            assert filters

# Generated at 2022-06-23 10:22:37.552698
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%24') == '$'
    assert do_urldecode('%25') == '%'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2b') == '+'


# Generated at 2022-06-23 10:22:46.521228
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Simply test that unicode_urldecode works in both Python 2 and Python 3
    '''


# Generated at 2022-06-23 10:22:57.195053
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == 'foo'
    assert do_urlencode(u'foo bar') == 'foo+bar'
    assert do_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert do_urlencode(u'foo%20bar') == 'foo%20bar'
    assert do_urlencode(u'foo#bar') == 'foo%23bar'
    assert do_urlencode(u'foo bar/#') == 'foo+bar%2F%23'
    assert do_urlencode(u'foo&bar/#') == 'foo%26bar%2F%23'
    assert do_urlencode(u'foo&bar/%23') == 'foo%26bar%2F%2523'

# Generated at 2022-06-23 10:23:09.531374
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'hello') == u'hello'
    assert unicode_urldecode(u'hello%20world') == u'hello world'
    assert unicode_urldecode(u'hello%40world') == u'hello@world'
    assert unicode_urldecode(u'hello+world') == u'hello world'
    assert unicode_urldecode(u'hello%2Bworld') == u'hello+world'
    assert unicode_urldecode(u'hello%2bworld') == u'hello+world'
    assert unicode_urldecode(u'hello%2fworld') == u'hello/world'

# Generated at 2022-06-23 10:23:16.681851
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from nose.tools import assert_equal
    assert_equal(unicode_urldecode('%2B'), '+')
    assert_equal(unicode_urldecode('%2b'), '+')
    assert_equal(unicode_urldecode('%2f'), '/')
    assert_equal(unicode_urldecode('%2F'), '/')
    assert_equal(unicode_urldecode('%61'), 'a')
    assert_equal(unicode_urldecode('%2a'), '*')
    assert_equal(unicode_urldecode('%25'), '%')


# Generated at 2022-06-23 10:23:23.367239
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    data = [
        ('abc', b'abc'),
        ('abc def', b'abc%20def'),
        ('abc def', b'abc+def', True),
        ('abc@def', b'abc%40def'),
        ('/abc/def', b'/abc/def', False, '/'),
        ('/abc/def', b'/abc/def', False, b'/'),
        ('/abc/def', b'%2Fabc%2Fdef', True),
        ('/abc/def', b'%2Fabc%2Fdef', True, b'/'),
    ]
    for value, expected, for_qs, safe in data:
        result = unicode_urlencode(value, for_qs=for_qs, safe=safe)
        assert result == expected


# Generated at 2022-06-23 10:23:29.779689
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foobar@example.com') == 'foobar%40example.com'
    assert do_urlencode('foo bar@example.com') == 'foo+bar%40example.com'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode(u'\xed') == '%C3%AD'
    assert do_urlencode(u'\xed') == '%C3%AD'
    assert do_urlen

# Generated at 2022-06-23 10:23:40.106133
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('søkeord') == 's%C3%B8keord'
    assert do_urlencode('s/z') == 's%2Fz'
    assert do_urlencode('s/z', for_qs=True) == 's%2Fz'
    assert do_urlencode({'one': 1, 'two': 2}) == 'two=2&one=1'
    assert do_urlencode({'two': '2', 'one': '1'}) == 'two=2&one=1'
    assert do_urlencode({'one': '1', 'two': '2'}) == 'one=1&two=2'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-23 10:23:44.246470
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2F') == u'http://'
    assert unicode_urldecode('http://') == u'http://'


# Generated at 2022-06-23 10:23:53.803760
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_string = u'ansible'
    assert unicode_urlencode(test_string) == u'ansible'

    test_string = u'ansible unicodé string'
    assert unicode_urlencode(test_string) == u'ansible+unicod%C3%A9+string'

    test_string = u'ansible/unicodé string'
    assert unicode_urlencode(test_string) == u'ansible%2Funicod%C3%A9+string'

    test_string = u'ansible unicodé string'
    assert unicode_urlencode(test_string, for_qs=True) == u'ansible%20unicod%C3%A9%20string'

# Generated at 2022-06-23 10:24:01.907007
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode("dag") == "dag"
    assert do_urldecode("dag+wieers") == "dag wieers"
    assert do_urldecode("dag%7Cwieers") == "dag|wieers"
    assert do_urldecode("dag%2Fwieers") == "dag/wieers"
    assert do_urldecode((1,)) == "%01"
    assert do_urldecode(["dag", "wieers"]) == "dag wieers"


# Generated at 2022-06-23 10:24:04.240705
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_test = FilterModule()
    assert filter_test != None


# Generated at 2022-06-23 10:24:09.171070
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert ('abc' == unicode_urldecode('abc')), \
        'unicode_urldecode returned %r instead of \'abc\'' % unicode_urldecode('abc')

    assert ('abc def' == unicode_urldecode('abc%20def')), \
        'unicode_urldecode returned %r instead of \'abc def\'' % unicode_urldecode('abc%20def')



# Generated at 2022-06-23 10:24:17.463858
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:24:18.869518
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm)

# Generated at 2022-06-23 10:24:21.050616
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

    # Test filters method
    assert fm.filters()


# Generated at 2022-06-23 10:24:32.803199
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test urlencode function with unicode strings '''
    try:
        text_type
    except NameError:
        text_type = unicode

    assert unicode_urlencode(text_type(u'% %')) == u'%25%20%25'
    assert unicode_urlencode(text_type(u'%%')) == u'%25%25'
    assert unicode_urlencode(text_type(u'~')) == '~'
    assert unicode_urlencode(text_type(u'%')) == u'%25'
    assert unicode_urlencode(text_type(u'<>')) == u'%3C%3E'

# Generated at 2022-06-23 10:24:35.194933
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%3D%3D') == '=='


# Generated at 2022-06-23 10:24:40.854424
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo=bar') == 'foo%3Dbar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'



# Generated at 2022-06-23 10:24:52.775407
# Unit test for function do_urlencode
def test_do_urlencode():
    def wrapped_assertEqual(foo, bar):
        assertEqual(foo, bar)

    # from test_urllib.py

# Generated at 2022-06-23 10:24:54.253817
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')

# Generated at 2022-06-23 10:25:00.793792
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    a_dict = {'bla': 1,
              'foo': 'bar'}
    assert(unicode_urlencode(a_dict) == u'bla=1&foo=bar')

    a_list = ['bla', 1, 'foo']
    assert(unicode_urlencode(a_list) == u'bla&1&foo')

    a_str = 'bla'
    assert(unicode_urlencode(a_str) == u'bla')

# Generated at 2022-06-23 10:25:12.772034
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a value') == u'a%20value'
    assert unicode_urlencode('a/value') == u'a/value'
    assert unicode_urlencode('a&value') == u'a%26value'
    assert unicode_urldecode('a%26value') == u'a&value'
    assert unicode_urlencode('a+value') == u'a%2Bvalue'
    assert unicode_urldecode('a%2Bvalue') == u'a+value'
    assert unicode_urlencode(u'ä value') == u'%C3%A4%20value'
    assert unicode_urldecode(u'%E2%82%AC%20value') == u'€ value'

    assert unicode_urlen

# Generated at 2022-06-23 10:25:16.091784
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode
    }


# Generated at 2022-06-23 10:25:25.640632
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils import template

    fm = FilterModule()
    filters = fm.filters()

    assert filters['urldecode']('http%3A%2F%2Fwww.ansible.com') == 'http://www.ansible.com'
    assert filters['urldecode']('http://www.ansible.com') == 'http://www.ansible.com'

    if not HAS_URLENCODE:
        assert filters['urlencode']('http://www.ansible.com') == 'http%3A%2F%2Fwww.ansible.com'



# Generated at 2022-06-23 10:25:26.061121
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:25:37.439472
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%21%2a%27') == '!*\''
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo=bar') == 'foo%3Dbar'
    assert do_urlencode('/') == '%2F'
    assert do_urlencode('') == ''
    assert do_urlencode(u'\u00f6') == '%C3%B6'

# Generated at 2022-06-23 10:25:42.516834
# Unit test for function do_urldecode
def test_do_urldecode():
    # Simple testcase
    assert do_urldecode('%20') == ' '

    # Sample case that was provided by the author of the function
    assert do_urldecode('%3Fq%3D%E3%83%A1%E3%83%A2%E3%83%AB%E3%83%A9') == '?q=メモラ'

# Generated at 2022-06-23 10:25:55.077996
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("this%20should%20be%20spaces") == "this should be spaces"
    assert unicode_urldecode("this%2Bshould%2Bbe%2Bpluses") == "this+should+be+pluses"
    assert unicode_urldecode("this%26should%26be%26ampersands") == "this&should&be&ampersands"
    assert unicode_urldecode("this%0D%0Ashould%0D%0Abe%0D%0Aline%0D%0Abreaks") == "this\r\nshould\r\nbe\r\nline\r\nbreaks"