

# Generated at 2022-06-23 10:15:55.533526
# Unit test for function do_urlencode
def test_do_urlencode():
    try:
        import jinja2
    except ImportError:
        return

    env = jinja2.Environment()
    try:
        env.filters['urlencode']
    except KeyError:
        env.filters['urlencode'] = do_urlencode

    assert u'name=foo&bar=baz%20ding' == env.from_string("{{ {'name':'foo', 'bar':'baz ding'} | urlencode }}").render()
    assert u'%2Fetc%2Fpasswd' == env.from_string("{{ '/etc/passwd' | urlencode }}").render()

# Generated at 2022-06-23 10:16:05.970498
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode']('a%2Bb') == 'a+b'
    assert filters['urlencode']('a b') == 'a+b'
    assert filters['urlencode']('a+b') == 'a%2Bb'
    assert filters['urlencode']('a/b') == 'a%2Fb'
    assert filters['urlencode']('/a/b') == '%2Fa%2Fb'
    assert filters['urlencode']({'a': 'A', 'b': 'B'}) == 'a=A&b=B'
    assert filters['urlencode'](['a=A', 'b=B']) == 'a=A&b=B'

# Generated at 2022-06-23 10:16:08.616600
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'urlencode' in FilterModule().filters()
    assert 'urldecode' in FilterModule().filters()

# Generated at 2022-06-23 10:16:16.788225
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"") == u""
    assert unicode_urlencode(u"foo bar") == u"foo+bar"
    assert unicode_urlencode(u"foo+bar") == u"foo%2Bbar"
    assert unicode_urlencode(u"foo@bar") == u"foo%40bar"
    assert unicode_urlencode(u"foo&bar") == u"foo%26bar"
    assert unicode_urlencode(u"foo=bar") == u"foo%3Dbar"
    assert unicode_urlencode(u"foo bar", for_qs=True) == u"foo+bar"
    assert unicode_urlencode(u"foo+bar", for_qs=True) == u"foo%2Bbar"
    assert unicode

# Generated at 2022-06-23 10:16:22.373077
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(HAS_URLENCODE)
    obj = FilterModule()
    filters = obj.filters()
    assert(type(filters) is dict)
    assert(len(filters) == 2)
    assert(filters['urldecode'] == do_urldecode)
    assert(filters['urlencode'] == do_urlencode)


# Generated at 2022-06-23 10:16:30.502471
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('a') == 'a'
    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode('a&b') == 'a%26b'
    assert do_urlencode('a=b') == 'a%3Db'
    assert do_urlencode('a/b') == 'a%2Fb'
    assert do_urlencode({'c': 'd'}) == 'c=d'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'

# Generated at 2022-06-23 10:16:33.633795
# Unit test for function do_urldecode
def test_do_urldecode():
    '''
    Unit : test_do_urldecode
    '''
    assert do_urldecode('This%20is%20just%20a%20test%21') == 'This is just a test!'

# Generated at 2022-06-23 10:16:37.496221
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()["urldecode"] == do_urldecode
    assert fm.filters()["urlencode"] == do_urlencode

# Generated at 2022-06-23 10:16:47.667529
# Unit test for function do_urlencode
def test_do_urlencode():
    '''
    url encoding tests

    This tests the url encoding function do_urlencode.

    It tests a selection of values and checks the expected
    results are generated.
    '''

    # Tests to perform

# Generated at 2022-06-23 10:16:51.075264
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode('a%2Bb') == 'a+b'


# Generated at 2022-06-23 10:16:55.040983
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20') == u' '
    assert do_urldecode(u'%20') == u' '
    assert do_urldecode(b'%20') == u' '
    assert do_urldecode(b'%21') == u'!'


# Generated at 2022-06-23 10:16:55.913263
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return


# Generated at 2022-06-23 10:17:01.026374
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] is do_urldecode
    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode'] is do_urlencode

# Generated at 2022-06-23 10:17:10.519865
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == 'foo'
    assert do_urlencode(u'foo/bar') == 'foo%2Fbar'
    assert do_urlencode(u'foo/bar baz') == 'foo%2Fbar+baz'
    assert do_urlencode(u'this is a test') == 'this+is+a+test'
    assert do_urlencode(u'this is a test for a query string') == 'this+is+a+test+for+a+query+string'
    assert do_urlencode({u'foo': u'bar', u'baz': u'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode([u'foo', u'bar', u'baz', u'qux'])

# Generated at 2022-06-23 10:17:14.166147
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%BC') == u'ü'
    assert unicode_urldecode(u'%c3%bc') == u'ü'


# Generated at 2022-06-23 10:17:22.117294
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # all tests below require Jinja2 version 2.7 or above
    object = FilterModule()
    assert object.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        # code path only triggered when Jinja2 is older than v2.7
        assert object.filters()['urlencode'] == do_urlencode
    else:
        assert object.filters()['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:17:24.007939
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('hello world') == 'hello world'

# Generated at 2022-06-23 10:17:30.351620
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    fm = FilterModule()

    assert fm.filters()['urldecode']('foo') == 'foo'
    assert '%20' not in fm.filters()['urldecode']('foo%20bar')
    assert fm.filters()['urldecode']('foo+bar') == 'foo+bar'

    if not HAS_URLENCODE:
        assert ' ' not in fm.filters()['urlencode']('foo bar')
        assert '+' in fm.filters()['urlencode']('foo+bar')
        assert '%' in fm.filters()['urlencode']('foo%bar')

# Generated at 2022-06-23 10:17:39.573456
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%3C%3E%23%25%22%26%7B%7D%7C%5E%5B%5D%60') == u'<>#%&{}|^[]`'
    assert do_urldecode('%21%24%26%27%28%29%2A%2B%2C%3B%3D%3F%40%5C%5D') == u'!$&\'()*+,;=?@\\]', do_urldecode('%21%24%26%27%28%29%2A%2B%2C%3B%3D%3F%40%5C%5D')

# Generated at 2022-06-23 10:17:51.296655
# Unit test for function do_urldecode
def test_do_urldecode():
    cases = {
        "%3Cbr%3E%0A%3Cbr%3E%0A": "<br>\n<br>\n",
        "%3Cp%3EHello+World%21%3C%2Fp%3E": "<p>Hello World!</p>",
        "a%2Bb%2Bc": "a+b+c",
        "a%2Bb%2Bc%3D1%26d%3D2": "a+b+c=1&d=2",
        }
    for k, v in iteritems(cases):
        result = do_urldecode(k)
        assert result == v, "'%s' -> '%s' (expected '%s')" % (k, result, v)



# Generated at 2022-06-23 10:17:53.338494
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo+bar%20baz') == u'foo bar baz'

# Generated at 2022-06-23 10:17:59.841465
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/fran%C3%A7ais') == u'http%3A//example.com/fran%C3%A7ais'
    assert unicode_urlencode(u'http://example.com/fran%C3%A7ais', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffran%25C3%25A7ais'

# Generated at 2022-06-23 10:18:08.786443
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six import u
    assert unicode_urlencode(u("parameter 1")) == "parameter%201"
    assert unicode_urlencode(u("parameter 1"), for_qs=True) == "parameter%201"
    assert unicode_urlencode("parameter 1") == "parameter%201"
    assert unicode_urlencode("parameter 1", for_qs=True) == "parameter%201"
    assert unicode_urlencode(u("parameter/1")) == "parameter%2F1"
    assert unicode_urlencode(u("parameter/1"), for_qs=True) == "parameter%2F1"
    assert unicode_urlencode("parameter/1") == "parameter%2F1"
    assert unicode

# Generated at 2022-06-23 10:18:12.891607
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode']('a%20b%20c') == 'a b c'
    assert filter_module.filters()['urldecode']('a%2Bb%2Bc') == 'a+b+c'

# Generated at 2022-06-23 10:18:17.646077
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9'.encode('utf-8')) == u'é'


# Generated at 2022-06-23 10:18:27.012519
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"http://example.com/") == u'http%3A//example.com/'
    assert unicode_urlencode(u"http://example.com/?a=1") == u'http%3A//example.com/?a%3D1'
    # FIXME: This fails on Python 2.6, 2.7 and 3.2
    #assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/?a%3D1&b%3D2'

# Generated at 2022-06-23 10:18:37.730520
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # Initializing test data
    jinja_url_data = [{'value': u'hello/world'}, {'value': u'hello world'}]
    jinja_qs_data = [{'value': u'hello world'}]

    # Initializing for loop for function unicode_urlencode
    for jinja_url in jinja_url_data:
        for jinja_qs in jinja_qs_data:
            # Urlencode the string
            result = unicode_urlencode(jinja_url.get('value'), jinja_qs.get('value'))

            # Compare with assert
            assert result == "hello/world" or "hello%20world"

# Generated at 2022-06-23 10:18:40.709834
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fn = FilterModule()
    result = fn.filters()
    assert result['urlencode']  # urlencode filter is present
    assert result['urldecode']  # urldecode filter is present



# Generated at 2022-06-23 10:18:43.113716
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('a%40b%20c%2Bd') == 'a@b c+d'


# Generated at 2022-06-23 10:18:52.764724
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('') == u''
    assert unicode_urldecode('%3D%3D') == u'=='
    assert unicode_urldecode('%3D%3D') == u'=='
    assert unicode_urldecode('%26%23x27%3B') == u"'#x27;"
    assert unicode_urldecode('%26%26%23x27%3B%3B') == u"'#x27;;"
    assert unicode_urldecode('%26%26%23x27%3B%3B') == u"'#x27;;"



# Generated at 2022-06-23 10:19:02.828791
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import pytest


# Generated at 2022-06-23 10:19:06.586189
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://www.example.com?x=1 y') == u'http%3A//www.example.com%3Fx%3D1+y'

# Generated at 2022-06-23 10:19:13.319474
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']("%2Fhello%2Fworld") == u"/hello/world"
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']("/hello/world") == u"%2Fhello%2Fworld"

    assert FilterModule().filters()['urlencode']({"a": u"b"}) == u"a=b"
    assert FilterModule().filters()['urlencode']({"a": u"b", "c": u"d"}) == u"a=b&c=d"

# Generated at 2022-06-23 10:19:15.438120
# Unit test for function do_urldecode
def test_do_urldecode():
    assert(do_urldecode('http%3A%2F%2Fexample.com%3Fa%3D1') == 'http://example.com?a=1')


# Generated at 2022-06-23 10:19:21.160751
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%20%21&%2B%3D%23%3F') == ' !&+=%23?'
    assert do_urldecode({'name': 'value'}) == 'name=value'
    assert do_urldecode(['name', 'value']) == 'name=value'


# Generated at 2022-06-23 10:19:21.771704
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:19:33.195922
# Unit test for function do_urlencode
def test_do_urlencode():
    """do_urlencode: test urlencoding"""
    result = do_urlencode('/host=localhost#comment')
    assert result == '/host%3Dlocalhost%23comment', 'URL encoding failed with default param'

    result = do_urlencode('/host=localhost#comment', for_qs=True)
    assert result == '/host%3Dlocalhost%23comment', 'URL encoding failed with for_qs=True'

    result = do_urlencode({"key1": "value1", "key2": "value2"})
    assert result == 'key1=value1&key2=value2', 'URL encoding failed with dict param'

    result = do_urlencode(["value1", "value2"])
    assert result == 'value1&value2', 'URL encoding failed with list param'


# Generated at 2022-06-23 10:19:42.016617
# Unit test for function do_urlencode
def test_do_urlencode():
    if HAS_URLENCODE:
        def _test_do_urlencode():
            pass
    else:
        def _test_do_urlencode():
            test = u'\u041b\u0430\u043b\u0430\u0448\u043a\u0438\u043d'
            result = u'%D0%9B%D0%B0%D0%BB%D0%B0%D1%88%D0%BA%D0%B8%D0%BD'
            assert result == do_urlencode(test)

    _test_do_urlencode()

# Generated at 2022-06-23 10:19:48.783541
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('ABC') == u'ABC'
    assert unicode_urldecode('ABC%20DEF') == u'ABC DEF'
    assert unicode_urldecode(u'ABC%20DEF') == u'ABC DEF'
    assert unicode_urldecode(u'ABC\u7c21 DEF') == u'ABC\u7c21 DEF'
    assert unicode_urldecode('ABC+DEF') == u'ABC DEF'
    assert unicode_urldecode(u'ABC+DEF') == u'ABC DEF'
    assert unicode_urldecode(b'ABC+DEF') == u'ABC DEF'


# Generated at 2022-06-23 10:19:50.123124
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

    assert f.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-23 10:19:52.457305
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(42) == u'42'

# Generated at 2022-06-23 10:19:52.995939
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass

# Generated at 2022-06-23 10:19:56.020277
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert f.filters()['urlencode'] == do_urlencode



# Generated at 2022-06-23 10:20:05.435849
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    """
    test_unicode_urldecode is a unit test for function unicode_urldecode
    """
    def _unittest_unicode_urldecode(string, expected):
        actual = unicode_urldecode(string)
        assert actual == expected

    strings = ('%2Fbar%2Fbaz', '%2Ffoo%2Fbar%2Fbaz', '%2Ffoo%2Fbar%2Fbaz%2F', '%2Ffoo%2Fbar%2Fbaz%2Fbax')
    expected = ('/bar/baz', '/foo/bar/baz', '/foo/bar/baz/', '/foo/bar/baz/bax')
    for (string, expected) in zip(strings, expected):
        _unittest_unic

# Generated at 2022-06-23 10:20:16.780044
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode({'a': 'b'}) == 'a=b'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert unicode_urlencode([('a', 'b'), ('c', 'd')]) == 'a=b&c=d'
    assert unicode_urlencode(('a', 'b', 'c', 'd')) == 'a=b&c=d'
    assert unicode_urlencode(('a', 'b', 'c', 'd'), True) == 'a=b&c=d'
    assert unicode_urlencode('foo bar baz', True) == 'foo+bar+baz'

# Generated at 2022-06-23 10:20:21.135045
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%F0%9F%98%8A%F0%9F%98%8D%F0%9F%98%8A%F0%9F%98%8D'
    assert unicode_urldecode(string) == u'\U0001F60A\U0001F60D\U0001F60A\U0001F60D'



# Generated at 2022-06-23 10:20:26.627955
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/&=') == '/%26%3D'
    assert do_urlencode({'A':'B C', 'D':'E F'}) == 'A=B+C&D=E+F'
    assert do_urlencode(['A', 'B+C']) == 'A&B%2BC'



# Generated at 2022-06-23 10:20:34.569715
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'+') == u'%2B'
    assert unicode_urlencode(u'+', for_qs=True) == u'%2B'
    assert unicode_urlencode(u'A+') == u'A%2B'
    assert unicode_urlencode(u'A+', for_qs=True) == u'A%2B'
    assert unicode_urlencode(u'A+B') == u'A%2BB'
    assert unicode_urlencode(u'A+B', for_qs=True) == u'A%2BB'
    assert unicode_urlencode(u'A B') == u'A%20B'
    assert unicode_urlencode(u'A B', for_qs=True) == u

# Generated at 2022-06-23 10:20:40.119601
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a') == 'a'
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('a b') == unicode_urlencode(u'a b')
    assert unicode_urlencode('/with space') == '%2Fwith%20space'
    assert unicode_urlencode('/with space', for_qs=True) == '%2Fwith+space'
    assert unicode_urlencode('http://server/path') == 'http%3A%2F%2Fserver%2Fpath'
    assert unicode_urlencode({'a': [1, 2]}) == 'a=1&a=2'
    assert unicode_urlencode({'a': 1}) == 'a=1'


# Generated at 2022-06-23 10:20:46.215976
# Unit test for function do_urldecode
def test_do_urldecode():
    ''' urldecode should return url decoded string '''
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%25bar') == 'foo%bar'
    assert do_urldecode('%F6') == u"ö"
    assert do_urldecode('%F6%E9') == u"öé"
    assert do_urldecode('%F6%E9%F6%E9') == u"öéöé"
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%26%26') == '&&'


# Generated at 2022-06-23 10:20:57.730148
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    fm = FilterModule()

    # test urldecode
    assert fm.filters()['urldecode']('a%2Fb%2Bc') == 'a/b+c'
    assert fm.filters()['urldecode'](['a%2Fb%2Bc', 'd%3De%26f']) == ['a/b+c', 'd=e&f']
    assert fm.filters()['urldecode']({'a': 'b', 'c': 'd%3Ee'}) == {'a': 'b', 'c': 'd>e'}

    # test urlencode
    assert fm.filters()['urlencode']('a/b+c') == 'a%2Fb%2Bc'

# Generated at 2022-06-23 10:20:59.388991
# Unit test for constructor of class FilterModule
def test_FilterModule():
    my_FilterModule = FilterModule()
    assert isinstance(my_FilterModule, object)


# Generated at 2022-06-23 10:21:10.076090
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode([('foo', 'bar')]) == 'foo=bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode([{'foo': 'bar'}, {'baz': 'bat'}]) == 'foo=bar&baz=bat'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode(['foo', 'bar/bat']) == 'foo&bar%2Fbat'
    assert do_urlencode({'foo': ['bar', 'bat/baz']}) == 'foo=bar&foo=bat%2Fbaz'

# Generated at 2022-06-23 10:21:14.061763
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'let%27s+go') == u"let's go"
    assert do_urldecode(b'let%27s+go') == u"let's go"



# Generated at 2022-06-23 10:21:18.217616
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'foo') == u'foo'
    assert do_urldecode(u'foo+bar+baz') == u'foo bar baz'
    assert do_urldecode(u'foo+bar%20baz') == u'foo bar baz'
    assert do_urldecode(u'%20') == u' '


# Generated at 2022-06-23 10:21:27.395275
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc+') == u'abc '
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%2B') == u'+'
    if PY3:
        assert unicode_urldecode('abc%2B') == u'abc+'


# Generated at 2022-06-23 10:21:33.244811
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert unicode_urlencode(b"a+b") == u"a+b"
        assert unicode_urlencode("a+b") == u"a%2Bb"
        assert unicode_urlencode("foo") == u"foo"
        assert unicode_urlencode("foo ") == u"foo+"
        assert unicode_urlencode(" foo") == u"+foo"
        assert unicode_urlencode(" foo ") == u"+foo+"
    else:
        assert unicode_urlencode("a+b") == u"a%2Bb"
        assert unicode_urlencode("foo") == u"foo"
        assert unicode_urlencode("foo ") == u"foo+"
        assert unicode_urlencode

# Generated at 2022-06-23 10:21:35.865227
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 10:21:44.064297
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:21:47.567063
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters().get('urldecode') is not None
    assert FilterModule().filters().get('urlencode') is not None

# Generated at 2022-06-23 10:22:00.120705
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode("a b") == 'a%20b'
        assert unicode_urlencode("a b", for_qs=True) == 'a+b'
        assert unicode_urlencode("a+b", for_qs=True) == 'a%2Bb'
        assert unicode_urlencode({'a': 'b'}) == 'a=b'
        assert unicode_urlencode({'a b': 'c d'}, for_qs=True) == 'a+b=c+d'
        assert unicode_urlencode(['a b', 'c d']) == 'a%20b&c%20d'

# Generated at 2022-06-23 10:22:03.593950
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(1) == u'1'
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode({'k1': 1, 'k2': 2}) == u'k1=1&k2=2'
    assert do_urlencode([1, 2, 3]) == u'1&2&3'

# Generated at 2022-06-23 10:22:15.131063
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    if PY3:
        assert f.filters()['urldecode']('2018%2F12%2F11+%E6%99%82%E3%80%82%E9%9B%BB%E5%AD%90%E6%99%82%E5%80%99+07%3A55') == '2018/12/11 時。電子時候 07:55'

# Generated at 2022-06-23 10:22:22.475252
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo/bar@example.com') == 'foo%2Fbar%40example.com'
    assert do_urlencode(['foo/bar@example.com']) == '0=foo%2Fbar%40example.com'
    assert do_urlencode({'foo/bar@example.com': 'bar/foo@example.com'}) == 'foo%2Fbar%40example.com=bar%2Ffoo%40example.com'



# Generated at 2022-06-23 10:22:25.505677
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo bar') == 'foo+%2B+bar'
    assert unicode_urlencode(u'foo bar') == 'foo+%2B+bar'


# Generated at 2022-06-23 10:22:33.193137
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%2Bdef') == u'abc+def'
    assert unicode_urldecode('abc+def') == u'abc+def'
    assert unicode_urldecode('abc def') == u'abc def'
    assert unicode_urldecode('abc+def') == u'abc+def'

# Generated at 2022-06-23 10:22:41.507619
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == u'string'
    assert do_urlencode(u'string') == u'string'
    assert do_urlencode({}) == u''
    assert do_urlencode([]) == u''
    assert do_urlencode(None) == None
    assert do_urlencode({'key': 'value'}) == u'key=value'
    assert do_urlencode(['key1=value1', 'key2=value2']) == u'key1=value1&key2=value2'

# Generated at 2022-06-23 10:22:50.300268
# Unit test for function do_urldecode
def test_do_urldecode():
    # Test regular string
    assert do_urldecode('foo bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    # Test unicode
    assert do_urldecode(to_text('foo bar')) == 'foo bar'
    assert do_urldecode(to_text('foo%20bar')) == 'foo bar'

# Unit  test for function do_urlencode

# Generated at 2022-06-23 10:22:57.457252
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
 
    assert do_urlencode("http://example.com/foo?abc=def") == "http%3A%2F%2Fexample.com%2Ffoo%3Fabc%3Ddef"
    assert do_urldecode("http%3A%2F%2Fexample.com%2Ffoo%3Fabc%3Ddef") == "http://example.com/foo?abc=def"

if __name__ == '__main__':
    # Run tests when file is called directly
    test_FilterModule_filters()

# Generated at 2022-06-23 10:23:02.080635
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('foo+bar') == "foo bar"
    assert fm.filters()['urlencode']('foo bar') == "foo+bar"

# Generated at 2022-06-23 10:23:08.180180
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    filterModule.filters()
    filterModule.filters
    filterModule.filters.get
    filterModule.filters.get('urldecode')
    filterModule.filters.get('urldecode')('hello')
    filterModule.filters.get('urlencode')
    filterModule.filters.get('urlencode')('hello')

# Generated at 2022-06-23 10:23:14.606282
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Check both jinja2 filters individually
    assert do_urldecode('%7E') == '~'
    assert do_urlencode('~') == '~'

    # Check combined filters class
    fm = FilterModule()
    assert fm.filters()['urldecode']('%7E') == '~'
    assert fm.filters()['urlencode']('~') == '~'

# Generated at 2022-06-23 10:23:20.680657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    res = fm.filters().get('urldecode', None)
    assert res is not None

    res = fm.filters().get('urlencode', None)
    if not HAS_URLENCODE:
        assert res is not None
    else:
        assert res is None



# Generated at 2022-06-23 10:23:28.594965
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/', True) == u'%2F'
    assert unicode_urlencode('/a') == u'/a'
    assert unicode_urlencode('/a', True) == u'%2Fa'
    assert unicode_urlencode('a') == u'a'
    assert unicode_urlencode('a', True) == u'a'
    assert unicode_urlencode('a b') == u'a%20b'
    assert unicode_urlencode('a b', True) == u'a+b'
    assert unicode_urlencode('a+b') == u'a%2Bb'

# Generated at 2022-06-23 10:23:32.353461
# Unit test for function do_urldecode
def test_do_urldecode():
    # do_urldecode
    assert do_urldecode('%2Fusr%2Flocal%2Fbin') == u'/usr/local/bin'



# Generated at 2022-06-23 10:23:38.098712
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == 'test'
    assert do_urlencode('/test') == '%2Ftest'
    assert do_urlencode('é') == '%C3%A9'
    assert do_urlencode({'test': 'value'}) == 'test=value'
    assert do_urlencode({'test': [123, 456]}) == 'test=123&test=456'



# Generated at 2022-06-23 10:23:39.359406
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test.filters() != None

# Generated at 2022-06-23 10:23:43.157837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-23 10:23:48.613201
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("foo") == "foo"
    assert unicode_urldecode("foo+bar") == "foo bar"
    assert unicode_urldecode("foo+") == "foo "
    assert unicode_urldecode("+bar") == " bar"



# Generated at 2022-06-23 10:23:59.382030
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo%20bar') == 'foo%2520bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode({'x': 'foo', 'y': 'bar'}) == 'x=foo&y=bar'
    assert do_urlencode({'x': 'foo bar', 'y': 'foo+bar'}) == 'x=foo+bar&y=foo%2Bbar'


# Generated at 2022-06-23 10:24:03.423595
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('%E4%BA%BA%E6%B0%91%E6%B3%95') == u'人民法'


# Unit test(s) for function do_urlencode

# Generated at 2022-06-23 10:24:12.284079
# Unit test for function do_urlencode
def test_do_urlencode():
    # simple data
    data = 'test'
    result = do_urlencode(data)
    assert result == 'test'

    # unicode data
    data = u'test\xa9'
    result = do_urlencode(data)
    assert result == u'test%C2%A9'

    # list data
    data = ['test1', 'test2']
    result = do_urlencode(data)
    assert result == 'test1&test2'

    # dict data
    data = {'key': 'value'}
    result = do_urlencode(data)
    assert result == 'key=value'

# Generated at 2022-06-23 10:24:15.949939
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo%40bar') == 'foo@bar'


# Generated at 2022-06-23 10:24:20.238355
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:24:30.255430
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Test class FilterModule filters '''

    from ansible.module_utils.jinja2.filters import FilterModule
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus, quote_plus

    filter_module = FilterModule()
    filters = filter_module.filters()

    result = filters['urldecode'](quote_plus('äøüÿ'))
    assert (result == unquote_plus('äøüÿ'))
    result = filters['urldecode'](quote_plus('äøüÿ'))
    assert (result == unquote_plus('äøüÿ'))

# Generated at 2022-06-23 10:24:34.213342
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-23 10:24:39.516518
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    ret = fm.filters()
    assert 'urldecode' in ret.keys()
    assert ret['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in ret.keys()
        assert ret['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:24:51.328797
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode() == ''
    assert do_urlencode(10) == '10'
    assert do_urlencode('hello world') == 'hello+world'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode([('a', 'b'), ('c', 'd')]) == 'a=b&c=d'
    assert do_urlencode({'a': ('b', 'c')}) == 'a=b&a=c'
    assert do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'

# Generated at 2022-06-23 10:25:01.773083
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    assert do_urldecode('str%20ing') == 'str ing'
    if not HAS_URLENCODE:
        assert do_urlencode(
            {'spam': 'eggs', 'foo': 'bar'}) == '&'.join(['foo=%s' % x for x in ('bar', 'spam=%s' % 'eggs')])
        assert do_urlencode('str ing') == 'str+ing'
        assert do_urlencode('str/ing') == 'str%2Fing'
    assert callable(filters['urldecode'])
    if not HAS_URLENCODE:
        assert callable(filters['urlencode'])

# Generated at 2022-06-23 10:25:04.703309
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'hello') == u'hello'
    assert unicode_urlencode(u'hello/world') == u'hello%2Fworld'
    assert unicode_urlencode(u'hello?world') == u'hello%3Fworld'

# Generated at 2022-06-23 10:25:14.590132
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc def', for_qs=True) == 'abc+def'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}, for_qs=True) == 'a=b&c=d'
    assert unicode_urlencode(['a', 'b', {'c': 'd'}]) == 'a&b&c=d'

# Generated at 2022-06-23 10:25:16.538055
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    assert filters['urldecode']


# Test urldecode

# Generated at 2022-06-23 10:25:19.348455
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'~/élève.txt') == u'%7E/%C3%A9l%C3%A8ve.txt'


# Generated at 2022-06-23 10:25:27.593313
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("alphanumeric") == "alphanumeric"
    assert do_urlencode("+") == "%2B"
    assert do_urlencode(" ") == "%20"
    assert do_urlencode("/") == "%2F"
    assert do_urlencode("?") == "%3F"
    assert do_urlencode("&") == "%26"
    assert do_urlencode("=") == "%3D"

# Generated at 2022-06-23 10:25:38.198092
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'/path') == u'/path'
    assert unicode_urlencode(u'a,b') == u'a%2Cb'
    assert unicode_urlencode(u'a,b', for_qs=True) == u'a%2Cb'
    assert unicode_urlencode(u'a&b') == u'a%26b'
    assert unicode_urlencode(u'a&b', for_qs=True) == u'a%26b'
    assert unicode_urlencode(u'a?b') == u'a%3Fb'
    assert unicode_urlencode(u'a?b', for_qs=True) == u'a%3Fb'


# Generated at 2022-06-23 10:25:42.128617
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # The constructor of class FilterModule does not have parameters
    fm = FilterModule()
    # Verify the return of filters()
    f = fm.filters()
    assert 'urldecode' in f
    if not HAS_URLENCODE:
        assert 'urlencode' in f


# Generated at 2022-06-23 10:25:54.799694
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%3a') == u':'
    assert unicode_urldecode('%2A') == u'*'
    assert unicode_urldecode('%2a') == u'*'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%3f') == u'?'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urld