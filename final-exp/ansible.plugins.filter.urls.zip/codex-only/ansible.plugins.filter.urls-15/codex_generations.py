

# Generated at 2022-06-23 10:16:00.900528
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test for string_types case
    assert unicode_urlencode("Hello World") == "Hello%20World"
    assert unicode_urlencode("Hello World", True) == "Hello+World"

    # Test for iterable case
    assert unicode_urlencode(["Hello World", "Hello Universe"]) == "Hello%20World&Hello%20Universe"
    assert unicode_urlencode(["Hello World", "Hello Universe"], True) == "Hello+World&Hello+Universe"

    # Test for iterable case with dicts
    assert unicode_urlencode({'Hello': 'World'}) == "Hello=World"
    assert unicode_urlencode({'Hello': 'World'}, True) == "Hello=World"


# Generated at 2022-06-23 10:16:12.900146
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule().filters()

    urlencode = filters['urlencode']

    assert urlencode(u'abc') == u'abc'
    assert urlencode(u'abc"def') == u'abc%22def'
    assert urlencode({'abc': u'def'}) == u'abc=def'
    assert urlencode({'abc': u'def', 'ghi': u'jkl'}) == u'abc=def&ghi=jkl'
    assert urlencode([(u'abc', u'def'), (u'ghi', u'jkl')]) == u'abc=def&ghi=jkl'

    urldecode = filters['urldecode']

    assert urldecode(u'abc') == u'abc'

# Generated at 2022-06-23 10:16:17.854628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2520') == u'%20'


if __name__ == '__main__':
    test_unicode_urldecode()

# Generated at 2022-06-23 10:16:27.871037
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('/') == '%2F'
    assert do_urlencode('&') == '%26'
    assert do_urlencode('a&b') == 'a%26b'
    assert do_urlencode('a=b') == 'a%3Db'
    assert do_urlencode([1, 2, 3]) == '1&2&3'
    assert do_urlencode([1, 2, 3], True) == '1&2&3'
    assert do_urlencode({'a': 1, 'b': 2, 'c': 3}) == 'a=1&c=3&b=2'
    assert do_urlencode({'a': 1, 'b': 2, 'c': 3}, True)

# Generated at 2022-06-23 10:16:30.247551
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:16:38.902694
# Unit test for function do_urldecode
def test_do_urldecode():
    testdict = {
        'foo': 'bar',
        'baz': 'buz',
        '1': '2',
        '3': '.4+5',
        '6': '7+8%',
        '9': '0=%&',
    }
    res = u'&'.join(unicode_urlencode(k) + '=' + unicode_urlencode(v, for_qs=True)
                    for k, v in iteritems(testdict))
    assert do_urldecode(res) == testdict, res
    assert do_urldecode(unicode_urlencode('foo')) == unicode_urlencode('foo')

# Generated at 2022-06-23 10:16:39.415726
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:16:47.304557
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Basic tests
    assert '' == unicode_urldecode('')
    assert ' ' == unicode_urldecode(' ')
    assert 'a' == unicode_urldecode('a')
    assert 'a' == unicode_urldecode('a')
    assert '_%30%30_' == unicode_urldecode('_%30%30_')

    # Valid UTF-8 Codepoints
    assert u'♥' == unicode_urldecode('%E2%99%A5')
    assert u'♥♥' == unicode_urldecode('%E2%99%A5%E2%99%A5')

    # Invalid UTF-8 Codepoints

# Generated at 2022-06-23 10:16:57.207597
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo%20bar') == 'foo%20bar'
    assert unicode_urlencode('foo/bar') == 'foo/bar'

    assert unicode_urlencode(u'föo') == 'f%C3%B6o'
    assert unicode_urlencode(u'föo bar') == 'f%C3%B6o%20bar'
    assert unicode_urlencode(u'föo+bar') == 'f%C3%B6o%2Bbar'
    assert unicode_urlencode

# Generated at 2022-06-23 10:17:01.662827
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2520') == '%20'


# Generated at 2022-06-23 10:17:04.165022
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c = FilterModule()
    assert c.filters()['urldecode'] == do_urldecode


# Generated at 2022-06-23 10:17:10.533402
# Unit test for function do_urlencode
def test_do_urlencode():
    string = "id=1&name=Tom&name=Jack"
    res = do_urlencode(string)
    assert res == "id%3D1%26name%3DTom%26name%3DJack"

    dict = {'id': '1', 'name': ['Tom', 'Jack']}
    res = do_urlencode(dict)
    assert res == "id%3D1%26name%3DTom%26name%3DJack"

# Generated at 2022-06-23 10:17:22.273136
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('unicode_str') == 'unicode_str'
    assert do_urlencode('/bin/test') == '%2Fbin%2Ftest'
    assert do_urlencode('test') == 'test'
    assert do_urlencode(123) == '123'
    assert do_urlencode({}) == ''
    assert do_urlencode({'key1': 1, 'key2': 2}) == 'key1=1&key2=2'
    assert do_urlencode({'key1': {'key2': 2}}) == 'key1=key2%3D2'
    assert do_urlencode([1, 2]) == '0=1&1=2'

# Generated at 2022-06-23 10:17:23.763682
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()


# Generated at 2022-06-23 10:17:28.609858
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('11') == '11'
    assert unicode_urlencode('11&11') == '11%2611'
    assert unicode_urlencode('11&11', for_qs=True) == '11%2611'
    assert unicode_urlencode('11/11') == '11%2F11'
    assert unicode_urlencode(u'π') == '%CF%80'
    assert unicode_urlencode('π') == b'%CF%80'



# Generated at 2022-06-23 10:17:33.260485
# Unit test for function do_urldecode

# Generated at 2022-06-23 10:17:40.354974
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("http://example.org/") == "http://example.org/"
    assert do_urldecode("http%3A%2F%2Fexample.org%2F") == "http://example.org/"
    assert do_urlencode("http://example.org/") == "http%3A%2F%2Fexample.org%2F"
    assert do_urlencode("http%3A%2F%2Fexample.org%2F") == "http%253A%252F%252Fexample.org%252F"
    assert do_urlencode(["a", "b"]) == "a=b"
    assert do_urlencode({"a": "b"}) == "a=b"

# Generated at 2022-06-23 10:17:43.264514
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('hello world') == 'hello%20world'


# Generated at 2022-06-23 10:17:53.171887
# Unit test for function do_urlencode

# Generated at 2022-06-23 10:17:56.848541
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    assert filters['urldecode']('foo%20bar') == 'foo bar'

    if not HAS_URLENCODE:
        assert filters['urlencode']('foo bar') == 'foo%20bar'

# Generated at 2022-06-23 10:18:04.822092
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from sys import getdefaultencoding
    try:
        from cgi import parse_qs
    except:
        from urllib.parse import parse_qs

    from ansible.module_utils.six import binary_type

    input = u'föö_bär=bâz&föö_baür=nöt+eûqâl'
    expected = u'föö_bär=bâz&föö_baür=nöt eûqâl'
    assert unquote_plus(input.encode(getdefaultencoding())) == expected

    assert unicode_urldecode(input) == expected
    assert unicode_urldecode(binary_type(input)) == expected

    # Validate we can seamlessly use the result and do not loose information

# Generated at 2022-06-23 10:18:08.334299
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb%2Cc%2Fd') == u'a+b,c/d'

# Generated at 2022-06-23 10:18:19.278674
# Unit test for function do_urlencode
def test_do_urlencode():
  import unittest, sys
  result = do_urlencode({'a': []})
  assert not result
  result = do_urlencode('myurl')
  assert result == 'myurl'
  result = do_urlencode({'myurl': 'myurl'})
  assert result == 'myurl=myurl'
  result = do_urlencode([('myurl', 'myurl')])
  assert result == 'myurl=myurl'
  result = do_urlencode([('myurl', 'myurl'), ('myurl2', 'myurl2')])
  assert result == 'myurl=myurl&myurl2=myurl2'
  result = do_urlencode({'myurl': None})
  assert result == 'myurl='

# Generated at 2022-06-23 10:18:26.925366
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test strings
    assert do_urlencode('http://foo') == 'http%3A//foo'
    assert do_urlencode('/a&b/c') == '%2Fa%26b%2Fc'
    assert do_urlencode('/a&b/c') != '%2Fa&b%2Fc'

    # Test dicts
    assert do_urlencode({'a': 'b', 'c': 'd e'}) == 'a=b&c=d+e'
    assert do_urlencode({'a': 'b', 'c': 'd e'}) != 'a=b&c=d e'

    # Test lists
    assert do_urlencode(('a', 'b')) == 'a&b'

# Generated at 2022-06-23 10:18:36.176130
# Unit test for function do_urldecode
def test_do_urldecode():
    from ansible.module_utils import basic
    import json

    data = 'some random string'
    encoded_data = basic.url_quote(data)

    # do_urldecode expects a unicode object and we receive a string
    # object from basic.url_quote.
    decoded_data = do_urldecode(encoded_data)

    assert data == decoded_data, "do_urldecode should decode encoded data"

    # verify the test case works
    json_data = json.dumps(data)
    json_data = do_urldecode(json_data)
    assert json_data != data, "do_urldecode should fail to decode this data"

    # Test to see if a dict is valid arg
    data = {'test_key': 'test_value'}
   

# Generated at 2022-06-23 10:18:46.132645
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus, unquote_plus

    fm = FilterModule()
    for k, v in fm.filters().items():
        assert hasattr(v, '__call__')
    d = dict(a="1 2 3", b="4=5&6")
    s = b"/foo?a=1+2+3&b=4%3D5%266" if PY3 else "/foo?a=1+2+3&b=4%3D5%266"

# Generated at 2022-06-23 10:18:56.486245
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'foo%20%3A%20bar' == unicode_urlencode('foo : bar'), \
        'urlencode test 1 failed'
    assert 'foo%20%3A%20bar' == unicode_urlencode('foo : bar', for_qs=True), \
        'urlencode test 2 failed'
    assert 'foo%20%3A%20bar%2F' == unicode_urlencode('foo : bar/', for_qs=False), \
        'urlencode test 3 failed'
    assert 'foo%2F%3A%20bar%2F' == unicode_urlencode('foo/: bar/', for_qs=False), \
        'urlencode test 4 failed'

# Generated at 2022-06-23 10:19:01.805177
# Unit test for function do_urlencode
def test_do_urlencode():
    '''
    Unit test to check if do_urlencode function works as expected.
    '''
    do_urldecode(do_urlencode(u'/ some space')) == u'/ some space'

    do_urldecode(do_urlencode({'a': [1, 2, 3]}, True)) == 'a=1&a=2&a=3'

# Generated at 2022-06-23 10:19:12.275031
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('%21') == u'!'
    assert unicode_urldecode('%23') == u'#'
    assert unicode_urldecode('%24') == u'$'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode(u'%26') == u'&'
    assert unicode_urldecode('%27') == u"'"
    assert unicode_urldecode('%28') == u'('
    assert unicode_urldecode('%29') == u')'
    assert unicode_urldecode('%2A') == u'*'

# Generated at 2022-06-23 10:19:21.238808
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    context = {}
    fm = FilterModule()
    filters = fm.filters()

    # Test urldecode
    assert filters['urldecode']('string%20with%20spaces') == 'string with spaces'
    assert filters['urldecode']('string+with+spaces') == 'string with spaces'

    # Test urlencode
    assert filters['urlencode'](42) == '42'
    assert filters['urlencode']('string with spaces') == 'string+with+spaces'
    assert filters['urlencode'](['a', 'b']) == 'a&b'
    assert filters['urlencode'](('a', 'b')) == 'a&b'

    assert filters['urlencode']({'a': 'b'}) == 'a=b'
    assert filters

# Generated at 2022-06-23 10:19:23.006718
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-23 10:19:32.657140
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urldecode("%5C%20%22%17") == "\\ \"\x17"  # urldecode without filter plugin
    assert do_urlencode({"a": "b"}) == "a=b"
    assert do_urlencode(["a", "b"]) == "a&b"
    assert do_urlencode({"a": "b", "c": "d"}) == "a=b&c=d"
    assert do_urlencode(["a", "b", "c", "d"]) == "a&b&c&d"
    assert do_urlencode("a b c d") == "a%20b%20c%20d"

# Generated at 2022-06-23 10:19:38.170986
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%E8%A8%80%E8%88%AC') == u'語言'


# Generated at 2022-06-23 10:19:42.480756
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'a%20b' == do_urlencode('a b')
    assert 'c%2Fd' == do_urlencode('c/d')
    assert 'e=f' == do_urlencode({'e': 'f'})
    assert 'x=1&x=2' == do_urlencode([('x', '1'), ('x', '2')])

# Generated at 2022-06-23 10:19:45.837221
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("/") == "/"
    assert do_urlencode("/Hello, World!") == "/Hello,%20World!"
    assert do_urlencode("my_dict", {'foo': 'bar'}) == "my_dict=foo=bar"



# Generated at 2022-06-23 10:19:55.739117
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus, quote_plus


# Generated at 2022-06-23 10:20:05.629112
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    tests = [
        ('\u2713', '%E2%9C%93'),
        ('\u2713 A', '%E2%9C%93+A'),
        ('Param One', 'Param+One'),
        ('Param One&Param Two', 'Param+One%26Param+Two'),
        ('Param One+Param Two', 'Param+One%2BParam+Two'),
        ('/path/to/file', '/path/to/file'),
    ]
    for test in tests:
        assert unicode_urlencode(test[0]) == test[1]
        assert unicode_urlencode(test[0], for_qs=True) == test[1]

# Generated at 2022-06-23 10:20:16.779983
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/foo') == '/foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'

    assert do_urlencode([]) == ''
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(['foo', ('bar', 'baz')]) == 'foo&bar=baz'
    assert do_urlencode(['foo', ('bar', ['baz', 'qux'])]) == 'foo&bar=baz&bar=qux'
    #assert do_urlencode(['foo', {'bar': 'baz'}]) == 'foo&bar=baz'
    #assert do_urlencode(['

# Generated at 2022-06-23 10:20:24.282657
# Unit test for function do_urlencode
def test_do_urlencode():
    """ unit test for do_urlencode """
    assert do_urlencode(u'abcd') == u'abcd'
    assert do_urlencode(u'abcd') != b'abcd'
    assert do_urlencode(u'~abcd') == u'%7Eabcd'
    assert do_urlencode(u'/abcd') == u'%2Fabcd'
    assert do_urlencode(u'~!@#$%^&*()_+') == u'%7E%21%40%23%24%25%5E%26%2A%28%29_%2B'

# Generated at 2022-06-23 10:20:33.108394
# Unit test for function do_urlencode
def test_do_urlencode():
  assert do_urlencode("one two three") == "one+two+three"
  assert do_urlencode("one&two") == "one%26two"
  assert do_urlencode("one two three") == "one+two+three"
  assert do_urlencode("one&two") == "one%26two"
  assert do_urlencode("one=two") == "one%3Dtwo"
  assert do_urlencode("one=two&three") == "one%3Dtwo%26three"
  assert do_urlencode("one&two=three") == "one%26two%3Dthree"
  assert do_urlencode("one%two=three") == "one%25two%3Dthree"

# Generated at 2022-06-23 10:20:34.543338
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # TODO: Define unit tests for class FilterModule
    assert True

# Generated at 2022-06-23 10:20:38.893259
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b') == u'a b'
    assert unicode_urldecode('a+b') == u'a+b'
    assert unicode_urldecode('a+b%2Cc+d') == u'a+b,c d'


# Generated at 2022-06-23 10:20:46.579596
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()

    # unit test urldecode
    assert filters['urldecode']("%7B%22info%22%3A%20%5B%7B%22privateIP%22%3A%20%2210.0.2.15%22%2C%20%22publicIP%22%3A%20%2223.97.171.33%22%7D%5D%7D") == "{\"info\": [{\"privateIP\": \"10.0.2.15\", \"publicIP\": \"23.97.171.33\"}]}"

# Generated at 2022-06-23 10:20:55.205043
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.œuvre.org') == u'http%3A//www.%C5%93uvre.org'
    assert unicode_urlencode(u'http://www.œuvre.org', for_qs=True) == u'http%3A%2F%2Fwww.%C5%93uvre.org'
    assert unicode_urlencode({'foo': ['bar', 'baz', 'qux']}, for_qs=True) == u'foo=bar&foo=baz&foo=qux'

# Generated at 2022-06-23 10:21:00.574536
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_module_instance = FilterModule()
    filters = ansible_module_instance.filters()
    expected_results = {
        'urldecode': 'do_urldecode',
        'urlencode': 'do_urlencode',
    }
    for filter_name, filter_method in iteritems(filters):
        assert expected_results[filter_name] == filter_method.__name__

    assert 'urldecode' in filters
    assert 'urlencode' in filters

# Generated at 2022-06-23 10:21:07.371986
# Unit test for function do_urlencode
def test_do_urlencode():
    """
    url encoding tests
    """
    assert do_urlencode(u'http://www.example.com/') == u'http%3A%2F%2Fwww.example.com%2F'
    assert do_urlencode(u'http://www.example.com/~test/') == u'http%3A%2F%2Fwww.example.com%2F%7Etest%2F'
    assert do_urlencode(u'http://www.example.com/?foo=bar') == u'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-23 10:21:10.097084
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'



# Generated at 2022-06-23 10:21:11.734019
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('foo=1&bar=2') == 'foo=1&bar=2'



# Generated at 2022-06-23 10:21:13.092951
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None
    assert FilterModule(object) is not None

# Generated at 2022-06-23 10:21:20.362776
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    data = u'böö'
    assert unicode_urlencode(data) == u'b%C3%B6%C3%B6'
    assert unicode_urlencode(data, for_qs=True) == u'b%C3%B6%C3%B6'

    data = {u'böö': u'bär', u'1': u'2'}
    assert unicode_urlencode(data) == u'1=2&b%C3%B6%C3%B6=b%C3%A4r'

    # Test if it accepts lists
    data = [u'böö', u'bär', 1, 2]

# Generated at 2022-06-23 10:21:27.289680
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')


if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:21:30.843712
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert type(obj) == FilterModule
    assert obj.filters() == {'urlencode': do_urlencode, 'urldecode': do_urldecode}


# Generated at 2022-06-23 10:21:31.430413
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:21:39.602140
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode('?/&:=;#') == b'%3F%2F%26%3A%3D%3B%23'
    assert do_urlencode(':/?#[]@$&+;') == b':/?#[]@$&+;'

    # Note: python2 quote_plus differs from python3 and the following tests checks for that
    # https://stackoverflow.com/questions/4507665/why-does-python-3-urlencode-produce-different-results-to-python-2
    if PY3:
        assert do_urlencode('python') == b'python'
        assert do_urlencode('python/') == b'python%2F'
    else:
        assert do_urlencode('python') == b'python'

# Generated at 2022-06-23 10:21:47.928837
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"ěščřžýáíéů") == u"%C4%9B%C5%A1%C4%8D%C5%99%C5%BE%C3%BD%C3%A1%C3%AD%C3%A9%C5%AF"
    assert unicode_urlencode(u"hello world") == u"hello%20world"
    assert unicode_urlencode(u"foo@bar.com") == u"foo%40bar.com"

# Generated at 2022-06-23 10:21:53.356792
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('http%3A%2F%2Fwww.example.com%2F') == 'http://www.example.com/'


# Generated at 2022-06-23 10:22:02.175493
# Unit test for function do_urlencode
def test_do_urlencode():
    # Check for various simple inputs
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('/') == '%2F'
    assert do_urlencode('%') == '%25'
    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode('a+b') == 'a%2Bb'
    assert do_urlencode({'a': 'b'}) == 'a=b'
    assert do_urlencode({'a': 1}) == 'a=1'
    assert do_urlencode({'a b': 'c d'}) == 'a+b=c+d'

# Generated at 2022-06-23 10:22:08.582115
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    cases = (
        (u'', u''),
        (u'  a  ', u'a'),
        (u'👍', u'👍'),
        (u'  👍  ', u'👍'),
        (u'%4A%90%3f', u'JZ?'),
    )
    for text, result in cases:
        assert unicode_urldecode(text) == result


# Generated at 2022-06-23 10:22:13.047739
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule()) == {'urldecode': do_urldecode} or \
        FilterModule.filters(FilterModule()) == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-23 10:22:19.686247
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    testdata = (
        (u'https%3A%2F%2Fjdanbrown.com%2F%3Fparam1%3Dvalue%26param2%3Dsecond%2520value',
         u'https://jdanbrown.com/?param1=value&param2=second%20value'),
    )
    for encoded, decoded in testdata:
        assert unicode_urldecode(encoded) == decoded

# Generated at 2022-06-23 10:22:23.451543
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(b'dag%20wieers') == 'dag wieers'
    else:
        assert unicode_urldecode('dag%20wieers') == u'dag wieers'


# Generated at 2022-06-23 10:22:32.083179
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Utility function to run tests
    def _run_filter(obj, filter_name, arg, expected_result, skip=False):
        # Run the filter and compare result
        result = obj.filters()[filter_name](arg)
        assert result == expected_result, "Expected %s, got %s" % (
            repr(expected_result), repr(result))
        from pprint import pprint
        pprint("%s: %s == '%s'" % (arg, result, expected_result))

    fm = FilterModule()
    filters = fm.filters()

    _run_filter(fm, 'urldecode', 'foo%20bar', 'foo bar')
    _run_filter(fm, 'urldecode', 'foo+bar', 'foo bar')

# Generated at 2022-06-23 10:22:39.799114
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'


# Generated at 2022-06-23 10:22:44.726315
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()

    # Test 'urldecode' method
    assert filters['urldecode']('Hello%20World') == 'Hello World'

    # Test 'urlencode' method
    assert filters['urlencode']('Hello World') == 'Hello+World'

    # Test 'urlencode' method
    assert filters['urlencode']('Hello World') == 'Hello+World'

# Generated at 2022-06-23 10:22:54.693291
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('abcd') == 'abcd')
    assert(do_urlencode(u'abcd') == u'abcd')
    assert(do_urlencode('ab/cd') == 'ab%2Fcd')
    assert(do_urlencode(u'ab/cd') == 'ab%2Fcd')
    assert(do_urlencode('ab%2Fcd') == 'ab%252Fcd')
    assert(do_urlencode(u'ab%2Fcd') == 'ab%252Fcd')
    assert(do_urlencode('ab:cd') == 'ab:cd')
    assert(do_urlencode(u'ab:cd') == 'ab:cd')

# Generated at 2022-06-23 10:23:01.794893
# Unit test for function do_urldecode
def test_do_urldecode():
    import sys

    # Test PY3
    if sys.version_info >= (3, 0):
        assert(do_urldecode(b'%20') == ' ')
        assert(do_urldecode(u'%20') == ' ')
        assert(do_urldecode('%20') == ' ')

    # Test PY2
    else:
        assert(do_urldecode(b'%20') == u' ')
        assert(do_urldecode(u'%20') == u' ')
        assert(do_urldecode('%20') == u' ')



# Generated at 2022-06-23 10:23:03.776947
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters.get('urlencode', None) == do_urlencode


# Generated at 2022-06-23 10:23:08.776651
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'a%20b%20c' == unicode_urlencode('a b c')
    assert 'a%20b%20c' == unicode_urlencode(u'a b c')
    assert 'a%20b%20c' == unicode_urlencode(b'a b c', for_qs=True)


# Generated at 2022-06-23 10:23:12.559521
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('a%20string') == 'a string'
    assert do_urlencode('a string') == 'a+string'


# Generated at 2022-06-23 10:23:14.087687
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'\u2661') == u'%E2%99%A1')



# Generated at 2022-06-23 10:23:17.535987
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%74%69%74%66%6F%6F%62%61%72') == u'titfoobar'


# Generated at 2022-06-23 10:23:19.685237
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ans = FilterModule()
    print(ans.__dict__)
    print(ans.filters())


# Generated at 2022-06-23 10:23:25.266016
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode(u'') == u''
    assert do_urldecode(u'abc') == u'abc'
    assert do_urldecode(u'abc%20def') == u'abc def'
    assert do_urldecode(u'%2F') == u'/'
    assert do_urldecode(u'%2F%2F') == u'//'



# Generated at 2022-06-23 10:23:25.997231
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

# Generated at 2022-06-23 10:23:27.342513
# Unit test for constructor of class FilterModule
def test_FilterModule():
    new_obj = FilterModule()
    assert hasattr(new_obj, "filters")

# Generated at 2022-06-23 10:23:38.665881
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abé') == u'ab%C3%A9'
    assert unicode_urlencode(u'abé', for_qs=True) == u'ab%C3%A9'
    assert unicode_urlencode((u'abé', u'cdë')) == u'ab%C3%A9&cd%C3%AB'
    assert unicode_urlencode({u'abé': u'cdë'}) == u'ab%C3%A9=cd%C3%AB'
    assert unicode_urlencode([u'abé', u'cdë']) == u'ab%C3%A9&cd%C3%AB'



# Generated at 2022-06-23 10:23:45.473518
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    # Test urldecode
    assert filters['urldecode']('%25') == '%'
    assert filters['urldecode']('%25%') == '%%'

    # Test urlencode
    assert filters['urlencode']('%') == '%25'
    assert filters['urlencode']('%%') == '%25%25'
    assert filters['urlencode']({'k1': 'v1', 'k2': 'v2'}) == 'k1=v1&k2=v2'

# Generated at 2022-06-23 10:23:52.056221
# Unit test for function unicode_urldecode

# Generated at 2022-06-23 10:23:59.047721
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    def filter_urlencode(s, for_qs=False):
        return do_urlencode(s)

    # Test function filters['urldecode']
    assert(do_urldecode("12345") == "12345")
    assert(do_urldecode("abcdef") == "abcdef")
    assert(do_urldecode("ABCDEF") == "ABCDEF")
    assert(do_urldecode("+-_.*@%/") == "+-_.*@%/")
    assert(do_urldecode("?") == "?")
    assert(do_urldecode("&") == "&")
    assert(do_urldecode("=") == "=")
    assert(do_urldecode("%2B") == "+")

# Generated at 2022-06-23 10:24:02.228930
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert 'urldecode' in module.filters()
    assert 'urlencode' in module.filters()



# Generated at 2022-06-23 10:24:06.407205
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if not PY3:
        assert unicode_urldecode('%C3%A9') == u'é'
    else:
        assert unicode_urldecode('%C3%A9') == 'é'


# Generated at 2022-06-23 10:24:15.859843
# Unit test for function unicode_urlencode

# Generated at 2022-06-23 10:24:17.125706
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:24:24.257036
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.org/@') == 'http%3A//www.example.org/%40'
    assert unicode_urlencode('http://www.example.org/%40') == 'http://www.example.org/%40'
    assert unicode_urlencode('http://www.example.org/%2540') == 'http%3A//www.example.org/%2540'

# Generated at 2022-06-23 10:24:35.237793
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('test') == u'test'
    assert do_urlencode('test/test') == u'test%2Ftest'
    assert do_urlencode({'key': 'value'}) == u'key=value'
    assert do_urlencode({'key': 'value', 'key2': 'value2'}) == u'key=value&key2=value2'
    assert do_urlencode({'key': {'key2': 'value2'}}) == u'key%5Bkey2%5D=value2'
    assert do_urlencode('test') == do_urldecode(do_urlencode('test'))

# Generated at 2022-06-23 10:24:37.265597
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('param%3Dvalue') == "param=value"


# Generated at 2022-06-23 10:24:41.040925
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # https://stackoverflow.com/questions/415511/how-to-get-the-current-time-in-python
    import datetime
    now = datetime.datetime.now()
    now_parsed = unicode_urlencode(now)
    if len(now_parsed) == 0:
        raise ValueError('unicode_urlencode produced invalid result')

# Generated at 2022-06-23 10:24:48.398951
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    f = FilterModule()
    assert f.filters()['urldecode']('%C3%BC') == unquote_plus('%C3%BC')

    if not PY3:
        assert f.filters()['urldecode'](u'%C3%BC') == unquote_plus(u'%C3%BC')

# Generated at 2022-06-23 10:25:00.168938
# Unit test for function do_urldecode
def test_do_urldecode():
    assert do_urldecode('key=value') == u'key=value'
    assert do_urldecode('key=value%3Dvalue2') == u'key=value=value2'
    assert do_urldecode('key=value%26value2') == u'key=value&value2'
    assert do_urldecode('key=value/value2') == u'key=value/value2'
    assert do_urldecode('key=value') == u'key=value'
    assert do_urldecode('key=') == u'key='
    assert do_urldecode('key') == u'key'
    assert do_urldecode('key=value=value2') == u'key=value=value2'

# Generated at 2022-06-23 10:25:12.446228
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('unicode') == 'unicode'
    assert do_urlencode(('unicode', 'unicode')) == 'unicode&unicode'
    assert do_urlencode(['unicode', 'unicode']) == 'unicode&unicode'
    assert do_urlencode({'unicode': 'unicode'}) == 'unicode=unicode'
    assert do_urlencode({'unicode': 'unicode', 'unicode2': 'unicode2'}) == 'unicode=unicode&unicode2=unicode2'
    assert do_urlencode({'unicode': ['unicode', 'unicode2'], 'unicode3': 'unicode3'}) == 'unicode=unicode&unicode=unicode2&unicode3=unicode3'
    assert do

# Generated at 2022-06-23 10:25:16.144315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    filters = fm.filters()

    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-23 10:25:18.271991
# Unit test for function do_urldecode
def test_do_urldecode():
    test_content = b'%3A%3a'
    assert do_urldecode(test_content) == '::'



# Generated at 2022-06-23 10:25:21.460375
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urldecode': do_urldecode}



# Generated at 2022-06-23 10:25:25.650953
# Unit test for function do_urldecode
def test_do_urldecode():
    # Ensure we can decode plain strings
    assert do_urldecode("hello") == "hello"

    # Ensure we can decode strings (with utf8 cahracters)
    assert do_urldecode("%E6%96%87%E5%AD%97%E7%AC%A6%E5%8F%B7") == u"\u6587\u5b57\u7b26\u53f7"

    # Ensure we can decode a list of strings
    assert do_urldecode(["hello", "%E6%96%87%E5%AD%97%E7%AC%A6%E5%8F%B7"]) == ["hello", u"\u6587\u5b57\u7b26\u53f7"]

    # Ensure we can decode a dictionary

# Generated at 2022-06-23 10:25:36.670045
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Bac+=') == u'Bac%2B%3D'
    assert unicode_urlencode(u'Bac+') == u'Bac%2B'
    assert unicode_urlencode(u'!#[]') == u'%21%23%5B%5D'
    assert unicode_urlencode(u'/a') == u'%2Fa'
    assert unicode_urlencode(u'%2F') == u'%252F'
    assert unicode_urlencode(u'%2F', for_qs=True) == u'%2F'
    assert unicode_urlencode(u'Bac+=', for_qs=True) == u'Bac%2B%3D'
    assert unicode_urlencode

# Generated at 2022-06-23 10:25:37.798396
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None

# Generated at 2022-06-23 10:25:45.514881
# Unit test for function do_urldecode
def test_do_urldecode():

    test_cases = [
        (None, None),
        ("foo", "foo"),
        ("spa%20ce", "spa ce"),
        ("%20%20%20", "   "),
        ("%F0%9F%98%83", "\U0001F603"),
        ("%F0%9F%98%83: %F0%9F%98%83", "\U0001F603: \U0001F603"),
    ]

    for test_case in test_cases:
        if do_urldecode(test_case[0]) != test_case[1]:
            print("Failed to urldecode: %s" % test_case[0])
            return False

    return True


# Generated at 2022-06-23 10:25:56.228481
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import sys

    if PY3:
        assert unicode_urlencode('foo bar') == 'foo%20bar'
        assert unicode_urlencode('foo bar', True) == 'foo%20bar'
        assert unicode_urlencode('/bar/foo') == '%2Fbar%2Ffoo'
        assert unicode_urlencode('/bar/foo', True) == '%2Fbar%2Ffoo'
        assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
        assert unicode_urlencode('foo/bar', True) == 'foo%2Fbar'
        assert unicode_urlencode('foo bar/foo') == 'foo%20bar%2Ffoo'