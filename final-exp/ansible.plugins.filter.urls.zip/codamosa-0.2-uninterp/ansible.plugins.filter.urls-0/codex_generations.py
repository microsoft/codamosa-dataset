

# Generated at 2022-06-17 11:23:36.898602
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:23:48.376668
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F') == '////'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F%2F') == '/////'
    assert FilterModule

# Generated at 2022-06-17 11:23:59.728125
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'

# Generated at 2022-06-17 11:24:02.521118
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:24:12.363865
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:15.870591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:24:24.916342
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'


# Generated at 2022-06-17 11:24:36.924373
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'

# Generated at 2022-06-17 11:24:44.178728
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:24:51.313857
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2f%2f%2f') == u'///'

# Generated at 2022-06-17 11:25:02.770620
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo?bar') == u

# Generated at 2022-06-17 11:25:10.766888
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:25:16.883458
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2b%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:25:20.781612
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-17 11:25:23.593232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:36.332371
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:25:43.863341
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/a/b') == '/a/b'
    assert unicode_urlencode('/a/b', for_qs=True) == '%2Fa%2Fb'
    assert unicode_urlencode('/a/b/') == '/a/b/'
    assert unicode_urlencode('/a/b/', for_qs=True) == '%2Fa%2Fb%2F'
    assert unicode_urlencode('/a/b/ ') == '/a/b/%20'

# Generated at 2022-06-17 11:25:48.013919
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:57.071808
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:03.287460
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc+def') == 'abc def'
    assert unicode_urldecode('abc%2Bdef') == 'abc+def'
    assert unicode_urldecode('abc%2bdef') == 'abc+def'
    assert unicode_urldecode('abc%2Bdef%2Bghi') == 'abc+def+ghi'
    assert unicode_urldecode('abc%2bdef%2bghi') == 'abc+def+ghi'
    assert unicode_urldecode('abc%2Bdef%2bghi') == 'abc+def+ghi'

# Generated at 2022-06-17 11:26:16.148920
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:19.032449
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:21.786598
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-17 11:26:25.165010
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:37.320698
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc:def') == u'abc%3Adef'
    assert unicode_urlencode(u'abc:def', for_qs=True) == u'abc%3Adef'
    assert unicode_urlencode(u'abc?def') == u

# Generated at 2022-06-17 11:26:44.236176
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:26:54.300986
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2F') == '//'

# Generated at 2022-06-17 11:26:57.664819
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:07.909805
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert do_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'

# Generated at 2022-06-17 11:27:13.925896
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:27:33.814185
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'

# Generated at 2022-06-17 11:27:41.667869
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:51.437431
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(['foo', 'bar baz']) == 'foo&bar+baz'
    assert do_urlencode(['foo', 'bar baz']) == 'foo&bar+baz'

# Generated at 2022-06-17 11:28:00.252394
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%C3%A9') == u'é'
    assert do_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert do_urldecode('%C3%A9&%C3%A9') == u'é&é'
    assert do_urldecode('%C3%A9&%C3%A9=%C3%A9') == u'é&é=é'
    assert do_urldecode('%C3%A9=%C3%A9&%C3%A9') == u'é=é&é'

# Generated at 2022-06-17 11:28:10.908509
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:28:14.540807
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:28:22.422342
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:28:31.493637
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:41.021034
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert do_urlencode(u'http://example.com/foo bar') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'
    assert do_urlencode(u'http://example.com/foo+bar') == u'http%3A%2F%2Fexample.com%2Ffoo%2Bbar'
    assert do_urlencode(u'http://example.com/foo%20bar') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'

# Generated at 2022-06-17 11:28:52.114166
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with Jinja2 v2.7
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'

# Generated at 2022-06-17 11:29:29.476150
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'

# Generated at 2022-06-17 11:29:32.485456
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:38.899380
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus, unquote_plus

    # Create a dummy module
    module = basic.AnsibleModule(
        argument_spec={},
    )

    # Create a dummy filter
    filter = FilterModule()

    # Test urldecode
    if PY3:
        assert filter.filters()['urldecode']('foo%2Fbar') == unquote_plus('foo%2Fbar')
    else:
        assert filter.filters()['urldecode']('foo%2Fbar') == to_text(unquote_plus(to_bytes('foo%2Fbar')))

    # Test urlencode

# Generated at 2022-06-17 11:29:48.688516
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode

# Generated at 2022-06-17 11:29:57.377398
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/bar baz/') == u'http%3A//foo/bar%20baz/'
    assert unicode_urlencode('http://foo/bar baz/', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar+baz%2F'
    assert unicode_urlencode(u'http://foo/bar baz/') == u'http%3A//foo/bar%20baz/'
    assert unicode_urlencode(u'http://foo/bar baz/', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar+baz%2F'

# Generated at 2022-06-17 11:30:02.210463
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%C3%A9') == u'éé'
    assert unicode_urldecode('%C3%A9%C3%A9%C3%A9') == u'ééé'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'
    assert unicode_urld

# Generated at 2022-06-17 11:30:08.733330
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo bar/', for_qs=True) == '/foo+bar/'
    assert unicode_urlencode('/foo?bar/') == '/foo%3Fbar/'
    assert unicode_urlencode('/foo?bar/', for_qs=True) == '/foo%3Fbar/'
    assert unicode_urlencode('/foo&bar/') == '/foo%26bar/'
    assert unicode_urlencode('/foo&bar/', for_qs=True) == '/foo%26bar/'

# Generated at 2022-06-17 11:30:16.810570
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('foo') == 'foo'
    assert fm.filters()['urldecode']('foo%20bar') == 'foo bar'
    assert fm.filters()['urldecode']('foo+bar') == 'foo bar'
    assert fm.filters()['urldecode']('foo%2Bbar') == 'foo+bar'
    assert fm.filters()['urldecode']('foo%2bbar') == 'foo+bar'
    assert fm.filters()['urldecode']('foo%2Bbar%20baz') == 'foo+bar baz'

# Generated at 2022-06-17 11:30:26.577088
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
   

# Generated at 2022-06-17 11:30:36.909154
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'

# Generated at 2022-06-17 11:31:37.685250
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'

# Generated at 2022-06-17 11:31:40.629909
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:48.282030
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:31:52.084383
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A//example.com/'
    assert unicode_urlencode('http://example.com/', for_qs=True) == 'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode('http://example.com/?a=1&b=2') == 'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode('http://example.com/?a=1&b=2', for_qs=True) == 'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:31:59.733332
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'€äöüßÄÖÜß'

# Generated at 2022-06-17 11:32:02.472789
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:32:12.968467
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:32:20.217498
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:28.715265
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:32:38.612768
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'
    assert unicode_urldecode(u'%E2%82%AC') == u'€'
    assert unicode_urldecode(u'%E2%82%AC%E2%82%AC') == u'€€'
    assert unicode_urldecode(u'%E2%82%AC%E2%82%AC%E2%82%AC') == u'€€€'