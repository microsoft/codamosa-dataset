

# Generated at 2022-06-17 11:23:31.081430
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert do_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'
    assert do_urldecode('%2F%2F%2F%2F%2F%2F%2F') == '///////'
    assert do_urldecode

# Generated at 2022-06-17 11:23:38.582965
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo@bar') == 'foo%40bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'

# Generated at 2022-06-17 11:23:43.664208
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:23:47.006899
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:23:57.248726
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:05.325329
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2f') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2f%2f') == '///'

# Generated at 2022-06-17 11:24:12.645489
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:24:21.269522
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:24.949597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-17 11:24:36.952366
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'

# Generated at 2022-06-17 11:24:49.216641
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:58.873817
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldec

# Generated at 2022-06-17 11:25:04.146015
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:11.141011
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%C3%84%C3%96%C3%9C%C3%9F') == u'äöüß ÄÖÜß'

# Generated at 2022-06-17 11:25:17.127067
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/foo') == '/foo'
    assert unicode_urlencode('/foo', for_qs=True) == '%2Ffoo'
    assert unicode_urlencode('/foo/bar') == '/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo/bar/') == '/foo/bar/'
    assert unicode_urlencode('/foo/bar/', for_qs=True) == '%2Ffoo%2Fbar%2F'
    assert unicode_

# Generated at 2022-06-17 11:25:25.079172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F'.encode('utf-8')) == u'äöüß'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F'.encode('latin-1')) == u'Ã¤Ã¶Ã¼ÃŸ'

# Generated at 2022-06-17 11:25:37.832163
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar') == u'http%3A//www.example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'
    assert unicode_urlen

# Generated at 2022-06-17 11:25:43.581991
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'
    assert do_urlencode(('foo', 'bar', 'baz')) == 'foo&bar&baz'

# Generated at 2022-06-17 11:25:53.837050
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/foo') == '/foo'
    assert unicode_urlencode('/foo', for_qs=True) == '%2Ffoo'
    assert unicode_urlencode('/foo/') == '/foo/'
    assert unicode_urlencode('/foo/', for_qs=True) == '%2Ffoo%2F'
    assert unicode_urlencode('/foo/bar') == '/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo/bar/')

# Generated at 2022-06-17 11:26:01.691053
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:13.305908
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2F%2F') == '///'
    assert fm.filters()['urldecode']('%2F%2F%2F%2F') == '////'

# Generated at 2022-06-17 11:26:17.131672
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2B%2B') == '++'
    assert FilterModule().filters()['urldecode']('%2b%2b') == '++'

# Generated at 2022-06-17 11:26:23.235479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2F%2F') == '///'

# Generated at 2022-06-17 11:26:36.399274
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2F') == '//'

# Generated at 2022-06-17 11:26:43.511029
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'

# Generated at 2022-06-17 11:26:53.882581
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:27:01.875441
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'
    assert unicode_urldecode(u'%E4%F6%FC%DF%C4%D6%DC%DF') == u'äöüßÄÖÜß'
    assert unicode_urldecode(u'%25%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'%äöüßÄÖÜß'

# Generated at 2022-06-17 11:27:08.902410
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_url

# Generated at 2022-06-17 11:27:18.948534
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'

# Generated at 2022-06-17 11:27:20.493891
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-17 11:27:26.818258
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:35.035989
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-17 11:27:41.723426
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:27:44.842737
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:55.156544
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo=bar') == 'foo%3Dbar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo?bar') == 'foo%3Fbar'
    assert do_urlencode('foo#bar') == 'foo%23bar'
    assert do_urlencode('foo@bar') == 'foo%40bar'
    assert do_urlencode('foo:bar') == 'foo%3Abar'


# Generated at 2022-06-17 11:27:59.368676
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:02.849741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:09.226571
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%C3%A9') == u'€é'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC') == u'€é€'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC%C3%A9') == u'€é€é'

# Generated at 2022-06-17 11:28:16.915633
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:28:24.795855
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'

# Generated at 2022-06-17 11:28:35.713567
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:45.997776
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
   

# Generated at 2022-06-17 11:28:53.582598
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'\xe4'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'\xe4\xf6\xfc\xdf'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%C3%84%C3%96%C3%9C%C3%9F') == u'\xe4\xf6\xfc\xdf \xc4\xd6\xdc\xdf'

# Generated at 2022-06-17 11:28:58.300370
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:05.728098
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'

# Generated at 2022-06-17 11:29:14.295801
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/b ar') == u'http%3A//foo/b%20ar'
    assert unicode_urlencode(u'http://foo/b ar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fb+ar'
    assert unicode_urlencode(u'http://foo/b+ar') == u'http%3A//foo/b%2Bar'

# Generated at 2022-06-17 11:29:20.364252
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test FilterModule.filters()
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:29.594968
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2f%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'

# Generated at 2022-06-17 11:29:32.918754
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:38.083514
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:29:51.303950
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def?ghi') == u'abc%2Fdef%3Fghi'
    assert unicode_urlencode(u'abc/def?ghi', for_qs=True) == u'abc%2Fdef%3Fghi'
   

# Generated at 2022-06-17 11:30:01.127574
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%7E') == u'~'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-17 11:30:03.424391
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:10.118201
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'

# Generated at 2022-06-17 11:30:18.384137
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%3a') == u':'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldec

# Generated at 2022-06-17 11:30:28.406017
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f%2F') == '//'
    assert do_urldecode('%2F%2f') == '//'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_ur

# Generated at 2022-06-17 11:30:31.801931
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:34.984837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:42.659188
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:30:45.621277
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:04.394201
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode('http://example.com/', for_qs=True) == 'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode('http://example.com/?foo=bar') == 'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'
    assert unicode_urlencode('http://example.com/?foo=bar', for_qs=True) == 'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:31:14.033405
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:31:24.605587
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:31:37.792268
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:31:44.121414
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode

# Generated at 2022-06-17 11:31:49.391909
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4%20%C3%B6') == u'ä ö'
    assert unicode_urldecode(u'%C3%A4%20%C3%B6%20%C3%BC') == u'ä ö ü'
    assert unicode_urldecode(u'%C3%A4%20%C3%B6%20%C3%BC%20%C3%84%20%C3%96%20%C3%9C') == u'ä ö ü Ä Ö Ü'

# Generated at 2022-06-17 11:31:55.346936
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:32:02.807753
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes

# Generated at 2022-06-17 11:32:09.597232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:19.289909
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2') == u'http%3A//foo/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:32:43.587389
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4') == u'\xe4'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F') == u'\xe4\xf6\xfc\xdf'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F%20%C3%84%C3%96%C3%9C%C3%9F') == u'\xe4\xf6\xfc\xdf \xc4\xd6\xdc\xdf'

# Generated at 2022-06-17 11:32:50.284298
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2F') == '//'

# Generated at 2022-06-17 11:32:57.580162
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A//example.com/foo%20bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'
    assert unicode_urlencode(u'http://example.com/foo+bar') == u'http%3A//example.com/foo%2Bbar'
    assert unicode_urlencode(u'http://example.com/foo+bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo%2Bbar'

# Generated at 2022-06-17 11:33:08.432488
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:33:18.359097
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%F0%9D%84%9E') == u'𝄞'


# Generated at 2022-06-17 11:33:26.017988
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'