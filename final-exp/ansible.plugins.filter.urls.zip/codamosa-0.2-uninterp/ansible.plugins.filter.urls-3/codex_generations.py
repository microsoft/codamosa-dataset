

# Generated at 2022-06-17 11:23:31.104889
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:23:38.599882
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:23:48.946261
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:00.077153
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:09.438729
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence

    fm = FilterModule()
    filters = fm.filters()

    assert filters['urldecode']('%20') == ' '
    assert filters['urldecode']('%2B') == '+'
    assert filters['urldecode']('%2b') == '+'
    assert filters['urldecode']('%3D') == '='
    assert filters['urldecode']('%3d') == '='
    assert filters['urldecode']('%26') == '&'

# Generated at 2022-06-17 11:24:20.973595
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:31.243911
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:39.538452
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/foo/bar') == u'http%3A//example.com/foo/bar'
    assert do_urlencode(u'http://example.com/foo/bar?a=1&b=2') == u'http%3A//example.com/foo/bar%3Fa%3D1%26b%3D2'
    assert do_urlencode(u'http://example.com/foo/bar#anchor') == u'http%3A//example.com/foo/bar%23anchor'

# Generated at 2022-06-17 11:24:49.618133
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:58.901935
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%20%2F') == '/ /'
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20') == '/ / '
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20%2F') == '/ / /'

# Generated at 2022-06-17 11:25:10.340262
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2f') == '//'
    assert fm.filters()['urldecode']('%2f%2F') == '//'
    assert fm.filters()['urldecode']('%2f%2f') == '//'

# Generated at 2022-06-17 11:25:13.285189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:23.035039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2f') == '//'
    assert do_urldecode('%2f%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2f%2f%2f') == '///'

# Generated at 2022-06-17 11:25:28.785173
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:25:37.392767
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo.com/bar?a=1&b=2') == u'http%3A//foo.com/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo.com/bar?a=1&b=2', for_qs=True) == u'http%3A%2F%2Ffoo.com%2Fbar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo.com/bar?a=1&b=2', for_qs=False) == u'http%3A%2F%2Ffoo.com%2Fbar%3Fa%3D1%26b%3D2'
    assert unicode_

# Generated at 2022-06-17 11:25:39.673098
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:45.963528
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:55.778878
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A//example.com/'
    assert unicode_urlencode('http://example.com/', for_qs=True) == 'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode('http://example.com/?a=b') == 'http%3A//example.com/%3Fa%3Db'
    assert unicode_urlencode('http://example.com/?a=b', for_qs=True) == 'http%3A%2F%2Fexample.com%2F%3Fa%3Db'

# Generated at 2022-06-17 11:26:02.389295
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode('%2F%2F%2F%2F') == '////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'
    assert unicode

# Generated at 2022-06-17 11:26:12.498636
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:26:26.217139
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:26:37.970691
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9') == u'é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9%20%26%20%C3%A9') == u'é & é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9%20%26%20%C3%A9%20%26%20%C3%A9') == u'é & é & é & é'

# Generated at 2022-06-17 11:26:44.647127
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/foo/bar') == u'http%3A%2F%2Fexample.com%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://example.com/foo/bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://example.com/foo/bar?a=1&b=2') == u'http%3A%2F%2Fexample.com%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:26:54.599564
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('foo%20bar') == 'foo bar'
    assert FilterModule().filters()['urldecode']('foo+bar') == 'foo bar'
    assert FilterModule().filters()['urldecode']('foo%2Fbar') == 'foo/bar'
    assert FilterModule().filters()['urldecode']('foo%2fbar') == 'foo/bar'
    assert FilterModule().filters()['urldecode']('foo%2Fbar%2Fbaz') == 'foo/bar/baz'
    assert FilterModule().filters()['urldecode']('foo%2fbar%2fbaz') == 'foo/bar/baz'

# Generated at 2022-06-17 11:27:02.487910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:09.267003
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:19.168519
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:27:25.157881
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:29.984312
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode

# Generated at 2022-06-17 11:27:39.665002
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert do_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert do_urlencode(u'http://example.com/?foo=bar&baz=qux') == u'http%3A//example.com/%3Ffoo%3Dbar%26baz%3Dqux'

# Generated at 2022-06-17 11:27:59.898682
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2f%2f') == '//'
    assert unicode_urldecode('%2F%2f') == '//'
    assert unicode_urldecode('%2f%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode('%2f%2f%2f') == '///'
    assert unicode_urldec

# Generated at 2022-06-17 11:28:03.192277
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:13.465445
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:22.652958
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-17 11:28:31.659078
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert do_urlencode(u'http://example.com/foo bar') == u'http%3A%2F%2Fexample.com%2Ffoo+bar'
    assert do_urlencode(u'http://example.com/foo+bar') == u'http%3A%2F%2Fexample.com%2Ffoo%2Bbar'
    assert do_urlencode(u'http://example.com/foo%20bar') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'

# Generated at 2022-06-17 11:28:41.059427
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:28:48.331219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:50.845898
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:56.463708
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'
    assert do_urlencode(('foo', 'bar', 'baz')) == 'foo&bar&baz'

# Generated at 2022-06-17 11:29:03.566563
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:29:34.621681
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:29:45.458722
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:29:56.442657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text as to_text_converter
    from ansible.module_utils.common.text.converters import to_bytes as to_bytes_converter
    from ansible.module_utils.common.text.converters import to_unicode as to_unicode_converter
    from ansible.module_utils.common.text.converters import to_bytes as to_bytes_conver

# Generated at 2022-06-17 11:30:03.490245
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'

# Generated at 2022-06-17 11:30:13.205874
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:30:19.343224
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar?a=b') == u'http%3A//foo/bar%3Fa%3Db'
    assert unicode_urlencode(u'http://foo/bar?a=b', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar%3Fa%3Db'

# Generated at 2022-06-17 11:30:29.357958
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2B%20') == '+ '
    assert do_urldecode('%2b%20') == '+ '
    assert do_urldecode('%2B%20%2B') == '+ +'
    assert do_urldecode('%2b%20%2b') == '+ +'
    assert do_urldecode('%2B%20%2B%20%2B') == '+ + +'
    assert do_urldecode('%2b%20%2b%20%2b') == '+ + +'

# Generated at 2022-06-17 11:30:37.732657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%3A') == ':'
    assert FilterModule().filters()['urldecode']('%3a') == ':'
    assert FilterModule().filters()['urldecode']('%3D') == '='
    assert FilterModule().filters()['urldecode']

# Generated at 2022-06-17 11:30:47.921603
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:30:57.849102
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo.com/bar?a=b&c=d') == u'http%3A//foo.com/bar%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://foo.com/bar?a=b&c=d', for_qs=True) == u'http%3A%2F%2Ffoo.com%2Fbar%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://foo.com/bar?a=b&c=d', for_qs=False) == u'http%3A//foo.com/bar%3Fa%3Db%26c%3Dd'

# Generated at 2022-06-17 11:31:28.490613
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/', for_qs=False) == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:31:34.781435
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:41.884807
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/', for_qs=True) == u'%2F'
    assert unicode_urlencode('/foo') == u'/foo'
    assert unicode_urlencode('/foo', for_qs=True) == u'%2Ffoo'
    assert unicode_urlencode('/foo/') == u'/foo/'
    assert unicode_urlencode('/foo/', for_qs=True) == u'%2Ffoo%2F'
    assert unicode_urlencode('/foo/bar') == u'/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == u'%2Ffoo%2Fbar'
    assert unicode_urlen

# Generated at 2022-06-17 11:31:45.042065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:54.547416
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert do_urlencode(u'http://example.com/foo bar') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'
    assert do_urlencode(u'http://example.com/foo bar/') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar%2F'
    assert do_urlencode(u'http://example.com/foo bar/baz') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar%2Fbaz'

# Generated at 2022-06-17 11:32:02.761689
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%3f') == u'?'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldec

# Generated at 2022-06-17 11:32:12.977874
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A//example.com/foo%20bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo+bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=False) == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo+bar'

# Generated at 2022-06-17 11:32:23.010372
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'

# Generated at 2022-06-17 11:32:30.004732
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:39.000777
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode