

# Generated at 2022-06-17 11:23:35.577443
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'

# Generated at 2022-06-17 11:23:48.000802
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%3a') == u':'
    assert unicode_urldecode('%3B') == u';'
    assert unicode_urldec

# Generated at 2022-06-17 11:23:59.540461
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%20%2F') == '/ /'
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20') == '/ / '
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20%2F') == '/ / /'

# Generated at 2022-06-17 11:24:08.697882
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'

# Generated at 2022-06-17 11:24:16.417047
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:23.106162
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:24:36.472182
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%20%C3%84%C3%96%C3%9C') == u'äöü ÄÖÜ'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%20%C3%84%C3%96%C3%9C%20%E2%82%AC') == u'äöü ÄÖÜ €'

# Generated at 2022-06-17 11:24:46.874970
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:24:58.285595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes as to_bytes_converter
    from ansible.module_utils.common.text.converters import to_text as to_text_converter
    from ansible.module_utils.common.text.converters import to_native as to_native_converter

# Generated at 2022-06-17 11:25:08.963203
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:17.242910
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo+bar'

# Generated at 2022-06-17 11:25:25.014393
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:25:37.805714
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'\u00e9+\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'\u00e9+\u00e9'

# Generated at 2022-06-17 11:25:44.660995
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test') == 'test'
    assert unicode_urlencode('test/') == 'test%2F'
    assert unicode_urlencode('test/', for_qs=True) == 'test%2F'
    assert unicode_urlencode('test/foo') == 'test%2Ffoo'
    assert unicode_urlencode('test/foo', for_qs=True) == 'test%2Ffoo'
    assert unicode_urlencode('test/foo/bar') == 'test%2Ffoo%2Fbar'
    assert unicode_urlencode('test/foo/bar', for_qs=True) == 'test%2Ffoo%2Fbar'

# Generated at 2022-06-17 11:25:54.676161
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:26:01.670135
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:07.817919
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-17 11:26:17.975538
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:26:21.367375
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:24.676484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:38.402716
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:41.235591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:51.339038
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('foo%20bar') == 'foo bar'
    assert FilterModule().filters()['urldecode']('foo+bar') == 'foo bar'
    assert FilterModule().filters()['urldecode']('foo%2Fbar') == 'foo/bar'
    assert FilterModule().filters()['urldecode']('foo%2fbar') == 'foo/bar'
    assert FilterModule().filters()['urldecode']('foo%2Fbar%3D') == 'foo/bar='
    assert FilterModule().filters()['urldecode']('foo%2fbar%3d') == 'foo/bar='

# Generated at 2022-06-17 11:26:54.447946
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:02.396914
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:27:12.718789
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.dicts import is_dict_subset
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_args
    from ansible.module_utils.common.text.formatters import to_nice_args_kwargs

# Generated at 2022-06-17 11:27:16.848250
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:27.218654
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%20%2F') == '/ /'
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20') == '/ / '
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20%2F') == '/ / /'

# Generated at 2022-06-17 11:27:34.171592
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'

# Generated at 2022-06-17 11:27:41.686457
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%20%2F') == '/ /'
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20%2F') == '/ / /'
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20%2F%20%2F') == '/ / / /'
   

# Generated at 2022-06-17 11:27:51.213120
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:00.080366
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode

# Generated at 2022-06-17 11:28:10.908795
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9') == u'é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9') == u'é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9') == u'é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9') == u'é & é'

# Generated at 2022-06-17 11:28:21.440985
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:31.048880
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2F%2F') == '///'

# Generated at 2022-06-17 11:28:40.985259
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:52.113163
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:28:57.714956
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4%20%C3%B6') == u'ä ö'
    assert unicode_urldecode(u'%C3%A4%20%C3%B6%20%C3%BC') == u'ä ö ü'
    assert unicode_urldecode(u'%C3%A4%20%C3%B6%20%C3%BC%20%C3%84%20%C3%96%20%C3%9C') == u'ä ö ü Ä Ö Ü'

# Generated at 2022-06-17 11:29:00.971747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:06.895409
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:29:19.117524
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:29.528353
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2b+%2B') == '+ +'
    assert fm.filters()['urldecode']('%2b+%2B') == '+ +'
    assert fm.filters()['urldecode']('%2b+%2B') == '+ +'
    assert fm.filters()['urldecode']('%2b+%2B') == '+ +'

# Generated at 2022-06-17 11:29:34.402792
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc:def') == u'abc%3Adef'
    assert unicode_urlencode(u'abc:def', for_qs=True) == u'abc%3Adef'
    assert unicode_urlencode(u'abc?def') == u

# Generated at 2022-06-17 11:29:45.099113
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'
    assert unicode_urlencode(u'http://example.com/?a=b', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3Db'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d') == u

# Generated at 2022-06-17 11:29:46.676672
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-17 11:29:56.644372
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F'.encode('utf-8')) == u'äöüß'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F'.encode('utf-8')) == u'äöüß'


# Generated at 2022-06-17 11:30:02.299999
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:30:12.094539
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == '/'
    assert do_urlencode('/foo bar/') == '/foo%20bar/'
    assert do_urlencode('/foo?bar/') == '/foo%3Fbar/'
    assert do_urlencode('/foo#bar/') == '/foo%23bar/'
    assert do_urlencode('/foo[bar]/') == '/foo%5Bbar%5D/'
    assert do_urlencode('/foo bar/') == '/foo%20bar/'
    assert do_urlencode('/foo&bar/') == '/foo%26bar/'
    assert do_urlencode('/foo=bar/') == '/foo=bar/'
    assert do_urlencode('/foo+bar/') == '/foo+bar/'

# Generated at 2022-06-17 11:30:14.584351
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urlencode'](' ') == '%20'

# Generated at 2022-06-17 11:30:23.887099
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%20%C3%84%C3%96%C3%9C') == u'äöü ÄÖÜ'

# Generated at 2022-06-17 11:30:54.964175
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%3f') == u'?'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldec

# Generated at 2022-06-17 11:30:58.241165
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:05.465184
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:31:14.595214
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:31:25.167857
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'\u00e9+\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'\u00e9+\u00e9'

# Generated at 2022-06-17 11:31:31.771347
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:36.385477
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:39.456105
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:48.212075
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_ur

# Generated at 2022-06-17 11:31:52.869777
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:32:43.529079
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/bar') == 'http%3A//foo/bar'
    assert unicode_urlencode('http://foo/bar', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode('http://foo/bar?a=1&b=2') == 'http%3A//foo/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode('http://foo/bar?a=1&b=2', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:32:50.248192
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:32:57.531927
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%C3%A9') == u'€é'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC') == u'€é€'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC%C3%A9') == u'€é€é'

# Generated at 2022-06-17 11:33:08.409587
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%84%C3%96%C3%9C') == u'äöüÄÖÜ'

# Generated at 2022-06-17 11:33:18.563839
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:33:26.040406
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%20%C3%B6') == u'ä ö'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC') == u'ä ö ü'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC%20%C3%84%20%C3%96%20%C3%9C') == u'ä ö ü Ä Ö Ü'