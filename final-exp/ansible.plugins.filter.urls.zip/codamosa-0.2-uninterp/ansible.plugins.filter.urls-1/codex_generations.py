

# Generated at 2022-06-17 11:23:35.930867
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:23:48.185462
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f%2F') == '//'
    assert unicode_urldecode('%2F%2f') == '//'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2f%2f') == '//'

# Generated at 2022-06-17 11:23:59.653131
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:24:08.817368
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%20%C3%84%C3%96%C3%9C') == u'äöü ÄÖÜ'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%20%C3%84%C3%96%C3%9C%20%E2%82%AC') == u'äöü ÄÖÜ €'

# Generated at 2022-06-17 11:24:16.485995
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'baz=qux&foo=bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'

# Generated at 2022-06-17 11:24:23.219562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F') == '/'

# Generated at 2022-06-17 11:24:36.533520
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2f%2f') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:24:46.966947
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode('%2F%2F%2F%2F') == '////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F') == '/////'
   

# Generated at 2022-06-17 11:24:53.355497
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:24:57.901462
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:09.093065
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:25:18.199362
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%2B%20%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß + äöüß'

# Generated at 2022-06-17 11:25:25.687317
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:31.699830
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E2%82%AC') == u'€'
    assert unicode_urldecode(u'%E2%82%AC%20') == u'€ '
    assert unicode_urldecode(u'%E2%82%AC%20%E2%82%AC') == u'€ €'
    assert unicode_urldecode(u'%E2%82%AC%20%E2%82%AC%20%E2%82%AC') == u'€ € €'
    assert unicode_urldecode(u'%E2%82%AC%20%E2%82%AC%20%E2%82%AC%20') == u'€ € € '

# Generated at 2022-06-17 11:25:42.177725
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/', for_qs=False) == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'

# Generated at 2022-06-17 11:25:53.056289
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert do_urlencode(u'http://example.com/foo bar') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar'
    assert do_urlencode(u'http://example.com/foo bar/') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar%2F'
    assert do_urlencode(u'http://example.com/foo bar/baz') == u'http%3A%2F%2Fexample.com%2Ffoo%20bar%2Fbaz'

# Generated at 2022-06-17 11:25:57.234595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-17 11:26:02.438190
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:07.158910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20') == u'é '
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:17.455922
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'

# Generated at 2022-06-17 11:26:28.627257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%E2%82%AC') == u'\u20ac'
    assert unicode_urldecode('%E2%82%AC%C3%A9') == u'\u20ac\u00e9'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC') == u'\u20ac\u00e9\u20ac'

# Generated at 2022-06-17 11:26:39.170102
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:45.367067
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:26:55.434040
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/foo bar/') == u'/foo%20bar/'
    assert unicode_urlencode('/foo bar/', for_qs=True) == u'/foo+bar/'
    assert unicode_urlencode('/foo?bar/') == u'/foo%3Fbar/'
    assert unicode_urlencode('/foo?bar/', for_qs=True) == u'/foo%3Fbar/'
    assert unicode_urlencode('/foo#bar/') == u'/foo%23bar/'
    assert unicode_urlencode('/foo#bar/', for_qs=True) == u'/foo%23bar/'

# Generated at 2022-06-17 11:27:02.927357
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc+def') == u'abc%2Bdef'

# Generated at 2022-06-17 11:27:12.743907
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:16.886363
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:22.039455
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:30.048628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:39.731580
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87+%E6%B5%8B%E8%AF%95') == u'中文+测试'

# Generated at 2022-06-17 11:27:57.200272
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:28:00.285562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:10.966800
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:28:21.504931
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:31.136765
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:28:40.989765
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:47.750449
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:28:57.848746
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%20%C3%B6') == u'ä ö'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC') == u'ä ö ü'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC%20%C3%84') == u'ä ö ü Ä'

# Generated at 2022-06-17 11:29:05.432870
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2f%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2f') == '//'

# Generated at 2022-06-17 11:29:14.114199
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'

# Generated at 2022-06-17 11:29:32.349275
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:38.827404
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:29:48.687040
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d') == u'http%3A//example.com/%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3Db%26c%3Dd'
    assert unicode_

# Generated at 2022-06-17 11:29:57.346632
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'

# Generated at 2022-06-17 11:30:02.974345
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%C3%84%C3%96%C3%9C%C3%9F') == u'äöüß ÄÖÜß'

# Generated at 2022-06-17 11:30:12.332189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2F%2F') == '///'

# Generated at 2022-06-17 11:30:18.925974
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo%2fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo%2Fbar%2Fbaz') == u'foo/bar/baz'
    assert unicode_urldecode(u'foo%2fbar%2fbaz') == u'foo/bar/baz'

# Generated at 2022-06-17 11:30:29.096812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert do_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'

# Generated at 2022-06-17 11:30:37.498509
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar baz') == 'foo+bar+baz'
    assert do_urlencode('foo bar+baz') == 'foo+bar%2Bbaz'
    assert do_urlencode('foo+bar baz') == 'foo%2Bbar+baz'
    assert do_urlencode('foo+bar+baz') == 'foo%2Bbar%2Bbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz/')

# Generated at 2022-06-17 11:30:47.893586
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/foo') == '/foo'
    assert unicode_urlencode('/foo bar') == '/foo%20bar'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo bar/baz') == '/foo%20bar/baz'
    assert unicode_urlencode('/foo bar/baz qux') == '/foo%20bar/baz%20qux'
    assert unicode_urlencode('/foo bar/baz qux/') == '/foo%20bar/baz%20qux/'

# Generated at 2022-06-17 11:31:27.018443
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:31:37.115369
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'


# Generated at 2022-06-17 11:31:43.611729
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:31:50.755551
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:31:59.613545
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo bar/baz') == u'foo+bar%2Fbaz'
    assert do_urlencode(u'foo bar/baz') == u'foo+bar%2Fbaz'
    assert do_urlencode(u'foo bar/baz') == u'foo+bar%2Fbaz'
    assert do_urlencode(u'foo bar/baz') == u'foo+bar%2Fbaz'

# Generated at 2022-06-17 11:32:10.822625
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode(u'%E2%82%AC') == u'€'
    assert unicode_urldecode(u'%E2%82%AC%C3%A4%C3%B6%C3%BC%C3%9F') == u'€äöüß'
    assert unicode_urldecode(u'%E2%82%AC%C3%A4%C3%B6%C3%BC%C3%9F%20%E2%82%AC') == u'€äöüß €'

# Generated at 2022-06-17 11:32:19.341533
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%2F%3D%26%25%C3%A9') == u'/=&%é'


# Generated at 2022-06-17 11:32:21.260278
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:29.177526
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:32:38.787146
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2F') == '//'