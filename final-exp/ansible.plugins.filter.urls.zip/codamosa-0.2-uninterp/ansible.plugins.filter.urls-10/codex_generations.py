

# Generated at 2022-06-17 11:23:35.515131
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:23:47.962012
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F') == '////'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F%2F') == '/////'
    assert FilterModule

# Generated at 2022-06-17 11:23:59.553757
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:24:10.302338
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/') == '/'
    assert unicode

# Generated at 2022-06-17 11:24:21.040456
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F') == u'/////'

# Generated at 2022-06-17 11:24:31.271139
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    assert do_urldecode('%20') == unquote_plus('%20')
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%2F') == unquote_plus('%2F')
    assert do_urldecode('%2F') != unquote_plus('%2f')
    assert do_

# Generated at 2022-06-17 11:24:41.959352
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:24:50.127146
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:24:59.867812
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:25:07.729793
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:25:13.121915
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    assert FilterModule().filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:25:22.892713
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.com/') == 'http%3A//www.example.com/'
    assert unicode_urlencode('http://www.example.com/', for_qs=True) == 'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode('http://www.example.com/?foo=bar') == 'http%3A//www.example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode('http://www.example.com/?foo=bar', for_qs=True) == 'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:36.134580
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:43.831179
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2f') == '//'
    assert do_urldecode('%2f%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_ur

# Generated at 2022-06-17 11:25:47.249309
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:52.023684
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:58.586905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:06.207534
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_ur

# Generated at 2022-06-17 11:26:17.075774
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'

# Generated at 2022-06-17 11:26:23.213058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:26:35.534042
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:38.402486
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:44.890408
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%3f') == '?'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%3d') == '='
   

# Generated at 2022-06-17 11:26:54.787402
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:02.666801
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:27:12.718665
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%C3%A9') == u'éé'
    assert unicode_urldecode('%C3%A9%C3%A9%C3%A9') == u'ééé'
    assert unicode_urldecode('%C3%A9%C3%A9%C3%A9%C3%A9') == u'éééé'
    assert unicode_urldecode('%C3%A9%C3%A9%C3%A9%C3%A9%C3%A9') == u'ééééé'

# Generated at 2022-06-17 11:27:16.823018
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%26%20%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß & äöüß'

# Generated at 2022-06-17 11:27:20.937207
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:27:29.945358
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u2713') == u'%E2%9C%93'
    assert unicode_urlencode(u'\u2713', for_qs=True) == u'%E2%9C%93'
    assert unicode_urlencode(u'\u2713', for_qs=False) == u'%E2%9C%93'
    assert unicode_urlencode(u'\u2713', for_qs=True) == u'%E2%9C%93'
    assert unicode_urlencode(u'\u2713', for_qs=False) == u'%E2%9C%93'

# Generated at 2022-06-17 11:27:36.066886
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:27:59.159534
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:28:07.561319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:18.179527
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f%2F') == u'/'
    assert unicode_urldecode('%2F%2f') == u'/'
    assert unicode_urldecode('%2F%2f%2F') == u'/'
    assert unicode_urldecode('%2F%2f%2F%2f') == u'/'
    assert unicode_ur

# Generated at 2022-06-17 11:28:25.502727
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:36.626370
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:28:46.050122
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:53.625007
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f%2F') == '//'
    assert do_urldecode('%2F%2f') == '//'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2f%2F') == '///'
    assert do_ur

# Generated at 2022-06-17 11:29:01.628463
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:29:07.503882
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:29:15.285934
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:29:49.716396
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:29:57.877932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2B%2B') == '++'
    assert FilterModule().filters()['urldecode']('%2b%2b') == '++'
    assert FilterModule().filters()['urldecode']('%2b%2B') == '+%2B'
    assert FilterModule().filters()['urldecode']('%2B%2b') == '+%2b'

# Generated at 2022-06-17 11:30:04.637880
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode('%2F%2F%2F%2F') == '////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F') == '/////'
   

# Generated at 2022-06-17 11:30:14.136404
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2F%2F') == '///'

# Generated at 2022-06-17 11:30:17.465100
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:27.385225
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == '{"foo":"bar"}'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'


# Generated at 2022-06-17 11:30:37.158887
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:30:47.893212
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%2B%20%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß + äöüß'

# Generated at 2022-06-17 11:30:57.849029
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\xe9 \xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\xe9 \xe9 \xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\xe9 \xe9 \xe9 \xe9'

# Generated at 2022-06-17 11:30:59.220046
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    assert FilterModule().filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:31:39.157200
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'

# Generated at 2022-06-17 11:31:48.187879
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:31:52.547321
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:32:00.008417
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://foo/bar?a=b&c=d') == 'http%3A%2F%2Ffoo%2Fbar%3Fa%3Db%26c%3Dd'
    assert do_urlencode('http://foo/bar?a=b&c=d') == do_urlencode({'a': 'b', 'c': 'd'}, 'http://foo/bar?')
    assert do_urlencode('http://foo/bar?a=b&c=d') == do_urlencode(['a=b', 'c=d'], 'http://foo/bar?')

# Generated at 2022-06-17 11:32:10.841558
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:32:16.243283
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:23.837405
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2f%2f%2f') == u'///'

# Generated at 2022-06-17 11:32:36.964524
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%20') == '/ '
    assert do_urldecode('%2F%20%2F') == '/ /'
    assert do_urldecode('%2F%20%2F%20') == '/ / '
    assert do_urldecode('%2F%20%2F%20%2F') == '/ / /'
    assert do_urldecode('%2F%20%2F%20%2F%20') == '/ / / '
    assert do_urldecode('%2F%20%2F%20%2F%20%2F') == '/ / / /'
    assert do_

# Generated at 2022-06-17 11:32:43.171087
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:50.231360
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'