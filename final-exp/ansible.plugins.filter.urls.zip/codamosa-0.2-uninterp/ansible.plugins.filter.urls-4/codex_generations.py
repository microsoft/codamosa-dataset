

# Generated at 2022-06-17 11:23:36.154684
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2f%2f%2f') == u'///'

# Generated at 2022-06-17 11:23:48.280427
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_ur

# Generated at 2022-06-17 11:23:57.310458
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:05.381088
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:14.676825
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/b ar') == u'http%3A//foo/b%20ar'
    assert unicode_urlencode(u'http://foo/b ar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fb+ar'
    assert unicode_urlencode(u'http://foo/b ar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fb+ar'


# Generated at 2022-06-17 11:24:25.546584
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A//example.com/foo%20bar'

# Generated at 2022-06-17 11:24:37.158031
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo.com/bar') == u'http%3A//foo.com/bar'
    assert unicode_urlencode(u'http://foo.com/bar', for_qs=True) == u'http%3A%2F%2Ffoo.com%2Fbar'
    assert unicode_urlencode(u'http://foo.com/bar?a=1&b=2') == u'http%3A//foo.com/bar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:24:47.461787
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A//example.com/foo%20bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo+bar'

# Generated at 2022-06-17 11:24:58.630181
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text

    f = FilterModule()
    filters = f.filters()

    # Test urldecode
    assert filters['urldecode']('%20') == ' '
    assert filters['urldecode']('%2B') == '+'
    assert filters['urldecode']('%2b') == '+'
    assert filters['urldecode']('%2F') == '/'
    assert filters['urldecode']('%2f') == '/'
    assert filters['urldecode']('%3D') == '='
    assert filters['urldecode']('%3d') == '='

# Generated at 2022-06-17 11:25:08.996368
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:25:15.615231
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:25:19.978158
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-17 11:25:22.892440
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:25:36.135147
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/fiz?buz=1') == u'http%3A//example.com/fiz%3Fbuz%3D1'
    assert unicode_urlencode(u'http://example.com/fiz?buz=1', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffiz%3Fbuz%3D1'
    assert unicode_urlencode(u'http://example.com/fiz?buz=1', for_qs=False) == u'http%3A//example.com/fiz%3Fbuz%3D1'

# Generated at 2022-06-17 11:25:40.463221
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9') == u'é'

# Generated at 2022-06-17 11:25:46.564585
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldec

# Generated at 2022-06-17 11:25:56.425962
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2f%2F') == '//'

# Generated at 2022-06-17 11:26:05.418069
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F')

# Generated at 2022-06-17 11:26:09.100599
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'

# Generated at 2022-06-17 11:26:19.032454
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:38.168380
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/bar') == 'http%3A//foo/bar'
    assert unicode_urlencode('http://foo/bar', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar') == 'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://føø/bår') == 'http%3A//f%C3%B8%C3%B8/b%C3%A5r'

# Generated at 2022-06-17 11:26:41.101216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:51.184613
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E7%B5%8C%E8%AA%9E') == u'中文 経語'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E7%B5%8C%E8%AA%9E%20%E6%96%87%E5%AD%97') == u'中文 経語 文字'

# Generated at 2022-06-17 11:26:59.514466
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%20%C3%B6') == u'ä ö'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC') == u'ä ö ü'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC%20%C3%84%20%C3%96%20%C3%9C') == u'ä ö ü Ä Ö Ü'

# Generated at 2022-06-17 11:27:05.826705
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2f%2f') == '//'
    assert unicode_urldecode('%2F%2f') == '//'
    assert unicode_urldecode('%2f%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode('%2f%2f%2f') == '///'
    assert unicode_urldec

# Generated at 2022-06-17 11:27:13.345640
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2f%2f%2f') == u'///'

# Generated at 2022-06-17 11:27:19.773882
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:29.847282
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d') == u'http%3A//example.com/%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3Db%26c%3Dd'
    assert unicode_

# Generated at 2022-06-17 11:27:39.481754
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:27:46.407440
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:28:10.805869
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldec

# Generated at 2022-06-17 11:28:21.333704
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:30.930835
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A%2F%2Fexample.com%2F'
    assert do_urlencode(u'http://example.com/?a=b&c=d') == u'http%3A%2F%2Fexample.com%2F%3Fa%3Db%26c%3Dd'
    assert do_urlencode(u'http://example.com/?a=b&c=d') == do_urlencode({u'a': u'b', u'c': u'd'})
    assert do_urlencode(u'http://example.com/?a=b&c=d') == do_urlencode([u'a=b', u'c=d'])

# Generated at 2022-06-17 11:28:37.043189
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:42.403756
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:43.819014
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:28:52.320737
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%2C%20%C3%A9') == u'é é, é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%2C%20%C3%A9%20%C3%A9') == u'é é, é é'

# Generated at 2022-06-17 11:29:00.253740
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F') == '////'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F%2F') == '/////'
    assert FilterModule

# Generated at 2022-06-17 11:29:07.417844
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%3B') == u';'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%40') == u'@'
    assert unicode_urldecode('%5B') == u'['
    assert unicode_urldecode

# Generated at 2022-06-17 11:29:15.226478
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F') == '////'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F%2F%2F') == '/////'

# Generated at 2022-06-17 11:29:56.442288
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:30:02.264285
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar baz') == u'foo%20bar%20baz'
    assert unicode_urlencode(u'foo bar baz', for_qs=True) == u'foo+bar+baz'

# Generated at 2022-06-17 11:30:08.795954
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:30:16.885801
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus, unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.jinja2.filters import FilterModule

    class FilterModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.filter_module = FilterModule()

        def tearDown(self):
            pass

        def test_urldecode(self):
            self.assertEqual(self.filter_module.filters()['urldecode']('%20'), ' ')

# Generated at 2022-06-17 11:30:26.656029
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlen

# Generated at 2022-06-17 11:30:31.610657
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6') == u'äö'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%84%C3%96%C3%9C') == u'äöüÄÖÜ'

# Generated at 2022-06-17 11:30:39.745389
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'

# Generated at 2022-06-17 11:30:44.232117
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:49.333660
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:58.400081
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    fm = FilterModule()
    filters = fm.filters()

    assert filters['urldecode']('%20') == ' '
    assert filters['urldecode']('%2F') == '/'
    assert filters['urldecode']('%2f') == '/'
    assert filters['urldecode']('%2F%2F') == '//'
    assert filters['urldecode']('%2F%2f') == '//'


# Generated at 2022-06-17 11:32:10.822892
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:32:19.742102
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:32:28.291198
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar&baz=qux') == u'http%3A//example.com/%3Ffoo%3Dbar%26baz%3Dqux'

# Generated at 2022-06-17 11:32:38.459441
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2B%2B') == '++'
    assert do_urldecode('%2b%2b') == '++'
    assert do_urldecode('%2B%2b') == '++'
    assert do_urldecode('%2b%2B') == '++'
    assert do_urldecode('%2B%2B%2B') == '+++'
    assert do_urldecode('%2b%2b%2b') == '+++'

# Generated at 2022-06-17 11:32:47.369958
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'

# Generated at 2022-06-17 11:32:56.240770
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2B%2B') == '++'
    assert FilterModule().filters()['urldecode']('%2b%2b') == '++'
    assert FilterModule().filters()['urldecode']('%2B%2b') == '++'
    assert FilterModule().filters()['urldecode']('%2b%2B') == '++'

# Generated at 2022-06-17 11:33:07.511547
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 11:33:15.384574
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:33:20.321398
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
