

# Generated at 2022-06-17 11:23:37.092551
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar') == u'http%3A//www.example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'
    assert unicode_urlen

# Generated at 2022-06-17 11:23:48.376651
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:23:59.725180
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:10.440660
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%C3%A9') == u'€é'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC') == u'€é€'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC%C3%A9') == u'€é€é'

# Generated at 2022-06-17 11:24:13.981041
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:24:20.389615
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:24:31.213993
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:41.754463
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:24:45.450278
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:24:52.151498
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:25:01.705840
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:25:09.225770
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'


# Generated at 2022-06-17 11:25:18.357976
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:25.790242
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/foo/bar') == '/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo bar/', for_qs=True) == '%2Ffoo%20bar%2F'
    assert unicode_urlencode('/foo bar/baz') == '/foo%20bar/baz'

# Generated at 2022-06-17 11:25:31.773597
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:41.377584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%C3%A9') == u'éé'

# Generated at 2022-06-17 11:25:46.989865
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f%2F') == u'/'
    assert unicode_urldecode('%2F%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'/'
    assert unicode_urldecode('%2F%2F%2F') == u'/'

# Generated at 2022-06-17 11:25:51.486351
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:01.703256
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:05.124557
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-17 11:26:18.806106
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%20%2F') == '/ /'
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20') == '/ / '
    assert FilterModule().filters()['urldecode']('%2F%20%2F%20%2F') == '/ / /'

# Generated at 2022-06-17 11:26:26.588333
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-17 11:26:38.121203
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%3D') == '='
    assert FilterModule().filters()['urldecode']('%3d') == '='
    assert FilterModule().filters()['urldecode']('%26') == '&'
    assert FilterModule().filters()['urldecode']

# Generated at 2022-06-17 11:26:44.720152
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:26:54.636431
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%3d') == '='
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%3F') == '?'
    assert do_urldecode('%3f') == '?'

# Generated at 2022-06-17 11:27:02.517854
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:27:08.981401
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:14.524785
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'
    assert unicode_urldecode('%C3%A9%20') == u'\xe9 '
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\xe9 \xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20') == u'\xe9 \xe9 '
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\xe9 \xe9 \xe9'

# Generated at 2022-06-17 11:27:25.157636
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%E6%B5%8B%E8%AF%95') == u'中文测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%E6%B5%8B%E8%AF%95%E6%B5%8B%E8%AF%95') == u'中文测试测试'

# Generated at 2022-06-17 11:27:32.433696
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo?bar') == u'foo%3Fbar'
    assert do_urlencode(u'foo#bar') == u'foo%23bar'

# Generated at 2022-06-17 11:27:43.202550
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:27:46.072576
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:27:56.296108
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldec

# Generated at 2022-06-17 11:27:59.416661
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:07.921522
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9') == u'é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9%20%26%20%C3%A9') == u'é & é & é'
    assert unicode_urldecode('%C3%A9%20%26%20%C3%A9%20%26%20%C3%A9%20%26%20%C3%A9') == u'é & é & é & é'

# Generated at 2022-06-17 11:28:15.546745
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:28:20.550621
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:28:29.868748
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/bar') == 'http%3A//foo/bar'
    assert unicode_urlencode('http://foo/bar', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode('http://foo/bar?a=1&b=2') == 'http%3A//foo/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode('http://foo/bar?a=1&b=2', for_qs=True) == 'http%3A%2F%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:28:35.355094
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-17 11:28:38.317028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:56.152371
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:03.320257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2F%2F%2F%2F') == u'////'

# Generated at 2022-06-17 11:29:13.710818
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('foo%20bar') == 'foo bar'
    assert FilterModule().filters()['urldecode']('foo+bar') == 'foo bar'
    assert FilterModule().filters()['urldecode']('foo%2Bbar') == 'foo+bar'
    assert FilterModule().filters()['urldecode']('foo%2bbar') == 'foo+bar'
    assert FilterModule().filters()['urldecode']('foo%2Bbar%2Bbaz') == 'foo+bar+baz'
    assert FilterModule().filters()['urldecode']('foo%2bbar%2bbaz') == 'foo+bar+baz'

# Generated at 2022-06-17 11:29:19.873481
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('foo%20bar') == 'foo bar'
    assert fm.filters()['urldecode']('foo+bar') == 'foo bar'
    assert fm.filters()['urldecode']('foo%2Fbar') == 'foo/bar'
    assert fm.filters()['urldecode']('foo%2fbar') == 'foo/bar'
    assert fm.filters()['urldecode']('foo%2Fbar%2Fbaz') == 'foo/bar/baz'
    assert fm.filters()['urldecode']('foo%2fbar%2fbaz') == 'foo/bar/baz'

# Generated at 2022-06-17 11:29:28.217527
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%7E') == u'~'
    assert unicode_urldecode('%7e') == u'~'
    assert unicode_urldecode('%7E%20%25') == u'~ %'
    assert unicode_urldecode('%7e%20%25') == u'~ %'
    assert unicode_urldecode('%7E%20%25%7E') == u'~ %~'
    assert unicode_urldecode('%7e%20%25%7e') == u'~ %~'

# Generated at 2022-06-17 11:29:35.769581
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2f%2f%2f') == u'///'

# Generated at 2022-06-17 11:29:46.243334
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:29:56.579201
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/foo') == '/foo'
    assert unicode_urlencode('/foo', for_qs=True) == '%2Ffoo'
    assert unicode_urlencode('/foo/bar') == '/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo/bar/') == '/foo/bar/'
    assert unicode_urlencode('/foo/bar/', for_qs=True) == '%2Ffoo%2Fbar%2F'
    assert unicode_

# Generated at 2022-06-17 11:30:02.226440
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%3D') == '='
    assert FilterModule().filters()['urldecode']('%3d') == '='
    assert FilterModule().filters()['urldecode']('%26') == '&'
    assert FilterModule().filters()['urldecode']

# Generated at 2022-06-17 11:30:06.383572
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:43.132894
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%F0%9D%84%9E') == u'𝄞'

# Generated at 2022-06-17 11:30:50.800798
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:30:59.572649
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f%2F') == '//'
    assert unicode_urldecode('%2F%2f') == '//'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2f%2f') == '//'
    assert unicode_urldecode('%2f%2F%2f')

# Generated at 2022-06-17 11:31:06.566262
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert do_urlencode(u'http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'
    assert do_urlencode(u'http://example.com/?a=b&c=d') == u'http%3A//example.com/%3Fa%3Db%26c%3Dd'
    assert do_urlencode(u'http://example.com/?a=b&c=d&e=f') == u'http%3A//example.com/%3Fa%3Db%26c%3Dd%26e%3Df'

# Generated at 2022-06-17 11:31:14.048296
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2') == u'http%3A//foo/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:31:24.640665
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:31:36.008167
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'
    assert do_urlencode(('foo', 'bar', 'baz')) == 'foo&bar&baz'

# Generated at 2022-06-17 11:31:42.745605
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert do_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'

# Generated at 2022-06-17 11:31:48.921089
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc?def') == u'abc%3Fdef'
    assert unicode_urlencode(u'abc?def', for_qs=True) == u'abc%3Fdef'
    assert unicode_urlencode(u'abc&def') == u

# Generated at 2022-06-17 11:31:57.354210
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%3D') == '='
    assert fm.filters()['urldecode']('%3d') == '='
    assert fm.filters()['urldecode']('%26') == '&'
    assert fm.fil

# Generated at 2022-06-17 11:33:00.856982
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-17 11:33:09.085035
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldec

# Generated at 2022-06-17 11:33:18.587172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:33:26.040593
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E2%9C%93') == u'✓'
    assert unicode_urldecode(u'%E2%9C%93%E2%9C%93') == u'✓✓'
    assert unicode_urldecode(u'%E2%9C%93%E2%9C%93%E2%9C%93') == u'✓✓✓'
    assert unicode_urldecode(u'%E2%9C%93%E2%9C%93%E2%9C%93%E2%9C%93') == u'✓✓✓✓'