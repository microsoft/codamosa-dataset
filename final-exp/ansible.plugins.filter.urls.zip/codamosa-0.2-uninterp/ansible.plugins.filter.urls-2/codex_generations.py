

# Generated at 2022-06-17 11:23:31.388378
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:23:36.110432
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:23:48.244961
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u

# Generated at 2022-06-17 11:23:57.309794
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:24:05.379917
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:24:14.676753
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:25.768810
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo?bar') == u

# Generated at 2022-06-17 11:24:37.220726
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:24:47.718586
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'%2b') == u'+'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2F%2F') == u'//'
    assert unicode_urldecode(u'%2F%2F%2F') == u'///'
    assert unicode_urldecode(u'%2F%2F%2F%2F') == u'////'
    assert unicode_urldecode

# Generated at 2022-06-17 11:24:57.630750
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%23') == u'#'
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%40') == u'@'
    assert unicode_urldecode

# Generated at 2022-06-17 11:25:09.029421
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?x=1&y=2') == u'http%3A//example.com/%3Fx%3D1%26y%3D2'
    assert unicode_urlencode(u'http://example.com/?x=1&y=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fx%3D1%26y%3D2'
   

# Generated at 2022-06-17 11:25:18.122517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F%20') == '/ '
    assert FilterModule().filters()['urldecode']('%2F%20%2F') == '/ /'

# Generated at 2022-06-17 11:25:25.617812
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:37.959035
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/foo') == '/foo'
    assert unicode_urlencode('/foo', for_qs=True) == '%2Ffoo'
    assert unicode_urlencode('/foo/') == '/foo/'
    assert unicode_urlencode('/foo/', for_qs=True) == '%2Ffoo%2F'
    assert unicode_urlencode('/foo/bar') == '/foo/bar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo/bar/')

# Generated at 2022-06-17 11:25:44.768697
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'

# Generated at 2022-06-17 11:25:54.743558
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode('%2F%2F%2F%2F') == '////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert unicode_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'
    assert unicode

# Generated at 2022-06-17 11:26:01.692395
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'

# Generated at 2022-06-17 11:26:12.471595
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:26:19.835920
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(['foo', 'bar/baz']) == 'foo&bar%2Fbaz'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar/baz'}) == 'foo=bar%2Fbaz'

# Generated at 2022-06-17 11:26:24.767071
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2f%2f%2f') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2f%2f%2f%2f') == '////'

# Generated at 2022-06-17 11:26:33.629868
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:41.039574
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/foo') == u'http%3A//example.com/foo'
    assert unicode_urlencode(u'http://example.com/foo', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo'
    assert unicode_urlencode(u'http://example.com/foo bar') == u'http%3A//example.com/foo%20bar'
    assert unicode_urlencode(u'http://example.com/foo bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2Ffoo+bar'

# Generated at 2022-06-17 11:26:51.109253
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:26:59.447572
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2B%2B') == '++'
    assert fm.filters()['urldecode']('%2b%2b') == '++'
    assert fm.filters()['urldecode']('%2B%2b') == '++'
    assert fm.filters()['urldecode']('%2b%2B') == '++'

# Generated at 2022-06-17 11:27:08.055246
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%3A') == u':'
    assert unicode_urldecode('%3a') == u':'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldec

# Generated at 2022-06-17 11:27:18.048039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule

# Generated at 2022-06-17 11:27:21.695515
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:30.010964
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2') == u'http%3A//foo/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:27:35.727176
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:27:45.223989
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc?def') == u'abc%3Fdef'
    assert unicode_urlencode(u'abc?def', for_qs=True) == u'abc%3Fdef'
    assert unicode_urlencode(u'abc&def') == u

# Generated at 2022-06-17 11:27:54.450595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:27:59.511747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:28:08.068215
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.org/') == u'http%3A//example.org/'
    assert unicode_urlencode(u'http://example.org/', for_qs=True) == u'http%3A%2F%2Fexample.org%2F'
    assert unicode_urlencode(u'http://example.org/', for_qs=False) == u'http%3A//example.org/'
    assert unicode_urlencode(u'http://example.org/?foo=bar') == u'http%3A//example.org/%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:28:18.553937
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:28:23.186514
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:36.416967
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2F') == '/'

# Generated at 2022-06-17 11:28:42.081007
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:28:48.476968
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'

# Generated at 2022-06-17 11:28:54.716555
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2F%2F%2F%2F') == '////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == '/////'
    assert do_urldecode('%2F%2F%2F%2F%2F%2F') == '//////'

# Generated at 2022-06-17 11:29:01.673634
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2') == u'http%3A//foo/bar%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://foo/bar?a=1&b=2', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar%3Fa%3D1%26b%3D2'

# Generated at 2022-06-17 11:29:15.285674
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/foo bar/') == '/foo%20bar/'
    assert unicode_urlencode('/foo bar/?baz=qux') == '/foo%20bar/?baz=qux'
    assert unicode_urlencode('/foo bar/?baz=qux', for_qs=True) == '/foo+bar/?baz=qux'
    assert unicode_urlencode('/foo bar/?baz=qux&zap=zazzle') == '/foo%20bar/?baz=qux&zap=zazzle'

# Generated at 2022-06-17 11:29:17.426401
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:29:23.718112
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%25') == '%'
    assert fm.filters()['urldecode']('%2B') == '+'
    assert fm.filters()['urldecode']('%2b') == '+'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%3d') == '='
    assert fm.filters()['urldecode']('%3D') == '='
    assert fm.fil

# Generated at 2022-06-17 11:29:35.450936
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:29:45.916915
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc/def') == u'abc%2Fdef'
    assert unicode_urlencode(u'abc/def', for_qs=True) == u'abc%2Fdef'
    assert unicode_urlencode(u'abc?def') == u'abc%3Fdef'
    assert unicode_urlencode(u'abc?def', for_qs=True) == u'abc%3Fdef'
    assert unicode_urlencode(u'abc&def') == u

# Generated at 2022-06-17 11:29:56.512447
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar') == u'http%3A//www.example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'
    assert unicode_urlen

# Generated at 2022-06-17 11:30:00.526391
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%23') == u'#'
    assert unicode_urldecode('%5B') == u'['
    assert unicode_urldecode('%5D') == u']'
    assert unicode_urldecode

# Generated at 2022-06-17 11:30:06.051392
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:30:15.036674
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'

# Generated at 2022-06-17 11:30:24.642033
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.urls
    import ansible.module_utils.urls.__init__
    import ansible.module_utils.urls.common
    import ansible.module_utils.urls.url_encoder
    import ansible.module_utils.urls.url_encoder.__init__
    import ansible.module_utils.urls.url_encoder.FilterModule
    import ansible.module_utils.urls.url_encoder.FilterModule.test_FilterModule_filters

# Generated at 2022-06-17 11:30:39.038095
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.six.moves.urllib.parse import urlunsplit

    # Test urldecode
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2B') == '+'
    assert FilterModule().filters()['urldecode']('%2b') == '+'

# Generated at 2022-06-17 11:30:48.060957
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%2F%2F') == u'//'
    assert unicode_urldecode(u'%2f%2f') == u'//'
    assert unicode_urldecode(u'%2F%2f') == u'//'
    assert unicode_urldecode(u'%2f%2F') == u'//'
    assert unicode_urldecode(u'%2F%2F%2F') == u'///'
    assert unicode_urldecode

# Generated at 2022-06-17 11:30:57.970628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:31:00.366946
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:31:07.063915
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar') == u'http%3A//www.example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar'
    assert unicode_urlen

# Generated at 2022-06-17 11:31:14.102059
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%3D') == '='
    assert do_urldecode('%3d') == '='
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%3F') == '?'
    assert do_urldecode('%3f') == '?'

# Generated at 2022-06-17 11:31:24.640807
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2') == u'http%3A//example.com/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com/?a=1&b=2', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3D1%26b%3D2'
    assert unic

# Generated at 2022-06-17 11:31:37.794308
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode(u'http://www.example.com/', for_qs=False) == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/?foo=bar') == u'http%3A//www.example.com/%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:31:44.120957
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'
    assert unicode_urlencode(u'http://example.com/?a=b', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3Db'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d') == u

# Generated at 2022-06-17 11:31:50.589283
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:09.363376
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:32:19.158458
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(['foo', 'bar baz']) == 'foo&bar+baz'
    assert do_urlencode(['foo', 'bar+baz']) == 'foo&bar%2Bbaz'
    assert do_urlencode(['foo', 'bar%2Bbaz']) == 'foo&bar%252Bbaz'

# Generated at 2022-06-17 11:32:28.036666
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode(['foo', 'bar baz']) == 'foo&bar+baz'
    assert do_urlencode(['foo', 'bar/baz']) == 'foo&bar%2Fbaz'
    assert do_urlencode(['foo', 'bar baz/qux']) == 'foo&bar+baz%2Fqux'
    assert do_url

# Generated at 2022-06-17 11:32:33.722959
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:32:43.586719
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%20') == ' '
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2f') == '/'
    assert fm.filters()['urldecode']('%2F%2F') == '//'
    assert fm.filters()['urldecode']('%2F%2F%2F') == '///'
    assert fm.filters()['urldecode']('%2F%2F%2F%2F') == '////'

# Generated at 2022-06-17 11:32:48.321034
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9'.encode('utf-8')) == u'é'
    assert unicode_urldecode(u'%C3%A9'.encode('latin-1')) == u'Ã©'


# Generated at 2022-06-17 11:32:56.067985
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_

# Generated at 2022-06-17 11:32:58.196995
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:33:08.756186
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:33:18.588165
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%26%C3%A9') == u'é&é'
    assert unicode_urldecode('%C3%A9%26%C3%A9') == u'é&é'
    assert unicode_urldecode('%C3%A9%26%C3%A9') == u'é&é'