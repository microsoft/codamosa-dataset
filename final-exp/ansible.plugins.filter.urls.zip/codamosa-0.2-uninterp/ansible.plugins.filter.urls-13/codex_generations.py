

# Generated at 2022-06-17 11:23:36.602428
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:23:48.347578
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:23:59.725443
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%C3%A9') == u'€é'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC') == u'€é€'
    assert unicode_urldecode('%E2%82%AC%C3%A9%E2%82%AC%C3%A9') == u'€é€é'

# Generated at 2022-06-17 11:24:10.440493
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'
    assert do_url

# Generated at 2022-06-17 11:24:17.023141
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:24:20.877563
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:24:31.244062
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%20%C3%B6') == u'ä ö'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC') == u'ä ö ü'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC%20%C3%9F') == u'ä ö ü ß'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC%20%C3%9F%20%C3%84') == u

# Generated at 2022-06-17 11:24:39.514988
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%84%C3%96%C3%9C') == u'äöüÄÖÜ'

# Generated at 2022-06-17 11:24:44.816945
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule

# Generated at 2022-06-17 11:24:47.248884
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    # assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:24:59.223706
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_ur

# Generated at 2022-06-17 11:25:00.713128
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'


# Generated at 2022-06-17 11:25:09.150719
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:25:18.276472
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:25:25.735973
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F%20') == u'äöüßÄÖÜß '

# Generated at 2022-06-17 11:25:31.750474
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:25:41.357072
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%3f') == u'?'
    assert unicode_urldec

# Generated at 2022-06-17 11:25:46.529388
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9+%C3%A9') == u'é é é'


# Generated at 2022-06-17 11:25:56.392800
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode(u'%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode(u'%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:25:59.520927
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-17 11:26:04.355459
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urlencode'](' ') == '%20'

# Generated at 2022-06-17 11:26:09.127791
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:14.557643
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:26:21.580953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%C3%A9') == u'\u00e9'
    assert FilterModule().filters()['urldecode']('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert FilterModule().filters()['urldecode']('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'

# Generated at 2022-06-17 11:26:29.107784
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:26:39.316528
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%2F%2F') == u'//'
    assert unicode_urldecode(u'%2f%2f') == u'//'
    assert unicode_urldecode(u'%2F%2f') == u'//'
    assert unicode_urldecode(u'%2f%2F') == u'//'
    assert unicode_urldecode(u'%2F%2F%2F') == u'///'
    assert unicode_urldecode

# Generated at 2022-06-17 11:26:45.430089
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f%2F') == '//'
    assert do_urldecode('%2F%2f') == '//'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2f%2F%2f') == '///'
    assert do_ur

# Generated at 2022-06-17 11:26:55.477006
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:27:00.471243
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%2B%C3%A9') == u'é+é'


# Generated at 2022-06-17 11:27:03.601154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:19.219432
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\xe9 \xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\xe9 \xe9 \xe9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'\xe9 \xe9 \xe9 \xe9'

# Generated at 2022-06-17 11:27:25.735036
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'

# Generated at 2022-06-17 11:27:30.619532
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:27:32.500973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:27:41.612483
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9+%C3%A9') == u'é é é'

# Generated at 2022-06-17 11:27:51.391039
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%26%20%C3%A9') == u'é & é'

# Generated at 2022-06-17 11:28:00.219361
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:06.976137
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:17.718840
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:28:22.857113
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence

    fm = FilterModule()
    filters = fm.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode

    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2B') == u'+'

    if not HAS_URLENCODE:
        assert do_url

# Generated at 2022-06-17 11:28:46.023980
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F%20%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß äöüß'

# Generated at 2022-06-17 11:28:51.617212
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'


# Generated at 2022-06-17 11:28:57.270931
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%C3%A9') == u'éé'
    assert unicode_urldecode(u'%C3%A9%C3%A9%C3%A9') == u'ééé'
    assert unicode_urldecode(u'%C3%A9%C3%A9%C3%A9%C3%A9') == u'éééé'
    assert unicode_urldecode(u'%C3%A9%C3%A9%C3%A9%C3%A9%C3%A9') == u'ééééé'
    assert unicode

# Generated at 2022-06-17 11:29:05.053415
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4%C3%B6%C3%BC%C3%9F%C3%84%C3%96%C3%9C%C3%9F') == u'äöüßÄÖÜß'

# Generated at 2022-06-17 11:29:14.079514
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:29:20.161816
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode('foo bar/baz') == 'foo+bar%2Fbaz'
    assert do_urlencode({'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert do_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'
    assert do_urlencode(('foo', 'bar', 'baz')) == 'foo&bar&baz'

# Generated at 2022-06-17 11:29:29.595206
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?foo=bar') == u'http%3A//example.com/%3Ffoo%3Dbar'
    assert unicode_urlencode(u'http://example.com/?foo=bar', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar'

# Generated at 2022-06-17 11:29:36.405211
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%2F%3D%26%25%7E') == '/=&%~'
    assert unicode_urldecode('%2F%3D%26%25%7E%20') == '/=&%~ '
    assert unicode_ur

# Generated at 2022-06-17 11:29:42.016245
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:29:43.478662
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:30:02.298951
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo/bar') == u'http%3A//foo/bar'
    assert unicode_urlencode(u'http://foo/bar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar'
    assert unicode_urlencode(u'http://foo/b ar') == u'http%3A//foo/b%20ar'
    assert unicode_urlencode(u'http://foo/b ar', for_qs=True) == u'http%3A%2F%2Ffoo%2Fb+ar'
    assert unicode_urlencode(u'http://foo/b+ar') == u'http%3A//foo/b%2Bar'

# Generated at 2022-06-17 11:30:06.383942
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:15.286230
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u20ac') == u'%E2%82%AC'
    assert unicode_urlencode(u'\u20ac', for_qs=True) == u'%E2%82%AC'
    assert unicode_urlencode(u'\u20ac', for_qs=False) == u'%E2%82%AC'
    assert unicode_urlencode(u'\u20ac', for_qs=True) == u'%E2%82%AC'
    assert unicode_urlencode(u'\u20ac', for_qs=False) == u'%E2%82%AC'
    assert unicode_urlencode(u'\u20ac', for_qs=True) == u'%E2%82%AC'
   

# Generated at 2022-06-17 11:30:24.926702
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95') == u'中文 测试'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87%20%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95') == u'中文 测试 测试'

# Generated at 2022-06-17 11:30:33.814954
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20') == ' '
    assert FilterModule().filters()['urldecode']('%2F') == '/'
    assert FilterModule().filters()['urldecode']('%2f') == '/'
    assert FilterModule().filters()['urldecode']('%2F%2F') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2f') == '//'
    assert FilterModule().filters()['urldecode']('%2F%2F%2F') == '///'
    assert FilterModule().filters()['urldecode']('%2F%2F%2f') == '///'

# Generated at 2022-06-17 11:30:37.547911
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:46.671324
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%3C%3E%3F%3A%40%26%3D%2B%24%2C%2F%3B%3F%23%5B%5D') == '<>?:@&=+$,/?;?#[]'
    assert FilterModule().filters()['urlencode']('<>?:@&=+$,/?;?#[]') == '%3C%3E%3F%3A%40%26%3D%2B%24%2C%2F%3B%3F%23%5B%5D'

# Generated at 2022-06-17 11:30:51.030177
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-17 11:30:59.778186
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test the urldecode filter
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%20bar') == 'foo bar'
    assert do_urldecode('foo%2Fbar') == 'foo/bar'
    assert do_urldecode('foo%2Fbar%2Fbaz') == 'foo/bar/baz'

    # Test the urlencode filter
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'

# Generated at 2022-06-17 11:31:04.418319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%2B%C3%A9') == u'é+é'
    assert unicode_urldecode(u'%C3%A9%2b%C3%A9') == u'é+é'
    assert unicode_urldecode(u'%C3%A9%2B%C3%A9') == u'é+é'

# Generated at 2022-06-17 11:31:40.839669
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9+%C3%A9') == u'é é'

# Generated at 2022-06-17 11:31:45.585068
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with Jinja2 v2.7 or later
    if HAS_URLENCODE:
        fm = FilterModule()
        assert fm.filters()['urlencode'] == do_urlencode

    # Test with Jinja2 older than v2.7
    else:
        fm = FilterModule()
        assert fm.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-17 11:31:54.645670
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2B') == u'+'
    assert do_urldecode('%2b') == u'+'
    assert do_urldecode('%2f') == u'/'
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%2F%2F') == u'//'
    assert do_urldecode('%2F%2F%2F') == u'///'
    assert do_urldecode('%2F%2F%2F%2F') == u'////'
    assert do_urldecode('%2F%2F%2F%2F%2F') == u'/////'
   

# Generated at 2022-06-17 11:32:02.763215
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2f%2f') == u'//'
    assert unicode_urldecode('%2F%2f') == u'//'
    assert unicode_urldecode('%2f%2F') == u'//'
    assert unicode_urldecode('%2F%2F%2F') == u'///'
    assert unicode_urldecode('%2f%2f%2f') == u'///'

# Generated at 2022-06-17 11:32:12.977893
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%2B') == '+'
    assert do_urldecode('%2b') == '+'
    assert do_urldecode('%2F') == '/'
    assert do_urldecode('%2f') == '/'
    assert do_urldecode('%2f%2f') == '//'
    assert do_urldecode('%2F%2F') == '//'
    assert do_urldecode('%2F%2F%2F') == '///'
    assert do_urldecode('%2f%2f%2f') == '///'

# Generated at 2022-06-17 11:32:23.012415
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:32:36.748061
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http%3A//example.com/'
    assert unicode_urlencode(u'http://example.com/', for_qs=True) == u'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode(u'http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'
    assert unicode_urlencode(u'http://example.com/?a=b', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%3Db'
    assert unicode_urlencode(u'http://example.com/?a=b&c=d') == u

# Generated at 2022-06-17 11:32:44.805211
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'\u00e9 \u00e9'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'\u00e9 \u00e9 \u00e9'


# Generated at 2022-06-17 11:32:51.714664
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode(u'%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'

# Generated at 2022-06-17 11:33:01.733892
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo.com/bar?a=b&c=d') == u'http%3A%2F%2Ffoo.com%2Fbar%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://foo.com/bar?a=b&c=d', for_qs=True) == u'http%3A%2F%2Ffoo.com%2Fbar%3Fa%3Db%26c%3Dd'
    assert unicode_urlencode(u'http://foo.com/bar?a=b&c=d', for_qs=False) == u'http%3A%2F%2Ffoo.com%2Fbar%3Fa%3Db%26c%3Dd'
   