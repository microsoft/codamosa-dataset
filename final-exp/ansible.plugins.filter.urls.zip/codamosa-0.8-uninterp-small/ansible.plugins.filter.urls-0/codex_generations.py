

# Generated at 2022-06-25 09:19:53.382834
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'jaC0w'
    var_0 = unicode_urlencode(str_0)


# Generated at 2022-06-25 09:19:55.904665
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit test for function urldecode of class FilterModule
    str_0 = 'w_8ud7O'
    var_0 = do_urlencode(str_0)


test_case_0()

# Generated at 2022-06-25 09:19:58.196456
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'w_8ud7O'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'w_8ud7O'


# Generated at 2022-06-25 09:19:59.614101
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'w_8ud7O'
    var_0 = unicode_urldecode(str_0)



# Generated at 2022-06-25 09:20:00.217621
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()

# Generated at 2022-06-25 09:20:03.026159
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(to_text(test_case_0())) == str_0


# Generated at 2022-06-25 09:20:08.250066
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input_string = 'w_8ud7O'
    expected = 'w 7O'
    actual = unicode_urldecode(input_string)
    assert actual == expected

# Generated at 2022-06-25 09:20:11.064027
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    phrase = 'w_8ud7O'
    assert unicode_urldecode(phrase) == 'w#8ud7O'


# Generated at 2022-06-25 09:20:15.158971
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'w_8ud7O'
    var_0 = unicode_urldecode(str_0)
    print(var_0)


# Generated at 2022-06-25 09:20:17.371871
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'w_8ud7O'
    var_0 = unicode_urlencode(str_0)


# Generated at 2022-06-25 09:20:24.716367
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/') == u'http://example.com/'
    assert unicode_urlencode(u'http://example.com/') == u'http://example.com/'
    assert unicode_urlencode(u'http://example.com/') != u'http://example.com/&'


# Generated at 2022-06-25 09:20:27.315567
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    filter_module_0 = FilterModule()

    assert filter_module_0.filters()['urldecode']('foo%20bar') == 'foo bar'

# Generated at 2022-06-25 09:20:29.014783
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%20string") == "a string"


# Generated at 2022-06-25 09:20:34.033910
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
    filters_1 = {'urldecode': do_urldecode}
    if not HAS_URLENCODE:
        filters_1 = {'urldecode': do_urldecode, 'urlencode': do_urlencode}
    # assert(filters_0 == filters_1)
    assert (filters_0 == filters_1)


# Generated at 2022-06-25 09:20:36.431044
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # case 0
    test_case_0()
#        import pytest
#        with pytest.raises(NotImplementedError):
#            assert do_urldecode(value)


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-25 09:20:41.415071
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('') == '')
    assert(unicode_urldecode('%20') == ' ')
    assert(unicode_urldecode('%21') == '!')
    assert(unicode_urldecode('%40') == '@')
    assert(unicode_urldecode('%23') == '#')
    assert(unicode_urldecode('%24') == '$')
    assert(unicode_urldecode('%26') == '&')
    assert(unicode_urldecode('%27') == '\'')
    assert(unicode_urldecode('%28') == '(')
    assert(unicode_urldecode('%29') == ')')

# Generated at 2022-06-25 09:20:44.388354
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
    assert type(result) is dict


# Generated at 2022-06-25 09:20:45.552200
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filterModule = FilterModule()

    filterModule.filters()


# Generated at 2022-06-25 09:20:50.941656
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert filter_module_0.filters() == {'urldecode': do_urldecode}, 'Expected outcome does not match'

# Generated at 2022-06-25 09:20:52.598941
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()
    assert result is not None


# Generated at 2022-06-25 09:21:00.770257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("test%C3%A4") == u"testä"
    assert unicode_urldecode("%F0%9F%8D%BA") == u"🍺"
    assert unicode_urldecode("%F0%9F%8D%B3") == u"🍳"
    assert unicode_urldecode("%40") == u"@"
    assert unicode_urldecode("%20") == u" "
    assert unicode_urldecode("%7E") == u"~"
    assert unicode_urldecode("%2C") == u","
    assert unicode_urldecode("%25") == u"%"
    assert unicode_urldecode("%3F") == u"?"
   

# Generated at 2022-06-25 09:21:06.070058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # No args
    result = unicode_urldecode()
    assert result == None
    # One arg
    result = unicode_urldecode("")
    assert result == ""
    # Two args
    result = unicode_urldecode("", "")
    assert result == ""


# Generated at 2022-06-25 09:21:16.770063
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Empty string should be empty
    assert (unicode_urlencode("") == "")
    # String with ascii should be the same
    assert (unicode_urlencode("abc") == "abc")
    # String with spaces should be decoded
    assert (unicode_urlencode("a b") == "a+b")
    # String with non-ascii should be encoded
    assert (unicode_urlencode("aĉ") == "a%C4%89")
    # String with some non-ascii should be encoded
    assert (unicode_urlencode("aĉb") == "a%C4%89b")
    # String with spaces and non-ascii should be encoded

# Generated at 2022-06-25 09:21:18.682825
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filter_module_filters_0 = filter_module_0.filters()


# Generated at 2022-06-25 09:21:25.339819
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters = filter_module_1.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:21:27.306332
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%0a') == '%0a'


# Generated at 2022-06-25 09:21:33.025017
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('-_.~') == '-_.~'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', True) == '%2F'
    assert unicode_urlencode('%') == '%25'
    assert unicode_urlencode('%', True) == '%25'
    assert unicode_urlencode('?a=b') == '%3Fa%3Db'
    assert unicode_urlencode('?a=b', True) == '%3Fa%3Db'
    assert unicode_urlencode('&a=b') == '%26a%3Db'
    assert unicode_urlencode('&a=b', True) == '%26a%3Db'
    assert unicode_

# Generated at 2022-06-25 09:21:34.851881
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2F%2F%20%2F%2F') == u'// //'


# Generated at 2022-06-25 09:21:37.461549
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("http%3A%2F%2Fdocs.ansible.com%2Fintro_inventory.html") == "http://docs.ansible.com/intro_inventory.html"


# Generated at 2022-06-25 09:21:43.759517
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # Test for #1
    value = u'/path/to/item with spaces'
    expected_result = u'/path/to/item%20with%20spaces'
    result = unicode_urlencode(value)
    assert result == expected_result, 'Expected "%s", but got "%s"' % (expected_result, result)



# Generated at 2022-06-25 09:21:51.017515
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Test method filters of class FilterModule
    """
    filter_module_0 = FilterModule()
    assert isinstance(filter_module_0.filters(), dict)

# Generated at 2022-06-25 09:21:55.338611
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'


# Generated at 2022-06-25 09:22:01.802502
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('a/b') == 'a%2Fb'
    assert do_urlencode('a,b') == 'a%2Cb'
    assert do_urlencode('abc123') == 'abc123'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'+=&:/?': '%'}) == '%2B%3D%26%3A%2F%3F=%25'


# Generated at 2022-06-25 09:22:07.366812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()
    assert isinstance(result, dict)


# Generated at 2022-06-25 09:22:13.400890
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/', for_qs=True) == u'%2F'
    assert unicode_urlencode('/', for_qs=True) == u'%2F'
    assert unicode_urlencode(u'ö') == u'%C3%B6'


# Generated at 2022-06-25 09:22:17.257270
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters_1 = filter_module_1.filters()
    assert isinstance(filters_1, dict)
    assert filters_1['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:22:20.869777
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    filter_module_0 = FilterModule()
    string = u'français'
    assert unicode_urlencode(string) == 'fran%C3%A7ais'
    string = u'English'
    assert unicode_urlencode(string) == 'English'


# Generated at 2022-06-25 09:22:21.912551
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"/api/json") == u"/api/json"


# Generated at 2022-06-25 09:22:26.452349
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert(filter_module_0.filters())

# Generated at 2022-06-25 09:22:28.422187
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create a new instance of the FilterModule class
    obj = FilterModule()

    # Call the filters() method of the instance
    assert callable(obj.filters)


# Generated at 2022-06-25 09:22:38.164821
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('Hello%20World%21') == 'Hello World!')
    assert(unicode_urldecode('%3F%3F%3F') == '???')
    assert(unicode_urldecode('%E2%99%A5') == '♥')
    assert(unicode_urldecode('%D1%82%D0%B5%D1%81%D1%82') == 'тест')



# Generated at 2022-06-25 09:22:44.728711
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode("a") == u'a'
    assert unicode_urldecode("1") == u'1'
    assert unicode_urldecode("a b") == u'a b'
    assert unicode_urldecode("1 2") == u'1 2'

    assert unicode_urldecode("%23") == u'#'
    assert unicode_urldecode("%40") == u'@'

    assert unicode_urldecode("aa") == u'aa'
    assert unicode_urldecode("a1") == u'a1'
    assert unicode_urldecode("aa bb") == u'aa bb'
    assert unicode_urldecode("a1 2") == u'a1 2'

    assert unic

# Generated at 2022-06-25 09:22:50.068110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters_result = filter_module_1.filters()


if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:22:51.279001
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass  # no results, test -success


# Generated at 2022-06-25 09:22:57.159438
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("TWiZWpjZFpXbE9ZUT09") == "M1yVzcdfZWkOY=="


# Generated at 2022-06-25 09:23:04.984730
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%40') == u'@'
    assert unicode_urldecode('%40') == u'@'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%21') == u'!'
    assert unicode_urldecode('%21') == u'!'
    assert unicode_urldecode('%23') == u'#'
    assert unicode_urldecode('%23') == u'#'
    assert unicode_urldecode

# Generated at 2022-06-25 09:23:09.373892
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    try:
        filter_module_1.filters()
    except:
        assert False


# Generated at 2022-06-25 09:23:20.232434
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E6%8A%80%E6%9C%AF%E6%9C%BA%E6%99%BA%E6%8E%88%E6%9D%83%EF%BC%8C%E4%B8%BA%E4%BA%8E%E5%A4%9F%E6%9C%9B%E5%B0%BC%E6%8A%A5+") == "技术机智授权，为了够望尼报 "

# Generated at 2022-06-25 09:23:24.993502
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "bob+the+builder"
    assert(unicode_urldecode(string) == 'bob the builder')
    string = "bob the builder"
    assert(unicode_urldecode(string) == 'bob the builder')


# Generated at 2022-06-25 09:23:36.143046
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'asdf%2Fasdf%2F').replace('\\', '/') == u'/asdf/asdf/'
    assert unicode_urldecode(u'asdf%2Fasdf%2F') == u'/asdf/asdf/'
    assert unicode_urldecode(u'/asdf/asdf/') == u'/asdf/asdf/'
    assert unicode_urldecode(b'/asdf/asdf/') == u'/asdf/asdf/'
    assert unicode_urldecode(u'%2Fasdf%2Fasdf%2F') == u'/asdf/asdf/'
    assert unicode_urldecode(b'%2Fasdf%2Fasdf%2F') == u

# Generated at 2022-06-25 09:23:44.171594
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    print(var_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'

# Generated at 2022-06-25 09:23:53.453608
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://foo?count=10&label=index') == u'http%3A//foo%3Fcount%3D10%26label%3Dindex'
    assert do_urlencode(u'http://foo?#count=10&label=index') == u'http%3A//foo%3F%23count%3D10%26label%3Dindex'
    assert do_urlencode(u'http://foo?count=10#&label=index') == u'http%3A//foo%3Fcount%3D10%23%26label%3Dindex'



# Generated at 2022-06-25 09:24:01.547046
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('bvIXXHA\t\t,]G5') == 'bvIXXHA\t\t,]G5')
    assert(unicode_urldecode('bvIXXHA%09%09%2C%5DG5') == 'bvIXXHA\t\t,]G5')
    assert(unicode_urldecode('bvIXXHA+%09+%09+%2C+%5DG5') == 'bvIXXHA\t\t,]G5')


# Generated at 2022-06-25 09:24:02.673446
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    f.filters()


# Generated at 2022-06-25 09:24:04.549073
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    e = 'bvIXXHA\t\t,]G5'
    a = unicode_urldecode(e)
    return a


# Generated at 2022-06-25 09:24:07.187272
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:24:11.762807
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == 'bvIXXHA\t\t,]G5'
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == 'bvIXXHA\t\t,]G5'
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == 'bvIXXHA\t\t,]G5'


# Generated at 2022-06-25 09:24:21.671134
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'bvIXXHA\t\t,]G5') == u'bvIXXHA\t\t,]G5'
    assert unicode_urldecode(u'Z.%CE%9D') == u'Z.\u03bd'
    assert unicode_urldecode(u'%C3%B1') == u'\xf1'
    assert unicode_urldecode(u'%C3%B1') == u'\xc3\xb1'
    assert unicode_urldecode(u'%C3%B1') == u'\u00f1'


# Generated at 2022-06-25 09:24:22.777698
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("Testing method filters of class FilterModule.")


# Generated at 2022-06-25 09:24:29.021540
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3, iteritems, string_types, to_bytes, to_text
    from ansible.module_utils._text import to_bytes, to_text
    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except ImportError:
        HAS_URLENCODE = False
    def unicode_urldecode(string):
        if PY3:
            return unquote_plus(string)
        return to_text(unquote_plus(to_bytes(string)))
    def do_urldecode(string):
        return unicode_urldecode(string)
    def unicode_urlencode(string, for_qs=False):
        safe = b'' if for_qs else b'/'
       

# Generated at 2022-06-25 09:24:43.892008
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urlencode(str_0)
    str_1 = 'I6-XU6xum_|'
    var_1 = unicode_urlencode(str_1, True)


# Generated at 2022-06-25 09:24:45.010396
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Dummy test for function filters of class FilterModule
    assert True


# Generated at 2022-06-25 09:24:53.722495
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    # Test with correct input
    # Test with correct input
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == to_text(b'bvIXXHA\t\t,]G5')
    assert unicode_urldecode('T[h<:R)A(X9_r') == to_text(b'T[h<:R)A(X9_r')
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == to_text(b'bvIXXHA\t\t,]G5')

# Generated at 2022-06-25 09:24:57.808378
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)

    assert var_0 == 'bvIXXHA\t\t,]G5'



# Generated at 2022-06-25 09:24:59.789563
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'application/json'
    str_1 = 'application%2Fjson'
    assert unicode_urlencode(str_0) == str_1


# Generated at 2022-06-25 09:25:04.185558
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert len(filters) == 2
    assert filters['urldecode'] == do_urldecode
    # This only runs when Jinja2 is older than v2.7
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:25:07.453719
# Unit test for function do_urlencode
def test_do_urlencode():
    ret_0 = do_urlencode(None)
    ret_1 = do_urlencode('test')
    assert ret_0 is not None
    assert ret_1 is not None


# Generated at 2022-06-25 09:25:09.836606
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    print("Running unit test for method filters of class FilterModule")
    filters = None
    obj = FilterModule()
    filters = obj.filters()
    for k, v in filters.items():
        print(k, v)



# Generated at 2022-06-25 09:25:14.243154
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    print(str_0)
    print(var_0)


# Generated at 2022-06-25 09:25:17.817339
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'pMBmMQf8_z'
    for_qs_0 = True
    bytes_0 = unicode_urlencode(str_0, for_qs_0)
    assert bytes_0 == 'pMBmMQf8_z'


# Generated at 2022-06-25 09:25:39.150215
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result = unicode_urlencode('http://www.google.com/search?hl=en&q=urlencode&btnG=Google+Search')
    assert result == 'http%3A//www.google.com/search%3Fhl%3Den%26q%3Durlencode%26btnG%3DGoogle%2BSearch'
    result = unicode_urlencode({'a': 'b'})
    assert result == 'a=b'
    result = unicode_urlencode({'a': 'b', 'c': 'd'})
    assert result == 'a=b&c=d'
    result = unicode_urlencode('http://www.google.com/search?hl=en&q=urlencode&btnG=Google+Search', for_qs=True)

# Generated at 2022-06-25 09:25:42.016971
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:25:50.313427
# Unit test for function unicode_urlencode
def test_unicode_urlencode():                                          # line: 1
    assert unicode_urlencode(u'bvIXXHA\t\t,]G5') == 'bvIXXHA%09%09,%5DG5'   # line: 2
    assert unicode_urlencode(u'bvIXXHA\t\t,]G5', for_qs=True) == 'bvIXXHA%09%09%2C%5DG5'
    assert unicode_urlencode(u'bvIXXHA\t\t,]G5/') == 'bvIXXHA%09%09,%5DG5%2F'

# Generated at 2022-06-25 09:25:52.527393
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == unquote_plus('bvIXXHA\t\t,]G5')


# Generated at 2022-06-25 09:25:54.654507
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = 'zZW[7'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:26:03.749650
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'

# generated code using codecs.encode()
    str_0 = 'a= 1'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'a= 1'

# generated code using codecs.encode()
    str_0 = 'a=2 '
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'a=2 '

# generated code using codecs.encode()
    str_0 = 'a= 3'
    var_0 = unicode_ur

# Generated at 2022-06-25 09:26:10.448710
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:26:21.236731
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    # assert equals
    var_0 = unicode_urldecode(str_0)
    assert var_0 == str_0
    str_0 = 'l7$(X80q3</MRGz([\x0b]w'
    # assert equals
    var_0 = unicode_urldecode(str_0)
    assert var_0 == str_0
    str_0 = 'l7$(X80q3</MRGz([\x0b]w'
    # assert equals
    var_0 = unicode_urldecode(str_0)
    assert var_0 == str_0
    str_0 = ';2>r<|\x0c[mY8'
    # assert

# Generated at 2022-06-25 09:26:24.749439
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filter_defs = fm.filters()
    assert len(filter_defs) > 0
    for name, filter in iteritems(filter_defs):
        assert callable(filter)


# Generated at 2022-06-25 09:26:26.829150
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:26:41.976430
# Unit test for function do_urlencode
def test_do_urlencode():
    str_0 = '=?utf-8?Q?=F0=9F=90=B1=2C_=E9=82=A3=E6=98=AF_=E6=88=91=E7=9A=84=E9=9D=A2=E5=90=91=F0=9F=98=84?='
    var_0 = do_urlencode(str_0)

# Generated at 2022-06-25 09:26:44.419079
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_0 = FilterModule()
    var_0 = test_0.filters()
    try:
        assert var_0
    except AssertionError:
        print("AssertionError occurred")


# Generated at 2022-06-25 09:26:45.780049
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)
    assert len(filters) == 2


# Generated at 2022-06-25 09:26:47.738852
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    n = FilterModule()
    assert n.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-25 09:26:49.518872
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert not var_0


# Generated at 2022-06-25 09:26:52.222543
# Unit test for function do_urlencode
def test_do_urlencode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = do_urlencode(str_0)
    assert var_0 == 'bvIXXHA%09%09%2C%5DG5'


# Generated at 2022-06-25 09:27:02.233739
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u' ') == u'%20'
    assert unicode_urlencode(u'@') == u'@'
    assert unicode_urlencode(u'\U0001f638') == u'%F0%9F%98%B8'
    assert unicode_urlencode(u'café') == u'caf%C3%A9'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo/bar')

# Generated at 2022-06-25 09:27:14.015302
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    args_0 = 'bvIXXHA\t\t,]G5'
    args_1 = dict()
    args_2 = 'bvIXXHA\t\t,]G5'
    args_3 = dict()
    args_4 = 'bvIXXHA\t\t,]G5'
    args_5 = dict()
    args_6 = 'bvIXXHA\t\t,]G5'
    args_7 = dict()
    args_8 = 'bvIXXHA\t\t,]G5'
    args_9 = dict()
    args_10 = 'bvIXXHA\t\t,]G5'
    args_11 = dict()
    var_0 = FilterModule()
    var_1 = var_0.filters()

# Unit

# Generated at 2022-06-25 09:27:17.203418
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        test_case_0()
    except:
        # AssertionError: must be str, not bytes
        pass
    else:
        assert False, 'Expected AssertionError'



# Generated at 2022-06-25 09:27:24.282136
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'
    str_1 = 'IO%bZ}@N5%=MN9X2'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == 'IO%bZ}@N5%=MN9X2'
    str_2 = 'CN&\t1nZ,5x5%=Q9X2'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == 'CN&\t1nZ,5x5%=Q9X2'

# Generated at 2022-06-25 09:27:43.424252
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert type(var_0) == str
    assert var_0 == 'bvIXXHA\t\t,]G5'
    str_1 = '$%<@s-s4%}GNjB'
    var_1 = unicode_urldecode(str_1)
    assert type(var_1) == str
    assert var_1 == '$%<@s-s4%}GNjB'
    str_2 = 'n)t3PqY'
    var_2 = unicode_urldecode(str_2)
    assert type(var_2) == str

# Generated at 2022-06-25 09:27:45.857484
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(var_0)
    

# Generated at 2022-06-25 09:27:52.491146
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a') == u'a'
    assert unicode_urlencode('a', for_qs=True) == u'a'
    assert unicode_urlencode(u'á') == u'%C3%A1'
    assert unicode_urlencode(u'á', for_qs=True) == u'%C3%A1'


# Generated at 2022-06-25 09:27:56.353928
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert sorted(filters) == sorted(['urldecode', 'urlencode'])

# [TEST CASES]

# Generated at 2022-06-25 09:28:02.676983
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'


# Generated at 2022-06-25 09:28:05.549678
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:13.519771
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    if 'urldecode' in filters.keys():
        str_0 = 'file:///C:/Program%20Files/7-Zip/7z.exe'
        var_0 = filters['urldecode'](str_0)
        assert var_0 == 'file:///C:/Program Files/7-Zip/7z.exe'
    if 'urlencode' in filters.keys():
        str_0 = 'http://127.0.0.1/?file=/tmp/ansible-test.xml'
        var_0 = filters['urlencode'](str_0)
        assert var_0 == 'http%3A//127.0.0.1/%3Ffile%3D/tmp/ansible-test.xml'

# Generated at 2022-06-25 09:28:15.570198
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod_0 = FilterModule()
    assert mod_0.filters() != {}

# Generated at 2022-06-25 09:28:18.715806
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'


# Generated at 2022-06-25 09:28:28.429625
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = 'O8RdWb7X9\t\t'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == 'O8RdWb7X9\t\t'
    str_2 = '-'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == '-'
    str_3 = 'qTp\t\t'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == 'qTp\t\t'
    str_4 = 'q3v/lnb-uVZ'
    var_4 = unicode_urldecode(str_4)
    assert var_4 == 'q3v/lnb-uVZ'

# Generated at 2022-06-25 09:28:40.167204
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # assert test with
    # for i in range(100):
    #     test_case_0()
    assert True


# Generated at 2022-06-25 09:28:42.457538
# Unit test for function do_urlencode
def test_do_urlencode():
    str_0 = 'bvIXXHA\t\t,]G5'
    str_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:50.386647
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'bvIXXHA\t\t,]G5') == u'bvIXXHA%09%09%2C%5DG5'

    if not HAS_URLENCODE:
        assert do_urlencode(u'bvIXXHA\t\t,]G5') == u'bvIXXHA%09%09%2C%5DG5'

test_unicode_urlencode()


# Generated at 2022-06-25 09:28:52.776874
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)



# Generated at 2022-06-25 09:28:56.369546
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate the class
    obj = FilterModule()

    # Call method filters of class FilterModule
    filters = obj.filters()



# Generated at 2022-06-25 09:28:57.968393
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters()


# Generated at 2022-06-25 09:29:01.394516
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'



# Generated at 2022-06-25 09:29:06.025921
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)



# Generated at 2022-06-25 09:29:07.550381
# Unit test for function do_urlencode
def test_do_urlencode():
    string = '1'
    assert do_urlencode(string) == u'1'


# Generated at 2022-06-25 09:29:12.555412
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    f = filterModule.filters()
    assert f['urldecode'] == do_urldecode
    assert f['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:29:26.239384
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('bvIXXHA\t\t,]G5') == 'bvIXXHA\t\t,]G5'


# Generated at 2022-06-25 09:29:29.624508
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'W8Iw1kd'
    var_0 = 'W8Iw1kd'
    uvar_0 = unicode_urlencode(str_0)
    assert (var_0 == uvar_0)


# Generated at 2022-06-25 09:29:32.810455
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'


# Generated at 2022-06-25 09:29:35.354550
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('bvIXXHA\t\t,]G5') == quote_plus('bvIXXHA\t\t,]G5')



# Generated at 2022-06-25 09:29:40.742724
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'bvIXXHA\t\t,]G5'



# Generated at 2022-06-25 09:29:42.219859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod_0 = FilterModule()
    assert(isinstance(mod_0.filters(), dict))


# Generated at 2022-06-25 09:29:45.811953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)


# Generated at 2022-06-25 09:29:54.128511
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = 'bvIXXHA\t\t,]G5'
    var_0 = unicode_urldecode(str_0)
    str_1 = 'bvIXXHA\t\t,]G5'
    var_1 = unicode_urldecode(str_1)
    str_2 = 'bvIXXHA\t\t,]G5'
    var_2 = unicode_urldecode(str_2)
    str_3 = 'bvIXXHA\t\t,]G5'
    var_3 = unicode_urldecode(str_3)
    filterModule = FilterModule()
    filterModule.filters()

