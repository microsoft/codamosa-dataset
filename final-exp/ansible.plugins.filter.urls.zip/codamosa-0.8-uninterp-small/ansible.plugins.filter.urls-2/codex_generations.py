

# Generated at 2022-06-25 09:19:50.487360
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-25 09:19:53.526137
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert isinstance(filter_module_1.filters(), dict)



# Generated at 2022-06-25 09:19:56.858587
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_filter_module_0 = filter_module_0.filters()
    filters_filter_module_0_dict_0 = filters_filter_module_0['urldecode']
    assert filters_filter_module_0_dict_0('abc') == 'abc'

# Generated at 2022-06-25 09:19:58.572349
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'hello%20world%21'
    assert unicode_urldecode(string) == 'hello world!'


# Generated at 2022-06-25 09:20:03.544778
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string = "%E6%B5%8B%E8%AF%95"
    result = unicode_urldecode(test_string)
    assert result == "测试"


# Generated at 2022-06-25 09:20:05.543236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() is not None


# Generated at 2022-06-25 09:20:12.054452
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    data = "Ch%C3%A2%E2%82%AC%C5%A3teau"
    result = unicode_urldecode(data)
    # These are the assertions

    assert result == u'Ch\xe2\x82\xac\u0153teau', 'Test Failed'


# Generated at 2022-06-25 09:20:17.075015
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/foo/bar?a=42&b=4711') == u'http://example.com/foo/bar%3Fa%3D42%26b%3D4711'


# Generated at 2022-06-25 09:20:21.329379
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test to ensure that unicode_urldecode returns the correct value
    '''
    value = '%a3%a3'
    expected = u'££'
    assert unicode_urldecode(value) == expected


# Generated at 2022-06-25 09:20:23.413548
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # check if urldecode converts '%20' to ' '
    assert unicode_urldecode("%20") == ' '



# Generated at 2022-06-25 09:20:28.792948
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    output = filter_module_1.filters()
    assert isinstance(output, dict) is True
    assert len(output) == 2
    assert 'urldecode' in output
    assert 'urlencode' in output

# Generated at 2022-06-25 09:20:34.861538
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    # AssertionError: <dict object at 0x7f68b6eba828> != {
    #     'urldecode': <function do_urldecode at 0x7f68b6eba598>,
    #     'urlencode': <function do_urlencode at 0x7f68b6eba620>,
    # }
    assert filter_module_0.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

# Generated at 2022-06-25 09:20:45.859794
# Unit test for function do_urlencode
def test_do_urlencode():
    # test_string
    print("testing function do_urlencode()")
    assert do_urlencode('asdf&qwerty') == 'asdf%26qwerty'
    assert do_urlencode(b'asdf&qwerty') == 'asdf%26qwerty'
    assert do_urlencode(u'asdf&qwerty') == 'asdf%26qwerty'
    assert do_urlencode('/path/with/slash') == '/path/with/slash'
    assert do_urlencode(b'/path/with/slash') == '/path/with/slash'
    assert do_urlencode(u'/path/with/slash') == '/path/with/slash'
    assert do_urlencode(42) == '42'
    assert do

# Generated at 2022-06-25 09:20:51.589663
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert not HAS_URLENCODE
    x = FilterModule()
    assert 'urldecode' in x.filters()
    assert 'urlencode' in x.filters()


# Generated at 2022-06-25 09:20:52.912348
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Hello World') == 'Hello%20World'


# Generated at 2022-06-25 09:20:57.959028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    # Test for method filters of class FilterModule
    assert filter_module_0.filters()


# Generated at 2022-06-25 09:21:06.195396
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '

    # Forcing a unicode string
    assert unicode_urldecode(b'%20') == u'%20'

    # Forcing a byte string
    assert unicode_urldecode(u'%20') == u' '

    # Forcing a byte string again
    assert unicode_urldecode(u'%20'.encode()) == u' '


# Generated at 2022-06-25 09:21:12.342426
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    input_str = 'https://www.baidu.com/s?wd=%E7%99%BE%E5%BA%A6'
    ret_str = do_urldecode(input_str)
    assert ret_str == 'https://www.baidu.com/s?wd=百度'


# Generated at 2022-06-25 09:21:20.875509
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http://localhost/api/v1/users/1') == u'http://localhost/api/v1/users/1'
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('ABC') == u'ABC'
    assert unicode_urldecode('abc%2Fghi') == u'abc/ghi'
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'ABC') == u'ABC'
    assert unicode_urldecode(u'abc%2Fghi') == u'abc/ghi'
    if PY3:
        assert unicode_urldecode(b'abc') == u'abc'

# Generated at 2022-06-25 09:21:23.880496
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E5%90%89%E6%9E%97%E3%82%B5%E3%83%BC%E3%83%90%E3%83%BC') == u'吉林サーバー'


# Generated at 2022-06-25 09:21:35.205977
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("abc") == "abc"
    assert unicode_urlencode("abc'") == "abc%27"
    assert unicode_urlencode("abc\n") == "abc%0A"
    assert unicode_urlencode("abc\r") == "abc%0D"
    assert unicode_urlencode("abc\t") == "abc%09"
    assert unicode_urlencode("abc ") == "abc%20"
    assert unicode_urlencode("abc&") == "abc%26"


# Generated at 2022-06-25 09:21:37.495229
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    res = filter_module_0.filters()
    assert isinstance(res, dict)


# Generated at 2022-06-25 09:21:48.053639
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string_0 = to_text(b'aHR0cDovL3d3dy5leGFtcGxlLmNvbS8%3D')
    test_string_1 = to_text(b'https%3A%2F%2Fwww.example.com%2F')
    test_string_2 = to_text(b'https://www.example.com/')

    assert unicode_urldecode(test_string_0) == test_string_2
    assert unicode_urldecode(test_string_1) == test_string_2
    assert unicode_urldecode(test_string_2) == test_string_2


# Generated at 2022-06-25 09:21:51.778445
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('/%20') == u'/%20'


# Generated at 2022-06-25 09:21:55.719563
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("Test%20and%20Test") == "Test and Test"


# Generated at 2022-06-25 09:21:58.913549
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar%20baz') == 'foo bar baz'
    assert unicode_urldecode('foo%2Fbar%2Fbaz') == 'foo/bar/baz'


# Generated at 2022-06-25 09:22:00.666560
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() is not None


# Generated at 2022-06-25 09:22:04.252462
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://localhost/index.php/Special:URIResolver/Property-3AUserbox') == 'http%3A//localhost/index.php/Special%3AURIResolver/Property-3AUserbox'


# Generated at 2022-06-25 09:22:08.285341
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    assert a.filters() == {'urldecode': do_urldecode}



# Generated at 2022-06-25 09:22:12.266407
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters_1 = filter_module_1.filters()
    filters_2 = filter_module_1.filters()



# Generated at 2022-06-25 09:22:18.991916
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == '{"foo":"bar"}'
    assert unicode_urldecode('%7b%22foo%22%3a%22bar%22%7d') == '{"foo":"bar"}'


# Generated at 2022-06-25 09:22:21.624119
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) is None
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('test') == 'test'


# Generated at 2022-06-25 09:22:26.023901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = filter_module_0.filters()


# Generated at 2022-06-25 09:22:30.204461
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input_0 = "{{ '~' | urldecode }}"
    expected_0 = "~"
    actual_0 = unicode_urldecode("{{ '~' | urldecode }}")
    assert actual_0 == expected_0 , "unicode_urldecode(" + input_0 + ") may not match expected (" + expected_0 + ")!"


# Generated at 2022-06-25 09:22:36.197028
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+bar') == u'foo+bar'
    assert unicode_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode(u'foo%3Dbar') == u'foo=bar'
    assert unicode_urldecode(u'foo%26bar') == u'foo&bar'
    assert unicode_urldecode(u'foo+bar%2Bbar') == u'foo+bar+bar'


# Generated at 2022-06-25 09:22:38.044039
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C5%A1%C3%AD%C4%8Dek') == u'šíček'


# Generated at 2022-06-25 09:22:39.614589
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    assert isinstance(filter_module.filters(), dict)


# Generated at 2022-06-25 09:22:43.346104
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }


# Generated at 2022-06-25 09:22:51.361160
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test cases
    assert do_urlencode(u'a') == u'a'
    assert do_urlencode(u'hello world') == u'hello+world'
    assert do_urlencode([u'hello', u'world', 1, 2]) == u'hello&world&1&2'
    assert do_urlencode({u'a': u'b', u'c': u'd'}) == u'a=b&c=d'


# Generated at 2022-06-25 09:22:57.019528
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['urldecode']("http%3A%2F%2Fwww.google.com") == "http://www.google.com"



# Generated at 2022-06-25 09:23:03.028896
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    res = unicode_urlencode(u"http://www.github.com/")
    assert res == "%s" % u"http%3A//www.github.com/"

# A utf8 encoded string

# Generated at 2022-06-25 09:23:08.033431
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc%5Bdef%5D') == 'abc[def]'
    assert unicode_urldecode('abc%5Bdef%5D') == 'abc[def]'
    assert unicode_urldecode('%7B%22foo%22%3A%22bar%22%7D') == '{"foo":"bar"}'


# Generated at 2022-06-25 09:23:11.103218
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert (unicode_urldecode('Hello%20World%21') == u'Hello World!')
    assert (unicode_urldecode('Hello%2BWorld%21') == u'Hello+World!')


# Generated at 2022-06-25 09:23:20.501134
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'') == u'')
    assert(unicode_urlencode(u'*') == u'*')
    assert(unicode_urlencode(u'http://x/y') == u'http%3A%2F%2Fx%2Fy')
    assert(unicode_urlencode(u'%2F') == u'%252F')
    assert(unicode_urlencode(u'%2F', for_qs=True) == u'%2F')
    assert(unicode_urlencode(u'%2F', for_qs=False) == u'%252F')


# Generated at 2022-06-25 09:23:24.380349
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-25 09:23:29.568801
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # setUp of test_case_0
    filter_module_0 = FilterModule()

    # No exception should be raised
    filter_module_0.filters()


# Generated at 2022-06-25 09:23:31.496883
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('x+y%20z') == 'x y z'


# Generated at 2022-06-25 09:23:33.747562
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%40%40') == '@@'


# Generated at 2022-06-25 09:23:44.665395
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A%2F%2Fexample.com%2F'
    assert unicode_urlencode('http://example.com/?q=test') == 'http%3A%2F%2Fexample.com%2F%3Fq%3Dtest'
    assert unicode_urlencode('http://example.com/?q=test&name=foo') == 'http%3A%2F%2Fexample.com%2F%3Fq%3Dtest%26name%3Dfoo'

# Generated at 2022-06-25 09:23:46.970356
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20world') == u'hello world'


# Generated at 2022-06-25 09:23:52.562304
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('a%2Fb%40c%3Dd%26e%20f%2Bg') == 'a/b@c=d&e f+g')


# Generated at 2022-06-25 09:23:55.807996
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of FilterModule
    filter_module_1 = FilterModule()

    # Verify the attributes are configured correctly
    assert filter_module_1.filters() != None


# Generated at 2022-06-25 09:23:57.951298
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'monkeys') == 'monkeys'


# Generated at 2022-06-25 09:24:00.414273
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    result = filter_module_1.filters()
    assert result == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:24:02.785244
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:24:05.395662
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo&bar') == 'foo%26bar'


# Generated at 2022-06-25 09:24:06.880971
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert not filter_module_0.filters()

# Generated at 2022-06-25 09:24:09.214987
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:24:11.099313
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert isinstance(filter_module.filters(), dict)

# Generated at 2022-06-25 09:24:12.716162
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('c%C3%B3mo+est%C3%A1') == 'cómo está'


# Generated at 2022-06-25 09:24:17.892663
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print(unicode_urldecode(string='#!'))
    print(unicode_urldecode(string='#%21'))
    print(unicode_urldecode(string='#%20'))
    print(unicode_urldecode(string='#%3F'))
    print(unicode_urldecode(string='#%7F'))
    print(unicode_urldecode(string='#%80'))
    print(unicode_urldecode(string='#%C2%BF'))
    print(unicode_urldecode(string='#%E1%BC%B0'))


# Generated at 2022-06-25 09:24:20.184765
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E6%9C%A9%E7%94%A8') == u'朩用'


# Generated at 2022-06-25 09:24:23.962861
# Unit test for function do_urlencode
def test_do_urlencode():

    # Initialize key variables
    data = 'a%20string'

    # Do test
    result = do_urlencode(data)
    assert result == 'a%2520string'

    # Do test for for_qs
    result = do_urlencode(data, for_qs=True)
    assert result == 'a+string'


# Generated at 2022-06-25 09:24:25.362983
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'foo%40bar' == unicode_urlencode('foo@bar')


# Generated at 2022-06-25 09:24:30.069299
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    string = 'string'
    value = 'value'
    assert filter_module_0.filters().get(string)(value) == unquote_plus('value')

# Generated at 2022-06-25 09:24:35.933421
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd efgh') == 'abcd%20efgh'
    assert unicode_urlencode('abcd efgh', True) == 'abcd%20efgh'
    assert unicode_urlencode("test & that", True) == 'test%20%26%20that'
    assert unicode_urlencode("test & that", False) == 'test%20%26%20that'


# Generated at 2022-06-25 09:24:46.396972
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(
        u'https://github.com/ansible/ansible/commit/dcd3368f4b9825cdc4e43a684f4acf754e5b593c') == \
        u'https%3A//github.com/ansible/ansible/commit/dcd3368f4b9825cdc4e43a684f4acf754e5b593c'

# Generated at 2022-06-25 09:24:53.835799
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:25:01.633705
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3a%2f%2fwww.example.com%2f') == u'http://www.example.com/'
    assert unicode_urldecode('http%3A%2F%2Fwww.example.com%2F') == u'http://www.example.com/'
    assert unicode_urldecode('http%3a%2f%2Fwww.example.com%2F') == u'http://www.example.com/'
    assert unicode_urldecode('http%3a%2F%2fwww.example.com%2F') == u'http://www.example.com/'


# Generated at 2022-06-25 09:25:05.891316
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(False) == ''


# Generated at 2022-06-25 09:25:17.572277
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc def') == 'abc def'
    assert unicode_urldecode('a+b+c') == 'a b c'
    assert unicode_urldecode('a%2Bb%2Bc') == 'a+b+c'
    assert unicode_urldecode('%E3%81%82') == u'あ'
    assert unicode_urldecode('%E3%81%82%2B%E3%81%84') == u'あ+い'
    assert unicode_urldecode('%E3%81%82%2B%E3%81%84%E3%81%86') == u'あ+いう'
    assert unicode_urld

# Generated at 2022-06-25 09:25:21.689908
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == 'test'
    assert unicode_urldecode('test+1') == 'test 1'
    assert unicode_urldecode('test%2B1') == 'test+1'


# Generated at 2022-06-25 09:25:23.941998
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%2Fwww.redhat.com%2F') == '//www.redhat.com/'


# Generated at 2022-06-25 09:25:27.329233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_0 = FilterModule().filters()


# Generated at 2022-06-25 09:25:38.387773
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # url_1 => url_2
    url_1 = u'foo%25%26bar%3D'
    url_2 = u'foo%&bar='
    assert unicode_urldecode(url_1) == url_2
    # url_3 => url_4
    url_3 = 'foo%25%26bar%3D'
    url_4 = u'foo%&bar='
    assert unicode_urldecode(url_3) == url_4
    # url_5 => url_6
    url_5 = b'foo%25%26bar%3D'
    url_6 = u'foo%&bar='
    assert unicode_urldecode(url_5) == url_6
    # url_7 => url_8
    url_7 = ''
    url_

# Generated at 2022-06-25 09:25:46.526223
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode("abc") == 'abc')
    assert(unicode_urlencode("abc") != 'üèê')
    assert(unicode_urlencode("üèê") == '%C3%BC%C3%A8%C3%AA')
    assert(unicode_urlencode("üèê") != 'abc')


# Generated at 2022-06-25 09:25:48.696958
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'this%20is%20string%20example....wow!!!'
    test_object = unquote_plus(string)
    assert unicode_urldecode(string) == test_object


# Generated at 2022-06-25 09:25:50.830117
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters().keys() == ['urldecode']
    assert filter_module_1.filters()['urldecode'].__name__ == 'do_urldecode'

# Generated at 2022-06-25 09:25:53.471207
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25')
    assert unicode_urldecode('%25a')
    assert unicode_urldecode('%25abc')
    assert unicode_urldecode('%25abc%25')

# Generated at 2022-06-25 09:25:58.037842
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('dag%20wieers') == 'dag wieers'
    assert unicode_urldecode('dag+wieers') == 'dag wieers'
    assert unicode_urldecode('dagwieers') == 'dagwieers'



# Generated at 2022-06-25 09:26:07.726485
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/foo/bar baz') == u'http%3A//example.com/foo/bar+baz'
    assert unicode_urlencode('http://test.example.com/test/test12345') == u'http%3A//test.example.com/test/test12345'
    assert unicode_urlencode(unicode('http://example.com/foo/bar baz', 'utf-8')) == u'http%3A//example.com/foo/bar+baz'
    assert unicode_urlencode(unicode('http://test.example.com/test/test12345', 'utf-8')) == u'http%3A//test.example.com/test/test12345'

# Generated at 2022-06-25 09:26:09.622071
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input = 'Hello%20World%21'
    output = 'Hello World!'
    assert unicode_urldecode(input) == output


# Generated at 2022-06-25 09:26:18.247494
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = "https%3A%2F%2Fwww.google.com%2Fsearch%3Fclient%3Dsafari%26rls%3Den%26q%3Dansible%26ie%3DUTF-8%26oe%3DUTF-8"
    assert unicode_urldecode(s) == u"https://www.google.com/search?client=safari&rls=en&q=ansible&ie=UTF-8&oe=UTF-8"


# Generated at 2022-06-25 09:26:21.060644
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a&b') == u'a%26b'
    assert unicode_urlencode(u'a&b', for_qs=True) == u'a%26b'


# Generated at 2022-06-25 09:26:25.183092
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
    assert filters_0 == {'urldecode': do_urldecode}, '{} != {{\'urldecode\': do_urldecode}}'.format(filters_0)

# Generated at 2022-06-25 09:26:30.180649
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()



# Generated at 2022-06-25 09:26:36.661950
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(string="Red Fish, Blue Fish !!!") == "Red%20Fish%2C%20Blue%20Fish%20!!!"
    assert unicode_urlencode(string="Red Fish, Blue Fish !!!", for_qs=True) == "Red+Fish%2C+Blue+Fish+!!!"


# Generated at 2022-06-25 09:26:40.634050
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo+bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%25bar') == 'foo%bar'


# Generated at 2022-06-25 09:26:42.449368
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("this is a test") == "this%20is%20a%20test"


# Generated at 2022-06-25 09:26:46.774530
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    example_str = 'http://example.com/o?!'
    your_str = ''
    if (unicode_urlencode(example_str) == 'http%3A//example.com/o%3F%21%3F'):
        print("Test for unicode_urlencode: Passed")
    else:
        print("Test for unicode_urlencode: Failed")


# Generated at 2022-06-25 09:26:53.944028
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abcdefghijklmnopqrstuvwxyz') == u'abcdefghijklmnopqrstuvwxyz'
    assert unicode_urldecode(u'ABCDEFGHIJKLMNOPQRSTUVWXYZ') == u'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert unicode_urldecode(u'0123456789') == u'0123456789'
    assert unicode_urldecode(u'_.-') == u'_.-'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%7E') == u'~'

# Generated at 2022-06-25 09:26:58.506262
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    data = {}
    data['quote_plus'] = 'abcd efgh'
    data['quote'] = '/abcd efgh/'
    data['unquote'] = '%2Fabcd+efgh%2F'
    data['unquote_plus'] = '%2Fabcd+efgh%2F'

    assert unicode_urlencode(data['quote']).decode(
    ) == data['quote'], 'quote test failed'
    assert unicode_urlencode(data['unquote']).decode(
    ) == data['unquote'], 'unquote test failed'
    assert unicode_urlencode(data['quote_plus'], for_qs=True).decode(
    ) == data['unquote_plus'], 'quote_plus test failed'
    assert unicode_urldec

# Generated at 2022-06-25 09:27:00.935167
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_0 = FilterModule().filters()
    assert len(filters_0) == 2
    assert 'urldecode' in filters_0
    assert 'urlencode' in filters_0


# Generated at 2022-06-25 09:27:01.554528
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass # nothing to test


# Generated at 2022-06-25 09:27:04.237496
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    result = filter_module_1.filters()

# Generated at 2022-06-25 09:27:11.095289
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    if not PY3:
        assert unicode_urldecode(u'%20') == u' '
        assert isinstance(unicode_urldecode(u'%20'), unicode)


# Generated at 2022-06-25 09:27:19.737261
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(u'a') == u'a'
    assert unicode_urldecode(u'a+') == u'a '
    assert unicode_urldecode(u'+a') == u' a'
    assert unicode_urldecode(u'+') == u' '
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2B') == u'+'


# Generated at 2022-06-25 09:27:20.841629
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters is FilterModule(filters)


# Generated at 2022-06-25 09:27:23.385227
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%c2%a9") == u"\xa9"
    assert unicode_urldecode("%E2%82%AC") == u"\u20ac"


# Generated at 2022-06-25 09:27:28.318777
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
   assert unicode_urlencode(1, False) == '1'
   assert unicode_urlencode('spam & eggs', False) == 'spam%20%26%20eggs'
   assert unicode_urlencode('/path/spam & eggs/', False) == '/path/spam%20%26%20eggs/'
   assert unicode_urlencode(u'/path/spam & eggs/', False) == '/path/spam%20%26%20eggs/'
   assert unicode_urlencode(1, True) == '1'
   assert unicode_urlencode('spam & eggs', True) == 'spam+%26+eggs'

# Generated at 2022-06-25 09:27:32.792113
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'swap_allocated_mb'
    var_0 = unicode_urlencode(str_0)
    assert var_0 == 'swap_allocated_mb'



# Generated at 2022-06-25 09:27:35.200409
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('swap_allocated_mb') == 'swap_allocated_mb'


# Generated at 2022-06-25 09:27:43.828016
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2

    filters = FilterModule.filters(None)
    assert len(filters) == 2




# Generated at 2022-06-25 09:27:52.598011
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'Test') == 'Test'
    assert do_urlencode(u'T{e}st') == 'T%7Be%7Dest'
    assert do_urlencode(u'Tëst') == 'T%C3%ABst'
    assert do_urlencode(u'тест') == '%D1%82%D0%B5%D1%81%D1%82'

# Generated at 2022-06-25 09:28:03.610104
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'swap_allocated_mb'
    result = unicode_urlencode(str_0)
    assert result == 'swap_allocated_mb'

    str_1 = 'swap_allocated_mb'
    result = unicode_urlencode(str_1, for_qs=True)
    assert result == 'swap_allocated_mb'

    str_2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-._~:/?#[]@!$&'()*+,;="
    result = unicode_urlencode(str_2)

# Generated at 2022-06-25 09:28:06.699503
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    with pytest.raises(TypeError):
        str_0 = 'swap_allocated_mb'
        unicode_urldecode(str_0)
        assert False



# Generated at 2022-06-25 09:28:08.330717
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)
    assert 'urldecode' in filters


# Generated at 2022-06-25 09:28:20.148157
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("performance_counter_enabled") == "performance_counter_enabled"
    assert unicode_urldecode("swap_allocated_mb") == "swap_allocated_mb"
    assert unicode_urldecode("ping_queue_depth") == "ping_queue_depth"
    assert unicode_urldecode("min_bandwidth_mbits_per_sec") == "min_bandwidth_mbits_per_sec"
    assert unicode_urldecode("max_bandwidth_mbits_per_sec") == "max_bandwidth_mbits_per_sec"
    assert unicode_urldecode("max_memory_mb") == "max_memory_mb"

# Generated at 2022-06-25 09:28:24.584740
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        with open('test/urldecode/url_0.txt', 'r') as file:
            assert file.read() == unicode_urldecode(file.read())
    except IOError as e:
        print('File not found')

if __name__ == '__main__':
    test_unicode_urldecode()

# Generated at 2022-06-25 09:28:25.738427
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()

# Generated at 2022-06-25 09:28:35.375766
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert to_text(unicode_urldecode(u'basic')) == u'basic'
    assert to_text(unicode_urldecode(u'swap_allocated_mb')) == u'swap_allocated_mb'
    assert to_text(unicode_urldecode(u'cpu_stats%3Auser')) == u'cpu_stats:user'
    assert to_text(unicode_urldecode(u'cpu_stats%3Auser')) == u'cpu_stats:user'
    assert to_text(unicode_urldecode(u'cpu_stats%3Auser')) == u'cpu_stats:user'

# Generated at 2022-06-25 09:28:40.182153
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print('\nUnit test for unicode_urldecode\n')
    test_case_0()


# Generated at 2022-06-25 09:28:42.457003
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Invoke method
    var_1 = FilterModule.filters(None)
    # Check for correct type
    assert isinstance(var_1, {})


# Generated at 2022-06-25 09:28:52.623278
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('//') == '%2F%2F'
    assert unicode_urlencode('//', for_qs=True) == '%2F%2F'
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('', for_qs=True) == ''
    assert unicode_urlencode(':') == '%3A'
    assert unicode_urlencode(':', for_qs=True) == '%3A'



# Generated at 2022-06-25 09:28:57.222317
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    foo_FilterModule = FilterModule()
    a = dict(foo_FilterModule.filters())
    #assert a == None, "Return is \n" + str(a)



# Generated at 2022-06-25 09:28:59.513221
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_0 = FilterModule()
    assert class_0.filters() == {'urldecode': do_urldecode}

# Generated at 2022-06-25 09:29:07.031478
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'swap_allocated_mb'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'swap_allocated_mb'
    str_1 = 'swap_available_mb'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == 'swap_available_mb'
    str_2 = 'swap_used_mb'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == 'swap_used_mb'
    str_3 = 'system_uptime'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == 'system_uptime'
    str_4 = 'system_load_average'


# Generated at 2022-06-25 09:29:09.405982
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'swap_allocated_mb' == unicode_urldecode('swap_allocated_mb')


# Generated at 2022-06-25 09:29:12.412922
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result_0 = unicode_urldecode('swap_allocated_mb')
    assert result_0 == 'swap_allocated_mb'



# Generated at 2022-06-25 09:29:20.064863
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('param1=a&param2=b') == 'param1=a&param2=b'
    assert unicode_urldecode('http%3A//www.example.com') == 'http://www.example.com'
    assert unicode_urldecode('http%3A%2F%2Fwww.example.com') == 'http://www.example.com'
    assert unicode_urldecode('%E9%87%8D%E8%A6%81%E4%BF%A1%E6%81%AF') == '重要信息'


# Generated at 2022-06-25 09:29:27.367145
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters()
    if "urlencode" in filters:
        str_u = 'swap_allocated_mb'
        str_u_0 = do_urlencode(str_u)
        assert(str_u == str_u_0), "str_u != str_u_0"

# Generated at 2022-06-25 09:29:31.079475
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(test_case_0())



# Generated at 2022-06-25 09:29:31.965171
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:29:35.250253
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('swap_allocated_mb') == 'swap_allocated_mb')
    assert(unicode_urldecode('%2F%2F%2F') == '///')
    assert(unicode_urldecode('%2f%2f%2f') == '///')



# Generated at 2022-06-25 09:29:40.408607
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'swap_allocated_mb'
    str_1 = 'swap_allocated_mb'
    assert unicode_urlencode(str_0) == str_1, "unicode_urlencode Failed"



# Generated at 2022-06-25 09:29:46.421493
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'swap_allocated_mb'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'swap_allocated_mb', 'Expected: "swap_allocated_mb", but got: ' + var_0

    str_0 = '.*'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '.*', 'Expected: ".*", but got: ' + var_0

    str_0 = 'foo/bar'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'foo/bar', 'Expected: "foo/bar", but got: ' + var_0

    str_0 = 'foo%'
    var_0 = unicode_ur