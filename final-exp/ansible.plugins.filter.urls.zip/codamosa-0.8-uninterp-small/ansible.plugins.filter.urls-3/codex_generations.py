

# Generated at 2022-06-25 09:19:53.015953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters() is not None

# Generated at 2022-06-25 09:19:55.675513
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()

# Generated at 2022-06-25 09:20:01.174561
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc+') == 'abc '
    assert unicode_urldecode('abc%20') == 'abc '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('+') == ' '
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('abc%2') == 'abc%2'
    assert unicode_urldecode('abc%20%') == 'abc %'


# Generated at 2022-06-25 09:20:02.392857
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() == {'urldecode': do_urldecode, }


# Generated at 2022-06-25 09:20:07.885435
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Foo+Bar%20Baz') == 'Foo Bar Baz'
    assert unicode_urldecode('Foo%20Bar+Baz') == 'Foo Bar+Baz'
    assert unicode_urldecode('Foo+Bar+Baz') == 'Foo Bar Baz'
    assert unicode_urldecode('Foo%20Bar%20Baz') == 'Foo Bar Baz'
    assert unicode_urldecode('Foo%20Bar%20Baz%20') == 'Foo Bar Baz '


# Generated at 2022-06-25 09:20:10.594336
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DdQw4w9WgXcQ') == 'http://www.youtube.com/watch?v=dQw4w9WgXcQ'
    assert unicode_urldecode('http%3A%2F%2Fgoogle.com') == 'http://google.com'


# Generated at 2022-06-25 09:20:12.026870
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_urldecode('foo')


# Generated at 2022-06-25 09:20:15.419206
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('value%2B123') == 'value+123')


# Generated at 2022-06-25 09:20:21.605026
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    # Assert that urldecode is present
    assert 'urldecode' in filters

    string = 'testing+%7C+12345'
    assert filters['urldecode'](string) == u'testing | 12345'

    if not HAS_URLENCODE:
        assert filters['urlencode'](string) == u'testing%2B%257C%2B12345'

# Generated at 2022-06-25 09:20:31.259141
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_bytes
    assert unicode_urlencode('http://www.example.com/') == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode('http://www.example.com/', for_qs=True) == u'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode({'foo': ['bar', 'baz']}) == u'foo=bar&foo=baz'
    assert unicode_urlencode({'foo': ['bar', 'baz']}, for_qs=True) == u'foo=bar&foo=baz'

# Generated at 2022-06-25 09:20:40.069977
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode("") == ""
    assert unicode_urlencode("/") == "%2F"
    assert unicode_urlencode("%2F") == "%252F"
    assert unicode_urlencode("%252F") == "%25252F"

    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("ab cd") == "ab%20cd"
    assert unicode_urlencode("ab+cd") == "ab%2Bcd"

    assert unicode_urlencode("https://www.example.com/") == "https%3A%2F%2Fwww.example.com%2F"

# Generated at 2022-06-25 09:20:46.914760
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("/") == b"%2F"
    assert unicode_urlencode("/", for_qs=True) == b"%2F"
    assert unicode_urlencode("&") == b"%26"
    assert unicode_urlencode("&", for_qs=True) == b"%26"
    assert unicode_urlencode(to_text("français")) == b"fran%C3%A7ais"
    assert unicode_urlencode(to_text("plain ascii"), for_qs=True) == b"plain+ascii"
    assert unicode_urlencode("étagère") == b"%C3%A9tag%C3%A8re"

# Generated at 2022-06-25 09:20:52.686142
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"hello world") == u"hello%20world"
    assert do_urlencode(u"hello world") == u"hello%20world"
    assert do_urlencode(["hello world", "test-test"]) == u"hello+world&test-test"
    assert do_urlencode({u"hello world": u"test-test"}) == u"hello+world=test-test"
    assert do_urlencode({u"hello world": u"test-test", u"test2": [u"hello", u"h3llo"]}) == u"hello+world=test-test&test2=hello&test2=h3llo"


# Generated at 2022-06-25 09:20:59.309435
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['urldecode']("http://www.google.com/search?q=ansible+modules&hl=en") == "http://www.google.com/search?q=ansible+modules&hl=en"

# Generated at 2022-06-25 09:21:04.884378
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode("%20") == u" ")
    assert(unicode_urldecode("%C3%A9") == u"é")


# Generated at 2022-06-25 09:21:07.421967
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '


# Generated at 2022-06-25 09:21:17.223468
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  # Verify that Unicode is acceptable
  assert unicode_urldecode('%3f') == '?'
  assert unicode_urldecode('%C2%BD') == '½'
  assert unicode_urldecode('%20') == ' '
  # Verify that string is acceptable
  assert unicode_urldecode('%3f') == '?'
  assert unicode_urldecode('%C2%BD') == '½'
  assert unicode_urldecode('%20') == ' '
  # Verify that %2B is decoded to a space character
  assert unicode_urldecode('%2B') == ' '
  # Verify that %2b is decoded to a space character
  assert unicode_urldecode('%2b') == ' '
  # Verify that %

# Generated at 2022-06-25 09:21:27.120552
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https://www.example.com/abc?abc=123&cde=456') == 'https://www.example.com/abc?abc=123&cde=456'
    assert unicode_urldecode('localhost.dev') == 'localhost.dev'
    assert unicode_urldecode('https://localhost.dev/abc?abc=123&cde=456') == 'https://localhost.dev/abc?abc=123&cde=456'
    assert unicode_urldecode('https://localhost.dev/abc?abc=abc&abc=123') == 'https://localhost.dev/abc?abc=abc&abc=123'


# Generated at 2022-06-25 09:21:29.305965
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # everything goes well
    filter_module_0 = FilterModule()
    assert (filter_module_0.filters() is not None)


# Generated at 2022-06-25 09:21:34.929521
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%') == u'%'
    assert unicode_urldecode('abc') == u'abc'


# Generated at 2022-06-25 09:21:41.434292
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wieers') == u'dag wieers'


# Generated at 2022-06-25 09:21:44.386173
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    url_encode_0 = filter_module_0.filters()
    assert url_encode_0


# Generated at 2022-06-25 09:21:46.473044
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters = filter_module_0.filters()


# Generated at 2022-06-25 09:21:55.300405
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo+bar', for_qs=True) == 'foo%2Bbar'



# Generated at 2022-06-25 09:22:02.117862
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A7') == u'\xe7'
    assert unicode_urldecode('%E2%86%92') == u'\u2192'
    assert unicode_urldecode('%27%2A%2B') == u'\'*+'
    assert unicode_urldecode('%20%5B%5D%5C%5E%5F%60%7B%7C%7D%7E') == u' [\\]^_`{|}~'



# Generated at 2022-06-25 09:22:12.198282
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test Cases.
    test_cases = (
        # test_case_0
        (
            u'asdf',
            u'asdf',
        ),
        # test_case_1
        (
            u'/',
            u'%2F',
        ),
        # test_case_2
        (
            u'asdf',
            u'asdf',
        ),
        # test_case_3
        (
            u'asdf',
            u'asdf',
        ),
    )

    for test_case in test_cases:
        test_input = test_case[0]
        expected = test_case[1]

        actual = unicode_urlencode(test_input)

        msg = "Expected {0} but got {1}".format(expected, actual)

# Generated at 2022-06-25 09:22:13.668039
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F+%2F') == '/+/'



# Generated at 2022-06-25 09:22:18.469198
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('python%20is%20fun%21') == 'python is fun!'
    assert unicode_urldecode('python%20is%20fun%2F') == 'python is fun/'
    assert unicode_urldecode('hell%2C%20world!') == 'hell, world!'

# Generated at 2022-06-25 09:22:22.461943
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    dictionary_0 = filter_module_0.filters()
    assert dictionary_0['urldecode'](u'93c6a33cfa1a7dcd388d6d4687a3a9c4327b1b80') == u'93c6a33cfa1a7dcd388d6d4687a3a9c4327b1b80'
# Test method of class FilterModule (1 of 2)

# Generated at 2022-06-25 09:22:28.019963
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    actual_result_0 = filter_module_0.filters()
    expected_result_0 = {'urldecode': do_urldecode }
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-25 09:22:38.570997
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'föö') == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'föö'.encode('utf-8')) == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'föö'.encode('utf-16')) == u'f%C3%B6%C3%B6'
    assert do_urlencode(u'föö', for_qs=True) == u'f%C3%B6%C3%B6'
    assert do_urlencode

# Generated at 2022-06-25 09:22:41.264874
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_ret_0 = filter_module_0.filters()
    assert type(filters_ret_0) == dict
    assert 'urldecode' in filters_ret_0


# Generated at 2022-06-25 09:22:46.499868
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    jinja2_filters_0 = filter_module_0.filters()
    assert jinja2_filters_0['urldecode'] == do_urldecode, 'AssertionError: %s' % (jinja2_filters_0['urldecode'],)


# Generated at 2022-06-25 09:22:50.310667
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module_1 = FilterModule()
    assert filter_module_1.filters() is not None



# Generated at 2022-06-25 09:22:53.691347
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%7B%22type%22%3A%22network.dns.dns_resolution%22%7D") == '{"type":"network.dns.dns_resolution"}'


# Generated at 2022-06-25 09:22:59.551756
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("Dag%20Wieers%20%26%20%C3%A9%C3%A8%C3%A0%C3%A7") == "Dag Wieers & éèàç"


# Generated at 2022-06-25 09:23:01.764429
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()

# Local variables:
# compile-command: "pytest do_url.py"
# End:

# Generated at 2022-06-25 09:23:04.929582
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:23:14.112589
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('hello world') == 'hello%20world'
    assert unicode_urlencode('http://www.example.com/') == 'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode('http://www.example.com/', True) == 'http%3A%2F%2Fwww.example.com%2F'
    assert unicode_urlencode('/foo bar/') == '%2Ffoo%20bar%2F'
    assert unicode_urlencode('/foo bar/', True) == '%2Ffoo+bar%2F'
    assert unicode_urlencode('test+test') == 'test%2Btest'

# Generated at 2022-06-25 09:23:16.524241
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit test for method filters of class FilterModule
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()


# Generated at 2022-06-25 09:23:27.440433
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/this is a/test') == '/this%20is%20a/test'
    assert unicode_urlencode('/this is a/test', for_qs=True) == '/this%20is%20a/test'
    assert unicode_urlencode(u'/this is a/test', for_qs=False) == '/this%20is%20a/test'
    assert unicode_urlencode(u'/this is a/test', for_qs=True) == '/this%20is%20a/test'


# Generated at 2022-06-25 09:23:34.398811
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u''
    for_qs = False
    assert unicode_urlencode(string, for_qs) == u'%00'
    string = u''
    for_qs = True
    assert unicode_urlencode(string, for_qs) == u'%00'
    string = u' '
    for_qs = False
    assert unicode_urlencode(string, for_qs) == u'%20'
    string = u' '
    for_qs = True
    assert unicode_urlencode(string, for_qs) == u'%20'
    string = u'!'
    for_qs = False
    assert unicode_urlencode(string, for_qs) == u'!'
    string = u'!'
    for_qs = True

# Generated at 2022-06-25 09:23:39.054678
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()

    # unit test for 'FilterModule.filters'
    assert(filter_module_1.filters() == {'urldecode': do_urldecode})

# Generated at 2022-06-25 09:23:44.966650
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'/', True) == u'%2F'
    assert unicode_urlencode(u'a/b') == u'a%2Fb'
    assert unicode_urlencode(u'a/b', True) == u'a%2Fb'


# Generated at 2022-06-25 09:23:49.636913
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'abc%20def' == do_urlencode('abc def')
    ret = do_urlencode({
        "a": "b",
        "c": "d"
    })
    assert 'a=b&c=d' == ret


# Generated at 2022-06-25 09:23:53.921146
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('''%3C%3E%2F%22%27%7B%7D%5B%5D%23%3A%25''') == '<>/"\'{}[]#:%'


# Generated at 2022-06-25 09:23:56.677960
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()



# Generated at 2022-06-25 09:23:59.249360
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    result = filter_module_1.filters()
    assert result is not None


# Generated at 2022-06-25 09:24:01.393599
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create a FilterModule object
    filter_module_0 = FilterModule()
    # Call method filters of filter_module_0
    filters = filter_module_0.filters()


# Generated at 2022-06-25 09:24:03.124895
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2Fetc%2Fpasswd') == u'/etc/passwd'


# Generated at 2022-06-25 09:24:10.180363
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:24:15.931778
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test only characters which are not a single byte
    q = '%C3%B6'
    unicode_urldecode(q)


# Generated at 2022-06-25 09:24:22.631816
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urldecode('a%2Bb') == 'a+b'
    assert unicode_urldecode('test%3Dtest') == 'test=test'
    assert unicode_urlencode('a+b') == 'a%2Bb'
    assert unicode_urlencode('test=test') == 'test%3Dtest'
    assert unicode_urlencode('a+b', True) == 'a%2Bb'
    assert unicode_urlencode('test=test', True) == 'test%3Dtest'


# Generated at 2022-06-25 09:24:23.731180
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('a%20b%20c') == 'a b c')


# Generated at 2022-06-25 09:24:25.390992
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input = "hello"
    output = "hello"
    assert unicode_urldecode(input) == output


# Generated at 2022-06-25 09:24:31.778395
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2Fcgi%2F%3Ffoo%3Dbar%26abc%3Ddef%26def%3D%26abc%3Dxyz') == 'http://example.com/cgi/?foo=bar&abc=def&def=&abc=xyz'


# Generated at 2022-06-25 09:24:38.733800
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == u'foo'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'é') == u'%C3%A9'


# Generated at 2022-06-25 09:24:44.164568
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a', for_qs=False) == 'a'
    assert unicode_urlencode('a b', for_qs=False) == 'a%20b'
    assert unicode_urlencode('a', for_qs=True) == 'a'
    assert unicode_urlencode('a b', for_qs=True) == 'a+b'


# Generated at 2022-06-25 09:24:47.227082
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b"unit%20test") == "unit test"
    assert unicode_urldecode("unit%20test") == "unit test"
    assert unicode_urldecode(b"unit%20test") == "unit test"


# Generated at 2022-06-25 09:24:53.229295
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2520') == '%20'
    assert unicode_urldecode('%252') == '%2'
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode(u'%3D') == '='
    assert unicode_urldecode(b'%3D') == '='


# Generated at 2022-06-25 09:25:01.144626
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo=bar') == u'foo=bar'


# Generated at 2022-06-25 09:25:07.325653
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'8%20day') == u'8 day'
    assert unicode_urldecode(u'%20%20n%20%20') == u'  n  '



# Generated at 2022-06-25 09:25:15.551469
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("http%3A%2F%2Fwww.google.com%2Fsearch%3Fhl%3Den%26biw%3D1152%26bih%3D746%26q%3Dfoo%2Bbar%2Bbaz%26aq%3Df%26aqi%3D%26aql%3D%26oq%3D") == "http://www.google.com/search?hl=en&biw=1152&bih=746&q=foo+bar+baz&aq=f&aqi=&aql=&oq="

# Generated at 2022-06-25 09:25:20.043259
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  filter_module = FilterModule()

  filters = filter_module.filters()
  assert(isinstance( filters, dict))


# Generated at 2022-06-25 09:25:21.690500
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello%20World%21') == 'Hello World!'



# Generated at 2022-06-25 09:25:24.223028
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'my%20name%20is%20%E4%B9%9F%E7%99%BE%E5%B9%B4')


# Generated at 2022-06-25 09:25:25.405116
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_obj = FilterModule()
    filters = filter_module_obj.filters()
    

# Generated at 2022-06-25 09:25:28.239264
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filter_module_1.filters()


# Generated at 2022-06-25 09:25:37.501404
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test function unicode_urldecode for correct results
    '''
    assert unicode_urldecode(b'ba%2C2ms') == u'ba,2ms'
    assert unicode_urldecode(u'ba%2C2ms') == u'ba,2ms'
    assert unicode_urldecode('ba%2C2ms') == u'ba,2ms'
    assert unicode_urldecode(b'foobar') == u'foobar'
    assert unicode_urldecode(u'foobar') == u'foobar'
    assert unicode_urldecode('foobar') == u'foobar'



# Generated at 2022-06-25 09:25:49.064224
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with a string
    assert unicode_urldecode('hello_world') == 'hello_world'
    # Test with a unicode string
    assert unicode_urldecode(u'hello_world') == u'hello_world'
    # Test with a unicode string and non-ascii chars
    assert unicode_urldecode(u'hello_\u221e') == u'hello_\u221e'
    # Test with a byte string
    assert unicode_urldecode(b'hello_world') == 'hello_world'
    # Test with a byte string and non-ascii chars
    assert unicode_urldecode(b'hello_\xe2\x88\x9e') == u'hello_\u221e'
    # Test with a unicode string, non

# Generated at 2022-06-25 09:25:56.736856
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert isinstance(filter_module_1.filters(), dict)

# Generated at 2022-06-25 09:26:02.096251
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Ffoo%20bar%2Fbaz') == 'http://foo bar/baz'
    # a test to show that Unicode strings are not allowed, but they are tolerated and processed OK
    assert unicode_urldecode(u'http%3A%2F%2Ffoo%20bar%2Fbaz') == 'http://foo bar/baz'

# Generated at 2022-06-25 09:26:06.301196
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    pass

# Generated at 2022-06-25 09:26:08.909055
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%21') == ' !'
    assert unicode_urldecode('%2A%2B') == '*+'
    assert unicode_urldecode('%2C%2F') == ',-./'


# Generated at 2022-06-25 09:26:20.620647
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("https://docs.ansible.com/ansible/latest/modules/win_chocolatey_module.html") == "https%3A%2F%2Fdocs.ansible.com%2Fansible%2Flatest%2Fmodules%2Fwin_chocolatey_module.html"
    assert do_urlencode("https://docs.ansible.com/ansible/latest/modules/win_chocolatey_module.html?view") == "https%3A%2F%2Fdocs.ansible.com%2Fansible%2Flatest%2Fmodules%2Fwin_chocolatey_module.html%3Fview"

# Generated at 2022-06-25 09:26:26.621813
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test a string
    string = 'https://localhost/test/%22%20%2f%3e%3b%3c/%3D%3A%20here/is/it'
    result = unicode_urldecode(string)
    if PY3:
        assert result == 'https://localhost/test/\" /><;</=:/ here/is/it'
    else:
        assert result == 'https://localhost/test/" /><;</=:/ here/is/it'

# Generated at 2022-06-25 09:26:27.928244
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters = filter_module_0.filters()
    return filters

# Generated at 2022-06-25 09:26:30.305451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    

# Generated at 2022-06-25 09:26:34.230900
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert "urldecode" in filter_module.filters()

# Generated at 2022-06-25 09:26:37.982756
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    jinja2_filters_0 = filter_module_0.filters()
    assert jinja2_filters_0['urldecode'] == do_urldecode, 'urldecode is not equal to do_urldecode'


# Generated at 2022-06-25 09:26:45.308291
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    # None tested in test_case_0
    #None


# Generated at 2022-06-25 09:26:47.436777
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test case 0
    if True:
        float_0 = -3068.03897
        var_0 = do_urldecode(float_0)
        print(var_0)


# Generated at 2022-06-25 09:26:49.653987
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = -3.054013e-05
    var_0 = unicode_urldecode(float_0)
    assert var_0 ==  b'-3.054013e-05'


# Generated at 2022-06-25 09:26:59.576496
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    import types
    all_attributes = dir(basic)
    test_cases = filter(lambda x: x.startswith('test_'), all_attributes)
    for test_case in test_cases:
        eval(test_case)()

if __name__ == '__main__':
    import sys, types, time
    #import trace

    #tracer = trace.Trace(ignoredirs=[sys.prefix, sys.exec_prefix], trace=0, count=1)
    #tracer.run('test_FilterModule_filters()')
    #r = tracer.results()
    #r.write_results(show_missing=True, coverdir=".")
    test_FilterModule_filters()
    #test_case_0()
    #test_case

# Generated at 2022-06-25 09:27:01.053074
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert do_urldecode('%E2%98%83') == "\u2603"

# Generated at 2022-06-25 09:27:02.449754
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = -3068.03897
    var_0 = do_urldecode(float_0)

# Generated at 2022-06-25 09:27:04.770536
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = -3068.03897
    filter_0 = FilterModule()
    var_0 = filter_0.filters()
    # AssertionError: False is not true
    assert var_0


# Generated at 2022-06-25 09:27:07.134604
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    myFilterModule = FilterModule()
    string_0 = myFilterModule.filters()


# Generated at 2022-06-25 09:27:10.503046
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("...") == "..."


# Generated at 2022-06-25 09:27:12.720790
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = -3068.03897
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:27:20.776744
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_0 = FilterModule()
    assert_equal(str(FilterModule_0.filters()), "{'urldecode': <function do_urldecode at 0x7f6579a66b70>, 'urlencode': <function do_urlencode at 0x7f6579a66a60>}")


# Generated at 2022-06-25 09:27:22.001329
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule_instance = FilterModule()
    assert isinstance(FilterModule.filters(filtermodule_instance), dict)

# Generated at 2022-06-25 09:27:23.650569
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = "https://www.google.com/search?q=filetype:pdf+ansible+modules&btnI"
    var_0 = unicode_urlencode(string)

# Generated at 2022-06-25 09:27:25.895335
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    a = unicode_urlencode('b', 'c')
    if a != u'b':
        raise Exception('Failed')


# Generated at 2022-06-25 09:27:34.254192
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'mobilization'
    str_1 = 'merchant'
    str_2 = 'client'
    str_3 = 'key'
    str_4 = unicode_urlencode(str_0)
    assert not str_4
    str_5 = unicode_urlencode(str_1)
    assert str_5 == 'merchant'
    str_6 = unicode_urlencode(str_2)
    assert str_6 == 'client'
    str_7 = unicode_urlencode(str_3)
    assert str_7 == 'key'


# Generated at 2022-06-25 09:27:36.199943
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    var_0 = unicode_urlencode(3068.03897)


# Generated at 2022-06-25 09:27:44.808716
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    list_0 = list([123.0, -0.0, -9.9])
    dict_0 = dict(enumerate(list_0))
    # Iterate using the given argument
    var_0 = unicode_urldecode(12345.0)
    # Iterate using the given argument
    var_1 = unicode_urldecode(-1.0)
    # Iterate using the given argument
    var_2 = unicode_urldecode(-1.0)
    # Iterate using the given argument
    var_3 = unicode_urldecode(-9.9)
    # Iterate using the given argument
    var_4 = unicode_urldecode(-0.0)
    # Iterate using the given argument

# Generated at 2022-06-25 09:27:56.312085
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    u1 = u'%C3%A0'
    assert unicode_urldecode(u1) == u'à'
    u1 = u'%E2%82%AC'
    assert unicode_urldecode(u1) == u'€'
    u1 = u'%E2%82'
    assert unicode_urldecode(u1) == u'%E2%82'
    u1 = u'%E2%82%AB'
    assert unicode_urldecode(u1) == u'\u0302'
    u1 = u'%F0%9D%84%9E'
    assert unicode_urldecode(u1) == u'\U0001D11E'
    u1 = u'%F0%9D%84'


# Generated at 2022-06-25 09:28:00.380510
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = -3068.03897
    var_0 = do_urldecode(float_0)

# Main program
if __name__ == '__main__':
    test_filter_module()

# Generated at 2022-06-25 09:28:05.452199
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    var_0 = f.filters()

# unit tests
if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:28:21.375781
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string1 = "http://www.cisco.com/tac.html?a=b&c=d"
    string2 = "http://www.cisco.com/tac.html?a=/b&c=d"
    string3 = "http://www.cisco.com/tac.html?a=b&c=/d"
    string4 = "http://www.cisco.com/tac.html?a=/b&c=/d"
    string5 = "http://www.cisco.com/tac.html?a=/b&c=/d?#h"
    assert unicode_urlencode(string1) == u'http%3A%2F%2Fwww.cisco.com%2Ftac.html%3Fa%3Db%26c%3Dd'
    assert unic

# Generated at 2022-06-25 09:28:30.494017
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:28:35.220255
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = -3068.03897
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.filters()
    var_0 = do_urldecode(float_0)


# Generated at 2022-06-25 09:28:39.463474
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-25 09:28:41.468940
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = -3068.03897
    var_0 = do_urldecode(float_0)
    pass


# Generated at 2022-06-25 09:28:43.881224
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = -3068.03897
    var_0 = unicode_urldecode(float_0)
    assert var_0 == u'-3068.03897'



# Generated at 2022-06-25 09:28:46.926981
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = -3068.03897
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:28:52.500446
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("false") == "false"
    assert unicode_urldecode("8678") == "8678"
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("/") == "/"
    assert unicode_urldecode("5347") == "5347"


# Generated at 2022-06-25 09:28:58.145639
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    """Unit test for function unicode_urldecode"""

    # Test case 0
    float_0 = -2664.86604
    var_0 = unicode_urldecode(float_0)

    assert var_0 == "-2664.86604"


# Generated at 2022-06-25 09:29:00.597637
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "foo"
    value = unicode_urldecode(string)
    assert len(value) == 3
    assert value == "foo"


# Generated at 2022-06-25 09:29:10.547148
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd') == 'abcd'
    assert unicode_urlencode('abcd', False) == 'abcd'
    assert unicode_urlencode('abcd', True) == 'abcd'
    assert unicode_urlencode('abcd', True) == 'abcd'


# Generated at 2022-06-25 09:29:15.754900
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Setup test case data
    float_0 = -3068.03897

    jinja2_filter = FilterModule()
    var_0 = unicode_urldecode(float_0)

    # Execute the method being tested
    filters = jinja2_filter.filters()

    # Verify the results
    # assert (var_0 == filters['urldecode'])


# Generated at 2022-06-25 09:29:20.181424
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('-3068.03897') == unicode(-3068.03897)


# Generated at 2022-06-25 09:29:30.817611
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Declaration of the class instance
    instance0 = FilterModule()

    # Call of the method filters
    # var_0 is of type ansible.module_utils._text.AnsibleUnicode
    var_0 = instance0.filters()

    # Tests

# Generated at 2022-06-25 09:29:32.658828
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = -3068.03897
    var_0 = unicode_urldecode(float_0)
    pass


# Generated at 2022-06-25 09:29:34.820567
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "type%3D%26name%3D%2F"
    expected = "type=&name=/"
    assert unicode_urldecode(string) == expected


# Generated at 2022-06-25 09:29:39.310946
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = -3068.03897
    do_urldecode(float_0)
    var_0 = filters()


# Generated at 2022-06-25 09:29:46.176796
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('Hello World') == 'Hello%20World'
    assert unicode_urlencode('Hello World', for_qs=True) == 'Hello+World'
    assert unicode_urlencode('Hello World/') == 'Hello%20World%2F'
    assert unicode_urlencode('Hello World/', for_qs=True) == 'Hello+World%2F'
    assert unicode_urlencode(u'Hello World') == 'Hello%20World'
    assert unicode_urlencode(u'Hello World', for_qs=True) == 'Hello+World'
    assert unicode_urlencode(u'Hello World/') == 'Hello%20World%2F'