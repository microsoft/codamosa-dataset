

# Generated at 2022-06-25 09:19:54.415231
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foobar') == u'foobar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'



# Generated at 2022-06-25 09:20:00.677591
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    blacklist = ['\x00']
    white = list(range(0x21, 0x7f)) + list(range(0xa1, 0xff))
    non_white = [x % 0xff for x in range(256) if x not in white and x not in blacklist]
    non_white += non_white
    non_white_s = ''.join([chr(x) for x in non_white])
    urldecoded = unicode_urldecode(non_white_s)
    assert len(urldecoded) < len(non_white_s)
    assert urldecoded == len(urldecoded)*'\ufffd'
    print('Urldecoded: %s' % urldecoded)


# Generated at 2022-06-25 09:20:02.753985
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()


# Generated at 2022-06-25 09:20:12.887591
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("[[<>(&*{}|#~=%^+-.)]]") == "%5B%5B%3C%3E(%26*%7B%7D%7C%23~%3D%25%5E%2B-.%29%5D%5D"
    assert unicode_urlencode("[[<>(./&*{}|#~=%^+-.)]]") == "%5B%5B%3C%3E(.%2F%26*%7B%7D%7C%23~%3D%25%5E%2B-.%29%5D%5D"
    assert unicode_urlencode("") == ""

# Generated at 2022-06-25 09:20:20.978584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unquote_plus(to_bytes(u"http://www.%E4%BD%A0%E5%A5%BD.com/")) == u'http://www.你好.com/'
    else:
        assert unquote_plus(u'http://www.%E4%BD%A0%E5%A5%BD.com/') == u'http://www.你好.com/'


# Generated at 2022-06-25 09:20:28.090822
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%20+') == '%20+'
    assert unicode_urldecode('%2B+') == '+ +'
    assert unicode_urldecode('%5E+') == '^ +'
    assert unicode_urldecode('%7C+') == '| +'


# Generated at 2022-06-25 09:20:31.124080
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"data%3D%27asdf%27%20AND%20rulename%3D%27test%27") == u"data='asdf' AND rulename='test'"


# Generated at 2022-06-25 09:20:32.947259
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'key=value'
    assert(unicode_urldecode(string) == 'key=value')


# Generated at 2022-06-25 09:20:34.150396
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'abc') == 'abc'



# Generated at 2022-06-25 09:20:40.046529
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert not PY3, 'This test is only for Python 2.x'
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('x') == 'x'
    assert unicode_urldecode('%') == '%'
    assert unicode_urldecode('%x') == '%x'
    assert unicode_urldecode('%0') == '%0'
    assert unicode_urldecode('%1') == '%1'
    assert unicode_urldecode('%01') == '%01'
    assert unicode_urldecode('%10') == '%10'
    assert unicode_urldecode('%20') == '%20'

# Generated at 2022-06-25 09:20:45.437040
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters = filter_module_0.filters()
    assert "urldecode" in filters
    assert "urlencode" in filters
    assert len(filters) == 2


# Generated at 2022-06-25 09:20:56.351663
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E5%B7%A5%E5%8E%82%E6%A5%BC%E6%A0%87%E6%B5%8B%E8%AF%95%E6%9C%9F%E9%AA%8C4456.xlsx') == '工压楼标测试期验4456.xlsx'

# Generated at 2022-06-25 09:21:07.022544
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a 1') == 'a%201'
    assert unicode_urlencode(u'a@1') == 'a@1'
    assert unicode_urlencode(u'a,1') == 'a%2C1'
    assert unicode_urlencode(u'a/1') == 'a%2F1'
    assert unicode_urlencode(u'a 1', for_qs=True) == 'a%201'
    assert unicode_urlencode(u'a@1', for_qs=True) == 'a%40%31'
    assert unicode_urlencode(u'a,1', for_qs=True) == 'a%2C1'
    assert unicode_urlencode(u'a/1', for_qs=True)

# Generated at 2022-06-25 09:21:10.882730
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%00%0A%0B%0D%0C") == "\x00\n\x0b\r\x0c"
    assert unicode_urldecode("%00%0a%0b%0d%0c") == "\x00\n\x0b\r\x0c"
    assert unicode_urldecode("%00%0a%0b%0d%0c") == unicode_urldecode("%00%0A%0B%0D%0C")

    assert unicode_urldecode("%00%09%0d%0c") == "\x00\t\r\x0c"
    assert unicode_urldecode("%00%09%0d%0c") == unicode_urldec

# Generated at 2022-06-25 09:21:14.338920
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:21:19.515055
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert (unicode_urldecode('abcdefg%20') == 'abcdefg ')
    assert (unicode_urldecode('abcdefg+') == 'abcdefg ')
    assert (unicode_urldecode('abcdefg%7E') == 'abcdefg~')
    assert (unicode_urldecode('%E4%BA%BA') == u'人')


# Generated at 2022-06-25 09:21:24.022909
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'

if __name__ == '__main__':
    test_case_0()
    test_unicode_urlencode()

# Generated at 2022-06-25 09:21:29.461032
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test for simple string
    test_string = 'http://example.com/foo/?bar=baz'
    assert unicode_urldecode(test_string) == 'http://example.com/foo/?bar=baz'
    
    # Test for UTF-8 Encoded string
    test_string = 'http%3A%2F%2Fexample.com%2Ffoo%2F%3Fbar%3Dbaz'
    assert unicode_urldecode(test_string) == 'http://example.com/foo/?bar=baz'
    

# Generated at 2022-06-25 09:21:32.705278
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = {
        '%20': ' ',
        '+': '+',
        '%2F': '/'
    }

    for key_input, output in test_cases.items():
        assert unicode_urldecode(key_input) == output, 'Output expected: {0}, but got: {1}'.format(output, unicode_urldecode(key_input))


# Generated at 2022-06-25 09:21:35.904608
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("ABC") == "ABC"
    assert unicode_urlencode("ABC") != "abc"
    assert unicode_urlencode("ABC") != "aBC"
    assert unicode_urlencode("abc") != "ABC"
    assert unicode_urlencode("aBC") != "ABC"
    assert unicode_urlencode("aBc") != "ABC"
    assert unicode_urlencode("a") != "ABC"
    assert unicode_urlencode("Ab") != "ABC"
    assert unicode_urlencode("aC") != "ABC"


# Generated at 2022-06-25 09:21:44.699777
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }

    filter_module_1 = FilterModule()
    assert filter_module_1.filters() == {
        'urldecode': do_urldecode,
    }


# Generated at 2022-06-25 09:21:47.461679
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    test_case_0()



if __name__ == '__main__':
    test_FilterModule_filters();

# Generated at 2022-06-25 09:21:55.649821
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    in_1 = b"N%C3%B6rth%20D%C3%A4kota/N%C3%B6rth%20D%C3%A4kota%2F1"
    expected_out_1 = "Nörth Däkota/Nörth Däkota/1"
    assert unicode_urldecode(in_1) == expected_out_1


# Generated at 2022-06-25 09:22:05.010682
# Unit test for function do_urlencode
def test_do_urlencode():
    # empty string
    assert(do_urlencode("") == "")
    assert(do_urlencode("") == "")

    # string
    assert(do_urlencode("abc") == "abc")
    assert(do_urlencode("abc") == "abc")
    assert(do_urlencode("a b c") == "a%20b%20c")
    assert(do_urlencode("a b c") == "a%20b%20c")

    # list
    assert(do_urlencode(["a", "b", "c"]) == "a&b&c")
    assert(do_urlencode(["a", "b", "c"]) == "a&b&c")

# Generated at 2022-06-25 09:22:09.441711
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    res = filter_module.filters()


# Generated at 2022-06-25 09:22:18.887993
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%00%1f/%7F') == '\x00\x1f/\x7f'
    assert unicode_urldecode('%00%1f/%7F') == b'\x00\x1f/\x7f'.decode('ascii')
    assert unicode_urldecode('%00%1f/%7F') == u'\x00\x1f/\x7f'


# Generated at 2022-06-25 09:22:25.235079
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    #  string = 'toto is the name'
    string = 'toto-is-the-name'
    res = unicode_urlencode(string)
    assert res == 'toto-is-the-name'
    #  res = unicode_urlencode(string, for_qs=True)
    res = unicode_urlencode(string)
    assert res == 'toto-is-the-name'
    string = 'ééé'
    res = unicode_urlencode(string)
    assert res == '%C3%A9%C3%A9%C3%A9'


# Generated at 2022-06-25 09:22:27.642712
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    expected = 'abcd%E2%82%AC+%2B%E2%82%AC'
    assert unicode_urlencode('abcd€ ++€', for_qs=True) == expected
    assert unicode_urlencode('abcd€ ++€') == expected


# Generated at 2022-06-25 09:22:37.879218
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7Eabc') == '~abc'
    assert unicode_urldecode('%21abc') == '!abc'
    assert unicode_urldecode('%2Babc') == '+abc'
    assert unicode_urldecode('%26abc') == '&abc'
    assert unicode_urldecode('%2Cabc') == ',abc'
    assert unicode_urldecode('%3Aabc') == ':abc'


# Generated at 2022-06-25 09:22:40.970888
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # unicode_urldecode(string)
    assert unicode_urldecode(u'%A4%F0%9F%98%80') == u'\u00A4\u03f0\U0001F420'


# Generated at 2022-06-25 09:22:46.501212
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input = b'cat%20%26%20dog'
    if PY3:
        input = input.decode('utf-8')
    expected_result = 'cat & dog'
    actual_result = unicode_urldecode(input)
    assert actual_result == expected_result


# Generated at 2022-06-25 09:22:51.639723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    result = filter_module_1.filters()
    assert result


test_case_0()
if __name__ == "__main__":
    test_FilterModule_filters()

# Generated at 2022-06-25 09:23:03.384203
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'\xe9'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_

# Generated at 2022-06-25 09:23:11.267934
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("foo") == "foo"
    assert unicode_urlencode("foo bar") == "foo%20bar"
    assert unicode_urlencode("bar/foo") == "bar%2Ffoo"
    assert unicode_urlencode("bar/foo", for_qs=True) == "bar%2Ffoo"
    assert unicode_urlencode("bar foo") == "bar%20foo"


# Generated at 2022-06-25 09:23:19.287296
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%2a') == '*'
    assert unicode_urldecode('%2A') == '*'
    assert unicode_urldecode(u'%2A') == '*'
    assert unicode_urldecode(u'abc-%2A') == 'abc-*'


# Generated at 2022-06-25 09:23:20.062129
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:23:26.932884
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("abc") == "abc"
    assert unicode_urldecode("123") == "123"
    assert unicode_urldecode("<>?\"%&()=+") == "<>?\"%&()=+"
    assert unicode_urldecode("%20%21%22%23%24") == " !\"#$"
    assert unicode_urldecode("%2B%2C%2F%3A%3B%3D%3F%40") == "+,/:;=?@"
    assert unicode_urldecode("%5B%5D%5E%60%7B%7C%7D") == "[]^`{|}"


# Generated at 2022-06-25 09:23:28.285242
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _filter_module_0 = FilterModule()
    _ret = _filter_module_0.filters()
    assert _ret



# Generated at 2022-06-25 09:23:33.183433
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("hello world") == "hello%20world"
    assert unicode_urlencode("hello_world") == "hello_world"
    assert unicode_urlencode("hello=world") == "hello%3Dworld"
    assert unicode_urlencode("hello+world") == "hello%2Bworld"
    assert unicode_urlencode("hello/world") == "hello%2Fworld"
    assert unicode_urlencode("hello world", for_qs=True) == "hello+world"
    assert unicode_urlencode("hello=world", for_qs=True) == "hello%3Dworld"
    assert unicode_urlencode("hello+world", for_qs=True) == "hello%2Bworld"

# Generated at 2022-06-25 09:23:39.896559
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'This string will be URL encoded') == b'This%20string%20will%20be%20URL%20encoded'
    assert do_urlencode(u'This string will be URL encoded') == 'This%20string%20will%20be%20URL%20encoded'

# Generated at 2022-06-25 09:23:48.499282
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(515) == u"515"
    assert unicode_urldecode("%24") == u"$"
    assert unicode_urldecode("%1") == u"%"
    assert unicode_urldecode("%") == u"%"
    assert unicode_urldecode("%26") == u"&"
    assert unicode_urldecode("%2") == u"%"
    assert unicode_urldecode("%25%26") == u"%&"
    assert unicode_urldecode("%") == u"%"



# Generated at 2022-06-25 09:23:50.296427
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = FilterModule()
    int_0.filters()


# Generated at 2022-06-25 09:23:55.412887
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = '+00%05.1f'
    var_0 = unicode_urldecode(int_0)
    msg = 'The actual value {} does not match expected value {}'
    assert var_0 == int_0, msg.format(var_0, int_0)


# Generated at 2022-06-25 09:23:59.208782
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Set up test environment
    FilterModule_instance = FilterModule()

    # Call method
    #assert FilterModule_instance.filters() == ''
    # Return value
    assert isinstance(FilterModule_instance.filters(), dict)


# Generated at 2022-06-25 09:24:00.682035
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = 515
    FilterModule().filters(int_0)


# Generated at 2022-06-25 09:24:02.131893
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode(515)
    
    assert result == 515



# Generated at 2022-06-25 09:24:03.474055
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)
    print(filters)

# Main test function.

# Generated at 2022-06-25 09:24:14.889455
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(5) == 5
    assert unicode_urldecode(5.0) == 5.0
    assert unicode_urldecode(515) == 515
    assert unicode_urldecode(515.0) == 515.0
    assert unicode_urldecode(3.14) == 3.14
    assert unicode_urldecode(True) == True
    assert unicode_urldecode('sOme') == 'sOme'
    assert unicode_urldecode('SOME') == 'SOME'
    assert unicode_urldecode('SoMe') == 'SoMe'
    assert unicode_urldecode('soME') == 'soME'
    assert unicode_urldecode('some') == 'some'


# Generated at 2022-06-25 09:24:15.930988
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()



# Generated at 2022-06-25 09:24:17.091058
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() is not None


# Generated at 2022-06-25 09:24:20.225458
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_0 = FilterModule()
    var_0 = module_0.filters()


# Generated at 2022-06-25 09:24:22.339058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 09:24:23.110871
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(5) == u'5'


# Generated at 2022-06-25 09:24:24.623221
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'\r\n') == u'%0D%0A'



# Generated at 2022-06-25 09:24:28.500901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = 515
    unicode_urldecode(int_0)

# Generated at 2022-06-25 09:24:32.633256
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input = quot = 515
    output = '%3F'
    var_0 = unicode_urldecode(input)
    assert var_0 == output


# Generated at 2022-06-25 09:24:39.650913
# Unit test for function do_urlencode
def test_do_urlencode():
    if PY3:
        # Testing for Python 3
        int_0 = 515
        var_0 = do_urlencode(int_0)
        var_1 = u'515'
        # Testing of assertion:
        assert var_0 == var_1
    else:
        # Testing for Python 2
        int_0 = 515
        var_0 = do_urlencode(int_0)
        var_1 = u'515'
        # Testing of assertion:
        assert var_0 == var_1



# Generated at 2022-06-25 09:24:41.666748
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'515') == "515"


# Generated at 2022-06-25 09:24:42.870294
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    int_0 = 515
    var_0 = unicode_urldecode(int_0)



# Generated at 2022-06-25 09:24:44.884315
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == '%2F'
    assert unicode_urldecode('%2520') == '%20'
    assert unicode_urldecode('%252F') == '/'
    assert unicode_urldecode('%252520') == '%20'


# Generated at 2022-06-25 09:24:52.631957
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    dict_0 = {u"a0": {"b0": {"c0": {"d0": u"", "d1": u"d1", "d2": u"d2", "d3": u"d3"}, "c1": u"c1", "c2": u"c2", "c3": u"c3"}, "b1": u"b1", "b2": u"b2", "b3": u"b3"}, "a1": u"a1", "a2": u"a2", "a3": u"a3"}
    var_0 = unicode_urldecode(dict_0)


# Generated at 2022-06-25 09:24:54.007459
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('515') == '515'


# Generated at 2022-06-25 09:25:02.448970
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No exceptions for unknown types (return None)
    assert unicode_urldecode(None) is None
    assert unicode_urldecode(False) is None
    assert unicode_urldecode(0) is None
    assert unicode_urldecode(0.0) is None
    assert unicode_urldecode(()) is None
    assert unicode_urldecode([]) is None
    assert unicode_urldecode({}) is None
    assert unicode_urldecode(set()) is None
    assert unicode_urldecode(object()) is None

    # Bytes are unquoted and decoded to unicode string
    assert unicode_urldecode(b'abc+def') == u'abc def'
    # The same goes for unicode strings
    assert unicode

# Generated at 2022-06-25 09:25:08.557903
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = unicode_urldecode('string_0')
    assert var_0 == 'string_0'
    var_1 = unicode_urldecode('string_1')
    assert var_1 == 'string_1'


# Generated at 2022-06-25 09:25:09.960703
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    # unit tests for filters
    assert filterModule.filters()

# Generated at 2022-06-25 09:25:12.929747
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing unicode_urldecode")
    print("=========================")

    print("\nVariable that should be decoded: 515")
    print("Actual result: ", unicode_urldecode("515"))
    print("Expected result: 515")



# Generated at 2022-06-25 09:25:15.198081
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    output = obj.filters();


# Generated at 2022-06-25 09:25:18.971966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 613
    str_0 = unicode_urldecode(int_0)
    str_1 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:25:21.645459
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Input parameters
    int_0 = '515'

    # Function call
    var_0 = unicode_urldecode(int_0)
    print(var_0)



# Generated at 2022-06-25 09:25:28.435932
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bs = b'http://zpravy.idnes.cz/svet.aspx?c=A020308_221019_auto_obc&src=fb101'
    assert(unicode_urlencode(bs) == 'http%3A%2F%2Fzpravy.idnes.cz%2Fsvet.aspx%3Fc%3DA020308_221019_auto_obc%26src%3Dfb101')
    bs = b'http://zpravy.idnes.cz/svet.aspx?c=A020308_221019_auto_obc&src=fb101'

# Generated at 2022-06-25 09:25:31.673597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    instance = FilterModule()
    assert isinstance(instance.filters, dict)


# Generated at 2022-06-25 09:25:33.312946
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()
    assert filters


# Generated at 2022-06-25 09:25:35.205132
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%31%30') == u'10'


# Generated at 2022-06-25 09:25:39.327272
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Set up test values
    int_0 = 515
    var_0 = unicode_urldecode(int_0)

    # Perform the test
    assert var_0 == 515


# Generated at 2022-06-25 09:25:40.541385
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule().filters)

# Generated at 2022-06-25 09:25:41.656739
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()




# Generated at 2022-06-25 09:25:49.554964
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test for int
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
    # Test for str
    str_0 = 'abcdefg'
    var_1 = unicode_urldecode(str_0)
    # Test for dict
    dict_0 = {}
    var_2 = unicode_urldecode(dict_0)
    # Test for list
    list_0 = [('abc', 123), ('def', 456)]
    var_3 = unicode_urldecode(list_0)
    # Test for tuple
    tuple_0 = ('abc', 123)
    var_4 = unicode_urldecode(tuple_0)


# Generated at 2022-06-25 09:25:55.024173
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('https://example.com/?a=%s' % ' '.join(['%(var_0)s', '%(var_0)s', '%(var_0)s'])) == 'https%3A//example.com/%3Fa%3D%%20'.join(['%(var_0)s', '%(var_0)s', '%(var_0)s'])



# Generated at 2022-06-25 09:25:57.042216
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
    assert var_0 == 515


# Generated at 2022-06-25 09:26:03.679450
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
    int_1 = 125
    var_1 = unicode_urldecode(int_1)
    int_2 = 552
    var_2 = unicode_urldecode(int_2)
    int_3 = 975
    var_3 = unicode_urldecode(int_3)
    print(var_0)
    print(var_1)
    print(var_2)
    print(var_3)


# Generated at 2022-06-25 09:26:08.696729
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # We really want to call a protected method of the class
    # that's why we are using _FilterModule__filters
    # It is declared as a property, so we can use it as an instance variable
    filt = FilterModule()
    arr = filt._FilterModule__filters()
    assert (arr['urldecode'] == do_urldecode)


# Generated at 2022-06-25 09:26:11.167838
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ref_0 = u'515'
    ref_1 = '515'
    assert unicode_urldecode('515') == ref_0

    # Should return the same value if given the same value
    assert unicode_urldecode('515') == ref_1



# Generated at 2022-06-25 09:26:17.486841
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_0 = FilterModule()
    ret_0 = class_0.filters()

# Generated at 2022-06-25 09:26:26.428884
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('.%20.') == u'. .')
    assert(unicode_urldecode('/%7Econnman/') == u'/~connman/')
    assert(unicode_urldecode('/%7econnman/') == u'/~connman/')
    assert(unicode_urldecode('/%7econnman/') == u'/~connman/')
    assert(unicode_urldecode('/%7Econnman') == u'/~connman')
    assert(unicode_urldecode('/%7econnman') == u'/~connman')
    assert(unicode_urldecode('/%7econnman') == u'/~connman')

# Generated at 2022-06-25 09:26:31.797738
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'http://www.example.com/some url?a=1&b=2'
    assert unicode_urlencode(string) == u'http%3A//www.example.com/some%20url%3Fa%3D1%26b%3D2'


# Generated at 2022-06-25 09:26:35.501657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = do_urldecode.__name__
    int_1 = unicode_urldecode.__name__
    int_2 = unicode_urlencode.__name__
    var_0 = FilterModule.filters


# Generated at 2022-06-25 09:26:37.899009
# Unit test for function do_urlencode
def test_do_urlencode():
    str_0 = "foo"
    str_1 = unicode_urlencode(str_0)
    assert "foo" == str_1


# Generated at 2022-06-25 09:26:40.106693
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Test with value that contains bytes
    int_0 = 515
    var_0 = unicode_urldecode(int_0)

# Generated at 2022-06-25 09:26:41.936934
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = '515'
    assert unicode_urldecode(var_0) == 515


# Generated at 2022-06-25 09:26:42.765346
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule().filters()) == 2

# Generated at 2022-06-25 09:26:45.423863
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()

# Generated at 2022-06-25 09:26:47.034817
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = 515
    var_0 = unicode_urlencode(value)
    assert var_0 == "%0D"


# Generated at 2022-06-25 09:26:48.822446
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 'Ocho.1'
    var_0 = unicode_urldecode(int_0)
    assert var_0 == 'Ocho.1'


# Generated at 2022-06-25 09:26:50.235099
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule())
    var_0 = filters['urldecode']
    var_1 = filters['urlencode']

# Generated at 2022-06-25 09:26:59.628140
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(to_text(b'https://matthew-harrison.com:8080/index.php?q=%3D%3D%3D&amp')) == to_text(b'https://matthew-harrison.com:8080/index.php?q=%3D%3D%3D&amp')
    assert unicode_urldecode(u'https://matthew-harrison.com:8080/index.php?q=%3D%3D%3D&amp') == b'https://matthew-harrison.com:8080/index.php?q=%3D%3D%3D&amp'

# Generated at 2022-06-25 09:27:01.448613
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
    assert var_0 == '515'



# Generated at 2022-06-25 09:27:02.558248
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    var_0 = unicode_urldecode(int_0)

# Generated at 2022-06-25 09:27:06.389560
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    # Test the real output of filters against the expected output
    filters = fm.filters()

    assert "urldecode" in filters
    assert filters["urldecode"] == do_urldecode

# Generated at 2022-06-25 09:27:10.712199
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string_0 = '515'
    str_ret_0 = unicode_urlencode(string_0)




# Generated at 2022-06-25 09:27:21.175886
# Unit test for function do_urlencode
def test_do_urlencode():
    assert not HAS_URLENCODE
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo:bar') == u'foo%3Abar'
    assert do_urlencode(u'foo;bar') == u'foo%3Bbar'
    assert do_urlencode(u'foo?bar') == u'foo%3Fbar'
    assert do_urlencode(u'foo@bar') == u'foo%40bar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'

# Generated at 2022-06-25 09:27:23.485683
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(test_case_0()) > True

# Generated at 2022-06-25 09:27:26.768036
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Setup
    int_0 = 515
    # Run
    var_0 = unicode_urldecode(int_0)

    assert var_0 == 515


# Generated at 2022-06-25 09:27:31.537211
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Populate the expected values
    expected_0 = '515'

    # Populate the arguments
    int_0 = 515
    var_0 = unicode_urldecode(int_0)

    # Evaluate the function
    #assert expected_0==var_0



# Generated at 2022-06-25 09:27:36.502204
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()



# Generated at 2022-06-25 09:27:40.570051
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        test_case_0()
        print('\033[6;30;42m' + '测试通过' + '\033[0m')
    except AssertionError:
        print('\033[6;30;41m' + '测试失败' + '\033[0m')

# Generated at 2022-06-25 09:27:47.713685
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/foo') == u'/foo'
    assert unicode_urlencode(u'/foo') == u'/foo'
    assert unicode_urlencode('/foo'.encode('utf-8')) == u'/foo'
    assert unicode_urlencode(u'/foo'.encode('utf-8')) == u'/foo'
    assert unicode_urlencode(b'/foo') == u'/foo'
    assert unicode_urlencode(b'/foo', for_qs=False) == u'/foo'
    assert unicode_urlencode(u'/foo', for_qs=False) == u'/foo'
    assert unicode_urlencode(b'/foo', for_qs=True) == u'/foo'

# Generated at 2022-06-25 09:27:56.250861
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    f = unicode_urldecode
    int_0 = 'a'
    var_0 = f(int_0)
    assert var_0 == "a"
    int_0 = ' '
    var_0 = f(int_0)
    assert var_0 == " "
    int_0 = '+'
    var_0 = f(int_0)
    assert var_0 == " "
    int_0 = '%20'
    var_0 = f(int_0)
    assert var_0 == " "
    int_0 = '%2B'
    var_0 = f(int_0)
    assert var_0 == "+"


# Generated at 2022-06-25 09:28:04.252488
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    unicode_urlencode(5)
    unicode_urlencode([1, 2])
    unicode_urlencode({'var_0': 'test'})
    unicode_urlencode({u'key_0': u'default', u'key_1': u'var_1'})
    unicode_urlencode(u'unicode_')
    unicode_urlencode(u'unicode_')
    unicode_urlencode('unicode_')
    unicode_urlencode(u'unicode_')


# Generated at 2022-06-25 09:28:06.334415
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = 515
    var_0 = unicode_urlencode(int_0)


# Generated at 2022-06-25 09:28:10.340978
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
    assert var_0 == '515'
    int_1 = 515
    var_1 = unicode_urldecode(int_1)
    assert var_1 == '515'


# Generated at 2022-06-25 09:28:12.977648
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()


# Generated at 2022-06-25 09:28:16.801210
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    print("int_0 : ", unicode_urldecode(int_0))
    assert unicode_urldecode(int_0) == '515'


# Generated at 2022-06-25 09:28:26.032824
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = unicode_urldecode('%5B%5D')
    if var_0 != '[]':
        raise Exception("Test failed")
    var_0 = unicode_urldecode('%5B%5D')
    if not isinstance(var_0, unicode):
        raise Exception("Test failed")
    var_0 = unicode_urldecode('%5B%5D')
    if var_0 != '[]':
        raise Exception("Test failed")
    var_0 = unicode_urldecode('%5B%5D')
    if var_0 != '[]':
        raise Exception("Test failed")
    var_0 = unicode_urldecode('%5B%5D')
    if var_0 != '[]':
        raise Exception("Test failed")


# Generated at 2022-06-25 09:28:26.901028
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    #assert var_0 == "515"
    assert var_0 == 515


# Generated at 2022-06-25 09:28:28.034346
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = 515
    str_0 = unicode_urlencode(int_0)
    str_1 = unicode_urlencode(str_0)


# Generated at 2022-06-25 09:28:34.786089
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'To be, or not to be, that is the question.'
    str_1 = b'To be, or not to be, that is the question.'
    str_2 = {'To be, or not to be, that is the question.': 'To be, or not to be, that is the question.'}
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(str_1)
    var_2 = unicode_urldecode(str_2)
    int_0 = -16
    var_3 = unicode_urldecode(int_0)


# Generated at 2022-06-25 09:28:39.967364
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_0 = FilterModule()
    filters_0 = class_0.filters()
    assert filters_0


# Generated at 2022-06-25 09:28:48.235988
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test when var_0 (value) is a dict
    dict_0 = {'colon': 'a:b', 'semi': 'a;b', 'amp': 'a&b', 'dollar': '$ a'}
    var_0 = do_urlencode(dict_0)

    assert var_0 == 'amp=a%26b&colon=a%3Ab&dollar=%24%20a&semi=a%3Bb'

    # Test when var_0 (value) is a string
    string_0 = 'a:b'
    var_1 = do_urlencode(string_0)

    assert var_1 == 'a%3Ab'

    # Test when var_0 (value) is a tuple
    tuple_0 = ('a', 'b')
    var_2 = do_url

# Generated at 2022-06-25 09:28:52.299401
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = 78
    var_0 = unicode_urlencode(int_0)
    var_2 = unicode_urlencode(var_0, True)

    assert var_0 == '78'
    assert var_2 == '78'



# Generated at 2022-06-25 09:28:58.458133
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'aHR0cDovL3d3dy5haG1hdGkuY28uYnIv'
    expected_result = 'http://www.ahmati.co.br/'
    result = unicode_urldecode(string)
    assert(expected_result == result)


# Generated at 2022-06-25 09:29:05.742051
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert('515' == unicode_urldecode(515))
    assert('515' == unicode_urldecode(int('515')))



# Generated at 2022-06-25 09:29:12.925417
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
  # test cases
  # - test case 0:
  unicode_urlencode(s=b'This is a complete test.')
  # - test case 1:
  unicode_urlencode(s=b'this is another test with @*%^@^*@^.')
  # - test case 2:
  unicode_urlencode(s=b'This is a unicode test \xc3\xa1\xc3\xa9\xc3\xad\xc3\xb3\xc3\xba\xe2\x82\xac')
  # - test case 3:

# Generated at 2022-06-25 09:29:16.312591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module0 = FilterModule()
    int_0 = 515
    var_0 = module0.filters()
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0


# Generated at 2022-06-25 09:29:23.248444
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'ansible'
    int_0 = 515
    str_1 = 'ansibel'
    str_2 = 'ansible'

    assert(unicode_urldecode(str_0) == str_1)
    assert(unicode_urldecode(int_0) == str_2)



# Generated at 2022-06-25 09:29:24.375770
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(string_0) == string_1


# Generated at 2022-06-25 09:29:30.076475
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create instance of class FilterModule
    int_0 = 515
    string_0 = 'foo'
    FilterModule_instance_0 = FilterModule()
    int_1 = 515
    str_0 = 'foo'
    # Call method filters of FilterModule instance FilterModule_instance_0
    FilterModule_instance_0.filters(int_0, string_0)

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(args=sys.argv)

# Generated at 2022-06-25 09:29:32.697133
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
   # assert var_0 == int_0, 'Failed assert test'


# Generated at 2022-06-25 09:29:33.820019
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()


# Generated at 2022-06-25 09:29:39.054875
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c = FilterModule()
    assert c.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:29:41.483955
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test 0
    int_0 = 515
    var_0 = unicode_urldecode(int_0)
    assert var_0 == u'2=', var_0
    print('Unit Test for function unicode_urldecoderan successfully')


# Generated at 2022-06-25 09:29:46.123078
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_instance = FilterModule()
    filters = FilterModule_instance.filters()
    assert filters['urldecode'] == do_urldecode

# Generated at 2022-06-25 09:29:46.771085
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()



# Generated at 2022-06-25 09:29:47.761738
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # expected: b'%0A'
    print("\x0A")

    pass
