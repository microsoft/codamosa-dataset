

# Generated at 2022-06-25 09:19:50.886407
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    value = 'a%2Bc'
    result = unicode_urldecode(value)
    expected_result = 'a+c'
    print('Result: ' + result)
    print('Expected result: ' + expected_result)



# Generated at 2022-06-25 09:19:56.163167
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:20:00.086066
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  filter_module_0 = FilterModule()
  assert isinstance(filter_module_0, FilterModule)

# Generated at 2022-06-25 09:20:04.769246
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # AssertionError: u'foo' != 'foo'
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo') != u'foo'
    assert unicode_urldecode('foo') != u'%20'


# Generated at 2022-06-25 09:20:13.588933
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("c+e") == "%20c%2Be"
    assert unicode_urlencode("c e") == "%20c%20e"
    assert unicode_urlencode("c/e") == "%20c%2Fe"
    assert unicode_urlencode("c&e") == "%20c%26e"
    assert unicode_urlencode("c=e") == "%20c%3De"
    assert unicode_urlencode("c;e") == "%20c%3Be"
    assert unicode_urlencode("e", for_qs=True) == "e"

# Generated at 2022-06-25 09:20:17.259195
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('value=1&ExistingAttribute=1') == 'value%3D1%26ExistingAttribute%3D1'


# Generated at 2022-06-25 09:20:20.576170
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'UTF8%E4%B8%96%E7%95%8C') == u'UTF8世界'


# Generated at 2022-06-25 09:20:22.559116
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters() is not None


# Generated at 2022-06-25 09:20:26.413528
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("{foo/bar}") == "%7Bfoo%2Fbar%7D"
    assert unicode_urlencode("{foo/bar}", True) == "%7Bfoo%2Fbar%7D"



# Generated at 2022-06-25 09:20:33.221624
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+') == u'foo '
    assert unicode_urldecode('foo%2B') == u'foo+'
    if PY3:
        assert unicode_urldecode(b'foo+') == u'foo '
        assert unicode_urldecode(b'foo%2B') == u'foo+'
    else:
        assert unicode_urldecode(u'foo+') == u'foo '
        assert unicode_urldecode(u'foo%2B') == u'foo+'



# Generated at 2022-06-25 09:20:41.174492
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test filter for do_urlencode
    filter = do_urlencode("B=b&C=c")
    assert filter == "B%3Db%26C%3Dc"


# Generated at 2022-06-25 09:20:44.469000
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    global filter_module_0
    try:
        assert type(filter_module_0.filters()) == dict
    except AssertionError:
        raise


# Generated at 2022-06-25 09:20:51.611040
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD') == '你好'
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD?%E5%8F%91%E5%B8%83') == '你好?发布'
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('%') == '%'
    assert unicode_urldecode('%%') == '%%'
    assert unicode_urldecode('%%%%') == '%%%%'
    assert unicode_urldecode('%E') == '%E'
    assert unicode_urldecode('%E4') == '%E4'
   

# Generated at 2022-06-25 09:20:57.914972
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://localhost:8080/get 🐳 info') == u'http%3A//localhost%3A8080/get%20%F0%9F%90%B3%20info'


# Generated at 2022-06-25 09:21:01.682250
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test') == 'test'
    assert unicode_urlencode('test\\test') == 'test%5Ctest'
    assert unicode_urlencode('test test') == 'test+test'
    assert unicode_urlencode('test\ntest') == 'test%0Atest'
    assert unicode_urlencode('test\ttest') == 'test%09test'


# Generated at 2022-06-25 09:21:02.610048
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == 'test'


# Generated at 2022-06-25 09:21:05.803936
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'a+b' == unicode_urldecode('a%2Bb')
    assert 'a b' == unicode_urldecode('a+b')


# Generated at 2022-06-25 09:21:10.606029
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a&b') == 'a%26b'
    assert unicode_urlencode('a&b', for_qs=True) == 'a%26b'

# Generated at 2022-06-25 09:21:20.574387
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/test?a=b&b=a') == 'http%3A%2F%2Fwww.example.com%2Ftest%3Fa%3Db%26b%3Da'
    assert unicode_urlencode(u'http://www.example.com/test?a=b&b=a', True) == 'http%3A%2F%2Fwww.example.com%2Ftest%3Fa%3Db%26b%3Da'
    assert unicode_urlencode(u'http://www.example.com/test/a/b') == 'http%3A%2F%2Fwww.example.com%2Ftest%2Fa%2Fb'


# Generated at 2022-06-25 09:21:23.248172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    with pytest.raises(TypeError):
        unicode_urldecode(1)
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%20") == u' '


# Generated at 2022-06-25 09:21:28.465919
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # TODO: Need to write a test for this as per below
    """
    filters = {
        'urldecode': do_urldecode,
    }

    if not HAS_URLENCODE:
        filters['urlencode'] = do_urlencode

    return filters
    """
    pass



# Generated at 2022-06-25 09:21:32.142104
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%20') == ' '


# Generated at 2022-06-25 09:21:39.536157
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'foo' == unicode_urldecode(u'foo')
    assert 'foo' == unicode_urldecode(b'foo')
    assert 'foo bar' == unicode_urldecode('foo+bar')
    assert 'foo bar' == unicode_urldecode('foo%20bar')
    assert 'foo bar' == unicode_urldecode(u'foo+bar')
    assert 'foo bar' == unicode_urldecode(b'foo+bar')
    assert 'foo bar' == unicode_urldecode(u'foo%20bar')
    assert 'foo bar' == unicode_urldecode(b'foo%20bar')
    assert 'foo:bar' == unicode_urldecode('foo:bar')
    assert 'foo:bar' == unic

# Generated at 2022-06-25 09:21:48.657637
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%0A') == u'\n'
    assert unicode_urldecode('%0A') == u'\n'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode('%20') == u' '
    if not PY3:
        assert unicode_urldecode(u'%E4%BA%BA') == u'\u4eba'
        assert unicode_urldecode('%E4%BA%BA') == u'\u4eba'


# Generated at 2022-06-25 09:21:51.878235
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()

    # Test for equality between the return value of method filters and the
    # expected value.
    assert filters_0 == {"urlencode": do_urlencode, "urldecode": do_urldecode}

# Generated at 2022-06-25 09:21:56.350406
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%F6%E4%FC%DF'
    result = unicode_urldecode(string)
    assert result == u'öäüß'


# Generated at 2022-06-25 09:21:59.660210
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('Æ') == '%C3%86'


# Generated at 2022-06-25 09:22:02.517685
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

# Generated at 2022-06-25 09:22:08.378843
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    # Check for key urldecode in dict f
    assert u'urldecode' in f
    # Check for key urlencode in dict f
    if HAS_URLENCODE:
        assert u'urlencode' in f

# Generated at 2022-06-25 09:22:13.759717
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/var/www/html/index.html') == '/var/www/html/index.html'
    assert unicode_urlencode('/var/www/html/index.html', for_qs=True) == '/var/www/html/index.html'
    assert unicode_urlencode('/var/www/html/index.html?foo=bar') == '/var/www/html/index.html%3Ffoo%3Dbar'
    assert unicode_urlencode('/var/www/html/index.html?foo=bar', for_qs=True) == '/var/www/html/index.html%3Ffoo%3Dbar'


# Generated at 2022-06-25 09:22:22.907691
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode('%2d%2d%2d%2d%2d%2d%2d%2d') == u'----------'
    assert unicode_urldecode('%40%40%40%40%40%40%40%40') == u'@@@@@@@@'
    assert unicode_urldecode('%6C%6C%6C%6C%6C%6C%6C%6C') == u'llllllll'
    assert unicode_urldecode('%21%23%24%25%26%27%28%29') == u'!#$%&\'()'

# Generated at 2022-06-25 09:22:27.182014
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

    filters = filter_module_0.filters()
    assert isinstance(filters, dict)


# Generated at 2022-06-25 09:22:30.368230
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    
    filter_module_1 = FilterModule()

    assert isinstance(filter_module_1.filters(), dict)


# Generated at 2022-06-25 09:22:35.803099
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    #tests = [
    #    # TODO: add tests here.
    #]
    #for test in tests:
    #    filter_module_0 = FilterModule()
    #    if not test.expected == filter_module_0.filters(test.arg):
    #        print "Error filtering '%s'. Expected '%s', got '%s'" % (test.arg, test.expected, filter_module_0.filters(test.arg))

    assert not FilterModule().filters()
    return

# Generated at 2022-06-25 09:22:36.577719
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:22:39.858121
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'https%3A%2F%2Fwww.google.com%3Fa%3Dx%26b%3Dy%23z' == unicode_urlencode(u'https://www.google.com?a=x&b=y#z')


# Generated at 2022-06-25 09:22:51.953442
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%A4') == u'ää'
    assert unicode_urldecode('%C3%A4%C3%A4%C3%A4') == u'äää'
    assert unicode_urldecode('a%C3%A4%C3%A4b') == u'aääb'
    assert unicode_urldecode('a%C3%A4b') == u'aäb'
    assert unicode_urldecode('a%C3b') == u'a%C3b'
    assert unicode_urldecode('a%b') == u'a%b'
    assert unicode_urldecode('ab') == u'ab'
    assert unicode_

# Generated at 2022-06-25 09:22:55.497981
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-25 09:23:03.788017
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    is_equal = True

    # Test case #1
    actual = unicode_urldecode("%3F%3F")
    expected = "??"

    if actual != expected:
        is_equal = False

    # Test case #2
    actual = unicode_urldecode("%3F")
    expected = "?"

    if actual != expected:
        is_equal = False

    # Test case #3
    actual = unicode_urldecode("%")
    expected = "%"

    if actual != expected:
        is_equal = False

    # Test case #4
    actual = unicode_urldecode("")
    expected = ""

    if actual != expected:
        is_equal = False

    # Test case #5

# Generated at 2022-06-25 09:23:10.874769
# Unit test for method filters of class FilterModule
def test_FilterModule_filters(): # pylint: disable=redefined-outer-name
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters(  )
    print(filters_0)
    #assert filters_0 == #, 'Expected different value for FilterModule.filters()'


# Generated at 2022-06-25 09:23:21.495502
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test with a string containing non-ascii characters
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urlencode(str_0)
    assert var_0 == "%0A%20%20%20%20Holds%20inventory%20data%20%28host%20and%20group%20objects%29.%0A%20%20%20%20Using%20it%27s%20methods%20should%20guarantee%20expected%20relationships%20and%20data.%0A%20%20%20%20"


# Generated at 2022-06-25 09:23:29.220378
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    str_1 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_1 = unicode_urldecode(str_1)
    str_2 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_2 = unicode_urldecode(str_2)

# Generated at 2022-06-25 09:23:30.483706
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == filters()


# Generated at 2022-06-25 09:23:40.814151
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    
    # AssertionError: expected "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    " == b"\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    # assert unicode_urldecode(str_0) == b"\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "

    # AssertionError: expected "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    " == ""
    # assert unicode_urldecode(str_0) == ""
    pass


# Generated at 2022-06-25 09:23:43.515998
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_data = 'Test data for unicode_urlencode'
    print("Test for unicode_urlencode")
    assert unicode_urlencode(str_data) == str_data


# Generated at 2022-06-25 09:23:47.654956
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Call method on instance FilterModule
    filters = FilterModule().filters()

    assert filters is not None

# Generated at 2022-06-25 09:23:51.098498
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert isinstance(unicode_urldecode("\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "), string_types)



# Generated at 2022-06-25 09:23:54.901183
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    result = filters.filters()
    assert id(result) == id({})
    assert result == {}


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-25 09:24:00.760547
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    val = "foo/bar"
    val_as_bytes = b'foo/bar'
    if PY3:
        res = quote_plus(val)
    else:
        res = quote_plus(val_as_bytes)
    assert unicode_urlencode(val) == res


# Generated at 2022-06-25 09:24:07.228676
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert do_urldecode(unicode_urldecode(string)) == string
    string = ""
    assert do_urldecode(unicode_urldecode(string)) == string
    string = "@#$%^&*()_+="
    assert do_urldecode(unicode_urldecode(string)) == string
    string = "!@#$%^&*()+_="
    assert do_urldecode(unicode_urldecode(string)) == string
    string = "qwertyuiopasdfghjklzxcvbnm,./;'[]\_+1234567890-="
    assert do_urldecode(unicode_urldecode(string)) == string

# Generated at 2022-06-25 09:24:12.207539
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    assert var_0 == " Holds inventory data (host and group objects). Using it's methods should guarantee expected relationships and data. "

# Generated at 2022-06-25 09:24:15.307736
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    param_0 = FilterModule().filters()
    assert isinstance(param_0, dict)


# Generated at 2022-06-25 09:24:18.764677
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = 'foo+bar%20baz'

    try: #Python 2
        assert unicode_urldecode(s) == u'foo bar baz'
    except NameError: # Python 3
        assert unicode_urldecode(s) == 'foo bar baz'


# Generated at 2022-06-25 09:24:27.201938
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = filter_module.filters().get("urldecode")(str_0)

    if not HAS_URLENCODE:
        str_1 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
        var_1 = filter_module.filters().get("urlencode")(str_1)


# Generated at 2022-06-25 09:24:31.015582
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Unit test for filters of class FilterModule
    # get filter methods of class FilterModule
    filter_methods_instance = FilterModule()

    # test if filters returns a dict
    assert isinstance(filter_methods_instance.filters(), dict)


# Generated at 2022-06-25 09:24:37.821882
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\n    Holds inventory data (host and group objects).\n    Using it\'s methods should guarantee expected relationships and data.\n    ') == u'%0A%20%20%20%20Holds%20inventory%20data%20%28host%20and%20group%20objects%29.%0A%20%20%20%20Using%20it%27s%20methods%20should%20guarantee%20expected%20relationships%20and%20data.%0A%20%20%20%20'

# Generated at 2022-06-25 09:24:44.934289
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(str_0)
    assert var_0 == var_1

if __name__ == "__main__":
    test_case_0()
    test_unicode_urldecode()

# Generated at 2022-06-25 09:24:47.069689
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(str_0) == "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "


# Generated at 2022-06-25 09:24:49.534151
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-25 09:24:53.740522
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)

# Generated at 2022-06-25 09:24:58.095122
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    flt = (FilterModule.filters)

    # TODO: Unit test goes here.
    #assert flt['replace'] == do_replace
    pass

# Generated at 2022-06-25 09:25:01.104684
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '\n    Holds inventory data (host and group objects).\n    Using it\'s methods should guarantee expected relationships and data.\n    '
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:25:03.229968
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = "a{b}c"
    expected = 'a%7Bb%7Dc'
    assert(unicode_urlencode(value) == expected)


# Generated at 2022-06-25 09:25:04.293966
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Test method filters of class FilterModule"""
    modules = FilterModule()

    filters = modules.filters()

    assert filters is not None


# Generated at 2022-06-25 09:25:11.004762
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    arg = '\n    Holds inventory data (host and group objects).\n    Using it\'s methods should guarantee expected relationships and data.\n    '
    result = unicode_urldecode(arg)
    assert result == '\n    Holds inventory data (host and group objects).\n    Using it\'s methods should guarantee expected relationships and data.\n    '
    assert type(result) is str


# Generated at 2022-06-25 09:25:15.315048
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    assert var_0 == u"\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "


if __name__ == "__main__":
    print(do_urldecode(str_0))

# Generated at 2022-06-25 09:25:19.656092
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 09:25:25.132518
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(var_0)
    assert unicode_urldecode(var_1) == str_0, "'%s' != '%s'" % (unicode_urldecode(var_1), str_0)


# Generated at 2022-06-25 09:25:25.877859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print(FilterModule().filters())

# Generated at 2022-06-25 09:25:27.720401
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%c2%a2') == u'¢'
    assert unicode_urldecode('%c2%a2') == u'¢'


# Generated at 2022-06-25 09:25:35.246351
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    v0 = FilterModule()
    v1 = v0.filters()
    v2 = v1.keys()
    v3 = 'urlencode' in v2
    #v3 = v3 == True
    #if v3 == True:
    #    v3 = 'urldecode' in v2
    #    v3 = v3 == True
    #    if v3 == True:
    assert v3 == True


# Generated at 2022-06-25 09:25:41.144166
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    assert unicode_urldecode(str_0) == "Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data."


# Generated at 2022-06-25 09:25:43.825369
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_0 = FilterModule()
    var_1 = filter(var_0)


# Generated at 2022-06-25 09:25:47.346814
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Try to decode 
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    assert str_0 == var_0


# Generated at 2022-06-25 09:25:56.789408
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    file_name_0 = 'ansible.module_utils.facts.__init__'
    file_directory_0 = '.../ansible-2.9.11/lib/ansible/module_utils/facts/__init__.py'
    pyclass_0 = FilterModule()
    pyclass_0_filters_0 = pyclass_0.filters()
    assert type(pyclass_0_filters_0) == dict
    pyclass_0_filters_0_0 = pyclass_0_filters_0['urldecode']
    pyclass_0_filters_0_0_0 = pyclass_0_filters_0_0(file_directory_0)
    assert type(pyclass_0_filters_0_0_0) == str


# Generated at 2022-06-25 09:26:00.059685
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Ansible jinja2 filters
    f = FilterModule()
    filters = f.filters()
    var_1 = filters['urldecode']('test')
    var_2 = filters['urldecode']('test', True)

# Generated at 2022-06-25 09:26:01.744716
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    arg_0 = FilterModule()
    ret_0 = arg_0.filters()


# Generated at 2022-06-25 09:26:10.279854
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    assert var_0 == "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "


# Generated at 2022-06-25 09:26:15.062635
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:26:20.840531
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test case 0
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    # Assertions
    assert var_0 == '\n    Holds inventory data (host and group objects).\n    Using it\'s methods should guarantee expected relationships and data.\n    '



# Generated at 2022-06-25 09:26:25.472305
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("Start unit test for function FilterModule.filters")

    obj = FilterModule()
    assert isinstance(obj.filters(), dict)

    print("Successful unit test for function FilterModule.filters")


# Generated at 2022-06-25 09:26:30.367825
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    fil = f.filters()
    test_case_0()


# Generated at 2022-06-25 09:26:36.491362
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    assert var_0.__class__ is str


# Generated at 2022-06-25 09:26:38.446041
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # k0: I don't think I need to test this, it's just returning a dict with function references
    # v0:
    pass


# Generated at 2022-06-25 09:26:41.287308
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:26:46.871575
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    #inventory = Inventory()
    results = FilterModule.filters()
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    #var_0 = unicode_urldecode(str_0)
    results_0 = do_urldecode(str_0)
    assert (results_0 == var_0)
    results_1 = do_urldecode(results)
    assert (results_1 == var_0)


# Generated at 2022-06-25 09:26:52.204114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    hypothesis_0 = {}
    hypothesis_0 = filter_module.filters()
    assert hypothesis_0 == {'urldecode': do_urldecode}

# Generated at 2022-06-25 09:26:56.506651
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_1 = "Test String"
    var_1 = unicode_urlencode(str_1, for_qs=True)
    assert var_1 == 'Test+String'



# Generated at 2022-06-25 09:26:59.319257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n        Parses a file as JSON.\n\n        Parameters:\n            path: Path to file to parse as JSON\n        "
    var_0 = unicode_urldecode(str_0)



# Generated at 2022-06-25 09:27:03.163103
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    assert unicode_urldecode(str_0) == "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "



# Generated at 2022-06-25 09:27:11.867138
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = do_urldecode(str_0)
test_FilterModule_filters()

'''
    Examples from AnsiballZ_ansible.module_utils.common._text
'''



# Generated at 2022-06-25 09:27:17.325555
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)
    return var_0


# Generated at 2022-06-25 09:27:21.822786
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    def obj_0(param_0):
        return do_urldecode(param_0)

    fm = FilterModule()
    filters_0 = fm.filters()

    # Test nested function filters within method filters
    filters_1 = filters_0['urldecode']
    assert filters_1(obj_0) == "\\n    Holds inventory data (host and group objects).\\n    Using it's methods should guarantee expected relationships and data.\\n    ", "Expected result for do_urldecode()"

    # Test expected results for filters
    filters_2 = filters_0['urldecode']
    assert filters_2("") == '', "Expected result for do_urldecode('')"

# Generated at 2022-06-25 09:27:32.448273
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = "ansible"
    str_1 = "ansible_1"
    str_2 = "ansible_2"
    str_3 = "ansible_3"
    str_4 = "ansible_4"
    str_5 = "ansible_5"
    str_6 = "ansible_6"
    str_7 = "ansible_7"
    str_8 = "ansible_8"
    str_9 = "ansible_9"
    class_0 = FilterModule()
    var_0 = class_0.filters()
    var_1 = var_0["urldecode"]
    var_2 = var_1(str_0)
    var_3 = var_2 == var_0["urldecode"]

# Generated at 2022-06-25 09:27:38.636376
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters() # Should return a dict

    # Unit test for method do_urldecode of class FilterModule
    assert unicode_urldecode(str_0) == var_0
    if not HAS_URLENCODE:
        # Unit test for method do_urlencode of class FilterModule
        assert unicode_urlencode(str_0) == var_0
        assert unicode_urlencode(str_0, for_qs=True) == var_0

# Generated at 2022-06-25 09:27:41.455851
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("test") == u"test"
    assert unicode_urlencode("test", False) == u"test"
    assert unicode_urlencode("test", True) == u"test"


# Generated at 2022-06-25 09:27:43.222479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    var_0 = obj.filters()
    assert len(var_0) > 0


# Generated at 2022-06-25 09:27:49.581288
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = "/hosts/host_name/"
    str_1 = do_urldecode(str_0)
    str_2 = unicode_urlencode(str_1)
    str_3 = do_urlencode(str_2)
    str_4 = do_urlencode(str_1)

# Import the sys and os modules
import sys, os, py_compile
# Check if the Python version is 2.7
if sys.version_info<(2,7):
    # Import the doctest module
    import doctest
    # Find the path of the Ansible Module utils
    path = os.path.dirname(os.path.realpath(__file__)) + "/../../lib/ansible/module_utils"
    # Change the current directory to the Ansible Module utils path


# Generated at 2022-06-25 09:27:50.940474
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Test filters() method of class FilterModule
    """
    inst_0 = FilterModule()

    # Test function call
    assert inst_0.filters()


# Generated at 2022-06-25 09:27:53.182299
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    a.filters()
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = do_urldecode(str_0)


# Generated at 2022-06-25 09:28:00.555862
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "sz23T9UNhf0T/E/G8pH/pb/zij+nIw=="
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:03.747658
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate class
    filter_module = FilterModule()
    # Access method filters
    assert filter_module.filters()

# Generated at 2022-06-25 09:28:08.528111
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of class FilterModule and assign to local var called FilterModule
    FilterModule = FilterModule()

    # Call method filters of FilterModule, assign the method's return value to local var called var_0
    var_0 = FilterModule.filters()
    # Method filters returns the following value:
    # {'urldecode': <function do_urldecode at 0x7f3a14bab488>}

    assert 'urldecode' in var_0


# Generated at 2022-06-25 09:28:10.061056
# Unit test for function do_urlencode
def test_do_urlencode():
    assert HAS_URLENCODE


# Generated at 2022-06-25 09:28:20.922788
# Unit test for method filters of class FilterModule

# Generated at 2022-06-25 09:28:24.621855
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '{ "foo": "bar" }'
    var_0 = unicode_urlencode(str_0)
    assert var_0 == '%7B%20%22foo%22%3A%20%22bar%22%20%7D'


# Generated at 2022-06-25 09:28:27.931534
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Interface vars to match vs json
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:32.092569
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    ") == "\\n    Holds inventory data (host and group objects).\\n    Using it's methods should guarantee expected relationships and data.\\n    "

# Generated at 2022-06-25 09:28:41.846113
# Unit test for method filters of class FilterModule

# Generated at 2022-06-25 09:28:42.737544
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert test_case_0()

# Generated at 2022-06-25 09:28:51.339205
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    str_1 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:57.265140
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_1 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_1 = do_urldecode(str_1)
    print(var_1)



# Generated at 2022-06-25 09:29:01.588441
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = "    Holds inventory data (host and group objects).\n    Using it\'s methods should guarantee expected relationships and data.\n    "
    assert do_urldecode(str_0) == "    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "


# Generated at 2022-06-25 09:29:04.233737
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = "\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:29:06.728705
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("https://127.0.0.1:8080") == "https%3A%2F%2F127.0.0.1%3A8080"

# Generated at 2022-06-25 09:29:09.093618
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)

# unit test for function: unicode_urldecode

# Generated at 2022-06-25 09:29:11.818134
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert 'urldecode' in filtermodule.filters()

# Generated at 2022-06-25 09:29:14.805724
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_obj = FilterModule()
    filters = filters_obj.filters()
    filters_ret = filters['urldecode']('%3D')


# Generated at 2022-06-25 09:29:24.939789
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Set up mock
    string = "string"
    for_qs = False
    safe = b'' if for_qs else b'/'
    if for_qs:
        quote_func = quote_plus
    else:
        quote_func = quote
    if PY3:
        return quote_func(string, safe)
    return to_text(quote_func(to_bytes(string), safe))

    mock_kwargs = {}

# Generated at 2022-06-25 09:29:26.236029
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    var_0 = obj.filters()


# Generated at 2022-06-25 09:29:37.245485
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert '%0A%20%20%20%20Holds%20inventory%20data%20%28host%20and%20group%20objects%29.%0A%20%20%20%20Using%20it%27s%20methods%20should%20guarantee%20expected%20relationships%20and%20data.%0A%20%20%20%20' == unicode_urlencode("\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    ")

# Generated at 2022-06-25 09:29:41.155359
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("\n    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    ") == "    Holds inventory data (host and group objects).\n    Using it's methods should guarantee expected relationships and data.\n    "



# Generated at 2022-06-25 09:29:43.541100
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    arg_0 = ['AnsibleModule'](), ['TemplateModule'](), ['AnsiColor'](), ['AnsibleUnsafeText'](), ['AnsibleHost'](), ['AnsibleHostGroup']()
    var_0 = FilterModule.filters(arg_0)