

# Generated at 2022-06-25 09:19:54.483201
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%24') == '$'
    assert unicode_urldecode('a=1&b=2&a=3') == 'a=1&b=2&a=3'


# Generated at 2022-06-25 09:19:57.399381
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'https://github.com/ansible/ansible/issues/28981'
    assert unicode_urlencode(string) == 'https%3A%2F%2Fgithub.com%2Fansible%2Fansible%2Fissues%2F28981'


# Generated at 2022-06-25 09:20:04.280988
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A//example.com/'
    assert unicode_urlencode('http://example.com/', for_qs=True) == 'http%3A%2F%2Fexample.com%2F'


# Generated at 2022-06-25 09:20:13.339871
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'param=something') == u'param%3Dsomething'
    assert do_urlencode(u'param=something else') == u'param%3Dsomething+else'
    assert do_urlencode({'param': 'something'}) == u'param=something'
    assert do_urlencode(['param', 'something']) == u'param=something'
    assert do_urlencode({'param': 'something else'}) == u'param=something+else'
    assert do_urlencode(['param', 'something else']) == u'param=something+else'


# Generated at 2022-06-25 09:20:20.344663
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
    filters_1 = {'urlencode': do_urlencode, 'urldecode': do_urldecode}
    if filters_0 != filters_1:
        assert False, ('filter_module_0.filters() "!=" filters_1')


# Generated at 2022-06-25 09:20:27.591006
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("hello") == "hello"
    assert unicode_urldecode("hello%3Fworld%3Dyes") == "hello?world=yes"
    assert unicode_urldecode("hello%3Fworld%3Dyes") == "hello?world=yes"
    assert unicode_urldecode("hello%3Fworld%3Dyes") == "hello?world=yes"
    assert unicode_urldecode("hello%3Fworld%3Dyes") == "hello?world=yes"

# Generated at 2022-06-25 09:20:33.183127
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('MyVal0') == 'MyVal0'
    assert unicode_urlencode('MyVal0/Val1') == 'MyVal0%2FVal1'
    assert unicode_urlencode('Val0Val1Val2Val3Val4Val5Val6Val7Val8Val9') == 'Val0Val1Val2Val3Val4Val5Val6Val7Val8Val9'


# Generated at 2022-06-25 09:20:37.954734
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert isinstance(unicode_urlencode('http://www.ansible.com'), basestring)
    assert unicode_urlencode('http://www.ansible.com') == 'http%3A%2F%2Fwww.ansible.com'


# Generated at 2022-06-25 09:20:41.340862
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:20:50.150824
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:21:01.001136
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.google.com/search?q=árvíztűrőtükörfúrógép') == 'http%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3D%C3%A1rv%C3%ADzt%C5%B1r%C5%91t%C3%BCk%C3%B6rf%C3%BAr%C3%B3g%C3%A9p'


# Generated at 2022-06-25 09:21:02.723271
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22id%22%3A%2252%22%7D') == '{"id":"52"}'


# Generated at 2022-06-25 09:21:14.394910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('c%2B%2B') == 'c++'
    assert unicode_urldecode('c%2b%2b') == 'c++'
    assert unicode_urldecode('%3C%3E') == '<>'
    assert unicode_urldecode('%3c%3e') == '<>'
    assert unicode_urldecode('%7B%7D') == '{}'
    assert unicode_urldecode('%7b%7d') == '{}'
    assert unicode_urldecode('%7B%7D%3C%3Ec%2B%2B') == '{}<>c++'

# Generated at 2022-06-25 09:21:22.629848
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Tests for function 'unicode_urldecode'.
    assert unicode_urldecode('this+that') == 'this that'
    assert unicode_urldecode('%C3%A0%C3%A8%C3%AD%C3%B2%C3%B9') == u'àèíòù'

# Generated at 2022-06-25 09:21:30.174217
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

    filters_0 = filter_module_0.filters()

    assert filters_0['urldecode'](u'%2B') == u'+'
    assert filters_0['urldecode'](u'%2b') == u'+'
    assert filters_0['urldecode'](u'%20%1F%10%42') == u'  ?\x10B'
    assert filters_0['urldecode'](u'%41') == u'A'
    assert filters_0['urldecode'](u'%41%42%43') == u'ABC'

# Generated at 2022-06-25 09:21:39.130220
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode('test') == 'test'
    assert unicode_urlencode('test test2') == 'test%20test2'
    assert unicode_urlencode('test test2/') == 'test%20test2%2F'
    assert unicode_urlencode(['test', 'test2']) == 'test&test2'
    assert unicode_urlencode(['test', ['test2']]) == 'test&test2'
    assert unicode_urlencode(['test', {'test2': 'test3'}]) == 'test&test2=test3'
    assert unicode_urlencode({'test': 'test2'}) == 'test=test2'

# Generated at 2022-06-25 09:21:45.485698
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("http://%7Eusername/") == "http://~username/"
    assert unicode_urldecode("http://%7eusername/") == "http://~username/"
    assert unicode_urldecode("http://%7Eusername%3Dsdf/") == "http://~username=sdf/"


# Generated at 2022-06-25 09:21:49.838128
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filter_module_0.filters()


# Generated at 2022-06-25 09:21:53.861603
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Template test case 1
    assert unicode_urldecode(u'Hello%20World%21') == 'Hello World!'

    # Template test case 2
    assert unicode_urldecode(u'Hello+World%21') == 'Hello World!'

    # Template test case 3
    assert unicode_urldecode(u'Andr%E9s') == u'Andr\xe9s'


# Generated at 2022-06-25 09:21:56.110345
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)

# unit test for method FilterModule of class FilterModule

# Generated at 2022-06-25 09:22:03.182073
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    # test_FilterModule_filters
    """
    result_0 = FilterModule().filters()
    assert result_0 == {"urldecode": do_urldecode}


if __name__ == '__main__':
    try:
        test_case_0()
    except AssertionError as err:
        print("Test case 0 failed: " + str(err))

# Generated at 2022-06-25 09:22:04.557894
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with a string argument
    assert unicode_urldecode('hello%20world') == 'hello world'



# Generated at 2022-06-25 09:22:16.086406
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input_0 = to_text("hello world")
    expected_output_0 = to_text("hello world")
    expected_output_0_1 = to_text("hello world")

    if PY3:
        actual_output_0 = unicode_urldecode(input_0)
    else:
        actual_output_0 = unicode_urldecode(input_0)

    assert actual_output_0 == expected_output_0 or actual_output_0 == expected_output_0_1


# Generated at 2022-06-25 09:22:20.413427
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six import b
    assert unicode_urldecode(b('foo%20bar+baz%2Bblah')) == 'foo bar baz+blah'
    assert unicode_urldecode('foo%20bar+baz%2Bblah') == 'foo bar baz+blah'



# Generated at 2022-06-25 09:22:26.542510
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    f_unicode_urldecode = unicode_urldecode
    assert f_unicode_urldecode('%2F') == '/'
    assert f_unicode_urldecode('%2f') == '/'
    assert f_unicode_urldecode('%2Ffoo%2Fbar%2F') == '/foo/bar/'
    assert f_unicode_urldecode('%2Ffoo%2fbar%2F') == '/foo/bar/'
    assert f_unicode_urldecode('%2Ffoo%2fbar%2Fasdf') == '/foo/bar/asdf'


# Generated at 2022-06-25 09:22:27.904730
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('example.com/test?q=test%20test') == 'example.com/test?q=test test'


# Generated at 2022-06-25 09:22:32.163847
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3Dqux') == u'http://example.com/?foo=bar&baz=qux'


# Generated at 2022-06-25 09:22:34.261600
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == '/'


# Generated at 2022-06-25 09:22:36.066301
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:22:37.962728
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_filters_0 = FilterModule()
    filter_module_filters_1 = filter_module_filters_0.filters()

# Generated at 2022-06-25 09:22:41.992046
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('foobar%20baz') == 'foobar baz')


# Generated at 2022-06-25 09:22:48.523559
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(u'foo+bar%20f%C3%A5') == u'foo bar f\xe5'
    else:
        assert unicode_urldecode(u'foo+bar%20f%C3%A5') == 'foo bar f\xc3\xa5'


# Generated at 2022-06-25 09:22:54.308043
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with a valid FilterModule object
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
    assert filters_0['urldecode'] == do_urldecode
    # Test with a valid FilterModule object
    filter_module_1 = FilterModule()
    filters_1 = filter_module_1.filters()
    if not HAS_URLENCODE:
        assert filters_1['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:22:56.717316
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%3A%2F%2F") == "://"


# Generated at 2022-06-25 09:23:02.445217
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('this%20is%20ascii') == 'this is ascii'
    assert unicode_urldecode('%e9%9b%bb%e8%b7%af') == u'電路'
    assert unicode_urldecode('%E9%9B%BB%E8%B7%AF') == u'電路'


# Generated at 2022-06-25 09:23:05.755345
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    res = unicode_urldecode('%E7%94%A8%E6%88%B7%E7%BC%96%E5%8F%B7')
    print('res: ', res)


# Generated at 2022-06-25 09:23:09.117831
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('helloworld') == 'helloworld'



# Generated at 2022-06-25 09:23:12.491724
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode']('a%20b+c%2Fd') == 'a b c/d'


# Generated at 2022-06-25 09:23:15.451970
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    input = 'foo_bar'
    result = unicode_urlencode(input, True)

    assert(result == 'foo_bar')


# Generated at 2022-06-25 09:23:21.601595
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar',True) == 'foo+bar'
    assert unicode_urlencode('/path/to?file.txt') == '%2Fpath%2Fto%3Ffile.txt'
    assert unicode_urlencode('/path/to?file.txt',True) == '%2Fpath%2Fto%3Ffile.txt'


# Generated at 2022-06-25 09:23:29.500145
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://ansible.com') == 'http%3A//ansible.com'
    assert unicode_urlencode('http://ansible.com', for_qs=True) == 'http%3A%2F%2Fansible.com'
    assert unicode_urlencode(['http://ansible.com']) == 'http%3A//ansible.com'
    assert unicode_urlencode(('http://ansible.com', 'http://docs.ansible.com')) == 'http%3A//ansible.com&http%3A//docs.ansible.com'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'


# Generated at 2022-06-25 09:23:31.398479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() is not None


# Generated at 2022-06-25 09:23:38.730185
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    filter_module_0 = FilterModule()

    assert filter_module_0.filters()['urldecode']('a b') == 'a b'
    assert filter_module_0.filters()['urldecode']('a+b') == 'a b'
    assert filter_module_0.filters()['urldecode']('a%20b') == 'a b'
    assert filter_module_0.filters()['urldecode']('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'


# Generated at 2022-06-25 09:23:40.814375
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22d%22%3A%22a%22%7D') == u'{"d":"a"}'


# Generated at 2022-06-25 09:23:42.679256
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%21') == u' !'


# Generated at 2022-06-25 09:23:45.810785
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = filter_module_0.filters
    assert filters.__class__ == dict
    assert filters == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:23:50.148851
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:23:52.931547
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert('urlencode' in filter_module_1.filters())



# Generated at 2022-06-25 09:24:03.522508
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if HAS_URLENCODE:
        return

    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('abc def') == 'abc+def'
    assert do_urlencode('abc def ghi') == 'abc+def+ghi'
    assert do_urlencode('a+') == 'a%2B'
    assert do_urlencode('a++') == 'a%2B%2B'
    assert do_urlencode('a+++') == 'a%2B%2B%2B'
    assert do_urlencode('a+b') == 'a%2Bb'
    assert do_urlencode('a++b') == 'a%2B%2Bb'

# Generated at 2022-06-25 09:24:14.889577
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test case 0
    assert do_urlencode('') == ''
    assert do_urlencode('https://ansible.com/') == 'https%3A%2F%2Fansible.com%2F'
    assert do_urlencode('dict') == 'dict'
    assert do_urlencode(1) == '1'
    assert do_urlencode(1.5) == '1.5'
    assert do_urlencode(True) == 'True'
    assert do_urlencode({}) == ''
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert do_urlencode([{'a': 'b', 'c': 'd'}]) == 'a=b&c=d'

# Generated at 2022-06-25 09:24:19.307711
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()


filter_module_0 = FilterModule()


# Generated at 2022-06-25 09:24:20.267501
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:24:21.431511
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25') == '%'


# Generated at 2022-06-25 09:24:23.978341
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc123') == u'abc123'


# Generated at 2022-06-25 09:24:25.811141
# Unit test for function do_urlencode
def test_do_urlencode():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['urlencode']('abc') == 'abc'



# Generated at 2022-06-25 09:24:29.394774
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # filter_module_1 = FilterModule()
    assert filter_module_0.filters() is not None


# Generated at 2022-06-25 09:24:32.303937
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    my_urldecode = unicode_urldecode('%7B%22f%22%3A%22foo%22%7D')
    assert my_urldecode == '{"f":"foo"}'


# Generated at 2022-06-25 09:24:39.037838
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == u'%2F'
    assert do_urlencode([]) == u''
    assert do_urlencode(['a', 'b', 'c']) == u'a=&b=&c='
    assert do_urlencode('') == u''
    assert do_urlencode({}) == u''
    assert do_urlencode({'a': 'b'}) == u'a=b'
    assert do_urlencode({'a': 'b', 'b': 'c'}) == u'a=b&b=c'
    assert do_urlencode({'a': 'b', 'b': 'c'}, True) == u'a=b&b=c'
    assert do_urlencode(123) == u'123'
    assert do_

# Generated at 2022-06-25 09:24:42.563064
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string = 'abc'
    actual_result = unicode_urldecode(test_string)
    expect_result = u'abc'

    assert actual_result == expect_result


# Generated at 2022-06-25 09:24:45.246763
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://localhost:8080/v1/users', for_qs=False) == u'http%3A%2F%2Flocalhost%3A8080%2Fv1%2Fusers'


# Generated at 2022-06-25 09:24:48.942731
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:24:58.812701
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    do_urldecode = unicode_urldecode
    FilterModule_inst = FilterModule()
    var_0 = FilterModule_inst.filters()
    var_0 = var_0.get('urldecode')
    assert var_0  == do_urldecode
    print('TEST: %s' % var_0)

if __name__ == "__main__":
    # Test case 0
    print('Running test case 0…')
    test_case_0()

# Generated at 2022-06-25 09:25:04.107619
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = 0
    float_0 = 0.0
    unicode_0 = u"0"
    int_1 = 1
    float_1 = 1.1
    unicode_1 = u"1"

    assert unicode_urldecode(unicode_0) == unicode_0
    assert unicode_urldecode(unicode_1) == unicode_1



# Generated at 2022-06-25 09:25:10.531988
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'0.001') == u'0.001'
    assert unicode_urldecode(u'0/001') == u'0/001'
    assert unicode_urldecode(u'a%20b%20c') == u'a b c'
    assert unicode_urldecode(u'a%2fb%2fc') == u'a/b/c'


# Generated at 2022-06-25 09:25:14.845732
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)
    print("var_0: %s" % var_0)

if __name__ == "__main__":
    test_unicode_urldecode()
    test_case_0()
    t = FilterModule()
    print("filters: %s" % t.filters())

# Generated at 2022-06-25 09:25:19.867934
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with a string type
    value = unicode_urldecode('%20')
    assert value == u' '

    # Test with a float type
    float_val = float(0.001)
    value = unicode_urldecode(float_val)
    assert value == '0.001'



# Generated at 2022-06-25 09:25:23.624311
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)
    #assert var_0 == '0.001'
    var_0 = unicode_urldecode('0.001')
    #assert var_0 == '0.001'


# Generated at 2022-06-25 09:25:33.488367
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '0.001'
    float_0 = 0.001
    var_0 = unicode_urldecode(str_0)
    print(var_0)
    var_1 = unicode_urldecode(float_0)
    print(var_1)

if __name__ == "__main__":
    print("###############")
    print("## Test Case 1")
    test_case_0()
    print("###############")
    print("## Test Case 2")
    test_unicode_urldecode()

# Generated at 2022-06-25 09:25:40.310244
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string_0 = 'test string'
    result = unicode_urldecode(string_0)
    assert result == 'test string'

    string_0 = 'test string'
    result = unicode_urldecode(string_0)
    assert result == 'test string'

    string_0 = 'test string'
    result = unicode_urldecode(string_0)
    assert result == 'test string'



# Generated at 2022-06-25 09:25:42.016383
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = []

    test_case_0()


# Generated at 2022-06-25 09:25:44.974674
# Unit test for function do_urlencode
def test_do_urlencode():
    assert isinstance(do_urlencode(1), string_types)



# Generated at 2022-06-25 09:25:47.271777
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = b'hello world'
    var_2 = unicode_urldecode(var_1)
    assert var_2 == u'hello world'



# Generated at 2022-06-25 09:25:51.766992
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)
    assert var_0 == '0.001'


# Generated at 2022-06-25 09:26:00.987499
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert isinstance(unicode_urldecode(str), unicode)
    assert unicode_urldecode(str) == unicode
    assert unicode_urldecode(str) == str
    assert unicode_urldecode(str) == '100'
    assert unicode_urldecode(str) == '1000'
    assert unicode_urldecode(str) == '10000'
    assert unicode_urldecode(str) == '100000'
    assert unicode_urldecode(str) == '1000000'
    assert unicode_urldecode(str) == '10000000'
    assert unicode_urldecode(str) == '100000000'
    assert unicode_urldecode(str) == '1000000000'
    assert unicode_urld

# Generated at 2022-06-25 09:26:08.575571
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%3a') == ':'
    assert unicode_urldecode('%3A%3a') == '::'
    assert unicode_urldecode('/') == '/'
    assert unicode_urldecode('%2F') == '%2F'
    assert unicode_urldecode('%2f') == '%2f'
    assert unicode_urldecode('%2f%2F') == '%2f%2F'
    assert unicode_urldecode('%2F/') == '%2F/'

# Generated at 2022-06-25 09:26:11.078272
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('Test filters.')
    print('method filters of class FilterModule')
    # filters() is called by a class decorator.
    # This is where filters are defined.
    # For now, skip testing.
    # filters() # filters of class FilterModule


# Generated at 2022-06-25 09:26:14.816740
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert do_urldecode("aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbQ==") == "https://www.google.com"


# Generated at 2022-06-25 09:26:19.522108
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = unicode_urldecode('https://www.google.com/search?q=%2Bfoo%20%2Bbar%20.html')
    assert var_1 == 'https://www.google.com/search?q=+foo +bar .html'


# Generated at 2022-06-25 09:26:22.791363
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    for val in ['hello', u'hello', to_text(b'hello')]:
        assert unicode_urldecode(val) == u'hello'


# Generated at 2022-06-25 09:26:24.032166
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('/test') == '/test'



# Generated at 2022-06-25 09:26:31.078286
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with string
    string_0 = 'abc'
    var_0 = unicode_urldecode(string_0)
    assert var_0 == 'abc'


# Generated at 2022-06-25 09:26:35.954686
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    float_0 = 0.001
    var_0 = unicode_urlencode(float_0)
    assert "%.6f" % var_0 == "%.6f" % 0.001


# Generated at 2022-06-25 09:26:37.228309
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()


# Generated at 2022-06-25 09:26:39.753028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    filters = mod.filters()

    assert filters.keys() == {'urldecode'}
    assert filters['urldecode'] == do_urldecode

# Generated at 2022-06-25 09:26:45.871118
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = u'\u30c9\u30a4\u30c4\u5de5\u623f'
    decoded = u'\u30c9\u30a4\u30c4\u5de5\u623f'

    encoded = u'%E3%83%8F%E3%83%AB%E3%83%89%E5%93%A5%E6%8C%BF'
    decoded_string = unicode_urldecode(encoded)

    assert string == decoded
    assert encoded == decoded_string


# Generated at 2022-06-25 09:26:51.730397
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'test'
    var_0 = unicode_urlencode(string)
    var_1 = unicode_urlencode(string, True)


# Generated at 2022-06-25 09:26:59.154108
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Narrow Python 2 build
    if not PY3:
        assert(to_text(unicode_urldecode(to_bytes('Test'))) == u'Test')
        assert(to_text(unicode_urldecode(u'Test')) == u'Test')

    # Wide Python 2 build
    if not PY3:
        assert(unicode_urldecode('Test') == u'Test')
        assert(unicode_urldecode(u'Test') == u'Test')


# Generated at 2022-06-25 09:27:01.878213
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    filter_module = FilterModule()
    for key, value in iteritems(filter_module.filters()):
        assert callable(value)

# Generated at 2022-06-25 09:27:04.372647
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(do_urlencode('http://www.foo.com/bar?a=b')) == 'http://www.foo.com/bar?a=b'



# Generated at 2022-06-25 09:27:06.429082
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    foo = FilterModule()
    var_0 = foo.filters()


# Generated at 2022-06-25 09:27:15.519584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)
    if var_0 == '0.001':
        print('Passed: unicode_urldecode')
    else:
        print('Failed: unicode_urldecode')



# Generated at 2022-06-25 09:27:23.430061
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2B") == "\+"
    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("%7B") == "{"
    assert unicode_urldecode("%7E") == "~"
    assert unicode_urldecode("%7c") == "|"
    assert unicode_urldecode("%7e") == "~"
    assert unicode_urldecode("%7E") == "~"
    assert unicode_urldecode("%5C") == "\\"
    assert unicode_urldecode("%5c") == "\\"
    assert unicode_urldecode("%2A") == "*"

# Generated at 2022-06-25 09:27:25.137944
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:27:27.989376
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) == None
    assert unicode_urldecode('test') == 'test'

# Generated at 2022-06-25 09:27:30.557172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("0.001") == "0.001"

# Generated at 2022-06-25 09:27:37.577458
# Unit test for function do_urlencode
def test_do_urlencode():
    print(do_urlencode.__doc__)
    print(do_urlencode('test'))
    print(do_urlencode(123))
    print(do_urlencode([1, 2, 3]))
    print(do_urlencode(dict(first=1, second=2, third=3)))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:27:43.021846
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:27:43.868728
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert True


# Generated at 2022-06-25 09:27:49.983588
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    data = 'hello'
    assert unicode_urldecode(data) == 'hello'
    # assert unicode_urldecode(data) == 'hello'


# Generated at 2022-06-25 09:27:52.165574
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "foo"
    expected_result = "foo"
    actual_result = unicode_urldecode(string)
    assert actual_result == expected_result


# Generated at 2022-06-25 09:28:03.514647
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Set up mock object
    FilterModule_instance = FilterModule()

    # Get the method to test
    test = getattr(FilterModule_instance, "filters")

    # Set up mock object
    mock_ansible_filter_plugins = None
    mock_ansible_filter_plugins__globals = None

    # If FilterModule.filters() raises a KeyError
    #assertRaises(KeyError, test, mock_ansible_filter_plugins, mock_ansible_filter_plugins__globals)

    # Verify the expected results
    #assertEqual(expected, test(mock_ansible_filter_plugins, mock_ansible_filter_plugins__globals))



# Generated at 2022-06-25 09:28:08.443491
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    if PY3:
        assert unicode_urldecode(float_0) == '0.001'
    else:
        assert unicode_urldecode(float_0) == u'0.001'

    bytes_0 = b'!/'
    if PY3:
        bytes_0 = '/%21/'
    assert unicode_urldecode(bytes_0) == '/!/'


# Generated at 2022-06-25 09:28:12.517325
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:28:15.518637
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = 'test'
    expected = 'test'
    actual = unicode_urlencode(value)
    assert actual == expected


# Generated at 2022-06-25 09:28:17.810042
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)
    assert var_0 == "0.001"


# Generated at 2022-06-25 09:28:25.538672
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    element_0 = int()

    # Call the method
    the_return = filterModule.filters()
    assert the_return == {'urldecode' : do_urldecode, 'urlencode': do_urlencode}

    # Call the method
    the_return = filterModule.filters(element_0)
    assert the_return == {'urldecode' : do_urldecode, 'urlencode': do_urlencode}




# Generated at 2022-06-25 09:28:28.223880
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)
    assert '%5C%22%20%5C%22' == var_0


# Generated at 2022-06-25 09:28:32.667430
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    float_0 = 0.001
    ret_0 = unicode_urlencode(float_0)
    float_1 = 0.001
    ret_1 = unicode_urlencode(float_1, True)


if __name__ == '__main__':
    test_case_0()
    test_j2_filters()
    test_unicode_urlencode()

# Generated at 2022-06-25 09:28:34.048794
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    arg = None
    obj = FilterModule()
    result = obj.filters(arg)


# Generated at 2022-06-25 09:28:43.916775
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)
    assert len(filters) == 2
    urldecode = filters['urldecode']
    assert urldecode == do_urldecode
    urlencode = filters['urlencode']
    assert urlencode == do_urlencode
    # Make sure that urlencode is called when Jinja2 is older than v2.7
    assert urlencode == do_urlencode if not HAS_URLENCODE else urlencode == do_urlencode
    # TODO: Implement further tests that verify your filter's behavior



# Generated at 2022-06-25 09:28:49.101025
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = do_urlencode((1, 2, 3))

# Generated at 2022-06-25 09:28:52.215493
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 0.001
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:28:56.812454
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:28:59.427802
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = 'foo=bar&baz=fuz'
    var_0 = unicode_urldecode(float_0)


# Generated at 2022-06-25 09:29:03.118564
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    method_0 = FilterModule.filters
    float_0 = 0.001
    var_0 = method_0(float_0)
    assert var_0 == {'urldecode': do_urldecode}, 'tests/test_jinja2_filters.py : test_case_1'


# Generated at 2022-06-25 09:29:05.466619
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module0 = FilterModule()
    assert module0.filters() is not None


# Generated at 2022-06-25 09:29:07.721520
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()

    # Test for method filters
    # Make sure the method doesn't return null
    obj.filters()

if __name__ == '__main__':
    # test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:29:11.726309
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'a string'
    assert unicode_urldecode(string) == 'a string'


# Generated at 2022-06-25 09:29:12.605127
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(0.001) == '0.001'

# Generated at 2022-06-25 09:29:16.098548
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    # This test case uses only one filter
    assert len(filters) == 1
    # Test the filter
    assert filters['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:29:25.544586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    float_0 = 0.001
    var_0 = FilterModule()
    var_1 = var_0.filters()
    var_2 = do_urldecode(float_0)
    var_1 = var_0.filters()
    var_3 = do_urldecode(float_0)


# Generated at 2022-06-25 09:29:28.145949
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    float_0 = '1.0'
    var_0 = unicode_urldecode(float_0)
    assert var_0 == '1.0'


# Generated at 2022-06-25 09:29:34.704920
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    try:
        unicode_urlencode = FilterModule.filters()['unicode_urlencode']
    except KeyError:
        assert False
        return

    # No input
    # Get exception for input without attribute 'keys'
    # Construct expected output from inputs
    expected_output = '?='

    output = unicode_urlencode(float_0)
    assert output == expected_output

# Generated at 2022-06-25 09:29:38.132284
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert False, "test disabled"


# Generated at 2022-06-25 09:29:42.486723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.plugins.filter import filters
    import jinja2
    filter_module = FilterModule()
    template_dir = '.'
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(template_dir))
    env.filters['filters'] = filters
    template = env.from_string("{{ {'test': 'hello', 'test2': 'test'} | filters }}")
    assert template.render() == "{'test': 'hello', 'test2': 'test'}"


# Generated at 2022-06-25 09:29:46.772668
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc123#$') == 'abc123%23%24'
    assert unicode_urlencode('abc123#$', for_qs=True) == 'abc123%23%24'
