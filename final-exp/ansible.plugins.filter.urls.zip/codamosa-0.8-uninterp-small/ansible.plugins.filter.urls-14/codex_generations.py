

# Generated at 2022-06-25 09:19:53.594033
# Unit test for function do_urlencode
def test_do_urlencode():

    # Testing with example dictionary value
    var_0 = 'example'

    filtered = do_urlencode(var_0)

    assert filtered == 'example'


# Generated at 2022-06-25 09:19:58.500826
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = u'abcdefgh'
    var_2 = unicode_urldecode(var_1)
    var_3 = u'abc%3Ddef%26gh'
    var_4 = unicode_urldecode(var_3)
    

# Generated at 2022-06-25 09:20:07.654698
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Invalid input type raises an exception.
    # Assertion: unicode_urldecode with inputs of invalid type must raise an exception.
    unicode_urldecode()
    # Set the assertion options
    options = {}
    options["enable_assertions"] = True
    os.environ[constants.AssertionOptionsConfig] = json.dumps(options)
    unicode_urldecode()
    # Assertion: unicode_urldecode with inputs of invalid type must raise an exception.
    options["disable_assertions"] = True
    os.environ[constants.AssertionOptionsConfig] = json.dumps(options)
    unicode_urldecode()


# Generated at 2022-06-25 09:20:09.361058
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.filters()


# Generated at 2022-06-25 09:20:15.101340
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = 'dag@wieers.com'
    actual_0 = unicode_urldecode(var_0)
    expected_0 = 'dag@wieers.com'
    assert actual_0 == expected_0


# Generated at 2022-06-25 09:20:23.842962
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode() == ''
    assert unicode_urlencode(None) == ''
    assert unicode_urlencode('string') == 'string'
    assert unicode_urlencode('string', for_qs=True) == 'string'
    assert unicode_urlencode(u'string') == 'string'
    assert unicode_urlencode(u'string', for_qs=True) == 'string'
    assert unicode_urlencode(u'string =') == 'string%20%3D'
    assert unicode_urlencode(u'string =', for_qs=True) == 'string+%3D'
    assert unicode_urlencode([u'a', u'b', u'c']) == 'a&b&c'
    assert unicode_urlen

# Generated at 2022-06-25 09:20:25.843134
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('cXdlcnR5') == b'qwerty'



# Generated at 2022-06-25 09:20:34.448034
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
	assert unicode_urlencode(u'foo') == u'foo'
	assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
	assert unicode_urlencode(u'foo bar') == u'foo%20bar'
	assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
	assert unicode_urlencode(u'foo&bar') == u'foo%26bar'
	assert unicode_urlencode(u'foo=bar') == u'foo%3Dbar'
	assert unicode_urlencode(u'foo?bar') == u'foo?bar'
	assert unicode_urlencode(u'foo#bar') == u'foo#bar'

# Generated at 2022-06-25 09:20:37.252047
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    """Test case for the "unicode_urldecode" function."""
    # assert unicode_urldecode('') == ''


# Generated at 2022-06-25 09:20:41.508641
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://localhost:5985/') == 'http%3A//localhost%3A5985/'


# Generated at 2022-06-25 09:20:50.938941
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test with a single argument
    assert unicode_urlencode('Test case for the "unicode_urlencode" function.') == 'Test%20case%20for%20the%20%22unicode_urlencode%22%20function.'
    assert unicode_urlencode('Test case for the "unicode_urlencode" function.', for_qs=True) == 'Test+case+for+the+%22unicode_urlencode%22+function.'

    # Test with a dictionary
    assert unicode_urlencode({'a': 'b'}) == 'a=b'

    # Test with a list
    assert unicode_urlencode(['a=b', 'c=d']) == 'a=b&c=d'

    # Test with a tuple

# Generated at 2022-06-25 09:20:52.435127
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Test case for the "unicode_urldecode" function.') == 'Test case for the "unicode_urldecode" function.'


# Generated at 2022-06-25 09:20:58.781021
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.module_utils.six as six
    six.assertIsInstance(FilterModule.filters(FilterModule()), dict)


if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:21:08.645089
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    """Test the functionality of the unicode_urldecode function."""

# Generated at 2022-06-25 09:21:16.966582
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Input parameters
    string = 'My book name is The Hitchhiker\'s Guide to the Galaxy.'
    for_qs = False
    # Expected output
    expected = 'My%20book%20name%20is%20The%20Hitchhiker%27s%20Guide%20to%20the%20Galaxy.'

    # Run the function, get the result
    result = unicode_urlencode(string, for_qs)

    # Check if the expected result is the same as the result
    assert result == expected, 'unicode_urlencode function failed.'
    print('Test passed!')


if __name__ == '__main__':
    test_case_0()
    test_unicode_urlencode()

# Generated at 2022-06-25 09:21:19.177872
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print("Testing 'unicode_urlencode' function.\n")
    test_case_0()

# ----------------------------------------------------------------------

# Generated at 2022-06-25 09:21:29.399671
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
  print('Testing the unicode_urlencode function...')

  str_0 = 'Test case for the "unicode_urlencode" function.'
  str_1 = unicode_urlencode(str_0)
  assert str_1 == 'Test%20case%20for%20the%20%22unicode_urlencode%22%20function.', 'Bare string returned "%s"' % str_1
  print('  Bare string: "%s" -&gt; "%s"' % (str_0, str_1))

  str_0 = 'Test case for the "unicode_urlencode" function.'
  str_1 = unicode_urlencode(str_0, for_qs=True)

# Generated at 2022-06-25 09:21:30.779952
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    myFilterModule = FilterModule()

    filters = myFilterModule.filters()

    assert 'urldecode' in filters



# Generated at 2022-06-25 09:21:31.374775
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    pass


# Generated at 2022-06-25 09:21:32.143754
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # No-op to force coverage
    pass


# Generated at 2022-06-25 09:21:35.503737
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'


# Generated at 2022-06-25 09:21:39.614086
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = '_x\x0c'
    obj_0 = FilterModule()
    var_0 = obj_0.filters()
    del obj_0
    var_1 = do_urldecode(str_0)

# Generated at 2022-06-25 09:21:43.540216
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert(var_0 == '_x\x0c')


# Generated at 2022-06-25 09:21:46.181701
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-25 09:21:49.774659
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'abc+_x\x0c'
    plus_replacement = 'abc%2B_x\x0c'
    assert(unicode_urldecode(string) == plus_replacement)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:21:51.621384
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == '_x\u000c'


# Generated at 2022-06-25 09:22:01.048357
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = '_x\x0c'
    str_1 = 'x=y&a=b'
    str_2 = '_x\x0c'
    str_3 = 'a\x00=b\x00&c\x00'
    str_4 = 'a\x00+%3D=b\x00%3D&c\x00+%3D'

    obj = FilterModule()
    var_0 = obj.filters()
    var_1 = do_urldecode(str_0)
    var_2 = do_urlencode(str_1)
    var_3 = do_urldecode(str_2)
    var_4 = do_urldecode(str_3)
    var_5 = do_urldecode(str_4)

# Generated at 2022-06-25 09:22:07.234013
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    with pytest.raises(TypeError) as excinfo:
        unicode_urlencode()
    assert 'missing 1 required positional argument: \'string\'' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        unicode_urlencode('')
    assert 'missing 1 required positional argument: \'string\'' in str(excinfo.value)
    str_0 = 'd_r'
    for_qs_0 = 'b'
    assert unicode_urlencode(str_0, for_qs_0) == 'd_r'


# Generated at 2022-06-25 09:22:16.668167
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Unicode string
    str_0 = '_x\x0c'
    result_0 = unicode_urldecode(str_0)
    assert result_0 == '_x\x0c'
    # Unicode string
    str_0 = '\x02\'\x1f~'
    result_0 = unicode_urldecode(str_0)
    assert result_0 == '\x02\'\x1f~'
    # Unicode string
    str_0 = '\x02\x1f'
    result_0 = unicode_urldecode(str_0)
    assert result_0 == '\x02\x1f'
    # Unicode string
    str_0 = '\x02\'\x1f~\x0c'
    result_0 = unicode_ur

# Generated at 2022-06-25 09:22:20.024179
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = '_x\x0c'
    for_qs = False
    safe = '/'
    expected = '_x%0C'
    actual = unicode_urlencode(string, for_qs)
    print(actual)
    assert actual == expected


# Generated at 2022-06-25 09:22:26.018099
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()


# Generated at 2022-06-25 09:22:32.986930
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # instance for FilterModule
    filter_module = FilterModule()

    # from ansible.module_utils.six import PY3
    assert PY3 is True or PY3 is False

    # from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    # unquote_plus -> _unquote_unreserved

    # from ansible.module_utils.six.moves.urllib.parse import quote_plus
    # quote_plus -> _quote

    # from ansible.module_utils.six.moves.urllib.parse import quote
    # quote -> _quote

    # from ansible.module_utils._text import to_bytes
    # to_bytes -> to_native

    # from ansible.module_utils._text import to_text
    # to_text ->

# Generated at 2022-06-25 09:22:35.026818
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == '_x'


# Generated at 2022-06-25 09:22:36.590995
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    TestFilterModule = FilterModule()
    assert isinstance(TestFilterModule.filters(), dict)

# Generated at 2022-06-25 09:22:37.654687
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    var_0 = obj.filters()

# Generated at 2022-06-25 09:22:40.213297
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'


# Generated at 2022-06-25 09:22:43.469179
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    result = {}
    # TypeError: 'dict' object is not callable
    with pytest.raises(TypeError):
        result = test.filters()


# Generated at 2022-06-25 09:22:51.071335
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Call unicode_urlencode with correct argumets:
    result = unicode_urlencode('dag')
    assert type(result) == str
    assert result == 'dag'
    # Call unicode_urlencode with wrong but valid argumets:
    result = unicode_urlencode('dag_wieers')
    assert type(result) == str
    assert result == 'dag_wieers'


# Generated at 2022-06-25 09:22:58.725482
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    name = '_x\x0c'
    value = unicode_urldecode(name)
    assert value == '_x'
    value = unicode_urldecode(name, True)
    assert value == '_x'


# Generated at 2022-06-25 09:23:03.132344
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x\x0c'



# Generated at 2022-06-25 09:23:14.088628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Testing if value = '_x\x0c' is equal to value = '_x\x0c' after calling function unicode_urldecode
    value = '_x\x0c'
    result = unicode_urldecode(value)
    assert result == '_x\x0c'
    # Testing if value = '+' is equal to value = ' ' after calling function unicode_urldecode
    value = '+'
    result = unicode_urldecode(value)
    assert result == ' '
    # Testing if value = '_' is equal to value = '_' after calling function unicode_urldecode
    value = '_'
    result = unicode_urldecode(value)
    assert result == '_'
    # Testing if value = '+\xf

# Generated at 2022-06-25 09:23:18.741834
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == '_x%0c'
    assert unicode_urldecode('\n') == '%0a'
    assert unicode_urldecode('_x\x0c') == '_x%0c'



# Generated at 2022-06-25 09:23:24.574225
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Tests for correct encoding.
    str_0 = 'i am a string'
    var_0 = do_urlencode(str_0)
    answer = 'i+am+a+string'
    assert var_0 == answer



# Generated at 2022-06-25 09:23:31.302860
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'

if __name__ == '__main__':
    test_case_0()
    test_unicode_urldecode()

# Generated at 2022-06-25 09:23:33.274930
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    assert unicode_urldecode(str_0) == '_x'


# Generated at 2022-06-25 09:23:39.281301
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '_x\x0c'
    var_0 = do_urldecode(str_0)
    assert unicode_urlencode(var_0) == '_x%0C'

# Generated at 2022-06-25 09:23:43.376812
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'


# Generated at 2022-06-25 09:23:48.474395
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Calling unicode_urlencode(string)
    str_1 = '_x\x0c'
    var_1 = unicode_urlencode(str_1)
    assert var_1 == '_x%0c'


# Generated at 2022-06-25 09:23:56.791864
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode({"a": "b", "c": "d"}) == "a=b&c=d")
    assert(do_urlencode({"a": "b"}) == "a=b")
    assert(do_urlencode({"a": None}) == "a=")
    assert(do_urlencode(None) == None)
    assert(do_urlencode({"a": ["b", "c"]}) == "a=b&a=c")
    assert(do_urlencode("a") == "a")


# Generated at 2022-06-25 09:24:05.378416
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:24:07.791000
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 1 == 1


# Generated at 2022-06-25 09:24:09.850294
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '}'
    str_1 = '%7D'
    var_0 = unicode_urlencode(str_0)
    assert var_0 == str_1



# Generated at 2022-06-25 09:24:17.426936
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('\n## Unit test for filters of class FilterModule\n')
    test_FilterModule_filters = FilterModule()
    result = test_FilterModule_filters.filters()
    print(result)

if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-25 09:24:20.060886
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert to_text(unicode_urldecode(to_text('_x\x0c'))) == "_x\x0c"


# Generated at 2022-06-25 09:24:25.785295
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("string") == "string"

    assert unicode_urlencode("string", for_qs=True) == "string"

    assert unicode_urlencode("/string") == "%2Fstring"

    assert unicode_urlencode("/string", for_qs=True) == "%2Fstring"



# Generated at 2022-06-25 09:24:30.107101
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'



# Generated at 2022-06-25 09:24:37.286597
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:24:42.382999
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:24:44.202738
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit test for method filters of class FilterModule.'''
    obj_0 = FilterModule()
    var_0 = obj_0.filters()

# Generated at 2022-06-25 09:24:51.021340
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == '_x\r'
    assert unicode_urldecode('3A') == u':'
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%3a') == ':'
    assert unicode_urldecode('%3A') == ':'


# Generated at 2022-06-25 09:24:54.007315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)
    assert filters != None

# Generated at 2022-06-25 09:25:00.424576
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    str_1 = '_x\x0c'
    var_1 = unicode_urldecode(str_1)
    str_2 = '_x\x0c'
    var_2 = unicode_urldecode(str_2)
    str_3 = '_x\x0c'
    var_3 = unicode_urldecode(str_3)

# Generated at 2022-06-25 09:25:01.912886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    # method filters()
    # TODO: make test

# Generated at 2022-06-25 09:25:04.475829
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = '_x\x0c'
    for_qs = False
    ret = unicode_urlencode(string, for_qs)
    assert ret == '_x%0C'


# Generated at 2022-06-25 09:25:11.113017
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = '_x\x0c'
    str_1 = '_x\x0c'
    obj_0 = FilterModule()
    dict_0 = obj_0.filters()
    var_0 = dict_0.get('urldecode')
    var_1 = var_0(str_0)
    var_3 = dict_0.get('urldecode')
    var_4 = var_3(str_1)
    assert (var_1 == var_4)


# Generated at 2022-06-25 09:25:13.429612
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    expected = '_x\x0c'
    actual = unicode_urldecode('_x\x0c')
    assert actual == expected


# Generated at 2022-06-25 09:25:17.606531
# Unit test for function do_urlencode
def test_do_urlencode():
    str_0 = 'gf\x0f'
    str_1 = '\x0e\x0e'
    var_0 = do_urlencode(str_0)
    var_1 = do_urlencode(str_0, str_1)


# Generated at 2022-06-25 09:25:26.436222
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'
    str_1 = ''
    var_1 = unicode_urldecode(str_1)
    assert var_1 == ''
    str_2 = '_x\x0c'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == '_x'
    str_3 = '_x\x0c'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == '_x'
    str_4 = ''
    var_4 = unicode_urldecode(str_4)
    assert var_4 == ''
    str_5

# Generated at 2022-06-25 09:25:29.162102
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:25:34.905972
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(var_0)
    var_1 = unicode_urldecode(var_0)
    assert var_0 == unicode('_x\x0c')
    assert var_1 == unicode('_x\x0c')


# Generated at 2022-06-25 09:25:47.672284
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x'
    str_1 = 'test/test'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == 'test/test'
    str_2 = 'n+=*'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == 'n+=*'
    str_3 = '%E5%85%94'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == '\u514c'


# Generated at 2022-06-25 09:25:50.580405
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:25:52.348454
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)

# main is just used for unit testing

# Generated at 2022-06-25 09:25:57.276584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test the function with arguments.
    str_0 = 'test_str'
    abs_0 = unicode_urldecode(str_0)
    assert abs_0 == 'test_str'

    str_0 = 'test_str'
    str_1 = 'test_str'
    abs_0 = unicode_urldecode(str_0)
    assert abs_0 == str_1



# Generated at 2022-06-25 09:25:59.528876
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '_x\x0c'
    var_1 = unicode_urldecode(str_1)


# Generated at 2022-06-25 09:26:01.427107
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:26:03.968020
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Print statements
    str_0 = '_x\x0c'
    str_1 = '_x\x0c'
    assert str_0 == str_1


# Generated at 2022-06-25 09:26:06.158389
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x\x0c'


# Generated at 2022-06-25 09:26:08.024589
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '_x\x0c'
    var_1 = unicode_urldecode(str_1)

    assert var_1 == '#'



# Generated at 2022-06-25 09:26:09.110240
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert type(FilterModule(  ).filters(  )) == dict


# Generated at 2022-06-25 09:26:17.157064
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '_x\x0c'
    var_0 = unicode_urlencode(str_0)
    # assert var_0 == '_x%0C'
    print(var_0)

test_unicode_urlencode()

# Generated at 2022-06-25 09:26:20.051416
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    inst_0 = FilterModule()
    data_0 = inst_0.filters()
    assert (list(data_0)[0] == 'urldecode')
    return

# Unit tests for method do_urlencode of class FilterModule

# Generated at 2022-06-25 09:26:23.069332
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x\\x0c'


# Generated at 2022-06-25 09:26:24.206453
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    with pytest.raises(Exception):
        FilterModule().filters()



# Generated at 2022-06-25 09:26:26.937625
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    str_1 = var_0
    assert str_1 == '_x\x0c'


# Generated at 2022-06-25 09:26:30.931975
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '_x\x0c'
    var_0 = unicode_urldecode(str_1)
    return var_0


# Generated at 2022-06-25 09:26:34.894328
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    _str = u'a'
    assert unicode_urlencode(_str) == u'a'


# Generated at 2022-06-25 09:26:37.942602
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'_x\x0c') == u'_x'
    assert unicode_urldecode(u'_x%0c') == u'_x'


# Generated at 2022-06-25 09:26:41.780548
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ('_x\x0c', '_x'),
    ]

    for str_0, test_case in enumerate(test_cases):
        if len(test_case) < 2:
            continue

        assert unicode_urldecode(test_case[0]) == test_case[1]

# Generated at 2022-06-25 09:26:43.179619
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert False


# Generated at 2022-06-25 09:26:51.926021
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x\x0c'

# Generated at 2022-06-25 09:27:01.902454
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test for function do_urlencode with simple data
    var_0 = {}
    var_1 = []

    # Test for function do_urlencode with simple data
    var_0 = {}
    var_1 = [1, 2, 3]
    var_2 = {}
    var_1.append(var_2)
    var_2 = {}
    var_1.append(var_2)
    var_2 = {}
    var_1.append(var_2)
    var_0['false'] = var_1
    var_1 = []
    var_2 = {}
    var_1.append(var_2)
    var_2 = {}
    var_1.append(var_2)
    var_2 = {}
    var_1.append(var_2)
    var_0

# Generated at 2022-06-25 09:27:10.790558
# Unit test for function do_urlencode
def test_do_urlencode():
    assert not unicode_urlencode('\x0c'.decode('utf-8'), False)
    assert unicode_urlencode('_x\x0c'.decode('utf-8'), False)
    assert unicode_urlencode('_x\x0c'.decode('utf-8'), True) == '_x%0C'
    assert unicode_urlencode('_x\x0c'.decode('utf-8')) == '_x%0C'


# Generated at 2022-06-25 09:27:15.136104
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert (var_0 == "_x")


# Generated at 2022-06-25 09:27:15.946476
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ret = unicode_urlencode("var_0")
    assert ret == string_types("var_0")


# Generated at 2022-06-25 09:27:18.289700
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    print(var_0)


# Generated at 2022-06-25 09:27:22.255865
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_1 = '{a: 1}'
    str_2 = 'a=1'
    var_1 = unicode_urlencode(str_1)
    var_2 = unicode_urlencode(str_1, for_qs=True)
    assert var_1 == '%7Ba%3A%201%7D' and var_2 == 'a%3D1'


# Generated at 2022-06-25 09:27:32.792615
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == '_x'
    assert unicode_urldecode('_x') == '_x'
    assert unicode_urldecode('=') == '='
    assert unicode_urldecode('=\n') == '=\n'
    assert unicode_urldecode('_x\x0c') == '_x'
    assert unicode_urldecode('_x') == '_x'
    assert unicode_urldecode('=') == '='
    assert unicode_urldecode('=\n') == '=\n'
    assert unicode_urldecode('value1') == 'value1'
    assert unicode_urldecode('value2') == 'value2'
    assert unic

# Generated at 2022-06-25 09:27:36.905129
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = u'abcd'
    var_2 = u'%s' % var_1
    assert unicode_urldecode(var_2) == var_1, '%s not equal to %s' % (unicode_urldecode(var_2), var_1)


# Generated at 2022-06-25 09:27:39.021339
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)



# Generated at 2022-06-25 09:27:43.098458
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()

# Generated at 2022-06-25 09:27:44.246986
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('+') == ' '


# Generated at 2022-06-25 09:27:56.250700
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('%20') == '%2520'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('%2F') == '%252F'
    assert unicode_urlencode('%252F') == '%25252F'
    assert unicode_urlencode('%25252F') == '%2525252F'

    assert unicode_urlencode('%20', True) == '%20'
    assert unicode_urlencode('/', True) == '%2F'
    assert unicode_urlencode('%2F', True) == '%2F'
    assert unicode_urlencode('%252F', True) == '%252F'

# Generated at 2022-06-25 09:28:06.011094
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ustr_0 = u'y'
    assert unicode_urlencode(ustr_0), u'y'
    ustr_1 = u'1'
    assert unicode_urlencode(ustr_1), u'1'
    ustr_2 = u'\x7f'
    assert unicode_urlencode(ustr_2), u'%7F'
    ustr_3 = u'\u0100'
    assert unicode_urlencode(ustr_3), u'%C4%80'
    ustr_4 = u'\U00010000'
    assert unicode_urlencode(ustr_4), u'%F0%90%80%80'
    #ustr_5 = u'\ud800'
    #assert unicode_urlencode(ustr_

# Generated at 2022-06-25 09:28:07.760820
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import gc
    obj = FilterModule()
    var_0 = obj.filters()
    del obj
    gc.collect()


# Generated at 2022-06-25 09:28:16.332141
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '\x08\x92\x8f\x06\x1a+t\x92\x8f'
    str_1 = '='
    str_2 = ''
    str_3 = '-'
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(str_1)
    var_2 = unicode_urldecode(str_2)
    var_3 = unicode_urldecode(str_3)


# Generated at 2022-06-25 09:28:28.181640
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '_x\x0c'
    str_1 = ' _x\x0c '
    var_1 = unicode_urldecode(str_1)
    assert var_1 == ' _x\x0c '
    str_2 = '_x\x0c'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == '_x\x0c'
    str_3 = 's+s'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == 's s'
    str_4 = '_x\x0c'
    var_4

# Generated at 2022-06-25 09:28:30.372758
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:32.201052
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:33.026838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t = FilterModule()
    t.filters()

# Generated at 2022-06-25 09:28:37.787396
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'C:\Windows\system32\drivers\etc\hosts'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:41.305585
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'_x\x0c') == u'_x\x0c'



# Generated at 2022-06-25 09:28:43.157842
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:46.354566
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = '_x\x0c'
    global filters_0

    filters_0 = FilterModule().filters()


# Generated at 2022-06-25 09:28:49.049356
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == u'_x\x0c'


# Generated at 2022-06-25 09:28:50.725602
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert(isinstance(obj.filters(), dict))

# Generated at 2022-06-25 09:29:02.439698
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Test urldecode()...")
    str_0 = '>'
    var_0 = unicode_urldecode(str_0)
    print("var_0 = %s" % repr(var_0))
    var_1 = '_x\x0c'
    var_2 = unicode_urldecode(var_1)
    print("var_2 = %s" % repr(var_2))
    var_3 = 'test_test'
    var_4 = unicode_urldecode(var_3)
    print("var_4 = %s" % repr(var_4))
    var_5 = '^'
    var_6 = unicode_urldecode(var_5)
    print("var_6 = %s" % repr(var_6))


# Generated at 2022-06-25 09:29:07.815868
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'mystring') == 'mystring'
    assert unicode_urldecode(u'mystring') == 'mystring'
    assert unicode_urldecode(b'mystring') == 'mystring'
    assert unicode_urldecode(u'sp%C3%A4c%C3%A9') == u'späc\u00e9'
    assert unicode_urldecode(b'sp%C3%A4c%C3%A9') == u'späc\u00e9'


# Generated at 2022-06-25 09:29:11.723975
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)


# Generated at 2022-06-25 09:29:12.361700
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    pass


# Generated at 2022-06-25 09:29:20.576151
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    assert unicode_urldecode(str_0) == '_x\x0c'


# Generated at 2022-06-25 09:29:25.306606
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class DummyObj:
        def __init__(self):
            pass
    dummyobj = DummyObj()
    assert dummyobj
    dummyinst = FilterModule()
    assert dummyinst
    result = dummyinst.filters()
    assert result

# Generated at 2022-06-25 09:29:28.265730
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '_x\x0c'
    var_0 = unicode_urldecode(str_0)
    var_1 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:29:31.200289
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()



# Generated at 2022-06-25 09:29:37.169624
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('_x\x0c') == '_x%0c'
    assert unicode_urlencode('_x\x0c', True) == '_x%0c'

    assert unicode_urlencode(u'_x\x0c') == '_x%0c'
    assert unicode_urlencode(u'_x\x0c', True) == '_x%0c'

    assert unicode_urlencode('_x\x0c', False) == '_x%0c'
    assert unicode_urlencode(u'_x\x0c', False) == '_x%0c'


# Generated at 2022-06-25 09:29:39.116387
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '_x\x0c'
    # Call function
    value = unicode_urldecode(str_1)
    # print(value)
    assert value == u"_x"



# Generated at 2022-06-25 09:29:40.632048
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Setup
    str_0 = '_x\x0c'

    # Exercise
    var_0 = unicode_urldecode(str_0)

    # Verify
    expected = '_x'
    assert var_0 == expected



# Generated at 2022-06-25 09:29:41.849678
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x') == 'y'


# Generated at 2022-06-25 09:29:45.773689
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('_x\x0c') == "_x"



# Generated at 2022-06-25 09:29:47.112598
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    # This assertion doesn't actually test anything with the given inputs.
    # assert filter_module.filters()
    pass