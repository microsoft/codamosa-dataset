

# Generated at 2022-06-25 09:19:51.096989
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'


# Generated at 2022-06-25 09:19:59.865258
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b"") == ""
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%") == "%"
    assert unicode_urldecode("%2") == "%2"
    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("%252") == "%2"
    assert unicode_urldecode("%2525") == "%25"
    assert unicode_urldecode("%25252") == "%2"



# Generated at 2022-06-25 09:20:01.789133
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    s = b"a b c"
    assert unicode_urlencode(s) == b'a%20b%20c'
    assert unicode_urlencode(s, True) == b'a+b+c'



# Generated at 2022-06-25 09:20:06.697031
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  filter_module_1 = FilterModule()
  assert filter_module_1.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:20:11.016670
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(to_text(b'%3D')) == u'%3D'
    assert unicode_urldecode('%3D') == u'%3D'


# Generated at 2022-06-25 09:20:12.804622
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass
    assert unicode_urldecode('c%3D') == 'c='


# Generated at 2022-06-25 09:20:20.045611
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters = FilterModule.filters(filter_module_0)
    assert filters == {
        'urldecode': do_urldecode,
    }, 'Expected value did not match actual value! Value: {val!r}.'.format(val=filters)


# Generated at 2022-06-25 09:20:27.924528
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "%7B%22ip%22%3A%22127.0.0.1%22%2C%22hostname%22%3A%22host.hostname.com%22%2C%22a%22%3A%5B%22b%22%5D%7D"
    expected_result = "{\"ip\":\"127.0.0.1\",\"hostname\":\"host.hostname.com\",\"a\":[\"b\"]}"
    assert(unicode_urldecode(string) == expected_result)



# Generated at 2022-06-25 09:20:35.816713
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%24') == u'$'
    assert unicode_urldecode(u'%26') == u'&'
    assert unicode_urldecode(u'%40') == u'@'
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'%2C') == u','
    assert unicode_urldecode(u'%3B') == u';'
    assert unicode_urldecode(u'%3D') == u'='
    assert unicode_urldecode(u'%3F') == u'?'
    assert unicode_urldecode(u'%5B') == u'['

# Generated at 2022-06-25 09:20:40.160196
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("test%20abc") == u"test abc"
    assert unicode_urldecode("%2520test%2520abc%2520") == u"%20test%20abc%20"
    assert unicode_urldecode("test%20abc%2520") == u"test abc%20"
    assert unicode_urldecode("%2520test%20abc") == u"%20test abc"


# Generated at 2022-06-25 09:20:46.929715
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
# AssertionError: {u'urldecode': <function do_urldecode at 0x7f6a0f624758>} != {u'urldecode': <function do_urldecode at 0x7f6a0f6247d0>}


# Generated at 2022-06-25 09:20:50.937960
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = unicode_urldecode(b'abc,def')
    assert s == u'abc,def'
    s = unicode_urldecode(b'abc%2Cdef')
    assert s == u'abc%2Cdef'
    s = unicode_urldecode(b'abc%2Cdef%2Cghi')
    assert s == u'abc%2Cdef%2Cghi'


# Generated at 2022-06-25 09:20:53.585535
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('%2520') == '%20'
        assert unicode_urldecode('%2B') == '+'
    else:
        assert unicode_urldecode('%2520') == to_text('%20')
        assert unicode_urldecode('%2B') == to_text('+')


# Generated at 2022-06-25 09:20:57.715921
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:20:59.032219
# Unit test for function do_urlencode
def test_do_urlencode():
    result = do_urlencode("string")
    assert 'string' in result


# Generated at 2022-06-25 09:21:04.320675
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('param1=value1&param2=value2') == 'param1=value1&param2=value2'


# Generated at 2022-06-25 09:21:05.478341
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("test") == "test"


# Generated at 2022-06-25 09:21:10.747993
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('''A space: '' and a quote: "''') == 'A%20space%3A%20%27%27%20and%20a%20quote%3A%20%22%27'


# Generated at 2022-06-25 09:21:15.486752
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result_expected = 'http%3A%2F%2Fwww.google.com%2F'
    result = unicode_urlencode('http://www.google.com/', for_qs=False)
    assert result == result_expected



# Generated at 2022-06-25 09:21:23.646491
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fwww.example.com%2F%3Fname%3Dvalue') == 'http://www.example.com/?name=value'
    assert unicode_urldecode('http%3A%2F%2Fwww.example.com%2F%3Fname%3Dvalue%26name2%3Dvalue2') == 'http://www.example.com/?name=value&name2=value2'
    assert unicode_urldecode(u'http%3A%2F%2Fwww.example.com%2F%3Fname%3Dvalue') == 'http://www.example.com/?name=value'

# Generated at 2022-06-25 09:21:27.775243
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'foo+bar%40example+com'
    assert unicode_urldecode(string) == to_text('foo bar@example com')



# Generated at 2022-06-25 09:21:30.587168
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A1bcd') == u'ábcd'
    assert unicode_urldecode('%c3%a1bcd') == u'ábcd'
    assert unicode_urldecode('%2F') == u'/'


# Generated at 2022-06-25 09:21:35.676525
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%20%2B%20%C3%BC?%25%5E5%5E5%5E5%5E5%5E5%5E5%5E5') == u'ä + ü?%^5^5^5^5^5^5^5^5'


# Generated at 2022-06-25 09:21:41.235094
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82'

# Generated at 2022-06-25 09:21:48.135839
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("ABCD") == 'ABCD'
    assert unicode_urldecode("%20") == " "
    assert unicode_urldecode("%E3%81%82") == "あ"
    assert unicode_urldecode("%2B") == "+"
    assert unicode_urldecode("a%20b") == "a b"
    assert unicode_urldecode("a+b") == "a+b"


# Generated at 2022-06-25 09:21:49.331627
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_urldecode('')


# Generated at 2022-06-25 09:21:55.676616
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # isinstance(FilterModule.filters(FilterModule()), types.DictType)
    # isinstance(FilterModule.filters(FilterModule()), types.DictType)
    # assert FilterModule.filters(FilterModule()) == {}
    # assert {} == {}
    assert True # TODO: implement your test here

test_FilterModule_filters()



# Generated at 2022-06-25 09:22:00.086540
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'héllo' == unicode_urldecode('h%C3%A9llo')
    assert u'héllo' == unicode_urldecode('h%c3%a9llo')
    assert u'héllo' == unicode_urldecode('h%e9llo')


# Generated at 2022-06-25 09:22:02.472515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2B') == u'+'


# Generated at 2022-06-25 09:22:08.379764
# Unit test for function do_urlencode
def test_do_urlencode():
    filter_module = FilterModule()
    filters = filter_module.filters()
    test = filters['urlencode']("/path/to?my=file.txt")
    assert test == '/path/to%3Fmy%3Dfile.txt', test



# Generated at 2022-06-25 09:22:15.412479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    out = FilterModule()
    actual_filters = out.filters()
    expected_filters = FilterModule()
    ok_(actual_filters == expected_filters)

# Generated at 2022-06-25 09:22:17.603370
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(False) == 'False'
    assert unicode_urldecode(True) == 'True'


# Generated at 2022-06-25 09:22:19.619060
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_0 = u"%2B%2B"
    var_0 = unicode_urldecode(test_0)


# Generated at 2022-06-25 09:22:20.886178
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    param_0 = None
    # Test function
    # assert None == unicode_urldecode(param_0)


# Generated at 2022-06-25 09:22:27.713444
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # Case 0:
    str_0 = 'Test string 000'
    str_0_expect = 'Test%20string%20000'
    assert unicode_urlencode(str_0) == str_0_expect

    # Case 1:
    str_1 = 'Test string 001'
    str_1_expect = 'Test%20string%20001'
    assert unicode_urlencode(str_1) == str_1_expect

    # Case 2:
    str_2 = 'Test string 002'
    str_2_expect = 'Test%20string%20002'
    assert unicode_urlencode(str_2) == str_2_expect

    # Case 3:
    str_3 = 'Test string 003'

# Generated at 2022-06-25 09:22:36.190639
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Function unicode_urldecode has default arguments
    # Function unicode_urldecode is a builtin filter
    assert unicode_urldecode('a/b/c') == 'a/b/c'
    assert unicode_urldecode('a%2Fb%2Fc') == 'a/b/c'


# Generated at 2022-06-25 09:22:39.242453
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert isinstance(module.filters(), dict)
    f = module.filters()
    assert "urldecode" in f
    assert f["urldecode"] is do_urldecode
    if not HAS_URLENCODE:
        assert "urlencode" in f
        assert f["urlencode"] is do_urlencode

# Generated at 2022-06-25 09:22:42.574424
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'test'
    for_qs = True
    result = unicode_urlencode(string, for_qs)
    assert string == 'test'
    assert result == 'test'


# Generated at 2022-06-25 09:22:53.766526
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'
    assert(unicode_urldecode('123')) == '123'

# Generated at 2022-06-25 09:23:04.989009
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == '', 'Wrong result for test_unicode_urldecode'
    assert unicode_urldecode('https://github.com/ansible/ansible/blob/devel/lib/ansible/modules/core/cloud/amazon/ec2_ami.py') == 'https://github.com/ansible/ansible/blob/devel/lib/ansible/modules/core/cloud/amazon/ec2_ami.py', 'Wrong result for test_unicode_urldecode'

# Generated at 2022-06-25 09:23:15.462226
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print('\n*** unicode_urldecode ***\n')
    s = 'a+b+c'
    t = unicode_urldecode(s)
    assert t == 'a b c'
    s = 'a%20b%20c'
    t = unicode_urldecode(s)
    assert t == 'a b c'
    s = '%26%20%3D%20%2A'
    t = unicode_urldecode(s)
    assert t == '& = *'
    print('\n# Test 0: unicode_urldecode\n')
    test_case_0()


# Generated at 2022-06-25 09:23:18.420047
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("test") == b''
test_unicode_urldecode()


# Generated at 2022-06-25 09:23:22.471508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()

# Generated at 2022-06-25 09:23:25.407211
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Setup
    unit_test_FilterModule = FilterModule()

    # Assertions
    assert_equal(unit_test_FilterModule.filters(), {'urlencode': do_urlencode, 'urldecode': do_urldecode})

# Generated at 2022-06-25 09:23:31.006099
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_instance = FilterModule()
    filters = class_instance.filters()
    # AssertionError: 'urlencode' not in <filters dict>
    # AssertionError: 'urldecode' not in <filters dict>


# Generated at 2022-06-25 09:23:32.602909
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello world') == 'hello world', 'Test case 0'


# Generated at 2022-06-25 09:23:44.582307
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  # Unit: filters
  filters = FilterModule.filters(FilterModule())
  filters['urldecode'](True) == True
  filters['urldecode'](False) == False
  filters['urldecode']('string') == 'string'
  filters['urldecode']('string string') == 'string string'
  filters['urldecode']({'key': 'value'}) == {'key': 'value'}
  filters['urldecode']({'key': 'value', 'key': 'value'}) == {'key': 'value', 'key': 'value'}
  filters['urldecode']({'key': 'value', 'key': 'value'}) == {'key': 'value', 'key': 'value'}

# Generated at 2022-06-25 09:23:47.157634
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_0 = FilterModule()
    var_0 = FilterModule.filters(class_0)
    return var_0


# Generated at 2022-06-25 09:23:48.538961
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(bool) == 'True'


# Generated at 2022-06-25 09:23:55.388765
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert to_text(u'\u00E9') == unicode_urldecode('%C3%A9')
    assert '\u540C\u6B65\u5730\u5740' == unicode_urldecode('%E5%90%8C%E6%AD%A5%E5%9C%B0%E5%9D%80')
    assert u'\u540C\u6B65\u5730\u5740' == unicode_urldecode('%E5%90%8C%E6%AD%A5%E5%9C%B0%E5%9D%80')

# Generated at 2022-06-25 09:24:07.254893
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode(None) == 'None'
    assert unicode_urldecode('True') == 'True'
    assert unicode_urldecode('False') == 'False'
    assert unicode_urldecode('123') == '123'
    assert unicode_urldecode('abc=123') == 'abc=123'
    assert unicode_urldecode('abc=def') == 'abc=def'
    assert unicode_urldecode('abc=%20def') == 'abc= def'
    assert unicode_urldecode('abc%20=%20def') == 'abc = def'
    assert unicode_urldecode('abc=%20') == 'abc= '
    assert unicode_

# Generated at 2022-06-25 09:24:09.547481
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(False) == u'False'
    assert unicode_urldecode(True) == u'True'
    assert unicode_urldecode(None) == u''



# Generated at 2022-06-25 09:24:13.345579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    fm = FilterModule()

    assert 'urldecode' in fm.filters()
    assert 'urlencode' in fm.filters()

    exit_args = dict(changed=False, rc=0)
    module.exit_json(**exit_args)


# Generated at 2022-06-25 09:24:15.079827
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'

# Generated at 2022-06-25 09:24:16.762658
# Unit test for function do_urlencode
def test_do_urlencode():
    s = 'verbatim'
    assert do_urlencode(s) == 'verbatim'



# Generated at 2022-06-25 09:24:18.945920
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_1 = True
    var_1 = FilterModule.filters(bool_1)


# Generated at 2022-06-25 09:24:25.279101
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    filterModule_0 = FilterModule()
    filters_0 = filterModule_0.filters()
    var_0 = filters_0["urldecode"]
    var_0 = do_urldecode(bool_0)


# Generated at 2022-06-25 09:24:28.985854
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'true'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:24:38.397072
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("?&") == u'?&amp;'
    assert unicode_urlencode("?&", for_qs=True) == u'?%26'
    assert unicode_urlencode("example.com/test/") == u"example.com/test/"
    assert unicode_urlencode("example.com/test/", for_qs=True) == u"example.com/test/"

    assert unicode_urlencode("?&") == u'?&amp;'
    assert unicode_urlencode("?&", for_qs=True) == u'?%26'
    assert unicode_urlencode("example.com/test/") == u"example.com/test/"

# Generated at 2022-06-25 09:24:41.606193
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    text = b'Hello+world'
    result = unicode_urlencode(text)
    assert result == u'Hello%2Bworld'



# Generated at 2022-06-25 09:24:47.716210
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22name%22%3A%22foo%22%7D') == '{"name":"foo"}'


# Generated at 2022-06-25 09:24:49.248530
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bool_0 = True
    var_0 = unicode_urlencode(bool_0)



# Generated at 2022-06-25 09:25:01.345951
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Compare urldecode vs. unicode_urldecode results
    try:
        assert do_urldecode('%') == '%'
    except:
        pass
    try:
        assert unicode_urldecode('%') == '%'
    except:
        pass
    try:
        assert do_urldecode('%%') == '%%'
    except:
        pass
    try:
        assert unicode_urldecode('%%') == '%%'
    except:
        pass
    try:
        assert do_urldecode('%20') == ' '
    except:
        pass
    try:
        assert unicode_urldecode('%20') == ' '
    except:
        pass

# Generated at 2022-06-25 09:25:06.209044
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()

if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-25 09:25:08.324085
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_0 = FilterModule()
    var_0 = module_0.filters()


# Generated at 2022-06-25 09:25:17.643952
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Setup
    import os
    import tempfile
    (fd, name) = tempfile.mkstemp()
    os.close(fd)

    string = 'https://github.com/ansible/ansible'
    string_for_qs = string + '?test=test'

    # Exercise
    actual_str = unicode_urlencode(string)
    actual_str_for_qs = unicode_urlencode(string_for_qs, for_qs=True)

    # Verify
    expected_str = 'https%3A%2F%2Fgithub.com%2Fansible%2Fansible'
    assert actual_str == expected_str

    # Verify

# Generated at 2022-06-25 09:25:20.624483
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'test'
    for_qs = True
    bool_0 = True
    var_0 = unicode_urlencode(string, for_qs)


# Generated at 2022-06-25 09:25:22.769721
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert (filters.filters()) == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:25:31.291329
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b''.join([b'%2520'])) == '%20'
    assert unicode_urldecode(b''.join([b'%2520'])) == '%20'
    assert unicode_urldecode(b''.join([b'%2520'])) == '%20'
    assert unicode_urldecode(b''.join([b'%2520'])) == '%20'
    assert unicode_urldecode(b''.join([b'%2520'])) == '%20'
    assert unicode_urldecode(b''.join([b'%20'])) == ' '
    assert unicode_urldecode(b''.join([b'%20'])) == ' '

# Generated at 2022-06-25 09:25:34.906031
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with simple string
    assert unicode_urldecode("abc123") == "abc123"

    # Test with another string
    assert unicode_urldecode("-._~") == "-._~"



# Generated at 2022-06-25 09:25:42.135469
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test cases
    assert do_urldecode('uri') == 'uri'
    assert do_urldecode('uri+uri') == 'uri uri'


# Generated at 2022-06-25 09:25:44.321147
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert len(filters.filters()) > 0


# Generated at 2022-06-25 09:25:45.735615
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('true') == "True"


# Generated at 2022-06-25 09:25:47.195414
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    result = unicode_urlencode('')

    assert result == ''


# Generated at 2022-06-25 09:25:48.727677
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)
    assert var_0 is None


# Generated at 2022-06-25 09:25:50.684912
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    # Test with param filterModule.filters returns bool
    # bool_0 returns bool
    var_0 = filterModule.filters()
    assert var_0 == bool



# Generated at 2022-06-25 09:25:57.507810
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello') == 'hello'
    assert unicode_urldecode('hello%2C+world') == 'hello, world'
    assert unicode_urldecode('hello%2C%20world') == 'hello, world'
    assert unicode_urldecode('hello%2c+world') == 'hello, world'
    assert unicode_urldecode('hello%2c%20world') == 'hello, world'
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('123%20') == '123 '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode

# Generated at 2022-06-25 09:26:00.022204
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'test+test'
    expected = 'test test'
    result = unicode_urldecode(string)
    assert result == expected


# Generated at 2022-06-25 09:26:01.548111
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_1 = FilterModule.filters()



# Generated at 2022-06-25 09:26:05.884063
# Unit test for function do_urlencode
def test_do_urlencode():
    assert '%20' == do_urlencode(' ')
    assert '%0D%0A%0D%0A' == do_urlencode(b'\r\n\r\n')
    assert '%252F' == do_urlencode('%2F')
    assert 'a%3D1%26b%3D2' == do_urlencode('a=1&b=2')
    assert 'a%3D1%26b%3D2' == do_urlencode(['a=1', 'b=2'])
    assert 'a%253D1%2526b%253D2' == do_urlencode(('a%3D1%26b%3D2',))
    assert 'a%3D1%26b%3D2' == do_urlencode

# Generated at 2022-06-25 09:26:09.131151
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'value_0'
    bool_0 = True
    var_0 = unicode_urlencode(string, bool_0)


# Generated at 2022-06-25 09:26:09.990442
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(True) == True


# Generated at 2022-06-25 09:26:21.202338
# Unit test for function do_urlencode
def test_do_urlencode():
    dict_0 = dict({(('key_0', 0), ('key_1', 1)): dict({('key_2', 2): 3})})
    dict_1 = dict((('key_0', 0), ('key_1', 1)))
    set_0 = set((0, 1, 2, 3))
    list_0 = [0, 1, '2', 3, dict_0]
    list_1 = [(0, 0), (1, 1)]
    str_0 = ''
    str_1 = '0'
    str_2 = '1'
    int_0 = 0
    int_1 = 1
    float_0 = 0.0
    float_1 = 1.0
    # str_3 = 'Ü'
    # str_4 = 'ÿ'
    # str_5 = 'Œ'

# Generated at 2022-06-25 09:26:24.385854
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    s = "abcd efg hijk"
    var_0 = do_urldecode(bool_0)
    var_1 = do_urlencode(s)


# Generated at 2022-06-25 09:26:27.405396
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_instance = FilterModule()
    test_filters = test_instance.filters()

# Generated at 2022-06-25 09:26:32.703150
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc0') == 'abc0'
    assert unicode_urldecode('abc1') == 'abc1'
    assert unicode_urldecode('abc2') == 'abc2'
    assert unicode_urldecode('abc3') == 'abc3'
    assert unicode_urldecode('abc4') == 'abc4'
    assert unicode_urldecode('abc5') == 'abc5'
    assert unicode_urldecode('abc6') == 'abc6'
    assert unicode_urldecode('abc7') == 'abc7'
    assert unicode_urldecode('abc8') == 'abc8'

# Generated at 2022-06-25 09:26:35.344962
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_1 = True
    str_0 = do_urldecode(bool_1)

# main function
if __name__ == "__main__":
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:26:36.264082
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert True


# Generated at 2022-06-25 09:26:39.148498
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'foo'
    # obj_0 = unquote_plus('foo')
    obj_0 = None
    result_0 = unicode_urldecode(str_0, obj_0)
    assert result_0 == str_0



# Generated at 2022-06-25 09:26:41.662394
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    expected_result = unquote_plus(b'https://www.google.com')
    result = unicode_urldecode('https://www.google.com')
    assert result == expected_result


# Generated at 2022-06-25 09:26:45.167992
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_0 = unicode('true')
    var_0 = unicode_urldecode(test_0)


# Generated at 2022-06-25 09:26:48.603097
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_1 = bool()
    var_0 = unicode_urldecode(bool_1)
    str_0 = "a/b/c"
    var_0 = unicode_urldecode(str_0)
    str_1 = "a/b/c"
    var_0 = unicode_urldecode(str_1)


# Generated at 2022-06-25 09:26:51.555837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_0 = FilterModule.filters(bool_0)
    assert var_0 == {'urldecode': do_urldecode}
    if not HAS_URLENCODE:
        assert var_0 == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-25 09:26:54.513834
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-25 09:26:56.280060
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(bool_0) == 'true'
    assert do_urlencode(var_0) == 'True'


# Generated at 2022-06-25 09:27:01.282315
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # AssertionError: u'%E5%A4%9A%E8%AF%AD%E8%A8%80\u4e00' != u'\u4e00\u4e8c\u4e09'
    assert unicode_urldecode(u'\u4e00\u4e8c\u4e09') == u'\u4e00\u4e8c\u4e09'


# Generated at 2022-06-25 09:27:04.047150
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with empty string
    var_0 = b''
    var_0 = unicode_urldecode(var_0)

    # Test with value True
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)


# Generated at 2022-06-25 09:27:06.174398
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode() == None


# Generated at 2022-06-25 09:27:10.832471
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule()
    assert filters.filters() == {
        'urldecode': do_urldecode,
    }


# Generated at 2022-06-25 09:27:19.465370
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    str_0 = 'th=abv'
    var_0 = unicode_urldecode(str_0)
    assert(var_0 == 'th=abv')

    str_0 = 'th=abv'
    var_0 = unicode_urldecode(str_0)
    assert(var_0 == 'th=abv')

    str_0 = 'th=abv'
    var_0 = unicode_urldecode(str_0)
    assert(var_0 == 'th=abv')



# Generated at 2022-06-25 09:27:31.844934
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def do_unicode_urlencode_test(arg, expected_result, expected_result_for_qs):
        # stored = arg
        # if hashlib:
        #     if isinstance(arg, string_types):
        #         stored = arg.encode('utf-8')
        #     else:
        #         stored = repr(arg).encode('utf-8')
        #     stored = hashlib.sha1(stored).hexdigest()
        result = unicode_urlencode(arg)
        result_for_qs = unicode_urlencode(arg, for_qs=True)
        assert result == expected_result
        assert result_for_qs == expected_result_for_qs
        return

    do_unicode_urlencode_test('', '', '')
    do_unicode_

# Generated at 2022-06-25 09:27:33.668977
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string_0 = 'This is a string'
    var_0 = unicode_urldecode(string_0)


# Generated at 2022-06-25 09:27:35.693711
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert '%091' == unicode_urldecode('+1')
# EOF

# Generated at 2022-06-25 09:27:37.304833
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("foo&bar") == unicode_urlencode("foo&bar")


# Generated at 2022-06-25 09:27:39.067490
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # First unit test
    obj_0 = FilterModule()
    # Second unit test
    obj_0.filters()

# Generated at 2022-06-25 09:27:47.335792
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Test with string_type
    string_4936 = '@dagwieers'
    assert(unicode_urldecode(string_4936) == '@dagwieers')

    # Test with bytes
    string_4936 = b'@dagwieers'
    assert(unicode_urldecode(string_4936) == '@dagwieers')

    # Test with string
    string_4936 = '@dagwieers'
    assert(unicode_urldecode(string_4936) == '@dagwieers')



# Generated at 2022-06-25 09:27:56.684637
# Unit test for function do_urlencode
def test_do_urlencode():
    '''
    Testing function do_urlencode
    '''
    assert do_urlencode(False) == u'False'
    assert do_urlencode(True) == u'True'
    assert do_urlencode(None) == u''
    assert do_urlencode([u'a', u'b', u'c', u'd']) == u'a&b&c&d'
    assert do_urlencode([u'a', u'b', u'c', u'd']) == u'a&b&c&d'
    assert do_urlencode({u'a': u'b'}) == u'a=b'
    assert do_urlencode({u'a': u'b', u'c': u'd'}) == u'a=b&c=d'
    assert do

# Generated at 2022-06-25 09:27:57.484954
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert True


# Generated at 2022-06-25 09:28:03.297672
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(str(True)) == 'True'
    assert unicode_urldecode(str(False)) == 'False'
    assert unicode_urldecode(list(range(10))) == '0,1,2,3,4,5,6,7,8,9'
    assert unicode_urldecode(dict(a=100, b=200)) == '100,200'


# Generated at 2022-06-25 09:28:06.757357
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = b'foo bar'
    for_qs = False
    expected_result = b'foo%20bar'
    actual_result = unicode_urlencode(string, for_qs)
    assert actual_result == expected_result


# Generated at 2022-06-25 09:28:15.222941
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    # Test if the method 'filters' of class 'FilterModule'
    # is_equal to the expected value
    var_0 = do_urldecode(bool_0)
    assert var_0 == 'True'

if __name__ == "__main__":
    test_FilterModule_filters()

# Generated at 2022-06-25 09:28:19.034871
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_1 = False
    bool_0 = True
    # Test if this method is able to return the value from a dict
    FilterModule_instance = FilterModule()
    bool_2 = bool_1
    if (bool_0 == bool_2):
        var_0 = FilterModule_instance.filters()


# Generated at 2022-06-25 09:28:28.478297
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Assert to pass if each of the given test case is successful
    assert unicode_urldecode('192.168.1.1') == '192.168.1.1'
    assert unicode_urldecode('192.168.1.1') == '192.168.1.1'
    assert unicode_urldecode('192.168.1.1') == '192.168.1.1'
    assert unicode_urldecode('192.168.1.1') == '192.168.1.1'
    assert unicode_urldecode('192.168.1.1') == '192.168.1.1'
    assert unicode_urldecode('192.168.1.1') == '192.168.1.1'
    assert unicode_urldecode

# Generated at 2022-06-25 09:28:29.598926
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass


# Generated at 2022-06-25 09:28:34.390393
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    assert unicode_urldecode(bool_0) == u'True'



# Generated at 2022-06-25 09:28:35.794161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_0 = FilterModule.filters()


# Generated at 2022-06-25 09:28:40.524456
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'abc'
    assert unicode_urlencode(string) == 'abc'


# Generated at 2022-06-25 09:28:43.951938
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Unit test for unicode_urldecode
    str0 = 'hello'
    if (unicode_urldecode(str0) != 'hello'):
        raise Exception(
            "Testcase {} has failed !".format(str(pytest.param(0))))


# Generated at 2022-06-25 09:28:49.461795
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test_string') == 'test_string'
    assert unicode_urlencode('test_string', for_qs=True) == 'test_string'
    assert unicode_urlencode(u'test_string', for_qs=True) == 'test_string'



# Generated at 2022-06-25 09:28:51.481794
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'xyz' == unicode_urldecode('xyz')



# Generated at 2022-06-25 09:28:57.875701
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_str = "a%20b%20c"
    assert unicode_urldecode(test_str) == "a b c"
    assert do_urldecode(test_str) == "a b c"


# Generated at 2022-06-25 09:28:58.806707
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()


# Generated at 2022-06-25 09:29:00.556810
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode(to_text(u"test"))
    print(result)


# Generated at 2022-06-25 09:29:05.541900
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # unit test for the urldecode method
    assert unicode_urldecode('test') == u'test'



# Generated at 2022-06-25 09:29:06.801806
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(1) == u"1"


# Generated at 2022-06-25 09:29:09.931440
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if isinstance(value, dict) or not isinstance(value, string_types):
        for k, v in itemiter:
            print('foo')
        else:
            print('bar')
        print('foo')


# Generated at 2022-06-25 09:29:18.718110
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test we can accept empty input, and return empty output
    string = ''
    assert unicode_urlencode(string) == ''

    # Test we can accept string input, and return correctly encoded string output
    string = 'hello-world'
    assert unicode_urlencode(string) == 'hello-world'

    # Test we can accept string input with special characters, and return correctly encoded string output
    string = 'hello-world/'
    assert unicode_urlencode(string) == 'hello-world%2F'

    # Test we can accept string input with multiple special characters, and return correctly encoded string output
    string = 'hello-world/~test'
    assert unicode_urlencode(string) == 'hello-world%2F~test'

    # Test we can accept unicode input, and return correctly encoded string output
   

# Generated at 2022-06-25 09:29:20.217574
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    assert callable(FilterModule.filters)

# Generated at 2022-06-25 09:29:22.860408
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('undefined') == 'undefined'


# Generated at 2022-06-25 09:29:26.091756
# Unit test for function do_urlencode
def test_do_urlencode():
    inp_0 = b'+'
    expected_0 = u'+'
    actual_0 = unicode_urlencode(inp_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 09:29:37.223352
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.six.moves.urllib.parse import unquote_plus

  # Test #0 - if type is string, then iteritems is None
  bool_0 = True
  str_0 = unicode_urlencode(bool_0)
  assert str_0 == to_bytes(unquote_plus(b'true'))

  # Test #1 - if type is string, then iteritems is None
  str_1 = '^'
  str_2 = unicode_urlencode(str_1)
  assert str_2 == to_bytes(unquote_plus(b'%5E'))

  # Test #2 - if type is string, then iteritems is None
  str_3 = '^'

# Generated at 2022-06-25 09:29:40.597463
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    rv = unicode_urldecode(2)
    assert isinstance(rv, str)
    rv = unicode_urldecode(b"\xFF")
    assert isinstance(rv, str)


# Generated at 2022-06-25 09:29:42.770636
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    try:
        do_FilterModule_filters()
    except Exception as err:
        print(err)
        print('Failed\n')
    else:
        print('Passed\n')


# Generated at 2022-06-25 09:29:46.330075
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters == {'urldecode': do_urldecode}
