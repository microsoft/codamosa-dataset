

# Generated at 2022-06-25 09:19:53.703455
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert filter_module_0.filters() == filters_expected_0 


# Generated at 2022-06-25 09:19:56.144922
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'dag@wieers.com' == unicode_urldecode('dag%40wieers.com')


# Generated at 2022-06-25 09:19:58.164778
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    filter_module_0 = FilterModule()
    assert filter_module_0.unicode_urldecode("Mohammad") == "Mohammad"


# Generated at 2022-06-25 09:20:02.909318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:20:05.846311
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}, 'Expected object of type dict but got %s' % type(filter_module_0.filters())

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:20:14.649759
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('python') == 'python'
    assert unicode_urlencode('python', for_qs=True) == 'python'
    assert unicode_urlencode(u'python') == u'python'
    assert unicode_urlencode(u'python', for_qs=True) == u'python'
    assert unicode_urlencode(b'python') == u'python'
    assert unicode_urlencode(b'python', for_qs=True) == u'python'
    assert unicode_urlencode('python/') == 'python%2F'
    assert unicode_urlencode('python/', for_qs=True) == 'python%2F'
    assert unicode_urlencode(u'python/') == u'python%2F'
    assert unicode

# Generated at 2022-06-25 09:20:23.008283
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Empty string
    assert unicode_urlencode('') == '', "unicode_urlencode('') is not ''"

    # Simple string
    assert unicode_urlencode('this is a string') == 'this+is+a+string', \
        "unicode_urlencode('this is a string') is not 'this+is+a+string'"

    # Unicode string
    assert unicode_urlencode(u'\u00C9douard') == '%C3%89douard', \
        "unicode_urlencode(u'\u00C9douard') is not '%C3%89douard'"

    # Safe characters

# Generated at 2022-06-25 09:20:26.704665
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3C%3E%3D%3A%3B%2C%2F%5C%3F%23%5B%5D') == '<>=:;,/\\?#[]'


# Generated at 2022-06-25 09:20:34.248184
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("") == ""
    assert unicode_urlencode("  ") == "++"
    assert unicode_urlencode("%") == "%25"

    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("++") == "  "
    assert unicode_urldecode(" ") == " "
    assert unicode_urldecode("%20") == " "
    assert unicode_urldecode(" ") == " "
    assert unicode_urldecode("%2B") == "+"


# Generated at 2022-06-25 09:20:36.694966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert (unicode_urldecode("http://www.example.com/%7Eusername/") == "http://www.example.com/~username/")
    assert (unicode_urldecode("colon%3Asemicolon%3Bone%2520space%3Btwo%2520spaces%3B") == "colon:semicolon;one%20space;two%20spaces;")
    assert (unicode_urldecode("a%2Bb%2Bc") == "a+b+c")



# Generated at 2022-06-25 09:20:40.606256
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fi = FilterModule()
    fs = fi.filters()
    assert 'urldecode' in fs
    assert 'urlencode' in fs

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:20:45.174479
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('hash#') == 'hash%23'
    assert unicode_urlencode('hash#', for_qs=True) == 'hash%23'
    assert unicode_urlencode('hash#', for_qs=False) == 'hash%23'


# Generated at 2022-06-25 09:20:50.058904
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("asdf") == "asdf"
    assert unicode_urldecode("asdf%20") == "asdf "
    assert unicode_urldecode("%20asdf") == " asdf"
    assert unicode_urldecode("asdf%20asdf") == "asdf asdf"
    assert unicode_urldecode("asdf%20asdf%20") == "asdf asdf "
    assert unicode_urldecode("%20asdf%20asdf") == " asdf asdf"
    assert unicode_urldecode("%20asdf%20asdf%20") == " asdf asdf "

# Generated at 2022-06-25 09:20:57.040045
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    from jinja2.filters import do_upper
    from jinja2.filters import do_string
    from jinja2.filters import do_bool
    from jinja2.filters import do_default
    from jinja2.filters import do_escape
    from jinja2.filters import do_sort
    from jinja2.filters import do_unique
    from jinja2.filters import do_replace
    from jinja2.filters import do_regex_replace
    from jinja2.filters import do_regex_search
    from jinja2.filters import do_length
    from jinja2.filters import do_random

# Generated at 2022-06-25 09:21:03.967082
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('Simple string') == 'Simple%20string'
    # assert unicode_urlencode('/') == 'Simple%20string'
    # assert unicode_urlencode('/') == 'Simple%20string'



# Generated at 2022-06-25 09:21:06.069071
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    result = filter_module_1.filters()
    assert isinstance(result, dict) == 1


# Generated at 2022-06-25 09:21:11.501809
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("abc/de") == 'abc%2Fde'
    assert unicode_urlencode("abc/de", for_qs=True) == 'abc%2Fde'

test_case_0()
test_unicode_urlencode()

# Generated at 2022-06-25 09:21:14.398405
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()


# Generated at 2022-06-25 09:21:15.511793
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert isinstance(filter_module.filters(), dict)


# Generated at 2022-06-25 09:21:18.023174
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _ = FilterModule()
    _.filters()

# Generated at 2022-06-25 09:21:23.975971
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode(u'M9|Jl+T4=QtB5Jf|#') == 'M9|Jl T4=QtB5Jf|#')



# Generated at 2022-06-25 09:21:26.610680
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'M9%7CJl%2BT4%3DQtB5Jf%7C%23' == unicode_urlencode('M9|Jl+T4=QtB5Jf|#')


# Generated at 2022-06-25 09:21:33.086190
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        str_0 = 'M9|Jl+T4=QtB5Jf|#'
        var_0 = unicode_urldecode(str_0)
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:21:34.010541
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj_0 = FilterModule()
    var_0 = obj_0.filters()


# Generated at 2022-06-25 09:21:35.091091
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_urldecode('M9|Jl+T4=QtB5Jf|#')

# Generated at 2022-06-25 09:21:35.916955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    unicode_urldecode(str_0)

# Generated at 2022-06-25 09:21:47.972599
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'M9|Jl+T4=QtB5Jf|#' == unicode_urldecode('M9%7CJl%2BT4%3DQtB5Jf%7C%23')
    assert 'M9|Jl+T4=QtB5Jf|#' == unicode_urldecode('M9%7cJl%2bT4%3dQtB5Jf%7c%23')
    assert 'M9|Jl+T4=QtB5Jf|#' == unicode_urldecode('M9+%7CJl+%2BT4+%3DQtB5Jf+%7C+%23')

# Generated at 2022-06-25 09:21:53.334324
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '9|Il$T4=QtB5If|#'

# Generated at 2022-06-25 09:21:55.300820
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()


# Generated at 2022-06-25 09:21:56.390214
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_0 = FilterModule()
    assert class_0.filters() is not None



# Generated at 2022-06-25 09:22:06.963404
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:22:09.955818
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj_FilterModule = FilterModule()

    obj_FilterModule.filters()


# Generated at 2022-06-25 09:22:18.623638
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_1 = 'M9|Jl+T4=QtB5Jf|#'
    str_2 = 'M9%7CJl%2BT4%3DQtB5Jf%7C%23'
    var_1 = unicode_urlencode(str_1)
    print('var_1: ', var_1)
    if var_1 == str_2:
        print('PASSED')
    else:
        print('FAILED')

# Generated at 2022-06-25 09:22:26.331439
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar', True) == 'foo+bar'
    assert unicode_urlencode('http://www.example.com/foo') == 'http%3A%2F%2Fwww.example.com%2Ffoo'
    assert unicode_urlencode({'foo': 'bar', 'abc': '123'}) == 'abc=123&foo=bar'
    assert unicode_urlencode(['foo', 'bar', 'baz']) == 'foo&bar&baz'
    assert unicode_urlencode('foo bar', False) == 'foo%20bar'
    assert unicode_urlencode('foo bar', True) == 'foo+bar'

# Generated at 2022-06-25 09:22:27.805756
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters


# Generated at 2022-06-25 09:22:32.613842
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    method_test_obj = FilterModule()
    # Execute function
    method_test_obj.filters()

# Generated at 2022-06-25 09:22:37.303574
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''

    for _ in range(1000):
        assert unicode_urlencode(str_0) == str_1
        assert unicode_urlencode(str_2, for_qs=True) == str_3


# Generated at 2022-06-25 09:22:40.252338
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("M9|Jl+T4=QtB5Jf|#") == "M9%7CJl%2BT4%3DQtB5Jf%7C%23"


# Generated at 2022-06-25 09:22:45.219733
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_2 = unicode_urlencode(str_0)
    assert var_2 == 'M9%7CJl%2BT4%3DQtB5Jf%7C%23'


# Generated at 2022-06-25 09:22:48.937977
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No exception is thrown when filters is called
    f = FilterModule()
    f.filters()


# Generated at 2022-06-25 09:22:54.517500
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    str_1 = 'M9|Jl+T4=QtB5Jf|#'
    var_1 = unicode_urldecode(str_1)


# Generated at 2022-06-25 09:22:57.342205
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import text

    @given(strategy=text())
    def test_unicode_urldecode(strategy):
        assert(True)


# Generated at 2022-06-25 09:23:01.132154
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        Test_unicode_urldecode = Test_Case_0()
    except:
        print('Caught exception: ', sys.exc_info()[0])



# Generated at 2022-06-25 09:23:03.425795
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_FilterModule = FilterModule()

# Generated at 2022-06-25 09:23:13.062294
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'M9|Jl T4=QtB5Jf|#'
    str_1 = '%8F%B1%8B%20%0D%0A'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == '? ?\r\n'
    str_2 = '%0D%0A%8F%B1%8B%20'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == '\r\n? ?'
    str_3 = '%8F%B1'
   

# Generated at 2022-06-25 09:23:18.742017
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'a+a%21' == do_urlencode('a a!')
    assert 'a+a%21' == do_urlencode('a a!')
    assert 'a%20a' == do_urlencode('a a')
    assert 'a%3Da' == do_urlencode('a=a')


# Generated at 2022-06-25 09:23:23.574504
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('M9|Jl+T4=QtB5Jf|#') == '/'


# Generated at 2022-06-25 09:23:25.067678
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urlencode']



# Generated at 2022-06-25 09:23:27.164982
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = 'M9|Jl+T4=QtB5Jf|#'
    str_0 = unicode_urldecode(var_0)
    return str_0



# Generated at 2022-06-25 09:23:31.549535
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'Jl+T4=QtB5Jf|#'
    expected_0 = unquote_plus(str_0)
    if PY3:
        var_0 = unicode_urldecode(str_0)
        assert var_0 == expected_0
    else:
        expected_0 = to_text(unquote_plus(to_bytes(expected_0)))
        var_0 = unicode_urldecode(str_0)
        assert var_0 == expected_0


# Generated at 2022-06-25 09:23:38.911082
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # TypeError
    try:
        unicode_urldecode(None)
    except TypeError:
        pass
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:23:43.071636
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:23:49.977568
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        assert 'M9|Jl+T4=QtB5Jf|#' == unicode_urldecode('M9%7CJl%2BT4%3DQtB5Jf%7C%23')
    except AssertionError as e:
        raise(e)

    assert 'M9|Jl+T4=QtB5Jf|#' == unicode_urldecode('M9|Jl+T4=QtB5Jf|#')



# Generated at 2022-06-25 09:23:54.168700
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result = unicode_urlencode(b'M9|Jl+T4=QtB5Jf|#')
    assert result == 'M9%7CJl+T4=QtB5Jf%7C%23'



# Generated at 2022-06-25 09:23:56.111092
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()



# Generated at 2022-06-25 09:24:03.931560
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Test with string
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)

    assert var_0 == u'M9|Jl T4=QtB5Jf|#'


# Generated at 2022-06-25 09:24:13.236346
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test case to check the encoding of a string value
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urlencode(str_0)
    print(var_0)
    # Test case to check the encoding of a list value
    list_0 = ['M9|Jl+T4=QtB5Jf|#','#']
    var_1 = unicode_urlencode(list_0)
    print(var_1)


# Generated at 2022-06-25 09:24:15.121546
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Instantiation of object FilterModule
    fm = FilterModule()

    # Method filters

# Generated at 2022-06-25 09:24:18.725518
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_1 = unicode_urlencode(str_0)
    str_1 = 'M9%7CJl%2BT4%3DQtB5Jf%7C%23'
    assert var_1 == str_1

# Generated at 2022-06-25 09:24:21.591741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    src_0 = FilterModule()
    dst_0 = src_0.filters()
    assert dst_0['urlencode'] == do_urlencode
    assert dst_0['urldecode'] == do_urldecode

# Generated at 2022-06-25 09:24:31.809669
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'
    assert unicode_urlencode('foo=bar') == 'foo%3Dbar'
    assert unicode_urlencode('foo=bar', for_qs=True) == 'foo%3Dbar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo+bar', for_qs=True) == 'foo%2Bbar'
    assert unicode_urlencode('foo!bar')

# Generated at 2022-06-25 09:24:34.909264
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('M9|Jl+T4=QtB5Jf|#') == 'M9%7CJl%2BT4%3DQtB5Jf%7C%23'


# Generated at 2022-06-25 09:24:37.370368
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

  # This will be the value to test against
  result = unicode_urldecode('M9|Jl+T4=QtB5Jf|#')

  # This asserts that result is equal to the expected value
  assert result == expected


# Generated at 2022-06-25 09:24:43.471975
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    tst_str_0 = 'M9|Jl+T4=QtB5Jf|#'

    assert(unicode_urldecode(tst_str_0) == 'M9|Jl T4=QtB5Jf|#')


# Generated at 2022-06-25 09:24:48.735545
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        assert unicode_urldecode('M9|Jl+T4=QtB5Jf|#') == u'$a & b!'
    except AssertionError:
        raise AssertionError('Should be $a & b!')


# Generated at 2022-06-25 09:24:51.226615
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_0 = FilterModule()
    filters_0 = class_0.filters()
    assert filters_0['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:24:59.339914
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    # AssertionError: u'M9|Jl\u20244=QtB5Jf|#' != u'M9|Jl #4=QtB5Jf|#'
    var_1 = u'M9|Jl #4=QtB5Jf|#'
    assert var_0 == var_1


# Generated at 2022-06-25 09:25:06.710640
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert '|' in var_0
    # assert "|" in var_0
    # assert var_0 == 'M9|Jl T4=QtB5Jf|#'
    # assert var_0 == 'M9|Jl T4=QtB5Jf|#'
    # assert var_0 == 'M9|Jl T4=QtB5Jf|#'
    # assert var_0 == 'M9|Jl T4=QtB5Jf|#'


# Generated at 2022-06-25 09:25:12.586972
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print(unicode_urlencode('M9|Jl+T4=QtB5Jf|#'))
    print(unicode_urlencode('M9|Jl+T4=QtB5Jf|#', False))


# Generated at 2022-06-25 09:25:14.838753
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule().filters()


# Generated at 2022-06-25 09:25:26.344705
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("a b"), "a+b"
    assert unicode_urlencode("ab") == "ab"
    assert unicode_urlencode("a+b") == "a%2Bb"
    assert unicode_urlencode("a b", for_qs=True) == "a+b"
    assert unicode_urlencode("a+b", for_qs=True) == "a%2Bb"
    assert unicode_urlencode("ab/cd") == "ab%2Fcd"
    assert unicode_urlencode("a/b/c") == "a%2Fb%2Fc"

# Generated at 2022-06-25 09:25:27.451586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  # Missing method definition
  assert False, "Test not implemented"


# Generated at 2022-06-25 09:25:32.938154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    try:
        # Init of class FilterModule
        obj_0 = FilterModule()

        # Unit test of method filters
        var_0 = obj_0.filters()

        assert var_0 == {
            'urldecode': do_urldecode,
        }
    except Exception as e:
        print(e)
        assert False

# Unit test of method unicode_urldecode

# Generated at 2022-06-25 09:25:36.908876
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'M9|Jl+T4=QtB5Jf|#'
    assert unicode_urldecode(string) == 'M9|Jl T4=QtB5Jf|#'


# Generated at 2022-06-25 09:25:47.498382
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Source:
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/utils/unicode.py
    assert unicode_urlencode(u'http://foo?bar=baz') == 'http%3A%2F%2Ffoo%3Fbar%3Dbaz'
    assert unicode_urlencode(u'http://foo?bar=baz', for_qs=True) == 'http%3A%2F%2Ffoo%3Fbar%3Dbaz'
    assert unicode_urlencode(u'http://foo?a=b&c=d') == 'http%3A%2F%2Ffoo%3Fa%3Db%26c%3Dd'

# Generated at 2022-06-25 09:25:54.359731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    try:
        str_0 = 'M9|Jl+T4=QtB5Jf|#'
        var_0 = unicode_urldecode(str_0)
        filters = FilterModule()
        filters.filters()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:26:02.984597
# Unit test for function do_urlencode
def test_do_urlencode():
    res_0 = do_urlencode('{key: "value"}')
    assert(res_0 == '%7Bkey%3A+%22value%22%7D')
    res_1 = do_urlencode('{key: "value"}')
    assert(res_1 == '%7Bkey%3A+%22value%22%7D')
    res_2 = do_urlencode('{key: "value"}')
    assert(res_2 == '%7Bkey%3A+%22value%22%7D')
    res_3 = do_urlencode('{key: "value"}')
    assert(res_3 == '%7Bkey%3A+%22value%22%7D')

# Generated at 2022-06-25 09:26:06.024437
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'M9|Jl T4=QtB5Jf|#'


# Generated at 2022-06-25 09:26:10.471703
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # string str_0
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    # str var_0
    var_0 = unicode_urldecode(str_0)
    # bool var_1
    var_1 = isinstance(var_0, str)
    # string str_1
    str_1 = u'M9|Jl T4=QtB5Jf|#'
    assert var_0 == str_1
    assert var_1 == True


# Generated at 2022-06-25 09:26:17.685345
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filter_dict = f.filters()
    assert filter_dict is not None, 'Method filters of class FilterModule returned None'
    assert filter_dict['urldecode'] is not None, 'Method filters of class FilterModule returned None'
    if not HAS_URLENCODE:
        assert filter_dict['urlencode'] is not None, 'Method filters of class FilterModule returned None'


# Generated at 2022-06-25 09:26:21.770327
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True


# Generated at 2022-06-25 09:26:24.268585
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)




# Generated at 2022-06-25 09:26:29.165680
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unquote_plus("M9|Jl+T4=QtB5Jf|#") == 'M9|Jl+T4=QtB5Jf|#'
    else:
        assert to_text(unquote_plus("M9|Jl+T4=QtB5Jf|#")) == 'M9|Jl+T4=QtB5Jf|#'
    print('Test success !')


# Generated at 2022-06-25 09:26:29.691812
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()



# Generated at 2022-06-25 09:26:39.303326
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # AssertionError: <function do_urldecode at 0x7f6b04870f28> != <function do_urlencode at 0x7f6b04870f28>
    filters = FilterModule().filters()
    assert(isinstance(filters, dict))
    assert(filters == {'urldecode': do_urldecode, 'urlencode': do_urlencode})
    assert(filters['urldecode'] == do_urldecode)
    assert(filters['urlencode'] == do_urlencode)
    del filters
    return


# Generated at 2022-06-25 09:26:41.818912
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    __filters = FilterModule().filters()
    assert 'urldecode' in __filters
    assert __filters['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:26:42.644647
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()


# Generated at 2022-06-25 09:26:49.678610
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Default unit test configuration
    filter_config = {
    }

    # Setup the unit test environment
    f = FilterModule()
    filters = f.filters()
    for name, filter_method in iteritems(filters):
        if name in filter_config:
            filter_method = filter_method(filter_config[name])

        # Test single argument methods
        if name in ['urldecode']:
            urldecode_test_cases = [
                {
                    'str_0': 'M9|Jl+T4=QtB5Jf|#',
                    'var_0': 'M9|Jl T4=QtB5Jf|#',
                },
            ]

# Generated at 2022-06-25 09:26:51.555989
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    # TODO: testing for individual filters should happen here
    assert 'urldecode' in filters


# Generated at 2022-06-25 09:27:01.514761
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('M9|Jl+T4=QtB5Jf|#') == u'Ⓐⓡⓡⓔⓓ'
    assert unicode_urldecode('|M9|Jl+T4=QtB5Jf|#') == u'|Ⓐⓡⓡⓔⓓ'
    assert unicode_urldecode('M9|Jl+T4=QtB5Jf|#|') == u'Ⓐⓡⓡⓔⓓ|'
    assert unicode_urldecode('||M9|Jl+T4=QtB5Jf|#|') == u'||Ⓐⓡⓡⓔⓓ|'

# Generated at 2022-06-25 09:27:10.669757
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('Unit test for filters of class FilterModule')
    f = FilterModule()
    print(f.filters())

if __name__ == "__main__":
    # example for method do_urldecode of class FilterModule (unit test needed)
    test_FilterModule_filters()
    test_case_0()

# Generated at 2022-06-25 09:27:21.178631
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('M9|Jl+T4=QtB5Jf|#') == '0|0|0|1|1|0|0|1|1|0|'
    assert unicode_urldecode('bW9ja2VyLmNvbQ==') == 'mock.com'
    assert unicode_urldecode('dWlkPTEyMw==') == 'uid=123'
    assert unicode_urldecode('dXNlcm5hbWU9T0xERVJQQVlPTkc=') == 'username=ODDERPAYING'

# Generated at 2022-06-25 09:27:27.908017
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('Test1') == 'Test1'
    assert unicode_urlencode(u'Test1') == 'Test1'
    assert unicode_urlencode(u'Test1') == 'Test1'
    assert unicode_urlencode(u'Test2') == 'Test2'
    assert unicode_urlencode('Test3') == 'Test3'
    assert unicode_urlencode('Test4') == 'Test4'
    assert unicode_urlencode('Test5') == 'Test5'


# Generated at 2022-06-25 09:27:38.563805
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('a b,c') == 'a%20b,c'
    assert unicode_urlencode('a+') == 'a%2B'
    assert unicode_urlencode('a+b') == 'a%2Bb'
    assert unicode_urlencode('|a') == '%7Ca'
    assert unicode_urlencode('a|') == 'a%7C'
    assert unicode_urlencode('a|b') == 'a%7Cb'
    assert unicode_urlencode('a') == 'a'
    assert unicode_urlencode('a,b') == 'a,b'

# Generated at 2022-06-25 09:27:40.137268
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    res = f.filters()
    assert res is not None


# Generated at 2022-06-25 09:27:45.762029
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('M9|Jl+T4=QtB5Jf|#') == 'M9|Jl T4=QtB5Jf|#'
    assert unicode_urldecode('M9|%4A%6C%2B%54%34%3D%51%74%42%35%4A%66%7C%23') == 'M9|%4A%6C%2B%54%34%3D%51%74%42%35%4A%66%7C%23'


# Generated at 2022-06-25 09:27:48.124562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_0 = FilterModule.filters(None)


# Generated at 2022-06-25 09:27:50.470992
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters



# Generated at 2022-06-25 09:27:51.640815
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-25 09:27:56.593165
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'\x80\x81\x82\x83') == '%C2%80%C2%81%C2%82%C2%83'


# Generated at 2022-06-25 09:28:10.151915
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    assert unicode_urldecode(str_0) == 'M9|Jl T4=QtB5Jf|#'
    str_1 = 'M9|Jl+T4=QtB5Jf|#'
    assert unicode_urldecode(str_1) == 'M9|Jl T4=QtB5Jf|#'
    str_2 = 'M9|Jl+T4=QtB5Jf|#'
    assert unicode_urldecode(str_2) == 'M9|Jl T4=QtB5Jf|#'



# Generated at 2022-06-25 09:28:14.926603
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Class instantiation
    obj = FilterModule()

    # Call method filters
    # from ansible.module_utils.six.moves.urllib.parse import quote_plus
    # var_0 = quote_plus('test_str')

    return

# Generated at 2022-06-25 09:28:17.658531
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    test_case_0()
    assert str_0 != str_0



# Generated at 2022-06-25 09:28:27.641160
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '万!@#$%^&*()_+=-{}[]\|\'\":;?><,./~`'
    assert unicode_urldecode(str_0) == '万!@#$%^&*()_+=-{}[]\|\'\":;?><,./~`'
    assert unicode_urldecode('abc123') == 'abc123'
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('ä') == 'ä'



# Generated at 2022-06-25 09:28:30.798920
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'M9|Jl+T4=QtB5Jf|#'
    assert unicode_urldecode(string) == 'M9|Jl+T4=QtB5Jf|#'


# Generated at 2022-06-25 09:28:41.736337
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(unicode("WUI9z.tbYsuM")) == unicode("WUI9z.tbYsuM")
    assert unicode_urldecode(unicode("")) == unicode("")
    assert unicode_urldecode(unicode("cK_*pWJe9V7#")) == unicode("cK_*pWJe9V7#")
    assert unicode_urldecode(unicode("*6U|b{aR,6")) == unicode("*6U|b{aR,6")
    assert unicode_urldecode(unicode("s~,W8:=c.B")) == unicode("s~,W8:=c.B")

# Generated at 2022-06-25 09:28:44.634734
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # First test case
    module = FilterModule()
    assert module.filters == {'urldecode': do_urldecode} or {'urldecode': do_urldecode, 'urlencode': do_urlencode}
    


# Generated at 2022-06-25 09:28:47.859439
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_module = FilterModule()
    filters = ansible_module.filters()
    assert filters["urldecode"]

# Generated at 2022-06-25 09:28:57.397122
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    do_urldecode = filters['urldecode']
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = do_urldecode(str_0)
    assert var_0 == 'M9|Jl T4=QtB5Jf|#'
    str_1 = '{"+rIoQ}hG?#'
    var_1 = do_urldecode(str_1)
    assert var_1 == '{" rIoQ}hG?#'
    if HAS_URLENCODE:
        do_urlencode = filters['urlencode']
        str_2 = 'D8tG/h0x*Oa|'
        var_2 = do_url

# Generated at 2022-06-25 09:29:05.739192
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'M9|Jl T4=QtB5Jf|#'
    str_1 = '/2NzI3OTgzOA==/cGx1Z2luLnZpZGVvLmZpcmVmb3g='
    var_1 = unicode_urldecode(str_1)
    assert var_1 == '/2NzI3OTgzOA==/cGx1Z2luLnZpZGVvLmZpcmVmb3g='

# Generated at 2022-06-25 09:29:15.481165
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    str_1 = 'M9|Jl+T4=QtB5Jf|#'
    var_1 = unicode_urldecode(str_1)
    assert var_0 == var_1


# Generated at 2022-06-25 09:29:16.459252
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_filter = FilterModule()
    assert not ansible_filter.filters() == None

# Generated at 2022-06-25 09:29:21.272364
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # str_0 = u'M9|Jl+T4=QtB5Jf|#'
    # var_0 = unicode_urldecode(str_0)
    assert True
# test_case_0()

# Generated at 2022-06-25 09:29:25.032950
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False



# Generated at 2022-06-25 09:29:33.667247
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'M9|Jl+T4=QtB5Jf|#'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '1234567890'

    str_0 = 'EUt+'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == 'a b'

    str_0 = '%C2%A2+'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == u'¢ '

    str_0 = '%E2%82%AC+'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == u'€ '


# Generated at 2022-06-25 09:29:43.094756
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create object of class FilterModule
    filters = FilterModule()
    # Get the filters out of this object
    filters_out = filters.filters()
    assert('urldecode' in filters_out)
    assert(filters_out['urldecode'] == do_urldecode)
    if not HAS_URLENCODE:
        assert('urlencode' in filters_out)
        assert(filters_out['urlencode'] == do_urlencode)


# Generated at 2022-06-25 09:29:53.704810
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert '|' == unicode_urldecode('%7C')
    assert '<' == unicode_urldecode('%3C')
    assert '>' == unicode_urldecode('%3E')
    assert '&' == unicode_urldecode('%26')
    assert '"' == unicode_urldecode('%22')
    assert "'" == unicode_urldecode("%27")
    assert ' ' == unicode_urldecode('%20')
    assert '@' == unicode_urldecode('%40')
    assert ':' == unicode_urldecode('%3A')
    assert '/' == unicode_urldecode('%2F')
    assert '?' == unicode_urldecode('%3F')
   