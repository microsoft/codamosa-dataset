

# Generated at 2022-06-25 09:19:51.099505
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = filter_module_0.filters()
    assert(filters is not None)

# Generated at 2022-06-25 09:19:55.954598
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Testing') == u'Testing'


# Generated at 2022-06-25 09:19:59.724223
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters = filter_module_0.filters()
    assert len(filters) == 2
    assert filters['urldecode'] is do_urldecode
    assert filters['urlencode'] is do_urlencode


if __name__ == "__main__":
    import pytest
    pytest.main(['-q', '-s', __file__])

# Generated at 2022-06-25 09:20:03.253346
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'mañana') == u'ma%C3%B1ana'


# Generated at 2022-06-25 09:20:12.618756
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode("%2F") == "/")
    assert(unicode_urldecode("%22") == '"')
    assert(unicode_urldecode("foo%2Fbar%2Bbaz") == "foo/bar+baz")
    assert(unicode_urldecode("foo%2Fbar+%2Fbaz") == "foo/bar+/baz")
    if PY3:
        assert(unicode_urldecode("%C3%B6") == "ö")


# Generated at 2022-06-25 09:20:15.561734
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("hello") == 'hello'



# Generated at 2022-06-25 09:20:19.238574
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert type(filters) is dict
    assert filters['urldecode'] == do_urldecode
    return

# Generated at 2022-06-25 09:20:27.780542
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters = filter_module_1.filters()
    assert filters['urldecode'] == do_urldecode,\
        "Return value of FilterModule.filters()[\"urldecode\"] differs."

    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode,\
            "Return value of FilterModule.filters()[\"urlencode\"] differs."

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:20:32.410051
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert unicode_urlencode(u"%") == "%25"
    assert unicode_urlencode(u"/") == "/"
    assert unicode_urlencode(u"/", for_qs=True) == "%2F"
    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("%2F") == "/"



# Generated at 2022-06-25 09:20:34.344937
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()


if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:20:44.459256
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(b'x=1&y=2') == u'x=1&y=2'
    else:
        assert unicode_urldecode(u'x=1&y=2') == u'x=1&y=2'
        assert unicode_urldecode(u'x=1&y=2'.encode('utf-8')) == u'x=1&y=2'



# Generated at 2022-06-25 09:20:51.609141
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Value1') == 'Value1'
    assert do_urlencode('Value1&Value2') == 'Value1%26Value2'
    assert do_urlencode('Value1&Value2&Value3') == 'Value1%26Value2%26Value3'
    assert do_urlencode({'Value1': 'Value2'}) == 'Value1=Value2'
    assert do_urlencode({'Value1': 'Value2', 'Value3': 'Value4'}) == 'Value1=Value2&Value3=Value4'
    assert do_urlencode({'Value1&Value2': 'Value3'}) == 'Value1%26Value2=Value3'

# Generated at 2022-06-25 09:20:56.301116
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode("a%20b") == "a b")


# Generated at 2022-06-25 09:21:06.944999
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unit_test_0 = unicode_urldecode("https%3A%2F%2Fwww.example.com%2F%3Ftest1%3D%252Ftest2%26test3%3D%25252Ftest4")
    assert unit_test_0 == "https://www.example.com/?test1=/test2&test3=%2Ftest4"
    unit_test_1 = unicode_urldecode("https%3A%2F%2Fwww.example.com%2F%3Ftest1%3D%252Ftest2%26test3%3D%25252Ftest4%7B%7D")
    assert unit_test_1 == "https://www.example.com/?test1=/test2&test3=%2Ftest4{}"

# Unit test

# Generated at 2022-06-25 09:21:11.301915
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%C3%A1bcd') == u'ábcd'
    assert unicode_urldecode(b'%25') == u'%'


# Generated at 2022-06-25 09:21:20.601513
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/', False) == u'/'
    assert unicode_urlencode('/', True) == u'/'

    assert unicode_urlencode('a&b', False) == u'a%26b'
    assert unicode_urlencode('a&b', True) == u'a%26b'

    assert unicode_urlencode('a b', False) == u'a%20b'
    assert unicode_urlencode('a b', True) == u'a+b'

    assert unicode_urlencode('a/b', False) == u'a%2Fb'
    assert unicode_urlencode('a/b', True) == u'a%2Fb'


# Generated at 2022-06-25 09:21:23.062921
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('1%2F2') == '1/2'
    assert unicode_urldecode('1/2') == '1/2'


# Generated at 2022-06-25 09:21:23.595914
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True

# Generated at 2022-06-25 09:21:28.256432
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%C3%A5%C3%A6%C3%B8'
    assert unicode_urldecode(string) == u'åæø'
    string = '%25C3%25A5%25C3%25A6%25C3%25B8'
    assert unicode_urldecode(string) == u'%C3%A5%C3%A6%C3%B8'


# Generated at 2022-06-25 09:21:31.353429
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo bar') == u'foo bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'



# Generated at 2022-06-25 09:21:34.409038
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # execute method filters of class FilterModule
    filters = FilterModule.filters(FilterModule())
    # validate return type of method filters -> dict
    assert isinstance(filters, dict)
    # compare return value of method filters with known values
    assert filters == {
        'urldecode': do_urldecode,
    }


# Generated at 2022-06-25 09:21:35.133301
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_inst = FilterModule()
    assert isinstance(module_inst.filters(), dict)

# Generated at 2022-06-25 09:21:43.134105
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'\x9aT\xa0\xe9\xe7') == to_unicode('\x9aT\xa0\xe9\xe7')
    assert unicode_urldecode(b'\xa0\x80\x80\x80\x80\x80\x80\xa0') == to_unicode('\xa0\x80\x80\x80\x80\x80\x80\xa0')


# Generated at 2022-06-25 09:21:44.654564
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters is not None


# Generated at 2022-06-25 09:21:48.096725
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert len(filters) == 2
    assert filters['urldecode'] == do_urldecode

# Test case default for method unicode_urlencode of class FilterModule

# Generated at 2022-06-25 09:21:51.418950
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xe0\xa5\x9aT\xa0\xe9\xe7'
    unicode_urldecode(bytes_0)

    var_0 = to_text(bytes_0)
    unicode_urldecode(var_0)


# Generated at 2022-06-25 09:22:03.397322
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urldecode(b'\x9aT\xa0\xe9\xe7') == u'%9aT%a0%e9%e7'
    assert unicode_urldecode('%9aT%a0%e9%e7') == u'%9aT%a0%e9%e7'
    assert unicode_urlencode(u'%9aT%a0%e9%e7') == '%25%39%61%54%25%61%30%25%65%39%25%65%37'
    assert unicode_urlencode('%9aT%a0%e9%e7') == '%25%39%61%54%25%61%30%25%65%39%25%65%37'



# Generated at 2022-06-25 09:22:08.902603
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    input_0 = b'C\xee\xa9\x9b\xad\x82\xa7'
    expected_0 = b'C%CE%A9%9B%AD%82%A7'
    result_0 = unicode_urlencode(input_0, False)
    assert result_0 == expected_0

# Generated at 2022-06-25 09:22:14.459313
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test case # 0
    var_0 = b'\x9aT\xa0\xe9\xe7'
    var_1 = unicode_urldecode(var_0)
    assert var_1 == u'\u009at\u00a0\u00e9\u00e7'


# Generated at 2022-06-25 09:22:15.951877
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 09:22:18.368930
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    filters.filters()


# Generated at 2022-06-25 09:22:26.114220
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    bytes_1 = b'/'
    to_text_0 = to_text(unicode_urldecode(bytes_0))
    quote_0 = quote(to_text_0)
    quote_plus_0 = quote_plus(to_text_0)
    assert unicode_urlencode(bytes_0) == quote_0
    assert unicode_urlencode(bytes_0, for_qs=True) == quote_plus_0
    assert unicode_urlencode(bytes_0, for_qs=False) == quote_0
    quote_1 = quote(to_text(bytes_0), bytes_1)
    quote_plus_1 = quote_plus(to_text(bytes_0), bytes_1)

# Generated at 2022-06-25 09:22:33.041256
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ') == 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%E9%98%BF%E5%A5%87%E8%B5%A4%E5') == 'é阿奇赤'

# Generated at 2022-06-25 09:22:35.768169
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c_0 = FilterModule()
    v_0 = c_0.filters()
    assert v_0 == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:22:41.515907
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test case for function unicode_urlencode where value =
    # 'Agent Smith'
    var_0 = unicode_urlencode('Agent Smith')
    assert var_0 == 'Agent%20Smith'
    # Test case for function unicode_urlencode where value =
    # '\udcc3\udca0\udcbf\udcc0\udca9 \udcc3\udca0\udcbf\udcc0\udca9'
    var_1 = unicode_urlencode('\udcc3\udca0\udcbf\udcc0\udca9 \udcc3\udca0\udcbf\udcc0\udca9')

# Generated at 2022-06-25 09:22:53.129545
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    src_0 = b'1sHU'
    out_0 = unicode_urldecode(src_0)
    assert out_0 == u'1sHU', u'Test 0 failed'
    src_1 = b'saaD'
    out_1 = unicode_urldecode(src_1)
    assert out_1 == u'saaD', u'Test 1 failed'

# Generated at 2022-06-25 09:22:56.015954
# Unit test for function do_urlencode
def test_do_urlencode():
    pass
    # do_urldecode(value) -> Return value


# Generated at 2022-06-25 09:23:00.393664
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert(len(filters) == 2)
    assert(filters == {'urldecode': do_urldecode, 'urlencode': do_urlencode})


# Generated at 2022-06-25 09:23:05.211873
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    # Verify do_urldecode exists
    assert 'urldecode' in filters
    # Verify that the filter is a callable
    assert callable(filters['urldecode'])



# Generated at 2022-06-25 09:23:08.015191
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == '42°%C3°'



# Generated at 2022-06-25 09:23:20.201019
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    assert 'T éç' == unicode_urldecode(bytes_0)
    bytes_1 = b'\xb6\xbe\x9c\xea\xcb\x1f\xac\xc1\x8e\xfb*2\xdf]\x9d'
    assert '¶¾œêË¬ÁŽû*2ß]ŝ' == unicode_urldecode(bytes_1)

# Generated at 2022-06-25 09:23:22.101874
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('\x9aT\xa0\xe9\xe7') == '%9aT%A0%E9%E7'


# Generated at 2022-06-25 09:23:24.701107
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({'contract_number': 'CN4730283', 'id': '75027'}) == 'contract_number=CN4730283&id=75027'


# Generated at 2022-06-25 09:23:28.717677
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    result = filters.filters()


# Generated at 2022-06-25 09:23:34.584496
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert '\x9aT\xa0\xe9\xe7' == unicode_urldecode(b'%9aT%a0%e9%e7'), \
        """`unicode_urldecode' function failed"""
    # assert that `unicode_urldecode' function not supports unicode strings as argument
    with pytest.raises(TypeError):
        unicode_urldecode('\x9aT\xa0\xe9\xe7')


# Generated at 2022-06-25 09:23:35.367447
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()


# Generated at 2022-06-25 09:23:44.776976
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Testing with b'\x9aT\xa0\xe9\xe7'
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    res_0 = unicode_urldecode(bytes_0)
    assert res_0 == u'\u269aT\xa0\xe9\xe7'

    # Testing with '2014-12-25T18:49:32Z'
    bytes_1 = '2014-12-25T18:49:32Z'
    res_1 = unicode_urldecode(bytes_1)
    assert res_1 == u'2014-12-25T18:49:32Z'

    # Testing with '2013-04-12T15:20:00Z'

# Generated at 2022-06-25 09:23:48.539262
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # noinspection PyUnresolvedReferences
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:23:56.167925
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(bytes(b'\x9aT\xa0\xe9\xe7')) == u'\u009aT\u00a0\u00e9\u00e7'
    else:
        assert unicode_urldecode(bytes(b'\x9aT\xa0\xe9\xe7')) == u'\x9aT\xa0\xe9\xe7'


# Generated at 2022-06-25 09:23:58.657754
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('https://') == b'https%3A%2F%2F'


# Generated at 2022-06-25 09:24:02.748836
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Tests with jinja2 < v2.7
    var_1 = FilterModule().filters()
    assert var_1 is not None, "Instance 'var1' of class 'FilterModule' could not be created"


# Generated at 2022-06-25 09:24:04.939826
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    arg_0 = unicode_urldecode(b'6-+')
    arg_1 = False
    expected = b'6%2B-%2B'
    actual = unicode_urlencode(arg_0, arg_1)
    assert actual == expected


# Generated at 2022-06-25 09:24:12.347051
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == '%9aT%A0%E9%E7', 'Expected %9aT%A0%E9%E7, but got {}.'.format(var_0)


# Generated at 2022-06-25 09:24:16.702999
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = unicode_urldecode(b'\x9aT\xa0\xe9\xe7')
    assert len(var_0) == 5
    assert var_0 == '驗碼'
    assert var_0[0] == '驗'

    # Verify that if you pass empty bytes in it returns empty string
    var_1 = unicode_urldecode(b'')
    assert type(var_1) is str
    assert len(var_1) == 0

    # Verify that if you pass empty string in it returns empty string
    var_2 = unicode_urldecode('')
    assert type(var_2) is str
    assert len(var_2) == 0

    # Verify that if you pass non-ascii string in it returns empty string
   

# Generated at 2022-06-25 09:24:18.886079
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_0 = FilterModule()
    filters_0 = module_0.filters()
    return


# Generated at 2022-06-25 09:24:28.442594
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:24:36.131111
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'


# Generated at 2022-06-25 09:24:40.300998
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    recent_filters = filter_module.filters()
    assert recent_filters['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:24:44.078622
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == u'\u00a2T\u00a0\u00e9\u00e7'


# Generated at 2022-06-25 09:24:47.798849
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    assert True # nothing to check


# Generated at 2022-06-25 09:24:54.640533
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('\x9aT\xa0\xe9\xe7') == '\x9aT\xa0\xe9\xe7'

# Generated at 2022-06-25 09:24:59.000573
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    # We implement urlencode when Jinja2 is older than v2.7
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

    assert filters['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:25:01.145725
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test_value') == 'test_value'


# Generated at 2022-06-25 09:25:11.888520
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing function unicode_urldecode")
    assert(unicode_urldecode('%9aT%A0%E9%E7') == '\x9aT\xa0\xe9\xe7')
    assert(unicode_urldecode('%E2%84%A2') == '\xe2\x84\xa2')
    assert(unicode_urldecode('%3Cscript%3E%3C%2Fscript%3E') == '<script></script>')
    assert(unicode_urldecode('%E2%84%A2') == '\xe2\x84\xa2')



# Generated at 2022-06-25 09:25:17.461971
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(bytes_0) == "香港"
    else:
        assert unicode_urldecode(bytes_0) == u"香港"


# Generated at 2022-06-25 09:25:21.305720
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_1 = b'\x9aT\xa0\xe9\xe7'
    assert unicode_urlencode(bytes_1) == b'%9aT%A0%E9%E7'


# Generated at 2022-06-25 09:25:26.310929
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fieldvalues = {}
    fobj = FilterModule()

    filters = fobj.filters()
    urldecode = filters['urldecode']
    var_0 = 'aHR0cDovL3d3dy5yfjFyZW8uY29tLw=='
    var_1 = unicode_urldecode(var_0)
    if not HAS_URLENCODE:
        urlencode = filters['urlencode']

        var_2 = urlencode(var_1)

# Generated at 2022-06-25 09:25:28.081525
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters()
    assert len(filters)
    filters['urldecode']('\x9aT\xa0\xe9\xe7')

# Generated at 2022-06-25 09:25:39.196050
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:25:44.006454
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b"\xe2\x82\xac") == u"\u20ac"
    assert unicode_urldecode(b"\xe2\x82\xac", arg_1=False) == u"\u20ac"


# Generated at 2022-06-25 09:25:47.639164
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    u = u'\u00c9cole'
    result = unicode_urlencode(u, for_qs=False)
    assert result == u'%C3%89cole'


# Generated at 2022-06-25 09:25:50.578373
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    pass


# Generated at 2022-06-25 09:25:53.540902
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    assert u'\u00e7\u00e9\xa0T\u009a' == unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:25:55.820245
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-25 09:26:04.800817
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'\u9a54\u7a0e\u724c') == u'%E9%A9%AC%E7%A8%8E%E7%89%8C'
    assert do_urlencode(u'/') == u'/'
    assert do_urlencode(u'name=\u9a54\u7a0e\u724c&user_id=1') == u'name=%E9%A9%AC%E7%A8%8E%E7%89%8C&user_id=1'

# Generated at 2022-06-25 09:26:09.309453
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '\x9aT\xa0\xe9\xe7'
    str_1 = unicode_urldecode(str_0)
    assert str_1 == u'\x9aT\xa0éç'
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    str_2 = unicode_urldecode(bytes_0)
    assert str_2 == u'\x9aT\xa0éç'



# Generated at 2022-06-25 09:26:17.486872
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'test string'
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    encoded_var_0 = unicode_urlencode(bytes_0)
    var_0 = unicode_urlencode(string)
    assert encoded_var_0 == b'%9aT%A0%E9%E7'
    assert var_0 == 'test%20string'


# Generated at 2022-06-25 09:26:19.016270
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert isinstance(filter_module.filters(), dict)


# Generated at 2022-06-25 09:26:22.729197
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    decoded = unicode_urldecode('%9aT%a0%e9%e7')
    assert decoded == u'\u009aT\u00a0\u00e9\u00e7'



# Generated at 2022-06-25 09:26:27.393833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # No inputs
    FilterModule().filters()
    FilterModule().filters()
    FilterModule().filters()

    # Args
    FilterModule().filters(None)
    FilterModule().filters(None, None)
    FilterModule().filters(None, None, None)
    FilterModule().filters(1, 2, 3)
    FilterModule().filters(1, 2, 3, None)


# Generated at 2022-06-25 09:26:31.152633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(None)
    assert isinstance(filters, dict)
    assert 'urldecode' in filters
    assert filters['urldecode'] is unicode_urldecode
    assert 'urlencode' in filters
    assert filters['urlencode'] is unicode_urlencode

# Generated at 2022-06-25 09:26:35.593235
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'\x9aT\xa0\xe9\xe7') == u'\u009aT\xa0\xe9\xe7'

# Generated at 2022-06-25 09:26:44.190109
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%F0%90%81%91') == u'€𐆑'
    assert unicode_urldecode('%E2%82%AC+%F0%90%81%91') == u'€+𐆑'
    assert unicode_urldecode('%E2%82%AC%2B%F0%90%81%91') == u'€+𐆑'
    assert unicode_urldecode('%E2%82%AC%20%F0%90%81%91') == u'€ 𐆑'

# Generated at 2022-06-25 09:26:48.288569
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urlencode(bytes_0)

    # The byte-string '%9aT%a0%e9%e7' should be equal to the string '%9aT%a0%e9%e7'
    assert var_0 == u'%9aT%a0%e9%e7'

# Generated at 2022-06-25 09:26:53.681298
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'\x9aT\xa0\xe9\xe7') == u'\u269aT\xa0\xe9\xe7'
    assert unicode_urldecode(b'\x9aT\xa0\xe9\xe7') != "ΩT\xa0éç"
    assert unicode_urldecode(to_text(b'%c3%aef%c3%b6%c3%b8')) == u"æføø"
    assert unicode_urldecode(to_text(b'%c3%aef%c3%b6%c3%b8')) != "æføø"

# Generated at 2022-06-25 09:26:57.093278
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert var_0 == u'\u009aT\u00a0\u00e9\u00e7'


# Generated at 2022-06-25 09:27:03.480159
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Mock:
    class ModuleMock(object):
        def __init__(self):
            pass
        def fail_json(self, msg):
            raise Exception(msg)
    # Unit test:
    obj = FilterModule()
    all_filters = obj.filters()
    assert 'urldecode' in all_filters, 'urldecode filter not found'
    if not HAS_URLENCODE:
        assert 'urlencode' in all_filters, 'urlencode filter not found'
    assert obj.filters() == all_filters, 'obj.filters() returned different values on subsequent calls'

# Generated at 2022-06-25 09:27:10.750140
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urlencode(bytes_0)
    assert (var_0 == b'%E2%99%A1T%C2%A0%C3%A9%C3%A7')


# Generated at 2022-06-25 09:27:21.253966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test the case where: bytes_0 = b'\x9aT\xa0\xe9\xe7'
    # and the expected result is: '\u009aT\u00a0\u00e9\u00e7'
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    expected_result_0 = '\u009aT\u00a0\u00e9\u00e7'
    actual_result_0 = unicode_urldecode(bytes_0)
    assert actual_result_0 == expected_result_0

    # Test the case where: string = 'test'
    # and the expected result is: 'test'
    string = 'test'
    expected_result_1 = 'test'
    actual_result_1 = unicode

# Generated at 2022-06-25 09:27:23.249277
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urlencode(bytes_0)


# Generated at 2022-06-25 09:27:31.497298
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert b'\x9aT\xa0\xe9\xe7' == unicode_urldecode(b'\x9aT\xa0\xe9\xe7')
    assert b'\x9aT\xa0\xe9\xe7' == unicode_urldecode(b'%9aT%A0%E9%E7')


# Generated at 2022-06-25 09:27:32.682336
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_0 = FilterModule().filters()
    assert filters_0


# Generated at 2022-06-25 09:27:35.387462
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'\x9aT\xa0\xe9\xe7') == u'马T汉'


# Generated at 2022-06-25 09:27:43.988787
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # assert unicode_urlencode(u'') == u'%E5%B7%AE'
    assert unicode_urlencode(u'') == u'%3D'
    assert unicode_urlencode(u'.') == u'.'
    assert unicode_urlencode(u'./') == u'./'
    assert unicode_urlencode(u'..') == u'..'
    assert unicode_urlencode(u'../') == u'../'
    assert unicode_urlencode(u'{}') == u'%7B%7D'
    assert unicode_urlencode(u'{./}') == u'%7B./%7D'
    assert unicode_urlencode(u'{../}') == u'%7B../%7D'

# Generated at 2022-06-25 09:27:56.252413
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_0 = FilterModule()
    var_1 = var_0.filters()


if __name__ == '__main__':
    # Need to import there so we can get the captured stdout
    from ansible.utils.pytest_runner import run_tests
    run_tests(test_datadir='test/filter_plugins/test_filters_core.py')

# -*- -*- -*- End included fragment: tests/filter_plugins/test_filters_core.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: lib/ansible/module_utils/urls.py -*- -*- -*-

# -*- coding: utf-8 -*-

#  (c) 2017, Ansible by Red Hat, inc

# Generated at 2022-06-25 09:28:03.536155
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_string = 'https://example.com/path/?a=1&b=2'
    expected_string = 'https%3A%2F%2Fexample.com%2Fpath%2F%3Fa%3D1%26b%3D2'
    actual_string = unicode_urlencode(test_string, for_qs=True)
    assert actual_string == expected_string

# Generated at 2022-06-25 09:28:05.899933
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_0 = FilterModule()

    var_1 = var_0.filters()



# Generated at 2022-06-25 09:28:06.854208
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    filters.filters()


# Generated at 2022-06-25 09:28:15.621099
# Unit test for function do_urlencode
def test_do_urlencode():
    x = 5
    y = 7
    list = [ x, 2, y ]
    assert do_urlencode(list) == u'5&2&7'
    assert do_urlencode(tuple(list)) == u'5&2&7'
    assert do_urlencode(x) == u'5'
    assert do_urlencode(y) == u'7'
    assert do_urlencode(dict(one=1, two=2, three=3)) == u'one=1&three=3&two=2'


# Generated at 2022-06-25 09:28:19.554763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    expected_0 = u'\u009aT\u00a0\u00e9\u00e7'
    var_0 = unicode_urldecode(u'\u009aT\u00a0\u00e9\u00e7')
    assert expected_0 == var_0


# Generated at 2022-06-25 09:28:21.996951
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)


# Generated at 2022-06-25 09:28:24.707065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'] is do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] is do_urlencode


# Generated at 2022-06-25 09:28:27.681958
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule.filters(FilterModule())
    assert x[0]['urldecode'] == do_urldecode
    assert x[0]['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:28:31.869036
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiation of class FilterModule
    FilterModule_obj_0 = FilterModule()

    # Call of methods filters of class FilterModule
    var_0 = FilterModule_obj_0.filters()

    # Assignment of attribute filters of object FilterModule_obj_0
    FilterModule_obj_0.filters = var_0


# Generated at 2022-06-25 09:28:34.565489
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert len(filters) == 1


# Generated at 2022-06-25 09:28:40.525030
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\xea\x95\x8c\x9d\x86\x82') == '%EA%95%8C%9D%86%82'


# Generated at 2022-06-25 09:28:42.817320
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert u'urldecode' in filters
    assert not HAS_URLENCODE or u'urlencode' in filters


# Generated at 2022-06-25 09:28:48.450626
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    str_0 = '%9aT%A0%E9%E7'
    var_0 = unicode_urlencode(bytes_0, True)
    assert var_0 == str_0


# Generated at 2022-06-25 09:28:51.037827
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u00b0C') == u'%C2%B0C'



# Generated at 2022-06-25 09:28:55.722423
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:28:58.499305
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result = unicode_urlencode(None)



# Generated at 2022-06-25 09:29:01.550847
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ansible_result = unicode_urlencode(b'\x9aT\xa0\xe9\xe7')
    assert ansible_result == '%9aT%A0%E9%E7'


# Generated at 2022-06-25 09:29:11.780401
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate a FilterModule object
    test_instance_0 = FilterModule()
    # Get the filters of the instance
    var_0 = test_instance_0.filters()
    # Assert the filters of the instance
    assert var_0 == {'urldecode': do_urldecode}

if __name__ == "__main__":
    import sys
    import warnings

    if sys.argv[1] == "--test":
        from ansible.module_utils.compat.tests.unit.compat.mock import patch
        from ansible.module_utils.compat import unittest

        class Test_FilterModule(unittest.TestCase):
            """Test jinja2.filters.urlencode
            """

# Generated at 2022-06-25 09:29:14.468088
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
    assert result['action'] is not None


# Generated at 2022-06-25 09:29:22.681943
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x9aT\xa0\xe9\xe7'
    var_0 = unicode_urldecode(bytes_0)
    var_1 = unicode_urldecode('')

    if var_0 != '\x9aT\xa0\xe9\xe7':
        var_2 = False

    var_2 = True

    assert var_2 == True



# Generated at 2022-06-25 09:29:24.342281
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True  


# Generated at 2022-06-25 09:29:33.036551
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    unicode_0 = u'\x9aT\xa0\xe9\xe7'
    var_0 = do_urldecode(unicode_0)

    unicode_2 = u'\x9aT\xa0\xe9\xe7'
    var_1 = do_urldecode(unicode_2)

    unicode_4 = u'\x9aT\xa0\xe9\xe7'
    var_2 = do_urldecode(unicode_4)

    unicode_6 = u'\x9aT\xa0\xe9\xe7'
    var_3 = do_urldecode(unicode_6)

    unicode_8 = u'\x9aT\xa0\xe9\xe7'
    var_4 = do_

# Generated at 2022-06-25 09:29:34.360002
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_instance = FilterModule()
    assert filters_instance.filters() is not None



# Generated at 2022-06-25 09:29:40.633661
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # JUNK
    check = unicode_urldecode(b'\x9aT\xa0\xe9\xe7')
    assert check == u"\u009aT\u00a0\u00e9\u00e7"


# Generated at 2022-06-25 09:29:42.576385
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_var = FilterModule.filters(FilterModule())
    assert filters_var is not None
    assert filters_var is not False
    assert filters_var != ''

# Generated at 2022-06-25 09:29:47.218151
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters0 = FilterModule()
    filters_0 = filters0.filters()
    # Exception has occurred: TypeError
    filters_0['urlencode']('\x9aT\xa0\xe9\xe7')
    var_0 = unicode_urlencode('\x9aT\xa0\xe9\xe7')

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()