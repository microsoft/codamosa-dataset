

# Generated at 2022-06-25 09:19:55.183367
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'https://www.example.com/foo/?a=1&b=2'
    assert unicode_urlencode(string) == u'https%3A%2F%2Fwww.example.com%2Ffoo%2F%3Fa%3D1%26b%3D2'



# Generated at 2022-06-25 09:19:56.434955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filter_0 = filter_module_0.filters()

# Generated at 2022-06-25 09:19:59.432267
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    document_0 = FilterModule()
    var_0 = document_0.filters()
    var_1 = var_0
    var_2 = var_1
    assert var_2 == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

# Generated at 2022-06-25 09:20:01.243515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'


# Generated at 2022-06-25 09:20:03.722872
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'safe') == u'safe'
    assert unicode_urlencode(u'safe/') == u'safe%2F'


# Generated at 2022-06-25 09:20:06.358802
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'


# Generated at 2022-06-25 09:20:10.555439
# Unit test for function do_urlencode
def test_do_urlencode():
    input = {'foo': 'bar'}
    expected = u'foo=bar'
    actual = do_urlencode(input)
    assert actual == expected


# Generated at 2022-06-25 09:20:12.804493
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0, "Failed to create instance"


# Generated at 2022-06-25 09:20:22.874039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)
    assert 'urldecode' in filters
    urldecode = filters['urldecode']
    assert urldecode(u'foo%20bar') == u'foo bar'
    assert urldecode(u'foo%21') == u'foo!'
    assert urldecode(u'foo%2A') == u'foo*'
    assert urldecode(u'foo%2B') == u'foo+'
    assert urldecode(u'foo%2C') == u'foo,'
    assert urldecode(u'foo%2F') == u'foo/'
    assert urldecode(u'foo%3A') == u'foo:'

# Generated at 2022-06-25 09:20:25.669813
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters = filter_module_1.filters()
    assert isinstance(filters, dict)


# Generated at 2022-06-25 09:20:30.210981
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Make sure that this does not raise an exception, since there is a regression in Jinja2
    # which prevents it from working for unicode strings.
    assert unicode_urlencode(u'\x13') == b'%13'


# Generated at 2022-06-25 09:20:37.342543
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(
        'https%3A%2F%2Fgithub.com%2Fansible%2Fansible%2Fblob%2Fdevel%2Fexamples%2Fscripts%2FConfigure%2520Remoting%2520for%2520Windows%2520Hosts.ps1') == 'https://github.com/ansible/ansible/blob/devel/examples/scripts/Configure%20Remoting%20for%20Windows%20Hosts.ps1'

# Generated at 2022-06-25 09:20:41.506794
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    filter_module_0 = FilterModule()
    # filter_module_0.unicode_urlencode(value)


# Generated at 2022-06-25 09:20:46.040275
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    test_value_1 = None
    expected_value_1 = {"urldecode": do_urldecode}
    actual_value_1 = filter_module_1.filters()
    assert expected_value_1 == actual_value_1


# Generated at 2022-06-25 09:20:47.678783
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urlencode': do_urlencode}


# Generated at 2022-06-25 09:20:51.735838
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("u'foo bar'") == b'u%27foo%20bar%27'
    assert unicode_urlencode("%7E") == b'~'


# Generated at 2022-06-25 09:20:58.384548
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = filter_module_0.filters()
    (k, v) = filters[0]
    if HAS_URLENCODE:
        assert k == 'urlencode'
    else:
        assert k == 'urldecode'


# Generated at 2022-06-25 09:21:05.552269
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Retrieve the instance method from the class
    function = filter_module_0.filters()['urldecode']
    
    # Only valid strings should pass through
    assert function('hello') == 'hello'

    # Strings should be unquoted and unescaped
    assert function('hello%20world') == 'hello world'


# Generated at 2022-06-25 09:21:08.921637
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert isinstance(filter_module_1.filters(), dict)



# Generated at 2022-06-25 09:21:17.722053
# Unit test for function do_urlencode
def test_do_urlencode():
    # Should take string (unquoted) and encode it
    assert do_urlencode('abc') == unicode_urlencode('abc')
    assert do_urlencode('ab c') == unicode_urlencode('ab c')
    assert do_urlencode('ab/c') == unicode_urlencode('ab/c')
    assert do_urlencode('ab?c') == unicode_urlencode('ab%3Fc')
    assert do_urlencode('ab#c') == unicode_urlencode('ab%23c')
    assert do_urlencode('ab%c') == unicode_urlencode('ab%25c')
    assert do_urlencode('ab&c') == unicode_urlencode('ab&c')

    # Should take dict and encode it
    assert do

# Generated at 2022-06-25 09:21:23.238849
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test%20test') == 'test test'



# Generated at 2022-06-25 09:21:29.332981
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    f = unicode_urldecode
    assert '' == f('')
    assert 'abc' == f('abc')
    assert 'ABC' == f('ABC')
    assert 'a b c' == f('a%20b%20c')
    assert 'a+b+c' == f('a%2Bb%2Bc')
    assert '☃' == f('%E2%98%83')
    assert '☃' == f('%e2%98%83')
    assert '☃' == f('%e2%98%83')
    assert '☃' == f('☃')



# Generated at 2022-06-25 09:21:32.286695
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:21:39.638311
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foobar') == u'foobar'
    assert do_urlencode(u'foobar/') == u'foobar%2F'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo%20bar') == u'foo%20bar'
    if not PY3:
        assert do_urlencode(u'foo\x20bar') == u'foo%20bar'
    assert do_urlencode(dict(a=u'foo', b=u'bar')) == u'a=foo&b=bar'
    assert do_urlencode((u'a', u'foo'))

# Generated at 2022-06-25 09:21:45.986622
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()

    assert(filter_module_1.filters()['urldecode'](filter_module_1.filters()['urlencode']('/hello world')) == '/hello world')
    return True

# Run all tests
if __name__ == '__main__':
    test_FilterModule_filters()
    test_case_0()

# Generated at 2022-06-25 09:21:49.249114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_rv = filter_module_0.filters()
    assert isinstance(filters_rv, dict)
    assert filters_rv['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:21:53.846635
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo%20') == 'foo '
    assert unicode_urldecode('foo%2B') == 'foo+'
    assert unicode_urldecode('foo+') == 'foo '


# Generated at 2022-06-25 09:21:54.949865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    s = FilterModule()
    assert isinstance(s.filters(), dict)


# Generated at 2022-06-25 09:22:04.369904
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E9%9F%93%E8%AA%9E%E3%83%86%E3%82%B9%E3%83%88') == u'韓語テスト'
    assert unicode_urldecode('+%E9%9F%93%E8%AA%9E%E3%83%86%E3%82%B9%E3%83%88') == u'+韓語テスト'
    assert unicode_urldecode('%2B%E9%9F%93%E8%AA%9E%E3%83%86%E3%82%B9%E3%83%88') == u'+韓語テスト'

# Generated at 2022-06-25 09:22:11.954644
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("hello world") == u'hello%20world'
    assert unicode_urlencode("hello world", for_qs=True) == u'hello+world'
    assert unicode_urlencode("hello world", for_qs=False) == u'hello%20world'


# Generated at 2022-06-25 09:22:16.352446
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'https://www.example.com/foo/bar'
    var_0 = unicode_urlencode(string)


# Generated at 2022-06-25 09:22:17.217785
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()


# Generated at 2022-06-25 09:22:18.875544
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)


# Generated at 2022-06-25 09:22:20.564030
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)


# Generated at 2022-06-25 09:22:27.523562
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Asserts that the result from calling unicode_urldecode() matches the expected value
    int_0 = '%E9%9F%A9%E8%A8%80'
    var_0 = unicode_urldecode(int_0)
    assert var_0 == u'韩语'

    int_1 = '\xB1\xB9\xC9\xB3\xC4\xDC\xC7\xF8'
    var_1 = unicode_urldecode(int_1)
    assert var_1 == u'买卖汉语拼音字母表'


# Generated at 2022-06-25 09:22:30.851179
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test cases
    result = unicode_urldecode(0)
    # assert result  == 


# Generated at 2022-06-25 09:22:38.439343
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:22:40.330802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()


# Main function
if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-25 09:22:42.519178
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    result = obj.filters()
    assert True


# Generated at 2022-06-25 09:22:43.429490
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters()


# Generated at 2022-06-25 09:22:46.188297
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert not unicode_urldecode(u"%")


# Generated at 2022-06-25 09:22:52.657966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Function unicode_urldecode must raise an exception on invalid input
    try:
        unicode_urldecode(42)
    except Exception as e:
        assert type(e) is TypeError
    # Test must raise exception on invalid input
    try:
        test_case_0()
    except Exception as e:
        assert type(e) is TypeError



# Generated at 2022-06-25 09:22:55.058326
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    safe='/'
    quote_func=quote
    string=r'/mysearch'
    assert unicode_urlencode(string)==quote_func(string,safe)
    # non-ascii string
    string=u'\u202eabc\u202c'
    assert unicode_urlencode(string,"")==quote_func(string.encode('utf-8'),"")
    assert unicode_urlencode(string,"")==u'%E2%80%AEabc%E2%80%AC'


# Generated at 2022-06-25 09:23:03.665956
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('c%20b') == 'c b'
    assert unicode_urldecode('foo%2Bbar') == 'foo+bar'
    assert unicode_urldecode('/goto.html?url=ftp://ftp.adobe.com/pub/adobe/reader/unix/9.x/9.5.5/misc/AdbeRdr9.5.5-1_i486linux_enu.deb') == '/goto.html?url=ftp://ftp.adobe.com/pub/adobe/reader/unix/9.x/9.5.5/misc/AdbeRdr9.5.5-1_i486linux_enu.deb'
    assert unicode_urldec

# Generated at 2022-06-25 09:23:10.460761
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Set up mock
    safe = 'safe'
    string = 'string'
    for_qs = False

    # Invoke method
    result = unicode_urlencode(string, for_qs)

    # Assertions
    assert result == 'string'


# Generated at 2022-06-25 09:23:17.485109
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('Test: filters')

    # ===== Test case 0 =====
    print('  Testcase 0: Default')
    obj_FilterModule = FilterModule()
    var_0 = obj_FilterModule.filters()


# Generated at 2022-06-25 09:23:24.458178
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = None
    int_0 = unicode_urlencode(int_0)
    assert int_0 == 'None', "Expected behavior for unicode_urlencode is defined in RFC 3986"


# Generated at 2022-06-25 09:23:25.478153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_obj = FilterModule()
    test_obj.filters()

# Generated at 2022-06-25 09:23:26.403017
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    inst_class = FilterModule()
    inst_class.filters()


# Generated at 2022-06-25 09:23:32.185085
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    val = 'test'
    assert unicode_urldecode(val) == 'test'
    val = 'foo+bar'
    assert unicode_urldecode(val) == 'foo bar'
    val = 'foo%20%21%22%23'
    assert unicode_urldecode(val) == 'foo !"#'


# Generated at 2022-06-25 09:23:37.469938
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    instance = FilterModule()
    assert isinstance(instance.filters(), dict)

# Generated at 2022-06-25 09:23:42.248724
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = None
    str_1 = None
    str_2 = None
    bool_0 = None
    var_0 = unicode_urlencode(str_0,bool_0)
    var_1 = unicode_urlencode(str_1,bool_0)
    var_2 = unicode_urlencode(str_2,bool_0)


# Generated at 2022-06-25 09:23:43.552380
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test if returns None when called with None
    assert unicode_urldecode(None) == None


# Generated at 2022-06-25 09:23:47.196092
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_0()



# Generated at 2022-06-25 09:23:50.249626
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = FilterModule()
    var_0 = int_0.filters()
    var_1 = var_0['urldecode']()


# Generated at 2022-06-25 09:23:52.098730
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = None
    FilterModul = FilterModule()
    str_0 = FilterModul.filters()


# Generated at 2022-06-25 09:23:53.753365
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()

    assert (obj.filters is not None)


# Generated at 2022-06-25 09:23:57.663750
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule_obj.filters()
    assert filters == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-25 09:24:07.276350
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    function_1 = unicode_urldecode('''None''')
    if function_1 == None:
        print('None')
    function_0 = unicode_urldecode('''{{ TestCase }}''')
    if function_0 == 'None':
        print('None')
    function_0 = unicode_urldecode('{{ TestCase }}')
    if function_0 == 'None':
        print('None')
    function_0 = unicode_urldecode('{{ TestCase }}')
    if function_0 == 'None':
        print('None')
    function_0 = unicode_urldecode('{{ TestCase }}')
    if function_0 == 'None':
        print('None')
    function_0 = unicode_urldecode('{{ TestCase }}')

# Generated at 2022-06-25 09:24:09.507178
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'].__name__ == 'do_urldecode'
    if not HAS_URLENCODE:
        assert filters['urlencode'].__name__ == 'do_urlencode'
    else:
        assert filters['urlencode'].__name__ == 'do_urlencode'


# Generated at 2022-06-25 09:24:15.354674
# Unit test for function do_urlencode
def test_do_urlencode():
    str_0 = unicode()
    str_1 = do_urlencode(str_0)


# Generated at 2022-06-25 09:24:17.920454
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)
    assert var_0 == 'None'


# Generated at 2022-06-25 09:24:22.143072
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)
    # assert that var_0 is of type <type 'unicode'>
    assert isinstance(var_0, unicode)
    # assert that var_0's unicode value is equal to 'None'
    assert var_0 == 'None'


# Generated at 2022-06-25 09:24:26.152809
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("$") == "$"
    assert unicode_urldecode("%") == "%"
    assert unicode_urldecode("%24") == "$"
    assert unicode_urldecode("%24%24") == "$$"
    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("%25%25") == "%%"



# Generated at 2022-06-25 09:24:27.106383
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    unicode_urldecode(int_0)


# Generated at 2022-06-25 09:24:29.172115
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    assert unicode_urldecode(int_0) == None

# Generated at 2022-06-25 09:24:38.424588
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(None, False) == u'None'
    assert unicode_urlencode(None, True) == u'None'
    assert unicode_urlencode('/lol/?', False) == u'/lol/%3F'
    assert unicode_urlencode('/lol/?', True) == u'/lol/%3F'
    assert unicode_urlencode('ansible-', False) == u'ansible-'
    assert unicode_urlencode('ansible-', True) == u'ansible-'
    assert unicode_urlencode('/lol/?', True) == u'/lol/%3F'
    assert unicode_urlencode('&=', False) == u'%26=', unicode_urlencode('&=', False)
    assert unicode_urlencode

# Generated at 2022-06-25 09:24:40.610581
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    for_qs = False
    string = 'variable'
    expected = 'variable'
    actual = unicode_urlencode(string, for_qs)
    assert expected == actual


# Generated at 2022-06-25 09:24:49.422959
# Unit test for function do_urlencode
def test_do_urlencode():
    int_0 = dict()
    var_0 = do_urlencode(int_0)
    if var_0 != u'':
        raise ValueError('var_0:Did not get expected result.  Got.  {}'.format(var_0))

    int_0 = dict(a='b', c='d')
    var_0 = do_urlencode(int_0)
    if var_0 != u'a=b&c=d':
        raise ValueError('var_0:Did not get expected result.  Got.  {}'.format(var_0))

    int_0 = dict(a='b', c=dict(e='f'))
    var_0 = do_urlencode(int_0)
    if var_0 != u'a=b&c=e%3Df':
        raise

# Generated at 2022-06-25 09:24:56.621035
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Config
    int_1 = None

    # Call the function
    returned_value_0 = unicode_urldecode(int_1)

    # AssertionError: AssertionError: Expected type of returned_value_0 is [str or unicode]


# Generated at 2022-06-25 09:25:01.437721
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-25 09:25:06.209074
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = None
    int_1 = None
    filters_0 = FilterModule().filters()


# Generated at 2022-06-25 09:25:08.631666
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)
    assert var_0 == ''



# Generated at 2022-06-25 09:25:10.702301
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = "abc"
    var_0 = unicode_urlencode(int_0)
    int_1 = "abc_xyz"
    var_1 = unicode_urlencode(int_1)


# Generated at 2022-06-25 09:25:14.106302
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = None
    var_0 = unicode_urlencode(int_0)
    #assert var_0 == {}
    int_1 = 'jmwfQy6UdA'
    var_1 = unicode_urlencode(int_1)
    #assert var_1 == {}

# Generated at 2022-06-25 09:25:16.155732
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    itemiter_0 = None
    var_0 = unicode_urlencode(itemiter_0)

# Generated at 2022-06-25 09:25:20.086594
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    data = ""
    arg = data
    # Call the function
    var_0 = unicode_urldecode(arg)



# Generated at 2022-06-25 09:25:27.580779
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Assert #1
    int_0 = '1337'
    var_0 = unicode_urldecode(int_0)
    assert var_0 == '1337'
    try:
        var_0 = unicode_urldecode(int_0)
    except Exception:
        var_0 = '1337'
    assert var_0 == '1337'
    # Assert #2
    int_1 = '+1337'
    var_1 = unicode_urldecode(int_1)
    assert var_1 == ' 1337'
    try:
        var_1 = unicode_urldecode(int_1)
    except Exception:
        var_1 = '1337'
    assert var_1 == '1337'
    # Assert #3
    int_

# Generated at 2022-06-25 09:25:35.162092
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # set up test inputs
    var_0 = "welcome home, motherfuckers"
    int_0 = urllib.quote_plus(var_0)
    # set up test outputs
    expected_1 = var_0
    # perform the test
    test_1 = unicode_urldecode(int_0)
    # compare test outputs to expected outputs
    print(test_1)
    assert test_1 == expected_1, "Expected: %s, but got: %s" % (expected_1, test_1)


# Generated at 2022-06-25 09:25:46.608424
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)
    assert var_0 is None

    int_1 = "%20%21%22%23%24%25%26%27%28%29"
    var_1 = unicode_urldecode(int_1)
    assert var_1 == " !\"#$%&'()"

    int_2 = "hello"
    var_2 = unicode_urldecode(int_2)
    assert var_2 == "hello"

    int_3 = "hello%20"
    var_3 = unicode_urldecode(int_3)
    assert var_3 == "hello%20"

    int_4 = "a+b"

# Generated at 2022-06-25 09:25:51.696154
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string_0 = 'hello world!'
    assert unicode_urldecode(string_0) == 'hello world!'


# Generated at 2022-06-25 09:26:00.987664
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing TestAnsibleCoreJinja2Module::test_unicode_urldecode")

    int_0 = None
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    float_0 = float()

    if (unicode_urldecode(int_0) is not to_text('')):
        print("unicode_urldecode(int_0) failed")
        return 1

    if (unicode_urldecode(str_0) is not to_text('')):
        print("unicode_urldecode(str_0) failed")
        return 2


# Generated at 2022-06-25 09:26:03.561120
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit test for filters method of class FilterModule
    int_0 = None
    pattern_0 = re.compile('urldecode')
    assert hasattr(pattern_0, 'search')
    assert callable(pattern_0.search)
    # TODO: Add assert for the return value of this method call


# Generated at 2022-06-25 09:26:07.349284
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()

    assert True

# Generated at 2022-06-25 09:26:08.378028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = None
    var_0 = FilterModule.filters(int_0)


# Generated at 2022-06-25 09:26:11.167199
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm_instance = FilterModule()
    filters_retval = fm_instance.filters()
    assert filters_retval == {'urldecode': do_urldecode} or filters_retval == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

# Generated at 2022-06-25 09:26:21.338054
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:26:23.451506
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert isinstance(filter_module.filters(), dict)


# Generated at 2022-06-25 09:26:25.981101
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_0 = FilterModule()
    var_0 = ansible_0.filters()
    assert var_0 == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:26:35.400477
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:26:39.604162
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = 'test'
    var_0 = unicode_urlencode(int_0)


# Generated at 2022-06-25 09:26:47.337236
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('7') == '7'
    assert unicode_urldecode('7.100') == '7.100'
    assert unicode_urldecode('azAZ09+/') == 'azAZ09+/'
    assert unicode_urldecode('-_.!~*()') == '-_.!~*()'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2A') == '*'
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('-_.!~*()%2A%2B') == '-_.!~*()*+'



# Generated at 2022-06-25 09:26:51.993223
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Configuration for FilterModule
    test_FilterModule = FilterModule()
    
    # Testing method filters with arguments
    # Return type: dict
    test_FilterModule.filters()

# Generated at 2022-06-25 09:27:01.976183
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()

    # def filters(self):
    #     filters = {
    #         'urldecode': do_urldecode,
    #     }
    # 
    #     if not HAS_URLENCODE:
    #         filters['urlencode'] = do_urlencode
    # 
    #     return filters
    filters_ret_0 = filters.filters()
    var_0 = 'urldecode' in filters_ret_0
    assert var_0 == True
    var_1 = filters_ret_0.get('urldecode')
    assert callable(var_1)
    assert var_1 == do_urldecode
    var_2 = filters_ret_0.get('urlencode')
    if HAS_URLENCODE:
        assert var_2

# Generated at 2022-06-25 09:27:03.888412
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = None
    var_0 = unicode_urlencode(int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:27:10.461563
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("\nTest unicode_urldecode")
    print("=======================")
    print("Testing positive cases")
    print("----------------------")

    test_case_0()

    print("Testing negative cases")
    print("----------------------")



# Generated at 2022-06-25 09:27:12.071040
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit: Build dict of testing.
    # Setup: No setup needed.
    test_case_0()

# Generated at 2022-06-25 09:27:21.310822
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Define a few input parameters to be passed to the function
    int_0 = None
    int_1 = 'aHR0cDovL3d3dy5hbnNpYmxlLmNvbS9hbnNpYmxlLWNvcmU='

    # Test calls with default parameter values for function
    var_0 = unicode_urldecode(int_0)
    var_1 = unicode_urldecode(int_1)

    # Test calls with explicit parameter values for function
    var_2 = unicode_urldecode(int_0)
    var_3 = unicode_urldecode(int_1)


# Generated at 2022-06-25 09:27:31.834071
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) == None, 'Expected None, but got %s' % unicode_urldecode(None)
    assert unicode_urldecode('None') == 'None', "Expected 'None', but got %s" % unicode_urldecode('None')
    assert unicode_urldecode('test_value') == 'test_value', "Expected 'test_value', but got %s" % unicode_urldecode('test_value')
    assert unicode_urldecode('test_value') == 'test_value', "Expected 'test_value', but got %s" % unicode_urldecode('test_value')

# Generated at 2022-06-25 09:27:33.668358
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    inst_0 = FilterModule()
    var_0 = inst_0.filters()
    del inst_0
    var_0
    pass

# Generated at 2022-06-25 09:27:38.375908
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)



# Generated at 2022-06-25 09:27:42.797482
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    int_0 = None
    var_0 = unicode_urlencode(int_0)


# Generated at 2022-06-25 09:27:44.598791
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_0 = None
    obj_0 = FilterModule()
    assert isinstance(obj_0.filters(), dict) is True


# Generated at 2022-06-25 09:27:50.082370
# Unit test for function do_urlencode
def test_do_urlencode():
    string = "foobar"
    var1 = do_urlencode(string)
    var2 = do_urlencode(string)
    assert var1 == var2

# Generated at 2022-06-25 09:27:55.088611
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # __doc__ (as of 2008-08-02) for jinja2.filters.do_urlencode:

    # URL escape a value.  If used as a filter, this will escape the value
    # if it's not string.  If it's string, it will return the value unchanged.
    # Taken from rabbitmq-public-umbrella/rabbitmq-public-umbrella.

    var_0 = FilterModule()
    var_1 = var_0.filters()


# Generated at 2022-06-25 09:28:03.636272
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj_0 = FilterModule()
    filters_0 = obj_0.filters()
    lst_0 = list(filters_0.items())
    tpl_0 = (lst_0[0][0], lst_0[0][1], lst_0[1][0], lst_0[1][1],)
    str_0 = str(tpl_0)
    print(str_0)


# Generated at 2022-06-25 09:28:11.819359
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        # (0, ),
    ]
    for index, test_case in enumerate(test_cases):
        print('Running test case #{}'.format(index + 1))
        try:
            func_result = unicode_urldecode(*test_case[0])
        except Exception as e:
            print('Exception raised when running test case #{}'.format(index + 1))
            raise e
        else:
            assert func_result == test_case[1]
        finally:
            print('Done running test case #{}\n'.format(index + 1))


# Generated at 2022-06-25 09:28:16.840168
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test case 1
    int_0 = '!@#$%^&*()_+'
    var_0 = unicode_urldecode(int_0)
    test = (var_0 == '!@#$%^&*()_+')
    print(test)


# Generated at 2022-06-25 09:28:18.825454
# Unit test for function do_urlencode
def test_do_urlencode():

    int_0 = 'test case 0'
    var_1 = None
    var_0 = do_urlencode(var_1)
    assert var_0 == int_0


# Generated at 2022-06-25 09:28:21.185942
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
    assert isinstance(result, dict)

# Generated at 2022-06-25 09:28:33.035221
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    for_qs = False

    # int_0 = None
    # var_0 = unicode_urlencode(int_0, for_qs)
    int_1 = True
    var_1 = unicode_urlencode(int_1, for_qs)
    int_2 = False
    var_2 = unicode_urlencode(int_2, for_qs)

    var_3 = u''
    var_4 = unicode_urlencode(var_3, for_qs)

    var_5 = u'Hello World?!'
    var_6 = unicode_urlencode(var_5, for_qs)

    var_7 = u'+~?&'
    var_8 = unicode_urlencode(var_7, for_qs)

    var_9 = u'/'
   

# Generated at 2022-06-25 09:28:33.888733
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()


# Generated at 2022-06-25 09:28:45.328294
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Simple examples
    assert unicode_urldecode('x') == u'x'
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('x%2Bx') == u'x+x'
    # Examples with non-ASCII characters
    assert unicode_urldecode('%C3%BC') == u'\xfc'
    assert unicode_urldecode('%E2%98%83') == u'\u2603'
    if PY3:
        assert unicode_urldecode('%C3%BC') == u'ü'
        assert unicode_urldecode('%E2%98%83') == u'☃'
    # Test input type

# Generated at 2022-06-25 09:28:48.136987
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Asserts int_0 value
    assert unicode_urldecode(None) == None


# Generated at 2022-06-25 09:28:49.298119
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()



# Generated at 2022-06-25 09:28:56.955010
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('test_FilterModule_filters')
    filters = FilterModule().filters()
    print('\tVerify filters is not None')
    assert filters is not None, 'Test Failed filters is None!'
    print('\tVerify filters is of type dict')
    assert isinstance(filters, dict), 'Test Failed filters is not of type dict!'
    print('\tVerify filters does not contain None')
    for value in filters.values():
        assert value is not None, 'Test Failed filters has None!'
    print('\tVerify filters has keys')
    assert len(filters) > 0, 'Test Failed filters is empty'


# Generated at 2022-06-25 09:28:58.816596
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    int_0 = FilterModule()
    var_0 = int_0.filters()


# Generated at 2022-06-25 09:29:02.714360
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    var_1 = None
    var_2 = None
    # expect result [result]
    print('Expect result: {}'.format(result))
    result = unicode_urlencode(var_1, var_2)
    print('Actual result: {}'.format(result))
    assert result == result



# Generated at 2022-06-25 09:29:11.862467
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    int_0 = None
    var_0 = unicode_urldecode(int_0)
    string_0 = 'qZx!K'
    var_1 = unicode_urldecode(string_0)
    list_0 = ['qZx!K', ";~#dH\x1a", 'qZx!K', 'qZx!K', 'qZx!K']
    tuple_0 = (string_0,)
    int_1 = 0

# Generated at 2022-06-25 09:29:20.547291
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) == None
    assert unicode_urldecode(b'c44b5b534e1c01dc3bfcc3e3b00ffa81') == 'c44b5b534e1c01dc3bfcc3e3b00ffa81'
    assert unicode_urldecode('9a2eb6f4b6f4a6a252a6a0e6b06f0e2dd2d9f9f9') == '9a2eb6f4b6f4a6a252a6a0e6b06f0e2dd2d9f9f9'
    assert unicode_urldecode('dbd7e000') == '\udbd7\ue000'
    assert unicode_urldecode

# Generated at 2022-06-25 09:29:25.035502
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    result = obj.filters()


# Generated at 2022-06-25 09:29:26.414219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_class = FilterModule()
    try:
        test_class.filters()
    except:
        raise


# Generated at 2022-06-25 09:29:33.589206
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ret = unicode_urlencode('abc', False)
    assert ret == 'abc'

    ret = unicode_urlencode('abc', True)
    assert ret == 'abc'

    ret = unicode_urlencode('a b', False)
    assert ret == 'a%20b'

    ret = unicode_urlencode('a b', True)
    assert ret == 'a%20b'

    ret = unicode_urlencode('a/b', False)
    assert ret == 'a%2Fb'

    ret = unicode_urlencode('a/b', True)
    assert ret == 'a%2Fb'


# Generated at 2022-06-25 09:29:36.572356
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unsupported filters: ['to_nice_yaml', 'to_nice_json']
    fm = FilterModule()
    filters = fm.filters()
    attr_names = set(filters.keys())
    assert attr_names == {'urlencode', 'urldecode'}

# Generated at 2022-06-25 09:29:40.559027
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("hello world") == "hello world"

    with pytest.raises(TypeError):
        unicode_urldecode("hello world", "should take exactly 1 argument (2 given)")



# Generated at 2022-06-25 09:29:41.787375
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'string%20' == unicode_urlencode('string ')


# Generated at 2022-06-25 09:29:46.029478
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    test_case_0()
    filters.filters()

test_FilterModule_filters()