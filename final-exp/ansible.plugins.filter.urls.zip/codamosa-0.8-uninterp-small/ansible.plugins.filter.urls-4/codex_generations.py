

# Generated at 2022-06-25 09:19:59.751423
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcdef') == 'abcdef'
    assert unicode_urldecode('abcdef+123') == 'abcdef 123'
    assert unicode_urldecode('abcdef+123') == 'abcdef 123'
    assert unicode_urldecode('abcdef=123') == 'abcdef=123'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc%20def+123') == 'abc def 123'
    assert unicode_urldecode('abc%20def=123') == 'abc def=123'
    assert unicode_urldecode('abc+def') == 'abc def'
    assert unicode_urldecode('abc+def+123') == 'abc def 123'


# Generated at 2022-06-25 09:20:04.311363
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%") == "%"
    assert unicode_urldecode("%%") == "%%"
    assert unicode_urldecode("%%%") == "%"
    assert unicode_urldecode("%1") == "%1"
    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("%25%") == "%"
    assert unicode_urldecode("%25%1") == "%1"
    assert unicode_urldecode("%25%25") == "%%"
    assert unicode_urldecode("%25%25%") == "%"
    assert unicode_urldecode("%25%25%1") == "%1"


# Generated at 2022-06-25 09:20:11.457531
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Tests for function unicode_urlencode
    assert unicode_urlencode(u'a {+b') == u'a%20%7B%2Bb'
    assert unicode_urlencode(u'a {+b', for_qs=True) == u'a%20%7B%2Bb'


# Generated at 2022-06-25 09:20:14.792202
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b') == 'a b'


# Generated at 2022-06-25 09:20:22.645549
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print ('Testing function unicode_urldecode...')
    # str_encoded = "https%3A%2F%2Fgithub.com%2Fdagwieers%2Fansible-examples"
    str_encoded = "http%3A%2F%2Fwww.example.com%2Fpath%2F%3Fquery%3D1%26a%3D2"
    str_decoded = "http://www.example.com/path/?query=1&a=2"
    assert unicode_urldecode(str_encoded) == str_decoded



# Generated at 2022-06-25 09:20:25.053834
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "hello%20there"
    assert unicode_urldecode(string) == "hello there"


# Generated at 2022-06-25 09:20:27.060282
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case_1_FilterModule = FilterModule()
    test_case_1_FilterModule.filters()


# Generated at 2022-06-25 09:20:27.691005
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass

# Generated at 2022-06-25 09:20:30.379145
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    ret = filter_module_0.filters()
    assert type(ret) is dict, "Method filters of class FilterModule has error in return type of return value"

# Generated at 2022-06-25 09:20:33.195555
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b"my+space") == u"my space"


# Generated at 2022-06-25 09:20:37.759404
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("TEST") == to_text("TEST")


# Generated at 2022-06-25 09:20:46.077597
# Unit test for method filters of class FilterModule

# Generated at 2022-06-25 09:20:49.085054
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Input parameters
    #   string:
    string = "\n"

    # Expected return value
    #   string:
    expected_return_value = "\\n"

    return_value = unicode_urldecode(string)

    assert return_value == expected_return_value



# Generated at 2022-06-25 09:20:54.852398
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode(to_bytes(u'Hello%20World%21')) == u'Hello World!'
    assert unicode_urldecode('Hello%20World%21') == u'Hello World!'
    assert unicode_urldecode(u'Hello%20World%21') == u'Hello World!'
    assert unicode_urldecode(to_bytes(u'Hello+World%21')) == u'Hello World!'
    assert unicode_urldecode('Hello+World%21') == u'Hello World!'
    assert unicode_urldecode(u'Hello+World%21') == u'Hello World!'

# Generated at 2022-06-25 09:20:56.382812
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_str_0 = 'encode'
    res_0 = unicode_urldecode(test_str_0)


# Generated at 2022-06-25 09:20:57.880853
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

# Generated at 2022-06-25 09:20:59.156782
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bool_0 = True
    var_0 = unicode_urlencode(bool_0)



# Generated at 2022-06-25 09:21:05.041004
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print("Testing unicode_urlencode")
    assert unicode_urlencode("test", for_qs=False) == to_bytes("test")
    assert unicode_urlencode("test", for_qs=True) == to_bytes("test")

# Generated at 2022-06-25 09:21:13.004214
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Input parameters for function 'unicode_urlencode'
    string = 'foo bar baz'
    for_qs = False
    # Output 'safe'
    safe = '/'
    # Output 'encoded'
    encoded = 'foo%20bar%20baz'

    if PY3:
        assert quote(string, safe) == encoded
    else:
        assert quote(to_bytes(string), safe) == encoded
    return



# Generated at 2022-06-25 09:21:14.280845
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == u'test'


# Generated at 2022-06-25 09:21:19.597605
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Dummy function to check the do_urlencode function.
    bool_0 = True
    var_0 = unicode_urlencode(bool_0)
    assert (var_0 == b'True')
    bool_1 = bool(0)
    var_1 = unicode_urlencode(bool_1)
    assert (var_1 == b'False')


# Generated at 2022-06-25 09:21:26.544640
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # print("Testing urldecode")
    bool_0 = True
    str_0 = 'http://docs.ansible.com/ansible/latest/user_guide/playbooks_templating.html#urlencode-filter'
    var_0 = do_urldecode(str_0)
    # print(var_0)



# Generated at 2022-06-25 09:21:37.737262
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    input_0 = 'foo'
    expected_0 = 'foo'
    assert(unicode_urlencode(input_0) == expected_0)

    input_1 = u'Zm9v'
    expected_1 = 'Zm9v'
    assert(unicode_urlencode(input_1) == expected_1)

    input_2 = 'foo'
    expected_2 = 'foo'
    assert(unicode_urlencode(input_2) == expected_2)

    input_3 = u'Zm9v'
    expected_3 = 'Zm9v'
    assert(unicode_urlencode(input_3) == expected_3)

    input_4 = u'Zm/v'
    expected_4 = 'Zm'

# Generated at 2022-06-25 09:21:39.664215
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    FilterModule.filters(bool_0)

# Generated at 2022-06-25 09:21:42.427045
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)


# Generated at 2022-06-25 09:21:46.560642
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        var_0 = unicode_urldecode('False')
        assert var_0 == 'False'
    var_0 = unicode_urldecode('False')
    assert var_0 == 'False'


# Generated at 2022-06-25 09:21:52.034323
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    text = 'Ansible is amazing!'
    ret = unicode_urldecode(text)

    assert ret is not None


# Generated at 2022-06-25 09:22:03.438577
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http://www.example.com/?a=1+2&b=M%C3%BCnchen+%26+Berlin') == 'http://www.example.com/?a=1 2&b=München & Berlin'
    assert unicode_urldecode('http://www.example.com/?a=1+2&b=M%C3%BCnchen+%26+Berlin') == 'http://www.example.com/?a=1 2&b=München & Berlin'
    assert unicode_urldecode('http://www.example.com/?a=1+2&b=München+%26+Berlin') == 'http://www.example.com/?a=1 2&b=München & Berlin'
    assert unicode_

# Generated at 2022-06-25 09:22:09.317388
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo%2') == 'foo%2'
    assert unicode_urldecode('foo%2F') == 'foo/'
    assert unicode_urldecode('foo%2F%2F') == 'foo//'
    assert unicode_urldecode('foo+%2F%2F+') == 'foo+//+'
    assert unicode_urldecode('foo+%2F%2F+') == 'foo+//+'
    assert unicode_urldecode('foo+') == 'foo '
    assert unicode_urldecode('foo%') == 'foo%'
    assert unicode_urldecode('foo%g') == 'foo%g'

# Generated at 2022-06-25 09:22:12.046652
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(bool_0) == b'True'


# Generated at 2022-06-25 09:22:23.127721
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Testing for Decoding
    assert unicode_urldecode('abc') == u'abc', "Failed for 'abc'"
    assert unicode_urldecode('abc/') == u'abc/', "Failed for 'abc/'"
    assert unicode_urldecode('abc/def') == u'abc/def', "Failed for 'abc/def'"
    assert unicode_urldecode('abc/def%3B') == u'abc/def;', "Failed for 'abc/def%3B'"
    assert unicode_urldecode('abc/def%3B%C3%80') == u'abc/def;\xc0', "Failed for 'abc/def%3B%C3%80'"

# Generated at 2022-06-25 09:22:30.143253
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        var_0 = u'https://foo/bar?baz=%3C%3D3%3E'
    else:
        var_0 = u'https://foo/bar?baz=%3C%3D3%3E'.encode('utf-8')
    var_1 = unicode_urldecode(var_0)
    assert var_1 == u'https://foo/bar?baz=<=3>'


# Generated at 2022-06-25 09:22:34.293291
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print('Testing unicode_urldecode')
    assert('asd' == unicode_urldecode('asd')), 'Test Failed'


# Generated at 2022-06-25 09:22:35.531511
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''


# Generated at 2022-06-25 09:22:39.816685
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_1 = FilterModule.filters(bool_0)

if __name__ == '__main__':
    import sys
    import json

    obj = {}

    for line in sys.stdin:
        k, v = line.strip().split('\t', 1)
        obj[k] = v

    print(json.dumps(obj))

# Generated at 2022-06-25 09:22:42.759257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'to%20test'
    res = unicode_urldecode(string)
    print(res)
    assert res == 'to test'


# Generated at 2022-06-25 09:22:44.284372
# Unit test for function do_urlencode
def test_do_urlencode():
    assert unicode_urlencode(bool_0) == 'True'


# Generated at 2022-06-25 09:22:45.966996
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a') == 'a'



# Generated at 2022-06-25 09:22:50.228337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_0 = FilterModule()
    var_1 = var_0.filters(bool_0)


# Generated at 2022-06-25 09:22:56.305788
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters_output = filter_module.filters()
    assert len(filters_output) == 2, 'Expected length of filters is 2'
    assert 'urldecode' in filters_output, 'Expected urldecode key in filters'
    assert filters_output['urldecode'] == do_urldecode, 'Expected urldecode value is do_urldecode'
    assert 'urlencode' in filters_output, 'Expected urlencode key in filters'
    assert filters_output['urlencode'] == do_urlencode, 'Expected urlencode value is do_urldecode'

# Generated at 2022-06-25 09:23:00.310886
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # assert unicode_urldecode('string') == 'string'
    assert True


# Generated at 2022-06-25 09:23:01.607944
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_0 = FilterModule()
    class_0 = module_0.filters()


# Generated at 2022-06-25 09:23:09.004287
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # AssertionError due to "is" is not true if the assertion
    # passes (unless you assign True/False to the variable).

    string = 'abc'
    var_1 = unicode_urldecode(string)
    print(type(var_1))

    string = 'cat'
    var_2 = unicode_urldecode(string)
    print(type(var_2))

    string = 'cat'
    var_3 = unicode_urldecode(string)
    print(type(var_3))



# Generated at 2022-06-25 09:23:20.026110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # See: https://github.com/ansible/ansible/issues/29369
    if not HAS_URLENCODE:
        from jinja2.filters import FILTERS as FILTERS_OLD

        FILTERS = FILTERS_OLD.copy()
        FILTERS.update({'urldecode': do_urldecode, 'urlencode': do_urlencode})
    else:
        FILTERS = None

    import ansible.constants
    ansible.constants.JINJA2_FILTERS = FILTERS

    filter_module = FilterModule()

    assert filter_module.filters() == FILTERS

if __name__ == '__main__':
    test_case_0()

    # Unit test for method filters of class FilterModule
    test_FilterModule_filters

# Generated at 2022-06-25 09:23:23.539473
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('asdf') == 'asdf'
    assert unicode_urldecode('asdf%2F') == 'asdf%2F'
    assert unicode_urldecode('asdf%2Ffunc=1') == 'asdf%2Ffunc=1'


# Generated at 2022-06-25 09:23:28.995325
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)

    assert var_0 is True


# Generated at 2022-06-25 09:23:37.748688
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test cases
    assert unicode_urlencode(u'+') == '%2B'
    assert unicode_urlencode('+') == '%2B'
    assert unicode_urlencode('abcd+') == 'abcd%2B'
    assert unicode_urlencode({'a': 'b', 'c': 'd+'}) == 'a=b&c=d%2B'
    assert unicode_urlencode({'c': 'd+'}, for_qs=True) == 'c=d%2B'
    assert unicode_urlencode(b'+') == '%2B'
    assert unicode_urlencode(b'abcd+') == 'abcd%2B'


# Generated at 2022-06-25 09:23:40.635146
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    boolean_0 = True
    filterModule = FilterModule()
    var_0 = filterModule.filters(boolean_0)


if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:23:42.643484
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'hello') == 'hello'


# Generated at 2022-06-25 09:23:47.084274
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_0 = FilterModule()
    # array value assigned to var_0
    var_0 = [1, 2, 3]
    # Run method filters and get result assigned to var_1
    var_1 = FilterModule.filters(module_0)
    assert var_1 == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:23:50.802615
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)


# Generated at 2022-06-25 09:23:53.582958
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(True) == 'True'
    assert unicode_urldecode(False) == 'False'

# Generated at 2022-06-25 09:24:03.727012
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("Testing") == "%54%65%73%74%69%6e%67"
    assert unicode_urlencode("/Testing") == "/%54%65%73%74%69%6e%67"

    assert unicode_urlencode("Testing", for_qs=True) == "Testing"
    assert unicode_urlencode("/Testing", for_qs=True) == "/Testing"

    assert unicode_urlencode(dict(key="val")) == "key=val"
    assert unicode_urlencode(["key", "val"]) == "key=val"

    assert unicode_urlencode(dict(key="val"), for_qs=True) == "key=val"
    assert unicode_urlencode(["key", "val"], for_qs=True)

# Generated at 2022-06-25 09:24:09.164882
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(unicode_urldecode("")) == ""



# Generated at 2022-06-25 09:24:11.146351
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        assert unicode_urldecode('%EA%B8%80') == '글'
    except AssertionError:
        print('Assertion error raised')


# Generated at 2022-06-25 09:24:16.813639
# Unit test for function do_urlencode
def test_do_urlencode():
    bool_0 = True
    string_0 = 'Testing function urlencode'
    string_1 = 'This is a string'
    string_2 = 'Dąbrowa Górnicza'
    dict_0 = {u'foo': u'bar', u'baz': u'qux'}
    list_0 = ['one', 'two', 'three']
    list_1 = ['Añoranza']
    list_2 = ['Añoranza', 'Astringency']
    list_3 = ['Añoranza', 'Astringency', 'Agnosticisms']
    list_4 = ['Añoranza', 'Astringency', 'Agnosticisms', 'Apalachicola']

# Generated at 2022-06-25 09:24:20.678484
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    var_2 = unicode_urlencode(b'k1=%c2%393&k2=v2', True)
    assert (var_2 == u'k1%3D%25c2%25393%26k2%3Dv2')


# Generated at 2022-06-25 09:24:25.390087
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_0 = FilterModule()
    # Test with true
    bool_0 = True
    var_0 = module_0.filters(bool_0)
    assert do_urldecode(var_0) == do_urldecode(bool_0)

# Generated at 2022-06-25 09:24:30.727444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test for method filters of class FilterModule.
    """
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters == {
        'urldecode': do_urldecode,
    }


# Generated at 2022-06-25 09:24:34.147471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    params = [
        'foo',
        'bar',
        'hello%2Fworld',
        u'hello%2Fworld',
        'baz%2F%2F',
        u'baz%2F%2F',
    ]
    expected = [
        'foo',
        'bar',
        'hello/world',
        'hello/world',
        'baz//',
        'baz//',
    ]
    for param, expected_value in zip(params, expected):
        result = unicode_urldecode(param)
        assert result == expected_value



# Generated at 2022-06-25 09:24:41.495752
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    bool_0 = True
    var_0 = filters['urldecode'](bool_0)
    if not HAS_URLENCODE:
        var_1 = filters['urlencode'](bool_0)



# Generated at 2022-06-25 09:24:42.772377
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_0 = FilterModule.filters(FilterModule, bool_0)


# Generated at 2022-06-25 09:24:45.709460
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'str'
    if PY3:
        assert unquote_plus(string) == unicode_urldecode(string)
    assert to_text(unquote_plus(to_bytes(string))) == unicode_urldecode(string)


# Generated at 2022-06-25 09:24:50.802794
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_string = u"m\xe2\x80\x99"
    byte_string = b"m\xc3\xa2\xe2\x82\xac\xc2\x9d"
    string = "m%C3%A2%E2%82%AC%C2%9D"
    if PY3:
        assert unicode_string == unicode_urldecode(string)
    else:
        assert unicode_string == unicode_urldecode(byte_string)

# Generated at 2022-06-25 09:24:57.425431
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Set 'bool_0' to True
    bool_0 = True
    var_0 = FilterModule()
    var_1 = var_0.filters()
    # The assertion below will throw an error if 'var_1' is pointing to
    # the wrong object.
    assert var_1 == var_0.filters()


# Generated at 2022-06-25 09:25:05.503965
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcd') == 'abcd'
    assert unicode_urldecode('abcde') == 'abcde'
    assert unicode_urldecode('abcdef') == 'abcdef'
    assert unicode_urldecode('abcdefg') == 'abcdefg'
    assert unicode_urldecode('abcdefgh') == 'abcdefgh'
    assert unicode_urldecode('abcdefghi') == 'abcdefghi'
    assert unicode_urldecode('abcdefghij') == 'abcdefghij'
    assert unicode_urldecode('abcdefghijk') == 'abcdefghijk'
    assert unicode_urldecode('abcdefghijkl') == 'abcdefghijkl'
    assert unicode_ur

# Generated at 2022-06-25 09:25:13.353959
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(bool) == do_urlencode(bool)
    assert do_urlencode(int) == do_urlencode(int)
    assert do_urlencode(float) == do_urlencode(float)
    assert do_urlencode(str) == do_urlencode(str)
    assert do_urlencode(unicode) == do_urlencode(unicode)
    assert do_urlencode(dict) == do_urlencode(dict)
    assert do_urlencode(list) == do_urlencode(list)
    assert do_urlencode(set) == do_urlencode(set)
    assert do_urlencode(tuple) == do_urlencode(tuple)


# Generated at 2022-06-25 09:25:15.274003
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'foo' == unicode_urldecode('foo')


# Generated at 2022-06-25 09:25:17.499426
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('"Hi")(, <36>') == '"Hi")(, <36>'


# Generated at 2022-06-25 09:25:21.493322
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    val_0 = 'http://www.example.com/foo/bar'
    expected_0 = 'http%3A//www.example.com/foo/bar'
    result_0 = unicode_urlencode(val_0)
    assert result_0 == expected_0


# Generated at 2022-06-25 09:25:27.300881
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'a%20b%20c' == unicode_urlencode('a b c')


# Generated at 2022-06-25 09:25:38.387606
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:25:41.529598
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    name = 'Elmo'
    assert unicode_urldecode(name) == u'Elmo'


# Generated at 2022-06-25 09:25:45.761409
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = "https://www.github.com/zindilis/karapola-kommon"
    assert(unicode_urlencode(string) == to_text
           ('https%3A//www.github.com/zindilis/karapola-kommon'))


# Generated at 2022-06-25 09:25:52.254866
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print('\n# Unit test for function unicode_urlencode()')
    print('\nExpected output:')
    print('\n---')
    print('Hello+World')
    print('---')
    print('\nActual output:')
    print('\n---')
    print(unicode_urlencode('Hello World'))
    print('---')
    print('\nExpected output:')
    print('\n---')
    print('Hello%2FWorld')
    print('---')
    print('\nActual output:')
    print('\n---')
    print(unicode_urlencode('Hello World', False))
    print('---')
    print('\nExpected output:')
    print('\n---')
    print('Hello%2BWorld')
    print

# Generated at 2022-06-25 09:25:54.153514
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    # Default return type
    assert isinstance(filterModule.filters(), dict)


# Generated at 2022-06-25 09:25:57.814845
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'foo' # $exported_to_globals
    for_qs = True # $exported_to_globals
    expected_result = ''
    result = unicode_urlencode(string, for_qs)
    assert result == expected_result



# Generated at 2022-06-25 09:26:02.477689
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    data = dict([('foo', 'bar'), ('baz', None), ('blong', 123), ('bing', 1.23)])
    url_string = unicode_urlencode(data)
    assert url_string == u'foo=bar&baz&blong=123&bing=1.23', "unicode_urlencode() failed to create correct URL string."


# Generated at 2022-06-25 09:26:07.873134
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    var_0 = FilterModule.filters(bool_0)


# Generated at 2022-06-25 09:26:17.843718
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:26:23.037865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Testing whether var_0 equal to True
    bool_0 = True
    var_0 = var_0
    assert var_0 == True

# Unit test method filters of class FilterModule

# Generated at 2022-06-25 09:26:26.538783
# Unit test for function do_urlencode
def test_do_urlencode():
    string_0 = "JnRg+JnRg"
    var_0 = do_urlencode(string_0)
    string_1 = "JnRg+JnRg"
    assert var_0 == string_1, 'Expected var_0 == string_1'

# Generated at 2022-06-25 09:26:35.419898
# Unit test for function unicode_urlencode

# Generated at 2022-06-25 09:26:36.746782
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_1 = FilterModule()
    var_1.filters()


# Generated at 2022-06-25 09:26:45.117190
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bool_0 = False
    string_0 = unicode_urlencode(bool_0)
    bool_1 = True
    string_1 = unicode_urlencode(bool_1)
    bool_2 = False
    string_2 = unicode_urlencode(bool_2)
    bool_3 = True
    string_3 = unicode_urlencode(bool_3)
    bool_4 = False
    string_4 = unicode_urlencode(bool_4)
    bool_5 = True
    string_5 = unicode_urlencode(bool_5)
    bool_6 = False
    string_6 = unicode_urlencode(bool_6)
    bool_7 = True
    string_7 = unicode_urlencode(bool_7)
    bool_8 = False


# Generated at 2022-06-25 09:26:47.000633
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(string='abcd efgh') == 'abcd%20efgh', u"Failed unit test for function unicode_urlencode"


# Generated at 2022-06-25 09:26:48.748380
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_1 = True
    result_0 = unicode_urldecode(bool_1)
    assert (result_0 == bool_1)


# Generated at 2022-06-25 09:26:49.919034
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)


# Generated at 2022-06-25 09:26:59.199783
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Asserts that the returns of urlencode/urldecode are right
    # We have different functionality in Python 2 and 3, so we test both
    auto_var_1 = PY3
    if (auto_var_1 is True):
        pass
    elif (auto_var_1 is False):
        pass
    else:
        raise Exception('Test Failed')

    auto_var_2 = not PY3
    if (auto_var_2 is True):
        pass
    elif (auto_var_2 is False):
        pass
    else:
        raise Exception('Test Failed')

    filters = FilterModule.filters(FilterModule())
    var_2 = u'1'
    var_3 = u'1'
    var_0 = filters[u'urlencode'](var_2)
   

# Generated at 2022-06-25 09:27:01.297196
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Invoke filters() with all valid parameter values.
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-25 09:27:14.589008
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test case 0
    bool_0 = True
    var_0 = do_urlencode(bool_0)
    # Test case 1
    dict_0 = {}
    var_0 = do_urlencode(dict_0)
    # Test case 2
    var_1 = {}
    var_0 = do_urlencode(var_1)
    # Test case 3
    var_0 = do_urlencode(dict_0)
    # Test case 4
    dict_0 = {'key1': 'value1'}
    var_0 = do_urlencode(dict_0)
    # Test case 5
    var_1 = {}
    var_0 = do_urlencode(var_1)
    # Test case 6
    var_0 = do_urlencode(dict_0)
   

# Generated at 2022-06-25 09:27:18.628388
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bool_0 = True
    var_0 = unicode_urlencode(bool_0)
    bool_0 = True
    var_1 = unicode_urlencode(bool_0, for_qs=True)
    str_0 = 'True'
    var_2 = unicode_urlencode(str_0)
    str_0 = 'True'
    var_3 = unicode_urlencode(str_0, for_qs=True)
    str_0 = '1'
    var_4 = unicode_urlencode(str_0)
    str_0 = '1'
    var_5 = unicode_urlencode(str_0, for_qs=True)
    str_0 = '1.2'
    var_6 = unicode_urlencode(str_0)
   

# Generated at 2022-06-25 09:27:19.314015
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(var_0) != None


# Generated at 2022-06-25 09:27:19.878102
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print(unicode_urldecode(None))


# Generated at 2022-06-25 09:27:22.056257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)


# Generated at 2022-06-25 09:27:27.422042
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # String with spaces
    assert unicode_urldecode('dag%20wieers') == 'dag wieers'

    # String with special characters
    assert unicode_urldecode('dag%20wieers%26%26') == 'dag wieers&&'

    # Encoded string
    assert unicode_urldecode('%C4%B1') == 'ı'


# Generated at 2022-06-25 09:27:31.153976
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'string'
    var_0 = unicode_urldecode(string)
    assert type(var_0) is str
    assert var_0 == string


# Generated at 2022-06-25 09:27:35.201165
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    bool_1 = True
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.filters()
    bool_2 = bool_1 if bool_0 else bool_1
    assert (var_0 == bool_0)


# Generated at 2022-06-25 09:27:37.894302
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_str = 'foo'
    assert unicode_urldecode(test_str) == 'foo'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:27:43.033016
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = True
    for_qs = True
    assert unicode_urlencode(string, for_qs) == 'True'


# Generated at 2022-06-25 09:27:48.403272
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)


# Generated at 2022-06-25 09:27:51.081422
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(string='bob') == 'bob'


# Generated at 2022-06-25 09:27:55.464667
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bool_0 = True
    var_0 = unicode_urldecode(bool_0)


# Generated at 2022-06-25 09:28:02.873297
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Get a reference to the FilterModule class

    filters = FilterModule.filters(FilterModule)
    if not isinstance(filters, dict):
        raise AssertionError(
            "Return value of FilterModule.filters(FilterModule) should be of type dict"
        )


# Generated at 2022-06-25 09:28:05.790072
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'één'
    result = '%C3%A9%C3%A9n'
    assert unicode_urlencode(string) == result


# Generated at 2022-06-25 09:28:09.116036
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert filters.filters() is not None

# Generated at 2022-06-25 09:28:20.680249
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    i = FilterModule()
    assert not False, "Failed to instantiate FilterModule filter."
    assert not False, "Failed to filter FilterModule filter."
    

# Testing method do_urldecode
# Call with args: true
# Call with args: false
# Call with args: true
# Call with args: false
# Call with args: true
# Call with args: false
# Call with args: true
# Call with args: false
# Call with args: true
# Call with args: false
# Call with args: true
# Call with args: false
# Call with args: true
# Call with args: false
# Call with args: /root/.ansible/tmp/ansible-tmp-1474683771.1-226310605815348/command
# Call with args: /root/.ansible/tmp/ans

# Generated at 2022-06-25 09:28:24.477308
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ("1", "1"),
        ("", ""),
    ]
    for test_case in test_cases:
        input, expected = test_case
        actual = unicode_urldecode(input)
        assert actual == expected, f"actual: {actual}, expected: {expected}"


# Generated at 2022-06-25 09:28:33.245495
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Check the python3 version first
    if sys.version_info[0] == 3:
        result = unicode_urldecode("c3RyaW5n")
        assert result == "string"
        result = unicode_urldecode("c3RyaW5n")
        assert result == "string"
        result = unicode_urldecode("c3RyaW5n")
        assert result == "string"
    # Check the python2.7 version next
    else:
        result = unicode_urldecode("c3RyaW5n")
        assert result == "string"
        result = unicode_urldecode("c3RyaW5n")
        assert result == "string"
        result = unicode_urldecode("c3RyaW5n")
       

# Generated at 2022-06-25 09:28:35.605911
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fwww.google.com') == 'https://www.google.com'


# Generated at 2022-06-25 09:28:41.265101
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'foo+bar'
    assert unicode_urldecode(string) == 'foo bar'


# Generated at 2022-06-25 09:28:44.798111
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "%E9%A9%AC"
    # Test if our custom unicode_urldecode has the same result as Jinja2's urlencode
    assert unicode_urldecode(string) == do_urlencode(string)
    assert True == do_urldecode(string)


# Generated at 2022-06-25 09:28:52.622266
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    arg_0 = None
    assert unicode_urldecode(arg_0) == None

    arg_0 = '\u0026'
    assert unicode_urldecode(arg_0) == '&'

    arg_0 = ' '
    assert unicode_urldecode(arg_0) == ' '

    arg_0 = '\u0026\u0026\u0026'
    assert unicode_urldecode(arg_0) == '&&&'



# Generated at 2022-06-25 09:28:56.005025
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    result = unicode_urlencode('?')
    assert result == '?'


# Generated at 2022-06-25 09:29:00.599517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bool_0 = True
    bool_1 = False
    bool_2 = True

    # Test cases
    assert do_urldecode(bool_2) == "True"
    assert do_urldecode(bool_1) == "False"
    assert do_urldecode(bool_0) == "True"

# Generated at 2022-06-25 09:29:05.540216
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = u'some string'
    result = unicode_urlencode(value)
    assert result == u'some%20string'


# Generated at 2022-06-25 09:29:06.435046
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:29:09.372238
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'var_0') == u'var_0'
    assert unicode_urldecode(u'var_1') == u'var_1'


# Generated at 2022-06-25 09:29:11.851867
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # assert(callable(FilterModule.filters())) == True
    pass


# Generated at 2022-06-25 09:29:17.233482
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a") == "a", "False result from unicode_urldecode"
    assert unicode_urldecode("%2F") == "/", "False result from unicode_urldecode"
    assert unicode_urldecode("a%2F") == "a/", "False result from unicode_urldecode"
    assert unicode_urldecode(test_case_0) == "true"

# Generated at 2022-06-25 09:29:23.630616
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert(filters.get('urldecode') is not None)
    assert(filters.get('urlencode') is not None)


# Generated at 2022-06-25 09:29:28.533821
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('1') == '1'
    assert unicode_urldecode(u'1') == u'1'
    assert unicode_urldecode(u'1') == u'1'
    assert unicode_urldecode(u'1') == u'1'
    assert unicode_urldecode(1) == '1'



# Generated at 2022-06-25 09:29:30.177437
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('aGVsbG8gd29ybGQ=') == 'hello world'


# Generated at 2022-06-25 09:29:32.188271
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Call function
    result = unicode_urldecode('ABCDEF')

    # Test result
    assert result == 'ABCDEF'


# Generated at 2022-06-25 09:29:33.330120
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'


# Generated at 2022-06-25 09:29:39.372058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert do_urldecode('abcd') == u'abcd'
    assert do_urldecode('%25') == u'%'
    assert do_urldecode('%2A') == u'*'
    assert do_urldecode('%2B') == u'+'
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%3F') == u'?'
    assert do_urldecode('%5F') == u'_'
    assert do_urldecode('%7E') == u'~'

# Generated at 2022-06-25 09:29:41.419602
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = 'a'
    for_qs = True
    assert  unicode_urlencode(value, for_qs) == 'a'


# Generated at 2022-06-25 09:29:44.231782
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()
    filters['urldecode'](True)
    filters['urldecode'](False)
    filters['urlencode'](True)
    filters['urlencode'](False)
    filters['urlencode']([])
    filters['urlencode']({})


# Generated at 2022-06-25 09:29:45.531035
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    assert filter_module.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:29:46.684821
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
