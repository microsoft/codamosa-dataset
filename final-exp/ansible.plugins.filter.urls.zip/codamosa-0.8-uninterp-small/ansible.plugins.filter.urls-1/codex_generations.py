

# Generated at 2022-06-25 09:19:52.365735
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'


# Generated at 2022-06-25 09:20:01.543553
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    sample_0 = '/'
    sample_1 = ':'
    sample_2 = 'B'
    sample_3 = 'D'
    sample_4 = '/'
    sample_5 = 'E'
    sample_6 = '/'
    sample_7 = 'E'
    sample_8 = 'E'
    sample_9 = '%'
    sample_10 = 'E'

    try:
        test_case_0()
    except (TypeError, ValueError) as e:
        print('Exception: {}'.format(e))
    else:
        print('Code Value: {}'.format(var_0))

    var_0 = unicode_urldecode(sample_0)
    var_1 = unicode_urldecode(sample_1)
    var_2 = unicode_urldecode

# Generated at 2022-06-25 09:20:12.929320
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule()

    # Test case parameter: list_0
    list_0 = []
    # Test case parameter: var_0
    var_0 = do_urlencode(list_0)

    # Test case parameter: dict_0
    dict_0 = {}
    # Test case parameter: var_1
    var_1 = do_urlencode(dict_0)

    # Test case parameter: dict_1
    dict_1 = {
        'foo': 1,
        'bar': 2,
    }
    # Test case parameter: var_2
    var_2 = do_urlencode(dict_1)

    # Test case parameter: dict_2
    dict_2 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    # Test case parameter

# Generated at 2022-06-25 09:20:19.314436
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    list_0 = []
    var_0 = unicode_urlencode(list_0)
    list_1 = []
    var_1 = unicode_urlencode(list_1, for_qs=True)


# Generated at 2022-06-25 09:20:22.697042
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    input_str = "Hello"
    output = unicode_urldecode(input_str)
    assert output == "Hello"


# Generated at 2022-06-25 09:20:26.185884
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    list_0 = []
    assert unicode_urldecode(list_0) == ''
    list_1 = {}
    assert unicode_urldecode(list_1) == '{}'


# Generated at 2022-06-25 09:20:34.983835
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_text

    assert unicode_urlencode("abc") == "abc"
    assert unicode_urlencode("a b c") == "a+b+c"
    assert unicode_urlencode("a+b+c") == "a%2Bb%2Bc"
    assert unicode_urlencode("a%20b%20c") == "a%20b%20c"
    assert unicode_urlencode("/") == "%2F"
    assert unicode_urlencode("/", for_qs=True) == "%2F"
    assert unicode_urlencode("abc", for_qs=True) == "abc"
    assert unicode_urlencode("a b c", for_qs=True) == "a+b+c"


# Generated at 2022-06-25 09:20:45.962219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    # Test 1: Ensure filters is a dictionary
    filters = filter_module.filters()
    assert isinstance(filters, list)


# Generated at 2022-06-25 09:20:51.590476
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = 'hello World!'
    var_0 = unicode_urlencode(string)

    # Test of code
    assert var_0 == 'hello%20World%21'


# Generated at 2022-06-25 09:20:52.589425
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode(u'Hello World!')) == u'Hello%20World!'


# Generated at 2022-06-25 09:20:55.961283
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    arg_0 = 'string'
    res_0 = unicode_urldecode(arg_0)
    assert res_0 == 'string'


# Generated at 2022-06-25 09:20:57.119523
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    list_0 =[]
    var_0 = unicode_urldecode(list_0)


# Generated at 2022-06-25 09:21:07.765902
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%D7%9C') == u'\xd7\x9c'
    assert unicode_urldecode('%D7%9C') == u'\xd7\x9c'
    assert unicode_urldecode('%D7%9C') == '\xd7\x9c'
    assert unicode_urldecode('%C3%BC') == u'\xc3\xbc'
    assert unicode_urldecode('%C3%BC') == u'\xc3\xbc'

# Generated at 2022-06-25 09:21:09.280339
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass


# Generated at 2022-06-25 09:21:11.219387
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    list_0 = []
    var_0 = unicode_urlencode(list_0)


# Generated at 2022-06-25 09:21:15.520709
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test case for method filters
    # Test case for:
    #     def filters(self):
    list_0 = []
    FilterModule_inst_0 = FilterModule()
    var_0 = FilterModule_inst_0.filters()


# Generated at 2022-06-25 09:21:23.667623
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("") == "%E2%98%83"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"
    assert unicode_urlencode("abcd") == "abcd"

# Generated at 2022-06-25 09:21:24.821804
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'


# Generated at 2022-06-25 09:21:28.301556
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("c%40dagwieers.com") == "c@dagwieers.com"


# Generated at 2022-06-25 09:21:31.960326
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    list_0 = []
    var_1 = unicode_urlencode(list_0)


# Generated at 2022-06-25 09:21:40.343557
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ##
    # Test with basic string
    assert 'Bär' == unicode_urldecode('B%C3%A4r')
    ##
    # Test with multiple encoded strings
    assert 'Bärs and ünicörns!' == unicode_urldecode('B%C3%A4rs+and+%C3%BCnic%C3%B6rns!')
    assert 'Bärs and ünicörns!' == unicode_urldecode('B%C3%A4rs%20and%20%C3%BCnic%C3%B6rns!')
    assert 'Bärs and ünicörns!' == unicode_urldecode('B%C3%A4rs+and%20%C3%BCnic%C3%B6rns!')

# Generated at 2022-06-25 09:21:49.695053
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        assert(unicode_urldecode("aaaa") == "aaaa")
        assert(unicode_urldecode("%3A") == ":")
        assert(unicode_urldecode("%3a") == ":")
    except AssertionError:
        print("AssertionError")
    try:
        assert(unicode_urldecode("%3A") == ":")
    except AssertionError:
        print("AssertionError")
    try:
        assert(unicode_urldecode("%3a") == ":")
    except AssertionError:
        print("AssertionError")


# Generated at 2022-06-25 09:21:53.779562
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    var_0 = unicode_urldecode(dict_0)
    var_1 = unicode_urldecode(dict_1)
    var_2 = unicode_urldecode(dict_2)
    var_3 = unicode_urldecode(dict_3)


# Generated at 2022-06-25 09:21:54.891809
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_object = FilterModule()
    assert(isinstance(filter_object.filters(), dict))

# Generated at 2022-06-25 09:21:56.035834
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-25 09:21:58.913421
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    dict_0 = {'a': 'b', 'c': 'd'}
    var_0 = unicode_urlencode(dict_0, True)
    print(var_0)



# Generated at 2022-06-25 09:22:01.397868
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo bar') == u'foo+bar'



# Generated at 2022-06-25 09:22:08.026978
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("============================================")
    # Test PY3=False, python2
    PY3 = False
    dict_0 = "%7B%22_ansible_parsed%22%3Atrue%2C%22_ansible_deleted_items%22%3A%5B%5D%2C%22_ansible_no_log%22%3Afalse%2C%22_ansible_item_result%22%3Atrue%2C%22_ansible_ignore_errors%22%3Afalse%2C%22_ansible_verbose_always%22%3Afalse%2C%22_ansible_no_log_response%22%3Afalse%2C%22changed%22%3Afalse%7D"

# Generated at 2022-06-25 09:22:15.485744
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    str_0 = "abcd"
    str_1 = "abcd"
    var_0 = FilterModule().filters()
    assert var_0["urldecode"](dict_0) == var_0["urldecode"](dict_0)
    assert var_0["urldecode"](str_0) == var_0["urldecode"](str_1)

# Generated at 2022-06-25 09:22:22.854614
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)
    # Verify the contents of 'filters'
    assert "_text" in filters
    assert "json_query" in filters
    assert "urlencode" in filters
    assert "yaml" in filters
    assert "quote" in filters
    assert "to_datetime" in filters
    assert "to_nice_yaml" in filters
    assert "to_nice_json" in filters
    assert "selectattr" in filters
    assert "to_uuid" in filters
    assert "to_yaml" in filters
    assert "to_json" in filters
    assert "map" in filters
    assert "to_csv" in filters
    assert "random" in filters
    assert "to_nice_size" in filters
    assert "to_nice_timedelta" in filters
   

# Generated at 2022-06-25 09:22:27.463289
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    var_0 = FilterModule.filters(dict_0)


# Generated at 2022-06-25 09:22:30.770505
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'dag wieers' == unicode_urldecode('dag+wieers'), 'String not returned as expected'


# Generated at 2022-06-25 09:22:38.336156
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert do_urldecode(None) is None
    assert unicode_urldecode({}) is not None
    assert unicode_urldecode({}) == {}
    assert unicode_urldecode({}) is not None
    assert unicode_urldecode({}) == {}
    assert unicode_urldecode({}, True) is not None
    assert unicode_urldecode({}, True) == {}
    assert unicode_urldecode({}, False) is not None
    assert unicode_urldecode({}, False) == {}
    assert unicode_urldecode({}, 1) is not None
    assert unicode_urldecode({}, 1) == {}
    assert unicode_urldecode({}, 1.0) is not None
    assert unicode_urldecode

# Generated at 2022-06-25 09:22:44.799459
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%20') == '%20'
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%23') == '#'
    assert unicode_urldecode('%24') == '$'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%5E') == '^'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%28') == '('
    assert unicode_urldecode('%29') == ')'
    assert unic

# Generated at 2022-06-25 09:22:48.104471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2Fvar%2Fwww%2Fhtml") == "/var/www/html"


# Generated at 2022-06-25 09:22:50.187496
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode == do_urldecode


# Generated at 2022-06-25 09:22:52.623074
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = b"Something%20with%20encoded%20characters"
    string = to_bytes(string)
    assert unicode_urldecode(string) == "Something with encoded characters"


# Generated at 2022-06-25 09:22:54.381197
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.ansible.com') == 'http%3A//www.ansible.com'


# Generated at 2022-06-25 09:23:03.492858
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print("Testing function unicode_urlencode")
    assert unicode_urlencode("%5B%25%2B%5D") == "%5B%25%2B%5D"
    assert unicode_urlencode("foo+bar") == "foo+bar"
    assert unicode_urlencode("%5B%25%2B%5D", True) == "%5B%25%2B%5D"
    assert unicode_urlencode("foo+bar") == "foo+bar"
    assert unicode_urlencode("foo bar") == "foo%20bar"
    assert unicode_urlencode("%5B%25%2B%5D", False) == "%5B%25%2B%5D"

# Generated at 2022-06-25 09:23:09.081982
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'{"a": "b", "c": "d"}') == '{"a": "b", "c": "d"}'


# Generated at 2022-06-25 09:23:17.455287
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd') == 'abcd'
    assert unicode_urlencode('abcd', True) == 'abcd'
    assert unicode_urlencode('ab%3Acd') == 'ab%3Acd'
    assert unicode_urlencode('ab%3Acd', True) == 'ab%253Acd'



# Generated at 2022-06-25 09:23:25.563167
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == b'%2F'
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('') == b''
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == b'%20'
    assert unicode_urlencode('  ') == '%20%20'
    assert unicode_urlencode('  ') == b'%20%20'
    assert unicode_urlencode('a') == 'a'
    assert unicode_urlencode('a') == b'a'
    assert unicode_urlencode('/a') == '%2Fa'

# Generated at 2022-06-25 09:23:32.323303
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("abc-123") == "abc-123"
    assert unicode_urldecode("abc%2d123") == "abc-123"
    assert unicode_urldecode("abc%0a123") == "abc\n123"
    assert unicode_urldecode("abc%0a123") == "abc\n123"
    assert unicode_urldecode("%00%00%00") == "\x00\x00\x00"
    assert unicode_urldecode("%3A") == ":"
    assert unicode_urldecode("%3a") == ":"
    assert unicode_urldecode("%2A") == "*"
    assert unicode_urldecode("%2a") == "*"

# Unit test

# Generated at 2022-06-25 09:23:36.561078
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'foo') == 'foo'
    assert unicode_urlencode(42) == '42'
    assert unicode_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert unicode_urlencode([('foo', 'bar'), ('baz', 'quux')]) == 'foo=bar&baz=quux'


# Generated at 2022-06-25 09:23:44.917471
# Unit test for function do_urlencode
def test_do_urlencode():
    var_0 = b'\x91\x9b\xe4\xbc\xb4\xd0\x8b\xcd\x98\xde\x8b\xcc\x81\xdf\x97\xd0\xa7\xcc\x81\xd0\x8b\xae&%2f*%2d'
    var_1 = do_urlencode(var_0)

# Generated at 2022-06-25 09:23:47.548726
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'a+a=b'
    assert(unicode_urldecode(string) == 'a a=b')

# Generated at 2022-06-25 09:23:49.806776
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Fb') == u'a/b'


# Generated at 2022-06-25 09:23:53.410247
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'fake_string'
    expected_result1 = 'fake_string'
    returned_result1 = unicode_urldecode(string)
    assert returned_result1 == expected_result1



# Generated at 2022-06-25 09:23:56.113571
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    var_0 = FilterModule().filters()


# Generated at 2022-06-25 09:24:02.524373
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Create object 'dict_0'
    dict_0 = {}
    # AssertionError: Got {}
    assert var_0 == dict_0, 'AssertionError: {} != {}'.format(var_0, dict_0)


# Generated at 2022-06-25 09:24:12.325116
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # test 1
    string = 'foobar'
    result = unicode_urlencode(string)
    assert result == 'foobar'
    # test 2
    string = 'spam & eggs'
    for_qs = True
    result = unicode_urlencode(string, for_qs)
    assert result == 'spam%20%26%20eggs'
    # test 3
    string = 'spam & eggs'
    for_qs = False
    result = unicode_urlencode(string, for_qs)
    assert result == 'spam%20%26%20eggs'
    # test 4
    string = 'spam & eggs'
    for_qs = 'should_be_bool'
    result = unicode_urlencode(string, for_qs)

# Generated at 2022-06-25 09:24:15.801943
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'a b + c' == unicode_urldecode(u'a+b+%2B+c')


# Generated at 2022-06-25 09:24:18.634867
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    item_0 = 'Encoding'
    var_0 = unicode_urldecode(item_0)
    assert var_0 == 'Encoding'



# Generated at 2022-06-25 09:24:19.942599
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()

# Generated at 2022-06-25 09:24:24.729237
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {
        'a_key': 'a_value',
        'another_key': 'another_value',
        'a_third_key': 'a_third_value',
    }
    obj_0 = FilterModule()
    var_0 = obj_0.filters()
    ret_0 = var_0.values()
    var_1 = obj_0.filters()
    ret_0 = var_0.values()
    ret_1 = var_1.values()


# Generated at 2022-06-25 09:24:28.888885
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    var_0 = FilterModule.filters(dict_0)


# Generated at 2022-06-25 09:24:36.684381
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ('fO% bar=baz baz', 'fO% bar=baz baz'),
        ('%3C%3E%26%22%27%C3%BF', '<>&""\'\xff'),
        ('%3C%3E%26%22%27%C3%BF', '<>&""\'\xff'),
    ]
    for tc in test_cases:
        assert unicode_urldecode(tc[0]) == tc[1]


# Generated at 2022-06-25 09:24:42.466092
# Unit test for function do_urlencode
def test_do_urlencode():
    str = "hello,world"
    assert do_urlencode(str) == 'hello,world'


# Generated at 2022-06-25 09:24:44.214350
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    filters_0 = FilterModule().filters()
    var_1 = filters_0.get('urldecode')(dict_0)


# Generated at 2022-06-25 09:24:47.549565
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    var_3 = filter_module_0.filters()

# Generated at 2022-06-25 09:24:56.814052
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo%2Bbar') == 'foo%252Bbar'
    assert unicode_urlencode('foo%bar') == 'foo%25bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo?bar') == 'foo?bar'
    assert unicode_urlencode('') == ''
    assert unicode_urlencode(None) == ''
    assert unicode_urlencode([]) == u''
    assert unicode_urlencode(u'')

# Generated at 2022-06-25 09:25:00.809930
# Unit test for function do_urlencode
def test_do_urlencode():
    # should work for string input
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    # should work for list input
    assert unicode_urlencode(['foo', 'bar']) == u'foo&bar'
    # should work for dict input
    assert unicode_urlencode({'foo': 'bar'}) == u'foo=bar'
    # should work for string input with for_qs=True
    assert unicode_urlencode(u'foo bar', True) == u'foo+bar'
    # should work for list input with for_qs=True
    assert unicode_urlencode(['foo', 'bar'], True) == u'foo&bar'
    # should work for dict input with for_qs=True

# Generated at 2022-06-25 09:25:08.622942
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('eHBsYXk=') == 'play'
    #assert unicode_urldecode('%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F') == '??????????????????????'
    #assert unicode_urldecode('%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F%3F') == '??????????????????????

# Generated at 2022-06-25 09:25:09.734147
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # This should not cause a crash, at least
    test_case_0()

# Generated at 2022-06-25 09:25:11.390260
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    cases = []
    case_0 = FilterModule().filters()
    cases.append(case_0)
    return cases



# Generated at 2022-06-25 09:25:13.534763
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No parameters
    # Attempt to return a user-defined method of the argument
    assert 'urldecode' in FilterModule.filters(None)


# Generated at 2022-06-25 09:25:15.274270
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert utf8_urlencode('foo') == 'foo'


# Generated at 2022-06-25 09:25:16.888920
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print(unicode_urldecode())


# Generated at 2022-06-25 09:25:20.532113
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Setup
    string = None

    # Invocation
    result = unicode_urldecode(string)

    # Verification
    assert result == None


# Generated at 2022-06-25 09:25:24.945206
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar baz') == 'foo+bar+baz'
    assert unicode_urlencode('foo bar baz', for_qs=True) == 'foo+bar+baz'
    assert unicode_urlencode('foo/bar/baz') == 'foo%2Fbar%2Fbaz'


# Generated at 2022-06-25 09:25:39.195894
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    #var_0 = unicode_urlencode('a')
    unicode_urlencode('a')
    #var_0 = unicode_urlencode('ab')
    unicode_urlencode('ab')
    #var_0 = unicode_urlencode('abc')
    unicode_urlencode('abc')
    #var_0 = unicode_urlencode('abcd')
    unicode_urlencode('abcd')
    #var_0 = unicode_urlencode('abcde')
    unicode_urlencode('abcde')
    #var_0 = unicode_urlencode('abcdef')
    unicode_urlencode('abcdef')
    #var_0 = unicode_urlencode('abcdefg')
    unicode_urlencode('abcdefg')


# Generated at 2022-06-25 09:25:40.542140
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a') == 'a'


# Generated at 2022-06-25 09:25:49.365052
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:25:59.159932
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/') == 'http%3A//example.com/'
    assert unicode_urlencode({'a': 1, 'b': 2}) == 'a=1&b=2'
    assert unicode_urlencode(['a=1', 'b=2']) == 'a%3D1&b%3D2'
    assert unicode_urlencode('/path/sub?a=1') == '%2Fpath%2Fsub%3Fa=1'
    assert unicode_urlencode('/path/sub?a=1', for_qs=True) == '%2Fpath%2Fsub%3Fa%3D1'

# Generated at 2022-06-25 09:26:04.597577
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    module = AnsibleModule(
        argument_spec = dict(
            string = dict(type='str'),
            for_qs = dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    # set up state
    string = module.params['string']
    for_qs = module.params['for_qs']
    # execute function
    result = unicode_urlencode(string, for_qs)

    assert isinstance(result, str)
    assert result == str_ref


# Generated at 2022-06-25 09:26:08.349922
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_object = FilterModule()
    dict_0 = {}
    var_0 = filter_object.filters()


# Generated at 2022-06-25 09:26:10.764907
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("Hello World", True) == "%20Hello%20World"
    assert unicode_urlencode("/home/user/relative/path") == "/home/user/relative/path"
    assert unicode_urlencode("/home/user/relative/path", True) == "%20/home/user/relative/path"


# Generated at 2022-06-25 09:26:14.443842
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = unicode_urldecode('%26')
    var_2 = unicode_urldecode('%26%')



# Generated at 2022-06-25 09:26:16.613888
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.filters()


# Generated at 2022-06-25 09:26:18.453524
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'enco%c3%b1ado') == u'enco\xf1ado'


# Generated at 2022-06-25 09:26:29.702004
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlen

# Generated at 2022-06-25 09:26:41.286580
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    #assert unicode_urlencode.__doc__ == ''
    str_0 = to_text(unquote_plus(to_bytes('f7b56336a0a05a34d8b8af9edf7439b0')))
    assert unicode_urlencode(str_0) == u'f7b56336a0a05a34d8b8af9edf7439b0'
    str_1 = u'{% extends "{0}" %}'.format(to_text(unquote_plus(to_bytes('f79bfbfbfa41eab3a86fba919ece95f0'))))

# Generated at 2022-06-25 09:26:42.765882
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    var_0 = FilterModule.filters(dict_0)


# Generated at 2022-06-25 09:26:44.989109
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:26:47.669316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Initialize test
    test = FilterModule()
    # Perform test
    result = test.filters()
    # Verify test

# Generated at 2022-06-25 09:26:56.185152
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('GET') == "GET"
    assert do_urlencode('/etc/ansible/hosts') == "%2Fetc%2Fansible%2Fhosts"
    assert do_urlencode('%2Fetc%2Fansible%2Fhosts') == "GET"
    assert do_urlencode('GET') == b"GET"
    assert do_urlencode('/etc/ansible/hosts') == b"%2Fetc%2Fansible%2Fhosts"
    assert do_urlencode('%2Fetc%2Fansible%2Fhosts') == b"GET"
    assert do_urlencode('GET') == u"GET"

# Generated at 2022-06-25 09:26:57.708145
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode({"key": "val"}) == 'val'


# Generated at 2022-06-25 09:27:05.173863
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%28a%2B123') == '(a+123'
    assert unicode_urldecode('A%2BB%2Bc%2B%2B') == 'A+B+c+'
    assert unicode_urldecode('An%20example%20string%20%C3%A9%C3%A9') == 'An example string \xc3\xa9\xc3\xa9'
    assert unicode_urldecode('An%20example%20string%20%C3%A9%C3%A9') == 'An example string \xc3\xa9\xc3\xa9'

# Generated at 2022-06-25 09:27:12.152369
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = unicode_urldecode('name')
    assert var_1 == 'name'
    var_2 = unicode_urldecode('a%20b%20c')
    assert var_2 == 'a b c'
    var_3 = unicode_urldecode('a%2Fb%2Fc')
    assert var_3 == 'a/b/c'


# Generated at 2022-06-25 09:27:15.641972
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello+world') == u'hello world'


# Generated at 2022-06-25 09:27:19.219088
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_FilterModule_filters_0()


# Generated at 2022-06-25 09:27:20.453241
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {"type": "string"}
    inst_0 = FilterModule()
    str_0 = inst_0.filters()
    boolean_0 = str_0 == dict_0

# Generated at 2022-06-25 09:27:31.154026
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u"" == unicode_urlencode(u"")
    assert u"%3A%3D" == unicode_urlencode(u":=")
    assert u"%3A%3D" == unicode_urlencode(u":=")
    assert u"%3A%3D" == unicode_urlencode(u":=", True)
    assert u"%3A%3D" == unicode_urlencode(u":=", True)
    assert u"%3A%3D" == unicode_urlencode(u":=", True)
    assert u"%3A%3D" == unicode_urlencode(u":=", True)
    assert u"%3A%3D" == unicode_urlencode(u":=", True)


# Generated at 2022-06-25 09:27:39.774541
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    dict_1 = {}
    FilterModule_filter = FilterModule(dict_0, dict_1)
    # Variation 1
    var_1 = FilterModule_filter.filters()
    # Variation 2
    var_2 = FilterModule_filter.filters()
    # Variation 3
    dict_0 = {}
    dict_1 = {}
    FilterModule_filter = FilterModule(dict_0, dict_1)
    var_3 = FilterModule_filter.filters()
    # Variation 4
    dict_0 = {}
    dict_1 = {}
    FilterModule_filter = FilterModule(dict_0, dict_1)
    var_4 = FilterModule_filter.filters()


# Generated at 2022-06-25 09:27:45.114439
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    var_0 = FilterModule().filters()

if __name__ == "__main__":
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:27:48.452302
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    dict_0 = {}
    var_0 = unicode_urldecode(dict_0)


# Generated at 2022-06-25 09:27:52.634922
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc+def') == 'abc+def'


# Generated at 2022-06-25 09:27:58.105712
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test with all unicode string
    assert "abcd" == unicode_urldecode("abcd")

    # Test with all non unicode string
    # This will fail when running for python 2 as str type does not have decode method
    #assert b"abcd" == unicode_urldecode(b"abcd")


# Generated at 2022-06-25 09:28:03.050358
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    # TEST CASE:
    # test if unicode_urlencode returns string if not a string or list and isinstance(value, string_types)
    var_0 = 'spam'
    var_0 = unicode_urlencode(var_0)
    assert(var_0 == 'spam')

# Generated at 2022-06-25 09:28:05.712748
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a+%c3%b6+c') == u'a ö c'


# Generated at 2022-06-25 09:28:20.452316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus, unquote_plus
    from ansible.module_utils._text import to_bytes, to_text
    if PY3:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    else:
        HAS_URLENCODE = False
    class TestFilterModule(object):
        ''' An class used for testing FilterModule class
        '''
        def filters(self):
            return {'urldecode': do_urldecode}
    object_0 = TestFilterModule()
    var_0 = object_0.filters()
    assert 'urldecode' in var_0

# Generated at 2022-06-25 09:28:21.718381
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    var_0 = unicode_urlencode('"\'&')


# Generated at 2022-06-25 09:28:25.209057
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    parsed_0 = unicode_urldecode('a string')
    assert parsed_0 == 'a string'


# Generated at 2022-06-25 09:28:26.160408
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fuzzy_0 = FilterModule()
    var_0 = fuzzy_0.filters()


# Generated at 2022-06-25 09:28:29.233542
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    input_0 = 'mp4'
    expected_0 = 'mp4'
    result_0 = unicode_urlencode(input_0)
    # Assert
    assert result_0 == expected_0


# Generated at 2022-06-25 09:28:34.076146
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Do not use pytest fixture
    #p0 = pytest.fixture()
    pass



# Generated at 2022-06-25 09:28:36.173845
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # static_0 = staticmethod(FilterModule().filters)
    static_0 = FilterModule().filters
    static_0()


# Generated at 2022-06-25 09:28:38.956475
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = {}
    var_0 = FilterModule().filters(dict_0)



# Generated at 2022-06-25 09:28:47.913620
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd efgh') == 'abcd%20efgh'
    assert unicode_urlencode(u'abcd efgh') == 'abcd%20efgh'
    assert unicode_urlencode(u'/abcd efgh') == '%2Fabcd%20efgh'
    assert unicode_urlencode(u'abcd efgh/') == 'abcd%20efgh%2F'
    assert unicode_urlencode(u'abcd efgh/?') == 'abcd%20efgh%2F%3F'
    assert unicode_urlencode(u'abcd efgh/', for_qs=True) == 'abcd%20efgh%2F'

# Generated at 2022-06-25 09:28:57.424743
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Assign instance of class 'FilterModule' to 'ansible_FilterModule'
    ansible_FilterModule = FilterModule()
    # Getting the type of 'ansible_FilterModule' (line 33)
    ansible_FilterModule_type_1 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 33, 10), 'ansible_FilterModule')
    
    # Obtaining the type of the subscript
    str_2 = get_builtin_python_type_instance(stypy.reporting.localization.Localization(__file__, 33, 30), 'str', 'urldecode')
    # Getting the type of 'ansible_FilterModule' (line 33)

# Generated at 2022-06-25 09:29:05.247378
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_method = FilterModule().filters()
    filter_method['urldecode']({})

# Generated at 2022-06-25 09:29:08.461766
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # assert unicode_urldecode() == '<return_value>'
    # assert unicode_urldecode() == '<return_value>'
    # assert unicode_urldecode() == '<return_value>'
    # assert unicode_urldecode() == '<return_value>'
    pass


# Generated at 2022-06-25 09:29:12.624655
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    buf = unicode_urldecode("%21")
    assert(buf == '!')
    buf = unicode_urldecode("%3A")
    assert(buf == ':')


# Generated at 2022-06-25 09:29:17.761041
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'a=b') == 'a=b'
    assert unicode_urldecode(b'a=b&c=d') == 'a=b&c=d'
    assert unicode_urldecode('a=b') == 'a=b'
    assert unicode_urldecode('a=b&c=d') == 'a=b&c=d'


# Generated at 2022-06-25 09:29:21.159432
# Unit test for function do_urlencode
def test_do_urlencode():
    dict_0 = {}
    if var_0:
        pass
    elif var_0:
        pass
    elif var_0:
        pass
    else:
        pass

# Generated at 2022-06-25 09:29:24.637944
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(do_urlencode('test')) == 'test'



# Generated at 2022-06-25 09:29:26.913457
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert do_urldecode(do_urlencode(dict_0)) == var_0

# Generated at 2022-06-25 09:29:37.152678
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("| Testing function unicode_urldecode")
    assert unicode_urldecode("%26") == "&"
    assert unicode_urldecode("%22") == "\""
    assert unicode_urldecode("%2B") == "+"
    assert unicode_urldecode("%3D") == "="
    assert unicode_urldecode("%3F") == "?"
    assert unicode_urldecode("%23") == "#"
    assert unicode_urldecode("%25") == "%"
    assert unicode_urldecode("%20") == " "
    assert unicode_urldecode("%2F") == "/"
    assert unicode_urldecode("%5E") == "^"
    assert unicode_ur

# Generated at 2022-06-25 09:29:43.321139
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({"a": 1, "b": 2, "c": 3}) == "a=1&b=2&c=3"
    assert do_urlencode(["test"]) == "test"
    assert do_urlencode("test") == "test"
    assert do_urlencode("http://example.com/?a=b&c=d&e=f") == "http%3A//example.com/?a=b&c=d&e=f"


# Generated at 2022-06-25 09:29:45.869441
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # check the returned value 
    assert unicode_urldecode('') == ''
