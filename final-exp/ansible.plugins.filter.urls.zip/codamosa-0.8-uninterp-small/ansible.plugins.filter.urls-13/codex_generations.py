

# Generated at 2022-06-25 09:19:59.259438
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Check that FilterModule.filters() returns a dict
    assert isinstance(FilterModule.filters, dict)

    #
    # Check that a string can be urlencoded
    #

    uri = 'http://www.example.com/resource?arg1=test&arg2=anothertest'
    assert urlencode(uri) == 'http%3A//www.example.com/resource%3Farg1%3Dtest%26arg2%3Danothertest'

    uri = 'http://www.example.com/path/to/resource/'
    assert unicode_urlencode(uri) == 'http%3A//www.example.com/path/to/resource/'

    uri = 'http://www.example.com/path/to/resource/'

# Generated at 2022-06-25 09:20:01.309968
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F') == '/'


# Generated at 2022-06-25 09:20:03.177196
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_1 = unicode_urldecode("%20")
    assert var_1 == " "


# Generated at 2022-06-25 09:20:05.497257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    var_1 = filter_module_1.filters()

# Generated at 2022-06-25 09:20:11.834124
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    #assert unicode_urldecode(string) == 'string':
    #assert unicode_urldecode(string) == 'string':
    assert True # TODO: implement your test here

###
### Jinja2 Tests
###

import jinja2
import unittest


# Generated at 2022-06-25 09:20:16.353396
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # From jinja2.filters import do_urlencode
    var_0 = FilterModule()
    filters = var_0.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-25 09:20:21.400261
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode']("http%3A%2F%2Fwww.ansible.com%2F") == "http://www.ansible.com/"
    assert filters['urldecode']("%2Fetc%2Fansible") == "/etc/ansible"

# Generated at 2022-06-25 09:20:26.013765
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # User input for param string
    string = '%E4%BD%A0%E5%A5%BD'
    # For param for_qs, need to add a True or False condition
    for_qs = True
    # Call function unicode_urlencode
    unicode_urlencode(string, for_qs)





# Generated at 2022-06-25 09:20:33.480416
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert not unicode_urldecode('')
    assert not unicode_urldecode('/')
    assert unicode_urldecode('/foo') == '/foo'
    assert unicode_urldecode('/foo+bar') == '/foo+bar'
    assert unicode_urldecode('/foo%20bar') == '/foo bar'
    assert unicode_urldecode('/foo%2fbar') == '/foo/bar'
    assert unicode_urldecode('/foo%25bar') == '/foo%bar'
    assert unicode_urldecode('/foo%2Fbar') == '/foo/bar'



# Generated at 2022-06-25 09:20:39.182164
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    unicode_string = u'苏格兰'
    expected_urlencode_string = u'%E8%8B%8F%E6%A0%BC%E5%85%B0'
    actual_urlencode_string = unicode_urlencode(unicode_string)

    assert actual_urlencode_string == expected_urlencode_string



# Generated at 2022-06-25 09:20:43.983547
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_0 = FilterModule.filters(FilterModule)
    var_0 = dict_0.get('urldecode')


# Generated at 2022-06-25 09:20:49.186650
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing Python version ", end="")
    print(sys.version)
    str_0 = ""
    var_0 = unicode_urldecode(str_0)
    print("%s returned: %s" % (str_0, var_0))
    str_0 = " "
    var_0 = unicode_urldecode(str_0)
    print("%s returned: %s" % (str_0, var_0))
    str_0 = "!"
    var_0 = unicode_urldecode(str_0)
    print("%s returned: %s" % (str_0, var_0))
    str_0 = " ! "
    var_0 = unicode_urldecode(str_0)

# Generated at 2022-06-25 09:20:54.047358
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%C3%BC') == u'\xfc'
    assert do_urldecode('%C3%9C') == u'\xdc'
    assert do_urldecode('urlencode:%20') == u'\xfc'
    assert do_urldecode('urlencode:%2520') == u'%20'


# Generated at 2022-06-25 09:21:03.796456
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Testing for bytes
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%2C') == ','
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%23') == '#'
    assert unicode_urldecode('%24') == '$'

# Generated at 2022-06-25 09:21:06.439703
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'abc'
    var_0 = unicode_urlencode(str_0, False)
    str_1 = 'def'
    var_1 = unicode_urlencode(str_1, True)

# Generated at 2022-06-25 09:21:09.465477
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    print(fm.filters())


# Generated at 2022-06-25 09:21:12.100773
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-25 09:21:14.188820
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(' ') == '%20'


# Generated at 2022-06-25 09:21:18.057654
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterMod = FilterModule()
    filterDict = filterMod.filters()
    filterMethod = filterDict.get('urldecode')
    assert filterMethod is not None, "Failed to find filter 'urldecode' in filter dict"

# Generated at 2022-06-25 09:21:24.099120
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # dict input
    dict_input = {"a":1,"b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10,"k":11,"l":12}
    dict_output = u'a=1&b=2&c=3&d=4&e=5&f=6&g=7&h=8&i=9&j=10&k=11&l=12'
    assert unicode_urlencode(dict_input) == dict_output
    assert unicode_urlencode(dict_input, True) == dict_output

    # slice input
    slice_input = slice(0,20)
    slice_output = u'0:20'
    assert unicode_urlencode(slice_input) == slice_

# Generated at 2022-06-25 09:21:32.219064
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # assert str_0 == ???
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%252F') == '%2F'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2525') == '%25'
    assert unicode_urldecode('%252525') == '%2525'
    assert unicode_urldecode('%2525252F') == '%2525%2F'
    assert unicode_urldecode('%252525252F') == '%252525%2F'


# Generated at 2022-06-25 09:21:39.587170
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    # assert var_0 == ' '
    if var_0 != ' ':
        raise AssertionError("var_0 = {0}".format(var_0))
    str_1 = 'a%20b%20%23'
    var_1 = unicode_urldecode(str_1)
    # assert var_1 == 'a b #'
    if var_1 != 'a b #':
        raise AssertionError("var_1 = {0}".format(var_1))
    str_2 = 'foo=bar+baz&x=y'
    var_2 = unicode_urldecode(str_2)
    # assert var_2 == 'foo=bar+

# Generated at 2022-06-25 09:21:42.786798
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '1'
    var = unicode_urlencode(str_0)
    assert var == '1'


# Generated at 2022-06-25 09:21:45.737485
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '%20'
    var_0 = unicode_urlencode(str_0)
    assert var_0 == '%20'


# Generated at 2022-06-25 09:21:53.392707
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == u' '
    str_1 = '%'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == u'%'
    str_2 = '%2'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == u'%2'
    str_3 = '%3'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == u'%3'
    str_4 = '%4'
    var_4 = unicode_urldecode(str_4)
    assert var_4 == u'%4'
    str_

# Generated at 2022-06-25 09:21:55.649838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    b = a.filters()
    print(b)


# Generated at 2022-06-25 09:21:59.654643
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
    assert type(result) == dict
    assert result['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode



# Generated at 2022-06-25 09:22:02.876354
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == b' ', 'Expected %r got %r' % (b' ', var_0)

# Generated at 2022-06-25 09:22:06.962982
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '


# Generated at 2022-06-25 09:22:19.245285
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '%20'
    var_1 = unicode_urldecode(str_1)
    assert ' ' == var_1
    str_2 = '%ED%95%9C%EA%B5%AD%EC%96%B4'
    var_2 = unicode_urldecode(str_2)
    assert '한국어' == var_2
    str_3 = 'https%3A%2F%2Fwww.google.com%2F'
    var_3 = unicode_urldecode(str_3)
    assert 'https://www.google.com/' == var_3
    str_4 = 'foo%20bar'
    var_4 = unicode_urldecode(str_4)

# Generated at 2022-06-25 09:22:25.812965
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()



# Generated at 2022-06-25 09:22:27.950172
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    flt = FilterModule()
    outputs = flt.filters()
    assert outputs['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:22:28.935429
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-25 09:22:35.574485
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    # Test case 0
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)

    filters = fm.filters()
    filters['urldecode'](str_0) == var_0



# Generated at 2022-06-25 09:22:37.813833
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    res = f.filters()
    assert(len(res) > 0)
    for item in res:
        assert(callable(item))


# Generated at 2022-06-25 09:22:39.790073
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_obj = FilterModule()
    method_0 = module_obj.filters()
    assert(method_0 == {'urlencode': do_urlencode, 'urldecode': do_urldecode})


# Generated at 2022-06-25 09:22:51.876019
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    # Check that the filter_module method filters exists
    assert callable(filter_module.filters), "filter_module does not have a filters method"
    # Check that the filter_module method filters returns a dict
    assert isinstance(filters, dict), "filters() method of filter_module should return a dict."
    assert filters['urldecode'], "filters() method of filter_module should return a dict with urldecode key."
    assert callable(filters['urldecode']), "urldecode filter of filter_module should be callable."
    assert filters['urldecode']() == '', "urldecode filter of filter_module should return ''  when no parameter is passed."


# Generated at 2022-06-25 09:23:00.582222
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('Testing 1 2 3') == 'Testing+1+2+3'
    assert unicode_urlencode(u'Testing 1 2 3') == 'Testing+1+2+3'
    assert unicode_urlencode(b'Testing 1 2 3') == 'Testing+1+2+3'
    assert unicode_urlencode({'a': 'b'}) == 'a=b'
    assert unicode_urlencode([('a', 'b'), ('c', 'd')]) == 'a=b&c=d'


# Generated at 2022-06-25 09:23:03.585214
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() is not None


# Generated at 2022-06-25 09:23:09.189092
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert filters.filters() is not None and type(filters.filters()) is dict, 'Method filters is not returning a value.'


# Generated at 2022-06-25 09:23:21.247089
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # check if the function works correctly
    assert(unicode_urldecode('%20') == ' ')
    assert(unicode_urldecode('%E2%82%AC') == '€')

    # check if the function works correctly with non-unicode input
    assert(unicode_urldecode(u'%20') == ' ')
    assert(unicode_urldecode('%20') == u' ')

    # check if the function works correctly if input is not a string
    try:
        unicode_urldecode(1)
    except Exception:
        assert(True)
    else:
        assert(False)

    # check if the function works correctly if input is not an acceptable string

# Generated at 2022-06-25 09:23:24.574097
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:23:29.605936
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule(object)
    assert filters.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

# Generated at 2022-06-25 09:23:31.899506
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = {}
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters is not None


# Generated at 2022-06-25 09:23:32.427484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True

# Generated at 2022-06-25 09:23:42.995344
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:23:44.246570
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    assert {} == filterModule.filters()


# Generated at 2022-06-25 09:23:47.122173
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    #assert('%2B' == unicode_urlencode('+'))
    assert('%2B' == unicode_urlencode('+'))


# Generated at 2022-06-25 09:23:48.493136
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    filters.filters()


# Generated at 2022-06-25 09:23:56.501566
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        assert (' ' == unicode_urldecode('%20'))
    except AssertionError as e:
        raise AssertionError(str(e) + ' At line ' +
                             str(sys._getframe().f_lineno))
    try:
        assert (' ' == unicode_urldecode('%20'))
    except AssertionError as e:
        raise AssertionError(str(e) + ' At line ' +
                             str(sys._getframe().f_lineno))


# Generated at 2022-06-25 09:24:01.279353
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '


# Generated at 2022-06-25 09:24:02.705005
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmodule_0 = FilterModule()

    filters_0 = fmodule_0.filters()


# Generated at 2022-06-25 09:24:04.581665
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with correct arguments
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:24:06.675044
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == ' '


# Generated at 2022-06-25 09:24:10.340229
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_filter_module = FilterModule()
    filters = ansible_filter_module.filters()
    assert to_text(filters['urldecode']) == do_urldecode
    # Test urlencode only when Jinja2 is older than v2.7
    if not HAS_URLENCODE:
        assert to_text(filters['urlencode']) == do_urlencode

# Generated at 2022-06-25 09:24:14.511145
# Unit test for function do_urlencode
def test_do_urlencode():
    var = {}
    assert do_urlencode(var) == ''

# Generated at 2022-06-25 09:24:16.344059
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert type(filters) == dict


# Generated at 2022-06-25 09:24:18.800308
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module_instance = FilterModule()
    assert module_instance.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:24:24.797319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    print('return is: ', var_0)
    assert var_0 == ' '


# Generated at 2022-06-25 09:24:28.144633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()

# Generated at 2022-06-25 09:24:38.468922
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(' ') == ' '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('/') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2Fblah%2F') == '/blah/'
    assert unicode_urldecode('%252F') == '/'
    assert unicode_urldecode('%2Fblah%2F') == u'/blah/'
    assert unicode_urldecode('%252Fblah%252F') == '/blah/'


# Generated at 2022-06-25 09:24:42.984217
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_1 = '+'
    str_2 = '%20'
    var_1 = unicode_urlencode(str_1)
    var_2 = unicode_urlencode(str_2)
    assert var_1 == str_2
    assert var_2 == str_2

# Generated at 2022-06-25 09:24:49.289398
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    filters['urldecode']('%20')
    filters['urlencode']({'a': 'b', 'c': 'd'})
    filters['urlencode']({'a': 'b', 'c': 'd'})
    filters['urlencode']({'a': 'b', 'c': 'd'})
    filters['urlencode']('%20')
    filters['urlencode']('%20')
    filters['urlencode']('%20')
    filters['urlencode']('%20')
    filters['urlencode']('%20')

# Generated at 2022-06-25 09:24:51.201971
# Unit test for function do_urlencode
def test_do_urlencode():
    var = do_urlencode({"a":"aa", "b": "bb"})
    assert var == "a=aa&b=bb"



# Generated at 2022-06-25 09:24:52.199031
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(None) == ''


# Generated at 2022-06-25 09:24:53.207932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filterModule.filters()

# Generated at 2022-06-25 09:24:54.875523
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule)
    assert 'urldecode' in filters.keys()
    assert 'urlencode' in filters.keys()


# Generated at 2022-06-25 09:25:00.466982
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode(' ') == '%20'

# Generated at 2022-06-25 09:25:03.478498
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode(u'%20') == u' '


# Generated at 2022-06-25 09:25:05.881215
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print('Testing unicode_urlencode...')
    str_0 = ' '
    var_0 = unicode_urlencode(str_0)
    print(var_0)


# Generated at 2022-06-25 09:25:19.413876
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '1'
    str_0 = unicode_urldecode(str_0)
    assert str_0 == '1'

    str_0 = '%20'
    str_0 = unicode_urldecode(str_0)
    assert str_0 == ' '

    str_0 = '%2'
    str_0 = unicode_urldecode(str_0)
    assert str_0 == '%2'

    str_0 = '+'
    str_0 = unicode_urldecode(str_0)
    assert str_0 == '+'


# Generated at 2022-06-25 09:25:24.653928
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'A'
    str_1 = '%'
    str_2 = 'z'
    assert unicode_urlencode(str_0) == 'A'
    assert unicode_urlencode(str_1) == '%25'
    assert unicode_urlencode(str_2) == 'z'

if __name__ == '__main__':
    test_case_0()
    test_unicode_urlencode()

# Generated at 2022-06-25 09:25:29.057424
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(True) == 'true'
    assert do_urlencode({'foo': 'bar'}) == u'foo=bar'
    assert do_urlencode([('foo', 'bar'), ('baz', 'bat')]) == u'foo=bar&baz=bat'
    assert do_urlencode({'a': 1, 'b': 2}) == u'a=1&b=2'



# Generated at 2022-06-25 09:25:30.050483
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()


# Generated at 2022-06-25 09:25:41.626400
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
    assert u' ' == unicode_urldecode('%20')
   

# Generated at 2022-06-25 09:25:43.775832
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('%a') == '%25a'



# Generated at 2022-06-25 09:25:47.885493
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '%20'
    str_1 = '~'
    str_2 = ' '
    # Assert type of return value
    assert(isinstance(unicode_urlencode(str_0, str_1), str))
    assert(unicode_urlencode(str_2, str_2) == '%20')



# Generated at 2022-06-25 09:25:50.877366
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '


# Generated at 2022-06-25 09:25:55.140496
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    str_0 = '%20'
    if HAS_URLENCODE:
        filters['urldecode'](str_0)
    else:
        filters['urldecode'](str_0)
        filters['urlencode'](str_0)
# END of ansible.module_utils.urls.parsing

# Generated at 2022-06-25 09:25:58.352100
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule.filters()

    assert(filters['urldecode'] == do_urldecode)

    if not HAS_URLENCODE:
        assert(filters['urlencode'] == do_urlencode)

# Generated at 2022-06-25 09:26:08.118538
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create class instance
    filters_instance = FilterModule()
    # Execute call of method filters
    filters_instance.filters()


# Generated at 2022-06-25 09:26:09.454618
# Unit test for function do_urlencode
def test_do_urlencode():
    value = {}
    result = do_urlencode(value)
    assert result is None


# Generated at 2022-06-25 09:26:19.341173
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '+'
    var_0 = unicode_urldecode(str_0)
    str_1 = 'a+b'
    var_1 = unicode_urldecode(str_1)
    str_2 = 'a b'
    var_2 = unicode_urldecode(str_2)
    str_3 = 'a%20b'
    var_3 = unicode_urldecode(str_3)
    str_4 = 'a%2fb'
    var_4 = unicode_urldecode(str_4)


# Generated at 2022-06-25 09:26:24.519323
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    assert ' ' == var_0

    str_0 = 'example.com'
    var_0 = unicode_urldecode(str_0)
    assert 'example.com' == var_0

    str_0 = '%20example.com'
    var_0 = unicode_urldecode(str_0)
    assert ' example.com' == var_0



# Generated at 2022-06-25 09:26:26.054476
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 09:26:27.429878
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode("%20") == ' ')



# Generated at 2022-06-25 09:26:28.773841
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    res = unicode_urldecode(str_0)
    assert res == str_1


# Generated at 2022-06-25 09:26:29.819898
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:26:39.062204
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%22') == '"'
    assert unicode_urldecode('%23') == '#'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2C') == ','
    assert unicode_urldecode('%2F') == '/'



# Generated at 2022-06-25 09:26:40.897650
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%20'
    result = unicode_urldecode(string)
    assert result == ' '



# Generated at 2022-06-25 09:26:49.954937
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    if PY3:
        unicode = str
    fixture = FilterModule()
    assert fixture.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-25 09:26:51.644399
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert hasattr(module, 'filters')


# Generated at 2022-06-25 09:26:59.034412
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Testing different values for function unicode_urlencode
    input_val = ' '
    str_res_0 = unicode_urlencode(input_val)
    print(str_res_0)
    input_val = '?'
    str_res_1 = unicode_urlencode(input_val)
    print(str_res_1)
    input_val = now
    str_res_2 = unicode_urlencode(input_val)
    print(str_res_2)
    print(None)


# Generated at 2022-06-25 09:27:01.553956
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # filters() implement
    try:
        f = FilterModule('test_json')
        json_filter = f.filters()
    except Exception as e:
        raise e


# Generated at 2022-06-25 09:27:03.347500
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = u'%20'
    i_1 = unicode_urldecode(str_0)
    return i_1 == u' '


# Generated at 2022-06-25 09:27:05.831739
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'dag', for_qs= False) == u'dag'


# Generated at 2022-06-25 09:27:10.546722
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-25 09:27:12.719778
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:27:16.743879
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("Begin unit test of method filters of class FilterModule.")
    ansible = FilterModule()
    ansible.filters()
    print("Test end.")


# Generated at 2022-06-25 09:27:19.543295
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_string = ' '
    assert unicode_urlencode(test_string) == '%20'
    assert unicode_urlencode(test_string, for_qs=True) == '%20'


# Generated at 2022-06-25 09:27:30.708807
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj_filters = obj.filters()
    assert obj_filters['urldecode'] == do_urldecode


# Generated at 2022-06-25 09:27:32.326660
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tmp = FilterModule()
    assert 'urldecode' in tmp.filters()



# Generated at 2022-06-25 09:27:37.008817
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    print(var_0)


# Generated at 2022-06-25 09:27:40.396306
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create a new FilterModule object
    module = FilterModule()

    assert module.filters() == {'urldecode': do_urldecode}


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 09:27:47.609670
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('%20') == " ")
    assert(unicode_urldecode('%2B') == "+")
    assert(unicode_urldecode('%5E') == "^")
    assert(unicode_urldecode('%24') == "$")
    assert(unicode_urldecode('%25') == "%")
    assert(unicode_urldecode('%2C') == ",")
    assert(unicode_urldecode('%28') == "(")
    assert(unicode_urldecode('%29') == ")")
    assert(unicode_urldecode('%20') == " ")
    assert(unicode_urldecode('%21') == "!")

# Generated at 2022-06-25 09:27:56.805808
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == ' '

    str_1 = 'a+b+c'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == 'a b c'

    str_2 = 'a%2fb%2fc'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == 'a/b/c'

    str_3 = '%22%26%27%2a%2b%2c%3a%3b%3d%3f%40%5b%5d'
    var_3 = unicode_urldecode(str_3)

# Generated at 2022-06-25 09:28:00.040441
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    
    


if __name__ == '__main__':
    import pytest
    pytest.main(['-x','test_unicode_urlencode.py'])

# Generated at 2022-06-25 09:28:02.942647
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = '%20'
    var_1 = unicode_urldecode(var_0)
    assert var_1 == ' '


# Generated at 2022-06-25 09:28:04.287227
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() is not None


# Generated at 2022-06-25 09:28:07.073844
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['urldecode'] == do_urldecode
    assert not HAS_URLENCODE or filters['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:28:15.655540
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    value = 'test string'
    assert unicode_urlencode(value) == u'test+string'
    assert unicode_urlencode(value, for_qs=True) == u'test%20string'

# Generated at 2022-06-25 09:28:17.619571
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    return var_0


# Generated at 2022-06-25 09:28:28.307404
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    var_1 = u' '
    assert var_0 == var_1
    str_1 = '%21'
    var_2 = unicode_urldecode(str_1)
    var_3 = u'!'
    assert var_2 == var_3
    str_2 = '%23'
    var_4 = unicode_urldecode(str_2)
    var_5 = u'#'
    assert var_4 == var_5
    str_3 = '%24'
    var_6 = unicode_urldecode(str_3)
    var_7 = u'$'
    assert var_6 == var_7
    str_4 = '%26'

# Generated at 2022-06-25 09:28:30.493164
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:41.699297
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string_0 = 'Hello World!'
    string_1 = 'HELLO WORLD!'
    string_2 = 'Hello World!\nHello World!\n'
    string_3 = 'Hello World!abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+,.?/:;{}[]`~'
    string_4 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    string_5 = 'abcdefghijklmnopqrstuvwxyz0123456789'
    string_6 = ' '
    string_7 = '%20'
    string_8 = u'%20'

# Generated at 2022-06-25 09:28:43.196257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f1 = FilterModule()
    assert isinstance(f1.filters, object)


# Generated at 2022-06-25 09:28:54.287432
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('http://test.com/%20') == 'http://test.com/ '
    assert unicode_urldecode('http://test.com/%20?123') == 'http://test.com/ ?123'
    assert unicode_urldecode('%20%20%20') == '   '
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3d') == '='
    assert unicode_urldecode('%3D') == '='
    assert unic

# Generated at 2022-06-25 09:28:57.571321
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = 'agfa.sans-serif'
    var_0 = unicode_urlencode(str_0)
    print(var_0)

# Generated at 2022-06-25 09:29:01.160712
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    ret_0 = urldecode(str_0)
    assert ret_0 == var_0


# Generated at 2022-06-25 09:29:04.984087
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    pass  # Replace this with a function call


# Generated at 2022-06-25 09:29:14.427895
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert False


# Generated at 2022-06-25 09:29:19.991376
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)

    str_1 = ' '
    
    assert( var_0 == str_1)


# Generated at 2022-06-25 09:29:30.605914
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '%20'
    var_0 = unicode_urldecode(str_1)
    str_2 = ' '
    assert var_0 == str_2, 'Return value of unicode_urldecode("%20") should be equal to " "! Got: ' + var_0
    str_3 = '%2B'
    var_1 = unicode_urldecode(str_3)
    str_4 = '+'
    assert var_1 == str_4, 'Return value of unicode_urldecode("%2B") should be equal to "+"! Got: ' + var_1
    str_5 = '%2b'
    var_2 = unicode_urldecode(str_5)
    str_6 = '+'
    assert var_2 == str

# Generated at 2022-06-25 09:29:36.158896
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    str_1 = '%2520'
    var_1 = unicode_urldecode(str_1)
    str_2 = '+'
    var_2 = unicode_urldecode(str_2)
    str_3 = ''
    var_3 = unicode_urldecode(str_3)
    assert var_0 == ' '
    assert var_1 == '%20'
    assert var_2 == ' '
    assert var_3 == ''


# Generated at 2022-06-25 09:29:40.202011
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    str_0 = 'urldecode'
    dict_0 = dict()
    dict_0[str_0] = do_urldecode
    return dict_0


# Generated at 2022-06-25 09:29:46.552637
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '%20'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == " "
    str_1 = 'test%'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == "test%"
    str_2 = 'test%m'
    var_2 = unicode_urldecode(str_2)
    assert var_2 == "test%m"
    str_3 = 'test%mi'
    var_3 = unicode_urldecode(str_3)
    assert var_3 == "test%mi"
    str_4 = 'test%mis'
    var_4 = unicode_urldecode(str_4)
    assert var_4 == "test%mis"
   