

# Generated at 2022-06-25 09:19:50.132939
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    filters = filter_module.filters()

    assert ('urldecode' in filters) == True


# Generated at 2022-06-25 09:19:56.150545
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert len(filters) == 2
    assert 'urldecode' in filters
    assert callable(filters['urldecode'])
    assert 'urlencode' in filters
    assert callable(filters['urlencode'])


# Generated at 2022-06-25 09:19:58.197060
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters['urldecode']('%20') == ' '


# Generated at 2022-06-25 09:19:59.612976
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('A%20string%20with%20spaces') == 'A string with spaces'


# Generated at 2022-06-25 09:20:01.221043
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == '%20'
    assert unicode_urldecode('%20') == u'%20'


# Generated at 2022-06-25 09:20:03.415733
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    u = u'%D7%99%D7%95%D7%9C%D7%93%D7%99%D7%91%D7%99%D7%9D'
    urldecoded = unicode_urldecode(u)
    assert urldecoded == u'יולדיבים'


# Generated at 2022-06-25 09:20:08.668239
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    success = True
    for k, v in filter_module.filters().items():
        #print(k)
        #print(v)
        pass


# Generated at 2022-06-25 09:20:11.129520
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filter_module_1.filters()


# Generated at 2022-06-25 09:20:17.275945
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fwww.ansible.com%2Fblog') == 'https://www.ansible.com/blog'
    assert unicode_urldecode('https://www.ansible.com/blog') == 'https://www.ansible.com/blog'


# Generated at 2022-06-25 09:20:20.575824
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters_1 = filter_module_1.filters()
    assert filters_1


if __name__ == '__main__':
    pass

# Generated at 2022-06-25 09:20:23.654947
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()


# Generated at 2022-06-25 09:20:26.612969
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    args = {
        "string": "gaurav",
        "for_qs": False,
    }
    ret = unicode_urldecode(**args)
    assert ret == "gaurav"


# Generated at 2022-06-25 09:20:31.549488
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters = filter_module_1.filters()

    assert isinstance(filters, dict)
    assert u'urldecode' in filters
    assert callable(filters[u'urldecode'])

    # assert u'urlencode' in filters
    # assert not callable(filters[u'urlencode'])



# Generated at 2022-06-25 09:20:33.587444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

#######
# def test_case_1():
#     filter_module_1 = FilterModule()


# Generated at 2022-06-25 09:20:38.803131
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(string="a b") == 'a%20b'
    assert unicode_urlencode(string="a b", for_qs=True) == 'a+b'
    assert unicode_urlencode(string="a/b") == 'a%2Fb'
    assert unicode_urlencode(string="a/b", for_qs=True) == 'a%2Fb'
    assert unicode_urlencode(string='a b#') == 'a%20b#'
    assert unicode_urlencode(string='a b#', for_qs=True) == 'a+b%23'


# Generated at 2022-06-25 09:20:41.324958
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a/b') == u'a/b'


# Generated at 2022-06-25 09:20:45.249187
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    for i in ('a', '%41', 'A', '%61', u'a', u'%41', u'A', u'%61'):
        result = unicode_urldecode(i)
        print(result)


# Generated at 2022-06-25 09:20:51.944096
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = b'c%2Fo%2Bm'
    answer = b'c/o+m'
    assert to_bytes(unicode_urldecode(string)) == answer
    string = b'c%2Fo%2Bm'
    answer = b'c/o+m'
    assert to_bytes(unicode_urldecode(string)) == answer
    string = u'c%2Fo%2Bm'
    answer = b'c/o+m'
    assert to_bytes(unicode_urldecode(string)) == answer
    string = u'c%2Fo%2Bm'
    answer = u'c/o+m'
    assert unicode_urldecode(string) == answer


# Generated at 2022-06-25 09:20:57.091284
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters() is not None


# Generated at 2022-06-25 09:21:03.324086
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert(isinstance(filters, dict))
    assert('urldecode' in filters)
    assert(filters['urldecode'] == do_urldecode)


# Generated at 2022-06-25 09:21:07.225460
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    str_ret_0 = filter_module_0.filters()
    assert str_ret_0

    str_ret_1 = filter_module_0.filters()
    assert str_ret_1


# Generated at 2022-06-25 09:21:08.014325
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert True == unicode_urldecode('?')


# Generated at 2022-06-25 09:21:11.062438
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag+wieers@redhat.com') == u'dag wieers@redhat.com'


# Generated at 2022-06-25 09:21:17.085666
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"a+a") == u"a a"
    assert unicode_urldecode(u"a%20a") == u"a a"
    assert unicode_urldecode(u"a+a a%20a") == u"a a a a"


# Generated at 2022-06-25 09:21:27.974973
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'c++') == u'c%2B%2B'
    assert unicode_urlencode(u'c++', for_qs=True) == u'c%2B%2B'
    assert unicode_urlencode(u'a\u65e5\u672c語') == u'a%E6%97%A5%E6%9C%AC%E8%AA%9E'
    assert unicode_urlencode(u'a\u65e5\u672c語', for_qs=True) == u'a%E6%97%A5%E6%9C%AC%E8%AA%9E'
    assert unicode_urlencode

# Generated at 2022-06-25 09:21:33.040469
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode(u'A%20B%20C') == u'A B C')
    assert(unicode_urldecode('A%20B%20C') == 'A B C')


# Generated at 2022-06-25 09:21:35.475551
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    value = "this+is%20a+test+of%21+%E4%BD%A0%E5%A5%BD"
    expected = "this is a test of! 你好"
    assert unicode_urldecode(value) == expected


# Generated at 2022-06-25 09:21:40.382556
# Unit test for function do_urlencode
def test_do_urlencode():
    print(do_urlencode({'A': 'a', 'B': 'b'}))
    print(do_urlencode({'A': 'a', 'B': 'b'}))
    print(do_urlencode({'A': 'a', 'B': 'b'}))


# Generated at 2022-06-25 09:21:44.833191
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%7B%27name%27%3A+%27foo%27%7D'
    assert unicode_urldecode(string) == '{\'name\': \'foo\'}'


# Generated at 2022-06-25 09:21:47.162586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

    filters = filter_module_0.filters()
    filters_items = filters.items()


# Generated at 2022-06-25 09:21:50.113160
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urldecode("hola%20mundo") == "hola mundo"



# Generated at 2022-06-25 09:21:56.522350
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("/") == "/", "urlencode failed"
    assert unicode_urlencode("/", True) == "/", "urlencode failed"
    assert unicode_urlencode("x") == "x", "urlencode failed"
    assert unicode_urlencode("x", True) == "x", "urlencode failed"
    assert unicode_urlencode("xyz") == "xyz", "urlencode failed"
    assert unicode_urlencode("xyz", True) == "xyz", "urlencode failed"
    assert unicode_urlencode("1") == "1", "urlencode failed"
    assert unicode_urlencode("1", True) == "1", "urlencode failed"

# Generated at 2022-06-25 09:21:58.143795
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

test_case_0()
test_FilterModule_filters()

# Generated at 2022-06-25 09:22:03.009045
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '''{% if not (tcp.listen_session | urldecode) in tcp.listen_session %}'''
    result_0 = unicode_urldecode(string)
    assert '''{% if not (tcp.listen_session | urldecode) in tcp.listen_session %}''' == result_0


# Generated at 2022-06-25 09:22:11.832633
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Hello%20World%21') == 'Hello World!'
    assert unicode_urldecode('Hello+World%21') == 'Hello World!'
    assert unicode_urldecode('Hello%2BWorld%21') == 'Hello+World!'
    assert unicode_urldecode('a:b:c') == 'a:b:c'
    assert unicode_urldecode('a%3Ab%3Ac') == 'a:b:c'
    assert unicode_urldecode('a::c') == 'a::c'
    assert unicode_urldecode('a%3A%3Ac') == 'a::c'



# Generated at 2022-06-25 09:22:15.341786
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Make sure the test input matches what we expect.
    assert unicode_urlencode('Hello World') == 'Hello%20World'
    assert unicode_urlencode('Hello World', for_qs=True) == 'Hello+World'


# Generated at 2022-06-25 09:22:21.219526
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = filter_module_0.filters()
    # Check using dict and list
    dict = {u'k1': u'v1', u'k2': u'v2'}
    list = [u'k1', u'k2']
    for k, v in filters.items():
        dict_ans = v(dict)
        list_ans = v(list)
        print("%s" %dict_ans)
        print("%s" %list_ans)


# Generated at 2022-06-25 09:22:32.114785
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    filter_module_1 = FilterModule()
    # Test for string
    assert filter_module_1.filters()['urldecode']('http%3A%2F%2Ffoo.com%3Fq%3Dabc%26d%3D%20%2B%26h%3Dbar') == "http://foo.com?q=abc&d= +&h=bar"

    if not HAS_URLENCODE:
        # Test for dict
        assert filter_module_1.filters()['urlencode']({'a': 'b', 'c': 'd'}) == "a=b&c=d"
        # Test for list
        assert filter_module_1.filters()['urlencode'](['a', 'b', 'c']) == "a&b&c"
        # Test for

# Generated at 2022-06-25 09:22:35.941731
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_input = 'testing%20url%20encoding'
    expected_output = 'testing url encoding'
    test_output = unicode_urldecode(test_input)
    assert test_output == expected_output


# Generated at 2022-06-25 09:22:39.528556
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode("my string") == str("my+string"))
    assert(unicode_urlencode("my string", for_qs=True) == str("my+string"))
    assert(unicode_urlencode({"key":"val"}) == str("key=val"))


# Generated at 2022-06-25 09:22:43.030454
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('example%20me') == 'example me')


# Generated at 2022-06-25 09:22:52.976066
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7Ea%21b%40c%23d%24e%f7%2Bg%2Ah%2Bi%2Cj%2Fk%3Al%3Bm%3Dn%3Fo%3Ap%3Bq%3Dr%3Ds%3Dt%3Fu%3Dv%3Dw%3Dx%25y%3Dz') == u'~a!b@c#d$e\xf7+g*h,i,j/k:l;m=n?o:p;q=r=s=t?u=v=w=x%y=z'


# Generated at 2022-06-25 09:23:02.695768
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test 1
    unicode_urldecode_1 = unicode_urldecode('http%3A//www.google.com')
    if unicode_urldecode_1 == 'http://www.google.com':
        print("Test 1: PASS")
    else:
        print("Test 1: FAIL")

    # Test 2
    unicode_urldecode_2 = unicode_urldecode('http%3A//www.google.com')
    if unicode_urldecode_2 == 'http://www.google.com':
        print("Test 2: PASS")
    else:
        print("Test 2: FAIL")



# Generated at 2022-06-25 09:23:05.831008
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Calling the filters method of FilterModule object
    filter_module_filters = FilterModule.filters(FilterModule())
    assert isinstance(filter_module_filters, dict)

# Unit tests for method do_urldecode of class FilterModule

# Generated at 2022-06-25 09:23:14.155877
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('&') == '%26'
    assert unicode_urlencode('&', True) == '%26'
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo', True) == 'foo'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar', True) == 'foo%2Fbar'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar', True) == 'foo+bar'
    assert unicode_urlencode('foo&bar') == 'foo%26bar'

# Generated at 2022-06-25 09:23:18.779001
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("https://docs.ansible.com/ansible/latest/modules/yum_module.html") == "https%3A%2F%2Fdocs.ansible.com%2Fansible%2Flatest%2Fmodules%2Fyum_module.html"


# Generated at 2022-06-25 09:23:24.264130
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'


# Generated at 2022-06-25 09:23:30.863522
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'


# Generated at 2022-06-25 09:23:32.464535
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('john+smith') == 'john%2Bsmith'


# Generated at 2022-06-25 09:23:33.747469
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
   assert unicode_urlencode('test') == 'test'


# Generated at 2022-06-25 09:23:37.977993
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello') == 'hello'


# Generated at 2022-06-25 09:23:39.594022
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    value = urldecode('Hello%20World')
    assert value == 'Hello World'


# Generated at 2022-06-25 09:23:42.855149
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode('%2B%2B%2B%2B')
    assert result == '++++'


# Generated at 2022-06-25 09:23:47.862886
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20+%20world') == u'hello  world'


# Generated at 2022-06-25 09:23:50.545573
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert 'urldecode' in filter_module_0.filters()


# Generated at 2022-06-25 09:23:55.657837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_dict_1 = filter_module_0.filters()

# Generated at 2022-06-25 09:23:58.777487
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # input
    string = u"ansible"
    
    # test
    result = unicode_urldecode(string)
    
    # verify
    assert result == u"ansible"


# Generated at 2022-06-25 09:24:01.811864
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('Dag Wieers') == u'Dag%20Wieers'

# Generated at 2022-06-25 09:24:09.176716
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test no arguments
    assert do_urlencode() == None

    # Test single string argument
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('abc/def') == 'abc%2Fdef'

    # Test single list argument
    assert do_urlencode(['a', 'b', 'c']) == 'a&b&c'

    # Test single dict argument
    assert do_urlencode({'a':'b', 'c':'d'}) == 'a=b&c=d'

    # Test multiple arguments
    assert do_urlencode('a', 'b') == 'a&b'
    assert do_urlencode('a', ['b', 'c']) == 'a&b&c'

# Generated at 2022-06-25 09:24:12.444098
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string_0 = '%40%40'
    expected_value_0 = '@@'
    actual_value_0 = unicode_urldecode(test_string_0)
    assert actual_value_0 == expected_value_0


# Generated at 2022-06-25 09:24:14.800716
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%2Fworld') == 'hello/world'


# Generated at 2022-06-25 09:24:19.404211
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode(u'qwerasdf') == u'qwerasdf'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'/foo bar/') == u'/foo%20bar/'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'/foo bar/', for_qs=True) == u'/foo+bar/'
    assert unicode_urlencode(u'QWERASDF') == u'QWERASDF'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'

# Generated at 2022-06-25 09:24:25.464564
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcABC12') == u'abcABC12'
    assert unicode_urlencode(u'abc?ABC12') == u'abc%3FABC12'
    assert unicode_urlencode(u'abc?ABC12', for_qs=True) == u'abc%3FABC12'
    assert unicode_urlencode(dict(a=u'A', b=u'B')) == u'a=A&b=B'
    assert unicode_urlencode([(u'a', u'A'), (u'b', u'B')]) == u'a=A&b=B'


# Generated at 2022-06-25 09:24:30.728310
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_cm = FilterModule()
    assert filter_module_cm.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

test_FilterModule_filters()


# Generated at 2022-06-25 09:24:37.630146
# Unit test for function do_urlencode
def test_do_urlencode():
    # Test with parameter which is a dict
    my_dict = dict(key1='Hello%2C+I%27m+a+string%21', key2='other value')
    my_dict_result = dict(key1='Hello%2C%20I%27m%20a%20string%21', key2='other+value')
    for test_dict in [my_dict, iteritems(my_dict)]:
        assert do_urlencode(test_dict) == 'key1=Hello%2C+I%27m+a+string%21&key2=other+value'
        assert do_urlencode(test_dict) == 'key1=Hello%2C%20I%27m%20a%20string%21&key2=other+value'
        assert do_urlencode(test_dict)

# Generated at 2022-06-25 09:24:48.888795
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'e8%bc%ac%ec%9d%b4%eb%8b%88%ec%84%9c%ea%b3%a0%eb%a9%b4%ec%9a%b4') == u"오늘의도장가면요"
    assert unicode_urldecode(u'Hello%2C+World%21') == u"Hello, World!"
    assert unicode_urldecode(u'%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'

# Generated at 2022-06-25 09:24:50.876672
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("One+Plus+One+Is+Equal+To%3A+2") == "One Plus One Is Equal To: 2"


# Generated at 2022-06-25 09:25:01.510009
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()

    # test the filters
    assert filters_0['urldecode']('%2Fetc%2Fpasswd') == '/etc/passwd'
    assert filters_0['urldecode']('%2Fetc%2Fpasswd%26') == '/etc/passwd&'

    # check if urlencode is available
    if HAS_URLENCODE:
        assert filters_0['urlencode']('/etc/passwd') == '%2Fetc%2Fpasswd'
        assert filters_0['urlencode']('/etc/passwd&') == '%2Fetc%2Fpasswd%26'

# Generated at 2022-06-25 09:25:10.550763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    one = "%26"
    two = "&"
    three = "%20"
    four = " "
    five = "%2F"
    six = "/"
    seven = "%3D"
    eight = "="
    assert unicode_urldecode(one) == two
    assert unicode_urldecode(three) == four
    assert unicode_urldecode(five) == six
    assert unicode_urldecode(seven) == eight


# Generated at 2022-06-25 09:25:14.796687
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'https%3A%2F%2Fwww.ansible.com%2F') == u'https://www.ansible.com/'


# Generated at 2022-06-25 09:25:26.311679
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fwww.yahoo.com%2F%E6%88%91%E6%98%AF%E4%B8%AD%E5%9B%BD%E4%BA%BA%E6%88%91%E7%9A%84%E4%B8%AD%E5%9B%BD') == 'https://www.yahoo.com/我是中国人我的中国'

# Generated at 2022-06-25 09:25:27.643713
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    out = filter_module_0.filters()
    assert out is not None

# Generated at 2022-06-25 09:25:29.644658
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filter_module_0.filters()


# Generated at 2022-06-25 09:25:33.313373
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert type(filters['urldecode']) == type(do_urldecode)
    assert type(filters['urlencode']) == type(do_urlencode)


# Generated at 2022-06-25 09:25:36.959145
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "q=Awesome+%26+Useful"
    assert unicode_urldecode(string) == "q=Awesome & Useful", unicode_urldecode(string)


# Generated at 2022-06-25 09:25:38.954751
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = filter_module_0.filters()


# Generated at 2022-06-25 09:25:42.129738
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'urldecode' in filter_module.filters().keys()
    assert filter_module.filters()['urldecode'] is do_urldecode

# Generated at 2022-06-25 09:25:47.308202
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with valid params
    if HAS_URLENCODE:
        assert filter_module_0.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}
    else:
        assert filter_module_0.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-25 09:25:54.108236
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ['test', 'test'],
        ['test+test', 'test test'],
        ['test+%2Btest', 'test +test'],
        ['%3Ftest%3F', '?test?'],
    ]

    for tc in test_cases:
        assert unicode_urldecode(tc[0]) == tc[1], 'Failure on test case {}'.format(tc)


# Generated at 2022-06-25 09:25:55.820773
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode(b'hello%20there%21') == u'hello there!'



# Generated at 2022-06-25 09:25:59.160478
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('string%20with%20spaces') == 'string with spaces'


# Generated at 2022-06-25 09:26:02.559157
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'a%3Db' == unicode_urldecode('a%3Db')
    assert 'a b' == unicode_urldecode('a+b')
    assert u'a b' == unicode_urldecode('a+b')


# Generated at 2022-06-25 09:26:08.153945
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("user%40example.com") == u"user@example.com"


# Generated at 2022-06-25 09:26:10.249300
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    dict_0=filter_module_0.filters()
    assert dict_0['urldecode'] == do_urldecode



# Generated at 2022-06-25 09:26:12.648723
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'foo%20bar' == unicode_urlencode(u'foo bar')



# Generated at 2022-06-25 09:26:15.890326
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('some text') == 'some text')
    assert(unicode_urldecode('some%20text') == 'some text')


# Generated at 2022-06-25 09:26:18.316009
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-25 09:26:27.191408
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test') == 'test'
    assert u'test' == unicode_urlencode('test')
    assert unicode_urlencode('test test') == 'test%20test'
    assert unicode_urlencode(123) == '123'
    assert unicode_urlencode('tést') == 't%C3%A9st'
    assert unicode_urlencode(True) == 'True'
    assert unicode_urlencode(False) == 'False'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert unicode_urlencode([{'a': 'b', 'c': 'd'}]) == 'a=b&c=d'
    assert unicode_

# Generated at 2022-06-25 09:26:35.455226
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('s3://test_bucket/key/a/b') == 's3://test_bucket/key/a/b'
    assert do_urlencode('test_bucket/key/a/b') == 'test_bucket/key/a/b'
    assert do_urlencode('s3://test_bucket/key/a/b/') == 's3://test_bucket/key/a/b/'
    assert do_urlencode('test_bucket/key/a/b/') == 'test_bucket/key/a/b/'
    assert do_urlencode(['a', 'b']) == 'a&b'

# Generated at 2022-06-25 09:26:38.199154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
#    filter_module = FilterModule()
#    filters = filter_module.filters()
#    assert filters['urldecode'] == do_urldecode
    assert 0 == 0


# Generated at 2022-06-25 09:26:46.606985
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        assert (unicode_urldecode(u'&zRQ!')) == u'&zRQ!'
        assert (unicode_urldecode(u'&RQ!')) == u'&RQ!'
        assert (unicode_urldecode(u'&RQ')) == u'&RQ'
    except AssertionError as e:
        print('AssertionError raised. %s' % e)


if __name__ == '__main__':
    for f in dict(FilterModule().filters()).values():
        if hasattr(f, '__call__'):
            f()
        else:
            print(f)

# Generated at 2022-06-25 09:26:52.173403
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    returned = obj.filters()
    assert returned is not None
    assert isinstance(returned, dict)
    assert len(returned) == 2


# Generated at 2022-06-25 09:26:55.809470
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)
    #assert () == obj.filters()



# Generated at 2022-06-25 09:26:57.339247
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No error should be raised
    c = FilterModule()
    c.filters();



# Generated at 2022-06-25 09:26:58.167190
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    print(filters)


# Generated at 2022-06-25 09:27:00.613364
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('&zRQ!') == '&zRQ!'
    assert unicode_urldecode('%2F1%2F') == '/1/'


# Generated at 2022-06-25 09:27:07.079156
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Test function to check result of unicode_urlencode
    '''

# Generated at 2022-06-25 09:27:10.750840
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('&zRQ!') == '#zRQ!'


# Generated at 2022-06-25 09:27:21.210026
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    variable_0 = '<>&"\''
    str_0 = unicode_urlencode(variable_0)
    str_1 = unicode_urlencode(variable_0)
    str_2 = unicode_urlencode(variable_0)
    str_3 = unicode_urlencode(variable_0)
    str_4 = unicode_urlencode(variable_0)
    str_5 = unicode_urlencode(variable_0)
    str_6 = unicode_urlencode(variable_0)
    str_7 = unicode_urlencode(variable_0)
    str_8 = unicode_urlencode(variable_0)
    str_9 = unicode_urlencode(variable_0)
    str_10 = unicode_urlencode(variable_0)

# Generated at 2022-06-25 09:27:27.948727
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    assert unicode_urldecode(str_0) == '&zRQ!'
    str_0 = 'G"U6CZ!"'
    assert unicode_urldecode(str_0) == 'G"U6CZ!"'
    str_0 = 'Z3\rG'
    assert unicode_urldecode(str_0) == 'Z3\rG'
    str_0 = '7'
    assert unicode_urldecode(str_0) == '7'


# Generated at 2022-06-25 09:27:37.987947
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(3) == u'3'
    assert unicode_urlencode((1, 2, 3)) == u'1&2&3'
    assert unicode_urlencode({'fin': 1, 'thud': 2}) == u'fin=1&thud=2'
    assert unicode_urlencode({'fin': 1, 'thud': 2}, for_qs=True) == u'fin%3D1%26thud%3D2'


# Generated at 2022-06-25 09:27:47.774515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Input
    str_1 = 'yK$>'
    # Output
    str_1_output = 'yK$>'
    assert str_1_output == unicode_urldecode(str_1)

    # Input
    str_2 = '*JH!p'
    # Output
    str_2_output = '*JH!p'
    assert str_2_output == unicode_urldecode(str_2)

    # Input
    str_3 = 'ZtH<'
    # Output
    str_3_output = 'ZtH<'
    assert str_3_output == unicode_urldecode(str_3)



# Generated at 2022-06-25 09:27:50.472140
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('&zRQ!') == '?zRQ!'


# Generated at 2022-06-25 09:27:51.392237
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_case_0()


# Generated at 2022-06-25 09:27:55.557045
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("'#") == '%27%23'



# Generated at 2022-06-25 09:28:02.601778
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)
    str_1 = u'&zRQ!'
    var_1 = unicode_urlencode(str_1)


# Generated at 2022-06-25 09:28:06.072488
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Create an instance of FilterModule
    obj_FilterModule = FilterModule()

    filters = obj_FilterModule.filters()

    filter_type_var1 = type(filters)

    return ([filter_type_var1])


# Generated at 2022-06-25 09:28:07.849652
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_Instance = FilterModule()
    FilterModule_Instance_filters = FilterModule_Instance.filters()
    assert True


# Generated at 2022-06-25 09:28:12.261625
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = 'abc'
    text_0 = 'abc'
    assert unicode_urldecode(str_0) == text_0

    str_1 = 'def'
    text_1 = 'def'
    assert unicode_urldecode(str_1) == text_1

    str_2 = 'ghi'
    text_2 = 'ghi'
    assert unicode_urldecode(str_2) == text_2



# Generated at 2022-06-25 09:28:13.842483
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    unicode_urlencode('abc')


# Generated at 2022-06-25 09:28:17.958656
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert '%26zRQ%21' == unicode_urlencode('&zRQ!')

if __name__ == '__main__':
    test_unicode_urlencode()

# Generated at 2022-06-25 09:28:21.098475
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('&zRQ!') == 'zRQ!'


# Generated at 2022-06-25 09:28:24.421039
# Unit test for function do_urlencode
def test_do_urlencode():
    # AssertionError with filter "urlencode"
    # error: {{ (str(...) == u(...)) and u(...) | urlencode or '' }} expected string or buffer
    assert do_urlencode(u'&') == u'%26'


# Generated at 2022-06-25 09:28:26.853382
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_1 = '&zRQ!'
    var_1 = unicode_urldecode(str_1)
    assert var_1 == '&zRQ!'


# Generated at 2022-06-25 09:28:28.995241
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%200') == ' '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('foo+') == 'foo '
    assert unicode_urldecode('foo ') == 'foo '
    assert unicode_urldecode('foo%2b%26') == 'foo+&'



# Generated at 2022-06-25 09:28:36.136023
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string = '&zRQ!'
    assert unicode_urldecode(test_string) == '&zRQ!'
    test_dict = {'foo': 'bar'}
    assert unicode_urldecode(test_dict) == {'foo': 'bar'}
    test_list = ['baz', 'qux']
    assert unicode_urldecode(test_list) == ['baz', 'qux']
    test_bytes = b'foo'
    if PY3:
        assert unicode_urldecode(test_bytes) == 'foo'
    else:
        assert unicode_urldecode(test_bytes) == b'foo'
    test_int = 123
    assert unicode_urldecode(test_int) == 123

# Generated at 2022-06-25 09:28:41.140191
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    str_0 = '>Y2|;'
    var_0 = unicode_urlencode(str_0)


# Generated at 2022-06-25 09:28:43.006380
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:47.270972
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()

# Generated at 2022-06-25 09:28:49.908367
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)


# Generated at 2022-06-25 09:28:56.912560
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert_equals(filter_module.filters(),
                  {'urldecode': do_urldecode, 'urlencode': do_urlencode})  # Stubs for other filters


# Generated at 2022-06-25 09:29:05.376661
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)
    str_1 = 'Qs_9c%25'
    var_1 = unicode_urldecode(str_1)
    str_2 = '&Xp'
    var_2 = unicode_urldecode(str_2)
    str_3 = '5&q3X'
    var_3 = unicode_urldecode(str_3)
    str_4 = 'F&5q3X'
    var_4 = unicode_urldecode(str_4)
    str_5 = 'Fx&5q3X'
    var_5 = unicode_urldecode(str_5)
    str_6 = '$&'
   

# Generated at 2022-06-25 09:29:10.264987
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print('\n### TESTING unicode_urldecode()')
    test_cases = [
        { 'input': '&zRQ!',        'expected': '&zRQ!' },
        { 'input': '%2F%0D%0A%0D', 'expected': '%2F%0D%0A%0D' },
    ]
    for case in test_cases:
        print('\nTest case: ' + str(case))
        result = unicode_urldecode(case['input'])
        assert result == case['expected']
        print('>>> success!')
    print('')


# Generated at 2022-06-25 09:29:12.485471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '&zRQ!'


# Generated at 2022-06-25 09:29:14.913553
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('&zRQ!') == '&zRQ!'


# Generated at 2022-06-25 09:29:20.596786
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    # Validating return type
    assert isinstance(filters, dict)
    # Validating return type
    assert isinstance(filters[next(iter(filters))], type(unicode_urldecode))

# Generated at 2022-06-25 09:29:24.677298
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:29:25.544481
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # unit test for method filters of class FilterModule
    pass

# Generated at 2022-06-25 09:29:29.368618
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('&zRQ!') == '_zRQ!'
    assert unicode_urldecode('&zRQ!') == '_zRQ!'
    assert unicode_urldecode('&zRQ!') == '_zRQ!'


# Generated at 2022-06-25 09:29:32.597560
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == u'&zRQ!'



# Generated at 2022-06-25 09:29:39.090995
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)

# Generated at 2022-06-25 09:29:40.333912
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    str_0 = '&zRQ!'
    var_0 = unicode_urldecode(str_0)
    assert var_0 == '&zRQ!'
    pass


# Generated at 2022-06-25 09:29:41.519096
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    b = FilterModule()
    assert b.filters() is not None


# Generated at 2022-06-25 09:29:45.740152
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("&zRQ!") == "&zRQ!"
