

# Generated at 2022-06-25 09:19:51.886213
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No exception thrown
    filter_0 = FilterModule()
    try:
        filters = filter_0.filters()
        filter_1 = filter_0.filters()
        filter_2 = filter_0.filters()
    except Exception:
        raise Exception("unexpected exception thrown")


# Generated at 2022-06-25 09:19:57.438651
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    var_0 = unicode_urldecode("AQA")

    assert var_0 == "AQA", "Expected result is `AQA`, but actual result is: '{}'".format(var_0)



# Generated at 2022-06-25 09:20:02.541204
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    # No exception raised
    filterModule.filters()


# Generated at 2022-06-25 09:20:04.893549
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello') == 'hello'


# Generated at 2022-06-25 09:20:13.289503
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    tests = [
        #[input, expected]
        [ [], '' ],
        [ ['a', 'b'], 'a%2Cb' ],
        [ ['a', 'b', 'c'], 'a%2Cb%2Cc' ],
        [ 'a,b,c', 'a%2Cb%2Cc' ],
    ]

    for test in tests:
        result = unicode_urlencode(test[0])
        assert result == test[1], "%s != %s" % (result, test[1])


# Generated at 2022-06-25 09:20:16.729682
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("Test filters of case 0")
    test_case_0()

test_FilterModule_filters()

# Generated at 2022-06-25 09:20:20.831408
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    var_0 = 'DEADBEEF'
    expected_0 = 'DEADBEEF'
    actual_0 = unicode_urlencode(var_0)
    assert expected_0 == actual_0


# Generated at 2022-06-25 09:20:27.638334
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    x = b'%E0%A4%A'
    x = unicode_urldecode(x)
    assert x == u'\u0906'
    x = b'%E0%A4%A'
    x = do_urldecode(x)
    assert x == u'\u0906'


# Generated at 2022-06-25 09:20:30.993966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Test cases supplied by user
    assert unicode_urldecode("Foo+Bar%26Baz") == "Foo Bar&Baz"
    assert unicode_urldecode("abc%3Ddef") == "abc=def"



# Generated at 2022-06-25 09:20:32.489723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("Test FilterModule filters ...")

    # Test the one filter
    test_case_0()


# Generated at 2022-06-25 09:20:36.547465
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%D0%B0%D0%B1%D0%B2%D0%B3%20') == u' абвг '


# Generated at 2022-06-25 09:20:39.307857
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%7D') == u'}'
    assert unicode_urldecode(u'a%7Cb') == u'a|b'
    assert unicode_urldecode(u'a%20b') == u'a b'
    assert unicode_urldecode(u'a+b') == u'a b'


# Generated at 2022-06-25 09:20:43.950729
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("""hello there""") == u"""hello%20there"""
    assert unicode_urlencode("""hello there""", for_qs=True) == u"""hello%20there"""
    assert unicode_urlencode("""hello/there""", for_qs=True) == u"""hello%2Fthere"""
    assert unicode_urlencode("""hello/there""") == u"""hello%2Fthere"""
    assert unicode_urlencode("""hello/there""", for_qs=True) == u"""hello%2Fthere"""
    assert unicode_urlencode("""hello/there""") == u"""hello%2Fthere"""

# Generated at 2022-06-25 09:20:49.129178
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_values = [
        [b"The+quick+brown+fox+jumps+over+the+lazy+dog", "The quick brown fox jumps over the lazy dog"],
        [b"The+quick+brown+fox+jumps+over+the+lazy+dog.", "The quick brown fox jumps over the lazy dog."],
        ["https://www.example.com/my%20space/my-file_name", "https://www.example.com/my space/my-file_name"],
        ["https://www.example.com/my%20space/my-file_name", "https://www.example.com/my space/my-file_name"]
    ]
    for test_value in test_values:
        assert unicode_urldecode(test_value[0]) == test_value[1]



# Generated at 2022-06-25 09:20:54.898182
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == 'test'
    assert unicode_urldecode('%20%21%40%23%24%25%5E%26*%28%29%5B%5D%7B%7D%5C%7C%5E%7E%60%5B%5D%3C%3E%2C%2E%2F%3F%3A%3B%27%2B%7C-%3D%22%7C%20%21%40%23%24%25%5E%26%2A%28%29%2C%3B%3A') == ' !@#$%^&*()[]{}\\|^~`[]<>,./?:;\'+|-="| !@#$%^&*(),:;:|'

# Generated at 2022-06-25 09:20:59.809480
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Hello World', True) == u'Hello+World'
    assert unicode_urlencode(u'Hello/World') == u'Hello%2FWorld'
    assert unicode_urlencode(u'Hello/World', True) == u'Hello%2FWorld'
    assert unicode_urlencode(u'Hello/World', True) == u'Hello%2FWorld'
    assert unicode_urlencode(u'Hello/World') == u'Hello%2FWorld'
    assert unicode_urlencode(u'Hello/World', True) == u'Hello%2FWorld'


# Generated at 2022-06-25 09:21:08.947714
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("test") == "test"
    assert do_urlencode("12345") == "12345"
    assert do_urlencode("abcABC") == "abcABC"
    assert do_urlencode("abcABC") == "abcABC"
    assert do_urlencode("Ça c'est le plus important") == "%C3%87a%20c%27est%20le%20plus%20important"
    assert do_urlencode(["a", "b", "c"]) == "a&b&c"
    assert do_urlencode({"a": "a"}) == "a=a"
    assert do_urlencode({"a": "abcABC", "b": "c"}) == "a=abcABC&b=c"


# Generated at 2022-06-25 09:21:10.973658
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/hello/there') == '/hello/there'


# Generated at 2022-06-25 09:21:15.291606
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert_equal(filter_module_0.filters(), {'urlencode': do_urlencode, 'urldecode': do_urldecode})


# Generated at 2022-06-25 09:21:23.477705
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"http://foo/bar.html?arg1=1&arg2=2") == u'http%3A//foo/bar.html%3Farg1%3D1%26arg2%3D2'
    assert unicode_urlencode(u"http://foo/bar.html?arg1=1&arg2=2", for_qs=True) == u'http%3A%2F%2Ffoo%2Fbar.html%3Farg1%3D1%26arg2%3D2'
    d = dict(
        foo=u'value of foo',
        bar=u'value of bar',
    )
    assert unicode_urlencode(d) == u'foo=value+of+foo&bar=value+of+bar'

# Unit test

# Generated at 2022-06-25 09:21:37.073703
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Test function unicode_urldecode")
    #Test input empty string
    string = ""
    assert unicode_urldecode(string) == ""
    #Test input string contain symbol like !*'();:@&=+$,/?#[]
    string = "!*'();:@&=+$,/?#[]"
    assert unicode_urldecode(string) == "!*'();:@&=+$,/?#[]"
    #Test input string contain symbol like %20
    string = "Hello%20world!"
    assert unicode_urldecode(string) == "Hello world!"
    #Test input string contain symbol like %2C
    string = "a,b"
    assert unicode_urldecode(string) == "a,b"



# Generated at 2022-06-25 09:21:39.970900
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('hello+world') == 'hello world'


# Generated at 2022-06-25 09:21:43.848901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    assert(len(filter_module_0.filters()) == 2)
    assert(type(filter_module_0.filters()) == dict)

# Generated at 2022-06-25 09:21:46.083143
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()


# Generated at 2022-06-25 09:21:51.172812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
    assert(filters_0.get('urldecode') == do_urldecode)
    if not HAS_URLENCODE:
        assert(filters_0.get('urlencode') == do_urlencode)
    else:
        assert(filters_0.get('urlencode') == do_urlencode)


# Generated at 2022-06-25 09:21:57.086233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:22:02.722455
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%C3%A8%20%28%20%C3%A9%20%29'
    assert unicode_urldecode(string) == u'\xe8 ( \xe9 )'
    string = b'%C3%A8%20%28%20%C3%A9%20%29'
    assert unicode_urldecode(string) == u'\xe8 ( \xe9 )'



# Generated at 2022-06-25 09:22:07.213188
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert type(filter_module_1.filters()) is dict


# Generated at 2022-06-25 09:22:19.244757
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'abc') == 'abc'
    assert do_urlencode(u'ab c') == 'ab+c'
    assert do_urlencode('ab c')  == 'ab+c'

    assert do_urlencode(u'ab/c') == 'ab%2Fc'
    assert do_urlencode(u'ab/c?') == 'ab%2Fc%3F'
    assert do_urlencode(u'ab/c?') == 'ab%2Fc%3F'

# Generated at 2022-06-25 09:22:26.810157
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ansible_1 = "Th%C3%A9%20%26%20Th%E1%BB%A9"
    ansible_2 = "Th\xc3\xa9 \xe2\x80\x94 Th\xe1\xbb\xa9"
    ansible_3 = "Th%C3%A9 \xe2\x80\x94 Th%E1\xBB%A9"
    ansible_4 = "The%20%26%20The"
    ansible_5 = "The%20%26%20The"
    ansible_6 = "The%20%26%20The"
    
    # Python 3
    python_1 = "Thé & Thứ"
    python_2 = "Thé — Thứ"

# Generated at 2022-06-25 09:22:31.224134
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass

# Generated at 2022-06-25 09:22:35.113710
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'M%C3%B6tley+Cr%C3%BCe'
    expected = 'Mötley Crüe'
    result = unicode_urldecode(string)
    assert result == expected, "Expected: %s, Actual: %s" % (expected, result)


# Generated at 2022-06-25 09:22:39.070534
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%26bar') == u'foo&bar'
    assert unicode_urldecode(u'foo%2526bar') == u'foo%26bar'
    assert unicode_urldecode(u'foo%3Dbar') == u'foo=bar'


# Generated at 2022-06-25 09:22:45.052455
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%5Cb') == u'a\\b'
    assert unicode_urldecode('a%3Ab') == u'a:b'
    assert unicode_urldecode('a%2Bb') == u'a+b'
    assert unicode_urldecode('a%2Fb') == u'a/b'
    assert unicode_urldecode('a%2F%2Fb') == u'a//b'
    assert unicode_urldecode('a%3Fb') == u'a?b'
    assert unicode_urldecode('a%3F%3Fb') == u'a??b'
    assert unicode_urldecode('a%23b') == u'a#b'
    assert unic

# Generated at 2022-06-25 09:22:47.280096
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    assert(isinstance(filter_module_1.filters(), dict))

# Generated at 2022-06-25 09:22:50.013851
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('&') == '%26'


# Generated at 2022-06-25 09:22:51.238081
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '


# Generated at 2022-06-25 09:23:03.383912
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    a_dict = {'a': 'foo', 'b': 'bar'}
    a_dict_values = ['foo', 'bar']
    a_dict_keys = ['a', 'b']
    a_dict_items = [('a', 'foo'), ('b', 'bar')]
    assert unicode_urlencode(a_dict) == u'a=foo&b=bar'
    assert unicode_urlencode(a_dict_values) == u'foo&bar'
    assert unicode_urlencode(a_dict_keys) == u'a&b'
    assert unicode_urlencode(a_dict_items) == u'a=foo&b=bar'

# Generated at 2022-06-25 09:23:06.046569
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_1 = FilterModule()
    filters = filter_module_1.filters()
    assert isinstance(filters, dict)
    assert 'urldecode' in filters
    return


# Generated at 2022-06-25 09:23:16.432782
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # filter_module_0 = FilterModule()
    # filter_module_0.filters()
    pass


if __name__ == "__main__":
    import sys
    import os
    import unittest


    def run_unittest(verbosity=2, test=None):
        if not test:
            # discover all tests
            test_loader = unittest.TestLoader()
            test_suit = test_loader.discover('.')
            if not test_suit.countTestCases():
                sys.stderr.write("ERROR: Failed to discover any tests.\n")
                sys.exit(1)
        else:
            # discover specific test
            test_loader = unittest.TestLoader()
            test_file_path = os.path.abspath(test)
            test_dir

# Generated at 2022-06-25 09:23:21.531516
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('\xeb\xb4_') == '\u6c64_'


# Generated at 2022-06-25 09:23:23.895459
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\x87\x8a\xd0\x1b\xba\xf2'
    var_0 = test_unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:23:28.720233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    filters.filters()


# Generated at 2022-06-25 09:23:31.218644
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    var_0 = unicode_urlencode(u'\u35b2')
    var_1 = unicode_urlencode(u'\u35b2', True)


# Generated at 2022-06-25 09:23:35.945226
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_input = u'\xeb\xb4_'
    expected_unicode_output = u'\u04b4_'
    # Unicode conversion function will not accept bytes input
    if PY3:
        unicode_input = unicode_input.encode('utf8')
    unicode_output = unicode_urldecode(unicode_input)
    assert unicode_output == expected_unicode_output


# Generated at 2022-06-25 09:23:42.823359
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'\xeb\xb4_', False) == u'%EB%B4_'
    assert unicode_urlencode(b'\xeb\xb4_', True) == u'%EB%B4_'
    assert unicode_urlencode(u'𠇐', False) == u'%F0%A0%87%90'
    assert unicode_urlencode(u'𠇐', True) == u'%F0%A0%87%90'


# Generated at 2022-06-25 09:23:47.867511
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(b'\xeb\xb4_') == u'%EB%B4_'
    


# Generated at 2022-06-25 09:23:50.545670
# Unit test for function do_urlencode
def test_do_urlencode():
    input = b'\xeb\xb4_'
    assert do_urlencode(input) == '%EB%B4_'


# Generated at 2022-06-25 09:23:55.658462
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    instance = FilterModule()
    f = instance.filters()
    if HAS_URLENCODE:
        assert f['urlencode'] == urlencode
    assert f['urldecode'] == urldecode

# Generated at 2022-06-25 09:23:58.113536
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%eb%b4_') == u'\u00eb\u00b4_'


# Generated at 2022-06-25 09:24:03.472265
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:24:09.174579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    print("filters ==", filters)
    assert True == True


# Generated at 2022-06-25 09:24:10.437031
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_filter_module = FilterModule()
    ansible_filter_module.filters()


# Generated at 2022-06-25 09:24:14.198065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()


# Generated at 2022-06-25 09:24:15.846374
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert(1)


# Generated at 2022-06-25 09:24:22.768770
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(['id', 'name']) == 'id=name'
    assert do_urlencode('name') == 'name'
    assert do_urlencode({'id': 'name'}) == 'id=name'
    assert do_urlencode([{'id': 'name'}, {'id': 'name'}]) == 'id=name&id=name'

# Generated at 2022-06-25 09:24:24.465183
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters()

if __name__ == '__main__':
    test_FilterModule_filters()
    test_case_0()

# Generated at 2022-06-25 09:24:30.307726
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode({'1': 1}, for_qs=False) == u'1=1'
    assert unicode_urlencode(1, for_qs=True) == u'1'


# Generated at 2022-06-25 09:24:32.193791
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xe2\x87\x94'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:24:35.307298
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == '\u3084_'


# Generated at 2022-06-25 09:24:44.085750
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test object creation
    fm = FilterModule()
    # Test __repr__() method of class FilterModule
    assert repr(fm)

    # Test method filters
    filters = fm.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters


# Generated at 2022-06-25 09:24:48.940693
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string_0 = 'cp5U5'
    for_qs_0 = u'y'
    assert unicode_urlencode(string_0, for_qs=for_qs_0) == b'cp5U5'


# Generated at 2022-06-25 09:24:51.311286
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule.filters() == {'urldecode': do_urldecode}



# Generated at 2022-06-25 09:24:54.606312
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    var_0 = FilterModule()
    var_1 = var_0.filters()
    bytes_0 = b'\xeb\xb4_'
    var_2 = do_urldecode(bytes_0)
    var_3 = do_urlencode(bytes_0)
    var_4 = do_urlencode(var_1)


# Generated at 2022-06-25 09:25:01.725534
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    # Verify the type of the returned object
    assert isinstance(filters, dict)
    # Verify that the returned object contains the 'urldecode' key
    assert 'urldecode' in filters.keys()
    # Verify that the returned object contains the 'urlencode' key
    assert 'urlencode' in filters.keys()
    # Verify that the 'urldebcode' key references the expected function
    assert filters['urldecode'] == do_urldecode
    # Verify that the 'urlencode' key references the expected function
    assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:25:13.016907
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%EF%BF%BD') == '\ufffd'
    assert unicode_urldecode(b'%EF%BF%BD%EF%BF%BD') == '\ufffd\ufffd'
    assert unicode_urldecode(b'%EF%BF%BD%EF%BF%BD%EF%BF%BD%EF%BF%BD') == '\ufffd\ufffd\ufffd\ufffd'

# Generated at 2022-06-25 09:25:16.313559
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    # assert filters['urldecode'] == do_urldecode

# Generated at 2022-06-25 09:25:22.331273
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  # Setup
  filtermodule = FilterModule()
  # Testing
  # NOTE: We implement urlencode when Jinja2 is older than v2.7
  filters = filtermodule.filters()
  assert not hasattr(filters, 'urlencode')
  assert hasattr(filters, 'urldecode')
  assert callable(filters['urldecode'])
  # NOTE: We implement urlencode when Jinja2 is older than v2.7

# Generated at 2022-06-25 09:25:28.938687
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    decoded = unicode_urldecode(b'%eb%b4_')

    assert decoded == u'\u6f54_'


# Generated at 2022-06-25 09:25:39.936054
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    var_0 = filter_obj.filters()
    assert isinstance(var_0, dict), "FilterModule.filters is a dictionary"
    assert var_0.get('urldecode') == do_urldecode
    if not HAS_URLENCODE:
        assert var_0.get('urlencode') == do_urlencode
    assert var_0.get('to_yaml') == to_yaml
    assert var_0.get('to_nice_yaml') == to_nice_yaml
    assert var_0.get('to_json') == to_json
    assert var_0.get('to_nice_json') == to_nice_json
    assert var_0.get('to_text') == to_text

# Generated at 2022-06-25 09:25:45.681589
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'\xeb\xb4_' == unicode_urldecode(b'\xeb\xb4_')


# Generated at 2022-06-25 09:25:52.206930
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    urlencode = filters['urlencode']
    assert urlencode('foo') == 'foo'
    assert urlencode('foo bar') == 'foo+bar'
    assert urlencode('foo bar') == 'foo%20bar'
    assert urlencode('foo/bar') == 'foo%2Fbar'
    assert urlencode('foo/?bar') == 'foo%2F%3Fbar'
    assert urlencode(['foo', 'bar']) == 'foo&bar'
    assert urlencode({'foo': 'bar'}) == 'foo=bar'
    assert urlencode({'foo': 'bar', 'baz': ['qux', 'quux']}) == 'foo=bar&baz=qux&baz=quux'


# Generated at 2022-06-25 09:26:01.507561
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from jinja2._compat import PY2, text_type
    # Test with bytes
    bytes_0 = b'\xeb\xb4_'
    res_0 = unicode_urldecode(bytes_0)
    assert res_0 == '\xeb\xb4_'
    # Test with text
    var_1 = '\xeb\xb4_'
    res_1 = unicode_urldecode(var_1)
    assert res_1 == '\xeb\xb4_'
    # Test with PY2
    if PY2:
        pass
    else:
        assert res_1 == '\xeb\xb4_'
    # Test with text_type
    if PY2:
        var_2 = text_type('\xeb\xb4_')

# Generated at 2022-06-25 09:26:03.337746
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule.filters(FilterModule())
    assert filters['urldecode'] == do_urldecode
    if HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-25 09:26:12.974121
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  string_0 = '\xe5\x8d\xbf\xe5\xbc\x97\xe6\xad\xa9\xe9\xbb\x94\xe7\xbb\x97\xe7\x8a\x84\xe5\x9f\xb6\xe8\x80\xaf\xe6\x82\x8d'

# Generated at 2022-06-25 09:26:16.823107
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    arg0 = b'\xeb\xb4_'
    # Call function unicode_urldecode
    assert unicode_urldecode(arg0) == '\u06b4_'


# Generated at 2022-06-25 09:26:20.951023
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'\xe9\x87\x91') == b'\xe9\x87\x91'
    assert unicode_urldecode(b'') == b''
    assert unicode_urldecode(b'\xeb\xb4_') == b'\xeb\xb4_'


# Generated at 2022-06-25 09:26:24.072029
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    text_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(text_0)

# Generated at 2022-06-25 09:26:25.898586
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:26:31.562117
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    arg_0 = u'\u0642_'
    expected = u'\u0642_'
    actual = unicode_urldecode(arg_0)

    assert actual == expected, "Expected {0}, got {1}".format(expected, actual)


# Generated at 2022-06-25 09:26:38.364175
# Unit test for function do_urlencode
def test_do_urlencode():
    dict_0 = {b'\xeb\xb4_': b'\xe1\xa5\x80'}
    var_0 = do_urlencode(dict_0)


# Generated at 2022-06-25 09:26:43.097467
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    result = filters.filters()
    assert len(result) == (2 if HAS_URLENCODE else 1)
    for key, value in result.items():
        assert key in ['urldecode', 'urlencode']
        assert value in [do_urldecode, do_urlencode]

if __name__ == '__main__':
    test_case_0()
    test_FilterModule_filters()

# Generated at 2022-06-25 09:26:46.246428
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Input parameters
    string = b'\xeb\xb4_'
    for_qs = False
    # Output parameters
    safe = b''
    assert unicode_urlencode(string, for_qs=for_qs) == safe


# Generated at 2022-06-25 09:26:50.705694
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

# Generated at 2022-06-25 09:26:56.588337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    filters = FilterModule.filters.__func__(filterModule)

    assert len(filters.keys()) == 2
    assert filters.get('urldecode') == do_urldecode
    assert filters.get('urlencode') == do_urlencode


# Generated at 2022-06-25 09:27:00.330951
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_0 = FilterModule.filters()

    assert isinstance(filters_0, dict)
    assert filters_0 == {'urldecode': do_urldecode} or filters_0 == {'urldecode': do_urldecode, 'urlencode': do_urlencode}



# Generated at 2022-06-25 09:27:05.864277
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # to_text(string, encoding="utf-8", errors="ignore")
    b_0 = b'\xeb\xb4_'
    t_0 = to_text(b_0, encoding='utf-8', errors='ignore')
    # unicode_urlencode(string, for_qs=False)
    u_0 = unicode_urlencode('_', for_qs=False)
    assert u_0 == u'_'
    u_1 = unicode_urlencode(t_0, for_qs=False)
    assert u_1 == u'%EB%B4_'


# Generated at 2022-06-25 09:27:10.187502
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  s0 = "abcd"
  # assert unicode_urldecode(s0) == "abcd"


# Generated at 2022-06-25 09:27:11.613285
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pass

    # Not enough arguments
    #test_unicode_urldecode(string)


# Generated at 2022-06-25 09:27:17.037118
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result_0 = unicode_urldecode('http://www.example.com?foo=bar&baz=b%C3%BC%27')
    assert result_0 == u'http://www.example.com?foo=bar&baz=bü\''


# Generated at 2022-06-25 09:27:22.860603
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'\u00eb\u00b4_') == '\u00eb\u00b4_'



# Generated at 2022-06-25 09:27:23.911983
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 09:27:26.616302
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:27:37.220022
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'9\xd5\x96\xbc') == u'9\u0596\u06bc'
    assert unicode_urldecode(b'k$\x91i\x01"\xd8') == u'k$\u0491i\u0001"\u0238'
    assert unicode_urldecode(b'\xf3\x12\x04') == u'\uf312\u0004'
    assert unicode_urldecode(b'\x95\xe2g') == u'\u0215\u02a2g'

# Generated at 2022-06-25 09:27:39.321199
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urlencode(bytes_0)


# Generated at 2022-06-25 09:27:46.857045
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    bytes_1 = b'\xeb\xb4_'
    bytes_2 = b'\xeb\xb4_'
    bytes_3 = b'\xeb\xb4_'
    bytes_4 = b'\xeb\xb4_'
    bytes_5 = b'\xeb\xb4_'
    bytes_6 = b'\xeb\xb4_'
    bytes_7 = b'\xeb\xb4_'
    bytes_8 = b'\xeb\xb4_'
    bytes_9 = b'\xeb\xb4_'
    bytes_10 = b'\xeb\xb4_'
    bytes_11 = b'\xeb\xb4_'

# Generated at 2022-06-25 09:27:56.451687
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("")==''
    assert unicode_urlencode(" ")=='+'
    assert unicode_urlencode("some_value")=='some_value'
    assert unicode_urlencode("some value")=='some+value'
    assert unicode_urlencode("some value", for_qs=True)=='some%20value'
    assert unicode_urlencode("some/value")=='some%2Fvalue'
    assert unicode_urlencode("some/value", for_qs=True)=='some%2Fvalue'
    assert unicode_urlencode("some(value)")=='some%28value%29'
    assert unicode_urlencode("some(value)", for_qs=True)=='some%28value%29'

# Generated at 2022-06-25 09:27:58.382531
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters.get('urldecode')
    assert filters.get('urlencode')



# Generated at 2022-06-25 09:27:59.215056
# Unit test for function do_urlencode
def test_do_urlencode():
    pass


# Generated at 2022-06-25 09:28:03.380486
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert type(filters) == dict
    # assert filters['urldecode'] == do_urldecode
    # assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-25 09:28:09.687431
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'/xE5'
    var_0 = unicode_urldecode(bytes_0)


# Generated at 2022-06-25 09:28:12.979298
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Unit test for case 0
    res = unicode_urldecode(b'\xeb\xb4_')
    assert res == u'\uacf0_'

# Generated at 2022-06-25 09:28:17.429490
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urlencode('_\u04ec')
    assert var_0 == '%5F%D5%AC', 'unicode_urlencode()'


# Generated at 2022-06-25 09:28:22.034110
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == u'\u5bb4_'


# Generated at 2022-06-25 09:28:24.363775
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Instantiate class FilterModule
    filter_module = FilterModule()

    # Call method filters of class FilterModule
    assert filter_module.filters() is not None

# Generated at 2022-06-25 09:28:29.935692
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('\xeb_') == '%EB_'
    assert unicode_urlencode('\xeb_', for_qs=1) == '%EB_'
    assert unicode_urlencode('\xeb_', for_qs=1) == '%EB_'
    assert unicode_urlencode('\xeb_') == '%EB_'
    assert unicode_urlencode('\xeb_') == '%EB_'

# Generated at 2022-06-25 09:28:31.193082
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters is not None


# Generated at 2022-06-25 09:28:33.706200
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    bytes_0 = b'\xeb\xb4_'
    var_0 = FilterModule()
    filters_0 = var_0.filters()
    filters_0['urldecode'](bytes_0)


# Generated at 2022-06-25 09:28:45.148733
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Foo') == 'Foo'
    assert unicode_urlencode(u'Foo%') == 'Foo%25'
    assert unicode_urlencode(u'Foo?') == 'Foo%3F'
    assert unicode_urlencode(u'Foo') == 'Foo'
    assert unicode_urlencode(u'Foo%') == 'Foo%25'
    assert unicode_urlencode(u'Foo?') == 'Foo%3F'
    assert unicode_urlencode(u'Foo') == 'Foo'
    assert unicode_urlencode(u'Foo%') == 'Foo%25'

# Generated at 2022-06-25 09:28:48.840409
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\uc720\uc801') == u'%EC%B0%A0%EC%B0%81'


# Generated at 2022-06-25 09:28:57.546884
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert do_urldecode(b'%2B') == u'+'
    assert do_urlencode(b'+') == u'%2B'


# Generated at 2022-06-25 09:28:59.827145
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c_instance = FilterModule()
    result = c_instance.filters()
    assert result['urldecode'] == do_urldecode

# Generated at 2022-06-25 09:29:02.584093
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xc3\x8d\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == 'Ì\u30b4_'


# Generated at 2022-06-25 09:29:08.702228
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  assert unicode_urldecode(b'\xeb\xb4_') == '\u09ee_'
  assert unicode_urldecode('%eb%b4%5f') == '\u09ee_'
  assert unicode_urldecode('%eb%b4%5f') == u'\u09ee_'



# Generated at 2022-06-25 09:29:18.636769
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    bytes_1 = b'&'
    bytes_2 = b'\xe9'
    bytes_3 = b'\xeb\xb4_'
    bytes_4 = b'='
    bytes_5 = b'\xe6'
    bytes_6 = b'\xc6\x83\xa3\xd4'
    bytes_7 = b'\xa3\x83'
    bytes_8 = b'&'


# Generated at 2022-06-25 09:29:23.191869
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)
    bytes_1 = b'\xca\x83\x01\x02\x03'
    assert var_0 == u'\u0394_'


# Generated at 2022-06-25 09:29:26.515201
# Unit test for function unicode_urldecode

# Generated at 2022-06-25 09:29:34.696928
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    bytes_0 = b'\xeb\xb4_'
    var_0 = unicode_urldecode(bytes_0)
    assert var_0 == '촬_'
    var_1 = unicode_urldecode('\xeb\xb4_')
    assert var_1 == '촬_'
    var_2 = unicode_urldecode(b'\xeb\xb4_')
    assert var_2 == '촬_'
    var_3 = unicode_urldecode('\xe8\xbf\x9b\xe5\x85\x85_')
    assert var_3 == '进充_'

# Generated at 2022-06-25 09:29:38.843756
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_0 = unicode_urldecode(b'\xeb\xb4_')


# Generated at 2022-06-25 09:29:42.517467
# Unit test for function do_urlencode
def test_do_urlencode():

    # Testing with dict
    # Test scenario 0
    dict_0 = {'key_0': 'val_0'}
    result = do_urlencode(dict_0)
    assert result == 'key_0=val_0'

    # Testing with list
    # Test scenario 0
    list_0 = ['val_0']
    result = do_urlencode(list_0)
    expected = 'val_0'
    assert result == expected