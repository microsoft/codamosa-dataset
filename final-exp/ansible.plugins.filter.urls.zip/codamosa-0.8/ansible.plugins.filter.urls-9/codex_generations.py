

# Generated at 2022-06-11 14:08:56.706759
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20') == u'é '
    assert unicode_urldecode('%C3%A9%20%C3%A9') == u'é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9') == u'é é é'
    assert unicode_urldecode('%C3%A9%20%C3%A9%20%C3%A9%20%C3%A9') == u'é é é é'


# Generated at 2022-06-11 14:09:00.386961
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ff = FilterModule().filters()
    assert ff['urldecode']('a+b') == 'a b'
    if not HAS_URLENCODE:
        assert ff['urlencode']('a b') == 'a+b'



# Generated at 2022-06-11 14:09:03.231902
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb%3Dc') == 'a+b=c'


if __name__ == "__main__":
    test_unicode_urldecode()

# Generated at 2022-06-11 14:09:10.655220
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode('føø') == 'f%C3%B8%C3%B8'
        assert unicode_urlencode('føø', True) == 'f%C3%B8%C3%B8'
    else:
        assert unicode_urlencode('føø') == 'f%C3%B8%C3%B8'
        assert unicode_urlencode('føø', True) == 'f%C3%B8%C3%B8'


# Generated at 2022-06-11 14:09:21.603561
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test existence of filters
    assert 'urldecode' in FilterModule.filters(None).keys()

    # Test FilterModule.filters()['urldecode']
    assert FilterModule.filters(None)['urldecode'](None) == ''

    # Test FilterModule.filters()['urldecode']
    assert FilterModule.filters(None)['urldecode']('') == ''

    # Test FilterModule.filters()['urldecode']
    assert FilterModule.filters(None)['urldecode']('%24') == '$'

    # Test FilterModule.filters()['urldecode']
    assert FilterModule.filters(None)['urldecode']('%2F') == '/'

    # Test FilterModule.filters()['urldecode

# Generated at 2022-06-11 14:09:31.389670
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'https%3A%2F%2Fdocs.ansible.com%2F' == do_urlencode('https://docs.ansible.com/')
    assert 'ssid=my_wifi_network' == do_urlencode({'ssid': 'my_wifi_network'})
    assert [('k1', 'v1'), ('k2', 'v2')] == list(zip(*[kv.split('=') for kv in do_urlencode([('k1', 'v1'), ('k2', 'v2')]).split('&')]))
    assert 'https%3A%2F%2Fdocs.ansible.com%2F' == do_urldecode('https%3A%2F%2Fdocs.ansible.com%2F')

# Generated at 2022-06-11 14:09:33.178352
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-11 14:09:35.401228
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fltr = FilterModule()
    assert fltr.filters()


# Generated at 2022-06-11 14:09:38.296584
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  o = FilterModule()
  assert dir(o) == ['filters']
  assert o.filters() == {'urldecode': do_urldecode}


# Generated at 2022-06-11 14:09:47.368066
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # We cannot easily test the urldecode filter because it calls
    # unquote_plus, which we have not overridden.  However, it is also
    # a very standard function, so we assume that it works.
    #
    # On the other hand, we can test urlencode by mocking urllib and
    # testing the inputs.
    import urllib
    import socket
    import StringIO
    import tempfile
    import os
    import shutil
    tmp = tempfile.mkdtemp()

# Generated at 2022-06-11 14:09:51.971462
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    results = fm.filters()
    assert results['urldecode'] is do_urldecode
    assert results['urlencode'] is do_urlencode


# Generated at 2022-06-11 14:09:54.033819
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

        assert FilterModule.filters(FilterModule()) == {'urldecode': do_urldecode}



# Generated at 2022-06-11 14:09:59.986240
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc123') == 'abc123'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%3C3') == u'<3'
    assert unicode_urldecode('2B%2B') == u'2B+'
    assert unicode_urldecode('%25') == u'%'


# Generated at 2022-06-11 14:10:07.719786
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:10:12.711336
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    data = [
        ("Test_string", "Test_string"),
        (u"Test_string", "Test_string"),
        ("Test%20string", "Test string"),
        (u"Test%20string", "Test string"),
        (u"Test string", "Test+string"),
        ("Test string", "Test+string"),
    ]

    for input, expected in data:
        result = unicode_urldecode(input)
        assert expected == result



# Generated at 2022-06-11 14:10:16.323499
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Test the filters method of class FilterModule '''
    module = FilterModule()
    filters = module.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert 'urlencode' in filters



# Generated at 2022-06-11 14:10:21.219394
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert (b'result' == unicode_urldecode(b'result'))
    assert (u'result' == unicode_urldecode(u'result'))
    assert (u'result' == unicode_urldecode(b'result'))



# Generated at 2022-06-11 14:10:23.440747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    method = FilterModule.filters
    instance = FilterModule()

    result = method(instance)
    assert 'urldecode' in result



# Generated at 2022-06-11 14:10:29.502308
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%2B123') == 'abc+123'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('abc+123') == 'abc+123'
    assert unicode_urldecode('ezr%C3%A0z+ezt%3D%3F%2B') == u'ezràz+ezt=?+'

# Generated at 2022-06-11 14:10:33.666965
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'á' == unicode_urldecode('%C3%A1')
    assert u'á' == unicode_urldecode('%C3%A1')
    assert u'áø' == unicode_urldecode('%C3%A1%C3%B8')



# Generated at 2022-06-11 14:10:39.224285
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%3C') == u'<'
    assert unicode_urldecode(u'%20') == u' '


# Generated at 2022-06-11 14:10:48.022242
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  assert unicode_urldecode(b'abc+hhh%ttt') == 'abc hhhttt'
  assert unicode_urldecode('abc+hhh%ttt') == 'abc hhhttt'
  assert unicode_urldecode(b'abc+%HHH%ttt') == 'abc  HHHttt'
  assert unicode_urldecode('abc+%HHH%ttt') == 'abc  HHHttt'
  assert unicode_urldecode(b'%u0026') == '&'
  assert unicode_urldecode('%u0026') == '&'
  assert unicode_urldecode(b'%u003C') == '<'
  assert unicode_urldecode('%u003C') == '<'
 

# Generated at 2022-06-11 14:10:50.360098
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode']('%20') == ' '
    assert filter_module.filters()['urldecode']('+') == ' '

# Generated at 2022-06-11 14:11:00.144816
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == 'test'
    assert unicode_urldecode('%2Ftest%2F') == '/test/'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('%2F%2F%2F') == '///'
    assert unicode_urldecode(u'test') == u'test'
    assert unicode_urldecode(u'%2Ftest%2F') == u'/test/'
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%2F%2F') == u'//'


# Generated at 2022-06-11 14:11:10.392235
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic
    from ansible.compat.tests import unittest

    class UrllibModuleTest(unittest.TestCase):
        def test_empty_input(self):
            # Empty input
            self.assertEqual(u'', do_urlencode(None))

        def test_dict_input(self):
            # Dict input
            self.assertEqual(u'wd=test&ie=utf-8',
                             do_urlencode({'wd': u'test', 'ie': u'utf-8'}))

        def test_list_input(self):
            # List input
            self.assertEqual(u'wd=test&wd=test2',
                             do_urlencode([u'wd=test', u'wd=test2']))

       

# Generated at 2022-06-11 14:11:14.771842
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Given a FilterModule instance
    fm = FilterModule()

    # When I call the filters method
    result = fm.filters()

    # Then I should get a dictionary of filters with urldecode and urlencode
    assert 'urldecode' in result
    assert 'urlencode' in result

# Generated at 2022-06-11 14:11:16.691924
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_urldecode('foo')
    unicode_urldecode('%E5%90%AC')


# Generated at 2022-06-11 14:11:19.161992
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert sorted(filter_module.filters()) == sorted({'urlencode': do_urlencode, 'urldecode': do_urldecode})



# Generated at 2022-06-11 14:11:22.202601
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert '%25' in FilterModule.filters(FilterModule)().get('urlencode')('%')
    assert '%' in FilterModule.filters(FilterModule)().get('urldecode')('%25')

# Generated at 2022-06-11 14:11:31.290157
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'?') == u'%3F'
    assert unicode_urlencode(u'?') == u'%3F'
    assert unicode_urlencode({'k': 'v'}) == u'k=v'
    assert unicode_urlencode({'k': u'?'}) == u'k=%3F'
    assert unicode_urlencode({'k': b'?'}) == u'k=%3F'
    assert unicode_urlencode([u'k', u'?']) == u'k=%3F'
    assert unicode_urlencode([b'k', b'?']) == u'k=%3F'


# Generated at 2022-06-11 14:11:44.003679
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unsafe') == u'unsafe'
    assert unicode_urlencode(u'unsafe + unsafe') == u'unsafe%20%2B%20unsafe'
    assert unicode_urlencode(u'unsafe + unsafe', for_qs=True) == u'unsafe+%2B+unsafe'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'


# Generated at 2022-06-11 14:11:47.053643
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%41%5a%52') == u'AZR'
    assert unicode_urldecode(u'%41%5a%52') == u'AZR'
    assert unicode_urldecode(u'%41%5a%52') == u'AZR'


# Generated at 2022-06-11 14:11:50.634475
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tm = FilterModule()
    assert tm.filters().keys() == ['urldecode']
    if not HAS_URLENCODE:
        assert tm.filters().keys() == ['urlencode', 'urldecode']


# Generated at 2022-06-11 14:11:58.123695
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = {'urlencode': 'http://www.example.com/?foo=bar+baz',
            'urldecode': 'http%3A%2F%2Fwww.example.com%2F%3Ffoo%3Dbar%2Bbaz'}
    f = FilterModule()
    for name, example in iteritems(data):
        for filter in f.filters():
            if filter == name:
                if name == 'urlencode':
                    assert example == do_urlencode(example)
                if name == 'urldecode':
                    assert example == do_urldecode(example)

# Generated at 2022-06-11 14:12:00.325392
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert "abcabcabcabcabcabcabcabcabcabcabcabc" == unicode_urlencode("abc" * 30)


# Generated at 2022-06-11 14:12:06.982707
# Unit test for function do_urlencode
def test_do_urlencode():
    testcases = dict()
    # testcases
    testcases[u'\u0445\u044b\u043b\u0438\u043a\u0430'] = u'%D1%85%D1%8B%D0%BB%D0%B8%D0%BA%D0%B0'
    testcases[u'\u043a\u0438\u0448\u044c'] = u'%D0%BA%D0%B8%D1%88%D1%8C'
    testcases[u'\u0438\u043b\u0435\u043d\u0430'] = u'%D0%B8%D0%BB%D0%B5%D0%BD%D0%B0'

# Generated at 2022-06-11 14:12:17.928341
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode(u'foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode(u'/') == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode(u'/', for_qs=True)

# Generated at 2022-06-11 14:12:18.905318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

# Generated at 2022-06-11 14:12:21.972641
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test for issue gh-5547, that urldecode does the correct unquote_plus
    assert unicode_urldecode('%7B%22key%22%3A+%22value%22%7D') == '{"key": "value"}'

# Generated at 2022-06-11 14:12:28.874663
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    for string in [
        'string',
        u'string',
        u'stríng',
        '%41%42%43%44',
        '%41%42%43%EF%BC%8C',
        '%41%42%43%E3%80%81',
    ]:
        assert string == unicode_urldecode(string)



# Generated at 2022-06-11 14:12:43.671317
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'wieers.com') == u'wieers.com'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'/', for_qs=True) == u'%2F'
    assert unicode_urlencode(u'wieers.com/') == u'wieers.com%2F'
    assert unicode_urlencode(u'foo bar/') == u'foo%20bar%2F'
    assert unicode_urlencode(u'foo+bar') == u'foo+bar'

# Generated at 2022-06-11 14:12:51.467604
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode(b'%2B') == '+'
    assert unicode_urldecode(b'%2b') == '+'
    assert unicode_urldecode(u'%2b') == u'+'
    assert unicode_urldecode(u'%41') == u'A'

# Generated at 2022-06-11 14:12:57.846069
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'%2b') == u'+'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%7E') == u'~'


# Generated at 2022-06-11 14:13:01.109258
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'euro%E2%82%AC') == u'euro\u20ac'
    assert unicode_urldecode(u'euro%E2%82%AC') == u'euro\u20ac'



# Generated at 2022-06-11 14:13:04.346642
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(to_bytes('Hello%20World%21')) == to_text('Hello World!')
    assert unicode_urldecode('Hello%20World%21') == to_text('Hello World!')



# Generated at 2022-06-11 14:13:08.124813
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("test") == u"test"
    assert unicode_urldecode("test%2Ftest") == u"test/test"
    assert unicode_urldecode("test+test") == u"test test"
    assert unicode_urldecode("test%22test") == u"test\"test"



# Generated at 2022-06-11 14:13:11.410904
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%20%C3%A9') == ' é'


# Generated at 2022-06-11 14:13:20.387626
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('%7B%22a%22%3A%22b%22%7D') == u'{"a":"b"}'
    assert unicode_urldecode('%7B%3A%3A%3A%7D') == u'{:::}'
    assert unicode_urldecode('%7B%22a%22%3A%22b%22%7D') == u'{"a":"b"}'
    assert unicode_urldecode('%7B%22a%22%3A%22b%22%7D') == u'{"a":"b"}'

# Generated at 2022-06-11 14:13:23.835565
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:13:33.518291
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    from ansible.module_utils import basic
    from ansible.module_utils.six import binary_type, text_type
    from io import StringIO

    # The test cases

# Generated at 2022-06-11 14:13:46.808102
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test unicode_urlencode '''
    assert unicode_urlencode(u'http://localhost/?a=b c') == u'http%3A%2F%2Flocalhost%2F%3Fa%3Db%20c'
    assert unicode_urlencode(u'http://localhost/?a=b c', for_qs=True) == u'http%3A%2F%2Flocalhost%2F%3Fa%3Db+c'
    assert unicode_urlencode(u'http://localhost/%3Fa%3Db c') == u'http%3A%2F%2Flocalhost%2F%253Fa%253Db%20c'

# Generated at 2022-06-11 14:13:57.745686
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test for correct behavior for valid UTF-8 percent encoded strings
    assert(unicode_urldecode("%C2%80") == u"€")
    assert(unicode_urldecode("%C2%80%20%C2%80") == u"€ €")

    # Test for correct behavior for invalid UTF-8 percent encoded strings
    # Windows
    assert(unicode_urldecode("%80") == u"\uFFFD")
    assert(unicode_urldecode("%80%20%80") == u"\uFFFD \uFFFD")

    # Mac
    assert(unicode_urldecode("%80") == u"\uFFFD")
    assert(unicode_urldecode("%80%20%80") == u"\uFFFD \uFFFD")

# Generated at 2022-06-11 14:13:59.454435
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(None), dict)

# Generated at 2022-06-11 14:14:02.120293
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters


# Generated at 2022-06-11 14:14:12.857491
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:14:14.629369
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2F") == u"/"
    assert unicode_urldecode("%25") == u"%25"



# Generated at 2022-06-11 14:14:24.258224
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import unittest

    # Test py2
    if not PY3:
        url = 'http%3A%2F%2Fwww.example.com%2F%3F%C3%A5%C3%A6%C3%B8%3D%20%26%20%C3%A5%C3%A6%C3%B8%3D%C3%A5%C3%A6%C3%B8'
        expect = u'http://www.example.com/?\xc3\xa5\xc3\xa6\xc3\xb8= & \xc3\xa5\xc3\xa6\xc3\xb8=\xc3\xa5\xc3\xa6\xc3\xb8'
        result = unicode_urldecode(url)


# Generated at 2022-06-11 14:14:32.148468
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:14:33.964617
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"Hello+World%21") == u"Hello World!"


# Generated at 2022-06-11 14:14:39.186165
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/fancy[pants]') == 'http%3A//example.com/fancy%5Bpants%5D'
    assert unicode_urlencode({'status': 'on', 'switch': 'yes'}) == 'status=on&switch=yes'

# Generated at 2022-06-11 14:14:54.190818
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock
    if sys.version_info[:2] < (3, 4):
        return unittest.TestCase.skipTest(unittest.TestCase(), 'requires python3.4')

    # Prepare mocks
    mock_to_bytes_str = MagicMock(return_value=b'foo')
    mock_to_bytes_str_unquote_plus_str_return = MagicMock(return_value='bar')
    mock_to_text_str_unquote_plus_str_return = MagicMock(return_value='bar')
    mock_to_bytes = MagicMock(side_effect=lambda x: x)
    mock_to

# Generated at 2022-06-11 14:14:57.371283
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u"plaintext" == unicode_urldecode(u"plaintext")
    assert u"some text" == unicode_urldecode(u"some%20text")



# Generated at 2022-06-11 14:15:04.669971
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    pkg = 'ansible_test_pkg'
    pkg_list = ('ansible_test_pkg', 'krb5-libs')
    for pkg_name in pkg, pkg_list:
        assert unicode_urldecode(pkg_name) == pkg_name
        assert unicode_urldecode(unicode_urlencode(pkg_name)) == pkg_name
        assert unicode_urldecode(unicode_urlencode(unicode_urlencode(pkg_name))) == pkg_name
        assert unicode_urldecode(unicode_urlencode(unicode_urlencode(unicode_urlencode(pkg_name)))) == pkg_name
    assert unicode_urldecode(unicode_urlencode(pkg_list)) == pkg_

# Generated at 2022-06-11 14:15:10.303239
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    buf = "%C3%A0%C3%A8%C3%AC%C3%B2%C3%B9"
    assert unicode_urldecode(buf) == u"àèìòù"

if __name__ == '__main__':
    test_unicode_urldecode()

# Generated at 2022-06-11 14:15:20.030225
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test character urlencoding
    assert(unicode_urlencode(u'This is a test') == 'This+is+a+test')
    assert(unicode_urlencode(u'This is a test') == 'This+is+a+test')
    assert(unicode_urlencode(u'i') == 'i')
    assert(unicode_urlencode(u'€') == '%E2%82%AC')
    # Test quoting
    assert(unicode_urlencode(u'This is a test', for_qs=True) == 'This+is+a+test')
    assert(unicode_urlencode(u'This is a test', for_qs=True) == 'This+is+a+test')
    # Test iteration (only for dictionaries)

# Generated at 2022-06-11 14:15:27.891140
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urlencode({'a': '&', 'b': 1, 'c': 'c'}) == 'b=1&c=c&a=%26'
    assert do_urlencode('a=1&b=2') == 'a=1%26b%3D2'
    assert do_urldecode('a%3D1%26b%3D2') == 'a=1&b=2'
    assert do_urldecode('a=1&b=2') == 'a=1&b=2'

# Generated at 2022-06-11 14:15:28.382905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()

# Generated at 2022-06-11 14:15:39.643323
# Unit test for function do_urlencode
def test_do_urlencode():

    if HAS_URLENCODE:
        assert do_urlencode('ab cd ef') == 'ab+cd+ef'
        assert do_urlencode('ab cd+ef') == 'ab+cd%2Bef'
        assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
        assert do_urlencode('/a/b/c') == '/a/b/c'
    else:
        assert do_urlencode('ab cd ef') == 'ab%20cd%20ef'
        assert do_urlencode('ab cd+ef') == 'ab%20cd%2Bef'
        assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
        assert do

# Generated at 2022-06-11 14:15:43.582701
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%20b%2Bc%2Fd') == 'a b+c/d'
    assert unicode_urldecode('a+b+c+d') == 'a b c d'



# Generated at 2022-06-11 14:15:49.783380
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:15:59.035226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Make instance
    instance = FilterModule()

    # Method filters
    args = {}
    assert do_urldecode(instance.filters()["urldecode"](args)) == '%20'
    assert do_urlencode(instance.filters()["urlencode"](args)) == '%20'

# Generated at 2022-06-11 14:16:00.858850
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        unicode_urldecode('V%C3%A9hicule')
    except NameError:
        pass

# Generated at 2022-06-11 14:16:04.534489
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:16:07.606500
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%EF%BB%BFHello%20World%2C%20how%20are%20you%3F') == u'\ufeffHello World, how are you?'



# Generated at 2022-06-11 14:16:18.601207
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert(unicode_urlencode('/') == b'%2F')
        assert(unicode_urlencode('/foo bar/') == b'%2Ffoo%20bar%2F')
        assert(unicode_urlencode('/foo bar/?baz=1') == b'%2Ffoo%20bar%2F%3Fbaz%3D1')
    else:
        assert(unicode_urlencode('/') == b'%2F')
        assert(unicode_urlencode('/foo bar/') == b'%2Ffoo%20bar%2F')
        assert(unicode_urlencode('/foo bar/?baz=1') == b'%2Ffoo%20bar%2F%3Fbaz%3D1')

#

# Generated at 2022-06-11 14:16:26.282105
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'/角色') == u'/%E8%A7%92%E8%89%B2'
    assert unicode_urlencode(u'/角色', for_qs=True) == u'/%E8%A7%92%E8%89%B2'
    assert unicode_urlencode(u'角/色') == u'%E8%A7%92/%E8%89%B2'
    assert unicode_urlencode(u'角/色', for_qs=True) == u'%E8%A7%92%2F%E8%89%B2'

# Generated at 2022-06-11 14:16:31.593982
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'abcd efgh' == unicode_urldecode('abcd%20efgh')
    # Test for PY3
    assert type(unicode_urldecode('abcd%20efgh')) == str
    # Test for PY2
    assert type(to_text(unicode_urldecode(to_bytes('abcd%20efgh')))) == unicode


# Generated at 2022-06-11 14:16:37.178105
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%40bar') == u'foo@bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'


# Generated at 2022-06-11 14:16:42.049772
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic

    with patch.object(basic.AnsibleModule, 'fail_json') as mfj:
        fm = FilterModule()
        assert fm.filters.get('urldecode') == do_urldecode
        mfj.assert_called_once_with(msg='Could not import jinja2.filters.do_urlencode')

# Generated at 2022-06-11 14:16:44.920461
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u263a') == u'%E2%98%BA'
    assert unicode_urlencode(u'\u2639') == u'%E2%98%B9'


# Generated at 2022-06-11 14:16:57.188255
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\"') == u'%22'
    assert unicode_urlencode(u'\'') == u'%27'
    assert unicode_urlencode(u'@') == u'@'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'a/b/c') == u'a/b/c'
    assert unicode_urlencode(u'/a/b/c') == u'/a/b/c'
    assert unicode_urlencode(u'a/b/c/') == u'a/b/c/'
    assert unicode_urlencode(u'a/b/c/?a=b') == u'a/b/c/?a=b'
    assert unicode

# Generated at 2022-06-11 14:17:07.186557
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.compat.tests import unittest
    import sys

    with patch.object(sys, 'version_info', (3, )):
        assert unicode_urlencode(u'unicode string') == u'unicode%20string'

    with patch.object(sys, 'version_info', (2, 6)):
        assert unicode_urlencode(u'unicode string') == u'unicode%20string'

    with patch.object(sys, 'version_info', (2, 6)):
        assert unicode_urlencode(u'unicode string') == u'unicode%20string'

    # python 2.6 or lower doesn't support unicode

# Generated at 2022-06-11 14:17:10.940201
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Makes sure that unicode_urldecode function is working
    '''
    msg = u'unicode_urldecode function is not working'
    assert unicode_urldecode('reg%C3%A9e+%3D') == u'regée =', msg



# Generated at 2022-06-11 14:17:16.698789
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'123ABC@ 哈哈') == '123ABC%40%20%E5%93%88%E5%93%88'
    assert unicode_urlencode(123) == '123'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert unicode_urlencode(['a', 'b', 'c']) == 'a%3Dtrue'


# Generated at 2022-06-11 14:17:20.504296
# Unit test for method filters of class FilterModule

# Generated at 2022-06-11 14:17:24.946193
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B6') == u'ö'
    assert unicode_urldecode('%7E/%3F%25=%26') == u'~/?%=&'
    assert unicode_urldecode('%C3%A4%2C=%2C%C3%A4') == u'ä,=,ä'


# Generated at 2022-06-11 14:17:32.061656
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test all possible urlencoding for unicode_urlencode '''
    import sys
    assert unicode_urlencode('') == ''
    assert unicode_urlencode(u' ') == '+'
    assert unicode_urlencode(u'%') == '%25'
    assert unicode_urlencode(u'?') == '%3F'
    assert unicode_urlencode(u'?') == '%3F'
    assert unicode_urlencode(u'&') == '&'
    assert unicode_urlencode(u'&', for_qs=True) == '%26'
    assert unicode_urlencode(u'a') == 'a'
    assert unicode_urlencode(u'A') == 'A'
    assert unicode_

# Generated at 2022-06-11 14:17:41.461633
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'ab c') == u'ab%20c'
    assert unicode_urlencode(u'ab?c') == u'ab%3Fc'
    assert unicode_urlencode(u'ab#c') == u'ab%23c'
    assert unicode_urlencode(u'ab%c') == u'ab%25c'
    assert unicode_urlencode(u'ab&c') == u'ab%26c'
    assert unicode_urlencode(u'ab/c') == u'ab/c'

    assert unicode_urlencode(u'ab&c', for_qs=True) == u'ab%26c'
    assert unicode_urlen

# Generated at 2022-06-11 14:17:51.419023
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://de.wikipedia.org/wiki/Elf (Begriffsklärung)') == u'http%3A%2F%2Fde.wikipedia.org%2Fwiki%2FElf%20%28Begriffskl%C3%A4rung%29'
    assert do_urlencode([u'key1', u'key2']) == u'key1&key2'
    assert do_urlencode([u'foo', u'bar'], True) == u'foo=bar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode(u'foo') == u'foo'

# Generated at 2022-06-11 14:17:53.888964
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert hasattr(filter_module, 'filters')
    assert callable(filter_module.filters)
    assert isinstance(filter_module.filters(), dict)


# Generated at 2022-06-11 14:18:07.658533
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'\u2713'
    assert unicode_urlencode(string) == u'%E2%9C%93'


# Generated at 2022-06-11 14:18:13.470010
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Tests if the string method of FilterModule works"""
    filters = FilterModule()
    assert do_urldecode(u"str%C3%ABng") == u"strëng"
    assert do_urldecode("str%C3%ABng") == "strëng"

    if not HAS_URLENCODE:
        assert do_urlencode(u"strëng") == u"str%C3%ABng"
        assert do_urlencode("strëng") == "str%C3%ABng"

# Generated at 2022-06-11 14:18:19.813987
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a%2Bb') == u'a+b'
    assert unicode_urldecode(b'a+b') == u'a b'
    assert unicode_urldecode(b'a%2Bb') == u'a+b'
    print('ok')


# Generated at 2022-06-11 14:18:25.713010
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import six
    import sys

    if six.PY2:
        assert unicode_urldecode(b'foo%3F%3Dbar') == u'foo?=bar'
        assert unicode_urldecode(u'foo%3F%3Dbar') == u'foo?=bar'
    else:
        assert unicode_urldecode(b'foo%3F%3Dbar') == 'foo?=bar'
        assert unicode_urldecode('foo%3F%3Dbar') == 'foo?=bar'



# Generated at 2022-06-11 14:18:34.471862
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == u""
    assert unicode_urldecode("foobar") == u"foobar"
    assert unicode_urldecode("foo%2Bbar") == u"foo+bar"
    assert unicode_urldecode("foo%2Bbar%2Bbaz") == u"foo+bar+baz"
    assert unicode_urldecode("foo%20bar") == u"foo bar"
    assert unicode_urldecode("foo+bar") == u"foo bar"
    assert unicode_urldecode("foo+bar+baz") == u"foo bar baz"


# Generated at 2022-06-11 14:18:39.160456
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.utils.unicode import to_unicode
    assert unicode_urldecode('%7B%22a%22%3A1%2C%22b%22%3A2%7D') == to_unicode(u'{"a":1,"b":2}')


# Generated at 2022-06-11 14:18:41.444152
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+bar') == 'foo bar'


# Generated at 2022-06-11 14:18:49.916492
# Unit test for function do_urlencode
def test_do_urlencode():
    input = {
        "postgresql": {
            "conf": {
                "master": {
                    "postgresql_master_port": 5443,
                    "postgresql_master_ssl": {
                        "postgresql_master_ssl_cert": "/etc/myhostcert.pem",
                        "postgresql_master_ssl_key": "/etc/myhostkey.pem",
                        "postgresql_master_ssl_ca": "/etc/mycacert.pem",
                        "postgresql_master_ssl_crl": "/etc/mycrl.pem",
                    }
                }
            }
        }
    }
    output = do_urlencode(input)