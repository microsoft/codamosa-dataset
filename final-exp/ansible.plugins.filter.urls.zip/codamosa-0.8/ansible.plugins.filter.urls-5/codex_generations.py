

# Generated at 2022-06-11 14:08:57.443019
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("2%F2") == u'2ò'
    assert do_urlencode("2ò") == u'2%F2'
    assert do_urlencode("2ò&") == u'2%F2%26'
    assert do_urlencode([u"2ò", u"&"]) == u'2%F2&%26'
    assert do_urlencode({u"2ò": u"&"}) == u'2%F2=%26'
    return

# Generated at 2022-06-11 14:09:02.978236
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a') == u'a'
    assert unicode_urldecode(u'%7B%22hi%22%3A+%22there%22%7D') == u'{"hi": "there"}'
    assert unicode_urldecode(u'%C3%A9g%C3%A9rie') == u'égérie'



# Generated at 2022-06-11 14:09:07.299874
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2F') == u'http://'
    assert unicode_urldecode(b'http%3A%2F%2F') == u'http://'
    try:
        unicode_urldecode('http%3A%2F%2F')
        assert False, 'Should throw a TypeError'
    except TypeError:
        pass


# Generated at 2022-06-11 14:09:19.459597
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Test expected behavior with ASCII input
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo bar') == 'foo bar'
    assert unicode_urldecode(' foo ') == ' foo '
    assert unicode_urldecode('  foo  ') == '  foo  '
    assert unicode_urldecode(' foo   bar ') == ' foo   bar '
    assert unicode_urldecode(' foo   bar  ') == ' foo   bar  '
    assert unicode_urldecode(' foo   bar') == ' foo   bar'
    assert unicode_urldecode('foo   bar ') == 'foo   bar '
    assert unicode_urldecode('foo ') == 'foo '
    assert unicode_urld

# Generated at 2022-06-11 14:09:21.737313
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'a%3Db%26c%3Dd' == unicode_urlencode(u'a=b&c=d')



# Generated at 2022-06-11 14:09:23.954886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    this_filter = FilterModule()
    assert do_urldecode("@") == this_filter.filters()['urldecode']("@")
    if not HAS_URLENCODE:
        assert do_urlencode("@") == this_filter.filters()['urlencode']("@")


# Generated at 2022-06-11 14:09:32.783594
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'key=value') == u'key%3Dvalue'
    assert do_urlencode(u'key=value&key2=value2') == u'key%3Dvalue&key2%3Dvalue2'
    assert do_urlencode(u'a') == u'a'
    assert do_urlencode(u'1') == u'1'
    assert do_urlencode(1) == u'1'
    assert do_urlencode(u' ') == u'+'
    assert do_urlencode(u'a/b') == u'a%2Fb'
    assert do_urlencode(u'a=b') == u'a%3Db'

# Generated at 2022-06-11 14:09:44.411471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Checks the function unicode_urldecode
    '''
    # Test parameters and expected results

# Generated at 2022-06-11 14:09:49.938276
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("'%20%21") == "' !"
    assert unicode_urldecode("%C3%AA") == u'ê'
    assert unicode_urldecode("%E2%82%AC") == u'€'



# Generated at 2022-06-11 14:09:53.993478
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == 'äöü'
    assert unicode_urldecode('%25%C3%A4%C3%B6%C3%BC') == '%äöü'


# Generated at 2022-06-11 14:10:05.897973
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    #
    # Function unicode_urlencode
    #
    assert unicode_urlencode(u'test') == u'test'
    assert unicode_urlencode(u'test/') == u'test%2F'
    assert unicode_urlencode(u'test', for_qs=True) == u'test'
    assert unicode_urlencode(u'test/', for_qs=True) == u'test%2F'
    assert unicode_urldecode(u'test') == u'test'
    assert unicode_urldecode(u'test%2F') == u'test/'
    assert unicode_urldecode(u'test') == u'test'
    assert unicode_urldecode(u'test%2F') == u'test/'

# Generated at 2022-06-11 14:10:14.168913
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('foo+%40+bar') == 'foo @ bar'
        assert unicode_urldecode('foo%3Dbar') == 'foo=bar'
        assert unicode_urldecode(u'foo+%40+bar') == 'foo @ bar'
        assert unicode_urldecode(u'foo%3Dbar') == 'foo=bar'
    else:
        assert unicode_urldecode('foo+%40+bar') == u'foo @ bar'
        assert unicode_urldecode('foo%3Dbar') == u'foo=bar'
        assert unicode_urldecode(u'foo+%40+bar') == u'foo @ bar'

# Generated at 2022-06-11 14:10:16.477876
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'www.example.com/?x%26=x') == u'www.example.com/?x&=x'


# Generated at 2022-06-11 14:10:17.389396
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-11 14:10:26.517360
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(to_text('')) == u''
    # http://tools.ietf.org/html/rfc3986#page-21
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%2A') == u'foo*'
    assert unicode_urldecode(u'foo%2a') == u'foo*'
    assert unicode_urldecode(u'foo%2a%2B') == u'foo*+'
    assert unicode_urldecode(u'foo%2a+%2B') == u'foo* +'
    # http://tools.ietf.org/html/rfc3986#appendix-A
    assert unicode_urldecode

# Generated at 2022-06-11 14:10:34.917101
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"This+string%2C+with%3A+symbols%21") == u"This string, with: symbols!"
    assert unicode_urldecode(u"%E3%83%86%E3%82%B9%E3%83%88") == u"テスト"
    assert unicode_urldecode(u"%E3%83%86%E3%82%B9%E3%83%88".encode('utf-8')) == u"テスト"
    assert unicode_urldecode(u"アンビリーバブル") == u"アンビリーバブル"



# Generated at 2022-06-11 14:10:41.196327
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode_urlencode ünicode_urlencode') == 'unicode_urlencode+%C3%BCnicode_urlencode'
    assert unicode_urlencode(u'unicode_urlencode ünicode_urlencode', for_qs=True) == 'unicode_urlencode+%C3%BCnicode_urlencode'


# Generated at 2022-06-11 14:10:45.197647
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('%7E')) == '~'
    assert(unicode_urldecode('~')) == '~'
    assert(unicode_urldecode('%7E%25%3F')) == '~%?'


# Generated at 2022-06-11 14:10:54.503338
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo=bar') == u'foo%3Dbar'

# Generated at 2022-06-11 14:11:02.797832
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://server/~user/foo bar/') == 'http%3A//server/~user/foo%20bar/'
    assert unicode_urlencode(u'http://server/~user/foo bar/?a=1&b=2') == 'http%3A//server/~user/foo%20bar/%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://server/~user/foo bar/?a=1&b=2', for_qs=True) == 'http%3A%2F%2Fserver%2F%7Euser%2Ffoo%20bar%2F%3Fa%3D1%26b%3D2'

# Generated at 2022-06-11 14:11:12.060257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ('%20', ' '),
        ('x+y', 'x y'),
        ('foo%2Bbar', 'foo+bar'),
        ('%C2%B5', 'μ'),
        ('%7E', '~'),
    ]
    for urlencoded, decoded in test_cases:
        if unicode_urldecode(urlencoded) != decoded:
            print('Failed to decode %s' % urlencoded)
            print('Decoded %s, expected %s' % (unicode_urldecode(urlencoded), decoded))
            exit(1)


# Generated at 2022-06-11 14:11:20.922713
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_bytes, to_text
    from jinja2 import Environment
    from ansible.utils.display import Display
    # Need for assert unicode_type
    import sys

    env = Environment(extensions=[u'jinja2.ext.i18n'])
    display = Display()

    env.loader = None
    env.finalize()
    filters = FilterModule().filters()

    for filter_name in list(filters.keys()):
        display.vvvv(u'Testing jinja2 filter %s' % filter_name)
        env.filters[filter_name] = filters[filter_name]
        name = u'test_filter_%s' % filter_name
        filter_testfunc = globals().get(name)

# Generated at 2022-06-11 14:11:24.619581
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert len(filters) == 2
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:11:29.473588
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%2F') == '//'
    assert unicode_urldecode('/test') == '/test'
    assert unicode_urldecode('/test%2Ftest') == '/test/test'
    assert unicode_urldecode('/test/test') == '/test/test'



# Generated at 2022-06-11 14:11:39.193819
# Unit test for function do_urlencode
def test_do_urlencode():
    data = {
        u'føø': [u'bår', u'baz', 42],
        42: u'what',
    }
    encoded1 = u'f%C3%B8%C3%B8=b%C3%A5r&f%C3%B8%C3%B8=baz&f%C3%B8%C3%B8=42&42=what'
    encoded2 = u'42=what&f%C3%B8%C3%B8=b%C3%A5r&f%C3%B8%C3%B8=baz&f%C3%B8%C3%B8=42'

# Generated at 2022-06-11 14:11:43.631576
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"Hello%20World%21") == to_text("Hello World!")
    assert unicode_urldecode(u"Hello+World%21") == to_text("Hello World!")
    assert unicode_urldecode(u"Hello+%26+World%21") == to_text("Hello & World!")


# Generated at 2022-06-11 14:11:45.516483
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    original = '''`!@#$%^&*()-_=+[]{}\\|;:'",<>/?~ \t '''
    encoded = do_urlencode(original)
    decoded = unicode_urldecode(encoded)

    assert original == decoded

# Generated at 2022-06-11 14:11:47.647125
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:11:56.841911
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http:%2F%2Fwww.python.org') == u'http://www.python.org'
    assert unicode_urldecode(u'http:%2F%2Fwww.python.org?foo=bar') == u'http://www.python.org?foo=bar'
    assert unicode_urldecode(u'http:%2F%2Fwww.python.org?foo=bar%20baz') == u'http://www.python.org?foo=bar baz'
    assert unicode_urldecode(u'http:%2F%2Fwww.python.org?foo=bar+baz') == u'http://www.python.org?foo=bar baz'

# Generated at 2022-06-11 14:12:05.385352
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo%40bar') == 'foo%2540bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode('foo;bar') == 'foo%3Bbar'
    assert do_urlencode('foo=bar') == 'foo=bar'
    assert do_urlencode('foo?bar') == 'foo?bar'
    assert do_

# Generated at 2022-06-11 14:12:09.397700
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'urldecode' in FilterModule().filters()
    assert 'urlencode' in FilterModule().filters()

# Generated at 2022-06-11 14:12:15.025029
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb+%26+c%3Dd') == 'a+b & c=d'
    assert unicode_urldecode('a%2Bb+%26+%c3%b3%3Dd') == 'a+b & ó=d'


# Generated at 2022-06-11 14:12:20.574518
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo%20bar') == u'foo bar'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode(['foo', 'bar']) == 'foo&bar'
    assert do_urlencode((' foo', ' bar ')) == '%20foo&%20bar%20'



# Generated at 2022-06-11 14:12:32.264137
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert filters['urldecode']('%41%42%43') == u'ABC'
    assert filters['urldecode']('%E3%82%A2%E3%82%A4%E3%82%B3') == u'アイコ'
    assert filters['urldecode']('%FE%FF%00%41') == u'A'
    assert filters['urldecode']('%FE%FF%00A') == u'A'
    assert filters['urldecode']('%41%42%43') == u'ABC'

# Generated at 2022-06-11 14:12:37.258664
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'urldecode' in filters
    assert callable(filters['urldecode'])
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert callable(filters['urlencode'])
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:12:40.039243
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%80%81%82') == u'\u20ac\u0081\u201a'

# Test module for function unicode_urlencode

# Generated at 2022-06-11 14:12:47.136753
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%3a') == u':'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%7e') == u'~'
    assert unicode_urldecode('%25') == u'%'

# Unit tests for function do_urldecode

# Generated at 2022-06-11 14:12:53.628966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%2F%3F%3D%26') == u'/=&'
    assert unicode_urldecode('%2F%C3%A9%3F%3D%26') == u'/é=&'



# Generated at 2022-06-11 14:12:56.290264
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'https://www.ansible.com/') == u'https%3A//www.ansible.com/'



# Generated at 2022-06-11 14:13:04.825446
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'](u'foo+1%20bar%E2%82%AC') == u'foo 1 bar\u20ac'
    assert FilterModule().filters()['urldecode'](u'a+%27b%27') == u'a \'b\''
    assert FilterModule().filters()['urldecode'](u'%7B%22foo%22%3A%22bar%22%7D') == u'{"foo":"bar"}'

    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'](u'foo 1 bar\u20ac') == u'foo+1+bar%E2%82%AC'
        assert FilterModule().filters()['urlencode'](u'a \'b\'') == u

# Generated at 2022-06-11 14:13:14.899848
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import quote_plus as urllib_quote_plus
    from ansible.module_utils.six.moves.urllib.parse import quote as urllib_quote
    # In Python 3 quote('foo') uses '/' as safe character, while in Python 2
    # quote_plus('foo') was the same as quote('foo', safe='').
    if PY3:
        assert unicode_urlencode('foo/bar') == urllib_quote('foo/bar')
        assert unicode_urlencode('foo/bar', for_qs=True) == urllib_quote_plus('foo/bar')
    else:
        assert unicode_urlencode('foo/bar') == urllib_quote('foo/bar', safe='/')

# Generated at 2022-06-11 14:13:16.854634
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test.filters() == {'urldecode': do_urldecode}



# Generated at 2022-06-11 14:13:23.480574
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test that jinja2.filters.do_urlencode is exposed when available,
    # and do_urlencode is exposed otherwise
    mod = FilterModule()
    assert 'urlencode' in mod.filters()
    if HAS_URLENCODE:
        assert mod.filters()['urlencode'] == do_urlencode
        assert mod.filters()['urldecode'] == do_urldecode
    else:
        assert mod.filters()['urlencode'] == unicode_urlencode
        assert mod.filters()['urldecode'] == unicode_urldecode

# Generated at 2022-06-11 14:13:33.261281
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    urldecode = unicode_urldecode
    assert urldecode('%20') == u' '
    assert urldecode('%7E') == u'~'
    assert urldecode('%21') == u'!'
    assert urldecode('%40') == u'@'
    assert urldecode('%23') == u'#'
    assert urldecode('%24') == u'$'
    assert urldecode('%26') == u'&'
    assert urldecode('%27') == u"'"
    assert urldecode('%28') == u'('
    assert urldecode('%29') == u')'
    assert urldecode('%2A') == u'*'

# Generated at 2022-06-11 14:13:43.381104
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = unicode(u'ü') # 2-byte
    assert u'ü' == unicode_urldecode(s)
    s = unicode(u'%C3%BC') # 3-byte
    assert u'ü' == unicode_urldecode(s)
    s = unicode(u'%E3%81%82') # 3-byte
    assert u'あ' == unicode_urldecode(s)
    s = unicode(u'\u0123') # 4 byte
    assert u'\u0123' == unicode_urldecode(s)
    s = unicode(u'%F0%90%8C%BC')
    assert u'𐌼' == unicode_urldecode(s)

# Generated at 2022-06-11 14:13:46.299577
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('do+re%2Fmi') == 'do%2Bre%252Fmi'
    assert unicode_urlencode(unicode('do+re%2Fmi')) == 'do%2Bre%252Fmi'

# Generated at 2022-06-11 14:13:57.474523
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('1 2 3') == '1%202%203'
    assert unicode_urlencode('1 2 3', for_qs=True) == '1+2+3'
    assert unicode_urlencode('a & b') == 'a+%26+b'
    assert unicode_urlencode('a & b', for_qs=True) == 'a+%26+b'
    assert unicode_urlencode({'a & b': 'a + b'}) == 'a+%26+b=a+%2B+b'

# Generated at 2022-06-11 14:14:03.996794
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2525') == u'%25'
    assert unicode_urldecode(u'%2F%2F') == u'//'
    assert unicode_urldecode(u'%2F%25%2F') == u'/%/'
    assert unicode_urldecode(u'%') == u'%'
    assert unicode_urldecode(u'%%') == u'%'


# Generated at 2022-06-11 14:14:06.364469
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == dict(urldecode=do_urldecode)


# Generated at 2022-06-11 14:14:14.300130
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''import unittest
    class TestTemplateFilters(unittest.TestCase):
    def test_unicode_urldecode(self):'''
    assert unicode_urldecode('foo+bar') == u'foo bar'
    assert unicode_urldecode('foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode('foo%252Bbar') == u'foo%2Bbar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo+%20bar') == u'foo  bar'


# Generated at 2022-06-11 14:14:21.900657
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    param = u'http://localhost:8080/test?arg=val&arg2=val2'
    if PY3:
        assert u'http://localhost:8080/test?arg=val&arg2=val2' == unicode_urlencode(param)
        assert u'http://localhost:8080/test%3Farg=val%26arg2=val2' == unicode_urlencode(param, for_qs=True)
    else:
        assert u'http://localhost:8080/test?arg=val&arg2=val2' == unicode_urlencode(param)
        assert u'http://localhost:8080/test%3Farg=val%26arg2=val2' == unicode_urlencode(param, for_qs=True)


# Generated at 2022-06-11 14:14:27.252564
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'Hello%2c+world%21+%E4%BA%BA%E6%B0%91%E5%A4%A7%E7%9A%84%E5%B7%B4%E5%90%88') == u'Hello, world! 人民大的巴合'



# Generated at 2022-06-11 14:14:32.170848
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if not PY3:
        data = {
            "%3Cstrong%3E": "<strong>",
        }
        for string, result in iteritems(data):
            assert unicode_urldecode(string) == result, 'unicode_urldecode failed to return %s' % result


# Generated at 2022-06-11 14:14:35.231997
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('dag%40wieers.com') == u'dag@wieers.com'



# Generated at 2022-06-11 14:14:41.493977
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'ä') == u'ä'
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4') == u'ä'
    assert unicode_urldecode(u'%C3%A4') == u'ä'


# Generated at 2022-06-11 14:14:46.650344
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    def do_test(filters):
        assert filters['urldecode']('%7Eelvis') == '~elvis'
        if not HAS_URLENCODE:
            assert filters['urlencode']('~elvis') == '%7Eelvis'

    fm = FilterModule()
    do_test(fm.filters())



# Generated at 2022-06-11 14:14:53.535264
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_instance = FilterModule()
    test_result = filters_instance.filters()

    assert type(test_result) == dict
    assert list(test_result.keys()) == ['urldecode']  # noqa: E501

    assert test_result['urldecode'](None) is None
    assert test_result['urldecode']('spam') == 'spam'
    assert test_result['urldecode']('%0A%0Dtest+%C3%A9%0A%0D') == '\ntest é\n'

# Generated at 2022-06-11 14:15:02.505165
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:15:13.060435
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert (unicode_urlencode('%s') == b'%25s')
    assert (unicode_urlencode('%s', for_qs=True) == b'%25s')
    assert (unicode_urlencode('%25s') == b'%2525s')
    assert (unicode_urlencode('%25s', for_qs=True) == b'%2525s')
    assert (unicode_urlencode('a') == b'a')
    assert (unicode_urlencode('a', for_qs=True) == b'a')
    assert (unicode_urlencode('?a=1') == b'%3Fa%3D1')

# Generated at 2022-06-11 14:15:16.726960
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(to_bytes('test+1')) == to_text('test 1')
    assert unicode_urldecode(to_bytes('test%21')) == to_text('test!')


# Generated at 2022-06-11 14:15:27.401289
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:15:31.775256
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test result with and without urlencode filter from Jinja2
    x = FilterModule()
    if HAS_URLENCODE:
        assert x.filters()['urlencode'] == do_urlencode
    else:
        assert x.filters()['urlencode'] == do_urlencode
    assert x.filters()['urldecode'] == do_urldecode



# Generated at 2022-06-11 14:15:40.375018
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm
    assert fm.filters
    filters = fm.filters()
    assert filters
    assert isinstance(filters, dict)
    assert len(filters) == 2
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    if HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode
    else:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:15:41.740261
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule(object).filters(), dict)

# Generated at 2022-06-11 14:15:45.477705
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:15:50.477013
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo+') == u'foo%2B'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'


# Generated at 2022-06-11 14:15:59.443921
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode('eggs') == 'eggs'
    assert unicode_urlencode('spam spam') == 'spam+spam'
    assert unicode_urlencode('foo@bar.com') == 'foo%40bar.com'
    assert unicode_urlencode('eggs and spam') == 'eggs+and+spam'
    assert unicode_urlencode("a b") == 'a+b'
    assert unicode_urlencode("+") == '%2B'
    assert unicode_urlencode("==?") == '%3D%3D%3F'
    assert unicode_urlencode("a/b") == 'a%2Fb'

# Generated at 2022-06-11 14:16:02.455896
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert not HAS_URLENCODE
    fm = FilterModule()
    fmfilters = fm.filters()
    assert 'urldecode' in fmfilters
    assert 'urlencode' in fmfilters

# Generated at 2022-06-11 14:16:08.889713
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class MockModule(object):
        pass

    class MockConfig(object):
        pass

    class MockArgs(object):
        pass

    filter_module = FilterModule()
    assert(filter_module.filters() == {'urldecode': unicode_urldecode})
    assert(filter_module.filters() == {'urldecode': unicode_urldecode, 'urlencode': unicode_urlencode})


# Generated at 2022-06-11 14:16:15.148078
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Check for decoded strings
    assert unicode_urldecode(u'Az\xc3\xa9rt+m\xc3\xa1r+itt+j%C3%B3') == u'Az\xe9rt m\xe1r itt j\xf3'
    assert unicode_urldecode('Az\xc3\xa9rt+m\xc3\xa1r+itt+j%C3%B3') == 'Azért már itt jó'



# Generated at 2022-06-11 14:16:27.832661
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm is not None
    ff = fm.filters()
    assert ff is not None
    # test urldecode
    assert ff['urldecode']('http%3A%2F%2Fwww.example.com%2Fpage.htm') == 'http://www.example.com/page.htm'
    # test urlencode
    assert ff['urlencode']('http://www.example.com/page.htm') == 'http%3A%2F%2Fwww.example.com%2Fpage.htm'
    assert ff['urlencode'](('foo', 'bar')) == 'foo&bar'
    assert ff['urlencode']({'foo': 'bar'}) == 'foo=bar'

# Generated at 2022-06-11 14:16:36.823031
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc def') == u'abc def'
    assert unicode_urldecode('abc+def') == u'abc def'
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%2Bdef') == u'abc+def'
    assert unicode_urldecode('abc%2bdef') == u'abc+def'
    assert unicode_urldecode('abc%def') == u'abc%def'
    assert unicode_urldecode('abc%2') == u'abc%2'


# Generated at 2022-06-11 14:16:43.470221
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'foobar' == unicode_urldecode('foobar')
    assert u'foo bar' == unicode_urldecode('foo%20bar')
    assert u'fooäå' == unicode_urldecode('foo%C3%A4%C3%A5')
    assert u'fooäå' == unicode_urldecode('foo%c3%a4%c3%a5')
    assert u'fooäå' == unicode_urldecode('foo%C3%a4%c3%A5')
    assert u'fooäå' == unicode_urldecode('foo%c3%A4%C3%a5')



# Generated at 2022-06-11 14:16:52.789956
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(u'a%02b+c/d') == u'a+b c/d'
    assert do_urlencode(u'a+b c/d') == u'a%2Bb+c%2Fd'
    assert do_urlencode({u'x': u'a+b c/d', u'y': u'e=1'}) == u'x=a%2Bb+c%2Fd&y=e%3D1'
    import sys
    if sys.version_info[0] < 3:
        assert do_urlencode(['a', 'e=1']) == u'0=a&1=e%3D1'

# Generated at 2022-06-11 14:17:01.644189
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%C3%A9') == u'\u00e9'
    assert unicode_urldecode(b'%7Bname%7D') == u'{name}'
    # The following case is normal when using urllib.urlencode()
    assert unicode_urldecode(b'%E2%98%83%40%E2%98%83%E2%98%83') == u'\u2603@\u2603\u2603'
    # The following case is normal when using URIs instead of URL encoded data

# Generated at 2022-06-11 14:17:07.417554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    for name, f in iteritems(filters):
        print(name + ': ' + str(f))
        if name == 'urldecode':
            assert f('Foo%20Bar%40here') == 'Foo Bar@here'
        if name == 'urlencode':
            assert f('Foo Bar@here') == 'Foo+Bar%40here'

# Generated at 2022-06-11 14:17:11.806326
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'døg') == u'd%C3%B8g'
    assert do_urlencode({u'@': u'døg'}) == u'%40=d%C3%B8g'
    assert do_urlencode({'@': u'døg'}) == u'%40=d%C3%B8g'

# Generated at 2022-06-11 14:17:18.710916
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('Hello%20World%21') == 'Hello World!'

    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('Hello World!') == 'Hello%20World%21'
        assert fm.filters()['urlencode'](dict(a='Hello World!')) == 'a=Hello%20World%21'
        assert fm.filters()['urlencode'](['a', 'Hello World!']) == 'a=Hello%20World%21'

# Generated at 2022-06-11 14:17:20.849425
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%23%2F%40%3F%3D%3B%26') == '#/@?=;&'



# Generated at 2022-06-11 14:17:28.555915
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # non-ASCII string
    assert unicode_urldecode(u'\u4f60\u597d') == u'\u4f60\u597d'
    # not unicode
    assert unicode_urldecode('%26%23x4f60%3b%26%23x597d%3b') == u'\u4f60\u597d'
    # not unicode
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD') == u'\u4f60\u597d'
    # unicode
    assert unicode_urldecode(u'%E4%BD%A0%E5%A5%BD') == u'\u4f60\u597d'
    # not unicode

# Generated at 2022-06-11 14:17:41.973464
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils._text import to_bytes, to_native
    filter_module = FilterModule()
    filters = filter_module.filters()
    urldecode = filters['urldecode']
    urlencode = filters['urlencode']


# Generated at 2022-06-11 14:17:51.346715
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'string_with_characters_that_need_encoding: %') == u'string_with_characters_that_need_encoding%3A%20%25'
    assert unicode_urlencode(u'string_with_characters_that_need_encoding: %', for_qs=True) == u'string_with_characters_that_need_encoding%3A+%25'
    assert unicode_urlencode(u'string_with_characters_that_need_encoding: %/') == u'string_with_characters_that_need_encoding%3A%20%25%2F'


# Generated at 2022-06-11 14:18:01.355300
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('/') == '%2F'
    assert do_urlencode('/=?&') == '%2F%3D%3F%26'
    assert do_urlencode('=') == '%3D'
    assert do_urlencode('?') == '%3F'
    assert do_urlencode('&') == '%26'
    assert do_urlencode(' ') == '%20'
    assert do_urlencode('"') == '%22'
    assert do_urlencode('$') == '%24'
    assert do_urlencode('<') == '%3C'
    assert do_urlencode('>') == '%3E'
    assert do_urlencode('%') == '%25'
    assert do_urlen

# Generated at 2022-06-11 14:18:07.424719
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    import unittest

    class TestUrldecode(unittest.TestCase):
        def testPy3(self):
            self.assertEqual(unicode_urldecode('foo%2Bbar'), 'foo+bar')

        if not PY3:
            def testPy2(self):
                self.assertEqual(unicode_urldecode('foo%2Bbar'), u'foo+bar')
    unittest.main(argv=[sys.argv[0]])


# Generated at 2022-06-11 14:18:15.053239
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fwww.ansible.com%2F') == u'http://www.ansible.com/'
    assert unicode_urldecode(u'module%2B%2B%2B%2B%2B%2Bexecution%2Faction%2B%2B%2B%2B%2B%2B') == u'module++++execution/action++++'
    assert unicode_urldecode(u'foobar%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B') == u'foobar++++++++++++'

# Generated at 2022-06-11 14:18:18.034399
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ff = FilterModule().filters()
    assert do_urldecode(u"Tønder") == unicode_urldecode(u"T%C3%B8nder")

# Generated at 2022-06-11 14:18:25.929566
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'abc-%7F') == u'abc-\x7f'
    assert unicode_urldecode(b'abc-%7f') == u'abc-\x7f'
    assert unicode_urldecode(b'abc-%F7') == u'abc-\xf7'
    assert unicode_urldecode(b'abc-%f7') == u'abc-\xf7'
    assert unicode_urldecode(b'abc-%2f') == u'abc-/'
    assert unicode_urldecode(b'abc-%2F') == u'abc-/'

# Generated at 2022-06-11 14:18:32.514013
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'\xE4'
    assert unicode_urldecode('%c3%a4') == u'\xE4'
    assert unicode_urldecode('%C3%A4+') == u'\xE4+'
    assert unicode_urldecode('%c3%a4+') == u'\xE4+'


# Generated at 2022-06-11 14:18:35.329164
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == b'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == b'foo+bar'


# Generated at 2022-06-11 14:18:46.504175
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%3f') == '?'
    assert unicode_urldecode('%3F') == '?'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%252f') == '%2f'
    assert unicode_urldecode('%2b') == '+'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3d') == '='