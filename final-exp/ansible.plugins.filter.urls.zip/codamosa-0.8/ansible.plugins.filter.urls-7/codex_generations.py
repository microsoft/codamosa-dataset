

# Generated at 2022-06-11 14:08:50.538681
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wieers') == u'dag wieers'
    assert unicode_urldecode('dag%20wieers') == u'dag wieers'


# Generated at 2022-06-11 14:09:01.610889
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert b'a%2Fb' == unicode_urlencode('a/b')
        assert b'a%3D1%26b%3D2' == unicode_urlencode('a=1&b=2', for_qs=True)
        assert b'%C3%A4' == unicode_urlencode(u'\u00E4')
    else:
        assert 'a%2Fb' == unicode_urlencode('a/b')
        assert 'a%3D1%26b%3D2' == unicode_urlencode('a=1&b=2', for_qs=True)
        assert '%C3%A4' == unicode_urlencode(u'\u00E4')



# Generated at 2022-06-11 14:09:03.231763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\xe9'


# Generated at 2022-06-11 14:09:06.962625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class MockModule(object):
        ''' Mocking class to simulate an ansible module '''
        def __init__(self):
            self.params = {}

    # Initialize a dummy module
    module = MockModule()
    f = FilterModule()
    assert f.filters()['urldecode']('foo%20bar') == 'foo bar'



# Generated at 2022-06-11 14:09:19.104059
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\xc3\xa9') == u'%C3%A9'
    assert unicode_urlencode(u'\xc3\xa9', True) == u'%C3%A9'
    assert unicode_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert unicode_urlencode(u'foo=bar', True) == u'foo%3Dbar'
    assert unicode_urlencode(u'foo?bar+baz') == u'foo%3Fbar%2Bbaz'
    assert unicode_urlencode(u'foo?bar+baz', True) == u'foo%3Fbar%2Bbaz'

# Generated at 2022-06-11 14:09:26.902849
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_data = [
        ("%2F", "/", "Incorrect decoding"),
        ("%7E", "~", "Incorrect decoding"),
        ("%40", "@", "Incorrect decoding"),
        ("%24", "$", "Incorrect decoding"),
        ("%00", "\x00", "Incorrect decoding"),
    ]
    for test_item in test_data:
        source, expected, msg = test_item
        actual = unicode_urldecode(source)
        assert actual == expected, msg



# Generated at 2022-06-11 14:09:36.512268
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.org/') == u'http://www.example.org/'
    assert unicode_urlencode(u'http://www.example.org/', for_qs=True) == u'http%3A%2F%2Fwww.example.org%2F'
    assert unicode_urlencode(u'http://www.example.org/%201') == u'http://www.example.org/%25201'
    assert unicode_urlencode(u'http://www.example.org/%201', for_qs=True) == u'http%3A%2F%2Fwww.example.org%2F%25201'
    assert unicode_urlencode(u'http://www.example.org/%2f') == u

# Generated at 2022-06-11 14:09:46.466184
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/test?test=test#test') == '/test%3Ftest=test%23test'
    assert unicode_urlencode('/test?test=test#test', for_qs=True) == '/test%3Ftest%3Dtest%23test'
    assert unicode_urlencode('/кириллица-test?test=test#test') == '/%D0%BA%D0%B8%D1%80%D0%B8%D0%BB%D0%BB%D0%B8%D1%86%D0%B0-test%3Ftest=test%23test'

    assert unicode_urldecode('/test%3Ftest=test%23test') == '/test?test=test#test'
   

# Generated at 2022-06-11 14:09:49.747371
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2F%2F') == u'//', 'unicode_urldecode decoding error'


# Generated at 2022-06-11 14:09:56.942293
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(u'foo' == unicode_urlencode(u'foo'))
    assert('%2B' == unicode_urlencode(u'+'))
    assert('%2B' == unicode_urlencode(u'%2B'))
    assert('%2B' == unicode_urlencode(u'%2B', for_qs=True))
    try:
        assert(u'foo' == unicode_urlencode(u'foo'.encode('UTF-8')))
    except:
        assert(u'foo' == unicode_urlencode(u'foo'.encode('UTF-8').decode('utf-8')))


# Generated at 2022-06-11 14:10:07.175771
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == 'test'
    assert u'中文'.encode('utf-8') == unicode_urldecode('%E4%B8%AD%E6%96%87')
    assert unicode_urldecode('%41%42') == 'AB'
    assert unicode_urldecode('%41%42+%43%44') == 'AB CD'
    assert unicode_urldecode('%41%42%43%44') == 'ABCD'
    assert unicode_urldecode('%61%62') == 'ab'
    assert unicode_urldecode('%00%42%43%44') == '\x00BCD'

# Generated at 2022-06-11 14:10:14.630107
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%7Ebr%2Foo%7E%20and%20%7Ebr%2Foke%7E') == u'~br/oo~ and ~br/oke~'
    assert do_urlencode('Hello World!') == 'Hello%20World%21'
    assert do_urlencode('http://foo.org/bar') == 'http%3A%2F%2Ffoo.org%2Fbar'
    assert do_urlencode('/tmp/something/') == '%2Ftmp%2Fsomething%2F'
    assert do_urlencode({'foo': 'bar', 'baz': 'föö'}) == 'foo=bar&baz=f%C3%B6%C3%B6'

# Generated at 2022-06-11 14:10:22.011479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    filters = test.filters()

    # Test urldecode
    assert filters['urldecode']('abc+def') == 'abc+def'
    assert filters['urldecode']('foo%20bar') == 'foo bar'

    # Test urlencode
    assert filters['urlencode']('abc def') == 'abc+def'
    assert filters['urlencode']('foo bar') == 'foo+bar'
    assert filters['urlencode']({'foo': 'bar'}) == 'foo=bar'

# Generated at 2022-06-11 14:10:28.697707
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # "Some characters cannot be part of a URL (for example, the space) and some other characters have a special meaning in a URL. In HTML forms, the character = is used to separate a name from a value."
    # http://www.w3schools.com/tags/ref_urlencode.asp
    assert unicode_urldecode("http%3A%2F%2Fwww.w3schools.com%2Ftags%2Fref_urlencode.asp") == "http://www.w3schools.com/tags/ref_urlencode.asp"
    assert unicode_urldecode("http://www.w3schools.com/tags/ref_urlencode.asp") == "http://www.w3schools.com/tags/ref_urlencode.asp"
    assert unicode_ur

# Generated at 2022-06-11 14:10:30.712674
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('dag%20wieers') == 'dag wieers'

# Generated at 2022-06-11 14:10:37.191690
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:10:46.787978
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Straight Python results
    assert u'abc' == unicode_urldecode('abc')
    assert u'abc' == unicode_urldecode('abc')
    assert u'abc' == unicode_urldecode('abc')
    assert u'abc' == unicode_urldecode('abc')
    assert u'abc' == unicode_urldecode('abc')
    assert u'abc' == unicode_urldecode('abc')
    assert u'abc' == unicode_urldecode(b'abc')

    # Characters that need escaping
    assert u'abc def' == unicode_urldecode('abc%20def')
    assert u'abc#def' == unicode_urldecode('abc%23def')
    assert u'abc def' == unicode_urld

# Generated at 2022-06-11 14:10:52.157971
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'abc123 @#:%' == unicode_urldecode(u'abc123%20%40%23%3A%25')
    assert u'abc123 @#:%' == unicode_urldecode('abc123%20%40%23%3A%25')
    assert b'abc123 @#:%' == unicode_urldecode(b'abc123%20%40%23%3A%25')



# Generated at 2022-06-11 14:10:56.353224
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    actual = obj.filters()
    expected = { 'urldecode': do_urldecode }
    if not HAS_URLENCODE:
        expected['urlencode'] = do_urlencode
    assert actual == expected


# Generated at 2022-06-11 14:11:03.616580
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves.urllib.parse import parse_qs, unquote_plus

    assert FilterModule().filters()['urldecode']('test') == 'test'
    assert FilterModule().filters()['urldecode']('test+test') == 'test test'
    assert FilterModule().filters()['urldecode']('+test+test') == ' test test'
    assert FilterModule().filters()['urldecode']('%2Btest%2Btest') == '+test+test'
    assert FilterModule().filters()['urldecode']('%2btest%2btest') == '+test+test'

    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('test') == 'test'

# Generated at 2022-06-11 14:11:16.608105
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    fn_urldecode = filters['urldecode']
    assert fn_urldecode('http%3A%2F%2Ffoo%2Ecom%2F') == 'http://foo.com/'

    if HAS_URLENCODE:
        fn_urlencode = filters['urlencode']
        assert fn_urlencode('http://foo.com/') == 'http%3A%2F%2Ffoo%2Ecom%2F'
        assert fn_urlencode('http://foo.com/') == fn_urldecode(fn_urldecode('http%3A%2F%2Ffoo%2Ecom%2F'))
    else:
        fn_urlencode = filters['urlencode']


# Generated at 2022-06-11 14:11:20.954521
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello') == 'hello'
    assert unicode_urldecode('hello+') == 'hello '
    assert unicode_urldecode('hello%20') == 'hello '
    assert unicode_urldecode('%E5%9C%A8%E4%B8%AD%E6%96%87') == u'在中文'.encode('utf-8')

# Generated at 2022-06-11 14:11:24.617999
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2B%2F%3D') == '+/='
    assert do_urlencode({'a': 1, 'b': u'♥'}) == 'a=1&b=%E2%99%A5'


# Generated at 2022-06-11 14:11:34.725305
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('Helo World') == 'Helo%20World'
    assert unicode_urlencode('Helo World', for_qs=True) == 'Helo+World'
    assert unicode_urlencode('Helo/World') == 'Helo%2FWorld'
    assert unicode_urlencode('Helo/World', for_qs=True) == 'Helo%2FWorld'
    assert unicode_urlencode('Helo:World') == 'Helo%3AWorld'
    assert unicode_urlencode('Helo:World', for_qs=True) == 'Helo%3AWorld'
    assert unicode_urlencode('Helo?World') == 'Helo%3FWorld'

# Generated at 2022-06-11 14:11:39.082139
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Python3.5.3 urllib.parse.unquote_plus('foo%42bar') returns 'fooBar'
    if PY3:
        assert unicode_urldecode('foo%42bar') == 'fooBbar'
    else:
        assert unicode_urldecode(u'foo%42bar') == u'fooBbar'



# Generated at 2022-06-11 14:11:42.219595
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = u'%A3%20%E6%B1%89%E6%BC%A2'
    assert unicode_urldecode(s) == u'£ 汉漢'



# Generated at 2022-06-11 14:11:48.711502
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode(u'\u00e0') == u'%C3%A0'
    assert unicode_urlencode(u'\u00e0\u20ac') == u'%C3%A0%E2%82%AC'
    assert unicode_urlencode(u'\u00e0\u20ac', for_qs=True) == u'%C3%A0%20%E2%82%AC'
    assert unicode_urlencode({}) == ''
    assert unicode_urlencode({u'k': u'v'}) == u'k=v'
    assert unicode_urlencode([(u'k', u'v')]) == u'k=v'

# Generated at 2022-06-11 14:11:54.891470
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode('%40') == u'@'
    assert unicode_urldecode(u'%40') == u'@'
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode(u'+') == u' '


# Generated at 2022-06-11 14:12:00.504783
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    x = FilterModule()
    f = x.filters()
    def test_filter_urldecode():
        assert f['urldecode']('foo%20bar') == "foo bar"
    if not HAS_URLENCODE:
        def test_filter_urlencode():
            assert f['urlencode']('foo bar') == "foo+bar"
    pytest.main([__file__, '-v'])

# Generated at 2022-06-11 14:12:02.962817
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('/') == u'/'


# Generated at 2022-06-11 14:12:10.272949
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:12:18.197670
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ('%C2%A3%20%22aa%22', u'£ "aa"'),
        ('%C2%A3+%22aa%22', u'£ "aa"'),
        (b'%C2%A3+%22aa%22', u'£ "aa"'),
    ]
    for (test, expect) in test_cases:
        result = unicode_urldecode(test)
        assert result == expect, \
            'Unexpected result for unicode_urldecode({}): {}'.format(test, result)



# Generated at 2022-06-11 14:12:24.358136
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dansible%2Bjinja2%26ie%3Dutf-8%26oe%3Dutf-8%26aq%3Dt%26rls%3Dorg.mozilla%3Aen-US%3Aofficial%26client%3Dfirefox-a'
    assert unicode_urldecode(string) == u'https://www.google.com/search?q=ansible+jinja2&ie=utf-8&oe=utf-8&aq=t&rls=org.mozilla:en-US:official&client=firefox-a'


# Generated at 2022-06-11 14:12:29.461763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode("https%3A%2F%2Fgithub.com%2Fansible%2Fansible%2Fissues%2F11264") == "https://github.com/ansible/ansible/issues/11264"



# Generated at 2022-06-11 14:12:33.116423
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:12:39.050519
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == 'é'
    assert unicode_urldecode('%3C%3E') == u'<>'
    assert unicode_urldecode('%3C%3F%3E') == u'<?'
    assert unicode_urldecode('%3C%3F%3F%3E') == u'<??'
    assert unicode_urldecode('%3C%%3E') == u'<%%>'



# Generated at 2022-06-11 14:12:46.282544
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Make sure to_text is already imported
    assert(unicode_urldecode(u'%7B') == u'{')
    assert(unicode_urldecode(u'%7D') == u'}')
    assert(unicode_urldecode(u'%0D') == u'\r')
    assert(unicode_urldecode(u'%0A') == u'\n')
    assert(unicode_urldecode(u'%3D') == u'=')
    assert(unicode_urldecode(u'%26') == u'&')


# Generated at 2022-06-11 14:12:52.867950
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Halló%20grænland') == 'Halló grænland'
    assert unicode_urldecode('Hall%C3%B3%20gr%C3%A6nland') == 'Halló grænland'
    assert unicode_urldecode('Hall%C3%B3%20gr%C3%A6nland') == 'Halló grænland'
    assert unicode_urldecode('test/test') == 'test/test'


# Generated at 2022-06-11 14:12:57.201019
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Attempt to initialize instance of FilterModule class
    instance = FilterModule()

    assert 'urldecode' in instance.filters()

    if not HAS_URLENCODE:
        assert 'urlencode' in instance.filters()
    else:
        assert 'urlencode' not in instance.filters()



# Generated at 2022-06-11 14:13:05.731479
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fwww.example.com%2F%3F%23') == 'http://www.example.com/?#'
    assert unicode_urldecode('http%3A%2F%2Fwww.example.com%2F%3F%23%E6%B5%8B%E8%AF%95') == 'http://www.example.com/?#测试'
    assert unicode_urldecode('%E6%B5%8B%E8%AF%95') == '测试'

# Generated at 2022-06-11 14:13:12.151461
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('/a%3Fb') == u'/a?b'
    assert unicode_urldecode('/a%41b') == u'/aAb'
    assert unicode_urldecode('/a%5Cb') == u'/a\\b'

# Generated at 2022-06-11 14:13:21.426707
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC%20') == u'€ '
    assert unicode_urldecode('%E2%82%AC%20+') == u'€  '
    assert unicode_urldecode('%E2%82%AC+%20') == u'€  '

# Generated at 2022-06-11 14:13:24.350724
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
  assert unicode_urldecode('%D7%99%D7%A9%D7%A8%D7%90%D7%9C') == u'ישראל'


# Generated at 2022-06-11 14:13:34.001913
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%40bar.com') == u'foo@bar.com'
    assert unicode_urldecode(u'Hello%20World') == u'Hello World'
    assert unicode_urldecode(u'Hello%2BWorld') == u'Hello+World'
    assert unicode_urldecode(u'Hello%252BWorld') == u'Hello%2BWorld'
    assert unicode_urldecode(u'8%25') == u'8%'
    assert unicode_urldecode(u'%2525') == u'%25'
    assert unicode_urldecode(u'%25252525') == u'%25%25%25%25'

# Generated at 2022-06-11 14:13:43.196845
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'Lässig#') == u'L%C3%A4ssig%23'
    assert unicode_urlencode(u'Lässig') == u'L%C3%A4ssig'
    assert unicode_urlencode(u'Lässig', for_qs=True) == u'L%C3%A4ssig'
    assert unicode_urlencode(u'Lässig/') == u'L%C3%A4ssig%2F'
    assert unicode_urlencode(u'Lässig/', for_qs=True) == u'L%C3%A4ssig%2F'

# Generated at 2022-06-11 14:13:53.986248
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%e9') == 'é'
    assert unicode_urldecode('%E9') == 'é'
    assert unicode_urldecode('%25e9') == '%e9'
    assert unicode_urldecode('%25E9') == '%E9'
    assert unicode_urldecode('%25%65%25') == '%e%25'
    assert unicode_urldecode('%25%65%25%32') == '%e%25%32'
    assert unicode_urldecode('%25%65%25%32%35') == '%e%25%32%35'

# Generated at 2022-06-11 14:14:02.004976
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'](b'%D1%87%D0%B0%D1%81%D1%82%D1%8C') == u'часть'
    assert FilterModule().filters()['urldecode'](b'%D1%87%D0%B0%D1%81%D1%82%D1%8C') == u'часть'
    assert FilterModule().filters()['urldecode'](b'%D1%87%D0%B0%D1%81%D1%82%D1%8C') == u'часть'


# Generated at 2022-06-11 14:14:12.737600
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fn = FilterModule().filters()
    assert fn['urldecode']('foo%20bar') == 'foo bar'
    assert fn['urldecode']('%54%6F%6F%20%62%61%72%21') == 'Too bar!'
    assert fn['urldecode']('%41+%42') == 'A B'
    if 'urlencode' in fn:
        assert fn['urlencode']('http://ansible.com/') == 'http%3A%2F%2Fansible.com%2F'
        assert fn['urlencode']('foo bar!') == 'foo+bar%21'
        assert fn['urlencode']('Too bar!') == 'Too+bar%21'
        assert fn['urlencode']('A B') == 'A+B'


# Generated at 2022-06-11 14:14:14.247125
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"中国") == "%E4%B8%AD%E5%9B%BD"


# Generated at 2022-06-11 14:14:17.705836
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    # NOTE: Jinja2 provides unicode_urldecode which is identical to unquote_plus
    assert unicode_urldecode('%2B') == unquote_plus('%2B')



# Generated at 2022-06-11 14:14:26.540835
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'a%2Bb') == 'a+b'
    assert unicode_urldecode(u'a%2Bb') == 'a+b'
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode(u'a+b') == 'a b'


# Generated at 2022-06-11 14:14:32.891569
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Python 3
    assert unicode_urlencode('http://foo.org/') == 'http%3A%2F%2Ffoo.org%2F'
    assert unicode_urlencode('http://foo.org/', for_qs=True) == 'http%3A%2F%2Ffoo.org%2F'
    assert unicode_urlencode('/path/to/file') == '%2Fpath%2Fto%2Ffile'
    assert unicode_urlencode('/path/to/file', for_qs=True) == '%2Fpath%2Fto%2Ffile'
    assert unicode_urlencode('?test=true') == '%3Ftest%3Dtrue'
    assert unicode_urlencode('?test=true', for_qs=True)

# Generated at 2022-06-11 14:14:38.222452
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo%24bar') == u'foo$bar'


# Generated at 2022-06-11 14:14:45.332474
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['urldecode']('%25') == u'%'
    assert filters['urldecode']('%25%20%3F%3D') == u'% ?='

    encoded = filters['urlencode']({'key1': 'val1', 'key2': 'val2'})
    assert isinstance(encoded, string_types)
    assert encoded == 'key1=val1&key2=val2'
    encoded = filters['urlencode']('%')
    assert isinstance(encoded, string_types)
    assert encoded == '%25'
    encoded = filters['urlencode'](' ?=')
    assert isinstance(encoded, string_types)

# Generated at 2022-06-11 14:14:54.483886
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:14:58.088217
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()

    result = filter.filters()
    assert result['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:15:04.821938
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'foo bar/') == u'foo%20bar%2F'
    assert unicode_urlencode(u'/baz qux') == u'%2Fbaz%20qux'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo bar') == u'foo+bar'
    assert unicode_urlencode({'a': '1 2', 'b': '3+4'}) == u'a=1+2&b=3%2B4'
    assert unicode_urlencode([('a', '1 2'), ('b', '3+4')]) == u'a=1+2&b=3%2B4'

# Generated at 2022-06-11 14:15:15.785382
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/foo') == u'/foo'
    assert unicode_urlencode('foo/') == u'foo%2F'
    assert unicode_urlencode('/foo/') == u'/foo%2F'
    assert unicode_urlencode('+') == u'+'
    assert unicode_urlencode(' ') == u'%20'
    assert unicode_urlencode('foo bar') == u'foo+bar'
    assert unicode_urlencode('foo   bar') == u'foo+++bar'
    assert unicode_urlencode('foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode('foo bar', True) == u'foo+bar'
    assert unicode_urlencode('foo   bar', True) == u

# Generated at 2022-06-11 14:15:19.409281
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fwww.foo.com%2F%3Fid%3D2%26foo%3Dbar') == 'http://www.foo.com/?id=2&foo=bar'


# Generated at 2022-06-11 14:15:26.454828
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode']('a%20b') == 'a b'
    assert f.filters()['urldecode']('a%20b?c%20d') == 'a b?c d'
    assert f.filters()['urldecode']('"a"') == '"a"'
    assert f.filters()['urldecode']('"a"?"b"') == '"a"?b'
    assert f.filters()['urldecode']('"a"?"b"?"c"') == '"a"?b?c'

# Generated at 2022-06-11 14:15:41.389480
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abcdABCD1234_+') == 'abcdABCD1234_%2B'
    assert do_urlencode(u'abcdABCD1234_+') == 'abcdABCD1234_%2B'
    assert do_urlencode(u'abcdABCD1234_+') == do_urlencode('abcdABCD1234_+')
    assert do_urldecode(do_urlencode('abcdABCD1234_+')) == 'abcdABCD1234_+'

# Generated at 2022-06-11 14:15:48.900627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from jinja2 import filters, contextfilter, Environment, DictLoader
    from jinja2.utils import Markup
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp(prefix="ansible_jinja2_")
    os.chdir(tmpdir)

# Generated at 2022-06-11 14:15:55.356914
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("c%2B%2B") == u'c++'
    assert unicode_urldecode("c+++") == u'c+++'
    assert unicode_urldecode("x%yz") == u'x%yz'
    assert unicode_urldecode("%2F") == u'/'
    assert unicode_urldecode("%2f") == u'/'
    assert unicode_urldecode("%2") == u'%2'



# Generated at 2022-06-11 14:15:59.732102
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2F~%26') == u'http://example.com/~&'
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'

# Generated at 2022-06-11 14:16:09.787277
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:16:14.424222
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _ = FilterModule().filters()
    assert 'urldecode' in dir(_)
    assert _['urldecode'](u'%C3%B1') == u'ñ'
    try:
        del _['urldecode']
        assert False, 'urldecode() should not have been removed'
    except KeyError:
        pass


# Generated at 2022-06-11 14:16:21.800810
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("hello") == "hello"
    assert unicode_urldecode("hello+world") == "hello world"
    assert unicode_urldecode("hello%20world") == "hello world"
    assert unicode_urldecode("hello%2Bworld") == "hello+world"

    # unit test for issue #11
    assert unicode_urldecode("%7B%22a%22%3A1%2C%22b%22%3A2%7D") == "{\"a\":1,\"b\":2}"



# Generated at 2022-06-11 14:16:25.628995
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # This method is called by unit tests. It is not called by Ansible.
    from ansible.module_utils import basic

    assert basic.AnsibleModule(
        argument_spec={},
    ).run_command(['python', __file__, 'test'], check_rc=True)


# Generated at 2022-06-11 14:16:35.577975
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode({'a': 'b'}) == 'a=b'
    assert unicode_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d'
    assert unicode_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'
    assert unicode_urlencode('a=b') == 'a%3Db'
    assert unicode_urlencode('a=b@') == 'a%3Db%40'
    assert unicode_urlencode('a=b@', for_qs=True) == 'a%3Db%40'
    assert unicode_urlencode('a=b/') == 'a%3Db%2F'

# Generated at 2022-06-11 14:16:38.374127
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%C3%B6") == "ö"
    assert unicode_urldecode("%3F%3F%3F%3F") == "????"



# Generated at 2022-06-11 14:16:49.685938
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'fooä') == u'foo%C3%A4'
    assert unicode_urlencode(u'http://example.com') == u'http%3A//example.com'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'foo') == u'foo'



# Generated at 2022-06-11 14:16:56.900881
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(to_text('/')) == to_text('/')
    assert unicode_urlencode(to_text('/'), for_qs=True) == to_text('%2F')
    assert unicode_urlencode(to_text('+')) == to_text('+')
    assert unicode_urlencode(to_text('+'), for_qs=True) == to_text('%2B')
    assert unicode_urlencode(to_text('\u20ac')) == to_text('%E2%82%AC')
    assert unicode_urlencode(to_text('\u20ac'), for_qs=True) == to_text('%E2%82%AC')

# Generated at 2022-06-11 14:17:03.064807
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    u1 = unicode_urldecode(u'http%3A%2F%2Fexample.org%2F%3Fx%3D2%26y%3D%26z%3D4')
    assert u1 == u'http://example.org/?x=2&y=&z=4'

    u2 = unicode_urldecode(u'%2B%2F')
    assert u2 == u'+/'



# Generated at 2022-06-11 14:17:12.263771
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode('test')
    assert result == u'test'
    assert isinstance(result, str)

    result = unicode_urldecode('tab%09test')
    assert result == u'tab\ttest'
    assert isinstance(result, str)

    result = unicode_urldecode('tab%09%3Dtest')
    assert result == u'tab\t=test'
    assert isinstance(result, str)
    if PY3:
        result = unicode_urldecode('c%CC%A7af%C3%A9')
        assert result == u'cÇafé'
        assert isinstance(result, str)

# Generated at 2022-06-11 14:17:21.406670
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat.tests.mock import patch

    # If we're running Python 3, patch unquote_plus
    # and quote_plus to return strings
    if PY3:
        p_uqp = patch('ansible.module_utils.six.moves.urllib.parse.unquote_plus', return_value='unicode_string')
        p_qp = patch('ansible.module_utils.six.moves.urllib.parse.quote_plus', return_value='unicode_string')

        p_uqp.start()
        p_qp.start()

    # Patch mock quote
    p_q = patch('ansible.module_utils.six.moves.urllib.parse.quote', return_value='unicode_string')

    p_q.start()



# Generated at 2022-06-11 14:17:24.356245
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    filter_module = FilterModule()
    assert hasattr(filter_module, 'filters')
    filters = filter_module.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-11 14:17:31.101787
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://www.google.com/search?q=url+encode&safe=off') == 'http%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Durl%2Bencode%26safe%3Doff'
    assert do_urlencode('http://www.google.com/search?q=url+encode&safe=on') == 'http%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Durl%2Bencode%26safe%3Don'

# Generated at 2022-06-11 14:17:34.547178
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar%2Bbaz') == 'foo bar+baz'
    assert unicode_urldecode('foo+bar%20baz') == 'foo bar baz'


# Generated at 2022-06-11 14:17:42.785428
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import os

    def _test(string, expected_output=None):
        if expected_output is None:
            expected_output = string
        assert unicode_urldecode(string) == expected_output

    _test('%21')
    _test('%21%24')
    _test('%25%21%24')
    _test('%255')
    _test('%2525%2525')
    _test('%25252525')
    _test('%25%2d%25%2d%25%2d%25%2d%25%2d')
    _test('%255%255')
    _test('%25255%25255')
    _test('%2525255%2525255')
    _test('%25+%25')
    _test('')

    _

# Generated at 2022-06-11 14:17:47.859905
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%2F%2B%7E') == '/+~'



# Generated at 2022-06-11 14:18:05.609838
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_inputs = {
        u'a+%C3%A9': u'a é',
        u'%C3%A9': u'é',
        u'%20': u' ',
        u'%21': u'!',
        u'+': u' ',
        u'%2B': u'+',
        u'%E2%82%AC': u'€',
    }

    for (test_input, expected_output) in iteritems(test_inputs):
        output = unicode_urldecode(test_input)
        error_string = "Input %s did not decode to %s but to %s" % (test_input, expected_output, output)
        assert output == expected_output, error_string



# Generated at 2022-06-11 14:18:14.061832
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():  # pylint: disable=invalid-name
    import ansible.utils.display as display
    from ansible.plugins.filter.core import FilterModule

    # Display is enabled by default, assume we don't need to do it in tests
    display.DISPLAY = display.Display()
    fm = FilterModule()
    filters = fm.filters()

    # Do we have the filters we expect?
    assert 'urldecode' in filters
    assert 'urlencode' in filters

    # Test urldecode filter
    assert filters['urldecode']('foo=bar') == 'foo=bar'
    assert filters['urldecode']('foo%20bar') == 'foo bar'

    # Test urlencode filter
    assert filters['urlencode']('foo=bar') == 'foo=bar'
    assert filters

# Generated at 2022-06-11 14:18:19.818860
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Test urlencode
    >>> test_unicode_urlencode()
    (u'foo', u'foo', u'foo')
    '''
    s = u'foo'
    t = unicode_urlencode(s+s)
    t = unicode_urldecode(t)
    return s, t, s+s


# Generated at 2022-06-11 14:18:26.915889
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(b'abcABC123') == u'abcABC123'
    assert unicode_urlencode(u'abcABC123') == u'abcABC123'
    assert unicode_urlencode({u'abcABC123': u'abcABC123'}) == u'abcABC123=abcABC123'
    assert unicode_urlencode(u'http://jira.example.com/jira/browse/FOO-123') == u'http%3A%2F%2Fjira.example.com%2Fjira%2Fbrowse%2FFOO-123'

# Generated at 2022-06-11 14:18:33.951760
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%80r%C3%B8') == u'Àrø'
    assert unicode_urldecode('%25C3%2580r%25C3%25B8') == u'%C3%80r%C3%B8'
    assert unicode_urldecode('%25C3%2580r%25C3%25B8') == u'%C3%80r%C3%B8'


# Generated at 2022-06-11 14:18:43.267394
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = (("abcabc%20def%20ghi", u"abcabc def ghi"),
                  ("abcabc%2Fdef%2Fghi/", u"abcabc/def/ghi/"),
                  ("abcabc%2fdef%2fghi/", u"abcabc/def/ghi/"))
    for test_case in test_cases:
        result = unicode_urldecode(test_case[0])
        assert result == test_case[1], "For input %s expected %s but got %s" % (test_case[0], test_case[1], result)


# Generated at 2022-06-11 14:18:48.425188
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%82') == u'あ'
    assert unicode_urldecode('%u3042') == u'あ'
    assert unicode_urldecode('foo%2bbar') == u'foo+bar'
    assert unicode_urldecode('%F0%90%80%80') == u'𐀀'
