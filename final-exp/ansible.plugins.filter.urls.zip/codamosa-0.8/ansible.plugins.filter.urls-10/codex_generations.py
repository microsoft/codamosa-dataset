

# Generated at 2022-06-11 14:08:57.869313
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo%25bar') == u'foo%bar'
    assert unicode_urldecode(u'foo%25%32%35bar') == u'foo%25bar'


# Generated at 2022-06-11 14:09:01.893567
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fwww.google.com%2F') == u'http://www.google.com/'
    assert unicode_urldecode('http://www.google.com/') == u'http://www.google.com/'


# Generated at 2022-06-11 14:09:10.871905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os, tempfile, sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleError

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-11 14:09:12.765507
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%97') == u'×'



# Generated at 2022-06-11 14:09:18.733869
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%41%42") == u"AB"
    assert unicode_urldecode(u"%E4%B8%AD%E6%96%87") == u"中文"
    assert unicode_urldecode(u"%E4%B8%AD%E6%96%87") == u"中文"


# Generated at 2022-06-11 14:09:29.269512
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('%2b') == '%2b'
    assert unicode_urldecode('%20') == '%20'
    assert unicode_urldecode('+') == '+'
    assert unicode_urldecode('%2B') == '%2B'
    assert unicode_urldecode('%25') == '%25'
    assert unicode_urldecode('%') == '%'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F%2F') == '//'

# Generated at 2022-06-11 14:09:33.342770
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filter_module.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in filter_module.filters()



# Generated at 2022-06-11 14:09:39.076257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    assert filterModule.filters()['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert filterModule.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in filterModule.filters()

# Generated at 2022-06-11 14:09:47.785254
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foobar') == 'foobar'
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode(u'foo%bar') == 'foo%25bar'
    assert unicode_urlencode(u'foo=bar') == 'foo=bar'
    assert unicode_urlencode(u'foo&bar') == 'foo%26bar'
    assert unicode_urlencode(u'foo/bar') == 'foo/bar'
    assert unicode_urlencode(u'/foo/bar/') == '/foo/bar/'

# Generated at 2022-06-11 14:09:55.885046
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%BC') == u'ü'
    assert unicode_urldecode(u'%E4%BA%BA%E5%A5%BD') == u'人好'
    assert unicode_urldecode(u'%E9%9F%B3%E6%A5%BD%E3%81%97%E3%81%BE%E3%81%99') == u'音楽します'
    assert unicode_urldecode(u'%e4%b8%ad%e6%96%87') == u'中文'

# Generated at 2022-06-11 14:10:00.032910
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''FilterModule.filters() unit test'''
    fm = FilterModule()
    assert fm.filters() != {}

# Generated at 2022-06-11 14:10:04.028267
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == u'hello world'
    assert unicode_urldecode('hello+world') == u'hello world'
    assert unicode_urldecode('hello world') == u'hello world'


# Generated at 2022-06-11 14:10:13.113538
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest

    test_dir = os.path.dirname(__file__)
    src_dir = os.path.join(test_dir, os.path.pardir)
    sys.path.insert(0, src_dir)

    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils._text import to_bytes, to_text

    from ansible.module_utils.jinja2 import FilterModule

    class FilterModuleTestCase(unittest.TestCase):

        def setUp(self):
            self.FilterModule = FilterModule()


# Generated at 2022-06-11 14:10:16.454544
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'Hello World!' == unicode_urldecode('Hello%20World%21')
    assert u'\u2603 ☃' == unicode_urldecode('%E2%98%83+%E2%98%83')


# Generated at 2022-06-11 14:10:18.509951
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    r = fm.filters()
    assert r['urldecode'] == do_urldecode

# Generated at 2022-06-11 14:10:23.556399
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    assert unicode_urldecode('%20') == unquote_plus('%20')
    assert unicode_urldecode('%2F%2F') == unquote_plus('%2F%2F')



# Generated at 2022-06-11 14:10:29.558205
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode('+') == ' '
    assert unicode_urldecode('+++') == '   '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%20%20') == '  '
    assert unicode_urldecode('%20+%20') == '  '
    assert unicode_urldecode('%20++%20') == '   '
    assert unicode_urldecode('%20+++%20') == '    '
    assert unicode_urldecode('+%20%20') == '  '

# Generated at 2022-06-11 14:10:36.250259
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/foo/bar baz') == u'http%3A%2F%2Fexample.com%2Ffoo%2Fbar%20baz'
    assert unicode_urlencode(u'/foo bar baz') == u'/foo%20bar%20baz'
    assert unicode_urlencode(u'foo bar baz') == u'foo%20bar%20baz'
    assert unicode_urlencode(u'foo/bar baz') == u'foo%2Fbar%20baz'
    assert unicode_urlencode(u'foo bar baz', for_qs=True) == u'foo+bar+baz'

# Generated at 2022-06-11 14:10:46.086478
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    class TestArgs(object):
        pass

    testargs = TestArgs()
    testargs.filters = None

    test = FilterModule()

    assert test.filters() is not None

    urlencode_test = test.filters()['urlencode']
    urldecode_test = test.filters()['urldecode']

    assert urlencode_test is not None
    assert urldecode_test is not None

    assert urlencode_test(u' ') == u'%20'
    assert urldecode_test(u'%20') == u' '

    assert urlencode_test({'foo': u'bar'}) == 'foo=bar'
    assert urlencode_test({'foo': 'bar'}) == 'foo=bar'

# Generated at 2022-06-11 14:10:50.508694
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%7E') == u'~'
    assert unicode_urldecode(u'%2F') == u'/'



# Generated at 2022-06-11 14:10:55.509418
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%C3%A9') == u'é'



# Generated at 2022-06-11 14:11:03.342162
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:11:05.615516
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%7Ba%7D') == u'{a}'


# Generated at 2022-06-11 14:11:07.022241
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%C3%A9") == u"é"



# Generated at 2022-06-11 14:11:09.959531
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }

# Generated at 2022-06-11 14:11:19.298380
# Unit test for function do_urlencode
def test_do_urlencode():
    if not HAS_URLENCODE:
        assert do_urlencode(u'fööbär') == u'f%C3%B6%C3%B6b%C3%A4r'
        assert do_urlencode(u'fööbär') == unicode_urlencode(u'fööbär')  # compare with standard impl
        assert do_urlencode(u'fööbär') == do_urldecode(u'f%C3%B6%C3%B6b%C3%A4r')  # compare with urldecode
        assert do_urlencode(u'fööbär') == do_urlencode(u'fööbär')  # compare with self
        # try same test with bytes (

# Generated at 2022-06-11 14:11:29.222746
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        (u'', u''),
        (u'abc', u'abc'),
        (u'abc%20def', u'abc def'),
        (u'abc+def', u'abc def'),
        (u'abc%23%25%26def', u'abc#%&def'),
        (u'%E2%82%AC%20%C2%A3%20%D0%90', u'€ £ А'),
        (to_bytes('%E2%82%AC%20%C2%A3%20%D0%90'), u'€ £ А'),
    ]

    for test_input, expected in test_cases:
        result = unicode_urldecode(test_input)

# Generated at 2022-06-11 14:11:37.171614
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    cases = [
        ("I'm a string", "I%27m%20a%20string"),
        ("I'm still a string", "I%27m%20still%20a%20string"),
        (["I'm", "an", "array"], "I%27m&an&array"),
        (["I'm", "still", "an", "array"], "I%27m&still&an&array"),
    ]
    for case in cases:
        assert unicode_urlencode(case[0]) == case[1]
        assert unicode_urlencode(case[0], for_qs=True) == case[1]


# Generated at 2022-06-11 14:11:38.469021
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '


# Generated at 2022-06-11 14:11:46.619028
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello+') == 'hello '
    assert unicode_urldecode('hello world') == 'hello world'
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('%7Euser') == '~user'
    assert unicode_urldecode('%42') == u'B'
    assert unicode_urldecode('%41') == u'A'
    assert unicode_urldecode('%') == u'%'
    assert unicode_urldecode(u'hello+') == u'hello '
    assert unicode_urldecode(u'hello world') == u'hello world'

# Generated at 2022-06-11 14:11:59.344121
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc def', for_qs=True) == 'abc+def'
    assert unicode_urlencode('abc/def') == 'abc%2Fdef'
    assert unicode_urlencode('abc/def', for_qs=True) == 'abc%2Fdef'
    assert unicode_urlencode('/abc def') == '%2Fabc%20def'
    assert unicode_urlencode('/abc def', for_qs=True) == '%2Fabc+def'
    assert unicode_urlencode('/abc/def') == '%2Fabc%2Fdef'

# Generated at 2022-06-11 14:12:03.587100
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc+123') == u'abc 123'
    assert unicode_urldecode(u'abc%2F123') == u'abc/123'
    assert unicode_urldecode(u'abc%2F123+') == u'abc/123 '


# Generated at 2022-06-11 14:12:07.992177
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%F6%FC%DF') == u'äöüß'
    assert unicode_urldecode('%E4%F6%FC%DF'.encode('utf-8')) == u'äöüß'


# Generated at 2022-06-11 14:12:12.623624
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'sp%C3%A5m') == u'spåm'
    assert unicode_urldecode(u'sp%20%C3%A5m') == u'spåm'



# Generated at 2022-06-11 14:12:21.908337
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc%20abc%2Babc%26abc%25abc%C3%A9') == u'abc abc+abc&abc%abc\xe9'
    assert unicode_urldecode(u'abc%20abc%2Babc%26abc%25abc%C3%A9') == u'abc abc+abc&abc%abc\xe9'
    assert unicode_urldecode(u'abc%20abc%2Babc%26abc%25abc%C3%A9') == unicode_urldecode('abc%20abc%2Babc%26abc%25abc%C3%A9')
    assert unicode_urldecode(u'abc%20abc%2Babc%26abc%25abc%C3%A9') == unic

# Generated at 2022-06-11 14:12:25.684821
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar%20baz') == u'foo bar baz'
    assert unicode_urldecode(u'foo+bar+baz') == u'foo bar baz'



# Generated at 2022-06-11 14:12:36.091941
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test 1') == 'test+1'
    assert unicode_urlencode('test/1') == 'test%2F1'
    assert unicode_urlencode('test/1') == 'test%2F1'
    assert unicode_urlencode('/test/1') == '%2Ftest%2F1'
    assert unicode_urlencode('/test/1') == '%2Ftest%2F1'
    assert unicode_urlencode('test?1') == 'test%3F1'
    assert unicode_urlencode('test&1') == 'test%261'
    assert unicode_urlencode('test?1') == 'test%3F1'

# Generated at 2022-06-11 14:12:37.695965
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar') == u'foo bar'



# Generated at 2022-06-11 14:12:39.797277
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_class = FilterModule()
    result = test_class.filters()
    assert(isinstance(result, dict))



# Generated at 2022-06-11 14:12:48.592215
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar baz') == 'foo%20bar%20baz'
    assert unicode_urlencode('foo/bar/baz') == 'foo%2Fbar%2Fbaz'
    assert unicode_urlencode('foo bar baz', for_qs=True) == 'foo+bar+baz'
    assert unicode_urlencode('foo/bar/baz', for_qs=True) == 'foo%2Fbar%2Fbaz'
    assert unicode_urlencode('foo+bar+baz') == 'foo%2Bbar%2Bbaz'

# Generated at 2022-06-11 14:12:57.925164
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('?&=') == '%3F%26%3D'
    assert do_urldecode(do_urlencode('?&=')) == '?&='


# Generated at 2022-06-11 14:13:06.651708
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:13:14.344843
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Unicode already encoded text
    string = u'\u0410\u0411\u0412'
    e = unicode_urlencode(string)
    if PY3:
        assert e == '%D0%90%D0%91%D0%92'
    else:
        assert e == u'%D0%90%D0%91%D0%92'

    # Unicode already encoded text
    string = u'\u0410\u0411\u0412'
    e = unicode_urlencode(string, for_qs=True)
    if PY3:
        assert e == '%D0%90%D0%91%D0%92'
    else:
        assert e == u'%D0%90%D0%91%D0%92'

    # Python

# Generated at 2022-06-11 14:13:23.146603
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo%20bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo%20bar', for_qs=True) == u'foo%20bar'


# Generated at 2022-06-11 14:13:33.150661
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('unicode_urlencode') == 'unicode_urlencode'
    assert unicode_urlencode(u'unicode_urlencode') == 'unicode_urlencode'
    assert unicode_urlencode('unicode_urlencode', for_qs=True) == 'unicode_urlencode'
    assert unicode_urlencode(u'unicode_urlencode', for_qs=True) == 'unicode_urlencode'

# Generated at 2022-06-11 14:13:43.269843
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Ensure do_urldecode returns a unicode value instead of a byte string
    assert isinstance(do_urldecode('Jur%C3%A9ia'), str)
    assert do_urldecode('Jur%C3%A9ia') == u'Juréia'

    # Ensure do_urlencode returns a unicode value instead of a byte string
    assert isinstance(do_urlencode('Juréia'), str)
    assert do_urlencode('Juréia') == u'Jur%C3%A9ia'

    # Check that a string_types value is encoded
    assert do_urlencode('Juréia') == u'Jur%C3%A9ia'

    # Check that an iterator value is encoded

# Generated at 2022-06-11 14:13:46.127771
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B6') == u'\xf6'
    assert unicode_urldecode('%C3%B6%C3%B6') == u'\xf6\xf6'

# Generated at 2022-06-11 14:13:55.442039
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    target = 'http://www.example.com/spaces should be encoded/'
    expected = 'http%3A%2F%2Fwww.example.com%2Fspaces%20should%20be%20encoded%2F'
    result = unicode_urlencode(target)

    if result != expected:
        print("FAIL: unicode_urlencode() expected '%s', but got '%s'" % (expected, result))
        exit(1)

    print("PASS: unicode_urlencode()")

if __name__ == '__main__':
    test_unicode_urlencode()

# Generated at 2022-06-11 14:14:00.829481
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if not PY3:
        assert unicode_urldecode('foo') == u'foo'
        assert unicode_urldecode('foo%2Bbar') == u'foo+bar'
        assert unicode_urldecode('foo%3Dbar%3Dfoo') == u'foo=bar=foo'
        assert unicode_urldecode('%6efoo') == u'nfoo'


# Generated at 2022-06-11 14:14:02.234367
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '


# Generated at 2022-06-11 14:14:11.329027
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode']('e%CC%81douard+manet') == u'édouard manet'



# Generated at 2022-06-11 14:14:18.769696
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    def test(value, for_qs, expected):
        assert unicode_urlencode(value, for_qs) == expected

    test('/foo/$bar?', False, '/foo/$bar%3F')
    test('/foo/$bar?', True, '/foo/$bar%3F')
    test(u'/foo/$bar?', False, '/foo/$bar%3F')
    test(u'/foo/$bar?', True, '/foo/$bar%3F')
    test(b'/foo/$bar?', False, '/foo/$bar%3F')
    test(b'/foo/$bar?', True, '/foo/$bar%3F')

    # This raises an exception for Py2 and should not for either Py2 or Py3
    test(u'/foo/\u2028', False, '/foo/\u2028')
   

# Generated at 2022-06-11 14:14:20.435399
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25') == '%'



# Generated at 2022-06-11 14:14:24.257798
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert 'urlencode' in filters
    assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:14:32.145872
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:14:41.301400
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'fo%20bar' == unicode_urlencode(u'fo bar')
    assert u'foo%2Fbar' == unicode_urlencode(u'foo/bar')
    assert u'baz' == unicode_urlencode(u'baz')
    assert u'foo%3Dbar' == unicode_urlencode(u'foo=bar', for_qs=True)
    assert u'foo%26bar' == unicode_urlencode(u'foo&bar', for_qs=True)
    assert u'foo%2Fbar' == unicode_urlencode(u'foo/bar', for_qs=True)

# Generated at 2022-06-11 14:14:51.730688
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.org') == 'http%3A%2F%2Fexample.org'
    assert unicode_urlencode('http://example.org/') == 'http%3A%2F%2Fexample.org%2F'
    assert unicode_urlencode('http://example.org/foo bar') == 'http%3A%2F%2Fexample.org%2Ffoo%20bar'
    assert unicode_urlencode('http://example.org/foo?bar=baz#xyzzy') == 'http%3A%2F%2Fexample.org%2Ffoo%3Fbar%3Dbaz%23xyzzy'

# Generated at 2022-06-11 14:14:59.290321
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A1%C3%A9%C3%AD%C3%B3%C3%BA') == u'áéíóú'
    assert unicode_urldecode('%C3%A0%C3%A8%C3%AC%C3%B2%C3%B9%C3%86') == u'àèìòùÆ'

    # THIS IS THE BACKSLASH + SINGLE QUOTE CHARACTER
    assert unicode_urldecode('%5C%27') == u'\\\''



# Generated at 2022-06-11 14:15:03.419344
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode(u'foo / bar') == 'foo%20/%20bar'
    assert unicode_urlencode(u'foo / bar', for_qs=True) == 'foo+%2F+bar'

# Generated at 2022-06-11 14:15:07.379451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    filters['urldecode']('https://google.com/%2F')
    if not HAS_URLENCODE:
        filters['urlencode']('https://google.com/%2F')

# Generated at 2022-06-11 14:15:16.420133
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result = {
        'urldecode': do_urldecode,
    }
    assert FilterModule().filters() == result



# Generated at 2022-06-11 14:15:22.927548
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%3E') == '>'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%20%0A%5C%20') == ' \n\\ '
    assert unicode_urldecode('%CE%91%CE%B2%CE%B3') == u'\u0391\u0392\u0393'



# Generated at 2022-06-11 14:15:24.657798
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("Hello%20World%20%E3%81%82") == u"Hello World あ"


# Generated at 2022-06-11 14:15:27.277465
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert module.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:15:29.709222
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    result = f.filters()
    assert isinstance(result, dict)
    assert 'urldecode' in result.keys()
    assert 'urlencode' in result.keys()



# Generated at 2022-06-11 14:15:41.131351
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo+bar'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo+bar', for_qs=True) == 'foo%2Bbar'
    assert unicode_urlencode(u'тук') == '%D1%82%D1%83%D0%BA'
    assert unicode_urlencode(u'тук', for_qs=True) == '%D1%82%D1%83%D0%BA'

# Generated at 2022-06-11 14:15:45.308848
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == ''
    assert do_urlencode('hello') == 'hello'
    assert do_urlencode('hello/there') == 'hello%2Fthere'
    assert do_urlencode({'a': ['b', 'c']}) == 'a=b&a=c'

# Generated at 2022-06-11 14:15:54.848005
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == ''
    assert unicode_urldecode('a') == 'a'
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode(u'http://example.com/some%20space/') == 'http://example.com/some space/'
    assert unicode_urldecode(u'http://example.com/a%20b+c%2Fd') == 'http://example.com/a b+c/d'
    assert unicode_urldecode(u'http://example.com/a%20b+c%2Fd?q=a+b+c%2Fd') == 'http://example.com/a b+c/d?q=a+b+c/d'


# Generated at 2022-06-11 14:16:01.886353
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode("%3c%3e%22%27%5c") == u"<>\"'\\"
    assert unicode_urldecode("%3D") == u"="
    assert unicode_urldecode("%253D") == u"%3D"
    assert unicode_urldecode("%3d") == u"="
    assert unicode_urldecode("%E2%82%AC") == u"€"
    assert unicode_urldecode("%7E") == u"~"
    assert unicode_urldecode("%21%40%23%24%25%5E%26*()%3D%2B") == u"!@#$%^&*()=+"

# Generated at 2022-06-11 14:16:04.383763
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters



# Generated at 2022-06-11 14:16:16.364909
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import quote_plus

    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', True) == '/'
    assert unicode_urlencode('&') == '%26'
    assert unicode_urlencode('&', True) == quote_plus('&')
    assert unicode_urlencode('/&/') == '/%26/'
    assert unicode_urlencode('/&/', True) == '/%26/'
    assert unicode_urlencode('&/&') == '%26/%26'
    assert unicode_urlencode('&/&', True) == quote_plus('&/&')

# Generated at 2022-06-11 14:16:20.236326
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%F6') == u'ö'
    assert unicode_urldecode('%C3%B6') == u'ö'
    assert unicode_urldecode('%c3%B6') == u'ö'


# Generated at 2022-06-11 14:16:29.460233
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    tests = (
        (1, '1'),
        ('1', '1'),
        ('0', '0'),
        ('', ''),
        ('&', '%26'),
        ('&amp;', '%26amp%3B'),
        ('/', '%2F'),
        ('/path', '%2Fpath'),
        ('/path?q=1', '%2Fpath%3Fq%3D1'),
        ('/path?q=1&foo=bar', '%2Fpath%3Fq%3D1%26foo%3Dbar'),
        ('/path?q=1&foo=bar', '%2Fpath%3Fq%3D1%26foo%3Dbar'),
        (u'\u16a0', '%E1%9A%A0'),
    )

# Generated at 2022-06-11 14:16:32.964638
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%AB') == 'ë'
    assert unicode_urldecode('%E2%88%9E') == '∞'

if __name__ == '__main__':
        test_unicode_urldecode()

# Generated at 2022-06-11 14:16:42.019244
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.errors import AnsibleFilterError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 14:16:45.785801
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%2Fdef') == u'abc/def'
    assert unicode_urldecode('abc%2Fdef%3Fghi%3Djkl') == 'abc/def?ghi=jkl'



# Generated at 2022-06-11 14:16:51.082571
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode({"a": 'b', "c": 'd'}) == 'a=b&c=d'
    assert do_urlencode(["a", 'b', "c", 'd']) == 'a=b&c=d'
    assert do_urlencode('a b c d') == 'a+b+c+d'

# Generated at 2022-06-11 14:16:53.559501
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = b'abcd%2Fxyz'
    assert unicode_urldecode(s) == u'abcd/xyz'



# Generated at 2022-06-11 14:16:55.700899
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()

    assert filters['urldecode'](filters['urlencode']("example.com")) == "example.com"

# Generated at 2022-06-11 14:17:05.829067
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25') == '%', "unicode_urldecode('%25') should be '%'"
    assert unicode_urldecode('%2525') == '%%', "unicode_urldecode('%2525') should be '%%'"
    assert unicode_urldecode('%252525') == '%%%', "unicode_urldecode('%252525') should be '%%%'"
    assert unicode_urldecode('%25252525') == '%%%%', "unicode_urldecode('%25252525') should be '%%%%'"
    assert unicode_urldecode('%25') == u'%', "unicode_urldecode('%25') should be u'%'"
    assert unicode_urldec

# Generated at 2022-06-11 14:17:16.685199
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%0A') == u'\n'
    assert unicode_urldecode('%0a') == u'\n'
    assert unicode_urldecode(u'%0A') == u'\n'
    assert unicode_urldecode(u'%0a') == u'\n'



# Generated at 2022-06-11 14:17:17.965185
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'test%20test') == u'test test'
    assert unicode_urldecode(u'test+test') == u'test test'


# Generated at 2022-06-11 14:17:26.111419
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # urldecode
    assert FilterModule.filters(None)['urldecode']('foo%20123') == unicode_urldecode('foo%20123')
    #  urlencode
    assert FilterModule.filters(None)['urlencode']('foo 123') == unicode_urlencode('foo 123')
    assert FilterModule.filters(None)['urlencode']('foo 123') == FilterModule.filters(None)['urlencode']('foo 123')
    assert FilterModule.filters(None)['urlencode']('foo 123') == do_urlencode('foo 123')
    assert FilterModule.filters(None)['urlencode']('foo 123') == 'foo+123'

# Generated at 2022-06-11 14:17:28.466135
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # NOTE: Each method here could be moved to its own test file.

    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }

# Generated at 2022-06-11 14:17:30.156843
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)
    assert len(fm.filters()) > 0


# Generated at 2022-06-11 14:17:33.880871
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7Ba%3A%22b%22%2C%20%22c%22%3A%7B%22e%22%3A%22f%22%7D%7D') == '{a:"b", "c":{"e":"f"}}'


# Generated at 2022-06-11 14:17:39.041446
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("%E1%9A%A0%E2%80%81%E2%80%82") == u"ᚠ  "
    if not HAS_URLENCODE:
        assert do_urlencode(u"ᚠ  ") == "%E1%9A%A0%E2%80%81%E2%80%82"

# Generated at 2022-06-11 14:17:44.930492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    urlsafe = 'a=b&c=d'
    unsafe = 'a=b&c=x=d&y=z'
    assert filters['urldecode'](urlsafe) == {'a': 'b', 'c': 'd'}
    assert filters['urldecode'](unsafe) == 'a=b&c=x=d&y=z'

    # Extra test for handling old python
    urlsafe = to_text('a=b&c=d')
    unsafe = to_text('a=b&c=x=d&y=z')
    assert filters['urldecode'](urlsafe) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-11 14:17:53.856450
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('string') == 'string'
    assert do_urlencode('string with spaces') == 'string+with+spaces'
    assert do_urlencode('string@with/slashes') == 'string%40with%2Fslashes'
    assert do_urlencode('string with spaces @ slashes') == 'string+with+spaces+%40+slashes'
    import time
    assert do_urlencode(time.time()) == unicode(time.time())
    assert do_urlencode({'one': 1, 'two': 2, 'three': 3}) == 'one=1&three=3&two=2'
    assert do_urlencode(['one', 'two', 'three']) == 'one&two&three'

# Generated at 2022-06-11 14:17:57.848936
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%20filename%3D%22%3C%3E%22%20%23%20%2Fetc%2Fpasswd%20%0A%20'
    expected = ' filename="<>" # /etc/passwd \n '
    result = unicode_urldecode(string)
    assert result == expected


# Generated at 2022-06-11 14:18:09.195031
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo+%C3%A4') == u'foo ä'
    assert unicode_urldecode(u'foo+%25+%C3%A4') == u'foo % ä'
    assert unicode_urldecode(u'foo+%E2%9C%93') == u'foo ✓'



# Generated at 2022-06-11 14:18:15.947111
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_cases = [
        ('', ''),
        ('hello', 'hello'),
        ('hello%20world', 'hello world'),
        ('hello+world', 'hello world'),
        ('%21%40%23%24%25%5E%26*()%7B%7D%7C%5B%5D%3A%3B%22%20%3C%3E%2C%2E%2F%3F%5C%7E%60%20%20%20%20', '!@#$%^&*(){}|[]\';" <>,./?\\~`    '),
        ('%E5%84%AA%E8%AE%BA', '優论'),
    ]

# Generated at 2022-06-11 14:18:19.891024
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'%3A' == unicode_urldecode('%3A')
    assert u'\u20ac' == unicode_urldecode('%e2%82%ac')
    assert u'\u20ac' == unicode_urldecode('%E2%82%AC')

# Generated at 2022-06-11 14:18:26.975926
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Implements unit tesing for filters method of class FilterModule'''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.module_utils.six as six

    test_urlencode_string = '@#$%^&*()<>?{}[]'
    test_urlencode_string_expected = '%40%23%24%25%5E%26*%28%29%3C%3E%3F%7B%7D%5B%5D'
    test_urlencode_list = [u'@#$%^&*()<>?{}[]', u'@#$%^&*()<>?{}[]']

# Generated at 2022-06-11 14:18:29.546903
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"a+%23+b") == u"a # b"

# Generated at 2022-06-11 14:18:34.978680
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('test%C3%A9') == 'testé'
    else:
        assert unicode_urldecode('test%C3%A9') == to_text(b'test\xc3\xa9')
    assert unicode_urldecode('test%26') == 'test&'
    assert unicode_urldecode('test%2B') == 'test+'


# Generated at 2022-06-11 14:18:46.295780
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    class TestCase:
        def __init__(self, input, expected):
            self.input = input
            self.expected = expected

    # Test cases

# Generated at 2022-06-11 14:18:53.499282
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'/abc/') == u'/abc/'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'/abc/def/') == u'/abc/def/'
    assert unicode_urlencode(u'/abc/def/', for_qs=True) == u'/abc/def/'
    assert unicode_urlencode(u'/abc/def/ghi/') == u'/abc/def/ghi/'