

# Generated at 2022-06-11 14:08:58.679701
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert do_urldecode('foo%20bar') == 'foo bar'
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode
        assert do_urlencode('foo bar') == 'foo+bar'
        assert do_urlencode({'a': 'foo', 'b': 'bar'}) == 'a=foo&b=bar'


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-11 14:09:01.523918
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%25') == u'dag%'
    assert unicode_urldecode(u'dag%25w') == u'dag%w'


# Generated at 2022-06-11 14:09:08.792638
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:09:13.878076
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # trac ticket #26283
    assert unicode_urlencode(unicode('http://www.example.com/')) == u'http%3A%2F%2Fwww.example.com%2F'

# Generated at 2022-06-11 14:09:17.262883
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'



# Generated at 2022-06-11 14:09:18.873678
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Test FilterModule.filters method '''

    filter_module = FilterModule()

    assert filter_module.filters()['urldecode'] == do_urldecode
    assert filter_module.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:09:29.386517
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/foo?bar=baz') == 'http%3A//example.com/foo?bar=baz'
    assert unicode_urlencode('http://example.com/foo?bar=baz', for_qs=True) == 'http%3A//example.com/foo%3Fbar%3Dbaz'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'

# Generated at 2022-06-11 14:09:39.749978
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Import necessary modules
    import os
    import sys
    import unittest

    # Initialize the filter module
    filter_module = FilterModule()

    # FilterModule.filters() test
    assert isinstance(filter_module.filters(), dict)

    # The filters should not be empty
    assert filter_module.filters() != {}

    # Ensure "urldecode" filter is present
    assert 'urldecode' in filter_module.filters()

    # Ensure "urlencode" filter is always present
    assert 'urlencode' in filter_module.filters()


if __name__ == '__main__':
    # Skip if we are not running unit tests
    if not __file__.endswith('.py'):
        sys.exit(0)

# Generated at 2022-06-11 14:09:47.311212
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('http://www.example.org/foo bar/') == 'http%3A%2F%2Fwww.example.org%2Ffoo%20bar%2F'
    assert unicode_urlencode('http://www.example.org/foo bar/?a=1&b=2') == 'http%3A%2F%2Fwww.example.org%2Ffoo%20bar%2F%3Fa%3D1%26b%3D2'


# Generated at 2022-06-11 14:09:56.575509
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('') == ''
    assert fm.filters()['urldecode']('%C3%A9') == u'\u00e9'
    assert fm.filters()['urldecode']('%2F') == '/'
    assert fm.filters()['urldecode']('%2F%3D') == '/='
    assert fm.filters()['urldecode']('%2F=') == '/='

    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('') == ''
        assert fm.filters()['urlencode'](u'\u00e9') == '%C3%A9'

# Generated at 2022-06-11 14:10:02.852861
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20+%2B%26') == u'%20+%2B%26'
    assert unicode_urldecode('+') == u'+'
    assert unicode_urldecode('.') == u'.'


# Generated at 2022-06-11 14:10:08.282855
# Unit test for function do_urlencode
def test_do_urlencode():
    value = {
        'hello': 'world',
        'foo': 'b ar',
        'baz': 'boz',
        'buz&': 'boz&',
    }

    result = do_urlencode(value)
    assert result == 'hello=world&foo=b+ar&baz=boz&buz%26=boz%26'



# Generated at 2022-06-11 14:10:10.106088
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc def') == 'abc%20def'
    assert unicode_urlencode('abc def', for_qs=True) == 'abc+def'


# Generated at 2022-06-11 14:10:19.028999
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test utf-8 chars
    test = u'The big brown fox jumped over the lazy dog'
    assert test == unicode_urldecode(unicode_urlencode(test)), 'Unicode encode/decode failed'

    # test reserved chars
    test = u'!*\'();:@&=+$,/?#[%]'
    assert test == unicode_urldecode(unicode_urlencode(test)), 'Encode/decode of reserved characters failed'

    # test reserved chars in a string
    test = u'The big brown fox jumped over the lazy dog !*\'();:@&=+$,/?#[%]'
    assert test == unicode_urldecode(unicode_urlencode(test)), 'Encode/decode of reserved characters in a string failed'

    # test unicode chars


# Generated at 2022-06-11 14:10:23.287990
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    method = FilterModule.filters

    assert 'urldecode' in method()

    filters = method()
    assert not HAS_URLENCODE and 'urlencode' in filters or HAS_URLENCODE and 'urlencode' not in filters


# Generated at 2022-06-11 14:10:29.421890
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test empty string
    assert unicode_urlencode('') == ''

    # Test RFC 3986 when path_only == True
    assert unicode_urlencode('https://www.example.com/foo/bar?query=abc') == 'https%3A%2F%2Fwww.example.com%2Ffoo%2Fbar%3Fquery%3Dabc'

    # Test RFC 3986 when path_only == False
    assert unicode_urlencode('https://www.example.com/foo/bar?query=abc', for_qs=True) == 'https%3A%2F%2Fwww.example.com%2Ffoo%2Fbar%3Fquery%3Dabc'

    # Test RFC 3986 when query is empty (path_only == True)

# Generated at 2022-06-11 14:10:33.599131
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%9C') == u"Ü"
    assert unicode_urldecode('%C3%9C'.encode('utf-8')) == u"Ü"
    assert unicode_urldecode(b'%C3%9C') == u"Ü"


# Generated at 2022-06-11 14:10:44.206924
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # url encoding should quote non-printable and non-ascii characters
    assert unicode_urlencode(u'\u05dc') == '%D7%9C'
    assert unicode_urlencode(u'\x1c') == '%1C'
    assert unicode_urlencode(u'a b c') == 'a+b+c'
    assert unicode_urlencode(u'a b c', for_qs=True) == 'a%20b%20c'
    assert unicode_urlencode(u'a / b') == 'a+%2F+b'
    assert unicode_urlencode(u'a / b', for_qs=True) == 'a%20%2F%20b'

# Generated at 2022-06-11 14:10:50.336234
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'\xc3') == u'Ã'
    assert unicode_urldecode(u'\xc3') == u'Ã'
    assert unicode_urldecode(u'%c3') == u'Ã'
    assert unicode_urldecode(b'%c3') == u'Ã'
    assert unicode_urldecode(u'%c3%a9') == u'Ã©'
    assert unicode_urldecode(b'%c3%a9') == u'Ã©'
    assert unicode_urldecode(u'\u0153') == u'œ'
    assert unicode_urldecode(u'%c5%93') == u'œ'


# Generated at 2022-06-11 14:11:00.145380
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urlencode(u'hello world') == u'hello%20world'
    assert do_urlencode(u'hello world!') == u'hello%20world%21'
    assert do_urlencode(u'hello world&test') == u'hello%20world%26test'
    assert do_urlencode(u'hello world&test=ing') == u'hello%20world%26test=ing'

    assert do_urlencode({u'hello world': u'hello world&test=ing'}) == u'hello%20world=hello%20world%26test=ing'

    assert do_urldecode(u'hello%20world') == u'hello world'
    assert do_urldecode(u'hello%20world%21') == u'hello world!'
    assert do_

# Generated at 2022-06-11 14:11:07.165283
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert 'foo+bar=baz' == unicode_urldecode('foo+bar=baz')
    assert u'föø+bår=baz' == unicode_urldecode('f%C3%B6%C3%B8+b%C3%A5r=baz')



# Generated at 2022-06-11 14:11:17.059874
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert unicode_urlencode(u'dag%&') == u'dag%25%26'
        assert unicode_urlencode(u'dag&') == u'dag%26'
        assert unicode_urlencode(u'dag&', for_qs=True) == u'dag%26'
        assert unicode_urlencode(u'dag&%&foo') == u'dag%26%25%26foo'

# Generated at 2022-06-11 14:11:23.293531
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == '', 'Empty string'
    assert do_urlencode('?a=b&b=c') == '%3Fa%3Db%26b%3Dc', 'Query string'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == 'a=b&c=d', 'Dict with pairs'
    assert do_urlencode(('a', 'b')) == 'a=b', 'Tuple with pairs'
    assert do_urlencode(['a', 'b']) == 'a=b', 'List with pairs'
    assert do_urlencode('a') == 'a', 'Simple string'
    assert do_urlencode(u'a') == 'a', 'Simple unicode string'

# Generated at 2022-06-11 14:11:33.078750
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("test") == "test"
    assert unicode_urlencode("test Ü") == "test+%C3%9C"
    assert unicode_urlencode("test Ü", for_qs=True) == "test+%C3%9C"
    assert unicode_urlencode("test Ü=&") == "test+%C3%9C%3D%26"
    assert unicode_urlencode("test Ü=&", for_qs=True) == "test+%C3%9C%3D%26"
    assert unicode_urlencode("test Ü/#") == "test+%C3%9C/%23"

# Generated at 2022-06-11 14:11:43.220783
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('string%20with%20spaces%20and%20%E3%82%A2%E3%83%BC%E3%82%AF%E3%82%AE%E3%83%A9%E3%83%B3%E3%83%89%C2%B5%C2%B5%C2%B5%C2%B5%C2%B5%C2%B5%C2%B5%C2%B5') == 'string with spaces and アーキガランドµµµµµµµµ'

# Generated at 2022-06-11 14:11:49.106853
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'El Veloz Águila') == u'El%20Veloz%20%C3%81guila'
    assert unicode_urlencode(u'Jeść nie żuć!') == u'Je%C5%9B%C4%87%20nie%20%C5%BCu%C4%87%21'

# Generated at 2022-06-11 14:11:52.143562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filt = FilterModule()
    assert 'urldecode' in filt.filters()
    assert 'urlencode' in filt.filters()
    assert filt.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-11 14:11:56.301277
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    filters = filter.filters()

    assert filters['urldecode']("%E8%83%BD%E5%8A%9B") == u'能力'

    if not HAS_URLENCODE:
        assert filters['urlencode']("小刀") == "%E5%B0%8F%E5%88%80"

# Generated at 2022-06-11 14:12:00.372776
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    if sys.version_info.major == 2:
        assert unicode_urldecode('%C3%A9') == u'é'
    else:
        assert unicode_urldecode('%C3%A9') == 'é'


# Generated at 2022-06-11 14:12:04.500197
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a b') == 'a%20b'
    assert unicode_urlencode('a+b') == 'a%2Bb'
    assert unicode_urlencode('a/b') == 'a%2Fb'
    assert unicode_urlencode('a#b') == 'a%23b'



# Generated at 2022-06-11 14:12:18.232705
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode
    assert do_urldecode('foo') == 'foo'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode('foo%2Fbar') == 'foo/bar'
    assert do_urldecode('foo+%2F%20+bar') == 'foo /  bar'

    # Test urlencode
    assert do_urlencode('foo') == 'foo'
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo /  bar') == 'foo+%2F++bar'

    # Dictionary

# Generated at 2022-06-11 14:12:20.846168
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:12:22.876139
# Unit test for method filters of class FilterModule

# Generated at 2022-06-11 14:12:34.043121
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo/bar', for_qs=True) == u'foo%2Fbar'
    if PY3:
        assert unicode_urlencode(u'©') == u'%C2%A9'
        assert unicode_urlencode(u'©', for_qs=True) == u'%C2%A9'
    else:
        assert unicode_urlencode

# Generated at 2022-06-11 14:12:38.546516
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # NOTE: When updating this test, make sure to update the documentation to match.
    import jinja2
    assert isinstance(jinja2.filters.FILTERS['urldecode'], type(do_urldecode))

    if not HAS_URLENCODE:
        assert isinstance(jinja2.filters.FILTERS['urlencode'], type(do_urlencode))

# Generated at 2022-06-11 14:12:42.329164
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = b'%C3%A4%C3%B6%C3%BC%C3%9F'
    decoded = unicode_urldecode(string)
    assert decoded == u'äöüß'
    return decoded


# Generated at 2022-06-11 14:12:44.007609
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("d%C3%BCmmen") == u"dümmen"


# Generated at 2022-06-11 14:12:52.329587
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E3%82%84%E3%82%85%E3%82%86') == u'やゅゆ'
    assert unicode_urldecode(u'%C3%A3%C3%A2%C3%A9') == u'ãâé'
    assert unicode_urldecode(u'%C3%83%C2%A3') == u'Ã£'
    assert unicode_urldecode(u'%C3%A3%C2%A3') == u'ã£'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%27') == u"'"

# Generated at 2022-06-11 14:12:56.017939
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u05e9\u05dc\u05d5\u05dd') == u'%D7%A9%D7%9C%D7%95%D7%9D'
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc@def.com') == u'abc%40def.com'
    assert unicode_urlencode(u'abc-def') == u'abc-def'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'<def>') == u'%3Cdef%3E'

# Generated at 2022-06-11 14:13:04.675156
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%C3%B6') == u'ö'
    assert unicode_urldecode(u'%00') == u'\x00'
    assert unicode_urldecode(u'%41%42') == u'AB'
    assert unicode_urldecode(u'%41B') == u'AB'
    assert unicode_urldecode(u'A%42') == u'AB'
    assert unicode_urldecode(u'A%42%20') == u'AB '
    assert unicode_urldecode(u'%41%42%20')

# Generated at 2022-06-11 14:13:12.612204
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(to_text(b'hello world')) == u'hello%20world'
    assert unicode_urlencode(u'hello world') == u'hello%20world'
    assert unicode_urlencode(u'hello world', for_qs=True) == u'hello+world'
    assert unicode_urlencode(u'hello wörld') == u'hello%20w%C3%B6rld'


# Generated at 2022-06-11 14:13:21.933758
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys

    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%2Fdef') == u'abc/def'
    assert unicode_urldecode('abc%2Fdef%3Fghi%3Dxyz') == u'abc/def?ghi=xyz'
    assert unicode_urldecode('%e6%88%91%e7%9a%84%e8%b7%af%e7%94%b1') == u'\u6211\u7684\u8def\u7531'
    if not PY3:
        assert unicode_urldecode(unicode('abc')) == u'abc'

    assert unicode_urldecode(sys.maxunicode * u'a')

# Generated at 2022-06-11 14:13:27.458756
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%26%25') == u'&%'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%25%26') == u'%&'



# Generated at 2022-06-11 14:13:32.886356
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('% ?"\u00fc') == '%25%20%3f%22%fc'
    assert unicode_urlencode('%&+') == '%25%26%2B'
    assert unicode_urlencode('%&+', for_qs=True) == '%25%26%2B'

# Generated at 2022-06-11 14:13:42.428882
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode(u'a/b c') == u'a%2Fb+c'
    assert unicode_urlencode(u'a/b c') != u'a%2Fb c'
    assert unicode_urlencode(u'Ü') == u'%C3%9C'

    assert unicode_urlencode('/', True) == '%2F'
    assert unicode_urlencode(u'a/b c', True) == 'a%2Fb+c'
    assert unicode_urlencode(u'Ü', True) == '%C3%9C'


# Generated at 2022-06-11 14:13:52.206169
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(None) == u'None'
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar/') == u'foo/bar/'
    assert unicode_urlencode(u'foo?bar=') == u'foo%3Fbar%3D'
    assert unicode_urlencode(u'foo&bar=') == u'foo%26bar%3D'
    assert unicode_urlencode(u'foo&bar=') == u'foo%26bar%3D'

# Generated at 2022-06-11 14:13:56.050789
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    raw = u'string+%C3%A0%C3%A7i%C3%ABn'
    expected = u'string àçiën'
    assert unicode_urldecode(raw) == expected


# Generated at 2022-06-11 14:13:58.193900
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC%C3%9F') == u'äöüß'
    assert unicode_urldecode('parse+tree#anchor') == u'parse tree#anchor'



# Generated at 2022-06-11 14:14:00.940718
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(b'%20') == '%20'
    assert unicode_urldecode('%20') == u'%20'



# Generated at 2022-06-11 14:14:05.663358
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit: Returns dicionary with filters
    filter_module = FilterModule()
    result = filter_module.filters()
    assert type(result) is dict
    assert len(result) == 2
    assert 'urldecode' in result



# Generated at 2022-06-11 14:14:12.972553
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    assert x.filters()['urldecode'](u'dag%20wieers') == u'dag wieers'

# Generated at 2022-06-11 14:14:16.924295
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_filters = FilterModule.filters(FilterModule())
    assert isinstance(test_filters, dict)

    test_urldecode = test_filters['urldecode']
    assert isinstance(test_urldecode, type(FilterModule.filters))

    assert test_urldecode('foo%20bar') == 'foo bar'
    assert test_urldecode('foo+bar') == 'foo+bar'

# Generated at 2022-06-11 14:14:20.705554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Test FilterModule.filters() '''
    F = FilterModule()
    assert F.filters()['urldecode'] == do_urldecode
    assert F.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:14:27.858275
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.urls import make_qs
    filter_module = FilterModule()
    inputParams = {
        'name': 'dagwieers',
        'user': 'dag'
    }
    assert filter_module.filters()['urldecode'](make_qs(inputParams)) == make_qs(inputParams)
    assert filter_module.filters()['urldecode'](make_qs(inputParams, doseq=True)) == make_qs(inputParams, doseq=True)

# Generated at 2022-06-11 14:14:39.665770
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'The quick brown fox jumps over the lazy dog') == 'The%20quick%20brown%20fox%20jumps%20over%20the%20lazy%20dog'

    assert unicode_urlencode(u'The quick brown fox jumps over the lazy dog', for_qs=True) == 'The+quick+brown+fox+jumps+over+the+lazy+dog'

    assert unicode_urlencode(u'The quick brown fox jumps over the lazy dog & cat') == 'The%20quick%20brown%20fox%20jumps%20over%20the%20lazy%20dog%20%26%20cat'


# Generated at 2022-06-11 14:14:42.668250
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    result = test.filters()
    assert isinstance(result, dict)
    assert 'urldecode' in result
    assert 'urlencode' in result


# Generated at 2022-06-11 14:14:52.461174
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest

    test = u'Räksmörgås'
    expect = u'R%C3%A4ksm%C3%B6rg%C3%A5s'

    module = FilterModule()
    filters = module.filters()

    class TestFilterModule(unittest.TestCase):
        # pylint: disable=too-many-public-methods
        def test_urlencode(self):
            self.assertEqual(filters['urlencode'](test), expect)

        def test_urldecode(self):
            self.assertEqual(filters['urldecode'](expect), test)

    # pylint: disable=undefined-variable
    if __name__ == '__main__':
        unitt

# Generated at 2022-06-11 14:15:01.534408
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'/foo bar/') == u'/foo%20bar/'
    assert do_urlencode(u'/foo bar/', for_qs=True) == u'/foo+bar/'

    assert do_urlencode({u'foo': u'bar'}) == u'foo=bar'
    assert do_urlencode({u'foo': u'bar baz'}) == u'foo=bar%20baz'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
   

# Generated at 2022-06-11 14:15:05.652166
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'this/is+encoded'
    assert unicode_urlencode(string, for_qs=False) == u'this%2Fis%2Bencoded'
    assert unicode_urlencode(string, for_qs=True) == u'this%2Fis%2Bencoded'

# Generated at 2022-06-11 14:15:16.420660
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()

    url1 = "%e2%80%9c%e2%80%9d%e2%80%9cHello%e2%80%9d%e2%80%9c%e2%80%9d%c2%a0World%c2%a0%e2%80%9c%e2%80%9d%e2%80%9c%e2%80%9d"


# Generated at 2022-06-11 14:15:25.894916
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import pytest

    assert unicode_urldecode(u"test+test") == u"test test"
    assert unicode_urldecode("test+test") == u"test test"
    with pytest.raises(UnicodeDecodeError):
        unicode_urldecode(b"test+test")



# Generated at 2022-06-11 14:15:26.990083
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2F") == "/"



# Generated at 2022-06-11 14:15:32.474952
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'x%20y%20z' == unicode_urlencode('x y z')
    assert 'x+y+z' == unicode_urlencode('x y z', for_qs=True)
    assert {'a': 'x+b', 'c': 'y+d'} == unicode_urldecode('a=x+b&c=y+d')
    assert 'x+y+z' == unicode_urldecode('a=x+y+z')
    assert 'a=x+y+z' == do_urlencode('a=x y z')
    filters = FilterModule()
    assert filters.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:15:38.014741
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    res = obj.filters()
    assert isinstance(res, dict)
    assert 'urldecode' in res
    assert res['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in res
        assert res['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:15:44.955157
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    #
    # assert filters['urldecode'] == do_urldecode
    # if not HAS_URLENCODE:
    #     assert filters['urlencode'] == do_urlencode
    #
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode


# Unit  test for method do_urldecode()

# Generated at 2022-06-11 14:15:54.377638
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode('a+b%2Cc') == 'a b,c'
    assert unicode_urldecode('a+b%2Cc+d%3D+e') == 'a b,c d = e'
    assert unicode_urldecode('a+b%2Cc+d%26+e') == 'a b,c d & e'
    assert unicode_urldecode('a%20+b') == 'a  b'
    assert unicode_urldecode('a%20+b%2Cc') == 'a  b,c'

# Generated at 2022-06-11 14:15:56.701254
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('key=val') == 'key=val'
    assert do_urldecode('%3D%3D') == '=='


# Generated at 2022-06-11 14:15:58.863451
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%26def') == u'abc&def'
    assert unicode_urldecode('abc%3Ddef') == u'abc=def'

# Generated at 2022-06-11 14:16:08.085915
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == b'/'
    assert unicode_urlencode(u'/') == b'/'
    assert unicode_urlencode(u'/') == to_bytes(u'/')
    assert unicode_urlencode(u'/') == u'/'.encode('utf-8')
    assert unicode_urlencode(u'/') == u'/'

    assert unicode_urlencode('/', True) == b'/'
    assert unicode_urlencode(u'/', True) == b'/'
    assert unicode_urlencode(u'/', True) == to_bytes(u'/')
    assert unicode_urlencode(u'/', True) == u'/'.encode('utf-8')
    assert unicode_urlencode(u'/', True) == u'/'

# Generated at 2022-06-11 14:16:10.938243
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == 'abc'
    assert unicode_urlencode('abc?=') == 'abc?%3D'

# Generated at 2022-06-11 14:16:24.334156
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_data = [
        (u'hello%20world', u'hello world'),
        (u'hello+world', u'hello world'),
        (u'hello%2Bworld', u'hello+world'),
        (u'https%3A%2F%2Fgithub.com%2F', u'https://github.com/'),
        (u'hello%25world', u'hello%world'),
        (u'hello%2Fworld', u'hello/world'),
    ]
    for (input_string, output_string) in test_data:
        assert unicode_urldecode(input_string) == output_string, (u'Error de-urlencoding %s' % input_string)



# Generated at 2022-06-11 14:16:29.731236
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    s = ' '
    assert(s == to_text(s))
    assert(to_bytes(s) == to_text(to_bytes(s)))
    assert(unicode_urlencode(s) == u'%20')
    assert(unicode_urlencode(s, for_qs=True) == u'+')
    assert(unicode_urldecode(to_text(s)) == u' ')



# Generated at 2022-06-11 14:16:39.414295
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('&') == '%26'
    assert unicode_urlencode(u'&') == u'%26'
    assert unicode_urlencode('&') == b'%26'
    assert unicode_urlencode(b'&') == b'%26'
    assert unicode_urlencode('%') == '%25'
    assert unicode_urlencode('@') == '%40'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('+') == '%2B'
    assert unicode_urlencode('=') == '%3D'
    assert unicode_urlencode('#') == '%23'
    assert unicode_urlencode('"') == '%22'

# Generated at 2022-06-11 14:16:45.430924
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:16:54.835200
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Python 2
    if not PY3:
        empty = ''
        assert unicode_urlencode(empty) == ''

    # Python 3
    empty = ''
        # assert unicode_urlencode(empty) == ''
    assert unicode_urlencode(empty, True) == ''

    # Test Unicode input
    unistring = '\u9b54\u7faf'
    assert unicode_urlencode(unistring) == '%E9%AD%94%E7%BE%AF'
    assert unicode_urlencode(unistring, True) == '%E9%AD%94%E7%BE%AF'

    # Test Unicode strings
    string = 'bouh'
    assert unicode_urlencode(string) == 'bouh'
    assert unicode_

# Generated at 2022-06-11 14:17:04.969970
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode'](u'dag%20wieers') == u'dag wieers'
    assert filters['urldecode']('dag%20wieers') == 'dag wieers'

    if not HAS_URLENCODE:
        # Python2
        if hasattr(__builtins__, 'unicode'):
            assert filters['urlencode'](u'dag wieers') == u'dag%20wieers'
        # Python3
        assert filters['urlencode']('dag wieers') == 'dag%20wieers'

    # Tests dict
    assert u'_%3D_=_%3D_' in filters['urlencode'](dict(__='__'))

    #

# Generated at 2022-06-11 14:17:07.847005
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode 
    do_urldecode('foo')
    # Test urlencode 
    do_urlencode('foo')
    # Test urlencode 
    do_urlencode({'foo':'bar'})

# Generated at 2022-06-11 14:17:16.021598
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_inputs = [
        (u'%20', u' '),
        ('%2B', '+'),
        ('%27', "'"),
        ('%25%6A', '%j'),
    ]

    for t in test_inputs:
        res = unicode_urldecode(t[0])
        res_decoded = unicode_urldecode(res)
        assert res == t[1], 'urldecode("%s") = "%s" != "%s"' % (t[0], res, t[1])
        assert res_decoded == t[0], 'urldecode("%s") = "%s" != "%s"' % (res, res_decoded, t[0])


# Generated at 2022-06-11 14:17:22.402998
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test a non-unicode string
    s = '%e6%88%91%e7%94%9f%e6%b4%bb'
    assert unicode_urldecode(s) == u'我生活'

    # test a unicode string
    s = u'%e6%88%91%e7%94%9f%e6%b4%bb'
    assert unicode_urldecode(s) == u'我生活'



# Generated at 2022-06-11 14:17:29.613634
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert "Hello world" == unicode_urldecode("Hello%20world")
    assert "Hello world" == unicode_urldecode("Hello world")
    assert "spam and eggs" == unicode_urldecode("spam%20and%20eggs")
    assert "spam and eggs" == unicode_urldecode("spam+and+eggs")
    assert u'русский' == unicode_urldecode(u'%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9')
    assert u'русский' == unicode_urldecode(u'русский')


# Generated at 2022-06-11 14:17:42.680537
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(FilterModule()), dict)


# Generated at 2022-06-11 14:17:48.353390
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    cases = [
        ('a%2Fb', 'a/b'),
        ('foo%20bar', 'foo bar'),
        ('foo%25bar', 'foo%bar'),
    ]
    for test, expected in cases:
        result = unicode_urldecode(test)
        try:
            assert result == expected
        except Exception as e:
            print("Test '%s' failed: %s" % (test, e))


# Generated at 2022-06-11 14:17:53.034115
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    my_string = u'%2Fdag-test%2F'
    assert unicode_urldecode(my_string) == u'/dag-test/'

    my_string_bytes = b'%2Fdag-test%2F'
    assert unicode_urldecode(my_string_bytes) == u'/dag-test/'


# Generated at 2022-06-11 14:17:57.048803
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        return

    assert unicode_urlencode("a b+c:d") == "a%20b%2Bc%3Ad"
    assert unicode_urlencode("a b+c:d", True) == "a+b%2Bc%3Ad"

# Generated at 2022-06-11 14:17:58.515930
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(FilterModule().filters()['urldecode']('%2525') == '%25')



# Generated at 2022-06-11 14:18:04.960809
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%21') == u'!'
    assert unicode_urldecode(u'%23') == u'#'
    assert unicode_urldecode(u'%24') == u'$'
    assert unicode_urldecode(u'%26') == u'&'
    assert unicode_urldecode(u'%27') == u"'"
    assert unicode_urldecode(u'%28') == u'('
    assert unicode_urldecode(u'%29') == u')'
    assert unicode_urldecode(u'%2A') == u'*'

# Generated at 2022-06-11 14:18:08.615595
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'f%C3%B6%C3%B6') == u'föö'
    assert unicode_urldecode('f%C3%B6%C3%B6') == u'föö'


# Generated at 2022-06-11 14:18:14.953636
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # do_urldecode returns unicode
    assert unicode_urldecode(u'%E0%A5%A7%E0%A4%BF%E0%A4%B0%E0%A5%8B%E0%A4%82') == u'धिरों'
    assert unicode_urldecode(u'a+%E0%A5%A7+a') == u'a ध a'
    assert unicode_urldecode(u'a+%2F+a') == u'a / a'
    assert unicode_urldecode('%2Fa') == u'/a'

# Generated at 2022-06-11 14:18:16.419859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-11 14:18:24.994511
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u2713 abc') == u'%E2%9C%93+abc'
    assert unicode_urlencode(u'#!@&') == u'%23!%40%26'
    assert unicode_urlencode(u'#!@&', for_qs=True) == u'%23%21%40%26'
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'!foo') == u'%21foo'
    assert unicode_urlencode(u'!foo', for_qs=True) == u'%21foo'
    assert unicode_urlencode(u'foo%2Fbar') == u'foo%2Fbar'
    assert unicode_urlen