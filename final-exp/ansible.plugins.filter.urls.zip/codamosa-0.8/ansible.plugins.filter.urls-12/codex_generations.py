

# Generated at 2022-06-11 14:08:52.846824
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%C3%A0") == u"\u00E0"
    assert unicode_urldecode("%C3%A0%20%C3%A8") == u"\u00E0 \u00E8"


# Generated at 2022-06-11 14:09:03.519051
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test for unicode_urlencode '''
    import sys

    # Python 3 does not have unicode
    if PY3:
        unicode = str


# Generated at 2022-06-11 14:09:13.960047
# Unit test for function do_urlencode
def test_do_urlencode():
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.dirname(__file__) +
                    '/../../../../lib/ansible/module_utils')
    from filter_plugins.core import FilterModule

    class TestURL(unittest.TestCase):
        def test_do_urlencode(self):
            self.assertEqual('a+%22b%22+c', do_urlencode('a "b" c'))
            self.assertEqual('root%3Apassword%40example.com',
                             do_urlencode('root:password@example.com'))
            self.assertEqual('foo+bar', do_urlencode('foo bar'))

# Generated at 2022-06-11 14:09:19.515860
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc%23def%26ghi%2Ajlm%22nop%5Cqr%27stu%3Dvwxy%2Bz%7E%25') == u'abc#def&ghi*jlm"nop\\qr\'stu=vwxy+z~%'



# Generated at 2022-06-11 14:09:22.581626
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%E9%9F%A9%E5%9B%BD'
    result = unicode_urldecode(string)
    assert result == '韩国', result


# Generated at 2022-06-11 14:09:32.073762
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc def') == u'abc def'
    assert unicode_urldecode(u'abc+def') == u'abc def'
    assert unicode_urldecode(u'abc%20def') == u'abc def'
    assert unicode_urldecode(u'abc%2Bdef') == u'abc+def'

    if PY3:
        assert unicode_urldecode('abc') == u'abc'
        assert unicode_urldecode('abc def') == u'abc def'
        assert unicode_urldecode('abc+def') == u'abc def'

# Generated at 2022-06-11 14:09:39.895064
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wieers') == u'dag wieers'
    assert unicode_urldecode(b'dag%20wieers') == u'dag wieers'

    assert unicode_urldecode(u'%F0%9F%8E%A9') == u'\U0001F4A9'
    assert unicode_urldecode(b'%F0%9F%8E%A9') == u'\U0001F4A9'



# Generated at 2022-06-11 14:09:43.911566
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc+%C3%A9+def') == u'abc é def'
    assert unicode_urldecode('abc+%20def') == u'abc def'


# Generated at 2022-06-11 14:09:53.569161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters_result = FilterModule().filters()
    urldecode_result = filters_result.get("urldecode")
    if PY3:
        assert(urldecode_result("Oh%20Hello%2C%20World%21%20This%20is%20a%20%F0%9F%A6%83%20URL%20encoded%20string."))
    else:
        assert(urldecode_result("Oh%20Hello%2C%20World%21%20This%20is%20a%20%F0%9F%A6%83%20URL%20encoded%20string."))

# Generated at 2022-06-11 14:09:57.489472
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    u = unicode_urldecode
    assert u(u'test+%C3%A9+%C3%A7') == u'test é ç'
    assert u(u'test+%E9+%E7') == u'test é ç'
    assert u(u'test') == u'test'


# Generated at 2022-06-11 14:10:07.390041
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://example.com/?a&b%20&&c=+') == u'http%3A//example.com/%3Fa%26b%20%26%26c%3D%2B'
    assert unicode_urlencode('http://example.com/?a&b%20&&c=+', for_qs=True) == u'http%3A%2F%2Fexample.com%2F%3Fa%26b%2520%26%26c%3D%2B'
    assert unicode_urlencode(u'http://example.com/?a&b%20&&c=+') == u'http%3A//example.com/%3Fa%26b%20%26%26c%3D%2B'

# Generated at 2022-06-11 14:10:10.241705
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six import u
    assert unicode_urldecode(u('Test+%26+%C3%BC')) == u('Test & ü')


# Generated at 2022-06-11 14:10:14.514360
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = 'g%C3%A2teau'
    assert unicode_urldecode(string) == 'gâteau'
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode(u'abc') == 'abc'
    assert unicode_urldecode(b'abc') == 'abc'

# Generated at 2022-06-11 14:10:21.885016
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fltr = FilterModule()
    filters = fltr.filters()

    assert filters['urldecode'](u'foo%20bar') == u'foo bar'

    if not HAS_URLENCODE:
        assert filters['urlencode'](u'foo bar') == u'foo+bar'
        assert filters['urlencode']({'spaces': u'foo bar', 'special': u'@:$+;'}) == u'spaces=foo+bar&special=@%3A$%2B%3B'

# Generated at 2022-06-11 14:10:28.624322
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:10:34.612277
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test without for_qs=True
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo bar', for_qs=False) == u'foo%20bar'
    # Test with for_qs=True
    assert unicode_urlencode('foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode('foo+bar', for_qs=True) == u'foo%2Bbar'


# Generated at 2022-06-11 14:10:45.121117
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from jinja2.runtime import Context
    from ansible.template import Templar

    fm = FilterModule()
    filters = fm.filters()

    template_uid = '55f41bc7d6c0b3778fb391015ce2d7d0fab8c23b'
    templar = Templar(variables={'template_host': 'foo'},
                      loader=None,
                      shared_loader_obj=None,
                      environment=None,
                      disable_lookups=True)

    context = Context({'ansible_vault': None}, None, None, None, None, {'vars': {'template_host': 'foo'}, 'template_host': 'foo'})

    # Test the urldecode filter

# Generated at 2022-06-11 14:10:54.475221
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    yamlfilename = os.path.join(os.path.dirname(__file__), 'test_FilterModule_filters.yaml')

    filter_module = FilterModule()
    filters = filter_module.filters()

    # import yaml
    # yaml.dump(filters, open(yamlfilename, 'w'), default_flow_style=False)

    import yaml
    expected = yaml.load(open(yamlfilename, 'r'))

    # yaml.dump(filters, sys.stdout, default_flow_style=False)

    for key, value in expected.items():
        assert key in filters, 'Missing filter %s' % key

# Generated at 2022-06-11 14:10:57.405141
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb') == u'a+b'
    assert unicode_urldecode('a+b') == u'a+b'


# Generated at 2022-06-11 14:11:01.283545
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters["urldecode"](u"%3A%2F%2F%3F%3F") == u"://??"
    assert filters["urlencode"](u"://??") == u"%3A%2F%2F%3F%3F"

# Generated at 2022-06-11 14:11:11.701319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fwww.example.com') == u'http://www.example.com'
    assert unicode_urldecode(b'http%3A%2F%2Fwww.example.com') == u'http://www.example.com'
    assert unicode_urldecode(u'http://www.example.com') == u'http://www.example.com'
    assert unicode_urldecode(b'http://www.example.com') == u'http://www.example.com'



# Generated at 2022-06-11 14:11:20.701803
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Initialize instance of class FilterModule
    filter_module = FilterModule()

    # Assign attribute 'filters' of instance 'filter_module'
    filters = filter_module.filters()

    # Initialize dictionaries
    filter_filters = filters['filter']
    map_filters = filters['map']
    select_filters = filters['select']
    reject_filters = filters['reject']

    # Verify name of method 'filter'
    assert filter_filters.__name__ == 'do_filter'

    # Verify name of method 'map'
    assert map_filters.__name__ == 'do_map'

    # Verify name of method 'select'
    assert select_filters.__name__ == 'do_select'

    # Verify name of method 'reject'
    assert reject_filters.__

# Generated at 2022-06-11 14:11:23.251003
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode('foo%3Dbar') == u'foo=bar'

# Generated at 2022-06-11 14:11:29.365393
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'da%C3%AFmon') == u'daïmon'
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode(None) == u''
    assert unicode_urldecode(42) == u'42'
    assert unicode_urldecode(42.0) == u'42.0'


# Generated at 2022-06-11 14:11:39.082392
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:11:41.634039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert 'urldecode' in filters.filters()
    assert 'urlencode' in filters.filters()



# Generated at 2022-06-11 14:11:44.114078
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters is not None
    assert len(filters) > 0
    for key in filters:
        assert key in filters



# Generated at 2022-06-11 14:11:51.584508
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("http://www.wikipedia.com/") == u'http%3A%2F%2Fwww.wikipedia.com%2F'
    assert unicode_urlencode("https://www.wikipedia.com/") == u'https%3A%2F%2Fwww.wikipedia.com%2F'
    assert unicode_urlencode("https://www.wikipedia.com/") == u'https%3A%2F%2Fwww.wikipedia.com%2F'
    assert unicode_urlencode("https://www.wikipedia.com/path/to/something") == u'https%3A%2F%2Fwww.wikipedia.com%2Fpath%2Fto%2Fsomething'

# Generated at 2022-06-11 14:11:53.462522
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-11 14:11:54.926058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2F') == u'/'


# Generated at 2022-06-11 14:12:04.037717
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'\u20ac') == u'%E2%82%AC'
    assert do_urlencode({u'\u20ac': u'\u20ac'}) == u'%E2%82%AC=%E2%82%AC'
    assert do_urlencode([(u'\u20ac', u'\u20ac')]) == u'%E2%82%AC=%E2%82%AC'

# Generated at 2022-06-11 14:12:13.151834
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert u'test' == unicode_urldecode(u'test')
    assert u'тест' == unicode_urldecode(u'%D1%82%D0%B5%D1%81%D1%82')

    assert u'тест' == unicode_urldecode(u'тест')
    assert u'тест' == unicode_urldecode(u'тест')
    assert u'тест' == unicode_urldecode(u'тест')


# Generated at 2022-06-11 14:12:17.533233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    result = fm.filters()
    assert result is not None
    assert len(result) > 0
    assert 'urldecode' in result
    assert 'urlencode' in result
    assert callable(result['urldecode'])
    assert callable(result['urlencode'])


# Generated at 2022-06-11 14:12:24.536058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'Hello%20World%21') == u'Hello World!'
    assert unicode_urldecode(u'Hello%27World%21') == u'Hello\'World!'
    assert unicode_urldecode(u'%EC%B6%A9%EC%9E%90%EC%9C%88') == u'충자윈'
    assert unicode_urldecode(u'%25%EC%B6%A9%EC%9E%90%EC%9C%88') == u'%충자윈'

# Generated at 2022-06-11 14:12:35.139296
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcABC123') == 'abcABC123'
    assert unicode_urlencode('€5.00') == '%E2%82%AC5.00'
    assert unicode_urlencode('€5.00', for_qs=True) == '%E2%82%AC5.00'
    assert unicode_urlencode('€&=?/+') == '%E2%82%AC%26%3D%3F%2F%2B'
    assert unicode_urlencode('€&=?/+', for_qs=True) == '%E2%82%AC%26%3D%3F%2F%2B'

# Generated at 2022-06-11 14:12:44.242075
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import zip

    # tested methods
    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_urldecode = filters['urldecode']
    filter_urlencode = filters['urlencode']

    # prepare parameters
    text = '你好'
    url_string = '%E4%BD%A0%E5%A5%BD'
    url_dict = dict(zip([text, text], [text, text]))
    url_items = [(text, text), (text, text)]

# Generated at 2022-06-11 14:12:52.622181
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/') == u'http%3A//www.example.com/'
    assert unicode_urlencode(u'http://www.example.com/') == unicode_urlencode(to_text(b'http://www.example.com/'))
    assert unicode_urlencode(u'http://www.example.com/') == unicode_urlencode(u'http://www.example.com/')
    if PY3:
        assert unicode_urlencode(u'http://www.example.com/') == unicode_urlencode(b'http://www.example.com/')
    else:
        assert unicode_urlencode(u'http://www.example.com/') != unicode_urlencode

# Generated at 2022-06-11 14:12:58.274355
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb+%2B') == u'a+b ++'
    assert unicode_urldecode('x%C3%BCx') == u'xüx'
    assert unicode_urldecode('%F0%9F%98%80') == u'😀'
    assert unicode_urldecode('%E2%82%AC') == u'€'


# Generated at 2022-06-11 14:13:06.949873
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test basic string encoding
    assert unicode_urlencode(u'hello world!') == u'hello%20world%21'

    # Test dict encoding
    assert unicode_urlencode({u'foo': u'bar', u'baz': u'faz'}) == u'foo=bar&baz=faz'

    # Test list encoding
    assert unicode_urlencode([u'foo', u'bar']) == u'foo&bar'

    # Test query string
    assert unicode_urlencode(u'hello world!', for_qs=True) == u'hello+world%21'

    # Test query string dict encoding

# Generated at 2022-06-11 14:13:15.058549
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic

    def _test(string, expected):
        result = unicode_urldecode(string)
        basic.fail_json(msg='input %r expected %r returned %r' % (string, expected, result))

    _test('abc', 'abc')
    _test('abc%20def', 'abc def')
    _test('abc%C3%A8%C3%A9%C3%AA', u'abcèéê')
    _test('abc%2Fdef', 'abc/def')
    _test(u'abc%2Fdef', u'abc/def')
    _test(u'abc%C3%A8%C3%A9%C3%AA%2Fdef', u'abcèéê/def')


# Generated at 2022-06-11 14:13:23.021339
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Not implemented
    pass

# Generated at 2022-06-11 14:13:33.016744
# Unit test for function do_urlencode
def test_do_urlencode():
    import sys
    import re

    # Test with string
    ret = do_urlencode('dummy string')
    assert ret == 'dummy+string'

    # Test with dictionary
    dict_obj = dict(key='value', foo='bar', bar='foo')
    str_ret = do_urlencode(dict_obj)
    strlist = str_ret.split('&')
    assert len(strlist) == 3
    assert strlist[0] == 'key=value'
    assert strlist[1] == 'foo=bar'
    assert strlist[2] == 'bar=foo'

    # Test with a list of tuples
    key_value_list = list()
    key_value_list.append(('key', 'value'))
    key_value_list.append(('foo', 'bar'))

# Generated at 2022-06-11 14:13:43.160140
# Unit test for method filters of class FilterModule

# Generated at 2022-06-11 14:13:53.889158
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:14:02.565602
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20world%3F') == u'hello world?'
    assert unicode_urldecode('hello%20world%3F') == u'hello world?'
    assert unicode_urldecode(u'hello+world%3F') == u'hello world?'
    assert unicode_urldecode('hello+world%3F') == u'hello world?'
    assert unicode_urldecode('%E6%96%87%E5%AD%97%E3%81%AE%E8%AA%AD%E3%81%BF%E3%81%A8%E3%81%97') == u'文字の読みとし'

# Generated at 2022-06-11 14:14:08.524140
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%25%20%25') == '% %'
    assert unicode_urldecode('%20%25') == ' %'


# Generated at 2022-06-11 14:14:13.135004
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string = "S%C3%A3%C3%B0p%C3%B8%C3%B1%C3%A5.t%C3%A5%C3%B5.c%C3%B2m"
    assert unicode_urldecode(test_string) == u"Sãòpñå.tåõ.côm"


# Generated at 2022-06-11 14:14:19.101050
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u'\x20'
    assert unicode_urldecode('%E6%97%A5%E6%9C%AC%E8%AA%9E') == u'\u65e5\u672c\u8a9e'
    assert unicode_urldecode('%E6%97%A5%E6%9C%AC%E8%AA%9E%20') == u'\u65e5\u672c\u8a9e\x20'
    assert unicode_urldecode('toto') == u'toto'


# Generated at 2022-06-11 14:14:29.079838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Setup a FilterModule instance
    fm = FilterModule()

    # Verify that the urldecode filter function returns expected result
    urldecode = fm.filters()['urldecode']
    # No change
    assert urldecode("nochange") == "nochange"
    # Percent encoded string
    assert urldecode("%25%32%35") == "%25"
    # Percent encoded utf-8 string
    assert urldecode("%25%C2%A2%25%C2%A2") == "%25¢%25¢"

    if not HAS_URLENCODE:
        # Verify that the urlencode filter function returns expected result
        urlencode = fm.filters()['urlencode']
        # No change
        assert urlencode("nochange") == "nochange"

# Generated at 2022-06-11 14:14:40.409325
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar%') == u'foo%20bar%25'
    assert unicode_urlencode(u'foo/') == u'foo%2F'
    assert unicode_urlencode(u'foo%') == u'foo%25'
    assert unicode_urlencode(u'foo%2F') == u'foo%252F'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u'foo+bar', for_qs=True) == u'foo%2Bbar'

# Generated at 2022-06-11 14:14:51.611364
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%C3%A9") == u"é"
    assert unicode_urldecode("%E2%82%AC%20") == u"€ "
    assert unicode_urldecode("%30%31%32") == u"012"

# Generated at 2022-06-11 14:14:54.301223
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filtermodule.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:15:03.092475
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' urldecode filter with unicode characters '''

    assert unicode_urldecode(u'%C3%B1') == u'ñ'
    assert unicode_urldecode(u'%E2%82%AC') == u'€'
    assert unicode_urldecode(u'%E2%82%AC') == u'€'
    assert unicode_urldecode(u'%25%20') == u'% '
    assert unicode_urldecode(u'%E2%82%AC%20') == u'€ '
    assert unicode_urldecode(u'%E2%82%AC%2F') == u'€/'

# Generated at 2022-06-11 14:15:07.067551
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string = "%D0%A2%D0%B5%D1%81%D1%82"
    decoded_string = unicode_urldecode(test_string)
    assert decoded_string == u"Тест"

# Generated at 2022-06-11 14:15:09.495895
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%20b%202%20c") == "a b 2 c"

# Generated at 2022-06-11 14:15:13.734054
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()



# Generated at 2022-06-11 14:15:23.085114
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc+') == u'abc '
    assert unicode_urldecode(u'abc+def') == u'abc def'
    assert unicode_urldecode(u'abc%2Bdef') == u'abc+def'
    assert unicode_urldecode(u'abc%2bdef') == u'abc+def'
    assert unicode_urldecode(u'abc%25def') == u'abc%def'
    assert unicode_urldecode(u'abc%C3%BCdef') == u'abc\xfcdef'


# Generated at 2022-06-11 14:15:30.566739
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Normal string
    assert unicode_urlencode("string") == "string"
    # String with spaces
    assert unicode_urlencode("some words") == "some%20words"
    # Unicode
    assert unicode_urlencode("世界") == "%E4%B8%96%E7%95%8C"
    # Unicode with spaces
    assert unicode_urlencode("你好 世界") == "%E4%BD%A0%E5%A5%BD%20%E4%B8%96%E7%95%8C"
    # Unicode with non-URL chars (forward slash)

# Generated at 2022-06-11 14:15:41.839384
# Unit test for function do_urlencode
def test_do_urlencode():
    c = dict({k: unicode_urlencode(v, True) for k, v in {'a': u'1', 'b': u'', 'c': u'\n', 'd': u'\x80', 'e': u'\xc0'}.items()})
    d = 'a=1&b=&c=%0A&d=%80&e=%C0'
    assert do_urlencode({'a': u'1', 'b': u'', 'c': u'\n', 'd': u'\x80', 'e': u'\xc0'}).encode('utf-8') == d
    assert do_urlencode(c) == d


# Generated at 2022-06-11 14:15:45.560226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode']('arg') == 'arg'
    if not HAS_URLENCODE:
        assert filters['urlencode']('arg') == 'arg'



# Generated at 2022-06-11 14:16:00.489586
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if not PY3:
        assert unicode_urldecode('abcdefghijklmnopqrstuvwxyz') == u'abcdefghijklmnopqrstuvwxyz'
        assert unicode_urldecode('+') == u' '
        assert unicode_urldecode('%20') == u' '
        assert unicode_urldecode('%21') == u'!'
        assert unicode_urldecode('%26') == u'&'
        assert unicode_urldecode('%7E') == u'~'
        assert unicode_urldecode('%27') == u"'"
        assert unicode_urldecode("%27") == u"'"
        # Make sure we don't decode +, because it is a valid character (I.

# Generated at 2022-06-11 14:16:10.803571
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # PY3
    if PY3:
        # Passing in a dict should return a string
        assert unicode_urlencode({'a': 'b'}) == 'a=b'
        # Passing in a list should return a string
        assert unicode_urlencode(['a', 'b']) == 'a&b'
        # Passing in a non-str, non-iterable object should return a string
        assert unicode_urlencode(object()) == ''
        # Passing in a tuple should return a string
        assert unicode_urlencode(('a', 'b')) == 'a&b'
        # Passing in a non-str string should return a str
        # NOTE: this is a different answer than Jinja2 provides!
        assert unicode_urlencode('abc d') == 'abc%20d'
       

# Generated at 2022-06-11 14:16:13.808285
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('Array+A%7C2+B8+C7%7D') == 'Array A|2 B8 C7}'
    assert do_urlencode('Array A|2 B8 C7}') == 'Array+A%7C2+B8+C7%7D'

# Generated at 2022-06-11 14:16:19.470205
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B1') == u'\xf1'
    assert unicode_urldecode('%C3%B1%2B%2F%3D') == u'\xf1+/='
    assert unicode_urldecode('%C3%B1+/=') == u'\xf1+/='



# Generated at 2022-06-11 14:16:28.272745
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.compat.tests import unittest

    class TestUrlEncode(unittest.skipUnless(PY3, "Not PY3")):
        def test_dict(self):
            s = do_urlencode({"a": "b"})
            self.assertEqual(s, "a=b")

        def test_tuple(self):
            s = do_urlencode(("a", "b"))
            self.assertEqual(s, "0=a&1=b")

        def test_list(self):
            s = do_urlencode(["a", "b"])
            self.assertEqual(s, "0=a&1=b")

        def test_unicode(self):
            s = do_urlencode({"a": "b"})
           

# Generated at 2022-06-11 14:16:30.129018
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3Ffoo%3Dbar') == '?foo=bar'


# Generated at 2022-06-11 14:16:34.756392
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'40%25') == u'40%'
    assert unicode_urldecode(b'40%25') == u'40%'
    assert unicode_urldecode(b'40%25'.decode('utf-8')) == u'40%'



# Generated at 2022-06-11 14:16:37.935771
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_urldecode('\xc2\x80')
    unicode_urldecode('\xc2\x80%')
    unicode_urldecode('\xc3\xa0%')
    unicode_urldecode('\xe2\x82\xac%')
    unicode_urldecode('\xf0\xa4\xad\xa2')


# Generated at 2022-06-11 14:16:39.488611
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A1') == u'á'



# Generated at 2022-06-11 14:16:40.642410
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u'%20'

# Generated at 2022-06-11 14:16:56.131505
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from . import do_urldecode, do_urlencode
    from unittest import TestCase, skipIf
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus

    if not PY3:
        unicode = lambda s, *_: s
        unichr = chr

    class Test_FilterModule_filters(TestCase):
        def test_urldecode(self):
            self.assertEqual(do_urldecode(u'a+b+c'), unicode('a b c'))
            self.assertEqual(do_urldecode(u'a b&c'), unicode('a b&c'))

# Generated at 2022-06-11 14:17:00.185027
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%B6%C3%A4') == u'öä'
    assert unicode_urldecode(u'%C3%B6%C3%A4%C3%BC%C3%9F') == u'öäüß'


# Generated at 2022-06-11 14:17:10.283710
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('http://example.com/') == u'http%3A//example.com/'
    assert do_urlencode('http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'
    assert do_urlencode(u'http://example.com/?a=b') == u'http%3A//example.com/%3Fa%3Db'
    assert do_urlencode(u'http://example.com/?a=b&c=d') == u'http%3A//example.com/%3Fa%3Db%26c%3Dd'

# Generated at 2022-06-11 14:17:14.281289
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b%20c') == u'a b c'
    assert unicode_urldecode('a+%E2%82%AC+%F0%9D%8C%86') == u'a \u20ac \U0001d116'

# Unit tests for function unicode_urlencode

# Generated at 2022-06-11 14:17:20.623151
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello') == 'hello'
    assert unicode_urldecode('hello+world') == 'hello world'
    assert unicode_urldecode('hello%20world') == 'hello world'
    assert unicode_urldecode('hello%2Bworld') == 'hello+world'
    assert unicode_urldecode('hello%25world') == 'hello%world'
    assert unicode_urldecode('hello+%25world') == 'hello %world'



# Generated at 2022-06-11 14:17:26.453417
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://some_server:some_port/some_path/some_file') == u'http%3A//some_server%3Asome_port/some_path/some_file'
    assert unicode_urlencode(unicode_urldecode(u'http%3A//some_server%3Asome_port/some_path/some_file'), for_qs=True) == u'http%3A//some_server%3Asome_port/some_path/some_file'


# Generated at 2022-06-11 14:17:30.127578
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'
    assert unicode_urldecode('%41%42') == u'AB'
    assert unicode_urldecode('%') == u'%'        # Invalid data is left intact

# Generated at 2022-06-11 14:17:39.744759
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com?a=1&b=2') == u'http%3A//example.com%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com?a=1&b=2', for_qs=True) == u'http%3A//example.com%3Fa%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.com?a=1/2+3') == u'http%3A//example.com%3Fa%3D1/2+3'

# Generated at 2022-06-11 14:17:42.878852
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module is not None
    assert 'urldecode' in filter_module.filters()
    assert 'urlencode' in filter_module.filters()


# Generated at 2022-06-11 14:17:44.486080
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-11 14:18:01.355291
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Verify the following:
    - We can decode bytes into it's unicode representation
    - We can decode unicode into it's unicode representation
    - We get the same result on Python 2 and Python 3
    '''
    assert unicode_urldecode(b'%5B%5D') == u'[]'
    assert unicode_urldecode(u'%5B%5D') == u'[]'
    assert unicode_urldecode(b'%5B%5D') == unicode_urldecode(u'%5B%5D')

    assert unicode_urldecode(b'%E5%98%98') == u'嘘'
    assert unicode_urldecode(u'%E5%98%98') == u'嘘'


# Generated at 2022-06-11 14:18:10.579281
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == 'foo'
    assert unicode_urldecode(u'foo+bar') == 'foo bar'
    assert unicode_urldecode(u'foo%20bar') == 'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == 'foo/bar'
    assert unicode_urldecode(u'foo%2Fbar%2Fbaz') == 'foo/bar/baz'
    assert unicode_urldecode(u'%C3%9Chl%C3%A9') == "Uhle"

# Generated at 2022-06-11 14:18:12.000517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test_FilterModule_filters is a stub
    assert True


# Generated at 2022-06-11 14:18:13.964047
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('stuff%20to%20decode') == u'stuff to decode', 'unicode_urldecode error'



# Generated at 2022-06-11 14:18:17.050243
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode('%C3%BC')
    assert result == u'ü'


# Generated at 2022-06-11 14:18:25.400579
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' Ansible core jinja2 filters unit tests '''

# Generated at 2022-06-11 14:18:33.831169
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("foo") == "foo"
    assert unicode_urldecode("foo+bar") == "foo bar"
    assert unicode_urldecode("%2B%2B") == "++"
    assert unicode_urldecode("%2B%20%2B") == "+ ++"
    assert unicode_urldecode("%2B%2B%2B%2B%2B%2B") == "++++++"
    assert unicode_urldecode("%2B%2d%2B%2D") == "+- +-"


# Generated at 2022-06-11 14:18:44.894556
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode_urlencode') == u'unicode_urlencode'
    assert unicode_urlencode(u'some%string') == u'some%string'
    assert unicode_urlencode(u'some%20string') == u'some%20string'
    assert unicode_urlencode(u'some% string') == u'some%25%20string'
    assert unicode_urlencode(u'some%+string') == u'some%25%2Bstring'
    assert unicode_urlencode(u'some+string') == u'some%2Bstring'
    assert unicode_urlencode(u'some%string', for_qs=True) == u'some%25string'

# Generated at 2022-06-11 14:18:47.096650
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'f%20o%20o') == u'f o o'

