

# Generated at 2022-06-11 14:08:47.717416
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('%28%29%28%29%28%29') == '((()))'



# Generated at 2022-06-11 14:08:54.397077
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unquote
    module = FilterModule()
    assert module.filters()['urldecode']('Hello%2BWorld%21') == 'Hello+World!'

    # Quote
    to_quote = {'key1': 'value1', 'key 2': 'value 2'}
    if not HAS_URLENCODE:
        module = FilterModule()
        assert module.filters()['urlencode'](to_quote) == 'key1=value1&key+2=value+2'

# Generated at 2022-06-11 14:09:02.268760
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fake = type('FakeModule', (object,), {'params': {'filter': 'urlencode'}})
    f = getattr(FilterModule().filters()[fake.params['filter']], '__func__')
    assert f('?foo=bar') == '%3Ffoo%3Dbar'
    fake.params['filter'] = 'urldecode'
    f = getattr(FilterModule().filters()[fake.params['filter']], '__func__')
    assert f('%3Ffoo%3Dbar') == '?foo=bar'

# Generated at 2022-06-11 14:09:09.090738
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import unittest

    class TestUnicodeUrlencode(unittest.TestCase):

        def test_input_string(self):
            self.assertEqual(unicode_urlencode("some string"), "some%20string")

        def test_input_string_with_slash(self):
            self.assertEqual(unicode_urlencode("some string /"), "some%20string%20%2F")

        def test_input_for_qs_param(self):
            self.assertEqual(unicode_urlencode("some string /", True), "some%20string%20%2F")


# Generated at 2022-06-11 14:09:13.678800
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%3F%40%5B%5D') == u'!#$&\'()*+,;=?@[]'



# Generated at 2022-06-11 14:09:18.437176
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    assert u'%C3%A4' == filter_obj.filters()['urlencode'](u'ä')
    assert u'%C3%A4' == filter_obj.filters()['urlencode']({'a':u'ä'})

# Generated at 2022-06-11 14:09:21.936310
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    module = FilterModule()
    filters = module.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
    else:
        assert 'urlencode' not in filters

# Generated at 2022-06-11 14:09:23.866138
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'Abc%20Def') == u'Abc Def'


# Generated at 2022-06-11 14:09:26.890771
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert('urldecode' in fm.filters())
    assert('urlencode' in fm.filters())



# Generated at 2022-06-11 14:09:31.012602
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc+') == 'abc '
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc%20def%2Aghi') == 'abc def*ghi'


# Generated at 2022-06-11 14:09:44.842167
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..')))
    from test.units.module_utils import FilterModuleTestCase

    passed = 0
    failed = 0
    total = 0

    # Load the tests from the testcase class
    tests = FilterModuleTestCase.load_fixtures('FilterModule')

    # Loop the tests
    for test in tests['core']:
        if test['name'] == 'urldecode':
            for item in test['inputs']:
                total += 1

# Generated at 2022-06-11 14:09:55.300115
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Set up module state
    module = FilterModule()
    # Verify urldecode method
    assert(module.filters()['urldecode']('foo') == 'foo')
    assert(module.filters()['urldecode']('foo is %2525') == 'foo is %25')
    # Verify urlencode method
    if 'urlencode' in module.filters():
        assert(module.filters()['urlencode']('foo') == 'foo')
        assert(module.filters()['urlencode']('foo is %25') == 'foo%20is%20%2525')


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-11 14:10:05.287857
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/path/with a space') == u'/path/with%20a%20space'
    assert unicode_urlencode('/path/a?key=value&foo=bar baz') == u'/path/a?key=value&foo=bar%20baz'
    assert unicode_urlencode('/path/a?key=value&foo=bar=baz') == u'/path/a?key=value&foo=bar%3Dbaz'
    assert unicode_urlencode('/path/a?key=value&foo=bar+baz') == u'/path/a?key=value&foo=bar%2Bbaz'

# Generated at 2022-06-11 14:10:09.772961
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import ansible.module_utils.six.moves.urllib.parse as urllib
    qs = u"key1=value1&key2=value2"
    assert unicode_urldecode(qs) == urllib.unquote_plus(qs)


# Generated at 2022-06-11 14:10:18.407233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('foo%20bar%3F') == 'foo bar?'
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('foo bar?') == 'foo+bar%3F'
        assert fm.filters()['urlencode'](['foo bar?']) == '0=foo+bar%3F'
        assert fm.filters()['urlencode']({'one': 'foo bar?', 'two': 'foo baz?'}) == 'two=foo+baz%3F&one=foo+bar%3F'
    assert fm.filters()['urlencode']('/') == '%2F'



# Generated at 2022-06-11 14:10:23.055361
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('http%3A%2F%2Fwww.example.com%2F%3Fabc%3Ddef%26xyz%3D123') == \
        u'http://www.example.com/?abc=def&xyz=123'



# Generated at 2022-06-11 14:10:24.194226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()


# Generated at 2022-06-11 14:10:30.751788
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.modules.templating import template

    my_filter_module = FilterModule()
    my_template = template.Template(basic._load_params(), basic._ANSIBLE_VERSION, basic._ANSIBLE_MODULE_ARGS, basic._ANSIBLE_MODULE_COMPLEX_ARGS, basic._ANSIBLE_MODULE_REQUIRED_ARGS)
    assert my_filter_module.filters() == my_template.filters()



# Generated at 2022-06-11 14:10:36.684796
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E6%96%87%E5%AD%97%E7%AC%A6%E4%B8%B2') == '文字符串'
    assert unicode_urldecode('%E6%96%87%E5%AD%97+%E7%AC%A6%E4%B8%B2') == '文字 符串'
    assert unicode_urldecode('%E6%96%87%E5%AD%97+%E7%AC%A6%E4%B8%B2') == '文字 符串'


# Generated at 2022-06-11 14:10:38.003633
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%2F') == u'//'

# Generated at 2022-06-11 14:10:48.651527
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:10:50.687804
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode('a+b%2Bc+%26+d')
    assert result == 'a b+c & d'



# Generated at 2022-06-11 14:10:57.024260
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B6%C3%A4%C3%BC') == u'öäü'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('%26%20') == u'& '
    assert unicode_urldecode('foo') == u'foo'


# Generated at 2022-06-11 14:11:00.903620
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    text_value_equal(u"test",
                     u"test",
                     u"test")
    text_value_equal(u"test",
                     u"test",
                     b"test")
    text_value_equal(u"test",
                     u"test",
                     b"test",
                     for_qs=True)


# Generated at 2022-06-11 14:11:10.687578
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    def check_urlencode(value, expected):
        assert FilterModule.filters()['urlencode'](value) == expected

    check_urlencode('foo', 'foo')
    check_urlencode('foo bar', 'foo%20bar')
    check_urlencode('foo+bar', 'foo%2Bbar')
    check_urlencode('foo+bar=baz', 'foo%2Bbar%3Dbaz')
    check_urlencode({'foo': 'bar', 'baz': 'qux'}, 'baz=qux&foo=bar')
    check_urlencode(('foo', 'bar'), 'foo&bar')
    check_urlencode(('foo=bar', 'baz=qux'), 'foo%3Dbar&baz%3Dqux')
    check_url

# Generated at 2022-06-11 14:11:17.934567
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import pytest

    test_strs = {
        u'%25F0%259F%2590%2580': u'🐀',
        u'%C3%B1': u'ñ',
        u'%25E2%2580%2599': u'\u2019',
        u'%e2%80%99': u'\u2019',
        u'%2F': u'/',
    }

    for enc, dec in test_strs.items():
        assert unicode_urldecode(enc) == dec



# Generated at 2022-06-11 14:11:20.031112
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters is not None
    assert 'urldecode' in filters


# Generated at 2022-06-11 14:11:22.071015
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+%2F%2Bb') == u'a+/%2Bb'


# Generated at 2022-06-11 14:11:31.874332
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    res_do_urldecode = FilterModule().filters()['urldecode'](u'%F6%E4%FC')
    assert res_do_urldecode == u'öäü'

    res_do_urldecode_wrong_encoding = FilterModule().filters()['urldecode'](u'%F6%E4%FC'.encode('iso-8859-15'))
    assert res_do_urldecode_wrong_encoding == u'\ufffd\ufffd\ufffd'

    res_do_urlencode = FilterModule().filters()['urlencode'](u'öäü')
    assert res_do_urlencode == u'%F6%E4%FC'

    res_do_

# Generated at 2022-06-11 14:11:33.604487
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = u'foo%20bar'
    assert unicode_urldecode(string) == u'foo bar'


# Generated at 2022-06-11 14:11:44.510070
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a%2Bb') == u'a+b'
    assert unicode_urldecode(b'a%2Bb') == u'a+b'
    assert unicode_urldecode(b'a+b') == u'a b'
    assert unicode_urldecode(u'%F0%9F%98%80') == u'\U0001f600'
    assert unicode_urldecode(b'%F0%9F%98%80') == u'\U0001f600'
    assert unicode_urldecode('\xe2\x98\x83') == '☃'
    # This test is to ensure that we

# Generated at 2022-06-11 14:11:52.897902
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:11:55.921203
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert fm.filters()['urldecode']('first%20last') == 'first last'
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('first last') == 'first+last'

# Generated at 2022-06-11 14:12:00.240216
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-11 14:12:06.961533
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%2A') == '*'
    assert unicode_urldecode('%27') == "'"
    assert unicode_urldecode('%28') == '('
    assert unicode_urldecode('%29') == ')'
    assert unicode_urldecode('%3B') == ';'
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%3D') == '='
    assert unicode_urldecode('%2B') == '+'

# Generated at 2022-06-11 14:12:17.928453
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'https://example.com/api/v2/hosts?limit=10&offset=0') == u'https%3A%2F%2Fexample.com%2Fapi%2Fv2%2Fhosts%3Flimit%3D10%26offset%3D0'
    assert unicode_urlencode(u'https://example.com/api/v2/hosts/127.0.0.1') == u'https://example.com/api/v2/hosts/127.0.0.1'
    assert unicode_urlencode(u'https://example.com/api/v2/hosts.json') == u'https://example.com/api/v2/hosts.json'

# Generated at 2022-06-11 14:12:24.740712
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_cases = []

    # test_case #0 - basic test
    input_0 = {
        'foo': 'bar',
    }
    expected_output_0 = {'urldecode': 'bar',
                         'urlencode': 'foo=bar'}
    test_cases.append((input_0, expected_output_0))

    # test_case #1 - with double quote
    input_1 = {
        'foo': 'bar',
        'baz': 'quux"quuux',
    }
    expected_output_1 = {'urldecode': 'bar',
                         'urlencode': 'foo=bar&baz=quux%22quuux'}
    test_cases.append((input_1, expected_output_1))

    # test_case #2 - utf

# Generated at 2022-06-11 14:12:29.586717
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:12:33.516146
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('a&b') == 'a%26b'
    assert do_urlencode('a&b c') == 'a%26b+c'
    assert do_urlencode({'a&b c': 'd e'}) == 'a%26b+c=d+e'

# Generated at 2022-06-11 14:12:42.595728
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # utf-8 encoded string
    assert unicode_urldecode(u'%3C%3E%C3%A4%C3%B6%C3%BC%C3%9F%C3%80%C3%87%C3%B5') == u'<>äöüßàçõ'
    # encoded unicode
    assert unicode_urldecode(u'%3C%3E%E4%F6%FC%DF%C0%C7%F5') == u'<>äöüßàçõ'
    # unicode string
    assert unicode_urldecode(u'<>äöüßàçõ') == u'<>äöüßàçõ'
    # ascii string
    assert unicode_urld

# Generated at 2022-06-11 14:12:49.762593
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    testcases = [
        ("Hello%20World%21", u"Hello World!"),
        ("Hello+World!", u"Hello World!"),
        ("Hello+%E4%B8%96%E7%95%8C%21", u"Hello 世界!"),
    ]
    for case, expected in testcases:
        assert unicode_urldecode(case) == expected, "urldecode(%s) != %s" % (case, expected)

# Generated at 2022-06-11 14:12:58.390063
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%26b') == u'a&b'
    assert unicode_urldecode(u'a%20b') == u'a b'
    assert unicode_urldecode(u'a+b') == u'a b'
    assert unicode_urldecode(u'a%3D') == u'a='
    assert unicode_urldecode(u'a%26b') == u'a&b'
    assert unicode_urldecode(u'%E4%BA%BA') == u'人'
    assert unicode_urldecode(u'+%26+') == u' & '


# Generated at 2022-06-11 14:13:07.052040
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('hello%20world') == u'hello world'
    assert do_urldecode(u'hello%20world') == u'hello world'
    assert do_urldecode(b'hello%20world') == u'hello world'

    if not HAS_URLENCODE:
        assert do_urlencode('hello world') == u'hello%20world'
        assert do_urlencode(u'hello world') == u'hello%20world'
        assert do_urlencode(b'hello world') == u'hello%20world'

        assert do_urlencode({'foo': 'bar', 'baz': ['qux', 'quux']}) == u'baz=qux&baz=quux&foo=bar'

    # TODO: Add the test cases from do

# Generated at 2022-06-11 14:13:08.375148
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('w%C3%A4lt') == 'w\xe4lt'



# Generated at 2022-06-11 14:13:10.308886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode'] == do_urldecode


# Generated at 2022-06-11 14:13:16.089059
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd') == 'abcd'
    assert unicode_urlencode('ab/cd') == 'ab%2Fcd'
    assert unicode_urlencode('ab/cd', True) == 'ab%2Fcd'
    assert unicode_urlencode({'a':1, 'b':2}) == 'a=1&b=2'
    assert unicode_urlencode([('a',1), ('b',2)]) == 'a=1&b=2'

# Generated at 2022-06-11 14:13:23.180781
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == '/'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('/path/') == '/path/'
    assert unicode_urlencode('/path/', for_qs=True) == '%2Fpath%2F'
    assert unicode_urlencode('/path with space/') == '/path%20with%20space/'
    assert unicode_urlencode('/path with space/', for_qs=True) == '%2Fpath%20with%20space%2F'

# Generated at 2022-06-11 14:13:33.183093
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc<>&?~def') == u'abc%3C%3E%26%3F~def'
    assert unicode_urlencode(u'abc<>&?~def', for_qs=True) == u'abc%3C%3E%26%3F%7Edef'
    assert unicode_urlencode(u'abc/def') == u'abc/def'

# Generated at 2022-06-11 14:13:37.222738
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    >>> hexdump(unicode_urldecode(b'foo+%C3%A9%20bar'))
    00000000  66 6f 6f 20 65 20 62 61  72 00                         |foo e bar.|
    '''
    pass



# Generated at 2022-06-11 14:13:45.764976
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("string") == "string"
    assert unicode_urlencode("abc123[]") == "abc123%5B%5D"
    assert unicode_urlencode("") == ""
    assert unicode_urlencode("/" + "/") == "%2F%2F"
    assert unicode_urlencode("/" + "/", for_qs=True) == "%2F%2F"
    assert unicode_urlencode("?&=;:") == "?&=;:"
    assert unicode_urlencode("?&=;:", for_qs=True) == "%3F%26%3D%3B%3A"
    assert unicode_urlencode("%2f%2f") == "%252f%252f"

# Generated at 2022-06-11 14:13:58.468618
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' test cases for FilterModule filters '''

    # FilterModule.filters()
    # Test empty object
    o = FilterModule()
    if 'urldecode' not in o.filters():
        assert 'Missing urldecode filter'
    if not HAS_URLENCODE:
        if 'urlencode' not in o.filters():
            assert 'Missing urlencode filter'

    # FilterModule.filters()
    # Test normal object
    o = FilterModule()
    if 'urldecode' not in o.filters():
        assert 'Missing urldecode filter'
    if not HAS_URLENCODE:
        if 'urlencode' not in o.filters():
            assert 'Missing urlencode filter'

# Generated at 2022-06-11 14:14:03.498297
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils import basic

    # Create class instance for testing
    fm = FilterModule()

    # Test urldecode filter
    assert fm.filters()['urldecode']('%C3%BCrsten') == 'ürsten'
    # Test urlencode filter
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']('ürsten') == '%C3%BCrsten'

if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-11 14:14:13.793578
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json

    # test for urldecode filter
    assert FilterModule().filters()['urldecode']('a%21b%26c%3Dd%3Fe%3D1%26f%3D2') == u'a!b&c=d?e=1&f=2'

    # test for urlencode filter
    if HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('/%21b&c=d?e=1&f=2') == u'%2F%21b%26c%3Dd%3Fe%3D1%26f%3D2'

# Generated at 2022-06-11 14:14:16.654618
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test for method 'filters' of class 'FilterModule'
    f = FilterModule()
    assert type(f.filters()) is dict
    assert 'urldecode' in f.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in f.filters()



# Generated at 2022-06-11 14:14:21.863397
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u'%00'
    assert unicode_urlencode(u'/') == u'%2F'
    assert unicode_urlencode(u'Hello World') == u'Hello%20World'
    assert unicode_urlencode(u'Hello World', for_qs=True) == u'Hello+World'


# Generated at 2022-06-11 14:14:26.856754
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['urldecode']('a+b%2Cc') == 'a b,c'

    if not HAS_URLENCODE:
        assert filters['urlencode']('a+b%2Cc') == 'a%2Bb%252Cc'

# Generated at 2022-06-11 14:14:30.955566
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A1') == u'á'
    assert unicode_urldecode('%C3%A1%20%C3%A1') == u'á á'


# Generated at 2022-06-11 14:14:41.532471
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    fm = FilterModule()
    # Testing urldecode filter
    result = fm.filters()['urldecode']('Encoded%20String')

    # Testing urlencode filter
    result = fm.filters()['urlencode']('Decoded String')
    assert result == 'Decoded%20String'

    result = fm.filters()['urlencode']('Decoded String')
    assert result == 'Decoded%20String'

    result = fm.filters()['urlencode']({'param': 'Decoded String'})
    assert result == 'param=Decoded%20String'


# Generated at 2022-06-11 14:14:44.997554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    tm = FilterModule()
    filters = tm.filters()
    assert len(filters) == 2
    assert 'urldecode' in filters
    assert 'urlencode' in filters

# Generated at 2022-06-11 14:14:46.887172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%3F%2B%26') == u' ?+&'



# Generated at 2022-06-11 14:14:56.394252
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E2%82%AC%20') == u'€ '
    assert unicode_urldecode('%E2%82%AC%20') == u'€ '
    assert unicode_urldecode('/var/cache/yum/x86_64/7/base/packages/glibc-2.17-106.el7.x86_64.rpm') == u'/var/cache/yum/x86_64/7/base/packages/glibc-2.17-106.el7.x86_64.rpm'


# Generated at 2022-06-11 14:15:04.201129
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'ab c') == u'ab%20c'
    assert unicode_urlencode(u'ab+c') == u'ab%2Bc'
    assert unicode_urlencode(u'ab/c') == u'ab%2Fc'
    assert unicode_urlencode(u'https://www.example.com:80/foo/?a=b&c=d') == u'https%3A%2F%2Fwww.example.com%3A80%2Ffoo%2F%3Fa%3Db%26c%3Dd'

# Generated at 2022-06-11 14:15:06.751684
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9+%2F+%2B') == u'é / +'



# Generated at 2022-06-11 14:15:17.324509
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('/') == u'/'
    assert unicode_urldecode(';') == u';'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3B') == u';'
    assert unicode_urldecode('%2F;') == u'/;'
    assert unicode_urldecode('%3B%2F') == u';/'
    assert unicode_urldecode(';%2F') == u';/'
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%2F%2F;') == u'//;'

# Generated at 2022-06-11 14:15:21.309809
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E5%8D%81%E5%A4%A7') == u'十大'
    assert unicode_urldecode(u'%2Ffoo%2Fbar') == u'/foo/bar'



# Generated at 2022-06-11 14:15:29.246161
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc xyz') == u'abc%20xyz'
    assert unicode_urlencode(u'abc+xyz') == u'abc%2Bxyz'
    assert unicode_urlencode(u'abc xyz', for_qs=True) == u'abc+xyz'
    assert unicode_urlencode(u'abc+xyz', for_qs=True) == u'abc%2Bxyz'
    assert unicode_urlencode(u'abc/xyz', for_qs=True) == u'abc%2Fxyz'
    assert unicode_urlencode(u'é') == u'%C3%A9'
    assert unicode_urlencode

# Generated at 2022-06-11 14:15:41.040160
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' test various arguments to do_urlencode '''
    string_inputs = {
        u'This is a string': u'This+is+a+string',
        u'This+is+a+string': u'This%2bis%2ba%2bstring',
        u'This=is=a=string': u'This%3Dis%3Da%3Dstring',
        u'This%is%a%string': u'This%25is%25a%25string',
        u"This&is&a&string": u"This%26is%26a%26string",
    }
    for string_input, output in iteritems(string_inputs):
        assert output == do_urlencode(string_input), 'string failed: %s' % string_input


# Generated at 2022-06-11 14:15:48.736113
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'abc%24%5E') == u'abc$^'
    assert unicode_urldecode(b'abc%2B') == u'abc+'
    assert unicode_urldecode(b'abc%20def') == u'abc def'
    assert unicode_urldecode(b'abc%2Fdef') == u'abc/def'
    assert unicode_urldecode(u'abc%20def') == u'abc def'
    assert unicode_urldecode(u'abc%2Fdef') == u'abc/def'
    assert unicode_urldecode(u'abc%20def') == u'abc def'

# Generated at 2022-06-11 14:15:58.089744
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD') == u'\u4f60\u597d'
    assert unicode_urldecode('/%E4%BD%A0%E5%A5%BD/') == u'/\u4f60\u597d/'
    assert unicode_urldecode('%2F%25E4%25BD%25A0%25E5%25A5%25BD%2F') == u'/%E4%BD%A0%E5%A5%BD/'

# Generated at 2022-06-11 14:16:03.489357
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule()
    filters = o.filters()
    assert filters['urldecode']('hello%20world') == 'hello world'
    assert filters['urldecode']('hello+world') == 'hello world'
    assert filters['urldecode']('hello+%F0%9F%98%81') == 'hello 👁'
    assert filters['urldecode']('%F0%9F%98%81') == '👁'

# Generated at 2022-06-11 14:16:13.609901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys

    # Make sure we can find the plugins
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters



# Generated at 2022-06-11 14:16:15.241032
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert hasattr(f, "filters")
    assert hasattr(f.filters(), "__call__")
    assert isinstance(f.filters(), dict)
    assert f.filters()


# Generated at 2022-06-11 14:16:23.921564
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(u'foo+space') == u'foo space'
    if PY3:
        assert unicode_urldecode(b'foo') == u'foo'
        assert unicode_urldecode(b'foo%2Fbar') == u'foo/bar'
        assert unicode_urldecode(b'foo+space') == u'foo space'
    else:
        assert unicode_urldecode(u'foo') == u'foo'
        assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
        assert unicode

# Generated at 2022-06-11 14:16:29.701045
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%3A%3A') == '::'
    assert unicode_urldecode('%C3%B6') == u'ö'
    assert unicode_urldecode('%E2%9C%93') == u'\u2713'


# Generated at 2022-06-11 14:16:36.349544
# Unit test for function do_urlencode
def test_do_urlencode():

    # Test for a string
    test_dictionary = 'this is a test'
    test_result = do_urlencode(test_dictionary)
    assert test_result == 'this%20is%20a%20test'

    # Test for a dictionary
    test_dictionary = {'this': 'that', 'how': 'why', 'true': 'false'}
    test_result = do_urlencode(test_dictionary)
    assert test_result == 'this=that&true=false&how=why'

# Generated at 2022-06-11 14:16:37.889880
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'\xe4'



# Generated at 2022-06-11 14:16:44.657843
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('a@b.c') == 'a%40b.c'
    assert unicode_urlencode('/home') == '%2Fhome'
    assert unicode_urlencode('/home', for_qs=True) == '%2Fhome'
    assert unicode_urlencode('foo?bar') == 'foo%3Fbar'
    assert unicode_urlencode('foo?bar', for_qs=True) == 'foo%3Fbar'
    assert unicode_urlencode({'a@b.c': '@/'}) == 'a%40b.c=%40%2F'
    assert unicode_urlencode([('a@b.c', '@/')]) == 'a%40b.c=%40%2F'
    assert unicode

# Generated at 2022-06-11 14:16:54.247884
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:16:59.326045
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test filters dictionary
    filters = FilterModule().filters()
    assert type(filters) == type({})
    # Test urldecode key
    assert 'urldecode' in filters
    assert callable(filters['urldecode'])
    # Test urlencode key
    if HAS_URLENCODE:
        assert 'urlencode' in filters
    else:
        assert 'urlencode' not in filters


# Generated at 2022-06-11 14:17:09.630170
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # This test won't run as part of the test-unit because it uses a module from the standard library
    import sys
    if '-v' in sys.argv or '--verbose' in sys.argv:
        if PY3:
            base = 'repr'
        else:
            base = 'str'
        f = getattr(__import__('urllib', fromlist=['quote_plus']), 'quote_plus')

# Generated at 2022-06-11 14:17:22.930378
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2Ffoo%2Fbar%2Fbaz") == u"/foo/bar/baz"
    assert unicode_urldecode("foo%20bar%20baz") == u"foo bar baz"
    assert unicode_urldecode("%2f%2F%2ffoo%2F%2Fbar%2F") == u"///foo//bar/"
    assert unicode_urldecode("%2f%2F%2ffoo%2F%2Fbar%2F") == u"///foo//bar/"
    assert unicode_urldecode("%2Ffoo%2Fbar%2Fbaz%2F") == u"/foo/bar/baz/"

# Generated at 2022-06-11 14:17:25.656711
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filts = fm.filters()
    assert 'urldecode' in filts
    if not HAS_URLENCODE:
        assert 'urlencode' in filts


# Generated at 2022-06-11 14:17:28.045162
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    urldecode = do_urldecode('foo+bar')
    assert urldecode == 'foo bar', "urldecode failed: '%s' != 'foo bar'" % urldecode


# Generated at 2022-06-11 14:17:32.444150
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_instance = FilterModule()
    if hasattr(FilterModule_instance, 'filters'):
        if isinstance(FilterModule_instance.filters, types.MethodType):
            assert isinstance(FilterModule_instance.filters(), dict)
        else:
            raise AssertionError("FilterModule.filters is not a method")
    else:
        raise AssertionError("FilterModule has no attribute 'filters'")

# Generated at 2022-06-11 14:17:41.777422
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    # Test with older version of Jinja2
    filter_module.filters()
    assert 'urldecode' in filter_module.filters()
    assert 'urlencode' in filter_module.filters()
    assert callable(filter_module.filters()['urldecode'])
    assert callable(filter_module.filters()['urlencode'])

    # Test with new version of Jinja2
    old_do_urlencode = do_urlencode
    do_urlencode = lambda x: None
    filter_module.filters()
    assert 'urldecode' in filter_module.filters()
    assert 'urlencode' not in filter_module.filters()

# Generated at 2022-06-11 14:17:44.935838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert f.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:17:54.097569
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'

    # Python 2
    if not PY3:
        assert unicode_urlencode(b'abc') == u'abc'
        assert unicode_urlencode(u'áëîøü') == u'%C3%A1%C3%AB%C3%AE%C3%B8%C3%BC'

    # Python 3
    assert unicode_urlencode('abc') == u'abc'
    assert unicode_urlencode(b'abc') == u'abc'
    assert unicode_urlencode('áëîøü') == u'%C3%A1%C3%AB%C3%AE%C3%B8%C3%BC'

# Generated at 2022-06-11 14:18:02.151635
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # See urlencode.py and urldecode.py in ansible/test/units/compat/
    assert unicode_urldecode('a+b') == u'a b'

    # Unicode type
    assert unicode_urldecode(u'%E7%9F%B3%E4%B8%B8+1') == u'石丸 1'

    # Unicode string
    assert unicode_urldecode('%E7%9F%B3%E4%B8%B8+1') == u'石丸 1'

    # Bytes type (Python 3)

# Generated at 2022-06-11 14:18:03.981971
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-11 14:18:06.311881
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E4%B8%96%E7%95%8C") == u"\u4e16\u754c"


# Generated at 2022-06-11 14:18:18.902666
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcd ef') == 'abcd%20ef'
    assert unicode_urlencode('abcd ef', True) == 'abcd+ef'
    assert unicode_urlencode(u'☃') == '%E2%98%83'
    assert unicode_urlencode({'a': 'b'}) == 'a=b'
    assert unicode_urlencode((('a', 'b'), ('c', 'd'))) == 'a=b&c=d'
    assert unicode_urlencode('abcd ef', True) == 'abcd+ef'


# Generated at 2022-06-11 14:18:26.327853
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    
    import pytest
    from ansible.module_utils.compat import unquote
    
    fm = FilterModule()
    fm_filters = fm.filters
    
    def test_urldecode():
        # The default urldecode filter is a wrapper around unquote
        assert fm_filters()['urldecode']('7Q%3D%3D') == unquote('7Q%3D%3D')
        assert fm_filters()['urldecode']('7Q==') == unquote('7Q==')
        
        # The fallback urldecode filter is a wrapper around unquote_

# Generated at 2022-06-11 14:18:35.973574
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%E4%B8%AD%E6%96%87') == u'中文'
    assert FilterModule().filters()['urldecode']('%C3%A4%C3%B6%C3%BC%20%C3%A4%20%C3%B6%20%C3%BC%20%20') == u'äöü ä ö ü  '
    assert FilterModule().filters()['urldecode']('%7Cfoo%7Cbar%7C') == u'|foo|bar|'
    assert FilterModule().filters()['urldecode']('%7efoo%7ebar%7e') == u'~foo~bar~'

# Generated at 2022-06-11 14:18:39.009153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Init class
    f = FilterModule()

    # Inits
    res = ''

    # Test 1
    if False:
        res = f.filters()
        assert res is not None

    # Return
    return

# Generated at 2022-06-11 14:18:45.129246
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(b'%3A') == ':'
        assert unicode_urldecode(u'%3A') == ':'
    else:
        assert unicode_urldecode(b'%3A') == u':'
        assert unicode_urldecode(u'%3A') == u':'
