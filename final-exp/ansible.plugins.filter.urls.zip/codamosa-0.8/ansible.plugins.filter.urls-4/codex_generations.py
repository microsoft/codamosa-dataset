

# Generated at 2022-06-11 14:08:51.298214
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'Je%20suis%20Charlie') == u'Je suis Charlie'
    assert unicode_urldecode('Je%20suis%20Charlie') == u'Je suis Charlie'
    assert unicode_urldecode(u'/a%20b/x%20y/') == u'/a b/x y/'
    assert unicode_urldecode('/a%20b/x%20y/') == u'/a b/x y/'


# Generated at 2022-06-11 14:08:58.594221
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test instance creation with and without parameters
    fm1 = FilterModule()
    assert isinstance(fm1, FilterModule)
    assert hasattr(fm1, 'filters')

    # Test return value of method filters
    f1 = fm1.filters()
    assert isinstance(f1, dict)
    assert 'urldecode' in f1
    if not HAS_URLENCODE:
        assert 'urlencode' in f1



# Generated at 2022-06-11 14:09:01.089742
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2Fthis%2Fis%2Funicode%2F%2F') == '/this/is/unicode//'



# Generated at 2022-06-11 14:09:06.795753
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'\u2713') == u'%E2%9C%93'
    assert unicode_urlencode(u'\u2713', for_qs=True) == u'%E2%9C%93'
    assert unicode_urlencode(u'français') == u'fran%C3%A7ais'
    assert unicode_urlencode(u'français', for_qs=True) == u'fran%C3%A7ais'

# Generated at 2022-06-11 14:09:18.915391
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%ED%95%9C%EA%B8%80') == '한글'
    assert unicode_urldecode('%ED%95%9C%EA%B8%80%EC%9D%80%20%EA%B0%80%EC%A0%9C%EC%9E%90%EC%9D%98%20%EC%B0%BE%ED%84%B0%20%EC%9D%B4%EC%88%9C') == '한글은 가제자의 찾터 이순'

# Generated at 2022-06-11 14:09:20.261126
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    maker = FilterModule()
    assert maker.filters()['urldecode'] == do_urldecode
    assert maker.filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:09:22.102996
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%EC%81%B0") == u"산"


# Generated at 2022-06-11 14:09:27.205372
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo/bar') == 'foo/bar'
    assert unicode_urlencode('foo@bar') == 'foo%40bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('input', for_qs=True) == 'input'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode('foo/bar', for_qs=True) == 'foo%2Fbar'
    assert unic

# Generated at 2022-06-11 14:09:34.987572
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http://www.python.org/dev/peps/pep-0333/#unicode-issues') == 'http://www.python.org/dev/peps/pep-0333/#unicode-issues'
    assert unicode_urldecode('%C3%BC') == '\xfc'
    assert unicode_urldecode('%C3%BC%20') == '\xfc '
    assert unicode_urldecode('%C3%BC%2B') == '\xfc+'
    assert unicode_urldecode('\xfc') == '\xfc'


# Generated at 2022-06-11 14:09:45.101184
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2

    class FilterModule(object):
        ''' Ansible core jinja2 filters '''

        def filters(self):
            return {
                'urldecode': do_urldecode,
            }

    env = jinja2.Environment()
    env.filters.update(FilterModule().filters())

    def assert_urldecode(string):
        assert env.from_string('{{ string | urldecode }}').render(string=string) == unicode_urldecode(string)

    assert_urldecode('a%2Bb%2Bc')
    assert_urldecode('a%2bb%2bc')
    assert_urldecode('a+b+c')

# Generated at 2022-06-11 14:09:56.281423
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("/") == "%2F"
    assert unicode_urlencode("/") == "/"
    assert unicode_urlencode("a/b") == "a%2Fb"
    assert unicode_urlencode("/a/b") == "/a%2Fb"
    assert unicode_urlencode("/a/b") == "%2Fa%2Fb"
    assert unicode_urlencode("a/b") == "a/b"

    assert unicode_urlencode("a/b", for_qs=True) == "a%2Fb"
    assert unicode_urlencode("/a/b", for_qs=True) == "%2Fa%2Fb"
    assert unicode_urlencode("/a/b", for_qs=True)

# Generated at 2022-06-11 14:10:06.072879
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode(u'abc') == 'abc'
        assert unicode_urlencode(u'abc;/?:@&=+$,') == 'abc%3B%2F%3F%3A%40%26%3D%2B%24%2C'
        assert unicode_urlencode(u'abc', for_qs=True) == 'abc'
        assert unicode_urlencode(u'abc;/?:@&=+$', for_qs=True) == 'abc%3B%2F%3F%3A%40%26%3D%2B%24'
    else:
        assert unicode_urlencode(u'abc') == 'abc'

# Generated at 2022-06-11 14:10:14.264600
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Setup:
    import sys
    import re
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    if sys.version_info < (2, 7):
        from ansible.module_utils.six.moves.urllib.parse import quote_plus
    else:
        quote_plus = None

    class FakeModule(object):
        def __init__(self):
            self.ansible_module_name = 'FakeModule'
            self.log = []
            self.logfile = StringIO()
        def fail_json(self, **kwargs):
            self.log.append(kwargs)
            self.logfile.write("FAIL!\n")
            raise SystemExit(1)

# Generated at 2022-06-11 14:10:16.640387
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'å∫ç' == unicode_urldecode('%C3%A5%E2%88%AB%C3%A7')


# Generated at 2022-06-11 14:10:22.174669
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc%5D') == 'abc]'
    assert unicode_urldecode('a%60+bc') == 'a` bc'
    assert unicode_urldecode('%7Ba%60%2Bbc%7D') == u'{a`+bc}'

# Generated at 2022-06-11 14:10:28.790942
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # NOTE: Python3 urllib.parse.unquote_plus automatically handles input that
    # is not a str, to_bytes is unnecessary.
    if PY3:
        assert unicode_urldecode(None) == u''
        assert unicode_urldecode(b'') == u''
        assert unicode_urldecode(u'') == u''
        assert unicode_urldecode({'a': 'b'}) == u''
        assert unicode_urldecode(('a', 'b')) == u''
        assert unicode_urldecode(u'abc') == u'abc'
        assert unicode_urldecode(b'abc') == u'abc'
        assert unicode_urldecode(u'abc%20def') == u'abc def'
       

# Generated at 2022-06-11 14:10:32.835690
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test FilterModule.filters()
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:10:41.205908
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo/bar') == u'foo/bar'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode([u'foo', u'bar']) == u'foo&bar'
    assert do_urlencode([u'foo', u'de=f', u'bar']) == u'foo&de%3Df&bar'
    assert do_urlencode({u'foo': u'bar', u'a': u'b'}) == u'foo=bar&a=b'


# Generated at 2022-06-11 14:10:48.819041
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('/a%20b') == '/a b'
    assert unicode_urldecode('a+b') == 'a b'
    assert unicode_urldecode('a%20b') == 'a b'
    assert unicode_urldecode('%20a%20b') == ' a b'
    assert unicode_urldecode('%20a%20b%20') == ' a b '
    assert unicode_urldecode('a%2520b') == 'a%20b'
    assert unicode_urldecode('a%252520b') == 'a%20b'
    assert unicode_urldecode('a%25252520b') == 'a%20b'


# Generated at 2022-06-11 14:10:49.299276
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    pass

# Generated at 2022-06-11 14:11:00.700873
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%25') == '%'
    assert do_urldecode('one%20two%20three') == 'one two three'

    assert do_urlencode('%') == '%25'
    assert do_urlencode('one two three') == 'one+two+three'
    assert do_urlencode({'one': 'two three'}) == 'one=two+three'
    assert do_urlencode(['one', 'two three']) == 'one&two+three'

    # Test if we get Jinja2's implementation if it exists
    try:
        from jinja2.filters import do_urlencode as jinja2_urlencode
        assert do_urlencode == jinja2_urlencode
    except ImportError:
        pass

# Generated at 2022-06-11 14:11:10.580745
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.unicode import to_unicode
    f = FilterModule().filters()
    # Test for urldecode filter
    urldecode = f.get('urldecode')
    assert urldecode('%20') == ' '
    assert urldecode('%25') == '%'
    assert urldecode('%7e') == '~'
    assert urldecode('%7E') == '~'
    assert urldecode('%7E') == urldecode('~')
    assert urldecode('%2d') == '-'
    assert urldecode('%2D') == '-'
    assert urldecode('%2D') == urldecode('-')

# Generated at 2022-06-11 14:11:17.898233
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abcd') == 'abcd'
    assert do_urlencode(['a', 'b', 'c']) == 'a=b=c'
    assert do_urlencode(['a=b', 'b=c']) == 'a%3Db=b%3Dc'
    assert do_urlencode({'a': 'b', 'b': 'c'}) == 'a=b&b=c'
    assert do_urlencode({'a': 'b=c'}) == 'a=b%3Dc'

# Generated at 2022-06-11 14:11:28.003723
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('~`!@#$%^&*()_-+={[}]|\:;"\'<,>.?/') == '~%60!%40%23%24%25%5E%26*()_-+%3D%7B%5B%7D%5D%7C%5C:%22%27%3C,%3E.%3F/'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'

# Generated at 2022-06-11 14:11:37.661419
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcd') == u'abcd'
    assert unicode_urlencode(u'abcd/efgh') == u'abcd%2Fefgh'
    assert unicode_urlencode(u'abcd/efgh', for_qs=True) == u'abcd%2Fefgh'

    assert unicode_urlencode(u'abcd#efgh') == u'abcd%23efgh'
    assert unicode_urlencode(u'abcd#efgh', for_qs=True) == u'abcd%23efgh'

    assert unicode_urlencode(u'abcd?efgh') == u'abcd%3Fefgh'
    assert unicode_urlencode(u'abcd?efgh', for_qs=True)

# Generated at 2022-06-11 14:11:43.858388
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('dag%20%3Cdag@wieers.com%3E') == u'dag <dag@wieers.com>'
    assert unicode_urldecode('dag+%3Cdag%40wieers.com%3E') == u'dag <dag@wieers.com>'
    assert unicode_urldecode('dag+%3Cdag%40wieers.com%3E') == u'dag <dag@wieers.com>'

# Generated at 2022-06-11 14:11:51.060008
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    tests = (
        # These tests are adapted from cpython Lib/test/test_urllib2.py
        ('%C2%A9', '\xa9'),  # UTF-8 string of length 1
        ('%E2%82%AC', '\u20ac'),  # UTF-8 string of length 3
        ('%C2%A9_%E2%82%AC', '\xa9_\u20ac'),  # UTF-8 string of length 7
        ('%C2%A9_%E2%82%AC_%F0%9D%84%9E', '\xa9_\u20ac_\U0001D11E'),  # UTF-8 string of length 15
    )

    for test in tests:
        assert test[1] == unicode_urldecode(test[0])

# Generated at 2022-06-11 14:11:53.663024
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters

# Generated at 2022-06-11 14:11:57.720522
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F%C3%A9%20%26%20%C3%A8') == u'/é & è'
    assert unicode_urldecode('%2F%E9%20%26%20%E8') == u'/é & è'



# Generated at 2022-06-11 14:12:04.154799
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'asdf') == 'asdf'
    assert unicode_urldecode('%3B%2F%3F%3A%40%26%3D%2B%24%2C%23') == ';/?:@&=+$,#'
    assert unicode_urldecode('%3B%2F%3F%3A%40%26%3D%2B%24%2C%23') == ';/?:@&=+$,#'


# Generated at 2022-06-11 14:12:07.822118
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%2Fbar%2fbaz') == u'foo/bar/baz'



# Generated at 2022-06-11 14:12:10.069126
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'



# Generated at 2022-06-11 14:12:20.299115
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    example = {
        'name': 'Iñigo Montoya',
        'what': 'kill your father',
    }

    assert unicode_urlencode(example) == u'name=I%C3%B1igo%20Montoya&what=kill%20your%20father'
    assert unicode_urlencode(example, for_qs=True) == u'name=I%C3%B1igo%20Montoya&what=kill%20your%20father'
    assert unicode_urlencode(example.values()) == u'I%C3%B1igo%20Montoya&kill%20your%20father'

    assert unicode_urlencode('Iñigo Montoya') == u'I%C3%B1igo%20Montoya'

# Generated at 2022-06-11 14:12:26.906016
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test%C3%A9') == 'testé'
    assert unicode_urldecode(u'test%C3%A9') == u'testé'
    assert unicode_urldecode(b'test%C3%A9') == u'testé'
    assert unicode_urldecode('test%25C3%25A9') == 'test%C3%A9'


# Generated at 2022-06-11 14:12:36.740165
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = '%C3%A4+%C3%B6+%C3%BC+%C3%9F'
    assert unicode_urldecode(string) == u'ä ö ü ß'

# Generated at 2022-06-11 14:12:40.750849
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('köök') == 'k%C3%B6%C3%B6k'
    assert unicode_urlencode('köök', for_qs=True) == 'k%C3%B6%C3%B6k'



# Generated at 2022-06-11 14:12:46.065272
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('a%2Fb') == 'a/b'
        assert unicode_urldecode('a%2F%2Bb') == 'a/+b'
    else:
        assert unicode_urldecode('a%2Fb') == u'a/b'
        assert unicode_urldecode('a%2F%2Bb') == u'a/+b'



# Generated at 2022-06-11 14:12:47.589388
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("Hello+World%21") == u'Hello World!'


# Generated at 2022-06-11 14:12:53.705196
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A5%C3%A6%C3%B8') == u'åæø'
    assert unicode_urldecode('%C3%A5%C3%A6%C3%B8') == u'åæø'
    assert unicode_urldecode('%C3%A5%C3%A6%C3%B8'.encode('utf-8')) == u'åæø'



# Generated at 2022-06-11 14:13:00.406816
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode_string') == u'unicode_string'
    assert unicode_urlencode(u'unicode_string', for_qs=True) == u'unicode_string'
    assert unicode_urlencode(u'áéí') == u'%C3%A1%C3%A9%C3%AD'
    assert unicode_urlencode(u'áéí', for_qs=True) == u'%C3%A1%C3%A9%C3%AD'



# Generated at 2022-06-11 14:13:06.369397
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD%20') == u'你好 '
    assert unicode_urldecode('%2F%2F') == u'//'
    assert unicode_urldecode('%252F') == u'%2F'


# Generated at 2022-06-11 14:13:07.087759
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

# Generated at 2022-06-11 14:13:11.551898
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    assert filters['urldecode']('example%20URL%20encoded%20string%20%C3%A8%C3%A9') == 'example URL encoded string èé'
    assert filters['urlencode']('example URL encoded string èé') == 'example+URL+encoded+string+%C3%A8%C3%A9'

# Generated at 2022-06-11 14:13:15.885765
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_cases = {
        (u'\u2019', ):      u'%E2%80%99',
        (u'\u2019/test', ): u'%E2%80%99%2Ftest'
    }

    for test_case, expected_result in test_cases.items():
        assert unicode_urlencode(*test_case) == expected_result

# Generated at 2022-06-11 14:13:20.067737
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _m = FilterModule()
    _f = _m.filters()
    assert _f['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert _f['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in _f


# Generated at 2022-06-11 14:13:23.179960
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'



# Generated at 2022-06-11 14:13:25.229200
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%2Bdef') == u'abc+def'



# Generated at 2022-06-11 14:13:26.783658
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == 'é'


# Generated at 2022-06-11 14:13:36.960661
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'') == u''
    assert unicode_urldecode('') == u''
    assert unicode_urldecode(u'a') == u'a'
    assert unicode_urldecode('a') == u'a'
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode(u'%') == u'%'
    assert unicode_urldecode('%') == u'%'
    assert unicode_urldecode(u'%a') == u'%a'
    assert unicode_urldecode('%a') == u'%a'

# Generated at 2022-06-11 14:13:41.354098
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'urldecode' in fm.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()
    else:
        assert 'urlencode' not in fm.filters()


# Generated at 2022-06-11 14:13:47.179382
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    fm = FilterModule()
    all_filters = fm.filters()

    assert 'urldecode' in all_filters
    assert all_filters['urldecode'] == do_urldecode
    assert 'urlencode' in all_filters
    assert all_filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:13:56.009242
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_filter_module = FilterModule()
    test_filters = test_filter_module.filters()

    test_string = 'test+string'
    test_urldecode_result = unicode_urldecode(test_string)
    test_urlencode_result = unicode_urlencode(test_string)

    assert test_filters['urldecode'](test_string) == test_urldecode_result
    if not HAS_URLENCODE:
        assert test_filters['urlencode'](test_string) == test_urlencode_result


# Generated at 2022-06-11 14:14:03.055934
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    fm = FilterModule()
    filters = fm.filters()

    # Testing filters for non-dictionary values
    assert filters['urldecode']('a+b') == u'a b'
    assert filters['urldecode']('a%2Bb') == u'a+b'
    assert filters['urldecode']('a b') == u'a b'
    assert filters['urldecode']('%7B%7D') == u'{}'
    if not HAS_URLENCODE:
        assert filters['urlencode']('a b') == u'a+b'
        assert filters['urlencode']('a+b') == u'a%2Bb'
        assert filters['urlencode']('{}') == u'%7B%7D'


# Generated at 2022-06-11 14:14:13.413357
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode(b'%2B') == u'+'
    assert unicode_urldecode(b'-') == u'-'
    assert unicode_urldecode(b'a') == u'a'
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'-') == u'-'
    assert unicode_urldecode(u'a') == u'a'
    assert unicode_urldecode(b'%2B%2B%2B') == u'+++'
    assert unicode_urldecode(u'%2B%2B%2B') == u'+++'


# Generated at 2022-06-11 14:14:22.332717
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%40bar') == u'foo@bar'
    assert unicode_urldecode('foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode('foo%2Fbar%2Fbiz%2Fbaz') == u'foo/bar/biz/baz'
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('foo%2F') == u'foo/'
    assert unicode_urldecode('%2Ffoo') == u'/foo'
    assert unicode_urldecode('%2F') == u'/'


# Generated at 2022-06-11 14:14:24.163328
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20cba') == u'abc cba'



# Generated at 2022-06-11 14:14:32.146662
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    from ansible.module_utils.six import u

    # encode a string
    assert unicode_urlencode(u("test")) == u("test")

    # encode a unicode string
    assert unicode_urlencode(u("žluťoučký kůň")) == u("%C5%BElu%C5%A5ou%C4%8Dk%C3%BD+k%C5%AF%C5%88")

    # encode a unicode string to unicode
    assert isinstance(unicode_urlencode(u("žluťoučký kůň")), u)

    # encode a unicode string to string

# Generated at 2022-06-11 14:14:39.053515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_values = {
        "%2F": "/",
        "a%2Bb": "a+b",
        "a%20b": "a b",
        "a%25b": "a%b",
        "a+b": "a b",
    }

    for input_value, expected_output in iteritems(test_values):
        assert unicode_urldecode(input_value) == expected_output



# Generated at 2022-06-11 14:14:41.078427
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    expected = '%C3%A4%C3%B6%C3%BC%C3%9F'

# Generated at 2022-06-11 14:14:43.742950
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'



# Generated at 2022-06-11 14:14:48.711049
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode']('foo%2Fbar') == 'foo/bar'
    if not HAS_URLENCODE:
        assert filters['urlencode']('foo bar') == 'foo+bar'

# Generated at 2022-06-11 14:14:58.511778
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    sys.path.insert(1, os.path.abspath(os.path.join(__file__, '../../.libs')))
    from ansible_filter_plugins import FilterModule
    import ansible_filter_plugins


# Generated at 2022-06-11 14:14:59.817371
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)



# Generated at 2022-06-11 14:15:01.721275
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert len(fm.filters()) == 2



# Generated at 2022-06-11 14:15:12.300702
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Bunch of random strings
    assert unicode_urldecode('http://foo/?a=1&b=2&c=3') == u'http://foo/?a=1&b=2&c=3'
    assert unicode_urldecode('sdfsdfsdfsdfsdfsdfsdfsdf') == u'sdfsdfsdfsdfsdfsdfsdfsdf'
    assert unicode_urldecode('sdf@#$sdfsdfsdfsdfsdfsdfsdfsdf') == u'sdf@#$sdfsdfsdfsdfsdfsdfsdfsdf'

# Generated at 2022-06-11 14:15:17.285088
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%7B%22key%22%3A%20%22value%22%7D") == u'{"key": "value"}'
    assert unicode_urldecode("%7B%22key%22%3A%20%22value%22%7D") == u'{"key": "value"}'


# Generated at 2022-06-11 14:15:26.232749
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_bytes

    # create an instance of FilterModule
    test_filter_instance = FilterModule()

    # check that the instance has a filters method
    assert hasattr(test_filter_instance, 'filters')

    # check if the filters method returns a dict
    assert isinstance(test_filter_instance.filters(), dict)

    # check that the filters method return a non-empty dict
    assert test_filter_instance.filters()

    # check that the filters method returns a dict as expected

# Generated at 2022-06-11 14:15:32.563985
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("") == ""
    assert unicode_urldecode("%") == "%"
    assert unicode_urldecode("%%") == "%"
    assert unicode_urldecode("%%%25%25") == "%"
    assert unicode_urldecode("%%%25%25%25") == "%"
    assert unicode_urldecode("%2b") == "+"
    assert unicode_urldecode("%2B") == "+"
    assert unicode_urldecode("%3D") == "="
    assert unicode_urldecode("%3d") == "="
    assert unicode_urldecode("%2f") == "/"
    assert unicode_urldecode("%2F") == "/"
    assert unic

# Generated at 2022-06-11 14:15:44.122444
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20') == u'é '
    assert unicode_urldecode('a%2Bb') == u'a+b'
    assert unicode_urldecode('a%2Bb%3Dc') == u'a+b=c'
    assert unicode_urldecode('a%26b') == u'a&b'
    assert unicode_urldecode('a%26b%3Dc') == u'a&b=c'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_ur

# Generated at 2022-06-11 14:15:47.067101
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%28") == u"("
    assert unicode_urldecode("%28%40") == u"(@"
    assert unicode_urldecode("%28%40%29") == u"(@)"


# Generated at 2022-06-11 14:15:59.234694
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    f = FilterModule()
    f.filters()['urldecode']('%20') == ' '
    f.filters()['urldecode']('%2B') == '+'

    tm = TestModule({})
    basic._ANSIBLE_ARGS = to_bytes(None, errors='surrogate_or_strict')
    basic._ANSIBLE_ARGS = to_bytes(StringIO())
    basic._ANSIBLE_ARGS = to_bytes(StringIO('{"ANSIBLE_MODULE_ARGS": {}}'))

# Generated at 2022-06-11 14:16:09.285910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E0%B8%A7%E0%B8%B4%E0%B8%98%E0%B8%B5%E0%B9%80%E0%B8%A5%E0%B9%88%E0%B8%99') == u'วิธีเล่น'

# Generated at 2022-06-11 14:16:15.619420
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    u = unicode_urldecode
    assert u(u'%C3%A9') == 'é'
    assert u('%32%35') == '25'
    assert u('%2B') == '+'
    assert u('%25') == '%'
    # Make sure the function is pure
    assert u(u'%E9') == 'é'
    assert u(u'%E9') == 'é'
    assert u(u'%E9') == 'é'


# Generated at 2022-06-11 14:16:24.144969
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'foo%2fbar' == unicode_urlencode('foo/bar')
    assert 'foo%26bar' == unicode_urlencode('foo&bar')
    assert 'foo%3dbar' == unicode_urlencode('foo=bar')
    assert 'foo%3fbar' == unicode_urlencode('foo?bar')
    assert 'foo%26bar' == unicode_urlencode({'foo': 'bar'})
    assert 'foo%26bar' == unicode_urlencode({'foo': 'bar'}, for_qs=True)
    assert 'foo%3dbaz%26bar%3d' == unicode_urlencode(['foo=baz', 'bar'], for_qs=True)
    assert 'foo%3dbaz%26bar%3d' == unicode

# Generated at 2022-06-11 14:16:26.317214
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']('a+b%2Fc') == 'a b/c'

# Generated at 2022-06-11 14:16:28.837295
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'\u20ac' == unicode_urldecode('%E2%82%AC')


# Generated at 2022-06-11 14:16:30.612425
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters().keys() == {'urlencode', 'urldecode'}


# Generated at 2022-06-11 14:16:40.340171
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import unittest

    class UnicodeUrlEncodeTest(unittest.TestCase):
        def test_unicode_urlencode_string(self):
            self.assertEqual(unicode_urlencode(u""), b"")
            self.assertEqual(unicode_urlencode(u"a"), b"a")

        def test_unicode_urlencode_string_safe(self):
            self.assertEqual(unicode_urlencode(u"/"), b"%2F")
            self.assertEqual(unicode_urlencode(u"/a"), b"%2Fa")

        def test_unicode_urlencode_string_for_qs(self):
            self.assertEqual(unicode_urlencode(u"=&"), b"%3D%26")


# Generated at 2022-06-11 14:16:48.256038
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus
    import pytest

    filtermod = FilterModule()

    f = filtermod.filters()['urldecode']

    assert isinstance(f('foo'), unicode)
    #assert f('foo') == 'foo'
    assert f('foo') == u'foo'

    f = filtermod.filters()['urlencode']

    assert isinstance(f('foo'), unicode)
    #assert f('foo') == 'foo'
    assert f('foo') == u'foo'

# Generated at 2022-06-11 14:16:51.082732
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    foo = FilterModule()
    assert foo.filters()['urldecode']('foo') is not None


# Generated at 2022-06-11 14:16:57.855567
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''

    # Create a instance of FilterModule
    fm = FilterModule()

    assert fm.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }

# Generated at 2022-06-11 14:17:07.956675
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:17:10.070732
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'python/jessie') == 'python%2Fjessie'


# Generated at 2022-06-11 14:17:12.224700
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%B8%96%E7%95%8C') == u'\u4e16\u754c'


# Generated at 2022-06-11 14:17:16.686442
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert {'urldecode': do_urldecode} == filter_module.filters()

    import jinja2
    jinja2.__version__ = "2.7"
    assert {'urldecode': do_urldecode, 'urlencode': do_urlencode} == filter_module.filters()

# Generated at 2022-06-11 14:17:20.267301
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()

    # this will error if the filter name is wrong
    assert filters['urldecode'] == do_urldecode
    # this will error if the filter is missing
    assert filters['uc'] == str.upper

# Generated at 2022-06-11 14:17:25.272274
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()

    assert filters['urldecode']('foo%20bar') == 'foo bar'
    assert filters['urldecode']('foo+bar') == 'foo bar'

    assert filters['urlencode']('foo bar') == 'foo+bar'
    assert filters['urlencode']({'foo': 'bar', 'biz': 'boz'}) == 'foo=bar&biz=boz'


# Generated at 2022-06-11 14:17:27.965636
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule.filters(FilterModule()),dict)
    assert callable(FilterModule.filters(FilterModule()).get('urldecode'))
    assert callable(FilterModule.filters(FilterModule()).get('urlencode'))



# Generated at 2022-06-11 14:17:28.645468
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-11 14:17:33.491319
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('abc123') == u'abc123')
    assert(unicode_urldecode(u'abc123') == u'abc123')

    assert(unicode_urldecode('%20') == u' ')
    assert(unicode_urldecode(u'%20') == u' ')

    assert(unicode_urldecode('%25') == u'%')
    assert(unicode_urldecode(u'%25') == u'%')

    assert(unicode_urldecode('%2525') == u'%25')
    assert(unicode_urldecode(u'%2525') == u'%25')

    assert(unicode_urldecode('%A9') == u'©')

# Generated at 2022-06-11 14:17:41.490880
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode filter
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']('a+b%3Dc') == u'a b=c'

    # Test urlencode filter
    filters2 = fm.filters()
    assert filters2['urlencode']('a b=c') == u'a+b%3Dc'

# Generated at 2022-06-11 14:17:51.417408
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_string_1 = u'Привет мир! №%&@№%&@№%&@'
    test_string_2 = u'!%&@№^&%^№%&@$%^&*%№^&'
    test_string_3 = u'%^&*()_+{}:|?><~`\';[]\./,\\'


# Generated at 2022-06-11 14:17:53.625314
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:18:01.839017
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Just for codec
    import codecs
    codecs.register(lambda name: codecs.lookup('utf8') if name == 'cp65001' else None)

    #
    # Test string - utf8 encoded
    #
    string = '%E5%A4%A9%E6%B0%94'
    assert unicode_urldecode(string) == '天气'

    #
    # Test string - cp6701 encoded
    #
    string = '%E5%A4%A9%E6%B0%94'
    assert unicode_urldecode(string) == '天气'

    #
    # Test dictionary - utf8 encoded
    #
    dict1 = {'天气': '晴天'}
    dict2 = unicode_ur

# Generated at 2022-06-11 14:18:10.915905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text

    x = FilterModule()
    filters = x.filters()
    assert isinstance(filters, Mapping)
    for name, func in iteritems(filters):
        assert callable(func)
    for enc_func in (do_urldecode, do_urlencode):
        assert isinstance(enc_func(''), to_text)
        assert isinstance(enc_func('a'), to_text)
        assert enc_func(u'\u03B1') == u'%CE%B1'
        assert enc_func(u'\u03B1', True) == u'%CE%B1'

# Generated at 2022-06-11 14:18:12.612739
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'


# Generated at 2022-06-11 14:18:16.191041
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters

# Generated at 2022-06-11 14:18:24.841757
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc%2B') == 'abc+'
    assert unicode_urldecode('abc%2F') == 'abc/'
    assert unicode_urldecode('abc%2F%2B') == 'abc/+'
    assert unicode_urldecode('abc%2F%2B%3D%2F') == 'abc/+=/'
    assert unicode_urldecode('abc%2F%2B%3D') == 'abc/+='
    assert unicode_urldecode('abc%2F%2B%3D%2F%2B%3D') == 'abc/+=/+='

# Generated at 2022-06-11 14:18:29.831408
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'märken') == u'märken'
    assert unicode_urldecode(u'm%C3%A4rken') == u'märken'
    assert unicode_urldecode(u'm%C3%A4rken') == u'märken'


# Generated at 2022-06-11 14:18:37.362436
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%27Stop%21%27%20said%20Fred') == u'\'Stop!\' said Fred'
    assert unicode_urldecode('%27Stop!%27%20said%20Fred') == u'\'Stop!\' said Fred'
    assert unicode_urldecode('%20%20%20%20%20%20%20%20%20%20') == u'                '
    assert unicode_urldecode('%0a%0d%0a%0d%0a%0d') == u'\n\r\n\r\n\r'
    assert unicode_urldecode('%C3%A9%C3%BA') == u'éú'
