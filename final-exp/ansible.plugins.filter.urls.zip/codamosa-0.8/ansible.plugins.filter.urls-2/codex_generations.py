

# Generated at 2022-06-11 14:08:49.805320
# Unit test for function do_urlencode
def test_do_urlencode():
    string = u"test,1"
    assert do_urlencode(string) == u"test%2C1"
    urle = u"test%2C1"
    assert do_urldecode(urle) == string


# Generated at 2022-06-11 14:08:53.093010
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    assert fm.filters()['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:09:01.280715
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("/home/user/") == "%2Fhome%2Fuser%2F"
    assert unicode_urlencode("/home/user/?foo=bar") == "%2Fhome%2Fuser%2F%3Ffoo%3Dbar"
    assert unicode_urlencode("/home/user/") == "%2Fhome%2Fuser%2F"
    assert unicode_urlencode("/home/user/?foo=bar") == "%2Fhome%2Fuser%2F%3Ffoo%3Dbar"



# Generated at 2022-06-11 14:09:08.679706
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%34') == u'$'
    assert unicode_urldecode('%6E') == u'n'
    assert unicode_urldecode('%78') == u'x'
    assert unicode_urldecode('%8B') == u'#'
    assert unicode_urldecode('%99') == u'#'
    assert unicode_urldecode('%D2%80') == u'#'
    assert unicode_urldecode('%D8%B0') == u'#'
    assert unicode_urldecode('%E2%82%AC') == u'#'
    assert unicode_urldecode('%F0%9D%92%A1') == u'#'


# Generated at 2022-06-11 14:09:17.585792
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Testing+%C3%A1%C3%AB%C3%AF%C3%B3') == u'Testing áëïó'
    assert unicode_urldecode('Testing%20%C3%A1%C3%AB%C3%AF%C3%B3') == u'Testing áëïó'
    assert unicode_urldecode('Testing') == u'Testing'
    assert unicode_urldecode('Testing%2B%2B%2B') == u'Testing+++'


# Generated at 2022-06-11 14:09:27.297485
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo+bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%2Fbar') == 'foo/bar'

    assert unicode_urldecode(u'foo') == 'foo'
    assert unicode_urldecode(u'foo+bar') == 'foo bar'
    assert unicode_urldecode(u'foo%20bar') == 'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == 'foo/bar'


# Generated at 2022-06-11 14:09:30.482718
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7E%21%40%23%24%25%5E%26*()_%2B%2C-.%2F') == u'~!@#$%^&*()_+,-./'



# Generated at 2022-06-11 14:09:31.426250
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 1 == 1

# Generated at 2022-06-11 14:09:39.463283
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # urldecode using the builtin from urllib
    from urllib import urlencode
    decoded = urlencode({'name': 'Dag Wieërs'})
    encoded = unicode_urldecode(decoded)
    assert encoded == {'name': 'Dag Wieërs'}

    # urldecode using the custom implementation
    decoded = 'name=Dag+Wie%C3%ABrs'
    encoded = unicode_urldecode(decoded)
    assert encoded == {'name': 'Dag Wieërs'}

# Generated at 2022-06-11 14:09:47.977981
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(b'%25') == u'%'
    assert unicode_urldecode(u'%3A') == u':'
    assert unicode_urldecode(b'%3A') == u':'
    assert unicode_urldecode(u'%25%3A') == u'%:%'
    assert unicode_urldecode(b'%25%3A') == u'%:%'
    assert unicode_urldecode(u'%25:%3A') == u'%::'
    assert unicode_urldecode(b'%25:%3A') == u'%::'

# Generated at 2022-06-11 14:09:55.161276
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test urldecode filter
    assert do_urldecode('%C3%86') == u'Æ'
    assert do_urldecode('%C3%A6') == u'æ'

    # Test urlencode filter
    assert do_urlencode(u'Æ') == '%C3%86'
    assert do_urlencode(u'æ') == '%C3%A6'

# Generated at 2022-06-11 14:10:05.183983
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('s%C3%A9rieux') == u'sérieux'
    assert unicode_urldecode(b's%C3%A9rieux') == u'sérieux'
    assert unicode_urldecode(u's%C3%A9rieux') == u'sérieux'
    assert unicode_urldecode(u's%25C3%25A9rieux') == u's%C3%A9rieux'
    assert unicode_urldecode(u's%25c%25a%25r%25i%25e%25u%25x') == u's%c%a%r%i%e%u%x'
    assert unicode_urldecode('%%') == u'%'
    assert unicode_ur

# Generated at 2022-06-11 14:10:10.885226
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode('%E2%9C%93') == u'✓'
    assert unicode_urldecode(u'%E2%9C%93') == u'✓'


# Generated at 2022-06-11 14:10:19.761279
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('/%20') == u'/ '
    assert unicode_urldecode('/%25%20') == u'/%20'
    assert unicode_urldecode('/%2f%2F') == u'//'
    assert unicode_urldecode('/%20%7c%20') == u'/ | '
    assert unicode_urldecode('/%3F%3D%3A%2C') == u'/?=:,'
    assert unicode_urldecode('/%3f%3D%3a%2C') == u'/?=:,'
    assert unicode_urldecode('/%2B') == u'/+'
    assert unicode_urldecode('/%25') == u'/%'
    assert unic

# Generated at 2022-06-11 14:10:23.616250
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Ensure that the do_unquote_plus method returns the correct value
    """
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']('%21') == u'!'

# Generated at 2022-06-11 14:10:26.018617
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    out = basic.AnsibleModule(argument_spec={}).run_command('echo "unittest_FilterModule_filters"')
    assert out[0] == 0



# Generated at 2022-06-11 14:10:30.314746
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('dag%40wieers.com') == u'dag@wieers.com'
    assert unicode_urldecode('%2Ftmp%2F%26') == u'/tmp/&'


# Generated at 2022-06-11 14:10:37.015219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Initialize a FilterModule object
    filter_module = FilterModule()

    # Get the dictionary
    dictionary = filter_module.filters()

    # Make sure type is a dictionary
    assert type(dictionary) is dict

    # Make sure the dictionary is not empty
    assert len(dictionary) > 0

    # Make sure the dictionary has key 'urldecode'
    assert 'urldecode' in dictionary

    # Make sure the dictionary has key 'urlencode'
    # This key is not available when Jinja2 is older than v2.7
    assert 'urlencode' in dictionary or not HAS_URLENCODE

    # Make sure the dictionary does not have some other keys
    assert 'urlencode2' not in dictionary
    assert 'urldecode2' not in dictionary


# Generated at 2022-06-11 14:10:43.352820
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing function unicode_urldecode")
    assert unicode_urldecode('%E5%A4%A9') == u'\u5929'  # Chinese for 'sky'
    assert unicode_urldecode(u'\u5929') == u'\u5929'
    assert unicode_urldecode(b'%E5%A4%A9') == u'\u5929'


# Generated at 2022-06-11 14:10:45.656264
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://www.example.org/foo/bar baz') == u'http%3A//www.example.org/foo/bar+baz'

# Generated at 2022-06-11 14:10:50.221887
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('%5e%2b%5e%26%3d%2b') == '^+^&=+'

# Generated at 2022-06-11 14:11:00.042780
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a') == u'a'
    assert unicode_urlencode(u'a b') == u'a%20b'
    assert unicode_urlencode(u'a+b') == u'a+b'
    assert unicode_urlencode(u'a b', for_qs=True) == u'a+b'
    assert unicode_urlencode(u'a/b') == u'a/b'
    assert unicode_urlencode(u'a/b', for_qs=True) == u'a%2Fb'
    assert unicode_urlencode(u'a=') == u'a%3D'
    assert unicode_urlencode(u'a=', for_qs=True) == u'a%3D'


# Generated at 2022-06-11 14:11:06.253827
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%20%C3%BC%20%C3%B6') == '\xc3\xa4 \xc3\xbc \xc3\xb6'
    assert unicode_urldecode('%C3%A4%20%C3%BC%20%C3%B6') == u'\xc3\xa4 \xc3\xbc \xc3\xb6'

# Generated at 2022-06-11 14:11:15.974067
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import json

    def assert_equal_utf8(s1, s2):
        assert s1 == s2, '%r != %r' % (s1, s2)
        assert type(s1) is type(s2), '%r -> %r, %r -> %r' % (type(s1), s1, type(s2), s2)
        assert json.dumps(s1).decode('utf-8') == json.dumps(s2).decode('utf-8')

    assert_equal_utf8(unicode_urlencode(u'abc'), u'abc')
    assert_equal_utf8(unicode_urlencode(u'a b\tc'), u'a+b%09c')

# Generated at 2022-06-11 14:11:18.077892
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmod = FilterModule()
    assert fmod.filters() == {'urldecode': do_urldecode}



# Generated at 2022-06-11 14:11:23.759860
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with input as a string
    string = "http://localhost/test?query=this&value=that%20more"

    # Test the 'urldecode' filter
    assert FilterModule().filters()['urldecode'](string) == string

    # Test the 'urlencode' filter only if jinja2 is older than v2.7
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode'](string) == string



# Generated at 2022-06-11 14:11:28.340021
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    a = '%E6%97%A5%E6%9C%AC%E8%AA%9E'
    b = to_text(do_urldecode(a))
    c = '日本語'
    assert b == c

# Generated at 2022-06-11 14:11:37.955527
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode']('name1=value1') == u'name1=value1'
    assert filters['urldecode']('name1=value1&name2=value2') == u'name1=value1name2=value2'
    if not HAS_URLENCODE:
        assert filters['urlencode'](u'name1=value1') == 'name1%3Dvalue1'
        assert filters['urlencode'](u'name1=value1&name2=value2') == 'name1%3Dvalue1name2%3Dvalue2'
        assert filters['urlencode']({u'name1': u'value1'}) == 'name1=value1'

# Generated at 2022-06-11 14:11:41.852698
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.org/') == u'http%3A//example.org/'
    assert unicode_urlencode(u'http://example.org/', for_qs=True) == u'http%3A%2F%2Fexample.org%2F'

# Generated at 2022-06-11 14:11:48.493002
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert filters['urldecode'](u'%F0%9F%87%BA%F0%9F%87%B8') == u'🇺🇸'
    assert filters['urldecode'](u'%5C%27') == u'"\\\'"'
    assert filters['urldecode'](u'%5C%27%26') == u'"\\\'&"'
    filters['urldecode'](u'%F0%9F%87%BA%F0%9F%87%B8') == u'🇺🇸'
    filters['urldecode'](u'%5C%27') == u'"\\\'"'

# Generated at 2022-06-11 14:11:54.142161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode'].__name__ == 'do_urldecode'

# Generated at 2022-06-11 14:12:03.621650
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Parameter is a string
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%21') == u'foo!'
    assert unicode_urldecode('foo%23') == u'foo#'
    assert unicode_urldecode('foo%25bar') == u'foo%bar'
    assert unicode_urldecode('foo%3B') == u'foo;'
    assert unicode_urldecode('foo%7B') == u'foo{'

    # Parameter is an unicode string
    assert unicode_urldecode('foo') == u'foo'

# Generated at 2022-06-11 14:12:05.770400
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%40') == u'@'


# Generated at 2022-06-11 14:12:07.456661
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'urldecode': do_urldecode}



# Generated at 2022-06-11 14:12:12.573949
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('A&B') == 'A%26B'
    assert do_urlencode(['A', 'B']) == 'A&B'
    assert do_urlencode({'A': 'One', 'B': 'Two'}) == 'A=One&B=Two'

# Generated at 2022-06-11 14:12:21.869722
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.compat.tests.mock import patch

    with patch('ansible.module_utils.six.PY3', True):
        assert unicode_urlencode(u'http://www.example.com/path/to/file?foo=bar') == 'http%3A%2F%2Fwww.example.com%2Fpath%2Fto%2Ffile%3Ffoo%3Dbar'
        assert unicode_urlencode(b'http://www.example.com/path/to/file?foo=bar') == 'http%3A%2F%2Fwww.example.com%2Fpath%2Fto%2Ffile%3Ffoo%3Dbar'

    with patch('ansible.module_utils.six.PY3', False):
        assert unicode_urlencode

# Generated at 2022-06-11 14:12:25.284815
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b%20c') == 'a b c'
    assert unicode_urldecode('a+b+c') == 'a b c'


# Generated at 2022-06-11 14:12:30.986326
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    f = FilterModule()
    for k, v in iteritems(f.filters()):
        if k == 'urldecode':
            assert (v('a%2Bb') == 'a+b')
        elif k == 'urlencode':
            assert (v('a+b') == 'a%2Bb')

# Generated at 2022-06-11 14:12:34.042437
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%C3%A1%C3%A9%C3%AD%C3%B3%C3%BA%C3%BC') == u'áéíóúü'

# Generated at 2022-06-11 14:12:35.825141
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://foo/bar') == 'http%3A//foo/bar'


# Generated at 2022-06-11 14:12:48.479276
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    res = unicode_urldecode('http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar')
    assert res == 'http://example.com/?foo=bar'
    res = unicode_urldecode('http%3a%2f%2fexample.com%2f%3ffoo%3dbar')
    assert res == 'http://example.com/?foo=bar'
    res = unicode_urldecode('http://example.com/%3Ffoo=bar')
    assert res == 'http://example.com/?foo=bar'
    res = unicode_urldecode(u'http://example.com/%3Ffoo=bar')
    assert res == u'http://example.com/?foo=bar'


# Generated at 2022-06-11 14:12:52.663292
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcABC', True) == u'abcABC'
    assert unicode_urlencode(u'abc ABC', True) == u'abc+ABC'
    assert unicode_urlencode(u'abc ABC', False) == u'abc%20ABC'

# Generated at 2022-06-11 14:13:01.727792
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from jinja2 import DictLoader, Environment
    # create a new FilterModule() object
    ans = FilterModule()
    # generate jinja env that uses our filters
    env = Environment(loader=DictLoader({'foo': 'bar'}), extensions=['jinja2.ext.do'], trim_blocks=True, lstrip_blocks=True)
    env.filters.update(ans.filters())
    # test urldecode() filter
    t = env.from_string('{{ "http%3A%2F%2Ffoo.com%2Fbar%3Fq%3D1%26t%3D2" | urldecode }}')
    assert t.render() == u'http://foo.com/bar?q=1&t=2'

# Generated at 2022-06-11 14:13:04.310949
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        unicode_urldecode("I am a string")
    except Exception as e:
        print("Failed with error: {0}".format(e))


# Generated at 2022-06-11 14:13:08.326416
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9%20') == u'é '
    assert unicode_urldecode('%20%C3%A9') == u' é'
    assert unicode_urldecode('%20%C3%A9%20') == u' é '

# Generated at 2022-06-11 14:13:17.099040
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abcABC123') == u'abcABC123'
    assert unicode_urlencode('abcABC123') == u'abcABC123'
    assert unicode_urlencode('αβγΑΒΓ123') == u'%CE%B1%CE%B2%CE%B3%CE%91%CE%92%CE%93123'
    assert unicode_urlencode('abcABC123', for_qs=True) == u'abcABC123'
    assert unicode_urlencode('abcABC123', for_qs=True) == u'abcABC123'

# Generated at 2022-06-11 14:13:24.857531
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_strings = [
        u'',
        u'abc',
        u'ab cd',
        u'ab+cd',
        u'ab%2Bcd',
        u'ab%2bcd',
        u'ab+++cd',
        u'ab+++cd',
        u'ab+++cd',
        u'ab+++cd',
        u'ab+++cd',
        u'ab+++cd',
    ]

# Generated at 2022-06-11 14:13:28.600579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import jinja2_filters
    # Check that urlencode is available when Jinja2 is older than v2.7
    data = jinja2_filters.FilterModule().filters()
    assert "urlencode" in data

# Generated at 2022-06-11 14:13:30.958742
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()
    assert fm.filters()['urldecode'] is do_urldecode


# Generated at 2022-06-11 14:13:33.520998
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("http%3A%2F%2Fwww.example.com") == 'http://www.example.com'



# Generated at 2022-06-11 14:13:40.578793
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'I%20have40%25%20of%20it%20for%20you') == u'I have40% of it for you'



# Generated at 2022-06-11 14:13:47.380498
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('string') == 'string'
    assert unicode_urlencode('param with whitespace') == 'param%20with%20whitespace'
    assert unicode_urlencode('/param with whitespace') == '%2Fparam%20with%20whitespace'
    assert unicode_urlencode('param with whitespace/') == 'param%20with%20whitespace%2F'
    assert unicode_urlencode('/param with whitespace/') == '%2Fparam%20with%20whitespace%2F'
    assert unicode_urlencode('param/with/slashes') == 'param%2Fwith%2Fslashes'

# Generated at 2022-06-11 14:13:58.426518
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    fm = FilterModule()
    assert fm is not None
    assert fm.filters() is not None
    urlencode = fm.filters()['urlencode']
    assert urlencode is not None

    assert urlencode('hello world') == 'hello%20world'
    assert urlencode('hello world %') == 'hello%20world%20%25'
    assert urlencode('hello world ') == 'hello%20world%20'
    assert urlencode('hello world &') == 'hello%20world%20&'
    assert urlencode('hello world /') == 'hello%20world%20/'
    assert urlencode('hello world ?') == 'hello%20world%20?'

    assert urlencode('foo bar') == 'foo%20bar'

# Generated at 2022-06-11 14:14:01.389217
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%C3%A4%C3%B6%C3%BC%C3%9F%E2%82%AC") == u"äöüß€"


# Generated at 2022-06-11 14:14:04.552235
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'%A3%B3%E1%C0' == unicode_urlencode(u'£óáà')



# Generated at 2022-06-11 14:14:09.733195
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    print(unicode_urlencode(u'Dörp'))
    print(unicode_urlencode(u'Dörp', for_qs=True))
    print(unicode_urlencode(u'Dörp&'))
    print(unicode_urlencode(u'Dörp&', for_qs=True))


# Generated at 2022-06-11 14:14:17.663967
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('This%20is%20a%20test') == u'This is a test'
    assert unicode_urldecode('This%2Bis%2Ba%2Btest') == u'This+is+a+test'
    assert unicode_urldecode('This+is+a+test') == u'This is a test'
    assert unicode_urldecode('This+is+a+test%3F') == u'This is a test%3F'
    assert unicode_urldecode('This+is+a+test%3f') == u'This is a test%3f'
    assert unicode_urldecode('%40') == u'@'
    assert unicode_urldecode('%23') == u'#'
    assert unic

# Generated at 2022-06-11 14:14:23.465778
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule. '''

    from ansible.module_utils.common.text.filter_plugins.core import FilterModule

    print("Show FilterModule.filters() ...")

    filterModule = FilterModule()

    print("Show FilterModule.filters(): %s" % str(filterModule.filters()))


# Generated at 2022-06-11 14:14:31.854170
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import collections

    # Test strings
    assert unicode_urlencode('Hello World!') == 'Hello%20World%21'
    assert unicode_urlencode('Hello World!', for_qs=True) == 'Hello+World%21'

    # Test tuples
    assert unicode_urlencode(('Hello World!',)) == 'Hello%20World%21'

    # Test lists
    assert unicode_urlencode(['Hello World!']) == 'Hello%20World%21'

    # Test dicts
    assert unicode_urlencode({'key': 'Hello World!'}) == 'key=Hello%20World%21'

# Generated at 2022-06-11 14:14:42.170985
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils import basic
    import sys

    dummy_module = basic.AnsibleModule(argument_spec = dict())
    if do_urlencode.__doc__ != basic.urlencode.__doc__:
        dummy_module.fail_json(
            msg='Incorrect documentation for urlencode filter. ' +
                'Output: "%s" Expected: "%s"' % (do_urlencode.__doc__,
                                                  basic.urlencode.__doc__))


# Generated at 2022-06-11 14:14:50.143080
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm is not None
    assert type(fm.filters) == type(fm)
    assert fm.filters is not None
    assert fm.filters.__class__ is fm.__class__
    assert fm.filters.filters == fm.filters


# Generated at 2022-06-11 14:14:57.412474
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%C3%A9%20%E2%80%A6%3F%26%3D%3D%3F%2F') == 'aé …?&==?/'
    assert unicode_urldecode('a%C3%A9%20%E2%80%A6%3F%26%3D%3D%3F%2F') == to_text(b'a\xc3\xa9 \xe2\x80\xa6?&==?/')



# Generated at 2022-06-11 14:15:04.693437
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import uuid
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode

    data = {
        'a': uuid.uuid4().hex,
        'b': uuid.uuid4().hex,
        'c': uuid.uuid4().hex,
    }

    # do_urldecode
    for k, v in iteritems(data):
        assert do_urldecode(unicode_urlencode(data[k])) == data[k]

    # do_urlencode
    assert do_urlencode

# Generated at 2022-06-11 14:15:07.247526
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'\u20ac4.99' == unicode_urldecode('%E2%82%AC4.99')

# Generated at 2022-06-11 14:15:10.534558
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%21') == u'!'
    assert unicode_urldecode(u'%21') == u'!'



# Generated at 2022-06-11 14:15:14.783769
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あいうえお'
    assert unicode_urldecode('abc+def') == u'abc def'


# Generated at 2022-06-11 14:15:18.179093
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%7e') == u'~'
    assert unicode_urldecode('%25') == u'%'


# Generated at 2022-06-11 14:15:20.899691
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urlencode'] == do_urlencode
    assert filters['urldecode'] == do_urldecode



# Generated at 2022-06-11 14:15:23.512720
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create FilterModule object
    fm = FilterModule()
    # Call function and test return value
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-11 14:15:30.870783
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("test") == "test"
    assert do_urlencode("test+test") == "test%2Btest"
    assert do_urlencode("Test+TEST") == "Test%2BTEST"
    assert do_urlencode("test+test") == "test%2Btest"
    assert do_urlencode("test&test") == "test%26test"
    assert do_urlencode("test/test") == "test%2Ftest"
    assert do_urlencode("test?test") == "test%3Ftest"
    assert do_urlencode("test%test") == "test%25test"
    assert do_urlencode(["test", "test"]) == "test&test"

# Generated at 2022-06-11 14:15:46.110599
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus


# Generated at 2022-06-11 14:15:48.148034
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  filters = FilterModule().filters()
  assert filters['urldecode'] == do_urldecode

# Generated at 2022-06-11 14:15:51.059705
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("abc%2Bxyz") == u"abc+xyz"
    assert unicode_urldecode("abc%2Bxyz%7C123") == u"abc+xyz|123"


# Generated at 2022-06-11 14:15:55.625289
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    if PY3:
        assert do_urldecode('%3D') == '='
        if not HAS_URLENCODE:
            assert do_urlencode('') == ''
    else:
        assert do_urldecode('%3D') == u'='
        if not HAS_URLENCODE:
            assert do_urlencode(u'') == u''

# Generated at 2022-06-11 14:15:58.128319
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'urldecode' in module.filters()
    if not HAS_URLENCODE:
        assert 'urlencode' in module.filters()

# Generated at 2022-06-11 14:16:00.898418
# Unit test for function do_urlencode
def test_do_urlencode():
    test_dict = {
        'key1': 'val1',
        'key2': 'val2'
    }
    assert(do_urlencode(test_dict) ==
           'key1=val1&key2=val2')

# Generated at 2022-06-11 14:16:04.212335
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.plugins.loader import filters_loader

    filtermod = filters_loader.get('FilterModule')
    assert isinstance(filtermod, FilterModule)
    assert 'urldecode' in filtermod.filters()



# Generated at 2022-06-11 14:16:14.380238
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    import unittest

    from ansible.module_utils._text import to_bytes, to_text

    class TestFilterModule(unittest.TestCase):

        def setUp(self):
            self.fm = FilterModule()
            self.maxDiff = None

        def test_urldecode(self):
            cases = (
                # Test inputs and their expected outputs
                (b'f%C3%B6%C3%B6+bar%3D+baz', u'f\xf6\xf6 bar= baz'),
                (b'f%C3%B6%C3%B6+bar%3D+baz%25&123=456', u'f\xf6\xf6 bar= baz%&123=456'),
            )

# Generated at 2022-06-11 14:16:18.203716
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode
    assert FilterModule().filters()['urlencode'] == do_urlencode


# Unit tests for method unicode_urldecode of class FilterModule

# Generated at 2022-06-11 14:16:25.714616
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    for data in [
            ('a+b=c', u'a b=c'),
            ('a%20b%3Dc', u'a b=c'),
            ('a+b=c', u'a b=c'),
            ('a%20b%3Dc', u'a b=c'),
            ('foo%2Fbar', u'foo/bar'),
            ('foo%2fbar', u'foo/bar'),
            ('foo%2Fbar', u'foo/bar'),
            ('foo%2fbar', u'foo/bar'),
            (u'foo/bar', u'foo/bar'),
    ]:
        assert unicode_urldecode(data[0]) == unquote_plus

# Generated at 2022-06-11 14:16:32.387395
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode(u'a%2Bb%2Bc') == u'a+b+c'
    assert do_urlencode(u'a b') == u'a+b'

# Generated at 2022-06-11 14:16:41.591239
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("/") == "%2F"
    assert do_urlencode("?") == "%3F"
    assert do_urlencode("&") == "&"
    assert do_urlencode("&?") == "&%3F"
    assert do_urlencode("foo bar baz") == "foo+bar+baz"
    assert do_urlencode("foo?bar baz") == "foo%3Fbar+baz"
    assert do_urlencode("foo&bar baz") == "foo&bar+baz"

    assert do_urlencode("/?") == "%2F%3F"
    assert do_urlencode("?/") == "%3F%2F"

# Generated at 2022-06-11 14:16:50.908884
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_string1_good = u'https%3A%2F%2Fwww.google.com%2F'
    assert unicode_urldecode(test_string1_good) == u'https://www.google.com/'
    test_string2_good = u'https%3A%2F%2Fwww.google.com%2F%7C'
    assert unicode_urldecode(test_string2_good) == u'https://www.google.com/|'
    test_string3_good = u'https%3A%2F%2Fwww.google.com%2F%7C%7C'
    assert unicode_urldecode(test_string3_good) == u'https://www.google.com/||'
    # test_string4_bad

# Generated at 2022-06-11 14:16:57.294357
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%40%5B%5D') == '!#$&\'()*+,;=@[]'
    assert unicode_urldecode(u'%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%40%5B%5D') == u'!#$&\'()*+,;=@[]'
    assert unicode_urldecode(b'%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%40%5B%5D') == u'!#$&\'()*+,;=@[]'
    assert isinstance

# Generated at 2022-06-11 14:16:59.856329
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    assert unicode_urldecode('%20') == unquote_plus('%20')



# Generated at 2022-06-11 14:17:05.869209
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = u'myquote=%27true%27'
    ref = u"myquote='true'"
    assert do_urldecode(data) == ref
    assert do_urlencode(ref) == data

    data = {'a': 'b', 'c': 'd'}
    ref = u'a=b&c=d'
    assert do_urlencode(data) == ref

# Generated at 2022-06-11 14:17:12.538448
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    r = unicode_urldecode("%2F%2F%2F")
    assert r == u"///"
    r = unicode_urldecode("%2F%2F%2F%2F")
    assert r == u"////"
    r = unicode_urldecode("%2F%2F%2F%2F%2F")
    assert r == u"/////"
    r = unicode_urldecode("%2F%2F%2F%2F%2F%2F")
    assert r == u"//////"



# Generated at 2022-06-11 14:17:18.492550
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    # Given the following string
    string = u'foo+bar%2Bbaz'

    # When decoded using the function unicode_urldecode
    result = unicode_urldecode(string)

    # Then it should match the original
    assert result == urlencode({u'foo bar+baz': ''}, doseq=True)[:-1]



# Generated at 2022-06-11 14:17:26.558127
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Parameter is unicode string and is encoded to utf-8
    assert unicode_urlencode(u'test') == 'test'
    assert unicode_urlencode(u'test/ä') == 'test%2F%C3%A4'
    # Parameter is unicode string and is encoded to latin-1
    assert unicode_urlencode(u'test', False, 'latin-1') == 'test'
    assert unicode_urlencode(u'test/ä', False, 'latin-1') == 'test%2F%E4'
    # Parameter is unicode string and code is utf-8
    assert unicode_urlencode('test') == 'test'

# Generated at 2022-06-11 14:17:34.671414
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode(u"François+Pépin") == u"François Pépin"
    assert unicode_urldecode("Fran%C3%A7ois+P%C3%A9pin") == u"François Pépin"
    assert unicode_urldecode("Fran%C3%A7ois+P%C3%A9pin") == "François Pépin"
    assert unicode_urldecode("Fran%C3%A7ois+P%C3%A9pin", raw_unicode=True) == "François Pépin"
    assert unicode_urldecode("Fran%C3%A7ois+P%C3%A9pin", raw_unicode=False) == u"François Pépin"

# Generated at 2022-06-11 14:17:43.717431
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    from ansible.module_utils import basic

    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']('abc%20def') == 'abc def'
    if not HAS_URLENCODE:
        assert filters['urlencode']('abc def') == 'abc%20def'
        assert filters['urlencode']('abc def') == 'abc%20def'
        assert filters['urlencode']('abc def') == 'abc%20def'
        assert filters['urlencode']('abc def') == 'abc%20def'



# Generated at 2022-06-11 14:17:53.204554
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    # Do not modify/remove this
    # Unit test for urldecode
    assert fm.filters()['urldecode']('%21') == '!'
    assert fm.filters()['urldecode']('%2A%2F%3F%26%3D%3B%2B') == '*/?&=;+'
    # Do not modify/remove this
    # Unit test for urlencode
    assert fm.filters()['urlencode'](' ') == '+'
    assert fm.filters()['urlencode']('%') == '%25'
    assert fm.filters()['urlencode']('&') == '%26'

# Generated at 2022-06-11 14:18:01.678465
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import tempfile

    from ansible.errors import AnsibleFilterError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # Obtain temporary filename for tests
    fd, tmp_path = tempfile.mkstemp()
    os.close(fd)

    # Creating instance of FilterModule
    f = FilterModule()

    # Creating instance of JinjaEnvironment to access Ansible jinja filters
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    j2_env = Templar(loader=loader, variables=variable_manager)

    # Testing urld

# Generated at 2022-06-11 14:18:10.513264
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = 'http://localhost:8080/v1/catalog/service/%E6%9C%8D%E5%8A%A1?tag=%E6%95%B0%E6%8D%AE%E5%BA%93'
    assert unicode_urldecode(s) == 'http://localhost:8080/v1/catalog/service/服务?tag=数据库'
    assert unicode_urldecode(u'http://localhost:8080/v1/catalog/service/服务?tag=数据库') == 'http://localhost:8080/v1/catalog/service/服务?tag=数据库'


# Generated at 2022-06-11 14:18:20.427586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test no jinja2.filters.do_urlencode
    filters = FilterModule().filters()
    assert do_urlencode in filters.values()
    assert do_urldecode in filters.values()
    assert 'urlencode' in filters.keys()
    assert 'urldecode' in filters.keys()

    # Test with jinja2.filters.do_urlencode
    from jinja2.filters import do_urlencode as jinja2_do_urlencode
    filters['urlencode'] = jinja2_do_urlencode
    filters = FilterModule().filters()
    assert do_urlencode not in filters.values()
    assert do_urldecode in filters.values()

# Generated at 2022-06-11 14:18:22.241136
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%20+%3F") == " +?"


# Generated at 2022-06-11 14:18:31.721821
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E0%A4%AE%E0%A5%81%E0%A4%96%E0%A4%BE') == u'मुखा'
    assert unicode_urldecode(u'%E0%A4%AE%E0%A4%82%E0%A4%B7%E0%A4%A6%E0%A4%BE%E0%A4%A8') == u'मूषदान'

# Generated at 2022-06-11 14:18:38.512073
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode("/") == "%2F"
    assert do_urlencode("a/b") == "a%2Fb"
    assert do_urlencode("a/b=c") == "a%2Fb=c"
    assert do_urlencode("a&b=c") == "a&b=c"
    assert do_urlencode("a&b=c") == "a&b=c"
    assert do_urlencode("a?b=c") == "a?b=c"
    assert do_urlencode("a/b?c=d") == "a%2Fb?c=d"
    assert do_urlencode("a&b?c=d") == "a&b?c=d"

# Generated at 2022-06-11 14:18:40.865106
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%21') == u'!'


# Generated at 2022-06-11 14:18:49.495321
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils import context_objects
    from ansible.module_utils.basic import AnsibleModule

    test_model = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    test_model_args = {}

    test_ctx = context_objects.ModuleResult(task_vars={}, result=None, ansible_module=test_model, ansible_module_args=test_model_args)

    assert FilterModule().filters()['urldecode'](test_ctx, 'a+b%20c') == u'a b c'

    # NOTE: The filters[urlencode] test is not include in the test because
    # that filter is imported from Jinja2 and is thus not guaranteed to exist!
    pass