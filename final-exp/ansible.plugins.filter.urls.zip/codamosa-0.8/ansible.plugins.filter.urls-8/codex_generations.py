

# Generated at 2022-06-11 14:08:59.644632
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'm%c3%b9ti%c3%a8res+%26+r%c3%a9volution%21') == u'mùtières & révolution!'
    assert unicode_urldecode(u'm%C3%B9ti%C3%A8res+%26+r%C3%A9volution%21') == u'mùtières & révolution!'
    assert unicode_urldecode(u'm%C3%B9ti%C3%A8res+%26+r%C3%A9volution%21'.encode('utf-8')) == u'mùtières & révolution!'

# Generated at 2022-06-11 14:09:05.701354
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('value') == 'value'
    assert unicode_urlencode('value/value') == 'value%2Fvalue'
    assert unicode_urlencode('value/value', for_qs=True) == 'value%2Fvalue'
    assert unicode_urlencode({'a': 'value', 'b': 'value'}) == 'a=value&b=value'
    assert unicode_urlencode([('a', 'value'), ('b', 'value')]) == 'a=value&b=value'

# Generated at 2022-06-11 14:09:17.215592
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode('/foo/bar') == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo/bar', for_qs=True) == '%2Ffoo%2Fbar'
    assert unicode_urlencode('/foo/?bar') == '%2Ffoo%2F%3Fbar'
    assert unicode_urlencode('/foo/?bar', for_qs=True) == '%2Ffoo%2F%3Fbar'

# Generated at 2022-06-11 14:09:25.395823
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"B%C3%83%C2%ADsico") == u"Básico"
    assert unicode_urldecode("B%C3%83%C2%ADsico") == u"Básico"
    assert unicode_urldecode("B%C3%83%C2%ADsico") == u"Básico"
    assert unicode_urldecode("B%C3%83%C2%ADsico") == u"Básico"


# Generated at 2022-06-11 14:09:27.041651
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters is not None



# Generated at 2022-06-11 14:09:33.096945
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm
    assert fm.filters()
    assert fm.filters()['urldecode']
    assert fm.filters()['urldecode']('http%3A%2F%2Fdocs.ansible.com%2F%3Fv%3D2.0') == 'http://docs.ansible.com/?v=2.0'
    assert fm.filters()['urldecode']('http://docs.ansible.com') == 'http://docs.ansible.com'


# Generated at 2022-06-11 14:09:44.728139
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    ''' Test unicode_urlencode '''
    assert 'this%20is%20a%20test' == unicode_urlencode('this is a test')
    assert 'this%20is%20a%20%E6%B5%8B%E8%AF%95' == unicode_urlencode(u'this is a 测试')
    assert 'a%20b%20c' == unicode_urlencode(['a', 'b', 'c'])
    assert 'this%20is%20a%20test' == unicode_urlencode({'this': 'is', 'a': 'test'})
    assert 'this%20is%20a%20test' == unicode_urlencode(LazyObject('this is a test'))

# Generated at 2022-06-11 14:09:53.388517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters()['urldecode'](u'%0A%09') == u'\n\t'
    assert filter.filters()['urldecode'](u'%E3%81%82') == u'あ'

    if not HAS_URLENCODE:
        assert filter.filters()['urlencode'](u'\n\t') == u'%0A%09'
        assert filter.filters()['urlencode'](u'あ') == u'%E3%81%82'



# Generated at 2022-06-11 14:09:55.674551
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%20") == ' '
    assert unicode_urldecode("%C3%A0") == to_text("à")


# Generated at 2022-06-11 14:10:00.988227
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%82') == u'あ'
    assert unicode_urldecode('%C3%A5') == u'å'
    assert unicode_urldecode('%E3%81%82%C3%A5') == u'あå'


# Unit tests for function do_urldecode

# Generated at 2022-06-11 14:10:12.104658
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode(u'') == ''
    assert unicode_urlencode(u'A') == 'A'
    assert unicode_urlencode(u'A') == 'A'
    assert unicode_urlencode(u'\u0080') == '%C2%80'
    assert unicode_urlencode(u'\u0080\u0081') == '%C2%80%C2%81'
    assert unicode_urlencode(u'\u0080\u0081', for_qs=True) == '%C2%80%C2%81'
    assert unicode_urlencode(u'/') == '%2F'

# Generated at 2022-06-11 14:10:18.279216
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u"Hi&there") == u"Hi%26there"
    assert do_urlencode(["A", "B", "C"]) == u"A&B&C"
    assert do_urlencode({"A": "B", "C": "D"}) == u"C=D&A=B"
    assert do_urlencode(u"Hi there") == u"Hi+there"
    assert do_urlencode(u"Hi there&") == u"Hi+there%26"


# Generated at 2022-06-11 14:10:22.294864
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%c3%a4') == u'\xe4'
    assert unicode_urldecode('%c3%a4'.encode('utf-8')) == u'\xe4'


# Generated at 2022-06-11 14:10:24.088650
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    decoded = unicode_urldecode('%C3%A1')
    assert decoded == u'á'



# Generated at 2022-06-11 14:10:29.643224
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in fm.filters()

test_FilterModule_filters()

# Unit tests for method unicode_urldecode of class FilterModule

# Generated at 2022-06-11 14:10:33.770337
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%3Abar') == 'foo:bar'
    assert unicode_urldecode('foo+%5Ebar') == 'foo ^bar'
    assert unicode_urldecode(u'foo%c3%b1bar') == u'fooñbar'



# Generated at 2022-06-11 14:10:36.750504
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fgithub.com%2F') == 'https://github.com/'


# Generated at 2022-06-11 14:10:46.431423
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%B6%C3%BC') == u'äöü'
    assert unicode_urldecode('%E2%82%AC%C3%A4%C3%B6%C3%BC') == u'€äöü'
    assert unicode_urldecode('%E2%82%AC%c3%A4%c3%B6%c3%BC') == u'€äöü'
    assert unicode_urldecode('+%C3%A4+%C3%B6+%C3%BC+') == u'+ä+ö+ü+'

# Generated at 2022-06-11 14:10:56.274488
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' unicode_urldecode should decode a url string '''
    assert u'a b' == unicode_urldecode(u'a%20b')
    assert u'a b' == unicode_urldecode(u'a+b')
    assert u'a b' == unicode_urldecode(u'a b')
    assert u'a/b' == unicode_urldecode(u'a/b')
    assert u'a%b' == unicode_urldecode(u'a%25b')
    assert u'a%b' == unicode_urldecode(u'a%2525b')
    assert u'a%b' == unicode_urldecode(u'a%25b')
    assert u'a%b' == unicode_

# Generated at 2022-06-11 14:11:03.007526
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo bar+bar') == 'foo+bar%2Bbar'
    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode({'foo': 'bar', 'bar': 'foo'}) == 'foo=bar&bar=foo'
    assert do_urlencode(('foo', 'bar')) == 'foo&bar'
    assert do_urlencode(('foo', 'bar', {'foo': 'bar'})) == 'foo&bar&foo=bar'

# Generated at 2022-06-11 14:11:06.986783
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert '\xc3\xa9\xc3\xa9' == unicode_urldecode("%C3%A9%C3%A9")


# Generated at 2022-06-11 14:11:11.620465
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('http://localhost:8888/aé'), 'http%3A//localhost%3A8888/a%C3%A9'
    assert unicode_urlencode('http://localhost:8888/aé', for_qs=True), 'http%3A%2F%2Flocalhost%3A8888%2Fa%C3%A9'

# Generated at 2022-06-11 14:11:16.771967
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urlencode('foo') == u'foo'
    assert do_urlencode({'foo': 'bar'}) == u'foo=bar'
    assert do_urldecode(u'foo') == u'foo'


if __name__ == '__main__':
    import pytest
    pytest.main(['--verbose', __file__])

# Generated at 2022-06-11 14:11:23.316403
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.compat.tests.unit.test_compat import make_file
    import os
    import tempfile

    filters = FilterModule().filters()
    assert 'urldecode' in filters
    assert filters['urldecode']('dag%40wieers.com') == 'dag@wieers.com'

    # The urlencode function is not available when running on old Jinja2
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode']('dag@wieers.com') == 'dag%40wieers.com'
        assert filters['urlencode']('dag@wieers.com', True) == 'dag%40wieers.com'

# Generated at 2022-06-11 14:11:27.116470
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert(fm.filters('urldecode') == do_urldecode)
    assert(fm.filters('urlencode') == do_urlencode)

# Generated at 2022-06-11 14:11:32.351691
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B6%C3%A4%C3%BC') == u'öäü'
    assert unicode_urldecode('%C3%B6%C3%A4%C3%BC') == u'öäü'
    assert unicode_urldecode('%C3%B6%C3%A4%C3%BC') == u'öäü'



# Generated at 2022-06-11 14:11:36.653455
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%40b%20c+d%25") == "a@b c+d%"
    assert unicode_urldecode("a@b c+d%25") == "a@b c+d%"



# Generated at 2022-06-11 14:11:45.264596
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'\u0153' == unicode_urldecode(u'%C5%93')
    assert u'abcABC123' == unicode_urldecode(u'abcABC123')
    assert u'abc 123' == unicode_urldecode(u'abc+123')
    assert u'ä' == unicode_urldecode(u'%C3%A4')
    assert u'ä 123' == unicode_urldecode(u'%C3%A4+123')
    assert u'ñ' == unicode_urldecode(u'%C3%B1')
    assert u'ñ 123' == unicode_urldecode(u'%C3%B1+123')

# Generated at 2022-06-11 14:11:53.911535
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%E2%82%AC') == '€'
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%3B') == ';'
    assert unicode_urldecode('%C3%A9') == 'é'
    assert unicode_urldecode('%3A') == ':'

# Generated at 2022-06-11 14:11:55.692802
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    s = u'abc def'
    expected = 'abc%20def'

    assert unicode_urlencode(s) == expected

# Generated at 2022-06-11 14:12:05.762526
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('a%20space') == 'a space'
    assert FilterModule().filters()['urldecode']('a+plus') == 'a+plus'
    assert FilterModule().filters()['urldecode']('a%25percent') == 'a%percent'
    assert FilterModule().filters()['urldecode']('a=equals') == 'a=equals'
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('a space') == 'a%20space'
        assert FilterModule().filters()['urlencode']('a+plus') == 'a%2Bplus'
        assert FilterModule().filters()['urlencode']('a%percent') == 'a%25percent'
        assert FilterModule

# Generated at 2022-06-11 14:12:16.850714
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test defaults
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    # Test 'for_qs'
    assert unicode_urlencode('foo bar', for_qs=True) == 'foo+bar'
    # Test with string objects
    assert unicode_urlencode(u'foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    # Test with unicode objects
    foo_str = u'foo'
    assert unicode_urlencode(foo_str) == 'foo'
    foo_bytes = to_bytes(foo_str)
    assert unicode_urlencode(foo_bytes) == 'foo'
    bar_str = u'bar'
    assert unicode_urlencode(bar_str)

# Generated at 2022-06-11 14:12:18.789355
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9%C3%A9') == u'éé'


# Generated at 2022-06-11 14:12:24.260641
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    x = '%20%41%42%43%E6%96%87'
    assert unicode_urldecode(x) == ' ABC文'

    x = '%E6%96%87%20%41%42%43'
    assert unicode_urldecode(x) == '文 ABC'

    x = 'ABC%20%E6%96%87'
    assert unicode_urldecode(x) == 'ABC 文'

    x = '%E6%96%87%20ABC'
    assert unicode_urldecode(x) == '文 ABC'



# Generated at 2022-06-11 14:12:30.902243
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' FilterModule class filters unit test '''
    import pytest
    fm = FilterModule()
    obj = fm.filters()
    obj_a = obj['urldecode']('hoge')
    obj_b = obj['urldecode']('hoge%24')
    assert obj_a == 'hoge'
    assert obj_b == 'hoge$'



# Generated at 2022-06-11 14:12:39.797260
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+bar') == u'foo bar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%3D%26') == u'foo=&'
    assert unicode_urldecode('foo%3D%2B') == u'foo=+'
    assert unicode_urldecode('foo%3D%25') == u'foo=%'
    assert unicode_urldecode('foo%3D%2A') == u'foo=*'
    assert unicode_urldecode('foo%3D%7C') == u'foo=|'
    assert unicode_urldecode('123%3D%2Aabc%3D%2A456') == u

# Generated at 2022-06-11 14:12:48.590711
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test for filter urldecode '''
    utf8_string = u'русский текст'
    utf8_encoded = '%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9+%D1%82%D0%B5%D0%BA%D1%81%D1%82'
    encoded = '%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9+%D1%82%D0%B5%D0%BA%D1%81%D1%82'
    assert unicode_urldecode(encoded) == utf

# Generated at 2022-06-11 14:12:58.196012
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'{{ foo.bar }}') == '%7B%7B+foo.bar+%7D%7D'
    assert unicode_urlencode(u'foo+bar') == 'foo%2Bbar'
    assert unicode_urlencode(u'foo%20bar') == 'foo%20bar'
    assert unicode_urlencode(u'foo bar') == 'foo+bar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == 'foo+bar'
    assert unicode_urlencode(u'foo / bar') == 'foo+%2F+bar'
    assert unicode_urlencode(u'foo / bar', for_qs=True) == 'foo+%2F+bar'
    assert unicode_urlen

# Generated at 2022-06-11 14:13:00.447804
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb%2Cc%3Dd') == 'a+b,c=d'


# Generated at 2022-06-11 14:13:04.636623
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for FilterModule.filters() method '''
    filters = FilterModule().filters()
    assert filters['urldecode'](u'Hello%20World%21') == u'Hello World!'
    if not HAS_URLENCODE:
        assert filters['urlencode'](u'Hello World!') == u'Hello%20World%21'



# Generated at 2022-06-11 14:13:07.714788
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode



# Generated at 2022-06-11 14:13:16.206283
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('?foo=bar') == '%3Ffoo%3Dbar'
    assert do_urlencode('http://foo.bar/baz/bar') == 'http%3A%2F%2Ffoo.bar%2Fbaz%2Fbar'
    assert do_urlencode({'one': 'two', 'three': 'four'}) == 'one=two&three=four'
    assert do_urlencode(['one', 'two', 'three', 'four']) == 'one&two&three&four'
    assert do_urlencode('?foo=bar&baz=qux') == '%3Ffoo%3Dbar%26baz%3Dqux'

# Generated at 2022-06-11 14:13:19.701161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert(filters.get('urldecode') == do_urldecode)
    assert(filters.get('urlencode') == do_urlencode)


# Generated at 2022-06-11 14:13:23.146701
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert 'abc%2B123' == unicode_urlencode('abc+123')
    assert 'abc%2B123' == unicode_urlencode(u'abc+123')
    assert 'abc%2B123' == unicode_urlencode(u'abc+123'.encode('utf-8'))

# Generated at 2022-06-11 14:13:25.982151
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test') == 'test'
    assert unicode_urldecode('testing+%21') == 'testing !'


# Generated at 2022-06-11 14:13:30.959132
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Unit test that FilterModule class' filters() method returns the expected
    result.
    """
    fm = FilterModule()
    filters = fm.filters()
    assert len(filters) == 2
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:13:32.885853
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    assert FilterModule().filters()['urldecode']('test%40example.com') == 'test@example.com'

# Generated at 2022-06-11 14:13:43.047360
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('') == ''
    assert do_urldecode('not encoded') == 'not encoded'
    assert do_urldecode('encoded%20string') == 'encoded string'
    assert do_urldecode('foo+bar') == 'foo bar'
    assert do_urldecode(u'encoded%20string') == u'encoded string'
    assert do_urldecode(u'foo+bar') == u'foo bar'
    assert do_urldecode(u'%E6%96%87%E5%AD%97') == u'文字'
    assert do_urldecode(u'%E6%96%87%E5%AD%97'.encode('utf-8')) == u'文字'

   

# Generated at 2022-06-11 14:13:47.745859
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import StringIO

    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

    # urldecode - Not in Jinja2 2.7
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters()
        assert hasattr(fm.filters()['urlencode'], '__call__')

# Generated at 2022-06-11 14:13:59.101758
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"https://username:password@www.example.com:8080/abc/def?q1=1&q2=2#tag") == u"https://username:password@www.example.com:8080/abc/def?q1=1&q2=2#tag"
    assert unicode_urldecode(u"https://username:password@www.example.com:8080/abc/def?q1=1&q2=2#\u30a2\u30a4\u30c9\u30eb") == u"https://username:password@www.example.com:8080/abc/def?q1=1&q2=2#\u30a2\u30a4\u30c9\u30eb"


# Generated at 2022-06-11 14:14:13.332951
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == u'abc'
    assert unicode_urlencode('abc123') == u'abc123'
    assert unicode_urlencode('abc 123') == u'abc%20123'
    assert unicode_urlencode('abc+123') == u'abc%2B123'
    assert unicode_urlencode('A B C') == u'A%20B%20C'
    assert unicode_urlencode('A B#C') == u'A%20B%23C'

    assert unicode_urlencode('abc', for_qs=True) == u'abc'
    assert unicode_urlencode('abc123', for_qs=True) == u'abc123'
    assert unicode_urlencode('abc 123', for_qs=True) == u

# Generated at 2022-06-11 14:14:15.948693
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2B') == to_text('+')
    assert unicode_urldecode('+') == to_text('+')
    assert unicode_urldecode('foo') == to_text('foo')



# Generated at 2022-06-11 14:14:19.960239
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('foo bar') == u'foo bar'
    assert unicode_urldecode('foo+bar') == u'foo bar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%') == u'foo%'
    assert unicode_urldecode('%') == u'%'


# Generated at 2022-06-11 14:14:29.611436
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    assert unicode_urldecode('%7B%22b%22%3A1%2C%22a%22%3A%22c%22%7D') == unquote_plus(b'%7B%22b%22%3A1%2C%22a%22%3A%22c%22%7D')

# Generated at 2022-06-11 14:14:40.683609
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # TODO: Refactor test_FilterModule_filters to use pytest
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import unittest

    class TestFilterModule(unittest.TestCase):

        # For Python 2.x
        if six.PY2:
            def test_FilterModule_filters_Python2(self):

                from ansible.module_utils import jinja2_filter
                f = jinja2_filter.FilterModule()
                url_dict = {'a:': '1', 'b': '2', 'c': None}
                url_dict_encoded = 'a%3A=1&b=2&c='
                url_list = ('a:', '1', 'b', '2', 'c', None)

                self

# Generated at 2022-06-11 14:14:47.812680
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3C%3E%3F%3A%2F%23%25+%26') == u'<>?:/#% &'
    assert unicode_urldecode('%C3%A9%C3%B1%C3%A5%C3%B8%C3%BE%C3%A9%20%C5%92%C3%B2') == u'éñåøþé Œô'


# Generated at 2022-06-11 14:14:51.572945
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:14:53.641638
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urlencode' in filters
    assert 'urldecode' in filters


# Generated at 2022-06-11 14:15:02.573126
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"abc") == u"abc"
    assert unicode_urldecode(u"%20") == u" "
    assert unicode_urldecode(u"%41") == u"A"
    assert unicode_urldecode(b"%41") == u"A"
    assert unicode_urldecode(u"%41%42%43") == u"ABC"
    assert unicode_urldecode(b"%41%42%43") == u"ABC"
    assert unicode_urldecode(u"%41%42%43%20%44%45") == u"ABC DE"
    assert unicode_urldecode(b"%41%42%43%20%44%45") == u"ABC DE"

# Unit

# Generated at 2022-06-11 14:15:13.124126
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:15:23.463579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f
    assert f.filters
    f = f.filters()
    assert f
    assert f['urldecode']


# Generated at 2022-06-11 14:15:30.844117
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode']('a%20string%20with%20space') == b'a string with space'
    assert filters['urldecode']('a%20string%20with%20space') == u'a string with space'
    assert filters['urldecode']('a+string+with+plus') == b'a string with plus'
    assert filters['urldecode']('a+string+with+plus') == u'a string with plus'
    if not HAS_URLENCODE:
        assert filters['urlencode']('a string with space') == 'a+string+with+space'
        assert filters['urlencode']('a string with plus') == 'a+string+with+plus'

# Generated at 2022-06-11 14:15:42.196374
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%c3%a9") == u"\u00e9"
    assert unicode_urldecode("%20") == u" "
    assert unicode_urldecode("%2F") == u"/"
    assert unicode_urldecode("%2f") == u"/"
    assert unicode_urldecode("%c3%A9") == u"\u00e9"
    assert unicode_urldecode("%2B") == u"+"
    assert unicode_urldecode("%20%28%29") == u" ()"
    assert unicode_urldecode("%2B+%2B") == u"++"

# Generated at 2022-06-11 14:15:45.519067
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert len(list(obj.filters().keys())) == 2

# Test class and method in docstring when run as script
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 14:15:50.873451
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a/b') == u'a%2Fb'
    assert unicode_urlencode(u'a/b', for_qs=True) == u'a%2Fb'
    assert unicode_urlencode(u'a b') == u'a%20b'
    assert unicode_urlencode(u'a b', for_qs=True) == u'a+b'

# Generated at 2022-06-11 14:15:59.200414
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%0A') == u'\n'
    assert unicode_urldecode('%7B%7D') == u'{}'
    assert unicode_urldecode('%28%29') == u'()'
    if PY3:
        assert unicode_urldecode('%20') == u' '
    else:
        assert unicode_urldecode('%20') == u'\x20'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%7B%22a%22%3A%5B1%2C3%5D%7D') == u'{"a":[1,3]}'

# Generated at 2022-06-11 14:16:09.248515
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test the following:
    # - FilterModule.filters() returns a dict
    # - 'urldecode' is in dict
    # - 'urledecode' is a function
    # - 'urldecode' can be called
    # - 'urlencode' is in dict
    # - 'urldecode' is a function
    # - 'urldecode' can be called
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert 'urldecode' in filters
    assert hasattr(filters['urldecode'], '__call__')
    assert do_urldecode('http%3A//docs.ansible.com/ansible/') == 'http://docs.ansible.com/ansible/'
   

# Generated at 2022-06-11 14:16:19.375695
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'%2F'
    assert unicode_urlencode('/', for_qs=True) == u'%2F'
    assert unicode_urlencode('-_') == u'%2D_'
    assert unicode_urlencode('-_', for_qs=True) == u'%2D%5F'
    assert unicode_urlencode({'key': 'value'}) == u'key=value'
    assert unicode_urlencode({'key': 'value'}, for_qs=True) == u'key=value'
    assert unicode_urlencode({'key': 'value', 'key2': 'value2'}) == u'key=value&key2=value2'

# Generated at 2022-06-11 14:16:28.157762
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    from ansible.module_utils._text import to_native
    pytest = ansible_pytest.module_utils.pytest_plugin
    test_data = ansible_pytest.module_utils.test_data

    def run_filter(filter_name, args, input_data=None):
        with open(test_data.ansible_path('unit/modules/utils/fixtures/FilterModule_filters/%s.json' % filter_name), 'rb') as f:
            golden_output = json.load(f)

        try:
            fm = FilterModule()
        except Exception as e:
            raise pytest.fail('Failed to instantiate FilterModule: {0}'.format(to_native(e)))


# Generated at 2022-06-11 14:16:36.469716
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'https://example.org/path/to/name?arg1=val1&arg2=val2'
    assert unicode_urlencode(string) == string
    string = u'foo/bar'
    assert unicode_urlencode(string) == u'foo%2Fbar'
    assert unicode_urlencode(string, for_qs=True) == u'foo%2Fbar'
    string = u'foo bar'
    assert unicode_urlencode(string) == u'foo%20bar'
    assert unicode_urlencode(string, for_qs=True) == u'foo+bar'


# Generated at 2022-06-11 14:16:59.457025
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://www.example.com/a\xE9b/c\xE8d/\xEA\xF1\xFC') == u'http%3A//www.example.com/a%C3%A9b/c%C3%A8d/%C3%AA%C3%B1%C3%BC'

# Generated at 2022-06-11 14:17:09.461226
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'~') == u'~'
    assert unicode_urlencode(u'%7E') == u'%7E'
    assert unicode_urlencode(u'~', for_qs=True) == u'%7E'
    assert unicode_urlencode(u'%', for_qs=True) == u'%25'
    assert unicode_urlencode(u'%') == u'%25'
    assert unicode_urlencode(u'%25', for_qs=True) == u'%2525'
    assert unicode_urlencode(u'%25') == u'%2525'


# Generated at 2022-06-11 14:17:11.516959
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    uni_test_string = u'%E2%98%83'
    print(unicode_urldecode(uni_test_string))



# Generated at 2022-06-11 14:17:15.164151
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # FIXME: This test is just a placeholder for now
    f = FilterModule().filters()
    assert 'urldecode' in f
    assert 'urlencode' in f
    assert f['urldecode'] == do_urldecode
    assert f['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:17:19.391333
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    assert unicode_urldecode('http%3A%2F%2Fexample.com%2Fapi%2Fv1%2Finfo%3Fq%3Dtest%26v%3D1') == 'http://example.com/api/v1/info?q=test&v=1'

# Generated at 2022-06-11 14:17:21.371233
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'k%C3%A9k%C3%A9') == u'kéké'


# Generated at 2022-06-11 14:17:28.252897
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # case 1: test filters
    filters = FilterModule().filters()
    url = "https://www.example.com/api/v1/account?username=admin&password={{ vault_admin_password }}"
    assert filters["urldecode"](url) == 'https://www.example.com/api/v1/account?username=admin&password={{ vault_admin_password }}'
    assert filters["urlencode"](url) == 'https%3A%2F%2Fwww.example.com%2Fapi%2Fv1%2Faccount%3Fusername%3Dadmin%26password%3D%7B%7B%20vault_admin_password%20%7D%7D'

# Generated at 2022-06-11 14:17:29.727196
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''FilterModule.filters() returns dict of jinja2 filters'''
    assert isinstance(FilterModule.filters(None), dict)

# Generated at 2022-06-11 14:17:33.870364
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:17:42.544057
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test1 = "%E6%9C%9D%E5%8F%B6%E7%B3%BB%E7%BB%9F%E7%9A%84%E5%8A%9E%E7%90%86"
    ans1 = "朝叶系统的办理"
    test2 = "%78%79%7A%7B%7C%7D%7E%7F%80%81%82%83%84%85%86%87%88%89"
    ans2 = "xyz{|}~\x7f\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89"

    assert unicode_urldecode(test1) == ans1
   

# Generated at 2022-06-11 14:18:04.264252
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    # Create a loaded environment
    env = jinja2.Environment(loader=jinja2.DictLoader({}))
    # Add filters
    env.filters.update(FilterModule().filters())

    # Test urldecode filter
    assert env.filters['urldecode']('a%2B%2F%26b%3D') == unquote_plus('a%2B%2F%26b%3D')
    assert env.filters['urldecode']('a+%2F&b=') == unquote_plus('a+%2F&b=')

    # Test urlencode filter
    # NOTE: Without jinja2 2.7, we

# Generated at 2022-06-11 14:18:13.069612
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'foobar') == 'foobar'
    assert unicode_urlencode(u'foo bar%') == 'foo%20bar%25'
    assert unicode_urlencode(u'foo bar%', for_qs=True) == 'foo+bar%25'
    assert unicode_urlencode(u'foo bar%/') == 'foo%20bar%25%2F'
    assert unicode_urlencode(u'foo bar%/', for_qs=True) == 'foo+bar%25%2F'
    assert unicode_urlencode(u'foo bar%2F') == 'foo%20bar%252F'
    assert unicode_urlencode(u'foo bar%2F', for_qs=True) == 'foo+bar%252F'

# Generated at 2022-06-11 14:18:23.007325
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import urlencode

    kwargs = {
        'for_qs': True,
    }
    for value in [
        None,
        42,
        'á',
        u'\N{LATIN SMALL LETTER A WITH GRAVE}',
        'http://www.example.com',
        u'http://www.example.com/~user',
        {'foo': 'bar'},
        [('foo', 'bar')],
        [('foo', '~bar')],
    ]:
        expected_value = urlencode(value, **kwargs)
        actual_value = do_urlencode(value)
        assert expected_value == actual_value

# Generated at 2022-06-11 14:18:26.972515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar%20baz') == 'foo bar baz'


# Generated at 2022-06-11 14:18:36.396390
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:18:39.312367
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("https%3A%2F%2Fgithub.com%2Fansible%2Fansible") == "https://github.com/ansible/ansible"


# Generated at 2022-06-11 14:18:49.182179
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode(b'') == ''
    assert unicode_urlencode('a') == 'a'
    assert unicode_urlencode(b'a') == 'a'
    assert unicode_urlencode('a a') == 'a%20a'
    assert unicode_urlencode(b'a a') == 'a%20a'
    assert unicode_urlencode('a+a') == 'a%2Ba'
    assert unicode_urlencode(b'a+a') == 'a%2Ba'
    assert unicode_urlencode('a=a') == 'a%3Da'
    assert unicode_urlencode(b'a=a') == 'a%3Da'
    assert unicode_url