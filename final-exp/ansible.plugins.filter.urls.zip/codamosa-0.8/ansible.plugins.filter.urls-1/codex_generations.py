

# Generated at 2022-06-11 14:08:51.616410
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-11 14:08:56.087278
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/foo+bar') == '%2Ffoo%2Bbar'
    assert unicode_urlencode('/foo+bar', for_qs=True) == '%2Ffoo%2Bbar'

# Generated at 2022-06-11 14:09:04.477723
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == ''
    assert unicode_urldecode('fooA') == 'fooA'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%40bar') == 'foo@bar'
    assert unicode_urldecode('foo%3Dbar') == 'foo=bar'
    assert unicode_urldecode('foo%26bar') == 'foo&bar'
    # the + character should not be replaced by spaces in a query string:
    assert unicode_urldecode('foo+bar', for_qs=True) == 'foo+bar'


# Generated at 2022-06-11 14:09:11.917799
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    for s, v in [
            ('foo+bar', u'foo bar'),
            ('foo%20bar', u'foo bar'),
            ('foo%01bar', u'foo\x01bar'),
            ('foo%01%21', u'foo\x01!'),
            ('foo%21%01', u'foo!\x01'),
            ('foo%81%41%42%43', u'foo\U00000081ABC'),
            ]:
        r = unicode_urldecode(s)
        assert r == v


# Generated at 2022-06-11 14:09:22.395608
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import unittest
    class TestStringMethods(unittest.TestCase):
        def test_urlencode(self):
            self.assertEqual(unicode_urlencode('/the+/world'), '%2Fthe%2B%2Fworld')
            self.assertEqual(unicode_urlencode('/the+/world', for_qs=True), '%2Fthe%2B%2Fworld')
            self.assertEqual(unicode_urlencode(u'/the+/world'), u'%2Fthe%2B%2Fworld')
            self.assertEqual(unicode_urlencode(u'/the+/world', for_qs=True), u'%2Fthe%2B%2Fworld')

    unittest.main()

# Generated at 2022-06-11 14:09:31.965567
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Unit test for method urldecode of class FilterModule
    class Test_FilterModule():
        def urldecode(self, string):
            return FilterModule.filters(self)['urldecode'](string)

        def urlencode(self, string):
            return FilterModule.filters(self)['urlencode'](string)

    test_class = Test_FilterModule()

# Generated at 2022-06-11 14:09:43.586767
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.common.text.converters import to_unicode
    from jinja2 import Environment

    F = FilterModule()
    env = Environment()

    urllib_quote_unquote_test = 'łąś'
    urllib_quote_unquote_test_unicode = u'łąś'
    jinja2_filters_urldecode_test = '%C5%82%C4%85%C5%9B'
    jinja2_filters_urlencode_test = '%C5%82%C4%85%C5%9B'
    jinja2_filters_urlencode_test_qs = '%C5%82%C4%85%C5%9B'

   

# Generated at 2022-06-11 14:09:54.739114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc+xyz') == u'abc xyz'
    assert unicode_urldecode(u'fööbär') == u'fööbär'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo+bar') == u'foo bar'

    assert unicode_urlencode('abc') == u'abc'
    assert unicode_urlencode('abc xyz') == u'abc+xyz'
    assert unicode_urlencode(u'fööbär') == u'f%C3%B6%C3%B6b%C3%A4r'

# Generated at 2022-06-11 14:09:58.370031
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm_filters = fm.filters()

    for (fname, f) in iteritems(fm_filters):
        if hasattr(f, '__call__'):
            assert f(1) == f(1)

# Generated at 2022-06-11 14:10:02.715662
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm is not None
    filters = fm.filters()
    assert "urldecode" in filters
    assert filters["urldecode"] is not None
    assert filters["urldecode"] == do_urldecode

# Generated at 2022-06-11 14:10:10.847359
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    value = u'%E2%96%88%E2%96%88%E2%96%88%E2%96%88%E2%96%88%E2%96%88%E2%96%88'
    expected = u'\u2608\u2608\u2608\u2608\u2608\u2608\u2608'
    observed = unicode_urldecode(value)
    assert expected == observed



# Generated at 2022-06-11 14:10:13.906030
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%2Fbar') == 'foo/bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%25bar') == 'foo%bar'



# Generated at 2022-06-11 14:10:23.907625
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:10:33.528787
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys

    # Set up test environment
    filter_module = FilterModule()
    filters = filter_module.filters()

    # Test urldecode
    assert filters['urldecode']('hello+world') == 'hello world'
    assert filters['urldecode']('hello%20world') == 'hello world'
    assert filters['urldecode']('hello%2Bworld') == 'hello+world'
    assert filters['urldecode']('hello%2bworld') == 'hello+world'

    if not HAS_URLENCODE:
        # Test urlencode
        assert filters['urlencode']('hello') == 'hello'
        assert filters['urlencode']('hello world') == 'hello+world'
        assert filters['urlencode']('hello+world') == 'hello%2Bworld'

# Generated at 2022-06-11 14:10:37.397527
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'こんにちは') == u'%E3%81%93%E3%82%93%E3%81%AB%E3%81%A1%E3%81%AF'

# Generated at 2022-06-11 14:10:46.922658
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%80') == u'€'
    assert unicode_urldecode(u'%E7%81%AA') == u'灪'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%C3%B8') == u'ø'
    assert unicode_urldecode(u'%c3%b8') == u'ø'
    assert unicode_urldecode(u'%ED') == u'í'
    assert unicode_urldecode(u'%c3%89') == u'É'

# Generated at 2022-06-11 14:10:49.792050
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    def test(expected, string):
        result = unicode_urldecode(string)
        assert expected == result
    test(u'français', 'fran%C3%A7ais')


# Generated at 2022-06-11 14:10:58.976960
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc+') == 'abc '
    assert unicode_urldecode('abc%20') == 'abc '
    assert unicode_urldecode('abc+def') == 'abc def'
    assert unicode_urldecode('abc+%20def') == 'abc  def'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc%2def') == 'abc%2def'
    assert unicode_urldecode('abc%2Fdef') == 'abc/def'


# Generated at 2022-06-11 14:11:03.971619
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("%5B%5D") == "[]"
    assert do_urldecode("%5B%3D%5D") == "[=]"
    assert do_urldecode("%5B%3D%3D%5D") == "[==]"
    assert do_urldecode("%5B%3D%3D%3D%5D") == "[===]"
    assert do_urldecode("%5B%25%5D") == "[%]"
    assert do_urldecode("%5B%25%3D%5D") == "[%=]"

# Generated at 2022-06-11 14:11:13.025801
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test urldecode filter against python urllib.unquote_plus

    >>> from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    >>> teststring = u'%D0%B4%D0%B0%D0%BD%D1%8C+%D0%BC%D0%BE%D0%B8%D0%B7%D0%B0%D0%BC%D0%BE%D0%B2'
    >>> unicode_urldecode(teststring) == unquote_plus(teststring)
    True
    '''
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 14:11:22.184911
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:11:26.145579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_instance = FilterModule()
    assert filter_instance.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }



# Generated at 2022-06-11 14:11:29.113787
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic

    # test FilterModule.filters()
    obj = FilterModule()
    f = obj.filters()
    assert f == { 'urldecode': do_urldecode }


# Generated at 2022-06-11 14:11:38.802157
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%7D') == u'{}'
    assert unicode_urldecode('%7B%7D%5B%5D%21%40%23%24%25%5E%26*%28%29_-%2B%3D%5B%5D%7B%7D%5C%7C%3A%3B%27%22%3C%3E%3F%2C.%2F') == u'{}[]!@#$%^&*()_-=[]{}\|:;\'",./'

# Generated at 2022-06-11 14:11:46.883046
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:11:53.745751
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    tester = FilterModule()
    filters = tester.filters()

    assert filters['urldecode']('abc123+%40xyz=%2B+%E2%82%AC') == 'abc123 @xyz= + €'
    if not HAS_URLENCODE:
        assert filters['urlencode']('abc123 @xyz= + €') == 'abc123+%40xyz%3D+%2B+%E2%82%AC'

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-11 14:12:03.276000
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os, sys
    import ansible.constants as C
    from ansible.utils.display import Display
    from six import StringIO
    try:
        from __main__ import display
    except ImportError:
        display = Display()
    display.verbosity = 3

    # Test the FilterModule class
    fm = FilterModule()

    for filtername, filterfunc in fm.filters().items():
        if filtername == 'urlencode' and HAS_URLENCODE:
            continue
        display.display('%s test: ' % filtername)
        datafile = os.path.join(C.FILTER_PLUGINS, 'tests', '%s.txt' % filtername)
        if not os.path.exists(datafile):
            continue

# Generated at 2022-06-11 14:12:14.821328
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'/') == u'%2F'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo,bar') == u'foo%2Cbar'
    assert do_urlencode(u'foo;bar') == u'foo%3Bbar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'foo@bar') == u'foo%40bar'

# Generated at 2022-06-11 14:12:20.958910
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo+bar') == u'foo+bar'
    assert unicode_urldecode(u'foo%2A+bar') == u'foo* bar'
    assert unicode_urldecode(u'foo%2A+bar%3Dbaz') == u'foo* bar=baz'


# Generated at 2022-06-11 14:12:32.570728
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'%23') == u'#'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2f') == u'/'
    assert unicode_urldecode(u'%') == u'%'
    if PY3 is False:
        assert unicode_urldecode(u'%2b') == u'+'
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'abc%2faa') == u'abc/aa'
    assert unicode_urldecode(u'abc+') == u

# Generated at 2022-06-11 14:12:37.982235
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['urldecode'] == do_urldecode
    assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:12:42.462383
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert do_urldecode == filters['urldecode']
    if not HAS_URLENCODE:
        assert do_urlencode == filters['urlencode']
    else:
        assert 'urlencode' not in filters



# Generated at 2022-06-11 14:12:44.983616
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%C3%A8') == 'è'
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('è') == '%C3%A8'

# Generated at 2022-06-11 14:12:49.118178
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filtermodule_filters_dict = filtermodule.filters()
    assert 'urldecode' in filtermodule_filters_dict
    if not HAS_URLENCODE:
        assert 'urlencode' in filtermodule_filters_dict
    else:
        assert 'urlencode' not in filtermodule_filters_dict


# Generated at 2022-06-11 14:12:55.362128
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # This test does not cover utf-8 encoded strings due to limitations in
    # Python2.x's unquote() function.
    assert unicode_urldecode('hello+world') == u'hello world'
    assert unicode_urldecode('hello%20world') == u'hello world'
    assert unicode_urldecode('hello+world%20') == u'hello world '
    assert unicode_urldecode(42) == u'42'


# Generated at 2022-06-11 14:12:59.162818
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test unicode_urldecode filter '''
    test_data = u'openstack%2Fsix%3D1.4.1'
    expected_result = u'openstack/six=1.4.1'
    assert unicode_urldecode(test_data) == expected_result

# Generated at 2022-06-11 14:13:00.788848
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.run_docstring_examples(FilterModule.filters, globals())

# Generated at 2022-06-11 14:13:08.698176
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test that the urldecode filter behaves correctly
    fm = FilterModule()
    urldecode = fm.filters()['urldecode']
    assert urldecode('http%3A%2F%2Fwww.example.com') == 'http://www.example.com'
    assert urldecode('http%3A%2F%2Fwww.example.com%2F%E2%98%83') == "http://www.example.com/\u2603"

    if not HAS_URLENCODE:
        urlencode = fm.filters()['urlencode']
        assert urlencode('http://www.example.com') == 'http%3A%2F%2Fwww.example.com'

# Generated at 2022-06-11 14:13:12.325905
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' Test the function unicode_urldecode
    '''
    assert(unicode_urldecode('e%2F%2Fo+e') == 'e//o e')
    assert(unicode_urldecode('e%252F%252Fo%2Be') == 'e%2F%2Fo+e')

# Generated at 2022-06-11 14:13:21.586163
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('') == ''
    assert do_urlencode('1') == '1'
    assert do_urlencode('this & that') == 'this+%26+that'
    assert do_urlencode('@=&') == '%40%3D%26'
    assert do_urlencode('one') == 'one'
    assert do_urlencode('one two') == 'one+two'
    assert do_urlencode(['one', 'two']) == 'one&two'
    assert do_urlencode({'key1': 'one', 'key2': 'two'}) == 'key1=one&key2=two'
    # Weirdest test case, I admit
    assert do_urlencode(set(['one', 'two'])) == 'two&one'
   

# Generated at 2022-06-11 14:13:37.393994
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2Fvar%2Fwww") == '/var/www'
    assert unicode_urldecode("%2Fvar%2Fwww%3Fa%3D1%26b%3D2") == '/var/www?a=1&b=2'
    assert unicode_urldecode("%2C%2Fvar%2Fwww%2C%3Fvar%3Dval3%3B%3E%20%3C%3Fphp%20echo%20%24val2%3B%20%3F%3E") == ',/var/www,?var=val3;>< <?php echo $val2; ?>'

# Generated at 2022-06-11 14:13:39.645913
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'%'
    expected = u'%25'
    actual = unicode_urlencode(string)
    assert expected == actual


# Generated at 2022-06-11 14:13:43.738124
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Ffoo%20bar%2F') == u'http://foo bar/'
    assert unicode_urldecode('http%3A%2F%2Ffoo%2F \u20ac') == u'http://foo/ \u20ac'


# Generated at 2022-06-11 14:13:46.738572
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_str = u'A ça marche'
    expected = u'A ça marche'

    assert unicode_urldecode(test_str) == expected



# Generated at 2022-06-11 14:13:57.673008
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # NOTE: To test, run this module as a standalone script
    #       $ python -m ansible.module_utils.urls
    #       (from the root directory of Ansible)

    import json
    import sys

    module = FilterModule()

    results = []

    if len(sys.argv) > 1:
        test_args = sys.argv[1:]

        try:
            results = [getattr(module.filters()[test_args[0]], '__call__')(*test_args[1:])]
        except KeyError:
            pass
    else:
        for filter_name, filter in iteritems(module.filters()):
            results.append(u'{0:<20}: {1}'.format(filter_name, filter(u'ABC test')))


# Generated at 2022-06-11 14:14:00.080126
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-11 14:14:02.789721
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode('%20') == u' '


# Generated at 2022-06-11 14:14:10.361542
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo=bar') == u'foo=bar'
    assert unicode_urldecode('foo+bar') == u'foo bar'
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('foo%C3%A9') == u'foo\xe9'
    assert unicode_urldecode('foo%2Bbar') == u'foo+bar'


# Generated at 2022-06-11 14:14:17.596022
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six import u
    assert u('abc%40def') == unicode_urldecode('abc%40def')
    assert u('abc*') == unicode_urldecode('abc*')
    assert u('abc@def') == unicode_urldecode('abc@def')
    assert u('a spaces') == unicode_urldecode('a spaces')
    assert u('a+spaces') == unicode_urldecode('a+spaces')
    assert u('a?spaces') == unicode_urldecode('a?spaces')
    assert u('a/spaces') == unicode_urldecode('a/spaces')


# Generated at 2022-06-11 14:14:19.903070
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    encoding_filter = FilterModule()
    assert(encoding_filter.filters())

# Generated at 2022-06-11 14:14:36.042555
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E4%BA%BA%E6%B0%91%E5%A4%A7%E7%9A%84%E7%94%B5%E8%84%91") == u"人民大的电脑"


# Generated at 2022-06-11 14:14:43.585044
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.utils.unsafe_proxy
    import ansible.module_utils.six.moves.urllib.parse
    import binascii
    f = FilterModule()
    data1 = b'\xc3\xab'
    if PY3:
        data1 = data1.decode('utf8')
    data2 = {'special': 'chars'}
    data3 = ['special:chars']
    for data in [data1, data2, data3]:
        assert f.filters()['urldecode'](data) == 'ë'
        assert f.filters()['urldecode'](f.filters()['urlencode'](data)) == 'ë'

# Generated at 2022-06-11 14:14:45.502068
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2F%2F+%2F%2F') == u'/// ///'


# Generated at 2022-06-11 14:14:54.633861
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:15:03.361374
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo/') == u'foo/'
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo+') == u'foo '
    assert unicode_urldecode(u'foo%20') == u'foo '
    assert unicode_urldecode(u'foo%2b') == u'foo+'
    assert unicode_urldecode(u'foo%252b') == u'foo%2b'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'

# Generated at 2022-06-11 14:15:13.940176
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import warnings
    warnings.filterwarnings("ignore", ".*", DeprecationWarning, ".*", )
    urlencode = do_urlencode
    urldecode = do_urldecode
    assert urldecode('%3C%3E%2F') == '<>/'
    assert urldecode('foo+%2B+bar%21') == 'foo + bar!'
    assert urldecode('%26%23123%3B') == '&#123;'
    assert urlencode('http://example.com') == 'http%3A//example.com'
    assert urlencode('http://example.com', True) == 'http%3A//example.com'
    assert urlencode('<>/') == '%3C%3E%2F'
    assert urlen

# Generated at 2022-06-11 14:15:17.592504
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule().filters()
    assert x['urldecode'] == do_urldecode
    assert x['urlencode'] == do_urlencode
    assert x['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:15:26.491263
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic
    from sys import version_info

    # Check that it does nothing unexpected with a simple string
    assert basic.unicode_urldecode('a test string') == 'a test string'
    assert basic.unicode_urldecode(to_text(b'a test string')) == 'a test string'

    # Check that it does nothing unexpected with a simple integer
    assert basic.unicode_urldecode(42) == 42

    # Check that it does nothing unexpected with a simple float
    if version_info[0] == 3:
        assert basic.unicode_urldecode(42.0) == 42.0
    else:
        assert basic.unicode_urldecode(42.0) == 42.0

    # Check that it does nothing unexpected with a simple float


# Generated at 2022-06-11 14:15:30.385865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Check urldecode
    assert do_urldecode('test%3Dtest%26test%3Dtest') == u'test=test&test=test'

    # Testing a function, but it is not used.
    # Check urlencode
    #assert do_urlencode({'test=test&test=test':'test'}) == u'test%3Dtest%26test%3Dtest=test'

# Generated at 2022-06-11 14:15:33.920146
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Fb%2Fc') == 'a/b/c'
    assert unicode_urldecode('a%2Fb%2Fc') == u'a/b/c'


# Generated at 2022-06-11 14:15:48.225089
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"/") == u"%2F"
    assert unicode_urlencode(u"/", for_qs=True) == u"%2F"



# Generated at 2022-06-11 14:15:50.381376
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }


# Generated at 2022-06-11 14:15:59.386303
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/path/to/file') == '/path/to/file'
    assert unicode_urlencode('/path/to/file', for_qs=True) == '/path/to/file'
    assert unicode_urlencode('abcd') == 'abcd'
    assert unicode_urlencode('abcd', for_qs=True) == 'abcd'
    assert unicode_urlencode('/abcd') == '/abcd'
    assert unicode_urlencode('/abcd', for_qs=True) == '/abcd'
    assert unicode_urlencode('ab/cd') == 'ab/cd'
    assert unicode_urlencode('ab/cd', for_qs=True) == 'ab%2Fcd'

# Generated at 2022-06-11 14:16:09.398928
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # NOTE: We use the following bytes string for the tests
    b_str_raw = b'a%2Fb'
    assert unicode_urldecode(b_str_raw) == u'a/b'
    b_str_raw = b'a%2Bb'
    assert unicode_urldecode(b_str_raw) == u'a+b'
    b_str_raw = b'a%25b'
    assert unicode_urldecode(b_str_raw) == u'a%b'
    b_str_raw = b'a%20b'
    assert unicode_urldecode(b_str_raw) == u'a b'
    b_str_raw = b'a%2fb'

# Generated at 2022-06-11 14:16:16.948174
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test decoding of ASCII string
    assert unicode_urldecode('hello%20world') == 'hello world'
    # Test decoding of unicode character
    assert unicode_urldecode('%E2%82%AC') == u'€'
    # Test decoding of unicode character followed by ASCII string
    assert unicode_urldecode('%E2%82%AC%20') == u'€ '
    # Test decoding of unicode character preceded by ASCII string
    assert unicode_urldecode('%20%E2%82%AC') == u' €'



# Generated at 2022-06-11 14:16:24.974163
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'key=') == u'key%3D'
    assert do_urlencode(u'foo bar') == u'foo%20bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'foo%20bar') == u'foo%20bar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo=bar') == u'foo%3Dbar'
    assert do_urlencode(u'foo&bar') == u'foo%26bar'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'

# Generated at 2022-06-11 14:16:34.756658
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:16:36.817014
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("/") == "%2F"
    # Assuming UTF-8 locale
    assert unicode_urlencode("\u20ac") == "%E2%82%AC"

# Generated at 2022-06-11 14:16:41.828978
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2F%20%3B') == '/ ;'
    assert do_urlencode({'foo': 'bar', 'baz': 'fuz'}) == 'foo=bar&baz=fuz'
    assert do_urlencode('foo bar fuz') == 'foo%20bar%20fuz'
    assert do_urlencode(['foo', 'bar', 'fuz']) == 'foo&bar&fuz'

# Generated at 2022-06-11 14:16:51.383764
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.common._collections_compat import Mapping
    assert unicode_urldecode('test%21') == 'test!'
    assert unicode_urldecode('test%20%21') == 'test !'
    assert unicode_urldecode('test%21%20') == 'test! '
    assert unicode_urldecode('%21test%20') == '!test '
    assert unicode_urldecode('%E2%82%AC') == u'\u20ac'
    assert unicode_urldecode('%F0%9D%8C%86') == u'\U0001D306'
    assert isinstance(unicode_urldecode('%F0%9D%8C%86'), string_types)
    assert unicode_

# Generated at 2022-06-11 14:17:22.792211
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'dávid') == 'd%C3%A1vid'
    assert unicode_urlencode(u'@dávid') == '%40d%C3%A1vid'
    assert unicode_urlencode(u'dávid', True) == 'd%C3%A1vid'
    assert unicode_urlencode(u'@dávid', True) == '%40d%C3%A1vid'
    assert unicode_urlencode('dávid') == 'd%C3%A1vid'
    assert unicode_urlencode('@dávid') == '%40d%C3%A1vid'
    assert unicode_urlencode('dávid', True) == 'd%C3%A1vid'
    assert unic

# Generated at 2022-06-11 14:17:29.891875
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('http%3A%2F%2Fwww.example.com%2F') == 'http://www.example.com/'
    assert FilterModule().filters()['urldecode']('http%3A%2F%2Fwww.example.com%3Fa%3D1%26b%3D2') == 'http://www.example.com?a=1&b=2'
    assert FilterModule().filters()['urldecode']('http%3A%2F%2Fwww.example.com%3Fa%3D1%26b%3D2%26c%3D%25') == 'http://www.example.com?a=1&b=2&c=%'

# Generated at 2022-06-11 14:17:32.093452
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%27') == u"'"
    assert isinstance(unicode_urldecode('%27'), unicode)


# Generated at 2022-06-11 14:17:38.267798
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert do_urldecode('%10%20') == u'%10%20'
    assert module.filters()['urldecode']('%10%20') == u'%10%20'
    assert do_urlencode('%10%20') == u'%2510%2520'
    if not HAS_URLENCODE:
        assert module.filters()['urlencode']('%10%20') == u'%2510%2520'



# Generated at 2022-06-11 14:17:44.634408
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Python 3
    if PY3:
        assert unicode_urldecode(u'%27%21%27') == u"'!'"
        assert unicode_urldecode(u'foo%3Dbar%26bar+%2B+baz') == u'foo=bar&bar + baz'
        assert unicode_urldecode(u'foo%3Dbar+%26+bar+%2B+baz') == u'foo=bar & bar + baz'
    else:
        assert unicode_urldecode(u'%27%21%27') == "'!'"
        assert unicode_urldecode(u'foo%3Dbar%26bar+%2B+baz') == 'foo=bar&bar + baz'

# Generated at 2022-06-11 14:17:47.616590
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%40b%2fc') == u'a@b/c'
    assert unicode_urldecode('a+b/c') == u'a+b/c'

# Generated at 2022-06-11 14:17:48.838796
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == ' '



# Generated at 2022-06-11 14:17:55.322865
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E3%81%82 %E3%81%84%E3%81%86%E3%81%88%E3%81%8A') == u'あ いうえお'
    assert unicode_urldecode('%C3%81%C3%82%C3%83%C3%84%C3%85%C3%86') == u'ÁÂÃÄÅÆ'
    assert unicode_urldecode('%41%42%43') == u'ABC'
    assert unicode_urldecode('%c3%a9') == u'é'



# Generated at 2022-06-11 14:17:57.590472
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('foo') == 'foo'
    assert FilterModule().filters()['urlencode']('foo') == 'foo'

# Generated at 2022-06-11 14:18:04.434868
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('c%41t') == u'cAt'
    assert unicode_urldecode('%61%6c%6f') == u'alo'
    assert unicode_urldecode('%2C') == u','
    assert unicode_urldecode('%20%21%22%23%24%25%26%27%28%29%2A') == u' !"#$%&\'()*'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3A%3B%3C%3D%3E%3F%40%5B%5C%5D%5E%5F%60') == u':;<=>?@[\\]^_`'
    assert unic

# Generated at 2022-06-11 14:18:32.639273
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc+xyz') == 'abc xyz'
    assert unicode_urldecode('abc%2Bxyz') == 'abc+xyz'
    assert unicode_urldecode('abc%2bxyz') == 'abc+xyz'



# Generated at 2022-06-11 14:18:35.170527
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%28%29') == u'()'
    assert unicode_urldecode('%2F%2F') == u'//'



# Generated at 2022-06-11 14:18:40.866333
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert filters['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in filters

# Generated at 2022-06-11 14:18:45.908562
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # NOTE: urldecode should not be needed, backslash is an escape character in Jinja2
    assert unicode_urldecode(u'a%20b%20c') == u'a b c'
    assert unicode_urldecode(u'a+b+c') == u'a+b+c'


# Generated at 2022-06-11 14:18:52.408934
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_native, to_text
    assert unicode_urldecode('a+%2B+b') == to_text(u'a+%2B+b')
    assert unicode_urldecode(b('a+%2B+b')) == u'a++b'
    assert unicode_urldecode(u'a+%2B+b') == u'a++b'
    assert unicode_urldecode(b('a+%2B+b')) == to_text(u'a++b')
    assert unicode_urldecode('a+%2B+b') == to_text(u'a++b')