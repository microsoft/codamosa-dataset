

# Generated at 2022-06-11 14:08:51.437556
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Setup target of test
    filtermodule = FilterModule()
    obj = filtermodule.filters()
    urldecode = obj['urldecode']
    assert isinstance(urldecode('dag'), str)



# Generated at 2022-06-11 14:09:02.506096
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('Café') == to_text(b'Caf%C3%A9')
    assert unicode_urlencode('Café', for_qs=True) == to_text(b'Caf%C3%A9')
    assert unicode_urlencode(dict(a=1, b=2)) == to_text(b'a=1&b=2')
    assert unicode_urlencode(['a=1', 'b=2']) == to_text(b'a%3D1&b%3D2')
    assert unicode_urlencode('a+b') == to_text(b'a%2Bb')

# Generated at 2022-06-11 14:09:05.846896
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E4%B8%AD%E5%9B%BD') == u'中国'
    assert unicode_urldecode(u'\u4e2d\u56fd'.encode('utf-8')) == u'中国'


# Generated at 2022-06-11 14:09:17.585626
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"foo bar") == u"foo%20bar"
    assert unicode_urlencode(u"foo/bar") == u"foo%2Fbar"
    assert unicode_urlencode(u"foo bar", True) == u"foo+bar"
    assert unicode_urlencode(u"foo=bar", True) == u"foo%3Dbar"
    assert unicode_urlencode(u"foo bar", True) == u"foo+bar"
    assert unicode_urlencode(u"foo&bar", True) == u"foo%26bar"
    assert unicode_urlencode(u"foo+bar", True) == u"foo%2Bbar"

# Generated at 2022-06-11 14:09:18.665406
# Unit test for function do_urlencode
def test_do_urlencode():
    assert 'n%3Dp%26s%3D1' == do_urlencode({'n':'p','s':1})

# Generated at 2022-06-11 14:09:23.498311
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"http://www.example.com/a%20b") == u'http://www.example.com/a b'
    assert unicode_urldecode(u"http://www.example.com/a+b") == u'http://www.example.com/a+b'


# Generated at 2022-06-11 14:09:32.595214
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:09:37.279909
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()["urldecode"] == do_urldecode
    if not HAS_URLENCODE:
        assert fm.filters()["urlencode"] == do_urlencode


# Generated at 2022-06-11 14:09:46.882735
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:09:49.363763
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%2F") == u"/"


# Generated at 2022-06-11 14:09:53.480861
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }

# Generated at 2022-06-11 14:09:58.113287
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%BC') == u'\u00fc'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%2F') != u'\u002f'

# Generated at 2022-06-11 14:10:01.451488
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+%20b') == 'a b'
    assert unicode_urldecode('a+b') == 'a+b'


# Generated at 2022-06-11 14:10:05.521055
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%20%3D%3F') == u'hello =?'
    assert unicode_urldecode(u'foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'


# Generated at 2022-06-11 14:10:07.566793
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode



# Generated at 2022-06-11 14:10:09.727228
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wieers') == u'dag wieers'



# Generated at 2022-06-11 14:10:15.345925
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc+def') == 'abc def'
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('abc%27def') == 'abc\'def'
    assert unicode_urldecode('abc%2Bdef') == 'abc+def'
    assert unicode_urldecode('%E3%81%82%E3%81%84%E3%81%86') == 'あいう'

# Generated at 2022-06-11 14:10:18.886131
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('abc') == do_urldecode('abc')
    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']('abc') == do_urlencode('abc')

# Generated at 2022-06-11 14:10:21.885071
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%40%23%24%25%5E%26') == '@#$%^&'


# Generated at 2022-06-11 14:10:25.916550
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Frandom.pages%3A8080%2Fpage%2F1') == 'http://random.pages:8080/page/1'
    assert unicode_urldecode('http://random.pages:8080/page/1') == 'http://random.pages:8080/page/1'


# Generated at 2022-06-11 14:10:31.321036
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2Fetc%2Fpasswd') == '/etc/passwd'
    assert unicode_urldecode('/etc/passwd') == '/etc/passwd'



# Generated at 2022-06-11 14:10:34.974938
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # urldecode
    assert 'foo bar' == do_urldecode('foo+bar'), 'urldecode() filter failed'
    # urlencode (only if Jinja2 is < 2.7)
    if not HAS_URLENCODE:
        assert '%2B' == do_urlencode('+'), 'urlencode() filter failed'
    return True

# Generated at 2022-06-11 14:10:37.442476
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urldecode' in filters


# Generated at 2022-06-11 14:10:41.013525
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('test%23%2B%2F%2C') == 'test#+,/,'
    assert do_urlencode('test#+,/,') == 'test%23%2B%2C%2F'

# Generated at 2022-06-11 14:10:42.221704
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-11 14:10:47.228762
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys

    if sys.version_info < (3, 0):
        assert unicode_urldecode('abc+%C3%A9f%3D%26%23%25') == u'abc éf=&#%'
    else:
        assert unicode_urldecode('abc+%C3%A9f%3D%26%23%25') == u'abc éf=&#%'



# Generated at 2022-06-11 14:10:56.949332
# Unit test for function do_urlencode
def test_do_urlencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo+bar') == 'foo%2Bbar'
    assert do_urlencode('foo@bar') == 'foo%40bar'
    assert do_urlencode('foo?bar') == 'foo%3Fbar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo&bar') == 'foo%26bar'
    assert do_urlencode(dict(foo='bar', hello='world')) == 'foo=bar&hello=world'

# Generated at 2022-06-11 14:11:03.914059
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json

    import pytest

    from ansible.module_utils.six import text_type

    testcases = [
        (u'http://www.example.com/a=b&b=c&c=d',
         u'http://www.example.com/a=b&b=c&c=d',
         {'urlencode': False}),
        (u'http://www.example.com/a=b&b=c&c=d',
         u'http://www.example.com/a=b&b=c&c=d',
         {'urlencode': True}),
    ]


# Generated at 2022-06-11 14:11:07.567456
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'].__name__ == 'do_urldecode'
    if not HAS_URLENCODE:
        assert filters['urlencode'].__name__ == 'do_urlencode'

# Generated at 2022-06-11 14:11:12.848109
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'http://\u20ac.com/?currency=\u20ac&amount=100'
    result = u'http%3A//%E2%82%AC.com/%3Fcurrency%3D%E2%82%AC%26amount%3D100'
    assert unicode_urlencode(string) == result


# Generated at 2022-06-11 14:11:22.761132
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/path?param=value') == u'/path?param=value'
    assert unicode_urlencode('/path?param=value', for_qs=True) == u'/path%3Fparam%3Dvalue'
    assert unicode_urlencode({'key': 'value'}) == u'key=value'
    assert unicode_urlencode({'key': 'value with spaces'}) == u'key=value+with+spaces'
    assert unicode_urlencode({'key': 'value+with+plus'}) == u'key=value%2Bwith%2Bplus'
    assert unicode_urlencode({'k1': 'v1', 'k2': 'v2'}) == u'k1=v1&k2=v2'
    assert unicode

# Generated at 2022-06-11 14:11:32.576352
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar') == u'foo bar'
    assert unicode_urldecode('/%7Econnolly/') == u'/~connolly/'
    assert unicode_urldecode('/%7econnolly/') == u'/~connolly/'
    assert unicode_urldecode('dr%C3%B6mtorp') == u'drömtorp'
    assert unicode_urldecode('dr%c3%b6mtorp') == u'drömtorp'
    assert unicode_urldecode('%E2%88%9E') == u'∞'
    assert unicode_urldecode('%e2%88%9e') == u'∞'
    assert unicode_urldecode

# Generated at 2022-06-11 14:11:42.477489
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Example from RFC 3986
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%3A') == ':'
    assert unicode_urldecode('%3a') == ':'
    assert unicode_urldecode('%2f') == '/'
    assert unicode_urldecode('%2F') == '/'
    assert unicode_urldecode('%41') == 'A'
    assert unicode_urldecode('%41%42') == 'AB'
    assert unicode_urldecode('%41%42%43') == 'ABC'
    assert unicode_urldecode('%41%42%43%44') == 'ABCD'

# Generated at 2022-06-11 14:11:46.252380
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Test method filters of class FilterModule'''
    from ansible.module_utils.jinja2.filters import FilterModule as class_FilterModule

    filters = class_FilterModule().filters()
    assert filters['urldecode'](u'test%20string') == u'test string'
    assert filters['urlencode'](u'test string') == u'test+string'

# Generated at 2022-06-11 14:11:49.910958
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['urldecode']("%2Fdecoded%2F") == '/decoded/'

    if not HAS_URLENCODE:
        assert filters['urlencode']("/encoded") == '%2Fencoded'

# Generated at 2022-06-11 14:11:54.461457
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys

    if PY3:
        string = 'F%C3%B6r%20vanliga%20anv%C3%A4ndare'
    else:
        string = string.decode('utf-8')
    assert unicode_urldecode(string) == 'För vanliga användare'



# Generated at 2022-06-11 14:12:03.918495
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    # urldecode - Decode URL-encoded strings
    assert filters['urldecode']('%3B') == do_urldecode('%3B')
    assert filters['urldecode']('%D0%B0%D1%81%D1%82%D0%B0') == do_urldecode('%D0%B0%D1%81%D1%82%D0%B0')
    assert filters['urldecode']('foo=bar;%E8%B6%85%E5%B8%82=%3B') == do_urldecode('foo=bar;%E8%B6%85%E5%B8%82=%3B')

# Generated at 2022-06-11 14:12:06.514278
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'] == do_urldecode


# Generated at 2022-06-11 14:12:08.237531
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == to_text(' ')



# Generated at 2022-06-11 14:12:19.058458
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if PY3:
        assert unicode_urlencode('abcd') == 'abcd'
        assert unicode_urlencode(' ') == '+'
        assert unicode_urlencode(' ') == '+'
        assert unicode_urlencode(' ') == '+'
        assert unicode_urlencode('~') == '~'
        assert unicode_urlencode('/') == '/'
        assert unicode_urlencode('abcd') == 'abcd'
        assert unicode_urlencode(' ') == '+'
        assert unicode_urlencode(' ') == '+'
        assert unicode_urlencode(' ') == '+'
        assert unicode_urlencode('~') == '~'

# Generated at 2022-06-11 14:12:30.984143
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    utf8_string = u'b\xe2r'
    utf8_string_bytes = utf8_string.encode('utf-8')
    utf8_string_quoted = quote_plus(utf8_string_bytes)

    assert unicode_urldecode(utf8_string_quoted) == utf8_string


# Generated at 2022-06-11 14:12:33.394704
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    a = u'abc%2Fdef'
    b = unicode_urldecode(a)
    assert b == u'abc/def'



# Generated at 2022-06-11 14:12:42.462671
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo', "Failed to decode foo"
    assert unicode_urldecode(u'foo+bar') == u'foo bar', "Failed to decode foo+bar"
    assert unicode_urldecode(u'foo%20bar') == u'foo bar', "Failed to decode foo bar"
    assert unicode_urldecode(u'f%C3%B8%C3%B8') == u'f\xf8\xf8', "Failed to decode føø"
    assert unicode_urldecode(u'f%2Bb%40r') == u'f+b@r', "Failed to decode f+b@r"

# Generated at 2022-06-11 14:12:44.939399
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    out = obj.filters()
    assert out['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert out['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:12:51.266695
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Unit test for method filters of class FilterModule.
    Test description:
        Test all methods of this class.
    Test condition:
        - FilterModule

    Test procedure:
        - Test object FilterModule:
            + Test whether FilterModule is a class
            + Test all methods of this class
                + Test method filters of class FilterModule
                    - Test condition: urlencode method doesn't exist.
                    - Test method filters of class FilterModule
                    - Test condition: urlencode method does exists.
                + Other methods of class FilterModule are tested implicitly
            
    Test result:
        -

    Notes:
        -
    """
    
    assert callable(FilterModule), "FilterModule is not a class"

    method_filters = FilterModule.filters()

# Generated at 2022-06-11 14:12:57.687973
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print('Testing unicode_urldecode')
    assert 'foo bar baz' == unicode_urldecode('foo+bar+baz')
    assert 'foo bar baz' == unicode_urldecode('foo%20bar%20baz')
    assert '1 2 3 4' == unicode_urldecode('1%202%203%204')
    assert '1 2 3 4' == unicode_urldecode('1+2+3+4')



# Generated at 2022-06-11 14:13:01.283776
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    testcases = [
        ('a+b', u'a b'),
        ('a%20b', u'a b'),
        ('a%2Bb', u'a+b'),
    ]

    for arg, expected in testcases:
        assert unicode_urldecode(arg) == expected



# Generated at 2022-06-11 14:13:03.292457
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode("value%2B1")
    assert result == "value+1"



# Generated at 2022-06-11 14:13:04.961620
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%9Cber') == u'\xf6'



# Generated at 2022-06-11 14:13:10.988393
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''Test correctly decodes ASCII characters'''
    assert unicode_urldecode('Hello') == 'Hello'
    assert unicode_urldecode('Hello+') == 'Hello+'
    assert unicode_urldecode('Hello+%2B') == 'Hello+%2B'
    assert unicode_urldecode('Hello+%2B%3D') == 'Hello+%2B%3D'
    assert unicode_urldecode('Hello+%2B%3D%26') == 'Hello+%2B%3D%26'
    assert unicode_urldecode('Hello+%2B%3D%26%20') == 'Hello+%2B%3D%26%20'

# Generated at 2022-06-11 14:13:24.723216
# Unit test for function do_urlencode
def test_do_urlencode():

    # Test dict input
    dict_value = {"a":"1", "b":"2", "c":"3"}
    exp_value = "a=1&b=2&c=3"
    assert do_urlencode(dict_value) == exp_value

    # Test tuple input
    tuple_value = ("a","1","b","2","c","3")
    assert do_urlencode(tuple_value) == exp_value

    # Test list input
    list_value = ["a","1","b","2","c","3"]
    assert do_urlencode(list_value) == exp_value

    # Test list of dict input
    listofdict_value = [{"a":"1", "b":"2", "c":"3"},{"a":"4", "b":"5", "c":"6"}]
    exp_value

# Generated at 2022-06-11 14:13:29.125561
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'你好'
    assert unicode_urlencode(string) == u'%E4%BD%A0%E5%A5%BD'
    assert unicode_urlencode(string, for_qs=True) == u'%E4%BD%A0%E5%A5%BD'


# Generated at 2022-06-11 14:13:35.155759
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u"This is a test" == unicode_urldecode("This%20is%20a%20test")

    assert u"This is a test" == unicode_urldecode("This+is+a+test")

    assert u"This is a test" == unicode_urldecode("This%20is%20a%20test", force=True)

    assert u"This is a test" == unicode_urldecode("This+is+a+test", force=True)


# Generated at 2022-06-11 14:13:40.628544
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("testing string") == "%27testing%20string%27"
    assert unicode_urlencode("testing string", for_qs=True) == "testing%20string"
    assert unicode_urlencode("testing string", for_qs=True) != "%27testing%20string%27"


# Generated at 2022-06-11 14:13:47.401768
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    to_str = str if PY3 else unicode
    assert do_urldecode(u'"abc"') == u'"abc"'
    assert do_urldecode(u'abc') == u'abc'
    assert do_urldecode(to_str(u'\xe2\x98\x83')) == to_str(u'\xe2\x98\x83')

    assert do_urlencode(u'"abc"') == u'"abc"'
    assert do_urlencode(u'abc') == u'abc'
    assert do_urlencode(to_str(u'\xe2\x98\x83')) == u'%E2%98%83'

    assert do_urlencode(u'abc ') == u'abc%20'
    assert do_urlencode

# Generated at 2022-06-11 14:13:52.276781
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['urldecode'](b'a+b%2Cc') == u'a b,c'
    assert f.filters()['urldecode'](b'a+b%2Cc') == u'a b,c'


# Generated at 2022-06-11 14:14:01.915577
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test basic case
    assert 'test:test' == unicode_urldecode('test:test')

    # test no-op case
    assert 'test%3Atest' == unicode_urldecode('test%3Atest')

    # test urlsplit
    assert 'test:test' == unicode_urldecode('test:test')

    # test encoded % chars in the value
    assert 'test:%25test' == unicode_urldecode('test:%25test')

    # test encoded % chars in the key
    assert 'test%25:test' == unicode_urldecode('test%25:test')

    # test encoded : chars in the value
    assert 'test:test%253Atest' == unicode_urldecode('test:test%253Atest')

   

# Generated at 2022-06-11 14:14:08.192241
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("abc") == "abc"
    assert unicode_urlencode("abc def") == "abc%20def"
    assert unicode_urlencode("abc def", for_qs=True) == "abc+def"
    assert unicode_urlencode(u"abc def") == "abc%20def"


# Generated at 2022-06-11 14:14:16.489577
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    cases = [
        ('', ''),
        ('foo', 'foo'),
        ('%20', ' '),
        ('+', ' '),
        (' ', ' '),
        ('foo+bar', 'foo bar'),
        ('%20+%20', '  '),
        ('%2520', '%20'),
        ('f%2520', 'f%20'),
        ('%2520b', '%20b'),
        ('f%2520b', 'f%20b'),
        ('foo%20bar', 'foo bar'),
        ('foo+bar', 'foo bar'),
        ('foo%20+bar', 'foo  bar'),
        ('foo%20+%20bar', 'foo   bar'),
        ('foo%2Bbar', 'foo+bar'),
    ]
    for case in cases:
        assert case

# Generated at 2022-06-11 14:14:21.240897
# Unit test for function do_urlencode
def test_do_urlencode():
    string = 'abc%20def'
    encoded = 'abc+def'
    assert do_urlencode(string) == encoded
    assert unicode_urlencode(string, for_qs=True) == encoded
    assert do_urldecode(encoded) == string
    assert unicode_urldecode(encoded) == string

# Generated at 2022-06-11 14:14:31.686163
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert '|urldecode' in repr(f.filters()['urldecode'])
    if not HAS_URLENCODE:
        assert '|urlencode' in repr(f.filters()['urlencode'])



# Generated at 2022-06-11 14:14:37.892878
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('utf8:Hãllo Wörld!') == 'utf8%3AH%C3%A3llo%20W%C3%B6rld%21'
    assert unicode_urlencode('utf8:Hãllo Wörld!', for_qs=True) == 'utf8%3AH%C3%A3llo+W%C3%B6rld%21'

# Generated at 2022-06-11 14:14:41.378139
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:14:51.732819
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six import PY3

    testcases = [
        ('%20', ' '),
        ('%0A', '\n'),
        ('foo+', 'foo '),
        ('foo+bar', 'foo bar'),
        ('foo%26bar', 'foo&bar'),
        ('foo%3Debar', 'foo=bar'),
        ('foo%3db%26ar', 'foo=b&ar'),
        ('foo+bar%26baz%3Dxyzzy', 'foo bar&baz=xyzzy'),
    ]
    if PY3:
        testcases.append(('%E2%80%93', '–'))
    else:
        testcases.append(('%E2%80%93', u'\u2013'))


# Generated at 2022-06-11 14:14:56.320877
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm_filters = fm.filters()

    # Test urldecode filter
    assert fm_filters['urldecode']('http%3A%2F%2Fdocs.ansible.com%2F') == 'http://docs.ansible.com/'

    # Test urlencode filter
    assert fm_filters['urlencode']('http://docs.ansible.com/') == 'http%3A%2F%2Fdocs.ansible.com%2F'

# Generated at 2022-06-11 14:15:04.148268
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # test_unicode_urldecode has to be in the same file as unicode_urldecode
    # This does not work in ansible.module_utils.basic

    # simple test
    assert u'Caf\xe9 R\xe9mi' == unicode_urldecode(u'Caf%c3%a9%20R%c3%a9mi')

    # test with an encoding problem
    assert u'Caf\ufffd R\xe9mi' == unicode_urldecode(u'Caf%c3%e9%20R%c3%a9mi')

    # test with a decoding problem
    assert u'CafÃ© RÃ©mi' == unicode_urldecode(u'Caf%C3%A9%20R%C3%A9mi')

# Generated at 2022-06-11 14:15:05.437261
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass



# Generated at 2022-06-11 14:15:16.206660
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus, quote_plus
    from ansible.module_utils._text import to_text, to_bytes
    class TestFilterModule(object):
        def filters(self):
            filters = {
                'urldecode': do_urldecode,
            }

            return filters
    test_FilterModule_instance = TestFilterModule()

# Generated at 2022-06-11 14:15:20.030011
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result = FilterModule.filters(FilterModule())
    assert result['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode

# Unit tests for method unicode_urldecode of class FilterModule

# Generated at 2022-06-11 14:15:28.470685
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    for for_qs in [False, True]:
        assert unicode_urlencode('', for_qs=for_qs) == u''
        assert unicode_urlencode('/', for_qs=for_qs) == u'/'
        assert unicode_urlencode('/a', for_qs=for_qs) == u'/a'
        assert unicode_urlencode('/a/', for_qs=for_qs) == u'/a/'
        assert unicode_urlencode('a', for_qs=for_qs) == u'a'
        assert unicode_urlencode('/a/a', for_qs=for_qs) == u'/a/a'
        assert unicode_urlencode('/a/a/', for_qs=for_qs) == u'/a/a/'


# Generated at 2022-06-11 14:15:45.756536
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'spam') == u'spam'
    assert unicode_urlencode(u'spam spam') == u'spam%20spam'
    assert unicode_urlencode(u'spam spam', for_qs=True) == u'spam+spam'
    assert unicode_urlencode(u'spam/spam') == u'spam/spam'
    assert unicode_urlencode(u'spam/spam', for_qs=True) == u'spam%2Fspam'
    assert unicode_urlencode(['spam', 'spam']) == u'spam&spam'

# Generated at 2022-06-11 14:15:55.157611
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # The following non-ascii characters were selected because they are
    # valid unicode but are not percent encoded by urlencode.
    non_ascii_chars = ['困', '叾', 'ﺏ', 'ﺹ', '髙', '趙']

    # The following ascii chars are unsafe but not encoded by urlencode
    ascii_unsafe_chars = [' ', '"', "'", '<', '>', '`']

    input_chars = non_ascii_chars + ascii_unsafe_chars
    input_string = ''.join(input_chars)


# Generated at 2022-06-11 14:15:57.182516
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2Fhome%2Fdag') == u'/home/dag'



# Generated at 2022-06-11 14:16:01.997785
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo / bar') == u'foo%20/%20bar'
    assert unicode_urlencode(u'foo / bar', for_qs=True) == u'foo+%2F+bar'
    assert unicode_urlencode(u'foo:bar') == u'foo%3Abar'


# Generated at 2022-06-11 14:16:04.853571
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%85sterg%C3%B6tland') == u'\xc3\x85sterg\xc3\xb6tland'



# Generated at 2022-06-11 14:16:11.031389
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode('@') == '%40')
    assert(unicode_urlencode('-') == '-')
    assert(unicode_urlencode('/') == '%2F')
    assert(unicode_urlencode('_') == '_')
    assert(unicode_urlencode(' ') == '%20')
    assert(unicode_urlencode('hello') == 'hello')


# Generated at 2022-06-11 14:16:14.014649
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('hello%20world') == u'hello world'
    assert unicode_urldecode('hello+world') == u'hello world'
    assert unicode_urldecode('hello%20world%21') == u'hello world!'



# Generated at 2022-06-11 14:16:15.895454
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'\u00e9'

# Generated at 2022-06-11 14:16:19.833651
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'


# Generated at 2022-06-11 14:16:28.838606
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Unit test for function unicode_urlencode
    '''

    assert unicode_urlencode(u"foo") == u"foo"
    assert unicode_urlencode(u"föö") == u"f%C3%B6%C3%B6"
    assert unicode_urlencode(u"föö/bär") == u"f%C3%B6%C3%B6/b%C3%A4r"
    assert unicode_urlencode(u"föö", True) == u"f%C3%B6%C3%B6"
    assert unicode_urlencode(u"föö bär") == u"f%C3%B6%C3%B6+b%C3%A4r"
   

# Generated at 2022-06-11 14:16:36.634531
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}

# Generated at 2022-06-11 14:16:43.966733
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('test') == u'test')
    assert(unicode_urldecode('a@b.com') == u'a@b.com')
    assert(unicode_urldecode('a:b') == u'a:b')
    assert(unicode_urldecode('a;b') == u'a;b')
    assert(unicode_urldecode('a&b') == u'a&b')
    assert(unicode_urldecode('a!b') == u'a!b')
    assert(unicode_urldecode('a,b') == u'a,b')
    assert(unicode_urldecode('a=b') == u'a=b')

# Generated at 2022-06-11 14:16:46.508650
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_module = FilterModule()
    assert ansible_module.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode
    }

# Generated at 2022-06-11 14:16:49.999324
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    d = f.filters()
    assert d['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert d['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:16:53.762018
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    result = module.filters()
    assert result['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode

test_FilterModule_filters()

# Generated at 2022-06-11 14:16:57.029398
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode(u'/') == u'/'
    assert unicode_urlencode(u'/') == u'/'

# Generated at 2022-06-11 14:17:00.714227
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import ansible.module_utils.basic as basic
    (is_fail, summary, exception) = basic.run_unit_test(FilterModule, dict(ANSIBLE_MODULE_ARGS='unicode_urldecode'))
    if is_fail:
        print(summary)
        raise exception

# Generated at 2022-06-11 14:17:06.113283
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # NOTE: We want to make sure that urldecode works with text input
    # and when Jinja2 2.7 is not available, we test our own implementation
    value = u'/a/b/c/d'
    assert unicode_urldecode(value) == value
    assert unicode_urldecode(do_urlencode(value)) == value


# Generated at 2022-06-11 14:17:14.868899
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('foo+bar%20baz') == 'foo bar baz'
    assert do_urldecode('foo+bar-baz') == 'foo bar-baz'
    assert do_urldecode('foo%01bar') == 'foo\x01bar'
    assert do_urldecode('%7B%22foo%22%3A%20%22bar%22%7D') == '{"foo": "bar"}'

    assert do_urlencode('foo bar') == 'foo+bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'
    assert do_urlencode('foo%bar') == 'foo%25bar'
    assert do_urlencode('foo^bar') == 'foo%5Ebar'
    assert do_url

# Generated at 2022-06-11 14:17:21.226353
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode('T%C3%A4nk-%20%C3%A5t-%2C-b%C3%A4ste') == 'Tänk- åt-, bäste'
    else:
        assert unicode_urldecode('T%C3%A4nk-%20%C3%A5t-%2C-b%C3%A4ste') == u'Tänk- åt-, bäste'


# Generated at 2022-06-11 14:17:37.328816
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo+bar') == 'foo bar'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo%25bar') == 'foo%bar'



# Generated at 2022-06-11 14:17:39.579106
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'](u'%F6') == u'ö'



# Generated at 2022-06-11 14:17:45.383302
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.compat.tests import unittest

    class FilterModuleTestCase(unittest.TestCase):

        def test_urldecode(self):
            test = FilterModule()

            self.assertEqual(test.filters()['urldecode']('%3d%3D'), '==')
            self.assertEqual(test.filters()['urldecode']('%3d%3d'), '==')

    unittest.main(verbosity=0)


# Generated at 2022-06-11 14:17:54.436242
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'M\u00f6nchengladbach') == u'M%C3%B6nchengladbach'
    assert unicode_urlencode(u'/M\u00f6nchengladbach/') == u'/M%C3%B6nchengladbach/'
    assert unicode_urlencode(u'/M\u00f6nchengladbach/?id=12&name=foo') == u'/M%C3%B6nchengladbach/?id=12&name=foo'
    assert unicode_urlencode(u'M\u00f6nchengladbach', for_qs=True) == u'M%C3%B6nchengladbach'

# Generated at 2022-06-11 14:17:58.906135
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb') == 'a+b'
    assert unicode_urldecode('a%20b') == 'a b'
    assert unicode_urldecode(u'a%2Bb') == 'a+b'
    assert unicode_urldecode(u'a%20b') == 'a b'


# Generated at 2022-06-11 14:18:00.395694
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%B6') == u'ö'



# Generated at 2022-06-11 14:18:09.351425
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E6%B5%8B%E8%AF%95") == u'测试'

    assert unicode_urldecode("%E6%B5%8B%E8%AF%95%20%E6%B5%8B%E8%AF%95") == u'测试 测试'

    assert unicode_urldecode("%3B") == u';'

    assert unicode_urldecode("%2F") == u'/'

    assert unicode_urldecode("%2A") == u'*'

    assert unicode_urldecode("%26") == u'&'

    assert unicode_urldecode("%25") == u'%'

    assert unicode_urldec

# Generated at 2022-06-11 14:18:14.953331
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abcd efg %') == 'abcd%20efg%20%25'
    assert do_urlencode({'k1': 'abcd efg %', 'k2': 'hij'}) == 'k1=abcd%20efg%20%25&k2=hij'
    assert do_urlencode('abcd efg %') == 'abcd%20efg%20%25'
    assert do_urlencode({'k1': 'abcd efg %'}) == 'k1=abcd%20efg%20%25'

# Generated at 2022-06-11 14:18:24.370306
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Non-dictionary test
    assert unicode_urlencode(u'http://\u043f\u0440\u0438\u043c\u0435\u0440') == 'http%3A//%D0%BF%D1%80%D0%B8%D0%BC%D0%B5%D1%80'
    assert unicode_urlencode(u'http://\u043f\u0440\u0438\u043c\u0435\u0440', for_qs=True) == 'http%3A//%D0%BF%D1%80%D0%B8%D0%BC%D0%B5%D1%80'

    # Dictionary test

# Generated at 2022-06-11 14:18:33.914888
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    u = u'http://example.com/@blah/föö/bär?f=baz&f=baz&späm=egß'
    s = u.encode('utf-8')
    assert unicode_urlencode(u) == u
    assert unicode_urlencode(s) == u
    assert unicode_urlencode(u, for_qs=True) == u'http%3A%2F%2Fexample.com%2F%40blah%2Ff%C3%B6%C3%B6%2Fb%C3%A4r%3Ff%3Dbaz%26f%3Dbaz%26sp%C3%A4m%3Deg%C3%9F'



# Generated at 2022-06-11 14:18:48.642446
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"éé") == u'%C3%A9%C3%A9'
    assert unicode_urlencode(u"éé", for_qs=True) == u'%C3%A9%C3%A9'
