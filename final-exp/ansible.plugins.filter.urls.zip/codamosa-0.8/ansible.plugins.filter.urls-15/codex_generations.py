

# Generated at 2022-06-11 14:08:53.335602
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    sys.path.append('../lib/')

    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode']('foo') == unicode_urldecode('foo')

    if not HAS_URLENCODE:
        assert filters['urlencode']('foo') == unicode_urlencode('foo')

# Generated at 2022-06-11 14:09:02.220977
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(42) == u'42'
    assert do_urlencode('@') == u'%40'
    assert do_urlencode('a=b&c=d') == u'a%3Db%26c%3Dd'
    assert do_urlencode(('a', 'b')) == u'a=b'
    assert do_urlencode({'a': 'b', 'c': 'd'}) == u'a=b&c=d'
    assert do_urldecode('a%3Db%26c%3Dd') == u'a=b&c=d'

# Generated at 2022-06-11 14:09:08.915484
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'lol%20lmao') == u'lol lmao'
    assert unicode_urldecode(u'lol+lmao') == u'lol lmao'
    assert unicode_urldecode(u'lol+lmao%21') == u'lol lmao!'
    assert unicode_urldecode(u'lol+%25+lmao') == u'lol % lmao'
    assert unicode_urldecode(u'lol+%253F+lmao') == u'lol %3F lmao'
    assert unicode_urldecode(u'lol%2B%2Blmao') == u'lol++lmao'



# Generated at 2022-06-11 14:09:13.909866
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('foo') == 'foo'
    assert fm.filters()['urldecode']('foo%20bar') == 'foo bar'
    assert fm.filters()['urldecode']('foo+bar') == 'foo bar'
    assert fm.filters()['urldecode']('%7B%22foo%22%3A+%22bar%22%7D') == '{"foo": "bar"}'

    if HAS_URLENCODE:
        assert fm.filters()['urlencode']('foo') == 'foo'
        assert fm.filters()['urlencode']('foo bar') == 'foo+bar'

# Generated at 2022-06-11 14:09:21.980055
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    for name, filter in iter(filters.items()):
        val = 'my first filter'
        if name == 'urlencode':
            val = 'my first filter'
            filter_val = filter(val)
            assert filter_val == 'my+first+filter'
        if name == 'urldecode':
            val = 'my%20first%20test'
            filter_val = filter(val)
            assert filter_val == 'my first test'

test_FilterModule_filters()

# Generated at 2022-06-11 14:09:22.916404
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    unicode_urldecode("a%20b") == "a b"


# Generated at 2022-06-11 14:09:32.229194
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test function unicode_urldecode

    >>> test_unicode_urldecode()
    True
    '''
    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%23') == '#'
    assert unicode_urldecode('%24') == '$'
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%27') == "'"
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%3C') == '<'
    assert unicode_urldecode('%3E') == '>'
   

# Generated at 2022-06-11 14:09:43.548784
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_plugin = FilterModule()

    assert filter_plugin.filters()['urldecode'].__name__ == 'do_urldecode'

    if not HAS_URLENCODE:
        assert filter_plugin.filters()['urlencode'].__name__ == 'do_urlencode'

    assert filter_plugin.filters()['urldecode']('c%7Cd') == 'c|d'

    if not HAS_URLENCODE:
        assert filter_plugin.filters()['urlencode']({'a': 'b'}) == 'a=b'
        assert filter_plugin.filters()['urlencode']({'a': 'b', 'c': 'd'}) == 'a=b&c=d'


# Generated at 2022-06-11 14:09:48.957440
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    ansible_filter = FilterModule()
    result = ansible_filter.filters()

    assert 'urldecode' in result
    assert 'urlencode' in result

    if not HAS_URLENCODE:
        assert result['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:09:53.872407
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule)['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert FilterModule.filters(FilterModule)['urlencode'] == do_urlencode
    else:
        assert FilterModule.filters(FilterModule)['urlencode'] == do_urlencode.jinja2



# Generated at 2022-06-11 14:10:01.823908
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%C3%A9') == u'é'
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9') == u'é'

# ===

# Generated at 2022-06-11 14:10:03.529760
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%BC') == u'ü'


# Generated at 2022-06-11 14:10:08.380919
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    a = u'%C3%A1%20%23%24%25%5E%26*%28%29%21.'
    b = u'á #$%^&*()!. '
    assert unicode_urldecode(a) == b
    assert unicode_urldecode(b) == b



# Generated at 2022-06-11 14:10:10.209332
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    filters['urldecode']('foo')
    if not HAS_URLENCODE:
        filters['urlencode']('foo')

# Generated at 2022-06-11 14:10:19.216159
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common.collections import ImmutableDict
    fm = FilterModule()
    for filt, _ in fm.filters()[0].items():
        if filt == 'urldecode':
            assert(do_urldecode(u"%41%42%43") == u"ABC")
        if filt == 'urlencode':
            assert(do_urlencode(u"ABC")  == u"ABC")
            assert(do_urlencode(u"ABC <>")  == u"ABC%20%3C%3E")
            assert(do_urlencode(ImmutableDict([(u"ABC", u"<>")]))  == u"ABC=%3C%3E")

# Generated at 2022-06-11 14:10:27.639576
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a') == u'a'
    assert unicode_urldecode('A') == u'A'
    assert unicode_urldecode('aA') == u'aA'

    assert unicode_urldecode('a+') == u'a '
    assert unicode_urldecode('+a') == u' a'
    assert unicode_urldecode('a+a') == u'a a'
    assert unicode_urldecode('+a+') == u' a '
    assert unicode_urldecode('a+a+a') == u'a a a'
    assert unicode_urldecode('a+A') == u'a A'

# Generated at 2022-06-11 14:10:36.006705
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:10:39.530941
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    actual = FilterModule().filters()

    expected = dict()
    expected['urldecode'] = do_urldecode
    if not HAS_URLENCODE:
        expected['urlencode'] = do_urlencode

    assert actual == expected

# Generated at 2022-06-11 14:10:48.224135
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('this%20is%20my%20url') == u'this is my url'
    assert unicode_urldecode('this+is+my+url') == u'this is my url'
    assert unicode_urldecode('this%0ais%0Amy%0Aurl') == u'this\nis\nmy\nurl'
    assert unicode_urldecode('this%09is%09my%09url') == u'this\tis\tmy\turl'
    assert unicode_urldecode('this%0Dis%0Dmy%0Durl') == u'this\ris\rmy\rurl'

# Generated at 2022-06-11 14:10:56.683873
# Unit test for function do_urlencode
def test_do_urlencode():
    assert(do_urlencode('key=value') == 'key%3Dvalue')
    assert(do_urlencode('key=value&key=value') == 'key%3Dvalue%26key%3Dvalue')

    if HAS_URLENCODE:
        assert(do_urlencode({'key': ['value1', 'value2']}) == 'key=value1&key=value2')
        assert(do_urlencode(['key1=value1', 'key2=value2']) == 'key1%3Dvalue1&key2%3Dvalue2')

    assert(do_urlencode(u'key=value') == 'key%3Dvalue')


# Generated at 2022-06-11 14:11:02.742366
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'%C3%A9' == unicode_urlencode(to_text(b'\xc3\xa9', 'utf-8')) and not unicode_urlencode(to_text(b'\xc3\xa9', 'utf-8'), for_qs=True) == u'%C3%A9'


# Generated at 2022-06-11 14:11:09.633315
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('dag%40wieers.com') == u'dag@wieers.com'
    assert unicode_urldecode('%C3%B6') == u'ö'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%25') == u'%'


# Generated at 2022-06-11 14:11:11.861615
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    urldecode = unicode_urldecode
    assert urldecode('%C3%A9'), u'\u00e9'


# Generated at 2022-06-11 14:11:16.191342
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'ä'
    assert unicode_urldecode('%C3%A4%20%C3%B6%20%C3%BC%20') == u'ä ö ü '


# Generated at 2022-06-11 14:11:23.071153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.jinja2 import FilterModule

    FilterModule_filters_result = FilterModule.filters(FilterModule)
    assert type(FilterModule_filters_result) == dict
    assert 'urldecode' in FilterModule_filters_result.keys()
    if not HAS_URLENCODE:
        assert 'urlencode' in FilterModule_filters_result.keys()
    assert type(FilterModule_filters_result['urldecode']) == type(do_urldecode)
    if not HAS_URLENCODE:
        assert type(FilterModule_filters_result['urlencode']) == type(do_urlencode)
    assert FilterModule_filters_result['urldecode'] == do_urldecode

# Generated at 2022-06-11 14:11:32.842633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    with open('tests/units/ansible_collections/ansible/builtin/tests/fixtures/filter_module.yml') as unit_test_file:
        unit_test_yml = yaml.safe_load(unit_test_file)
        unit_test_data = unit_test_yml['unit_test_patterns']

    for key, value in unit_test_data.items():
        if key == 'unittest_data':
            continue
        if key == 'test_urlencode':
            if not HAS_URLENCODE:
                continue
        result = re.sub('FilterModule', '', key)
        result = result.lower()
        if value.get('input') is None:
            print('[INFO] Skipping test')
            continue

# Generated at 2022-06-11 14:11:35.879062
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%20b%20c') == u'a b c'


# Generated at 2022-06-11 14:11:40.129996
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode(u'hi+there') == u'hi there')
    assert(unicode_urldecode(u'20%3A%3F') == u'20:?')
    assert(unicode_urldecode('20%3A%3F') == u'20:?')



# Generated at 2022-06-11 14:11:47.484264
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Initialize FilterModule object
    filter_module = FilterModule()
    # Fetch all available filters
    all_filters = filter_module.filters()

    # Check if the filters are the right type
    assert isinstance(all_filters, dict)

    # Add all filters to the local globals() to simulate the environment
    # within the jinja2 templating engine
    for key, value in all_filters.items():
        globals()[key] = value

    # Test urlencode
    assert urlencode('key=value') == 'key%3Dvalue'
    assert urlencode(['key=value']) == 'key%3Dvalue'

    # Test urldecode
    assert urldecode('key%3Dvalue') == 'key=value'

# Generated at 2022-06-11 14:11:53.262337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert callable(filters['urldecode'])
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        assert callable(filters['urlencode'])
        assert filters['urlencode'] == do_urlencode
    return



# Generated at 2022-06-11 14:12:05.053186
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'%22abc', for_qs=True) == u'%2522abc'
    assert unicode_urlencode('%22abc', for_qs=True) == u'%2522abc'
    assert unicode_urlencode(b'%22abc', for_qs=True) == u'%2522abc'
    assert unicode_urlencode({1: 2}, for_qs=True) == u'1=2'
    assert unicode_urlencode({u'1': u'2'}, for_qs=True) == u'1=2'
    assert unicode_urlencode([(u'1', u'2')], for_qs=True) == u'1=2'

# Generated at 2022-06-11 14:12:16.327515
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_data = [
        (u'', b''),
        (u'☃', b'%E2%98%83'),
        (u'☃', b'%E2%98%83'),
        (u'\u2603', b'%E2%98%83'),
        (b'\xe2\x98\x83', b'%E2%98%83'),
        (b'\xe2\x98\x83', b'%E2%98%83'),
        (b'/', b'/'),
        (u'☃', b'+'),
        (u'\u2603', b'+'),
        (b'\xe2\x98\x83', b'+'),
        (b'/', b'/'),
    ]


# Generated at 2022-06-11 14:12:23.919257
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('foo') == u'foo'
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2c') == u','
    assert unicode_urldecode('%2C') == u','
    assert unicode_urldecode('%21') == u'!'

# Generated at 2022-06-11 14:12:29.090792
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u'foo bar' == unicode_urldecode('foo+bar')
    assert u'foo bar' == unicode_urldecode('foo%20bar')
    assert u'foo bar' == unicode_urldecode('foo%2bbar')



# Generated at 2022-06-11 14:12:38.026621
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'français') == u'fran%C3%A7ais'
    assert unicode_urlencode('français') == u'fran%C3%A7ais'
    assert unicode_urlencode(u'français', for_qs=True) == u'fran%C3%A7ais'
    assert unicode_urlencode('français', for_qs=True) == u'fran%C3%A7ais'
    assert unicode_urlencode(u'foo&bar') == u'foo%26bar'
    assert unicode_urlencode('foo&bar') == u'foo%26bar'

# Generated at 2022-06-11 14:12:43.507407
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u' ') == u' '
    assert unicode_urldecode(u'+') == u' '
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%2520') == u'%20'
    assert unicode_urldecode(u'%2B') == u'+'


# Generated at 2022-06-11 14:12:51.107389
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    test_data = {
        'urldecode': [
            ('foo%2Fbar', 'foo/bar'),
            ('foo%20bar', 'foo bar'),
            ('foo%25bar', 'foo%bar'),
        ],
        'urlencode': [
            # Invalid object
            (None, 'None'),
            (unicode_urlencode('foo/bar'), 'foo%2Fbar'),
            (unicode_urlencode('foo bar'), 'foo%20bar'),
            (unicode_urlencode('foo%bar'), 'foo%25bar'),
        ],
    }
    for name, funcs in fm.filters().items():
        for _input, expected_output in test_data.get(name):
            assert expected_output == funcs(_input)

# Generated at 2022-06-11 14:12:58.001585
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4%BD%A0%E5%A5%BD') == u'你好'
    assert unicode_urldecode('%e4%bd%a0%e5%a5%bd%2b%2f') == u'你好+/'
    assert unicode_urldecode(u'%e4%bd%a0%e5%a5%bd%2b%2f') == u'你好+/'


# Generated at 2022-06-11 14:13:00.590103
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert('urldecode' in filters)
    assert('urlencode' in filters)


# Generated at 2022-06-11 14:13:03.587866
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%2Fusr%2Fbin') == u'/usr/bin'
    assert unicode_urldecode(u'%E3%81%82') == u'\u3042'



# Generated at 2022-06-11 14:13:17.598361
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    def eq(a, b):
        return a == b

    # test method filters of class FilterModule
    m = FilterModule()
    # test jinja2 filters
    assert eq(m.filters()['urldecode']('x+y='), 'x y')
    assert eq(m.filters()['urldecode']('x%2B+y%2B='), 'x+ y+')
    assert eq(m.filters()['urlencode'](['a', 'b']), 'a=b')
    assert eq(m.filters()['urlencode']({'a':1, 'b':2}), 'a=1&b=2')
    assert eq(m.filters()['urlencode']('a b'), 'a+b')

# Generated at 2022-06-11 14:13:23.276084
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%2Fmy%2Fpath") == u"/my/path"
    assert unicode_urldecode("%2F%2") == u"//"
    assert unicode_urldecode("%2F%2F") == u"//"
    assert unicode_urldecode("%2F%252") == u"///"
    assert unicode_urldecode("%2F%252F") == u"///"


# Generated at 2022-06-11 14:13:26.064086
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    value = u'ansible+roles'
    result = unicode_urldecode(value)
    assert result == u'ansible roles'


# Generated at 2022-06-11 14:13:26.903028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule.filters()



# Generated at 2022-06-11 14:13:29.085157
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Red%20Fish%2C%20Blue%20Fish') == 'Red Fish, Blue Fish'



# Generated at 2022-06-11 14:13:38.889176
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_url = u'http://some.site.tld/foo/bar?a=1&b=2'

    assert unicode_urldecode(test_url) == test_url

    test_url = u'http://some.site.tld/foo/bar?a=1&b=2&a=2&foo=bar+bar&bar=foo+foo&foo=bar%20bar&bar=foo%20foo'
    expected_url = u'http://some.site.tld/foo/bar?a=1&b=2&a=2&foo=bar+bar&bar=foo+foo&foo=bar bar&bar=foo foo'

    assert unicode_urldecode(test_url) == expected_url



# Generated at 2022-06-11 14:13:42.930877
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Test method FilterModule_filters of class FilterModule.
    """
    filter_module = FilterModule()
    expected_result = {'urldecode': do_urldecode}

    result = filter_module.filters()
    assert result == expected_result



# Generated at 2022-06-11 14:13:50.588779
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcd') == u'abcd'
    assert unicode_urlencode(u'/abcd') == u'/abcd'
    assert unicode_urlencode(u'@abcd') == u'%40abcd'
    assert unicode_urlencode(u'@abcd', True) == u'%40abcd'
    assert unicode_urlencode(u'/ab%cd') == u'/ab%25cd'
    assert unicode_urlencode(u'/ab%cd') == u'/ab%25cd'



# Generated at 2022-06-11 14:13:54.460559
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2Fadmin%3Fid%3D1%26action%3Ddelete') == 'http://example.com/admin?id=1&action=delete'

# Generated at 2022-06-11 14:13:59.410766
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo bar') == u'foo bar'
    assert unicode_urldecode(u'%2F') == u'/'
    assert unicode_urldecode(u'%2F+%2F') == u'//'



# Generated at 2022-06-11 14:14:06.323322
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4') == u'\xe4'


# Generated at 2022-06-11 14:14:15.568515
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('c%3A%5CUsers%5Cmattb') == u'c:\\Users\\mattb'
    assert unicode_urldecode('+') == u' '
    assert unicode_urldecode('%21%23%24%25%26%27%28%29%2A%2B%2C%2D%2E%2F') == u'!#$%&\'()*+,-./'
    assert unicode_urldecode('%7B%7D') == u'{}'
    assert unicode_urldecode(u'c:\\Users\\mattb') == u'c:\\Users\\mattb'
    assert unicode_urldecode(u' ') == u' '
    assert unicode_urld

# Generated at 2022-06-11 14:14:21.939569
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7E') == '~'
    assert unicode_urldecode('%7e') == '~'
    assert unicode_urldecode('~') == '~'
    assert unicode_urldecode(u'%7E') == '~'
    assert unicode_urldecode(u'%7e') == '~'
    assert unicode_urldecode(u'~') == '~'


# Generated at 2022-06-11 14:14:31.150951
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"foo bar") == u'foo%20bar'
    assert unicode_urlencode(u"foo+bar") == u'foo%2Bbar'
    assert unicode_urlencode(u"foo%2fbar") == u'foo%252Fbar'

    assert unicode_urlencode(u"foo bar", for_qs=True) == u'foo+bar'
    assert unicode_urlencode(u"foo+bar", for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode(u"foo%2fbar", for_qs=True) == u'foo%2fbar'

    assert unicode_urlencode(u"foo 'bar'") == u'foo%20%27bar%27'
    assert unic

# Generated at 2022-06-11 14:14:41.705516
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    for for_qs in True, False:
        assert unicode_urlencode('abcd efgh', for_qs) == 'abcd%20efgh'
        assert unicode_urlencode('abcd/efgh', for_qs) == 'abcd%2Fefgh'
        assert unicode_urlencode('abcd?efgh', for_qs) == 'abcd%3Fefgh'
        assert unicode_urlencode(u'abcd efgh', for_qs) == 'abcd%20efgh'
        if PY3:
            assert type(unicode_urlencode('abcd efgh', for_qs)) == str
            assert type(unicode_urlencode(u'abcd efgh', for_qs)) == str

# Generated at 2022-06-11 14:14:51.886596
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('abc!') == 'abc%21'
    assert do_urlencode('abc!@#$') == 'abc%21%40%23%24'
    assert do_urlencode('abc 123') == 'abc+123'
    assert do_urlencode(u'\u2603') == '%E2%98%83'
    assert do_urlencode(u'\u2603!@#$') == '%E2%98%83%21%40%23%24'

    assert do_urlencode({'a': '1'}) == 'a=1'
    assert do_urlencode({'a': '1', 'b': '2'}) == 'a=1&b=2'
    assert do_url

# Generated at 2022-06-11 14:14:57.578863
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    # Check filters are not empty
    assert len(filters) > 0

    # Check urldecode filter
    assert filters['urldecode']('foo%20bar') == 'foo bar'

    # Check urlencode filter
    assert filters['urlencode']('foo bar') == 'foo+bar'
    assert filters['urlencode']('foo bar') != 'foo%2bbar'

# Generated at 2022-06-11 14:15:03.761888
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert u"abc" == unicode_urldecode(u"abc")
    assert u"abc" == unicode_urldecode(u"abc")
    assert u"a+b+c" == unicode_urldecode(u"a%2Bb%2Bc")
    assert u"a+b c" == unicode_urldecode(u"a+b+c")
    assert u"a b c" == unicode_urldecode(u"a+b+c")
    assert u"a b c" == unicode_urldecode(u"a%20b%20c")

# Generated at 2022-06-11 14:15:11.281777
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils import basic
    assert unicode_urldecode('a+b/c') == u'a b/c'
    assert unicode_urldecode('a+b%2Fc') == u'a b/c'
    assert unicode_urldecode('a b%2Fc') == u'a b/c'
    assert basic.to_text('a+b/c', nonstring='passthru') == u'a+b/c'


# Generated at 2022-06-11 14:15:14.149854
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    inStr = '?version%3D1%26type%3D2'
    outStr = unicode_urldecode(inStr)
    assert outStr == '?version=1&type=2'


# Generated at 2022-06-11 14:15:27.312489
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    string = "https%3A%2F%2Fjira.example.com%2Fbrowse%2FPROJECT"
    assert unicode_urldecode(string) == u'https://jira.example.com/browse/PROJECT'

# Generated at 2022-06-11 14:15:30.537943
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20%E4%BD%A0%E5%A5%BD') == u' 你好'
    assert unicode_urldecode('%20%E4%BD%A0%E5%A5%BD') != ' 你好'


# Generated at 2022-06-11 14:15:41.389958
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    import pytest
    from collections import namedtuple

    # Mock this module to avoid loading of urlencode filter
    sys.modules['jinja2.filters'] = namedtuple('module', ['do_urlencode'])(do_urlencode)
    os.environ['HAS_URLENCODE'] = 'False'

    fm = FilterModule()
    filters = fm.filters()

    # Assert that urldecode filter was loaded from this module
    assert 'urldecode' in filters
    assert filters['urldecode'] is not do_urlencode

    # Assert that urlencode filter was loaded from this module
    assert 'urlencode' in filters
    assert filters['urlencode'] is do_urlencode

# Generated at 2022-06-11 14:15:48.900010
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'test') == u'test'
    assert unicode_urlencode(u'test\u20ac') == u'test%E2%82%AC'
    assert unicode_urlencode(u'\u20ac') == u'%E2%82%AC'
    assert unicode_urlencode(u'test\u20ac', for_qs=True) == u'test%E2%82%AC'
    assert unicode_urlencode(u'test/', for_qs=True) == u'test%2F'
    assert unicode_urlencode(u'test/') == u'test%2F'
    assert unicode_urlencode(u'test', for_qs=True) == u'test'


# Generated at 2022-06-11 14:15:57.461992
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    # Default encoding for Python 2 is ASCII, which makes it hard to test
    # unicode strings.
    if sys.version_info[0] < 3:
        reload(sys)  # noqa
        sys.setdefaultencoding('utf-8')
        assert sys.getdefaultencoding() == 'utf-8'

    assert unicode_urldecode('%C3%A5') == u'å'
    assert unicode_urldecode('%C3%A5%C3%B8%C3%A6%C3%B8') == u'åøæø'
    assert unicode_urldecode('åøæø') == u'åøæø'



# Generated at 2022-06-11 14:16:03.117252
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert len('abc') == len(unicode_urldecode('abc'))
    assert len('河') == len(unicode_urldecode('河'))
    assert len(unicode_urldecode('%E6%B2%B3')) == len(unicode_urldecode('%e6%b2%b3'))
    assert len(unicode_urldecode('a=%E6%B2%B3')) == len(unicode_urldecode('a=%e6%b2%b3'))

# Generated at 2022-06-11 14:16:05.774918
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert type(filter_module) == FilterModule
    filters = filter_module.filters()

    assert type(filters) == dict


# Generated at 2022-06-11 14:16:16.081468
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo bar') == 'foo%20bar'
    assert unicode_urlencode('foo bar/') == 'foo%20bar%2F'
    assert unicode_urlencode('foo bar/', for_qs=True) == 'foo+bar%2F'
    assert unicode_urlencode('spam and eggs') == 'spam%20and%20eggs'
    assert unicode_urlencode('spam and eggs', for_qs=True) == 'spam+and+eggs'
    assert unicode_urlencode('foo bar?') == 'foo%20bar%3F'

# Generated at 2022-06-11 14:16:24.457172
# Unit test for function do_urlencode
def test_do_urlencode():
    import types
    test_string = 'k1=v1&k2=v2'
    result = do_urlencode(test_string)
    assert result == 'k1=v1%26k2%3Dv2', 'do_urlencode({}) should return "k1=v1%26k2%3Dv2"'.format(test_string)
    test_dict = {'k1': 'v1', 'k2': 'v2'}
    result = do_urlencode(test_dict)
    assert result == 'k1=v1&k2=v2', 'do_urlencode({}) should return k1=v1&k2=v2'.format(test_dict)
    test_list = ['k1=v1', 'k2=v2']
    result = do

# Generated at 2022-06-11 14:16:25.949998
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'dag%20wiers') == u'dag wiers'


# Generated at 2022-06-11 14:16:38.374335
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A1') == u'\u00e1'


# Generated at 2022-06-11 14:16:44.928751
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus, urlsplit, urlunsplit
    import codecs
    import random

    def to_unicode(x):
        if isinstance(x, string_types):
            return x
        if hasattr(x, '__unicode__'):
            return x.__unicode__()
        if hasattr(x, '__str__'):
            return x.__str__()
        return codecs.unicode_escape_decode(x)[0]

    # Test 1: characters 0-255, encoded in UTF-8
    s = [ chr(x) for x in range(255) ]
    r = to_unicode(unquote_plus(unicode_urlencode(''.join(s))))
    assert r

# Generated at 2022-06-11 14:16:48.255932
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%2F%C3%A9') == u'/é'.encode('utf-8').decode('utf-8')


# Generated at 2022-06-11 14:16:51.093423
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    for filter in fm.filters():
        assert filter in ['urldecode','urlencode']

# Generated at 2022-06-11 14:16:54.497842
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'dag&wieers') == u'dag%26wieers'
    assert unicode_urlencode(u'http://wieers.com/~dag/') == u'http%3A//wieers.com/~dag/'


# Generated at 2022-06-11 14:17:04.523037
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/path/to/file') == '/path/to/file'
    assert unicode_urlencode('/path to/file') == '/path%20to/file'
    assert unicode_urlencode('/path to/file', for_qs=True) == '/path%20to/file'
    assert unicode_urlencode('/path&to/file', for_qs=True) == '/path%26to/file'
    assert unicode_urlencode('/path=to/file', for_qs=True) == '/path%3Dto/file'
    assert unicode_urlencode({'key1': 'val1', 'key2': 'val2'}) == 'key1=val1&key2=val2'

# Generated at 2022-06-11 14:17:13.717625
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert unicode_urlencode(u'foo bar') == 'foo%20bar'
        assert unicode_urlencode('foo bar') == 'foo%20bar'
        assert unicode_urlencode(u'https://www.example.com/?foo=bar') == 'https%3A//www.example.com/%3Ffoo%3Dbar'
        assert unicode_urlencode('https://www.example.com/?foo=bar') == 'https%3A//www.example.com/%3Ffoo%3Dbar'
        assert unicode_urlencode(u'bar') == 'bar'
        assert unicode_urlencode('bar') == 'bar'

# Generated at 2022-06-11 14:17:15.090108
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'



# Generated at 2022-06-11 14:17:20.265388
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://éé.com/') == 'http%3A//%C3%A9%C3%A9.com/'
    assert unicode_urlencode(u'http://éé.com/', for_qs=True) == 'http%3A%2F%2F%C3%A9%C3%A9.com%2F'

# Generated at 2022-06-11 14:17:21.333313
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.testmod(FilterModule.filters)

# Generated at 2022-06-11 14:17:51.097172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo%3Abar') == u'foo:bar'
    assert unicode_urldecode(b'foo%3Abar') == u'foo:bar'
    assert unicode_urldecode(b'foo%3Abar'.decode('utf8')) == u'foo:bar'
    if PY3:  # pragma: no cover
        assert unicode_urldecode(b'foo%3Abar') == 'foo:bar'
        assert unicode_urldecode('foo%3Abar') == 'foo:bar'



# Generated at 2022-06-11 14:17:57.628461
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''
    Unit test for FilterModule filters() method

    Note that the test_urlencode_1(), test_urlencode_2(),
    test_urlencode_3(), test_urlencode_4() are taken
    from Jinja2 test_filters.py::test_urlencode()
    '''

    assert isinstance(FilterModule().filters(), dict) == True



# Generated at 2022-06-11 14:18:04.458793
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('c%3A%5C') == 'c:\\'
    assert do_urldecode('%25') == '%'
    assert do_urldecode('') == ''
    assert do_urldecode(None) == ''
    assert do_urldecode(1) == '1'

    assert do_urlencode('c:\\') == 'c%3A%5C'
    assert do_urlencode('c:\\\\') == 'c%3A%5C%5C'
    assert do_urlencode('%') == '%25'
    assert do_urlencode('abc') == 'abc'
    assert do_urlencode('') == ''
    assert do_urlencode(None) == ''

# Generated at 2022-06-11 14:18:06.604544
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%F6%E4%FC') == u'öäü'


# Generated at 2022-06-11 14:18:14.546580
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json

    fm = FilterModule()
    try:
        import jinja2.filters
        jinja2.filters.FILTERS['urldecode'] = do_urldecode
        if not HAS_URLENCODE:
            jinja2.filters.FILTERS['urlencode'] = do_urlencode
    except (ImportError, KeyError):
        pass

    # urldecode()
    inp = 'path%2Fto%2Ffile'
    out = do_urldecode(inp)
    if out != 'path/to/file':
        print("Error: urldecode() failed, expected 'path/to/file', got %s" % out)
        print("using input %s" % inp)

# Generated at 2022-06-11 14:18:20.116534
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%41%42%43') == u'ABC'
    assert unicode_urldecode('%090%09') == u'\t\t'
    assert unicode_urldecode('ABC') == u'ABC'
    assert unicode_urldecode(u'ABC') == u'ABC'



# Generated at 2022-06-11 14:18:27.167618
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('https%3A%2F%2Fwww.google.com%2F') == 'https://www.google.com/'
    assert unicode_urldecode('https%3A%2F%2Fwww.google.com%2F%3Ftest%3Dtest') == 'https://www.google.com/?test=test'
    assert unicode_urldecode('https%3A%2F%2Fwww.google.com%2F%3Ftest%3Dtest%26parameter2%3Dparameter2') == 'https://www.google.com/?test=test&parameter2=parameter2'

# Generated at 2022-06-11 14:18:36.484567
# Unit test for method filters of class FilterModule

# Generated at 2022-06-11 14:18:40.226920
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' urldecode filter with unicode input '''
    assert unicode_urldecode('abc123') == u'abc123'
    assert unicode_urldecode('%26%3D') == u'&='


# Generated at 2022-06-11 14:18:49.398852
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import assertCountEqual, PY3
    from ansible.module_utils._text import to_native
    if HAS_URLENCODE:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True

    filter_module = FilterModule()

    assert "foo" == filter_module.filters()['urldecode']("foo")
    assert "foo+bar" == filter_module.filters()['urldecode']("foo%2Bbar")

    assert "foo=bar" == filter_module.filters()['urlencode']("foo=bar")
    assert "foo=bar" == filter_module.filters()['urlencode']({'foo': 'bar'})

    # Only test that Jinja2 >= 2.7 has ur