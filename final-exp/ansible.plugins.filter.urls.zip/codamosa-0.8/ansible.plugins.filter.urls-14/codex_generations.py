

# Generated at 2022-06-11 14:08:55.151573
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == u'foo'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(b'foo+bar') == u'foo bar'
    assert unicode_urldecode(b'foo%20bar') == u'foo bar'
    assert unicode_urldecode(b'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode('foo+bar') == 'foo bar'

# Generated at 2022-06-11 14:09:00.021667
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'https://www.example.com/') == u'https://www.example.com/'
    assert unicode_urldecode(u'/index.php?action=view&name=foo+bar') == u'/index.php?action=view&name=foo bar'


# Generated at 2022-06-11 14:09:08.019851
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_bytes
    '''Test FilterModule filters.

    TestFilterModuleFilters() -> None
    '''
    f = FilterModule()
    filter_class = f.filters()

# Generated at 2022-06-11 14:09:14.520145
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:09:26.141317
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo bar') == u'foo bar'
    assert unicode_urldecode(u'foo+bar') == u'foo bar'
    assert unicode_urldecode(u'foo%20bar') == u'foo bar'
    assert unicode_urldecode(u'foo%2Qbar') == u'foo%2Qbar'
    assert unicode_urldecode(u'foo%2qbar') == u'foo%2qbar'
    assert unicode_urldecode(u'foo%2Zbar') == u'foo%2Zbar'
    assert unicode_urldecode(u'foo%2zbar') == u'foo%2zbar'
    assert unicode_urldecode(u'foo%2+bar')

# Generated at 2022-06-11 14:09:31.772463
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'%6C') == u'l'
    assert unicode_urldecode(u'%6C%6C') == u'll'
    assert unicode_urldecode(u'%6C+%6C+%6C') == u'l l l'
    assert unicode_urldecode(u'%6C%6C%6C') == u'lll'


# Generated at 2022-06-11 14:09:33.259447
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    s = FilterModule()
    assert s.filters()['urldecode'] == do_urldecode

# Generated at 2022-06-11 14:09:40.139342
# Unit test for function do_urlencode
def test_do_urlencode():
    ''' Test function do_urlencode '''
    # Initialize key variables
    test_dict = {
        u'foo': u'bar',
        u'baz': u'`1+2=3`',
    }

    # Test function
    result = do_urlencode(test_dict)
    expected_result = 'foo=bar&baz=%601%2B2%3D3%60'
    assert result == expected_result

# Generated at 2022-06-11 14:09:44.727786
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    my_filters = fm.filters()
    assert 'urldecode' in my_filters
    if not HAS_URLENCODE:
        assert 'urlencode' in my_filters
    assert len(my_filters) == 2


# Generated at 2022-06-11 14:09:53.388757
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'a%2Fb+%2Bc' == unicode_urlencode(u'a/b +c')
    assert u'a%2Fb+%2Bc' == unicode_urlencode(u'a/b +c', for_qs=True)
    assert u'a%2Fb+%2Bc' == unicode_urlencode('a/b +c')
    assert u'a%2Fb+%2Bc' == unicode_urlencode('a/b +c', for_qs=True)

# Generated at 2022-06-11 14:10:05.077005
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule().filters()
    assert x['urldecode']('dag%2C%20if%20you%27re%20happy%20and%20you%20know%20it%20then%20you%27re%20really%20a%20clam') == 'dag, if you\'re happy and you know it then you\'re really a clam'
    assert x['urldecode']('dag%2C%20if%20you%27re%20happy%20and%20you%20know%20it%20then%20you%27re%20really%20a%20clam') == 'dag, if you\'re happy and you know it then you\'re really a clam'

# Generated at 2022-06-11 14:10:09.546515
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    result = fm.filters()
    # NOTE: This is not intended behaviour to have urlencode in the filter function list
    assert result == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-11 14:10:15.012588
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six.moves import urllib
    assert unicode_urldecode('%3Csome%20text%3E') == u'<some text>'
    assert unicode_urldecode(urllib.parse.unquote_plus('%3Csome+text%3E')) == u'<some text>'
    assert unicode_urldecode(urllib.parse.unquote_plus('%3Csome text')) == u'<some text'

# Generated at 2022-06-11 14:10:17.434297
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # check if the dict returned by `FilterModule.filters()` is a dict
    assert(isinstance(FilterModule.filters(object()), dict))


# Generated at 2022-06-11 14:10:26.518718
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'foo%21bar' == unicode_urlencode(u'foo!bar')
    assert u'foo%21bar' == unicode_urlencode(u'foo!bar')
    assert u'foo%21bar' == unicode_urlencode(b'foo!bar')
    assert u'foo%21bar' == unicode_urlencode(b'foo!bar')
    assert u'foo%20bar' == unicode_urlencode(b'foo bar')
    assert u'foo%20bar' == unicode_urlencode(u'foo bar')
    assert u'foo%20bar' == unicode_urlencode(b'foo bar')
    assert u'foo%20bar' == unicode_urlencode(u'foo bar')

# Generated at 2022-06-11 14:10:31.111741
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"%21%40") == "!@"
    assert unicode_urldecode(u'%E6%97%A5%E6%9C%AC%E8%AA%9E') == u'日本語'

# Generated at 2022-06-11 14:10:33.528193
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7E') == u'~', 'unicode_urldecode failed to urldecode ~ character'  # noqa: F821



# Generated at 2022-06-11 14:10:43.829567
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/') == u'/'
    assert unicode_urlencode('//') == u'/%2F'
    assert unicode_urlencode('//', for_qs=True) == u'%2F%2F'
    assert unicode_urlencode(u'øæå€') == u'%C3%B8%C3%A6%C3%A5%E2%82%AC'
    assert unicode_urlencode({'key': 'value', 'foo': 'bar'}) == u'key=value&foo=bar'
    assert unicode_urlencode(['key=value', 'foo=bar']) == u'key%3Dvalue&foo%3Dbar'



# Generated at 2022-06-11 14:10:45.504836
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A9') == u'é'



# Generated at 2022-06-11 14:10:54.946481
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert ' ' == unicode_urldecode('+'), 'unescape-plus-sign'
    assert '=' == unicode_urldecode('%3d'), 'unescape-percent-encoded-3d'
    assert '%3D' == unicode_urldecode('%253D'), 'double-percent-encoded-3d'
    assert 'include:!#$&\'()*+,./:;=?@[]%' == unicode_urldecode('include:!%23$&\'()*%2b,./:;%3d?@[]%25'), 'query-with-reserved-characters'
    assert ' ' == unicode_urldecode('%2B'), 'unescape-percent-encoded-2b'
    assert u'\u0192' == unicode_urld

# Generated at 2022-06-11 14:11:02.201294
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("http://localhost/") == u"http://localhost/"
    assert unicode_urlencode("http://localhost/(") == u"http://localhost/%28"
    assert unicode_urlencode("http://localhost/(", True) == u"http://localhost/(".replace(" (", "%20(").replace("(", "%28").replace(")", "%29")

# Generated at 2022-06-11 14:11:06.757848
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode']('foo%20bar') == 'foo bar'

    if not HAS_URLENCODE:
        assert filters['urlencode']('foo bar') == 'foo%20bar'
        assert filters['urlencode']('foo bar') == do_urlencode('foo bar')



# Generated at 2022-06-11 14:11:08.100806
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2Ffoo') == '/foo'



# Generated at 2022-06-11 14:11:13.071346
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%2Bb=c%2Bd') == u'a+b=c+d'
    assert unicode_urldecode(u'a%C3%A9b=c%C3%A9d') == u'aéb=céd'



# Generated at 2022-06-11 14:11:17.139424
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%3F%3E%3D') == u'%3F%3E%3D'
    assert unicode_urldecode('%E2%80%93') == u'–'
    assert unicode_urldecode('%25') == u'%'

# Generated at 2022-06-11 14:11:23.482508
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('/var/run') == '/var/run'
    assert unicode_urlencode('/var/run/') == '/var/run/'
    assert unicode_urlencode('/var/run/httpd.pid') == '/var/run/httpd.pid'
    assert unicode_urlencode('/var/run/httpd.pid/') == '/var/run/httpd.pid/'
    assert unicode_urlencode('/var/run/httpd.pid/foo') == '/var/run/httpd.pid/foo'
    assert unicode_urlencode('/var/run/httpd.pid/foo/') == '/var/run/httpd.pid/foo/'

# Generated at 2022-06-11 14:11:26.991313
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('Hello%20World%21') == 'Hello World!'
    assert do_urlencode('Hello World!') == 'Hello%20World%21'

# Generated at 2022-06-11 14:11:36.690678
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    import pytest
    
    from ansible.module_utils.six.moves.urllib.parse import quote_plus, unquote_plus
    
    filter_module = FilterModule()
    filters = filter_module.filters()
    
    # test do_urldecode
    assert filters['urldecode']('+') == unquote_plus('+')
    
    # test do_urlencode
    assert filters['urlencode']('+') == quote_plus('+')
    
    # test do_urlencode when the argument is a dictionary
    assert filters['urlencode']({"A": "B"}) == "%s=%s" % ("A", "B")

# Generated at 2022-06-11 14:11:45.297942
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    # Test Python 2
    ispy2 = False
    ispy3 = False
    if PY3:
        ispy3 = True
    else:
        ispy2 = True

    # Test with bytes
    decode_test1 = unicode_urldecode(b"http%3A%2F%2F192.168.1.100%3A8080%2Fstatus.xml")
    assert decode_test1 == "http://192.168.1.100:8080/status.xml"

    # Test with unicode
    decode_test2 = unicode_urldecode("http%3A%2F%2F192.168.1.100%3A8080%2Fstatus.xml")
    assert decode_test2 == "http://192.168.1.100:8080/status.xml"

# Generated at 2022-06-11 14:11:53.949678
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcdef') == 'abcdef'
    assert unicode_urldecode('%40') == '@'
    assert unicode_urldecode('%23') == '#'
    assert unicode_urldecode('%26') == '&'
    assert unicode_urldecode('%24') == '$'
    assert unicode_urldecode('%21') == '!'
    assert unicode_urldecode('%2B') == '+'
    assert unicode_urldecode('%28') == '('
    assert unicode_urldecode('%29') == ')'
    assert unicode_urldecode('%2A') == '*'
    assert unicode_urldecode('%2F') == '/'
   

# Generated at 2022-06-11 14:12:01.156529
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # No need for double quoting in Python 3
    expected = u"éé" if PY3 else u"%C3%A9%C3%A9"
    assert unicode_urlencode(u"éé") == expected



# Generated at 2022-06-11 14:12:07.176224
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # We have to urlencode this because this string is not a valid Python
    # identifier
    assert unicode_urldecode('x%3D1') == 'x=1'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('hello%2C%20world%21') == 'hello, world!'
    assert unicode_urldecode('foo%252Fbar') == 'foo%2Fbar'
    assert unicode_urldecode('foo%25252Fbar') == 'foo%2Fbar'
    assert unicode_urldecode('%7E%24%26%2A%28%29%3D') == '~$&*()='

# Generated at 2022-06-11 14:12:18.085252
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%2F') == u'/'
    assert do_urldecode('%26') == u'&'
    assert do_urldecode('%25') == u'%'

    if not HAS_URLENCODE:
        assert do_urlencode(u' ') == '%20'
        assert do_urlencode(u'/') == '%2F'
        assert do_urlencode(u'&') == '%26'
        assert do_urlencode(u'%') == '%25'
        assert do_urlencode(u'foo?bar') == 'foo%3Fbar'
        assert do_urlencode(u'foo&bar') == 'foo%26bar'
       

# Generated at 2022-06-11 14:12:24.661515
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters

    assert do_urldecode(u'%20') == u' '
    assert do_urldecode(u'%7B%7D') == u'{}'

    assert do_urlencode(u' ') == u'%20'
    assert do_urlencode(u'{}') == u'%7B%7D'
    assert do_urlencode(dict(a=1, b=2)) == u'a=1&b=2'
    assert do_urlencode([(u'a', 1), (u'b', 2)]) == u'a=1&b=2'

# Generated at 2022-06-11 14:12:29.866158
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test unicode_urldecode
    string = 'Привет, how are you doing?'
    expected = u'Привет, how are you doing?'
    result = unicode_urldecode(string)
    assert expected == result



# Generated at 2022-06-11 14:12:35.059071
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('my+value') == 'my value'
    assert unicode_urldecode('my%20value') == 'my value'
    assert unicode_urldecode('%C3%A9') == u'é'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode('%2F') == '/'



# Generated at 2022-06-11 14:12:39.892161
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('https://docs.ansible.com/ansible/') == 'https%3A//docs.ansible.com/ansible/'
    assert unicode_urlencode('https://docs.ansible.com/ansible/', True) == 'https%3A%2F%2Fdocs.ansible.com%2Fansible%2F'


# Generated at 2022-06-11 14:12:48.661477
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Test cases from https://wiki.python.org/moin/EscapingHtml
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo%20bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo+bar', True) == u'foo%2Bbar'
    assert unicode_urlencode(u'foo bar', True) == u'foo+bar'

    # Additional test cases
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode

# Generated at 2022-06-11 14:12:54.540082
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u' € a b & c = d '
    expected = u'%20%E2%82%AC%20a%20b%20%26%20c%20%3D%20d%20'
    assert unicode_urlencode(string) == expected
    assert unicode_urlencode(string, for_qs=True) == '%20%E2%82%AC+a+b+%26+c+%3D+d+'


# Generated at 2022-06-11 14:13:01.605711
# Unit test for function do_urlencode
def test_do_urlencode():
    s = '@:+%'
    assert do_urlencode(s) == '%40%3A%2B%25'
    assert do_urldecode('%40%3A%2B%25') == s

    d = {'f': '&', 'b:': '='}
    assert do_urlencode(d) == 'b%3A=%3D&f=%26'

    l = [('f', '+'), ('b', '-')]
    assert do_urlencode(l) == 'b=%2D&f=%2B'

# Generated at 2022-06-11 14:13:06.510438
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%2F') == '/'


# Generated at 2022-06-11 14:13:14.157264
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import MutableMapping
    from jinja2.filters import do_urlencode
    from operator import methodcaller
    fm = FilterModule()
    filters = fm.filters()
    try:
        assert isinstance(filters, MutableMapping)
    except NameError:
        assert isinstance(filters, dict)
    assert len(filters) > 0
    assert set(filters.keys()) >= {
        'urldecode',
        'urlencode',
    }
    if HAS_URLENCODE:
        assert do_urlencode is filters['urlencode']

# Generated at 2022-06-11 14:13:21.546088
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"a%2Fb") == u"a/b"
    assert unicode_urldecode(u"a%2fb") == u"a/b"
    assert unicode_urldecode(u"a%20b") == u"a b"
    assert unicode_urldecode(u"a+b") == u"a+b"
    assert unicode_urldecode(u"a b") == u"a b"
    assert unicode_urldecode(u"a/b") == u"a/b"



# Generated at 2022-06-11 14:13:28.107108
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(None) is None
    assert unicode_urldecode(b'a%20space') == u'a space'
    assert unicode_urldecode(u'a%20space') == u'a space'
    assert unicode_urldecode(u'a+space') == u'a space'
    assert unicode_urldecode(u'a%E2%82%AC+symbol') == u'a€ symbol'


# Generated at 2022-06-11 14:13:38.171219
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # NOTE: expected values are quoted urls
    assert unicode_urlencode(u'\u05d0\u05d1\u05d2\u05d3') == u'%D7%90%D7%91%D7%92%D7%93'
    assert unicode_urlencode(u'\u05d0\u05d1\u05d2\u05d3', for_qs=True) == u'%D7%90%D7%91%D7%92%D7%93'
    assert unicode_urlencode(u'\u05d0\u05d1\u05d2\u05d3', for_qs=False) == u'%D7%90%D7%91%D7%92%D7%93'


# Generated at 2022-06-11 14:13:41.699268
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    items = f.filters()
    assert items['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert items['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:13:43.388471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9') == u'é'


# Generated at 2022-06-11 14:13:45.991738
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert isinstance(unicode_urldecode('%20'), str if PY3 else unicode)



# Generated at 2022-06-11 14:13:57.193635
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('!#$%&\'()*+,-./:;<=>?@[]^_`{|}~') == '!%23%24%25%26%27%28%29%2A%2B%2C-.%2F%3A%3B%3C%3D%3E%3F%40%5B%5D%5E_%60%7B%7C%7D%7E'
    assert unicode_urlencode('this+is+a+test') == 'this%2Bis%2Ba%2Btest'
    assert unicode_urlencode('this+is+a+test', for_qs=True) == 'this%2Bis%2Ba%2Btest'

# Generated at 2022-06-11 14:14:03.355485
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('xyz') == u'xyz'
    assert unicode_urldecode('%2Bxyz') == u'+xyz'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('+') == u'+'
    assert unicode_urldecode('%00') == u'\x00'
    assert unicode_urldecode('%') == u'%'


# Generated at 2022-06-11 14:14:15.792183
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ud = unicode_urldecode
    assert ud(u'%C3%A5%C3%B8%C3%A6%C3%B8%C3%A5%C3%B8') == u'åøæøåø'
    assert ud(u'%25C3%25A5%25C3%25B8%25C3%25A6%25C3%25B8%25C3%25A5%25C3%25B8') == u'%C3%A5%C3%B8%C3%A6%C3%B8%C3%A5%C3%B8'
    assert ud(u'3%3A4') == u'3:4'
    assert ud(u'foo%20bar') == u

# Generated at 2022-06-11 14:14:18.566223
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    ''' unicode_urldecode should return quoted strings unquoted '''

    assert unicode_urldecode(u'abc%20def') == u'abc def'
    assert unicode_urldecode(u'abc+def') == u'abc def'



# Generated at 2022-06-11 14:14:21.116997
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    r = fm.filters()
    print('filters() => %s' % (r,))


# Generated at 2022-06-11 14:14:25.734897
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert not HAS_URLENCODE or fm.filters()['urlencode'] == do_urlencode
    assert fm.filters()['urldecode'] == do_urldecode


# Unit tests for method unicode_urlencode of class FilterModule

# Generated at 2022-06-11 14:14:29.348297
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    tests = {
        "%20": " ",
        "%2B": "+",
        "%2F": "/",
        "%C3%B1": "ñ",
    }

    for test_input, expected in iteritems(tests):
        assert unicode_urldecode(test_input) == expected


# Generated at 2022-06-11 14:14:40.527774
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:14:45.469102
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A7%C3%A3o') == 'ção'
    assert unicode_urldecode(unicode_urldecode('%C3%A7%C3%A3o')) == 'ção'


# Generated at 2022-06-11 14:14:49.845001
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%CE%BD%CE%B5%CF%84%CE%B1') == u'νετα'
    assert unicode_urldecode(u'%2Fip%2Froute%2F10.0.0.0%2F24') == u'/ip/route/10.0.0.0/24'

# Generated at 2022-06-11 14:14:54.191106
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'https%3A%2F%2Fwww.wikipedia.org%2F') == u'https://www.wikipedia.org/'
    assert unicode_urldecode(u'%C3%A8%C3%A9') == u'èé'



# Generated at 2022-06-11 14:14:59.244226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert filters['urldecode']('%20') == u' '

    if not HAS_URLENCODE:
        assert filters['urlencode'](' ') == u'%20'
        assert filters['urlencode']({'key': 'value'}) == 'key=value'



# Generated at 2022-06-11 14:15:11.588291
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('TEST: test_FilterModule_filters')
    f = FilterModule()
    for name in ('urldecode', 'urlencode'):
        if name not in f.filters():
            print('FAIL: Filter not found: %s', name)
            assert False
    print('PASS: test_FilterModule_filters')


# Generated at 2022-06-11 14:15:15.241031
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        assert unicode_urldecode(b'%C3%A9') == u'é'
    else:
        assert unicode_urldecode(b'%C3%A9') == u'\xc3\xa9'



# Generated at 2022-06-11 14:15:24.547269
# Unit test for method filters of class FilterModule

# Generated at 2022-06-11 14:15:31.590238
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%2Fusr%2Flocal%2Fbin').endswith('usr/local/bin')
    assert do_urlencode('/usr/local/bin').endswith('%2Fusr%2Flocal%2Fbin')
    assert do_urlencode(['/usr/local/bin']).endswith('%2Fusr%2Flocal%2Fbin')
    assert do_urlencode({'key': '/usr/local/bin'}).endswith('key=%2Fusr%2Flocal%2Fbin')
    assert do_urlencode(('key', '/usr/local/bin')).endswith('key=%2Fusr%2Flocal%2Fbin')
    assert do_urlencode('/usr/local/bin/').endswith

# Generated at 2022-06-11 14:15:35.083370
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    if PY3:
        res = unicode_urldecode('%C3%B6')
        assert res == 'ö'
    else:
        res = unicode_urldecode('%C3%B6')
        assert res == u'ö'


# Generated at 2022-06-11 14:15:45.086769
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'~') == u'%7E'
    assert do_urlencode(u'/path') == u'%2Fpath'
    assert do_urlencode(u'key=val') == u'key%3Dval'
    assert do_urlencode(u'key=val&k=v') == u'key%3Dval&k%3Dv'
    assert do_urlencode({'key': 'val'}) == u'key%3Dval'
    assert do_urlencode(['key=val', 'k=v']) == u'key%3Dval&k%3Dv'


# Generated at 2022-06-11 14:15:52.908521
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.errors
    from ansible.plugins.filter import FilterModule as FilterModule_obj
    from ansible.module_utils._text import to_bytes, to_text

    try:
        from jinja2.filters import do_urlencode
        HAS_URLENCODE = True
    except:
        HAS_URLENCODE = False

    fm = FilterModule_obj()
    assert(fm.filters()['urldecode'])
    if not HAS_URLENCODE:
        assert(fm.filters()['urlencode'])

    assert(fm.filters()['urldecode']('%2F') == '/')

# Generated at 2022-06-11 14:15:57.579785
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    if sys.version_info[0] == 2:
        assert unicode_urldecode('%20') == u' '
        assert unicode_urldecode(u'%20') == u' '
    else:
        assert unicode_urldecode('%20') == ' '
        assert unicode_urldecode(u'%20') == ' '



# Generated at 2022-06-11 14:16:01.415003
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%20b%20c') == u'a b c'
    assert unicode_urldecode('a%20b%20c') == 'a b c'
    assert unicode_urldecode(bytearray(b'a%20b%20c')) == 'a b c'
    assert unicode_urldecode('%C3%A5') == u'å'


# Generated at 2022-06-11 14:16:03.181035
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%20') == u' '


# Generated at 2022-06-11 14:16:19.792309
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys

# Generated at 2022-06-11 14:16:21.265598
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['urldecode']('foo%20bar') == 'foo bar'


# Generated at 2022-06-11 14:16:30.542224
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # unicode_urldecode()
    assert unicode_urldecode('J%C3%A4ger') == 'Jäger'
    assert unicode_urldecode('Z%C3%BCrich') == 'Zürich'
    assert unicode_urldecode(u'M%C3%BCnchen') == u'München'
    assert unicode_urldecode('%7Ewieers') == '~wieers'
    assert unicode_urldecode(u'%7Ewieers') == u'~wieers'

    # unicode_urlencode()
    assert unicode_urlencode('Jäger') == 'J%C3%A4ger'

# Generated at 2022-06-11 14:16:33.110627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters
    assert len(filters) == (2 if HAS_URLENCODE else 3)

# Generated at 2022-06-11 14:16:36.397828
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abcdef') == u'abcdef'
    assert unicode_urldecode('%41%42%43') == u'ABC'
    assert unicode_urldecode('%41%42%43') == u'ABC'



# Generated at 2022-06-11 14:16:39.299390
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()
    assert f['urldecode']('foo%20bar') == 'foo bar'
    if not HAS_URLENCODE:
        assert f['urlencode']('foo bar') == 'foo%20bar'

# Generated at 2022-06-11 14:16:43.746454
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%E2%82%AC') == u'€'
    assert unicode_urldecode(u'%E2%82%AC') == u'€'
    assert unicode_urldecode('%E2%82%AC') == u'€'
    assert unicode_urldecode(u'€') == u'€'
    assert unicode_urldecode('€') == u'€'
    return True


# Generated at 2022-06-11 14:16:52.412204
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://foo.bar/foo bar') == u'http%3A//foo.bar/foo%20bar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo&bar') == u'foo%26bar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo bar', for_qs=True) == u'foo+bar'

# Generated at 2022-06-11 14:17:01.248737
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'unicode') == u'unicode'
    assert unicode_urlencode(u'unicode_é') == u'unicode_%C3%A9'
    assert unicode_urlencode(u'unicode_/é') == u'unicode_%2F%C3%A9'
    assert unicode_urlencode(u'unicode_é', for_qs=True) == u'unicode_%C3%A9'
    assert unicode_urlencode(u'unicode_+é', for_qs=True) == u'unicode_%2B%C3%A9'
    assert unicode_urlencode(u'unicode_&é', for_qs=True) == u'unicode_%26%C3%A9'

# Generated at 2022-06-11 14:17:07.423966
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    '''
    Test to ensure that urldecode works properly
    '''
    if PY3:
        test = unicode_urldecode('%C3%A2%C3%A9%C3%A9') == 'âéé'
    else:
        test = unicode_urldecode('%C3%A2%C3%A9%C3%A9') == u'âéé'
    assert test



# Generated at 2022-06-11 14:17:16.685099
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'hello%2Bworld') == u'hello+world'
    assert unicode_urldecode(u'hello+world') == u'hello world'

# Generated at 2022-06-11 14:17:20.473958
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Note: we can't use quote_plus here because it's a different encoding on Python 3
    assert unicode_urldecode('abc%2B123') == u'abc+123'
    assert unicode_urldecode('%A1') == u'\xa1'
    assert unicode_urldecode('%A1%A2') == u'\xa1\xa2'
    assert unicode_urldecode('%C3%A9') == u'\xe9'
    assert unicode_urldecode('%C3%A9%C3%A7') == u'\xe9\xe7'
    assert unicode_urldecode('abc%2B123%A1%C3%A9') == u'abc+123\xa1\xe9'


# Generated at 2022-06-11 14:17:24.318233
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    f = fm.filters()
    assert 'urldecode' in f
    assert f['urldecode'] == do_urldecode

    if not HAS_URLENCODE:
        assert 'urlencode' in f
        assert f['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:17:26.536058
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%3Abar') == 'foo:bar'
    assert unicode_urldecode('%2Fvar%2Flog') == '/var/log'



# Generated at 2022-06-11 14:17:34.672029
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25') == '%'
    assert unicode_urldecode('%2525') == '%%'
    assert unicode_urldecode('%25%30') == '%%0'
    assert unicode_urldecode('%25%30%25') == '%%%'
    assert unicode_urldecode('%25%30%25%30') == '%%0%0'
    assert unicode_urldecode('%25%300') == '%%0'
    assert unicode_urldecode('%25%3000') == '%%0'
    assert unicode_urldecode('%25%30') == '%%0'
    assert unicode_urldecode('%30%25') == '%0%'
    assert unicode_ur

# Generated at 2022-06-11 14:17:41.081037
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'http://example.com/føø') == u'http%3A//example.com/f%C3%B8%C3%B8'
    assert unicode_urlencode(dict(a=1, b='one')) == u'a=1&b=one'
    assert unicode_urlencode(dict(a=(1, 2, 3), b=(4, 5, 6))) == u'a=1&a=2&a=3&b=4&b=5&b=6'

# Generated at 2022-06-11 14:17:51.093713
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'%C3%A4%C3%B6%C3%BC%C3%9F' == unicode_urlencode(u'äöüß')
    assert list(u'%C3%A4%C3%B6%C3%BC%C3%9F') == list(unicode_urlencode(list(u'äöüß')))
    assert {u'C3': u'äöüß'} == unicode_urlencode({u'C3': u'äöüß'})
    assert u'key=val1&key=val2&key=val3' == unicode_urlencode([u'val1', u'val2', u'val3'], for_qs=True)

# Generated at 2022-06-11 14:17:58.832889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule

    :Alt title: TestFilterModulefilters
    :Test name: test_FilterModule_filters
    :Test title: Test FilterModule.filters
    '''
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule()
    fm = FilterModule()
    assert 'urldecode' in fm.filters().keys()
    if not HAS_URLENCODE:
        assert 'urlencode' in fm.filters().keys()

# Generated at 2022-06-11 14:18:05.141357
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:18:12.795087
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'foo=bar' == FilterModule().filters()['urlencode']('foo=bar')
    assert 'foo=bar' == FilterModule().filters()['urlencode']({'foo': 'bar'})
    assert 'foo=bar&baz=42' == FilterModule().filters()['urlencode']({'foo': 'bar', 'baz': 42})

    assert '@' == FilterModule().filters()['urldecode']('%40')
    assert '%' == FilterModule().filters()['urldecode']('%25')
    assert '@%' == FilterModule().filters()['urldecode']('%40%25')

# Generated at 2022-06-11 14:18:30.383699
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    dictionary = {u'key': u'value'}
    test_string = u'value'
    assert unicode_urlencode(test_string) == u'value'
    assert unicode_urlencode(dictionary) == u'key=value'


# Generated at 2022-06-11 14:18:33.912448
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters
    assert filters['urldecode'] is not None
    assert filters['urlencode'] is not None


# Generated at 2022-06-11 14:18:45.597696
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    test_FilterModule = FilterModule()
