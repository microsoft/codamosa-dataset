

# Generated at 2022-06-11 14:08:54.230950
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:08:57.930196
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert b'p:p' == unicode_urldecode(b'p%3Ap')
    assert u'p:p' == unicode_urldecode(u'p%3Ap')



# Generated at 2022-06-11 14:09:06.728768
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u'abc' == unicode_urlencode(u'abc')
    assert u'%20' == unicode_urlencode(u' ')
    assert u'%C3%A9%20' == unicode_urlencode(u'é ')
    assert u'%C3%A9%20' == unicode_urlencode(u'é ')

    assert u'%C3%A9%20' == unicode_urlencode(u'é ', for_qs=True)
    assert u'%E2%98%83' == unicode_urlencode(u'☃', for_qs=True)
    assert u'%C3%A9%20' == unicode_urlencode(u'é ', for_qs=True)


# Generated at 2022-06-11 14:09:12.259200
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode'].__name__ == 'do_urldecode'

    if not HAS_URLENCODE:
        assert fm.filters()['urlencode'].__name__ == 'do_urlencode'

# Generated at 2022-06-11 14:09:14.858375
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fexample.com%2F') == 'http://example.com/'



# Generated at 2022-06-11 14:09:26.434082
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus

    string = u'/?|[]()!@#$^*<>#'
    expected = b'%2F%3F%7C%5B%5D%28%29%21%40%23%24%5E*%3C%3E%23'
    result = unicode_urlencode(string)
    assert result == expected, 'Expected %s, but got %s (quote)' % (to_text(expected), result)

    expected = b'%2F%3F%7C%5B%5D%28%29%21%40%23%24%5E*%3C%3E%23'
    result = unicode_urlencode(string, True)

# Generated at 2022-06-11 14:09:35.779413
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E4') == u'ä'
    assert unicode_urldecode('%2C') == u','
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%5B') == u'['
    assert unicode_urldecode('%5D') == u']'
    assert unicode_urldecode('%2F') == u'/'
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode

# Generated at 2022-06-11 14:09:46.010444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import yaml
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    filter_module = FilterModule()
    filter_module_filters = filter_module.filters()
    test_data_path = os.path.join(os.path.dirname(__file__), 'test_data.yml')
    with open(test_data_path) as f:
        test_data = yaml.safe_load(f)
    # urlencode test
    if PY3:
        assert filter_module_filters['urlencode'](test_data['urlencode']['input']) \
            == test_data['urlencode']['output']

# Generated at 2022-06-11 14:09:56.118114
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u"/") == u"%2F"
    assert unicode_urlencode(u"%") == u"%25"
    assert unicode_urlencode(u"+") == u"%2B"
    assert unicode_urlencode(u" ") == u"%20"
    assert unicode_urlencode(u"/") == u"%2F"
    assert unicode_urlencode(u"/", for_qs=True) == u"%2F"
    assert unicode_urlencode(u"+") == u"%2B"
    assert unicode_urlencode(u"+", for_qs=True) == u"%2B"
    assert unicode_urlencode(u" ") == u"%20"
   

# Generated at 2022-06-11 14:10:01.134668
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a%2Bb') == 'a+b'
    assert unicode_urldecode('a%2bb') == 'a+b'
    assert unicode_urldecode('a+b') == 'a b'


# Unit tests for function unicode_urlencode

# Generated at 2022-06-11 14:10:05.342603
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fwww.google.com%2F') == u'http://www.google.com/'

# Generated at 2022-06-11 14:10:13.935263
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        assert unicode_urlencode(u'Привет') == u'%D0%9F%D1%80%D0%B8%D0%B2%D0%B5%D1%82'
        assert unicode_urlencode(u'При\nвет') == u'%D0%9F%D1%80%D0%B8%0A%D0%B2%D0%B5%D1%82'
        assert unicode_urlencode(u'Привет', for_qs=True) == u'%D0%9F%D1%80%D0%B8%D0%B2%D0%B5%D1%82'
        assert unicode_url

# Generated at 2022-06-11 14:10:23.943608
# Unit test for function do_urlencode

# Generated at 2022-06-11 14:10:29.241697
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode("Hello+world%21") == u"Hello world!"

    if not HAS_URLENCODE:
        assert do_urlencode("Hello world!") == u"Hello+world%21"
        assert do_urlencode({"a": "b"}) == u"a=b"
        assert do_urlencode([("a", "b")]) == u"a=b"

# Generated at 2022-06-11 14:10:32.873135
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.testmod(Report=True,
                    optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)


if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-11 14:10:43.506599
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode("https://www.example.com/foo/bar") == u"https%3A%2F%2Fwww.example.com%2Ffoo%2Fbar"
    assert unicode_urlencode("https://www.example.com/foo/bar/?thing=stuff") == u"https%3A%2F%2Fwww.example.com%2Ffoo%2Fbar%2F%3Fthing%3Dstuff"
    assert unicode_urlencode("https://www.example.com/foo/bar/?thing=stuff&other=other%20stuff") == u"https%3A%2F%2Fwww.example.com%2Ffoo%2Fbar%2F%3Fthing%3Dstuff%26other%3Dother%20stuff"
    assert unicode_

# Generated at 2022-06-11 14:10:49.992625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3, iteritems, string_types
    from ansible.module_utils.six.moves.urllib.parse import quote, quote_plus, unquote_plus
    from jinja2.filters import do_urlencode

    fm = FilterModule()
    assert(fm.filters())

    # do_urldecode test
    assert(do_urldecode("foo") == "foo")
    assert(do_urldecode("foo+bar") == "foo bar")
    assert(do_urldecode("foo%20bar") == "foo bar")

# Generated at 2022-06-11 14:10:51.424647
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20def') == u'abc def'


# Generated at 2022-06-11 14:10:57.518997
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    print("Testing unicode_urldecode")
    str1 = u"www.google.com/search?as_q=test"
    str2 = unicode_urldecode(str1)
    print("str2: %s" % str2)
    if str2 != "www.google.com/search?as_q=test":
        print("FAIL: str2 should be same as str1")


# Generated at 2022-06-11 14:10:59.316337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters()['urldecode']('a%20b') == 'a b'



# Generated at 2022-06-11 14:11:10.920947
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%26') == u'&'
    assert unicode_urldecode('%27') == u"'"
    assert unicode_urldecode('%2f') == u'/'
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2B') == u'+'
    assert unicode_urldecode('%2b') == u'+'
    assert unicode_urldecode('%3D') == u'='
    assert unicode_urldecode('%3d') == u'='
    assert unicode_urldecode(u'%26') == u'&'
    assert unicode_urldecode(u'%27') == u"'"
    assert unicode_

# Generated at 2022-06-11 14:11:20.038588
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc') == u'abc'
    assert unicode_urldecode(u'abc&def') == u'abc&def'
    assert unicode_urldecode(u'abc+def') == u'abc def'
    assert unicode_urldecode(u'abc%2Bdef') == u'abc+def'
    assert unicode_urldecode(u'abc%23def') == u'abc#def'
    assert unicode_urldecode(u'abc%2523def') == u'abc%23def'
    assert unicode_urldecode('abc+def') == 'abc def'
    assert unicode_urldecode('abc%2Bdef') == 'abc+def'

# Generated at 2022-06-11 14:11:29.801717
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'asdf') == u'asdf'
    assert unicode_urlencode(u'/asdf') == u'/asdf'

    assert unicode_urlencode(u'\x80') == u'%C2%80'
    assert unicode_urlencode(u'\x80', for_qs=True) == u'%C2%80'
    assert unicode_urlencode(u'\\x80') == u'\\x80'
    assert unicode_urlencode(u'\\x80', for_qs=True) == u'%5Cx80'

    assert unicode_urlencode(u' ') == u'%20'
    assert unicode_urlencode(u' ', for_qs=True) == u'%20'


# Generated at 2022-06-11 14:11:35.597317
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    if not PY3:
        unittest.TestCase.assertEqual(unicode_urlencode(u"Joël Kaufman"),
                                      u"Jo%C3%ABl%20Kaufman")
    else:
        unittest.TestCase.assertEqual(unicode_urlencode(u"Joël Kaufman"),
                                      "%C3%ABl%20Kaufman")

# Generated at 2022-06-11 14:11:44.369219
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    result = unicode_urldecode('abcabcabc')
    assert result == 'abcabcabc'

    result = unicode_urldecode('+')
    assert result == ' '

    result = unicode_urldecode('%20')
    assert result == ' '

    result = unicode_urldecode('%2B')
    assert result == '+'

    result = unicode_urldecode('%2b')
    assert result == '+'

    result = unicode_urldecode('%2f')
    assert result == '/'

    result = unicode_urldecode('%2F')
    assert result == '/'

    result = unicode_urldecode('%26')
    assert result == '&'


# Generated at 2022-06-11 14:11:48.812450
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_source = "%40%23%24%25%5E%26%2A%28%29_%2B%7B%7D%5B%5D%3B%27%3A%22%2C%2F%3F%3C%3E%3F%3D%22%20"
    test_target = "@#$%^&*()_+{}[];':\",/?<>?=\" "
    assert unicode_urldecode(test_source) == test_target, \
        "unicode_urldecode() failed"


# Generated at 2022-06-11 14:11:52.143432
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters is not None
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters
    # TODO: Add some more unit tests



# Generated at 2022-06-11 14:12:01.926201
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    assert unicode_urlencode('unicode_urlencode') == u'unicode_urlencode'
    assert unicode_urlencode(u'unicode_urlencode') == u'unicode_urlencode'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode(u'foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode({'foo+bar': 'foo bar'}) == u'foo%2Bbar=foo%20bar'

# Generated at 2022-06-11 14:12:07.237406
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # check with unicode encoded url
    assert unicode_urldecode(u'f%C5%82ota_%C5%BCaba') == u'fłota_żaba'

    # check with ascii encoded url
    assert unicode_urldecode('f%C5%82ota_%C5%BCaba') == u'fłota_żaba'



# Generated at 2022-06-11 14:12:18.160300
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == ''
    assert unicode_urlencode(' ') == '%20'
    assert unicode_urlencode('/') == '%2F'
    assert unicode_urlencode('/', for_qs=True) == '%2F'
    assert unicode_urlencode('%') == '%25'
    assert unicode_urlencode('%20') == '%2520'
    assert unicode_urlencode('%25') == '%2525'
    assert unicode_urlencode('%2520') == '%252520'
    assert unicode_urlencode(u'\x80') == '%C2%80'
    assert unicode_urlencode('\x80') == '%C2%80'

# Unit test

# Generated at 2022-06-11 14:12:30.234255
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%21') == u'!'
    assert unicode_urldecode(u'%21') == u'!'
    assert unicode_urldecode(b'%21') == u'!'
    assert unicode_urldecode('%21%22') == u'!"'
    assert unicode_urldecode(u'%21%22') == u'!"'
    assert unicode_urldecode(b'%21%22') == u'!"'


# Generated at 2022-06-11 14:12:39.283905
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    datalist = [
        ('foo%20bar', 'foo bar'),
        ('foo+bar', 'foo+bar'),
        ('foo%2Fbar', 'foo/bar'),
        ('foo%26bar', 'foo&bar'),
        ('foo%3Dbar', 'foo=bar'),
        ('foo%3Fbar', 'foo?bar'),
        ('foo%2Bbar', 'foo+bar'),
        ('foo%25bar', 'foo%bar'),
        ('foo%C3%A9', u'fooé'),
        ('foo%C3%A9', u'fooé'),
    ]
    for data in datalist:
        if PY3:
            assert unicode_urldecode(data[0]) == data[1]

# Generated at 2022-06-11 14:12:41.861843
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()["urldecode"]("b%2Bc") == "b+c"


# Generated at 2022-06-11 14:12:49.056049
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert u"Hello%20World%21" == unicode_urlencode(u"Hello World!")
    assert u"Hello%20%25%20World%21" == unicode_urlencode(u"Hello % World!")
    assert u"%26%23%3B%26%23%3B" == unicode_urlencode(u"&#;;")
    assert u"%26%23%3B%26%23%3B" == unicode_urlencode(u"&#;;", for_qs=True)
    assert u"test%3A%3A%0A%3B" == unicode_urlencode(u"test::\n;")

# Generated at 2022-06-11 14:12:50.599014
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'] == do_urldecode


# Generated at 2022-06-11 14:12:59.937571
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('space%20space') == u'space space'
    assert do_urldecode('%E4%B8%AD%E6%96%87') == u'中文'
    assert do_urlencode(u'中文') == u'%E4%B8%AD%E6%96%87'
    assert do_urlencode(u'中文'.encode('utf-8')) == u'%E4%B8%AD%E6%96%87'
    assert do_urlencode({'foo': u'bar bar'}) == u'foo=bar+bar'
    assert do_urlencode({'foo': u'bar bar'}) == u'foo=bar+bar'

# Generated at 2022-06-11 14:13:02.160104
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm = fm.filters()
    assert fm['urldecode']('%20') == ' '


# Generated at 2022-06-11 14:13:05.696065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] == do_urldecode
    assert 'urlencode' in filters
    assert filters['urlencode'] == do_urlencode

# Generated at 2022-06-11 14:13:11.281723
# Unit test for function unicode_urldecode
def test_unicode_urldecode():

    def url_decode(string):
        return ''.join([chr(int(string[i:i + 2], 16)) for i in range(0, len(string), 2)])

    assert unicode_urldecode('%20') == ' '
    assert unicode_urldecode('%E2%82%AC') == url_decode('E282AC')
    assert unicode_urldecode('%E2%82%AC!') == url_decode('E282AC21')
    assert unicode_urldecode('%E2%82%AC!%E2%82%AC') == url_decode('E282AC21E282AC')

# Generated at 2022-06-11 14:13:20.250488
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.compat.tests.test_unsql import TestUnsql
    import ansible.module_utils.compat.misc

    class FilterModuleTests(TestUnsql):
        module = ansible.module_utils.compat.misc
        cls = FilterModule
        method = 'filters'

        def test_urldecode(self):
            import jinja2

            template = jinja2.Template('{{ v | urldecode }}')
            self.assertFalse(template.render(v=u'%') is None)

            template = jinja2.Template('{{ v | urldecode }}')
            self.assertFalse(template.render(v=b'%') is None)

            template = jinja2.Template('{{ v | urldecode }}')
           

# Generated at 2022-06-11 14:13:37.829481
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://www.foo.com/~user/') == u'http%3A%2F%2Fwww.foo.com%2F~user%2F'
    assert do_urlencode(u'http://www.foo.com/~user/?a=b') == u'http%3A%2F%2Fwww.foo.com%2F~user%2F%3Fa%3Db'
    assert do_urlencode(u'http://www.foo.com/~user/?id=12345') == u'http%3A%2F%2Fwww.foo.com%2F~user%2F%3Fid%3D12345'

# Generated at 2022-06-11 14:13:46.116520
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    unicode_urlencode : Tests for Python 2/3 compatibility
    '''

    test_data = {
        'unicode' : u'El Niño',
        'str' : 'El Niño',
        'dict' : {'foo' : 'bar', 'baz' : 'fuuuuuuu'},
        'list' : ['foo', 'bar', 'baz'],
        'tuple': ('foo', 'bar', 'baz')
    }

    for key, val in test_data.items():
        if isinstance(val, (list, tuple)):
            for item in val:
                assert unicode_urlencode(item) == do_urlencode(item)
        else:
            assert unicode_urlencode(val) == do_urlencode(val)

# Generated at 2022-06-11 14:13:57.276173
# Unit test for function do_urlencode
def test_do_urlencode():
    import pytest

    # Basic test
    assert do_urlencode('http://foo/bar') == 'http%3A//foo/bar'

    # Test for function for_qs
    assert do_urlencode('/&?=') == '%2F%26%3F%3D'

    # Test unicode input
    # assert do_urlencode(u'http://foo/bar') == 'http%3A//foo/bar'

    # Test that the output is always text
    # assert isinstance(do_urlencode(u'http://foo/bar'), text_type)

    # Test that a dict yields: 'foo=bar&baz=spam'
    assert do_urlencode({'foo': 'bar', 'baz': 'spam'}) == 'foo=bar&baz=spam'

# Generated at 2022-06-11 14:13:58.559123
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['urldecode']('/usr/bin%252Fname') == '/usr/bin/name'

# Generated at 2022-06-11 14:14:04.550216
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fexample.com') == u'http://example.com'
    assert unicode_urldecode(b'http%3A%2F%2Fexample.com') == u'http://example.com'
    assert unicode_urldecode(u'a%40b') == u'a@b'
    assert unicode_urldecode(b'a%40b') == u'a@b'
    assert unicode_urldecode(u'%E4%BA%B2') == u'\u4e3a'
    assert unicode_urldecode(b'%E4%BA%B2') == u'\u4e3a'


# Generated at 2022-06-11 14:14:12.446935
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('abc') == u'abc'
    assert unicode_urlencode('ab c') == u'ab%20c'
    assert unicode_urlencode('ab+c') == u'ab%2Bc'
    assert unicode_urlencode('/var/log/httpd/access_log') == u'/var/log/httpd/access_log'
    assert unicode_urlencode('/var/log/httpd/access_log', for_qs=True) == u'%2Fvar%2Flog%2Fhttpd%2Faccess_log'


# Generated at 2022-06-11 14:14:16.861288
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    y = x.filters()
    assert 'urldecode' in y
    assert callable(y['urldecode'])
    assert y['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert 'urlencode' in y
        assert callable(y['urlencode'])
        assert y['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in y

# Generated at 2022-06-11 14:14:27.580955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.common._collections_compat import Mapping
    from jinja2.filters import do_urlencode
    from operator import methodcaller as mc

    # Verify do_urlencode is present in Jinja2, which is also available in Ansible
    # and therefore do_urlencode doesn't need to be implemented in FilterModule
    assert do_urlencode

    # Verify that the urlencode and urldecode filters are part of the FilterModule
    filters = FilterModule().filters()
    assert set(filters).issuperset(set(['urldecode', 'urlencode']))

    # Verify that do_urldecode is a method of class FilterModule
    assert callable(mc(do_urldecode, FilterModule))

    # Verify that do_urlencode

# Generated at 2022-06-11 14:14:38.398121
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode('foo+bar', for_qs=True) == u'foo%2Bbar'
    assert unicode_urlencode('foo bar') == u'foo%20bar'
    assert unicode_urlencode('foo bar', for_qs=True) == u'foo+bar'
    assert unicode_urlencode('foo%2Bbar') == u'foo%252Bbar'
    assert unicode_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert unicode_urlencode(b'foo+bar') == u'foo%2Bbar'



# Generated at 2022-06-11 14:14:41.532254
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert module.filters['urlencode'] == do_urlencode


# Generated at 2022-06-11 14:14:58.720113
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == u'foo'
    assert unicode_urlencode(u'foo') == u'foo'
    assert unicode_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert unicode_urlencode(u'foo/bar', True) == u'foo%2Fbar'
    assert unicode_urlencode(u'föo bar') == u'f%C3%B6o%20bar'
    assert unicode_urlencode(u'föo bar', True) == u'f%C3%B6o+bar'
    assert unicode_urlencode(u' föo/bär ') == u'+f%C3%B6o%2Fb%C3%A4r+'


# Generated at 2022-06-11 14:15:00.017204
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # NOTE: Cannot use unit tests as Jinja2 is optional
    pass

# Generated at 2022-06-11 14:15:02.460471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22abc%22%3A%22def%22%7D') == u'{"abc":"def"}'



# Generated at 2022-06-11 14:15:07.860662
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'https%3A%2F%2Fwww.homeownershub.com%2Fmaintenance%2Fplumbing%2F472941-water-leak-repair-guide.html%2F') == u'https://www.homeownershub.com/maintenance/plumbing/472941-water-leak-repair-guide.html/'

# Generated at 2022-06-11 14:15:11.814429
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    s = b'%C3%A6%20%C3%B8%20%C3%A5'
    assert unicode_urldecode(s) == u'æ ø å'



# Generated at 2022-06-11 14:15:12.994772
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("foo%20bar") == u"foo bar"

# Generated at 2022-06-11 14:15:17.726591
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # unit tests for urldecode
    # tests for urldecode
    filtered = do_urldecode('%7B%22%22%3A+%22value%22%7D')
    assert filtered == '{"": "value"}'

    # [un]comment to see failed assertions
    # assert filtered == '(expected)'

# Generated at 2022-06-11 14:15:26.599333
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils._text import to_bytes, to_text

    assert unicode_urldecode(u'objet%20d%27%C3%A9tude') == u'objet d\'étude'
    assert unicode_urldecode(u'objet+d%27%C3%A9tude') == u'objet d\'étude'
    assert unicode_urldecode(u'objet20d27C3A9tude') == u'objet20d27C3A9tude'
    assert unicode_urldecode(u'objet%2Bd%27%C3%A9tude') == u'objet+d\'étude'

# Generated at 2022-06-11 14:15:32.081277
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    obj = FilterModule()
    # Test with non-dict parameter
    assert u'a=b' == obj.filters()['urlencode']({'a': 'b'})

    # Test with dict parameter
    assert u'a=b&c=d' == obj.filters()['urlencode'](OrderedDict([('a', 'b'), ('c', 'd')]))

    # Test with non-dict parameter
    assert u'a+b' == obj.filters()['urldecode']('a+b')

    # Test with dict parameter
    assert u'a^b' == obj.filters()['urldecode']('a%5eb')

# Generated at 2022-06-11 14:15:36.905167
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'test%20%F0%9F%A6%82') == u'test \U0001f682'

# Generated at 2022-06-11 14:15:50.033641
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('bj%C3%B8rn') == u'bjørn'
    assert unicode_urldecode('bj%C3%B8rn%20') == u'bjørn '
    assert unicode_urldecode('%20%C3%B8%20') == u' ø '
    assert unicode_urldecode('%20%C3%B8%20') == u' ø '
    assert unicode_urldecode('%7E%7E%7E') == u'~~~'
    assert unicode_urldecode('%26%26%26') == u'&&&'
    assert unicode_urldecode('%3F%3F%3F') == u'???'

# Generated at 2022-06-11 14:15:52.499073
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('Dag%20Wie%C3%ABrs') == 'Dag Wieërs'


# Generated at 2022-06-11 14:16:00.463567
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%C3%A4%C3%A9') == to_text('äé', encoding='utf-8')
    assert unicode_urldecode('%7B%22a%22+%3A+1%7D') == to_text('{"a" : 1}', encoding='utf-8')
    assert unicode_urldecode('%25C3%25A4%25C3%25A9') == to_text('%C3%A4%C3%A9', encoding='utf-8')
    assert unicode_urldecode('%2525C3%2525A4%2525C3%2525A9') == to_text('%25C3%25A4%25C3%25A9', encoding='utf-8')

# Generated at 2022-06-11 14:16:10.755981
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:16:14.340702
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('test%2Ftest') == 'test/test'
    assert unicode_urldecode('test%2Ftest%3Ftest=1') == 'test/test?test=1'
    assert unicode_urldecode('test%2Ftest%3Ftest%3D1') == 'test/test?test=1'



# Generated at 2022-06-11 14:16:22.292288
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test = u"https://www.google.com/search?hl=en&q=urlencode+python38&btnG=Google+Search"
    assert u'https://www.google.com/search?hl=en&q=urlencode%2Bpython38&btnG=Google%2BSearch' == unicode_urlencode(test)
    assert u'https%3A%2F%2Fwww.google.com%2Fsearch%3Fhl%3Den%26q%3Durlencode%252Bpython38%26btnG%3DGoogle%252BSearch' == unicode_urlencode(test, for_qs=True)



# Generated at 2022-06-11 14:16:31.667248
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    import sys

    if sys.version_info[0] == 2:
        # Only test with Python 2
        assert unicode_urlencode(u'abcd') == 'abcd'
        assert unicode_urlencode(u'ab/cd') == 'ab%2Fcd'
        assert unicode_urlencode(u'ab/cd') == 'ab%2Fcd'
        assert unicode_urlencode(u'ab/cd', for_qs=True) == 'ab%2Fcd'
        assert unicode_urlencode(u'ab cd') == 'ab%20cd'
        assert unicode_urlencode(u'ab cd', for_qs=True) == 'ab+cd'
        assert unicode_urlencode(u'ab&cd') == 'ab%26cd'
        assert unic

# Generated at 2022-06-11 14:16:41.051402
# Unit test for function unicode_urlencode
def test_unicode_urlencode():

    test_cases = (
        (u'abc', 'abc'),
        (u'abc def', 'abc%20def'),
        (u'abc\ndef', 'abc%0Adef'),
        (u'?/&+=', '%3F%2F%26%2B%3D'),
    )

    for string, expect in test_cases:
        result = unicode_urlencode(string)
        assert result == expect, "unicode_urlencode('%s') => %s (expected %s)" % (
            string, result, expect)


# Generated at 2022-06-11 14:16:49.857027
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a=1") == "a=1"
    assert unicode_urldecode("a=1+1") == "a=1 1"
    assert unicode_urldecode("a%3D1%261") == "a=1&1"
    assert unicode_urldecode("a%26b%3D1%3Fc%3D2") == "a&b=1?c=2"
    assert unicode_urldecode("a%3Db%26c%3Dd") == "a=b&c=d"
    assert unicode_urldecode("a%3Db%26c%3Dd%3Fe%3Df") == "a=b&c=d?e=f"
    assert unicode_urldecode

# Generated at 2022-06-11 14:16:54.847417
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abc') == u'abc'
    assert unicode_urlencode(u'abc def') == u'abc%20def'
    assert unicode_urlencode(u'abc def', for_qs=True) == u'abc+def'
    assert unicode_urlencode(u'abc+def', for_qs=True) == u'abc%2Bdef'


# Generated at 2022-06-11 14:17:11.615954
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import jinja2
    from ansible.module_utils.six import PY3

    if not PY3:
        reload(sys)
        sys.setdefaultencoding('utf-8')

    f = FilterModule().filters()
    env = jinja2.Environment()
    env.filters.update(f)
    t = env.from_string('{{ some_dict|urlencode }}')
    assert t.render(some_dict={'foo': 'bar', 'baz': 'qux'}) == 'foo=bar&baz=qux'
    assert t.render(some_dict=[('foo', 'bar'), ('baz', 'qux')]) == 'foo=bar&baz=qux'
    print('OK')



# Generated at 2022-06-11 14:17:20.772584
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo+bar') == 'foo+bar'
    assert unicode_urldecode('foo%2fbar') == 'foo%2fbar'
    assert unicode_urldecode('foo%2Fbar') == 'foo%2Fbar'
    assert unicode_urldecode('foo%25bar') == 'foo%bar'
    assert unicode_urldecode('foo bar') == 'foo bar'
    assert unicode_urldecode('foo+bar') == 'foo+bar'
    assert unicode_urldecode('foo/bar') == 'foo/bar'
    assert unicode_urldecode('foo%bar') == 'foo%bar'
    assert unic

# Generated at 2022-06-11 14:17:24.904481
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('A & B') == 'A+%26+B'
    assert do_urlencode(['A & B', 'C', 'D']) == 'A+%26+B&C&D'
    assert do_urlencode({'A': 'B', 'C': 'D'}) == 'A=B&C=D'

# Generated at 2022-06-11 14:17:31.308988
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters['urldecode'].__name__ == 'do_urldecode'
    assert filters['urldecode']('https%3A%2F%2Fgithub.com%2Fdagwieers') == 'https://github.com/dagwieers'
    if not HAS_URLENCODE:
        assert filters['urlencode'].__name__ == 'do_urlencode'
        assert filters['urlencode']('https://github.com/dagwieers') == 'https%3A%2F%2Fgithub.com%2Fdagwieers'

# Generated at 2022-06-11 14:17:40.265769
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%ED%99%88%EA%B8%B0') == u'학기'
    assert unicode_urldecode('%ED%99%88%EA%B8%B0') == u'학기'
    assert unicode_urldecode('/%ED%99%88%EA%B8%B0') == u'/학기'
    assert unicode_urldecode('/%ED%99%88%EA%B8%B0/') == u'/학기/'
    assert unicode_urldecode('%00') == '/'
    assert unicode_urldecode('%00') == '/'

# Generated at 2022-06-11 14:17:42.797965
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    text = unicode_urldecode('a%40b+c%2Fd')
    assert text == u'a@b c/d'


# Generated at 2022-06-11 14:17:44.403720
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("abc+%3D") == "abc ="


# Generated at 2022-06-11 14:17:50.828801
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"dag%20wieers&test=2") == u"dag wieers&test=2"
    assert unicode_urldecode("dag%20wieers&test=2") == u"dag wieers&test=2"
    assert unicode_urldecode(u"dag%20wieers&test=2") == u"dag wieers&test=2"


# Generated at 2022-06-11 14:17:59.801569
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode('foo bar') == 'foo%20bar'
    assert do_urlencode('foo/bar') == 'foo%2Fbar'

    assert do_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert do_urlencode([('foo', 'bar')]) == 'foo=bar'
    assert do_urlencode((('foo', 'bar'), )) == 'foo=bar'
    assert do_urlencode([['foo', 'bar']]) == 'foo=bar'
    assert do_urlencode({'foo': ['bar', 'baz']}) == 'foo=bar&foo=baz'



# Generated at 2022-06-11 14:18:04.034149
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('') == u''
    assert unicode_urldecode('a') == u'a'
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%3F') == u'?'
    assert unicode_urldecode('%3F%20') == u'? '
    assert unicode_urldecode('%3F%20%3F') == u'? ?'


# Generated at 2022-06-11 14:18:21.808714
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

# Generated at 2022-06-11 14:18:25.296942
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert(unicode_urlencode("{'a':1}") == "%7B%27a%27%3A1%7D")
    assert(unicode_urlencode("{'a':1}", for_qs=True) == "%7B%27a%27%3A1%7D")


# Generated at 2022-06-11 14:18:35.195825
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Get a FilterModule object
    fm = FilterModule()
    # Get the filters
    filters = fm.filters()

    unicode_urlencoded_string = u'Mo%C3%B6'
    unicode_urldecoded_string = u'Moö'

    # Test that the urlencode filter encoding is correct
    assert filters['urldecode'](unicode_urlencoded_string) == unicode_urldecoded_string
    # Test that the urldecode filter decoding is correct
    if not HAS_URLENCODE:
        assert filters['urlencode'](unicode_urldecoded_string) == unicode_urlencoded_string
    else:
        assert filters['urlencode'](unicode_urldecoded_string) == unicode_urlencoded_string


# Generated at 2022-06-11 14:18:46.083566
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    for val in [
        u'http://www.foo.com/',
        u'http://www.foo.com/foo=bar',
        u'http://www.foo.com/?foo=bar',
        u'http://www.foo.com/?foo=bar&bar=baz',
        u'http://www.foo.com/?foo%20a=bar&bar%20b=baz',
        u'http://www.foo.com/?foo%20a=bar%20a&bar%20b=baz%20b',
        u'http://www.foo.com/?foo=bar%20a&bar=baz%20a',
    ]:
        assert val == unicode_urldecode(unicode_urlencode(val))


# Generated at 2022-06-11 14:18:53.290592
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.compat import AnsibleModule
    from ansible.module_utils.six import BytesIO
