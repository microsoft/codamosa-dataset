

# Generated at 2022-06-11 14:08:57.585261
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Tests that depend on urllib.quote_plus:
    assert unicode_urlencode(u"å") == u"%C3%A5"
    assert unicode_urlencode(u"å", True) == u"%C3%A5"
    assert unicode_urlencode(u"å", False) == u"%C3%A5"
    assert unicode_urlencode(u"åäö") == u"%C3%A5%C3%A4%C3%B6"
    assert unicode_urlencode(u"åäö", True) == u"%C3%A5%C3%A4%C3%B6"

# Generated at 2022-06-11 14:09:06.554786
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import jinja2
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_native

    f = FilterModule()
    filters = f.filters()

    assert not HAS_URLENCODE

    # urlencode
    assert filters['urlencode']('abc') == 'abc'
    assert filters['urlencode']('abc/def') == 'abc%2Fdef'
    assert filters['urlencode']('abc/def?foo=bar') == 'abc%2Fdef%3Ffoo%3Dbar'
    assert filters['urlencode']('abc/def?foo=bar&foz=baz') == 'abc%2Fdef%3Ffoo%3Dbar%26foz%3Dbaz'

# Generated at 2022-06-11 14:09:12.913166
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("a%20b%20c") == u'a b c'
    assert unicode_urldecode("a%20b%20c%29%28") == u'a b c)('
    assert unicode_urldecode("a%20%21%20c") == u'a ! c'


# Generated at 2022-06-11 14:09:23.865130
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert(unicode_urldecode('+') == u' ')
    assert(unicode_urldecode('%2B') == u'+')
    assert(unicode_urldecode('%2b') == u'+')
    assert(unicode_urldecode('%') == u'%')
    assert(unicode_urldecode('%z') == u'%z')
    assert(unicode_urldecode('%Z') == u'%Z')
    assert(unicode_urldecode('%%') == u'%%')
    assert(unicode_urldecode('%25') == u'%')
    assert(unicode_urldecode('%25%25') == u'%%')

# Generated at 2022-06-11 14:09:27.542835
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('foo') == 'foo'
    assert FilterModule().filters()['urlencode']({'bar': 'baz'}) == 'bar=baz'



# Generated at 2022-06-11 14:09:32.932793
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('&') == '%26'
    assert unicode_urlencode('%') == '%25'
    assert unicode_urlencode('foo&bar') == 'foo%26bar'
    assert unicode_urlencode('foo%bar') == 'foo%25bar'
    assert unicode_urlencode('foo&bar', for_qs=True) == 'foo%26bar'
    assert unicode_urlencode('foo%bar', for_qs=True) == 'foo%25bar'

# Generated at 2022-06-11 14:09:41.397169
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'abc123') == u'abc123'
    assert unicode_urldecode(u'abc+123') == u'abc 123'
    assert unicode_urldecode(u'abc%2B123') == u'abc+123'
    assert unicode_urldecode(u'abc%20def') == u'abc def'
    assert unicode_urldecode(u'%2Fpath%2Fto%2Ffile.txt') == u'/path/to/file.txt'


# Generated at 2022-06-11 14:09:45.026582
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode



# Generated at 2022-06-11 14:09:55.639823
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Testing urlencoded strings
    assert unicode_urldecode(u'foo%2Fbar') == u'foo/bar'
    assert unicode_urldecode(u'%2Ffoo%2Fbar%2F') == u'/foo/bar/'
    assert unicode_urldecode(u'%2Ffoo%2Fbar%2F%3F%3D%26') == u'/foo/bar/?=&'
    assert unicode_urldecode(u'%C3%BC%3D%3D') == u'ü=='
    assert unicode_urldecode(u'%C3%BC%3D%3D') == u'ü=='

    # Testing non-urlencoded strings

# Generated at 2022-06-11 14:09:57.584601
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('a%20b') == 'a b'
    assert do_urlencode('a b') == 'a+b'

# Generated at 2022-06-11 14:10:07.017451
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    example = {
        'foo bar': 'foo%20bar',
        'café': 'caf%C3%A9',
        'français': 'fran%C3%A7ais',
        '中文': '%E4%B8%AD%E6%96%87',
        '☃': '%E2%98%83',
        '%A2': '%25A2',
        '💩': '%F0%9F%92%A9',
    }

    for utf8, expected in iteritems(example):
        assert unicode_urlencode(utf8) == expected


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-11 14:10:11.143743
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('Hello, Dag') == 'Hello%2C%20Dag'
    assert unicode_urlencode('Hello, Dag') == u'Hello%2C%20Dag'
    assert unicode_urlencode('~?=>&') == '~%3F%3D%3E%26'



# Generated at 2022-06-11 14:10:19.761283
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    test_data = {
        u'http://example.com/path%2f/foo%20bar': u'http://example.com/path%2f/foo%20bar',
        u'http://example.com/path/foo bar': u'http://example.com/path/foo%20bar',
        u'http://example.com/path+/foo+bar': u'http://example.com/path+/foo+bar',
    }

    for input_str, output_str in iteritems(test_data):
        assert unicode_urlencode(input_str) == output_str, "Failed to urlencode '%s', expected '%s', got '%s'" % (input_str, output_str, unicode_urlencode(input_str))

# Generated at 2022-06-11 14:10:27.959917
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert 'urldecode' in filters
    urldecode = filters['urldecode']
    urldecode_possible_outputs = list(map(urldecode, ['%C3%A9', urldecode('%C3%A9')]))
    assert all([elem == urldecode_possible_outputs[0] for elem in urldecode_possible_outputs])

    if not HAS_URLENCODE:
        assert 'urlencode' in filters
        urlencode = filters['urlencode']
        urlencode_possible_outputs = list(map(urlencode, ['é', urlencode('é')]))

# Generated at 2022-06-11 14:10:32.034705
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' FilterModule.filters() Unit tests '''

    m = FilterModule()
    res = m.filters()
    a = 'urldecode'
    b = 'urlencode'
    assert a in res
    assert b in res



# Generated at 2022-06-11 14:10:33.736155
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    string = u'café'
    assert 'caf%C3%A9' == unicode_urlencode(string)



# Generated at 2022-06-11 14:10:40.242509
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo+bar') == u'foo bar'
    assert unicode_urldecode('foo%2Bbar') == u'foo+bar'
    assert unicode_urldecode('foo+%26+bar') == u'foo & bar'
    assert unicode_urldecode('%C3%A1%C3%A3%C3%A9') == u'áãé'


# Generated at 2022-06-11 14:10:48.468892
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%E1%88%B4') == u'\u1234'
    assert unicode_urldecode(u'%E1%88%B4%F0%9F%92%A9%E2%9C%A8%E2%AD%90') == u'\u1234\U0001F4A9\u2728\u24D0'
    assert unicode_urldecode(u'%E1%88%B4%20%F0%9F%92%A9%20%E2%9C%A8%20%E2%AD%90') == u'\u1234 \U0001F4A9 \u2728 \u24D0'


# Generated at 2022-06-11 14:10:51.100973
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%F0%9F%92%A9') == u'\U0001F4A9'
    assert unicode_urldecode('%20') == u' '


# Generated at 2022-06-11 14:10:53.900655
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    b = FilterModule()
    assert b.filters() == {'urldecode': do_urldecode, 'urlencode': do_urlencode}


# Generated at 2022-06-11 14:11:02.524256
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'my$test') == u'my%24test'
    assert unicode_urlencode(u'zo\xeb') == u'zo%EB'
    assert unicode_urlencode(u'\u4e2d\u6587') == u'%E4%B8%AD%E6%96%87'
    assert unicode_urlencode(u'/my/test/') == u'/my/test/'
    assert unicode_urlencode(u'my/test?x="1"') == u'my%2Ftest%3Fx%3D%221%22'



# Generated at 2022-06-11 14:11:06.436371
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Create test instance of FilterModule
    fmod = FilterModule()

    # Test filters method
    filters = fmod.filters()

    # Assert return values
    assert 'urldecode' in filters
    if not HAS_URLENCODE:
        assert 'urlencode' in filters


# Generated at 2022-06-11 14:11:16.154312
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'A B') == u'A+B'
    assert do_urlencode(u'A+B') == u'A%2BB'
    assert do_urlencode(u'A:B') == u'A%3AB'
    assert do_urlencode({'A': u'B', 'C': u'D'}) == u'A=B&C=D'
    assert do_urlencode(('A', 'B')) == u'A=B'
    assert do_urlencode({'a': 1}) == u'a=1'
    assert do_urlencode((u'a', 1)) == u'a=1'
    assert do_urlencode((u'a', [1, 2])) == u'a=1&a=2'




# Generated at 2022-06-11 14:11:21.409945
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foobar') == u'foobar'
    assert unicode_urlencode('/foobar/') == u'/foobar/'
    assert unicode_urlencode(u'\u83b7') == u'%E8%8E%B7'
    assert unicode_urlencode({u'a': u'\u83b7', u'b': u'foobar'}, for_qs=True) == u'a=%E8%8E%B7&b=foobar'


# Generated at 2022-06-11 14:11:26.937237
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == u'abc'
    assert unicode_urldecode('abc%20def') == u'abc def'
    assert unicode_urldecode('abc%7Edef') == u'abc~def'
    assert unicode_urldecode('%E4%B8%AD%E6%96%87') == u'中文'


# Generated at 2022-06-11 14:11:32.843027
# Unit test for function do_urlencode
def test_do_urlencode():

    assert do_urlencode('a+b') == 'a%2Bb'
    assert do_urlencode('a b') == 'a+b'
    assert do_urlencode('/a b') == '%2Fa+b'

    assert do_urlencode({'a': 'A', 'b': 'B'}) == 'a=A&b=B'
    assert do_urlencode(['a=A', 'b=B']) == 'a%3DA&b%3DB'



# Generated at 2022-06-11 14:11:42.733914
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(u'http://example.com/') == 'http%3A//example.com/'
    if PY3:
        assert do_urlencode('http://example.com/') == 'http%3A//example.com/'
    else:
        assert do_urlencode(unicode('http://example.com/')) == 'http%3A//example.com/'
    assert do_urlencode(u'http://ex%3Dample.com/') == 'http%3A//ex%3Dample.com/'
    assert do_urlencode({'test': 'ex&ample.com', 'test2': 'ex=ample.com'}) == 'test=ex%26ample.com&test2=ex%3Dample.com'
    assert do_urlencode

# Generated at 2022-06-11 14:11:44.934668
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('test') == 'test'
    assert unicode_urlencode('test test') == 'test%20test'


# Generated at 2022-06-11 14:11:47.353909
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('') == u''
    assert unicode_urlencode(u'') == u''
    assert unicode_urlencode(u'\u2027') == u'%E2%80%A7'



# Generated at 2022-06-11 14:11:54.106192
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%E8%89%B2') == u'色'
    assert unicode_urldecode('%E8%89%B2%E5%BD%B1') == u'色影'
    assert unicode_urldecode('%2Fa%3Fc%26d%3D') == u'/a?c&d='
    assert unicode_urldecode('%2Fa%3Fc%26d%3D') == u'/a?c&d='


# Generated at 2022-06-11 14:12:04.838172
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from tempfile import TemporaryFile

    from ansible.module_utils._text import to_bytes

    class TestUnicodeUrldecode(unittest.TestCase):
        def setUp(self):
            self.unicode_string = u'清华大学'
            self.bytes_string = b'\xe6\xb8\x85\xe5\x8d\x8e\xe5\xa4\xa7\xe5\xad\xa6'
            self.quoted_unicode_string = u'%E6%B8%85%E5%8D%8E%E5%A4%A7%E5%AD%A6'
            self.qu

# Generated at 2022-06-11 14:12:16.287099
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    # Test for filters with different input types

# Generated at 2022-06-11 14:12:22.390886
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # test urldecode filter
    fm = FilterModule()
    assert fm.filters()['urldecode']("abc") == u"abc"
    assert fm.filters()['urldecode']("abc%20def") == u"abc def"

    # test urlencode filter
    if not HAS_URLENCODE:
        assert fm.filters()['urlencode']("abc") == u"abc"
        assert fm.filters()['urlencode']("abc def") == u"abc+def"



# Generated at 2022-06-11 14:12:26.919720
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert len(f.filters()) == 2
    assert f.filters()['urldecode'] is do_urldecode
    assert f.filters()['urlencode'] is do_urlencode


# Generated at 2022-06-11 14:12:34.222963
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc') == 'abc'
    assert unicode_urldecode('abc+') == 'abc '
    assert unicode_urldecode('abc%2F') == 'abc/'
    assert unicode_urldecode('abc%2f') == 'abc/'
    assert unicode_urldecode('abc%252F') == 'abc%2F'
    assert unicode_urldecode('abc%C3%A9') == u'abc\u00e9'


# Generated at 2022-06-11 14:12:39.237806
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode'](u'%25%2B%2F%2C%3B') == u'%+/,;'
    assert FilterModule().filters()['urldecode'](u'%E2%80%A8') == u'\u2028'
    assert FilterModule().filters()['urldecode'](u'%E2%80%A9') == u'\u2029'

# Generated at 2022-06-11 14:12:47.500213
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode('%C3%A9') == u'é'

    assert unicode_urldecode(u'%41%42%43%40%21%24%26%27%28%29%2A%2B%2C%3B%3D') == u'ABC@!$&\'()*+,;='
    assert unicode_urldecode('%41%42%43%40%21%24%26%27%28%29%2A%2B%2C%3B%3D') == u'ABC@!$&\'()*+,;='


# Generated at 2022-06-11 14:12:54.002397
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('+++') == u' '
    assert do_urldecode('%20') == u' '
    assert do_urldecode('%7E') == u'~'
    assert do_urlencode(u' ') == '%20'
    assert do_urlencode(u'~') == '%7E'
    assert do_urlencode(u'+++') == '%2B%2B%2B'
    assert do_urlencode(u'&') == '%26'

# Generated at 2022-06-11 14:12:57.326151
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('foo') == 'foo'
    assert unicode_urldecode('foo%20bar') == 'foo bar'
    assert unicode_urldecode('foo+bar') == 'foo bar'


# Generated at 2022-06-11 14:12:59.453471
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%2F') == u'/'



# Generated at 2022-06-11 14:13:08.867222
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # type(None) is not a string
    assert unicode_urldecode(None) is None

    # Test conversion to unicode (py2 only)
    if not PY3:
        assert isinstance(unicode_urldecode(u'foo'), unicode)
        assert isinstance(unicode_urldecode('foo'), unicode)
        assert isinstance(unicode_urldecode(b'foo'), unicode)

    # Test decoding
    assert unicode_urldecode('a+b%20c') == u'a b c'
    assert unicode_urldecode('a+b%20c%2Bd') == u'a b c+d'
    assert unicode_urldecode('a+b%20c%2Bd%26e%3Df') == u

# Generated at 2022-06-11 14:13:17.467626
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%3C%3E%20%23%25%7B%7D%7C%5C%5E%5B%5D%60%3A%3B%22%27%2C%3F%2F%2B%26') == '<> #%{}|\\^[]`:;"\',?/+&'
    assert FilterModule().filters()['urldecode']('%3e%3c%20%23%25%7b%7d%7c%5c%5e%5b%5d%60%3a%3b%22%27%2c%3f%2f%2b%26') == '>< #%{}|\\^[]`:;"\',?/+&'
    assert FilterModule().fil

# Generated at 2022-06-11 14:13:22.078065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test cases for method FilterModule.filters
    fm = FilterModule()
    filters = fm.filters()
    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode
    else:
        assert 'urlencode' not in filters


# Generated at 2022-06-11 14:13:32.121398
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    # Test to determine whether unicode_urldecode is idempotent
    test_input = u'%20ABC%20DEF%20%7B%20%7D%20%5E%20%C2%A3%20%24%20%E2%82%AC%20%CE%B1%20%CF%86%20%CE%B8%20%E2%80%9E%20%E2%80%B9%20%E2%80%A6%20%E2%80%9D'
    test_output = u' ABC DEF { } ^ £ $ € α φ θ „ ‹ … ”'
    assert unicode_urldecode(test_input) == test_output
    assert unicode_urldecode(test_output) == test_output

#

# Generated at 2022-06-11 14:13:42.389330
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:13:52.069939
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    from ansible.module_utils import basic
    from ansible.module_utils.jinja2 import Environment

    jinja2_env = Environment(trim_blocks=True, lstrip_blocks=True,
                             undefined=basic.AnsibleUndefined)

    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['urldecode'] == do_urldecode
    if not HAS_URLENCODE:
        assert filters['urlencode'] == do_urlencode

    # test 'urldecode' filter
    test_string = u'%2Ftest%2Furl%3Fq%3Dabc%23'
    decoded_string = u'/test/url?q=abc#'


# Generated at 2022-06-11 14:14:01.787381
# Unit test for function do_urlencode
def test_do_urlencode():
    assert do_urlencode(None) == u''
    assert do_urlencode(u'foo') == u'foo'
    assert do_urlencode(u'foo bar') == u'foo+bar'
    assert do_urlencode(u'foo/bar') == u'foo%2Fbar'
    assert do_urlencode(u'foo bar/baz') == u'foo+bar%2Fbaz'
    assert do_urlencode(u'foo+bar') == u'foo%2Bbar'
    assert do_urlencode(u'föö+bär') == u'f%C3%B6%C3%B6%2Bb%C3%A4r'
    assert do_urlencode({'foo': 'foo bar', 'bar': 42}) == u

# Generated at 2022-06-11 14:14:12.535754
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(b'%E0%A4%95%E0%A5%81%E0%A4%96%E0%A5%80') == u'\u0915\u0941\u0936\u0940'
    assert unicode_urldecode(u'%E0%A4%95%E0%A5%81%E0%A4%96%E0%A5%80') == u'\u0915\u0941\u0936\u0940'
    assert unicode_urldecode(u'%E0%A4%95%E0%A5%81%E0%A4%96%E0%A5%80') == u'\u0915\u0941\u0936\u0940'

# Generated at 2022-06-11 14:14:14.278184
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('http%3A%2F%2Fwww.redhat.com') == u'http://www.redhat.com'



# Generated at 2022-06-11 14:14:20.681587
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    filter_obj = FilterModule()
    filters = filter_obj.filters()
    # Test urldecode()
    assert filters['urldecode'](u'foobar') == u'foobar'
    encoded = u'0%0A1%0A2'
    decoded = u'0\n1\n2'
    assert filters['urldecode'](encoded) == decoded
    # Test urlencode()
    if HAS_URLENCODE:
        assert sorted(filters.keys()) == ['urldecode', 'urlencode']
    else:
        assert sorted(filters.keys()) == ['urldecode', 'urlencode']
        assert filters['urlencode'](u'foobar') == u'foobar'

# Generated at 2022-06-11 14:14:31.260286
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode('foo') == 'foo'
    assert unicode_urlencode('foo/bar') == 'foo%2Fbar'
    assert unicode_urlencode('foo bar') == 'foo+bar'
    assert unicode_urlencode({'foo': 'bar'}) == 'foo=bar'
    assert unicode_urlencode({'foo': 'bar', 'baz': 'gronk'}) == 'foo=bar&baz=gronk'
    assert unicode_urlencode(('f o o', 'b a r')) == 'f%20o%20o=b%20a%20r'
    assert unicode_urlencode(['foo', 'bar']) == 'foo=bar'

# Generated at 2022-06-11 14:14:41.773624
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'a=1') == u'a%3D1'
    assert unicode_urlencode(u'a=1&b=2') == u'a%3D1%26b%3D2'
    assert unicode_urlencode(u'http://example.net/') == u'http%3A//example.net/'
    assert unicode_urlencode(u'http://example.net/', for_qs=True) == u'http%3A%2F%2Fexample.net%2F'

    assert unicode_urlencode(u'\u00e9') == u'%C3%A9'
    assert unicode_urlencode(u'a[1]=2') == u'a%5B1%5D%3D2'

# Generated at 2022-06-11 14:14:46.089564
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc+def') == u'abc def', 'unicode_urldecode to space'
    assert unicode_urldecode('abc%2Bdef') == u'abc+def', 'unicode_urldecode to +'



# Generated at 2022-06-11 14:14:55.241830
# Unit test for function unicode_urlencode

# Generated at 2022-06-11 14:14:56.599262
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {} == FilterModule.filters(FilterModule())

# Generated at 2022-06-11 14:15:04.328216
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'http%3A%2F%2Fansible.com%2Fblog%2F') == u'http://ansible.com/blog/'

# Generated at 2022-06-11 14:15:11.512452
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'www.example.com') == 'www.example.com'
    assert unicode_urlencode(u'www.example.com/some/path') == 'www.example.com%2Fsome%2Fpath'
    assert unicode_urlencode(u'www.example.com/some/path', for_qs=True) == 'www.example.com%2Fsome%2Fpath'


# Generated at 2022-06-11 14:15:14.656091
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class Mock(object):

        def filters(self):
            pass

    fm = FilterModule()
    filters = fm.filters()
    assert 'urldecode' in filters
    assert 'urlencode' in filters


# Generated at 2022-06-11 14:15:24.322720
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    # Make sure unicode_urlencode does not break urls
    original_url = '''
        username:password@example.com:8080/over/there/index.dtb?type=animal&name=narwhal#nose
    '''

    assert unicode_urlencode(original_url) == original_url

    # Make sure unicode_urlencode encodes all non alphanumeric characters
    url_with_non_alphanumeric_chars = '''
        ";/?:@&=+$,<>#%"
    '''


# Generated at 2022-06-11 14:15:27.242449
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'urldecode' in filters
    assert filters['urldecode'] is do_urldecode

    assert 'urlencode' in filters
    assert filters['urlencode'] is do_urlencode


# Generated at 2022-06-11 14:15:34.070159
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%7B%22hello%22%3A%22world%22%7D') == '{"hello":"world"}'
    try:
        unicode_urldecode(b'%7B%22hello%22%3A%22world%22%7D')
        assert False
    except TypeError:
        pass


# Generated at 2022-06-11 14:15:45.521611
# Unit test for function unicode_urldecode

# Generated at 2022-06-11 14:15:55.002206
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    from ansible.module_utils.six import PY3

    def assert_urldecode(original, expected):
        assert expected == unicode_urldecode(original)

    assert_urldecode(u'%2Ftest', u'/test')
    assert_urldecode(u'%7Btest', u'{test')
    assert_urldecode(u'%2Ftest%7Btest', u'/test{test')
    assert_urldecode(u'%2Ftest%7B{test', u'/test{{test')

    if PY3:
        assert_urldecode(b'%2Ftest', u'/test')
        assert_urldecode(b'%7Btest', u'{test')

# Generated at 2022-06-11 14:15:58.968089
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    assert unicode_urlencode(u'abcABC123') == u'abcABC123'
    assert unicode_urlencode(u'abc ABC 123') == u'abc%20ABC%20123'
    assert unicode_urlencode(u'a+b/c') == u'a%2Bb%2Fc'



# Generated at 2022-06-11 14:16:06.108407
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    import sys
    uri = u'http://example.com/test/\u00c9.html'
    if PY3:
        if sys.version_info[0] < 3:
            assert uri == do_urldecode(uri)
        else:
            assert uri != do_urldecode(uri)
            assert uri == do_urldecode(to_bytes(uri))
    else:
        assert uri == do_urldecode(uri)
        assert uri == do_urldecode(to_bytes(uri))



# Generated at 2022-06-11 14:16:09.167865
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'MyPr%C3%A9f%C3%A9rence') == u'MyPréférence'


# Generated at 2022-06-11 14:16:19.290094
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A9') == u'é'
    assert unicode_urldecode(u'%20') == u' '
    assert unicode_urldecode(u'%25') == u'%'
    assert unicode_urldecode(u'%2B') == u'+'
    assert unicode_urldecode(u'%2B%2B') == u'++'
    assert unicode_urldecode(u'%2B+') == u'+ '
    assert unicode_urldecode(u'%3D!') == u'=!'
    assert unicode_urldecode(u'%25%2B') == u'%+'

# Generated at 2022-06-11 14:16:25.749083
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['urldecode']('%20%3C%3E%23%25%7B%7D%7C%5E%7E%5B%5D%60') == u' <>#%{}|^~[]`'

    if not HAS_URLENCODE:
        assert FilterModule().filters()['urlencode']({'a': 'b c'}) == u'a=b+c'
        assert FilterModule().filters()['urlencode']('a=b&c=d') == u'a%3Db%26c%3Dd'


# Generated at 2022-06-11 14:16:32.854312
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'urldecode': do_urldecode,
    }
    # Permentantly replace filter_module.filters()['urlencode']
    if not HAS_URLENCODE:
        filter_module.filters()['urlencode'] = do_urlencode
    assert filter_module.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode,
    }



# Generated at 2022-06-11 14:16:39.600568
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from jinja2.utils import generate_lorem_ipsum
    assert u'Lorem+ipsum+dolor+sit+amet+consectetur+adipiscing+elit.+Pellentesque+euismod+purus+eu+leo+sagittis+placerat.+Proin+eu+neque+enim%2C+a+vulputate+elit.+Vestibulum+vel+congue+augue' == unicode_urlencode(generate_lorem_ipsum(5))

# Generated at 2022-06-11 14:16:44.333018
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'a%2Bb%2Bc') == u'a+b+c'
    assert unicode_urldecode(u'%E4%B8%AD%E6%96%87') == u'中文'


# Generated at 2022-06-11 14:16:51.731294
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    test_list = [{
        'input': b'test%20',
        'expected': "test ",
    }, {
        'input': b'test%2520',
        'expected': "test%20"
    }, {
        'input': 'test%2520',
        'expected': u"test%20"
    }, {
        'input': 'test%20',
        'expected': u"test "
    }]

    for test in test_list:
        assert unicode_urldecode(test['input']) == test['expected']


# Generated at 2022-06-11 14:16:56.122951
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_urldecode('%20') == ' '
    assert do_urldecode('%26') == '&'
    assert do_urldecode('%2B') == '+'

    assert isinstance(do_urlencode(' '), string_types)
    assert isinstance(do_urlencode('&'), string_types)
    assert isinstance(do_urlencode('+'), string_types)


# Generated at 2022-06-11 14:17:01.681270
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Verify urldecode filter is available
    assert callable(FilterModule.filters(None)['urldecode'])

    # Verify we have urlencode filter if Jinja2 is older than v2.7
    filters = FilterModule.filters(None)
    if HAS_URLENCODE:
        assert 'urlencode' not in filters
    else:
        assert callable(filters['urlencode'])


# Generated at 2022-06-11 14:17:08.957330
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    tests = {
        # Empty string
        '': '',
        # Single character
        'a': 'a',
        # Couple of characters
        'ab': 'ab',
        # Encoded characters
        '%00%01%02': '\x00\x01\x02',
        # Unicode characters
        '€': u'€',
        # Encoded unicode characters
        '%e2%82%ac': u'€'
    }

    for test in tests:
        assert unicode_urldecode(test) == tests[test]


# Generated at 2022-06-11 14:17:11.247031
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%25%2B%3D%3F%3B') == u'%+=?;'



# Generated at 2022-06-11 14:17:17.643628
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u"1+1=%C2%B11+1=2%2C+2%3D%C2%B12") == u"1+1=±11+1=2, 2=±2"
    assert unicode_urldecode(u"1+1=%E2%88%9A1+1=2%2C+2%3D%E2%88%9A2") == u"1+1=√1+1=2, 2=√2"


# Generated at 2022-06-11 14:17:25.970144
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    '''
    Unit test for unicode_urlencode.

    Validate that unicode_urlencode correctly handles various
    Python types.
    '''

# Generated at 2022-06-11 14:17:31.999340
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import unittest
    from ansible.module_utils.six.moves.urllib.parse import urlparse, parse_qsl

    class FilterModuleFilters(unittest.TestCase):
        def setUp(self):
            self.classmodule = FilterModule()

        # Unit test for method `do_urldecode`


# Generated at 2022-06-11 14:17:41.400284
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%20') == u' '
    assert unicode_urldecode('%25') == u'%'
    assert unicode_urldecode('%2B') == u'+'

    if PY3:
        assert unicode_urldecode('%40') == u'@'
    else:
        assert unicode_urldecode('%40') == u'@'

    assert unicode_urldecode('%5E') == u'^'
    assert unicode_urldecode('%60') == u'`'
    assert unicode_urldecode('%7B') == u'{'
    assert unicode_urldecode('%7C') == u'|'
    assert unicode_urldecode('%7D')

# Generated at 2022-06-11 14:17:49.665527
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('abc%20def') == 'abc def'
    assert unicode_urldecode('%E2%82%AC') == u'\u20ac'
    assert unicode_urldecode('abc%20def%E2%82%AC') == u'abc def\u20ac'
    assert unicode_urldecode('%E2%82%AC%20def%20abc') == u'\u20ac def abc'


# Generated at 2022-06-11 14:17:55.563239
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['urldecode'](u'foo+bar') == u'foo bar'
    assert filters['urldecode'](u'foo%20bar') == u'foo bar'
    if not HAS_URLENCODE:
        assert filters['urlencode'](u'foo bar') == u'foo+bar'
        assert filters['urlencode']({'a': 'foo', 'b': 'bar'}) == u'a=foo&b=bar'
        assert filters['urlencode']({'a': ['foo', 'bar']}) == u'a=foo&a=bar'



# Generated at 2022-06-11 14:17:57.872804
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'foo') == 'foo'
    assert unicode_urldecode(u'foo+bar') == 'foo bar'


# Generated at 2022-06-11 14:18:04.615824
# Unit test for function unicode_urlencode
def test_unicode_urlencode():
    from ansible.module_utils._text import to_text, to_bytes

    url_encoded_str = u'abc+def%2F%2B%2Fghi'
    url_decoded_str = u'abc def///ghi'

    # basic usage
    assert unicode_urlencode(url_decoded_str) == url_encoded_str

    # without unicode conversions
    assert unicode_urlencode(to_bytes(url_decoded_str)) == url_encoded_str

    # without unicode conversions
    assert unicode_urlencode(url_encoded_str) == url_encoded_str

    # test if quote_plus is called

# Generated at 2022-06-11 14:18:13.137484
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    value = "http://192.168.1.1/index.htm?name=%u5F20%u4E09&age=30"
    assert filters['urldecode'](value) == u"http://192.168.1.1/index.htm?name=张三&age=30"

    value = "http://192.168.1.1/index.htm?name=%u5F20%u4E09&age=30"
    assert filters['urlencode'](value) == u"http%3A%2F%2F192.168.1.1%2Findex.htm%3Fname%3D%25u5F20%25u4E09%26age%3D30"

# Generated at 2022-06-11 14:18:14.297504
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()


# Generated at 2022-06-11 14:18:18.233154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    assert filterModule.filters() == {
        'urldecode': do_urldecode,
        'urlencode': do_urlencode
    }

# Generated at 2022-06-11 14:18:21.185018
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('a+b') == u'a b'
    assert unicode_urldecode('a%2Bb') == u'a+b'



# Generated at 2022-06-11 14:18:27.102678
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode("%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A") == u'あいうえお'
    assert unicode_urldecode("%40%23%24%25%5E%26%2A%28%29_%2B%20%21%7E") == u'@#$%^&*()_+ ~!'
    assert unicode_urldecode("%7B%7D%5B%5D%3A%3B%22%2C%27%3C%3E%3F%2F") == u'{}[]:;"\',<>?/'

# Generated at 2022-06-11 14:18:35.974225
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode('%F0%9F%98%80') == '\U0001f600'
    assert unicode_urldecode('%F0%9F%98%80%F0%9F%98%BB') == '\U0001f600\U0001f6bb'
    assert unicode_urldecode('%26%3D%2A') == '&=*'
    assert unicode_urldecode('%0A') == '\n'
    assert unicode_urldecode('%0A%0D%0A') == '\n\r\n'
    assert unicode_urldecode('%00') == '\x00'


# Generated at 2022-06-11 14:18:49.081858
# Unit test for function unicode_urldecode
def test_unicode_urldecode():
    assert unicode_urldecode(u'%C3%A4') == u'\xe4'
    assert unicode_urldecode(u'%E2%9C%93') == u'\u2713'
    assert unicode_urldecode(b'%C3%A4') == u'\xe4'
    assert unicode_urldecode(b'%E2%9C%93') == u'\u2713'
    assert unicode_urldecode(b'This is a test') == u'This is a test'
    if PY3:
        assert unicode_urldecode('%E2%9C%93') == u'\u2713'
        assert unicode_urldecode('%C3%A4') == u'\xe4'