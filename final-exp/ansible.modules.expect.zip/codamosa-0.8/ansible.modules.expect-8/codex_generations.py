

# Generated at 2022-06-11 07:10:45.705481
# Unit test for function main
def test_main():
    args = dict(
        command = 'command',
        chdir = '/chdir/',
        creates = '/creates',
        removes = '/removes',
        responses = dict(
            a = 'b',
            c = ['d', 'e'],
        ),
        timeout = 10,
        echo = True,
    )
    def mock_exit_json(changed=None, **kwargs):
        print("Exiting with: %s %s" % (changed, kwargs))

    def mock_fail_json(rc=None, msg=None, **kwargs):
        print("Failure: %s %s %s" % (rc, msg, kwargs))


# Generated at 2022-06-11 07:10:52.752754
# Unit test for function main
def test_main():
    from test.unit.ansible.builtin.test_expect import TestExpect
    from test.mock.ansible.ansible import AnsibleModule
    from test.mock.ansible.ansible import AnsibleModule
    from test.mock.ansible.ansible import missing_required_lib
    from test.mock.ansible.ansible import to_bytes
    from test.mock.ansible.ansible import to_native
    from test.mock.ansible.ansible import to_text
    import pexpect
    import os
    import datetime

    main()
    main()
    main()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 07:11:05.210252
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    class ModuleStub(object):

        def __init__(self, params={'params': ''}):
            self.params = params

        def fail_json(self, message, **kwargs):
            raise Exception(message)

        def exit_json(self, **kwargs):
            return kwargs

    class PexpectStub(object):

        def __init__(self, params={'params': ''}):
            self.params = params

        def run(self, cmd, timeout=30, withexitstatus=True, events=None,
                cwd=None, encoding=None, echo=False):
            return to_bytes("Hello World!"), 0


# Generated at 2022-06-11 07:11:15.968373
# Unit test for function main

# Generated at 2022-06-11 07:11:28.131007
# Unit test for function main
def test_main():
    ''' main '''
    # pylint: disable=too-many-branches
    # pylint: disable=protected-access
    import pexpect
    from ansible.module_utils._text import to_bytes

    # Test with pexpect._run
    pexpect._run = lambda *args, **kargs: ('stdout', 0)
    with pytest.raises(SystemExit):
        main()

    # Test with pexpect.run
    pexpect.run = lambda *args, **kargs: ('stdout', 0)
    with pytest.raises(SystemExit):
        main()
    # Test with pexpect.run raising pexpect.ExceptionPexpect

# Generated at 2022-06-11 07:11:38.513260
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule({})
    question = 'Question'
    responses = ['response1', 'response2', 'response3']

    resp_gen = (b'%s\n' % r.rstrip(b'\n') for r in responses)
    wrapped = response_closure(module, question, responses)

    for i in range(0, 3):
        assert wrapped({'child_result_list': []}) == next(resp_gen)

    try:
        next(resp_gen)
        assert False
    except StopIteration:
        pass

    try:
        # Test for handling if the response has been exhausted
        wrapped({'child_result_list': ['output']})
        assert False
    except SystemExit:
        pass

# Generated at 2022-06-11 07:11:47.650952
# Unit test for function main
def test_main():
    try:
        import pexpect
    except ImportError:
        return

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    events = dict()
    for key, value in module.params['responses'].items():
        if isinstance(value, list):
            response = response_closure(module, key, value)

# Generated at 2022-06-11 07:11:51.495823
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as am:
        module = Mock(params={})
        am.return_value = module
        main()
        assert module.fail_json.called

# Generated at 2022-06-11 07:11:59.791118
# Unit test for function response_closure
def test_response_closure():
    # Create a mock module
    module = MockModule()
    # Create a mock closure, a simple lambda.
    # The closure here just returns the next item of a list.
    # When the expected question is encountered, the closure will
    # be called with the current context and the next item of the
    # list will be returned.
    responses = ['response1', 'response2', 'response3']
    response_closure_lambda = lambda info: responses.pop(0)

    # Create a mock event response map,
    # when the question 'Question' is encountered,
    # call the mock closure.
    events = {b'Question': response_closure_lambda}

    # Create a mock pexpect.spawn object and call the run function
    # with the mock event response map. The run function will call
    # the mock closure when the expected question is encountered.

# Generated at 2022-06-11 07:12:09.926424
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    question = "Successful Login"
    responses = ["a", "b", "c"]

    response = response_closure(module, question, responses)

    for i in range(1,4):
        info = {"child_result_list": ["Match %d" % i]}
        assert(response(info) == to_bytes("%s\n" % responses[i-1]))
    info

# Generated at 2022-06-11 07:12:30.792509
# Unit test for function main
def test_main():
    import os
    import pexpect
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )


# Generated at 2022-06-11 07:12:41.677634
# Unit test for function response_closure
def test_response_closure():
    '''
    Unit test for response_closure
    '''
    class FakeModule(object):
        '''
        Fake module to use in the test
        '''
        def __init__(self):
            self.failures = list()

        def fail_json(self, *args, **kwargs):
            '''
            Fake fail_json record args and kwargs
            '''
            self.failures.append(kwargs)

    question = 'Question'
    responses = [
        'Response 1',
        'response 2'
    ]
    module = FakeModule()
    callback = response_closure(module, question, responses)
    resp = callback({'child_result_list': list()})
    assert to_text(resp) == responses[0]


# Generated at 2022-06-11 07:12:53.280882
# Unit test for function main
def test_main():
    # Given
    with open("test-ansible.builtin.expect.module.yaml", 'r') as ff:
        my_args = yaml.load(ff)
    my_module = AnsibleModule(argument_spec=my_args)
    real_run = pexpect.run
    # Mocking pexpect.run
    pexpect.run = Mock()

# Generated at 2022-06-11 07:13:03.148264
# Unit test for function response_closure
def test_response_closure():
    test_module = object()
    test_question = object()
    test_responses = [object(), object(), object(), object()]
    resp_gen = (test_responses[i] for i in range(len(test_responses)))

    def wrapped(info):
        try:
            return next(resp_gen)
        except StopIteration:
            test_module.fail_json(msg="No remaining responses for '%s', "
                                 "output was '%s'" %
                                 (test_question,
                                  info['child_result_list'][-1]))

    expected = wrapped

    result = response_closure(test_module, test_question, test_responses)
    assert result == expected

# Generated at 2022-06-11 07:13:12.078578
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    class FakeModule(object):
        class FailJsonArguments(object):
            def __init__(self, msg, **kwargs):
                self.msg=msg
                self.kwargs=kwargs
        def __init__(self, **kwargs):
            self.params=kwargs
            self.fail_json_args = None
        def fail_json(self, msg, **kwargs):
            raise self.FailJsonArguments(msg, **kwargs)
    class TestResponseClosure(unittest.TestCase):
        def test_it(self):
            responses = ['success','success','success','reject','success','reject','reject','reject','reject']

# Generated at 2022-06-11 07:13:14.129457
# Unit test for function main
def test_main():
    assert(__name__ == '__main__')
    assert(main() == None)

# Generated at 2022-06-11 07:13:25.478765
# Unit test for function main
def test_main():
    #Get the path to the test data and create a temporary data file
    scriptdir = os.path.dirname(os.path.realpath(__file__))
    testdata = os.path.join(scriptdir, "expect_test_data.txt")

    testfile = open(testdata, "w")
    testfile.write("This is test data.")
    testfile.close()

    #Create the test command
    #Currently, this is the only command that is currently supported.
    command = "cat %s" % testdata

    #Create the event dictionary.  Currently, this is the only event dictionary
    #supported.  This is a dictionary of the form key = regex and value = string
    #to send.
    events = {
        "Enter the password:" : "test_password\n"
    }

    #Create the

# Generated at 2022-06-11 07:13:31.934275
# Unit test for function main
def test_main():
    # Simulate the pexpect run function
    class fake_pexpect():
        def run(self, *args, **kwargs):
            self.b_out = b'stdout'
            self.rc = 0
            return self.b_out, self.rc

        def runu(self, *args, **kwargs):
            self.b_out = b'stdout'
            self.rc = 0
            return self.b_out, self.rc

    def fake_pexpect_spawn(*args, **kwargs):
        return fake_pexpect()

    # Simulate the AnsibleModule object
    class TestModule():
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args


# Generated at 2022-06-11 07:13:39.342395
# Unit test for function main
def test_main():
    from ansible.modules.remote_management.network.nxos import expect
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # For AnsibleModule object
    MODULE_ARGS = {
        'command':'show version',
        'responses':{
            'would you like to proceed':'yes'
        },
        'chdir':'/root/tmp/'
    }
    setattr(sys.modules['ansible.modules.remote_management.network.nxos.basic'],
            'AnsibleModule', AnsibleModule)
    module = expect.main()
    assert module.params['command'] == 'show version'
    assert module.params['chdir'] == '/root/tmp/'

# Generated at 2022-06-11 07:13:44.673591
# Unit test for function main
def test_main():
    ret = main()
    assert ret
    assert type(ret) == type({})
    assert ret.has_key('cmd') == True
    assert ret.has_key('stdout') == True
    assert ret.has_key('rc') == True
    assert ret.has_key('start') == True
    assert ret.has_key('end') == True
    assert ret.has_key('delta') == True
    assert ret.has_key('changed') == True

# Generated at 2022-06-11 07:14:16.584051
# Unit test for function main
def test_main():
    args = ["ansible-playbook", "--check", "--diff", "-i", "hosts", "site.yml"]
    if not os.path.exists("hosts"):
        print("hosts file does not exist, check test site.yml")
        sys.exit(2)
    rc = main(args)
    if rc == 0:
        print("OK")
    else:
        print("NOK")

# Generated at 2022-06-11 07:14:28.103964
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import cStringIO
    import ansible.module_utils.basic
    import ansible.module_utils.action
    # set up our standard output to go to a buffer rather than print
    orig_stdout = sys.stdout
    test_buffer = cStringIO()
    sys.stdout = test_buffer
    # load our module
    m = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
   

# Generated at 2022-06-11 07:14:28.848646
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:39.661453
# Unit test for function response_closure
def test_response_closure():
    import pexpect
    import time
    import random
    import mock
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.modules import expect

    # Mock the AnsibleModule class to help test the expected failure.
    class FakeAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {
                'command': 'echo',
                'responses': {'Question': ['Yes', 'No', 'Maybe']},
            }
            self.args = args
            self.kwargs = kwargs

    # Mock the pexpect.spawn class.

# Generated at 2022-06-11 07:14:43.120026
# Unit test for function response_closure
def test_response_closure():
    cmd = 'echo "Test command"'
    event = {'question' : ['response1', 'response2']}

    # Simulate the function wrapped in a lambda function passed to the
    # pexpect.spawn() instance as the 'events' argument.
    # create information dictionary used by the 'response_closure'
    # function to retrieve the child process result
    child_result_list = []
    child_result_list.append('output of test command')
    info = {'child_result_list' : child_result_list}

    wrapped = response_closure(None, 'question', event['question'])
    wrapped(info)

# Generated at 2022-06-11 07:14:43.691136
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:54.130922
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    if not HAS_PEXPECT:
        module.fail_json(msg=missing_required_lib("pexpect"),
                         exception=PEXPECT_IMP_ERR)

    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']

# Generated at 2022-06-11 07:15:03.831305
# Unit test for function main
def test_main():
    os.chdir('/tmp')
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    if not HAS_PEXPECT:
        module.fail_json(msg=missing_required_lib("pexpect"),
                         exception=PEXPECT_IMP_ERR)

    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']

# Generated at 2022-06-11 07:15:05.377923
# Unit test for function main
def test_main():
    assert main('name') == None


# Generated at 2022-06-11 07:15:15.697330
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
    argument_spec=dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
    )
)
    question = "Test question"
    responses = ["response1","response2","response3","response4","response5"]
    response_func = response_closure(module, question, responses)
    expected_output_list = ["response1","response2","response3","response4","response5"]
    actual_output_list = []

# Generated at 2022-06-11 07:16:20.567297
# Unit test for function main
def test_main():
    # Test module function
    # The return value should be a dictionary
    assert("This module should return a dict")
    # There should be a key called 'stdout' in the dict
    assert("There should be a key 'stdout' in the dict")
    # There should be a key called 'end' in the dict
    assert("There should be a key 'end' in the dict")
    # There should be a key called 'delta' in the dict
    assert("There should be a key 'delta' in the dict")
    # There should be a key called 'changed' in the dict
    assert("There should be a key 'changed' in the dict")
    # There should be a key called 'rc' in the dict
    assert("There should be a key 'rc' in the dict")
    # There should be a key called 'start' in the

# Generated at 2022-06-11 07:16:21.891452
# Unit test for function main
def test_main():
    # TODO: autogenerate tests from docstrings
    pass

# Generated at 2022-06-11 07:16:30.317214
# Unit test for function main
def test_main():
    with pytest.raises(ImportError):
        import pexpect
    HEY_HEY_HEY = "HEY HEY HEAT"
    def print_and_wait(*args):
        print(HEY_HEY_HEY)
        return 10
    HEY_HEY_HEY = "HEY HEY HEAT"
    def print_and_wait_again(*args):
        print(HEY_HEY_HEY)
        return 5
    pexpect.spawn.side_effect = print_and_wait

# Generated at 2022-06-11 07:16:40.189842
# Unit test for function response_closure
def test_response_closure():
    import unittest

    class FakeModule(object):
        def fail_json(self, msg, **kwargs):
            self.msg = msg
            self.params = kwargs.get('child_result_list', None)

    class TestResponseClosure(unittest.TestCase):

        def test_single_response(self):
            a = FakeModule()
            r_c = response_closure(a, 'foo', ['bar'])
            self.assertEqual(r_c({'bar': 'baz'}), b'bar\n')

        def test_single_response_fail(self):
            a = FakeModule()
            r_c = response_closure(a, 'foo', ['bar'])
            r_c({'foo': 'bar'})

# Generated at 2022-06-11 07:16:51.766268
# Unit test for function main
def test_main():
    _m = MockedModule(dict(
        command = 'test command',
        chdir = 'test/path',
        creates = 'test/path/testfile.txt',
        removes = 'test/path/testfile2.txt',
        responses = {
            'test question': 'test response',
            'test response': 'test question'
        },
        timeout = 30,
        echo = False
    ))
    # First test that if the file is not found, it is skipped
    pexpect.exists.return_value = False
    main()
    assert _m.exit_json.called
    assert 'skipped, since test/path/testfile.txt exists' in _m.exit_json.call_args[1]['stdout']

# Generated at 2022-06-11 07:17:01.720648
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule

    responses = dict()
    responses['question'] = ['response1', 'response2']
    question = responses['question']

    module = AnsibleModule(argument_spec={})
    response = response_closure(module, question, responses)
    first_response = response({"child_result_list":[]})
    second_response = response({"child_result_list":[]})

    assert first_response == b'response1\n'
    assert second_response == b'response2\n'
    error_msg = "No remaining responses for '['response1', 'response2']', output was '[]'"

# Generated at 2022-06-11 07:17:13.330278
# Unit test for function main
def test_main():
    init_json = {
        "command": 'foo',
        "responses": {
            'bar?': 'foo',
            'baz?': ['bar', 'foo'],
        },
        "chdir": ".",
        "timeout": 2,
        "echo": True,
        "creates": None,
        "removes": None,
        "_ansible_version": "{}".format(ansible_version),
        "_ansible_sys_info": ansible_sys_info
    }


# Generated at 2022-06-11 07:17:22.440478
# Unit test for function response_closure
def test_response_closure():
    def test_module(responses):
        return AnsibleModule(argument_spec={'responses': dict(type='dict', required=True)},
                             params={'responses': responses})

    assert response_closure(test_module({'Question': 'Response'}), 'Question', ['Response'])('dict') == b'Response\n'
    assert response_closure(test_module({'Question': ['Response', 'Another response']}), 'Question', ['Response', 'Another response'])('dict') == b'Response\n'
    assert response_closure(test_module({'Question': ['Response', 'Another response']}), 'Question', ['Response'])('dict') == b'Another response\n'

# Generated at 2022-06-11 07:17:29.425845
# Unit test for function main
def test_main():
    import sys
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    module = patch.object(sys.modules[__name__], 'AnsibleModule')

    module = patch.object(sys.modules[__name__], 'HAS_PEXPECT', True)

    module = patch.object(sys.modules[__name__], 'pexpect')

    mock_main = patch.object(sys.modules[__name__], 'main')
    mock_main.return_value = True

# Generated at 2022-06-11 07:17:37.090212
# Unit test for function main
def test_main():
    # Make sure that the module fails when no command given
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True, default=None),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict'),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    try:
        main()
    except SystemExit:
        assert True
    else:
        assert False

    # Make sure that the module fails when the command returns non-zero

# Generated at 2022-06-11 07:19:42.612909
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={'responses': dict(type='dict', required=True)})

    # Test case without list
    question = 'my question'
    responses = ['my response']
    response = response_closure(module, question, responses)

    # Test case with a list
    question = 'another question'
    responses = ['a response', 'another response']
    response = response_closure(module, question, responses)

    try:
        response({'child_result_list': ['my result']})
    except AnsibleModuleFail:
        pass

# Generated at 2022-06-11 07:19:43.232234
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:19:52.930971
# Unit test for function response_closure
def test_response_closure():
    ''' Unit test for response_closure'''
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.ansible_modlib.testcase_runner.custom_assertions import assert_items_equal

# Generated at 2022-06-11 07:19:53.621897
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:19:54.186223
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:20:00.912857
# Unit test for function main
def test_main():
    # module_name = 'ansible.builtin.expect'
    module_name = __name__

    args = {
        'command': 'uname -a',
        'responses': {'to be or not to be': 'i am'}
    }

    module = AnsibleModule({}, supports_check_mode=True)
    import ansible
    ansible.module_utils.action_plugins[module_name] = ansible.module_utils.basic
    import ansible.module_utils.basic

# Generated at 2022-06-11 07:20:01.625700
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:20:12.713130
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils._text
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six
    import ansible.module_utils.six.moves

    import ansible.modules.system.expect
    import sys
    import collections

    module = ansible.module_utils.ansible_release.AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )



# Generated at 2022-06-11 07:20:22.598489
# Unit test for function main
def test_main():
    # Run the main function
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    module.params = dict(
        command='command',
        chdir='\temp',
        creates='\file1.txt',
        removes='\file2.txt',
        responses=dict(some_question='some_answer'),
        timeout=60,
        echo=False,
    )

    main()