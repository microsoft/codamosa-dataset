

# Generated at 2022-06-11 07:10:47.617332
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.args = args

        def fail_json(self, *args, **kwargs):
            self.fail_args = args
            self.fail_kwargs = kwargs
            raise Exception("Test Exception")

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    class MockPexpect(object):
        class ExceptionPexpect(Exception):
            pass

        def __init__(self):
            self.spawn_calls = []
            self.spawn_returns = []
            self.spawn_exceptions = []


# Generated at 2022-06-11 07:10:58.313859
# Unit test for function response_closure
def test_response_closure():
    class ModuleMock:
        def __init__(self):
            self.called = False

        def fail_json(self, msg, child_result_list=[]):
            self.called = True
            assert child_result_list == ['test_output']
            assert msg == "No remaining responses for 'question', output was 'test_output'"

    module_mock = ModuleMock()
    resp = response_closure(module_mock, 'question', ['test1', 'test2', 'test3'])

    assert resp({'child_result_list': []}) == b'test1\n'
    assert resp({'child_result_list': []}) == b'test2\n'
    assert resp({'child_result_list': []}) == b'test3\n'
    assert module_mock.called == True

# Generated at 2022-06-11 07:11:10.337424
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    args = dict(
        command='echo "hello"',
        chdir='/tmp',
        creates='/tmp/test',
        removes='/tmp/test2',
        responses=dict(
            question1='answer1',
            question2='answer2',
        ),
        timeout=5,
        echo=True,
    )


# Generated at 2022-06-11 07:11:18.602682
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    mod = basic.AnsibleModule(argument_spec={})
    mod.fail_json = lambda msg: None
    resp = ['a', 'b', 'c']
    res = response_closure(mod, 'foo', resp)
    assert res({'child_result_list': []}) == b'a\n'
    assert res({'child_result_list': []}) == b'b\n'
    assert res({'child_result_list': []}) == b'c\n'
    assert res({'child_result_list': []}) == b'a\n'
    assert res({'child_result_list': []}) == b'b\n'

# Generated at 2022-06-11 07:11:29.623368
# Unit test for function main

# Generated at 2022-06-11 07:11:41.034531
# Unit test for function response_closure
def test_response_closure():
    input_responses = ['response1', 'response2', 'response3']
    expected_responses = [b'response1\n', b'response2\n', b'response3\n']
    question = 'Question'
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    cls = response_closure(module, question, input_responses)

    # Generating all the possible results with a single method call

# Generated at 2022-06-11 07:11:52.875091
# Unit test for function main
def test_main():
    import pytest
    import collections

    # Mock io functions
    io_functions = collections.namedtuple('mock_io_functions', ['file_open'])

    def mock_file_open(filename, *args, **kwargs):
        def mocked_file_open(*args, **kwargs):
            return open('/dev/null', *args, **kwargs)
        return mocked_file_open
    mock_io = io_functions(file_open=mock_file_open)

    # Mock module class
    class mock_module(object):

        def __init__(self, *args, **kwargs):
            pass

        def exit_json(*args, **kwargs):
            pass

        def fail_json(*args, **kwargs):
            pass


# Generated at 2022-06-11 07:12:00.516218
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_native
    import os
    from tempfile import mkstemp
    from shutil import rmtree
    from tempfile import mkdtemp
    from time import sleep

    from . import test_data
    from .test_data import get_test_data

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    empty_file = os.path.join(fixture_path, 'empty-file')
    non_empty_file = os.path.join(fixture_path, 'non-empty-file')

# Generated at 2022-06-11 07:12:10.844261
# Unit test for function response_closure
def test_response_closure():
    import sys
    import io
    import mock

    # Mock out the rstrip() call for the following test. This is useful
    # because we aren't really interested in testing it; we want to test
    # that the returned value is what we think it is.
    response_closure.rstrip = mock.MagicMock()

    # Mock out the module.fail_json() call for the following test. This is
    # useful because we aren't really interested in testing it; we want to
    # test that the returned value is what we think it is.
    response_closure.fail_json = mock.MagicMock()

    # If a list of responses is provided, successive matches should each
    # return the next response in the list.
    questions = [
        "question1",
        "question2",
    ]

# Generated at 2022-06-11 07:12:22.030367
# Unit test for function main
def test_main():
    # Initialize argument parser and create fake args
    args = ['/usr/bin/ansible-playbook', 'runme.yml', '--extra-vars={"user":"michael","password":"1234"}', '-v']
    import sys
    sys.argv = args
    sys.argv.pop()

    # Create fake module
    import argparse
    class FakeModule(argparse.Namespace):
        def __init__(self, dict):
            for k, v in dict.items():
                setattr(self, k, v)

    options = {}
    options['command'] = 'test'
    options['timeout'] = 30
    options['echo'] = False
    options['responses'] = {'Exit? \(yes/no\)\ [no]:':'yes'}

# Generated at 2022-06-11 07:12:34.863681
# Unit test for function main
def test_main():
    args = dict(
    )

    # Test simple usage of main
    test_args = args.copy()
    result = main(test_args)
    assert main() == None
    assert result != None

# Generated at 2022-06-11 07:12:43.411608
# Unit test for function response_closure
def test_response_closure():
    responses = ['Test-1', 'Test-2']
    quest = 'Quest'
    child_result_list = ['Hello World!']
    result = response_closure(self, quest, responses)
    # First call
    expected_result = b'Test-1\n'
    assert result(child_result_list) == expected_result
    # Second call
    expected_result = b'Test-2\n'
    assert result(child_result_list) == expected_result
    # Third call raises a StopIteration exception
    with pytest.raises(StopIteration):
        result(child_result_list)

# Generated at 2022-06-11 07:12:54.618533
# Unit test for function main
def test_main():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_text
    from ansible.plugins.action.copy import ActionModule as CopyActionModule

    # __file__ is not available for import of this module, so we'll
    # fake it to make testing *somewhat* easier
    imp.load_source('ansible.builtin.expect', 'ansible/modules/system/expect.py')
    imp.load_source('ansible.module_utils.basic', 'ansible/module_utils/basic.py')

    module = MockAnsibleModule()


# Generated at 2022-06-11 07:13:06.524628
# Unit test for function main
def test_main():
    import sys
    import subprocess
    import os
    import pexpect
    old = sys.argv
    main = sys.modules[__name__].main

# Generated at 2022-06-11 07:13:13.656321
# Unit test for function main
def test_main():
    import json
    import base64
    stdout_base64 = b'Cg=='
    stdout = base64.b64decode(stdout_base64).decode('utf-8')
    response = 0
    startd = datetime.datetime.now()
    endd = datetime.datetime.now()
    delta = endd - startd
    rc = 0
    args = '/bin/false'
    chdir = None
    creates = None
    removes = None
    timeout = 3
    echo = False
    events = {}

# Generated at 2022-06-11 07:13:25.113350
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = 'something'
    responses = ['this', 'that', 'the other']
    resp_value = response_closure(module, question, responses)

    assert resp_value(dict(child_result_list=[])) == b'this\n'
    assert resp_value(dict(child_result_list=[])) == b'that\n'

# Generated at 2022-06-11 07:13:31.651630
# Unit test for function response_closure
def test_response_closure():
    import unittest
    import ansible.module_utils.basic as module_utils
    import ansible.module_utils

    ansible.module_utils.basic._ANSIBLE_ARGS = None
    args = dict(command='command',
                responses=dict(foo='bar',))

    module = module_utils.AnsibleModule(**args)

    class FakeInfo(object):
        def __init__(self):
            self.index = 0
        def __call__(self, info):
                self.index += 1
                if self.index == 1:
                    info['child_result_list'] = ["foo"]
                return "bar"
    fake_info = FakeInfo()

    responses = ['bar', 'baz']
    wrapped = response_closure(module, "foo", responses)


# Generated at 2022-06-11 07:13:39.201414
# Unit test for function response_closure
def test_response_closure():
    import mock

    # Ensure that a string response is returned when the generator
    # only has one item
    module = mock.Mock()
    question = 'This is a question'
    responses = ['This is a response']
    expected = b'%s\n' % to_bytes(responses[0]).rstrip(b'\n')
    wrapped = response_closure(module, question, responses)
    actual = wrapped(None)
    assert actual == expected

    # Ensure that a string response is returned when the generator
    # has more than one item
    module = mock.Mock()
    question = 'This is a question'
    responses = ['This is a response', 'This is another response']
    expected = b'%s\n' % to_bytes(responses[0]).rstrip(b'\n')
    wrapped = response

# Generated at 2022-06-11 07:13:47.751257
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            responses=dict(type='dict', required=True),
        )
    )
    responses = ["response1", "response2", "response3"]
    question = "Question"
    response = response_closure(module, question, responses)

    assert response({"child_result_list": [1, 2, 3]}) == b"response1\n"
    assert response({"child_result_list": [1, 2, 3]}) == b"response2\n"
    assert response({"child_result_list": [1, 2, 3]}) == b"response3\n"

# Generated at 2022-06-11 07:13:56.995900
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (2, 6):
        return

    m = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    m._ansible_no_log = True

    # Create a temp directory to work in
    tmp = tempfile.mkdtemp()
    os.chdir(tmp)

    # Write a file

# Generated at 2022-06-11 07:14:30.074428
# Unit test for function main
def test_main():
    from ansible.modules.system.expect import main
    from ansible.module_utils.common.collections import ImmutableDict
    from io import StringIO
    import contextlib
    import os
    import sys
    import tempfile
    import unittest

    test_args = {
        'command': '/path/to/custom/command',
        'responses': {
            'Question': 'response1'
        },
        'timeout': 30,
        'echo': False
    }

    test_env = os.environ.copy()
    test_env.update({ 'ANSIBLE_MODULE_ARGS': to_text(ImmutableDict(test_args)) })

    def fake_pexpect_run(command, **kwargs):
        return b'response1\n', 0


# Generated at 2022-06-11 07:14:40.686424
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.removed import removed_module
    # Invalid name test
    with pytest.raises(basic.AnsibleFailJson) as excinfo:
        module = AnsibleModule(
            argument_spec=dict(
                command=dict(required=True),
                chdir=dict(type='path'),
                creates=dict(type='path'),
                removes=dict(type='path'),
                responses=dict(type='dict', required=True),
                timeout=dict(type='int', default=30),
                echo=dict(type='bool', default=False),
            )
        )
        chdir = module.params['chdir']
        args = module.params['command']
        creates = module.params['creates']
        removes = module

# Generated at 2022-06-11 07:14:48.485626
# Unit test for function main
def test_main():
    import mock

    args = {
        'command': '/bin/true',
        'chdir': None,
        'creates': None,
        'removes': None,
        'responses': {},
        'timeout': 30,
        'echo': False
    }

    m = mock.MagicMock(return_value=b'true')
    m.side_effect = [
        # args, timeout, withexitstatus, events,
        # extra_args, logfile, cwd, env, _spawn
        (b'true', 0, None, None,
         None, None, None, None, None, None, None)
    ]

    with mock.patch.object(pexpect, 'run', m):
        from ansible.modules.packaging import expect
        res = expect.main()


# Generated at 2022-06-11 07:14:59.637485
# Unit test for function response_closure
def test_response_closure():
    import sys
    import copy

    parent = sys.modules['__main__']

    # Create a dummy module object
    module = type('AnsibleModule', (object,), dict(
        fail_json=lambda *args, **kwargs: sys.exit(1),
        exit_json=lambda *args, **kwargs: sys.exit(0)
    ))()

    # Capture stderr to check for errors
    saved_stderr = sys.stderr

# Generated at 2022-06-11 07:15:10.008136
# Unit test for function main
def test_main():
  import os
  import tempfile
  import unittest
  import pexpect
  import filecmp

  class TestPexpect(unittest.TestCase):
    def setUp(self):
      self.tempdir = tempfile.mkdtemp()
      os.chdir(self.tempdir)

    def tearDown(self):
      os.chdir('/')
      if os.path.exists(self.tempdir):
        import shutil
        shutil.rmtree(self.tempdir)

    # Unit test for function main
    def test_main_1(self):
      test_file_1 = os.path.join(self.tempdir, "test_file_1.txt")

# Generated at 2022-06-11 07:15:20.238291
# Unit test for function main
def test_main():
    test_arguments = {'command': 'dummy command','responses': 'dummy_responses','chdir': 'dummy_chdir'}
    test_args = {
        'chdir': 'dummy_chdir',
        'creates': 'dummy_creates',
        'removes': 'dummy_removes',
        'responses': 'dummy_responses',
        'timeout': 'dummy_timeout',
        'echo': 'dummy_echo',
    }

# Generated at 2022-06-11 07:15:28.911144
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    module = AnsibleModule({
        'command': 'ls',
        'responses': {'hello': 'world'},
        'timeout': 30,
        'echo': False
    })
    try:
        main()
    except AnsibleExitJson as e:
        print(e.args)
        print(e.args[0]['cmd'])
        assert(e.args[0]['cmd'] == 'ls')
    except AnsibleFailJson as e:
        print(e.args)
        print(e.args[0]['msg'])

# Generated at 2022-06-11 07:15:34.077692
# Unit test for function main
def test_main():
    args = dict(
        command='/bin/echo',
        responses=dict(
            question=['response', 'response']
        )
    )

    pexpect_calls_expected = [dict(
        args=['/bin/echo', (('cwd', None), ('env', None), ('encoding', None), ('logfile', None), ('timeout', None), ('withexitstatus', True), ('events', None), ('extra_args', None))],
        kwargs=dict(echo=False, _spawn=pexpect.spawn)
    )]

    pexpect_returns_expected = [dict(
        out=b'response\r\n'
    )]

    module_args = dict(
        command='/bin/echo',
        responses=dict(
            question=['response']
        )
    )

# Generated at 2022-06-11 07:15:43.532678
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})

    responses = ['response1', 'response2', 'response3']
    question = 'Question'

    responder = response_closure(module, question, responses)

    assert responder({'child_result_list': [b'Output']}) == b'response1\n'
    assert responder({'child_result_list': [b'Output']}) == b'response2\n'
    assert responder({'child_result_list': [b'Output']}) == b'response3\n'

    try:
        responder({'child_result_list': [b'Output']})
    except SystemExit as e:
        assert "No remaining responses for '%s'" % question in e.message

# Generated at 2022-06-11 07:15:49.919199
# Unit test for function main
def test_main():
    # Test with no command given
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    args = ''
    chdir = module.params['chdir']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']

    events = dict()

# Generated at 2022-06-11 07:16:33.691606
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:40.539545
# Unit test for function main
def test_main():
    from ansible.module_utils import temporary_path
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from io import BytesIO

    module_args = dict(
        command=to_bytes("ls -ld /"),
        responses=dict(
        ),
    )

    basic._ANSIBLE_ARGS = to_bytes('')
    with temporary_path() as t_path:
        basic.HAS_PEXPECT = True
        with BytesIO() as stdout:
            rc = main()
            assert(rc == 0)


# Generated at 2022-06-11 07:16:42.167883
# Unit test for function main
def test_main():
    # test for function main
    # TODO: Add tests
    pass

# Generated at 2022-06-11 07:16:53.509680
# Unit test for function main
def test_main():
    command = 'pwd'
    responses = {'question': 'response'}

    # Test if module is not pexpect
    m = AnsibleModule(argument_spec=dict(
        command=dict(required=True),
        responses=dict(type='dict', required=True),))
    assert main(m) == 'module.fail_json'

    # Test if pexpect is not installed
    import sys
    sys.path_hooks = []
    assert main(m) == 'module.fail_json'

    # Test if pexpect version is lower than 3.3
    m.params['command'] = command
    m.params['responses'] = responses
    m.pexpect.__version__ = '3.2'
    assert main(m) == 'module.fail_json'

    # Test if created file exists

# Generated at 2022-06-11 07:17:02.925312
# Unit test for function main
def test_main():

    # Mock pexpect import and subsequent functions
    module_mock = None
    def expect_run_side_effect(args, timeout=30, withexitstatus=True,
                               events=None, cwd=None, encoding=None):
        class MockResult:
            status = 0
            stdout = b'already done'
        return MockResult()
    def expect__run_side_effect(args, timeout=30, withexitstatus=True,
                                events=None, extra_args=None, logfile=None,
                                cwd=None, env=None, _spawn=None, echo=False):
        class MockResult:
            status = 0
            stdout = b'already done'
        return MockResult()
    def expect_ExceptionPexpect_side_effect(msg):
        raise pexpect

# Generated at 2022-06-11 07:17:03.647731
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:17:14.939219
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.six import PY2, PY3
    import sys
    if PY2:
        reload(sys)
        sys.setdefaultencoding('utf8')

    class FakeModule(object):
        def __init__(self, module_name='test_name', params={'responses': {}}):
            self.params = params
            self.fail_json = 'fail_json_%s' % module_name

    fake_module = FakeModule()

    # response_closure should return a function, when it is called it returns the next response
    expected_response = ['response1', 'response2']
    response = response_closure(fake_module, 'Question', expected_response)
    for i in range(2):
        assert response(expected_response[i]) == expected_response[i]

   

# Generated at 2022-06-11 07:17:24.398793
# Unit test for function main
def test_main():

    #NOTE: We use the devel branch of the Ansible repo for development, not the stable branch.
    #      This is why we're testing against the devel branch version spec.
    test_main_args = dict(
        command=[
            'ansible-playbook',
            '--help'
        ],
        chdir='',
        creates='',
        removes='',
        responses={
            # There are no expected prompts when running `ansible-playbook --help`
            # So we give it a totally fake response to a non-existent question
            'This is a totally invalid question': 'This is a totally invalid response'
        },
        timeout='30',
        echo='false'
    )


# Generated at 2022-06-11 07:17:33.143185
# Unit test for function response_closure
def test_response_closure():
    class FakeModule:
        def __init__(self):
            pass
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    class FakeOpts:
        pass

    responses = iter(['response1', 'response2', 'response3'])
    question = 'Question'
    closure = response_closure(FakeModule(), question, responses)
    result = []
    for i in range(1, 10):
        result.append(closure({'child_result_list': ['hi']}))
    expected = [b'response1\n', b'response2\n', b'response3\n'] * 3
    assert result == expected

# Generated at 2022-06-11 07:17:41.395324
# Unit test for function main
def test_main():
    import json
    import os
    import shutil
    import sys
    import time
    import tempfile

    bin_dir = os.path.dirname(os.path.realpath(sys.argv[0]))

    base_dir = tempfile.mkdtemp(prefix='ansible-test-expect-')

    second_dir = os.path.join(base_dir, 'second')
    os.mkdir(second_dir)

    # test passing and failing
    for arg in (
        # should succeed
        dict(command='echo yay', rc=0, changed=True,
             stdout='yay'),

        # should fail
        dict(command='echo boo', rc=1, changed=True,
             stdout='boo'),
    ):
        command = arg['command']
        expected_rc = int

# Generated at 2022-06-11 07:19:50.048507
# Unit test for function response_closure
def test_response_closure():
    import mock
    import sys

    module = mock.MagicMock()

    # Test that repeated uses of the closure return all responses
    closure = response_closure(module, 'foo', ['bar', 'baz'])
    assert closure(1) == b'bar\n'
    assert closure(1) == b'baz\n'

    # Test that the closure fails with an exception if there are no more
    # responses
    closure = response_closure(module, 'foo', ['bar'])
    try:
        assert closure(1)
    except SystemExit:
        err = sys.exc_info()[1]
        assert err.code == 1
    else:
        assert False

    # Test that the module fails when it runs out of responses
    closure = response_closure(module, 'foo', ['bar'])

# Generated at 2022-06-11 07:19:58.448515
# Unit test for function response_closure
def test_response_closure():
    # The function's code uses the next() function, which doesn't work on
    # empty generators.

    from operator import truediv

    # To assert that the function returns the correct value when given a
    # non-empty generator.

    # Inputs
    module = AnsibleModule(match_plugins=['builtin', 'test_matchers'])
    is_empty = False
    # To test if the function returns the correct value when the generator
    # is not empty.
    response_generator = (1,2,3,4,5)
    expected_output = 1
    # The expected output should be the first item in the generator.

    # Process
    actual_output = response_closure(module,
                                     "test question",
                                     response_generator)

    # Output
    assert expected_output == actual_output()




# Generated at 2022-06-11 07:20:07.238827
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            responses=dict(type='dict', required=True),
        )
    )
    f = response_closure(module, "question",
                         ['foo', 'bar', 'baz'])
    assert f({'child_result_list': []}) == b'foo\n'
    assert f({'child_result_list': []}) == b'bar\n'
    assert f({'child_result_list': []}) == b'baz\n'
    try:
        f({'child_result_list': []})
    except SystemExit:
        pass
    else:
        raise AssertionError("Expected the function to raise an exception")

# Generated at 2022-06-11 07:20:18.616689
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    events = dict()

# Generated at 2022-06-11 07:20:26.666131
# Unit test for function main
def test_main():
    """Test case for function main"""
    # create a temporary directory
    import tempfile
    from ansible_collections.ansible.community.plugins.module_utils.action.expect import response_closure, main

    tmpdir = tempfile.mkdtemp()
    testfile = to_text(os.path.join(tmpdir, 'testfile'))
    testfile2 = to_text(os.path.join(tmpdir, 'testfile2'))

    # create a simple module object
    import ansible_collections.ansible.community.plugins.modules.action.expect as expect