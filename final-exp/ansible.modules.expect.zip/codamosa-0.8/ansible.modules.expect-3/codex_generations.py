

# Generated at 2022-06-11 07:10:43.241100
# Unit test for function response_closure
def test_response_closure():
    class FakeModule(object):
        def fail_json(*args, **kwargs):
            pass

    expected_results = [1, 2, 3, 4]
    test_gen = (x for x in range(1, 10))
    test_closure = response_closure(FakeModule(), 'test_question', expected_results)

    for expected in expected_results:
        assert test_closure({}) == expected

    # Now we should get a StopIteration
    with pytest.raises(StopIteration):
        test_closure({'child_result_list': [1]})

# Generated at 2022-06-11 07:10:44.361336
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:10:52.779175
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    test_cases = [
        # test response as string
        (ImmutableDict({'resp_str': 'test_resp'}), 'test_resp'),
        # test response as list
        (ImmutableDict({'resp_list': ['test_resp1', 'test_resp2']}), 'test_resp1'),
        # test response as list
        (ImmutableDict({'resp_list': ['test_resp1', 'test_resp2']}), 'test_resp2'),
    ]

# Generated at 2022-06-11 07:11:05.333390
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class MockShellModule(object):
        def __init__(self, argspec, params):
            self.args = argspec
            self.params = params
            self.exit_json_args = None
            self.fail_json_args = None

        def exit_json(self, **args):
            self.exit_json_args = args

        def fail_json(self, **args):
            self.fail_json_args = args

    class MockPexpect(object):
        class ExceptionPexpect(Exception):
            pass

        class TIMEOUT(Exception):
            pass

        class EOF(Exception):
            pass


# Generated at 2022-06-11 07:11:07.240716
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    assert 'err' in main()


# Generated at 2022-06-11 07:11:17.210250
# Unit test for function main
def test_main():
    test_args = dict(
        command='mycommand',
        chdir='/my/chdir',
        creates='/my/creates',
        removes='/my/removes',
        responses=dict(key='value'),
        timeout=30,
        echo=False
    )
    with patch.dict(os.environ, {
            'HOME': '/',
            'PATH': '',
            'PWD': '/',
            'LANG': 'en_US.UTF-8',
            'LC_ALL': 'en_US.UTF-8',
            'TERM': 'xterm',
            'SHELL': '/bin/sh'
    }):
        temp_cwd = tempfile.mkdtemp()
        this_dir = os.path.dirname(os.path.realpath(__file__))


# Generated at 2022-06-11 07:11:28.816450
# Unit test for function response_closure
def test_response_closure():

    class Module(object):

        def __init__(self):
            self.params = {}
            return

        def fail_json(self, msg, **kwargs):
            return

    module = Module()

    responses = ['1', '2', '3']
    question = 'Question'

    response = response_closure(module, question, responses)
    res = response({})
    assert res == b"1\n"

    res = response({})
    assert res == b"2\n"

    res = response({})
    assert res == b"3\n"

    # Should fail here because no more responses
    from ansible.module_utils.basic import AnsibleAssertionError
    try:
        response({})
        assert False
    except AnsibleAssertionError:
        pass

# Generated at 2022-06-11 07:11:40.217063
# Unit test for function response_closure
def test_response_closure():
    import mock

    class FakeModule(object):
        _ansible_no_log = False

        def fail_json(self, *args, **kwargs):
            raise AssertionError('fail_json: %s %s' % (args, kwargs))

    def mock_function(*args, **kwargs):
        raise AssertionError('mock: %s %s' % (args, kwargs))

    fm = FakeModule()
    fm.fail_json = mock_function

    rc = response_closure(fm, "Question", ['response1', 'response2'])

    r1 = rc({'child_result_list': []})
    assert r1 == 'response1\n'

    r2 = rc({'child_result_list': ['']})

# Generated at 2022-06-11 07:11:48.532825
# Unit test for function response_closure
def test_response_closure():
    import sys
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestResponseClosures(unittest.TestCase):
        def test_response_closure_with_list(self):
            from ansible.module_utils import basic
            from ansible.module_utils._text import to_text
            import ansible
            module = basic.AnsibleModule(
                argument_spec=dict(
                    responses=dict(type='dict', required=True),
                )
            )
            question = 'test_string_in'
            responses = ['response1', 'response2', 'response3']

# Generated at 2022-06-11 07:11:58.496336
# Unit test for function response_closure
def test_response_closure():
    import mock
    module = mock.Mock(name='ansible.module_utils.basic.AnsibleModule()')
    # Setup return value of module.fail_json()
    module.fail_json.side_effect = SystemExit
    question = 'Question:'
    responses = [
        'response1',
        'response2',
        'response3'
    ]
    index = 0
    resp_gen = response_closure(module, question, responses)

    # Loop over all responses, indexing from 0
    for item in responses:
        resp_gen(None)

    # Check one further to invoke the exception case

# Generated at 2022-06-11 07:12:19.904848
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(**{})

    # It should return a generator function that returns the first string
    question = 'question'
    responses = ['First response', 'Second response']
    gen_func = response_closure(module, question, responses)
    assert callable(gen_func)
    assert gen_func() == b'First response\n'

    # The second invocation should return the second string
    assert gen_func() == b'Second response\n'

    # The third invocation should raise an exception
    called = False
    info = {
        'child_result_list': [b'First response\n', b'Second response\n']
    }
    try:
        gen_func(info)
    except Exception as e:
        called = True

# Generated at 2022-06-11 07:12:28.894016
# Unit test for function main
def test_main():
    out, err = capsys.readouterr()
    assert out.split('\n')[0] == "[WARNING]:  * Failed to parse /tmp/ansible_expect_payload_X9il7x_ with yaml. Please see examples page for correct syntax."
    assert out.split('\n')[1] == "[WARNING]:  * See: https://docs.ansible.com/ansible/latest/modules/" \
                                 "expect_module.html#notes "
    assert out.split('\n')[2] == "[WARNING]:  * Ignore this warning if you've removed the head or tail of" \
                                 " this example."



# Generated at 2022-06-11 07:12:39.133013
# Unit test for function response_closure
def test_response_closure():
    import yaml
    module = { '_ansible_verbose_always': True }
    module['_ansible_no_log'] = False
    module['_ansible_debug'] = False
    module['_ansible_diff'] = False
    module['_ansible_check_mode'] = False
    module['_ansible_version'] = 'fake'
    module['_ansible_version_info'] = (2, 1, 0)
    module['_ansible_module_name'] = 'expect'
    module['_ansible_module_args'] = yaml.dump({
        'command': 'fake',
        'responses': {'Question': ['response1', 'response2']},
        'timeout': 123,
        'chdir': '/foo/bar',
    })

# Generated at 2022-06-11 07:12:50.757333
# Unit test for function response_closure
def test_response_closure():
    import copy
    import unittest
    class FakeModule(object):
        def __init__(self):
            self.fail_json_args = None
        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args, kwargs
    class FakeInfo(object):
        def __init__(self):
            self.child_result_list = []

    question = 'question?'
    wrong_question = 'wrong question?'
    responses = ['a', 'b', 'c']
    wrong_responses = ['d', 'e']
    correct_info = FakeInfo()
    correct_info.child_result_list = ['child result 1', 'child result 2']
    wrong_info = copy.deepcopy(correct_info)

# Generated at 2022-06-11 07:12:58.124635
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils import basic
    import types
    module = AnsibleModule(argument_spec=dict())
    question = "Test question"
    responses = ["first", "second", "third"]
    func = response_closure(module, question, responses)
    assert isinstance(func, types.FunctionType)
    func_args = getattr(func, 'func_code').co_argcount
    assert func_args == 1
    assert func.__name__ == "_response_closure"

    child_result = basic.ascii_native_dict()
    child_result['child_result_list'] = [
        'first prompt',
        'second prompt',
        'third prompt',
    ]
    result1 = func(child_result)
    assert result1 == b'first\n'

# Generated at 2022-06-11 07:13:06.966401
# Unit test for function response_closure
def test_response_closure():
    import sys
    import io

    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock

    m = mock.Mock()
    module = m

    responses = ['1', '2', '3']
    question = 'Question'

    def dummy_fail_json(*args, **kwargs):
        raise Exception

    response_closure(m, question, responses)()
    assert m.fail_json.call_args[0][0]['msg'] == "No remaining responses for 'Question', output was ''"



# Generated at 2022-06-11 07:13:07.709410
# Unit test for function main
def test_main():
  print("Hello")


# Generated at 2022-06-11 07:13:18.951217
# Unit test for function main
def test_main():
    # Setup test variables
    args = 'touch test.file'
    creates = 'test.file'
    removes = None
    responses = {
        'password: ': 'password'
    }
    timeout = 30
    echo = False
    b_out = ''
    rc = 0
    startd = datetime.datetime.now()
    endd = datetime.datetime.now()
    delta = endd - startd
    result = dict(
        cmd=args,
        stdout=to_native(b_out).rstrip('\r\n'),
        rc=rc,
        start=str(startd),
        end=str(endd),
        delta=str(delta),
        changed=True,
    )

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-11 07:13:29.678241
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = 'question'
    responses = ['a','b','c']

    # testing response_closure()
    resp = response_closure(module, question, responses)
    assert resp({'child_result_list': ['output ']}), b'a\n'
    assert resp({'child_result_list': ['output ']}), b'b\n'

# Generated at 2022-06-11 07:13:38.178521
# Unit test for function main
def test_main():
    import os
    import sys
    import datetime
    import __main__

    class UnitTestArgs(object):
        def __init__(self):
            self.command = "echo 'hello, world'"
            self.creates = None
            self.removes = None
            self.responses = {"hello": "goodbye"}
            self.timeout = 5
            self.echo = False

    class TestArgv(object):
        def __init__(self):
            self.exit = 1
            self.message = None
            self.exception = None

    class TestAnsibleModule(object):
        def __init__(self, argspec, supports_check_mode=False):
            self.params = UnitTestArgs()
            self.check_mode = False
            self.supports_check_mode = supports_check_mode

# Generated at 2022-06-11 07:14:13.777727
# Unit test for function response_closure
def test_response_closure():
    class ModuleMock(object):
        def __init__(self):
            self.fail_json = self.fail_json_

        def fail_json_(self, msg=None, **kwargs):
            self.fail_json_msg = msg
            raise AssertionError("fail_json called")

    moduleMock = ModuleMock()
    question = 'Question'
    responses = ['response1', 'response2']
    wrapped = response_closure(moduleMock, question, responses)
    response = wrapped({'child_result_list': ['']})
    assert response == b'response1\n'
    response = wrapped({'child_result_list': ['']})
    assert response == b'response2\n'

# Generated at 2022-06-11 07:14:24.804354
# Unit test for function response_closure
def test_response_closure():
    import sys
    class FakeModule(object):
        def __init__(self):
            self.fail_json = self._fail_json
        def _fail_json(self, **kwargs):
            sys.exit(1)

    # Test that a single response is repeated when not given as a list
    assert response_closure(FakeModule(), 'a', ['b'])('c') == b'b\n'
    assert response_closure(FakeModule(), 'a', ['b'])('c') == b'b\n'
    assert response_closure(FakeModule(), 'a', ['b'])('c') == b'b\n'
    with pytest.raises(SystemExit) as exc:
        response_closure(FakeModule(), 'a', ['b'])('c')
    assert exc.value.code == 1

    #

# Generated at 2022-06-11 07:14:35.051993
# Unit test for function main
def test_main():
    args = 'pwd'
    command = 'pwd'
    chdir = '~/QA'
    creates = None
    removes = None
    responses = {'foo': 'bar'}
    timeout = 30
    echo = False
    command_exp = 'pwd'
    chdir_exp = '~/QA'
    creates_exp = None
    removes_exp = None
    responses_exp = {'foo': 'bar'}
    timeout_exp = 30
    echo_exp = False


    assert command == command_exp
    assert chdir == chdir_exp
    assert creates == creates_exp
    assert removes == removes_exp
    assert responses == responses_exp
    assert timeout == timeout_exp
    assert echo == echo_exp

# Generated at 2022-06-11 07:14:39.908274
# Unit test for function main
def test_main():
    # execute test with different parameters
    args = dict(
        command="command",
        creates="creates",
        removes="removes",
        responses={"test1": "test1", "test2": "test2"},
        timeout=None,
        echo=False   
    )
    result = main(args)
    assert result

# Generated at 2022-06-11 07:14:48.094834
# Unit test for function main
def test_main():
    # Get necessary modules from Ansible
    module_mocker = AnsibleModuleMocker()
    module = module_mocker.get_mocked_ansible_module(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    # Create a Response class object to mock pexpect calls
    response = Response()

    # Create a object to test main()
    main_obj = expect(module, response)

    # Test case where args is empty
    rc = main_obj.test_main

# Generated at 2022-06-11 07:14:49.260572
# Unit test for function main
def test_main():
    doctest.testmod(pexpect)

# Generated at 2022-06-11 07:15:00.303068
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # multiple responses
    responses = [ 'one', 'two', 'three', 'four' ]
    question = 'Test'

    wrapped = response_closure(module, question, responses)
    assert wrapped({}) == b'one\n'
    assert wrapped({}) == b'two\n'
    assert wrapped({}) == b'three\n'
    assert wrapped({}) == b'four\n'

    # numbers as strings
    responses = [ '1', '2', '3', '4' ]

    wrapped = response_closure(module, question, responses)
    assert wrapped({}) == b'1\n'
    assert wrapped({}) == b'2\n'
    assert wrapped({}) == b'3\n'
    assert wrapped

# Generated at 2022-06-11 07:15:10.532213
# Unit test for function response_closure
def test_response_closure():
    argspec = dict(command=dict(required=True),
                   chdir=dict(type='path'),
                   creates=dict(type='path'),
                   removes=dict(type='path'),
                   responses=dict(type='dict', required=True),
                   timeout=dict(type='int', default=30),
                   echo=dict(type='bool', default=False))

    module_obj = AnsibleModule(argument_spec=argspec, check_invalid_arguments=False)
    question = "Question"
    responses = ["response1", "response2", "response3"]

    # Mock the module instance so it doesn't fail
    class Module(object):
        def fail_json(self, *args, **kwargs):
            raise Exception("Unexpected fail_json call")

    module_obj.fail_json = Module.fail_json

# Generated at 2022-06-11 07:15:18.824352
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = [ "one", "two", "three" ]
    cl = response_closure(module, "test", responses)

    info = { "child_result_list": [ ] }
    assert cl(info) == b"one\n"
    assert cl(info) == b"two\n"
    assert cl(info) == b"three\n"

    try:
        cl(info)
    except Exception as e:
        assert to_text(e) == "No remaining responses for 'test', output was ''"
    else:
        assert False, "expected exception"

# Generated at 2022-06-11 07:15:27.831819
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleModule

    command = 'command'
    chdir = None
    creates = None
    removes = None
    responses = dict()
    timeout = 30
    echo = False
    tmp_out = StringIO()

    responses['first'] = 'first'
    responses['second'] = ['second', 'second']
    responses['third'] = ['third', 'fourth']
    responses['fifth'] = ['fifth']


# Generated at 2022-06-11 07:16:30.715946
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.six.moves import StringIO
    # set module args for running test
    module_args = {
        'command': '/bin/true',
        'responses': {
            'Question': ['response1', 'response2', 'response3'] },
        'timeout': 30
    }
    module = AnsibleModule(argument_spec=module_args)
    # mocks
    class mock_pexpect_spawn(object):
        def __init__(self, command, timeout=30, cwd=None, env=None):
            self.command = command
            self.timeout = timeout
            self.cwd = cwd
            self.env = env
            self.before = b''
            self.after = b''

# Generated at 2022-06-11 07:16:40.428498
# Unit test for function response_closure
def test_response_closure():
    module_args = dict(
        command='/bin/true',
        responses=dict(
            key=['value1', 'value2', 'value3'],
        )
    )
    module = AnsibleModule(
        argument_spec=module.argument_spec,
        supports_check_mode=module.supports_check_mode,
        no_log=module.no_log,
    )
    caller = globals()['response_closure']

    # Initial case
    response = caller(module, 'key', ['value1', 'value2', 'value3'])
    assert response(dict()) == b'value1\n'
    assert response(dict()) == b'value2\n'
    assert response(dict()) == b'value3\n'

    # Single value case

# Generated at 2022-06-11 07:16:51.899070
# Unit test for function response_closure
def test_response_closure():
    import sys
    import copy
    import pexpect
    import pytest

    sys.argv = [sys.argv[0]]
    sys.argv.append("command=echo")
    sys.argv.append("responses={'Hello World': ['hello there', 'how are you']}")
    sys.argv.append("echo=yes")

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            responses=dict(type='dict', required=True),
            echo=dict(type='bool', default=False),
        )
    )

    chdir = None
    args = module.params['command']
    responses = module.params['responses']
    echo = module.params['echo']

    events = dict()

# Generated at 2022-06-11 07:17:00.178067
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.ansible_module import _load_params
    module = _load_params()
    question = 'Question?'
    responses = [1, 2, 3]
    response_gen = response_closure(module, question, responses)

    assert response_gen(None) == b'1\n'
    assert response_gen(None) == b'2\n'
    assert response_gen(None) == b'3\n'
    try:
        response_gen(None)
        assert False, 'Expected exception'
    except Exception as e:
        assert "No remaining responses" in str(e)

# Generated at 2022-06-11 07:17:11.452490
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    module.fail_json = lambda msg, **kwargs: msg

    question = '???'
    responses = ['a', 'b']
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

# Generated at 2022-06-11 07:17:19.866048
# Unit test for function response_closure
def test_response_closure():
    module = None
    question = "Question"
    responses = ["res1", "res2", "res3"]
    func = response_closure(module, question, responses)
    assert func({'child_result_list': ['res1\n']}) == b'res2\n'
    assert func({'child_result_list': ['res2\n']}) == b'res3\n'
    try:
        func({'child_result_list': ['res3\n']})
        assert False
    except AssertionError as e:
        assert "No remaining responses" in to_text(e)

# Generated at 2022-06-11 07:17:26.822033
# Unit test for function response_closure
def test_response_closure():
    import logging

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    responses = ['response1', 'response2', 'response3']
    question = 'Question'
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    wrapped = response_closure(module, question, responses)
    module.params = {'responses': {'Question': responses}}

# Generated at 2022-06-11 07:17:36.040448
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_native, to_text

    # Create a Mock AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    # Set Fake arguments
    question = "MyQuestion"
    responses = ["response_1", "response_2", "response_3"]

    # Call the tested function

# Generated at 2022-06-11 07:17:42.496041
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            responses=dict(type='dict', required=True),
        )
    )
    assert response_closure(module, 'a', ('b'))('c') == b'b\n'
    assert response_closure(module, 'a', ('b', 'c'))('d') == b'b\n'
    assert response_closure(module, 'a', ('b', 'c'))('d') == b'c\n'
    try:
        response_closure(module, 'a', ('b', 'c'))('d')
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-11 07:17:49.571139
# Unit test for function main
def test_main():
    import sys
    import tempfile

    # Output buffers for execution
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = tempfile.TemporaryFile()
    sys.stderr = tempfile.TemporaryFile()
    # Argv simulates
    sys.argv = ['ansible-test-pexpect']
    # Module args
    args = {
        'command': 'hostname',
        'chdir': None,
        'creates': None,
        'removes': None,
        'responses': {'hostname': 'localhost'},
        'timeout': 30,
        'echo': False,
    }
    # Execute
    main()
    # Retrieve output buffers
    sys.stdout.seek(0)

# Generated at 2022-06-11 07:19:59.517884
# Unit test for function response_closure
def test_response_closure():
    import mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    module = AnsibleModule()
    response = response_closure(module, "question", ["response1", "response2"])
    child_result = []
    with mock.patch('ansible.module_utils.basic.AnsibleModule.fail_json') as mock_fail_json:
        response({"child_result_list": child_result})
        assert to_native(child_result[-1]) == "response1"
        response({"child_result_list": child_result})
        assert to_native(child_result[-1]) == "response2"
        response({"child_result_list": child_result})

# Generated at 2022-06-11 07:20:05.965759
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    n = 0
    for x in response_closure(module, 'A', ['1', '2', '3', '4'])({}):
        assert x == '%d\n' % (n+1)
        n += 1
    try:
        next(response_closure(module, 'A', ['1', '2', '3', '4'])({}))
    except StopIteration:
        pass
    else:
        assert False

# Generated at 2022-06-11 07:20:07.907162
# Unit test for function response_closure
def test_response_closure():
    responses = ['a', 'b', 'c']
    response_closure(module, 'foo', responses)

# Generated at 2022-06-11 07:20:19.182124
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeExitModule(object):
        def __init__(self):
            self.exit_json_kwargs = None
            self.fail_json_kwargs = None
            self.fail_json_message = None

        def fail_json(self, fail_msg, **kwargs):
            self.fail_json_message = fail_msg
            self.fail_json_kwargs = kwargs

        def exit_json(self, **kwargs):
            self.exit_json_kwargs = kwargs

    fake_ansible_module = FakeExitModule()

    def mock_run(*args, **kwargs):
        ''' A mock for pexpect.run
        Returns (output, rc)
        '''