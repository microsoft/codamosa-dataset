

# Generated at 2022-06-11 07:10:46.104946
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.action
    import ansible.module_utils.basic
    import ansible.module_utils.common
    import ansible.module_utils.six

    class FakeModule(object):
        def fail_json(self, msg, **kwargs):
            raise RuntimeError(msg)

    module = FakeModule()

    responses = ["one", "two"]
    question = "a question"
    resp_gen = (b'%s\n' % r for r in responses)
    response = response_closure(module, question, responses)
    assert b'one\n' == response({'child_result_list': [], 'matched_index': 0})
    assert b'two\n' == response({'child_result_list': [], 'matched_index': 0})

# Generated at 2022-06-11 07:10:53.631483
# Unit test for function main
def test_main():
    import ansible.runner
    import ansible.playbook
    import ansible.inventory
    import ansible.constants
    import os

    args = dict(
        command=os.path.dirname(os.path.realpath(__file__)) + "/test_expect.sh",
        creates='test.txt',
        responses={
            'Please enter username': 'root',
            'Please enter password': 'root'
        },
        echo=False
    )

    runner = ansible.runner.Runner(
        module_name='expect',
        module_args=args,
        pattern='*',
        forks=10
    )

    datastructure = runner.run()
    print(datastructure)

    # add some debug output to see what goes wrong

# Generated at 2022-06-11 07:11:03.643559
# Unit test for function main
def test_main():
    # Test handling of non-zero rc
    mock_module = MagicMock()
    mock_module.fail_json.side_effect = SystemExit
    mock_module.params = {'rc': 1}
    with pytest.raises(SystemExit):
        main(mock_module)

    # Test handling of zero rc
    mock_module = MagicMock()
    mock_module.exit_json.side_effect = SystemExit
    mock_module.params = {}
    with mock.patch.dict(__builtins__, {"open": mock_open()}):
        with pytest.raises(SystemExit):
            main(mock_module)

# Generated at 2022-06-11 07:11:05.860428
# Unit test for function main
def test_main():
    print("Test")


# Generated at 2022-06-11 07:11:16.401116
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import binary_type, PY2

    pexpect_original_run = pexpect.run

    def test_run(*args, **kwargs):
        cmd = args[0].decode('utf-8')
        responses = kwargs['events']
        response = b'\n'
        if cmd.endswith('should exec'):
            response = responses[b'Question'](message=responses[b'Question'])
        elif cmd.endswith('shouldn\'t exec'):
            if PY2:
                response = responses[b'Question'].next()

# Generated at 2022-06-11 07:11:28.259772
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args = dict(
        commands=['echo foo'],
        creates=None,
        chdir='/tmp',
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )

    m = basic.AnsibleModule(argument_spec=dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
    ))
    m.params = args


# Generated at 2022-06-11 07:11:39.489901
# Unit test for function main
def test_main():
    args = dict(
        command='pwd',
        chdir=None,
        creates=None,
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit
   

# Generated at 2022-06-11 07:11:48.187268
# Unit test for function main
def test_main():

    # mock module input parameters
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    args = module.params['command']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']

    # mock the pexpect run function
    orig_pexpect_run = pexpect.run

    out = ""
    rc = 0


# Generated at 2022-06-11 07:11:57.426818
# Unit test for function main
def test_main():
    # Should fail, because args is empty
    ret = ()
    with pytest.raises(Exception) as excinfo:
        main(args=ret)
    assert "no command given" in str(excinfo.value)

    # Should fail, because args is empty
    ret = '', '', '', '', '', ''
    with pytest.raises(Exception) as excinfo:
        main(args=ret)
    assert "no command given" in str(excinfo.value)

    # Should not fail, because args is not empty
    ret = 'touch /tmp/foo.txt', '', '', '', '', ''
    with pytest.raises(SystemExit):
        main(args=ret)

# Generated at 2022-06-11 07:11:59.088055
# Unit test for function main
def test_main():
    """
    test_main(dict())

    :param dict:
    :return:
    """

# Generated at 2022-06-11 07:12:11.525406
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-11 07:12:22.714585
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    question = 'Password:'
    responses = ['abc', 'def']
    response = response_closure(module, question, responses)

    # First call to response()
    output = to_native(response(dict(child_result_list=[])).rstrip('\r\n'))
    assert output == 'abc'

    # Second call to response()

# Generated at 2022-06-11 07:12:32.020926
# Unit test for function main
def test_main():
  import unittest
  import sys
  import pexpect

  class StubModule(object):
    def __init__(self, params):
      self.params = params
      self.fail_json = None
      self.exit_json = None

    def fail_json(self, **kwargs):
      print(kwargs)
      sys.exit(1)

    def exit_json(self, **kwargs):
      self.exit_json = kwargs

  cmd = "echo -n 'hello world'"
  responses = {'hello': 'hello world'}

  current_dir = os.path.dirname(os.path.realpath(__file__))
  test_file_path = os.path.join(current_dir, 'test_file.txt')
  test_file_path2 = os.path.join

# Generated at 2022-06-11 07:12:43.035333
# Unit test for function main
def test_main():
    import tempfile
    import pexpect

    def mock_pexpect(timeout, withexitstatus, events, cwd, echo, encoding):
        expect_list, _ = zip(*events.items())
        return expect_list, 0

    real_pexpect_run = pexpect.run
    pexpect.run = mock_pexpect

    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            stdout, cwd = main(
                {
                    'ANSIBLE_MODULE_ARGS': {
                        'command': 'echo foo',
                        'responses': {'answer': '42'},
                        'chdir': tmpdir,
                    }
                },
            )
            assert stdout == 'Response list: [\'answer\']'
    finally:
        pexpect.run = real_pexpect

# Generated at 2022-06-11 07:12:52.176997
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    this_dir = os.path.dirname(os.path.realpath(__file__))
    data_dir = os.path.join(this_dir, 'data')
    test_file = os.path.join(data_dir, 'test_expect.json')

    # Loads test cases from JSON file
    with open(test_file, "r") as fh:
        args = json.loads(fh.read())
        fh.close()

    # Runs test case
    sys.argv=['']
    main()

# Generated at 2022-06-11 07:12:54.428454
# Unit test for function main
def test_main():
    from ansible.modules.common.expect import main
    import pytest
    try:
        import pexpect
        HAS_PEXPECT = True
    except ImportError:
        HAS_PEXPECT = False

# Generated at 2022-06-11 07:13:01.940605
# Unit test for function main
def test_main():
    import os
    import pexpect
    b_out,rc = pexpect._run('ls', timeout=30, withexitstatus=True, events={}, extra_args=None, logfile=None, cwd=os.getcwd(), env=None, _spawn=pexpect.spawn, echo=False)
    b_out = b_out.decode()
    lines = b_out.split('\r\n')[0:-1]
    assert 'test_expect.py' in lines



# Generated at 2022-06-11 07:13:11.471217
# Unit test for function main
def test_main():
    class MockModule(object):

        def __init__(self):
            self.exit_json = None
            self.fail_json = None
            self.params = None
            self.args = None
        def exit_json(*args, **kwargs):
            self.exit_json = args
            print('exit_json:', self.exit_json)
        def fail_json(*args, **kwargs):
            self.fail_json = args
            print('fail_json:', self.fail_json)

    mm = MockModule()

# Generated at 2022-06-11 07:13:21.651687
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = ["Response 1", "Response 2", "Response 3"]
    question = "Question"

    def wrapped(info):
        try:
            return next(resp_gen)
        except StopIteration:
            module.fail_json(msg="No remaining responses for '%s', "
                                 "output was '%s'" %
                                 (question,
                                  info['child_result_list'][-1]))

    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    assert wrapped == response_closure(module, question, responses)

# Generated at 2022-06-11 07:13:32.147432
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.ansible_modlib.basic
    module = ansible.module_utils.ansible_modlib.basic.AnsibleModule(
        argument_spec={},
    )

    # Test that successive calls return successive values
    responses = ['foo', 'bar', 'baz', 'blah']
    expected_responses = [b'foo\n', b'bar\n', b'baz\n', b'blah\n']
    returned_responses = []
    response_gen = response_closure(module, 'question', responses)
    for _ in responses:
        returned_responses.append(response_gen({}))
    assert returned_responses == expected_responses
    # Test that StopIteration is raised after exhausting all responses

# Generated at 2022-06-11 07:13:54.372023
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=False),
            chdir=dict(type='path', required=False),
            creates=dict(type='path', required=False),
            removes=dict(type='path', required=False),
            responses=dict(type='dict', required=False),
            timeout=dict(type='int', required=False),
            echo=dict(type='bool', required=False),
        )
    )
    responses = dict()
    responses['Question'] = ['Response1', 'Response2', 'Response3']
    resp_dict = dict()
    resp_dict['stdout'] = ['']
    resp_dict['rc'] = [0]
    expected = dict(stdout=[''], changed=True, rc=[0])

    response = response_

# Generated at 2022-06-11 07:13:59.573654
# Unit test for function response_closure
def test_response_closure():
    import sys
    assert sys.version_info < (3,)
    assert response_closure(None, 'foo', ['bar'])('x') == b'bar\n'
    assert response_closure(None, 'foo', ['bar', 'baz'])('x') == b'bar\n'
    assert response_closure(None, 'foo', ['bar', 'baz'])('x') == b'baz\n'

# Generated at 2022-06-11 07:14:06.358832
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = ['response1', 'response2', 'response3']
    expected_responses = [to_bytes('response%d\n' % (i + 1)) for i in range(3)]
    actual_responses = []
    response = response_closure(module, 'Question', responses)

    for i in range(3):
        actual_responses.append(response({'child_result_list': []}))

    assert actual_responses == expected_responses

# Generated at 2022-06-11 07:14:14.305320
# Unit test for function main
def test_main():
    exe=[]
    def fake_exit_json(**kwargs):
        exe.append(kwargs)
    class FakeModule:
        def __init__(self):
            self.exit_json = fake_exit_json
            self.params = {
                'command':'ls /',
                'chdir':'/',
                'creates':None,
                'removes':None,
                'responses':{},
                'timeout':None,
                'echo':False
            }
    module = FakeModule()

    main()
    assert exe[0]['rc'] == 0
    comd = exe[0]['cmd'].split(' ')
    assert comd[1] == '-a'


# Generated at 2022-06-11 07:14:25.312717
# Unit test for function main
def test_main():
    import os
    import subprocess
    import re
    import datetime
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:14:36.399366
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    args = module.params['command']
    responses = module.params['responses']

    events = dict()
    for key, value in responses.items():
        if isinstance(value, list):
            response = response_closure(module, key, value)
        else:
            response = b'%s\n' % to_bytes(value).rstrip(b'\n')

        events

# Generated at 2022-06-11 07:14:45.973953
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']

    events = dict()

# Generated at 2022-06-11 07:14:57.025801
# Unit test for function response_closure
def test_response_closure():
    # Setup module parameters
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=False, default=None),
            chdir=dict(type='path', required=False, default=None),
            creates=dict(type='path', required=False, default=None),
            removes=dict(type='path', required=False, default=None),
            responses=dict(type='dict', required=False, default=None),
            timeout=dict(type='int', required=False, default=30),
            echo=dict(type='bool', required=False, default=False),
        )
    )
    module.params['responses'] = {'Question': ['response1', 'response2', 'response3']}


# Generated at 2022-06-11 07:15:05.456334
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils import basic
    def check_result(result, msg, rc=None, changed=True):
        if not isinstance(result, basic.AnsibleExitJson):
            raise Exception('result is not an AnsibleExitJson')
        if result.msg != msg:
            raise Exception('unexpected result message')
        if result.rc != rc:
            raise Exception('unexpected result rc')
        if result.changed != changed:
            raise Exception('unexpected result changed')

    def test(responses, expect_msg, expect_rc=None, expect_changed=True):
        module = basic.AnsibleModule({'responses': {'key': responses}})

# Generated at 2022-06-11 07:15:06.057101
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:15:41.657009
# Unit test for function main
def test_main():
    import subprocess
    # It can't be tested without pexpect
    if not HAS_PEXPECT:
        return
    # Create dummy module object
    module_obj = create_dummy_module()
    # Create dummy args
    args = ['date', '+%s']
    # Set up return values
    # (This means `date +%s` should return `1234567890`)
    responses = {
        r'\d+': '1234567890'
    }
    # Make sure function returns as expected
    main()
    assert module_obj.exit_json.called
    assert not module_obj.fail_json.called
    # Make sure calling the command actually works
    assert int(subprocess.check_output(args).decode()) == int(responses[r'\d+'])


# Generated at 2022-06-11 07:15:47.057862
# Unit test for function response_closure
def test_response_closure():
    assert response_closure(None, 'Question', ['response1', 'response2']) == \
        'response1\n'
    assert response_closure(None, 'Question', ['response1', 'response2']) == \
        'response2\n'
    module = AnsibleModule(argument_spec={})
    with pytest.raises(AnsibleModuleFailException) as execinfo:
        response_closure(module, 'Question', ['response1'])
    assert 'No remaining responses for \'Question\', output was \'None\'' in str(execinfo)

# Generated at 2022-06-11 07:15:55.618661
# Unit test for function response_closure
def test_response_closure():
    import os
    import pexpect

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
        )
    )

    key = "key"
    values = ["value1", "value2"]
    response_function = response_closure(module, key, values)

    child = pexpect.spawn(u"echo")
    child.logfile_read = open(os.devnull, "w")

    assert response_function(child) == b'value1\n'

# Generated at 2022-06-11 07:16:05.675400
# Unit test for function main

# Generated at 2022-06-11 07:16:07.303348
# Unit test for function main
def test_main():
    args = []
    if not args:
        assert False


# Generated at 2022-06-11 07:16:16.769868
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.six import iteritems

    module = AnsibleModule(
        argument_spec=dict(
            responses=dict(type='dict', required=True)
        )
    )

    responses = {
        'some question':
            [
                'first response',
                'second response',
                'third response'
            ]
    }

    for question, expected_responses in iteritems(responses):
        resp_gen = response_closure(module, question, expected_responses)

        resp_count = 0
        for expected_response in expected_responses:
            response = resp_gen(None)
            assert response == '%s\n' % expected_response.rstrip('\n')
            resp_count += 1

        # Check that the generator ran out of responses

# Generated at 2022-06-11 07:16:23.189225
# Unit test for function main
def test_main():
    global yaml
    yaml = '''---
- hosts: localhost
  tasks:
  - name: create user1
    expect:
      command: passwd user1
      chdir: /tmp
      creates: /tmp/user1_created
      removes: /tmp/user1_removed
      responses:
        (?i)password: "MySekretPa$$word"
        (?i)password: "MySekretPa$$word"
      timeout: 30
      echo: false
'''
    print(yaml)
    main()

# Generated at 2022-06-11 07:16:26.071230
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:16:27.704815
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:37.967412
# Unit test for function main
def test_main():
    cmd = "echo foobar"
    events = {
        "foobar": "dummy_response"
    }
    chdir = None
    timeout = 3
    echo = False
    b_out, rc = pexpect._run(cmd, timeout=timeout, withexitstatus=True,
                             events=events, extra_args=None, logfile=None,
                             cwd=chdir, env=None, _spawn=pexpect.spawn,
                             echo=echo)

    assert b_out == b"foobar", "test_main 1 failed"
    assert rc == 0, "test_main 2 failed"

    cmd = "echo foobar"
    events = {
        "foobar": "dummy_response"
    }
    chdir = None
    timeout = 3
    echo = True
    b_

# Generated at 2022-06-11 07:17:34.177781
# Unit test for function response_closure
def test_response_closure():
    import mock
    mod = mock.MagicMock()
    mod.fail_json.return_value = None

    test_response_closure.closed_value = to_bytes('default string')
    def make_generator(responses):
        for response in responses:
            test_response_closure.closed_value = to_bytes(response)
            yield to_bytes(response)

        assert False, 'too many invocations'

    responses = ['first', 'second', 'third']
    make_generator = mock.Mock(side_effect=make_generator)

    event = response_closure(mod, 'test', responses)
    assert event

    questions = ['first', 'second', 'third', 'fourth', 'fifth']
    # First invocation should use first response

# Generated at 2022-06-11 07:17:34.679948
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:17:42.495854
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    chdir = test_module.params['chdir']
    args = test_module.params['command']
    creates = test_module.params['creates']
    removes = test_module.params['removes']
    responses = test_module.params['responses']
    timeout = test_module.params['timeout']
    echo = test_module.params['echo']


# Generated at 2022-06-11 07:17:47.059712
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

# Generated at 2022-06-11 07:17:56.230709
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__
    import pexpect


# Generated at 2022-06-11 07:18:01.942926
# Unit test for function response_closure
def test_response_closure():
    import StringIO
    import sys

    saved_stdout = sys.stdout

# Generated at 2022-06-11 07:18:11.030494
# Unit test for function main
def test_main():
    import pexpect
    import datetime

    def mocked_pexpect_run_side_effect(*args, **kwargs):
        ''' this is the mocked pexpect.run function'''
        # return the expected result
        rc = {'command': args[0], 'event': args[0], 'response': args[0]}
        return rc, 0

    def mocked_pexpect_spawn(*args, **kwargs):
        ''' this is the mocked pexpect.spawn function'''
        return {'name': 'spawn'}

    def mocked_pexpect_swrite(*args, **kwargs):
        ''' this is the mocked pexpect.swrite function'''
        return 0


# Generated at 2022-06-11 07:18:18.179876
# Unit test for function main
def test_main():
    import pexpect, sys
    sys.argv = [sys.argv[0],
                '-a', 'command=true',
                '-a', 'responses={}',
                '-a', 'echo=True']
    with patch.object(pexpect, "__version__", "3.3"):
        with patch("pexpect.spawn", autospec=True) as mock_pexpect_spawn:
            mock_pexpect_spawn().expect = lambda *a: (0, None)
            sys.modules["pexpect"].run = lambda *a, **kw: (b"Hello", 0)
            main()


# Generated at 2022-06-11 07:18:24.113269
# Unit test for function response_closure
def test_response_closure():
    import copy

    module = AnsibleModule(argument_spec={})

    question = 'foo'
    responses = [ 'bar', 'baz' ]
    resp_gen = response_closure(module, question, responses)

    # Ensure resp_gen returns the first item as promised
    assert(resp_gen(dict({'child_result_list': [ 'a', 'b', 'c' ]})) == b'bar\n')

    # Ensure resp_gen returns the second item as promised
    assert(resp_gen(dict({'child_result_list': [ 'a', 'b', 'c' ]})) == b'baz\n')

    # Ensure resp_gen throws an exception as expected

# Generated at 2022-06-11 07:18:32.887739
# Unit test for function response_closure
def test_response_closure():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    class FakeModule(object):
        fail_json = unittest.mock.Mock(side_effect=SystemExit)

    class TestExpect(unittest.TestCase):
        def test_response_closure_one(self):
            """
            Test response_closure, when given a single response.
            """
            responses = ['response1']
            wrapped = response_closure(FakeModule(), 'String', responses)
            self.assertEqual(wrapped({}), to_text('response1\n'))

        def test_response_closure_multiple(self):
            """
            Test response_closure, when given a list of responses.
            """