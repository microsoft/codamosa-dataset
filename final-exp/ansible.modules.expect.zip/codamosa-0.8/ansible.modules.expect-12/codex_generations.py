

# Generated at 2022-06-11 07:10:47.808806
# Unit test for function response_closure
def test_response_closure():
    """Mocking a class to test a function"""
    class MockModule(object):
        """Mocking a class"""
        def __init__(self):
            self.fail_json = lambda msg: "Fail JSON: %s" % msg
    class MockResponses(object):
        """Mocking a class"""
        def __init__(self):
            self.responses = ['r1', 'r2', 'r3']
            self.question = 'question?'
    mock_module = MockModule()
    mock_responses = MockResponses()
    # No remaining responses to return
    response = response_closure(mock_module, mock_responses.question, mock_responses.responses)

# Generated at 2022-06-11 07:10:48.317254
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:10:57.983061
# Unit test for function response_closure
def test_response_closure():
    """Test to make sure that response_closure works as intended"""
    module = type('', (object,), dict(fail_json=lambda *args, **kwargs: None))
    module.fail_json = lambda *args, **kwargs: None
    responses = ["test", "test2"]
    question = 'mytest'
    func = response_closure(module, question, responses)
    assert func({}) == b"test\n"
    assert func({}) == b"test2\n"

    responses = ["test"]
    question = 'mytest'
    func = response_closure(module, question, responses)
    assert func({}) == b"test\n"
    assert func({}) == b"test\n"

# Generated at 2022-06-11 07:11:10.032806
# Unit test for function main
def test_main():
    args = {
        'command': 'passwd username',
        'chdir': None,
        'creates': None,
        'removes': None,
        'responses': {
            'password': 'MySekretPa$$word'
        },
        'timeout': 30,
        'echo': False,
    }

    # Successful execution
    m = AnsibleModule(argument_spec=args)
    m.exit_json = lambda **kwargs: kwargs

    result = main()
    assert result['rc'] == 0
    assert result['cmd'] == args['command']

    # Failing execution
    m = AnsibleModule(argument_spec=args)
    m.fail_json = lambda **kwargs: kwargs

    result = main()
    assert result['rc'] == 256

# Generated at 2022-06-11 07:11:18.470668
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    question = 'echo foo'
    responses = ['bar', 'baz']
    wrapped = response_closure(module, question, responses)
    result = wrapped([])
    # at this point, wrapped should have returned 'bar\n'
    assert result == b'bar\n'
    # call it again, should now return b'baz\n'
    result = wrapped([])
    assert result == b'baz\n'
    # call it a third time, should now fail!
    assert module.fail_json.called

# Generated at 2022-06-11 07:11:29.554047
# Unit test for function response_closure
def test_response_closure():
    m = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
        )
    )

    question = "What is your name"
    responses = ['bob', 'bill', 'jim']
    response = response_closure(m, question, responses)

    assert response({'child_result_list': ['ahaha']}) == 'bob\n'
    assert response({'child_result_list': ['ahaha']}) == 'bill\n'

# Generated at 2022-06-11 07:11:30.507991
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-11 07:11:37.239898
# Unit test for function response_closure
def test_response_closure():
    test_module = AnsibleModule(argument_spec={})
    responses = ["one", "two"]
    question = "Question"
    response = response_closure(test_module, question, responses)
    assert response(dict()) == b"one\n"
    assert response(dict()) == b"two\n"
    try:
        response(dict())
    except Exception as e:
        pass
    else:
        assert False, "no error thrown"

# Generated at 2022-06-11 07:11:46.095129
# Unit test for function response_closure
def test_response_closure():
    class DummyModule(object):
        def fail_json(self, *args, **kwargs):
            pass

    dummy_module = DummyModule()

    generator_test = ['a', 'b', 'c']
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in generator_test)
    wrapped = response_closure(dummy_module, 'Question', generator_test)

    assert wrapped({}) == next(resp_gen)
    assert wrapped({}) == next(resp_gen)
    assert wrapped({}) == next(resp_gen)
    try:
        wrapped({})
    except StopIteration:
        assert True

# Generated at 2022-06-11 07:11:56.896878
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    responses = response_closure(module, 'question', ['response', 'second response'])
    ret = responses({'child_result_list': [('question', 'response'), ('question', 'second response'), ('question', 'third response')]})
    assert ret == b'response\n'

# Generated at 2022-06-11 07:12:11.865633
# Unit test for function main
def test_main():
    args = [
        '/path/to/custom/command',
        {
            'responses': {
                'Question': 'response1'
            }
        },
        False,
        False,
        False
    ]

    result = main(args)
    assert result is not None

# Generated at 2022-06-11 07:12:20.002552
# Unit test for function response_closure
def test_response_closure():
    responses = ["one", "two"]
    question = "Question"
    module = AnsibleModule(argument_spec={})
    resp_closure = response_closure(module, question, responses)
    assert resp_closure(dict(child_result_list=[])) == b"one\n"
    assert resp_closure(dict(child_result_list=[])) == b"two\n"
    try:
        resp_closure(dict(child_result_list=[]))
    except SystemExit as e:
        assert e.code == 1
    else:
        assert False

# Generated at 2022-06-11 07:12:25.560902
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        mock_module.return_value = object()
        with patch('ansible.module_utils.pexpect.pexpect') as mock_pexpect:
            mock_pexpect.spawn.return_value = object()
            main()
            assert mock_pexpect.runu.call_count == 1

# Generated at 2022-06-11 07:12:33.434083
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    import pexpect
    args = 'command'
    responses = {'Question': ['response1', 'response2', 'response3']}
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )


# Generated at 2022-06-11 07:12:44.697829
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    mod_arg_spec = dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
    )


# Generated at 2022-06-11 07:12:55.327084
# Unit test for function main
def test_main():
    #Check for argument_spec definition
    assert main.__doc__.find('argument_spec=dict(') != -1
    #Check for option 'command' (required=True)
    assert main.__doc__.find('command=dict(') != -1
    assert main.__doc__.find('type=str') != -1
    assert main.__doc__.find('required=True') != -1
    #Check for option 'chdir' (type='path')
    assert main.__doc__.find('chdir=dict(') != -1
    assert main.__doc__.find('type=path') != -1
    #Check for option 'creates' (type='path')
    assert main.__doc__.find('creates=dict(') != -1

# Generated at 2022-06-11 07:13:07.111526
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = "My Question"
    responses = ["Answer 1", "Answer 2"]
    child_result_list = ["Last output"]
    info = {
        'child_result_list': child_result_list
    }

    response_fn = response_closure(module, question, responses)
    # first time should return first answer
    first_response = response_fn(info)
    assert first

# Generated at 2022-06-11 07:13:18.038958
# Unit test for function main
def test_main():
    someinput="""command: "cat -"
responses:
  'a': 'b'
  'c':
    - 'd'
    - 'e'"""
    import tempfile
    import os
    import subprocess
    # Create a temp file
    tf = tempfile.NamedTemporaryFile(delete = False)
    # Name the file
    tempname = tf.name
    # Write to file
    tf.write(someinput)
    tf.close()
    # Run the unit test
    cmd = "ansible-playbook -i localhost,"
    cmd2 = " -e 'host_key_checking=False' --connection=local"
    cmd3 = " -e '@%s' test.yml" % (tempname)
    cmd4 = cmd + cmd2 + cmd3

# Generated at 2022-06-11 07:13:28.869239
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    responses = ['response1', 'response2', 'response3']
    question = 'Question'
    response_gen = response_closure(module, question, responses)
    assert response_gen(dict()) == b'response1\n'
    assert response_gen(dict()) == b'response2\n'
    assert response_gen(dict()) == b'response3\n'

# Generated at 2022-06-11 07:13:37.664171
# Unit test for function response_closure
def test_response_closure():
    def get_mock_module():
        class MockModule(object):
            def __init__(self):
                self.fail_json = lambda msg: msg
        return MockModule()

    def get_mock_info():
        class MockInfo(object):
            def __init__(self):
                self.child_result_list = [1]
        return MockInfo()

    module = get_mock_module()
    info = get_mock_info()

    closure = response_closure(module, 'Question', ['Response 1', 'Response 2', 'Response 3'])

    assert closure(info) == b'Response 1\n'
    assert closure(info) == b'Response 2\n'
    assert closure(info) == b'Response 3\n'

# Generated at 2022-06-11 07:14:05.040127
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:14:09.792578
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    responses = ['response1', 'response2', 'response3']
    question = "Question"

    closure_resp = response_closure(module, question, responses)
    assert closure_resp({'child_result_list': []}) == b'response1\n'
    assert closure_resp({'child_result_list': []}) == b'response2\n'
    assert closure_resp

# Generated at 2022-06-11 07:14:20.521141
# Unit test for function response_closure
def test_response_closure():
    from collections import namedtuple
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO, cStringIO

    class Module(object):
        def fail_json(self, msg, **kwargs):
            raise AssertionError("msg: %s, kwargs: %s" % (msg, kwargs))
    module = Module()

    # Test PY2 vs PY3 differences
    # - list responses must be converted to bytes
    # - last item's output must be converted to bytes
    # - kwargs must match the same bytes/unicode rules

    # Python 2 test
    module.fail_json = lambda *args, **kwargs: args[0]
    mylist = ['response1','response2','response3']

# Generated at 2022-06-11 07:14:31.904275
# Unit test for function response_closure
def test_response_closure():
    import unittest

    class ResponseTest(unittest.TestCase):
        '''
        Unit tests for function response_closure
        '''
        def test_single_response(self):
            # Single expected string
            module = object
            answers = ['Hello', 'Good bye']
            question = 'What is your name?'
            responses = {
                'What is your name?': 'John',
            }

            f = response_closure(module, question, responses[question])
            result = f(answers)
            self.assertEqual(result, 'John\n')

        def test_list_response(self):
            # List of responses
            module = object
            answers = ['Hello', 'Good bye']
            question = 'How are you?'

# Generated at 2022-06-11 07:14:33.444824
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-11 07:14:39.067166
# Unit test for function main
def test_main():
    a = {
        'changed': 1,
        "cmd": "fdfd",
        'rc': 0,
        "stdout": "d",
        'start': "2013-05-23 12:01:12.011111",
        'end': "2013-05-23 12:01:12.011111",
        "delta": "2013-05-23 12:01:12.011111"
    }

# Generated at 2022-06-11 07:14:39.713980
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:14:47.991878
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native

    module = AnsibleModule(argument_spec={})
    question = 'Question'
    responses = ['response1', 'response2', 'response3']

    response = response_closure(module, question, responses)

    expected = [b'response1\n', b'response2\n', b'response3\n']
    actual = []

    result = {'child_result_list': []}

    for i in range(0, 3):
        actual.append(response(result))

    assert expected == actual

# Generated at 2022-06-11 07:14:59.154019
# Unit test for function response_closure
def test_response_closure():
    cmd = 'Test_Response_Closure'
    responses = ['foo', 'bar']
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    rc = None
    b_out = None
    question = 'test'

# Generated at 2022-06-11 07:15:05.667256
# Unit test for function main
def test_main():
    from ansible import context
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.common.collections import ImmutableDict

    context.CLIARGS = ImmutableDict(tags={}, listtags=False, listtasks=False,
                                    listhosts=False, syntax=False,
                                    connection='local')

    test_main_program = unfrackpath('/usr/bin/python')
    test_main_args = "tests/units/modules/ansible/builtin/expect.py"

    ret = main(test_main_program, test_main_args)

    assert ret == 0


# Generated at 2022-06-11 07:16:07.091000
# Unit test for function main
def test_main():
    import contextlib
    import os
    import pexpect

    with contextlib.nested(open('/tmp/args.txt', 'r'), open('/tmp/responses.txt', 'r')) as (args, responses):
        b_args = to_bytes(args.read().strip('\n'))
        events = {to_bytes(k): b'%s\n' % v.strip('\n') for k, v in dict(line.split(' ', 1) for line in responses).items()}


# Generated at 2022-06-11 07:16:16.521600
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.six.moves import StringIO
    from ansible.utils import context_objects as co
    from ansible.utils.display import Display
    module = AnsibleModule(argument_spec={})
    display = Display()
    display.verbosity = 4
    setattr(co, 'display', display)
    module._socket_path = 'test'
    module.fail_json = lambda x: 1 / 0
    module.exit_json = lambda x: 0
    # Test a simple response
    responses = ['test']
    closure1 = response_closure(module, 'test', responses)
    stream = StringIO()
    b_stream = to_bytes(stream)
    stream.write('test\n')
    stream.seek(0)

# Generated at 2022-06-11 07:16:25.941953
# Unit test for function response_closure
def test_response_closure():
    # Does it work when a string is passed as the response?
    module = AnsibleModule(argument_spec=dict())
    question = "foo"
    responses = "bar"
    expected = b"bar\n"
    f = response_closure(module, question, responses)
    assert f(dict(child_result_list=[None])) == expected

    # Does it work when a list is passed as the response?
    module = AnsibleModule(argument_spec=dict())
    question = "foo"
    responses = ["bar", "baz"]
    expected = b"bar\n"
    f = response_closure(module, question, responses)
    assert f(dict(child_result_list=[None])) == expected
    expected = b"baz\n"

# Generated at 2022-06-11 07:16:37.399353
# Unit test for function response_closure
def test_response_closure():
    import types
    import sys

    if sys.version_info < (3,):
        module = types.DictProxyType(locals()) # pylint: disable=unpacking-non-sequence
    else:
        class testclass(object):
            def fail_json(self, *args, **kwargs):
                raise AssertionError()

        module = testclass()

    # Test responses
    responses = [ 'response1', 'response2', 'response3' ]

    # Test generated response closure
    response = response_closure(module, 'Question', responses)
    assert(isinstance(response, types.FunctionType))
    assert(response.__name__ == 'wrapped')

    # Test calls to generated response
    assert(response({ 'child_result_list': ['Question'] }) == b'response1\n')
   

# Generated at 2022-06-11 07:16:48.910391
# Unit test for function main
def test_main():
    is_changed = False
    is_fail = False
    is_rc_none = False
    is_rc_zero = False

    def fake_exec_module(module_name=None, module_args=None, tmp=None, task_vars=None,
                         delete_remote_tmp=None):
        nonlocal is_changed, is_fail, is_rc_none, is_rc_zero

        if module_args['command'].strip() == '':
            is_fail = True
        elif module_args['rc'] is None:
            is_rc_none = True
        elif module_args['rc'] != 0:
            is_fail = True
        elif module_args['rc'] == 0:
            is_rc_zero = True

# Generated at 2022-06-11 07:16:59.254948
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModuleFail
    class FakeModule(object):
        def __init__(self, responses):
            self.responses = responses

        def fail_json(self, msg):
            raise AnsibleModuleFail(msg)

    module = FakeModule(responses=['a', 'b', 'c'])

    def test_func(info):
        return next(response_closure(module, 'question', module.responses))

    assert test_func({}) == b'a\n'
    assert test_func({}) == b'b\n'
    assert test_func({}) == b'c\n'

# Generated at 2022-06-11 07:17:10.080332
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    # Replace basic.AnsibleModule with a fake class that just returns the
    # args as a dictionary.
    class FakeAnsibleModule(object):
        def __init__(self, argument_spec):
            self.args = argument_spec
        def fail_json(self, **args):
            print ("FAIL %r" % args)
        def exit_json(self, **args):
            print ("SUCCESS %r" % args)
    basic.AnsibleModule = FakeAnsibleModule
    # Replace the pexpect library with a fake class that returns the args
    # as a tuple (the pexpect library is not available on all platforms).
    class FakePexpectObject(object):
        def __init__(self, *args):
            self.args = args


# Generated at 2022-06-11 07:17:20.979774
# Unit test for function main
def test_main():
    """
    set_module_args() somewhat arcane syntax
    """
    from ansible.modules.system import expect

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    command = 'echo -n "Hello"'
    chdir = None
    creates = None
    removes = None
    timeout = 30
    responses = {}
    echo = False


# Generated at 2022-06-11 07:17:30.703175
# Unit test for function response_closure
def test_response_closure():
    import itertools
    import pytest
    class DummyAnsibleModule(object):
        def fail_json(self, msg, other_params):
            assert msg == "No remaining responses for 'question', output was 'other_params'"
    module = DummyAnsibleModule()
    responses = [1, 2, 3]
    question = 'question'
    func = response_closure(module, question, responses)
    assert func({'child_result_list': ['other_params']}) == '1\n'
    assert func({'child_result_list': ['other_params']}) == '2\n'
    assert func({'child_result_list': ['other_params']}) == '3\n'

# Generated at 2022-06-11 07:17:31.434780
# Unit test for function main
def test_main():
    print(main)

# Generated at 2022-06-11 07:19:36.829219
# Unit test for function response_closure
def test_response_closure():
    class Args(object):
        responses = {'a': ['1', '2', '3']}

    class Module(object):
        def __init__(self):
            self.params = Args()

        def fail_json(self, *args, **kwargs):
            raise Exception('failure')

    module = Module()

    rc = []
    r = response_closure(module, 'a', ['1', '2', '3'])
    for i in range(3):
        rc.append(r({}))
    assert ''.join(rc) == '123'
    try:
        r({'child_result_list': ['FAIL']})
        assert False
    except Exception as e:
        assert e.args[0] == "No remaining responses for 'a', output was 'FAIL'"

# Generated at 2022-06-11 07:19:47.219055
# Unit test for function main
def test_main():
    import tempfile
    import shutil

    # Unit test 1
    # Testing with a valid command
    test_args = dict(
        command="ls",
        chdir=tempfile.gettempdir(),
        creates="",
        removes="",
        responses="",
        timeout=30,
        echo=False,
    )
    set_module_args(test_args)
    with pytest.raises(AnsibleExitJson) as exec_info:
        main()
    result = exec_info.value.args[0]["stdout"]
    assert "ansible.builtin.expect.py" in result

    # Unit test 2
    # Testing with a valid command which will fail

# Generated at 2022-06-11 07:19:56.225714
# Unit test for function main
def test_main():
    args = dict(
        command='ls',
        responses=dict(
            question1='answer1',
            question2='answer2',
            question3='answer3',
            ),
        )
    if HAS_PEXPECT:
        with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
            with patch('pexpect.run') as mock_run:
                mock_module.return_value.exit_json.return_value = None
                main()
                mock_run.assert_called_once_with('ls', timeout=30, withexitstatus=True, events={b'question1': b'answer1\n', b'question2': b'answer2\n', b'question3': b'answer3\n'}, cwd=None, echo=False, encoding=None)
   

# Generated at 2022-06-11 07:20:04.151630
# Unit test for function response_closure
def test_response_closure():
    import io
    import sys
    import unittest
    sys.path.append('../')
    from ansible.compat.tests.mock import Mock, patch

    def run_test(responses, child_result_list, expected):
        module = Mock()
        module.fail_json = Mock()
        with patch.object(pexpect, 'spawn') as pexpect_spawn:
            pexpect_spawn.return_value = Mock()
            pexpect_spawn.return_value.expect = Mock(return_value=0)
            pexpect_spawn.return_value.before = "".join(child_result_list)
            for q, r in responses:
                if isinstance(r, list):
                    wrap = response_closure(module, q, r)
                    wrap("")

# Generated at 2022-06-11 07:20:15.880533
# Unit test for function response_closure
def test_response_closure():
    import imp
    import os
    import sys
    import unittest

    # Mock the needed environment variables to 'test' the module
    test_env = dict(
        ANSIBLE_MODULE_ARGS=dict(
            command='/path/to/command',
            responses=dict(
                question='response'
            ),
            timeout=30
        ),
        ANSIBLE_MODULE_REQUIRE='/path/to/requirements',
        ANSIBLE_MODULE_CORE='/path/to/framework',
        ANSIBLE_MODULE_UTILS='/path/to/utils',
        ANSIBLE_MODULE_SETUP='/path/to/setup'
    )
    for key in test_env:
        os.environ[key] = test_env[key]

    # Add path to ans

# Generated at 2022-06-11 07:20:25.036604
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import sys
    from io import StringIO

    args = dict(
        command='/usr/bin/false',
        responses=dict(
            hello=dict(
                regex='world',
                response='abc',
            ),
        ),
    )
    sys.argv = sys.argv[:1]
    sys.argv.append(to_text(json.dumps(args)))
    m_basic = basic.AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        ),
    )
