

# Generated at 2022-06-11 07:10:49.374972
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils.common
    import tempfile
    import textwrap

    # If the response is a list, successive matches return successive responses.
    # List functionality is new in 2.1.

    test_module_path = tempfile.mktemp()

# Generated at 2022-06-11 07:11:01.059098
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils._text

    class TestModule(AnsibleModule):
        pass

    # Test expected behavior
    # This should not cause any exceptions!
    responses = ['2', '3', '4']
    question = "Please enter a value"

    response_fn = response_closure(TestModule(argument_spec={}), question, responses)
    for i in range(10):
        response_fn({'child_result_list': []})

    # Remove the last thing from responses and make sure it fails
    responses = responses[:-1]
    response_fn = response_closure(TestModule(argument_spec={}), question, responses)
    for i in range(2):
        response_fn({'child_result_list': []})


# Generated at 2022-06-11 07:11:03.010370
# Unit test for function main
def test_main():
    # Check that pexpect needs to be installed
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-11 07:11:12.178466
# Unit test for function main
def test_main():
    # Test case 1:
    pexpect.__version__ = '2.2'
    ret = main()
    assert ret[0] == "Insufficient version of pexpect installed (2.2), this module requires pexpect>=3.3. Error was "
    # Test case 2:
    pexpect.__version__ = '4.2'
    ret = main()
    assert ret[0][0] == "cmd"
    # Test case 3:
    pexpect.__version__ = '4.2'
    ret = main()
    assert ret[0][0] == "cmd"

# Generated at 2022-06-11 07:11:15.703871
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
        )
    )

    module.params['command'] = '/bin/echo'
    main()

    module.params['command'] = 'echo'
    main()

# Generated at 2022-06-11 07:11:17.330341
# Unit test for function main
def test_main():
    print("test_main")

# Generated at 2022-06-11 07:11:28.892100
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={} )
    question = "test Q?"
    responses = ["test A", "test B", "test C"]
    func = response_closure(module, question, responses)

    if func({}) != b'test A\n':
        print("response_closure function failed")
        exit(-1)

    if func({}) != b'test B\n':
        print("response_closure function failed")
        exit(-1)

    if func({'child_result_list': [b'output']}) != b'test C\n':
        print("response_closure function failed")
        exit(-1)

    if func({'child_result_list': [b'output']}) != None:
        print("response_closure function failed")
        exit(-1)

    exit(0)

# Generated at 2022-06-11 07:11:29.728536
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:41.139488
# Unit test for function main
def test_main():
    import subprocess
    (t1, t2, t3) = (0, 0, 0)
    mod = AnsibleModule(argument_spec=dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
    ))
    chdir = None
    args = "ansible"
    creates = None
    removes = None
    responses = {'Select an option': '3'}
    timeout = 30
    echo = False
    events = dict()

# Generated at 2022-06-11 07:11:52.875188
# Unit test for function response_closure
def test_response_closure():
    import types
    import pexpect
    import sys
    import os

    old_stdin = sys.stdin
    old_stdout = sys.stdout
    try:
        # Python 3
        sys.stdin = open('/dev/null', 'r')
        sys.stdout = open('/dev/null', 'ab')
        if sys.version_info >= (3, 0):
            m = pexpect.spawnu('/bin/sh', echo=False)
        else:
            m = pexpect.spawn('/bin/sh', echo=False)
    except:
        # Python 2
        sys.stdin = open('/dev/null', 'rb')
        sys.stdout = open('/dev/null', 'wb')

# Generated at 2022-06-11 07:12:13.922037
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    # Should fail for pexpect<4.0
    # Does not fail for pexpect>=4.0
    test_pexpect = pexpect.__version__.split('.')
    if int(test_pexpect[0]) < 4:
        module = AnsibleModule(
            argument_spec=dict(
                command=dict(required=True),
                responses=dict(type='dict', required=True),
                echo=dict(type='bool', required=True),
            )
        )
        rc, out, err = main()
        assert rc == 256
    # Should run with no errors for pexpect>=4.0

# Generated at 2022-06-11 07:12:24.293959
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    question = 'Question'
    responses = ['response1', 'response2']

    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

    wrapped = response_closure(module, question, responses)

    assert wrapped(dict()) == next(resp_gen)
    assert wrapped(dict()) == next(resp_gen)
    module.fail_json.assert_called_with(
        msg="No remaining responses for '%s', "
            "output was '%s'" %
            (question,
             dict()['child_result_list'][-1]))

# Generated at 2022-06-11 07:12:32.877418
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    # Test non existing directory
    module.params = {
        'command': 'echo "Hello world!"',
        'chdir': 'non_existing_dir',
    }
    main()
    # Test timeout
    module.params = {
        'command': 'sleep 99999',
        'timeout': 1,
    }
    main()
    # Test success

# Generated at 2022-06-11 07:12:44.050096
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    import sys
    import pexpect


    def _spawn(command, args):
        return FakePexpect(command, args)

    old_spawn = pexpect.spawn
    old_run = pexpect.run
    old_runu = pexpect.runu
    pexpect.spawn = _spawn
    pexpect.run = _spawn
    pexpect.runu = _spawn

    class FakePexpect(object):
        def __init__(self, command, args):
            self.command = command
            self.args = args
            self.output = None
            self.exitstatus = 0


# Generated at 2022-06-11 07:12:54.951468
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.script import main as script_main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.expect import main as expect_main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.shell import main as shell_main
    import sys

    argv = sys.argv[1:]
    argv.append("")


# Generated at 2022-06-11 07:13:06.716086
# Unit test for function main
def test_main():
    if not HAS_PEXPECT:
        print('Skipping tests due to missing pexpect module')
        return

    from ansible.module_utils import basic

    globs = globals()
    globs['__builtins__']['to_bytes'] = str


# Generated at 2022-06-11 07:13:17.377685
# Unit test for function response_closure
def test_response_closure():
    '''
    Unit tests for function response_closure
    '''
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        '''
        Mockup of a module
        '''
        def __init__(self):
            self.exit_args = None
            self.debug_args = None
            self.warn_args = None
            self.fail_args = None

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def fail_json(self, **kwargs):
            self.fail_args = kwargs

        def debug(self, msg, **kwargs):
            self.debug_args = msg

        def warn(self, msg, **kwargs):
            self.warn_args = msg

    fake_module = FakeModule

# Generated at 2022-06-11 07:13:28.257069
# Unit test for function response_closure
def test_response_closure():
    from mock import Mock
    from ansible.module_utils.six import iteritems
    module = Mock()

    # List response
    args = { "foo": ["foo", "bar", "baz"] }
    for question, responses in iteritems(args):
        response = response_closure(module, question, responses)
        assert response(None) == b"foo\n"
        assert response(None) == b"bar\n"
        assert response(None) == b"baz\n"

        # Make sure we fail after the last item in the list
        module.fail_json.assert_not_called()
        response({"child_result_list": ['']})
        module.fail_json.assert_called_once()

    # Single response
    module.reset_mock()

# Generated at 2022-06-11 07:13:29.296111
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-11 07:13:37.950746
# Unit test for function main
def test_main():
    command = 'ansible-doc expect | grep --color=never -E "^DESCRIPTION:|^OPTIONS:|^AUTHOR:"'
    args = command.split()
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    chdir = module.params['chdir']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']

# Generated at 2022-06-11 07:14:13.127990
# Unit test for function response_closure
def test_response_closure():
    import random
    from ansible.module_utils.six import StringIO
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    NUM_TESTS = 1000
    MIN_LEN = 1
    MAX_LEN = 20
    SEED = 0xdeadbeef
    random.seed(SEED)

    for i in range(NUM_TESTS):
        length = random.randint(MIN_LEN, MAX_LEN)
        responses = []
        for j in range(length):
            responses.append(random.randint(0, 0xffffffff))

        r = response_closure(module, '', responses)
        out = StringIO()

# Generated at 2022-06-11 07:14:13.757920
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:16.683309
# Unit test for function main
def test_main():
    with patch('ansible_runner.run_ansible_module', return_value=dict(rc=0,
            stdout='', stderr='')):
        assert main() == 0


# Generated at 2022-06-11 07:14:28.159696
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.basic
    import pexpect
    import types
    import os

    test_responses_list = ['test1', 'test2', 'test3']
    test_responses_dict = {
        'password: ': 'test_passwd',
        'foo bar': 'test_foobar',
        'bar foo': ['foo bar', 'bar foo', 'foofoo']
    }
    test_timeout = 5
    test_echo = 0
    test_run_failure = ["Command 'test_cmd' failed"]
    test_failure = ['test_failure']
    test_rc = -1


# Generated at 2022-06-11 07:14:38.962636
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec = {})

    question = 'question'
    responses = ['first response', 'second response', 'third response']
    responses_iter = iter(responses)

    wrapped = response_closure(module, question, responses)

    assert wrapped({}) == ('first response\n')
    assert wrapped({}) == ('second response\n')
    assert wrapped({}) == ('third response\n')
    try:
        wrapped({})
    except SystemExit as e:
        passed = e.code == 1 and 'No remaining responses for \'question\'' in str(e)
    assert passed

    question = 'another question'
    responses = ['only one response']
    wrapped = response_closure(module, question, responses)

    try:
        wrapped({})
    except SystemExit as e:
        assert e.code

# Generated at 2022-06-11 07:14:39.619511
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:14:47.964615
# Unit test for function response_closure
def test_response_closure():
    class Module:
        def __init__(self):
            self.fail_json_ran = False
            self.fail_json_msg = None

        def fail_json(self, msg):
            self.fail_json_msg = msg
            self.fail_json_ran = True

    module = Module()
    # Test single string
    responses = ['response1']
    question = 'Question'
    rc = response_closure(module, question, responses)

    ans = rc(None)
    assert ans == b'response1\n'
    assert not module.fail_json_ran
    assert module.fail_json_msg is None

    # Test list of strings
    responses = ['response1', 'response2']
    question = 'Question'
    rc = response_closure(module, question, responses)


# Generated at 2022-06-11 07:14:48.602149
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:14:59.760860
# Unit test for function response_closure
def test_response_closure():
    def test_module(responses, exit_json_arg):
        def exit_json(**kwargs):
            exit_json_arg['called'] = True
            for (k, v) in kwargs.items():
                exit_json_arg[k] = v

        module = type('module', (object,), {
            'fail_json': lambda **kwargs: exit_json(failed=True, **kwargs),
            'exit_json': exit_json,
        })

        response = response_closure(module, 'question', responses)
        assert isinstance(response, type(lambda: 0))

        def test_response(result, expected_response):
            exit_json_arg.clear()
            response(result)

# Generated at 2022-06-11 07:15:05.808335
# Unit test for function main
def test_main():
    args = {}
    script = pexpect.spawn("echo ok")
    args["CREATES"] = script.exitstatus
    args["REMOVES"] = script.exitstatus
    args["RESPONSES"] = script.exitstatus
    args["ECHO"] = script.exitstatus
    args["TIMEOUT"] = script.exitstatus
    args["COMMAND"] = "echo ok"
    unit_test_main(args)


# Generated at 2022-06-11 07:16:08.956457
# Unit test for function main
def test_main():
    # If module is broken, no exit_json is called
    # TODO: Clean up this test
    b_out = b'foo' * 2000

    def _exit_json(self, *args, **kwargs):
        _exit_json.called = True
        _exit_json.rc = kwargs['rc']


    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            AnsibleModule.run_command.called = False
            AnsibleModule.fail_json.called = False

        def run_command(self, args, timeout=None, check_rc=True):
            AnsibleModule.run_command.args = args
            AnsibleModule.run_command.called = True
            AnsibleModule.run_command.timeout = timeout
            return b_out, 1

       

# Generated at 2022-06-11 07:16:09.765030
# Unit test for function main
def test_main():
  # Function needs to be tested
  pass

# Generated at 2022-06-11 07:16:19.604550
# Unit test for function main
def test_main():
    # Create an instance of the AnsibleModule class
    module = AnsibleModule(
        argument_spec={'command':dict(required=True), 'chdir':dict(type='path'), 'creates':dict(type='path'), 'removes':dict(type='path'), 'responses':dict(), 'timeout':dict(type='int', default=30), 'echo':dict(type='bool', default=False), })
    # Change the current working directory
    chdir = module.params['chdir']
    if chdir:
        chdir = os.path.abspath(chdir)
        os.chdir(chdir)
    # if args.strip() == '':
    #     module.fail_json(rc=256, msg="no command given")
    # if creates:
    #     # do not run the command if the line

# Generated at 2022-06-11 07:16:28.616281
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six import PY3

    module = mock.MagicMock(
        fail_json=lambda x, **kw: {'failed': True, 'kwargs': kw}
    )
    question = 'question'
    responses = ['response1', 'response2', 'response3']
    expected_responses = [
        b'response1\n',
        b'response2\n',
        b'response3\n',
        b'response1\n',
    ]
    wrapped = response_closure(module, question, responses)

    for expected in expected_responses:
        info = {'child_result_list': ['output1']}

# Generated at 2022-06-11 07:16:32.351424
# Unit test for function main
def test_main():
    args = dict(
        command = 'echo hello',
        chdir = '/tmp',
        creates = 'bar',
        removes = 'baz',
        responses = dict(),
        timeout = 30,
        echo = False,
    )
    result = main(args)


# Generated at 2022-06-11 07:16:41.287373
# Unit test for function main
def test_main():

    # Create some test data
    args = u'fake_command'
    answers = {'(?i)password: ': 'fake_password'}
    expected_results = u'fake_command'
    expected_results_stdout = to_text('fake_command\r\nfake_password')

    # Create the module
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    # Populate the module

# Generated at 2022-06-11 07:16:52.544966
# Unit test for function main
def test_main():
    import pexpect
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args = dict(
        command='echo "hello world"',
        chdir='/var/tmp',
        creates='foo',
        removes=None,
        responses=dict(),
        timeout=30
    )

    m = basic.AnsibleModule(argument_spec=args)
    rc, output = main()
    assert rc == 0
    assert output == b'hello world\r\n'

    args['responses']['hello'] = 'world'
    args['command'] = 'echo "hello world"'

    m = basic.AnsibleModule(argument_spec=args)
    rc, output = main()
    assert rc == 0

    args['command'] = 'echo "hello"'

# Generated at 2022-06-11 07:17:02.248799
# Unit test for function response_closure
def test_response_closure():
    import io
    import sys
    class FakeModule:
        def __init__(self):
            self.params = {'timeout': 30}
            self.fail_json_called = False
            self.failure_msg = None
            self._debug = False
            self._diff = False
            self._tmp = None
            self._socket_path = None
            self._ansible_socket = None
            self._ansible_no_log = False
            self.no_log = False
            self._ansible_verbosity = 0
            self._ansible_check_mode = False
            self._ansible_diff = False
            self._ansible_debug = False
            self._ansible_string_conversion_action = True
            self._ansible_module_name = 'fake_module'
            self._ansible_module_

# Generated at 2022-06-11 07:17:03.988562
# Unit test for function response_closure
def test_response_closure():
    response_closure_1 = response_closure(module, '', 'test')

# Generated at 2022-06-11 07:17:13.228299
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    responses = {'login': 'root'}
    module = AnsibleModule(
        argument_spec=dict(command=dict(required=True),
                           responses=dict(type='dict', required=True),
                           ),
        supports_check_mode=False
    )
    module.params['responses'] = responses
    module.params['command'] = 'ssh 127.0.0.1'
    rc = main()
    print(rc)
    assert isinstance(rc, dict)
    assert len(rc['stdout']) > 0
    assert rc['rc'] == 0

# Generated at 2022-06-11 07:19:14.138316
# Unit test for function response_closure
def test_response_closure():

    module = "test"
    question = "This is a test"
    responses = ["string1", "string2", "string3", "string4"]
    test_resp = response_closure(module, question, responses)

    assert test_resp("") == "string1\n"
    assert test_resp("") == "string2\n"
    assert test_resp("") == "string3\n"
    assert test_resp("") == "string4\n"

# Generated at 2022-06-11 07:19:22.070591
# Unit test for function main
def test_main():
    target = AnsibleModule({})
    target.params['command'] = 'echo hello'
    target.params['responses'] = {
        'hello': 'world'
    }
    target.params['timeout'] = 1
    target.params['echo'] = True
    target.params['chdir'] = None
    target.params['creates'] = None
    target.params['removes'] = None

    # Fake start time to avoid changing time in the unit test
    def fake_start():
        return datetime.datetime(2000, 1, 1)
    target.fail_json = lambda **args: print(args)
    target.exit_json = lambda **args: print(args)

    pexpect.run = lambda *args, **kwargs: ('', 0)
    datetime.datetime.now = fake_start
   

# Generated at 2022-06-11 07:19:30.000733
# Unit test for function main
def test_main():
    # Mock Module
    class MockModule(object):
        def __init__(self, params, args, keywords):
            self.params = params
            self.args = args
            self.keywords = keywords
        def fail_json(self, *args, **kwargs):
            self._fail = args
            self._fail_kwargs = kwargs
        def exit_json(self, *args, **kwargs):
            self._exit = args
            self._exit_kwargs = kwargs

    # Mock pexpect
    class MockPexpect(object):
        class ExceptionPexpect(Exception):
            pass
        __version__ = '3.3.0'
        def __init__(self, **kwargs):
            self._spawn_kwargs = kwargs['args']

# Generated at 2022-06-11 07:19:33.478788
# Unit test for function response_closure
def test_response_closure():
    responses = [
        'response 1',
        'response 2'
    ]

    response_generator = response_closure(
        None,
        'Question',
        responses
    )

    assert response_generator({}) == 'response 1\n'
    assert response_generator({}) == 'response 2\n'

# Generated at 2022-06-11 07:19:42.837732
# Unit test for function response_closure
def test_response_closure():
    import mock
    import unittest

    class ResponseClosureTests(unittest.TestCase):
        def setUp(self):
            self.module = mock.Mock(AnsibleModule)
            self.responses = ['a', 'b', 'c']
            self.question = 'Question?'
            self.response = response_closure(self.module, self.question, self.responses)

        def test_stop_iteration(self):
            child_result_list = [to_text('foo')]
            self.module.fail_json.side_effect = SystemExit
            self.assertRaisesRegexp(SystemExit, "No remaining responses for '%s', output was 'foo'" % self.question,
                                    self.response, dict(child_result_list=child_result_list))


# Generated at 2022-06-11 07:19:52.569876
# Unit test for function response_closure
def test_response_closure():
    import random
    import sys
    import tempfile
    # Use tempfile to avoid importing ansible.module_utils.basic
    # Because we don't have access to the module, we can't perform logging,
    # make sure to enable debugging in pexpect.run
    testModule = type('module', (), {'fail_json': tempfile.NamedTemporaryFile().write})
    testResponses = [ 'TEST_RESPONSE_{0}'.format(i) for i in range(0, random.randrange(1, 5)) ]
    testFunc = response_closure(testModule, 'TEST_QUESTION', testResponses)
    testOutput = []

# Generated at 2022-06-11 07:20:00.104990
# Unit test for function response_closure
def test_response_closure():

    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils._text
    class TestResponseClosure(unittest.TestCase):
        def test_response_closure(self):
            module = ansible.module_utils.basic.AnsibleModule(argument_spec = {})
            question = 'hello'
            responses = ['hola', 'bonjour', 'aloha']
            response = response_closure(module, question, responses)
            self.assertEqual(response({}), ansible.module_utils._text.to_bytes('hola\n'))
            self.assertEqual(response({}), ansible.module_utils._text.to_bytes('bonjour\n'))

# Generated at 2022-06-11 07:20:01.786112
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print('Unable to run main()')

# Generated at 2022-06-11 07:20:11.183161
# Unit test for function main
def test_main():
    args = ['mock']
    args.append('-m')
    args.append('./library/expect.py')
    args.append('-a')
    args.append('command=ls')
    args.append('responses={"yes": "yes", "no": "no", "None": "None"}')
    args.append('timeout=30')
    args.append('creates=0')
    args.append('removes=1')
    args.append('echo=False')
    args.append('chdir=/tmp')
    with mock.patch('sys.argv', args):
        result = main()
    assert result is None


# Generated at 2022-06-11 07:20:20.061324
# Unit test for function response_closure
def test_response_closure():
    import pytest

    fake_module = type('AnsibleModule', (object,), {'fail_json': lambda x: None})()
    fake_module.fail_json = pytest.raises(SystemExit)

    responses = response_closure(fake_module, 'TestQuestion', ['foo', 'bar', 'baz'])

    assert responses({}) == b'foo\n'
    assert responses({}) == b'bar\n'
    assert responses({}) == b'baz\n'
    fake_module.fail_json.assert_called_with({'msg': "No remaining responses for 'TestQuestion', output was ''"})