

# Generated at 2022-06-17 04:34:06.928613
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect
    import time
    import datetime
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary environment
    old_path = os.environ['PATH']
    os.environ['PATH'] = '/bin:/usr/bin'

    # Create a temporary module args

# Generated at 2022-06-17 04:34:19.887155
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import pexpect
    import sys
    import time
    import datetime
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text


# Generated at 2022-06-17 04:34:30.466311
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})
            self.module.exit_json = lambda **kwargs: sys.exit(0)
            self.module.fail_json = lambda **kwargs: sys.exit(1)

        def test_response_closure_single_response(self):
            question = 'Question'
            responses = ['response']
            response = response_closure(self.module, question, responses)
            self.assertEqual(response({'child_result_list': []}), to_bytes('response\n'))


# Generated at 2022-06-17 04:34:41.141089
# Unit test for function main
def test_main():
    import pexpect
    import os
    import sys
    import time
    import tempfile
    import shutil
    import subprocess
    import json

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Set up a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary script
    script_path = os.path.join(tmpdir, 'script.sh')

# Generated at 2022-06-17 04:34:52.872391
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import time
    import pexpect
    import pexpect.exceptions
    import pexpect.replwrap
    import pexpect.popen_spawn
    import pexpect.fdpexpect
    import pexpect.pty_spawn
    import pexpect.spawnbase
    import pexpect.expect
    import pexpect.screen
    import pexpect.spawn
    import pexpect.run
    import pexpect.__version__
    import pexpect.__version_info__
    import pexpect.__main__
    import pexpect.__init__
    import pexpect.__doc__
    import pexpect.__all__
    import pexpect.__author__
    import pexpect.__author

# Generated at 2022-06-17 04:35:00.834910
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        command='',
        chdir=None,
        creates=None,
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )
    with pytest.raises(SystemExit):
        main(args)

    # Test with no command
    args = dict(
        command='',
        chdir=None,
        creates=None,
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )
    with pytest.raises(SystemExit):
        main(args)

    # Test with no responses

# Generated at 2022-06-17 04:35:11.511565
# Unit test for function response_closure
def test_response_closure():
    import mock
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = mock.MagicMock()
            self.module.fail_json.side_effect = SystemExit
            self.module.params = {
                'command': 'command',
                'responses': {
                    'Question': ['response1', 'response2', 'response3']
                }
            }
            self.module.check_mode = False
            self.module.no_log = False
            self.module.debug = False
            self.module.verbosity = 0
            self.module.log = mock.MagicMock()
            self.module.warn = mock.MagicMock()
            self.module.deprecate = mock.MagicMock()

# Generated at 2022-06-17 04:35:22.145386
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.expect
    import ansible.module_utils.six

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

    class FakeAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])


# Generated at 2022-06-17 04:35:32.746050
# Unit test for function main
def test_main():
    import pexpect
    import sys
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import PY3
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.basic import to_text
    from ansible.module_utils.basic import to_native
    from ansible.module_utils.basic import to_bytes
    from ansible.module_utils.basic import to_text

# Generated at 2022-06-17 04:35:40.296012
# Unit test for function main
def test_main():
    # Test with no required args
    with pytest.raises(SystemExit):
        main()

    # Test with required args
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    module.params = {
        'command': 'ls',
        'chdir': None,
        'creates': None,
        'removes': None,
        'responses': {},
        'timeout': 30,
        'echo': False,
    }

# Generated at 2022-06-17 04:36:04.148832
# Unit test for function main
def test_main():
    args = dict(
        command='ls -l',
        chdir='/tmp',
        creates='/tmp/file',
        removes='/tmp/file',
        responses=dict(
            Question='response',
            Question2='response2',
        ),
        timeout=30,
        echo=False,
    )
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    module.params = args
    main()

# Generated at 2022-06-17 04:36:18.340461
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single(self):
            question = 'Question'
            responses = ['response']
            resp_gen = response_closure(self.module, question, responses)

            info = {'child_result_list': ['output']}

# Generated at 2022-06-17 04:36:27.339330
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        command='',
    )
    result = dict(
        cmd='',
        stdout='',
        rc=256,
        start='',
        end='',
        delta='',
        changed=True,
    )
    module = AnsibleModule(argument_spec=args)
    try:
        main()
    except SystemExit as e:
        assert e.code == result['rc']
    # Test with no command
    args = dict(
        command='',
    )
    result = dict(
        cmd='',
        stdout='',
        rc=256,
        start='',
        end='',
        delta='',
        changed=True,
    )
    module = AnsibleModule(argument_spec=args)

# Generated at 2022-06-17 04:36:36.510302
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single_response(self):
            question = 'Question'
            responses = ['response1']

# Generated at 2022-06-17 04:36:47.407974
# Unit test for function main
def test_main():
    import os
    import sys
    import shutil
    import tempfile
    import time
    import unittest
    import pexpect

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.basic import no_logging, HAS_PEXPECT
    from ansible.module_utils.basic import PEXPECT_IMP_ERR
    from ansible.module_utils.basic import missing_required_lib
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text


# Generated at 2022-06-17 04:36:55.252830
# Unit test for function main
def test_main():
    import pexpect
    import sys
    import os
    import tempfile
    import shutil
    import time
    import datetime
    import subprocess
    import re
    import json
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils._text
    import ansible.module_utils.action
    import ansible.module_utils.action_plugins
    import ansible.module_utils.action_plugins.expect
    import ansible.module_utils.action_plugins.expect.main
    import ansible.module_utils.action_plugins.expect.pexpect
    import ansible.module_utils.action_plugins.expect.pexpect.spawnbase
    import ansible.module_utils.action_plugins.expect.pexpect.spawn
    import ansible.module

# Generated at 2022-06-17 04:37:03.487242
# Unit test for function main
def test_main():
    import sys
    import os
    import pexpect
    import datetime
    import traceback
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create a temp file to use as the command to run
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create the temp file contents
    with open(temp_path, 'w') as f:
        f.write("#!/bin/sh\necho 'Hello World'\n")

    # Make the temp file executable
    os.chmod(temp_path, 0o755)

    # Create a temp directory to use as the chdir
    temp_dir = tempfile.mkdtemp()

   

# Generated at 2022-06-17 04:37:14.559834
# Unit test for function main

# Generated at 2022-06-17 04:37:22.669221
# Unit test for function response_closure
def test_response_closure():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    module = AnsibleModule(argument_spec={})
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    response = response_closure(module, question, responses)

    # Test first response
    info = {'child_result_list': ['']}
    assert response(info) == to_bytes('response1\n')

    # Test second response
    info = {'child_result_list': ['']}

# Generated at 2022-06-17 04:37:30.923161
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    try:
        main()
    except SystemExit as e:
        assert e.code == 256


# Generated at 2022-06-17 04:38:05.778966
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from unittest.mock import MagicMock

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = MagicMock()

    class TestAnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False):
            self.argument_spec = argument_spec
            self.params = {}
            self.fail_json = MagicMock()

    class TestPexpect(object):
        def __init__(self):
            self.__version__ = '3.3'

    # Mock pexpect
    sys.modules['pexpect'] = TestPexpect()

    # Mock AnsibleModule
    sys.modules['ansible.module_utils.basic'] = MagicMock()

# Generated at 2022-06-17 04:38:14.347539
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single_response(self):
            question = 'Question'
            responses = ['response1']
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:38:25.289666
# Unit test for function main
def test_main():
    import sys
    import pexpect
    import os
    import tempfile
    import shutil
    import time
    import datetime
    import unittest
    from unittest.mock import patch, MagicMock, Mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Mock pexpect.spawn
    class MockSpawn(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.before = b''
            self.after = b''
            self.match = None
            self.match_index = None
            self.exitstatus = 0
            self.flag_eof = False

# Generated at 2022-06-17 04:38:31.199018
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect
    import time
    import datetime
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    from ansible.module_utils.six import PY3

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()

    # Create a temporary environment
    old_env = os.environ.copy()
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"command": "echo hello", "responses": {"hello": "world"}}'

# Generated at 2022-06-17 04:38:43.751019
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 04:38:54.253707
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import pexpect
    import json
    import time
    import subprocess
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    class TestExpect(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.old_cwd = os.getcwd()
            os.chdir(self.tempdir)
            self.test_file = os.path.join(self.tempdir, 'test_file')
            self.test_file2 = os.path.join(self.tempdir, 'test_file2')
            self.test_

# Generated at 2022-06-17 04:39:05.693225
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class FakeModule(object):
        def __init__(self):
            self.fail_json = sys.exit

    module = FakeModule()

    responses = ['foo', 'bar', 'baz']
    question = 'Question'

    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

    def wrapped(info):
        try:
            return next(resp_gen)
        except StopIteration:
            module.fail_json(msg="No remaining responses for '%s', "
                                 "output was '%s'" %
                                 (question,
                                  info['child_result_list'][-1]))


# Generated at 2022-06-17 04:39:19.225967
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})

        def test_response_closure_single_response(self):
            responses = ['response1']
            question = 'Question'
            response = response_closure(self.module, question, responses)
            self.assertEqual(response({'child_result_list': []}), b'response1\n')

        def test_response_closure_multiple_responses(self):
            responses = ['response1', 'response2']
            question = 'Question'
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:39:22.838135
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-17 04:39:33.196675
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary files
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    fd, tmpfile2 = tempfile.mkstemp(dir=tmpdir)

    # Create temporary file with content
    fd, tmpfile3 = tempfile.mkstemp(dir=tmpdir)
    with open(tmpfile3, 'w') as f:
        f.write('foo\n')

    # Create temporary file with content
    fd, tmp

# Generated at 2022-06-17 04:40:41.719208
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import time
    import pexpect
    import pexpect.exceptions
    import pexpect.replwrap
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary environment
    tmpenv = os.environ.copy()

    # Create a temporary module

# Generated at 2022-06-17 04:40:52.175295
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.action_plugins
    import ansible.module_utils.ansible_release
    import ansible.module_utils.ansible_version
    import ansible.module_utils.argspec
    import ansible.module_utils.basic
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.text
    import ansible.module_utils.connection
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.alpine


# Generated at 2022-06-17 04:41:00.206054
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.action.expect
    import ansible.module_utils.six

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['command'] = 'command'
            self.params['responses'] = dict()
            self.params['responses']['Question'] = ['response1', 'response2', 'response3']
            self.params['timeout'] = 30
            self.params['echo'] = False
            self.fail_json = ansible.module_utils.six.print_
            self.exit_json = ansible.module_utils.six.print_


# Generated at 2022-06-17 04:41:10.776575
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        command='',
        chdir=None,
        creates=None,
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )
    module = AnsibleModule(argument_spec=args)
    try:
        main()
    except SystemExit as e:
        assert e.code == 256
    else:
        assert False

    # Test with no command
    args = dict(
        command='',
        chdir=None,
        creates=None,
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )
    module = AnsibleModule(argument_spec=args)
    try:
        main()
    except SystemExit as e:
        assert e.code == 256

# Generated at 2022-06-17 04:41:17.025753
# Unit test for function main
def test_main():
    # Test the case where the command is empty
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    module.params['command'] = ''
    try:
        main()
    except SystemExit as e:
        assert e.code == 256
    else:
        assert False, "Should have raised an exception"

    # Test the case where the command is not empty

# Generated at 2022-06-17 04:41:22.575906
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    response = response_closure(module, question, responses)
    assert response(dict(child_result_list=['output1'])) == b'response1\n'
    assert response(dict(child_result_list=['output2'])) == b'response2\n'
    assert response

# Generated at 2022-06-17 04:41:29.082276
# Unit test for function main
def test_main():
    args = dict(
        command='ls',
        chdir='/',
        creates='/etc/passwd',
        removes='/etc/passwd',
        responses=dict(
            Question=['response1', 'response2', 'response3']
        ),
        timeout=30,
        echo=False
    )
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    module.params = args
    main()

# Generated at 2022-06-17 04:41:37.618734
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single_response(self):
            question = 'Question'
            responses = ['response1']
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:41:49.113967
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single(self):
            question = 'Question'
            responses = ['response1']
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:42:00.356415
# Unit test for function response_closure
def test_response_closure():
    import mock
    module = mock.MagicMock()
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    wrapped = response_closure(module, question, responses)
    assert wrapped({'child_result_list': [b'Question']}) == next(resp_gen)
    assert wrapped({'child_result_list': [b'Question']}) == next(resp_gen)
    assert wrapped({'child_result_list': [b'Question']}) == next(resp_gen)
    module.fail_json.assert_called_once_with(msg="No remaining responses for 'Question', output was 'Question'")