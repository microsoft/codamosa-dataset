

# Generated at 2022-06-17 04:34:03.784460
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        command='',
        chdir=None,
        creates=None,
        removes=None,
        responses={},
        timeout=30,
        echo=False,
    )
    result = dict(
        cmd='',
        stdout='',
        rc=256,
        start='',
        end='',
        delta='',
        changed=True,
    )
    module = AnsibleModule(argument_spec=args)
    try:
        main()
    except SystemExit as e:
        assert e.code == result['rc']

    # Test with creates

# Generated at 2022-06-17 04:34:15.645177
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})

        def test_response_closure_single_response(self):
            responses = ['foo']
            question = 'bar'
            response = response_closure(self.module, question, responses)
            self.assertEqual(response({'child_result_list': []}), b'foo\n')

        def test_response_closure_multiple_responses(self):
            responses = ['foo', 'bar']
            question = 'baz'
            response = response_closure(self.module, question, responses)
           

# Generated at 2022-06-17 04:34:22.167420
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestAnsibleModule(AnsibleModule):
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    class TestExpectModule(unittest.TestCase):
        def test_response_closure(self):
            module = TestAnsibleModule(argument_spec={})
            question = 'Question'
            responses = ['response1', 'response2', 'response3']
            response = response_closure(module, question, responses)
            self.assertEqual(response(dict()), to_bytes('response1\n'))
            self.assertEqual(response(dict()), to_bytes('response2\n'))

# Generated at 2022-06-17 04:34:27.269759
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import pexpect
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()

    # Create a temporary environment
    old_env = os.environ
    os.environ = {}

    # Create a temporary module args
    module_args = dict(
        command='/bin/false',
        chdir=tmpdir,
        creates=tmpfile,
        removes=tmpfile,
        responses={},
        timeout=30,
        echo=False,
    )

# Generated at 2022-06-17 04:34:39.047261
# Unit test for function main
def test_main():
    import sys
    import os
    import pexpect
    import datetime
    import time
    import tempfile
    import shutil
    import subprocess
    import traceback
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, temp_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a file in the temporary directory
    fd, temp_file2 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a file in the temporary directory
    fd, temp_file3 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a file in the temporary directory
    fd,

# Generated at 2022-06-17 04:34:48.450528
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})

        def test_response_closure_single_response(self):
            responses = ['foo']
            question = 'bar'
            resp_gen = response_closure(self.module, question, responses)
            self.assertEqual(resp_gen({}), b'foo\n')
            self.assertRaises(SystemExit, resp_gen, {})

        def test_response_closure_multiple_responses(self):
            responses = ['foo', 'bar']
            question = 'bar'
            resp_gen = response_closure(self.module, question, responses)
            self

# Generated at 2022-06-17 04:34:59.737310
# Unit test for function response_closure
def test_response_closure():
    import unittest
    import mock

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = mock.MagicMock()
            self.module.fail_json.side_effect = Exception('fail_json')

        def test_single_response(self):
            responses = ['foo']
            question = 'bar'
            resp_gen = response_closure(self.module, question, responses)
            self.assertEqual(resp_gen({}), b'foo\n')
            self.assertRaises(Exception, resp_gen, {})

        def test_multiple_responses(self):
            responses = ['foo', 'bar']
            question = 'bar'
            resp_gen = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:35:10.073301
# Unit test for function main

# Generated at 2022-06-17 04:35:14.379006
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import pexpect
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary script
    fd, tmpscript = tempfile.mkstemp(dir=tmpdir)
    os.write(fd, to_bytes("""#!/bin/sh
echo "Hello world"
echo "This is a test"
echo "This is only a test"
exit 0
"""))
    os.close(fd)

# Generated at 2022-06-17 04:35:25.771089
# Unit test for function main

# Generated at 2022-06-17 04:36:00.333908
# Unit test for function main
def test_main():
    import sys
    import os
    import pexpect
    import tempfile
    import shutil
    import time
    import subprocess
    import json
    import re
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')
            self.test_file_contents = 'test_file_contents'
            self.test_file_contents_bytes = to_bytes(self.test_file_contents)
            self.test_file_cont

# Generated at 2022-06-17 04:36:09.773814
# Unit test for function main
def test_main():
    # Test with no responses
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    args = 'echo "Hello world"'
    responses = {}
    timeout = 30
    echo = False
    chdir = None
    creates = None
    removes = None
    events = dict()
    for key, value in responses.items():
        if isinstance(value, list):
            response = response_closure(module, key, value)

# Generated at 2022-06-17 04:36:19.448340
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    response = response_closure(module, question, responses)

    assert response({'child_result_list': []}) == b'response1\n'
    assert response({'child_result_list': []}) == b'response2\n'
    assert response({'child_result_list': []}) == b'response3\n'

    try:
        response({'child_result_list': []})
        assert False
    except SystemExit:
        assert True

# Generated at 2022-06-17 04:36:30.717264
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def test_response_closure(self):
            class FakeModule(object):
                def fail_json(self, msg, **kwargs):
                    raise Exception(msg)

            module = FakeModule()
            question = 'Question'
            responses = ['response1', 'response2', 'response3']
            resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)


# Generated at 2022-06-17 04:36:41.511458
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure(self):
            question = 'question'
            responses = ['response1', 'response2', 'response3']
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:36:48.205089
# Unit test for function main

# Generated at 2022-06-17 04:36:56.787243
# Unit test for function response_closure
def test_response_closure():
    import mock
    module = mock.MagicMock()
    question = 'question'
    responses = ['response1', 'response2', 'response3']
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    wrapped = response_closure(module, question, responses)
    assert wrapped(dict(child_result_list=[])) == next(resp_gen)
    assert wrapped(dict(child_result_list=[])) == next(resp_gen)
    assert wrapped(dict(child_result_list=[])) == next(resp_gen)
    module.fail_json.assert_called_once_with(msg="No remaining responses for 'question', output was ''")

# Generated at 2022-06-17 04:37:04.093857
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single_response(self):
            question = 'Question'
            responses = ['response1']
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:37:14.860405
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.configparser
    import ansible.module_utils.six.moves.queue
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.six.moves.ur

# Generated at 2022-06-17 04:37:22.935384
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    response = response_closure(module, question, responses)

    assert response({'child_result_list': ['output1']}) == b'response1\n'
    assert response({'child_result_list': ['output2']}) == b'response2\n'

# Generated at 2022-06-17 04:37:59.438630
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})
            self.module.fail_json = self.fail_json
            self.module.exit_json = self.exit_json

        def fail_json(self, *args, **kwargs):
            self.fail_args = args
            self.fail_kwargs = kwargs

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def test_single_response(self):
            responses = ['foo']


# Generated at 2022-06-17 04:38:06.985430
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary file
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a function to be used as a side_effect for pexpect.run
    def run_side_effect(args, **kwargs):
        if args == 'echo "Hello World"':
            return b'Hello World\r\n', 0

# Generated at 2022-06-17 04:38:21.694035
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import pexpect
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.action_plugins
    import ansible.module_utils.action_plugins.expect
    import ansible.module_utils.action_plugins.expect.main
    import ansible.module_utils.action_plugins.expect.response_closure
    import ansible.module_utils.action_plugins.expect.response_closure.wrapped
    import ansible.module_utils.action_plugins.expect.response_closure.wrapped.next
    import ansible.module_utils.action_plugins.expect.response_closure.wrapped.next.StopIteration

# Generated at 2022-06-17 04:38:28.797015
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect
    import pexpect.exceptions
    import pexpect.replwrap
    import pexpect.popen_spawn
    import pexpect.spawnbase
    import pexpect.fdpexpect
    import pexpect.pty_spawn
    import pexpect.screen
    import pexpect.spawn
    import pexpect.expect
    import pexpect.expect_list
    import pexpect.expect_loop
    import pexpect.spawnu
    import pexpect.run
    import pexpect.runu
    import pexpect.__version__
    import pexpect.__version_info__
    import pexpect.__main__
    import pexpect.__init__

# Generated at 2022-06-17 04:38:39.273992
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest

    class TestResponseClosure(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    command=dict(required=True),
                    chdir=dict(type='path'),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    responses=dict(type='dict', required=True),
                    timeout=dict(type='int', default=30),
                    echo=dict(type='bool', default=False),
                )
            )

        def test_response_closure_single_response(self):
            question = 'Question'
            responses = ['response1']
            response = response_closure(self.module, question, responses)

# Generated at 2022-06-17 04:38:47.252673
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import pexpect
    import pexpect.exceptions
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    from ansible.module_utils.action import ActionBase
    from ansible.module_utils.action import AnsibleAction
    from ansible.module_utils.action import ActionModule
    from ansible.module_utils.action import ActionModuleMetaClass
    from ansible.module_utils.action import AnsibleModuleUtils
    from ansible.module_utils.action import AnsibleModuleUtilsMetaClass
    from ansible.module_utils.action import AnsibleModuleUtilsBase
    from ansible.module_utils.action import AnsibleModuleUt

# Generated at 2022-06-17 04:38:57.564491
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestResponseClosure(unittest.TestCase):
        def test_response_closure(self):
            module = AnsibleModule(argument_spec={})
            question = 'Question'
            responses = ['response1', 'response2', 'response3']
            resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
            wrapped = response_closure(module, question, responses)
            self.assertEqual(wrapped({'child_result_list': []}), next(resp_gen))

# Generated at 2022-06-17 04:39:05.629586
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = ['response1', 'response2', 'response3']
    question = 'Question'
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    response = response_closure(module, question, responses)
    assert response(dict()) == next(resp_gen)
    assert response(dict()) == next(resp_gen)
    assert response(dict()) == next(resp_gen)
    try:
        response(dict())
    except SystemExit:
        pass
    else:
        assert False

# Generated at 2022-06-17 04:39:19.156954
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = "Question"
    responses = ["response1", "response2", "response3"]
    response = response_closure(module, question, responses)

    assert response({"child_result_list": []}) == b"response1\n"
    assert response({"child_result_list": []}) == b"response2\n"
    assert response({"child_result_list": []})

# Generated at 2022-06-17 04:39:31.512391
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestAnsibleModule(AnsibleModule):
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    class TestExpect(unittest.TestCase):
        def setUp(self):
            self.module = TestAnsibleModule(argument_spec=dict())

        def test_response_closure(self):
            responses = [b'foo', b'bar', b'baz']
            question = b'Question'
            response = response_closure(self.module, question, responses)
            self.assertEqual(response({'child_result_list': []}), b'foo\n')

# Generated at 2022-06-17 04:40:39.438624
# Unit test for function main
def test_main():
    import sys
    import os
    import pexpect
    import datetime
    import traceback
    import tempfile
    import shutil
    import time
    import re
    import json
    import pytest

    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_bytes, to_native, to_text

    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd

# Generated at 2022-06-17 04:40:51.480014
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect
    import pexpect.exceptions
    import pexpect.replwrap
    import pexpect.spawn
    import pexpect.fdpexpect
    import pexpect.pxssh
    import pexpect.pxssh.exceptions
    import pexpect.pxssh.pxssh
    import pexpect.pxssh.pxssh_expect
    import pexpect.pxssh.pxssh_async
    import pexpect.pxssh.pxssh_async_expect
    import pexpect.pxssh.pxssh_async_replwrap
    import pexpect.pxssh.pxssh_async_replwrap_expect
    import pexpect.pxssh.pxssh_async_replwrap_ex

# Generated at 2022-06-17 04:40:58.897532
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()

    # Test with no command
    with pytest.raises(SystemExit):
        main(dict(responses={}))

    # Test with no responses
    with pytest.raises(SystemExit):
        main(dict(command='ls'))

    # Test with no timeout
    with pytest.raises(SystemExit):
        main(dict(command='ls', responses={}))

    # Test with no echo
    with pytest.raises(SystemExit):
        main(dict(command='ls', responses={}, timeout=30))

    # Test with a valid command
    main(dict(command='ls', responses={}, timeout=30, echo=False))

# Generated at 2022-06-17 04:41:10.022165
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:41:16.139328
# Unit test for function main
def test_main():
    import sys
    import os
    import pexpect
    import datetime
    import time
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    def response_closure(module, question, responses):
        resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

        def wrapped(info):
            try:
                return next(resp_gen)
            except StopIteration:
                module.fail_json(msg="No remaining responses for '%s', "
                                     "output was '%s'" %
                                     (question,
                                      info['child_result_list'][-1]))

        return wrapped


# Generated at 2022-06-17 04:41:24.149135
# Unit test for function main
def test_main():
    import pexpect
    import os
    import sys
    import tempfile
    import time
    import traceback
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, 'testfile')
            self.tempfile2 = os.path.join(self.tempdir, 'testfile2')
            self.tempfile3 = os.path.join(self.tempdir, 'testfile3')

# Generated at 2022-06-17 04:41:36.212305
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import pexpect
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.action_plugins
    import ansible.module_utils.actions
    import ansible.module_utils.connection
    import ansible.module_utils.shell
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.urls

# Generated at 2022-06-17 04:41:43.650541
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        command='',
        chdir=None,
        creates=None,
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )
    module = AnsibleModule(argument_spec=args)
    try:
        main()
        assert False
    except SystemExit as e:
        assert e.code == 256
        assert 'no command given' in str(e)

    # Test with creates
    args = dict(
        command='',
        chdir=None,
        creates='/tmp/test_main',
        removes=None,
        responses=dict(),
        timeout=30,
        echo=False,
    )
    module = AnsibleModule(argument_spec=args)

# Generated at 2022-06-17 04:41:51.942545
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import pexpect

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary environment
    old_env = os.environ.copy()
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"command": "echo hello", "responses": {"hello": "world"}, "timeout": 1}'
    os.environ['ANSIBLE_MODULE_REQUIREMENTS'] = '{"pexpect": ">=3.3"}'
    os.environ['ANSIBLE_MODULE_SILENT'] = 'True'

    # Save the current directory and change to a temporary directory


# Generated at 2022-06-17 04:42:01.372657
# Unit test for function response_closure
def test_response_closure():
    import mock
    import ansible.module_utils.basic
    import ansible.module_utils._text

    module = mock.MagicMock(spec=ansible.module_utils.basic.AnsibleModule)
    module.fail_json.side_effect = Exception('fail_json')

    question = 'Question'
    responses = ['response1', 'response2', 'response3']

    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
