

# Generated at 2022-06-20 21:51:01.116391
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            responses=dict(type='dict', required=True),
        )
    )

    responses = {
        'Question': [
            'response1',
            'response2',
            'response3',
            'response4',
        ]
    }

    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses['Question'])
    response = response_closure(module, 'Question', responses['Question'])

    assert response({'child_result_list': []}) == next(resp_gen)
    assert response({'child_result_list': []}) == next(resp_gen)

# Generated at 2022-06-20 21:51:10.323331
# Unit test for function response_closure
def test_response_closure():
    # Mock pexpect module
    import pexpect_mock as pexpect
    module = AnsibleModule(argument_spec=dict(
        responses=dict(type='dict', required=True),
    ))
    responses = [u'first response', u'second response']
    question = u'Question'
    wrapped = response_closure(module, question, responses)

    for response in responses:
        assert wrapped(None) == '%s\n' % response
    with pytest.raises(AnsibleExitJson):
        wrapped(dict(child_result_list=[u'other output']))



# Generated at 2022-06-20 21:51:21.056358
# Unit test for function response_closure
def test_response_closure():
    import unittest

    class ResponseClosureTestCase(unittest.TestCase):
        def setUp(self):
            self.module = FakeAnsibleModule()
            self.question = "Question?"
            self.responses = ['first', 'second', 'third']
            self.response = response_closure(self.module, self.question, self.responses)

        def test_when_no_response_remains(self):
            self.module.result = {'child_result_list': ['last']}
            with self.assertRaises(SystemExit) as cm:
                self.response({'child_result_list': ['next']})
            self.assertEqual(cm.exception.code, 1)

# Generated at 2022-06-20 21:51:31.717558
# Unit test for function response_closure
def test_response_closure():
    from ansible.modules.system import expect
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})
    question = 'Test question?'
    response_array = ['response 1', 'response 2']

    callable = expect.response_closure(module, question, response_array)
    response = callable({'child_result_list': None})
    assert response == b'response 1\n'
    response = callable({'child_result_list': None})
    assert response == b'response 2\n'
    try:
        response = callable({'child_result_list': None})
    except SystemExit:
        pass

# Generated at 2022-06-20 21:51:42.623025
# Unit test for function main
def test_main():
    from ansible.modules.system.expect import main
    import ansible.module_utils.basic
    myArgs = dict(
        args = '/path/to/custom/command',
        chdir = '/',
        creates = '/etc/passwd',
        removes = '/var/tmp',
        responses = {
            'Question': [ 'response1', 'response2', 'response3' ]
        },
        timeout = 30,
        echo = False
    )
    myModule = ansible.module_utils.basic.AnsibleModule
    myFailJson = myModule.fail_json
    myFailJsonFunc = lambda: None
    myExitJson = myModule.exit_json
    myExitJsonFunc = lambda: None
    myModule.fail_json = myFailJsonFunc

# Generated at 2022-06-20 21:51:43.159152
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:51:51.006981
# Unit test for function main
def test_main():
    test_data = '''
    - hosts: localhost
      gather_facts: no
      tasks:
        - name: test example_command using created file
          expect:
            command: /bin/cat /var/tmp/foo
            creates: /var/tmp/foo
            responses:
              "delete me": "no"
              "What is your name": "Bob"
          register: result
        - debug: var=result
    '''

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.basic import AnsibleModule
    import os

    A = action_loader.get('expect', class_only=True)

# Generated at 2022-06-20 21:52:03.098109
# Unit test for function response_closure
def test_response_closure():
    class Module:
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    module = Module()
    responses = [ "one", "two", "three" ]
    question = "question"
    response = response_closure(module, question, responses)
    child_result_list = []
    callback = response({"child_result_list": child_result_list})
    assert callback == "one\n"
    assert child_result_list == []
    callback = response({"child_result_list": child_result_list})
    assert callback == "two\n"
    assert child_result_list == []
    callback = response({"child_result_list": child_result_list})
    assert callback == "three\n"
    assert child_result_list == []

# Generated at 2022-06-20 21:52:11.189471
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.ansible_modlib.common.utils import is_iterable
    import unittest
    import sys

    def captureException(f):
        def new_f(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except Exception as e:
                new_f.exception = e

        new_f.exception = None
        return new_f

    class ResponseClosureTestCase(unittest.TestCase):
        def setUp(self):
            self._output = sys.stderr

            class FakeModule:
                def __init__(self):
                    self.json_output = {}

                def fail_json(self, msg, **kwargs):
                    self.json_output['msg'] = msg

# Generated at 2022-06-20 21:52:20.163816
# Unit test for function main
def test_main():
    import os
    os.path.exists = lambda path: True
    os.path.abspath = lambda path: path

    os.chdir = lambda chdir: None

    def spawn(cmd, *args, **kwargs):
        out = 'password: Success\n'
        return FakePexpect(out, 0)

    pexpect.spawn = spawn

    module = FakeAnsibleModule(args={
        'command': 'passwd username',
        'responses': {
            '(?i)password': 'password'
        },
        'timeout': 30,
        'echo': False,
        })

    try:
        main()
    except SystemExit as e:
        assert(e.args[0] == 0)
        stdout = 'password: Success'

# Generated at 2022-06-20 21:52:33.012232
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:52:38.908152
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    main()


# Generated at 2022-06-20 21:52:49.397535
# Unit test for function main
def test_main():
    import json
    import mock

    def run_module():
        module_args = dict(
            command='/bin/true',
            chdir=None,
            creates=None,
            responses={},
            removes=None,
            timeout=30,
            echo=False,
        )
        with mock.patch.object(AnsibleModule, 'run_command') as rc:
            rc.return_value = (0, '', '')

# Generated at 2022-06-20 21:53:03.523194
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.remote_management.basics import expect
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec = dict(
            command = dict(required=True),
            chdir = dict(type='path'),
            creates = dict(type='path'),
            removes = dict(type='path'),
            responses = dict(type='dict', required=True),
            timeout = dict(type='int', default=30),
            echo = dict(type='bool', default=False),
        )
    )

    setattr(module.params['command'], 'stdin', StringIO(u'hello world \n'))

# Generated at 2022-06-20 21:53:16.064799
# Unit test for function main
def test_main():
    from ansible.modules.system.expect import main
    from ansible.module_utils.six.moves import StringIO
    import sys
    import shutil
    import os
    import pexpect
    import uuid

    if not hasattr(pexpect, "run") and not hasattr(pexpect, "_run"):
        raise Exception("Insufficient version of pexpect installed, "
                        "this module requires pexpect>=3.3")

    original_stdout = sys.stdout
    sys.stdout = StringIO()


# Generated at 2022-06-20 21:53:28.441557
# Unit test for function main
def test_main():
    command = "command"
    chdir = "chdir"
    creates = "creates"
    removes = "removes"
    responses = ["responses"]
    timeout = 30
    echo = False

    temp_args = dict(
        command=command,
        creates=creates,
        removes=removes,
        chdir=chdir,
        responses=responses,
        timeout=timeout,
        echo=echo
    )


# Generated at 2022-06-20 21:53:29.022532
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:53:29.915286
# Unit test for function main
def test_main():
    assert(main() is None)

# Generated at 2022-06-20 21:53:35.456925
# Unit test for function main

# Generated at 2022-06-20 21:53:46.452845
# Unit test for function main
def test_main():

    with patch("ansible.module_utils.basic.AnsibleModule") as mock_module:
        # Create an instance of the module class
        mock_module.return_value = mocked_ansible_module = MagicMock(spec=AnsibleModule)

        with patch("ansible.module_utils.basic.AnsibleModule") as mock_module_two:
            # Create an instance of the module class
            mock_module_two.return_value = mocked_ansible_module = MagicMock(spec=AnsibleModule)

            # Create an instance of the pexpect module class
            with patch("pexpect.ExceptionPexpect") as mock_pexpect_exception:
                mock_pexpect_exception.side_effect = Exception(pexpect.ExceptionPexpect('test_pexpect_exception'))


# Generated at 2022-06-20 21:54:18.483224
# Unit test for function response_closure
def test_response_closure():
    import json
    from io import StringIO
    from ansible.module_utils.basic import AnsibleModule
    with open("fixtures/expect_response_closure.json", "r") as f:
        tests = json.load(f)
    for test in tests:
        module = AnsibleModule(argument_spec=test["args"])
        result = test["result"]
        responses = test["responses"]
        question = test["question"]
        responseFn = response_closure(module, question, responses)
        for result_index in range(len(result)):
            response = responseFn({"child_result_list": [question]})
            if result[result_index] is not None:
                assert response == result[result_index] + to_bytes("\n")
            else:
                assert response == to_

# Generated at 2022-06-20 21:54:30.544848
# Unit test for function response_closure
def test_response_closure():
    import sys

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    class ModuleTest(object):
        def fail_json(self, msg):
            raise Exception(msg)

    m = ModuleTest()
    r1 = "['\n', '\r\n']"
    r2 = "['\r', '\r\r\r\r\r']"
    r3 = "['\r\r']"
    r4 = "['\r\r\r']"
    r5 = "['\r\r\r\r']"
    r6 = "['\r\r\r\r\r']"
    r7 = "['\n\n\n']"

# Generated at 2022-06-20 21:54:41.314597
# Unit test for function response_closure
def test_response_closure():
    import pexpect
    import nose

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    child = pexpect.spawn('/bin/echo', timeout=5)
    child.expect('sleep')
    responses = ['one', 'two', 'three']

    # case insensitive
    resp_gen = response_closure(module, '(?i)sleep', responses)

# Generated at 2022-06-20 21:54:48.127731
# Unit test for function main
def test_main():
    import pexpect
    old_run = pexpect.run
    old_spawn = pexpect.spawn
    pexpect.run = lambda command: (b'', 0)
    pexpect.spawn = lambda command, *args, **kwargs: (b'', 0)

    old_module = AnsibleModule
    AnsibleModule = lambda argument_spec: (argument_spec, {})
    main()
    assert AnsibleModule[1]['rc'] == 0
    assert AnsibleModule[1]['changed']
    pexpect.run = old_run
    pexpect.spawn = old_spawn

# Generated at 2022-06-20 21:54:59.776552
# Unit test for function main
def test_main():
    import os
    import tempfile
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes, to_text

    tmpdir = tempfile.mkdtemp()
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)


# Generated at 2022-06-20 21:55:11.917900
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        """function to patch over fail_json; package return data into an exception"""
        k

# Generated at 2022-06-20 21:55:15.129370
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-20 21:55:26.822749
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        ),
        supports_check_mode=False,
        required_one_of=[],
        required_together=[],
        mutually_exclusive=[],
        add_file_common_args=False,
    )
    setattr(module, 'exit_json', exit_json)
    setattr(module, 'fail_json', fail_json)



# Generated at 2022-06-20 21:55:37.272037
# Unit test for function main
def test_main():
    args = dict(
        command = 'ls',
        creates = './somedir',
        removes = './somedir',
        responses = dict(Question = 'Response'),
        timeout = 30,
        echo = False
    )
    result = dict(
        cmd = 'ls',
        stdout = 'skipped, since ./somedir does not exist',
        rc = 0,
        start = '',
        end = '',
        delta = '',
        changed = False
    )
    # Input param test
    # Not required args
    module = AnsibleModule(argument_spec = args, supports_check_mode = False)
    # required args

# Generated at 2022-06-20 21:55:44.230151
# Unit test for function response_closure
def test_response_closure():

    # The response_closure function is used to generate responses to prompts
    # when the responses are specified in a list.  If the list is exhausted,
    # the module should fail_json
    # This test exercises this behaviour with a failing case.
    class FakeModule():
        def fail_json(self, msg):
            self.fail_json_msg = msg

    fake_module = FakeModule()
    response_gen = response_closure(fake_module, 'Question', ['response1', 'response2'])
    # Call once to get the first response
    response = response_gen({})
    # At this point, there is no second response, so calling again should fail_json
    response = response_gen({'child_result_list': [response]})

# Generated at 2022-06-20 21:56:35.014180
# Unit test for function response_closure
def test_response_closure():
    import mock
    class FakeModule(object):
        def __init__(self):
            self.fail_json = mock.MagicMock()
    mod = FakeModule()
    question = "Question"
    responses = ['response1', 'response2', 'response3']
    f = response_closure(mod, question, responses)
    assert f({'child_result_list': []}) == b"response1\n"
    assert f({'child_result_list': []}) == b"response2\n"
    assert f({'child_result_list': []}) == b"response3\n"
    assert f({'child_result_list': []}) == None
    mod.fail_json.assert_called_with(msg="No remaining responses for 'Question', output was ''")

# Generated at 2022-06-20 21:56:42.744579
# Unit test for function response_closure
def test_response_closure():
    class FakeModule:
        def fail_json(self, msg, **kwargs):
            raise Exception(msg.format(**kwargs))

    module = FakeModule()

    generator = response_closure(module, 'generator', ['a', 'b', 'c'])
    assert generator({}) == b'a\n'
    assert generator({}) == b'b\n'
    assert generator({}) == b'c\n'
    try:
        generator({})
        assert False
    except Exception as exp:
        assert str(exp) == "No remaining responses for 'generator', " \
                           "output was '{'child_result_list': []}'"

    fake_output = {'child_result_list': [b'chunk1\nchunk2\n']}


# Generated at 2022-06-20 21:56:48.136162
# Unit test for function main
def test_main():
    import imp
    import os
    import sys
    import tempfile

    # Save the original sys.argv
    orig_sys_argv = sys.argv

    # Read in the module source as a string
    module_file = os.path.realpath(__file__)
    with open(module_file) as f:
        module_data = f.read()

    # Need a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Setup a temporary module file
    module_name = 'ansible.builtin.expect'
    temp_module = os.path.join(temp_dir, module_name + '.py')
    with open(temp_module, 'w') as f:
        f.write(module_data)

    # Setup the expected test result

# Generated at 2022-06-20 21:56:58.462665
# Unit test for function response_closure
def test_response_closure():
    failed = False
    def module_fail_json(msg):
        assert msg.startswith("No remaining responses for")
        raise Exception(msg)
    def assertEquals(a,b):
        if a != b:
            print("FAIL: %s expected, %s received" % (a, b))
            assert False
    mod = type('', (object,), {'fail_json': module_fail_json})()
    for test in [
        ("foo", ["bar"], b"bar\n"),
        ("foo", ["bar", "baz"], b"bar\n", b"baz\n")
    ]:
        questions = test[0]
        responses = test[1]
        result = test[2:]
        out = []
        def run(a):
            out.append(a)
        tests

# Generated at 2022-06-20 21:57:04.230345
# Unit test for function response_closure
def test_response_closure():
    import doctest
    import importlib
    import sys
    importlib.reload(sys)
    module = doctest.DocTestFixture(globs={'module': module})
    if not module.runTest(doctest.DocTestSuite(response_closure)).failed:
        print('SUCCESS: test_response_closure')
    else:
        print('FAILURE: test_response_closure')

# Generated at 2022-06-20 21:57:15.712429
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    args = {
        'command': 'ls',
        'chdir': None,
        'echo': False,
        'responses': {
            'Question': 'dummy',
        },
        'removes': None,
        'creates': None,
        'timeout': 30,
    }
    imp_err = '\n'.join('%s: %s' % i for i in PEXPECT_IMP_ERR.items())

# Generated at 2022-06-20 21:57:27.305595
# Unit test for function main
def test_main():
    # Initialize an empty AnsibleModule instance
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    # Set argument values
    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']

    #

# Generated at 2022-06-20 21:57:31.575035
# Unit test for function response_closure
def test_response_closure():
    def mock_fail_json(*args, **kwargs):
        pass

    module = AnsibleModule(argument_spec={})
    module.fail_json = mock_fail_json

    question = 'question'
    response1 = 'response1'
    response2 = 'response2'
    responses = [response1, response2]
    response_func = response_closure(module, question, responses)

    # Get the first response
    info = {'child_result_list': [response1]}

# Generated at 2022-06-20 21:57:46.334531
# Unit test for function response_closure
def test_response_closure():
    import mock
    class MockModule(object):
        def fail_json(self, msg):
            raise Exception(msg)

    module = MockModule()

    def _test(responses, exp_results):
        counter = [0]
        def wrapped(info):
            counter[0] += 1
            return responses[counter[0] - 1]

        resp = response_closure(module, 'Question', responses)
        for i in range(len(exp_results)):
            text = resp({'child_result_list': ['']})
            assert text == exp_results[i]

    _test(['response1', 'response2', 'response3'],
          [b'response1\n', b'response2\n', b'response3\n'])


# Generated at 2022-06-20 21:57:51.510735
# Unit test for function response_closure
def test_response_closure():
    output = {}
    answer = response_closure(output, 'Question', ['response1', 'response2'])
    assert answer({'child_result_list': ['Question1']}) == b'response1\n'
    assert answer({'child_result_list': ['Question2']}) == b'response2\n'
    # the following statement fails with KeyError because
    # of StopIteration
    answer({'child_result_list': ['Question3']})

# Generated at 2022-06-20 21:59:41.380769
# Unit test for function main
def test_main():
    # required args
    args = dict(
        command='passwd username',
        responses={
            'assword': 'MySekretPa$$word'
        },
    )
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    main()

# Generated at 2022-06-20 21:59:54.282345
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    chdir = '/tmp/test'
    args = 'echo "Hello world"'
    creates = ''
    removes = ''
    responses = {'Hello': 'world'}
    timeout = '30'
    echo = False

    startd = datetime.datetime.now()


# Generated at 2022-06-20 22:00:03.308853
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Set sys.argv so the module thinks it is being invoked from the CLI
    sys.argv.insert(1, "")

    # The following is the answer to life, the universe, and everything
    response = response_closure(AnsibleModule(argument_spec={}),
                                "The question", [7, 7, 7])

    # Test that the generator works as intended
    assert(response("") == b"7\n")
    assert(response("") == b"7\n")
    assert(response("") == b"7\n")

    # Test that the generator fails as intended
    try:
        response("")
    except SystemExit:
        pass
    except Exception as e:
        assert(False)

# Generated at 2022-06-20 22:00:07.538000
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = ['first response', 'second response']
    question = 'question'
    resp_gen = response_closure(module, question, responses)
    assert resp_gen(1) == b'first response\n'
    assert resp_gen(1) == b'second response\n'
    try:
        resp_gen(1)
        assert False, "Expected pexpect.EOF"
    except pexpect.EOF:
        assert True, "Expected pexpect.EOF"

# Generated at 2022-06-20 22:00:17.868657
# Unit test for function main
def test_main():
    import pexpect
    import os
    #import whyteboard
    import pytest
    #from pytest_mock import mocker
    #import mocker
    #from module_utils.action_common_attributes import *
    import module_utils.action_common_attributes
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_bytes, to_native, to_text

    '''
    def explain_exception(exc_type, exc_value, exc_tb):
        return traceback.format_exception(exc_type, exc_value, exc_tb)

    sys.excepthook = explain_exception
    '''

    #mocker.patch('module_utils.action_common_attributes.__

# Generated at 2022-06-20 22:00:34.046319
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']
    events = dict()

# Generated at 2022-06-20 22:00:44.653592
# Unit test for function response_closure
def test_response_closure():
    import inspect

    def test_response_closure_call(name):
        closure = response_closure(name, response_closure.responses[name])
        if isinstance(closure, list):
            return closure
        new_closure = []
        while True:
            try:
                new_closure.append(closure())
            except TypeError:
                break
        return new_closure

    response_closure.responses = {
        'string': 'string',
        'list': ['string1', 'string2'],
    }
    assert test_response_closure_call('string') == ['string\n']
    assert test_response_closure_call('list') == ['string1\n', 'string2\n']

    response_closure.responses = {
        'function': lambda x: "string",
    }
    assert test_