

# Generated at 2022-06-20 21:51:03.021982
# Unit test for function main
def test_main():
    # Test with no args
    module = AnsibleModule({})
    rc, out, err = main()
    assert rc != 0
    assert 'no command given' in err

    # Test with valid args
    module = AnsibleModule({'command': 'echo', 'responses': {'test': 'test'}})
    rc, out, err = main()
    assert rc == 0
    assert out['stdout'] == ''
    assert out['rc'] == 0

    # Test with invalid args
    module = AnsibleModule({'command': 'echo', 'responses': {'test': 'test'}, 'timeout': 'foo'})
    rc, out, err = main()
    assert rc != 0
    assert 'Expected a timeout value of type' in err

# Generated at 2022-06-20 21:51:14.591962
# Unit test for function response_closure
def test_response_closure():
    from ansible import context
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes

    r = response_closure(None, "Question", ["response1", "response2", "response3"])
    assert r(None) == b"response1\n"
    assert r(None) == b"response2\n"
    assert r(None) == b"response3\n"

    c = context.CLIARGS
    c._config = None
    context._init_global_context(c)
    context.CLIARGS = c
    del c
    context.CLIARGS['vault_password_file'] = ['/nonexistant/path']

# Generated at 2022-06-20 21:51:29.649247
# Unit test for function response_closure
def test_response_closure():
    class Module(object):

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

    m = Module()

    question = 'Question'
    responses = ['response 1', 'response 2', 'response 3']

    r = response_closure(m, question, responses)

    assert 'response 1' == to_text(r({}), nonstring='passthru')

    assert 'response 2' == to_text(r({}), nonstring='passthru')

    assert 'response 3' == to_text(r({}), nonstring='passthru')

    try:
        r({})
    except Exception as e:
        assert e.args[0] == "No remaining responses for 'Question', output was ''"

# Generated at 2022-06-20 21:51:39.788241
# Unit test for function response_closure
def test_response_closure():
    """Create a test module"""
    module = AnsibleModule(argument_spec={})
    # Test a single response
    responses = ['single']
    question = 'foo'
    assert response_closure(module, question, responses)() == b'single\n'
    # Test 3 responses
    responses = ['first', 'second', 'third']
    assert response_closure(module, question, responses)() == b'first\n'
    assert response_closure(module, question, responses)() == b'second\n'
    assert response_closure(module, question, responses)() == b'third\n'
    # Test that we fail when we run out of responses
    with pytest.raises(SystemExit):
        response_closure(module, question, responses)()

# Generated at 2022-06-20 21:51:55.090066
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    got_response1 = False
    got_response2 = False
    got_response3 = False
    response = response_closure(module, question, responses)

# Generated at 2022-06-20 21:52:05.805705
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import ansible.modules.extras.system.expect.ansible_module_expect
    import sys

    args = dict()
    args['command'] = 'ansible-test'
    args['chdir'] = '/tmp'
    args['creates'] = '/tmp'
    args['removes'] = '/tmp'
    args['responses'] = 'dict'
    args['timeout'] = 30
    args['echo'] = 'True'

    print(args)


# Generated at 2022-06-20 21:52:06.705007
# Unit test for function main
def test_main():
    print('in test-main')
    assert True

# Generated at 2022-06-20 21:52:13.168116
# Unit test for function response_closure
def test_response_closure():
    import sys
    import json
    import difflib
    from pexpect import replwrap
    from io import StringIO
    from os import path
    from shutil import copy
    from tempfile import NamedTemporaryFile

    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_native, to_text

    PEXPECT_IMP_ERR = None
    try:
        import pexpect
    except ImportError:
        PEXPECT_IMP_ERR = traceback.format_exc()

    if not HAS_PEXPECT:
        raise missing_required_lib("pexpect")

    test_script = path.join(path.dirname(path.realpath(__file__)), 'expect-script.py')

# Generated at 2022-06-20 21:52:21.533052
# Unit test for function main
def test_main():

    test_utils = TestUtils()

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    PEXPECT_IMP_ERR = None
    try:
        import pexpect
        HAS_PEXPECT = True
    except ImportError:
        PEXPECT_IMP_ERR = traceback.format_exc()
        HAS_PEXPECT = False


# Generated at 2022-06-20 21:52:30.598405
# Unit test for function response_closure
def test_response_closure():

    # Unittest requires the module_utils to be loaded. In a real test case
    # you would mock the module_utils in a similar way to how it is done
    # in ansible-test.
    from ansible.module_utils.common.collections import is_list
    from ansible.module_utils.basic import AnsibleModule

    # Mock module object so it can be passed to response_closure.
    class MockModule(object):

        def __init__(self):
            self.fail_json = lambda msg: print(msg)

    # Mock module.fail_json to make sure it is called with the correct text.
    def fail_json(expected_msg):
        def actual_fail_json(msg):
            assert msg == expected_msg
        return actual_fail_json

    # Test empty response.

# Generated at 2022-06-20 21:52:50.953609
# Unit test for function response_closure
def test_response_closure():

    # Dictionary for test parameters
    test_args_1 = {
        'command': '/path/to/custom/command',
        'responses': {'Question': 'response1'},
        'timeout': 30,
        'echo': False,
    }

    test_args_2 = {
        'command': '/path/to/custom/command',
        'responses': {'Question': ['response1', 'response2', 'response3']},
        'timeout': 30,
        'echo': False,
    }

    # Initialize the Ansible Module so that the test can use it
    module = AnsibleModule(argument_spec=dict())

    # Test the response_closure function with buffer full error
    question = 'Question'
    responses = ['response1', 'response2', 'response3']

# Generated at 2022-06-20 21:53:04.241473
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    from ansible.module_utils.six import PY2

    mock_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )

    str_resps = response_closure(mock_module, 'Bob', ['Hello', 'World'])
    byte_resps = response_closure(mock_module, 'Bob', [b'Hello', b'World'])
    unicode_resps = response_closure(mock_module, 'Bob', [u'Hello', u'World'])
    if PY2:
        # Python 2 native str + unicode -> str
        assert str_resps(dict()) == 'Hello\n'
        assert str_resps(dict()) == 'World\n'

# Generated at 2022-06-20 21:53:08.956723
# Unit test for function main
def test_main():
    args = dict(
            command='ls -d /',
            responses=dict(
                out=['hello']
            )
        )
    module = AnsibleModule(argument_spec=dict())
    module.params = args
    main()


# Generated at 2022-06-20 21:53:20.589510
# Unit test for function main
def test_main():

    import inspect
    import json
    import os
    import tempfile
    import time

    from lib.actions import ModuleArgsParser
    from ansible.module_utils._text import to_bytes

    # This is something to make the stdout be comparable regardless
    # of Python version or locale settings
    # The following is Python 2.7 code which should be equivalent
    # to what Python 3.6 does by default.
    import io
    import locale
    import codecs
    def _surrogatepassthrough(exc):
        if 'surrogates not allowed' in str(exc):
            return (unicode(exc.object[exc.start:exc.end]), exc.end)
        raise TypeError(exc)
    codecs.register_error('surrogatepass', _surrogatepassthrough)


# Generated at 2022-06-20 21:53:27.593647
# Unit test for function response_closure
def test_response_closure():
    module = object()
    responses = ['a', 'b', 'c']

    def wrapped(info):
        try:
            return next(resp_gen)
        except StopIteration:
            module.fail_json(msg='No remaining responses for question, output was info[\'child_result_list\'][-1]')

    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

    assert response_closure(module, question='question', responses=responses) == wrapped

# Generated at 2022-06-20 21:53:35.648324
# Unit test for function main
def test_main():
    test_command = ['command1', 'command2', 'command3']
    test_resp = [
        ('^password:', 'password\r'),
        ('^password:', 'password\r'),
        ('^password:', ['password\r', 'a', 'b', 'c'])
    ]
    test_echo = True

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )


# Generated at 2022-06-20 21:53:46.661544
# Unit test for function main
def test_main():
    import sys
    import os
    import pexpect

    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params
            self.argument_spec = dict()

        def fail_json(self, **kwargs):
            print('FAIL: {}'.format(kwargs))
            sys.exit(1)

        def exit_json(self, **kwargs):
            print('OK: {}'.format(kwargs))
            sys.exit(0)

    class PexpectMock(object):
        def __init__(self):
            pass

        def run(self, command, timeout=0, withexitstatus=True,
                events=None, cwd=None, echo=False, encoding=None):
            return b'OK', 0


# Generated at 2022-06-20 21:53:57.385858
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    responses = ['resp 1', 'resp 2', 'resp 3']
    question = 'Question'
    response = response_closure(module, question, responses)

    assert response({}) == 'resp 1\n'
    assert response({}) == 'resp 2\n'
    assert response({}) == 'resp 3\n'
    assert response({'child_result_list': ['']}) == 'resp 1\n'
    assert response({'child_result_list': ['']}) == 'resp 2\n'
    assert response({'child_result_list': ['']}) == 'resp 3\n'
    assert response({'child_result_list': ['question']}) == 'resp 1\n'
    assert response

# Generated at 2022-06-20 21:54:03.127668
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    questions = ["question1", "question2", "question3", "question4"]
    responses = [ "response1", "response2", "response3", "response4"]
    responses2 = [ "response1", "response2", "response3", "response4", "response5"]
    responses3 = [ "response1", "response2", "response3", "response4", "response5", "response6"]

    def check(responses):
        responses = responses[:]

# Generated at 2022-06-20 21:54:09.516161
# Unit test for function main
def test_main():
    from ansible_collections.sivel.sivel_tests.plugins.modules.expect import main
    from ansible.module_utils.basic import AnsibleModule
    import os

    args = dict(
        command   = 'ls',
        chdir     = None,
        creates   = None,
        removes   = None,
        responses = None,
        timeout   = 0,
        echo      = False
    )
    cwd = os.path.dirname(__file__)
    test_stdout = b"__init__.py\ntest_expect.py\n"
    rc = 0

# Generated at 2022-06-20 21:54:40.946783
# Unit test for function response_closure
def test_response_closure():
    import unittest.mock
    m = unittest.mock.MagicMock()
    resps = ['resp1', 'resp2']

    def call_it(info):
        r = response_closure(m, 'Q', resps)
        return r(info)

    m.fail_json.side_effect = Exception('test')
    m.fail_json.reset_mock()

    # Test first value
    res = call_it(dict())
    assert res == b'resp1\n', res

    # Second call, second value
    res = call_it(dict())
    assert res == b'resp2\n', res

    # Should be at the end of the list now, raise exception

# Generated at 2022-06-20 21:54:49.330474
# Unit test for function main
def test_main():
    # Test case 1: command is wrong
    argument_spec = dict(command=dict(required=True), responses=dict(type='dict', required=True), timeout=dict(type='int', default=30), echo=dict(type='bool', default=False))
    testModule = AnsibleModule(argument_spec=argument_spec)
    chdir = None
    args = 'tampered_command'
    creates = None
    removes = None
    responses = {'Question': 'Answer'}
    timeout = 30
    echo = False
    events = dict()
    for key, value in responses.items():
        response = response_closure(testModule, key, value)
        events[to_bytes(key)] = response
    if chdir:
        chdir = os.path.abspath(chdir)
        os.chdir

# Generated at 2022-06-20 21:55:00.172436
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.ansible_modlib.common.collections import ImmutableDict
    from ansible.module_utils.basic import ArgumentSpec, AnsibleModule
    import ansible.module_utils.ansible_modlib.pexpect as pexpect

    module_args = dict(
        command="cmd",
        responses=dict(
            Question=["response1", "response2"],
            AnotherQuestion=["responseA", "responseB", "responseC"],
        )
    )
    spec = dict(
        command=dict(required=True),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
    )

    module_args['_ansible_check_mode'] = False
    module

# Generated at 2022-06-20 21:55:04.734548
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    import mock
    import pexpect

    def mock_run(*args, **kwargs):
        return (b'out', 0)

    mock_expect_module = mock.MagicMock()
    mock_expect_module.run.side_effect = mock_run


# Generated at 2022-06-20 21:55:20.006790
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule as _AnsibleModule
    from ansible.module_utils._text import to_bytes

    def _create_file(path, contents):
        with open(path, 'wb') as f:
            f.write(contents)
        return path

    # Mock with prototype
    class _pexpect(object):
        @staticmethod
        def run(command, timeout=30, withexitstatus=False, events=None, cwd=None, echo=False, encoding=None):
            return 'Mocked pexpect'
    class _AnsibleModuleMock(_AnsibleModule):
        def fail_json(self, **kwargs):
            self.result = kwargs
            self.exit_args = dict(failed=True)

# Generated at 2022-06-20 21:55:20.611149
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:55:27.597552
# Unit test for function main
def test_main():
    # Test for empty dict for responses param
    with pytest.raises(Exception) as e:
        main(responses={})
    assert e.value.args[0] == 'missing required arguments: responses'

    # Test for a valid response dict
    code, output = main(responses={'yes': 'yes'})
    assert code == 0
    assert output == 'changed=True\nchanged=True\nrc=0\n'

# Generated at 2022-06-20 21:55:43.571062
# Unit test for function main
def test_main():
    resp = {'Should we continue? (y/N)': ['y', 'n']}
    mod = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        ),
        supports_check_mode=False
    )

    mod.params['responses'] = resp
    main()
    assert mod.fail_json.called
    assert 'No remaining responses for' in mod.fail_json.call_args[0][0]['msg']
    assert mod.fail_json.call_

# Generated at 2022-06-20 21:55:52.382544
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            responses=dict(type='dict', required=True),
        )
    )
    responses = module.params['responses']
    responses = {
        r'Question: ([\s\S]+)': ['response1', 'response2', 'response3'],
    }

    (question, response) = responses.popitem()
    wrapped = response_closure(module, question, response)

    info = {}
    info['child_result_list'] = []
    assert wrapped(info) == b'response1\n'
    info['child_result_list'].append(b'This is an output line')
    assert wrapped(info) == b'response2\n'

# Generated at 2022-06-20 21:55:58.833945
# Unit test for function main
def test_main():
    import copy
    import json

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']

    events = dict()

# Generated at 2022-06-20 21:56:58.361937
# Unit test for function response_closure
def test_response_closure():
    # Test the case where responses are a list
    module = AnsibleModule(argument_spec=dict())
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    ret = response_closure(module, question, responses)
    assert len(ret) > 0
    assert ret(dict()) == 'response1\n'

    # Test the case where responses is not a list
    module = AnsibleModule(argument_spec=dict())
    question = 'Question'
    responses = 'responses'
    ret = response_closure(module, question, responses)
    assert len(ret) > 0
    assert ret(dict()) == 'responses\n'

# Generated at 2022-06-20 21:57:11.248430
# Unit test for function main
def test_main():
    # Make the argument list for this module
    module = AnsibleModule(dict(
        command=dict(required=True),
        responses=dict(type='dict', required=True),
    ))
    command = '/path/to/command'
    module.params = dict(
        command=command,
        responses=dict(
            question1='response1',
            question2='response2',
            question3='response3',
        )
    )
    # Instantiate the module
    mod = main()
    assert module.fail_json.call_count == 0
    assert module.exit_json.call_count == 1
    m_args, m_kwargs = module.exit_json.call_args
    assert m_args == tuple()
    call_args = m_kwargs['cmd']

# Generated at 2022-06-20 21:57:19.056255
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils import basic as ans_basic

    test_module = ans_basic.AnsibleModule(
        argument_spec=dict(
            responses=dict(type='dict', required=True)
        )
    )


    def test_module_fail_json(msg, **kwargs):
        assert msg == "No remaining responses for 'Question'"

    test_module.fail_json = test_module_fail_json

    response = response_closure(test_module, 'Question', ['response1', 'response2', 'response3'])

    child_result_list = [
        b"Question 1: Prompt",
        b"Question 2: Prompt"
    ]

    answer = response(dict(child_result_list=child_result_list))

    assert answer == b"response1\n"

    child_

# Generated at 2022-06-20 21:57:21.675284
# Unit test for function main
def test_main():
    assert to_bytes(u'hello\n')
    assert to_native(b'hello\n')


# Generated at 2022-06-20 21:57:29.934450
# Unit test for function response_closure
def test_response_closure():
    import mock
    import pytest

    module = mock.Mock()

    question = 'question'
    responses = ['foo', 'bar', 'baz']

    wrapped = response_closure(module, question, responses)

    def repeat(*args, **kwargs):
        raise RuntimeError()

    module.fail_json.side_effect = repeat

    assert wrapped(dict(child_result_list=[b'foo'])) == b'foo\n'
    assert wrapped(dict(child_result_list=[b'bar'])) == b'bar\n'
    assert wrapped(dict(child_result_list=[b'baz'])) == b'baz\n'
    with pytest.raises(RuntimeError):
        wrapped(dict(child_result_list=[b'quux']))

# Generated at 2022-06-20 21:57:45.126710
# Unit test for function response_closure
def test_response_closure():
    import unittest
    import mock

    def _validate(question, responses, num_occurrences=1, expected_return=None):
        m = mock.Mock()
        m.params = dict(question=question, responses=responses)
        rc = response_closure(m, question, responses)
        # verify that m.fail_json() is not called for the call to rc()
        assert not m.fail_json.called
        expected_return = expected_return or responses[-1]
        for _ in range(num_occurrences):
            assert rc([]) == '%s\n' % expected_return
        # verify that m.fail_json() IS called for the next call to rc()

# Generated at 2022-06-20 21:57:53.397176
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    import threading
    import time
    import mock

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass
    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an
        exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        if 'rc' not in kwargs:
            kwargs['rc'] = 0
       

# Generated at 2022-06-20 21:58:09.240804
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule({
        'command': 'ls',
        'chdir': None,
        'creates': None,
        'removes': None,
        'responses': {'(?i)password': 'MySekretPa$$word'},
        'timeout': 30,
        'echo': True,
    })

    b_out, rc, startd, endd, delta = to_native(b'ok'), 0, \
        datetime.datetime.now(), datetime.datetime.now(), \
        datetime.datetime.now() - datetime.datetime.now()


# Generated at 2022-06-20 21:58:10.988403
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-20 21:58:26.390662
# Unit test for function response_closure
def test_response_closure():
    import unittest

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict'),
            timeout=dict(default=30),
            echo=dict(type='bool', default=False),
        ),
        supports_check_mode=False,
    )

    class TestResponseClosure(unittest.TestCase):

        def test_successive_responses(self):
            responses = ['response1', 'response2', 'response3']

            response_f = response_closure(module, 'Question', responses)
            self.assertEqual(response_f({}), b'response1\n')

# Generated at 2022-06-20 22:00:32.038815
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:00:43.634207
# Unit test for function response_closure
def test_response_closure():
    import mock
    import pexpect

    test_module = mock.Mock()
    test_module.fail_json.side_effect = RuntimeError()

    test_question = 'foo'
    test_responses = ['bar', 'baz']

    test_value = 'bar'
    b_test_value = to_bytes(test_value)
    b_test_value_newline = b_test_value + b'\n'
    test_info = {'child_result_list': ['match1']}

    test_data = {'info': [test_info],
                 'values': [b_test_value_newline, b_test_value_newline, b_test_value_newline, b_test_value_newline]}
