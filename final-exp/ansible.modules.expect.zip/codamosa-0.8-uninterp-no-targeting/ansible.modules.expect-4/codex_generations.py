

# Generated at 2022-06-20 21:51:10.143935
# Unit test for function response_closure
def test_response_closure():
    command = None
    responses = {
        'foo': 'bar',
        'baz': ['bar', 'foo', 'bar']
    }
    wrapped1 = response_closure(None, 'foo', responses['foo'])
    wrapped2 = response_closure(None, 'baz', responses['baz'])

    assert wrapped1(None) == 'bar\n'
    assert wrapped1(None) == 'bar\n'
    assert wrapped2(None) == 'bar\n'
    assert wrapped2(None) == 'foo\n'
    assert wrapped2(None) == 'bar\n'

# Generated at 2022-06-20 21:51:11.467901
# Unit test for function response_closure
def test_response_closure():
    pass

# Generated at 2022-06-20 21:51:23.356603
# Unit test for function main
def test_main():
    args = {
    u'chdir': None,
    u'command': u' echo',
    u'creates': None,
    u'echo': False,
    u'removes': None,
    u'responses': {u'Interactive prompts': u'\n'},
    u'timeout': 30
    }

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    rc, out, changed = main(module, args)

# Generated at 2022-06-20 21:51:34.041378
# Unit test for function response_closure
def test_response_closure():
    import unittest

    class BaseTest(unittest.TestCase):
        class MyModule:
            def __init__(self):
                self.params = {'command': None}

            def fail_json(self, msg):
                raise ValueError(msg)

        class ModuleProxy:
            def __init__(self):
                self.module = BaseTest.MyModule()

            def fail_json(self, msg, **kwargs):
                self.module.fail_json(msg)

        def setUp(self):
            self.module = BaseTest.ModuleProxy()

        def tearDown(self):
            del self.module.module

    class TestResponseClosure(BaseTest):
        def test_plain_string(self):
            responses = response_closure(self.module, 'question', 'response')

# Generated at 2022-06-20 21:51:43.765223
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import basic
    from ansible.module_utils.ansible_release import __version__ as ansible_internal_version
    from ansible.module_utils.common.process import _clean_args
    from ansible.module_utils.six import PY3
    from io import BytesIO

    test_cmd = 'test command "with quotes"'
    test_chdir = '/path/to/somewhere'
    test_responses = {'Question': ['a', 'b', 'c']}
    test_timeout = 30
    test_echo = False


# Generated at 2022-06-20 21:51:48.925315
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    import six
    import sys

    class ModuleFailException(Exception):
        pass

    class FakeModule(object):
        class FakeModuleFailJsonException(Exception):
            pass

        def __init__(self):
            self.params = {}
            self.debug = {}
            self.log = {}
            self.fail_json_exception = self.FakeModuleFailJsonException()
            self.fail_json_msg = ''
            self.fail_json_rc = None

        def fail_json(self, rc=None, msg='', **kwargs):
            if not isinstance(msg, six.string_types):
                msg = str(msg)

            self.fail_json_msg = msg
            self.fail_json_rc = rc

# Generated at 2022-06-20 21:51:54.327326
# Unit test for function main
def test_main():
    module = AnsibleModule({'command': 'ls /root'})
    try:
        pexpect.run('ls /root')
    except:
        module.fail_json(msg='Insufficient version of pexpect installed')

# Generated at 2022-06-20 21:52:02.183488
# Unit test for function response_closure
def test_response_closure():
    import mock
    import ansible.module_utils.basic
    m = mock.MagicMock(spec=ansible.module_utils.basic.AnsibleModule)
    m.fail_json.side_effect = Exception
    r = response_closure(m, 'Key', ['Value'])
    assert r == 'Value\n'
    assert r() == 'Value\n'
    assert r() == 'Value\n'
    try:
        r()
    except Exception as e:
        assert 'No remaining responses for' in str(e)

# Generated at 2022-06-20 21:52:10.609984
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_bytes, to_native, to_text
    from ansible.module_utils.pycompat24 import get_exception
    import traceback
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    responses = ['response1', 'response2', 'response3']
    question = 'Question'

# Generated at 2022-06-20 21:52:16.049531
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as mock_exit:
        main()
        mock_exit.assert_called_with(
            cmd='ansible-test',
            stdout='skipped, since /tmp/test-file exists',
            changed=False,
            rc=0
        )

# Generated at 2022-06-20 21:52:34.594900
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import get_exception
    import ansible.module_ansible_expect
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')
    sys.path.append('../')
    sys.path.append('../lib/')
    sys.path.append('/usr/lib/python2.6/site-packages/')
    sys.path.append('/usr/lib/python2.7/site-packages/')
    import ansible_utils
    ann = ansible_utils.ansible_utils()
    ann.get_root()

# Generated at 2022-06-20 21:52:45.257139
# Unit test for function response_closure
def test_response_closure():
  import test.test_pexpect as tp
  import tempfile
  class Module(object):
    def fail_json(self, msg, **kwargs):
      self.msg = msg
  module = Module()
  module.params = {}
  module.params['command'] = 'command'
  module.params['responses'] = {'Question': ['response1', 'response2']}
  question = 'Question'
  tmp = tempfile.mkdtemp()
  p = pexpect.spawn('/bin/sh', ['-c', 'while true; do echo 1; read -p "Question?"; done'], cwd=tmp)
  response = response_closure(module, question, module.params['responses'][question])
  p.expect('Question')
  # response1
  response(tp.info)
 

# Generated at 2022-06-20 21:52:55.178523
# Unit test for function main
def test_main():
    if not HAS_PEXPECT:
        print('Failed: \"pexpect\" library is required for this test, skipping.')
        return False

    class MockModule():

        params = {}
        result = {}

        def fail_json(self, **kwargs):
            self.result = kwargs
            self.result.update(failed=True)

        def exit_json(self, **kwargs):
            self.result = kwargs
            self.result.update(failed=False)

    module = MockModule()

    # Test with no args
    main()
    assert module.result.get('failed') == True
    assert module.result.get('rc') == 256
    assert module.result.get('cmd') == 'no command given'

    # Test with args and chdir

# Generated at 2022-06-20 21:52:59.808914
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils._text import to_text

    class FakeModule():
        def __init__(self):
            self.fail_json_args = None

        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs

    expected_msg = "No remaining responses for 'foo', output was 'bar'"
    expected_msg = to_text(expected_msg)
    module = FakeModule()
    question = to_text('foo')
    responses = [to_text('bar')]
    response = response_closure(module, question, responses)
    response(dict(child_result_list=[to_text('bar')]))
    response(dict(child_result_list=[to_text('bar')]))
   

# Generated at 2022-06-20 21:53:15.165473
# Unit test for function response_closure
def test_response_closure():
    import mock

    class module_mock(object):
        @staticmethod
        def fail_json(msg):
            raise Exception(msg)

    module = module_mock()

    # Test the first response for 3 times
    responses = ["response 1", "response 2", "response 3"]

    # Successive calls return successive responses
    # The first response return, the second response return,
    # the third response return, but it should fail when the fourth
    # response is called.
    response = response_closure(module, "Question", responses)

    assert response({"child_result_list": [""]}) == "response 1\n"
    assert response({"child_result_list": [""]}) == "response 2\n"
    assert response({"child_result_list": [""]}) == "response 3\n"


# Generated at 2022-06-20 21:53:22.564770
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={'responses': dict(type='dict', required=True), 'command': dict(required=True)})
    m.fail_json = lambda msg, **kwargs: None
    # Case 1: keys are strings, values are strings
    r = {'key1': 'value1', 'key2': 'value2'}
    rc = response_closure(m, 'key1', r)
    assert next(rc) == b'value1\n'
    # Case 2: keys are strings, values are lists
    r = {'key1': ['value1', 'value2', 'value3'], 'key2': ['value4', 'value5', 'value6']}

# Generated at 2022-06-20 21:53:27.460546
# Unit test for function response_closure
def test_response_closure():
    class DummyModule:
        def __init__(self, fail_json):
            self.fail_json = fail_json

    class DummyResponse:
        child_result_list = ['nothing']

    with pytest.raises(StopIteration):
        response_closure(DummyModule(DummyResponse),
                         'question', [1, 2, 3])

# Generated at 2022-06-20 21:53:41.006140
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import pexpect

    MOCK_BASE_PATH = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'mock'))
    MOCK_MODULE_PATH = os.path.join(MOCK_BASE_PATH, 'ansible', 'modules', 'cloud', 'amazon', 'ec2_vpc_route_table')


# Generated at 2022-06-20 21:53:49.930700
# Unit test for function main
def test_main():
    moduleArgs = {
        'chdir': '/usr/bin',
        'creates': './hello.txt',
        'removes': './hello.txt',
        '_ansible_check_mode': False,
        '_ansible_diff': False,
        '_ansible_verbosity': 0,
        'ansible_loop_var': 'item',
        'command': 'ls',
        'responses': {
            'Question': ['response1', 'response2', 'response3']
        },
        'timeout': 60
    }


# Generated at 2022-06-20 21:54:04.514000
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import json
    import sys
    import re

    # Set up mock argument values.
    chdir = None
    args = '/etc/init.d/nginx restart'
    creates = None
    removes = None
    responses = {'\[sudo\] password for test': 'test\n'}
    timeout = 100
    echo = True

    # Set up sys to return input.
    class sys_input(object):
        def __init__(self, input):
            self.input = input

        def __call__(self):
            return self.input

    sys.modules['sys'] = sys_input

    # Mock module results.
    class AnsibleModuleResults(object):
        def __init__(self, changed):
            self.changed = changed


# Generated at 2022-06-20 21:54:37.529013
# Unit test for function main
def test_main():
    """
    # provide a set of arguments that would normally be received from the command line
    args = {'removes': None, 'chdir': None, 'creates': None, 'responses': 'some_dict', 'timeout': None, 'echo': None}

    # the mock_module fixture is a helper function that creates a fake ansible module
    mock_module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    test_main()
    """

# Generated at 2022-06-20 21:54:48.307826
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    assert response_closure(module, 'ooga', ['booga']) == b'booga\n'

    assert response_closure(module, 'ooga', ['booga', 'wooga'])() == b'booga\n'
    # get a new instance
    resp_gen = response_closure(module, 'ooga', ['booga', 'wooga'])
    assert resp_gen() == b'booga\n'
    assert resp_gen() == b'wooga\n'

    # get a new instance
    resp_gen = response_closure(module, 'ooga', ['booga', 'wooga'])
    # use a bunch of times
    assert resp_gen() == b'booga\n'

# Generated at 2022-06-20 21:54:59.837136
# Unit test for function main
def test_main():
    # Set up args
    module_args = dict(command='ls -l', chdir='/root',
                       creates=None, removes=None,
                       responses={}, timeout=30, echo=False)

    # Set up our mock objects
    class MockAnsibleModule(object):

        def __init__(self, arg_spec, no_log=False):
            self.params = arg_spec

        # Mock fail_json
        def fail_json(self, msg=None, rc=None):
            self.msg = msg
            self.rc = rc

        # Mock exit_json
        def exit_json(self, **kwargs):
            self.kwargs = kwargs

    module = MockAnsibleModule(module_args)

    # Mock the output of pexpect.spawn

# Generated at 2022-06-20 21:55:11.956238
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils._text

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            responses=dict(type='dict', required=True),
        )
    )

    question = "What is the meaning of life, the universe and everything?"
    # Create a finite generator function.
    response_closure(module, question, [42, 43])
    # Create an infinite generator function.
    responses = [42]
    response_closure(module, question, responses)
    # Create an infinite generator function.
    responses = [42, 43, 44]
    response = response_closure(module, question, responses)

# Generated at 2022-06-20 21:55:23.016567
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    question = 'Please select: '
    responses = ['1', '2']
    response = response_closure(module, question, responses)
    assert(response(None) == b'1\n')
    assert(response(None) == b'2\n')

# Generated at 2022-06-20 21:55:34.969169
# Unit test for function response_closure
def test_response_closure():
    import mock
    mock_module = mock.Mock()

    answer = 'answer'

    test_closure = response_closure(mock_module, 'question', ['answer'])
    assert answer == test_closure({'child_result_list': [None]})

    # Now that we have tested the single element case, test the list
    question = 'question'
    responses = ['answer1', 'answer2', 'answer3', 'answer4']

    test_closure = response_closure(mock_module, question, responses)

    # Test the first response
    assert responses[0] + '\n' == test_closure({'child_result_list': [None]})

    # Test the first response again, make sure we get the next value

# Generated at 2022-06-20 21:55:44.973295
# Unit test for function response_closure
def test_response_closure():
    y = ["hello", "hi"]
    res = response_closure(None, "Question", y)
    # res should return "hello" on the first call, "hi" on the second
    # and raise a StopIteration exception after that.
    assert res(None) == b"hello\n"
    assert res(None) == b"hi\n"
    try:
        res(None)
    except StopIteration:
        pass
    else:
        assert False # this should have raised a StopIteration exception

# Generated at 2022-06-20 21:55:53.130243
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec=dict(responses=dict(type='dict', required=True)))
    question = 'Question'
    responses = ['response1', 'response2', 'response3']

    resp_gen = response_closure(module, question, responses)(dict())
    assert resp_gen == b'response1\n'

    resp_gen = response_closure(module, question, responses)(dict())
    assert resp_gen == b'response2\n'

    resp_gen = response_closure(module, question, responses)(dict())
    assert resp_gen == b'response3\n'


# Generated at 2022-06-20 21:55:53.987750
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:56:08.232082
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    # Change working directory
    dir_name = 'test_dir'
    os.mkdir(dir_name)
    os.chdir(dir_name)

    # Create dummy command and make sure it fails
    command_name = 'command.sh'
    command_file = open(command_name, 'w')
    command_file.write('#!/usr/bin/env bash\n')
    command_file.write('echo "Hello World"\n')
    command_file.close()
    os.chmod(command_name, 0o755)

    responses = {
        'fatal: fatal': 'fatal',
        'repository is empty': 'repository',
        'error': 'error'
    }

    # Call main()

# Generated at 2022-06-20 21:57:07.532963
# Unit test for function main
def test_main():

    # create a module object
    class Obj(object):
        pass
    module = Obj()
    module.params = dict(command='ls -l')
    module.exit_json = lambda a: a
    module.fail_json = lambda a, b=None, **kwargs: b

    import sys
    import StringIO

    out = StringIO.StringIO()
    old_stdout = sys.stdout
    sys.stdout = out

    # Execute the main() function
    try:
        main()
    finally:
        sys.stdout = old_stdout
        out.close()

    # Now check the result
    sys.stdout.seek(0)
    assert '"cmd": "ls -l"' in sys.stdout.read()
    assert '"rc": 0' in sys.stdout.read()

# Generated at 2022-06-20 21:57:16.459550
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    if not HAS_PEXPECT:
        module.fail_json(msg=missing_required_lib("pexpect"),
                         exception=PEXPECT_IMP_ERR)

    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']

# Generated at 2022-06-20 21:57:27.396444
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.six import PY2

    if not PY2:
        from io import StringIO
    else:
        from cStringIO import StringIO

    import sys

    import textwrap

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            responses=dict(type='dict', required=True),
        )
    )

    def _assert_msg_equals(a, b):
        msg = "Expected: %s, Actual: %s" % (b, a)
        try:
            assert a == b
        except AssertionError:
            module.fail_json(msg=msg)


# Generated at 2022-06-20 21:57:28.187364
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    return 0

# Generated at 2022-06-20 21:57:29.066234
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:57:38.162808
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = ['a', 'b', 'c']
    question = 'My Question'
    callback = response_closure(module, question, responses)
    child_result_list = ['d', 'e', 'f']
    assert callback({'child_result_list': child_result_list}) == b'a\n'
    assert callback({'child_result_list': child_result_list}) == b'b\n'
    assert callback({'child_result_list': child_result_list}) == b'c\n'
    try:
        callback({'child_result_list': child_result_list})
        raise AssertionError("Module should have failed")
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-20 21:57:39.245859
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:57:49.073989
# Unit test for function main
def test_main():
    def run_module(module_args):
        if 'ANSIBLE_LIBRARY' not in os.environ:
            os.environ['ANSIBLE_LIBRARY'] = os.path.join(os.path.dirname(__file__),
                                                         '../../library')
        import ansible.modules.test.expect as expect
        return expect.main()[0]

    # Set up our module parameters
    module_return = dict(
        changed=True,
        delta='0:00:00.002000',
        end='Thu Jan 01 00:00:00 1970',
        rc=0,
        start='Thu Jan 01 00:00:00 1970',
        stderr='',
        stdout='',
        cmd='echo "bar"'
    )

# Generated at 2022-06-20 21:58:00.391139
# Unit test for function response_closure
def test_response_closure():
    import unittest

    class MyModule(object):
        def fail_json(self, msg):
            raise FailJsonException(msg)

    class FailJsonException(Exception):
        pass

    class MyTestCase(unittest.TestCase):
        def test_one(self):
            my_module = MyModule()
            question = "question"
            responses = ["response1", "response2"]
            generator = response_closure(my_module, question, responses)
            self.assertEqual(to_bytes('response1\n'),
                             generator({'child_result_list': []}))
            self.assertEqual(to_bytes('response2\n'),
                             generator({'child_result_list': []}))

# Generated at 2022-06-20 21:58:01.303919
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-20 22:00:02.802654
# Unit test for function response_closure
def test_response_closure():
    import sys

    if sys.version_info[0:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class AnsibleModuleTestCase(unittest.TestCase):

        def test_closure(self):
            pm = AnsibleModule(argument_spec=dict(
                responses=dict(type='dict', required=True),
            ))

            questions = ['one', 'two']
            responses = ['1', '2', '3']
            events = {}

            for index, question in enumerate(questions):
                response = response_closure(pm, question, responses)

                def wrapped(info):
                    return response(info)

                events[question] = wrapped

            self.assertEqual(events['one'](), b'1\n')
            self

# Generated at 2022-06-20 22:00:16.121927
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    try:
        import pexpect
    except ImportError:
        pass
    else:
        resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in ('response1', 'response2', 'response3'))
        response = response_closure(module, "Question", ('response1', 'response2', 'response3'))
        assert response(dict()) == next(resp_gen)
        assert response(dict()) == next(resp_gen)
        assert response(dict()) == next(resp_gen)
        assert response(dict()) == b'response3\n'
        assert response(dict()) == b'response3\n'

# Generated at 2022-06-20 22:00:20.896505
# Unit test for function main
def test_main():
    f = open('/tmp/testfile', 'w')
    f.write('abc')
    f.close()
    # Testing invalid module argument
    module = AnsibleModule(argument_spec=dict(
        command=dict(required=True), chdir=dict(type='path'), creates=dict(type='path'),
        removes=dict(type='path'), responses=dict(type='string'),
        timeout=dict(type='int', default=30)), supports_check_mode=False)
    try:
        main()
    except SystemExit as e:
        print(e.code)
    os.remove('/tmp/testfile')

# Generated at 2022-06-20 22:00:35.805610
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    responses = [ "first response", "second response", "third response" ]
    wrapped = response_closure(module, 'Question', responses)
    # First call should return "first response"
    assert wrapped(None) == b"first response\n"
    # Second call should return "second response"
    assert wrapped(None) == b"second response\n"
    # Third call should return "third response"
    assert wrapped(None) == b"third response\n"
    # Fourth call should error out

# Generated at 2022-06-20 22:00:40.307708
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    # Create a tmp file that mocks the ansible.builtin.expect module.
    handle, tmpfile = tempfile.mkstemp(prefix="ansible_test_response_closure_")


# Generated at 2022-06-20 22:00:50.954804
# Unit test for function response_closure
def test_response_closure():
    try:
        import pexpect
        HAS_PEXPECT = True
    except ImportError:
        HAS_PEXPECT = False

    # We don't care what the module object looks like here,
    # only that it has a fail_json method
    class FakeModule:
        def fail_json(self, *args, **kwargs):
            print(args)
            raise Exception()

    class FakeResult:
        def __init__(self):
            self.stdout = []

        def append(self, val):
            self.stdout.append(val)

    module = FakeModule()
    responses = ["response 1", "response2"]
    question = "question"
    question_bytes = to_bytes(question)

    # Since we can't easily get a pexpect.spawn object, set up a fake one