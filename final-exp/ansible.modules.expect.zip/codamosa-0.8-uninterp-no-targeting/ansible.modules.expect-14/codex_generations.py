

# Generated at 2022-06-20 21:50:54.636996
# Unit test for function main
def test_main():
    assert main(args=['/usr/bin/yes'])


# Generated at 2022-06-20 21:51:01.010542
# Unit test for function main
def test_main():
    import sys
    import pexpect
    import pexpect.expect

    sys.argv = ['ansible.builtin.expect', '/path/to/ansible.builtin.expect',
                'command=/bin/true', 'responses={}', 'chdir=.',
                'creates=/tmp/file', 'removes=/tmp/file']

    # Handle initialization of AnsibleModule

# Generated at 2022-06-20 21:51:13.674436
# Unit test for function response_closure
def test_response_closure():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec={'responses':dict(required=True)})

    question = "This is a question"
    responses = ["response 1", "response 2", "response 3"]
    mod_resp = response_closure(module, question, responses)

    calls = [0,0,0]
    results = []
    results.append(mod_resp({'child_result_list':['one']}))
    calls[0] = calls[0] + 1
    results.append(mod_resp({'child_result_list':['two']}))
    calls[1] = calls[1] + 1

# Generated at 2022-06-20 21:51:24.601472
# Unit test for function main
def test_main():
    import json
    import tempfile
    from contextlib import contextmanager

    from io import open
    from subprocess import Popen, PIPE, STDOUT

    from ansible_mock import patch
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils import basic as module_utils_basic
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    @contextmanager
    def _tempfile():
        fd, tf = tempfile.mkstemp()
        try:
            yield os.fdopen(fd, 'wb')
        finally:
            os.remove(tf)


# Generated at 2022-06-20 21:51:25.917820
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:51:37.473005
# Unit test for function main
def test_main():
    """Test Basic Expect module case
    """
    test_dict = {'chdir': None,
                 'creates': None,
                 'removes': None,
                 'responses': {'hello': 'world'},
                 'command': 'echo hello',
                 'timeout': 30,
                 'echo': False}

    module = AnsibleModule(argument_spec=dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
        ))

    module.params = test_dict
    main()

# Generated at 2022-06-20 21:51:40.446385
# Unit test for function main
def test_main():
    pass
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 21:51:55.613225
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    def generate_result(rc, stdout, **kwargs):
        result = dict(
            cmd=args,
            stdout=to_native(stdout).rstrip('\r\n'),
            rc=rc,
            start='',
            end='',
            delta='',
            changed=True,
        )
        result.update(kwargs)
        return result


# Generated at 2022-06-20 21:52:06.199859
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils import basic

    responses = {
        'question1': [
            'response to question 1',
            'another response to question 1',
            'yet another response to question 1',
        ],
        'question2': 'response to question 2',
    }
    rc = 1
    m = basic.AnsibleModule(
        argument_spec=dict(
            command='/bin/true',
            responses=dict(type='dict', required=True),
        ),
    )
    responses = {
        'question1': response_closure(m, 'question1', responses['question1']),
        'question2': b'%s\n' % to_bytes(responses['question2']).rstrip(b'\n'),
    }


# Generated at 2022-06-20 21:52:15.114487
# Unit test for function main
def test_main():
    import unittest
    import functools
    from pexpect import spawn

    class AnsibleModuleMock:
        def __init__(self, func):
            self.params = None
            self.func = func

        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)

        def exit_json(self, *args, **kwargs):
            raise SystemExit(args, kwargs)

        def __call__(self, *args, **kwargs):
            self.params = kwargs
            return self

    ansible_module_mock = AnsibleModuleMock(main)

    def parse_args(command):
        commands = command.split(' ')
        if len(commands) == 1:
            raise Exception('Must provide both a command and a question')

# Generated at 2022-06-20 21:52:28.486249
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:52:37.854753
# Unit test for function main
def test_main():
    import sys
    import os
    import argparse
    import tempfile
    import time

    # Define constants that are used throughout the unit test
    TEST_STDERR_NO_CAPTURE = to_bytes('This is stderr')
    TEST_STDOUT_FROM_STDOUT = to_bytes('This is stdout')
    TEST_STDOUT_FROM_STDERR = to_bytes('This is stderr')
    TEST_STDOUT_FROM_PEXPECT = to_bytes('This is pexpect')
    TEST_STDOUT_CHILD = to_bytes('This is stdout from child')
    TEST_STDOUT_CHILD_WITH_ESCAPE = to_bytes(r'This is stdout from child\nwith escape')

# Generated at 2022-06-20 21:52:48.946429
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    result = response_closure(module, question, responses)
    # First call is 'response1\n'
    assert result({'child_result_list': ['Stuff']}) == b'response1\n'
    # Second call is 'response2\n'
    assert result({'child_result_list': ['Stuff']}) == b'response2\n'
    # Third call is 'response3\n'
    assert result({'child_result_list': ['Stuff']}) == b'response3\n'
    # Fourth call raises a fail_json
    from ansible.module_utils.ansible_module_common import AnsibleFailJsonException

# Generated at 2022-06-20 21:52:56.568162
# Unit test for function response_closure
def test_response_closure():
    responses = [
        'one',
        'two',
        'three',
    ]

    key = 'Question'

    module = {
        'fail_json': lambda *args, **kwargs: None
    }

    response = response_closure(module, key, responses)

    assert response({'child_result_list': []}) == to_bytes('one\n')
    assert response({'child_result_list': []}) == to_bytes('two\n')
    assert response({'child_result_list': []}) == to_bytes('three\n')

    with pytest.raises(AnsibleModuleFail):
        response({'child_result_list': ['Initial output']})

# Generated at 2022-06-20 21:53:02.490865
# Unit test for function response_closure
def test_response_closure():
    import sys
    import types

    class Test:
        def __init__(self):
            self.fail_json = lambda msg, **k: sys.exit(1)
            self.params = dict()

        def run_command(self, args, check_rc=True):
            print(args)
            return 1, '', ''

    test = Test()
    test.params['responses'] = dict()
    test.params['responses']['password: '] = ['aaa', 'bbb']
    test.params['responses']['Please enter your password: '] = [r'Test\\\\\$1', r'Test\\\\\$2']
    test.params['responses']['Please enter your hostname: '] = [r'hostname', r'another_hostname']


# Generated at 2022-06-20 21:53:16.205088
# Unit test for function main
def test_main():
    args = '-vu'
    #args = None
    args = '-vu'
    args = '-v'
    args = '-h'
    args = 'terminal'
    args = ''
    args = '--help'
    args = '--version'
    args = '-d'
    args = '--debug'
    args = '-p'
    args = '-b'

    args = 'bar'
    args = '-v 1'
    args = '-p 2'
    args = '-b 3'
    if len(args):
        import sys
        sys.argv = [sys.argv[0]] + args.split()
        main()

# Generated at 2022-06-20 21:53:28.486617
# Unit test for function main
def test_main():

    from test_runner import AnsibleExitJson

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']
    timeout = module.params['timeout']
    echo = module.params['echo']

    # create a dummy pexpect class

# Generated at 2022-06-20 21:53:36.157614
# Unit test for function response_closure
def test_response_closure():
    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {
                'responses': {
                    'test': ['foo', 'bar', 'baz'],
                },
            }

        def fail_json(self, *args, **kwargs):
            raise ModuleFailException()

    class ModuleFailException(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    import doctest
    module = TestModule()
    result = doctest.run_docstring_examples(response_closure,
                                            {},
                                            name='TestModule',
                                            module=TestModule(),
                                            globs={'module': module})

# Generated at 2022-06-20 21:53:38.411877
# Unit test for function main
def test_main():
    import pexpect
    import ansible.module_utils.basic as basic
    import ansible.module_utils._text as text
    import ansibl

# Generated at 2022-06-20 21:53:48.580758
# Unit test for function response_closure

# Generated at 2022-06-20 21:54:19.248698
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = "Q?"
    responses = ["A", "B", "C"]
    response = response_closure(module, question, responses)

    info = {'child_result_list': ['D']}
    assert response(info) == b'A\n'
    assert response(info) == b'B\n'
    assert response(info) == b'C\n'

# Generated at 2022-06-20 21:54:21.476502
# Unit test for function main
def test_main():
    with patch('pexpect.spawn') as spawn:
        main()
        assert spawn.called == True

# Generated at 2022-06-20 21:54:33.450692
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils._text
    import ansible.module_utils.connection
    import ansible.module_utils.network_common
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.wait_for
    import ansible_collections.ansible.netcommon.plugins.module_utils.network
    # We're not testing all of these, just so we can import expect without
    # risking a name clash in global scope
    import time


# Generated at 2022-06-20 21:54:46.941233
# Unit test for function main
def test_main():
    from .mock import patch, MagicMock

    argv = ['ansible-test', 'expect', '-a', 'command=foo', '-a', 'responses="{key: value}"' ]

    with patch('ansible.module_utils.basic.AnsibleModule', autospec=True) as mock_module:
        with patch('ansible.module_utils.ansible_module.AnsibleModule', autospec=True) as mock_amodule:
            mock_module.return_value = MagicMock()
            mock_amodule.return_value = MagicMock()


# Generated at 2022-06-20 21:54:57.260830
# Unit test for function main
def test_main():
    
    t1 = pexpect.run('ls', timeout=30, withexitstatus=True, events=dict(), cwd=None, echo=True, encoding=None)
    print(t1)
    t2 = pexpect._run('ls', timeout=30, withexitstatus=True, events=dict(), extra_args=None, logfile=None, cwd=None, env=None, _spawn=pexpect.spawn, echo=True)
    print(t2)
    t3 = main();
    print(t3)

    print("Test complete")

# Generated at 2022-06-20 21:55:09.595300
# Unit test for function response_closure
def test_response_closure():
    class Module:
        def __init__(self):
            self.fail_json_called = False

        def fail_json(self, msg):
            self.fail_json_called = True
            self.msg = msg

    m = Module()
    question = 'Question'
    responses = ['response1', 'response2', 'response3']
    responses_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)
    r = response_closure(m, question, responses)

    # Case: valid response
    response = r(dict())
    assert response == next(responses_gen)
    assert not m.fail_json_called

    # Case: fail_json called
    response = r(dict(child_result_list=['last_output']))
   

# Generated at 2022-06-20 21:55:14.534647
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})

    responses = ['response1', 'response2', 'response3']
    expected = ['response1\n', 'response2\n', 'response3\n']

    resgen = response_closure(module, 'question', responses)

    out = []
    for _ in responses:
        out.append(resgen({}))
    assert expected == out


# Generated at 2022-06-20 21:55:25.892245
# Unit test for function response_closure
def test_response_closure():
    import mock
    import sys
    import unittest

    sys.modules['pexpect'] = mock.Mock()
    from ansible.modules.commands.command import response_closure

    module = mock.Mock()

    # First test case is a single response
    question = "Question"
    response = "Response"

    expected_outputs = ['Response']
    actual_outputs = []

    def mock_fail_json(msg):
        sys.modules['ansible.module_utils.basic'].AnsibleModule.fail_json = mock.Mock(msg=msg)

    def mock_exit_json(msg):
        sys.modules['ansible.module_utils.basic'].AnsibleModule.exit_json = mock.Mock(msg=msg)

    def mock_response(info):
        actual_output

# Generated at 2022-06-20 21:55:36.689980
# Unit test for function response_closure
def test_response_closure():
    import mock
    import sys
    import signal

    from ansible.modules.extras.basic.expect import response_closure
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.result = {}
            self.fail_json = mock.MagicMock(spec_set=True, side_effect=SystemExit)

    m = TestAnsibleModule()

    # Use the signal module to test the timeout functionality in
    # response_closure.
    signal.signal(signal.SIGALRM, lambda x, y: sys.exit(1))

    def test_response_closure_generator(question, responses, count):
        f = response_closure(m, question, responses)

       

# Generated at 2022-06-20 21:55:47.655699
# Unit test for function response_closure
def test_response_closure():
    import sys
    import unittest
    from unittest.mock import MagicMock
    from ansible.module_utils.basic import AnsibleModule

    FOO_ANSIBLE_MODULE_ARGS = dict(command='/bin/date', responses={'foo': ['bar', 'baz']})
    module = AnsibleModule(argument_spec=FOO_ANSIBLE_MODULE_ARGS)
    response = response_closure(module, 'foo', ['bar', 'baz'])
    expected_results = [b'bar\n', b'baz\n', b'FAILURE']
    actual_results = [response({'child_result_list': []}),
                      response({'child_result_list': []}),
                      response({'child_result_list': [b'/bin/date']})]
   

# Generated at 2022-06-20 21:56:46.574052
# Unit test for function response_closure
def test_response_closure():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, msg, **kwargs):
            self.fail_json_msg = msg
            self.fail_json_kwargs = kwargs

    # test case 1
    module = AnsibleModuleMock()
    question = u"Is it a good example?"
    responses = [1, 2, 3, 4, 5]
    responses_closure = response_closure(module, question, responses)
    info = {'child_result_list': [1, 2, 3, 4]}
    assert responses_closure(info) == b"5\n"
    # response consumed
    info = {'child_result_list': [1, 2, 3, 4, 5]}
    assert module.fail_json

# Generated at 2022-06-20 21:56:48.659225
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-20 21:56:53.241800
# Unit test for function main
def test_main():
    def mock_pexpect_run(command, timeout=None, withexitstatus=False, events=None, cwd=None, echo=False, env=None, extra_args=None, logfile=None, maxread=None, encoding=None):
        return ('Success', 0)

    def mock_pexpect_runu(command, timeout=None, withexitstatus=False, events=None, cwd=None, echo=False, env=None, extra_args=None, logfile=None, maxread=None, encoding=None):
        return ('Success', 0)


# Generated at 2022-06-20 21:56:54.106999
# Unit test for function response_closure
def test_response_closure():
    pass

# Generated at 2022-06-20 21:57:07.798772
# Unit test for function main
def test_main():
    args = dict(
        command='/bin/false',
        chdir='/tmp',
        creates='',
        removes='',
        responses={},
        timeout=30,
        echo=False
    )
    res = dict(
        cmd='/bin/false',
        stdout='',
        rc=1,
        start=str(datetime.datetime.now()),
        end=str(datetime.datetime.now()),
        delta=str(datetime.datetime.now() - datetime.datetime.now()),
        changed=True,
    )
    with pytest.raises(SystemExit) as cm:
        main()
    assert cm.value.args[0] == res

# Generated at 2022-06-20 21:57:11.694080
# Unit test for function response_closure
def test_response_closure():
    import os

    # Create a module with a side effect used to check the
    # right number of responses is generated
    class MockModule(object):
        def fail_json(self, *args, **kwargs):
            raise RuntimeError('Failed')

    module = MockModule()
    count = [0]
    question = ['Question']

    def wrapped(info):
        count[0] += 1
        return b'Some response'

    responses = [ wrapped ]
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

    closure = response_closure(module, question[0], responses)
    closure({'child_result_list' : [1,2,3]})

# Generated at 2022-06-20 21:57:24.752011
# Unit test for function response_closure
def test_response_closure():
    from collections import namedtuple
    from types import FunctionType
    class Module:
        def __init__(self):
            self.fail_json = lambda **kwargs: None
    module = Module()
    closure = response_closure(module, "foo", ["bar", "baz"])
    assert type(closure) is FunctionType
    assert closure(namedtuple("Result", "child_result_list")([b""])) == b"bar\n"
    assert closure(namedtuple("Result", "child_result_list")([b""])) == b"baz\n"
    with pytest.raises(Exception):
        closure(namedtuple("Result", "child_result_list")([b""]))

# Generated at 2022-06-20 21:57:32.431547
# Unit test for function response_closure
def test_response_closure():
    from six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = 'Question'
    responses = [ 'response1', 'response2', 'response3' ]
    resp_gen = (b'%s\n' % to_bytes(r).rstrip(b'\n') for r in responses)

    wrapped = response_closure(module, question, responses)

# Generated at 2022-06-20 21:57:47.176555
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    def mock_failure(msg):
        raise AssertionError(msg)

    def mock_success(msg):
        pass

    args = dict(
        command=['/bin/echo', 'foobar'],
        responses={
            'foo': ['bar', 'baz'],
        }
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.fail_json = mock_failure
    module.exit_json = mock_success
    resp_closure = response_closure(module, 'foo', args['responses']['foo'])

    assert resp_closure(dict(child_result_list=[])) == b'bar\n'

# Generated at 2022-06-20 21:57:52.287024
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False)))

    # Test module without pexpect
    module.pexpect = None
    main()

# Generated at 2022-06-20 21:59:50.055525
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:59:50.668306
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:59:53.834645
# Unit test for function main
def test_main():
    args = dict(
        command='ls -la',
        chdir='/home/testusr',
        creates='/home/testusr/file.txt',
        removes='/home/testusr/file.txt',
        responses={'Question':'Yes'},
        timeout=30,
        echo=True
    )
    m = AnsibleModule(**args)
    main()

# Generated at 2022-06-20 21:59:58.975765
# Unit test for function main
def test_main():
    getopt.getopt = pretest_getopt_getopt
    temp_stdin = sys.stdin
    try:
        sys.stdin = StringIO.StringIO('ls -l')
        main()
    finally:
        sys.stdin = temp_stdin


# Generated at 2022-06-20 22:00:14.829210
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    responses = [
        "one",
        "two",
        "three"
    ]
    question = "foo"
    resp_closure = response_closure(module, question, responses)

    assert resp_closure({"child_result_list": []}) == b"one\n"
    assert resp_closure({"child_result_list": []}) == b"two\n"

# Generated at 2022-06-20 22:00:24.423425
# Unit test for function main
def test_main():
    from . import expect_module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    m = AnsibleModule(dict(
        command='/usr/bin/env',
        chdir='/',
        creates=None,
        removes=None,
        responses=dict(
            Hello=b'World',
        ),
        timeout=5,
        echo=True,
    ))

    try:
        expect_module.HAS_PEXPECT = False
        expect_module.main()
    except SystemExit:
        err = m._result['msg']
        assert 'pexpect' in err
        assert 'missing' in err

    expect_module.HAS_PEXPECT = True

# Generated at 2022-06-20 22:00:29.689684
# Unit test for function main
def test_main():
    # If a string that is too long to be processed by the expect module
    # is passed to the main function, then the module will throw an exception.
    # This scenario is handled in the main function and is tested here.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import missing_required_lib
    from ansible.module_utils._text import to_bytes
    command = "You have new mail in /var/mail/ansible"
    chdir = "/tmp"
    creates = ""
    removes = ""
    responses = {}
    timeout = 30
    args = (command, chdir, creates, removes, responses, timeout)

# Generated at 2022-06-20 22:00:33.257442
# Unit test for function response_closure
def test_response_closure():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    def test_fun():
        module = AnsibleModule(argument_spec={})

        wrapped = response_closure(module, 'Question', ['response1', 'response2', 'response3'])

        assert wrapped({}) == 'response1\n'
        assert wrapped({}) == 'response2\n'
        assert wrapped({}) == 'response3\n'
        with pytest.raises(AnsibleModule.fail_json.parameter_value_exception_obj):
            wrapped({'child_result_list': [1]})

# Generated at 2022-06-20 22:00:33.659986
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:00:38.394122
# Unit test for function response_closure
def test_response_closure():

    class FakeModule(object):
        def __init__(self):
            self.fail_json_called = 0
            self.msg = None

        def fail_json(self, msg, **kwargs):
            self.fail_json_called += 1
            self.msg = msg
            return False

    class FakeChildResult(object):
        def __init__(self):
            self.value = 0
            self.output = None

        def append_result(self, output):
            self.value += 1
            self.output = output

    class FakeInfo(object):
        def __init__(self):
            self.fake_child_result_list = FakeChildResult()

        @property
        def child_result_list(self):
            return self.fake_child_result_list

    module = FakeModule()