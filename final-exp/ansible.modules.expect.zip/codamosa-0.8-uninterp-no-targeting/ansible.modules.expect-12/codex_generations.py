

# Generated at 2022-06-20 21:51:12.126315
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic as module_args
    import ansible.module_utils._text as to_bytes

    with_list_responses = [ "foo", "bar", "baz" ]

    # test with a list of responses
    wrapped = response_closure(module_args.AnsibleModule(argument_spec={}),
                               "question", with_list_responses)
    assert wrapped({"child_result_list": []}) == to_bytes("foo")
    assert wrapped({"child_result_list": []}) == to_bytes("bar")
    assert wrapped({"child_result_list": []}) == to_bytes("baz")

# Generated at 2022-06-20 21:51:19.394717
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})
    responses = ['bar', 'baz']
    def resp_gen(info):
        try:
            return next(resp_gen)
        except StopIteration:
            module.fail_json(msg="No remaining responses for '%s', "
                             "output was '%s'" %
                             ('question', 'output'))

    resp_closure = response_closure(module, 'question', responses)
    assert resp_closure == resp_gen

# Generated at 2022-06-20 21:51:30.217971
# Unit test for function response_closure
def test_response_closure():
    m = AnsibleModule(argument_spec={})

    q1 = "Question 1:"
    r1 = ["response1", "response2", "response3"]

    assert response_closure(m, q1, r1) == b'response1\n'
    assert response_closure(m, q1, r1) == b'response2\n'
    assert response_closure(m, q1, r1) == b'response3\n'

    with pytest.raises(AnsibleError):
        response_closure(m, q1, r1)

# Generated at 2022-06-20 21:51:41.401483
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    question = "Test question"
    responses = ["Test response1", "Test response2"]

    r = response_closure(module, question, responses)

    assert r({'child_result_list': "Test response1"}) == b"Test response1\n"
    assert r({'child_result_list': "Test response2"}) == b"Test response2\n"


# Generated at 2022-06-20 21:51:56.168612
# Unit test for function main
def test_main():
    # Load arguments from ansible for unit tests
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    #is_changed, changed_data, original_data, diff, success_message
    chdir = module.params['chdir']
    args = module.params['command']
    creates = module.params['creates']
    removes = module.params['removes']
    responses = module.params['responses']

# Generated at 2022-06-20 21:52:06.705255
# Unit test for function response_closure
def test_response_closure():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_text

    import sys
    sys.path.append('lib/')

    class AnsibleModuleFake():
        def __init__(self, arg=None):
            arg = arg or {}
            self.params = arg

        def fail_json(self, **args):
            raise RuntimeError('Fail')

    module = AnsibleModuleFake()
    response = response_closure(module, 'question', ['response1', 'response2'])

# Generated at 2022-06-20 21:52:07.130745
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:52:16.420860
# Unit test for function response_closure
def test_response_closure():
    import io
    import unittest
    import pexpect
    import ansible.module_utils.basic
    import ansible.module_utils
    import sys
    def test_empty_closure():
        test_pexpect = pexpect.spawn('echo gogogo')
        test_module, test_connection = ansible.module_utils.basic.AnsibleModule(argument_spec = {'command': {'required': True}}), None
        test_closure = response_closure( test_module, 'Question1', [])
        with self.assertRaises(StopIteration):
            test_closure(test_pexpect)

    def test_normal_closure():
        test_pexpect = pexpect.spawn('echo gogogo')
        test_pexpect.expect('gogogo')
        test_module, test_

# Generated at 2022-06-20 21:52:31.465867
# Unit test for function main
def test_main():
    import sys

    print(sys.version)
    print(sys.version_info)
    print(sys.path)

    if sys.version_info[0] == 2:
        module = __import__('mock')
    elif sys.version_info[0] == 3:
        module = __import__('unittest.mock')
    else:
        raise Exception('Unknown Python version %s' % sys.version_info)

    spec_set = module.mock.patch.object(
        AnsibleModule,
        'exit_json',
    )

    mock = module.Mock()

    class Status:
        def __init__(self, rc):
            self.rc = rc

    mock.return_value = Status(0)
    spec_set.start()

    result = main()

    spec_

# Generated at 2022-06-20 21:52:36.556309
# Unit test for function response_closure
def test_response_closure():
    import re
    class TestModule(object):
        def fail_json(self, **msg):
            print(msg) # pragma: no cover

    module = TestModule()
    question = 'Question?'
    answers = ['yes', 'no', 'maybe']
    events = {to_bytes(question): response_closure(module, question, answers)}

    for answer in answers:
        events[to_text(question)]({'child_result_list': [None, None]})

    try:
        events[to_text(question)]({'child_result_list': [None, None]})
    except (pep.ExceptionPexpect, SystemExit):
        pass
    else:
        start = 'No "AnsibleException: No remaining responses for \'%s\'' % question

# Generated at 2022-06-20 21:53:06.132470
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    inp_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    key = b'Question'
    values = ['One', 'Two', 'Three']
    response = response_closure(inp_module, key, values)

    assert(response({'question': key, 'child_result_list': []}) == b'One\n')

# Generated at 2022-06-20 21:53:17.829147
# Unit test for function main
def test_main():
    # N.B. Don't test echos because they're not easily distinguishable
    args = dict(responses={'a': 'b', 'c': 'd'})
    args.update(dict(command='cat /dev/null'))
    module_args = dict()
    module_args.update(args)
    module_args.update(dict(creates='/dev/null'))
    module = AnsibleModule(module_args)
    args.update(dict(module=module))
    args.update(dict(module_args=module_args))
    main()
    assert module._result['stdout'] == ''
    assert module._result['rc'] == 0
    assert module._result['changed'] == True
    assert module._result['cmd'] == 'cat /dev/null'
    assert module._result['start']

# Generated at 2022-06-20 21:53:29.708164
# Unit test for function response_closure
def test_response_closure():
    import unittest

    class TestResponseClosure(unittest.TestCase):

        def setUp(self):
            self.question = "How are you?"
            self.responses = ["I am good", "I am fine", "I am bad"]

        def test_response_closure_one(self):
            response = response_closure(self, self.question, self.responses)
            self.assertEqual(response({"child_result_list": []}), b"I am good\n")

        def test_response_closure_two(self):
            response = response_closure(self, self.question, self.responses)
            self.assertEqual(response({"child_result_list": [""]}), b"I am fine\n")

        def test_response_closure_three(self):
            response = response

# Generated at 2022-06-20 21:53:34.816418
# Unit test for function main
def test_main():
    # Setup pexpect mock
    from ansible.module_utils import basic
    from ansible.module_utils.pexpect import pexpect

    class PexpectModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda msg, **args: self.fail_msg
            self.exit_json = lambda **args: self.exit_msg

        def fail_json(self, msg):
            raise RuntimeError(msg)

    def pexpect_run_mock(args, timeout=30, withexitstatus=True, events=None, cwd=None, echo=False, encoding=None):
        '''Call our mock module instance with the passed kwargs'''

# Generated at 2022-06-20 21:53:45.957862
# Unit test for function response_closure
def test_response_closure():
   from shutil import copyfile
   from tempfile import mkstemp
   from unittest import TestCase
   import os
   import stat

   class AnsibleModule:
      def __init__(self):
         pass
      def fail_json(self, msg):
         raise Exception(msg)

   class TestExpect(TestCase):
      def test_response_closure(self):
         args = ('passwd', 'username')

         responses = {
            '(?i)password:': [ 'passwordwrong', 'password1', 'password2' ],
         }

         module = AnsibleModule()
         question = '(?i)password:'
         responses = responses[question]
         response = response_closure(module, question, responses)


# Generated at 2022-06-20 21:53:56.427888
# Unit test for function response_closure
def test_response_closure():
    response_list = ['response1','response2','response3','response4']
    responses = response_closure(None, 'dummy string', response_list)
    # first call should be equal to first element of response_list
    assert responses('dummy info')  == b'response1\n'
    # second call should be equal to second element of response_list
    assert responses('dummy info') == b'response2\n'
    # third call should be equal to third element of response_list
    assert responses('dummy info') == b'response3\n'
    # fourth call should be equal to fourth element of response_list
    assert responses('dummy info') == b'response4\n'

# Generated at 2022-06-20 21:54:02.924281
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
        mock_module = Mock()
        mock_module.check_mode = False
        mock_module.params = {
            'chdir': True,
            'command': True,
            'creates': True,
            'removes': True,
            'responses': {'key': 'value'},
            'timeout': 30,
            'echo': False
        }

        mock_AnsibleModule.return_value = mock_module


# Generated at 2022-06-20 21:54:14.527791
# Unit test for function main
def test_main():
    # the following test
    # was obtained from http://www.python-forum.org/pythonforum/viewtopic.php?f=3&t=19439
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils._text as text

    class TestModule(unittest.TestCase):
        def test_main(self):
            args = dict(
                command='ls',
                responses=dict(
                    word='yes',
                    hi='hello'
                ),
            )

# Generated at 2022-06-20 21:54:26.815282
# Unit test for function main
def test_main():
    import pexpect
    import shutil
    import tempfile
    import datetime

    # Create a file with the following content
    # Manually test the expect module by running the following command:
    #   ansible -m expect -a "command=cat /tmp/foo; echo bar; sleep 2; echo baz" \
    #           -a "responses={'bar': 'biz', 'baz': 'buzz'}" -i inventory default

# Generated at 2022-06-20 21:54:32.209175
# Unit test for function main
def test_main():
    # Mock ansible module
    import sys
    import tempfile

    def mock_exit_json(**kwargs):
        sys.exit(0)

    def mock_fail_json(**kwargs):
        sys.exit(1)

    class MockModule:
        def __init__(self):
            sys.modules['ansible'] = mock_module
            self.params = {
                'chdir': None,
                'command': 'cowsay moo',
                'creates': None,
                'removes': None,
                'responses': {
                    '6 cows': '6'
                },
                'timeout': None,
                'echo': False,
            }
            self.check_mode = False
            self.exit_json = mock_exit_json
            self.fail_json = mock_fail_json

# Generated at 2022-06-20 21:55:04.522684
# Unit test for function response_closure
def test_response_closure():
    import copy
    module = AnsibleModule({}, {})
    question = 'Question'
    responses = ['response1', 'response2']
    resp_gen = response_closure(module, question, responses)
    responses_copy = copy.copy(responses)
    assert resp_gen(None) == 'response1\n'
    assert resp_gen(None) == 'response2\n'
    assert responses == responses_copy, 'responses was mutated'
    try:
        resp_gen({'child_result_list': ['output string']})
        assert False, 'expected exception'
    except Exception as e:
        assert 'No remaining responses for \'Question\'' in str(e)

# Generated at 2022-06-20 21:55:14.319334
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

# Generated at 2022-06-20 21:55:25.887090
# Unit test for function main
def test_main():
    test_cmd = 'echo "Hello, World"'
    test_cmd_creates_nofile = 'echo "Hello, World"'
    test_cmd_creates_yesfile = 'echo "Hello, World"'
    test_cmd_removes_nofile = 'echo "Hello, World"'
    test_cmd_removes_yesfile = 'echo "Hello, World"'
    test_chdir_none = None
    test_chdir_yes = '/home/vagrant'
    test_creates_none = None
    test_creates_nofile = './test_creates_nofile'
    test_creates_yesfile = './test_creates_yesfile'
    test_removes_none = None
    test_removes_nofile = './test_removes_nofile'

# Generated at 2022-06-20 21:55:36.689977
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    with open('expect.json') as data_file:
        data = json.load(data_file)

    test_args = data['args']
    test_args['responses'] = {
        'password:': 'password'
    }

    orig_sys_argv = sys.argv
    orig_sys_stdout = sys.stdout
    orig_os_chdir = os.chdir
    orig_os_stat = os.stat

    if sys.version_info[0] < 3:
        open_function = '__builtin__.open'
    else:
        open_function = 'builtins.open'



# Generated at 2022-06-20 21:55:43.759686
# Unit test for function response_closure
def test_response_closure():
    import unittest
    from unittest.mock import Mock

    # Use this to mock the module
    class MockModule:
        def __init__(self):
            self.fail_json = Mock()
            self.fail_json.side_effect = Exception('Fail_Json Exception')

    mock_module = MockModule()
    question = 'Test'
    responses = ['one', 'two', 'three']

    # Test that it returns the expected value
    response = response_closure(mock_module, question, responses)
    assert response({'child_result_list': ['Test']}) == 'one\n'
    assert response({'child_result_list': ['Test']}) == 'two\n'
    assert response({'child_result_list': ['Test']}) == 'three\n'

    # Test that it throws

# Generated at 2022-06-20 21:55:52.419798
# Unit test for function main
def test_main():
    startd = datetime.datetime.now()
    args = "echo hello world"
    expected_result = {
        'cmd': args,
        'stdout': 'hello world',
        'rc': 0,
        'start': str(startd),
        'end': str(startd),
        'delta': '0:00:00.000000',
        'changed': True
    }
    module = AnsibleModule(argument_spec=dict(
        command=dict(required=True),
        chdir=dict(type='path'),
        creates=dict(type='path'),
        removes=dict(type='path'),
        responses=dict(type='dict', required=True),
        timeout=dict(type='int', default=30),
        echo=dict(type='bool', default=False),
    ))

# Generated at 2022-06-20 21:55:58.870242
# Unit test for function main
def test_main():
    import os
    import sys
    import imp
    import shlex
    import yaml
    import tempfile
    # imp.load_source's first argument is the filename, not a module name
    module = imp.load_source('_', 'expect.py')
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write('''#!/bin/sh
echo "foo is bar"''')

# Generated at 2022-06-20 21:56:10.362841
# Unit test for function main
def test_main():
    # Calling main() with different parameters should
    # cause the function module.exit_json() to return
    # different results
    # Patch the function module.exit_json with a
    # lambda.
    # Patch the function module.fail_json with a
    # lambda.
    # Patch the function module.fail_json with a
    # lambda.

    # Create a Mock object
    with patch.object(AnsibleModule, 'expect') as mock_expect:

        # Create a Mock object
        with patch.object(AnsibleModule, 'fail_json') as mock_fail_json:

            # Create a Mock object
            with patch.object(AnsibleModule, 'fail_json') as mock_fail_json:
                main()
                assert mock_expect.call_count == 1

# Generated at 2022-06-20 21:56:21.197088
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
            creates=dict(type='path'),
            removes=dict(type='path'),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )

    def test_fail(msg, **kwargs):
        try:
            module.fail_json(msg=msg, **kwargs)
        except SystemExit as e:
            assert e.code == 1

    def test_exit(msg, **kwargs):
        try:
            module.exit_json(msg=msg, **kwargs)
        except SystemExit as e:
            assert e.code == 0


# Generated at 2022-06-20 21:56:25.730698
# Unit test for function main
def test_main():
    import subprocess
    import tempfile
    import pexpect
    import ansible.module_utils.basic

    # Create a test script to run
    fh, script = tempfile.mkstemp()

# Generated at 2022-06-20 21:57:27.264495
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule()

    class FakeException(Exception):
        pass

    responses = [1, 2, 3, 4, 5]

    def test_func(info):
        try:
            return next(responses)
        except StopIteration:
            raise FakeException('BAM!')

    wrapped = response_closure(module, 'Foo', test_func)
    assert wrapped({'child_result_list': []}) == b'1\n'
    assert wrapped({'child_result_list': []}) == b'2\n'
    assert wrapped({'child_result_list': []}) == b'3\n'
    assert wrapped({'child_result_list': []}) == b'4\n'
    assert wrapped({'child_result_list': []}) == b'5\n'

# Generated at 2022-06-20 21:57:36.964471
# Unit test for function response_closure
def test_response_closure():
    """
    - name: Generic question with multiple different responses
      ansible.builtin.expect:
        command: /path/to/custom/command
        responses:
          Question:
            - response1
            - response2
            - response3
    """
    import io
    import sys
    import unittest

    module = sys.modules[__name__]
    module.fail_json = lambda *args, **kwargs: sys.exit(1)
    module.exit_json = lambda *args, **kwargs: sys.exit(0)

    class MockModule(object):
        class _AnsibleFailJson(object):
            def __init__(self):
                self.msg = None
            def __call__(self, msg):
                self.msg = msg

        fail_json = _AnsibleFailJ

# Generated at 2022-06-20 21:57:48.884620
# Unit test for function main
def test_main():
    module = MockModule({
        'command': 'echo "Hello World"',
        'responses': {
            'Enter your name:': "Ansible"
        },
        'timeout': 5,
        'echo': False
    })

    try:
        pexpect.run = MockPexpectRun(module)
        main()
    except SystemExit:
        pass

    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    test_data_1 = os.path.join(test_data_dir, 'expect_test_1.txt')
    test_data_2 = os.path.join(test_data_dir, 'expect_test_2.txt')

# Generated at 2022-06-20 21:58:00.389274
# Unit test for function main
def test_main():
    args = dict(
        command='ls',
        chdir='/tmp',
        creates='/tmp',
        removes='/tmp',
        responses=dict(hoge=['hoge'], fuga='fuga'),
        timeout=30,
        echo=True
    )
    module_args = dict(
        argument_spec=dict(
            command=dict(required=True),
            chdir=dict(type='path', default=''),
            creates=dict(type='path', default=''),
            removes=dict(type='path', default=''),
            responses=dict(type='dict', required=True),
            timeout=dict(type='int', default=30),
            echo=dict(type='bool', default=False),
        )
    )
    module_args.update(args)
    module = Ans

# Generated at 2022-06-20 21:58:05.563733
# Unit test for function main
def test_main():
    command = "pwd"
    chdir = ""
    creates = ""
    removes = ""
    responses = {
            "test1": "test2",
            "test3": "test4",
    }
    timeout = 30
    echo = False
    module = AnsibleModule(argument_spec=dict(command=dict(required=True),
                                              chdir=dict(type='path'),
                                              creates=dict(type='path'),
                                              removes=dict(type='path'),
                                              responses=dict(type='dict',
                                                             required=True),
                                              timeout=dict(type='int',
                                                           default=30),
                                              echo=dict(type='bool',
                                                        default=False),
                                              )
                           )

# Generated at 2022-06-20 21:58:06.174845
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:58:07.355185
# Unit test for function main
def test_main():
    # TODO: Stubs
    pass

# Generated at 2022-06-20 21:58:17.888329
# Unit test for function main
def test_main():
    import sys
    import signal

    command = 'echo test'
    responses = {'test': 'test'}
    args = {
        'command': command,
        'responses': responses,
        '_ansible_module_name': 'ansible.builtin.expect',
        '_ansible_debug': True
    }

    # AnsibleModule.run_command is patched to call this function instead
    def run_command(module, command):
        module.log(command)  # prints test_main output for debugging
        return (0, '')

    # Start replacement modules
    import pexpect
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = TestAnsibleModule

# Generated at 2022-06-20 21:58:29.516239
# Unit test for function response_closure
def test_response_closure():
    import ansible.module_utils.basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-20 21:58:35.869872
# Unit test for function response_closure
def test_response_closure():
    module = AnsibleModule(argument_spec={})

    key = 'Question'
    responses = ['response1', 'response2', 'response3']
    rc_func = response_closure(module, key, responses)

    assert rc_func("foo") == b'response1\n'
    assert rc_func("foo") == b'response2\n'
    assert rc_func("foo") == b'response3\n'

# Generated at 2022-06-20 22:00:50.956211
# Unit test for function main
def test_main():
    # Import PeXpect here to avoid it getting imported too early and causing a
    # fatal AttributeError on Python 2.6.
    import pexpect

    def run_pexpect(args, timeout=None, withexitstatus=False,
                    events=None, extra_args=None, logfile=None, cwd=None,
                    env=None, _spawn=pexpect.spawn):
        # Return arg passed in as withexitstatus.
        return None, withexitstatus

    # Testing with a real version
    setattr(pexpect, '__version__', '4.2.1')
    setattr(pexpect, 'run', run_pexpect)
    setattr(pexpect, 'spawn', run_pexpect)
    assert main() == 0

    # Testing with a lower version