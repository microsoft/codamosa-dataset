

# Generated at 2022-06-21 21:47:09.454656
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__() should return True if and only if attributes
    __dict__ of both objects are equal.
    """
    class TestException(InvalidPattern):
        _fmt = '%(a)s'
    e1 = TestException(a='a')
    e2 = TestException(a='b')
    e3 = TestException(a='a')
    e4 = TestException('a')
    diff_class = ValueError('a')
    assert e1 == e3
    assert e1 != e2
    assert e1 != e4
    assert e1 != diff_class

# Generated at 2022-06-21 21:47:20.559618
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # This code is shared among several tests, so we just make a few
    # variations to test.
    exc = InvalidPattern('some message')
    # a simple message
    assert str(exc) == ('Invalid pattern(s) found. some message')
    assert unicode(exc) == ('Invalid pattern(s) found. some message')
    # now make it a unicode object.
    exc = InvalidPattern(u'some message')
    assert str(exc) == ('Invalid pattern(s) found. some message')
    assert unicode(exc) == ('Invalid pattern(s) found. some message')
    # now try a non-ascii message
    exc = InvalidPattern(u'\N{SNOWMAN}')
    assert str(exc) == ('Invalid pattern(s) found. %s' % u'\N{SNOWMAN}')

# Generated at 2022-06-21 21:47:29.297637
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib import _dont_write_bytecode
    _dont_write_bytecode.add(test_InvalidPattern___repr__)
    import subprocess # for string comparison
    # To make the test independent of gettext, we use the English
    # exception message.
    message = 'Invalid pattern(s) found. "x*" nothing to repeat at position 0'
    error = InvalidPattern('nothing to repeat at position 0')
    error._fmt = 'Invalid pattern(s) found. "%(pattern)s" %(reason)s'
    error.pattern = 'x*'
    error.reason = 'nothing to repeat at position 0'
    # The message is stored in the attribute _preformatted_string
    assert error._preformatted_string == message

# Generated at 2022-06-21 21:47:36.609462
# Unit test for function finditer_public
def test_finditer_public():
    re.compile = _real_re_compile
    line = u'hello world\n'
    assert isinstance(re.finditer(u'w', line), type(iter([])))

    re.compile = lazy_compile
    pat = re.compile(u'w')
    assert isinstance(pat, LazyRegex)
    assert isinstance(re.finditer(pat, line), type(iter([])))

# Generated at 2022-06-21 21:47:40.303214
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 21:47:47.697682
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex__setstate__ must set the state of the LazyRegex passed in argument."""
    regex = LazyRegex(args=('x',), kwargs={'y':'z'})
    regex.__setstate__({'args':('b',), 'kwargs':{'c':'d'}})
    assert regex._regex_args == ('b',)
    assert regex._regex_kwargs == {'c':'d'}

# Generated at 2022-06-21 21:47:53.880639
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('msg')
    assert e.msg == 'msg'
    assert str(e) == 'Unprintable exception InvalidPattern: dict={\'msg\': \'msg\'}'
    assert repr(e) == 'InvalidPattern(\'msg\')'
    e = InvalidPattern('msg'); e._fmt = 'fmt'
    assert str(e) == 'fmt'
    assert repr(e) == 'InvalidPattern(\'msg\')'

# Generated at 2022-06-21 21:47:59.383264
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # LazyRegex objects should compile when necessary
    object_ = LazyRegex(args=("bzr", ))
    assert isinstance(object_, LazyRegex)
    assert object_._real_regex is None

    # Test that the compilation occurs by accessing a member of the object
    assert object_.pattern == "bzr"
    assert not isinstance(object_._real_regex, LazyRegex)

# Generated at 2022-06-21 21:48:07.671671
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # This test is in this file because InvalidPattern is designed to be
    # imported by other modules like re.py.
    e = InvalidPattern('foo')
    assert e.msg == 'foo'
    assert str(e) == 'Invalid pattern(s) found. foo'
    e2 = InvalidPattern('bar')
    assert str(e2) == 'Invalid pattern(s) found. bar'
    assert e == e
    assert not e == e2


# Test that proxy objects actually lazily compile

# Generated at 2022-06-21 21:48:17.172037
# Unit test for function finditer_public
def test_finditer_public():
    """Test the function finditer_public."""
    from bzrlib.tests import TestCase
    from bzrlib.transport.memory import MemoryServer

    class TestFinditer(TestCase):

        def test_finditer_public_regex(self):
            """Test if the function returns finditer of regex if it receives regex as input."""
            pattern = r'(?P<path>[^:]*):(?P<revid>[^:]*)'
            string = 'foo:bar'
            result = finditer_public(pattern, string)
            self.assertEqual(result, re.finditer(pattern, string))

        def test_finditer_public_lazy(self):
            """Test if the function returns finditer of lazy if it receives lazy as input."""

# Generated at 2022-06-21 21:48:23.042061
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-21 21:48:28.958528
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return the message"""
    msg1 = 'Not enough arguments supplied'
    s = "InvalidPattern('%s')" % msg1
    assert repr(InvalidPattern(msg1)) == s
    msg2 = "Invalid pattern(s) found. 'Not enough arguments supplied'"
    s2 = "InvalidPattern('%s')" % msg2
    assert repr(InvalidPattern(msg2)) == s2

# Generated at 2022-06-21 21:48:39.960884
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test restoring a LazyRegex from a pickled state.

    This test verifies that __setstate__ correctly replaces the LazyRegex
    members with ones restored from the pickled state.
    """
    lazy_regex = LazyRegex(["lazy_compile_test"], {"flags": re.IGNORECASE})
    # Now state should not be None
    assert lazy_regex._real_regex is None
    assert lazy_regex._regex_args == ("lazy_compile_test",)
    assert lazy_regex._regex_kwargs == {"flags": re.IGNORECASE}
    old_args = lazy_regex._regex_args
    old_kwargs = lazy_regex._regex_kwargs
    # We can restore from state and the values are correctly replaced
    lazy_

# Generated at 2022-06-21 21:48:43.300379
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() of InvalidPattern should return a str."""
    e = InvalidPattern('There are some invalid pattern(s).')
    assert isinstance(str(e), str)
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-21 21:48:50.255264
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext

    old_gettext = gettext # Save the old one
    gettext = lambda x: x # Override gettext

    # Call the function to test
    e = InvalidPattern('msg')
    assert(isinstance(e.__unicode__(), unicode))
    assert(e.__unicode__() == 'msg')

    gettext = old_gettext # Restore gettext

# Generated at 2022-06-21 21:49:03.081960
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test for constructor of class LazyRegex"""
    regex_object = LazyRegex()
    assert regex_object._regex_args == () and \
           regex_object._regex_kwargs == {}

    regex_object = LazyRegex(re.compile('foo'))
    assert regex_object._regex_args == ('foo',) and \
           regex_object._regex_kwargs == {}

    regex_object = LazyRegex([re.IGNORECASE, re.LOCALE])
    assert regex_object._regex_args == ([re.IGNORECASE, re.LOCALE], ) and \
           regex_object._regex_kwargs == {}

    regex_object = LazyRegex([re.IGNORECASE, re.LOCALE], re.LOCALE)
    assert regex_object

# Generated at 2022-06-21 21:49:13.469744
# Unit test for function lazy_compile
def test_lazy_compile():
    """The lazy_compile function works as expected"""
    # Regex are not compiled immediately
    regex = lazy_compile('a')
    # Regex are compiled on the first access
    regex.search('a')
    # Regex are not recompiled
    regex.search('a')
    # Regex with errors raise InvalidPattern

# Generated at 2022-06-21 21:49:20.429914
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    regex = LazyRegex(['[a-z]+'], {})
    d = regex.__getstate__()
    regex2 = LazyRegex()
    regex2.__setstate__(d)
    regex2.__getattr__('_real_regex').pattern

# Generated at 2022-06-21 21:49:26.417364
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the method __setstate__ of class LazyRegex
    """
    lr = LazyRegex(('abcd',), {})
    lr.__setstate__({'args': ('1234',), 'kwargs': {}})
    assert lr._real_regex is None
    assert lr._regex_args == ('1234',)
    assert lr._regex_kwargs == {}



# Generated at 2022-06-21 21:49:30.551920
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    import re
    doctest.testmod(re)
    doctest.testmod(re, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 21:49:44.109884
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    def _test(expected_exception, regex1, regex2):
        if expected_exception:
            try:
                regex1 == regex2
            except expected_exception:
                pass
            else:
                raise AssertionError(
                    "Expected InvalidPattern but got None")
        else:
            try:
                regex1 == regex2
            except InvalidPattern:
                raise AssertionError(
                    "Expected None but got InvalidPattern")
    def _test_eq(regex1, regex2):
        _test(None, regex1, regex2)
    def _test_not_eq(regex1, regex2):
        _test(AssertionError, regex1, regex2)

# Generated at 2022-06-21 21:49:51.056247
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string that can be eval'ed to make the same
    exception, e.g.

    InvalidPattern("oops")
    """
    exc = InvalidPattern("oops")
    s = repr(exc)
    exc2 = eval(s)
    eq = exc == exc2
    assert eq, ("InvalidPattern(%r) != %r" % (exc, exc2))

# Generated at 2022-06-21 21:50:02.927169
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()

# Generated at 2022-06-21 21:50:15.443066
# Unit test for function finditer_public
def test_finditer_public():
    import re
    # Check that the public finditer doesn't fail
    # if receives a LazyRegex.
    m = re.finditer('.', 'abc')
    if hasattr(m, 'next'):
        next = m.next
    else:
        next = m.__next__
    next()


# Some libraries calls re.sub which fails it if receives a LazyRegex.
if getattr(re, 'sub', False):
    def sub_public(pattern, repl, string, count=0, flags=0):
        if isinstance(pattern, LazyRegex):
            return pattern.sub(repl, string, count)
        else:
            return _real_re_compile(pattern, flags).sub(repl, string, count)
    re.sub = sub_public


# Generated at 2022-06-21 21:50:20.130674
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    L = LazyRegex()
    L.__setstate__({'args':('\W.*','u'), 'kwargs':{}})
    assert L._regex_args == ('\W.*','u')
    assert L._regex_kwargs == {}



# Generated at 2022-06-21 21:50:23.081307
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-21 21:50:34.939371
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must reset the proxy object"""
    # create a proxy object
    regex = LazyRegex(args=("test",))
    # the proxy object has no attribute args or kwargs
    assert_raises(AttributeError, getattr, regex, '_regex_args')
    assert_raises(AttributeError, getattr, regex, '_regex_kwargs')
    # call __getstate__ on the proxy object
    state = regex.__getstate__()
    # state must equal {"args": ("test",), "kwargs": {}}
    assert state == {"args": ("test",), "kwargs": {}}
    # call __setstate__ on the proxy object with the state
    regex.__setstate__(state)
    # now the proxy object has got attribute args and kwargs
    assert getattr

# Generated at 2022-06-21 21:50:47.905763
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the regex compiled by LazyRegex is the same.

    That the LazyRegex is a weaker version which is the same for simple
    cases and different for the other.
    """
    re_1 = _real_re_compile('a*x')
    re_2 = lazy_compile('a*x')
    assert re_1.pattern == re_2.pattern
    assert re_1.match('a') is None
    assert re_2.match('a') is None
    assert re_1.match('x') is not None
    assert re_2.match('x') is not None
    assert re_1.match('axx') is not None
    assert re_2.match('axx') is not None
    assert re_1.findall('abxabcx') == re_2.findall

# Generated at 2022-06-21 21:50:59.517756
# Unit test for function lazy_compile
def test_lazy_compile():
    """Unit test for function lazy_compile"""
    import gc

    import bzrlib.tests

    def check_lazy_compile(pattern, args, kwargs):
        obj = LazyRegex(args, kwargs)
        # We want to ensure that it doesn't compile until accessed
        gc.collect()
        bzrlib.tests.run_capture_stdout(re.compile, pattern, *args, **kwargs)
        gc.collect()
        # Now actually access the object
        getattr(obj, 'search')
        # And that we don't have more than one regex object
        gc.collect()
        bzrlib.tests.run_capture_stdout(re.compile, pattern, *args, **kwargs)

    # check_lazy_compile('

# Generated at 2022-06-21 21:51:10.422124
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.__init__ import bzrlib_version_string
    from bzrlib.i18n import gettext
    from bzrlib import osutils
    from StringIO import StringIO

    from bzrlib.osutils import get_user_encoding
    from bzrlib.tests import TestCase
    from bzrlib.tests.mock_i18n import mock_gettext
    from bzrlib.transport import get_transport
    from bzrlib.ui import ui_factory


    class TestInvalidPattern(TestCase):
        """Unit test case fot method __str__ of class InvalidPattern"""



# Generated at 2022-06-21 21:51:25.294735
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Encode the unicode message to str

    InvalidPattern.__repr__ must return a str, not a unicode object.
    This tests that __repr__ is encoding the unicode message from __str__ to
    str.
    """
    from bzrlib.i18n import gettext
    # The message below comes from bzrlib.tests.test_wildcard_matcher
    msg = gettext('Missing closing bracket for character class')
    ex = InvalidPattern(msg)

# Generated at 2022-06-21 21:51:31.871098
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public"""
    iter = finditer_public('a\s', 'a b')
    assert iter.next().group(0) == 'a '
    try:
        iter.next()
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-21 21:51:40.330293
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex"""
    proxy = LazyRegex()
    proxy.__setstate__({'args': ('42',), 'kwargs': ('',)})
    proxy._compile_and_collapse()
    try:
        proxy.search('42').group()
    except AttributeError:
        raise AssertionError('A LazyRegex object did not compile correctly.')

# Generated at 2022-06-21 21:51:46.213721
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test LazyRegex.__getstate__()"""
    # Call method
    result = LazyRegex(args=(), kwargs={}).__getstate__()

    # Check what is call
    assert result == {'args': (), 'kwargs': {}}



# Generated at 2022-06-21 21:51:47.838339
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('The pattern is invalid.')
    assert unicode(e) == u'The pattern is invalid.'



# Generated at 2022-06-21 21:51:53.941444
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test if _real_regex is really compiled after calling a method.

    _real_regex is compiled and copied to the class after calling a method
    and we don't need to call _real_regex anymore.
    """
    compile_pattern = 'my_regex'
    lazy_compiled_pattern = LazyRegex((compile_pattern,))
    assert lazy_compiled_pattern.match('') is None
    assert hasattr(lazy_compiled_pattern, 'match')
    assert isinstance(lazy_compiled_pattern.match(''), re.MatchObject)


# Generated at 2022-06-21 21:52:05.776374
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    # Create a LazyRegex
    regex = LazyRegex(args=("hello",))
    # Check that its arguments are set
    assert(regex._regex_args == ("hello",))
    # By default, _real_regex is not compiled
    assert(regex._real_regex is None)
    # Pickle the LazyRegex and restore it
    p = pickle.dumps(regex, 2)
    restore = pickle.loads(p)
    # Same thing as before
    assert(restore._regex_args == ("hello",))
    assert(restore._real_regex is None)
    # Normal matching works
    assert(regex.match('hello')
           is not None)
    # Now that it is compiled, we cannot set its attributes

# Generated at 2022-06-21 21:52:14.360226
# Unit test for function lazy_compile
def test_lazy_compile():
    import os
    import sys
    import pprint
    import pickle
    if sys.version_info[0] == 2 and sys.version_info[1] <= 4:
        import cStringIO
    else:
        import io as cStringIO
    # This is what we're going to override regexs with
    _real_re_compile = re.compile
    re.compile = lambda *args, **kwargs: lazy_compile(*args, **kwargs)
    # This is a slightly modified __builtin__.repr, which will do nice
    # inline formatting
    def r(o):
        if isinstance(o, LazyRegex):
            return 'LazyRegex(%s)' % pprint.pformat((o._regex_args, o._regex_kwargs), width=77)
       

# Generated at 2022-06-21 21:52:17.160260
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern(u'Invalid pattern.')
    except InvalidPattern as e:
        assert e.msg == u'Invalid pattern.'
    else:
        assert 0, 'Empty exception raised.'


# Generated at 2022-06-21 21:52:23.586471
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string that is eval'able to create a copy.
    """
    import re
    try:
        re.compile("(")
    except Exception as e:
        if e.__class__ is not InvalidPattern:
            raise
        s = repr(e)
        if not isinstance(s, str):
            raise TypeError("__repr__ returned %r, which is not a string." % s)
        try:
            eval(s)
        except Exception as e:
            raise AssertionError(
                "eval(%r) raised %r (%s)" % (s, e, type(e).__name__))

# Generated at 2022-06-21 21:52:36.498886
# Unit test for function finditer_public
def test_finditer_public():
    # Test for re.finditer on two different patterns.

    # Only one match
    string = 'test string'
    pattern = r't(\w+)'
    obj_iter = re.finditer(pattern, string)
    obj_finditer_iter = finditer_public(pattern, string)
    assert isinstance(obj_finditer_iter, re.MatchIterator)
    # Test equality between the two iterators
    for obj_iter_item, obj_finditer_iter_item in zip(obj_iter,
                                                     obj_finditer_iter):
        assert obj_iter_item == obj_finditer_iter_item

    # Multiple matches
    string = 'We will test string on multiple patterns'
    pattern = r't(\w+)'
    obj_iter = re.finditer(pattern, string)
    obj_finditer

# Generated at 2022-06-21 21:52:40.714979
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex = LazyRegex(('foo.*',))
    assert regex._real_regex is None
    assert regex._regex_kwargs == {}
    assert regex._regex_args == ('foo.*',)


# Generated at 2022-06-21 21:52:52.040263
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """
    If the LazyRegex has not been compiled, __getattr__ will lead to compile function
    afterward, __getattr__ can get attribute from real_regex
    """
    lazy = LazyRegex(("",))
    assert '_real_regex' in lazy.__dict__ # LazyRegex hasn't been compiled
    # The next call will compile
    lazy.search("")
    assert '_real_regex' not in lazy.__dict__ # LazyRegex has been compiled
    regex = lazy._real_regex
    assert lazy._real_regex == regex  # LazyRegex has been get new attribute


# Generated at 2022-06-21 21:53:02.935068
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return a dictionary of _real_regex and _regex_args.

    _real_regex is used to store the real regex after compiling.
    _regex_args is used to store the original args and kwargs.
    """

    # Create a LazyRegex.
    lazy_regex = LazyRegex(args=('^bzr',), kwargs={})
    state = lazy_regex.__getstate__()

    # Check the values of _real_regex and _regex_args.
    regex_args = state['args']
    regex_kwargs = state['kwargs']
    expected_regex_args = ('^bzr',)
    expected_regex_kwargs = {}
    if regex_args != expected_regex_args:
        raise Assert

# Generated at 2022-06-21 21:53:05.038585
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Unit test for InvalidPattern"""
    msg = 'msg'
    ip = InvalidPattern(msg)
    assert(ip.msg == msg)
    assert(str(ip) == 'Invalid pattern(s) found. msg')

# Generated at 2022-06-21 21:53:13.743224
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__() returns the expected value."""
    # Testcase: a LazyRegex object is created with the args and kwargs required
    # for re.compile().
    proxy = LazyRegex(("aBc",), {"flags": re.IGNORECASE})
    expected = {
        "args": ("aBc",),
        "kwargs": {"flags": re.IGNORECASE},
        }
    # Testcase: __getstate__ returns the expected value.
    actual = proxy.__getstate__()
    assert expected == actual

# Generated at 2022-06-21 21:53:25.358525
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for InvalidPattern.__str__()

    It should:
    * return a 'str' object, not a 'unicode' object.
    * convert a unicode format string to a byte string using
      the default encoding.
    """
    # set the exception format string to a unicode string
    InvalidPattern._fmt = unicode('for %(msg)s')

# Generated at 2022-06-21 21:53:31.807712
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile should actually reset re.compile to _real_re_compile

    This test also tests that re.compile is not already lazy_compile
    because if it is, the test is meaningless.
    """
    install_lazy_compile()
    if re.compile == lazy_compile:
        pass
    else:
        raise AssertionError("re.compile is not lazy_compile")
    reset_compile()
    if re.compile == _real_re_compile:
        pass
    else:
        raise AssertionError("re.compile is not _real_re_compile")



# Generated at 2022-06-21 21:53:42.748791
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method __getattr__ of the class LazyRegex in the module
    re_proxy.py.
    """

    lr = LazyRegex(args=('foo'))
    lr_real_regex = lr._real_regex

    try:
        # Test that the _compile_and_collapse method is called when the object
        # lr is used.
        _l = lr_real_regex.__class__
        _d = 'This attribute is not defined in the class ProxyRegex.'
        # pylint: disable=no-member
        raise AssertionError(_d)
    except AttributeError:
        pass

    # Test if the real object is retrieved when the attribute is accessed the
    # first time.
    _l = lr.__copy__

# Generated at 2022-06-21 21:53:51.196333
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib.i18n import gettext
    # when we don't pass _fmt to the constructor
    e = InvalidPattern(u'Missing _fmt')
    assert str(e) == 'Missing _fmt'
    assert e._get_format_string() is None

    # when we pass _fmt to the constructor, this is used to format the
    # exception
    e = InvalidPattern(u'Missing _fmt again')
    e._fmt = '%(msg)s'
    assert str(e) == 'Missing _fmt again'
    assert e._get_format_string() is None

    # when we pass _fmt to the constructor and we have a translatable string,
    # this is used to format the exception
    e = InvalidPattern(u'Missing _fmt again')
    e._fmt

# Generated at 2022-06-21 21:54:07.902699
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern.

    Testing by comparing the result string with a pre-defined string.

    This test requires a local encoding that supports non-ascii characters.
    If a local encoding is not available, the test is skipped.
    """
    try:
        unicode("\u00e9")
    except UnicodeError:
        # Test skipped because the locale encoding is not available
        return

    # string given as argument
    e = InvalidPattern("Unicode \u00e9")
    s = unicode(e)
    if not (s == "Unicode \u00e9"):
        raise AssertionError("Invalid string")
    # string given in the class attribute _fmt
    e = InvalidPattern("")
    e._fmt = "Unicode \u00e9"


# Generated at 2022-06-21 21:54:14.292995
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a Unicode object

    For example, we might use this exception in a try/except block
    """
    exception = InvalidPattern("Foo")

# Generated at 2022-06-21 21:54:24.083618
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test __repr__ method.

    __repr__ builds a string with the class name and attributes, formatted
    as a call to the class constructor.

    The method is called by repr() function.
    """
    # Test when __str__ is implemented by InvalidPattern
    ip = InvalidPattern('msg')
    ip._fmt = 'format string'
    assert repr(ip) == "InvalidPattern(format string)"

    # Test when __str__ is not implemented by InvalidPattern, but by its
    # parent class.
    class MyException(Exception):
        """Sample exception class."""
        def __init__(self, attr):
            """Constructor."""
            self.attr = attr

        def __str__(self):
            """Return string representation.

            __str__ returns the attribute.
            """

# Generated at 2022-06-21 21:54:26.440999
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for correct state when pickling LazyRegex."""
    values = ["abc", "def"]
    lazy_regex = LazyRegex(values)
    state = lazy_regex.__getstate__()
    assert state == {'args': (values[0],), 'kwargs': {'flags': 0}}

# Generated at 2022-06-21 21:54:33.795312
# Unit test for function lazy_compile
def test_lazy_compile():
    from bzrlib import tests
    import re
    import types

    class TestLazyRegex(tests.TestCase):

        def test_lazy_regex_match(self):
            pattern = '.*'
            target = 'this is a test'
            regex = lazy_compile(pattern)
            self.assertEqual(pattern, regex.pattern)
            self.assertEqual(target, regex.match(target).group())

        def test_no_double_compilation(self):
            pattern = '.*'
            target = 'this is a test'
            regex = lazy_compile(pattern)
            self.assertIsInstance(regex, types.InstanceType)
            regex.match(target)
            self.assertIsInstance(regex, types.MethodType)


# Generated at 2022-06-21 21:54:38.205289
# Unit test for function reset_compile
def test_reset_compile():
    # reset_compile shouldn't break in this case
    reset_compile()
    # reset_compile should revert a previous install_lazy_compile() call
    install_lazy_compile()
    reset_compile()



# Generated at 2022-06-21 21:54:48.203406
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.tests import TestCase

    class Test(TestCase):
        def test_InvalidPattern___unicode__(self):
            """InvalidPattern.__unicode__ should return a unicode string."""
            # unicode string.
            e = InvalidPattern(u'test_InvalidPattern___unicode__')
            self.assertIsInstance(unicode(e), unicode)
            # byte string in ascii encoding.
            e = InvalidPattern(u'string in ascii encoding')
            self.assertIsInstance(unicode(e), unicode)
            # byte string in ascii encoding.
            e = InvalidPattern(u'\u0421\u0442\u0440\u043e\u043a\u0430')
            self.assertIsInstance(unicode(e), unicode)

# Generated at 2022-06-21 21:54:54.901181
# Unit test for function lazy_compile
def test_lazy_compile():
    from cStringIO import StringIO
    from bzrlib.tests.blackbox import test_case

    out = StringIO()

    class ReLazyTests(test_case.ExternalBase):

        def test_lazy_compile(self):
            out = StringIO()
            install_lazy_compile()
            self.build_tree_contents([('a', 'foo\n')])

            # Check that it works with an exact param list
            re_exp = re.compile('foo', 0)
            re_proxy = re.compile('foo', 0)
            self.assertEqual(type(re_exp), type(re_proxy))

            # Check that it works with a named param list
            re_exp = re.compile(pattern='foo', flags=0)
            re_proxy = re.comp

# Generated at 2022-06-21 21:55:00.355932
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex."""
    obj = LazyRegex()
    state = obj.__getstate__()
    assert state["args"] == ()
    assert state["kwargs"] == {}
    assert isinstance(state, dict)
    assert len(state) == 2

# Generated at 2022-06-21 21:55:11.388391
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Ensure that InvalidPattern.__eq__ compares the same as a normal
    Exception.__eq__.
    """
    def test_eq_method(a, b):
        """Compare a's __eq__ method to b's __cmp__ method.

        :param a: an exception object that supports __eq__ and __cmp__
        :param b: an exception object that supports __eq__ and __cmp__
        :return: a tuple of the results of comparing a's __eq__ and __cmp__ to
            b's __eq__ and __cmp__
        """
        if a.__eq__(b) != a.__cmp__(b) == 0:
            return a.__class__.__name__, a, b, '__eq__ and __cmp__ not same'

# Generated at 2022-06-21 21:55:20.977314
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of InvalidPattern

    Need to call str() on the exception to get the right formatting. This is
    because the formatting is being done in the __str__ method.
    """
    e = InvalidPattern(u'abc')
    str(e) # just check that str doesn't blow up.
    assert str(e) == 'Invalid pattern(s) found. abc'

# Generated at 2022-06-21 21:55:32.566324
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Return the string representation of an InvalidPattern error

    This unit test the following features:
    * the representation is the error message in ascii
    * the message can be formatted
    * the error message is also unicode
    * the error message can also be unicode formatted
    """
    # Test without formatting
    error_str = str(InvalidPattern('msg'))
    error_unicode = unicode(InvalidPattern('msg'))
    assert isinstance(error_str, str), \
        '__str__ should return a str object'
    assert isinstance(error_unicode, unicode), \
        '__unicode__ should return a unicode object'
    assert error_str == error_unicode, \
        '__str__ and __unicode__ should return the same object'

# Generated at 2022-06-21 21:55:39.660338
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test the __str__ method of the InvalidPattern class."""
    error_message = 'Invalid pattern exception.'
    for e in InvalidPattern(error_message), unicode(InvalidPattern(error_message)):
        # Calling str() on an invalid pattern object.
        str(e)
        # Calling unicode() on an invalid pattern object.
        unicode(e)
        # Calling repr() on an invalid pattern object.
        repr(e)
        # Test the __eq__ method of the InvalidPattern class.
        assert e == InvalidPattern(error_message)

# Generated at 2022-06-21 21:55:44.862560
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    pattern = b'^[a-z]{4}$'
    lazy_regex = LazyRegex((pattern, 0))
    assert lazy_regex._real_regex is None
    assert lazy_regex._regex_args == (pattern, 0)
    assert lazy_regex._regex_kwargs == {}


# Generated at 2022-06-21 21:55:47.623707
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    proxy = LazyRegex(('[0-9]',), {'flags': re.IGNORECASE})
    assert proxy._regex_args == ('[0-9]',)
    assert proxy._regex_kwargs == {'flags': re.IGNORECASE}
    assert proxy._real_regex is None
    return proxy



# Generated at 2022-06-21 21:55:58.825460
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests method __str__ of class InvalidPattern"""
    import re
    import bzrlib.trace
    bzrlib.trace.enable_default_logging()
    bzrlib.trace.mutter('test')
    e = InvalidPattern('test')
    assert str(e) == 'test'
    bzrlib.trace.mutter('test %s %d', 'a', 1)
    e = InvalidPattern('test %s %d')
    assert str(e) == 'test %s %d'
    bzrlib.trace.mutter('test %s %d', 'a', 'b')
    e = InvalidPattern('test %s %d')
    assert str(e) == 'test %s %d'
    assert e._format() == 'test a b'

# Generated at 2022-06-21 21:56:08.801647
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    reg1 = LazyRegex(('\n'),{})
    try:
        reg1 = LazyRegex(('\a'),{})
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. "\\x07" '\
                         'unexpected end of regular expression', \
                         'Unexpected exception raised. Got: %s' % str(e)
    else:
        raise AssertionError('LazyRegex did not raise expected exception')


# Test that LazyRegex works by calling re.compile(), which should return
# the LazyRegex.

# Generated at 2022-06-21 21:56:11.326185
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():

    #create an invalidpattern object
    test_object = InvalidPattern("Invalid pattern")

    #__repr__ function always returns string representation of an object
    #when we use eval then it returns the same object
    assert eval(repr(test_object)) == test_object


# Generated at 2022-06-21 21:56:15.921759
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase

    class TestCaseInInvalidPattern(TestCase):

        def test_InvalidPattern___str__(self):
            e = InvalidPattern('Invalid regular expression.')
            self.assertEqualDiff('Invalid regular expression.\n', str(e))

# Generated at 2022-06-21 21:56:18.408928
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile should work even called repeatedly."""
    reset_compile()
    reset_compile()



# Generated at 2022-06-21 21:56:33.032580
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for method __getstate__ of class LazyRegex
    """
    lr = LazyRegex()
    res = lr.__getstate__()
    assert res == {
        "args": (),
        "kwargs": {},
        }



# Generated at 2022-06-21 21:56:39.596143
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() returns a dictionary of members to store in pickled state

    The dictionary returned by __getstate__() should contain all of
    the members necessary to restore the proxy object.
    """
    regex = LazyRegex(['foo'], {'bar':'baz'})
    state = regex.__getstate__()
    # Check the contents of the state
    assert state == { 'args': ['foo'], 'kwargs': {'bar': 'baz'} }



# Generated at 2022-06-21 21:56:42.237730
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern.
    """
    ip = InvalidPattern("test")
    assert unicode(ip) == u"test"

# Generated at 2022-06-21 21:56:50.786491
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Check if LazyRegex correctly evaluates __setstate__ method.

    This test is needed to check that unpickled LazyRegex object resulted
    from previous run.
    """
    regex = LazyRegex(('[a-z]',))
    assert regex._real_regex == None
    state = regex.__getstate__()
    new_regex = LazyRegex()
    new_regex.__setstate__(state)
    # new_regex is not a LazyRegex after restore
    assert new_regex._real_regex != None