

# Generated at 2022-06-21 21:47:10.433537
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public."""
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import SymlinkFeature

    class TestFinditerPublic(TestCase):
        _test_needs_features = [SymlinkFeature]

        def test_finditer_public(self):
            self.assertRaises(AttributeError,
                              lazy_compile.finditer, None, '')
            self.assertRaises(AttributeError,
                              lazy_compile.finditer, '', None)

    import unittest
    suite = unittest.makeSuite(TestFinditerPublic)
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-21 21:47:21.022848
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestCase
    class DummyClass(object):
        pass
    class TestResetCompile(TestCase):
        def setUp(self):
            # Store original compile
            self._real_re_compile = re.compile

        def test_reset_compile(self):
            """Test reset_compile() restore original compile function"""
            re.compile = DummyClass
            self.assertTrue(re.compile is DummyClass)
            reset_compile()
            self.assertFalse(re.compile is DummyClass)
            self.assertTrue(re.compile is self._real_re_compile)
            # Reset again, nothing should change
            old_compile = re.compile
            reset_compile()

# Generated at 2022-06-21 21:47:27.542717
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # Test that re.compile has been overridden by lazy_compile.
    re = __import__('re')
    if re.compile is not lazy_compile:
        raise ValueError("re.compile not overridden by lazy_compile")

    # Test that original function re.compile is available as
    # _real_re_compile.
    if re.compile is not _real_re_compile:
        raise ValueError("re.compile is not available as _real_re_compile")



# Generated at 2022-06-21 21:47:39.988889
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern.

    This test checks that the method __unicode__ of class InvalidPattern
    returns a unicode object. It also checks that it returns a string
    decoded using the default encoding if the format string is a str.
    """
    p = InvalidPattern('foo bar')
    u = p.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'foo bar'

    # Test the case where we try to format the string
    class UnicodeFormat(InvalidPattern):
        _fmt = u'foo bar baz %(msg)s'

    p = UnicodeFormat('foo')
    p._preformatted_string = unicode('foo bar baz foo')
    u = p.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-21 21:47:41.948888
# Unit test for function reset_compile
def test_reset_compile():
    # Should avoid infinite recursion
    install_lazy_compile()
    reset_compile()



# Generated at 2022-06-21 21:47:53.305894
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests for InvalidPattern.__str__ method.

    Sometimes InvalidPattern.__str__ fails if _get_format_string
    or _format method or some others return something that InvalidPattern
    can't convert to unicode object. It failed for example with following
    message:

      UnicodeEncodeError: 'ascii' codec can't encode character u'\u0422'
      in position 0: ordinal not in range(128)

    This test illustrates this case.
    """
    # Create instance of class InvalidPattern.
    instance = InvalidPattern('test')
    # Override _format method
    def _format():
        return u'\u0422'
    setattr(instance, '_format', _format)
    # This call should not fail.
    str(instance)

# Generated at 2022-06-21 21:47:58.279104
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should always return a 'str' object"""
    py_str = 'Unprintable exception InvalidPattern: dict={}, fmt=Invalid pattern(s) found. %(msg)s, error=None'
    exc = InvalidPattern('msg')
    out_str = str(exc)
    assert isinstance(out_str, str)
    assert py_str == out_str



# Generated at 2022-06-21 21:48:02.517064
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() should return a str"""
    try:
        raise InvalidPattern("foo")
    except InvalidPattern as e:
        assert isinstance(e.__str__(), str) # Relying on exception propagation.

# Generated at 2022-06-21 21:48:14.203287
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Method __setstate__ of class LazyRegex must properly restore the state
    of object after unpickling it.
    """
    import pickle
    pattern = r'[a-z]'
    args = (pattern, )
    kwargs = {'flags': re.I}
    lazy_regex = LazyRegex(args, kwargs)
    lazy_regex._compile_and_collapse()
    new_lazy_regex = pickle.loads(pickle.dumps(lazy_regex))
    if new_lazy_regex._real_regex:
        raise AssertionError("Unpickled regex object "
            "must be no compiled.\n")

    real_re_compile_1 = new_lazy_regex._real_re_compile
    new_

# Generated at 2022-06-21 21:48:26.190565
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from unittest import TestCase

    class Test___str__(TestCase):

        def test__preformatted_string(self):
            exc = InvalidPattern(None)
            exc._preformatted_string = "preformatted message"
            self.assertEqual(str(exc), 'preformatted message')

        def test__get_format_string(self):
            exc = InvalidPattern(None)
            exc._get_format_string = lambda: "formatted message"
            self.assertEqual(str(exc), 'formatted message')

        def test_NA(self):
            exc = InvalidPattern(None)
            self.assertEqual(str(exc),
                "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None")

    Test___str__('test__preformatted_string').test__

# Generated at 2022-06-21 21:48:39.505799
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("reset_compile has not reset re.compile")


# Generated at 2022-06-21 21:48:43.054953
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase

    class TestInvalidPattern(TestCase):

        def test___eq__(self):
            self.assertFalse(InvalidPattern('a') == 1)
            self.assertFalse(InvalidPattern('a') == InvalidPattern('b'))
            self.assertTrue(InvalidPattern('a') == InvalidPattern('a'))

# Generated at 2022-06-21 21:48:52.373272
# Unit test for function finditer_public
def test_finditer_public():
    # Get a compiled re
    f = re.finditer(r'.*', 'foo')
    # Ensure it is a class that does not call our finditer_public
    dummy_class = type(f)
    # Our LazyRegex has been set to a dummy class because we are not in a
    # bzrlib.tests.
    LazyRegex.finditer = finditer_public
    l = LazyRegex(('.',))
    l.__class__ = dummy_class
    try:
        finditer_public(l, '')
    finally:
        # Restore the original finditer_public
        LazyRegex.finditer = finditer_public

# Generated at 2022-06-21 21:49:00.064196
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ must return a str, not unicode."""
    # The exception InvalidPattern set a '_preformatted_string' attribute,
    # so the __repr__ method will return a str object.
    e = InvalidPattern('some message')
    e._preformatted_string = 'preformatted message'
    assert isinstance(e.__repr__(), str)


# Unit tests for method __repr__ of class LazyRegex

# Generated at 2022-06-21 21:49:05.532933
# Unit test for function lazy_compile
def test_lazy_compile():
    # This test must not be installed in the global namespace
    # to meet the pre-condition for install_lazy_compile
    install_lazy_compile()
    reset_compile()
    import re
    if re.compile is not _real_re_compile:
        raise AssertionError(
            "re.compile should be _real_re_compile, but is %r" % re.compile())

# Generated at 2022-06-21 21:49:15.535847
# Unit test for function lazy_compile
def test_lazy_compile():
    import pickle
    global re
    _real_re_compile = re.compile
    re.compile = lazy_compile
    try:
        c = re.compile("(a*)*")
        d = pickle.dumps(c)
        c2 = pickle.loads(d)
    finally:
        re.compile = _real_re_compile
    for r in (c, c2):
        assert isinstance(r, LazyRegex)
        assert re.match("a", "a", r)
        assert re.search("a", "a", r)
        assert re.split("a", "a", r) == ['', '']

# Generated at 2022-06-21 21:49:23.828947
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lr = LazyRegex()
    lr.__setstate__({
        "args": ('a|b', ),
        "kwargs": {
            'foo': 'bar',
            },
        })
    lr.__getattr__('match')
    assert lr._real_regex.pattern == 'a|b', lr._real_regex.pattern

# Generated at 2022-06-21 21:49:26.510063
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of LazyRegex."""
    import doctest
    import bzrlib.lazy_regex
    return doctest.DocTestSuite(bzrlib.lazy_regex)

# Generated at 2022-06-21 21:49:31.609785
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('a message')
    assert e.msg == 'a message'
    assert e.__str__() == 'a message'
    assert e.__repr__() == 'InvalidPattern(a message)'



# Generated at 2022-06-21 21:49:35.068405
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert re.compile is lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-21 21:49:43.356631
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    doctest.testmod(verbose=False)
    return

# Generated at 2022-06-21 21:49:48.873038
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests import TestCase
    install_lazy_compile()
    try:
        # The proxy object has not been compiled yet, so should return None
        self.assertEqual(None, re.compile('foo').pattern)
    finally:
        reset_compile()



# Generated at 2022-06-21 21:50:00.192943
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex = re.compile('abc', 0)
    l = LazyRegex(('abc', 0))
    assert not l._real_regex
    assert l._regex_args == ('abc', 0)
    assert l._regex_kwargs == {}
    assert l.__getattr__('pattern') == 'abc'
    assert l.__getattr__('pattern') == 'abc'
    assert l._real_regex == regex
    for attr in LazyRegex._regex_attributes_to_copy:
        assert getattr(l, attr) == getattr(regex, attr)

    # We now have the same attributes as a normal compiled regex
    assert l.__dict__ == regex.__dict__



# Generated at 2022-06-21 21:50:03.489081
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    class TestException(InvalidPattern):
        _fmt = 'Test exception'

    e = TestException(None)
    import pdb;pdb.set_trace()
    assert str(e) == 'Test exception'



# Generated at 2022-06-21 21:50:15.864290
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    import os
    import sys
    # setup simple gettext with 'bzr' as domain
    gettext.install(domain='bzr', localedir=os.path.join('..', 'locale'))
    # change locale to 'en_GB'
    import locale
    locale.setlocale(locale.LC_ALL, 'en_GB')
    msg = '"foo*" nothing to repeat'
    e = InvalidPattern(msg)
    u = gettext("Invalid pattern(s) found. %(msg)s") % {
        'msg': msg}
    # check if __unicode__ works for utf-8
    assert str(e) == u.encode('utf-8')
    # check if __unicode__ works for unicode
   

# Generated at 2022-06-21 21:50:22.917701
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lr = LazyRegex(r'^bzr\+ssh://')
    lr_dict = lr.__getstate__()
    del lr
    lr = LazyRegex()
    lr.__setstate__(lr_dict)
    # Compile and access the lazy regex to check that __setstate__ worked
    isinstance(lr.match('bzr+ssh://'), type(None))

# Generated at 2022-06-21 21:50:34.810454
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Make sure that preformatted input works
    msg = InvalidPattern('This is a test')
    msg._preformatted_string = "preformatted unicode"
    msg.some_data = "this is some data"
    msg.other_data = "this is more data"
    assert str(msg) == "preformatted unicode"

    # Make sure that a valid format string works
    msg = InvalidPattern('This is a test')
    msg._fmt = "%(some_data)s %(other_data)s"
    msg.some_data = "this is some data"
    msg.other_data = "this is more data"
    assert str(msg) == "this is some data this is more data"

    # Make sure that exceptions are caught
    msg = InvalidPattern('This is a test')
    msg._f

# Generated at 2022-06-21 21:50:38.266021
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    exc = InvalidPattern(u"unicode message")
    exc2 = InvalidPattern(u"unicode message")
    exc3 = InvalidPattern(u"unicode message2")
    exc4 = ValueError(u"unicode message")
    assert exc == exc2
    assert exc != exc3
    assert exc != exc4

# Generated at 2022-06-21 21:50:50.485211
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.i18n import set_output_encoding
    from cStringIO import StringIO
    out = StringIO()
    set_output_encoding('utf-8')
    e1 = InvalidPattern('foo')
    e2 = InvalidPattern(u'foo\u1234')
    # e1.__repr__() should always return a str object
    assert isinstance(e1.__repr__(), str)
    assert e1.__repr__() == "InvalidPattern('foo')"
    # e2.__repr__() should always return a str object
    assert isinstance(e2.__repr__(), str)
    assert e2.__repr__() == "InvalidPattern('foo\\xe1\\x88\\xb4')"
    # e1.__unicode__() should always return

# Generated at 2022-06-21 21:51:01.118342
# Unit test for function finditer_public
def test_finditer_public():
    """Test that finditer() calls re.finditer() to get an iterator.

    But when re.finditer() is not present, finditer() itself is the
    iterator.
    """
    class String(object):
        def __init__(self, test_instance, string):
            self.test_instance = test_instance
            self.string = string
        def __iter__(self):
            self.test_instance.assertEqual('this is a test string', self.string)
            yield 'ok'

    def finditer_private(pattern, string, flags=0):
        return String(self, string)


# Generated at 2022-06-21 21:51:11.713043
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ method of class LazyRegex"""
    lr = LazyRegex((), {})
    d = lr.__getstate__()
    # I expected this :
    #     d == {
    #         'args': (),
    #         'kwargs': {}
    #     }
    # but this is what I got
    assert 'args' in d
    assert 'kwargs' in d

# Generated at 2022-06-21 21:51:24.343304
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() with no message should return canonically formatted string"""
    from bzrlib.i18n import gettext
    ip = InvalidPattern(None)
    # The following is the message when the string is formatted for the
    # system locale
    expected_msg = gettext('Invalid pattern(s) found. %(msg)s')
    msg = str(ip)
    assert expected_msg % {'msg': ''} == msg, (msg, expected_msg)

    # Checke Unicode conversion
    unicode_msg = unicode(ip)
    assert isinstance(unicode_msg, unicode)
    assert unicode_msg == unicode(msg)

    # Check that formatting with non-ascii characters works, and encodes the
    # final string correctly.

# Generated at 2022-06-21 21:51:26.744287
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = "foo"
    my_exception = InvalidPattern(msg)
    assert msg in str(my_exception)

# Generated at 2022-06-21 21:51:28.285103
# Unit test for function lazy_compile

# Generated at 2022-06-21 21:51:39.505721
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from bzrlib.tests import TestCase
    import pickle
    test_case = TestCase()
    r = LazyRegex(('(a|b)*c', 8))
    # change the state of r with method __setstate__
    r.__setstate__(dict(args=('aaabbbbccc', 5), kwargs={'xxx':'yyy'}))
    test_case.assertEqual(r._regex_args, ('aaabbbbccc', 5))
    test_case.assertEqual(r._regex_kwargs, {'xxx':'yyy'})
    # the original method __setstate__ should be fine with pickle
    p = pickle.dumps(r)
    r.__setstate__(pickle.loads(p))
    test_case.assertEqual

# Generated at 2022-06-21 21:51:49.726592
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex"""
    lazy_regex = LazyRegex(args=('a',), kwargs={'flags': 8})
    # Set state to an empty dictionary
    state = {}
    lazy_regex.__setstate__(state)
    # Check if state of the instance is set correctly
    assert (getattr(lazy_regex, '_regex_args') == (),
            getattr(lazy_regex, '_regex_kwargs') == {})

# Generated at 2022-06-21 21:52:00.742361
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ of LazyRegex class."""
    from cStringIO import StringIO
    from bzrlib import tests
    from bzrlib.tests import (
        TestCase,
        )
    from bzrlib.regex import LazyRegex

    class TestLazyRegex__setstate__(TestCase):
        """__setstate__ of LazyRegex class."""

        def test__setstate__(self):
            """test__setstate__ - pickle the LazyRegex"""
            lz = LazyRegex(['[a-z]+'])
            buf = StringIO()
            lz.__setstate__('foobar')
            self.assertEqual(lz._real_regex, None)

# Generated at 2022-06-21 21:52:12.783725
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # This test makes sure that str and unicode are implemented
    # as expected.
    # It also makes sure that a unicode message is translated
    # in the worst cases:
    #    - the message contains a unicode string
    #    - the message contains a non-ascii string
    #    - the message contains an object which does not have
    #      the __str__ method implemented

    # the message contains a unicode string
    msg = u"\xe9"
    e = InvalidPattern(msg)
    # e.msg is a unicode string
    assert isinstance(e.msg, unicode)
    # all these calls must return a "str" object
    assert type(str(e)) is str
    assert type(unicode(e)) is unicode
    assert type(repr(e)) is str
    # the unic

# Generated at 2022-06-21 21:52:20.625987
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should always return a str object, never a unicode object"""
    # setup
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'Has a Unicode string: %(msg)s'

    # test
    exc = MyInvalidPattern('msg')
    str_exc = str(exc)

    # check
    assert isinstance(str_exc, str), "__str__ didn't return a str object"

    # teardown (none)


# Generated at 2022-06-21 21:52:33.486733
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    class Test(LazyRegex):
        def __init__(self, args, kwargs):
            self._regex_args = args
            self._regex_kwargs = kwargs

        def _real_re_compile(self, *args, **kwargs):
            return (_real_re_compile(self._regex_args, self._regex_kwargs),)

    def _test(search_string, compile_string):
        regex = Test(compile_string, {})
        res = regex.search(search_string)
        return res is not None

    # XXX: Maybe we should test more than one case?
    # This is the same test as in test_regex.py
    assert _test("foo", "[f]oo")

install_lazy_compile()

# Generated at 2022-06-21 21:52:43.123294
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    test_regex = LazyRegex('a')
    # Before accessing real_regex, test_regex._real_regex is None
    test_regex.__getattr__('match')
    # After __getattr__ is called, test_regex._real_regex is not None
    assert test_regex._real_regex is not None


# Generated at 2022-06-21 21:52:48.248172
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re_orig = re.compile
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
    finally:
        reset_compile()
        assert re_orig is re.compile

# Generated at 2022-06-21 21:52:57.064599
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for the function finditer_public."""
    from bzrlib.tests import TestCase
    match = re.search("foo", "foo")
    assert isinstance(match, re._sre.SRE_Match)
    match = re.search("foo", "bar")
    assert match is None
    install_lazy_compile()
    match = re.search("foo", "foo")
    assert isinstance(match, LazyRegex)
    match = re.search("foo", "bar")
    assert match is None
    reset_compile()

if __name__ == '__main__':
    test_finditer_public()

# Generated at 2022-06-21 21:53:09.268300
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import bzrlib.tests
    r = re.compile('pattern')
    r_l = re.compile('pattern')
    r_a = ["__copy__", "__deepcopy__", "findall", "finditer", "match",
    "scanner", "search", "split", "sub", "subn", "_real_regex", "_regex_args",
    "_regex_kwargs"]
    for a in r_a:
        bzrlib.tests.TestCase.assertIs(getattr(r, a), getattr(r_l, a))
    bzrlib.tests.TestCase.assertIs(r.__copy__, r_l.__copy__)

# Generated at 2022-06-21 21:53:12.156766
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('no patterns found')
    except InvalidPattern as e:
        return e.msg == 'no patterns found'
    return False # should never get here

# Generated at 2022-06-21 21:53:20.059256
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test that LazyRegex.__getstate__ returns the values of _regex_args and
    _regex_kwargs.
    """
    from bzrlib.tests import TestCase
    from pickle import dumps
    lazy_regex = LazyRegex(("hello"), {"flags":re.IGNORECASE})
    expected_state = {"args":("hello"), "kwargs":{"flags":re.IGNORECASE}}
    self.assertEqual(expected_state, lazy_regex.__getstate__())



# Generated at 2022-06-21 21:53:25.926284
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import bzrlib.osutils
    if bzrlib.osutils.is_unicode_filename_supported():
        expected = u'Invalid pattern(s) found. "a" nothing to repeat'
    else:
        expected = u'Invalid pattern(s) found. "a" nothing to repeat'
    e = InvalidPattern('"a" nothing to repeat')
    assert str(e) == expected

# Generated at 2022-06-21 21:53:30.618624
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile() returns the original re.compile() implementation.
    """

    def always_raise_error(*args, **kwargs):
        raise AssertionError("re.compile was not reset")

    re.compile = always_raise_error
    try:
        reset_compile()
    finally:
        # Restore the original re.compile()
        re.compile = _real_re_compile

# Generated at 2022-06-21 21:53:36.549270
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ for InvalidPattern"""
    ex1 = InvalidPattern('msg1')
    ex2 = InvalidPattern('msg1')
    ex3 = InvalidPattern('msg2')
    ex4 = ValueError('msg1')
    assert(ex1 == ex2)
    assert(ex1 != ex3)
    assert(ex1 != ex4)

# Generated at 2022-06-21 21:53:41.594575
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ip = InvalidPattern('test')
    assert ip.msg == 'test'
    assert isinstance(ip, ValueError)
    try:
        raise ip
    except InvalidPattern as ip2:
        assert ip2.msg == 'test'


__all__ = ['LazyRegex', 'lazy_compile', 'install_lazy_compile',
           'reset_compile']

# Generated at 2022-06-21 21:53:54.965959
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that we can override the default regex compile method.

    This emulates the use cases in bzrlib's regex_needs_lazy_compile function,
    and checks the results are the same.
    """
    install_lazy_compile()
    # Make sure we get a LazyRegex from a standard compile call
    assert isinstance(re.compile('foo'), LazyRegex)
    # With no flags we should have the same result
    assert re.compile('foo').pattern == 'foo'
    assert re.compile('foo').flags == 0
    # But with a flag we should be different
    assert re.compile('foo', re.IGNORECASE).pattern == 'foo'
    assert re.compile('foo', re.IGNORECASE).flags == re.IGNORECASE
    # Now add

# Generated at 2022-06-21 21:54:04.544683
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Tests for the constructor of class LazyRegex.

    The constructor LazyRegex(args, kwargs) sets both args and kwargs
    as instance variables.  The set instance variables can be accessed
    and compared with the given args and kwargs.

    """
    args = "abc"
    kwargs = { 'flags': re.IGNORECASE }
    rx = LazyRegex(args, kwargs)
    assert rx._regex_args == args, rx._regex_args
    assert rx._regex_kwargs == kwargs, rx._regex_kwargs


# Generated at 2022-06-21 21:54:06.656795
# Unit test for function finditer_public
def test_finditer_public():
    from breezy.tests import test_regex

    test_regex.finditer_public_test()

# Generated at 2022-06-21 21:54:08.908722
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = LazyRegex()
    for i in r._regex_attributes_to_copy:
        getattr(r, i)

# Generated at 2022-06-21 21:54:16.844085
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    try:
        if re.compile is not _real_re_compile:
            raise AssertionError("re.compile() was not restored")
        reset_compile()
        if re.compile is not _real_re_compile:
            raise AssertionError("double call to reset_compile()")
    finally:
        reset_compile()


# Generated at 2022-06-21 21:54:28.357779
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the method __unicode__ of class InvalidPattern"""
    # Preformatted message
    obj = InvalidPattern('')
    obj._preformatted_string = u'preformatted message'
    assert unicode(obj) == u'preformatted message', repr(unicode(obj))
    try:
        obj = InvalidPattern()
    except TypeError:
        # This causes a TypeError which we just want to catch and ignore
        pass
    else:
        assert False, \
               "InvalidPattern.__unicode__ accepts less then one argument"
    # Format string
    obj = InvalidPattern('default message')
    assert unicode(obj) == u'default message', repr(unicode(obj))
    obj = InvalidPattern('')
    msg = u'default message'
    obj._fmt = msg

# Generated at 2022-06-21 21:54:38.922949
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # inherited object error
    msg = "Please use bzrlib.errors.InvalidPattern instead."
    e = ValueError(msg)
    invalid_pattern = InvalidPattern(e)
    # __str__() should always return a 'str' object
    # never a 'unicode' object.
    assert isinstance(str(invalid_pattern), str)
    assert str(invalid_pattern) == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=%s' % msg
    assert isinstance(unicode(invalid_pattern), unicode)
    assert unicode(invalid_pattern) == u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=%s' % msg

# Generated at 2022-06-21 21:54:43.928990
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """See bug #131249"""
    msg = 'Bad pattern'
    exception = InvalidPattern(msg)
    assert exception.msg == msg
    assert str(exception) == msg
    assert unicode(exception) == msg.decode('utf-8')
    assert repr(exception) == "InvalidPattern('Bad pattern')"

# Generated at 2022-06-21 21:54:48.364118
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test if install_lazy_compile() works"""
    global _real_re_compile
    original_re_compile = _real_re_compile
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
    finally:
        _real_re_compile = original_re_compile
        reset_compile()

# Generated at 2022-06-21 21:54:54.988154
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern.

    The method __repr__ should return the string "InvalidPattern(<msg>)",
    where msg is the formatted version of the message of the exception.
    """
    # We can't test "Unprintable exception InvalidPattern: ..." as we don't
    # know what the dict will contain.
    try:
        raise InvalidPattern('error')
    except InvalidPattern as e:
        assert repr(e) == "InvalidPattern('error')"

    try:
        raise InvalidPattern(u'error')
    except InvalidPattern as e:
        assert repr(e) == "InvalidPattern(u'error')"


# Generated at 2022-06-21 21:55:11.589614
# Unit test for function finditer_public
def test_finditer_public():
    _lazy = LazyRegex(('test',))
    _lazy._compile_and_collapse()
    finditer = _lazy.finditer
    _result = ['test']
    _mock = MockObject(_result)
    _lazy.finditer = _mock
    finditer_public('test', 'test')
    assert _mock.called_with == (_result, 'test')

    # When the LazyRegex isn't compiled we get the same behaviour
    _lazy = LazyRegex(('test',))
    _result = ['test']
    _mock = MockObject(_result)
    _lazy.finditer = _mock
    finditer_public('test', 'test')
    assert _mock.called_with == (_result, 'test')



# Generated at 2022-06-21 21:55:22.695194
# Unit test for function reset_compile
def test_reset_compile():
    import __builtin__
    from cStringIO import StringIO
    from bzrlib import tests
    from bzrlib.patiencediff import re

    # Save and restore stdout
    old_stdout = sys.stdout
    sys.stdout = StringIO()

    # Reset the flags so we can test this from a clean state
    re.reset_compile()

    # Install the lazy regex
    re.install_lazy_compile()

    # Test to ensure re.compile is the lazy regex
    if re.compile is not re.lazy_compile:
        raise AssertionError("re.compile is not set to the module lazy_compile")

    # Test to ensure the regex is delayed

# Generated at 2022-06-21 21:55:32.017259
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import osutils
    from bzrlib.bzrdir import BzrDir
    from bzrlib.location import LocationEncodingConfig
    from bzrlib.tests.per_branch_implementations.test_branch import TestCaseWithBranch

    class TestInvalidPattern(TestCaseWithBranch):

        def test_InvalidPattern(self):
            self.requireFeature(LocationEncodingConfig)
            invalid_filename = osutils.filename_to_unicode(u'\xa1')

# Generated at 2022-06-21 21:55:41.160057
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # 'msg' is a str.
    msg = 'invalid pattern'
    e = InvalidPattern(msg)
    assert isinstance(e.msg, unicode)
    assert e.__unicode__() == msg
    # 'msg' is unicode, but it is not decodable.
    msg = u'\u00fe'
    e = InvalidPattern(msg)
    assert isinstance(e.msg, unicode)
    assert e.__unicode__() == msg
    # 'msg' is unicode and it is decodable.
    msg = u'\u00e9'
    e = InvalidPattern(msg)
    assert isinstance(e.msg, unicode)
    assert e.__unicode__() == msg

# Generated at 2022-06-21 21:55:44.228695
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('Whoops!')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. Whoops!'

# Generated at 2022-06-21 21:55:49.419092
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # The pattern is "abCd*e"
    lazy_regex = LazyRegex(('abCd*e',))
    assert lazy_regex.__getstate__() == {
        "args": ('abCd*e',),
        "kwargs": {},
        }



# Generated at 2022-06-21 21:55:55.073375
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string that includes the class
    name and the string value of the Exception.

    This is necessary to correctly identify an exception in a test.
    """
    fmt = "%s(%s)"
    s = "foo"
    e = InvalidPattern(s)
    assert fmt % (e.__class__.__name__, s) == repr(e)

# Generated at 2022-06-21 21:55:57.560426
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle

    proxy = LazyRegex(args=("abc",), kwargs=dict())

    assert pickle.loads(pickle.dumps(proxy)) == proxy

# Generated at 2022-06-21 21:56:01.394780
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method __getattr__ of the class LazyRegex

    This method test the getattr from the class LazyRegex
    """
    lazy = LazyRegex(('(foo)',), {})
    assert lazy.__getattr__('__copy__') == getattr(lazy, '__copy__')


# Generated at 2022-06-21 21:56:10.123225
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should return the real attribute without
    compilation.
    """
    # Method _compile_and_collapse is mocked
    lr = LazyRegex()
    lr.__class__._compile_and_collapse = lambda *args, **kwargs: None

    lr._real_regex = lambda: None
    lr._regex_attributes_to_copy = ['_real_regex']

    assert lr.__getattr__('_real_regex') is lr._real_regex


# Generated at 2022-06-21 21:56:17.540424
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """test_InvalidPattern___unicode__"""
    a = InvalidPattern('foo')
    a.__unicode__()

# Generated at 2022-06-21 21:56:19.305537
# Unit test for constructor of class InvalidPattern

# Generated at 2022-06-21 21:56:22.697236
# Unit test for function lazy_compile
def test_lazy_compile():
    """re.compile should trigger compilation"""
    r = lazy_compile('foo')
    assert(isinstance(r, LazyRegex))
    r.search('bar') # This doesn't compile until we search
    assert(isinstance(r, type(re.compile('foo'))))



# Generated at 2022-06-21 21:56:31.253948
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex"""
    re.compile = _real_re_compile
    re.compile = lazy_compile


# Generated at 2022-06-21 21:56:37.648942
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ returns dictionary with the correct keys"""
    proxy = LazyRegex(("foo",), {"bar": "baz"})
    state = proxy.__getstate__()

    if not "args" in state:
        raise AssertionError("key 'args' not in state")
    if not "kwargs" in state:
        raise AssertionError("key 'kwargs' not in state")



# Generated at 2022-06-21 21:56:45.585243
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.tests import features

    class TestLazyRegex(ExternalBase):

        def test_flags(self):
            re.flags = 0
            self.assertEqual(re.flags, 0)
            # Now set it to something else
            re.flags = 1
            self.assertEqual(re.flags, 1)

        def test_compile(self):
            if features.is_python_3_based:
                # compile is deprecated in python3
                self.assertRaises(DeprecationWarning, re.compile, '')
            else:
                self.assertRaises(DeprecationWarning, re.compile)

    TestLazyRegex('test_flags').run_tests()