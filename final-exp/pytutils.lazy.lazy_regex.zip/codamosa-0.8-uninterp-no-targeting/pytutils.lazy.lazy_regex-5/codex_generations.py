

# Generated at 2022-06-21 21:47:08.904720
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ of class LazyRegex.

    __getattr__ normally is not called on an object, not even by a
    unit test.
    """
    proxy = LazyRegex(args=('(a|b)',))

    # Access actual attribute
    proxy.match

    # Access non-existing attribute -> raise AttributeError
    try:
        proxy.non_existing
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError expected.')



# Generated at 2022-06-21 21:47:20.172596
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test __setstate__ of class LazyRegex.
    """
    # TODO: jam 20070306 Add a test of a real, non-synthetic saved state.
    # We have to do this through a pickle.
    lr = LazyRegex()
    assert lr._real_regex is None
    state = lr.__getstate__()
    assert state == {
            "args": (),
            "kwargs": {},
            }
    del lr
    lr = LazyRegex()
    lr.__setstate__(state)
    assert lr._real_regex is None
    assert lr._regex_args == ()
    assert lr._regex_kwargs == {}


# Install the lazy regex by default.
_real_re_compile = re.compile

# Generated at 2022-06-21 21:47:30.176931
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Check that the InvalidPattern class can be converted to unicode."""
    # A placeholder exception to assert on.
    orig_exception = re.error("invalid regex")
    # Without a format string
    e = InvalidPattern(orig_exception)
    assert type(e.__unicode__()) == unicode
    assert e.__unicode__().encode('utf8') == (
        'Unprintable exception InvalidPattern: dict={}, fmt=None, '
        'error=invalid regex')
    # With a format string
    e._fmt = u'%(msg)s'
    e.msg = orig_exception
    assert type(e.__unicode__()) == unicode
    assert e.__unicode__().encode('utf8') == "invalid regex"

# Generated at 2022-06-21 21:47:37.760411
# Unit test for function reset_compile
def test_reset_compile():
    # Because this is a module level function it's a bit difficult to
    # test in isolation without mocking imports.
    install_lazy_compile()
    try:
        # This should be a LazyRegex now
        regex = re.compile("foo")
        reset_compile()
        assert re.compile == _real_re_compile
        # This should be a real re.compile object
        regex = re.compile("foo")
        reset_compile()
    finally:
        reset_compile()

# Generated at 2022-06-21 21:47:50.796408
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__() compares the __dict__ attribute

    This attribute is the default one for new-style classes.
    """
    # Scenario
    # 1. Create two instances of InvalidPattern
    # 2. Modify one of them by adding an attribute
    # 3. Modify one of them by adding an attribute
    # Final asserts
    # 1. References are not identical (None __eq__ None)
    # 2. The one modified is not equal to the other
    # 3. They are equal by their __dict__
    ip1 = InvalidPattern('Hello')
    ip2 = InvalidPattern('Hello')
    ip1.user_error_msg = 'User error message'
    assert ip1 is not ip2
    assert ip1 != ip2
    assert ip1.__dict__ == ip2.__dict__
    ip1.user

# Generated at 2022-06-21 21:47:56.504682
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    # _fmt is not set in this class
    exception = InvalidPattern('msg')
    result = str(exception)
    expected = 'Unprintable exception InvalidPattern: dict={\'msg\': \'msg\'},' \
               ' fmt=None, error=None'
    assert expected == result
    # _fmt contains a valid format string
    _fmt = ''
    exception = InvalidPattern('msg')
    try:
        exception._fmt = 'fmt'
        result = str(exception)
    finally:
        exception._fmt = _fmt
    expected = gettext('fmt') % {'msg': 'msg'}
    assert expected == result
    # _fmt contains a valid format string
    _fmt = ''

# Generated at 2022-06-21 21:48:05.090428
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that we can installl lazy_compile."""
    install_lazy_compile()
    try:
        re.compile('a')
    except TypeError:
        raise AssertionError(
            "re.compile has not been overridden correctly, still expects" \
            " compile to accept a string")
    reset_compile()
    try:
        re.compile('a')
    except TypeError:
        raise AssertionError(
            "re.compile has not been restored correctly, still expects" \
            " compile to accept a string")

# Generated at 2022-06-21 21:48:10.982753
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Validate that installing a lazy compile makes regexs work on demand.
    """
    install_lazy_compile()
    try:
        import warnings
        warnings.filterwarnings(action='ignore', category=DeprecationWarning)
        # This should not raise a DeprecationWarning
        re.compile("(")
    finally:
        reset_compile()



# Generated at 2022-06-21 21:48:18.965029
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    import bzrlib
    from bzrlib.lazy_regex import InvalidPattern
    e = InvalidPattern('foo')
    assert_equal('InvalidPattern(foo)', repr(e))
    # Use of non-ascii characters
    e = InvalidPattern('f\xc3\xa4o')
    assert_equal('InvalidPattern(f\xc3\xa4o)', repr(e))
    # Building a new InvalidPattern object with default encoding 'ascii'
    assert_equal('InvalidPattern(foo)',
           repr(InvalidPattern('foo')))
    # Building a new InvalidPattern with a different encoding 'iso8859-1'
    assert_equal('InvalidPattern(f\xf6o)',
           repr(InvalidPattern('f\xc3\xa4o'.decode('utf-8'))))

# Generated at 2022-06-21 21:48:23.323424
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib.tests.test_i18n import opts_vi
    import bzrlib.tests as tests
    tests.run_doctest(doctest, opts_vi)

# Generated at 2022-06-21 21:48:33.152453
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('test')
    expected = 'test'
    actual = unicode(e)
    assert expected == actual, '%s != %s' % (expected, actual)

    e.__dict__['_preformatted_string'] = 'Preformatted string'
    expected = 'Preformatted string'
    actual = unicode(e)
    assert expected == actual, '%s != %s' % (expected, actual)

# Generated at 2022-06-21 21:48:42.823120
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_unicode_mode
    old_unicode_mode = set_unicode_mode(False)

# Generated at 2022-06-21 21:48:53.565855
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile()."""
    # Some tests taken from the original re.compile()'s doctests.
    # The doctests were removed in Python 3.
    re_obj = lazy_compile('r.d')
    re_obj.sub('-', 'red')
    re_obj.sub('-', 'blue')


# Generated at 2022-06-21 21:49:04.393570
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    def call_fmt_with_empty_format_string(cls):
        return cls()._format()
    def call_fmt_with_nonempty_format_string(cls):
        return cls(u'%(msg)s')._format()

    expected_str = u'Unprintable exception InvalidPattern: '\
        'dict={...}, fmt=None, error=None'
    actual_str = call_fmt_with_empty_format_string(InvalidPattern)
    assert expected_str == actual_str

    msg_member = b'Unicode\xc3\xa1'
    expected_str = msg_member
    actual_str = call_fmt_with_nonempty_format_string(InvalidPattern)
    assert expected_str == actual_str

# Generated at 2022-06-21 21:49:14.212359
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase

    class Test(TestCase):

        def _test_one(self, a, b, result):
            if result:
                self.assertEqual(a, b)
            else:
                self.assertNotEqual(a, b)

        def test_InvalidPattern___eq__(self):
            self._test_one(InvalidPattern("a"), InvalidPattern("a"), True)
            self._test_one(InvalidPattern("a"), InvalidPattern("b"), False)

    Test().run_tests()



# Generated at 2022-06-21 21:49:25.405800
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method InvalidPattern.__repr__"""
    not_a_valid_latin1_char = u'\xa5' # japanese yen character
    try:
        raise InvalidPattern(not_a_valid_latin1_char)
    except InvalidPattern as e:
        # The following assertion tests the fix for bug #152080
        # No need to test what str(e) returns because we already know
        # that str(e) will be invalid and that is why we are testing.
        assert not unicode(e).encode('latin1')

# Generated at 2022-06-21 21:49:30.343845
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    a = InvalidPattern('one')
    b = InvalidPattern('one')
    c = InvalidPattern('two')
    assert a == b
    assert not a == c



# Generated at 2022-06-21 21:49:39.291580
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should compare the class and all of the attributes"""
    invpat1 = InvalidPattern('some message')
    invpat2 = InvalidPattern('some message')
    invpat3 = InvalidPattern('some other message')
    # Same class, same attributes
    assert invpat1 == invpat2
    # Same class, different attributes
    assert invpat1 != invpat3
    # Different class
    assert invpat1 != 'not an InvalidPattern object'
    # __eq__ should never return NotImplemented (not the same as NotImplementedError)
    assert invpat1 != NotImplemented

# Generated at 2022-06-21 21:49:49.297026
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.plugins.fastimport.tests.test_lazy_regex import TestLazyRegex
    t = TestLazyRegex('test_LazyRegex___getstate__')
    try:
        t.run_bzr('init')
        t.build_tree(['test-script'])
        t.run_bzr(['add', 'test-script'])
        t.run_bzr(['commit', '-m', 'initial revision'])
        t.run_bzr(['build-snapshot'])
    finally:
        t.tearDown()

# Generated at 2022-06-21 21:49:54.510260
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'Some message'
    expected = 'Invalid pattern(s) found. ' + msg
    e = InvalidPattern(msg)
    actual = str(e)
    assert expected == actual, \
        'InvalidPattern constructor does not work properly. Expected: %s, ' \
        'actual: %s' % (expected, actual)

# Generated at 2022-06-21 21:50:07.858265
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    exc = InvalidPattern('message')
    exc._preformatted_string = 'preformatted'
    assert str(exc) == 'preformatted'
    assert isinstance(str(exc), str)
    assert unicode(exc) == 'preformatted'
    assert isinstance(unicode(exc), unicode)
    assert repr(exc) == "InvalidPattern('preformatted')"
    assert exc._get_format_string() is None
    exc2 = InvalidPattern(exc)
    assert str(exc2) == 'preformatted'
    assert isinstance(str(exc2), str)
    assert unicode(exc2) == 'preformatted'
    assert isinstance(unicode(exc2), unicode)
    assert repr(exc2) == "InvalidPattern('preformatted')"
    assert exc == exc2


# Generated at 2022-06-21 21:50:15.968390
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy = LazyRegex(('BZR_.*',), {'flags': re.IGNORECASE})
    assert lazy
    # lazy.__getstate__() is the same as eval(repr(lazy)):
    assert (dict(eval(repr(lazy))) == lazy.__getstate__())

# Unit test to check that installing LazyRegex and resetting works.
# This also tests that calling reset_compile() multiple times is safe.

# Generated at 2022-06-21 21:50:22.116153
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # This can't be done as part of the class definition since it needs
    # gettext to be initialized.
    # Also, this method is only used for testing.
    from bzrlib.i18n import gettext
    InvalidPattern._fmt = gettext('Invalid pattern(s) found. %(msg)s')


test_InvalidPattern()

# Generated at 2022-06-21 21:50:34.179270
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Testing method __unicode__ of class InvalidPattern.

    In particular, we want to check if the method works fine at least with
    the following charsets:
    1. ascii: no conversion needed
    2. utf-8: use unicode(str, utf-8)
    3. unknown: use unicode(str)
    """

    def check_InvalidPattern__unicode__(s, expected):
        """Check method __unicode__ for given string s."""
        class E(InvalidPattern):
            _preformatted_string = s
        assert unicode(E('any')) == expected

    # testing ascii string
    check_InvalidPattern__unicode__('ascii', u'ascii')

    # testing utf-8 string
    s = '\xc2\xa9'
    check_

# Generated at 2022-06-21 21:50:39.762214
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() returns the state to use when pickling.
    """
    regex = LazyRegex(('a*',), {'flags': re.I | re.U})
    expected_result = {
        "args": ('a*',),
        "kwargs": {'flags': re.I | re.U}
    }
    result = regex.__getstate__()
    if result != expected_result:
        raise AssertionError('Expected %r, got %r' % (expected_result, result))



# Generated at 2022-06-21 21:50:46.830383
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Make sure that lazy_compile overrides re.compile"""
    install_lazy_compile()
    regex1 = re.compile("foo")
    regex2 = re.compile("bar")
    assert regex1 is not regex2
    assert regex1.match("foo") is not None
    assert regex2.match("bar") is not None


# Unit tests for the LazyRegex instance
from unittest import TestCase


# Generated at 2022-06-21 21:50:53.244083
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex"""
    regex = LazyRegex(['a*b'], {})
    regex.__setstate__({"args": ['c*d'], "kwargs": {}})
    regex._compile_and_collapse()
    assert regex._regex_args == ['c*d']

# Generated at 2022-06-21 21:50:58.445680
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy = LazyRegex(args=("[a-z]+",), kwargs={"flags":re.IGNORECASE})
    assert lazy._real_regex is None
    assert lazy._regex_args == ("[a-z]+",)
    assert lazy._regex_kwargs == {"flags":re.IGNORECASE}


# Generated at 2022-06-21 21:51:05.088203
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase
    import bzrlib.patiencediff
    a1 = InvalidPattern('')
    a2 = InvalidPattern('')
    TestCase.assertEqual(a1,a2)
    TestCase.assertFalse(a1 != a2)
    a3 = InvalidPattern('do not match')
    TestCase.assertTrue(a1 != a3)
    TestCase.assertFalse(a1 == a3)
    a4 = bzrlib.patiencediff.PatienceSequenceMatcher([],[])
    TestCase.assertTrue(a1 != a4)
    TestCase.assertFalse(a1 == a4)

# Now do the same for re.match

# Generated at 2022-06-21 21:51:11.005270
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern

    Test with a properly formatted error message and with an error message
    that could not be formatted.
    """
    i1 = InvalidPattern('foo bar')
    assert 'foo bar' in str(i1)

    i2 = InvalidPattern('%(foo)s %(bar)s')
    assert '%(foo)s %(bar)s' in str(i2)

# Generated at 2022-06-21 21:51:28.374887
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the LazyRegex.__getattr__ method."""
    import gc

    def check_LazyRegex_works_as_expected(regex_args, regex_kwargs):
        """Check that LazyRegex works as expected.

        Check that a LazyRegex object can be used as a re.RegexObject.
        After compiling the original proxy should be discarded and the proxy
        should then be a trivial wrapper around a RegexObject.
        """
        LazyRegex_proxy = LazyRegex(regex_args, regex_kwargs)
        # Compile and exhaust the match in order to force collapse
        match_object = LazyRegex_proxy.match("hello")
        # In order to make sure the original proxy has been discarded we
        # need to make sure it is garbage collected.
        LazyRegex

# Generated at 2022-06-21 21:51:36.213989
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Install a lazy compile and check that re.compile() returns LazyRegexs

    Note that this will also make that the default for the test suite, which
    is OK, because we're making lazy patterns the default elsewhere.
    """
    install_lazy_compile()
    regex = re.compile("abc")
    try:
        assert isinstance(regex, LazyRegex)
    finally:
        reset_compile()

# Generated at 2022-06-21 21:51:45.318805
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern__unicode__

    The method InvalidPattern.__unicode__ should always return a unicode object.
    """
    # setup
    from bzrlib.i18n import gettext
    fmt = gettext(u'Invalid pattern(s) found. %(msg)s')
    expected_unicode = u'Invalid pattern(s) found. foo'
    # test
    inv_pat = InvalidPattern('foo')
    # verify
    if isinstance(inv_pat.__unicode__(), unicode):
        assert(inv_pat.__unicode__() == expected_unicode)
    else:
        raise AssertionError('InvalidPattern.__unicode__() should return a unicode'
                             ' object.')



# Generated at 2022-06-21 21:51:51.399448
# Unit test for function finditer_public
def test_finditer_public():
    """Test that finditer_public is a valid replacement for finditer.

    It has the same behavior as the original method, but when called with
    a LazyRegex parameter, it calls the finditer method on that object.
    """
    # Test with a standard pattern.
    pattern = re.compile('abc')
    string = 'abcdef'
    iterator = re.finditer(pattern, string)
    result = [match.group() for match in iterator]
    assert result == ['abc']


    # Test with a lazy regex.
    pattern = lazy_compile('abc')
    string = 'abcdef'
    iterator = re.finditer(pattern, string)
    result = [match.group() for match in iterator]
    assert result == ['abc']


test_suite = test_finditer_public

# Generated at 2022-06-21 21:51:59.790633
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should catch AttributeError, and continue
    with a compile and collapse, if _real_regex is None.

    This is the real cause of bug #360091.
    """
    lr = LazyRegex(('a'))
    try:
        lr.group()
    except AttributeError:
        pass
    else:
        raise AssertionError("_real_regex should be None by default")

# Install by default
install_lazy_compile()

# Generated at 2022-06-21 21:52:01.147175
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    LazyRegex()

# Generated at 2022-06-21 21:52:12.959367
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of the class InvalidPattern."""
    # Check that it returns a 'unicode' object and not a 'str' object.
    # Note. It is important to use unicode literals.
    s = 'abc'
    s_unicode = u'abc'
    t = InvalidPattern(s)
    u = t.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError('__unicode__ lacks the return value a unicode'
            ' object')
    if u != s_unicode:
        raise AssertionError('__unicode__ lacks the return value ' + s)
    s = u'abc'
    s_unicode = u'abc'
    t = InvalidPattern(s)
    u = t.__unicode__()

# Generated at 2022-06-21 21:52:19.100119
# Unit test for function reset_compile
def test_reset_compile():
    import bzrlib.tests
    from bzrlib.tests import TestCase, TestCaseWithMemoryTransport

    class TestOriginalCompile(TestCase):

        def setUp(self):
            super(TestOriginalCompile, self).setUp()
            install_lazy_compile()

        def test_re_compile_when_lazy_compile_enabled(self):
            # This is an odd unit test -- we are basically asserting
            # that the original compile routine works when we are in
            # lazy compile mode.
            self.assertEqual(re.compile, lazy_compile)
            r = re.compile("foo")
            self.assertTrue(isinstance(r, LazyRegex))


# Generated at 2022-06-21 21:52:30.262896
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ of LazyRegex

    This tests for the issue reported in https://bugs.launchpad.net/bugs/299054
    where referring to the regex attribute groups would cause an AttributeError
    as the real_regex attribute had not been compiled yet.
    """
    import bzrlib.trace

    lr = LazyRegex(("(\d)(\d)(\d)",))
    bzrlib.trace.enable_default_logging()
    lr.groups
    return True

# __getattr__ of LazyRegex tests


# Generated at 2022-06-21 21:52:39.909163
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern("message")
    assert e.msg == "message"
    # __unicode__ must return a unicode object
    assert isinstance(unicode(e), unicode)
    # __str__ must return a str object
    assert isinstance(str(e), str)
    # __repr__ should mention the message
    assert "message" in str(repr(e))
    a = InvalidPattern("bar")
    b = InvalidPattern("bar")
    assert a == b



# Generated at 2022-06-21 21:52:48.402582
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('foo')
    assert e.msg == 'foo'
    assert e.__str__() == 'Invalid pattern(s) found. foo'

# Generated at 2022-06-21 21:52:54.833199
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore the object to a pre-compiled state.

    This method is used by pickle.loads to restore the object.
    """
    import pickle
    regex = LazyRegex((r'(?),',), {'flags': re.IGNORECASE})
    regex.__setstate__({'args': (r'(?),',), 'kwargs': {'flags': re.IGNORECASE}})



# Generated at 2022-06-21 21:52:58.808087
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    expected_args = ('regexstring',)
    expected_kwargs = {'flags':1234}
    lr = LazyRegex(expected_args, expected_kwargs)
    assert lr._regex_args == expected_args
    assert lr._regex_kwargs == expected_kwargs
    assert lr._real_regex is None


# Generated at 2022-06-21 21:53:02.584360
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object."""
    assert isinstance(InvalidPattern('test').__unicode__(), unicode)


# Generated at 2022-06-21 21:53:04.308861
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # make sure we can create an instance of LazyRegex
    LazyRegex()

# Generated at 2022-06-21 21:53:13.475507
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test LazyRegex.__getstate__"""
    args = ('pattern',)
    kwargs = {'flags': re.IGNORECASE}
    lazy_re = LazyRegex(args, kwargs)
    state = lazy_re.__getstate__()

    # The returned state should be equal to the set of the arguments
    # and the key parameters used when the object LazyRegex was created
    expected = {
        "args": args,
        "kwargs": kwargs,
        }
    assert state == expected, \
        "LazyRegex.__getstate__ should return the state of the class"

# Generated at 2022-06-21 21:53:22.465553
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    regex = LazyRegex(args=('^foo$',))
    assert regex.pattern is None
    assert regex._real_regex is None

    regex = re.compile('^foo$')
    assert regex.pattern == '^foo$'
    assert regex._real_regex is None

    lazy_regex = LazyRegex(args=('^foo$',))
    assert lazy_regex.pattern == '^foo$'
    assert lazy_regex._real_regex is not None
    assert lazy_regex._real_regex.pattern == '^foo$'



# Generated at 2022-06-21 21:53:26.743275
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__() does not raise AttributeError for known
    attributes
    """
    for attr in LazyRegex._regex_attributes_to_copy:
        obj = LazyRegex()
        # make sure that obj has not been compiled
        assert obj._real_regex is None

        try:
            # getattr(obj, attr) should not raise AttributeError
            getattr(obj, attr)
        except AttributeError:
            raise AssertionError(
                'AttributeError raised for attribute %r' % attr)

# Generated at 2022-06-21 21:53:34.778520
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit tests for LazyRegex.__getstate__() method.
    """
    regex = lazy_compile(r'a*')
    state = regex.__getstate__()
    expected_state = {"args": (r'a*',), "kwargs": {}}
    assert expected_state == state, \
           "regex.__getstate__() returned incorrect value: %r, expected: %r" \
           % (state, expected_state)

# Generated at 2022-06-21 21:53:44.938665
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the LazyRegex proxy works as expected"""

    import warnings
    warnings.filterwarnings("ignore", ".*the regex module is deprecated",
                            DeprecationWarning, __name__)

    # First, some simple tests that we can access the regex
    # properly:
    r1 = lazy_compile("ab")
    assert r1.match("aba")
    assert not r1.match("ba")
    assert r1.match("ab")
    assert not r1.match("abc")

    # Check for proper handling of multilines, and flags
    r2 = lazy_compile("ab", flags=re.MULTILINE)
    assert r2.match("ba")
    assert r2.match("ab")
    assert not r2.match("abc")

    # Check for proper handling of capturing groups
   

# Generated at 2022-06-21 21:53:55.463733
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # This is a trivial test because InvalidPattern is a subclass of
    # ValueError which has a non trivial __repr__ method.
    import bzrlib.errors
    bzrlib.errors.InvalidPattern._fmt = '%(msg)s'
    ip = bzrlib.errors.InvalidPattern('msg')
    repr(ip)

# Generated at 2022-06-21 21:53:58.099319
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    p = lazy_compile('(.*)')
    assert p.__getstate__() == {'args': ('(.*)',), 'kwargs': {}}

# Generated at 2022-06-21 21:54:09.470645
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object.

    This is to avoid crashing, when the __unicode__ method returns a
    unicode object (by default).
    """
    # this is a list of tuples (error, unicode-expected-output)

# Generated at 2022-06-21 21:54:16.953965
# Unit test for function reset_compile
def test_reset_compile():
    # First call to reset_compile shouldn't do anything -- since we haven't
    # installed lazy_compile yet
    reset_compile()
    # Install lazy_compile, then verify reset_compile resets it
    install_lazy_compile()
    reset_compile()
    # And then it should still work if we install again
    install_lazy_compile()
    reset_compile()


# Generated at 2022-06-21 21:54:28.412443
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import bzrlib.tests.per_interpreter
    from bzrlib.tests.test_i18n import i18n_environ
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_translations_dir
    from bzrlib.i18n import set_output_encoding
    import os
    import sys
    import tempfile

    prefix = os.path.join(tempfile.gettempdir(),
                          "bzrlib_i18n_unit_tests.%d." % os.getpid())
    name = prefix + "install"
    # setup a fake domain
    set_translations_dir(name)
    # setup a fake locale directory

# Generated at 2022-06-21 21:54:35.354215
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Get state of LazyRegex

    Unit test for method __getstate__ of class LazyRegex
    """
    args = ('a*b',)
    kwargs = {'flags': 0}
    LR = LazyRegex(args, kwargs)
    if LR.__getstate__() != {
            "args": ('a*b',),
            "kwargs": {'flags': 0}
            }:
        raise AssertionError()


# Generated at 2022-06-21 21:54:38.771095
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = LazyRegex(('a',))
    e = r.__getattr__('foo')
    assert e is r._real_regex.foo



# Generated at 2022-06-21 21:54:48.656631
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    lazyre = lazy_compile("ab*")
    dict_initial = {"args": ("ab*",), "kwargs": {}}
    setattr(lazyre, "__dict__", dict_initial)
    assert lazyre.__getattr__("_regex_args") == ("ab*",)
    assert lazyre.__getattr__("_regex_kwargs") == {}

    lazyre = pickle.loads(pickle.dumps(lazyre))
    assert lazyre.__getattr__("_regex_args") == ("ab*",)
    assert lazyre.__getattr__("_regex_kwargs") == {}

    new_dict = {"args": ("cd*",), "kwargs": {}}
    lazyre.__setstate__(new_dict)
    assert lazy

# Generated at 2022-06-21 21:54:54.420021
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'Invalid pattern'
    p = InvalidPattern(msg)
    expected_str = msg
    expected_repr = 'InvalidPattern(%s)' % msg
    got_str = str(p)
    got_repr = repr(p)
    if expected_str != got_str:
        raise AssertionError('str(%r) expected %r, got %r'
                             % (p, expected_str, got_str))
    if expected_repr != got_repr:
        raise AssertionError('repr(%r) expected %r, got %r'
                             % (p, expected_repr, got_repr))

# Generated at 2022-06-21 21:54:56.543849
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy regex compilation"""
    import doctest
    from bzrlib import regexes
    return doctest.DocTestSuite(regexes)

# Generated at 2022-06-21 21:55:12.481459
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile does what we think it does"""
    install_lazy_compile()
    r = re.compile('.*', re.DOTALL)
    assert isinstance(r, LazyRegex)



# Generated at 2022-06-21 21:55:17.092842
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr__ of class InvalidPattern"""
    error_msg = 'Please enter a bug report at https://bugs.launchpad.net.'
    error = InvalidPattern(error_msg)
    assert repr(error) == \
        "InvalidPattern('Please enter a bug report at https://bugs.launchpad.net.')"

# Generated at 2022-06-21 21:55:30.494427
# Unit test for function finditer_public
def test_finditer_public():
    import doctest

    from bzrlib import errors

    from bzrlib.tests import TestUtil

    from bzrlib.lazy_regex import (
        reset_compile,
        LazyRegex,
        finditer_public,
        )

    from bzrlib.tests.blackbox import test_lazy_regex

    from bzrlib.tests.per_regex import (
        TestCaseWithMemoryTransport,
        TestCaseWithTransport,
        )

    globals()['install_lazy_compile'] = test_lazy_regex.install_lazy_compile
    globals()['LazyRegex'] = test_lazy_regex.LazyRegex
    globals()['finditer_public'] = test_lazy_regex.finditer_public

# Generated at 2022-06-21 21:55:35.226157
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ is used in doctest. See https://bugs.launchpad.net/bzr/+bug/441094"""
    a = InvalidPattern('')

    # __eq__ should not raise exceptions
    b = InvalidPattern('')
    assert a == b

    b = InvalidPattern('message')
    assert a != b

# Generated at 2022-06-21 21:55:39.437842
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of class LazyRegex."""
    lazy_regex = LazyRegex()
    # _real_regex should not be initialized
    assert lazy_regex._real_regex is None
    # _regex_args should be initialized
    assert lazy_regex._regex_args == ()
    # _regex_kwargs should be initialized
    assert lazy_regex._regex_kwargs == {}


test_suite = "test_LazyRegex"

# Generated at 2022-06-21 21:55:48.631241
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test of LazyRegex.__setstate__ method"""
    # Create a LazyRegex
    lr = LazyRegex()
    # Mock data to be restored
    args = ('a', 'b', 'c')
    kwargs = {'d':'d', 'e':'e'}
    # Restore state
    lr.__setstate__({'args':args, 'kwargs':kwargs})
    # Check
    assert lr._regex_args == args
    assert lr._regex_kwargs == kwargs
    assert lr._real_regex == None

# Generated at 2022-06-21 21:55:51.949854
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = re.compile('foo')
    l = LazyRegex(('foo',))
    assert r.match('foo')
    assert l.match('foo')
    assert r == l

# Generated at 2022-06-21 21:56:01.579061
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    # test with a complex regexp
    lazy_regex = LazyRegex(("(?P<name>\w+)",), {})
    state = lazy_regex.__getstate__()
    assert len(state) == 2
    assert type(state) is dict
    assert type(state["args"]) is tuple
    assert len(state["args"]) == 1
    assert type(state["kwargs"]) is dict
    assert len(state["kwargs"]) == 0
    assert state["args"][0] == "(?P<name>\w+)"
    # test with simple regexp
    lazy_regex = LazyRegex(("^abc$",), {})
    state = lazy_regex.__getstate__()
    assert len(state) == 2

# Generated at 2022-06-21 21:56:13.456628
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should compare all members in self.__dict__"""
    from testtools.matchers import Equals
    # Run tests for the method
    error = InvalidPattern(msg='illegal character range')
    error1 = InvalidPattern(msg='illegal character range')
    error.__dict__['a'] = 'b'
    error1.__dict__['a'] = 'c'
    # Comparing __dict__ of two separate objects,
    # should return as not equal as they have
    # different object ids
    error.__dict__['self_id'] = id(error)
    error1.__dict__['self_id'] = id(error1)
    # Test to ensure the member is copied to the new object
    error1.__dict__['a'] = error.__dict__['a']
    error1.__dict

# Generated at 2022-06-21 21:56:19.014558
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of class LazyRegex"""
    LazyRegex()
    LazyRegex(42)
    LazyRegex(foo=42)
    LazyRegex(42, bar=24)
    LazyRegex(42, foo=24)
    LazyRegex(42, foo=24, bar='asd')



# Generated at 2022-06-21 21:56:31.908578
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test whether install_lazy_compile works without an exception."""
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-21 21:56:38.881570
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class MyError(Exception):
        pass
    e = MyError()
    e._preformatted_string = 'test_exception_string'
    e._fmt = 'invalid pattern: %(msg)s'
    er1 = InvalidPattern("msg")
    er2 = InvalidPattern("msg")
    assert er1 == er2
    er3 = InvalidPattern("msg1")
    assert er1 != er3
    assert str(er1) == 'invalid pattern: msg'


# Generated at 2022-06-21 21:56:42.692222
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    r = re.compile('Foobar')
    r.findall('Foobar')
    state = r.__getstate__()
    assert 'args' in state
    assert 'kwargs' in state
    assert state['args'] == ('Foobar', )
    assert state['kwargs'] == {}


# Generated at 2022-06-21 21:56:54.201750
# Unit test for function finditer_public
def test_finditer_public():
    # test for simple match
    regex = re.compile(r'a')
    assert re.finditer(regex, 'a')[0].group() == 'a'
    # test for simple non-match
    assert re.finditer(regex, 'b') == []
    # test for multiple match
    regex = re.compile(r'a')
    assert re.finditer(regex, 'aab')[0].group() == 'a'
    assert re.finditer(regex, 'aab')[1].group() == 'a'
    # test for LazyRegex
    regex = re.lazy_compile(r'a')
    assert re.finditer(regex, 'a')[0].group() == 'a'
    regex = re.lazy_compile(r'b')