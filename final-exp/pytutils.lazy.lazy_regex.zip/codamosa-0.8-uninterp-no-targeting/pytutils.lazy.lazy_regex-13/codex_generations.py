

# Generated at 2022-06-21 21:46:59.302746
# Unit test for function lazy_compile
def test_lazy_compile():
    pattern = lazy_compile("a")
    if hasattr(pattern, 'pattern'):
        assert pattern.pattern == "a"
    mo = pattern.search("a")
    assert mo.group(0) == "a"



# Generated at 2022-06-21 21:47:06.870224
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    l = LazyRegex(('^abc',), dict(flags=re.IGNORECASE))
    l.match('ABC')
    s = pickle.dumps(l)
    l = pickle.loads(s)
    assert l.match('ABC') is not None



# Generated at 2022-06-21 21:47:19.031063
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    try:
        lazy_regex = LazyRegex((r'[a-z]'))
    except:
        raise AssertionError("Could not create instance of LazyRegex")
    regex = lazy_regex.search('bbz')
    if regex is None:
        raise AssertionError(
            "LazyRegex object not built correctly" +
            "from search('bbz') on 'bbz'")
    regex = lazy_regex.match('bbz')
    if regex is not None:
        raise AssertionError(
            "LazyRegex object not built correctly" +
            "from match('bbz') on 'bbz'")
    regex = lazy_regex.findall('bbz')

# Generated at 2022-06-21 21:47:22.464347
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set the attributes 'args' and 'kwargs'"""
    obj = LazyRegex()
    obj.__setstate__({"args": [], "kwargs": {}})
    assert(obj._regex_args == [])
    assert(obj._regex_kwargs == {})

# Generated at 2022-06-21 21:47:28.742987
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__() should return attributes of real_regex object
    and actually create real_regex object if it is not created yet.
    """
    import re
    p = LazyRegex(('^a'))
    assert p.__getattr__('pattern') == '^a'
    assert p.pattern == '^a'
    assert p._real_regex.pattern == '^a'
    assert p._real_regex.match('a')
    assert not p._real_regex.match('b')


# Generated at 2022-06-21 21:47:40.386987
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import ugettext
    try:
        raise InvalidPattern("foo")
    except InvalidPattern as exc:
        instance = exc
    assert ugettext("Invalid pattern(s) found. %(msg)s") == \
        "Invalid pattern(s) found. %(msg)s"
    assert unicode(instance) == u'Invalid pattern(s) found. foo'
    assert str(instance) == 'Invalid pattern(s) found. foo'
    assert repr(instance) == "InvalidPattern('Invalid pattern(s) found. foo')"
    assert instance == InvalidPattern("foo")
    instance._fmt = "bar %(msg)s"
    assert unicode(instance) == u'bar foo'
    assert str(instance)

# Generated at 2022-06-21 21:47:45.149376
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()
    r = re.compile("foo")
    install_lazy_compile()
    r = re.compile("foo")  # We don't really care that this works
    reset_compile()
    r = re.compile("foo")  # The real test: that this works.

# Generated at 2022-06-21 21:47:47.543180
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() must return a 'dict' instance."""
    pattern = LazyRegex("a")
    state = pattern.__getstate__()
    if not isinstance(state, dict):
        raise AssertionError("__getstate__() must return a 'dict' instance.")


# Generated at 2022-06-21 21:47:53.163707
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    args = ("(a|b)*abb",)
    kwargs = {"flags": re.I}
    regex = LazyRegex(args, kwargs)
    assert (regex._regex_args == args), \
        "LazyRegex constructor failed to set correct args"
    assert (regex._regex_kwargs == kwargs), \
        "LazyRegex constructor failed to set correct kwargs"
    assert (regex._real_regex == None), \
        "LazyRegex constructor failed to start with empty real regex"
    assert (regex._compile_and_collapse() == None), \
        "LazyRegex._compile_and_collapse failed to return none on first use"

# Generated at 2022-06-21 21:48:00.584373
# Unit test for function lazy_compile
def test_lazy_compile():
    from cStringIO import StringIO
    from bzrlib.tests import TestCase

    class FakeRegex(object):

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True
            return FakeRegexMatch(self.args, self.kwargs, self)

        def findall(self, *args, **kwargs):
            return 'findall(%r,%r)' % (args, kwargs)

        def __str__(self):
            return 'FakeRegex(%r,%r)' % (self.args, self.kwargs)


# Generated at 2022-06-21 21:48:08.938177
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test InvalidPattern___repr__"""
    import doctest
    doctest.run_docstring_examples(InvalidPattern._format, globals())

# Generated at 2022-06-21 21:48:16.927114
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex()initializes _real_regex to None, _regex_args to (), and
    _regex_kwargs to {}"""
    lzre = LazyRegex()
    assert lzre._real_regex is None
    assert lzre._regex_args == ()
    assert lzre._regex_kwargs == {}
    # If we access an attribute, it compiles the regex and returns the
    # attribute
    assert len(lzre.pattern) == 0
    # It collapses the proxy, so if we access another attribute, it just
    # returns it
    assert len(lzre.pattern) == 0



# Generated at 2022-06-21 21:48:27.494252
# Unit test for function lazy_compile
def test_lazy_compile():
    # This unit test is pretty basic, but that is because this module
    # is the baseline.
    # in various other unit tests we test that the LazyRegexes are
    # properly handled.
    probe = re.compile('foo')
    assert isinstance(probe, LazyRegex)
    assert not isinstance(probe, re._pattern_type)
    install_lazy_compile()
    try:
        probe = re.compile('foo')
        assert isinstance(probe, LazyRegex)
        assert not isinstance(probe, re._pattern_type)
    finally:
        reset_compile()
    probe = re.compile('foo')
    assert isinstance(probe, LazyRegex)
    assert not isinstance(probe, re._pattern_type)

# Generated at 2022-06-21 21:48:35.210650
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # __eq__ is only defined for objects of the same class.
    obj = InvalidPattern('foo')
    class SubInvalidPattern(InvalidPattern):
        pass
    obj2 = SubInvalidPattern('foo')
    assert not obj == obj2

    # __eq__ must return NotImplemented if the other class does not support it.
    assert obj == object() == NotImplemented

    obj3 = InvalidPattern('foo')
    assert obj == obj3

    obj4 = InvalidPattern('bar')
    assert not obj == obj4



# Generated at 2022-06-21 21:48:43.933509
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern."""
    # When an InvalidPattern object is used in a == comparison, the pattern
    # string is compared with the other pattern string.
    e1 = InvalidPattern('s1')
    assert e1 == InvalidPattern('s1'), 's1 should be equal to s1'
    assert not e1 != InvalidPattern('s1'), 's1 should be equal to s1'
    assert not (e1 == InvalidPattern('s2')), 's1 should not be equal to s2'
    assert e1 != InvalidPattern('s2'), 's1 should not be equal to s2'
    e2 = InvalidPattern('s2')
    assert not (e2 == InvalidPattern('s1')), 's2 should not be equal to s1'

# Generated at 2022-06-21 21:48:54.253971
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    r = LazyRegex((r'(?P<host>[^:]+)(?::(?P<port>\d+))?',), {'flags': re.IGNORECASE})
    assert r._regex_args == (r'(?P<host>[^:]+)(?::(?P<port>\d+))?',)
    assert r._regex_kwargs == {'flags': re.IGNORECASE}
    # Because the recursive call to __setstate__ from pickle.py don't create a
    # new instance, this method is never called, so we must use a new instance
    # of LazyRegex
    import pickle
    r2 = pickle.loads(pickle.dumps(r))

# Generated at 2022-06-21 21:49:00.063928
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    class TestException(InvalidPattern):
        _fmt = '%(what)s'
        def __init__(self, what):
            self.what = what

    e = TestException('OK')
    if str(e) != 'OK':
        raise AssertionError(
            "InvalidPattern().__str__() failed: %r" % str(e))

# Generated at 2022-06-21 21:49:07.760381
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ returns the class name and its arguments
    """
    # this is the only class for which we have __repr__ redefined
    test_data = InvalidPattern('test message')
    expected_result = 'InvalidPattern(test message)'

    result = repr(test_data)

    assert result == expected_result, 'result = %r' % (result,)


# Generated at 2022-06-21 21:49:17.094085
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test LazyRegex.__getattr__ with the most common case.

    Tests all member attributes of a compiled LazyRegex. The real
    members are methods.
    """
    __tracebackhide__ = True
    # This is not a re.compile call, because we want to test
    # the LazyRegex class itself, not the function lazy_compile
    # created.
    regex = LazyRegex((r'foo',))
    # Check that all _regex_attributes_to_copy are accessible
    # as attributes.
    for attribute in LazyRegex._regex_attributes_to_copy:
        # __getattr__ may access _real_regex, the actual compiled
        # regex, if the attribute is not yet set in self.
        assert getattr(regex, attribute) is not None

# Generated at 2022-06-21 21:49:21.896935
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Ensure InvalidPattern.__repr__ returns a valid representation"""
    e = InvalidPattern('Pattern failed')
    e.__repr__()
    str(e)
    unicode(e)

# Generated at 2022-06-21 21:49:35.184474
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    pattern = re.compile('(a|b')  # Raises a re.error exception
    try:
        pattern.match()
    except re.error as e:
        pass # bind e to the re.error exception
    try:
        raise InvalidPattern(str(e))
    except InvalidPattern as e:
        if not isinstance(e, re.error):
            raise AssertionError('A re.error exception was expected')

# Generated at 2022-06-21 21:49:37.667753
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ of InvalidPattern

    Two InvalidPattern instances should be equal if and only if their
    messages are equal.
    """
    a = InvalidPattern('foo')
    b = InvalidPattern('foo')
    assert a == b
    b = InvalidPattern('bar')
    assert a != b

# Generated at 2022-06-21 21:49:41.835604
# Unit test for function finditer_public
def test_finditer_public():
    r = lazy_compile('ab')
    it = finditer_public(r, 'ab')
    assert next(it).group(0) == 'ab'


# Only install if we are the main __init__
if __name__ == '__init__':
    install_lazy_compile()

# Generated at 2022-06-21 21:49:48.874142
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    b = InvalidPattern('msg1')
    b.other_param = 'value'
    c = InvalidPattern('msg1')
    c.other_param = 'value'
    d = InvalidPattern('msg2')
    d.other_param = 'value'
    e = InvalidPattern('msg2')
    e.other_param = 'wrong_value'
    assert b == c
    assert not b == d
    assert not b == e

# Generated at 2022-06-21 21:49:50.658718
# Unit test for function lazy_compile
def test_lazy_compile():
    regex1 = re.compile('test')
    regex2 = lazy_compile('test')
    regex3 = lazy_compile('test')
    regex4 = re.compile('test')
    assert regex1 == regex2
    assert regex2 == regex3
    assert regex3 == regex4


# Generated at 2022-06-21 21:49:57.560028
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern returns str type"""
    from bzrlib import i18n
    i18n.install()

    def _get_str(msg):
        """Returns a string from InvalidPattern"""
        err = InvalidPattern(msg)
        return str(err)

    msg_to_str = _get_str('test')
    if not isinstance(msg_to_str, str):
        raise AssertionError('__str__ does not return str type')

# Generated at 2022-06-21 21:50:06.315275
# Unit test for function reset_compile
def test_reset_compile():
    # We have to have a separate test case because setUp/tearDown is called on
    # each test case, so we can't do this in the main test case.
    install_lazy_compile()
    reset_compile()
    re_compile_type = type(re.compile)
    re_compile_type_real = type(_real_re_compile)
    if re_compile_type != re_compile_type_real:
        raise AssertionError(
            "re.compile is not the original function after reset_compile(): "
            "%r != %r" % (re_compile_type, re_compile_type_real))

# Generated at 2022-06-21 21:50:10.255809
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    return doctest.DocFileSuite('../../../doc/developers/testing.txt',
                                optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 21:50:16.853261
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should always return a 'str' object (not unicode)"""

# Generated at 2022-06-21 21:50:23.874907
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Make sure the __str__() method of InvalidPattern gives the right result

    We just want to be sure that the __str__() method is compatible with
    Python 2.5 and Python 2.6 and won't break under Python 3
    """
    ip = InvalidPattern('pattern "foobar" detected invalid')
    assert str(ip) == 'Invalid pattern(s) found. "foobar" detected invalid'

# Generated at 2022-06-21 21:50:31.781571
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    o = LazyRegex(['abc'], {'flags': re.IGNORECASE})
    data = pickle.dumps(o)
    o2 = pickle.loads(data)
    assert isinstance(o2, LazyRegex)

# Generated at 2022-06-21 21:50:37.126237
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ method of class LazyRegex"""
    lazy_regex = LazyRegex(args=('(?P<something>.+)',), kwargs={'flags':re.I})
    state = lazy_regex.__getstate__()
    # 'args' should contain compiled regular expression
    expected_args = ('(?P<something>.+)',)
    # 'kwargs' should contain flags
    expected_kwargs = {'flags':re.I}
    # state variable should have 'args' and 'kwargs'
    expected_dict = {'args': expected_args, 'kwargs': expected_kwargs}
    # state variable should be equal to expected_dict

# Generated at 2022-06-21 21:50:48.760404
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ is able to return attribute of the real regex.

    This test is written to ensure the LazyRegex.__getattr__() works well.
    """
    import re
    install_lazy_compile()
    try:
        lazyPattern = re.compile(r'(?P<name>[abc]+)')
        realPattern = _real_re_compile(r'(?P<name>[abc]+)')
        assert lazyPattern.pattern == realPattern.pattern
        assert lazyPattern.groups == realPattern.groups
        assert lazyPattern.groupindex == realPattern.groupindex
        assert lazyPattern.flags == realPattern.flags
    finally:
        reset_compile()

# Generated at 2022-06-21 21:50:53.714997
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Regression test for bug#743048.

    Verify that the implementation of __repr__ for InvalidPattern does not
    fail for an invalid dictionary.
    """
    pattern = InvalidPattern("Invalid pattern")
    pattern.__dict__ = None
    pattern.__repr__()

# Generated at 2022-06-21 21:51:02.756520
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test install_lazy_compile and reset_compile."""
    r = re.compile('abc')
    install_lazy_compile()
    lr = re.compile('def')
    # Make sure that lr is actually a LazyRegex
    assert isinstance(lr, LazyRegex)
    # Make sure that r is still a regular regex
    assert not isinstance(r, LazyRegex)
    reset_compile()
    # Make sure the regular re.compile() works
    r = re.compile('abc')
    assert not isinstance(r, LazyRegex)
    # Make sure that it works with the same name
    r = re.compile('def')
    assert not isinstance(r, LazyRegex)
    # Make sure that the LazyRegex still works

# Generated at 2022-06-21 21:51:10.217954
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    install_lazy_compile()
    try:
        regex = re.compile(r'a')
        assert isinstance(regex, LazyRegex)
        real_regex = regex._real_regex
        assert real_regex is None
        assert regex.search('a')
        assert regex._real_regex is not None
        # Make sure we are using the _real_regex for
        # the next two calls
        assert regex.search('b') is None
        assert regex.search('a')
    finally:
        reset_compile()

# Generated at 2022-06-21 21:51:21.647628
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for __eq__ method of InvalidPattern class.

    Test for bug #658384
    """
    # Default behaviour:
    # >>> class CustomException(Exception):
    # ...   pass
    # >>> raise CustomException()
    # Traceback (most recent call last):
    #   File "<stdin>", line 1, in <module>
    # __main__.CustomException
    # >>> raise CustomException()
    # Traceback (most recent call last):
    #   File "<stdin>", line 1, in <module>
    # __main__.CustomException
    # >>> raise CustomException() == CustomException()
    # Traceback (most recent call last):
    #   File "<stdin>", line 1, in <module>
    # __main__.CustomException
    # >>> raise CustomException() == CustomException()
   

# Generated at 2022-06-21 21:51:28.639638
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from bzrlib.tests import TestCase
    from cPickle import dumps, loads

    class TestLazyRegex(TestCase):

        def test___setstate__(self):
            re_source = '.*'
            regex = LazyRegex((re_source,))
            regex_pickle = dumps(regex)
            regex_unpickle = loads(regex_pickle)

            regex_unpickle._compile_and_collapse()

            self.assertEqual(regex_unpickle._regex_args, (re_source, ))
            self.assertEqual(regex_unpickle._regex_kwargs, {})

# Generated at 2022-06-21 21:51:33.196945
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex"""
    # Save the default re.compile() and install lazy_compile
    install_lazy_compile()

    # Create a LazyRegex object and freeze it
    lr1 = LazyRegex(('a',), {})

    # This is _not_ the original re.compile()
    assert re.compile is not _real_re_compile

    # Now restore the original re.compile()
    reset_compile()
    assert re.compile is _real_re_compile

    # Unfreeze and load the LazyRegex
    lr2 = LazyRegex(('a',), {})

    # Verify the two objects
    assert lr1.__getstate__() == lr2.__getstate__()


# Generated at 2022-06-21 21:51:44.799622
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that re.compile() is overridden with lazy_compile"""
    # After calling this, the real compile should be gone:
    install_lazy_compile()
    try:
        if re.compile is not lazy_compile:
            raise AssertionError(
                "re.compile should have been overridden with lazy_compile")
        if lazy_compile is _real_re_compile:
            raise AssertionError(
                "lazy_compile and real_compile should be different")
        # and that the real compile is still available:
        if _real_re_compile is not re.compile:
            raise AssertionError(
                "real_compile is no longer a distinct function.")
    finally:
        reset_compile()

# Generated at 2022-06-21 21:52:04.657794
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Testing __getstate__ of LazyRegex.

    This test is for the function __getstate__ of class LazyRegex.
    This function will return a dict containing the state of the instance.
    """
    import pickle
    regex = LazyRegex(("\d"))
    state = regex.__getstate__()
    expected = {"args": ("\d"), "kwargs": {}}
    assert state == expected, "%s != %s" % (state, expected)



# Generated at 2022-06-21 21:52:09.716508
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = LazyRegex(args=(b"foobar", re.IGNORECASE))
    assert r._regex_args == (b"foobar", re.IGNORECASE)
    assert r._real_regex is None
    return r


# Generated at 2022-06-21 21:52:13.403902
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = "test_message"
    e = InvalidPattern(msg)
    e._preformatted_string = 'test_preformatted_message'
    assert isinstance(e._format(), unicode)
    assert e.msg == msg
    assert str(e) == 'test_preformatted_message'
    assert unicode(e) == 'test_preformatted_message'

# Generated at 2022-06-21 21:52:20.025479
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should use __dict__"""
    class X(InvalidPattern):
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
    obj1 = X()
    obj2 = X()
    obj1.foo = 'foo'
    obj2.foo = 'foo'
    obj1.bar = 'bar'
    obj2.bar = 'bar'
    assert obj1 == obj2


# Generated at 2022-06-21 21:52:28.262849
# Unit test for function reset_compile
def test_reset_compile():
    global _real_re_compile
    install_lazy_compile()
    try:
        assert re.compile is lazy_compile
        reset_compile()
        assert re.compile is _real_re_compile
        reset_compile()
        assert re.compile is _real_re_compile
    finally:
        reset_compile()

# Generated at 2022-06-21 21:52:33.522312
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern("asdf")
    except InvalidPattern as e:
        assert e.__str__() == str(e)
        assert e.__unicode__() == unicode(e)
        assert unicode(e) == 'Invalid pattern(s) found. "asdf"'

# VFALCO: I do not see the point of the above, but I am not removing it,
# since it does have coverage.

# Generated at 2022-06-21 21:52:40.289230
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should not raise an exception"""
    e1 = InvalidPattern('msg1')
    e2 = InvalidPattern('msg1')
    e3 = InvalidPattern('msg2')
    e4 = 'foo'
    try:
        if e1 == e2: pass
        if e3 == e3: pass
        if e1 != e3: pass
        if e1 != e4: pass
        if e2 != e4: pass
    except Exception:
        raise AssertionError('InvalidPattern.__eq__ caused an exception')

# Generated at 2022-06-21 21:52:44.939202
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test case for method __repr__ of class InvalidPattern."""
    error = InvalidPattern(u'xx')
    expected = u'InvalidPattern(xx)'
    assert repr(error) == expected

# Generated at 2022-06-21 21:52:54.932906
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method __setstate__ of class LazyRegex.
    """
    import pickle
    lazy = LazyRegex([])
    # Check that the proxy can be pickled and restored
    # It would raise a TypeError if __setstate__ was not implemented.
    pickle.loads(pickle.dumps(lazy))
    # Even though the proxy was pickled and restored, the original regex was not.
    # So it should not have been compiled yet.
    try:
        lazy.pattern
    except TypeError:
        pass
    else:
        raise AssertionError('The underlying regex should not have been compiled yet.')

# Generated at 2022-06-21 21:52:59.059991
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern().__str__() should return a message in string
    """
    str(InvalidPattern('a message'))
    str(InvalidPattern(u'a message'))


# Generated at 2022-06-21 21:53:19.364021
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('test')
    except InvalidPattern as e:
        s = str(e)
        assert isinstance(s, str), '__str__ must return a str'
        assert s == 'Invalid pattern(s) found. test', s
        assert isinstance(unicode(e), unicode), '__unicode__ must return a unicode'
    try:
        raise InvalidPattern('')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. ', str(e)
        assert unicode(e) == u'Invalid pattern(s) found. ', unicode(e)

if __name__ == '__main__':
    test_InvalidPattern___str__()

# Generated at 2022-06-21 21:53:29.503058
# Unit test for function finditer_public
def test_finditer_public():
    """test function finditer_public"""
    # if re.finditer does not exist, then this test cannot be tested
    if not getattr(re, 'finditer', False):
        return
    import random
    num_digits = 10
    string = ''.join(map(lambda x: str(random.randint(0,9)),
                         range(num_digits)))
    # string  = '1234567891'
    # string = '013791'
    # string = '137913'
    # string = '013791'
    select_digits = [1,3,7,9]
    # select_digits = [1]
    # select_digits = [1, 3, 7]
    # select_digits = [1, 3, 7, 9]
    # select_digits

# Generated at 2022-06-21 21:53:41.240425
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern should return a unicode object."""

    from bzrlib.i18n import gettext

    def _check(s):
        e = InvalidPattern(s)
        u = unicode(e) # calls e.__unicode__() which returns a unicode object
        assert isinstance(u, unicode), "%r is not an unicode object" % u

    # We test some unicode strings which contain non-ASCII characters.
    _check('foo')
    _check(gettext(u'B\xe2\x80\xa1r'))
    _check(gettext(u'Bzr\x20'))
    _check(gettext(u'Bzr\xe2\x98\x83'))

# Generated at 2022-06-21 21:53:50.307455
# Unit test for function finditer_public
def test_finditer_public():
    # Calling to re.finditer function with a string
    test_string = 'abcdabcd'
    iter_string = re.finditer('bcd', test_string)
    results_string = [x.span() for x in iter_string]
    assert results_string == [(1, 4), (5, 8)], "Error in string regex"

    # Calling to re.finditer function with a LazyRegex object
    test_lazyregex = 'abcdabcd'
    iter_lazyregex = re.finditer(LazyRegex(('bcd',)), test_lazyregex)
    results_lazyregex = [x.span() for x in iter_lazyregex]

# Generated at 2022-06-21 21:54:02.253343
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    for flags in [0, re.IGNORECASE, re.MULTILINE, re.DOTALL, re.LOCALE, re.UNICODE]:
        for pattern in ['', '.*', 'A.*', 'A.*B.*C.*']:
            lazy_regex = LazyRegex((pattern, flags))
            pickled_lazy_regex = pickle.dumps(lazy_regex)
            unpickled_lazy_regex = pickle.loads(pickled_lazy_regex)
            real_regex = _real_re_compile(pattern, flags)
            # Should be the same as the real regex
            assert real_regex == unpickled_lazy_regex
            assert real_regex.match('A') == unpickled_lazy_re

# Generated at 2022-06-21 21:54:07.552828
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test __setstate__ method of class LazyRegex."""
    lazyregex = LazyRegex(args=(), kwargs={})
    new_dict = {"args" : ("^.*$",), "kwargs" : {}}
    lazyregex.__setstate__(new_dict)
    assert lazyregex._regex_args == ("^.*$",)

# Generated at 2022-06-21 21:54:19.293217
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # Test case 1: simple message
    e = InvalidPattern("abc")
    assert repr(e) == "InvalidPattern('abc')"

    # Test case 2: message with format
    e = InvalidPattern("%(a)s %(b)s")
    assert repr(e) == "InvalidPattern('%(a)s %(b)s')"

    # Test case 3: extra arguments
    e = InvalidPattern("%(a)s %(b)s", a=1, b='2')
    assert repr(e) == "InvalidPattern('%(a)s %(b)s')"

    # Test case 4: error with format
    e = InvalidPattern("%s", "abc")
    assert repr(e) == "InvalidPattern('%s')"

    # Test case 5: error with string

# Generated at 2022-06-21 21:54:26.620915
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Check that the __setstate__ method of class LazyRegex does work"""
    l = LazyRegex(('^.+',), {'flags': re.UNICODE})
    assert l._real_regex is None
    l.__getstate__()
    assert l._real_regex is None
    l.__setstate__({
            "args": ('^.+', ),
            "kwargs": {'flags': re.UNICODE}
            })
    assert l._real_regex is None

# Generated at 2022-06-21 21:54:30.759808
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return a dictionary of the regex arguments."""
    lazy = LazyRegex(("^asdf$",), {"flags": 2 | 4})
    state = lazy.__getstate__()
    assert state['args'] == ("^asdf$",)
    assert state['kwargs'] == {"flags": 2 | 4}



# Generated at 2022-06-21 21:54:35.783052
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of class InvalidPattern"""
    try:
        raise InvalidPattern('Try to raise me')
    except InvalidPattern as e:
        assert e.msg == 'Try to raise me'
        assert unicode(e) == u'Invalid pattern(s) found. "Try to raise me"'

# Generated at 2022-06-21 21:54:54.815986
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it
    """
    # create a compiler
    pattern = LazyRegex(['(?P<name>.)(?P<value>.)'], {})
    assert pattern._real_regex is None
    assert pattern.__getattr__('groups') == 2
    # check that creating the compiled object
    # will set _real_regex to it
    assert pattern._real_regex is not None
    pattern._real_regex = None
    assert pattern.__getattr__('groups') == 2


# Generated at 2022-06-21 21:54:59.395864
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    assert_equal(LazyRegex(('abc',)).__getstate__(),
        {'args': ('abc',), 'kwargs': {}})


# Generated at 2022-06-21 21:55:05.875985
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object

    The type of the return value should be a unicode object.
    """
    pattern = InvalidPattern(msg="Test Exception Message")
    if not isinstance(pattern.__unicode__(), unicode):
        raise AssertionError(
            "Expected type 'unicode', but got '%s'." %
            pattern.__unicode__().__class__.__name__)



# Generated at 2022-06-21 21:55:12.401577
# Unit test for function lazy_compile
def test_lazy_compile():
    # test that lazy_compile works
    re.compile = _real_re_compile
    try:
        install_lazy_compile()
        re.compile = _real_re_compile
        obj = re.compile(r"foo")
        obj2 = re.compile(r"foo")
        assert obj is obj2
        assert obj.search("bar") is None
        assert obj.search("foobar") is not None
    finally:
        reset_compile()


# Generated at 2022-06-21 21:55:17.895759
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError
    install_lazy_compile()
    reset_compile()


install_lazy_compile()

# Generated at 2022-06-21 21:55:28.884951
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return the state to use when pickling.
    """
    import pickle

    expected = {'args': (r'\s+',), 'kwargs': None}
    lazy = lazy_compile(r'\s+')
    actual = lazy.__getstate__()
    assert expected == actual, \
        "__getstate__ returned %r, expected %r" % (actual, expected)
    state = lazy.__getstate__()
    pickled = pickle.loads(pickle.dumps(state))
    assert state == pickled, "__getstate__ didn't roundtrip %r %r" \
        % (state, pickled)

# Generated at 2022-06-21 21:55:32.856778
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """The method __repr__ returns a string containing the name of the class
    and a string representation of the object.

    >>> exc = InvalidPattern('a message')
    >>> exc.__repr__()
    "InvalidPattern('a message')"
    """

# Generated at 2022-06-21 21:55:35.183831
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lazy = LazyRegex()
    lazy.__setstate__({'args': 'abc'})
    expected = LazyRegex('abc')
    assert lazy == expected

# Generated at 2022-06-21 21:55:39.415677
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex."""

    global called
    called = False

    class TestLazyRegex(LazyRegex):
        """Make getattr public for testing only."""

        def __getattr__(self, attr):
            global called
            called = True
            return LazyRegex.__getattr__(self, attr)

    test_regex = TestLazyRegex()
    test_regex.test_value
    assert called

# Generated at 2022-06-21 21:55:45.889247
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    # 're' is a module, so it should have a __dict__
    # also ensure that if this has been called before that we reset first
    if not getattr(re, '__dict__', False) or "compile" in re.__dict__:
        install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError('re.compile is not the correct function')

# Generated at 2022-06-21 21:56:01.941357
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Method __getstate__() of class LazyRegex stores
       arguments and keyword arguments received in method __init__().
    """
    import pickle
    r = LazyRegex('abc', {'flags': re.I})
    d = pickle.dumps(r)
    rr = pickle.loads(d)
    assert (rr._regex_args == ('abc',))
    assert (rr._regex_kwargs == {'flags': re.I})

# Generated at 2022-06-21 21:56:12.143180
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Branch will use 'lazy_compile' instead of the original 'compile' when
    installing lazy_compile
    """
    real_re_compile = re.compile
    install_lazy_compile()
    re_compile_used = re.compile
    reset_compile()
    re_compile_restored = re.compile
    if not (real_re_compile is re_compile_restored and not 
        (real_re_compile is re_compile_used)):
        raise AssertionError("recompile not restored to the original value")


# Install our overriden compile() if asked to.
install_lazy_compile()

# Generated at 2022-06-21 21:56:22.569898
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from testtools.matchers import Equals
    from testtools import TestCase

    class TestInvalidPattern(TestCase):
        def test___eq___without_kwargs(self):
            invalid_pattern = InvalidPattern('some message')
            other = InvalidPattern('some message')
            self.assertThat(invalid_pattern, Equals(other))

        def test___eq___with_kwargs(self):
            invalid_pattern = InvalidPattern('some message', 'something')
            other = InvalidPattern('some message', 'something')
            self.assertThat(invalid_pattern, Equals(other))

        def test___eq___with_key_difference(self):
            invalid_pattern = InvalidPattern('some message', thing="something")
            other = InvalidPattern('some message', thing="something else")

# Generated at 2022-06-21 21:56:31.170944
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """eq between two InvalidPattern.

    __eq__ will return NotImplemented if the object types are different.
    If the object types are the same, __eq__ will return the comparison
    result of the dicts.
    """
    ip1 = InvalidPattern("msg1")
    ip2 = InvalidPattern("msg1")
    ip3 = InvalidPattern("msg3")
    class BogusIP(object): pass
    bip4 = BogusIP()
    ip4 = InvalidPattern("msg4")

    # Two InvalidPatterns with the same dict should be equal
    eq = ip1.__eq__(ip2)
    assert eq == True, "InvalidPatterns with the same dict should be equal"

    # Two InvalidPatterns with the different dict should be different
    eq = ip1.__eq__(ip3)

# Generated at 2022-06-21 21:56:36.751238
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a representation of the error"""
    from bzrlib.i18n import gettext
    invalid_pattern = InvalidPattern("broken regex")
    invalid_pattern._preformatted_string = gettext("broken regex")
    assert str(invalid_pattern) == "broken regex"


if __name__ == '__main__':
    test_InvalidPattern___str__()

# Generated at 2022-06-21 21:56:38.083312
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import (
        errors,
        )
    return doctest.DocTestSuite(errors)

# Generated at 2022-06-21 21:56:40.741421
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ip = InvalidPattern('test')
    if not isinstance(ip, InvalidPattern):
        return False
    if str(ip) != 'test':
        return False
    return True



# Generated at 2022-06-21 21:56:45.011793
# Unit test for function lazy_compile
def test_lazy_compile():
    """The function creates a LazyRegex, the input arguments to the function
    are passed to the LazyRegex __init__."""
    args = [u"."]
    kwargs = dict(flags=re.U)
    regex = re.compile(*args, **kwargs)
    proxy = LazyRegex(args=args, kwargs=kwargs)
    assert type(regex) == type(proxy)



# Generated at 2022-06-21 21:56:49.137488
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    from . import tests as test_suite
    from .tests import doc_test_modules
    tests = [test_suite] + list(doc_test_modules())
    for test in tests:
        doctest.testmod(test)