

# Generated at 2022-06-21 21:47:14.855577
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test LazyRegex class.

    LazyRegex.__init__ must create a proxy which should receive the
    arguments provided to its constructor and pass them to the real
    re.compile function.
    """
    # Capture re.compile
    global _real_re_compile
    re_compile_backup = _real_re_compile
    global _real_re_compile
    _real_re_compile_results = []
    def my_re_compile(pattern, flags=0):
        _real_re_compile_results.append((pattern, flags))
        return _real_re_compile(pattern, flags)
    _real_re_compile = my_re_compile
    reset_compile()
    re_compile_results = []

# Generated at 2022-06-21 21:47:25.397961
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.trace import mutter, note
    msg = 'test message'
    exc = InvalidPattern(msg)
    exc._preformatted_string = msg
    note(str(exc))
    note(unicode(exc))
    msg = 'message in unicode'
    exc = InvalidPattern(msg)
    exc._fmt = msg
    note(str(exc))
    note(unicode(exc))
    msg = 'message in unicode'
    exc = InvalidPattern(msg)
    note(str(exc))
    note(unicode(exc))
    msg = 'test msg %(test)s test %(test1)s'
    exc = InvalidPattern(msg)
    exc._fmt = msg
    exc._test = 'test1'

# Generated at 2022-06-21 21:47:38.006000
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() works as advertised.

    The original value of re.compile is stored and then restored. So
    these tests shouldn't have any side effects.
    """
    from bzrlib import tests
    import re

    original_compile = re.compile

    # Test that install_lazy_compile() switches to a LazyRegex object for
    # single argument matches
    install_lazy_compile()
    res = re.compile('a')
    tests.TestCaseWithTransport.assertIsInstance(res, LazyRegex)
    tests.TestCaseWithTransport.assertEqual(0, len(res._real_regexs))
    reset_compile()
    res = re.compile('a')

# Generated at 2022-06-21 21:47:50.905717
# Unit test for function lazy_compile
def test_lazy_compile():
    r = re.compile('a')
    r = re.compile('a', re.I)
    r = re.compile('a', re.I, re.L)
    r = re.compile('a', re.I, re.L, re.M)
    r = re.compile('a', re.I, re.L, re.M, re.S)
    r = re.compile('a', re.I, re.L, re.M, re.S, re.U)
    r = re.compile('a', re.I, re.L, re.M, re.S, re.U, re.X)
    lr = re.compile('a')
    lr = re.compile('a', re.I)

# Generated at 2022-06-21 21:47:52.040131
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = LazyRegex(('\d+',))
    assert r.groupindex == {}



# Generated at 2022-06-21 21:48:02.621565
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # Override the real compile method with the lazy one
    install_lazy_compile()

    # Create a new regex using the lazy compile method which should return a
    # LazyRegex object.
    r = re.compile("foo")

    # All of the attributes on a proxy object should be present, but they
    # should point to None
    for attr in LazyRegex._regex_attributes_to_copy:
        assert getattr(r, attr) is None

    # Compiling a regex with invalid syntax should create an exception
    # containing the original regex
    try:
        re.compile("[")
    except InvalidPattern as e:
        assert e.msg.startswith('"[')

    # First re.compile() should return a LazyRegex object

# Generated at 2022-06-21 21:48:14.294136
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Pickling and unpickling of LazyRegex objects works.

    This tests that LazyRegex objects can be pickled and unpickling works.
    """

    lazy_regex = LazyRegex(('a.*b',), dict(flags=re.IGNORECASE))

    # pickle and unpickle object to check if object can be pickled
    import cPickle
    pickled_object = cPickle.dumps(lazy_regex)
    unpickled_lazy_regex = cPickle.loads(pickled_object)

    # compare lazy_regex and unpickled_lazy_regex

# Generated at 2022-06-21 21:48:18.235072
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    err = InvalidPattern('Quantum fuzziness detected')
    assert repr(err) == "InvalidPattern('Quantum fuzziness detected')"
    err2 = InvalidPattern('Quantum fuzziness detected\nWhat do I do?')
    assert repr(err2) == "InvalidPattern('Quantum fuzziness detected\\nWhat do I do?')"

# Generated at 2022-06-21 21:48:30.846391
# Unit test for function finditer_public
def test_finditer_public():
    """Test that finditer_public calls finditer on the pattern."""
    pattern = LazyRegex()
    string = 'aaa'
    record = []

    def finditer(self, string):
        record.append(string)
        return []
    pattern.finditer = finditer

    result = re.finditer(pattern, string)
    # result must be an empty iterable which returns an empty list on
    # subsequent calls.
    result = list(result)
    result2 = list(result)
    result3 = list(result2)

    # We expect to be called once with the string.
    self.assertEqual([string], record)
    # We expect an empty list on all subsequent calls
    self.assertEqual([], result)
    self.assertEqual([], result2)

# Generated at 2022-06-21 21:48:41.396175
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that the constructor of LazyRegex sets the slots correctly."""
    args = ('^root', re.MULTILINE)
    kwargs = {'flags': re.MULTILINE}
    lazy_regex = LazyRegex(args, kwargs)
    # we're calling the constructor of LazyRegex directly, so we have to
    # set the _real_re_compile attribute by hand.
    lazy_regex._real_re_compile = _real_re_compile
    assert(lazy_regex._regex_args == args)
    assert(lazy_regex._regex_kwargs == kwargs)
    # The _real_regex attribute should initially be None
    assert(lazy_regex._real_regex is None)
    # We should also have a

# Generated at 2022-06-21 21:48:48.888690
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that re.compile() actually returns a LazyRegex object."""
    install_lazy_compile()
    r = re.compile('\d+')
    assert isinstance(r, LazyRegex)



# Generated at 2022-06-21 21:48:51.560752
# Unit test for function reset_compile
def test_reset_compile():
    """The function reset_compile can be run multiple times"""
    install_lazy_compile()
    reset_compile()


_real_re_compile('foo')
del _real_re_compile

# Generated at 2022-06-21 21:48:57.680803
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should return a string not a unicode object"""

    # create an exception InvalidPattern

# Generated at 2022-06-21 21:49:01.099440
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """__init__ sets up InvalidPattern objects properly."""
    ip = InvalidPattern('foo')
    assert isinstance(ip, InvalidPattern)
    assert ip.msg == 'foo'
    assert str(ip) == 'foo'

# Generated at 2022-06-21 21:49:13.552267
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Verify constructor behavior
    lazy_regex = LazyRegex()
    assert(lazy_regex._real_regex is None)
    assert(lazy_regex._regex_args == ())
    assert(lazy_regex._regex_kwargs == {})
    # Now call the constructor with arguments
    lazy_regex = LazyRegex(('/usr', ), {'flags':re.I})
    assert(lazy_regex._real_regex is None)
    assert(lazy_regex._regex_args == ('/usr', ))
    assert(lazy_regex._regex_kwargs == {'flags':re.I})


# Generated at 2022-06-21 21:49:27.522057
# Unit test for function finditer_public
def test_finditer_public():
    from cStringIO import StringIO
    testpattern = '^[A-Za-z0-9_]+$'
    teststring = "abcd_"

    def iter_to_str(it):
        s = StringIO()
        s.write('[')
        for elem in it:
            s.write('"' + elem.group(0) + '", ')
        s.write(']')
        return s.getvalue()

    if getattr(re, 'finditer', False):
        # This test is to verify that public re.finditer function find the same
        # match as the internal one.
        pattern = re.compile(testpattern)
        public_finditer = re.finditer(pattern, teststring)
        private_finditer = pattern.finditer(teststring)
        public_find

# Generated at 2022-06-21 21:49:40.655299
# Unit test for function lazy_compile
def test_lazy_compile():
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestNotApplicable

    # TODO: figure out how to get this test to run under py3k
    try:
        unicode
    except NameError:
        raise TestNotApplicable('No unicode under python3k')

    class TestRegex(TestCase):

        def test_regex_ascii(self):
            # Test that we can create a LazyRegex object that is really
            # a regex, and uses the same attributes as a real regex
            p1 = re.compile(b'^bzr$')
            p2 = re.compile(b'^bzr$')
            # P1 == P2 because they're both compiled regexes
            self.assertEqual(p1, p2)
            lp

# Generated at 2022-06-21 21:49:43.122927
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return the message"""
    ip = InvalidPattern('Message')
    # pass marker
    assert ip.__str__() == 'Message'

# Generated at 2022-06-21 21:49:48.445227
# Unit test for function reset_compile
def test_reset_compile():
    test_string = 'aaabbbaaa'
    lazy_re = re.compile('aaa')
    reset_compile()
    re_instance = re.compile('aaa')
    match = re_instance.match(test_string)
    lazy_match = lazy_re.match(test_string)

# Generated at 2022-06-21 21:50:00.343611
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
  from bzrlib.tests import TestCase

  class LazyRegex___getstate__TestCase(TestCase):
    def setUp(self):
        super(LazyRegex___getstate__TestCase, self).setUp()

        self.lr = LazyRegex()

    def test_LazyRegex__getstate__(self):
        #  __getstate__() -> {'args': self._regex_args,
        #                     'kwargs': self._regex_kwargs,}

        self.assertEqual({'args': self.lr._regex_args,
                          'kwargs': self.lr._regex_kwargs,
                          }, self.lr.__getstate__())

  return LazyRegex___getstate__TestCase


# Generated at 2022-06-21 21:50:16.445533
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    # This test assumes that the default encoding is utf-8, which is almost
    # always true. It'll be skipped if not.
    try:
        unicode('\xc0', 'utf-8')
    except UnicodeDecodeError:
        raise TestSkipped("The default encoding is not utf-8.")
    # Make sure InvalidPattern.__str__ returns a str object
    p = InvalidPattern("test")
    if not isinstance(str(p), str):
        raise AssertionError("__str__ does not return a str object")
    # Make sure InvalidPattern.__str__ works for non-ASCII unicode strings
    p = InvalidPattern(unicode("invalid pattern \xc0", "utf-8"))

# Generated at 2022-06-21 21:50:27.146444
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore the state of pickled LazyRegexs"""
    lr = LazyRegex()
    # This will trigger a collapse
    lr.match('a')
    # Sanity check
    assert isinstance(lr._real_regex, re._pattern_type)

    pickled = pickle.dumps(lr)
    restored = pickle.loads(pickled)
    # Sanity check
    assert isinstance(restored, LazyRegex)
    # This will trigger a collapse
    restored.match('a')
    assert isinstance(restored._real_regex, re._pattern_type)

# Generated at 2022-06-21 21:50:32.798717
# Unit test for function reset_compile
def test_reset_compile():
    """Unit test for reset_compile"""
    class MockRegex(object):
        pass
    re.compile = MockRegex
    reset_compile()
    assert re.compile == _real_re_compile
    re.compile = MockRegex
    reset_compile()
    assert re.compile == _real_re_compile

# Generated at 2022-06-21 21:50:36.883543
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """New method __repr__ of class InvalidPattern returns correctly."""

    # Create a message for InvalidPattern object
    msg = "Invalid pattern(s) found. %(msg)s"

    # Create InvalidPattern object with the message
    obj = InvalidPattern(msg)

    # Get the __repr__() of the InvalidPattern object
    r = obj.__repr__()

    # Get the length of the returned string
    leng = len(r)

    # Check whether the returned string has correct length
    assert (leng == 53), \
        "test_InvalidPattern___repr__(): Invalid length of returned string."



# Generated at 2022-06-21 21:50:48.920418
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    regex_object = re.compile(r'\w[\w.-]*@\w[\w.-]*\w\.\w{2,3}')
    regex_pickled_object = regex_object.__getstate__()
    assert regex_object == {'args': (r'\w[\w.-]*@\w[\w.-]*\w\.\w{2,3}',), 'kwargs': {}}
    regex_object = LazyRegex()
    regex_object.__setstate__(regex_pickled_object)
    assert regex_object._regex_args == (r'\w[\w.-]*@\w[\w.-]*\w\.\w{2,3}',)

# Generated at 2022-06-21 21:50:55.933276
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Ensure that LazyRegex works as expected."""
    lr = LazyRegex(r'^test$')
    assert isinstance(lr, LazyRegex)
    assert lr._real_regex is None
    assert lr._regex_args == (r'^test$',)
    assert lr._regex_kwargs == {}


if __name__ == "__main__":
    test_LazyRegex()

# Generated at 2022-06-21 21:51:03.935788
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern"""
    try:
        e = InvalidPattern('foo')
        assert repr(e) == 'InvalidPattern(foo)'
        e = InvalidPattern('foo\tbar\n baz')
        assert repr(e) == 'InvalidPattern(\'foo\tbar\n baz\')'
        e = InvalidPattern(u'foo\tbar\n baz')
        assert repr(e) == 'InvalidPattern(u\'foo\tbar\n baz\')'
    except:
        raise


# Generated at 2022-06-21 21:51:11.784551
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__() sets the right _regex_args and _regex_kwargs."""
    lazy_regex = LazyRegex(args=('.',), kwargs={'flags': re.DOTALL})
    state = {
        "args": ('^.*$',),
        "kwargs": {'flags': re.DOTALL | re.IGNORECASE},
        }
    lazy_regex.__setstate__(state)
    assert lazy_regex._regex_args == ('^.*$',)
    assert lazy_regex._regex_kwargs == {'flags': re.DOTALL | re.IGNORECASE}

# Generated at 2022-06-21 21:51:17.273969
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test the repr method of InvalidPattern
    """
    from bzrlib.lazy_regex import InvalidPattern
    import re
    try:
        re.compile("[")
    except re.error as e:
        ip = InvalidPattern(e)
        assert repr(ip) == "InvalidPattern('[',)"

# Generated at 2022-06-21 21:51:22.790305
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    install_lazy_compile()
    reset_compile()
    reset_compile()


if __name__ == '__main__':
    test_reset_compile()

# Generated at 2022-06-21 21:51:34.730741
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method InvalidPattern.__str__()

    InvalidPattern is supposed to return a string which is not a unicode string.
    """
    ip = InvalidPattern('msg')
    s = str(ip)
    assert isinstance(s, str)

    ip = InvalidPattern('msg')
    s = unicode(ip)
    assert isinstance(s, unicode)

# Generated at 2022-06-21 21:51:45.261452
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ of LazyRegex returns the requested value."""
    def func(pattern, attr):
        """Return the value of the attribute called attr."""
        proxy = LazyRegex((pattern,))
        return getattr(proxy, attr)
    # We first test the function func with an existing attribute.
    # This attribute must be found in the list _regex_attributes_to_copy.
    assert func('.', '__copy__') is not None
    # We also check the return of an attribute that will be requested after
    # the proxy has been compiled.
    assert func('.', 'search') is not None
    # Test that LazyRegex raises an exception
    # if the requested attribute doesn't exist.

# Generated at 2022-06-21 21:51:51.532543
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ finds and returns attributes of the real regex."""

    # Create a regex which matches 'a' or 'b'.
    regex = LazyRegex([r'[ab]'])

    # Verify that a property of the regex can be found.
    assert regex.groups == 0

    # Verify that a method of the regex can be found.
    assert regex.search('b') is not None

# Generated at 2022-06-21 21:51:59.517364
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a non unicode string"""
    import doctest
    from bzrlib.tests.regex_utils import InvalidPattern
    from bzrlib import tests
    import sys
    doctest.DocFileCase(tests.__file__,
                        '../../doc/developers/api-design.txt',
                        optionflags=doctest.ELLIPSIS,
                        globs={'InvalidPattern': InvalidPattern,
                               'sys': sys,
                               })

# Generated at 2022-06-21 21:52:12.388497
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests.blackbox import TestCaseWithTransport
    from bzrlib import osutils

    class TestInvalidPattern(TestCaseWithTransport):

        def test_eq(self):
            def get_exception(msg):
                e = InvalidPattern(msg)
                return e

            def check_exception(msg, msg2):
                e = get_exception(msg)
                e2 = get_exception(msg2)
                self.assertTrue(e == e2)
                e = get_exception(msg)
                e2 = get_exception(msg)
                self.assertTrue(e == e2)

            def check_exception_not_equal(msg, msg2):
                e = get_exception(msg)
                e2 = get_exception(msg2)
               

# Generated at 2022-06-21 21:52:18.393920
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test InvalidPattern.__unicode__

    A simple use case: InvalidPattern will be fully instantiated before it is
    printed.
    """
    e = InvalidPattern('msg1')
    # Check that:
    # * __str__() and __unicode__() return the same
    # * the result is unicode
    # * the result contains the provided message
    u = unicode(e)
    assert (unicode(u) == unicode(str(u)))
    assert isinstance(u, unicode)
    assert (u.find('msg1') != -1)

    # Same test but with a custom format.
    e._fmt = 'msg2 %(msg)s'
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-21 21:52:22.173828
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for InvalidPattern.__unicode__"""
    error = InvalidPattern('Invalid pattern(s) found. a')
    assert unicode(error) == u'Invalid pattern(s) found. a'
    assert str(error) == 'Invalid pattern(s) found. a'

# Generated at 2022-06-21 21:52:28.890710
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    gettext("""\
Invalid pattern(s) found. %(msg)s
""").encode('UTF-8')
    e = InvalidPattern('foo')
    assert str(e) == 'Invalid pattern(s) found. foo'

# Generated at 2022-06-21 21:52:38.508547
# Unit test for function finditer_public
def test_finditer_public():
    """Test function finditer_public."""
    import re
    r = lazy_compile('.')
    assert getattr(r, 'flags', 0) == 0
    s = 'abc'
    l = [i.group() for i in re.finditer(r, s)]
    assert l == ['a', 'b', 'c']

# Some libraries calls re.sub which fails if receives a LazyRegex.
# We now monkey-patch re.sub because some code uses it to compile a pattern
# (that also happens in our own code) and only later uses the result.
if getattr(re, 'sub', False):
    def sub_public(pattern, repl, string, count=0, flags=0):
        if isinstance(pattern, LazyRegex):
            return pattern.sub(repl, string, count)
       

# Generated at 2022-06-21 21:52:42.284453
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    a_lazy_regex = LazyRegex(("[0-9]+",), {"flags": re.LOCALE})
    state = a_lazy_regex.__getstate__()
    if not isinstance(state, dict):
        raise AssertionError("__getstate__ did not return a dict.")
    expected_state = {"args": ("[0-9]+",), "kwargs": {"flags": re.LOCALE}}
    if state != expected_state:
        raise AssertionError("__getstate__ did not return "
                             "the expected dict.")



# Generated at 2022-06-21 21:52:51.879106
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile actually installs a proxy"""
    # Undo any previous installs
    reset_compile()
    # Ensure we start with the real implementation
    assert re.compile is _real_re_compile
    # Install the proxy
    install_lazy_compile()
    assert re.compile is not _real_re_compile
    assert re.compile('foo') is not None
    # Make sure we don't do a double install
    install_lazy_compile()
    assert re.compile is not _real_re_compile
    assert re.compile('foo') is not None

# Generated at 2022-06-21 21:52:59.799807
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test that InvalidPattern instances with same content compare equal.
    """
    err1 = InvalidPattern("foo")
    err2 = InvalidPattern("foo")
    assert err1 is not err2
    assert err1 == err2
    assert err2 == err1
    assert not (err1 != err2)
    assert not (err2 != err1)

    err1.bar = 37
    assert err1 is not err2
    assert err1 != err2
    assert err2 != err1
    assert not (err1 == err2)
    assert not (err2 == err1)

    err2.bar = 37
    assert err1 is not err2
    assert err1 == err2
    assert err2 == err1
    assert not (err1 != err2)
    assert not (err2 != err1)

    err1.b

# Generated at 2022-06-21 21:53:06.359836
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex"""
    lr = LazyRegex(args=(r"\d[\d ]\d",), kwargs={"flags": 0})
    assert lr.__getstate__() == {"args": (r"\d[\d ]\d",), "kwargs": {"flags": 0}}

# Generated at 2022-06-21 21:53:16.780809
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    from bzrlib import __file__ as bzrlib_path
    from bzrlib.tests.blackbox import ExternalBase

    class TestInvalidPattern(ExternalBase):

        def test_str_contains_invalid_pattern_msg(self):
            from bzrlib.errors import InvalidPattern
            msg = "Invalid pattern(s) found. 'a' nothing to repeat at position 0"
            err = InvalidPattern(msg)
            self.assertContainsRe(str(err), '^Invalid pattern\(s\) found\..*')

    TestInvalidPattern('test_str_contains_invalid_pattern_msg')

# Generated at 2022-06-21 21:53:25.784098
# Unit test for function reset_compile
def test_reset_compile():
    import bzrlib.tests
    bzrlib.tests.TestCase.assertEquals(_real_re_compile, re.compile)
    install_lazy_compile()
    bzrlib.tests.TestCase.assertNotEquals(_real_re_compile, re.compile)
    reset_compile()
    bzrlib.tests.TestCase.assertEquals(_real_re_compile, re.compile)
    reset_compile()
    bzrlib.tests.TestCase.assertEquals(_real_re_compile, re.compile)

# Generated at 2022-06-21 21:53:37.281906
# Unit test for function finditer_public
def test_finditer_public():
    from .. import tests

    tests.SymbolVersioningTestCase.setUp(None)
    re._finditer = re.finditer
    import __builtin__
    def _finditer(pattern, string, flags=0):
        if isinstance(pattern, LazyRegex):
            return pattern.finditer(string)
        else:
            return _real_re_compile(pattern, flags).finditer(string)
    __builtin__.__dict__['re'].finditer = _finditer

# Generated at 2022-06-21 21:53:47.200949
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from cStringIO import StringIO
    from bzrlib.i18n import lazy_gettext as _
    # Regex with a syntax error.
    regex = r'(?P<A>x'
    # Translated error message.
    msg = _('%s: unbalanced parenthesis') % (regex,)
    # Instantiate an InvalidPattern.
    e = InvalidPattern(msg)
    # Redirect standard output to a StringIO object
    sio = StringIO()
    old_stdout, sys.stdout = sys.stdout, sio
    # This is what we want to "print".

# Generated at 2022-06-21 21:53:49.069486
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    ip = InvalidPattern("regex compilation failed")
    assert(type(ip.__unicode__()) == type(u''))

# Generated at 2022-06-21 21:53:54.853948
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # 'msg' must be added as attribute while creating an instance
    i = InvalidPattern('sample message')
    assert isinstance(unicode(i), unicode)
    assert isinstance(str(i), str)
    assert i._get_format_string() is None
    i = InvalidPattern('new %(msg)s')
    assert i._get_format_string() == u'new %(msg)s'

# Generated at 2022-06-21 21:53:57.930447
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    try:
        re_exp = re.compile('a(b)c')
        assert isinstance(re_exp, LazyRegex)
    finally:
        reset_compile()

# Generated at 2022-06-21 21:54:06.520178
# Unit test for function finditer_public
def test_finditer_public():
    _real_re_compile = re.compile
    install_lazy_compile()
    re.compile = _real_re_compile
    re.finditer('.', '1')

# Generated at 2022-06-21 21:54:09.769874
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError("install_lazy_compile has not installed lazy_compile")



# Generated at 2022-06-21 21:54:20.217554
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('msg')
    e2 = InvalidPattern('msg')
    e3 = InvalidPattern('msg2')
    e4 = InvalidPattern('msg3')
    assert e1 == e1
    assert e1 == e2
    assert e1 != e3
    assert e1 != e4
    assert e2 == e1
    assert e2 == e2
    assert e2 != e3
    assert e2 != e4
    assert e3 != e1
    assert e3 != e2
    assert e3 == e3
    assert e3 != e4
    assert e4 != e1
    assert e4 != e2
    assert e4 != e3
    assert e4 == e4

# Generated at 2022-06-21 21:54:25.673982
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    args = ('^(?a)',)
    kwargs = {'flags': re.IGNORECASE}
    lazy_re = LazyRegex(args, kwargs)
    assert lazy_re.__getstate__() == {
        "args": args,
        "kwargs": kwargs
        }



# Generated at 2022-06-21 21:54:32.704780
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() works"""
    from bzrlib.tests import TestCase

    # First we need to make sure that lazy_compile doesn't recurse
    # to itself
    reset_compile()

    class FakeLocalRe(object):
        compile = lazy_compile

    old_re = re.compile
    try:
        re.compile = FakeLocalRe.compile
        install_lazy_compile()
        self.assertIs(re.compile, lazy_compile)
        reset_compile()
        self.assertIs(re.compile, old_re)
    finally:
        re.compile = old_re

# Generated at 2022-06-21 21:54:44.466623
# Unit test for function finditer_public
def test_finditer_public():
    regex1 = re.compile('abc')
    regex2 = re.compile('xyz')
    r = re.compile('ab')
    sample1 = 'abab'
    sample2 = 'xyzxyz'
    sample3 = 'xyz'

    result = re.finditer(regex1, sample1)
    assert(None != result)
    assert(result.next().group() == 'abc')

    result = re.finditer(regex1, sample2)
    assert(None != result)
    try:
        result.next()
    except Exception as e:
        # we expect to get StopIteration here
        assert isinstance(e, StopIteration)

    result = re.finditer(regex2, sample2)
    assert(None != result)

# Generated at 2022-06-21 21:54:51.047497
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__

    Method __repr__ of class InvalidPattern should return the string:
    "%s(%s)" % (self.__class__.__name__, str(self))
    that is the name of the class and the repr output of str(self).
    """

    from bzrlib.i18n import gettext
    gettext("Test")

    msg = "Test message for InvalidPattern"
    pattern_invalid = InvalidPattern(msg)
    assert("InvalidPattern(" + repr(msg) + ")" == pattern_invalid.__repr__())


# Generated at 2022-06-21 21:54:57.576955
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the install_lazy_compile function"""
    import re
    install_lazy_compile()
    try:
        pattern = re.compile('foobar')
        assert isinstance(pattern, LazyRegex)
        # A proxy object has no _sre attribute
        # until it is actually compiled
        assert not hasattr(pattern, '_sre')
        # Accessing a member should cause compilation
        for x in pattern.findall('foo'):
            pass
        assert hasattr(pattern, '_sre')
        # The compiled object should now be accessible
        assert pattern._sre is not None
    finally:
        reset_compile()


# Generated at 2022-06-21 21:55:09.883517
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for LazyRegex.__getattr__."""
    # We have to intercept the call to re.compile to avoid calling
    # the real method.
    re.compile = dummy_compile

    def get_real_method(object, method_name):
        return getattr(object, '_real_regex').__getattribute__(method_name)

    def test(method_name):
        """Unit test for the method *method_name* of class LazyRegex."""
        # Build a dummy regex object
        regex = LazyRegex()
        # Build the method to call
        method = getattr(regex, method_name)
        # Call the method.
        result = method()
        # Check that the method has been called on the real object.

# Generated at 2022-06-21 21:55:20.928688
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile restores re.compile

    It is a little unsatisfying that this test can't happen without
    forking a process, but we need to confirm that reset_compile
    actually does remove its own changes, without the tester having
    called install_lazy_compile() themselves.
    """
    from bzrlib.tests import TestCase, TestCaseInTempDir
    class TestResetCompile(TestCaseInTempDir):

        def test_reset_compile(self):
            from subprocess import Popen, PIPE
            # We want to test that reset_compile really does restore
            # the original re.compile, so we fork and do everything in
            # the child process. We don't want to test the behaviour of
            # re.compile, so we fork and then just check we didn't hit


# Generated at 2022-06-21 21:55:32.709430
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for equality of two InvalidPatterns"""
    e = InvalidPattern('foobar')
    e2 = InvalidPattern('foobar')
    e3 = InvalidPattern('foo')
    e4 = InvalidPattern(e)
    assert e == e
    assert e == e2
    assert not (e == e3)
    assert e == e4
    assert e != e3
    assert e != object()

# Generated at 2022-06-21 21:55:38.148328
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that the proxies to the methods of the real regex are evaluating
    correctly.
    """
    lr = LazyRegex(args=("a",))
    assert lr.match("aaa")
    assert lr.match("baa") is None
    lr = LazyRegex(args=("a", re.I))
    assert lr.match("AAA")
    assert lr.match("BAA") is None



# Generated at 2022-06-21 21:55:44.334280
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('a')
    e2 = InvalidPattern('a')
    e3 = InvalidPattern('b')

    assert e1 == e2
    assert e2 == e1
    assert not(e1 == e3)
    assert not(e3 == e1)
    assert not(e2 == e3)
    assert not(e3 == e2)

# Generated at 2022-06-21 21:55:49.586577
# Unit test for function lazy_compile
def test_lazy_compile():
    s = 'some.*string'
    try:
        lazy_compile(s)
    except re.error as e:
        # raise InvalidPattern instead of re.error as this gives a
        # cleaner message to the user.
        raise InvalidPattern('"' + s + '" ' +str(e))

# Generated at 2022-06-21 21:55:55.965559
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern"""
    import doctest
    # Example 1
    ex1 = InvalidPattern("foo")
    # Test
    __tracebackhide__ = True
    r = doctest._ellipsis_match(repr(ex1))
    # Verification
    if r == "InvalidPattern(foo)":
        pass
    else:
        raise AssertionError(r)


# Generated at 2022-06-21 21:56:02.606515
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import unittest
    class TestCase(unittest.TestCase):
        """Test case for method __str__ of class InvalidPattern."""
        def test_valid_pattern(self):
            """Test with valid pattern"""
            try:
                lazy_compile('(', 'n')
            except InvalidPattern as e:
                self.assertTrue(str(e))

        def test_invalid_pattern(self):
            """Test with invalid pattern"""
            try:
                lazy_compile('(')
            except InvalidPattern as e:
                self.assertTrue(str(e))
    unittest.main(defaultTest="TestCase")

# Generated at 2022-06-21 21:56:07.057697
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod()


# So long as we're not testing, install lazy_compile as the default
# compile
if __name__ != '__main__':
    install_lazy_compile()

# Generated at 2022-06-21 21:56:18.452276
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    if re.compile is not _real_re_compile:
        raise ValueError("reset_compile() did not restore the original re.compile function")


# The LazyRegex class must have the same interface as the _sre.SRE_Pattern
# object, otherwise we would get an AttributeError when that object is
# subclassed and looked up from the proxy object.  For example,
# re.MatchObject.start() -> re.MatchObject.string -> re.compile().search()
# -> LazyRegex.search() -> LazyRegex.collapse() -> LazyRegex.start() ->
# AttributeError.
#
# This test is also a regression test for
# https://bugs.launchpad.net/bzr/+bug/65

# Generated at 2022-06-21 21:56:22.633711
# Unit test for function finditer_public
def test_finditer_public():
    # re.finditer(pattern, string)
    assert re.finditer('.*', 'test') is not None
    # re.finditer(pattern, string, flags=0)
    assert re.finditer('.*', 'test', flags=0) is not None


# Some 3rd party libraries calls re.compile which fails if receives
# a LazyRegex.

# Generated at 2022-06-21 21:56:25.696370
# Unit test for function reset_compile
def test_reset_compile():
    """Unit test for function reset_compile"""
    f = re.compile
    install_lazy_compile()
    reset_compile()
    assert f is re.compile, (f, re.compile)

# Generated at 2022-06-21 21:56:49.952240
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Method __setstate__ restores the state from the serialized state"""
    testre = re.compile("test regex")
    serialized_state = testre.__getstate__()

    copy_testre = re.compile()
    copy_testre.__setstate__(serialized_state)
    # test if compiled regex is the same as testre
    assert testre.search("test regex"), "test regex must match itself"
    assert copy_testre.search("test regex"), "test regex must match itself"