

# Generated at 2022-06-21 21:46:58.379119
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPatter.__repr__() returns a string with the class name, and the
    parameter string of the exception.
    """
    try:
        raise InvalidPattern("Some message")
    except InvalidPattern as e:
        assert repr(e) == "InvalidPattern('Some message')"


# Generated at 2022-06-21 21:47:06.868405
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    my_regex = LazyRegex(args=('a', 10), kwargs={'I':'-'})
    state = my_regex.__getstate__()
    assert state['args'] == ('a', 10)
    assert state['kwargs'] == {'I':'-'}

# Generated at 2022-06-21 21:47:12.847846
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__() should  return True but not raise an exception."""
    # This test shows that the method __eq__ of class InvalidPattern
    # behaves correctly. The following method call should return True but
    # should not raise a TypeError.
    assert InvalidPattern('Detail message.') == InvalidPattern('Detail message.')



# Generated at 2022-06-21 21:47:21.417754
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    test_data = [
        (["^(a|b|c)+$", 0], LazyRegex([r"^(a|b|c)+$", 0])),
        (["^(a|b|c)+$", re.IGNORECASE], LazyRegex([r"^(a|b|c)+$", re.IGNORECASE])),
        ]

    for (args, expected) in test_data:
        lazy_regex = LazyRegex()
        lazy_regex.__setstate__({"args": args, "kwargs": {}})
        assert(lazy_regex == expected)



# Generated at 2022-06-21 21:47:24.252375
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class TestException(Exception):
        _fmt = "This is a test"

    try:
        raise TestException()
    except TestException as e:
        str(e)

# Generated at 2022-06-21 21:47:27.998009
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Tests LazyCompile.__getstate__()"""
    r = lazy_compile(u'^foo$', re.UNICODE)
    state = r.__getstate__()

    assert state == {'args': (u'^foo$', re.UNICODE), 'kwargs': {}}, state



# Generated at 2022-06-21 21:47:32.395885
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern"""
    import doctest
    doctest.run_docstring_examples(InvalidPattern.__eq__, globals(),
                                   name='InvalidPattern.__eq__')

# Generated at 2022-06-21 21:47:34.953919
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__(self, attr)"""
    proxy = LazyRegex(['^a.b$'])
    value = proxy.split('a*b')
    expected_value = ['a*b']
    assert value == expected_value, \
        'actual value: %r\nexpected value:%r' % (value, expected_value)



# Generated at 2022-06-21 21:47:44.351664
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test InvalidPattern.__eq__
    """
    # Check if two InvalidPattern objects are equal.
    exception = InvalidPattern('Invalid pattern(s) found. msg')
    exception2 = InvalidPattern('Invalid pattern(s) found. msg')
    assert exception == exception2
    # Check if two InvalidPattern objects are not equal.
    exception2 = InvalidPattern('Invalid pattern(s) found. msg2')
    assert exception != exception2
    # Check if an InvalidPattern object is not equal to something else.
    exception = InvalidPattern('Invalid pattern(s) found. msg')
    assert exception != 'Invalid pattern(s) found. msg'
    # Check if an InvalidPattern object is equal to itself.
    assert exception == exception
    # Check if an InvalidPattern object is equal to something else (None).
    assert exception != None
    # Check if an Invalid

# Generated at 2022-06-21 21:47:55.752514
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile function

    This function does not test that the _regex_attributes_to_copy are working
    correctly -- that is tested by the LazyRegexTest.test_match test.
    """
    import doctest, re
    from bzrlib.tests import TestCase
    from cStringIO import StringIO

    class TestLazyRegex(TestCase):
        """Test LazyRegex."""

        def test_match(self):
            """Test a simple match."""
            regular_re = r'a(b*)(c*)'

            # Test simple compile
            lazy_pattern = lazy_compile(regular_re)
            self.assertEqual(lazy_pattern._regex_args, (regular_re,))

# Generated at 2022-06-21 21:48:05.247117
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test if the returned state of LazyRegex.__getstate__ is correct"""
    state = LazyRegex(('k(.*)',), {'flags': 3}).__getstate__()

# Generated at 2022-06-21 21:48:15.061072
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # - object without a _fmt attribute
    e = InvalidPattern(msg='abc')
    got = unicode(e)
    assert got == u'Unprintable exception InvalidPattern: dict={\'msg\': \'abc\'}'
    # - object with a _fmt attribute
    e = InvalidPattern(msg='abc')
    e._fmt ='%(msg)s'
    got = unicode(e)
    assert got == u'abc'
    class E(InvalidPattern):
        def _get_format_string(self):
            return u'%(msg)s'
    e = E(msg='abc')
    got = unicode(e)
    assert got == u'abc'

# Generated at 2022-06-21 21:48:18.635450
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Testing method __repr__ of class InvalidPattern"""
    err = InvalidPattern('test message')
    assert repr(err) == 'InvalidPattern(\'test message\')'



# Generated at 2022-06-21 21:48:22.672890
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern must return a str."""
    err = InvalidPattern(msg='test')
    assert(isinstance(str(err), str))

# Generated at 2022-06-21 21:48:33.905023
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib import i18n
    from bzrlib.i18n import gettext
    from bzrlib.tests import TestCase
    i18n.install_gettext_translations(write_mo=True)
    i18n.enable_i18n()
    # Try with a non-translated string
    try:
        raise InvalidPattern('Repository path is not a valid pathname')
    except InvalidPattern as e:
        msg = str(e)
    TestCase.assertEqual(
        "Repository path is not a valid pathname",
        msg,
        "Failed to raise InvalidPattern with a non-translated message")
    # Try with a translated string

# Generated at 2022-06-21 21:48:39.714721
# Unit test for function finditer_public
def test_finditer_public():
    test_string = "aabccab"
    # LazyRegex
    pattern = LazyRegex(("a",))
    assert len(list(re.finditer(pattern, test_string))) == 4
    # _sre.SRE_Pattern
    pattern = re.compile("[cb]")
    assert len(list(re.finditer(pattern, test_string))) == 3

# Generated at 2022-06-21 21:48:50.898713
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase

    class TestInvalidPattern___eq__(TestCase):

        def test_fails_on_different_classes(self):
            e1 = InvalidPattern(u"test")
            e2 = ValueError(u"test")
            self.assertIs(NotImplemented, e1.__eq__(e2))

        def test_fails_on_different_classes_with_inheritance(self):
            e1 = InvalidPattern(u"test")
            e2 = ValueError(u"test")
            class SubValueError(ValueError):
                pass
            e3 = SubValueError(u"test")
            self.assertIs(NotImplemented, e1.__eq__(e3))


# Generated at 2022-06-21 21:48:59.230166
# Unit test for function reset_compile
def test_reset_compile():
    import re
    from bzrlib.lazy_re import (lazy_compile, reset_compile)
    # This test is only valid if the initial compile function isn't
    # already overridden to be lazy_compile
    assert re.compile != lazy_compile
    assert re.compile != lazy_compile
    # This shouldn't raise
    reset_compile()
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-21 21:49:02.520893
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test __eq__ of class InvalidPattern"""
    x = InvalidPattern("abc")
    y = InvalidPattern("abc")
    z = InvalidPattern("def")
    assert x == y
    assert x != z

# Generated at 2022-06-21 21:49:15.600401
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__()

    This test checks that is a regular expression that is compiled when
    it is first used as an attribute and not before and also that
    consecutive calls to LazyRegex.__getattr__() are not expensive.
    """
    import re
    import bzrlib.lazy_regex
    bzrlib.lazy_regex.install_lazy_compile()
    assert re.compile == bzrlib.lazy_regex.lazy_compile
    obj = re.compile('^a')
    obj.split
    assert re.compile == bzrlib.lazy_regex.lazy_compile
    obj.finditer
    obj.findall
    obj.search
    obj.match
    obj.scanner
    obj.sub

# Generated at 2022-06-21 21:49:26.067963
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Tests __getstate__ method of class LazyRegex.

    The test verifies that the state of a LazyRegex object can be correctly
    pickled and unpickled.
    """
    import pickle
    pattern = LazyRegex(('^.+$',))
    state = pattern.__getstate__()
    pattern_unpickled = pickle.loads(pickle.dumps(pattern))
    state_unpickled = pattern_unpickled.__getstate__()
    assert state == state_unpickled

# Generated at 2022-06-21 21:49:29.177881
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    proxy = LazyRegex(["^a[^b]*b$"])
    assert proxy is not None


# Generated at 2022-06-21 21:49:33.905320
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() returns unicode"""
    i = InvalidPattern('foo')
    iu = unicode(i)
    assert isinstance(iu, unicode), "%r returned by __unicode__ is not unicode" % (iu,)

# Generated at 2022-06-21 21:49:43.189112
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should compile the regex if needed"""
    class test_class(object):
        def __init__(self):
            self.called = False
            self.return_value = None
        def __call__(self, *args, **kwargs):
            self.called = True
            return self.return_value
    test_compile = test_class()
    proxy = LazyRegex((), {})
    proxy._real_re_compile = test_compile
    assert not test_compile.called
    assert proxy.search("") == None
    assert test_compile.called
    test_compile.return_value = "compiled regex"
    assert proxy.search("") == "compiled regex"

# Generated at 2022-06-21 21:49:52.217484
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public.

    Some libraries calls re.finditer which fails it if receives a LazyRegex.
    """
    r = _real_re_compile('f')
    itr = re.finditer(r, 'f')
    m = itr.next()
    assert m.group() == 'f'


try:
    from bzrlib._patiencediff_pyx import PatienceSequenceMatcher
except ImportError:
    from bzrlib._patiencediff_py import PatienceSequenceMatcher


# Generated at 2022-06-21 21:49:56.349131
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():

    class TestInvalidPattern(InvalidPattern):
        # This is just to get something to run through the test.
        # The __repr__ call is actually done in the InvalidPattern
        # class.
        pass

    my_object = TestInvalidPattern('foo')
    repr(my_object)

# Generated at 2022-06-21 21:50:06.824164
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    r = re.compile(r"(a*)b")
    from bzrlib import _lazysre


# Generated at 2022-06-21 21:50:18.004246
# Unit test for function finditer_public
def test_finditer_public():
    global finditer_public
    global re
    # Mock the python library before using it
    _real_re_compile, _real_re_finditer = re.compile, re.finditer
    def mock(pattern, flags):
        return re.RegexObject(pattern, flags)
    re.finditer = finditer_public
    def finditer(pattern, string):
        return _real_re_finditer(pattern, string)

    re.compile = mock

# Generated at 2022-06-21 21:50:30.242794
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = u'This is the message'
    ex = InvalidPattern(msg)
    assert ex.msg == msg
    # msg can be unicode
    assert unicode(ex) == u'Invalid pattern(s) found. This is the message'
    assert str(ex) == 'Invalid pattern(s) found. This is the message'
    assert repr(ex) == "InvalidPattern(Invalid pattern(s) found. This is the message)"
    assert ex == InvalidPattern(msg)
    assert (InvalidPattern(u'foo') !=
            InvalidPattern('bar'))
    def f(s):
        ex = InvalidPattern(s)
        assert str(ex) == s

    f('unicode string')
    f(u'unicode string')
    f(str(u'unicode string'))

# Generated at 2022-06-21 21:50:37.515163
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() does return a regex compiled lazily to a regex
    compiled eagerly."""
    original_re_compile = re.compile
    re.compile = lazy_compile
    try:
        r1 = re.compile("abc")
        r2 = re.compile("xyz")
        reset_compile()
        r1 = re.compile("abc")
        r2 = re.compile("xyz")
    finally:
        re.compile = original_re_compile



# Generated at 2022-06-21 21:50:45.861895
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test unit of constructor of class InvalidPattern"""
    error = InvalidPattern('msg')
    # Preformatted string
    e = InvalidPattern('msg', preformatted_string='foo')
    assert e._preformatted_string == 'foo'

# Generated at 2022-06-21 21:50:54.802979
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile function"""
    re.compile = _real_re_compile
    # Create a LazyRegex proxy objet
    proxy_obj = lazy_compile('a (regex)*\?', re.IGNORECASE)
    # It should be bool(proxy_obj)
    bool(proxy_obj)
    # proxy_obj should have the same attributes as a real _sre.SRE_Pattern
    # object
    attribute_list = LazyRegex._regex_attributes_to_copy
    for attribute in attribute_list:
        getattr(proxy_obj, attribute)
    # proxy_obj should be pickleable
    import pickle
    pickle_obj = pickle.dumps(proxy_obj)
    new_proxy_obj = pickle.loads(pickle_obj)


# Generated at 2022-06-21 21:51:03.293567
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """When method __repr__ of class InvalidPattern is called,
    it returns a string that can be evaluated by eval, such
    as 'InvalidPattern("regex_error")'.
    In order for this to work, the 'msg' attribute must be
    an instance of str.
    """
    s = InvalidPattern("regex error")
    assert eval(repr(s)) == s
    s = InvalidPattern(u"regex error")
    assert eval(repr(s)) == s
    s = InvalidPattern("alsdkfja sdkfj asdf")
    assert eval(repr(s)) == s
    s = InvalidPattern(u"jkfh sd fjkhsdkfj hsdfkj hsdfjkhsdf")
    assert eval(repr(s)) == s



# Generated at 2022-06-21 21:51:05.030135
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    assert InvalidPattern('msg')
    assert InvalidPattern(u'msg')

# Generated at 2022-06-21 21:51:10.080716
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    regex = LazyRegex(r'^<\d+>')
    state = regex.__getstate__()
    new_regex = pickle.loads(pickle.dumps(regex))
    new_state = new_regex.__getstate__()
    assert state == new_state



# Generated at 2022-06-21 21:51:21.501704
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # method __getattr__ of clas LazyRegex returns correct value
    # if the regex hasn't been compiled
    re_1 = LazyRegex(('\\d',))
    assert re_1.pattern == '\\d'
    # method __getattr__ of clas LazyRegex returns correct value
    # if the regex already have been compiled
    re_2 = LazyRegex(('\\d',))
    re_2._real_regex = re_real = re.compile('\\d')
    assert re_2.pattern == '\\d'
    # if the requested attribute is missing,
    # method __getattr__ of clas LazyRegex raises AttributeError

# Generated at 2022-06-21 21:51:31.758568
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy compilation."""
    # Check that if we just use a proxy, it works
    re.compile = lazy_compile
    regex = re.compile(r'\d+')
    assert regex.match('123').group(0) == '123'
    # once it's been used, it should keep working.
    assert regex.match('123').group(0) == '123'

    class BadRegex(object):
        """Test that a bad regex gives the right error"""

        def __init__(self):
            self.compile_count = 0

        def __call__(self, *args, **kwargs):
            self.compile_count += 1
            if self.compile_count == 1:
                raise re.error('bad regex')
            return self


# Generated at 2022-06-21 21:51:44.469038
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit tests for method __unicode__ of class InvalidPattern"""
    # test attributes:
    #       _fmt
    #       msg
    #       _preformatted_string

    # test error without _fmt and without _preformatted_string
    error = InvalidPattern("Error msg")
    assert (unicode(error) == "Unprintable exception InvalidPattern: "\
            "dict={'msg': 'Error msg'}, fmt=None, error=None")
    # test error with _fmt and without _preformatted_string
    class ErrorWithFmt(InvalidPattern):
        _fmt = "Some pattern(s) are invalid: %(msg)s"
        def _get_format_string(self):
            return "Some pattern(s) are invalid: %(msg)s"

# Generated at 2022-06-21 21:51:48.948127
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('there should be no message')
    except InvalidPattern as e:
        assert_equal(str(e), 'Invalid pattern(s) found. there should be no message')



# Generated at 2022-06-21 21:52:02.469462
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile actually works"""
    import pickle

    test_pattern = 'foo'
    lazy_regex = lazy_compile(test_pattern)
    assert not isinstance(lazy_regex, re._pattern_type)
    assert isinstance(lazy_regex, LazyRegex)
    assert lazy_regex._real_regex is None
    assert lazy_regex._regex_args == (test_pattern,)
    assert lazy_regex._regex_kwargs == {}
    assert lazy_regex._regex_attributes_to_copy != []

    # Once it is accessed it should be a real regex
    regex = lazy_regex.search('foo')
    assert regex
    assert isinstance(regex, re._pattern_type)
    assert lazy_regex._real_re

# Generated at 2022-06-21 21:52:21.736736
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    from bzrlib.tests.per_regex import TestCaseWithRegex
    from bzrlib.trace import mutter

    class __getstate__TestCase(TestCaseWithRegex):
        def test__getstate__(self):
            s = lazy_compile(r"^bzr-test[a-z]+$").__getstate__()
            self.assertEqual(({'args': (r"^bzr-test[a-z]+$",), 'kwargs': {}},), s)

    # XXX: This test is dubious. It doesn't access __getstate__.
    # But I don't want to mess with the Trace decorator applied to this method.
    mutter("A dup test has been added to exercise __getstate__")
    __getstate__TestCase('__getstate__').test__get

# Generated at 2022-06-21 21:52:30.600368
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class MyException(InvalidPattern):
        _fmt = 'A MyException with %(foo)s and %(bar)s'
    ex1 = MyException(foo='foo', bar='bar')
    assert ex1.foo == 'foo'
    assert ex1.bar == 'bar'
    assert str(ex1) == 'A MyException with foo and bar'
    assert unicode(ex1) == u'A MyException with foo and bar'

# Generated at 2022-06-21 21:52:32.560661
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test equality of InvalidPattern objects"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:52:39.867716
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Unit tests for __init__ method of class LazyRegex"""

    lazyregex = LazyRegex(args=['[A]'], kwargs={})
    assert lazyregex._real_regex is None
    assert lazyregex._regex_args == ['[A]']
    assert lazyregex._regex_kwargs == {}



# Generated at 2022-06-21 21:52:50.279619
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() properly overrides compile() with
    lazy_compile()."""
    install_lazy_compile()
    # compile() should now return a LazyRegex
    try:
        pattern = re.compile(r'foo')
        assert isinstance(pattern, LazyRegex), "compile() should return a LazyRegex"
        # and the LazyRegex should compile on access
        assert pattern.findall('foo') == ['foo']
    finally:
        reset_compile()

# Generated at 2022-06-21 21:53:01.175455
# Unit test for function finditer_public
def test_finditer_public():
    m1 = re.match("foo", "foo")
    m2 = re.match("foo", "foobar")

    it = re.finditer("foo", "foo")
    try:
        assert next(it).start() == m1.start()
        assert StopIteration is next(it)
    except StopIteration:
        pass
    it = re.finditer("foo", "foobar")
    try:
        assert next(it).start() == m2.start()
        assert StopIteration is next(it)
    except StopIteration:
        pass

# Generated at 2022-06-21 21:53:03.203190
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # To test that no exception is raised
    LazyRegex()


# Generated at 2022-06-21 21:53:04.257965
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:53:13.786041
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    _real_re_compile = re.compile
    re.compile = lambda p,f=0: 'compiled(%r,%r)' % (p,f)
    lazy = LazyRegex((r'foobar',), {'flags':3})
    # We have not yet compiled
    assert 'compiled' not in str(lazy)
    # But we are the same type as a compiled regex
    assert isinstance(lazy, type(re.compile('x')))
    # When we access an attribute, we will be compiled
    assert lazy.pattern == 'compiled(r\'foobar\',3)'
    re.compile = _real_re_compile

# Generated at 2022-06-21 21:53:25.368417
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from bzrlib.tests.per_regex import TestCaseWithRegex
    from bzrlib.tests import TestSkipped

    # This is needed for Python 2.4.
    def _execute_test(self):
        regex = LazyRegex()
        regex.__setstate__({'args': ('^(?P<path>.*)$',),
                            'kwargs': {}})
        str(regex)
        # no assertions, we just want to test that the __setstate__ method
        # doesn't raise an exception

    try:
        TestCaseWithRegex('test_LazyRegex___setstate__')._execute_test = _execute_test
    except AttributeError:
        raise TestSkipped("Method LazyRegex.__setstate__ can't be tested in this version of Python.")

# Generated at 2022-06-21 21:53:40.444205
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that __str__ is implemented for InvalidPattern."""
    ex = InvalidPattern('foo')
    ex.bar = 'bar'
    ex.baz = 'baz'
    assert str(ex) == 'Invalid pattern(s) found. foo'
    assert unicode(ex) == u'Invalid pattern(s) found. foo'
    # format_string is None.
    try:
        del ex._fmt
    except AttributeError:
        pass
    assert str(ex) == 'Unprintable exception InvalidPattern: ' \
        'dict={"baz": "baz", "bar": "bar", "msg": "foo"}, fmt=None, error=None'


# Generated at 2022-06-21 21:53:49.777791
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # check that the unicode method works:
    if isinstance(b'', unicode):
        raise AssertionError('1')
    ip = InvalidPattern(b'foo')
    if not isinstance(unicode(ip), unicode):
        raise AssertionError('2')
    # check that repr works:
    if repr(ip) != "InvalidPattern('foo')":
        raise AssertionError('3: %r' % repr(ip))
    # check that str works:
    if str(ip) != 'foo':
        raise AssertionError('4: %r' % repr(ip))
    # check that unicode(str) works.
    ip = InvalidPattern('foo')

# Generated at 2022-06-21 21:54:00.451361
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError("failed to override re.compile")
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("failed to reset re.compile")
    # recursion
    install_lazy_compile()
    install_lazy_compile()
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("failed to reset re.compile in recursion")


# Test the local finditer_public method

# Generated at 2022-06-21 21:54:04.022344
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'foo'
    p = InvalidPattern(msg)
    assert msg in unicode(p)
    # check that InvalidPattern can be used in a unicode context.
    assert msg in unicode(p.__class__(msg))

# Generated at 2022-06-21 21:54:10.979784
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return meaningful string.

    Example of a typical call:
        InvalidPattern('"a*" nothing to repeat at position 0')
    """

    initial_value = '"a*" nothing to repeat at position 0'
    ip = InvalidPattern(initial_value)
    expected_value = 'InvalidPattern("\\"a*\\" nothing to repeat at position 0")'
    returned_value = repr(ip)
    assert(returned_value == expected_value), "__repr__ returned '%s', but '%s' expected" % (returned_value, expected_value)

# Generated at 2022-06-21 21:54:11.851048
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex constructs with no arguments"""
    LazyRegex()

# Generated at 2022-06-21 21:54:21.941811
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ produces utf8 strings"""
    # There are two cases, when '_fmt' is unicode and when it is ascii.
    # Ascii case
    exc = InvalidPattern(u"\xed\xa0\x80\xed\xb6\x81")
    # __unicode__ must return a unicode object.
    exc.__unicode__().__class__.__name__==u'unicode'
    # __str__ must return a str object.
    exc.__str__().__class__.__name__=='str'
    # There is no '%' in the expected output, so the message should be
    # left as is.
    assert exc.__unicode__() == exc.msg
    # Unicode case

# Generated at 2022-06-21 21:54:30.722807
# Unit test for function finditer_public
def test_finditer_public():
    r = lazy_compile(r'\w+')
    l = [m.group(0) for m in re.finditer(r, 'Hello World')]
    assert l == ['Hello', 'World']

# Some libraries calls re.split which fails it if receives a LazyRegex.
if getattr(re, 'split', False):
    def split_public(pattern, string, maxsplit=0):
        if isinstance(pattern, LazyRegex):
            return pattern.split(string, maxsplit)
        else:
            return _real_re_compile(pattern, flags).split(string, maxsplit)
    re.split = split_public


# Generated at 2022-06-21 21:54:42.930695
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must return a unicode object."""
    class MyException(InvalidPattern):
        """A sample subclass"""
        _fmt = 'MyException(%(msg)s)'

    e = MyException('test')
    # Check that the format string is applied correctly.
    assert str(e) == 'MyException(test)'
    # Check that the Unicode object is returned.
    assert isinstance(e.__unicode__(), unicode)
    # Check that we don't get a UnicodeDecodeError.
    assert str(MyException('\xe7\xf6\xfc')) == 'MyException(\xe7\xf6\xfc)'
    # Preformatted message
    e._preformatted_string = 'Preformatted message'
    assert e.__unicode__() == u'Preformatted message'
   

# Generated at 2022-06-21 21:54:45.437117
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern class should return a value

    This is a test for a bug reported in bug #726782
    """
    assert(len(str(InvalidPattern("This is a msg"))) > 0)

# Generated at 2022-06-21 21:54:57.968490
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy compile and lazy regex objects"""
    import sys
    # There are lots of regex tests, to preserve test coverage for those, and
    # also to make sure that we're using the same regex implementation,
    # we'll use the test suite for _sre, even though we're really testing our
    # wrapper.
    import _sre
    _sre.compile = lazy_compile
    _sre.test()
    # Also do some basic testing of the lazy compilation, including
    # pickling and overriding re.compile
    install_lazy_compile()
    compiled = re.compile("foo")
    assert not isinstance(compiled, LazyRegex)
    # Make sure it's a real regex
    assert compiled.search("foo")
    reset_compile()
    compiled = re.compile("foo")

# Generated at 2022-06-21 21:55:10.033276
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():

    def assert_equal(e, expected):
        """Assert that e.__str__() == expected"""
        actual = str(e)
        if actual != expected:
            raise AssertionError('%r != %r' % (actual, expected))

    assert_equal(InvalidPattern('foo'), 'foo')
    assert_equal(InvalidPattern('foo\x00bar'), 'foo\x00bar')
    assert_equal(InvalidPattern(u'foo'), u'foo')
    assert_equal(InvalidPattern(u'foo\x00bar'), u'foo\x00bar')
    assert_equal(
        InvalidPattern(u"Unable to merge these branches:\r\n  foo"),
        u"Unable to merge these branches:\r\n  foo")

# Generated at 2022-06-21 21:55:21.225088
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern

    Method __eq__() compares attributes of this exception.
    """
    exception = InvalidPattern('message')
    exception.exception = 'exception'
    exception._fmt = 'string'
    exception.msg = 'message'
    exception.tb = 'tb'
    exception.trace = 'trace'
    exception2 = InvalidPattern('message')
    exception2.exception = 'exception'
    exception2._fmt = 'string'
    exception2.msg = 'message'
    exception2.tb = 'tb'
    exception2.trace = 'trace'
    exception3 = InvalidPattern('message')
    exception3.exception = 'exception_differs'
    exception3._fmt = 'string_differs'

# Generated at 2022-06-21 21:55:32.661415
# Unit test for function lazy_compile
def test_lazy_compile():
    r = re.compile(r'(?:)(?:)')
    # Check it is a LazyRegex
    assert isinstance(r, LazyRegex)
    assert r._real_regex is None
    # Access the first attribute it should compile
    r.findall('foo')
    assert isinstance(r._real_regex, type(r))
    # Check that we can getstate and setstate
    new_r = LazyRegex()
    import pickle
    new_r.__setstate__(pickle.loads(pickle.dumps(r.__getstate__())))
    # new_r should now be the same and after using it, the real_regex
    # should be compiled
    assert new_r.findall('foo') == r.findall('foo')
    assert new_r._

# Generated at 2022-06-21 21:55:39.935692
# Unit test for function finditer_public
def test_finditer_public():
    """Test finditer_public function.

    This function provides a good test for finditer_public because it
    checks whether it is called or not.
    """
    re.finditer_called = False
    def finditer_private(pattern, string, flags=0):
        re.finditer_called = True
        return iter([])
    re.finditer = finditer_private
    try:
        # This call should not trigger finditer_public
        list(re.finditer("p", "p"))
        assert not re.finditer_called
        # This call should trigger finditer_public
        list(re.finditer("p", "p", flags=re.L))
        assert re.finditer_called
    finally:
        del re.finditer_called
        re.finditer = finditer_public

# Generated at 2022-06-21 21:55:42.834433
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__"""

    x=InvalidPattern(msg="foo")
    y=InvalidPattern(msg="foo")

    assert x == y



# Generated at 2022-06-21 21:55:54.968480
# Unit test for function lazy_compile
def test_lazy_compile():
    # First, a test of the behavior of LazyRegex.
    proxy = LazyRegex(["a*c"], {})
    assert proxy._real_regex is None
    proxy.match("bc")
    assert proxy._real_regex is not None
    # Test the utility function
    import re
    compiled = lazy_compile("a*c")
    assert isinstance(compiled, LazyRegex)
    assert compiled._real_regex is None
    assert compiled.match("bc").group(0) == "c"
    assert compiled._real_regex is not None
    # Test the install function.
    install_lazy_compile()
    compiled = re.compile("a*c")
    assert isinstance(compiled, LazyRegex)
    reset_compile()
    assert re.compile

# Generated at 2022-06-21 21:56:03.112387
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern."""
    e1 = InvalidPattern("test1")
    e2 = InvalidPattern("test2")
    # two different instances are never equal.
    assert e1.__eq__(e2) is NotImplemented
    assert e2.__eq__(e1) is NotImplemented
    # two different instances with the same msg does not matter.
    e1.msg = e2.msg
    assert e1.__eq__(e2) is NotImplemented
    assert e2.__eq__(e1) is NotImplemented
    # two different instances with different class does not matter.
    class Dummy1(InvalidPattern): pass
    e1 = Dummy1("test3")
    e2 = InvalidPattern("test3")
    assert e1.__eq

# Generated at 2022-06-21 21:56:07.107120
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('test')
    except InvalidPattern as e:
        assert(str(e) == 'test')

if __name__ == '__main__':
    test_InvalidPattern()

# Generated at 2022-06-21 21:56:11.056301
# Unit test for function reset_compile
def test_reset_compile():
    # We can test that reset_compile is safe to call multiple times
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    reset_compile()

# Generated at 2022-06-21 21:56:22.760209
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test LazyRegex."""
    # A simple test
    r = LazyRegex(('^a',), {})
    assert r._real_regex is None
    assert r._regex_args == ('^a',)
    assert r._regex_kwargs == {}
    # Set the state
    r.__setstate__({'args': ('^b',), 'kwargs': {'foo': 'bar'}})
    assert r._regex_args == ('^b',)
    assert r._regex_kwargs == {'foo': 'bar'}

# Generated at 2022-06-21 21:56:30.847012
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from doctest import ELLIPSIS
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_i18n import TestCaseWithTransport

    class TestInvalidPattern_eq(TestCaseWithTransport):

        def test_eq(self):
            class1 = InvalidPattern("msg1")
            class2 = InvalidPattern("msg1")
            self.assertEqual(class1, class2)
            class1.msg = "msg2"
            class1._fmt = "msg2"
            class2.msg = "msg2"
            class2._fmt = "msg2"
            self.assertEqual(class1, class2)


    TestInvalidPattern_eq.suite().run(debug=True)

# Generated at 2022-06-21 21:56:36.518088
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import unittest

    invalid_regex = '.'
    lazy_compile(invalid_regex)

    class TestLazyRegex(unittest.TestCase):

        def test_invalid_regex(self):
            self.assertRaises(ValueError, LazyRegex, (invalid_regex,))

    unittest.main()

# Generated at 2022-06-21 21:56:40.455539
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ must return True only if all attributes of the class are equal.
    """
    obj1 = obj2 = InvalidPattern('msg')
    assert obj1 == obj2
    obj1.msg = ''
    obj2.msg = 'msg'
    assert obj1 != obj2


# Generated at 2022-06-21 21:56:52.893657
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test LazyRegex.__setstate__

    This tests that when you pickle a LazyRegex, the __setstate__() method
    creates a valid LazyRegex.
    """
    import pickle
    proxies = [LazyRegex(), LazyRegex('[abc]', re.I)]
    for proxy in proxies:
        pickup = pickle.dumps(proxy, pickle.HIGHEST_PROTOCOL)
        newproxy = pickle.loads(pickup)

        # Make sure we have a LazyRegex
        assert isinstance(newproxy, LazyRegex)

        # Make sure _real_regex is None (and therefore not the original proxy)
        assert newproxy._real_regex is None

        # Make sure _regex_args is correct
        assert newproxy._regex_args