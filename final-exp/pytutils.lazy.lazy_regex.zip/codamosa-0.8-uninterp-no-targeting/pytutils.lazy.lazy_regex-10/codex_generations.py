

# Generated at 2022-06-21 21:47:11.117703
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test LazyRegex proxy object"""
    import doctest
    import re
    import sys

    if sys.version < "2.7":
        sys.stderr.write("Skipping re tests with Python 2.6")
        return True

    try:
        re.compile
    except AttributeError:
        # re.compile is not supported on Python 2.6
        return True

    # Reset re.compile to the original
    reset_compile()

    # Do the doctest
    # The call to reset_compile() makes the _real_re_compile() function
    # available for use in the test
    return doctest.testmod()[0] == 0

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:47:19.921812
# Unit test for function lazy_compile
def test_lazy_compile():
    """Make sure lazy_compile works as expected"""
    # Check that it returns a proxy object
    proxy = lazy_compile(r"^[0-9]+$")
    # And that it doesn't compile the regex until we try to use it
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # Check that the proxy proxies re.compile's arguments forward
    assert proxy.pattern == r"^[0-9]+$", \
        "The proxy doesn't forward the pattern to the compiled regex"


if __name__ == '__main__':
    test_lazy_compile()

# Generated at 2022-06-21 21:47:30.490038
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern"""
    # check that repr() of a unicode exception shows the unicode characters
    ex = InvalidPattern(u'\u03b5\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac'
                        u' \u03c0\u03c1\u03bf\u03c2 \u03c7\u03b1\u03c1\u03b1'
                        u'\u03ba\u03c4\u03c9\u03bc\u03ad\u03bd\u03b7')
    repr = ex.__repr__()

# Generated at 2022-06-21 21:47:41.865997
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests that __unicode__ returns the correct message for InvalidPattern.
    
    It also checks that it still works if we add to the InvalidPattern._fmt
    class variable.
    """
    from bzrlib.i18n import gettext
    from bzrlib.i18n import lazy_gettext as _
    gettext('')
    # FIXME: RBC 20060108 If the code has no translations, the test below
    # fails because the msgid is not returned, instead the msgstr is.
    # Raising a TranslationNotFoundError to cause gettext to fallback to
    # the msgid solves this problem. But I don't know why calling 
    # gettext('') and _('') doesn't have this effect. This is a problem
    # even in the test suite.
    #raise TranslationNotFound

# Generated at 2022-06-21 21:47:50.308615
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that InvalidPattern.__str__() returns the right thing.
    """
    # check that \a is replaced in the error message.
    # XXX: This will be fixed by bug #415340
    r = re.compile(u'\\a')
    exc = InvalidPattern(str(r.error))
    assert isinstance(exc.__str__(), str)
    assert exc.__str__() == (
        "Invalid pattern(s) found. "
        "re.error('\\a',)"
        )



# Generated at 2022-06-21 21:47:55.790918
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must set the correct state"""
    regex = LazyRegex([''], {})
    regex.__setstate__({'args': ['a', 'b'], 'kwargs': {'c': 'd'}})
    assert regex._regex_args == ['a', 'b']
    assert regex._regex_kwargs == {'c': 'd'}



# Generated at 2022-06-21 21:47:58.132769
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    default_compile = re.compile
    reset_compile()
    assert default_compile is re.compile

# Generated at 2022-06-21 21:48:10.553083
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test the __str__ method of InvalidPattern"""
    import doctest
    from bzrlib.tests.test_i18n import FakeTranslator
    from bzrlib import _gettext_path
    from bzrlib.i18n import gettext

    def setup(test):
        # doctest always insert the current module namespace into the namespace
        # of the test. But in order to test InvalidPattern, we want to test
        # the one from this module, not the one from the current module.
        # Therefore we replace the current namespace with the one from this
        # module.
        test.globs['__name__'] = __name__
        test.globs['gettext'] = gettext

# Generated at 2022-06-21 21:48:22.699153
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    # Imports needed for testing:
    from bzrlib import osutils
    from bzrlib import lazy_import
    import re
    from bzrlib.trace import mutter

    # This test code is executed in UTF8-encoded environment.
    # b'\xd0\xb8\xd1\x81\xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2\xd0\xbb\xd0\xb5\xd0\xbd\xd0\xb8\xd0\xb5'
    # is a UTF-8 string corresponding to a unicode string containing Cyrillic
    # 'исправление'.

    # This is the string to test on
    e = InvalidPattern

# Generated at 2022-06-21 21:48:25.999895
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # For LazyRegex, this should succeed because re.compile returns a
    # SRE_Pattern object and it's all good
    _real_re_compile("")
    LazyRegex()

# Generated at 2022-06-21 21:48:40.213476
# Unit test for function finditer_public
def test_finditer_public():
    """Test the use of finditer_public."""
    # The goal of this test is to ensure that finditer_public correctly calls
    # finditer on the wrapped regex.
    import re

    # finditer_public should call finditer on the underlying regex
    class RegexDummy:
        def __init__(self):
            self.finditer_called = False

        def finditer(self, string):
            self.finditer_called = True
            return iter(())

    regex = RegexDummy()
    pattern = LazyRegex((None,), {'regex': regex})
    re.finditer(pattern, '')
    assert regex.finditer_called, "finditer_public did not call finditer on the regex"

# Generated at 2022-06-21 21:48:43.769059
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test for function install_lazy_compile"""
    import re
    try:
        re.compile('(?P<foo>.*)')
        raise AssertionError('re import should not have compiled regex.')
    except AttributeError:
        pass
    install_lazy_compile()
    re.compile('(?P<foo>.*)')

# Generated at 2022-06-21 21:48:48.286572
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test that __repr__ does not fail (see bug #76093)"""
    try:
        raise InvalidPattern("test")
    except InvalidPattern:
        (type, value, traceback) = sys.exc_info()
        repr(value)

# Generated at 2022-06-21 21:48:52.453776
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Make sure that install_lazy_compile has the desired effect"""
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
        reset_compile()
        assert re.compile is _real_re_compile
    except:
        reset_compile()
        raise

# Generated at 2022-06-21 21:48:57.516510
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode string."""
    for s in [u"", u"\u1234", u"\U00012345"]:
        err = InvalidPattern(s)
        assert isinstance(err.__unicode__(), unicode)

# Generated at 2022-06-21 21:49:04.481453
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test that InvalidPattern.__unicode__ does not convert to Unicode"""
    from bzrlib.i18n import gettext
    gettext("")
    test_msg = "This is a test"
    subject = InvalidPattern(test_msg)
    utf8_msg = subject.__unicode__()
    assert utf8_msg == test_msg, \
        "__unicode__ is converting Unicode to UTF8 (%r != %r)" % (
            utf8_msg, test_msg)

# Generated at 2022-06-21 21:49:12.210573
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    l = LazyRegex()
    l._regex_args = ()
    l._regex_kwargs = {"flags": 0, "pattern": 'test'}
    state = l.__getstate__()
    assert state == {
            "args": (),
            "kwargs": {"flags": 0, "pattern": 'test'},
            }


# Generated at 2022-06-21 21:49:23.152504
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test of some cases.

    All of these cases are expected to pass.
    """
    # Invalidpattern objects can be created with no arguments
    InvalidPattern()

    # InvalidPattern can be created with a message
    InvalidPattern('Foo')

    # __str__() is expected to return the message that was given
    e = InvalidPattern('Foo')
    assert str(e) == 'Foo'

    # __unicode__() is expected to return the message as unicode
    e = InvalidPattern('Foo')
    assert unicode(e) == 'Foo'

    # __str__() is expected to return the same message that was given
    e = InvalidPattern('Foo')
    assert str(e) == 'Foo'

    # __repr__ is expected to return a string that is suitable for eval

# Generated at 2022-06-21 21:49:30.323956
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should return either True, False or NotImplemented

    It should not raise an exception
    """
    assert InvalidPattern('msg1') == InvalidPattern('msg1')
    assert not InvalidPattern('msg1') == InvalidPattern('msg2')
    assert InvalidPattern('msg1') != InvalidPattern('msg2')
    assert not InvalidPattern('msg1') != InvalidPattern('msg1')
    assert InvalidPattern('msg1') != ValueError('msg1')
    assert not InvalidPattern('msg1') == ValueError('msg1')
    assert InvalidPattern('msg1') != 'something else'
    assert not InvalidPattern('msg1') == 'something else'
    assert InvalidPattern('msg1') == InvalidPattern('msg1')
    assert InvalidPattern('msg1') != ValueError
    assert not InvalidPattern('msg1') == ValueError

# Generated at 2022-06-21 21:49:41.868598
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex"""
    from StringIO import StringIO
    from bzrlib.tests import TestCase
    import re

    # this is re.sub replacement
    def sub(pattern, repl, string, count=0, flags=0):
        return re.sub(pattern, repl, string, count, flags)

    class TestLazyRegex(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.sub = sub

        def test_sub(self):
            # set attribute sub (to be restored in tearDown)
            # sub is needed by re.sub
            re.sub = self.sub
            # create a LazyRegex
            r = lazy_compile(r'\s*')
            # call the function

# Generated at 2022-06-21 21:49:58.504199
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() should always return an str object"""
    from bzrlib.i18n import _i18n_autodetect
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_encoding
    saved_detect = _i18n_autodetect
    saved_encoding = gettext.policy._default_encoding
    # first, test with the current system encoding

# Generated at 2022-06-21 21:50:07.039028
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    def raise_re_compile(*args, **kwargs):
        raise re.error
    lazy_regex = LazyRegex()
    real_re_compile = lazy_regex._real_re_compile
    lazy_regex._real_re_compile = raise_re_compile
    try:
        try:
            # Try to compile, which will fail
            lazy_regex.match('a')
        except InvalidPattern as e:
            pass
        else:
            raise AssertionError('LazyRegex.__init__ should catch re.error')
    finally:
        lazy_regex._real_re_compile = real_re_compile



# Generated at 2022-06-21 21:50:17.249111
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Ensure that method __eq__ compares all attributes of the InvalidPattern class"""

    # Create 2 objects to compare
    # pylint: disable=W0622
    msg = u'Invalid pattern(s) found. "%s" %s'
    a = InvalidPattern(msg % (u'', u'a'))
    b = InvalidPattern(msg % (u'b', u'b'))

    # a and b are different because the message is different
    assert a != b
    assert not a == b

    # make a a copy of b
    a = InvalidPattern(b.msg)

    # a and b should now be the same
    assert a == b
    assert not a != b



# Generated at 2022-06-21 21:50:25.919539
# Unit test for function reset_compile
def test_reset_compile():
    def noop(*args):
        pass
    test_compile = noop
    re.compile = test_compile
    reset_compile()
    assert re.compile is _real_re_compile
    re.compile = test_compile
    reset_compile()
    assert re.compile is _real_re_compile
    del re.compile
    reset_compile()
    assert re.compile is _real_re_compile


# Generated at 2022-06-21 21:50:37.122936
# Unit test for function reset_compile
def test_reset_compile():
    # Ensure it really does reset the value of re.compile
    re.compile = lambda *args, **kwargs: (args, kwargs)
    reset_compile()
    test_real_re_compile = re.compile
    test_real_re_compile('foo')
    try:
        # This is specific to the python compiler for regex, and doesn't
        # really test anything - we really just have to hope that the
        # above call still works.
        assert(test_real_re_compile == re.compile)
    finally:
        # Reset the value so we don't interfere with the rest of the
        # tests.
        re.compile = test_real_re_compile

    # Ensure it doesn't care how many times it is called
    reset_compile()

# Generated at 2022-06-21 21:50:47.460257
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Checking that install_lazy_compile works properly"""
    import re
    # Installing lazy_compile
    install_lazy_compile()
    tpattern = 'single[0-9]'
    text = 'single0'
    # Checking that it is a LazyRegex object
    tcompile = re.compile(tpattern)
    assert isinstance(tcompile, LazyRegex)
    # Resetting re.compile()
    reset_compile()
    # Checking that re.compile() is now the original
    tcompile = re.compile(tpattern)



# Generated at 2022-06-21 21:50:54.565596
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern.

    This also test method _get_format_string which is used by __str__.
    """
    try:
        raise InvalidPattern("No error")
    except InvalidPattern as e:
        assert(str(e) == "Invalid pattern(s) found. No error" or
               str(e) == "Invalid pattern(s) found. No error\n")

# Generated at 2022-06-21 21:50:58.811522
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # test to see that LazyRegex properly exports regex pattern to
    # allow pickling.
    regexp = LazyRegex(r"\d+", re.VERBOSE)
    assert(regexp.__getstate__()['args'] == (r"\d+",))



# Generated at 2022-06-21 21:51:08.638099
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    from bzrlib.tests import TestUtil
    p1 = InvalidPattern("msg1")
    p2 = InvalidPattern("msg2")
    p3 = InvalidPattern("msg1")
    p4 = InvalidPattern("msg1")
    p4._fmt = "msg4"
    TestUtil.assertEqualDiff(
        (p1, p2, p3, p4),
        (p1, p2, p3, p4)
        )
    TestUtil.assertNotEqualDiff(
        (p1, p2, p3, p4),
        (p3, p3, p3, p3)
        )

# Generated at 2022-06-21 21:51:14.909888
# Unit test for function finditer_public
def test_finditer_public():
    re.finditer("\S+", "a b c")
    re.finditer("\S+", "a b c", re.IGNORECASE)
    proxy = lazy_compile("\S+")
    re.finditer(proxy, "a b c")
    proxy = lazy_compile("\S+", re.IGNORECASE)
    re.finditer(proxy, "a b c")



# Generated at 2022-06-21 21:51:25.957066
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    assert str(InvalidPattern('msg')) == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert unicode(InvalidPattern('msg')) == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert repr(InvalidPattern('msg')) == 'InvalidPattern(Unprintable exception InvalidPattern: dict={}, fmt=None, error=None)'

# Generated at 2022-06-21 21:51:38.393177
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ of class LazyRegex should work as expected"""
    from bzrlib.urlutils import local_path_from_url
    lr = LazyRegex([r'[a-z]{5}'])
    assert lr._real_regex is None
    assert lr.groupindex == {}
    assert lr.groups == 0
    # The compiled regex must have been returned by _compile_and_collapse,
    # which has been called in either cases.
    assert lr.match(r'abcde') is not None
    assert lr.match(r'abcdef') is None

    lr = LazyRegex([r'[a-z]{5}'], {'flags': re.I})
    assert lr.match(r'ABCDE') is not None
   

# Generated at 2022-06-21 21:51:42.287070
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that lazy_compile gets installed."""
    reset_compile()
    install_lazy_compile()
    regex = re.compile("foo")
    assert isinstance(regex, LazyRegex)
    reset_compile()

# Generated at 2022-06-21 21:51:48.527027
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    a = InvalidPattern('a')
    b = InvalidPattern('b')

    assert a == a
    assert a != b

    # assert that InvalidPattern objects can be used as dict keys
    dict = {a: 1}
    dict[b] = 2
    assert dict[a] == 1
    assert dict[b] == 2

# Generated at 2022-06-21 21:51:50.494419
# Unit test for function finditer_public
def test_finditer_public():
    re.finditer('^(?P<a>.)?(?P<b>.)?$', 'foo')

# Generated at 2022-06-21 21:52:02.768080
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # python 2.6
    class StateTest(object):

        _args = None
        _kwargs = None

        def __getstate__(self):
            return {
                "args": self._args,
                "kwargs": self._kwargs,
                }

        def __setstate__(self, dict):
            self._args = dict["args"]
            self._kwargs = dict["kwargs"]

    test = StateTest()
    test._args = (1,)
    test._kwargs = {'a': 1}
    test_dict = test.__getstate__()
    result = {'args': (1,), 'kwargs': {'a': 1}}
    result_test = StateTest()

    result_test.__setstate__(test_dict)
    assert result_test._args == test._args


# Generated at 2022-06-21 21:52:13.559765
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method LazyRegex.__getattr__
    """

    # A LazyRegex compiles and collapses after the first attribute access.
    # If the real regex does not exist, it will be compiled
    # from the saved args and kwargs.
    lazy_regex = LazyRegex(args=('a',), kwargs={'flags':0})
    lazy_regex._real_regex = None
    assert lazy_regex.match('a') is not None

    # A LazyRegex compiles and collapses after the first attribute access.
    # The __getattr__ method should skip any attributes starting with '_'
    # except _real_regex because they are expected to be set by the proxy
    # object.

# Generated at 2022-06-21 21:52:21.622069
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should call __init__ with the given state"""
    # create a LazyRegex object
    obj = LazyRegex("(\\w+):(\\w+)", {"flags": 10})
    # set the state using a dictionary
    obj.__setstate__({"args": ["(\\w+):(\\w+)", {"flags": 10}],
                     "kwargs": {}})
    assert (obj._regex_args == ["(\\w+):(\\w+)", {"flags": 10}])
    assert (obj._regex_kwargs == {})

# Generated at 2022-06-21 21:52:33.903212
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ must return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it.
    """
    from bzrlib.tests import TestCase

    class TestLazyRegex(TestCase):

        def _make_LazyRegex(self, *args, **kwargs):
            return lazy_compile(*args, **kwargs)

        def test___getattr__with_empty_actual_regex(self):
            # if _real_regex is empty, _compile_and_collapse() must be called
            # before returning regex_attributes.
            test_regex = self._make_LazyRegex('abc')
            self.assertEqual(None, test_regex._real_regex)

# Generated at 2022-06-21 21:52:39.285138
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test case for LazyRegex.__setstate__.
    """
    l = LazyRegex(("foo",))
    l.__setstate__({"args": ("foo",), "kwargs": {}})
    l.__setstate__({"args": ("bar",), "kwargs": {}})
    l.__setstate__({"args": ("foo",), "kwargs": {}})

# Generated at 2022-06-21 21:52:47.267689
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()
    re.compile = lambda x: 1
    reset_compile()
    if re.compile != _real_re_compile:
        raise AssertionError("re.compile was not reset")



# Generated at 2022-06-21 21:52:53.699314
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that re.compile is overridden with lazy_compile.

    It is not safe to use this test on the same interpreter as other
    running tests -- they may use regex compilation and change the compiler
    in non-obvious ways.
    """
    try:
        install_lazy_compile()
        return re.compile is lazy_compile
    finally:
        reset_compile()

# Generated at 2022-06-21 21:53:01.235590
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    real_state = {"args":("^\d{4}-\d{2}-\d{2}$",),
                  "kwargs":{}}
    lazy_regex = LazyRegex(("^\d{4}-\d{2}-\d{2}$",), {})
    assert real_state == lazy_regex.__getstate__()


# Generated at 2022-06-21 21:53:02.987551
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern"""
    # __eq__ is defined in class Exception
    ip = InvalidPattern('Some message')
    assert ip != 'Some message'
    assert ip == InvalidPattern('Some message')

# Generated at 2022-06-21 21:53:05.523454
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should work when _fmt is an unicode string and no self.msg"""
    e = InvalidPattern('')
    e._fmt = u'bad %(msg)s'
    e.msg = 'error'
    str(e)



# Generated at 2022-06-21 21:53:07.769507
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:53:19.205808
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern for Unicode/str

    Create an instance of InvalidPattern, call __unicode__ and __str__ and
    check that they return the expected result.
    """
    from bzrlib.i18n import gettext
    pattern_error = InvalidPattern('Test-Message for regexp')
    pattern_error.msg = 'Test-Message for regexp'
    pattern_error._fmt = 'Invalid pattern(s) found. %(msg)s'
    gettext('Invalid pattern(s) found. %(msg)s')
    msg = gettext(pattern_error._fmt)
    assert isinstance(msg, unicode)
    assert pattern_error._get_format_string() == msg
    assert isinstance(str(pattern_error), str)

# Generated at 2022-06-21 21:53:29.400456
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Method __setstate__ restores object state from a given dictionary"""

    # Test values that are not pickable
    class NotPickable(object):
        """Class that raises an error if we try to pickle it."""
        def __setstate__(self, state):
            raise NotImplementedError()

    args = (u'\xc3\xa9\xc3\xaa',)
    kwargs = {u'flags':0}
    lr = LazyRegex(args, kwargs)
    state = lr.__getstate__()
    lr.__setstate__(state)
    lr_dumped = lr.__getstate__()
    lr_dumped['args'] = NotPickable()

# Generated at 2022-06-21 21:53:41.242572
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the functionality of LazyRegex proxy objects."""
    # Some examples from the Python re docs
    test_regexes = [
        (r'(?i)yes', 'yes?'),
        (r'\d+', '1234'),
        (r'\d+', 'abcd'),
        (r'\w+', 'I am: a test string.'),
        (r'\\section', r'\section'),
        ]
    for regex, string in test_regexes:
        r = lazy_compile(regex)
        # Don't check that the proxy has no members, because several
        # functions will create members on demand
        #self.assertEqual(dir(r), [])
        m = r.search(string)
        self.assertTrue(m is not None)
        # Check that

# Generated at 2022-06-21 21:53:44.605577
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Function re.compile has been overridden.

    No checks for whether it actually does anything as we do not have
    documentation for the module.
    """
    install_lazy_compile()
    reset_compile()


# Generated at 2022-06-21 21:53:52.763381
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = LazyRegex(('[0-9]',))
    assert(r._real_regex is None)
    assert(r._regex_args == ('[0-9]',))


# Generated at 2022-06-21 21:53:54.954313
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern("Foo")
    except InvalidPattern as e:
        assert("Foo" in str(e))

# Generated at 2022-06-21 21:54:06.793089
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() changes re.compile()."""
    re.compile('a')
    _real_re_compile = re.compile
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError(
            "install_lazy_compile failed to install lazy_compile")
    if lazy_compile('a') != _real_re_compile('a'):
        raise AssertionError(
            "install_lazy_compile did not create a compatible proxy")
    # Make sure a pickle works.
    p = lazy_compile('a')
    import cPickle
    unpickled = cPickle.loads(cPickle.dumps(p))

# Generated at 2022-06-21 21:54:18.666341
# Unit test for function lazy_compile
def test_lazy_compile():
    compile_count = [0]
    class CountingRegex(object):
        def __init__(self, pattern, flags=0):
            self.pattern = pattern
            compile_count[0] += 1
        def search(self, string, pos=0, endpos=None):
            if string == self.pattern:
                return True
            else:
                return False
    _real_re_compile = re.compile

# Generated at 2022-06-21 21:54:23.893847
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test construction of InvalidPattern class."""
    i = InvalidPattern("msg")
    # __str__ should also work
    str(i)
    # unicode should work
    unicode(i)
    # repr should work
    repr(i)
    i_copy = InvalidPattern("msg")
    assert i == i_copy

# Generated at 2022-06-21 21:54:26.521850
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'cause of error'
    e = InvalidPattern(msg)
    assert e.__str__() == "Invalid pattern(s) found. %s" % (msg,)

# Generated at 2022-06-21 21:54:31.529779
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    args = (r'^\s*\|\s*$',)
    kwargs = {}
    proxy = LazyRegex(args, kwargs)
    state = proxy.__getstate__()
    expected = {
        "args": args,
        "kwargs": kwargs,
        }
    assert state == expected, \
        "wrong state returned by method __getstate__ of class LazyRegex"


# Generated at 2022-06-21 21:54:39.188664
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """ Test that LazyRegex.__getstate__ returns the state of the instance.
    """
    from bzrlib.tests.per_regex import TestCase
    test_case = TestCase()
    lazy = LazyRegex(('abc', 0))
    lazy._compile_and_collapse()
    test_case.assertEqual({
        "args": ('abc', 0),
        "kwargs": {},
        }, lazy.__getstate__())


# Generated at 2022-06-21 21:54:45.146281
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ method of class InvalidPattern should return ascii strings
    as unicode and unicode strings as is"""
    obj = InvalidPattern('Invalid regular expression:')
    obj._preformatted_string = 'ascii string'
    assert isinstance(obj.__unicode__(), unicode)
    obj._preformatted_string = u'unicode string'
    assert isinstance(obj.__unicode__(), unicode)

# Generated at 2022-06-21 21:54:51.635997
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.tests.i18n_tests import gettext_noop
    import sys
    orig_gettext = gettext
    try:
        gettext = gettext_noop
        s = str(InvalidPattern("some message"))
        if sys.version_info[0] == 2:
            assert s == 'Invalid pattern(s) found. "some message" '
        else:
            assert s == "Invalid pattern(s) found. 'some message' "
    finally:
        gettext = orig_gettext


# Generated at 2022-06-21 21:55:07.995201
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the method LazyRegex.__setstate__"""
    from bzrlib.tests import TestCase
    class TestLazyRegex__setstate__(TestCase):

        def test___setstate__(self):
            lazy_regex = LazyRegex(('test',), {'flags': re.M})
            lazy_regex.__setstate__({
                'args': ('blah',),
                'kwargs': {'flags': re.I},
            })
            self.assertEqual(('blah',), lazy_regex._regex_args)
            self.assertEqual({'flags': re.I}, lazy_regex._regex_kwargs)
    run_unittest(TestLazyRegex__setstate__)

# Generated at 2022-06-21 21:55:13.811501
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """__str__ of InvalidPattern should return a str not a unicode object.

    This is because all bzrlib exceptions should return  a str object,
    not a unicode object.
    """
    t = InvalidPattern('msg')
    s = str(t)
    # Make sure s is a string and not a unicode object.
    if isinstance(s, unicode):
        raise AssertionError('InvalidPattern().__str__() should return a str object. Found %s.' % (s,))

# Generated at 2022-06-21 21:55:23.789771
# Unit test for function lazy_compile

# Generated at 2022-06-21 21:55:26.153149
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should always return a str."""
    assert isinstance(InvalidPattern('foo').__repr__(), str)

# Generated at 2022-06-21 21:55:36.595132
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import _i18n_string
    _preformatted_string = _i18n_string("%(msg)s")
    _i18n_string("Invalid pattern(s) found. %(msg)s")
    invalid_pattern = InvalidPattern("msg")
    invalid_pattern._preformatted_string = _preformatted_string
    unicode_pattern = _i18n_string("Invalid pattern(s) found. msg")
    __tracebackhide__ = True
    try:
        raise invalid_pattern
    except InvalidPattern as e:
        assert e.msg == "msg"
        bzr_exc = str(e)
        assert bzr_exc == unicode_pattern.encode('utf8')
        # We can call unicode without args

# Generated at 2022-06-21 21:55:48.056684
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method LazyRegex.__getattr__"""

    # create the LazyRegex which will be used to test attribute access
    lr = LazyRegex(("^dummy",), {})
    # check that the wanted attribute hasn't been set yet
    try:
        lr.match
    except AttributeError:
        pass
    else:
        raise AssertionError("LazyRegex.match should not exist yet")

    # check that the attribute can be found and is the one we expect
    match = lr.match
    if not hasattr(match, '__name__') or match.__name__ != '_real_match':
        raise AssertionError("LazyRegex.match should be indirected to "
                             "re.match")

    # check that the matching function has been cached
    match

# Generated at 2022-06-21 21:55:52.272954
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() must return a unicode object"""
    instance = InvalidPattern("foo")
    result = instance.__unicode__()
    assert isinstance(result, unicode), "%r is not a unicode object" % result

# Generated at 2022-06-21 21:55:57.187456
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Example of method __str__()"""
    try:
        raise InvalidPattern('string %(msg)s')
    except InvalidPattern as e:
        if str(e) != 'string msg':
            raise AssertionError('__str__() returned %r but should be %r'
                                 % (str(e), 'string msg'))

# Generated at 2022-06-21 21:55:59.859593
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ returns a dict"""
    rex = LazyRegex((), {})
    state = rex.__getstate__()
    assert isinstance(state, dict)



# Generated at 2022-06-21 21:56:02.795520
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """repr(InvalidPattern(message)) == "InvalidPattern(message)"."""
    assert repr(InvalidPattern("message")) == "InvalidPattern(message)"

# Generated at 2022-06-21 21:56:19.213397
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # We don't want to use bzrlib.branchbuilder to build a tree because
    # this test must not depend on any DB access or any plugins.

    # The current implementation of LazyRegex has __slots__, so comparison
    # with None only works if we are comparing the same object.
    # However, we want to avoid creating a real regex, because we want this
    # test to test the construction/initialization of
    # LazyRegex.
    # So we use the non-zero integer 0 as a fake real regex.
    real_regex = 0

    # Create a LazyRegex with an empty list of arguments
    args = []
    kwargs = {}
    l = LazyRegex(args, kwargs)
    # Check that the LazyRegex is properly initilized
    assert l._real_

# Generated at 2022-06-21 21:56:23.117523
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # Given an instance of class InvalidPattern
    msg = 'InvalidPattern message'
    obj = InvalidPattern(msg)
    # When calling it's repr method
    repr_obj = repr(obj)
    # I get a string representation of the class and its arguments
    expected_repr_obj = 'InvalidPattern(%s)' % msg
    assert repr_obj == expected_repr_obj

# Generated at 2022-06-21 21:56:26.142416
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    r1 = re.compile('[a-z]*')
    d = r1.__getstate__()
    r2 = re.compile('')
    r2.__setstate__(d)

# Generated at 2022-06-21 21:56:31.750019
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """ __getattr__(self, attr) should return a member from
        the proxied regex object. If the regex hasn't been
        compiled yet, compile it
    """
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-21 21:56:36.487417
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class_ = InvalidPattern
    # constructor should bind 'msg' argument to 'self.msg'
    msg = 'foo'
    e = class_(msg)
    eq = e.msg
    assert isinstance(eq, str)
    assert eq == msg
    e = class_(unicode(msg))
    eq = e.msg
    assert isinstance(eq, unicode)
    assert eq == msg
    e = class_(msg)
    eq = e.msg
    assert isinstance(eq, str)
    assert eq == msg
    e = class_(unicode(msg))
    eq = e.msg
    assert isinstance(eq, unicode)
    assert eq == msg


# Generated at 2022-06-21 21:56:44.316450
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lazy_rego = LazyRegex((''), {})
    expected_dict = {
        "args": (''),
        "kwargs": {},
    }
    result_dict = lazy_rego.__getstate__()
    for key in result_dict:
        assert key in expected_dict
        assert result_dict[key] == expected_dict[key]

    expected_dict = {
        "args": ('pattern'),
        "kwargs": {},
    }
    result_dict = LazyRegex(('pattern'), {}).__getstate__()
    for key in result_dict:
        assert key in expected_dict
        assert result_dict[key] == expected_dict[key]


# Generated at 2022-06-21 21:56:50.879319
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex."""
    import pickle
    lazy_regex = LazyRegex(("^.*$",), {})
    lazy_regex.__setstate__({'args': ("^.*$",),
                             'kwargs': {}})
    lazy_regex.__getstate__()
    pickle.loads(pickle.dumps(lazy_regex))