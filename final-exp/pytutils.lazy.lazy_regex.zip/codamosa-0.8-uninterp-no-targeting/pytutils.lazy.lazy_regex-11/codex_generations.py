

# Generated at 2022-06-21 21:47:13.884126
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib.i18n import ui
    from bzrlib import trace
    try:
        e = InvalidPattern('hello world')
    except Exception:
        trace.mutter('error instantiating InvalidPattern')
        raise
    try:
        estr = str(e)
    except Exception:
        trace.mutter('error stringifying InvalidPattern', exc_info=True)
        raise
    # str(e) must be a str and not a unicode instance
    # because there are places where we do not yet
    # expect unicode exceptions.
    if not isinstance(estr, str):
        trace.mutter('error converting InvalidPattern:'
                     ' str(e) is a %s not an str'
                     % (type(estr),))

# Generated at 2022-06-21 21:47:24.521410
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    LazyRegex()
    LazyRegex(('foo',))
    LazyRegex((('foo',),))
    LazyRegex((('foo',),), {})
    LazyRegex((), {'flags':0})
    LazyRegex((), {'flags':'I', 'flags':'I'})
    # What can happen is that the constructor which takes an existing regex
    # could mask that the object is a LazyRegex proxy object.
    # So it should be stricly forbidden to subclass LazyRegex
    import sys
    def subclass_LazyRegex():
        class MyLazyRegex(LazyRegex):
            pass
    raises(TypeError, subclass_LazyRegex)
    # or to mix it

# Generated at 2022-06-21 21:47:30.286951
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr = LazyRegex(('attention',), {'flags': re.IGNORECASE})
    assert lr._regex_args == ('attention',)
    assert set(lr._regex_kwargs.items()) == set([('flags', re.IGNORECASE)])



# Generated at 2022-06-21 21:47:41.756740
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib import __version__
    from bzrlib import i18n

    try:
        # This should work for 2.6, 2.7 and 2.4
        raise InvalidPattern('%(msg)s')
    except InvalidPattern as e:
        assert str(e) == __version__ + ': Invalid pattern(s) found. %(msg)s'

    # Check that if an exception string is provided, it will be used and
    # expanded correctly
    i18n.gettext_for_module(__name__, '_fmt', 'Invalid pattern(s) found. %(msg)s')
    try:
        raise InvalidPattern('My message')
    except InvalidPattern as e:
        assert str(e) == __version__ + ': Invalid pattern(s) found. My message'

# Generated at 2022-06-21 21:47:50.183534
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern."""
    assert InvalidPattern('msg1') == InvalidPattern('msg1')
    assert InvalidPattern('msg2') == InvalidPattern('msg2')
    assert InvalidPattern('msg1') != InvalidPattern('msg2')
    assert InvalidPattern('msg1') != None
    assert InvalidPattern('msg1') != "msg1"
    assert InvalidPattern('') == InvalidPattern('')
    assert InvalidPattern('msg1') != InvalidPattern('')
    assert InvalidPattern('') != InvalidPattern('msg1')

# Generated at 2022-06-21 21:47:55.956689
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for __str__ of class InvalidPattern"""
    ip = InvalidPattern("mypattern")

    # test for str
    assert str(ip) == "mypattern"

    # test for unicode
    assert unicode(ip) == "mypattern"

    # test when the message contains a format operator
    ip = InvalidPattern("This is invalid pattern %s")
    try:
        str(ip)
    except TypeError as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        assert exc_type == TypeError
        assert str(e) == "not all arguments converted during string formatting"
    else:
        raise AssertionError('Test has failed: TypeError is expected')

    try:
        unicode(ip)
    except TypeError as e:
        exc_type, exc_

# Generated at 2022-06-21 21:47:58.655556
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of class InvalidPattern works as expected"""
    msg = "Pattern 'foo' is invalid"
    e = InvalidPattern(msg)
    assert str(e) == msg, "__str__ of class InvalidPattern failed"

# Generated at 2022-06-21 21:48:04.601955
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str"""
    error = InvalidPattern(u'invalid pattern')
    assert isinstance(str(error), str)
    error = InvalidPattern(u'invalid pattern')
    error._preformatted_string = 'Unicode String'
    assert isinstance(str(error), str)

# Generated at 2022-06-21 21:48:10.498534
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lr = lazy_compile("a")
    lr._compile_and_collapse()
    assert lr.__getstate__() == {'args': ('a',), 'kwargs': {}}


# Unit tests for the pickling code
#
# These are only run if the pickle module is importable. The other tests in
# this module do not require it.

# Generated at 2022-06-21 21:48:18.756243
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'abc'
    e = InvalidPattern(msg)
    assert e.msg == msg
    # __unicode__() and __str__() is provided by the superclass Exception
    # for backward compatibility.
    assert e.__unicode__() == u'abc'
    assert e.__str__() == 'abc'
    assert str(e) == 'abc'
    assert repr(e) == 'InvalidPattern(abc)'

    # preformatted string should be returned by __str__()
    e = InvalidPattern('')
    e._preformatted_string = 'def'
    assert e.__str__() == 'def'
    assert e.__unicode__() == u'def'

    # _fmt attribute is used to format exception messages
    e._fmt = '%(msg)s'
    assert e

# Generated at 2022-06-21 21:48:30.227997
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ of LazyRegex can find member when not compiled."""
    lr = LazyRegex()
    try:
        lr.foo
    except AttributeError:
        pass
    else:
        raise AssertionError('Should raise AttributeError')


# Generated at 2022-06-21 21:48:32.370156
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__ compares the contents of the exception"""
    e1 = InvalidPattern('abc')
    e2 = InvalidPattern('abc')
    e3 = InvalidPattern('def')
    assert e1 == e2
    assert not (e1 != e2)
    assert e1 != e3
    assert not (e1 == e3)

# Generated at 2022-06-21 21:48:38.879266
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ returns a member from the proxied regex object."""
    lr = LazyRegex(r'foo')
    assert lr.pattern == r'foo' # LazyRegex checks if attribute _real_regex exists
    assert lr.match('foobar') is not None # Then triggers it to be compiled.
    assert lr.pattern == r'foo'
    assert lr.match('bar') is None


# Generated at 2022-06-21 21:48:44.190933
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    def check(s):
        e = InvalidPattern(s)
        assert e.msg == s
        assert str(e) == s
        # deepcopy() and copy() are not supported
        import copy
        assert copy.copy(e) is e
        assert copy.deepcopy(e) is e

    check('msg')
    check('%(some_key)s')
    try:
        1/0
    except:
        s = str(InvalidPattern('msg'))
        assert s.split(' ', 1)[0] == 'Unprintable'

# Generated at 2022-06-21 21:48:53.485146
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    text = u"Ow\u00ebrschwelligkeit"
    # On python2.7 and python3.3 InvalidPattern is derived from ValueError.
    # On python3.2 and python2.6 InvalidPattern is derived from UnicodeError.
    # On python2.5 InvalidPattern is derived from Exception.
    # Therefore we catch not only InvalidPattern but all its base classes.
    try:
        raise InvalidPattern(text)
    except (InvalidPattern, UnicodeError, ValueError, Exception) as e:
        assert isinstance(unicode(e), unicode)
        assert isinstance(str(e), str)
        assert isinstance(repr(e), str)
        assert e.msg == text

# Generated at 2022-06-21 21:49:00.229228
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests import TestCase
    install_lazy_compile()
    p = re.compile('a*')
    self.assertIsInstance(p, LazyRegex)
    reset_compile()
    p = re.compile('a*')
    self.assertIsInstance(p, re._pattern_type)
    self.assertNotIsInstance(p, LazyRegex)



# Generated at 2022-06-21 21:49:02.481310
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test __unicode__()"""
    e = InvalidPattern('msg')
    assert unicode(e) == 'msg'



# Generated at 2022-06-21 21:49:14.089462
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = LazyRegex((r'^.*$',))
    assert r._regex_args == (r'^.*$',)

    def get_groups(__):
        return 'b'
    _real_re_compile = re.compile
    def _re_compile(pattern):
        r = _real_re_compile(pattern)
        r.match = lambda a: get_groups
        return r
    re.compile = _re_compile
    try:
        assert r.match('a').groups() == 'b'
    finally:
        re.compile = _real_re_compile

# Generated at 2022-06-21 21:49:27.718761
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # Testing InvalidPattern.__eq__
    # No 'msg' attributes, so can be equal
    # Comparing InvalidPattern instances, returns True
    a = InvalidPattern("first message")
    b = InvalidPattern("another message")
    # Comparing with a different class of object returns False
    c = object()
    # Comparing with an instance of the same class but with different
    # attributes returns False
    d = InvalidPattern("yet another message")
    __test_eq(a, b, c, d)

    # Testing InvalidPattern.__ne__
    # In Python 2.x, C{==} returns C{NotImplemented} for objects that
    # are not instances of InvalidPattern.
    # That causes Python 2.x to try "not a.__eq__(b)" and
    # raises AttributeError, C{__ne__}

# Generated at 2022-06-21 21:49:40.838134
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import six

    if six.PY3:
        from io import BytesIO
        from io import StringIO
        str_io = BytesIO()
        uni_io = StringIO()
    else:
        str_io = StringIO()
        uni_io = None
    def w(s):
        str_io.write(s)
        if uni_io is not None:
            uni_io.write(s.decode('utf8'))
    ip = InvalidPattern('pattern')
    ip._fmt = 'Invalid pattern %(project_name)s: %(msg)s'

    ip.project_name = 'foo'
    ip.msg = 'usage'
    ip._preformatted_string = 'preformatted'
    ip._get_format_string = None

# Generated at 2022-06-21 21:49:56.095824
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    c = InvalidPattern("message")
    assert c.msg == "message"


# Module level constants for testing.
_TEST_RE = re.compile("^a+$")
_TEST_RE_FAIL = re.compile("^(?P<a>")
_TEST_RE_FAIL2 = re.compile("^(?P<a>$")
_TEST_RE_FAIL3 = re.compile("^(?P<a>b)$")
_TEST_RE_FAIL4 = re.compile("^(?P<a>.)$")
_TEST_STR = "aaaaa"
_TEST_TUPLE = (1, 2)
_TEST_DICT = {"a": "b"}



# Generated at 2022-06-21 21:49:58.169537
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    err = InvalidPattern('foo')
    assert err.msg == 'foo'

# Generated at 2022-06-21 21:50:07.620484
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the behaviour of constructing a LazyRegex object."""
    LazyRegex()
    LazyRegex("pattern")
    LazyRegex("pattern", re.DOTALL)
    LazyRegex("pattern", 0, re.DOTALL)
    LazyRegex("pattern", re.DOTALL, re.DEBUG)
    LazyRegex("pattern", 0, re.DOTALL, re.DEBUG)
    LazyRegex("pattern", 0, re.DOTALL, re.DEBUG, 10)
    LazyRegex("pattern", 0, re.DOTALL, re.DEBUG, 10, 20)
    import sys
    if sys.version_info[0:2] < (2, 7):
        # Python 2.6 does not accept keyword arguments for re.compile
        return
    LazyRe

# Generated at 2022-06-21 21:50:15.969021
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test case for method __setstate__ of class LazyRegex"""
    lazy_regex_pickled = re._pickle.dumps(LazyRegex(("pattern", re.I)))
    lazy_regex_loaded = re._pickle.loads(lazy_regex_pickled)
    assert lazy_regex_loaded._regex_args == ("pattern", re.I)
    assert lazy_regex_loaded._regex_kwargs == {}

# Generated at 2022-06-21 21:50:19.033013
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test that 'repr' function returns a string"""
    p = InvalidPattern('testing')
    assert isinstance(repr(p), str)


# Generated at 2022-06-21 21:50:20.908345
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    ex = InvalidPattern('foo')
    assert repr(ex) == 'InvalidPattern(foo)'

# Generated at 2022-06-21 21:50:28.614515
# Unit test for function finditer_public
def test_finditer_public():
    """Test finditer_public"""

    t = ('abcd', 'abcd', 0)
    # Test when we are given a LazyRegex
    l_regex = lazy_compile('a', 0)
    results = finditer_public(l_regex, *t)
    assert(results[0].group(0) == 'a')
    # Test when we are given a regex
    results = finditer_public(*t)
    assert(results[0].group(0) == 'a')

# Generated at 2022-06-21 21:50:38.773498
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test if the function install_lazy_compile works correctly.

    This test is doing a bit of hackery to test that the right result is
    returned. It uses a side-effect of calling re.compile to work out
    if the expected result was returned.
    """
    import re

    regex = re.compile('not lazy')
    regex2 = re.compile('also not lazy')

    assert len(regex.pattern) == len('not lazy')
    assert len(regex2.pattern) == len('also not lazy')

    import bzrlib.lazy_regex

    bzrlib.lazy_regex.install_lazy_compile()
    regex = re.compile('lazy')
    regex2 = re.compile('also lazy')


# Generated at 2022-06-21 21:50:40.259760
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    exc = InvalidPattern('Pattern error: Unknown letter (A)')
    assert str(exc) == "Invalid pattern(s) found. Pattern error: Unknown letter (A)"
    assert repr(exc) == "InvalidPattern(Pattern error: Unknown letter (A))"



# Generated at 2022-06-21 21:50:47.686196
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should compare all the values in __dict__."""
    class MyException(InvalidPattern):
        _fmt = 'my message'

    e1 = MyException('foo')
    e2 = MyException('bar')
    e3 = MyException('foo')
    import copy
    e4 = copy.deepcopy(e1)
    assert(e1 != e2)
    assert(e1 == e3)
    assert(e1 == e4)

# Generated at 2022-06-21 21:51:01.625894
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern.
    """
    error = InvalidPattern('foo')
    repr_str = repr(error)
    assert repr_str == "InvalidPattern('foo')"


if __name__ == '__main__':
    # some simple tests.
    pattern = lazy_compile('(?P<branch_nick>.*)')
    assert pattern.match('a').groupdict() == {'branch_nick': 'a'}
    assert pattern.match('a').group() == 'a'
    assert pattern.match('a').group(0) == 'a'
    assert pattern.match('a').groups() == ('a',)
    assert pattern.match('a').groupdict() == {'branch_nick': 'a'}

# Generated at 2022-06-21 21:51:11.856906
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex's __getstate__ method should return a dict of args and kwargs
    which are used to create a LazyRegex."""
    lazy_regex = LazyRegex((b"abc",), {})
    expected_state = {
        "args": (b"abc",),
        "kwargs": {},
    }
    state = lazy_regex.__getstate__()
    if expected_state["args"] != state["args"]:
        raise AssertionError(b"Expected args: %s != state's args: %s"
                             % (expected_state["args"], state["args"]))

# Generated at 2022-06-21 21:51:24.568451
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for the LazyRegex.__getattr__ method.

    This method was found to be broken during conversion to using pythons
    new-style classes. The reason was that attributes are looked up in
    the base LazyRegex class, and not in the proxied _sre.SRE_Pattern
    class, and hence the attributes were never found. This testcase
    demonstrates that the attributes are now looked up in the proxied
    _sre.SRE_Pattern class.
    """

# Generated at 2022-06-21 21:51:33.247218
# Unit test for function reset_compile
def test_reset_compile():
    """Unit test for function reset_compile
    """
    install_lazy_compile()
    reset_compile()
    regex = re.compile("foo")
    assert regex._real_regex is not None
    assert isinstance(regex._real_regex, _real_re_compile("foo").__class__), \
        'regex._real_regex is of wrong type.'

# Generated at 2022-06-21 21:51:42.580330
# Unit test for function lazy_compile
def test_lazy_compile():
    import sys

    if sys.version_info < (2, 7):
        # Lazy regexes did not exist before python 2.7
        return

    install_lazy_compile()
    try:
        # Just a simple test to verify that it works. We use the
        # existing test suite to verify that it is correct
        prog = re.compile("gold is where you bury dead people")
        assert prog.search("gold is where you bury dead people") is not None
        reset_compile()
    finally:
        reset_compile()

# Generated at 2022-06-21 21:51:49.646074
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Check that install_lazy_compile() actually installs lazy_compile()."""
    re.compile = _real_re_compile
    install_lazy_compile()
    # First test that our install is persistent
    pattern1 = re.compile(r'foo')
    assert isinstance(pattern1, LazyRegex), ("Expected LazyRegex, got " +
        str(type(pattern1)))
    assert not hasattr(pattern1, "_real_regex")
    # Now test that we are transparent
    pattern2 = re.compile(r'foo')
    assert pattern2._real_regex is not None
    # Now reset compile, and test it
    reset_compile()
    pattern3 = re.compile(r'foo')
    assert pattern3.pattern == 'foo'
   

# Generated at 2022-06-21 21:51:54.247785
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError('re.compile is not lazy_compile')

# Generated at 2022-06-21 21:52:05.950070
# Unit test for function lazy_compile
def test_lazy_compile():
    """LazyRegex objects are a proxy that compile on first use.

    >>> import re
    >>> real_re = re.compile
    >>> re.compile = lazy_compile
    >>> class TestException(Exception):
    ...     # A class to make it easier to check for errors
    ...     pass
    >>> regex = re.compile('^(?:Bzr\w+|bzr)$')
    >>> regex
    <LazyRegex object at ...>
    >>> regex.compile is real_re
    True
    >>> regex._real_regex
    >>> regex.match
    Traceback (most recent call last):
      ...
    TestException
    >>> regex._real_regex = TestException
    >>> regex.match
    Traceback (most recent call last):
      ...
    TestException
    """



# Generated at 2022-06-21 21:52:13.546128
# Unit test for function finditer_public
def test_finditer_public():
    import re
    assert re.finditer("a", "a")
    assert re.finditer(_real_re_compile("a"), "a")
    re.compile = lazy_compile
    assert re.finditer("a", "a")
    assert re.finditer(_real_re_compile("a"), "a")
    re.compile = _real_re_compile
    assert re.finditer("a", "a")
    assert re.finditer(_real_re_compile("a"), "a")
    re.compile = lazy_compile
    assert re.finditer("a", "a")
    assert re.finditer(_real_re_compile("a"), "a")
    re.compile = _real_re_compile
    assert re.finditer("a", "a")


# Generated at 2022-06-21 21:52:23.308947
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method _InvalidPattern__unicode__

    This tests the methods which build the string and then the
    method __unicode__ itself with various inputs.
    """
    def _do_test(input_value):
        e = InvalidPattern(input_value)
        result = getattr(e, '_preformatted_string', None)
        if result is not None:
            return result
        result = getattr(e, '_get_format_string', None)()
        if result is not None:
            return result
        raise RuntimeError(
            "Unable to get a test value from method _do_test")

    # A _preformatted_string
    _do_test('abcdefg')
    # A _fmt string
    _do_test('%(msg)s')
    # A _fmt

# Generated at 2022-06-21 21:52:37.875005
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for the LazyRegex class"""
    # Subversion currently uses the expression
    #
    #    re.compile(r"^([A-Za-z]):").match(path)
    #
    # to split the path into (drive, tail). This is a bogus test, as
    # drives are not used on Unix, but it will do for the purposes of
    # unit testing.
    #
    # As of Python 2.6, this code is replaced in subversion's
    # swig/python/svn/core.py by a call to os.path.splitdrive(), so we
    # should never get here.
    path = 'C:/Windows'
    pattern = r"^([A-Za-z]):"
    obj = LazyRegex((pattern,))

# Generated at 2022-06-21 21:52:47.233270
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex."""
    import pickle
    import StringIO
    def _do_test(args, kwargs):
        lr = LazyRegex(args, kwargs)
        lr._compile_and_collapse()

        buf = StringIO.StringIO()
        pickle.dump(lr, buf)

        buf.seek(0)
        lr2 = pickle.load(buf)

        for a in args:
            assert not lr2._regex_args[0].startswith("(?P<")
        for k in kwargs:
            assert kwargs[k] == lr2._regex_kwargs[k]

    _do_test(["(?P<foo>.*)"], {})
    _do_

# Generated at 2022-06-21 21:52:58.110542
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test_InvalidPattern___str__

    This unit test tests the method __str__ of class InvalidPattern.
    """
    from bzrlib.i18n import gettext

    class InvalidPatternTest(InvalidPattern):
        """A test class for testing the method __str__ of class InvalidPattern.
        """

        _fmt = 'This is a test: %(msg)s'

    # Test when _fmt is ASCII
    e = InvalidPatternTest('Test')
    if str(e) != 'This is a test: Test':
        raise AssertionError(
            "error string should be 'This is a test: Test', but is %r"
            % str(e))

# Generated at 2022-06-21 21:53:03.892751
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode string"""
    error = InvalidPattern("test error message")
    actual = error.__unicode__()
    expected = u"Invalid pattern(s) found. test error message"
    assert(isinstance(actual, unicode))
    assert(actual == expected)



# Generated at 2022-06-21 21:53:13.520773
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the method __getstate__ of class LazyRegex.

    This test uses a mock object to emulate the compiling method.
    """
    fake_regex = LazyRegex(('[A-Z]+',), {'flags': re.IGNORECASE})
    fake_regex._real_re_compile = lambda *a, **kw: True
    fake_regex.match('aaa')
    state = fake_regex.__getstate__()
    expected_state = {
        "args": ('[A-Z]+',),
        "kwargs": {'flags': re.IGNORECASE}
    }
    assert state == expected_state, state


# Generated at 2022-06-21 21:53:18.359376
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test constructor of class LazyRegex"""

    obj = LazyRegex(('a', re.IGNORECASE))
    assert obj._regex_args == ('a', re.IGNORECASE)
    assert obj._regex_kwargs == {}
    assert obj._real_regex is None


# Generated at 2022-06-21 21:53:28.917801
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method __setstate__ of LazyRegex class.

    Class LazyRegex is a proxy object, which create real regex object when
    it is required. Method _compile_and_collapse do this action. Therefore
    we need to call this method when we unpickle LazyRegex.

    :return: None
    :raise TestSkipped: if method _compile_and_collapse doesn't call _real_re_compile
    """
    from StringIO import StringIO
    from tempfile import TemporaryFile

    from bzrlib.tests import TestCase

    from bzrlib.lazy_re import LazyRegex, _real_re_compile

    real_re_compile_wrapper = [None] # wrapper for _real_re_compile

# Generated at 2022-06-21 21:53:36.214234
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    assert re.compile == lazy_compile
    reset_compile()
    assert re.compile == _real_re_compile
    reset_compile()
    assert re.compile == _real_re_compile
    # and for good measure, test that the underlying regex compilation works
    # correctly.
    re.compile("")


# Generated at 2022-06-21 21:53:40.124707
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    lazy = LazyRegex(args=(r'a(b)',))
    # access a method that is not supported natively by LazyRegex
    # this will trigger the compilation of the real regex
    assert lazy.sub(r'foo', 'b') == 'foo'

# Generated at 2022-06-21 21:53:49.551234
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__() should produce a string"""
    import sys
    import pickle
    # a unicode string for fun
    s = InvalidPattern(u"unicode \u1234")
    # these should be unicode strings
    s.__repr__()
    repr(s)
    # these should be bytestrings
    s.__str__()

    # we should be able to pickle and unpickle the Exception instance
    pickled = pickle.dumps(s)
    unpickled = pickle.loads(pickled)
    assert s == unpickled

    # and it should still provide a string representation
    assert unpickled.__repr__() is not None

# Generated at 2022-06-21 21:54:06.378946
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import install_gettext_translations
    import os
    import tempfile
    import shutil
    import sys
    dirname = tempfile.mkdtemp()

# Generated at 2022-06-21 21:54:07.522924
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    LazyRegex()

# Generated at 2022-06-21 21:54:10.022567
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    obj = LazyRegex(('(a)+', ), {})
    assert pickle.loads(pickle.dumps(obj)) == obj


# Generated at 2022-06-21 21:54:21.329763
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must always return a unicode object"""
    b_input = '\xe9'
    u_expected = u'\xe9'
    from StringIO import StringIO
    from bzrlib import osutils
    from bzrlib import trace
    from bzrlib.i18n import gettext
    from bzrlib.i18n import install_text_extraction
    install_text_extraction()
    old_stderr, sys.stderr = sys.stderr, StringIO()

# Generated at 2022-06-21 21:54:25.716876
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import doctest
    from bzrlib.tests import TestCase
    tests = doctest.DocTestSuite(provide_obj=dict(
        InvalidPattern=InvalidPattern))
    tests.layer = TestCase
    return tests

# Generated at 2022-06-21 21:54:27.940799
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string that can be evaluated
    to give an instance of the class.
    """
    invalid_pattern = InvalidPattern('msg')
    exec("%r" % (invalid_pattern,))



# Generated at 2022-06-21 21:54:32.943760
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    assert str(InvalidPattern('foo bar')) == 'Invalid pattern(s) found. foo bar'
    assert unicode(InvalidPattern('foo bar')) == u'Invalid pattern(s) found. foo bar'
    assert repr(InvalidPattern('foo bar')) == "InvalidPattern(Invalid pattern(s) found. foo bar)"


# Generated at 2022-06-21 21:54:38.415276
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of LazyRegex"""
    regex = lazy_compile('(?P<name>.*)')
    assert regex._real_regex is None
    assert regex._regex_args == ('(?P<name>.*)', )
    assert regex._regex_kwargs == {}

# Generated at 2022-06-21 21:54:44.507808
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    lazy_compile = LazyRegex(('a',))
    real_compile = re.compile('a')
    assert getattr(lazy_compile, 'pattern') == real_compile.pattern
    # Make sure __getattr__ is called only once.
    assert getattr(lazy_compile, 'pattern') == real_compile.pattern

# Generated at 2022-06-21 21:54:52.724773
# Unit test for constructor of class LazyRegex

# Generated at 2022-06-21 21:54:59.630430
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    raise InvalidPattern('')

# Generated at 2022-06-21 21:55:03.293610
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    try:
        res = re.compile('foo')
        assert isinstance(res, LazyRegex)
    finally:
        reset_compile()

# Generated at 2022-06-21 21:55:13.186541
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Testing method __getattr__ of class LazyRegex"""

    class Reg(LazyRegex):
        pass

    Reg._regex_attributes_to_copy = [
                 'attr1', 'attr2'
                 ]
    Reg.__slots__ = ['_real_regex', '_regex_args', '_regex_kwargs',
        'attr1', 'attr2'
        ]

    # testing that an LazyRegex object is correctly unwrapped
    reg = Reg()
    assert reg.attr1 == reg._real_regex.attr1
    assert reg.attr2 == reg._real_regex.attr2

    # testing that an exception is raised if an attribute does not exist.
    try:
        reg.unknown_attribute
    except AttributeError:
        pass

# Generated at 2022-06-21 21:55:15.109551
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import doctest
    return doctest.DocTestSuite('bzrlib.lazy_regex')



# Generated at 2022-06-21 21:55:16.526687
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()
    reset_compile()
    reset_compile()

# Generated at 2022-06-21 21:55:30.165957
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the LazyRegex class"""
    # Testing the constructor of class LazyRegex requires comparing two
    # LazyRegex objects with different _regex_args and _regex_kwargs.
    # Unfortunately comparison of two objects are done by comparing the
    # objects themselves, which is not what we want to do.  So we create two
    # objects, check that they are different, and then check that they are
    # equal.
    # For the same reason, we cannot test that the lazy regex has no attribute
    # before calling the private method _compile_and_collapse.
    lr1 = LazyRegex(('a',), {'b': 1})
    lr2 = LazyRegex(('c',), {'d': 2})

# Generated at 2022-06-21 21:55:31.239708
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    InvalidPattern('hello world').__str__()

# Generated at 2022-06-21 21:55:39.071926
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that LazyRegex.__getattr__ actually works.

    Note that 'test' attribute is only defined for _real_regex,
    but LazyRegex.__getattr__ method should be able to fetch it.
    """
    def test_with_transform_func(transform_func):
        regex_obj = transform_func('.*')
        if not isinstance(regex_obj, LazyRegex):
            # We can't test a non-LazyRegex
            return
        # We have a LazyRegex, try to get the 'test' attribute
        regex_obj.test('hello')
    test_with_transform_func(lazy_compile)
    test_with_transform_func(re.compile)

# Generated at 2022-06-21 21:55:44.914710
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ of LazyRegex
    """
    args = ('.*',)
    kwargs = {'flags': re.DOTALL}
    lr = LazyRegex(args, kwargs)
    assert lr.__getstate__() == {'args': args, 'kwargs': kwargs}



# Generated at 2022-06-21 21:55:50.301932
# Unit test for function reset_compile
def test_reset_compile():
    compile_calls = []
    def fake_compile(*args, **kwargs):
        compile_calls.append((args, kwargs))
        return compile_calls

    re.compile = fake_compile
    install_lazy_compile()
    global_re = re
    global_compile = re.compile
    reset_compile()
    re.compile('foo')
    re.findall('bar')
    re.sub('qux', 'quuux')
    re.sub('qux', 'quuux')
    reset_compile()
    re.compile('foo2')
    re.findall('bar2')
    re.sub('qux2', 'quuux2')
    reset_compile()
    re.compile('foo3')

# Generated at 2022-06-21 21:56:03.379532
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from StringIO import StringIO
    from bzrlib.lazy_regex import InvalidPattern

    # Test re.compile exception in a non-Unicode context
    try:
        if __file__:
            raise re.error("re error")
    except re.error as e:
        s = StringIO()
        original_unicode = unicode
        def unicode(s, e=None):
            return original_unicode(s).encode('ascii', 'replace')
        try:
            print >>s, e
            x = s.getvalue()
        finally:
            del unicode

    # Test re.compile exception in a Unicode context
    try:
        if __file__:
            raise re.error("re error")
    except re.error as e:
        s = StringIO()
       

# Generated at 2022-06-21 21:56:14.598002
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ is used to compare exceptions raised by various functions
    """
    msg = "can't match pattern with itself: '.' contains no '*'"
    exc1 = InvalidPattern(msg)
    exc2 = InvalidPattern(msg)
    assert exc1 == exc2

    exc3 = InvalidPattern(msg * 2)
    assert exc1 != exc3

    exc4 = ValueError(msg)
    assert exc1 != exc4


# The following 2 helper functions are required for the tests
# to pass on windows as the module 're' is already loaded.

# Helper function to replace re.compile with the LazyRegex.
install_lazy_compile()


# Helper function to restore re.compile back to its original value.

# Generated at 2022-06-21 21:56:19.436707
# Unit test for function finditer_public
def test_finditer_public():
    """re.finditer function works well with LazyRegex."""
    sample = "This is a sample string"
    pattern = lazy_compile("sample")
    expected = [(u'sample', 8)]
    for actual in re.finditer(pattern, sample):
        assert (actual.group(0), actual.start()) in expected

# Generated at 2022-06-21 21:56:29.014165
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test that LazyRegex.__getstate__ returns the same state as __setstate__
    expects.
    """
    regex = LazyRegex('pattern', re.I | re.U | re.L)
    expected_state = {"args": ('pattern',), "kwargs": {'flags': re.I | re.U | re.L}}
    actual_state = regex.__getstate__()
    if actual_state != expected_state:
        raise AssertionError("Expected LazyRegex.__getstate__() == "
                             "%s == LazyRegex(%s).__getstate__(), but "
                             "got %s"
                             % (expected_state,
                                expected_state,
                                actual_state))

# Generated at 2022-06-21 21:56:39.821092
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    c = None

# Generated at 2022-06-21 21:56:48.376191
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    import sys
    msg = 'this is a message'
    pattern_error = InvalidPattern(msg)
    # Check that __str__ don't raise any exception
    try:
        str(pattern_error)
    except:
        raise AssertionError("__str__ of InvalidPattern should not raise any exception.")
    # Check that the string msg is in the string returned by __str__
    assert msg in str(pattern_error), \
        "method __str__ of class InvalidPattern does not return the string msg."

# Generated at 2022-06-21 21:56:58.856029
# Unit test for function lazy_compile
def test_lazy_compile():
    import pickle
    LazyRegex.__doc__ = 'lalala'
    r = LazyRegex(('regex 1', re.I))
    r2 = pickle.loads(pickle.dumps(r))
    r2._compile_and_collapse()
    r._compile_and_collapse()
    r3 = LazyRegex(('regex 1', re.I))
    r2._compile_and_collapse()
    r4 = LazyRegex(('regex 2', re.I))
    r4._compile_and_collapse()
    r3._compile_and_collapse()
    assert r._real_regex.match('foo')

    k = re.compile('regex 1', re.I)