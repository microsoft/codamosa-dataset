

# Generated at 2022-06-21 21:47:06.012930
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string."""
    err = InvalidPattern('foolish pattern')
    s = 'InvalidPattern(foolish pattern)'
    assert repr(err) == s


# Generated at 2022-06-21 21:47:17.208080
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__()."""
    from bzrlib.i18n import gettext
    assert gettext("Permission denied") != "Permission denied"

    class TestException(ValueError):
        _fmt = "Permission denied"

    exception = TestException()
    unicode_exception = unicode(exception)
    assert unicode_exception == gettext("Permission denied")
    assert str(unicode_exception) == gettext("Permission denied")

    exception = InvalidPattern("Permission denied")
    unicode_exception = unicode(exception)
    assert unicode_exception == gettext("Permission denied")
    assert str(unicode_exception) == gettext("Permission denied")

# Generated at 2022-06-21 21:47:22.150348
# Unit test for function reset_compile
def test_reset_compile():
    if re.compile is not lazy_compile:
        raise AssertionError("re.compile should be lazy_compile")
    reset_compile()
    if re.compile is lazy_compile:
        raise AssertionError("re.compile should not be lazy_compile")

# Install the default lazy compile
install_lazy_compile()

# Generated at 2022-06-21 21:47:28.646249
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ of class LazyRegex must return the requested attribute
    if the regex hasn't been compiled yet.
    """
    regex = LazyRegex(('^a+$',), {})
    assert hasattr(regex, '_real_regex')
    assert regex._real_regex is None
    assert hasattr(regex, 'match')
    assert isinstance(regex.match, types.MethodType)
    assert regex._real_regex is not None
    assert isinstance(regex.match, types.MethodType)



# Generated at 2022-06-21 21:47:32.343326
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    r = re.compile('(?:s)t(?P<group>.*)')
    reset_compile()
    return r

# Generated at 2022-06-21 21:47:42.790330
# Unit test for function reset_compile
def test_reset_compile():
    # These tests are only valid if the re module is using our
    # new lazy_compile.
    if re.compile != lazy_compile:
        return
    try:
        # First we check that calling reset_compile doesn't break re.compile
        reset_compile()
        recompile = re.compile
        reset_compile()
        if not isinstance(recompile, type(re.compile)):
            raise AssertionError(
                "Calling reset_compile() changed re.compile()")
    finally:
        # If we changed re.compile, then we should reset it
        if recompile is not re.compile:
            re.compile = recompile
    # If we have nested calls to install_lazy_compile, they should
    # still be undone by a single call to

# Generated at 2022-06-21 21:47:47.984016
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile works.

    :return: None.
    """
    install_lazy_compile()
    try:
        re.compile('foo')
    except TypeError:
        return
    raise AssertionError('install_lazy_compile did not work')

# Generated at 2022-06-21 21:47:50.069864
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    inv_pat = InvalidPattern("msg")
    assert repr(inv_pat) == "InvalidPattern('msg')"

# Generated at 2022-06-21 21:47:56.286372
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return the state to use when pickling"""
    pattern = LazyRegex(("ab"), dict())
    pickled = pattern.__getstate__()
    assert pickled["args"] == ("ab"), "expected [('ab')], got [%s]" % str(pickled["args"])
    assert pickled["kwargs"] == dict(), "expected [{}], got [%s]" % str(pickled["kwargs"])



# Generated at 2022-06-21 21:47:58.307812
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    from bzrlib.tests import TestUtil
    return doctest.DocTestSuite(TestUtil)

# Generated at 2022-06-21 21:48:06.068997
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-21 21:48:11.514226
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Check that the LazyRegex has the properties for the regexp to be built
    # safely on demand.
    regex = LazyRegex(('foo', re.I), {})
    regex.findall('foo bar Foo')
    regex.findall('abc bar Foo')
    regex.findall('foo bar Bar')


# Generated at 2022-06-21 21:48:15.484880
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return the string representation."""
    try:
        raise InvalidPattern('Example')
    except InvalidPattern as e:
        assert repr(e) == 'InvalidPattern(Example)'

        # The following should not raise an exception
        unicode(e)
        str(e)

# Generated at 2022-06-21 21:48:26.190597
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    real_compile = re.compile
    try:
        install_lazy_compile()
        regex = re.compile("foo")
        # No compile happened yet
        if hasattr(regex, 'pattern'):
            raise AssertionError(
                "re.compile did not return a proxy object")
        # Now it will happen
        regex.match("foo")
        if not hasattr(regex, 'pattern'):
            raise AssertionError(
                "re.compile returned a proxy object that was not compiled")
        if regex.pattern != "foo":
            raise AssertionError(
                "re.compile returned a proxy object that was not the right "
                "regex")
    finally:
        re.compile = real_compile



# Generated at 2022-06-21 21:48:36.561921
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore a LazyRegex's state."""
    lr = LazyRegex(('foo',))
    lr.__setstate__({
        'args': ('bar',),
        'kwargs': {'foo': True}
        })
    # No real regex yet
    eq = getattr(lr, '_real_regex', None) is None
    assert(eq, 'LazyRegex should not be compiled.')
    # Asking for a method makes it compile
    lr.search('foobar')
    eq = lr._real_regex.search('foobar').group() == 'bar'
    assert(eq, 'LazyRegex should compile after __setstate__.')

# Generated at 2022-06-21 21:48:43.087738
# Unit test for function finditer_public
def test_finditer_public():
    """Test finditer_public function

    This function is actually a test for finditer_public function.
    """
    regex = LazyRegex(('a',))
    # We use a list as a workaround: for Python2.4, to allow a generator
    # to be used in a tuple assignment's list, we need to consume the
    # generator at least once before we can use it in the tuple assignment,
    # which includes "for" loops.
    result = list(finditer_public(regex, 'a'))
    assert len(result) == 1, "Should have matched 'a'"



# Generated at 2022-06-21 21:48:46.777030
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy_regex = LazyRegex((r'abc', re.I), {'flags':re.M})
    _real_re_compile(r'abc', re.I)

# Generated at 2022-06-21 21:48:49.533240
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    regex = LazyRegex('(.*)')
    assert regex.__getstate__() == {'args': ['(.*)'], 'kwargs': {}}



# Generated at 2022-06-21 21:48:59.383319
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib import (
        errors,
        )
    msg = 'foo bar'
    exc = errors.InvalidPattern(msg)
    # the repr contains the message and the class name
    assert str(exc).find(msg) > 0
    assert str(exc).find('%s' % errors.InvalidPattern.__name__) > 0
    assert str(exc).startswith('<')
    assert str(exc).endswith('>')
    # the type of the string is str
    assert type(str(exc)) is str

# Generated at 2022-06-21 21:49:07.527885
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib._patiencediff_py import IteratorWithPeek as _IteratorWithPeek
    def _fake_new_patience_iter(self, text, max_span=None):
        return _IteratorWithPeek(_patience_iter_fake)
    _patience_iter_fake = iter([(1, 0), (1, 0)])

    re.finditer('a', 'a')
    re.finditer(LazyRegex(('a',)), 'a')

    # monkeypatch _patience_iter to a fake iterable
    bzrlib._patiencediff_py.IteratorWithPeek = _fake_new_patience_iter
    bzrlib._patiencediff_py.patience_iter = _patience_iter_fake

    re.finditer('a', 'a')
    re

# Generated at 2022-06-21 21:49:14.155236
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    install_lazy_compile()

    s = "foo bar bar foo bar"
    # compile pattern 'bar'
    p = re.compile("bar")
    # use method search
    m = p.search(s, 1)

    reset_compile()

# Generated at 2022-06-21 21:49:27.713024
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test __unicode__ method of InvalidPattern class."""
    from bzrlib.i18n import gettext
    class SubInvalidPattern(InvalidPattern):
        _fmt = ('Invalid value for regexp %(regexp)s: %(msg)s')
    s = SubInvalidPattern(u'\xdd')
    s.regexp = u'\xdd\xdd'
    s.msg = u'\xdd'
    u = s.__unicode__()
    assert isinstance(u, unicode)
    from bzrlib.tests.test_i18n import u
    assert u('Invalid value for regexp \xdd\xdd: \xdd') == u(u)
    # check that encodings other than utf8 are detected and avoided

# Generated at 2022-06-21 21:49:39.238754
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """_"""
    r = LazyRegex(('hi[0-9]+',))
    r = LazyRegex('hi[0-9]+')
    r = LazyRegex(('hi[0-9]+',), {'flags': re.I})
    r = LazyRegex('hi[0-9]+', re.I)
    r = LazyRegex(('hi[0-9]+', 0))
    r = LazyRegex('hi[0-9]+', 0)
    r = LazyRegex(('hi[0-9]+',), dict(flags=re.I, do_something_else=True))



# Generated at 2022-06-21 21:49:45.687430
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern

    The test shows that method __repr__ of class InvalidPattern will return a
    string expresses an instance of class InvalidPattern.
    """
    msg = 'Invalid pattern(s) found. It is a test.'
    instance = InvalidPattern(msg)
    assert repr(instance) == "%s('%s')" % (instance.__class__.__name__, msg)

# Generated at 2022-06-21 21:49:47.652543
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test that InvalidPattern can be constructed"""
    e = InvalidPattern("testing")
    assert isinstance(e, Exception)

# Generated at 2022-06-21 21:50:00.094160
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile function."""
    install_lazy_compile()
    pattern = re.compile(r'\w+')
    # Test that the returned object is of correct type and that the
    # original re.compile is preserved in the object.
    assert pattern.__class__ == LazyRegex, (
        "re.compile did not return a LazyRegex object")
    assert pattern._real_re_compile == _real_re_compile, (
        "_real_re_compile was not preserved in the LazyRegex object")
    # Test that the regex is not compiled until it is used.
    pattern.pattern = "bar"
    pattern.flags = re.I
    # Check that the original regex object doesn't exist

# Generated at 2022-06-21 21:50:04.114282
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Ensure that LazyRegex works with __getattr__"""
    regex = LazyRegex()
    text = 'Hello World'
    # Allow matching for the getattr() call in the following line
    # pylint: disable=no-member
    regex.match(text)
    return

# Generated at 2022-06-21 21:50:15.549865
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() method of LazyRegex class must return a dict with args and kwargs"""
    lr = LazyRegex([r'^(?:(?P<first>.*),(?P<last>.*),(?P<role>.*),)'], {'re.MULTILINE':None})
    d = lr.__getstate__()
    assert isinstance(d, dict)
    assert d == {'args': [r'^(?:(?P<first>.*),(?P<last>.*),(?P<role>.*),)'],
                 'kwargs': {'re.MULTILINE':None}}


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:50:28.151093
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern should.__unicode__"""

    from StringIO import StringIO
    from bzrlib import trace

    # This is a bit overkill, but we want to make sure that __unicode__()
    # never emits UnicodeWarning. This is captured in test_regex.py under
    # 'test_re_compile_unicode_warning'
    # We could use twisted.trial.unittest.TestCase.assertWarns, but it is not
    # available in python 2.4
    out = StringIO()
    old_stderr = trace.stderr
    try:
        trace.stderr = out
        u = unicode(InvalidPattern(u'\xe9'))
    finally:
        trace.stderr = old_stderr
    # This means that we have got a UnicodeWarning

# Generated at 2022-06-21 21:50:33.777396
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor LazyRegex."""
    re.compile = _real_re_compile
    # Check that the attribute _real_regex is None when a LazyRegex
    # object was just created
    lazy_regex = LazyRegex()
    assert(lazy_regex._real_regex is None)
    # Check that the attribute _regex_args is a tuple
    assert(isinstance(lazy_regex._regex_args, tuple))
    # Check that the attribute _regex_kwargs is a dict
    assert(isinstance(lazy_regex._regex_kwargs, dict))

# Generated at 2022-06-21 21:50:43.593081
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should not raise AttributeError"""
    e1 = InvalidPattern('foo')
    e2 = InvalidPattern('foo')
    e3 = InvalidPattern('bar')
    assert e1 == e2
    assert e2 == e1
    assert not e2 == e3

# Generated at 2022-06-21 21:50:49.538966
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    from bzrlib import tests
    lazy_regex = LazyRegex(('pattern',), {'flags':0})
    pickled_state = lazy_regex.__getstate__()
    tests.TestCase.assertEqual(
        {'args': ('pattern',), 'kwargs': {'flags':0}},
        pickled_state)

# Generated at 2022-06-21 21:51:00.497556
# Unit test for function lazy_compile
def test_lazy_compile():
    from cStringIO import StringIO
    args = ("aa",)
    kwargs = {}
    proxy = LazyRegex(args, kwargs)
    # No real regex has been compiled
    assert proxy._real_regex == None
    # Accessing any method will cause the real regex to compile
    assert proxy.findall("aa") == ["aa"]
    # The real regex has been compiled
    assert proxy._real_regex is not None
    # Accessing any method on the real regex works.
    assert proxy.findall("aa") == ["aa"]
    assert proxy.pattern == "aa"
    # Pickling
    s = StringIO()
    proxy.dump(s)
    s.seek(0)
    new_proxy = LazyRegex.load(s)
    # Compiling the new object should produce the same

# Generated at 2022-06-21 21:51:06.256819
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ handles non utf8 string and unicode"""
    class NonUtf8StringException(InvalidPattern):
        _fmt = 'This is a non utf8 string: "abcd"'

    class UnicodeException(InvalidPattern):
        _fmt = u'This is a unicode string: \xa3'

    non_utf8_string = NonUtf8StringException('').__str__()
    assert isinstance(non_utf8_string, str), \
        '__str__ should return a non utf8 string'
    assert 'This is a non utf8 string' in non_utf8_string, \
        '__str__ should return a string containing the format string'

    unicode_string = UnicodeException('').__str__()

# Generated at 2022-06-21 21:51:14.030248
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the proxy object works as expected"""
    for regex in (r'test', r'[ab]', r'^b.*d$'):
        lazy_regex = lazy_compile(regex, re.I)
        assert isinstance(lazy_regex, LazyRegex)
        assert lazy_regex._regex_args == (regex, re.I)
        assert lazy_regex._real_regex is None
        # As we haven't done anything with the proxy yet, the regex
        # shouldn't have been compiled:
        assert not lazy_regex._compile_and_collapse.called
        # Now use all of the methods on the proxy:
        assert lazy_regex.match('test') is not None
        assert lazy_regex.findall('a') == []
        assert lazy_re

# Generated at 2022-06-21 21:51:27.098075
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that installing lazy re.compile works correctly"""
    # Moved test to the module itself, so that it is exercised by the
    # test suite.

    install_lazy_compile()

    class CapturingCounter(object):
        """A counter which captures the calls that are made to it.

        :ivar calls: A list of the calls that have been made, where each call
                     is represented by a tuple containing the positional
                     arguments that were passed to __call__.
        """

        def __init__(self):
            self.calls = []

        def __call__(self, *args, **kwargs):
            self.calls.append(args)

    # Create a proxy object
    proxy_compile = lazy_compile("[a-z]*", re.IGNORECASE)
    # Verify that it hasn

# Generated at 2022-06-21 21:51:38.936257
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    # set values for the test
    message = 'this is a test'
    # set the class attributes
    e = InvalidPattern(message)
    e._get_format_string = '_fmt test'
    # test that these attribute give the correct result
    assert e.__str__() == message
    assert repr(e) == 'InvalidPattern(\'this is a test\')'
    assert e.__unicode__() == message
    assert e.__repr__() == 'InvalidPattern(this is a test)'
    assert e.__eq__(e) == True
    # test 'bad' values
    test1 = InvalidPattern('test1')
    test2 = InvalidPattern('test2')
    assert e.__eq__(test1) == NotImplemented
   

# Generated at 2022-06-21 21:51:44.762427
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex(re.compile(str)) == LazyRegex.__getstate__()"""
    regex = re.compile("test")
    lazy_regex = LazyRegex((regex.pattern,), regex.__dict__)
    lazy_regex_state = lazy_regex.__getstate__()
    assert lazy_regex_state["args"] == (regex.pattern,)
    assert lazy_regex_state["kwargs"] == regex.__dict__



# Generated at 2022-06-21 21:51:47.217881
# Unit test for function reset_compile
def test_reset_compile():
    # Do not use install_lazy_compile() to avoid installing finalizers
    # which make testing harder
    re.compile = lazy_compile
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-21 21:51:49.929367
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() should not raise an exception.

    Especially, it should not raise UnicodeDecodeError as reported in
    https://bugs.launchpad.net/bzr/+bug/119811
    """
    msg = 'fo\xf6\xdf'
    e = InvalidPattern(msg)
    str(e)

# Generated at 2022-06-21 21:52:10.045883
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import i18n
    s = ['Invalid pattern(s) found. ', '%(msg)s']
    u = i18n.gettext(u''.join(s)).encode('utf8')
    e = InvalidPattern(u'%(msg)s')
    eq = 'Invalid pattern(s) found. %(msg)s'
    assert repr(e) == repr(eq)
    assert str(e) == str(eq)
    assert unicode(e) == e._get_format_string()

# Generated at 2022-06-21 21:52:19.599067
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test InvalidPattern.__unicode__.

    A method with no parameters, returning unicode is tested.
    """
    f = InvalidPattern("test")
    for _ in range(2):
        expected = 'test'
        observed = f.__unicode__()
        if observed != expected:
            raise AssertionError("""\
Expected %s, found %s
""" % (repr(expected), repr(observed)))

from bzrlib.tests.blackbox import TestCaseWithTransport



# Generated at 2022-06-21 21:52:32.830907
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    if sys.version_info.major < 3:
        class UnicodeString:
            """A str subclass with attribute __str__ = unicode"""
            def __str__(self):
                return unicode('UnicodeString.__str__()')
        class UTF8String1:
            """A str subclass with attribute __str__ = UTF-8 str"""
            def __str__(self):
                return 'UTF8String1.__str__()'.encode('utf8')
        class UTF8String2:
            """A str subclass with attribute __str__ = UTF-8 str"""
            __str__ = 'UTF8String2.__str__()'.encode('utf8')
        class UnicodeString2:
            """A str subclass with attribute __unicode__ = unicode"""

# Generated at 2022-06-21 21:52:44.073484
# Unit test for function lazy_compile
def test_lazy_compile():
    """Make sure the proxy object works correctly."""
    new_compile = LazyRegex(re_args=('a',), re_kwargs={'re.I':True})
    real_re = _real_re_compile('a', re.I)
    if new_compile.match("bla") is not real_re.match("bla"):
        raise AssertionError("Lazy regex matching doesn't work")
    if new_compile.match("bla") is new_compile.match("bla"):
        raise AssertionError("Lazy regex matching doesn't work")
    if new_compile.match("bla") is not real_re.match("bla"):
        raise AssertionError("Lazy regex matching doesn't work")
    new_compile = LazyRegex()


# Generated at 2022-06-21 21:52:56.446114
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from StringIO import StringIO
    from bzrlib import tests

    test_cases = [
        # test 1, email address
        '''
        invalid pattern: "(?P<user>[^@<>\\s]+)@(?P<hostname>[^@<>\\s]+)"
        ''']
    stream = StringIO()
    for tc in test_cases:
        msg = tc.strip().encode('utf8')
        stream.write(msg)
        stream.write('\n')
        e = InvalidPattern(msg)
        tests.TestCase.assertIsInstance(e, Exception)
        test_unicode_object = e.__unicode__()
        tests.TestCase.assertIsInstance(test_unicode_object, unicode)

# Generated at 2022-06-21 21:53:01.806769
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    p = re.compile(r'abc')
    assert isinstance(p, type(re.compile(r'abc')))
    reset_compile()
    assert isinstance(p, type(re.compile(r'abc')))

# Generated at 2022-06-21 21:53:13.385257
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    from bzrlib.osutils import get_user_encoding, get_terminal_encoding
    from bzrlib.i18n import gettext

    # The test looks at two translations: one that needs to be encoded using
    # get_terminal_encoding() and another that uses get_user_encoding().
    # Both encodings are exercised using the same test pattern: UnicodeDecode
    # and UnicodeEncodeError.

    class TestInvalidPattern(TestCase):

        def setUp(self):
            super(TestInvalidPattern, self).setUp()
            self.set_up_smart_server_and_client(request_backlog=3)


# Generated at 2022-06-21 21:53:17.388603
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lr = LazyRegex(('^hello$',))
    lr_state = lr.__getstate__()
    assert lr_state == {
        "args": ('^hello$',),
        "kwargs": {}
        }


# Generated at 2022-06-21 21:53:28.508977
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy = LazyRegex(('^abc', re.M))
    if getattr(lazy, 're_nsub', None) is not None:
        error_msg = "lazy should not be compiled"
        raise AssertionError(error_msg)

    # test that the memoizing works correctly.  The second re.compile should
    # use the cached values, not repeat the re.compile
    lazy2 = LazyRegex(('^abc', re.M))
    lazy == lazy2
    if getattr(lazy, 're_nsub', None) is None:
        error_msg = "lazy should be compiled"
        raise AssertionError(error_msg)

    # test that we can't get the attrs before compile-time

# Generated at 2022-06-21 21:53:32.888694
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests import TestCase

    class TestInvalidPattern(TestCase):

        def test_InvalidPattern___repr__(self):
            #__repr__ for InvalidPattern is not implemented.
            #This test assert an error is raise when __repr__ is called.
            #The object returned by __repr__ must be a string.
            invalid_pattern = InvalidPattern('test')
            self.assertRaises(TypeError, invalid_pattern.__repr__)

    TestInvalidPattern().test_InvalidPattern___repr__()

# Generated at 2022-06-21 21:53:54.852201
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    # reset_compile() is idempotent
    reset_compile()

# Generated at 2022-06-21 21:54:01.475668
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ sets appropriate values"""
    lazy_regex1 = LazyRegex(('test',), {'flags': 0})
    lazy_regex2 = LazyRegex()
    lazy_regex2.__setstate__({'args': ('test',), 'kwargs': {'flags': 0}})
    assert lazy_regex1 == lazy_regex2

# Generated at 2022-06-21 21:54:10.951363
# Unit test for function lazy_compile
def test_lazy_compile():
    """Basic test for lazy_compile"""
    class MyLazyRegex(LazyRegex):
        """A LazyRegex that knows how it was compiled"""
        def __init__(self, *args, **kwargs):
            super(MyLazyRegex, self).__init__(*args, **kwargs)
            self.compiled_by = (args, kwargs)

    def _lazy_compile(pattern, flags=0):
        return MyLazyRegex((pattern, flags))

    # change re.compile to use our own lazy compile
    old_compile = re.compile

# Generated at 2022-06-21 21:54:21.580169
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern.

    See http://doc.bazaar.canonical.com/developers/testing.html and
    http://doc.bazaar.canonical.com/testing.html for more information
    about testing and testtools.
    """
    from bzrlib.tests import TestCase
    class TestInvalidPattern(TestCase):
        def test_unicode(self):
            """Test that the __unicode__ method works and returns a unicode
            object (no encoding error is raised).
            """
            err = InvalidPattern('foo bar')
            u = unicode(err)
            self.assertIsInstance(u, unicode)

    from bzrlib.tests import TestUtil
    TestUtil.test_suite()

# Generated at 2022-06-21 21:54:24.238576
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should not raise ValueError"""
    InvalidPattern('repr-test')


# Generated at 2022-06-21 21:54:27.763815
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    r = re.compile('test')
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError
    if isinstance(r, LazyRegex):
        raise AssertionError
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError


# Generated at 2022-06-21 21:54:39.504858
# Unit test for function lazy_compile
def test_lazy_compile():
    # re.compile is not overriden by lazy_compile by default, so reset it now
    reset_compile()

    import re
    import pickle
    from itertools import islice

    re.compile = lazy_compile

# Generated at 2022-06-21 21:54:41.608991
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    raise NotImplementedError(__name__ + '.test_LazyRegex___getstate__')


# Generated at 2022-06-21 21:54:50.627743
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""

    def _test(err_msg, expected_msg):
        """Test __unicode__ method of InvalidPattern"""
        class MyException(Exception):
            """This is a test exception"""
            def __unicode__(self):
                """Return a unicode string that has to be ignored"""
                return u"unicode error msg"
        err = MyException(err_msg)
        expected = u"Unprintable exception MyException: dict={}, fmt=None, error=" \
            + expected_msg
        invalid = InvalidPattern(err)
        actual = invalid.__unicode__()
        if actual != expected:
            raise AssertionError("InvalidPattern.__unicode__(%r) returned %r, "
                "expected %r" % (err_msg, actual, expected))

# Generated at 2022-06-21 21:54:55.563784
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    err = InvalidPattern("foo")
    str(err)
    repr(err)
    # Test equality
    err2 = InvalidPattern("foo")
    err3 = InvalidPattern("bar")
    if err != err2:
        raise AssertionError("__eq__ broken")
    if err == err3:
        raise AssertionError("__eq__ broken")


# Install the override on import.
install_lazy_compile()

# Generated at 2022-06-21 21:55:42.200843
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    err = InvalidPattern('foo')
    eq = str(err)
    assert eq == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None', (
        'Expected <Unprintable exception InvalidPattern: dict={}, fmt=None, '
        'error=None> got <%s>' % (eq,))

# Generated at 2022-06-21 21:55:50.696066
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # Check that re.compile(r'test') is a proxy object.
    re.compile(r'test')
    if not isinstance(re.compile(r'test'), LazyRegex):
        raise AssertionError(
            "Expected LazyRegex object, got %r" % (re.compile(r'test'),))

    # Check that the proxy object performs correctly.
    re.compile(r'test').search('teststring')
    re.compile(r'\btest\b').search(' test ')

# Generated at 2022-06-21 21:55:57.654194
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from cStringIO import StringIO
    import pickle

    proxy = re.compile("^.*$")

    f = StringIO()
    pickle.dump(proxy, f)
    f.seek(0)
    proxy2 = pickle.load(f)

    # Check that proxy2 object is also LazyRegex
    assert isinstance(proxy2, LazyRegex)

    # Check that proxy2 object can be used as proxy
    assert proxy2.findall("a") == ["a"]



# Generated at 2022-06-21 21:56:03.710016
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern

    Call __unicode__ of class InvalidPattern and check if it returns unicode.
    """
    msg = "Invalid value"
    err = InvalidPattern(msg)
    assert(isinstance(err.__unicode__(), unicode))
    assert(unicode(msg) in err.__unicode__())

# Generated at 2022-06-21 21:56:08.025639
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    docextract = doctest.DocTestExtractor()
    suite = docextract.find(lambda f: f.__module__ == __name__)
    suite.run(doctest.OutputChecker())

# Generated at 2022-06-21 21:56:14.598204
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test that the method LazyRegex.__setstate__ actually sets attributes."""
    lazy = lazy_compile(r'a*')
    lazy.__setstate__({'args': r'b*', 'kwargs': {}})
    # This can't be evaluated until we've copied the attributes
    # over
    assert lazy.search('bbbbb') is not None
    assert lazy.search('aaaaa') is None


# Generated at 2022-06-21 21:56:20.504746
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestUtil
    install_lazy_compile()
    orig = re.compile
    assert re.compile is lazy_compile
    reset_compile()
    assert re.compile is orig
    TestUtil.suppress_deprecated_warnings()
    reset_compile() # idempotent
    TestUtil.assertLength(1, _real_re_compile._warnings)

# Generated at 2022-06-21 21:56:24.030634
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import doctest
    from bzrlib.tests import TestSkipped
    try:
        doctest.testmod()
    except (ImportError, SyntaxError):
        raise TestSkipped('doctest failed to import')

# Generated at 2022-06-21 21:56:37.789283
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the correct working of method __getstate__ of class LazyRegex"""
    from bzrlib.tests.matchers import HasMethod
    from bzrlib.tests import TestCase

    class TestLazyRegex(TestCase):

        def test___getstate__(self):
            """Test getstate
            """
            regex = re.compile("pattern")
            self.assertThat(regex, HasMethod("__getstate__"))

            # Test that the method returns the same values used to create
            # the LazyRegex object
            regex = LazyRegex(("pattern", ))
            state = regex.__getstate__()
            self.assertEqual((("pattern", ), {}), (state["args"], state["kwargs"]))

            # Test that the method returns the same values used to create
            # the Lazy

# Generated at 2022-06-21 21:56:48.966458
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of class InvalidPattern should return unicode.
    If a localised version of message is available, it should be used.
    """
    cls = InvalidPattern

    # Test that the method returns a unicode object.
    e = cls(u'error message')
    result = e.__unicode__()
    assert isinstance(result, unicode)

    # Test that the method returns a localised error message.
    # The localisation is not done when we test as we haven't set up
    # the i18n environment.
    e = cls(u'localised error message')
    e._get_format_string = lambda : u'localised format'
    result = e.__unicode__()
    assert isinstance(result, unicode)
    assert result == u'localised format'


# Unit