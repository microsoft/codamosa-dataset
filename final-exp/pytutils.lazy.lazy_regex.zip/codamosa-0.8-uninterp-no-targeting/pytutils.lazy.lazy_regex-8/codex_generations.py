

# Generated at 2022-06-21 21:47:01.400467
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should be return a 'str' object.

    This is the case for 2 ways:
    - If a str object is passed as argument to InvalidPattern,
      __str__ must convert it to unicode and return a str object.
    - If a unicode is passed as argument to InvalidPattern,
      __str__ must return a str object.
    - In others case __str__ should return a 'str' object which is supposed to
      be readable.

    TODO: Check if __str__ return a useful string if Exception is raised.
    """
    __str__ = InvalidPattern('An error').__str__
    assert isinstance(__str__(), str)
    assert isinstance(__str__(u'A unicode error'), str)

# Generated at 2022-06-21 21:47:11.194901
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that the constructor of LazyRegex creates sensible objects."""
    import sys

    # The pattern is not passed to re.compile, so it should not have been
    # compiled yet
    regex = LazyRegex(('^a.*c.*$',))
    assert regex._real_regex is None

    # the attributes should be the same as for a compiled regex.
    for attr in LazyRegex._regex_attributes_to_copy:
        attr_re = getattr(regex, attr)
        attr_compiled = getattr(_real_re_compile('^a.*c.*$'), attr)
        assert attr_re == attr_compiled

    # the generated regex should match a correct string, but not one that
    # is incorrect.

# Generated at 2022-06-21 21:47:17.391802
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should return member of proxied object."""
    # Compile and collapse lazy regex object
    lazy = LazyRegex(("foo[0-9]+",))
    lazy.match("foo1")
    # Get group attribute from proxy object
    group = lazy.group
    # Ensure that group() method was obtained from proxied object
    assert group("foo1") == "foo1"



# Generated at 2022-06-21 21:47:27.251926
# Unit test for function lazy_compile
def test_lazy_compile():
    from six.moves import cStringIO as StringIO
    import sys
    import unittest

    # This is a hack because unittest.TextTestRunner introduces a
    # dependency on sys.stdout being a TextIOWrapper, but we want this
    # to be a StringIO.
    _saved_stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        import bzrlib.tests.test_regex
        suite = bzrlib.tests.test_regex.test_suite()
    finally:
        sys.stdout = _saved_stdout

    tests = unittest.makeSuite(bzrlib.tests.test_regex.TestLazyCompile)
    suite.addTests(tests)
    return suite



# Generated at 2022-06-21 21:47:39.828080
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should compare all attributes and compare class identity."""
    class DerivedInvalidPattern(InvalidPattern):
        pass
    o = InvalidPattern('msg')
    assert o == o
    assert not (o==1)
    d = DerivedInvalidPattern('msg')
    assert not (o == d)
    d2 = DerivedInvalidPattern('msg')
    assert d == d2
    d.a = 1
    d2.a = 1
    assert d != d2
    assert d2 != d
    d2.a = 2
    assert d != d2
    assert d2 != d
    d2 = DerivedInvalidPattern('msg')
    d.b = 1
    assert d == d2
    d2.b = 2
    assert d != d2
    assert d2 != d


# Generated at 2022-06-21 21:47:51.758685
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """This is a test for check of method __unicode__ of class InvalidPattern
    """
    # String ascii
    try:
        InvalidPattern('a')
    except InvalidPattern as e:
        assert unicode(e) == u'a'
    # String utf-8
    try:
        InvalidPattern('a\xc3\xa1')
    except InvalidPattern as e:
        assert unicode(e) == u'a\xe1'
    # String ascii with %(msg)s
    try:
        InvalidPattern('a')
    except InvalidPattern as e:
        e._fmt = 'this is a %(msg)s'
        assert unicode(e) == u'this is a a'
    # String utf-8 with %(msg)s

# Generated at 2022-06-21 21:48:00.242513
# Unit test for function lazy_compile
def test_lazy_compile():
    import re
    import sys
    import pickle

    # LazyRegexes should compile on demand
    regex = lazy_compile("foo")
    # but proxy all the other properties.
    if regex.pattern != 'foo':
        raise AssertionError("Pattern did not match")
    regex = regex.findall("abcabcabcabc")
    if regex != ['abc']:
        raise AssertionError("Proxied method failed")

    # Errors in re.compile should be delayed and reported as
    # InvalidPattern
    try:
        regex = lazy_compile("*")
    except InvalidPattern:
        pass
    else:
        raise AssertionError("InvalidPattern was not raised")

    # LazyRegexes should be pickleable
    regex = lazy_compile("foo")

# Generated at 2022-06-21 21:48:05.432448
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
        reset_compile()
        assert re.compile is _real_re_compile
    except:
        # make sure reset_compile is called even if test fails
        reset_compile()
        raise



# Generated at 2022-06-21 21:48:13.461132
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # Override gettext
    def gettext(msg):
        return msg
    def ngettext(msg1, msg2, count):
        return msg1 + ' ' + msg2 + ' ' + count
    e = InvalidPattern('This is a test')
    assert e._get_format_string() == 'Invalid pattern(s) found. %(msg)s'
    assert str(e) == 'This is a test'


test_suite = "test"
# Just for unit tests to find the modules.
test_suite = None

# Generated at 2022-06-21 21:48:26.087816
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    f = InvalidPattern('foo')
    g = InvalidPattern('foo')
    h = InvalidPattern('bar')
    f_f = InvalidPattern('foo')
    f_f.__dict__['_preformatted_string'] = 'foo'
    assert f == f
    assert not f != f
    assert f in [f, g, h]
    assert f == g
    assert not f == h
    assert not f != g
    assert g == f
    assert not g != f
    assert not g == h
    assert g != h
    assert not g in [f, h]
    assert f in [f_f, f]
    assert f_f in [f, f_f]
    assert not f == f_f
    assert not f_f == f

# Generated at 2022-06-21 21:48:38.744891
# Unit test for function reset_compile
def test_reset_compile():
    compile = re.compile
    reset_compile()
    assert compile == _real_re_compile
    assert re.compile is not compile
    reset_compile()
    assert compile == re.compile
    assert re.compile is not lazy_compile

# Generated at 2022-06-21 21:48:44.496140
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the method __setstate__ of class LazyRegex"""
    import pickle

    # make a LazyRegex object
    lr = LazyRegex(('ab*', re.I))
    # dump the object
    s = pickle.dumps(lr)
    # load the object
    new_lr = pickle.loads(s)
    # compare the dumped and loaded object
    assert lr._regex_args == new_lr._regex_args
    assert lr._regex_kwargs == new_lr._regex_kwargs
    assert lr._real_regex == new_lr._real_regex

# Generated at 2022-06-21 21:48:54.510112
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # For two objects with the same kwargs, this test fails when the msg is
    # unicode, and works when it's str (even though it looks like it should
    # always work!).
    # Clearly, the underlying problem is that InvalidPattern.__eq__ is wrong.
    # So, should we not bother to fix it?
    # I think so. I think we can live without it, because we don't really care
    # whether these objects are equal or not.
    o1 = InvalidPattern('msg1')
    o2 = InvalidPattern('msg2')
    o3 = InvalidPattern('msg1')

    o1.msg = 'msg1'
    # This is FALSE:
    #o1.msg = u'msg1'

    o2.msg = 'msg2'
    # This is FALSE:
    #o2.msg =

# Generated at 2022-06-21 21:49:05.328948
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Preserving the preformatted string
    class MyException(InvalidPattern):
        _preformatted_string = 'My preformatted string'
    myexception = MyException('Message')
    str(myexception)
    assert isinstance(str(myexception), str)
    assert str(myexception) == 'My preformatted string'
    assert repr(myexception) == "MyException('My preformatted string')"

    # Using an unicode message
    class MyException(InvalidPattern):
        _fmt = u'%(msg)s'
    myexception = MyException(u'Message with accents \xe9\xf6\xf8\xe5')
    assert isinstance(str(myexception), str)
    assert isinstance(unicode(myexception), unicode)

# Generated at 2022-06-21 21:49:11.454114
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Unit test for function install_lazy_compile"""
    try:
        install_lazy_compile()
        if re.compile != lazy_compile:
            raise AssertionError('re.compile was not replaced')
    finally:
        reset_compile()

# Generated at 2022-06-21 21:49:16.240108
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    from bzrlib import tests
    from bzrlib.tests import TestCase

    loader = tests.TestLoader()
    suite = loader.suiteClass()
    suite.addTests([loader.loadTestsFromTestCase(TestLazyRegex),
                    doctest.DocTestSuite(__name__)])
    return suite


# Generated at 2022-06-21 21:49:21.823139
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lazy_regex = LazyRegex()
    try:
        lazy_regex.__setstate__(None)
    except Exception:
        return False
    return not hasattr(lazy_regex, '_real_regex')


# Generated at 2022-06-21 21:49:29.962037
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    import bzrlib.trace
    bzrlib.trace.set_verbosity(120)
    _fmt = "test %(msg)s"
    # If _fmt is empty
    e = InvalidPattern("bla")
    e._fmt = ""
    assert unicode(e) == str(e)
    assert unicode(e) == u"Unprintable exception InvalidPattern: dict={'msg': 'bla'}, fmt='', error=None"
    # If _fmt is None
    e = InvalidPattern("bla")
    e._fmt = None
    assert unicode(e) == str(e)

# Generated at 2022-06-21 21:49:35.529397
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    msg = "This is a test InvalidPattern message"
    ip = InvalidPattern(msg)
    assert str(ip) == msg, \
        "Failed: testing InvalidPattern method __str__"
    return True

# test suite.

# Generated at 2022-06-21 21:49:42.861956
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ of class LazyRegex must preserve functionality of
    the original attribute.
    """
    def test_method(regex):
        regex.findall('abcabc')
        regex.finditer('abcabc')
        regex.match('abc')
        regex.scanner('abc')
        regex.search('abc')
        regex.split('abc')
        regex.sub('abc')
        regex.subn('abc')

    regex = lazy_compile('abc')
    test_method(regex)
    regex = lazy_compile(regex)
    test_method(regex)

# Generated at 2022-06-21 21:50:03.319904
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function"""
    lazy = lazy_compile('[0-9]+', re.I)
    # It should have the same interface as a real regex
    for x in dir(lazy):
        if x.startswith('__'):
            continue
        assert hasattr(re.compile('[0-9]+', re.I), x)
    # The regex should not yet have been compiled
    assert lazy._real_regex is None
    # We should be able to access one of its methods
    assert lazy.findall('1 2 3') == ['1', '2', '3']
    # And it should have been compiled now.
    assert lazy._real_regex is not None



# Generated at 2022-06-21 21:50:10.419051
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib.tests import TestCaseWithMemoryTransport
    class TestLazyRegex(TestCaseWithMemoryTransport):
        def test_lazy_regex_ctor(self):
            regex = LazyRegex((r'a', re.I))
            self.assertRaises(AttributeError, getattr, regex, 'flags')

    test_LazyRegex().test_lazy_regex_ctor()

# Generated at 2022-06-21 21:50:19.521194
# Unit test for function finditer_public
def test_finditer_public():
    import re

    class MyCompile(object):
        def __init__(self, pattern, flags):
            self.pattern = pattern
            self.flags = flags

        def finditer(self, string):
            return iter([(self.pattern, self.flags)])

    re.compile = MyCompile

    my_pat = r'\d*'
    my_string = '1234'
    my_flags = re.IGNORECASE

    actual_iter = re.finditer(my_pat, my_string, my_flags)
    expected_iter = iter([(my_pat, my_flags)])

    for actual, expected in zip(actual_iter, expected_iter):
        assert actual == expected

    # Test the LazyRegex part of finditer_public
    re.compile = _real_re_

# Generated at 2022-06-21 21:50:31.460278
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test the constructor of class InvalidPattern"""
    ip = InvalidPattern('bad things happened')
    eq = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert str(ip) == eq
    assert unicode(ip) == eq

    ip = InvalidPattern('bad things happened')
    ip.__dict__['foo'] = 'bar'
    assert str(ip) == \
        'Unprintable exception InvalidPattern: dict={\'foo\': \'bar\'}, ' \
        'fmt=None, error=None'

    ip = InvalidPattern('bad things happened')
    ip._fmt = 'blah: %(foo)s'
    ip.__dict__['foo'] = 'bar'
    assert str(ip) == 'blah: bar'

    ip = InvalidPattern('bad things happened')

# Generated at 2022-06-21 21:50:36.845674
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test that method InvalidPattern.__repr__ returns the right string"""
    pattern = '[\d'
    error = 'missing ]'
    regex_error = InvalidPattern(error)
    repr_regex_error = repr(regex_error)
    assert repr_regex_error == 'InvalidPattern(\'[\\d missing ]\')'



# Generated at 2022-06-21 21:50:41.125079
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests.test_regex import TestRegexModule

    def setUp(self):
        # call original setUp
        TestRegexModule.setUp(self)
        install_lazy_compile()

    def tearDown(self):
        reset_compile()
        # call original tearDown
        TestRegexModule.tearDown(self)

    TestRegexModule.setUp = setUp
    TestRegexModule.tearDown = tearDown

# Generated at 2022-06-21 21:50:51.713565
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore a LazyRegex object"""
    # create a LazyRegex
    lr = LazyRegex(('ab',), {'flags': re.IGNORECASE})
    assert lr._regex_args == ('ab',)
    assert lr._regex_kwargs == {'flags': re.IGNORECASE}
    assert lr._real_regex is None

    # pickle and unpickle the object
    import cPickle
    lr1 = cPickle.loads(cPickle.dumps(lr, 2))

    # The object should be restored
    assert lr1._regex_args == ('ab',)
    assert lr1._regex_kwargs == {'flags': re.IGNORECASE}
    assert lr1._real_regex is None

# Generated at 2022-06-21 21:50:54.831465
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ex = InvalidPattern('test message')
    assert ex.msg == 'test message'
    assert str(ex) == 'Invalid pattern(s) found. test message'

# Generated at 2022-06-21 21:50:56.441482
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    reset_compile()
    reset_compile()

# Generated at 2022-06-21 21:51:03.833651
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    a = InvalidPattern("foo")
    b = InvalidPattern("foo")
    c = InvalidPattern("bar")

    # Test the repr for a exception object
    repr(a)
    repr(b)
    repr(c)

    # Test the repr for this test function
    repr(test_InvalidPattern___repr__)

    # Test if two exception objects are equal
    if a == b:
        assert a is b

    # Test if the objects of the same class but with different attribute value
    # are equal.
    assert not a == c

# Generated at 2022-06-21 21:51:26.318470
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__()

    A test to ensure that the __unicode__ method of InvalidPattern is working
    correctly.
    """
    import bzrlib
    old_debug = bzrlib.trace.is_quiet()
    bzrlib.trace.set_verbosity(0)
    try:
        # Simulate a crash in the apport information collection process
        error = InvalidPattern('test')
        error._get_format_string = lambda: 1/0
        try:
            unicode(error)
            assert False, "ZeroDivisionError should be raised"
        except ZeroDivisionError:
            pass
    finally:
        bzrlib.trace.set_verbosity(old_debug)

# Generated at 2022-06-21 21:51:31.725924
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lr_test = LazyRegex(('test'), {})
    res = lr_test.__getstate__()
    assert res == {'args':('test'), 'kwargs':{}}

# Generated at 2022-06-21 21:51:37.226473
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string that could be used to recreate the object.

    \n  >>> ip = InvalidPattern(u'error msg')
    \n  >>> ip
    InvalidPattern('error msg')
    """

# Generated at 2022-06-21 21:51:43.103771
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ of LazyRegex"""
    import pickle

    regex = LazyRegex(('a+',))
    regex.__getstate__()
    serialized = pickle.dumps(regex)
    deserialized = pickle.loads(serialized)
    deserialized.findall('aaa')
    deserialized.findall('bbb')

# Generated at 2022-06-21 21:51:48.301440
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method __getattr__ of class LazyRegex"""

    # create a instance of LazyRegex
    regex = LazyRegex()

    # the object regex doesn't have __class__
    # and when we want to get the __class__ from it,
    # the method __getattr__ will be called
    assert regex.__class__ == LazyRegex

    # the method _compile_and_collapse()
    # has been called in _getattr__
    assert regex._real_regex != None


# Generated at 2022-06-21 21:52:02.040248
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    #Test 1
    test_obj = LazyRegex()
    expected = {
        "args": (),
        "kwargs": {},
        }
    actual = test_obj.__getstate__()
    assert expected == actual, \
        'test_LazyRegex___getstate__:\n  expected: %s\n  actual: %s' % (
        expected, actual)
    #Test 2
    args = ("hello", 'i', 'foo')
    kwargs = {'bar': 'quux', 'baz': 'xyzzy'}
    test_obj = LazyRegex(args, kwargs)
    expected = {
        "args": args,
        "kwargs": kwargs,
        }
    actual = test_

# Generated at 2022-06-21 21:52:13.324144
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern

    This test is specific to lazy_regex.py module. All other tests are
    in test_bzrlib.lazy_regex.
    """
    # test that all ascii _fmt strings with string of all ascii chars
    # returns correctly encoded string
    exc = InvalidPattern('msg')
    exc._fmt = 'pattern(s) regex(s) regex++ regex** regex// regex\\\\ regex$$ regex__ regex-- regex++ regex?? regex.. regex,, regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex$$ regex// regex\\\\'
    exc.msg = 'msg'
    assert isinstance(str(exc), str)

# Generated at 2022-06-21 21:52:16.142220
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__."""
    pattern = lazy_compile('.*')
    pattern.__setstate__(pattern.__getstate__())
    return pattern

# Generated at 2022-06-21 21:52:23.815807
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import re
    # Test that constructor stores arguments
    args = (r'^(?P<key>.*)$', re.I)
    kwargs = {}
    r = LazyRegex(args, kwargs)
    # getattr should return the correct arguments
    assert getattr(r, "_regex_args") == tuple(args)
    assert getattr(r, "_regex_kwargs") == kwargs
    # Test that constructor stores empty arguments
    args = tuple()
    kwargs = dict()
    r = LazyRegex(args, kwargs)
    assert getattr(r, "_regex_args") == tuple()
    assert getattr(r, "_regex_kwargs") == dict()


# Generated at 2022-06-21 21:52:29.900804
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern

    If a subclass of InvalidPattern does not override method __eq__,
    the method should return a proper comparison.
    """
    class IP(InvalidPattern):
        pass

    v1 = IP('msg1')
    v2 = IP('msg2')
    v3 = IP('msg1')
    assert v1 != v2
    assert v1 == v3

# Generated at 2022-06-21 21:52:47.851145
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test function lazy_compile"""
    r_string = '.*'
    r_flags = re.UNICODE
    r = lazy_compile(r_string, r_flags)
    assert isinstance(r, LazyRegex)
    assert not hasattr(r, 'findall') # It's not compiled yet
    r.findall('ab') # cause compilation
    assert hasattr(r, 'findall') # It is compiled now
    assert r.findall('ab')
    r = lazy_compile(r_string, r_flags) # recompile
    r_new = r.__copy__() # copy
    r_new.findall('ab') # r_new must be compiled too
    assert r_new.findall('ab')

# Generated at 2022-06-21 21:52:57.562887
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should restore the regex from pickled state."""
    # create a regex object
    regex = LazyRegex(['a'], {})
    # get pickled state
    state = regex.__getstate__()
    # create a new regex object
    regex = LazyRegex()
    # restore from pickled state
    regex.__setstate__(state)
    # the new regex object should be identical to the old one
    assert regex._regex_args == ('a',)
    assert regex._regex_kwargs == {}
    # accessing the regex properties should compile the regex
    regex.findall('aaa')
    assert regex._real_regex is not None

# Generated at 2022-06-21 21:53:05.356703
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Make sure install_lazy_compile works as documented.
    """
    install_lazy_compile()
    proxy = re.compile('abc')
    if not isinstance(proxy, LazyRegex):
        raise AssertionError('not a LazyRegex')
    try:
        if proxy.search('123abc456') is None:
            raise AssertionError('proxy not working')
    finally:
        reset_compile()



# Generated at 2022-06-21 21:53:13.653804
# Unit test for function reset_compile
def test_reset_compile():
    def test_re_compile():
        return re.compile('foo')
    # Ensure that reset_compile() will reset us to the original re.compile()
    install_lazy_compile()
    reset_compile()
    # Now install it again, and make sure we can restore
    install_lazy_compile()
    reset_compile()
    # Now make sure that reset_compile() will work even if re.compile() has
    # been overridden elsewhere
    re.compile = test_re_compile
    reset_compile()

# Generated at 2022-06-21 21:53:16.831659
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('msg1')
    e2 = InvalidPattern('msg2')
    assert e1 != e2
    e2 = InvalidPattern('msg1')
    assert e1 == e2

# Generated at 2022-06-21 21:53:22.041350
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Check that the LazyRegex object is pickleable."""
    lazy_re = LazyRegex(("",))
    pickle_lazy_re = lazy_re.__getstate__()
    assert("args" in pickle_lazy_re) and ("kwargs" in pickle_lazy_re)

# Generated at 2022-06-21 21:53:29.222135
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Tests the LazyRegex.__getattr__ method."""

    # We must use the class LazyRegex because we want to call
    # LazyRegex.__getattr__() directly
    my_real_regex = LazyRegex()
    my_real_regex._real_regex = re.compile('.*')
    my_real_regex.__getattr__('bar')
    my_real_regex.__getattr__('match')
    my_real_regex.__getattr__('_real_regex')

# Generated at 2022-06-21 21:53:30.711793
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:53:38.325398
# Unit test for function reset_compile
def test_reset_compile():
    re_compile = re.compile
    import bzrlib.lazy_regex
    bzrlib.lazy_regex.install_lazy_compile()
    try:
        assert re.compile is not re_compile
        bzrlib.lazy_regex.reset_compile()
        assert re.compile is re_compile
    finally:
        bzrlib.lazy_regex.reset_compile()

# Generated at 2022-06-21 21:53:46.402016
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Return a string representation of the object for debugging purposes."""

    message_1 = 'Invalid pattern(s) found. "abc" unbalanced parenthesis'
    message_2 = 'Invalid pattern(s) found. "abc" unbalanced parenthesis'


    # Test if the string representation of the object can be decoded using the
    # default encoding.
    string_representation_1 = InvalidPattern('abc unbalanced parenthesis').__repr__()
    string_representation_2 = InvalidPattern('abc unbalanced parenthesis').__repr__()

    # Test
    assert message_1 == string_representation_1
    assert message_2 == string_representation_2

# Generated at 2022-06-21 21:54:04.460188
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member of the proxied regex object.

    If the regex hasn't been compiled yet, compile it.
    """
    regex = LazyRegex()
    # regex._real_regex and regex._real_regex.flags are both None
    assert regex.flags is None
    # Once we have compiled, the only time we should come here
    # is actually if the attribute is missing.
    regex._compile_and_collapse()
    # regex._real_regex has been initialized
    assert regex._real_regex.flags is not None
    # The following line should not raise AttributeError
    assert regex._real_regex.flags is not None
    # AttributeError must be raised
    try:
        regex.xxx
    except AttributeError:
        pass

# Generated at 2022-06-21 21:54:08.032244
# Unit test for function finditer_public
def test_finditer_public():
    """Test that the function finditer_public works correctly"""
    regex = re.compile('ab+c')
    result = finditer_public(regex, 'abbcdef')
    assert 'MatchObject' in repr(next(result))

# Generated at 2022-06-21 21:54:12.847806
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should only be called on members not defined on the class"""
    re_object = lazy_compile("pattern")
    def __eq__(self, other):
        self._eq_was_called = True
        return True
    re_object.__eq__ = __eq__
    re_object.__eq__(re_object, re_object)
    if not getattr(re_object, "_eq_was_called", False):
        raise AssertionError("__getattr__ was called but it should not be.")



# Generated at 2022-06-21 21:54:17.487346
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the __getstate__ method."""
    lazy_regex = LazyRegex(('foo',), {'bar': 1})
    assert lazy_regex.__getstate__() == {
        "args": ('foo',),
        "kwargs": {'bar': 1},
    }


# Generated at 2022-06-21 21:54:28.457901
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test for creation of class LazyRegex in bzrlib.lazy_regex"""
    from unittest import TestCase
    from bzrlib import tests
    from bzrlib.tests import test_regex

    class TestLazyRegex(tests.TestCase):
        # This class is just a simple wrapper around the unit tests for
        # the regular expression library since this is the library that
        # lazy regexs are tested against.

        def test_re_escape(self):
            # Test that this works, as it is used by the unit tests
            self.assertEqual(_real_re_compile('f').match('f'),
                             _real_re_compile('f').match('f'))

    test_suite = test_regex.test_suite()

# Generated at 2022-06-21 21:54:34.917139
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should always return an str"""
    from breezy.tests import TestCase

    e = InvalidPattern('foo')
    TestCase.assertEquals(str, type(e.__repr__()))


__all__ = ['InvalidPattern', 'LazyRegex', 'lazy_compile', 'install_lazy_compile',
    'reset_compile', 'test_InvalidPattern___repr__']

# Generated at 2022-06-21 21:54:45.312103
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import re

    # Test with args
    p = LazyRegex(('test',), {})
    p._compile_and_collapse()
    assert isinstance(p._real_regex, re._pattern_type)
    assert p._real_regex.pattern == 'test'
    assert p.pattern == 'test'

    # Test with kwargs
    p = LazyRegex((), {'flags': re.IGNORECASE})
    assert p._regex_args == ()
    assert p._regex_kwargs == {'flags': re.IGNORECASE}
    p._compile_and_collapse()
    assert p._real_regex.flags == re.IGNORECASE



# Generated at 2022-06-21 21:54:46.196528
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:54:53.771028
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method __getstate__"""

    # We do not use the lazy_compile function. We want to test the methods of
    # class LazyRegex. So we instantiate this class with the two paramaters
    # args, kwargs (the other parameters are not used).
    re_compile = LazyRegex(args = ("abc",), kwargs = {})

    # The first call of a method of re_compile must cause the compile of
    # the pattern "abc" with the function _real_re_compile and must
    # return an object of type _sre.SRE_Pattern.
    assert re_compile._real_regex is None
    re_pattern = re_compile.search("abc")

# Generated at 2022-06-21 21:55:05.398577
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex.

    This test verifies that the state of a LazyRegex instance can be
    set from a pickled state.
    """
    import pickle

    original = LazyRegex(args=('foo',), kwargs={'flags': re.I})
    pickled_state = pickle.dumps(original)
    instance = LazyRegex(args=('bar',), kwargs={'flags': re.X})
    instance.__setstate__(pickle.loads(pickled_state))
    # Ensure that the instance is now in the same state as the original
    # instance
    assert "foo" in repr(instance)
    assert "bar" not in repr(instance)
    assert "re.I" in repr(instance)

# Generated at 2022-06-21 21:55:18.988414
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    ip1 = InvalidPattern('message 1')
    ip2 = InvalidPattern('message 1')
    ip3 = InvalidPattern('message 2')
    ip4 = RuntimeError('message 1')
    assert(ip1 == ip2)
    assert(ip1 != ip3)
    assert(ip1 != ip4)

# Generated at 2022-06-21 21:55:23.898628
# Unit test for function reset_compile
def test_reset_compile():
    re.compile("^hello$")
    install_lazy_compile()
    re.compile("^hello$", re.IGNORECASE)
    reset_compile()
    re.compile("^hello$", re.IGNORECASE)

# Generated at 2022-06-21 21:55:33.486826
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the method __setstate__ of class LazyRegex.

    Test that the method __setstate__() of class LazyRegex restores the state
    of an instance of LazyRegex properly after pickling and unpickling."""
    lr = LazyRegex(args=("[A-Z]",), kwargs={"flags":re.IGNORECASE})
    lr.__getattr__("findall")
    assert lr._real_regex is not None
    data = lr.__getstate__()
    lr.__setstate__(data)
    lr.__getattr__("findall")
    assert lr._real_regex is None

# Generated at 2022-06-21 21:55:36.400567
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    l_re = LazyRegex(("pattern",), {'flags':1})
    state = l_re.__getstate__()
    assert state == {"args":("pattern",), "kwargs":{'flags':1}}


# Generated at 2022-06-21 21:55:38.503563
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex = LazyRegex("a")
    test_regex = re.compile("a")
    assert regex.match("a").group() == test_regex.match("a").group()

# Generated at 2022-06-21 21:55:45.224502
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that LazyRegex.__getattr__ always returns value.

    Python re.compile method has a side-effect: it can raise re.error exception.
    """
    p = LazyRegex(("*",), {})
    assert p.pattern == "*", 'Test: invalid regex pattern.'
    assert p.flags == 0, 'Test: invalid regex flags.'


# Generated at 2022-06-21 21:55:50.019312
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    LR = LazyRegex(('f.*u',), dict())
    assert not hasattr(LR, 'match')
    assert not hasattr(LR, 'search')
    LR.match('foo')
    assert hasattr(LR, 'match')
    assert hasattr(LR, 'search')

# Generated at 2022-06-21 21:55:58.194010
# Unit test for function finditer_public
def test_finditer_public():
    teststr = "abc"
    testpattern = "abc"
    testpattern_lazy = LazyRegex((testpattern,))
    assert [m.group(0) for m in re.finditer(testpattern, teststr)] == \
        [m.group(0) for m in finditer_public(testpattern, teststr)]

    try:
        for m in finditer_public(testpattern_lazy, teststr):
            break
    except AttributeError:
        # This is the desired behavior for LazyRegex
        pass
    else:
        # Should not come here
        assert False

# Generated at 2022-06-21 21:56:03.709893
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object

    If the regex hasn't been compiled yet, compile it
    """
    regex = LazyRegex(("pattern", re.IGNORECASE))
    assert regex.pattern  # should trigger compilation
    assert regex.groups == 0 # was 0 before compilation



# Generated at 2022-06-21 21:56:10.565163
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test that LazyRegex.__setstate__ works as expected.
    """
    # Create a proxy object
    proxy = LazyRegex(('^a',))
    # pickle it
    dict = proxy.__getstate__()
    # restore it
    proxy.__setstate__(dict)
    # check that it has been restored
    assert proxy._regex_args == ('^a',)
    assert proxy._regex_kwargs == {}

# Generated at 2022-06-21 21:56:26.314442
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should compile the regex if it is not yet compiled"""
    lazy_regex = LazyRegex(("abc",))
    assert (lazy_regex._real_regex is None)
    lazy_regex.match("abc")
    assert (lazy_regex._real_regex is not None)



# Generated at 2022-06-21 21:56:37.696786
# Unit test for function finditer_public
def test_finditer_public():
    """Test re.finditer calls LazyRegex.finditer.

    This function is performed in a try/except in order to make sure
    we have the re module loaded first.
    """
    try:
        re
    except NameError:
        return

    import re
    import re as _re

    def finditer_mock(pattern, string, flags=0):
        pass

    _re.finditer = finditer_mock
    try:
        re.finditer(LazyRegex(), "")
    except TypeError:
        return
    else:
        raise AssertionError("Should throw a 'TypeError' exception")
    finally:
        _re.finditer = re.finditer

# Generated at 2022-06-21 21:56:44.629376
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    err = InvalidPattern("Error message")
    expected = 'InvalidPattern("Error message")'
    actual = repr(err)
    assert expected == actual #, "%r != %r" % (expected, actual)
    err = InvalidPattern("Error message %(foo)s")
    actual = repr(err)
    assert expected == actual #, "%r != %r" % (expected, actual)
    err = InvalidPattern("Error message %(foo)s")
    err.foo = "bar"
    expected = 'InvalidPattern("Error message %(foo)s")'
    actual = repr(err)
    assert expected == actual #, "%r != %r" % (expected, actual)

# Generated at 2022-06-21 21:56:53.782930
# Unit test for function lazy_compile
def test_lazy_compile():
    import pickle
    obj = lazy_compile('a+')
    assert obj.__getstate__() == { 'args': ('a+',), 'kwargs': {} }
    obj.__setstate__(obj.__getstate__())
    assert obj._regex_args == obj.__getstate__()['args']
    assert obj.match('aaa')
    obj2 = pickle.loads(pickle.dumps(obj))
    assert obj2.match('aaa')
    assert not obj2.match('bbb')
    assert obj.match('aaa')
    assert not obj.match('bbb')