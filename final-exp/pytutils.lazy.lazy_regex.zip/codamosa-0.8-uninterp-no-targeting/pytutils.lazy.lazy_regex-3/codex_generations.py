

# Generated at 2022-06-21 21:47:09.135129
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import sys

    # get the real value of stdout
    stdout = sys.stdout

    try:
        # redirect stdout to a StringIO
        from StringIO import StringIO
        sys.stdout = StringIO()

        # try to print an InvalidPattern object
        from bzrlib.osutils import invalid_pattern
        assert unicode(invalid_pattern('test')) == 'Invalid pattern(s) found. "test"'
    finally:
        # restore stdout
        sys.stdout = stdout

# Generated at 2022-06-21 21:47:16.627809
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalid_pattern = InvalidPattern('some message')
    # check type
    result = invalid_pattern.__str__()
    if not isinstance(result, str):
        raise AssertionError("method __str__ of InvalidPattern must " \
            "return a str object.")
    # check value
    result2 = invalid_pattern.__str__()
    if result != 'some message':
        raise AssertionError("method __str__ of InvalidPattern must " \
            "return the same string passed to its constructor.")

# Generated at 2022-06-21 21:47:26.349203
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__()"""
    from bzrlib.errors import BzrError
    from bzrlib.i18n import gettext
    try:
        raise InvalidPattern(u'foo')
    except InvalidPattern as e:
        # Since InvalidPattern does not provide its own format string, it
        # should use the _fmt attribute
        e._get_format_string().encode('utf8') == 'Invalid pattern(s) found. %(msg)s'
        e.__unicode__().encode('utf8') == 'Invalid pattern(s) found. foo'
        e.__str__() == 'Invalid pattern(s) found. foo'
        e.__repr__() == 'InvalidPattern(Invalid pattern(s) found. foo)'

# Generated at 2022-06-21 21:47:31.915839
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should be able to specifiy the exact class.

    This method is needed to know how to make a copy of this class, but in
    practice this is only used while testing.
    """
    error = InvalidPattern('foo')
    repr(error)

# Generated at 2022-06-21 21:47:36.313684
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    p = re.compile('abc')
    assert isinstance(p, LazyRegex), repr(p)
    assert p._real_regex is None
    p.pattern
    assert p._real_regex is not None


# Generated at 2022-06-21 21:47:42.973201
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that LazyRegex.__getattr__ loads the proper regex"""
    install_lazy_compile()
    try:
        real_regex = re.compile('(a)')
        lazy_regex = re.compile('(a)')
        assert lazy_regex._real_regex is None
        assert lazy_regex.findall('aba') == real_regex.findall('aba')
        assert lazy_regex._real_regex is real_regex
    finally:
        reset_compile()

# Generated at 2022-06-21 21:47:49.157375
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ returns False for objects of different class, NotImplemented for
    objects of different class that are not InvalidPattern
    """
    ip = InvalidPattern("Error")
    assert not ip.__eq__("Error")
    assert ip.__eq__(InvalidPattern("Error"))
    assert not ip.__eq__(InvalidPattern("Different Error"))
    assert ip.__eq__(ip)

# Generated at 2022-06-21 21:47:57.696790
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should be able to retrieve attributes from the
    proxy"""

    class LazyRegexTestClass(LazyRegex):
        def __init__(self, *args, **kwargs):
            self._real_regex = object()
            self._regex_attributes_to_copy = []

    pattern = LazyRegexTestClass('foo')
    assert pattern._real_regex is pattern.__getattr__('_real_regex')

# Install the overridden re.compile function at the end so that if someone
# imports this module it won't be active unless they ask for it
install_lazy_compile()

# Generated at 2022-06-21 21:48:04.779259
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    # pickle a pattern
    r = re.compile('pattern for test')
    s = pickle.dumps(r)
    # unpickle it
    r = pickle.loads(s)
    # test
    if not isinstance(r, re._pattern_type):
        raise AssertionError(
            'result of Unpickling of a LazyRegex object must be a real regex')


# Generated at 2022-06-21 21:48:12.783157
# Unit test for function reset_compile
def test_reset_compile():
    # Sanity check
    if re.compile is not lazy_compile:
        raise ValueError("re.compile is not lazy_compile")
    reset_compile()
    if re.compile is lazy_compile:
        raise ValueError("re.compile is still lazy_compile")
    re.compile = lazy_compile
    reset_compile()
    if re.compile is not _real_re_compile:
        raise ValueError("re.compile is not _real_re_compile")


# Generated at 2022-06-21 21:48:20.174164
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = _real_re_compile
    re.compile = lazy_compile
    reset_compile()
    re.compile = lazy_compile
    reset_compile()

# Generated at 2022-06-21 21:48:31.365386
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestCase
    from bzrlib.tests import KnownFailure
    from bzrlib.revision import _format_revno_sort_key
    import re
    class TestResetCompile(TestCase):
        def setUp(self):
            super(TestResetCompile, self).setUp()
            reset_compile()
            self.addCleanup(reset_compile)
        def test_re_compile_forgotten_args(self):
            self.assertRaises(TypeError, re.compile, "pattern", flags=0)
        def test_re_compile_not_forgotten_args(self):
            re.compile("pattern", flags=0, other='arg')
        def test_reset_compile(self):
            reset_compile()
           

# Generated at 2022-06-21 21:48:41.883789
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Make sure that LazyRegex.__getattr__ works as expected."""
    import re
    old_compile = re.compile
    # Make sure re.compile returns a LazyRegex
    re.compile = lazy_compile
    regex = re.compile(".*")
    # Make sure that a compiled regex is always returned and that the original
    # compile method is changed to return compiled regexs
    regex2 = re.compile(".*")
    assert regex is regex2
    # Make sure that __getattr__ returns valid regex objects
    assert type(regex.findall) == type(re.findall)
    assert type(regex.match) == type(re.match)
    assert type(regex.finditer) == type(re.finditer)
    assert type(regex.search)

# Generated at 2022-06-21 21:48:49.300172
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex objects should be created"""
    lazy_re = LazyRegex(r'^foo.*')
    # _real_regex should not have been created yet
    assert lazy_re._real_regex is None
    assert lazy_re.pattern == r'^foo.*'
    # Check that _real_regex has been created
    assert lazy_re._real_regex is not None
    assert lazy_re._real_regex.pattern == r'^foo.*'

# Generated at 2022-06-21 21:49:02.879491
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # When called, this should return a LazyRegex
    r = re.compile('a.*b')
    # unless the implementation of LazyRegex is broken, the
    # compile won't actually be invoked until the regex is used
    if hasattr(r, '_real_regex'):
        raise AssertionError('re.compile returned a LazyRegex, but '
                             'the underlying regex was already compiled')

    # now try using the regex
    if not r.search('abc'):
        raise AssertionError('re.compile returned a LazyRegex, '
                             'but the regex didn\'t work')

    # now check that we can call reset_compile()
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError

# Generated at 2022-06-21 21:49:14.655775
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test LazyRegex __getstate__ method."""
    lazy_regex = LazyRegex(args=('test pattern', ))
    # The __getstate__ method returns a dict of two keys:
    state_keys = set(lazy_regex.__getstate__().keys())
    expected_keys = set(['args', 'kwargs'])
    # Verify that the method returns the expected keys.
    if state_keys != expected_keys:
        raise AssertionError("Unexpected state keys: %s" % (
            set(lazy_regex.__getstate__()).symmetric_difference(expected_keys)))



# Generated at 2022-06-21 21:49:25.326909
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    import bzrlib.regex
    bzrlib.regex.install_lazy_compile()
    # lazy_regex proxies won't be equal to each other
    re1 = re.compile("h.*")
    re2 = re.compile("h.*")
    assert(re1 != re2)
    # But will be equal to the underlying regex
    assert(re1 == re.compile("h.*"))
    assert(re2 == re.compile("h.*"))



# Generated at 2022-06-21 21:49:39.500082
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # Test constructor and all the other methods.
    tests = (
        (InvalidPattern(u'foo'),
                     # self, actual
                     u'foo',
                     # repr
                     u'InvalidPattern(u\'foo\')',
                     # str
                     u'foo'),
        (InvalidPattern(u'foo\tbar'),
                     # self, actual
                     u'foo\tbar',
                     # repr
                     u'InvalidPattern(u\'foo\\tbar\')',
                     # str
                     u'foo\tbar'),
        )


# Generated at 2022-06-21 21:49:51.117372
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Testing method __unicode__ of class InvalidPattern

    The method verifies that the message of the InvalidPattern (if
    present) is correctly decoded from utf-8.
    """
    from bzrlib import (
        _i18n_exceptions,
        )
    s = b"\xe4\xf6\xfc\xc4\xd6\xdc\xdf"
    ex = InvalidPattern(s)
    assert isinstance(ex.__unicode__(), unicode)
    # If the exception string is already unicode don't try to
    # decode it, just return the unicode string
    ex = InvalidPattern(u'\xe4\xf6\xfc')
    assert isinstance(ex.__unicode__(), unicode)

# Generated at 2022-06-21 21:50:03.017037
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the LazyRegex.__setstate__ method."""
    import cPickle

    lazy_regex_object = LazyRegex(("^([0-9]+)$",), {'flags': 0})
    # check that the lazy_regex_object is not compiled
    try:
        lazy_regex_object.match("0")
    except AttributeError:
        pass
    else:
        raise AssertionError("LazyRegex object should not be compiled")
    # pickle the lazy_regex_object
    pickled_lazy_regex_object = cPickle.dumps(lazy_regex_object)
    # load back the pickled lazy_regex_object

# Generated at 2022-06-21 21:50:13.519339
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Check whether the __getstate__ method for the LazyRegex class works
       correctly"""
    lazy_re = LazyRegex(args=('^a/b', re.IGNORECASE), kwargs={})
    expected_state = {"args": ("^a/b", re.IGNORECASE),
                      "kwargs": {}}
    assert(lazy_re.__getstate__() == expected_state)




# Generated at 2022-06-21 21:50:20.265243
# Unit test for function reset_compile
def test_reset_compile():
    # set up the initial state so that reset_compile is a no-op.
    reset_compile()
    # Change the state, so that we can tell if the reset actually did something
    re.compile = lambda *args, **kwargs: _real_re_compile(*args, **kwargs)
    re.compile.__name__ = 'compile'
    re.compile.__doc__ = _real_re_compile.__doc__
    # Now reset
    reset_compile()
    # And check it was reset.
    if re.compile is not _real_re_compile:
        raise AssertionError(
            "re.compile was not reset to its original value")



# Generated at 2022-06-21 21:50:30.871682
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import sys
    exc = InvalidPattern('msg')
    exc._preformatted_string = 'preformatted msg'
    has_unicode_type = isinstance(u'A', unicode)
    if has_unicode_type:
        u = unicode(exc)
        if not isinstance(u, unicode):
            raise AssertionError('%s is not a unicode object' % (u,))
    else:
        # We are on Python 3 where unicode does not exist.
        # We just need to ensure the __str__ is unicode
        u = str(exc)
        if not isinstance(u, str):
            raise AssertionError('%s is not a str object' % (u,))

# Generated at 2022-06-21 21:50:36.722535
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must return the same state that comes from __getstate__"""
    obj = LazyRegex()
    state = obj.__getstate__()
    obj2 = LazyRegex()
    obj2.__setstate__(state)
    state2 = obj2.__getstate__()
    if state != state2:
        raise AssertionError("__setstate__ does not work properly")

# Generated at 2022-06-21 21:50:49.522366
# Unit test for function finditer_public
def test_finditer_public():
    """Check that the function overrides re.finditer works"""
    # This is the class used by the standard 're' module
    from bzrlib.tests import TestCase
    pattern = LazyRegex(['a'])
    class FakeMatchObject(object):
        def group(self, i=0):
            return i
    finditer = FakeMatchObject()
    finditer.next = lambda : FakeMatchObject()
    finditer.next.next = lambda : finditer.next
    finditer.next.next.next = finditer.next
    finditer.next.next.next.next = None
    pattern.finditer = lambda s: finditer
    self = TestCase()
    self.assertEqual(4, len(list(re.finditer('a', 'aaaa'))))

# Generated at 2022-06-21 21:50:55.185392
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ method of LazyRegex class."""
    pattern = LazyRegex(["foo"])
    state = pattern.__getstate__()
    # state[0] will contain a tuple of the args passed to LazyRegex.__init__
    assert state["args"] == ["foo"]
    assert state["kwargs"] == {}

# Generated at 2022-06-21 21:50:58.990375
# Unit test for constructor of class InvalidPattern

# Generated at 2022-06-21 21:51:09.890283
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """check InvalidPattern.__str__()"""
    # check InvalidPattern.__str__() without preformatted string
    err = InvalidPattern('hello world')
    assert str(err) == 'hello world'
    assert unicode(err) == unicode('hello world')

    # check InvalidPattern.__str__() with preformatted string
    err = InvalidPattern(None)
    err._preformatted_string = 'hello world'
    assert str(err) == 'hello world'
    assert unicode(err) == unicode('hello world')

    # check InvalidPattern.__str__() with Unicode preformatted string
    err = InvalidPattern(None)
    err._preformatted_string = u'h\u1234'
    assert str(err) == 'h\xe1\x88\xb4'
    assert unicode

# Generated at 2022-06-21 21:51:13.886923
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert re.compile is lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-21 21:51:24.038036
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex__getattr__"""
    import re
    regex = LazyRegex(('^(foo)|(bar)$',))
    regex.match('foobar')
    assert regex.pattern == '^(foo)|(bar)$'
    assert regex.flags == 0
    assert regex.groups == 3
    assert regex.groupindex == {}
    assert isinstance(regex.__copy__(), re._pattern_type)
    assert isinstanc

# Generated at 2022-06-21 21:51:38.825616
# Unit test for function lazy_compile
def test_lazy_compile():

    # Check that we start from the correct state
    # The point of this is if someone has already patched re,
    # we will continue to work.
    compile = re.compile
    re.compile = _real_re_compile
    assert re.compile == _real_re_compile
    re.compile = compile

    # Now check that we can lazy compile properly
    re.compile = lazy_compile
    try:
        if re.compile(".").__class__ is not LazyRegex:
            raise AssertionError("Compilation not being proxied")
        re.compile(".", re.I)
    finally:
        re.compile = _real_re_compile

# Generated at 2022-06-21 21:51:46.567393
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object even if the object is
    subclass of InvalidPattern.
    """
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'PATTERN'
    e = MyInvalidPattern('FOO')
    u = unicode(e)
    s = str(e)
    assert isinstance(u, unicode)
    assert isinstance(s, str)
    assert u
    assert s

# Generated at 2022-06-21 21:51:50.720524
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = re.compile('(?P<foo>bar)')
    r.match('bar')
    s = LazyRegex()
    # Just a test to make sure the following does not fail
    s.match('bar')


# Generated at 2022-06-21 21:51:57.828283
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Class LazyRegex must have a constructor"""
    pattern = 'foo'
    regex = LazyRegex(args=(pattern,))

    # The regex has not been compiled yet
    assert regex._real_regex is None
    assert regex._regex_args == (pattern,)
    assert regex._regex_kwargs == {}

test_LazyRegex.todo = 'LazyRegex is not used (yet)'

# Generated at 2022-06-21 21:52:06.288444
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # make sure this is still true after having modified the class
    def check_equal(a, b):
        """Return True if the two objects compares equal"""
        if a == b:
            return True
        else:
            return False

    # same subclasses (works)
    a = InvalidPattern('')
    b = InvalidPattern('')
    check_equal(a, b)

    # different subclasses (fails)
    class SubclassA(InvalidPattern):
        pass
    class SubclassB(InvalidPattern):
        pass
    a = SubclassA('')
    b = SubclassB('')
    check_equal(a, b)

# Generated at 2022-06-21 21:52:12.402881
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    err = InvalidPattern('foobar')
    err_repr = repr(err)
    err_str = str(err)
    assert err_repr == err_str
    assert err_repr == 'InvalidPattern(\'foobar\')'
    err = InvalidPattern('invalid pattern:%(msg)s')
    err._preformatted_string = 'invalid pattern: foobar'
    err_repr = repr(err)
    err_str = str(err)
    assert err_repr == err_str
    assert err_repr == 'InvalidPattern(\'invalid pattern: foobar\')'



# Generated at 2022-06-21 21:52:18.415030
# Unit test for function finditer_public
def test_finditer_public():
    if not getattr(re, 'finditer', False):
        return
    # search for 'a' in 'abc'
    a_pat = LazyRegex(('a', ))
    a_pat_iter = finditer_public(a_pat, 'abc')
    # check it returned a LazyRegexIterator
    assert isinstance(a_pat_iter, re._LazyRegexIterator), \
        '%r is not an instance of LazyRegexIterator' % a_pat_iter
    # assert this iterator has the string 'abc'
    assert a_pat_iter.string == 'abc', \
        '%s should be the string abc' % a_pat_iter.string
    # assert the iterator itself is an iterator

# Generated at 2022-06-21 21:52:22.460771
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern"""
    # Test for equality
    error = InvalidPattern('msg')
    assert error == InvalidPattern('msg')
    # Test for inequality
    assert error != InvalidPattern('other_msg')
    assert error != InvalidPattern('msg')
    assert error != InvalidPattern('different')

# Generated at 2022-06-21 21:52:33.778587
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set _regex_args and _regex_kwargs."""
    lr = LazyRegex(('(?i)abc',), {'a': 'b'})
    # On default initialization, _regex_args and _regex_kwargs should not be
    # None.
    assert lr._regex_args is not None
    assert lr._regex_kwargs is not None
    # Calling __setstate__ should set _regex_args and _regex_kwargs to a new
    # dict.
    lr.__setstate__({'args': (), 'kwargs': {}})
    assert lr._regex_args == ()
    assert lr._regex_kwargs == {}

# Generated at 2022-06-21 21:52:44.395223
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()

# Generated at 2022-06-21 21:53:00.788024
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """InvalidPattern can be build with str, unicode or InvalidPattern."""
    from bzrlib.i18n import _i18n_string
    for msg in ["invalid regex",
                u'inva\u00f1ida regex',
                _i18n_string("invalid regex")]:
        try:
            raise InvalidPattern(msg)
        except InvalidPattern as e:
            assert isinstance(e.msg, unicode)
            assert isinstance(str(e), str)
            assert isinstance(unicode(e), unicode)

# Generated at 2022-06-21 21:53:02.603065
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    # This shouldn't raise recursion errors
    reset_compile()
    # check that it uses a real compile
    assert re.compile("foo")

# Generated at 2022-06-21 21:53:03.260936
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()

# Generated at 2022-06-21 21:53:05.470588
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test that InvalidPattern.__repr__ doesn't blow up."""
    InvalidPattern('').__repr__()
    InvalidPattern('a').__repr__()
    InvalidPattern(u'a').__repr__()

# Generated at 2022-06-21 21:53:14.158833
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for finditer_public"""
    re.finditer("abc", "abc def")
    re.finditer("abc", "abc def", re.IGNORECASE)
    re.finditer(re.compile("abc"), "abc def")
    re.finditer(re.compile("abc", re.IGNORECASE), "abc def")
    re.finditer(re.compile("abc", re.IGNORECASE), "abc def", re.IGNORECASE)


# Use lazy_compile as the default compilation method.
install_lazy_compile()

# Generated at 2022-06-21 21:53:16.038573
# Unit test for function reset_compile
def test_reset_compile():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 21:53:27.418775
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__ should compare all attributes and their values"""
    e1 = InvalidPattern('foo')
    e1.arg = 'bar'
    e2 = InvalidPattern('foo')
    e2.arg = 'bar'
    import cPickle
    pickle = cPickle.dumps(e1)
    e1a = cPickle.loads(pickle)
    e2a = cPickle.loads(pickle)
    pickle = cPickle.dumps(e2)
    e1b = cPickle.loads(pickle)
    e2b = cPickle.loads(pickle)
    assert e1 == e1
    assert e1a == e1
    assert e1b == e1
    assert e2 == e2
    assert e2a == e2
    assert e

# Generated at 2022-06-21 21:53:37.431863
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ must return True if and only if all attributes of the object
    compared are equal.
    """
    p1 = InvalidPattern(u"hello")
    p2 = InvalidPattern(u"hello")
    p3 = InvalidPattern(u"hello")
    p4 = InvalidPattern(u"hello2")
    p5 = InvalidPattern(u"hello2")
    p3.__dict__["foo"] = "bar"
    p4.__dict__["foo"] = "bar"
    assert p1 == p2
    assert p1 != p3
    assert p1 == p4
    assert p4 == p5
    assert p4 != p3

# Generated at 2022-06-21 21:53:43.612538
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern

    >>> exc = InvalidPattern("foo")
    >>> exc
    InvalidPattern('foo')
    >>> unicode(exc)
    u'foo'
    >>> str(exc)
    'foo'
    >>> e = InvalidPattern(u'\u20ac')
    >>> isinstance(str(e), str)
    True
    >>> isinstance(unicode(e), unicode)
    True
    """
    pass

# Generated at 2022-06-21 21:53:45.840689
# Unit test for function finditer_public
def test_finditer_public():
    """Test function finditer_public"""
    it = re.finditer('foo', 'foo')
    for x in it:
        pass

# Generated at 2022-06-21 21:53:57.665381
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """ This method check that the state to use when pickling is properly
    returned by __getstate__.
    """
    lr = LazyRegex(args=('foobar',))
    result = lr.__getstate__()
    assert(len(result) == 2)
    assert('args' in result)
    assert('kwargs' in result)
    assert(result['args'] == ('foobar',))
    assert(result['kwargs'] == {})


# Generated at 2022-06-21 21:54:06.282632
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """
    Test re_lazy.InvalidPattern.__unicode__().

    Test that it returns a unicode object
    """
    from bzrlib.i18n import gettext
    d = {'_fmt': '%(msg)s %(name)s', 'msg': 'test message', 'name': 'name'}
    ip = InvalidPattern(**d)
    u = unicode(ip)
    assert isinstance(u, unicode)


# Test for method _get_format_string() of class InvalidPattern


# Generated at 2022-06-21 21:54:16.495515
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex."""
    re_compile = LazyRegex(args=("(?:a)",), kwargs={})
    expected = {"args": ("(?:a)",), "kwargs": {}}
    actual = re_compile.__getstate__()
    if expected != actual:
        raise AssertionError("Unit test for method __getstate__ of class "
                             "LazyRegex failed\n"
                             "    Expected: %r\n"
                             "    Actual: %r"
                             % (expected, actual))


# Generated at 2022-06-21 21:54:28.094438
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern"""
    from bzrlib.tests import TestCase

    msg1 = 'One pattern found.'
    msg2 = 'Two patterns found.'
    ip1 = InvalidPattern(msg1)
    ip2 = InvalidPattern(msg2)
    ip3 = InvalidPattern(msg1)

    class TestInvalidPattern(TestCase):

        def test___eq__(self):
            self.assertEqual(ip1, ip3) # compare equal
            self.assertNotEqual(ip1, ip2) # compare not equal to different object
            self.assertNotEqual(ip1, None) # compare not equal to None
            self.assertNotEqual(ip1, msg1) # compare not equal to string
            self.assertNotEqual(ip1, '%s' % ip1) #

# Generated at 2022-06-21 21:54:38.363786
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """test_LazyRegex___getattr__()

    This tests that LazyRegex returns the right type of object
    when __getattr__ is called.
    It also tests that __getattr__ doesn't cause infinite recursion.
    """
    test_pattern = LazyRegex(("a", 0))
    test_pattern.finditer("a")
    # These two tests make sure that finditer returns the same type of
    # object as the original re.finditer class
    assert isinstance(test_pattern.finditer("a"), re.finditer("a").__class__)
    assert isinstance(test_pattern.finditer("a"), type(re.finditer("a")))

# Generated at 2022-06-21 21:54:44.109934
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile restores the original function."""
    install_lazy_compile()
    reset_compile()
    # We can't use the normal assertEquals here because it will in-turn
    # call re.compile, but that is what we are testing here.
    if re.compile is not _real_re_compile:
        raise AssertionError("re.compile was not restored.")

# Generated at 2022-06-21 21:54:45.823494
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('msg')
    e2 = InvalidPattern('msg')
    assert (e1 == e2)

# Generated at 2022-06-21 21:54:49.379917
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ compares instances of InvalidPattern."""
    e1 = InvalidPattern('a')
    e2 = InvalidPattern('b')
    assert e1 == e1
    assert e1 != e2
    assert e1 != 'a'
    assert e1 != 'b'


# Generated at 2022-06-21 21:54:50.922209
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    exc = InvalidPattern(msg='msg')
    assert str(exc) == 'InvalidPattern(msg)'

# Generated at 2022-06-21 21:54:58.307862
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Testing method __getstate__ of class LazyRegex"""
    lazy_regex = LazyRegex((r'(?P<first>\w+)://(?P<second>[\w\.]+)/(?P<third>.+)', re.IGNORECASE), {})
    state = lazy_regex.__getstate__()
    args, kwargs = state['args'], state['kwargs']
    new_regex = re.compile(*args, **kwargs)
    # This regex was not compiled yet
    lazy_regex._compile_and_collapse()
    # Now this regex is compiled
    assert new_regex._sre.pattern == lazy_regex._sre.pattern
    assert new_regex._sre.flags == lazy_regex._sre.flags
    assert new_

# Generated at 2022-06-21 21:55:10.744536
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    args = (r'(?P<foo>bar)',)
    kwargs = {'flags': re.IGNORECASE}
    lazy_r = lazy_compile(*args, **kwargs)
    new_lazy_r = LazyRegex()
    new_lazy_r.__setstate__(lazy_r.__getstate__())
    real_r = new_lazy_r._real_regex
    assert real_r._pattern == args[0]
    assert real_r.flags == kwargs['flags']

# Generated at 2022-06-21 21:55:14.710738
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = LazyRegex()
    r = LazyRegex((r'xyz',))
    r = LazyRegex((r'xyz',), {'flags': re.IGNORECASE})


# Generated at 2022-06-21 21:55:22.657374
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    pattern = "pattern"
    def f(flags):
        return LazyRegex((pattern,), dict(flags=flags))
    for flags in (0, re.IGNORECASE, re.UNICODE, re.MULTILINE, re.VERBOSE,
                  re.IGNORECASE | re.MULTILINE,
                  re.IGNORECASE | re.MULTILINE | re.UNICODE):
        lr = f(flags)
        d = lr.__getstate__()
        assert d == {
            "args": (pattern,),
            "kwargs": {"flags": flags},
            }

# Generated at 2022-06-21 21:55:32.757365
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # Here we test for method __getstate__ of class LazyRegex
    # First the case when the regex has been compiled
    regex = re.compile('a')
    state = regex.__getstate__()
    assert state['args'] == (regex.pattern,)
    assert state['kwargs'] == {'flags':regex.flags}

    # Then the case when the regex has not been compiled
    args = ('a',)
    kwargs = {'flags':regex.flags}
    regex = LazyRegex(args, kwargs)
    state = regex.__getstate__()
    assert state['args'] == args
    assert state['kwargs'] == kwargs



# Generated at 2022-06-21 21:55:38.791988
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ returns correct value"""
    lazy = LazyRegex(r".*")
    state = lazy.__getstate__()
    expected = {'args': (r'.*',), 'kwargs': {}}
    new_lazy = LazyRegex(**state)
    assert lazy._regex_args[0] == new_lazy._regex_args[0], \
           "LazyRegex object failed to un-pickle"
    assert lazy._regex_kwargs == new_lazy._regex_kwargs


# install the default behaviour
install_lazy_compile()

# Generated at 2022-06-21 21:55:46.118436
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of class InvalidPattern."""
    err = InvalidPattern('invalid pattern %s %d %(k)d', k='v')
    assert str(err) == 'invalid pattern %s %d v'
    assert str(err.__class__(str(err), k='v2')) == 'invalid pattern %s %d v2'
    try:
        raise err
    except InvalidPattern as exc:
        assert str(exc) == str(err)

# Generated at 2022-06-21 21:55:57.700446
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests import TestCase
    reset_compile()
    re.compile('(a)|[bc]')
    re.compile('(a)|[bc]')
    global _n_calls
    _n_calls = 0
    def monkey_compile(str, *args, **kwargs):
        global _n_calls
        _n_calls += 1
        return _real_re_compile(str, *args, **kwargs)
    re.compile = monkey_compile
    re.compile('(a)|[bc]')
    re.compile('(a)|[bc]')
    self.assertEqual(_n_calls, 2)
    install_lazy_compile()
    re.compile('(a)|[bc]')

# Generated at 2022-06-21 21:56:07.516890
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """test that install_lazy_compile() replaces the original version"""
    re_compile_orig = re.compile
    install_lazy_compile()

# Generated at 2022-06-21 21:56:13.455168
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test case for method __setstate__ of class LazyRegex"""
    import pickle
    lazy = LazyRegex()
    b = pickle.dumps(lazy)
    lazy2 = pickle.loads(b)
    assert isinstance(lazy2, LazyRegex)
    assert lazy2._regex_args == ()
    assert lazy2._regex_kwargs == {}



# Generated at 2022-06-21 21:56:20.463050
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Test constructor with no arguments
    regex = LazyRegex()
    assert regex._real_regex is None
    assert regex._regex_args == ()
    assert regex._regex_kwargs == {}

    # Test constructor with arguments
    regex = LazyRegex(('abc',), {'abc': 1})
    assert regex._real_regex is None
    assert regex._regex_args == ('abc',)
    assert regex._regex_kwargs == {'abc': 1}


# Generated at 2022-06-21 21:56:38.429314
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    def check_equal(a, b):
        # Note that a.__class__ == b.__class__, but a and b are not
        # the same object
        assert(a.__dict__ == b.__dict__)
        assert(a == b)
        assert(not (a != b))

    def check_not_equal(a, b):
        # Note that a.__class__ == b.__class__, but a and b are not
        # the same object
        assert(a.__dict__ != b.__dict__)
        assert(a != b)
        assert(not (a == b))

    # The following two instances are equal
    a = InvalidPattern("the same message")
    b = InvalidPattern("the same message")
    check_equal(a, b)

    # Let's check that __eq

# Generated at 2022-06-21 21:56:40.743132
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern("error")
    except InvalidPattern as e:
        assert str(e) == u'Invalid pattern(s) found. "error"'


# Generated at 2022-06-21 21:56:48.113120
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ of LazyRegex

    This test covers all of the method.
    """
    lr = LazyRegex(args=("abc",))

    lr._real_regex = None
    lr._real_regex = "real_regex"
    assert lr.pattern == "real_regex"

    lr._real_regex = None
    lr._compile_and_collapse()
    assert lr.pattern == "abc"