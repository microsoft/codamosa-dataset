

# Generated at 2022-06-21 21:46:58.917941
# Unit test for function reset_compile
def test_reset_compile():
    import re
    install_lazy_compile()
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-21 21:47:11.148161
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method __setstate__ of class LazyRegex"""
    import pickle
    from bzrlib import tests

    proxy = LazyRegex(('(?<=^|\n)abc',), {'flags':re.MULTILINE})
    proxy._compile_and_collapse()
    save = pickle.dumps(proxy)
    proxy2 = pickle.loads(save)
    # test that this is a LazyRegex and a copy of the state
    tests.TestCase.assertIsInstance(proxy2, LazyRegex)
    tests.TestCase.assertEqual(proxy2._real_regex, proxy._real_regex)
    tests.TestCase.assertEqual(proxy2._real_regex.pattern, proxy._real_regex.pattern)

# Generated at 2022-06-21 21:47:21.719402
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Set up a mock object which will be called when compiling
    class MockRegex(object):
        def __init__(self, args, kwargs):
            self.args = args
            self.kwargs = kwargs
    _real_re_compile = re.compile
    re._real_re_compile = MockRegex
    # now check that LazyRegex objects are constructed correctly.
    reg = LazyRegex(('pattern',), {'flags': re.IGNORECASE})
    try:
        assert reg.args == ('pattern',)
        assert reg.kwargs == {'flags': re.IGNORECASE}
        assert reg._real_regex is None
    finally:
        # restore the original re.compile
        re.compile = _real_re_compile



# Generated at 2022-06-21 21:47:30.025522
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib.tests import TestCase

    def assert_iter(iterator, expected_items):
        """Assert that the iterator produces the specified items."""
        lst = list(iterator)
        self.assertEqual(len(lst), len(expected_items))
        for i, expected in enumerate(expected_items):
            self.assertEqual(lst[i].span(), expected.span())

    class FinditerPublicTest(TestCase):
        def test_single_lazy(self):
            expected = [_real_re_compile('f').search('f')]
            assert_iter(re.finditer(lazy_compile('f'), 'f'), expected)

        def test_multiple_lazy(self):
            expected = [_real_re_compile('f').search('foo')]


# Generated at 2022-06-21 21:47:35.216726
# Unit test for function finditer_public
def test_finditer_public():
    """Test the function finditer_public"""
    re.compile = lazy_compile
    comp = re.compile("[a-z]")
    # This will exercise the LazyRegex
    myiter = finditer_public(comp, "abc")
    assert(myiter.next().group(0) == "a")
    assert(myiter.next().group(0) == "b")
    assert(myiter.next().group(0) == "c")
    # This will just be a normal iterator
    myiter = finditer_public("[a-z]", "abc")
    assert(myiter.next().group(0) == "a")
    assert(myiter.next().group(0) == "b")
    assert(myiter.next().group(0) == "c")
    re.compile

# Generated at 2022-06-21 21:47:40.497364
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """The __eq__ function of class InvalidPattern"""
    a = InvalidPattern("a")
    b = InvalidPattern("b")
    NotImplemented
    assert a == a
    # __eq__ must return NotImplemented if the class of the other object is not
    # the same.
    assert a != NotImplemented
    assert a != b
    assert a != "abc"

# Generated at 2022-06-21 21:47:49.784770
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    m = re.compile("test")
    if not isinstance(m, LazyRegex):
        raise AssertionError("install_lazy_compile() doesn't install" \
                             " LazyRegex objects properly")
    reset_compile()
    m = re.compile("test")
    if isinstance(m, LazyRegex):
        raise AssertionError("reset_compile() doesn't reset," \
                             " LazyRegex objects still being installed")

if __name__ == "__main__":
    test_install_lazy_compile()

# Generated at 2022-06-21 21:47:53.657959
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() restores the original re.compile()"""
    # Call reset_compile() before installing, to see that it acts sanely
    reset_compile()
    re.compile = lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile

# Install the overridden re.compile method by default. This is what the
# lazy_re module does; not all tests require it.
install_lazy_compile()

# Generated at 2022-06-21 21:48:00.472085
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore the LazyRegex instance.

    This test was added because implementing pickling resulted in a
    segfault when running the test suite.
    """
    # This used to segfault:
    r = LazyRegex()
    r._compile_and_collapse()
    r2 = LazyRegex()
    r2.__setstate__(r.__getstate__())
    r2._compile_and_collapse()
    # This used to crash with a unicode encode error
    r3 = LazyRegex()
    r3.__setstate__(dict(args=("[:\\w]+",), kwargs={}))
    r3._compile_and_collapse()

# Generated at 2022-06-21 21:48:03.140602
# Unit test for constructor of class InvalidPattern

# Generated at 2022-06-21 21:48:12.435826
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set _regex_args and _regex_kwargs"""
    lazy_regex = LazyRegex()
    dict = {'args': 'a', 'kwargs': 'b'}
    lazy_regex.__setstate__(dict)
    assert lazy_regex._regex_args == dict['args']
    assert lazy_regex._regex_kwargs == dict['kwargs']

# Generated at 2022-06-21 21:48:14.552782
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    try:
        raise InvalidPattern(u'msg')
    except InvalidPattern as e:
        return e.__repr__()


# Generated at 2022-06-21 21:48:17.398891
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ of class InvalidPattern"""
    # Test that the repr of an InvalidPattern instance is correct
    invalid_pattern = InvalidPattern("test message")
    assert repr(invalid_pattern) == ('InvalidPattern("test message")')

# Generated at 2022-06-21 21:48:27.608413
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # Test: call _compile_and_collapse exactly one time
    class MockLazyRegex(LazyRegex):
        def __init__(self):
            LazyRegex.__init__(self)
            self.call_count = 0
            self.result = ''

        def _compile_and_collapse(self):
            self.call_count += 1
            self._real_regex = self
            return self.result
    lzr = MockLazyRegex()
    lzr_real_regex = lzr._real_regex
    assert lzr_real_regex is None
    # We should not call _compile_and_collapse
    assert lzr.call_count == 0
    # A normal attribute should work

# Generated at 2022-06-21 21:48:38.927787
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """test_LazyRegex___getattr__ tests the method LazyRegex.__getattr__.

    This method must do two things.
    1. If real_regex is None, the method _compile_and_collapse
       should be called.
    2. If this method is called again then real_regex is not None,
       the attribute must be obtained from real_regex.
    """
    class MockRegex(object):
        """MockRegex mocks a real regex for unit testing."""

        def __init__(self):
            self._num_calls = 0

        def _compile_and_collapse(self):
            """ record _compile_and_collapse is called. """
            self._num_calls = self._num_calls + 1

    regex = MockRegex()
   

# Generated at 2022-06-21 21:48:45.212766
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Examining method __eq__ of class InvalidPattern."""
    from bzrlib.tests import TestCase, TestSkipped
    try:
        raise InvalidPattern('msg1')
        raise TestSkipped('Raising InvalidPattern failed')
    except InvalidPattern as e1:
        try:
            raise InvalidPattern('msg2')
            raise TestSkipped('Raising InvalidPattern failed')
        except InvalidPattern as e2:
            class _test_InvalidPattern(TestCase):
                def test_equal(self):
                    self.assertFalse(e1 == e2)
                    e2.msg = 'msg1'
                    self.assertTrue(e1 == e2)
            return _test_InvalidPattern('test_equal')        
    raise TestSkipped('Could not raise InvalidPattern')

# Generated at 2022-06-21 21:48:48.127827
# Unit test for function finditer_public
def test_finditer_public():
    """Test the function finditer_public.

    This test can be run as a standalone unit test.
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:48:57.149906
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test for exception when the format string contains a replacement field
    class InvalidPatternFmt(ValueError):
        _fmt = 'Invalid pattern(s) found: %(msg)s'

    e = InvalidPatternFmt('Error')
    assert e.__unicode__() == u'Invalid pattern(s) found: Error'

    # Test for exception when the format string does not contain
    # a replacement field
    class InvalidPatternNoFmt(ValueError):
        _fmt = 'Invalid pattern(s) found.'

    e = InvalidPatternNoFmt('Error')
    assert e.__unicode__() == u'Invalid pattern(s) found.'

    # Test for exception when the _fmt attribute has a unicode value.
    # The value is a translation of the string 'Invalid pattern(s) found'

# Generated at 2022-06-21 21:48:58.745844
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-21 21:49:01.638310
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Class InvalidPattern must return a valid representation for __repr__
    """
    invalid = InvalidPattern("Bad charset in pattern: '0-0'")

    repr(invalid)

# Generated at 2022-06-21 21:49:16.420222
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('error message')
    except InvalidPattern as e:
        assert str(e) == 'error message'
        assert unicode(e) == 'error message', (
            "InvalidPattern.__unicode__() should return message; got %r"
            % (unicode(e),))
    try:
        raise InvalidPattern('error message with %(fmt)s')
    except InvalidPattern as e:
        assert str(e) == 'error message with %(fmt)s'
        assert unicode(e) == 'error message with %(fmt)s', (
            "InvalidPattern.__unicode__() should return message; got %r"
            % (unicode(e),))
        # set the fmt string back to the default
        e._fmt = InvalidPattern._fmt

# Generated at 2022-06-21 21:49:27.325067
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """This test makes sure that when an attribute is missing in a compile
    regex, the attribute is searched in the proxy.
    """
    # Create the regex
    regex = re.compile('match')
    # Check that the attr search in the proxy works
    pattern = regex.pattern
    # Check that the search in the proxy stops when the attribute is found
    # from the proxy itself
    p = re.compile('match', re.IGNORECASE)
    pattern = p.pattern
    # Check that the search in the proxy stops when the attribute is found
    # from a superclass
    p = re.compile('match', re.IGNORECASE)
    pattern = p.pattern

# Generated at 2022-06-21 21:49:35.185731
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    a = InvalidPattern("test")
    b = InvalidPattern("test")
    c = InvalidPattern("test_not_equal")
    d = ValueError("test")
    assert(a == b)
    assert(b == a)
    assert(a != c)
    assert(b != c)
    assert(a != d)
    assert(b != d)
    assert(c != d)

# Generated at 2022-06-21 21:49:44.061071
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile is a valid replacement for re.compile

    That is, it returns a proxy object which has the same methods
    and when called with the same arguments, it behaves the same.

    :return: None
    """
    import doctest, re
    from StringIO import StringIO

    def _set_result(text, pattern, result):
        """A replacement for re.search which always returns result"""
        return result

    def _list_result(text, pattern, result):
        """A replacement for re.search which adds the result to a list"""
        del text, pattern
        _list.append(result)

    def _string_result(text, pattern, result, string_io=None):
        """A replacement for re.search which adds the result to a stream"""
        del text, pattern

# Generated at 2022-06-21 21:49:56.197561
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    try:
        re.compile('foo')
    except ImportError:
        # re is not available
        return
    else:
        # re is available
        try:
            lazy_regex = lazy_compile('foo')
        except:
            raise
        else:
            # Make sure the proxy object works
            lazy_regex.match('foo')
            # Make sure it can be pickled
            import pickle
            pickle.loads(pickle.dumps(lazy_regex))
            # Make sure it can be unpickled
            import os, tempfile
            fd, name = tempfile.mkstemp()
            f = os.fdopen(fd, 'w+b')
            pickle.dump(lazy_regex, f)
            f.seek

# Generated at 2022-06-21 21:50:00.901515
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    a = LazyRegex(('\d', ))
    b = pickle.loads(pickle.dumps(a))
    self.assertEquals(a._regex_args, b._regex_args)

# Generated at 2022-06-21 21:50:03.743179
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    i = InvalidPattern("msg")
    s = str(i)
    assert s == 'Invalid pattern(s) found. msg', s
    assert i._format() == 'Invalid pattern(s) found. msg'

# Generated at 2022-06-21 21:50:16.167243
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should return a string object

       If an InvalidPattern object's .msg attribute is a unicode object,
       InvalidPattern.__str__ should return a string object encoded using
       utf8 encoding.
    """

    # this tests the UnicodeEncodeError branch in _format()
    import sys
    if sys.version_info[:2] <= (2, 6):
        # this tests the string __str__ branch in _format()
        class InvalidPattern2(InvalidPattern):
            """InvalidPattern2

               This class is used to test the branch which uses
               string __str__ in _format() because _get_format_string()
               returns None.
            """
            def _get_format_string(self):
                return None

        msg = 'Invalid pattern(s) found.\n'

        s = InvalidPattern2

# Generated at 2022-06-21 21:50:28.874300
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    u = InvalidPattern('msg')
    assert str(u) == unicode(u)
    assert isinstance(str(u), str)
    u = InvalidPattern('msg with %(type)s')
    assert str(u) == unicode(u)
    assert isinstance(str(u), str)
    u = InvalidPattern('msg %(type)s')
    u.type = 'with more'
    assert str(u) == unicode(u)
    assert isinstance(str(u), str)
    u = InvalidPattern('msg %(type)s')
    u.type = 'with more %(andmore)s'
    assert str(u) == unicode(u)
    assert isinstance(str(u), str)
    u = InvalidPattern('msg %(type)s')

# Generated at 2022-06-21 21:50:34.163320
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex."""
    # Test the effect of method __setstate__ on an empty LazyRegex object.
    test_object = LazyRegex()
    test_object.__setstate__({'args': (r'ABC',), 'kwargs': {}})
    # Test the effect of method __setstate__ on an non-empty LazyRegex object.
    test_object = LazyRegex(r'abc', {})
    test_object.__setstate__({'args': (r'DEF',), 'kwargs': {}})

# Generated at 2022-06-21 21:50:46.375176
# Unit test for function finditer_public
def test_finditer_public():
    import re
    r = LazyRegex(('ab*', re.I))
    res = re.finditer('abbb', 'abbb abbb')
    r_res = re.finditer(r, 'abbb abbb')
    assert [(i.group(0), i.start(), i.end()) for i in res] == \
        [(i.group(0), i.start(), i.end()) for i in r_res]

# Generated at 2022-06-21 21:50:53.768050
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ip = InvalidPattern(msg="hello")
    assert ip.msg == "hello"
    assert 'hello' in repr(ip)
    assert 'hello' in unicode(ip)
    # __str__ is the same as __unicode__
    assert unicode(ip) == str(ip)

if __name__ == '__main__':
    install_lazy_compile()

# Generated at 2022-06-21 21:51:03.346772
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib import tests
    import sys

    # This is a little hack to make the following attribute tests work
    # we add the attribute '_fmt' for the test and remove it after the test
    sys.modules['bzrlib.tests'].InvalidPattern._fmt = '%(msg)s'

    e1 = tests.InvalidPattern('msg1')
    e1_1 = tests.InvalidPattern('msg1')
    e2 = tests.InvalidPattern('msg2')
    e3 = tests.InvalidPattern(msg='msg1')
    e4 = tests.InvalidPattern('msg1', msg='msg1')
    e5 = tests.InvalidPattern(msg='msg1', more='more1')
    # The instances e1, e1_1 and e3 are equal, but e2, e4 and e5 are not.

# Generated at 2022-06-21 21:51:08.341889
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    try:
        re.compile('foo')
        is_proxy = isinstance(re.compile('foo'), LazyRegex)
        assert is_proxy
    finally:
        reset_compile()
    is_proxy = isinstance(re.compile('foo'), LazyRegex)
    assert not is_proxy

# Generated at 2022-06-21 21:51:11.176707
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    install_lazy_compile()


__all__ = [
    'install_lazy_compile',
    'reset_compile',
    'test_install_lazy_compile',
]

# Generated at 2022-06-21 21:51:13.236904
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test the method InvalidPattern.__repr__"""
    msg = 'test message'
    e = InvalidPattern(msg)
    assert repr(e) == 'InvalidPattern(%s)' % msg



# Generated at 2022-06-21 21:51:24.573934
# Unit test for function reset_compile
def test_reset_compile():
    """BzrTools.LazyRegex.test_reset_compile: test reset_compile()."""
    # reset_compile() should restore re.compile.
    reset_compile()
    assert re.compile is _real_re_compile

    # Calling reset_compile() multiple times shouldn't hurt.
    reset_compile()
    assert re.compile is _real_re_compile

    # re should remain unchanged in all other cases.
    assert re.match is _real_re.match
    assert re.search is _real_re.search

# Generated at 2022-06-21 21:51:36.662510
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile works correctly"""
    # Test that it actually overrides
    d = re.compile('a')
    install_lazy_compile()
    assert(re.compile is lazy_compile)
    assert(not isinstance(d, LazyRegex))
    e = re.compile('a', re.IGNORECASE)
    assert(isinstance(e, LazyRegex))
    assert(e is not d)
    reset_compile()
    assert(re.compile is _real_re_compile)
    assert(not isinstance(e, LazyRegex))
    assert(not isinstance(d, LazyRegex))

# Generated at 2022-06-21 21:51:42.825451
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """re.compile can be overridden to return a LazyRegex object."""
    install_lazy_compile()
    compiled = re.compile(r'foo')
    assert isinstance(compiled, LazyRegex)
    assert compiled._real_regex is None
    assert compiled._real_re_compile is re.compile
    reset_compile()



# Generated at 2022-06-21 21:51:48.038031
# Unit test for function lazy_compile
def test_lazy_compile():
    import re
    install_lazy_compile()
    p = re.compile("pattern")
    assert isinstance(p, LazyRegex)
    assert p._real_regex is None
    # match should be a 'method-wrapper'
    assert isinstance(p.match, type(p.__getattribute__("match")))
    # but once we've accessed it, we have the real regex
    assert isinstance(p.match("string"), type(re.match("pattern", "string")))
    reset_compile()



# Generated at 2022-06-21 21:52:07.458666
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    class E(Exception):
        pass

    for args in (
            (('msg0',), {}),
            (('msg1',), {'name': 'value'}),
            ((), {'msg': 'msg2', 'name': 'value'}),
            ((), {'msg': 'msg3'})):
        e0 = InvalidPattern(*args[0], **args[1])
        e1 = InvalidPattern(*args[0], **args[1])
        assert e0 == e1

        args[1].update({'name': 'another value'})
        e2 = InvalidPattern(*args[0], **args[1])
        assert e0 != e2

        e3 = E(*args[0], **args[1])
        assert e0 != e3

    # check that __eq__ handles the case where it is passed non

# Generated at 2022-06-21 21:52:14.772670
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    proxy1 = LazyRegex()
    proxy2 = LazyRegex()
    assert proxy1 is not proxy2
    assert proxy1 != proxy2
    assert proxy1.__class__ == proxy2.__class__

    # test __getattr__
    assert not hasattr(proxy1, '__deepcopy__')
    assert not hasattr(proxy1, '__copy__')
    assert not hasattr(proxy2, '__deepcopy__')
    assert not hasattr(proxy2, '__copy__')
    proxy1._compile_and_collapse()
    assert hasattr(proxy1, '__deepcopy__')
    assert hasattr(proxy1, '__copy__')
    assert not hasattr(proxy2, '__deepcopy__')
    assert not hasattr(proxy2, '__copy__')

    # test

# Generated at 2022-06-21 21:52:23.795261
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern

    It is a copy of unit test of class Exception.
    """
    # The test itself
    class Bad(Exception):
        def __init__(self, a, b):
            Exception.__init__(self, a, b)
            self.args = a, b
    err = Bad(1, 2)
    assert err == Bad(1, 2)
    assert err != Bad(1, 3)
    assert err != Bad(1, 2, 3)
    assert err != Bad(1, 2, None)
    assert err != Bad(1, None)
    assert err != 1
    assert err != 'test'


test_suite = TestUtil.make_suite(__name__)


# Generated at 2022-06-21 21:52:30.208874
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern"""
    e = InvalidPattern('Some message')
    e.name = 'name'
    e.attr = 'attr'
    assert repr(e) == "InvalidPattern('Some message', attr='attr', name='name')"


# Generated at 2022-06-21 21:52:42.779322
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ method of InvalidPattern objects

    This method is used to compare 2 InvalidPattern objects with
    each other. We compare the objects by comparing their class
    names, and their content of __dict__.

    This is also used for the __cmp__ method of InvalidPattern
    class, which is a C implementation of the comparison of two
    objects.

    This method should return True if the two objects are the same
    class, and have the same __dict__.
    """
    # Create 2 instances of the same class InvalidPattern, with
    # slightly different __dict__
    d1 = {'foo': 'bar'}
    d2 = {'foo': 'foo'}
    obj1 = InvalidPattern("hello world")
    obj1.__dict__ = d1
    obj2 = InvalidPattern("hello world!")
    obj2.__dict

# Generated at 2022-06-21 21:52:55.615734
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    class FakeRegex:
        def __init__(self, regex_args, regex_kwargs):
            self.regex_args = regex_args
            self.regex_kwargs = regex_kwargs

    fake_regex_1 = FakeRegex(regex_args=('abc',), regex_kwargs={'test': 1})
    fake_regex_2 = FakeRegex(regex_args=('def',), regex_kwargs={'test': 2})

    lazy_regex = LazyRegex(args=('abc',), kwargs={'test': 1})
    lazy_regex._real_regex = fake_regex_1
    delattr(lazy_regex, '_regex_args')
    delattr(lazy_regex, '_regex_kwargs')

    lazy

# Generated at 2022-06-21 21:53:00.632768
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ method must return a dict"""
    regex = LazyRegex()
    if not isinstance(regex.__getstate__(), dict):
        raise AssertionError('__getstate__ method of LazyRegex must return a dict')



# Generated at 2022-06-21 21:53:09.871581
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test lazy_compile using re.compile directly.

    This is probably not the best approach, but will do for now.
    """
    import pickle
    obj = lazy_compile('foo')
    newobj = pickle.loads(pickle.dumps(obj))
    assert isinstance(newobj, LazyRegex)
    assert newobj._real_regex is None
    assert newobj._regex_args == ('foo',)
    assert newobj._regex_kwargs == {}
    assert newobj.search('foo')
    assert not newobj.search('bar')

# Generated at 2022-06-21 21:53:14.807488
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # test with simple message
    e = InvalidPattern("Message")
    assert str(e) == "Invalid pattern(s) found. Message"

    # test with complex message
    e = InvalidPattern("Some message with %s" % 2)
    assert str(e) == "Invalid pattern(s) found. Some message with 2"



# Generated at 2022-06-21 21:53:18.423503
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__() of class InvalidPattern."""
    msg = "test message"
    ip = InvalidPattern(msg)
    assert repr(ip) == "InvalidPattern(%r)" % msg

# Generated at 2022-06-21 21:53:38.949412
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert isinstance(re.compile("a"), LazyRegex)
    reset_compile()
    assert not isinstance(re.compile("a"), LazyRegex)

# test that we have a reasonable message

# Generated at 2022-06-21 21:53:48.228209
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    error = InvalidPattern('nothing')

# Generated at 2022-06-21 21:53:56.047146
# Unit test for function finditer_public
def test_finditer_public():
    import testtools
    this = testtools.TestCase

    # re.finditer takes a compiled regex as a first argument.
    # re.finditer returns a iterator.

    # The first argument should have a finditer method.
    class MockLazyRegex(object):
        def finditer(self, string):
            return "string"
    mockLazyRegex = MockLazyRegex()

    finditer_public_result = this._finditer_public(mockLazyRegex, "string")
    this.assertEqual("string", finditer_public_result)

# Generated at 2022-06-21 21:54:01.837476
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    try:
        assert re.compile is lazy_compile
        assert re.compile('(s)') is not None
        assert isinstance(re.compile('(s)'), LazyRegex)
    finally:
        reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-21 21:54:09.547537
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ returns the internal state of a LazyRegex instance.

    That state should be a dictionary containing the original arguments
    provided to the constructor.
    """
    import pickle

    regex = LazyRegex(args=['abc'], kwargs={'flags': re.IGNORECASE})
    state = regex.__getstate__()
    restored = pickle.loads(pickle.dumps(regex))
    eq = (state['args'] == restored._regex_args)
    eq = eq and (state['kwargs'] == restored._regex_kwargs)
    return eq

# Generated at 2022-06-21 21:54:16.161464
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    real_re_compile = re.compile
    install_lazy_compile()
    assert re.compile != real_re_compile
    reset_compile()
    assert re.compile == real_re_compile

if __name__ == '__main__':
    # Run the unit test if run directly
    test_install_lazy_compile()

# Generated at 2022-06-21 21:54:19.595589
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    reset_compile()
    reset_compile()
    r = re.compile('.')
    assert r.groups == 0, r.groups

# Generated at 2022-06-21 21:54:26.970663
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the override does not prevent regex compilation"""
    # Note: This does not test that lazy_compile *does* work, just that it
    # doesn't prevent the normal operation of re.compile
    try:
        re.compile("[")
    except re.error:
        pass
    else:
        raise AssertionError("Didn't raise re.error on bad regex")


if __name__ == '__main__':
    install_lazy_compile()
    test_lazy_compile()

# Generated at 2022-06-21 21:54:29.472635
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    re.compile("a|b")
    reset_compile()
    re.compile("a|b")

# Generated at 2022-06-21 21:54:41.448036
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test case for method __getattr__ of class LazyRegex
    """
    import weakref
    import sys
    lazy_regex = LazyRegex(r'[0-9]')
    member_names = [name for name, value in LazyRegex.__dict__.items() \
        if isinstance(value, property)]
    for name in member_names:
        attr = getattr(lazy_regex, name)
        # Make sure getattr() doesn't return None
        if attr is None:
            return ('__getattr__ of class LazyRegex returns None for '
                'attribute %s' % name)
    regex = lazy_regex._real_re_compile(r'[0-9]')
    # We need to ensure that the proxy and the regex object use the same
   

# Generated at 2022-06-21 21:54:52.585055
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    v = InvalidPattern('message')
    assert repr(v) == "InvalidPattern(u'message')"

# Generated at 2022-06-21 21:54:59.726914
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile()"""
    # Install our own compile (should be no-op)
    install_lazy_compile()
    reset_compile()
    # Make sure it still works as normal
    pattern = r"""(?P<pattern1>[a-z]+)(?P<pattern2>[0-9]+)"""
    re.compile(pattern)
    reset_compile()
    re.compile(pattern)

# Generated at 2022-06-21 21:55:07.280113
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile"""
    lazyr = lazy_compile('\w+')
    if hasattr(lazyr, 'pattern'):
        raise AssertionError("LazyRegex should have no attributes yet")
    if id(lazyr) == id(lazyr):
        # All the attributes are on the _real_regex
        return
    if not hasattr(lazyr, 'pattern'):
        raise AssertionError("LazyRegex should have collapsed by now")



# Generated at 2022-06-21 21:55:15.573931
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern.

    This test case is meant to test the '_format' method of the
    InvalidPattern class.
    """
    pattern = u'a|(b)'
    err_msg = 'nothing matched'
    exc = InvalidPattern('"%s" %s' % (pattern, err_msg))
    exc._fmt = None

    # unicode string
    wanted = u'Invalid pattern(s) found. "a|(b)" nothing matched'
    got = unicode(exc)
    if got != wanted:
        raise AssertionError(
            "Expected '%s', but got '%s'" % (wanted, got))

    # ASCII string
    #
    # Note: we cannot compare 'got' and 'wanted' with "got == wanted"
    # because got

# Generated at 2022-06-21 21:55:19.352895
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Method __repr__ of class InvalidPattern must return error message.
    """
    assert repr(InvalidPattern('foo')) == "InvalidPattern('foo')"


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:55:23.324092
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() must return a unicode object."""
    e = InvalidPattern('foo')
    u = e.__unicode__()
    assert type(u) == unicode


# Generated at 2022-06-21 21:55:34.461974
# Unit test for function lazy_compile
def test_lazy_compile():
    """Ensure that the basic features of lazy_compile work"""
    # Create a proxy object
    proxy = lazy_compile('^a.*')
    # Now ensure that the underlying regex is not yet compiled
    assert proxy._real_regex is None
    # This should compile the regex
    assert proxy.match('a regex')
    # Now, the regex should be compiled
    assert proxy._real_regex is not None
    # And we should be able to call methods directly on the proxy.
    assert proxy.match('a regex')
    assert not proxy.match('not a regex')
    # And we should be able to store the proxy in a dict
    d = {}
    d['proxy'] = proxy
    assert d['proxy'].match('a regex')
    # And we should be able to hard link to the proxy, delete the
    # original

# Generated at 2022-06-21 21:55:36.580583
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    ex = InvalidPattern("MSG")
    assert str(ex) == "MSG"



# Generated at 2022-06-21 21:55:40.279119
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile()"""
    old_compile = re.compile
    try:
        re.compile = None
        reset_compile()
    finally:
        re.compile = old_compile


# Generated at 2022-06-21 21:55:42.723380
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """__str__ should work with a _fmt attribute"""
    InvalidPattern('foo')._fmt = 'message %(msg)s'


# Generated at 2022-06-21 21:55:59.244920
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    return doctest.DocTestSuite(re)


# Some libraries calls re.split which fails it if receives a LazyRegex.
if getattr(re, 'split', False):
    def split_public(pattern, string, maxsplit=0):
        if isinstance(pattern, LazyRegex):
            return pattern.split(string, maxsplit)
        else:
            return _real_re_compile(pattern).split(string, maxsplit)
    re.split = split_public


# Generated at 2022-06-21 21:56:08.852640
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """test_install_lazy_compile - make sure install_lazy_compile works"""

    # sanity check to make sure it is not already installed
    assert re.compile is not lazy_compile, \
        "re.compile is already set to lazy_compile"

    install_lazy_compile()
    assert re.compile is lazy_compile, \
        "re.compile is not lazy_compile"

    reset_compile()
    assert re.compile is not lazy_compile, \
        "re.compile is still lazy_compile"

# Generated at 2022-06-21 21:56:13.274379
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should always return a unicode string

    It is expected to be utf8 even if the formatted string is not a
    unicode string afterwards.
    """
    import bzrlib.i18n
    class MyInvalidPattern(InvalidPattern):
        _fmt = "A test"
    msg = MyInvalidPattern(msg="A test")
    assert isinstance(msg, InvalidPattern)
    assert isinstance(msg, bzrlib.i18n.Message)
    assert isinstance(unicode(msg), unicode), \
            "__unicode__ does not return a unicode string: %s" % type(unicode(msg))

# Generated at 2022-06-21 21:56:23.003344
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, it should compile it and then
    return the requested attribute.

    If the attribute is really missing, it will raise an AttributeError
    which we catch and transform as a re.error to check it's interpreted as
    an InvalidPattern.
    """
    r = LazyRegex()
    r._real_re_compile = unittest.mock.Mock()
    r._compile_and_collapse = unittest.mock.Mock()
    r._real_regex = unittest.mock.Mock()
    with unittest.TestCase.assertRaises(re.error) as cm:
        r.inquisition
    err = cm.exception

# Generated at 2022-06-21 21:56:30.510773
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Tests method __repr__ of class InvalidPattern"""
    try:
        class E(InvalidPattern):
            _fmt = "Message %(msg)s"
        err = E("")
        err.msg = "MSG"
        err.attr = "ATTR"
        raise err
    except InvalidPattern as e:
        assert repr(e) == 'E("MSG")'



# Generated at 2022-06-21 21:56:34.997721
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """check if method __getattr__ of the LazyRegex class return the correct attribute"""
    pattern = '([a-z])'
    lr = LazyRegex((pattern, 0))
    assert lr.__getattr__('pattern') == pattern


# Generated at 2022-06-21 21:56:39.418961
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__"""
    args = ['pattern', 'flags']
    kwargs = {'flags':re.I}
    lazy_regex = LazyRegex(args, kwargs)
    dict = {'args':args, 'kwargs':kwargs}
    lazy_regex.__setstate__(dict)

# Generated at 2022-06-21 21:56:46.553731
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Testing method __eq__ of class InvalidPattern.

    This test only checks the basic functionality: equality,
    inequality and TypeError when comparing with a non InvalidPattern
    object.
    """
    # Check equality
    equal_exceptions = [
        InvalidPattern('hello'),
        InvalidPattern('hello'),
        ]
    for exc in equal_exceptions:
        for other in equal_exceptions:
            if exc != other:
                raise AssertionError('exceptions %r and %r '
                                     'should be equal' % (exc, other))
            if not (exc == other):
                raise AssertionError('exceptions %r and %r '
                                     'should be equal' % (exc, other))

    # Check inequality
    exc1 = InvalidPattern('hello')
    exc2 = InvalidPattern('hello2')

# Generated at 2022-06-21 21:56:52.369369
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib.tests import TestCase
    from bzrlib.trace import mutter

    class TestFinditerPublic(TestCase):

        def test_finditer_public(self):
            def test_finditer_public():
                mutter('Testing "finditer_public"')
                from bzrlib.tests import TestCase
                from bzrlib.trace import mutter
                # Test for bug #434877 (re.finditer behaviour w/LazyRegex)
                mutter('Testing "finditer_public"')
                m = re.compile('t').finditer('this')
                self.assertFalse(isinstance(m, LazyRegex))
                m.next()
    #        try:
    #            m2 = re.finditer('t', 'this')
    #            m2.next