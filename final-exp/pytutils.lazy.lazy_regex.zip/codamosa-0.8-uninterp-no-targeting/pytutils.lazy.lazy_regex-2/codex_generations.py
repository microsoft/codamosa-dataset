

# Generated at 2022-06-21 21:47:06.551619
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test for the function install_lazy_compile."""
    reset_compile()
    install_lazy_compile()
    p = re.compile('foo')
    assert isinstance(p, LazyRegex)
    reset_compile()



# Generated at 2022-06-21 21:47:18.445530
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the method __setstate__ of class LazyRegex."""

    lazyregex = LazyRegex()
    dict = {"args": (), "kwargs": {"flags": re.M}}

    # Check that the dictionary type is correct.
    try:
        lazyregex.__setstate__(dict)
    except TypeError:
        raise AssertionError("Fail on unselected type of dictionary")

    # Check that the dictionary isn't empty.
    dict = {}
    try:
        lazyregex.__setstate__(dict)
    except KeyError:
        pass
    else:
        raise AssertionError(
            "Fail on dictionary which is empty\n" \
            "instead of raise an exception")

    # Check that the dictionary contains valid key.
    dict = {"args": (), "kwargs": {}}


# Generated at 2022-06-21 21:47:21.970423
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    class IP(InvalidPattern):
        _fmt = "foo %(msg)s bar %(msg)s baz"
    e1 = IP("x")
    e2 = IP("x")
    e3 = IP("y")
    assert e1 == e2
    assert not e1 == e3

# Generated at 2022-06-21 21:47:29.740509
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit testing for method __setstate__ of class LazyRegex"""
    compiled_re = re.compile("hello\n")

    # Create a LazyRegex object
    lazy_re = LazyRegex()

    # Pickle the real regex object with protocol 2 (which is the default)
    real_re_pickled_str = pickle.dumps(compiled_re)

    # Set the pickled state of the LazyRegex object with the pickled
    # state of the compiled real regex, and unpickle it
    lazy_re.__setstate__(pickle.loads(real_re_pickled_str))

    # Check that we have the same object
    assert compiled_re == lazy_re._real_regex



# Generated at 2022-06-21 21:47:33.772135
# Unit test for function reset_compile
def test_reset_compile():
    global _real_re_compile
    _real_re_compile = "foo"
    reset_compile()
    from bzrlib.tests import TestSkipped
    raise TestSkipped('passed')

# Generated at 2022-06-21 21:47:35.672533
# Unit test for function finditer_public
def test_finditer_public():
    import bzrlib.tests
    bzrlib.tests.SyntheticTests().test_finditer_public()

# Generated at 2022-06-21 21:47:45.109852
# Unit test for function lazy_compile
def test_lazy_compile():
    # This should compile a regex the first time it is used
    regex = lazy_compile('abc')
    assert regex._real_regex is None
    regex.search('abc')
    assert regex._real_regex is not None
    # Make sure we don't compile again
    regex.search('abc')
    regex.search('abc')
    regex.search('abc')
    assert regex._real_regex is not None
    # Make sure we can pickle
    import pickle
    pickle.loads(pickle.dumps(regex))
    # Make sure we get the exception we expect

# Generated at 2022-06-21 21:47:50.542275
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from unittest import main
    import doctest
    from doctest import DocFileSuite
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.i18n import _i18n_paths
    def load_tests(standard_tests, module, loader):
        if not _i18n_paths:
            # The gettext module is not being used.
            return standard_tests
        path = '../../../doc/developers/i18n.txt'
        doctest.NORMALIZE_WHITESPACE = True
        suite = DocFileSuite(path, module_relative=True,
                              optionflags=doctest.NORMALIZE_WHITESPACE)
        standard_tests.addTests(suite)
        return standard_tests

    TestCaseWithTransport

# Generated at 2022-06-21 21:47:54.220979
# Unit test for function finditer_public
def test_finditer_public():
    rc = re.compile('\d+')
    lr = LazyRegex(('\d+',))
    assert list(finditer_public(rc, '1234')) == [(0, 2), (2, 4)]
    assert list(finditer_public(lr, '1234')) == [(0, 2), (2, 4)]
    assert list(finditer_public('\d+', '1234')) == [(0, 2), (2, 4)]

# Generated at 2022-06-21 21:48:05.246938
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return state for recompiling, not regex

    If you save the pickled state of a LazyRegex, it should not have
    the regex precompiled. Otherwise, we will end up recompiling a regex
    every time we load it out of the cache. (e.g. for rio.search_windows)
    """
    myregex = LazyRegex(args=('foo',), kwargs={})
    # compile the regex
    myregex.match('foo')
    # save the pickled state
    state = myregex.__getstate__()
    # check that it hasn't saved the underlying regex as part of the state
    # and that it has saved the original args to re.compile
    assert state["args"] == ('foo',)
    assert state["kwargs"] == {}

# Generated at 2022-06-21 21:48:16.495424
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex"""
    import cPickle
    regex = LazyRegex('^Bazaar revision control system version (?P<ver>[\d\.]+)$', re.M)
    regex2 = cPickle.loads(cPickle.dumps(regex))
    regex2._compile_and_collapse()
    # Bazaar is known to match the regex
    # so we expect (1, None)
    # if the regex was compiled
    assert regex2.match('Bazaar revision control system version 1.19')

# Generated at 2022-06-21 21:48:28.443200
# Unit test for function lazy_compile
def test_lazy_compile():
    """Check that lazy_compile behaves as documented."""
    # This is a bit tricky as we're overriding the global re.compile.
    # We have to make sure that each test is isolated and doesn't rely on
    # the state of the regex module or the regex module dependencies.

    # We could just use a local compile function for testing, but this
    # wouldn't give us the full test coverage.
    from bzrlib.tests import TestCase
    from bzrlib.osutils import (
        pathjoin,
        )

    lazy_compile("foo")
    class TestLazyRegex(TestCase):

        def setUp(self):
            super(TestLazyRegex, self).setUp()
            # We want to test the state of the re module as it is when
            # we start our tests. We can't do this

# Generated at 2022-06-21 21:48:33.475818
# Unit test for function lazy_compile
def test_lazy_compile():
    from bzrlib import tests
    # We don't actually use this test case, it is just here as a reference to
    # the exact testing semantics used.
    class TestCase(tests.TestCase):

        def _test_compile(self, pattern, args, kwargs, expected_regex):
            self.run_twice(lambda: self.assertEqual(
                    expected_regex, re.compile(pattern, *args, **kwargs)))

        def _test_search(self, regex, haystack, expected_result):
            self.run_twice(lambda: self.assertEqual(
                    expected_result, regex.search(haystack)))

        def run_twice(self, function):
            """Call function twice, to ensure it works if pre-compiled"""
            function()
            function()

   

# Generated at 2022-06-21 21:48:39.001537
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import re
    global _real_re_compile

    _real_re_compile = re.compile
    re.compile = lazy_compile

    try:
        re.compile('foo')
    except:
        raise AssertionError('LazyRegex constructor must not fail.')
    finally:
        re.compile = _real_re_compile

# Generated at 2022-06-21 21:48:43.349473
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should pass the attribute onto the real regex"""
    lr = LazyRegex(('a',))
    lr._compile_and_collapse()
    rr = lr._real_regex
    rr.attr = 42
    assert lr.attr == 42

# Generated at 2022-06-21 21:48:46.180998
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    s = str(InvalidPattern(u'foo'))
    assert isinstance(s, str)


# Generated at 2022-06-21 21:48:52.132142
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex

    This test ensures that the method __setstate__ of LazyRegex can be called
    without errors.
    """
    args = ['\s+', 0]
    kwargs = {'flags': 0}
    lazy_regex = LazyRegex(args, kwargs)
    state = lazy_regex.__getstate__()
    lazy_regex.__setstate__(state)

# Generated at 2022-06-21 21:49:00.830585
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # A new class inherits InvalidPattern
    class DerivedException(InvalidPattern):
        _fmt = 'DerivedException: %(msg)s'
    # test InvalidPattern
    first = InvalidPattern('First')
    second = InvalidPattern('Second')
    assert first != second
    assert first == first
    # test DerivedException
    assert DerivedException('Third') == DerivedException('Third')
    assert DerivedException('Fourth') != DerivedException('Fifth')
    assert InvalidPattern('Sixth') != DerivedException('Seventh')

# Generated at 2022-06-21 21:49:14.649993
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ must return a unicode object."""
    import bzrlib.tests
    from bzrlib.i18n import gettext

    # The message for this exception is translated
    e = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    e.msg = 'This is the error message'
    fmt = e._get_format_string()
    assert type(fmt) == str
    assert fmt == gettext('Invalid pattern(s) found. %(msg)s')
    assert type(unicode(e)) == unicode

    # The message for this exception is not translated
    e = InvalidPattern('This exception is not translated')
    assert type(e.msg) == str
    assert e.msg == 'This exception is not translated'

# Generated at 2022-06-21 21:49:27.958238
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    real_compile = re.compile

# Generated at 2022-06-21 21:49:34.878279
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-21 21:49:43.925987
# Unit test for function finditer_public
def test_finditer_public():
    """Unit tests for function LazyRegex.finditer()."""
    # We do not want to test the behaviour of re.finditer
    # as we did not change it.
    # So we change its behaviour to return the same as LazyRegex.finditer()
    # for any pattern (not only for LazyRegex).
    original_finditer = re.finditer
    re.finditer = lambda pattern, string, flags=0, unused=None: \
        _real_re_compile(pattern, flags).finditer(string)

    def t(expected, pattern, string, flags=0):
        """Helper to test the behaviour of finditer()."""
        got = _real_re_compile(pattern, flags).finditer(string)

# Generated at 2022-06-21 21:49:53.252326
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unpickling of a LazyRegex."""
    import cPickle
    lr = LazyRegex(["^abc$"])
    lr.abc = "def" # test that a missing value is set
    lr.findall("abc") # compile the regex
    lr2 = cPickle.loads(cPickle.dumps(lr))
    # if pickle/unpickle has not worked correctly, one of the following will
    # fail because the regex has not been compiled.
    lr2.findall("abc")
    lr2.abc

# Generated at 2022-06-21 21:49:59.771163
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__() should restore *args and **kwargs from
    dict as given to LazyRegex.__init__().
    """
    args = ('.*', 0)
    kwargs = {'flags': re.MULTILINE}
    lr = LazyRegex(args, kwargs)
    lr.__setstate__(lr.__getstate__())
    assert((lr._regex_args, lr._regex_kwargs)
        ==(args, kwargs),
        "args and kwargs should be the same from __init__ and "
        "__setstate__. %s" % lr)

# Generated at 2022-06-21 21:50:07.491512
# Unit test for function finditer_public
def test_finditer_public():
    """Check that finditer_public proxies properly to a real regex"""
    assert isinstance(re.finditer("foo", "foo"),
                      re._pattern_type)
    assert isinstance(re.finditer("bar", "foo"),
                      re._pattern_type)

# Some libraries calls re.search which fails it if receives a LazyRegex.
if getattr(re, 'search', False):
    def search_public(pattern, string, flags=0):
        if isinstance(pattern, LazyRegex):
            return pattern.search(string)
        else:
            return _real_re_compile(pattern, flags).search(string)
    re.search = search_public


# Generated at 2022-06-21 21:50:15.335436
# Unit test for function finditer_public
def test_finditer_public():
    """Test the finditer_public function.
    """
    test_string = 'abc123'
    pattern = '\d'
    reg = lazy_compile(pattern)

    # tests that a LazyRegex is passed to finditer
    assert re.finditer(reg, test_string).next().group(0) == "1"

    # tests that an _sre.SRE_Pattern is passed to finditer
    assert re.finditer(pattern, test_string).next().group(0) == "1"

# Generated at 2022-06-21 21:50:17.076155
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    err = InvalidPattern('')
    assert err.__str__() == err.__unicode__()



# Generated at 2022-06-21 21:50:30.064440
# Unit test for function lazy_compile
def test_lazy_compile():
    """Install lazy_compile as the default compile mode.

    This allows us to unit test the lazy_compile function.
    """
    install_lazy_compile()

# Generated at 2022-06-21 21:50:36.393285
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test the method __eq__ of class InvalidPattern.

    This test make sure that two InvalidPatterns are equal if they have
    the same attributes.
    """
    error_a = InvalidPattern('msg')
    error_b = InvalidPattern('msg')
    error_c = InvalidPattern('other msg')

    assert error_a == error_b
    assert not error_a == error_c
    assert not error_a == 'msg'

# Generated at 2022-06-21 21:50:44.878231
# Unit test for function reset_compile
def test_reset_compile():
    global _real_re_compile
    import re
    pattern = 'test'
    re.compile(pattern)
    try:
        orig_compile = re.compile
        install_lazy_compile()
        re.compile = _real_re_compile
        re.compile(pattern)
        reset_compile()
        re.compile(pattern)
    finally:
        reset_compile()
        re.compile(pattern)



# Generated at 2022-06-21 21:51:02.945084
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    class Class_regex_match:
        def match(self, string, pos=0, endpos=65535):
            return None

    obj_regex_match = Class_regex_match()

    def _real_re_compile(*args, **kwargs):
        return obj_regex_match

    _real_re_compile_backup = re._real_re_compile
    re._real_re_compile = _real_re_compile

    pattern = LazyRegex((u'pattern',))

    # Test that the proxy object forwards the call to the real object.
    result = pattern.match()
    assert result is None

    re._real_re_compile = _real_re_compile_backup

# Generated at 2022-06-21 21:51:09.393593
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """We should be able to use repr() to get the pattern in a way
    such that we can re-create the object.
    """
    pattern = '*'
    msg = "Invalid pattern"
    ip = InvalidPattern(msg)
    # ensure the repr is valid
    eval(repr(ip))

test_suite = TestSuite()
test_suite.addTest(make_doctest_suite(__name__))
test_suite.addTest(test_InvalidPattern___repr__)

# Generated at 2022-06-21 21:51:20.448815
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that installing lazy_compile actually overrides re.compile properly

    Compilation should be deferred, but other attributes should work.
    """
    install_lazy_compile()
    # We can't check if the original compile has been overridden as we would
    # get an infinite recursion error

# Generated at 2022-06-21 21:51:22.527345
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-21 21:51:31.857781
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib.i18n import gettext
    e = InvalidPattern('foo')
    gettext(u'foo')
    str(e)
    repr(e)
    # repr() should not fail
    repr(InvalidPattern(('a', 'b', 1, 2)))
    # escape non-ascii character
    try:
        InvalidPattern(u'A\u0394B')
    except UnicodeDecodeError as e:
        pass
    else:
        raise AssertionError("UnicodeDecodeError not raised")
    InvalidPattern(u'A\u0394B'.encode('utf8'))
    # InvalidPattern should not raise any error when formatting
    # the error message.
    e = InvalidPattern(u'foo')
    str(e)

# Generated at 2022-06-21 21:51:40.330673
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__"""
    p = LazyRegex(('[0-9]+',))
    assert p.pattern == '[0-9]+'
    # We do not check that p._real_regex is not None because we do not want
    # to couple too much the implementation to our tests. It is OK if the
    # implementation change, as long as the test remain valid.


# Generated at 2022-06-21 21:51:46.213525
# Unit test for function reset_compile
def test_reset_compile():
    """Ensure that reset_compile() actually resets compile()"""
    install_lazy_compile()
    reset_compile()
    re.compile = lazy_compile
    reset_compile()
    re.compile = lazy_compile
    reset_compile()

# Generated at 2022-06-21 21:51:54.534246
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib import i18n
    # sanity check
    if gettext("Invalid pattern(s) found. %(msg)s") != _("Invalid pattern(s) found. %(msg)s"):
        raise AssertionError("translation of _fmt failed")
    msg = "test message"
    ip = InvalidPattern(msg)
    ip_str = str(ip)
    # ip_str must be ascii string
    # first check is to make sure that the messages are translated

# Generated at 2022-06-21 21:52:02.905538
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext, lazy_gettext
    from bzrlib.lazy_regex import InvalidPattern

    class TestInvalidPattern(InvalidPattern):
        _fmt = lazy_gettext("Invalid pattern: %(msg)s")
    e = TestInvalidPattern("test")
    assert str(e) == "Invalid pattern: test"
    setattr(e, '_preformatted_string', 'test')
    assert str(e) == "test"
    assert repr(e) == "TestInvalidPattern('test')"

# Generated at 2022-06-21 21:52:09.177182
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test whether LazyRegex.__getstate__() returns a valid state

    This is a regression test for bug #583928.
    """
    pattern = LazyRegex()
    assert pattern.__getstate__() == {
        'args': (),
        'kwargs': {}
    }


# Generated at 2022-06-21 21:52:43.877889
# Unit test for function lazy_compile
def test_lazy_compile():
    """Unit tests for function lazy_compile"""
    install_lazy_compile()

# Generated at 2022-06-21 21:52:56.312922
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    def assert_repr(expected, instance):
        """helper function to test repr on an InvalidPattern instance"""
        result = repr(instance)
        if expected != repr(instance):
            raise AssertionError(
                "repr of instance %r not as expected (got %r)" %
                (instance, result))
    assert_repr("InvalidPattern('')", InvalidPattern(''))
    assert_repr("InvalidPattern('foo')", InvalidPattern('foo'))
    assert_repr("InvalidPattern('bar')", InvalidPattern(u'bar'))
    assert_repr("InvalidPattern(u'\\xe9')", InvalidPattern(u'\xe9'))
    assert_repr("InvalidPattern('\\xc3\\xa9')", InvalidPattern('\xc3\xa9'))

# Generated at 2022-06-21 21:53:06.253922
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from unittest import TestCase
    from testtools.matchers import Equals
    from testtools.matchers._common import type_mismatch

    class Test(TestCase):
        def test_invalid_pattern_equal(self):
            error1 = InvalidPattern('A')
            error2 = InvalidPattern('A')
            error3 = InvalidPattern('B')
            self.assertThat(error1, Equals(error2))
            self.assertThat(error1, Equals(error1))
            self.assertThat(error3, Equals(error3))
            self.assertThat(error1, type_mismatch(error3))
    return Test

# Generated at 2022-06-21 21:53:13.336245
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    regex = re.compile('spam')
    assert isinstance(regex, LazyRegex)
    assert regex._regex_args == ('spam',)
    assert regex._regex_kwargs == {}
    assert regex.match('spam') is not None
    reset_compile()
    regex = re.compile('spam')
    assert isinstance(regex, re._compile.__class__)


# Generated at 2022-06-21 21:53:19.163923
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    class InvalidPatternSubclass(InvalidPattern):
        pass
    assert InvalidPattern("text") == InvalidPattern("text")
    assert not InvalidPattern("text") == InvalidPattern("text2")
    assert InvalidPattern("text") != InvalidPattern("text2")
    assert InvalidPattern("text") != InvalidPatternSubclass("text")
    assert InvalidPatternSubclass("text") != InvalidPattern("text")

# Generated at 2022-06-21 21:53:29.108261
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    proxy = lazy_compile('123')
    assert proxy._regex_args == ('123',)
    assert proxy._regex_kwargs == {}
    proxy = lazy_compile('123', 4)
    assert proxy._regex_args == ('123',)
    assert proxy._regex_kwargs == {'flags': 4}
    proxy = lazy_compile('123', 4, 5)
    assert proxy._regex_kwargs == {}
    assert proxy._regex_args == ('123', 4, 5)
    proxy = lazy_compile('123', 4, 5, kwarg=6)
    assert proxy._regex_kwargs == {'kwarg': 6}
    assert proxy._regex_args == ('123', 4, 5)


# Generated at 2022-06-21 21:53:36.315015
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that attributes of LazyRegex are retrieved from the compiled regex
    """
    # Setup
    patt = lazy_compile("pattern")
    patt._real_regex = mock.Mock(_sre.SRE_Pattern)
    # Test
    patt.__getattr__("match")
    # Verify
    patt._real_regex.__getattr__.assert_called_with("match")

# Generated at 2022-06-21 21:53:38.189756
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-21 21:53:47.946298
# Unit test for function lazy_compile
def test_lazy_compile():
    """Unit test for function lazy_compile"""
    # A dummy error class used to check that the error from re.compile is
    # converted to an InvalidPattern
    class DummyError(Exception):
        pass
    # A dummy class used to check that the real re.compile is called
    class Compiled:
        pass
    # Re-implement re.compile to throw an exception only if the regex is
    # r'(', and to return a dummy object otherwise.
    def dummy_re_compile(regex, flags=0):
        if regex == r'(':
            raise DummyError
        return Compiled()
    # Override re.compile with our dummy function
    _real_re_compile = re.compile
    re.compile = dummy_re_compile

    # Create a LazyRegex

# Generated at 2022-06-21 21:53:55.057311
# Unit test for function finditer_public
def test_finditer_public():
    """Test function finditer_public"""
    import re
    test_pattern = "^(?P<one>\\d*).*(?P<two>\\w+)"
    test_string = "0123456789abcdefghij"
    test_re = re.finditer(test_pattern, test_string)
    test_iter = test_re.next()
    test_dict = test_iter.groupdict()
    test_dict_value = {'one': '0123456789', 'two': 'abcdefghij'}
    if test_dict != test_dict_value:
        raise AssertionError("Got a dict that is different than expected: %s" % test_dict)

# Generated at 2022-06-21 21:54:24.163465
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """This test is here to make sure that the LazyRegex object returned by
    this module can be marshalled and unmarshalled.

    This is important because the LazyRegex objects are returned as
    attributes of LazyPattern objects.
    """
    # We need to create a LazyRegex outside of the scope of this function
    # so that the function scope's locals variables do not override
    # its attributes.
    lazy_regex = lazy_compile('foo')
    from bzrlib import tests
    tests.TestCaseWithTransport.assertEqual(
        'foo', lazy_regex._regex_args[0])
    # test __getstate__
    state = lazy_regex.__getstate__()

# Generated at 2022-06-21 21:54:32.738802
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore the state of a LazyRegex"""

    def create_lazy_regex():
        lazy_regex = LazyRegex(('abc',), {})
        lazy_regex._compile_and_collapse()
        return lazy_regex

    # test with _real_regex unset
    lazy_regex = create_lazy_regex()
    del lazy_regex._real_regex
    assert lazy_regex._real_regex is None
    lazy_regex.match('abc')
    assert lazy_regex._real_regex is not None

    # test with _real_regex set
    lazy_regex = create_lazy_regex()
    assert lazy_regex._real_regex is not None
    lazy_regex.match('abc')

# Generated at 2022-06-21 21:54:38.156060
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests import TestCaseInTempDir
    class TestInvalidPattern_repr(TestCaseInTempDir):
        def test_InvalidPattern___repr__(self):
            e = InvalidPattern(u'pattern')
            self.assertEqual(repr(e), "InvalidPattern('pattern')")

# Generated at 2022-06-21 21:54:40.518876
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should not raise an exception"""
    InvalidPattern("something").__repr__()

# Generated at 2022-06-21 21:54:47.672858
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test LazyRegex.__setstate__ method"""
    sample_args = (r'foo',)
    sample_kwargs = {'bar': 1}
    sample_state = {'args': sample_args,
                    'kwargs': sample_kwargs}
    lazyreg = LazyRegex()
    lazyreg.__setstate__(sample_state)
    assert lazyreg._real_regex == None
    assert lazyreg._regex_args == sample_args
    assert lazyreg._regex_kwargs == sample_kwargs


# Generated at 2022-06-21 21:54:56.876943
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ of LazyRegex class.

    See http://bazaar-vcs.org/BzrDeveloperGuidelines/LazyRegex.
    """
    import cPickle
    import re

    def _test(obj1, obj2):
        state1 = obj1.__getstate__()
        # check that obj1 can be pickled
        cPickle.dumps(obj1)
        # check that obj1 and obj2 have same getstate
        state2 = obj2.__getstate__()
        if state1 != state2:
            return False
        # check that obj1 and obj2 can be pickled
        cPickle.dumps(obj2)
        return True

    # 1. test default state
    obj = LazyRegex()

# Generated at 2022-06-21 21:55:09.145350
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    import bzrlib.tests
    bzrlib.tests.TestCaseWithMemoryTransport.install_builtin_transport(
        'file:///')
    class TestCase(bzrlib.tests.TestCase):

        def test_InvalidPattern___str__(self):
            # _fmt is not defined
            s = str(InvalidPattern('a'))
            self.assertEqualDiff(
                'Unprintable exception InvalidPattern: dict={\'msg\': \'a\'}, '
                'fmt=None, error=None', s)
            # _fmt is defined
            class InvalidPattern2(InvalidPattern):
                _fmt = ('%(msg)s')
            s = str(InvalidPattern2('a'))
            self.assertE

# Generated at 2022-06-21 21:55:12.557597
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    msg = 'Invalid pattern(s) found. %(msg)s'
    e = InvalidPattern(msg)
    assert e._get_format_string() == gettext(u'Invalid pattern(s) found. %(msg)s')

# Generated at 2022-06-21 21:55:19.398889
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test InvalidPattern constructor"""
    invalid_pattern = InvalidPattern("test")
    if str(invalid_pattern) != "Invalid pattern(s) found. test":
        raise AssertionError("InvalidPattern str() not implemented correctly")
    if repr(invalid_pattern) != """InvalidPattern('test')""":
        raise AssertionError("InvalidPattern repr() not implemented correctly")
    if invalid_pattern.msg != "test":
        raise AssertionError("InvalidPattern msg not implemented correctly")



# Generated at 2022-06-21 21:55:28.113603
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ returns correct attribute

    If a LazyRegex is passed to a function that expects a
    real Regex it may attempt to access an attribute on
    the LazyRegex. For this case to work we need to make
    sure that the attribute can be accessed via __getattr__
    """
    la = LazyRegex()
    assert la.pattern == ''


# So that we only ever have one copy of this object around, we create it here
# and export it to the root namespace.
_dot_regex = lazy_compile('.')



# Generated at 2022-06-21 21:55:58.682711
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should return the evaluated property."""
    # create a test pattern:
    test_string = 'banana'
    test_regex = LazyRegex((test_string,))
    # the property pattern has not been evaluated yet:
    assert test_regex._real_regex is None
    # the property 'pattern' should be the evaluated test string:
    assert test_regex.pattern == test_string
    # now the property _real_regex has been evaluated:
    assert test_regex._real_regex is not None
    # we can access the property _real_regex now:
    assert test_regex._real_regex.pattern == test_string
    # but even if we delete it we can still access it:
    del test_regex._real_regex
   

# Generated at 2022-06-21 21:56:04.090962
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should work on InvalidPattern objects."""
    y = InvalidPattern('%(msg)s')
    y.msg = '123'
    z = InvalidPattern('%(msg)s')
    z.msg = '123'
    assert y == z
    assert not (y != z)
    assert not (y == None)
    assert y != None
    assert not (y == 'abc')
    assert y != 'abc'
    y.msg = 'abc'
    assert not (y == z)
    assert y != z
    assert y != None
    assert not (y == None)
    assert y != 'abc'
    assert not (y == 'abc')

# Generated at 2022-06-21 21:56:08.493512
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lr = LazyRegex()
    lr.__setstate__({"args": (r"",), "kwargs": {}})
    lr.__setstate__({"args": (r"", 0), "kwargs": {}})

# Generated at 2022-06-21 21:56:15.418625
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Calling InvalidPattern.__eq__ raises a TypeError if the comparison
    object is not of type InvalidPattern.
    """
    import bzrlib.testament
    import doctest
    note = doctest.NORMALIZE_WHITESPACE
    return bzrlib.testament.Testament().groups['blackbox'].doctest_suite(
        'bzrlib.regex._lazy_re.InvalidPattern.__eq__', optionflags=note)

# Generated at 2022-06-21 21:56:23.947634
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() restores the original re.compile()

    This test has to be in this module because it needs to import the actual
    re module, not the local wrapper.
    """
    import re
    orig_compile = re.compile
    try:
        # Make sure re.compile() is not currently wrapped
        re.compile = re._real_re_compile
        # Now, install our wrapper.
        re.compile = lazy_compile
        # We should now have a wrapper
        assert re.compile is not re._real_re_compile
        # Now reset it back
        re.reset_compile()
        assert re.compile is re._real_re_compile
    finally:
        re.compile = orig_compile



# Generated at 2022-06-21 21:56:26.096911
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Unit test for constructor of class InvalidPattern"""
    e = InvalidPattern('test')
    assert str(e) == 'test'


# Generated at 2022-06-21 21:56:30.772206
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ of InvalidPattern must return str"""
    try:
        raise InvalidPattern("test_InvalidPattern___repr__")
    except InvalidPattern as exc:
        assert(isinstance(str(exc), str))

# Generated at 2022-06-21 21:56:33.137662
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 21:56:35.869688
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    msg = 'regular expression pattern could not be compiled'
    i1 = InvalidPattern(msg)
    i2 = InvalidPattern(msg)
    assert i1 == i2

# Generated at 2022-06-21 21:56:44.421243
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test lazy-compile by compiling a valid and an invalid pattern."""
    from . import tests
    reinstall_recompile_flag = tests.reinstall_recompile_flag
    try:
        tests.reinstall_recompile_flag = False

        reset_compile()
        install_lazy_compile()
        regex = re.compile("foobar")
        regex = regex.compile("foobar")
        # This should not raise re.error
        try:
            regex = re.compile("(foobar")
            regex.search('foobar')
        except InvalidPattern:
            pass
        else:
            raise AssertionError(
                "Regex compilation with a bad pattern should raise "
                "InvalidPattern")
    finally:
        tests.reinstall_recompile_flag = reinstall_