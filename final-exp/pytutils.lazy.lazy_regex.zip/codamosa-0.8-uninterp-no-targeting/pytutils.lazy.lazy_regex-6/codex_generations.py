

# Generated at 2022-06-21 21:47:10.686905
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Check that we can override re.compile with lazy_compile.

    This also checks that nested calls to install_lazy_compile
    will still restore the correct original behaviour.
    """
    install_lazy_compile()
    # Force a recompile to check that the override takes effect
    re.compile('foo')
    reset_compile()
    # And again
    re.compile('foo')
    reset_compile()

    # Now check that we can override again
    install_lazy_compile()
    # Force a recompile to check that the override takes effect
    re.compile('foo')
    reset_compile()
    # And again
    re.compile('foo')
    reset_compile()

# Generated at 2022-06-21 21:47:16.028242
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    import doctest
    from bzrlib.errors import InvalidPattern
    # the docstring below must start with the following line (it is checked
    # by the offical python doctest module)
    # >>> from bzrlib.errors import InvalidPattern
    return doctest.DocTestSuite(InvalidPattern)

# Generated at 2022-06-21 21:47:26.147446
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import symbol_versioning
    try:
        import bzrlib.tests
    except ImportError:
        symbol_versioning.warn('bzrlib.tests not found')
    import doctest
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.errors import (
        NoTwoVcsParents,
        UncommittedChanges,
        )
    from bzrlib.tests import (
        multiply_tests,
        test_suite,
        )


    doctest.OutputChecker.check_output = \
        lambda self, want, got, optionflags: want in got

    def load_tests(loader, standard_tests, pattern):
        suite = loader.suiteClass()
        suite.addTests(standard_tests)

# Generated at 2022-06-21 21:47:34.571340
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    if isinstance(InvalidPattern('msg'), re.error):
        raise AssertionError('InvalidPattern instance must not be a '
                             're.error instance')
    if InvalidPattern('msg') == InvalidPattern('msg2'):
        raise AssertionError('InvalidPattern instances with different '
                             'messages must not be equal')
    if InvalidPattern('msg') != InvalidPattern('msg'):
        raise AssertionError('InvalidPattern instances with same message '
                             'must be equal')

# Generated at 2022-06-21 21:47:41.938685
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    ip = InvalidPattern(msg="Some message")
    # check repr
    repr(ip)
    # check str
    str(ip)
    # check unicode
    unicode(ip)
    ip = InvalidPattern(_("Invalid pattern(s) found. %(msg)s"))
    # check repr
    repr(ip)
    # check str
    str(ip)
    # check unicode
    unicode(ip)

# Generated at 2022-06-21 21:47:53.642094
# Unit test for function lazy_compile
def test_lazy_compile():
    import bzrlib.tests
    re.compile('a')
    import gc
    gc.collect() # clean up dangling references to _sre.so
    re.compile = _real_re_compile
    class TestLazyCompile(bzrlib.tests.TestCase):
        def test_compile(self):
            import gc
            re.compile = _real_re_compile
            self.assertNotEqual(_real_re_compile, lazy_compile)
            re.compile = lazy_compile
            self.assertEqual(re.compile, lazy_compile)
            r = re.compile("a")
            self.assertEqual(lazy_compile, re.compile)
            self.assertIsInstance(r, LazyRegex)
           

# Generated at 2022-06-21 21:48:00.310239
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() must returns a unicode object by default.

    __str__() should return a unicode object by default.
    """

    class Ugly(InvalidPattern):
        _fmt = 'Test'

    e = Ugly('test message')
    str_object = str(e)
    # We must test the type of str_object because the default implementation
    # of __str__() for InvalidPattern class always returns a 'str' object
    # and we have overridden it to return a 'unicode' object.
    try:
        unicode(str_object)
    except UnicodeDecodeError:
        raise AssertionError('__str__() must returns a unicode object by '
                             'default')

# Generated at 2022-06-21 21:48:12.037435
# Unit test for function finditer_public
def test_finditer_public():
    # a regex without re.MULTILINE flag
    pattern = lazy_compile('aaa')
    test_string = 'abaaba'
    expect = re.finditer(pattern, test_string)
    result = finditer_public(pattern, test_string)
    assert len(list(expect)) == len(list(result))
    # a regex with re.MULTILINE flag
    pattern = lazy_compile('aaa', re.MULTILINE)
    test_string = 'abaaba'
    expect = re.finditer(pattern, test_string)
    result = finditer_public(pattern, test_string)
    assert len(list(expect)) == len(list(result))


if __name__ == '__main__':
    # Run all of the function test_*() in this module
    import sys

# Generated at 2022-06-21 21:48:18.084455
# Unit test for function lazy_compile
def test_lazy_compile():
    import bzrlib.tests
    test_suite = bzrlib.tests.TestUtil.load_tests_from_module(
        bzrlib.regex, 'lazyregex.test_lazyregex')
    return test_suite

# Generated at 2022-06-21 21:48:30.709607
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy regex compilation"""

    re.escape = lambda x: x
    install_lazy_compile()

# Generated at 2022-06-21 21:48:36.362001
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    assert LazyRegex()



# Generated at 2022-06-21 21:48:44.287502
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests import TestCase
    a = r'a'
    b = re.compile(a)
    self.assertIsInstance(b, LazyRegex)
    self.assertEqual(b.pattern, a)
    self.assertEqual(b.match(a), re.match(a, a))
    install_lazy_compile()
    c = re.compile(a)
    self.assertIsInstance(c, LazyRegex)
    self.assertEqual(c.pattern, a)
    self.assertEqual(c.match(a), re.match(a, a))
    reset_compile()
    d = re.compile(a)
    self.assertNotIsInstance(d, LazyRegex)

# Generated at 2022-06-21 21:48:49.580296
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern should return a unicode object.
    """
    ip = InvalidPattern("test unicode")
    if not isinstance(ip.__unicode__(), unicode):
        raise AssertionError("InvalidPattern.__unicode__ should return a "
            "unicode object.")


# Generated at 2022-06-21 21:48:55.201812
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that the constructor LazyRegex works."""
    a = LazyRegex(["[a-z]"], {})
    # a shall be of type LazyRegex
    assert(type(a) is LazyRegex)



# Generated at 2022-06-21 21:49:04.563887
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore LazyRegex state from dictionary"""
    from bzrlib.tests import TestCase

    args = "pattern1", "pattern2"
    kwargs = {"flag1": True, "flag2": False}
    state = {
        "args": args,
        "kwargs": kwargs,
        }

    proxy = LazyRegex()
    proxy.__setstate__(state)
    self.assertIs(proxy._real_regex, None)
    self.assertEqual(proxy._regex_args, args)
    self.assertEqual(proxy._regex_kwargs, kwargs)



# Generated at 2022-06-21 21:49:07.243614
# Unit test for function lazy_compile
def test_lazy_compile():
    lazy_regex = lazy_compile("[0-9]+")
    assert lazy_regex._real_regex is None
    assert repr(lazy_regex) == "<LazyRegex [0-9]+>"



# Generated at 2022-06-21 21:49:12.568771
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # create two InvalidPattern object
    first = InvalidPattern('error message')
    second = InvalidPattern('error message')
    # their representaion (str) are the same, thus they are identical
    # and __eq__ should return True
    assert first == second



# Generated at 2022-06-21 21:49:20.423961
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() raises UnicodeDecodeError when _fmt
    contains an invalid utf8 string.
    """
    error = InvalidPattern('\x80')
    # The following will raise the error if __unicode__() is not defined.
    unicode(error)
    # The following will raise the error if __unicode__() is badly implemented
    # and contains a decoding error in the following line:
    #     return gettext(unicode(fmt))
    str(error)

#TODO: move this somewhere sane, this is not great.

# Generated at 2022-06-21 21:49:29.547906
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Method __setstate__ must reset an object to the state given by a
    previous invocation of method __getstate__"""
    lr1 = LazyRegex(("a*b",), {"flags": 1})
    # compile lr1
    lr1.match("aaab")
    lr1_state = lr1.__getstate__()
    lr2 = LazyRegex()
    lr2.__setstate__(lr1_state)
    # lr2 must not be compiled yet
    assert lr2._real_regex is None
    # lr2 must be equal to lr1
    lr2.match("aaab")
    assert lr2._real_regex is not None
    assert lr1._real_regex is not None
    assert lr1._real_regex

# Generated at 2022-06-21 21:49:37.270883
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    a = LazyRegex(('a',))
    b = pickle.loads(pickle.dumps(a))
    a_args, a_kwargs = a._regex_args, a._regex_kwargs
    b_args, b_kwargs = b._regex_args, b._regex_kwargs
    assert (a_args == b_args) and (a_kwargs == b_kwargs)

# Generated at 2022-06-21 21:49:46.865867
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test if the method __str__ of class InvalidPattern, return string in
    unicode now, and not a unicode object.
    """
    message = InvalidPattern('test')
    assert isinstance(message.__str__(), str)

# Generated at 2022-06-21 21:49:58.720174
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__() should return a dictionary.  This
    dictionary should have two items: "args" and "kwargs".  Each of
    these should be the same as what was passed to the constructor for
    this object."""
    cases = [
        ((), {}, {'args': (), 'kwargs': {}}),
        (('foo',), {}, {'args': ('foo',), 'kwargs': {}}),
        ((), {'bar': 'baz'}, {'args': (), 'kwargs': {'bar': 'baz'}}),
        (('foo',), {'bar': 'baz'}, {'args': ('foo',), 'kwargs': {'bar': 'baz'}}),
        ]
    for args, kwargs, state in cases:
        regex = LazyRe

# Generated at 2022-06-21 21:50:10.698951
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib import _i18n

    # set up the translation function
    gettext("Invalid pattern: %(msg)s")
    gettext("Unprintable exception InvalidPattern: dict=%(dict)s, fmt=%(fmt)s, error=%(error)s")
    gettext("Invalid pattern(s) found")

    # make sure the method __str__ works
    eng_dict = {'msg': 'Error test'}
    eng_error = InvalidPattern('Error test')
    eng_file = _i18n.prepare_string_file(eng_dict, eng_error)
    eng_unprintable_err = eng_file.readline()


# Generated at 2022-06-21 21:50:17.206361
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class bzrlib.lazy_regex.InvalidPattern"""
    try:
        raise InvalidPattern('re.error: bad character in group name')
    except InvalidPattern as e:
        s = str(e)
        assert s == 'Invalid pattern(s) found. "re.error: bad character in group name"'
        u = unicode(e)
        assert u == s, (s.encode('utf8'), u.encode('utf8'))

# Generated at 2022-06-21 21:50:20.077899
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    p = InvalidPattern(msg='test message')
    assert str(p) == 'test message', 'test failed'

# Generated at 2022-06-21 21:50:23.931926
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    obj = LazyRegex(('test',))
    obj.__setstate__({'args': ('test2',), 'kwargs': {}})
    obj.match('test')


# Generated at 2022-06-21 21:50:33.779406
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from sets import Set

    msg1 = 'message one'
    msg2 = 'message two'
    ip1 = InvalidPattern(msg1)
    ip2 = InvalidPattern(msg2)
    ip1_copy = InvalidPattern(msg1)
    class SubException(InvalidPattern):
        pass
    subex = SubException(msg1)

    assert ip1 == ip1_copy
    assert not ip1 == ip2
    assert not ip1 == subex
    assert not ip1 == msg1

    # test set membership
    assert ip1 in Set((ip1, ip1_copy))
    assert ip1 not in Set((ip2, subex, msg1))

# Generated at 2022-06-21 21:50:40.058682
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import os
    import sys
    if sys.version_info[0] > 2:
        return
    if not hasattr(os, 'getcwdu'):
        return
    old_cwd = os.getcwdu()
    try:
        os.chdir(b'\xff')
        err = InvalidPattern('some message')
        repr(err)
    finally:
        os.chdir(old_cwd)

# Generated at 2022-06-21 21:50:51.312071
# Unit test for function lazy_compile
def test_lazy_compile():
    re.compile = _old_re_compile = re.compile

# Generated at 2022-06-21 21:51:01.772825
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern."""
    e = InvalidPattern
    # empty exception
    expected = u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    actual = e().__unicode__()
    assert actual == expected, "expected '%s', got '%s'" % (expected, actual)

    # with an error
    expected = u"Unprintable exception InvalidPattern: dict={'msg': u'abc'}, fmt=None, error=None"
    actual = e(u"abc").__unicode__()
    assert actual == expected, "expected '%s', got '%s'" % (expected, actual)

    # with a preformatted message

# Generated at 2022-06-21 21:51:12.416073
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern"""

    e1 = InvalidPattern(msg="message")
    e2 = InvalidPattern(msg="message")
    assert e1 == e2
    e3 = InvalidPattern(msg="other message")
    assert e3 != e1


_real_re_compile = re.compile
if _real_re_compile is lazy_compile:
    raise AssertionError(
        "re.compile has already been overridden as lazy_compile, but this would" \
        " cause infinite recursion")

# Generated at 2022-06-21 21:51:21.574847
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test bug 852992

    This test shouldn't use re directly, so that it would actually catch the
    problem"""
    import bzrlib.trace
    install_lazy_compile()
    # We should now be using the lazy version.
    # We want to check that this doesn't create an infinite loop.
    assert re.compile is lazy_compile
    bzrlib.trace.dont_trace_regex_compile_result(re)
    # This shouldn't recurse
    bzrlib.trace.dont_trace_regex_compile_result(re)

# Generated at 2022-06-21 21:51:31.049422
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that the new compile mode works."""
    reset_compile()
    install_lazy_compile()
    re_a = re.compile('a')
    re_b = re.compile('b')
    assert re_a != re_b
    assert re_a._real_regex is None
    assert re_b._real_regex is None
    assert re_a.match('a')
    assert re_b.match('b')
    assert re_a._real_regex is not None
    assert re_b._real_regex is not None
    # This must be last to ensure we don't break existing code.
    reset_compile()

# Generated at 2022-06-21 21:51:38.067289
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ must return a str, not a unicode object.
    We don't want to break the traceback.
    """
    exception = InvalidPattern('test')
    try:
        raise exception
    except:
        (message, traceback) = sys.exc_info()[:2]
        if message.__class__ is str:
            # We have the str object that we want
            pass
        else:
            # We don't have the str object that we want
            raise AssertionError(message.__class__)

# Generated at 2022-06-21 21:51:40.596494
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex: Test the constructor.

    """
    foo = LazyRegex()
    assert foo
    # TODO: check that it really is lazy: use a dummy re.compile()


# Generated at 2022-06-21 21:51:46.497621
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    error = InvalidPattern('test %(msg)s')
    error._preformatted_string = 'test'

    def check(expected_string):
        assert str(error) == expected_string
        assert unicode(error) == unicode(expected_string)

    check('test')

# Generated at 2022-06-21 21:51:53.688517
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from bzrlib.tests import TestCase

    class TestLazyRegex__setstate__(TestCase):
        def test_setstate_with_empty_dict(self):
            lazy_regex = LazyRegex()
            new_state = {}
            lazy_regex.__setstate__(new_state)
            self.assertEqual({
            "args" : (),
            "kwargs" : {},
            }, new_state)
    test_LazyRegex___setstate__ = TestLazyRegex__setstate__()
    test_LazyRegex___setstate__.test_setstate_with_empty_dict()

# Generated at 2022-06-21 21:52:01.015863
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode object"""
    error = InvalidPattern('missing message')
    assert isinstance(error.__unicode__(), unicode)
    assert error.__unicode__() == u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    error = InvalidPattern(u'missing fmt')
    assert error.__unicode__() == u'missing fmt'

# Generated at 2022-06-21 21:52:12.901510
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ returns a member from the proxied regex object."""
    global re_compile_thunk
    from bzrlib.tests.test_regex import TestPythonRegex
    test_cases = TestPythonRegex(None)
    test_cases.test_compile()
    test_cases.test_pattern_objects()
    test_cases.test_search_star_star()
    test_cases.test_match_star_star()
    test_cases.test_split()
    test_cases.test_findall()
    test_cases.test_finditer()
    test_cases.test_sub_star_star()
    test_cases.test_subn_star_star()
    test_cases.test_scanner()
    test_cases.test_pickle()


# Install the lazy

# Generated at 2022-06-21 21:52:23.153861
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Checks that method __setstate__ of class LazyRegex works properly"""
    class DummyLazyRegex(LazyRegex):
        """Dummy instance of class LazyRegex"""

    dummy_lazy_regex = DummyLazyRegex()
    # State to use when unpickling a DummyLazyRegex object
    state = {
        "args": [],
        "kwargs": {},
        }
    # Restore from a pickled state
    dummy_lazy_regex.__setstate__(state)
    # Checks that LazyRegex has not been compiled
    try:
        dummy_lazy_regex._real_regex
    except AttributeError:
        pass

# Generated at 2022-06-21 21:52:43.661769
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('Invalid pattern')
    except InvalidPattern as e:
        assert(str(e).startswith('Unprintable exception InvalidPattern: '
                                 'dict={'), str(e))
        assert(str(e).endswith('}, fmt=None, error=None'), str(e))
        assert(str(e).find('"Invalid pattern"'), str(e))

# Generated at 2022-06-21 21:52:51.142936
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test string representation of InvalidPattern."""
    error = InvalidPattern("invalid pattern")
    assert isinstance(error, Exception)
    assert str(error) == "Invalid pattern(s) found. invalid pattern"
    assert str(error) == unicode(error).encode('utf8')
    assert repr(error) == "InvalidPattern('Invalid pattern(s) found. invalid pattern')"



# Generated at 2022-06-21 21:52:58.505127
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    re.compile = _real_re_compile
    install_lazy_compile()
    lazy_regex = lazy_compile("test")
    state = lazy_regex.__getstate__()
    assert state == {
        "args": ("test",),
        "kwargs": {},
        }
    reset_compile()

# Generated at 2022-06-21 21:53:02.965466
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() should return the state to use when pickling"""
    regex = LazyRegex((), {})
    state = regex.__getstate__()
    import copy
    copy.deepcopy(regex)

# Generated at 2022-06-21 21:53:08.356214
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ must be a string.

    Unit tests for repr() of class InvalidPattern
    """

    # __repr__ returns a string
    i = InvalidPattern("test")
    assert repr(i) == "InvalidPattern('test')"
    assert type(repr(i)) == str

    # Test with a Unicode string
    i = InvalidPattern(u"test")
    assert type(repr(i)) == str
    import sys
    if sys.version_info[0] == 2:
        # Test that Unicode objects are handled correctly.
        assert repr(i) == u"InvalidPattern(u'test')"
    else:
        assert repr(i) == "InvalidPattern('test')"

# Unit tests for methods __unicode__ and __str__ of class InvalidPattern
# (see bug #648914)

# Generated at 2022-06-21 21:53:10.388998
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:53:15.160979
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test __str__ method of InvalidPattern"""
    # Check that the method __str__ returns a str
    msg = 'Invalid regex pattern'
    error = InvalidPattern(msg)
    error_str = str(error)
    assert isinstance(error_str, str)
    # Check that the error message is displayed
    assert msg in error_str

# Generated at 2022-06-21 21:53:26.628771
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ method of InvalidPattern must be defined"""
    from bzrlib.tests.test_regex import TestCaseWithBrokenRegex
    class TestableInvalidPattern(InvalidPattern):
        """class for testing __eq__ method"""
        _fmt = ('testing %(test)s')
        def __init__(self, msg, test):
            InvalidPattern.__init__(self, msg)
            self.test = test

    one = TestableInvalidPattern('just testing', 'test one')
    two = TestableInvalidPattern('just testing', 'test one')
    # test with same values
    TestCaseWithBrokenRegex.assertEqual(one, two)
    three = TestableInvalidPattern("I don't match", 'test three')
    TestCaseWithBrokenRegex.assertNotEqual(one, three)


# Generated at 2022-06-21 21:53:34.222214
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method __getattr__ of class LazyRegex."""
    # get an attribute.
    regex = LazyRegex()
    foo = regex.pattern
    assert foo is None, "returned an attribute"
    # This should fail, because I haven't set it.
    try:
        foo = regex.unknown_attribute
    except AttributeError:
        pass
    else:
        assert False, "returned an unknown attribute"

# Generated at 2022-06-21 21:53:44.457131
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys

    class test_InvalidPattern___str__(object):

        def __init__(self, name, dict_, err):
            self.name = name
            self.dict_ = dict_
            self.err = err

        def run(self):
            self.check_basic(
                'Unprintable exception InvalidPattern_test_class: dict={}, ' \
                'fmt={}, error={}',
                'InvalidPattern_test_class',
                {}, None, None)
            self.check_basic(
                'Unprintable exception InvalidPattern_test_class: dict={}, ' \
                'fmt={}, error={}',
                'InvalidPattern_test_class',
                {'a': 'b'}, None, None)

# Generated at 2022-06-21 21:54:02.253240
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string"""
    # Verify the type of the return value
    ip = InvalidPattern(None)
    assert isinstance(ip.__repr__(), str)
    # Verify the content of the return value (regex_errors.py calls repr()
    # on the raised exception to include it in the error message)
    ip = InvalidPattern('Your pattern is invalid')
    assert "InvalidPattern('Your pattern is invalid')" == ip.__repr__()

# Generated at 2022-06-21 21:54:10.436928
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Strings returned by InvalidPattern.__str__ must be valid

    InvalidPattern.__str__ must return a string, not a unicode object, even
    if the string is ascii.
    """
    class InvalidPatternTest(InvalidPattern):
        """For testing __str__"""
        _fmt = '%(msg)s'
        def __init__(self, msg):
            """For testing __str__"""
            self.msg = msg
    try:
        raise InvalidPatternTest('invalid pattern')
    except InvalidPatternTest as e:
        s = str(e)
        assert isinstance(s, str)
        assert isinstance(s, unicode)



# Generated at 2022-06-21 21:54:13.138700
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex_lazy = LazyRegex(pattern='*')


# Generated at 2022-06-21 21:54:15.143441
# Unit test for function reset_compile
def test_reset_compile():
    """Calling reset_compile restores original re.compile"""
    assert re.compile is not _real_re_compile
    reset_compile()
    assert re.compile is _real_re_compile


# Generated at 2022-06-21 21:54:19.848896
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class Test(object):
        def __init__(self, msg):
            self.msg = msg
    ip = InvalidPattern(Test('msg'))
    eq = 'Invalid pattern(s) found. msg'
    assert str(ip) == eq
    assert unicode(ip) == eq


# Test compatibility with pre-lazy_compile code

# Generated at 2022-06-21 21:54:30.457179
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method '__getattr__' of the LazyRegex class.

    '__getattr__' is tested by creating a class that inherits from
    LazyRegex, overriding all the methods and attributes of LazyRegex.

    Then a call to __getattr__ is made and if it returns an attribute of
    the mocked class, we know that __getattr__ looks at the attributes of
    the mock, otherwise it doesn't.

    """
    class LazyRegexMock(LazyRegex):
        """Mock a LazyRegex object."""
        _regex_attributes_to_copy = [
                '__copy__', '__deepcopy__', 'findall', 'finditer', 'match',
                'scanner', 'search', 'split', 'sub', 'subn'
                ]
        __slots__

# Generated at 2022-06-21 21:54:42.568437
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests.blackbox import ExternalBase
    class TestInvalidPattern1(ExternalBase):
        """Test method __repr__ of class InvalidPattern."""
        def test_normal(self):
            try:
                raise InvalidPattern('a')
            except InvalidPattern as e:
                self.assertEqual(str(e), e.__repr__())
                self.assertEqual(str(e), repr(e))
    TestInvalidPattern1('test_normal').test_normal()

    class TestInvalidPattern2(ExternalBase):
        """Test method __repr__ of class InvalidPattern."""

# Generated at 2022-06-21 21:54:51.664784
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = LazyRegex(("abc",))
    assert isinstance(r.pattern, unicode)
    assert r.pattern == u"abc"

    # Ensure that the r.pattern field is really cached
    if hasattr(r._real_regex, "__dict__"):
        # We have an ordinary regex object
        assert r._real_regex.__dict__["pattern"] == u"abc"
    else:
        # We have a _sre.SRE_Pattern object, which doesn't have a __dict__
        assert r._real_regex.pattern == u"abc"
    # Make sure that the proxy hasn't been collapsed
    assert not hasattr(r, 'pattern')

# Generated at 2022-06-21 21:54:55.220139
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Unit test for function install_lazy_compile"""
    reset_compile()
    install_lazy_compile()
    regex = re.compile("foo")
    assert regex._real_regex is None
    regex.match("foo")
    assert regex._real_regex is not None


# Generated at 2022-06-21 21:54:59.725045
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__() should return a string."""
    invalid_pattern = InvalidPattern('invalid pattern')
    msg = "%r" % invalid_pattern
    assert msg == 'InvalidPattern(invalid pattern)', msg



# Generated at 2022-06-21 21:55:16.786553
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern(b'foo')
    u = unicode(e)
    if not isinstance(u, unicode):
        raise AssertionError('unicode(%r) is not unicode' % (e,))
    s = str(e)
    if not isinstance(s, str):
        raise AssertionError('str(%r) is not str' % (e,))

# Generated at 2022-06-21 21:55:24.161714
# Unit test for function reset_compile
def test_reset_compile():
    def new_compile(r, f=0, **kw):
        return 'new'
    re.compile = new_compile
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError(
            "reset_compile() did not reset the function pointer")


# Generated at 2022-06-21 21:55:26.532199
# Unit test for function reset_compile
def test_reset_compile():
    # reset compile needs to reset even if it has never been called.
    re.compile = lazy_compile
    reset_compile()

# Generated at 2022-06-21 21:55:36.903143
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""

    class MyInvalidPattern(InvalidPattern):

        _fmt = u'\xa9 is not a valid pattern'

        def __init__(self):
            InvalidPattern.__init__(self, u'')

    r = MyInvalidPattern()
    # converts the unicode string to a str object
    assert isinstance(str(r), str)
    # __str__ must return a str.
    assert isinstance(r.__str__(), str)

    # As we provide a __repr__ method, this object should be usable by
    # %s or %r operator
    assert isinstance(u'%s' % r, unicode)
    assert isinstance(u'%r' % r, unicode)
    # should always return a unicode, even with a 'str' formatting

# Generated at 2022-06-21 21:55:44.862490
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that re.compile is overridden properly"""
    # Check the real compile function is still the same
    assert re.compile is _real_re_compile
    install_lazy_compile()
    assert re.compile is lazy_compile, \
           "compile is not pointing at our defined compile function"
    reset_compile()
    assert re.compile is _real_re_compile, \
           "compile is not pointing at the original function after reset"


# unit test for function reset_compile

# Generated at 2022-06-21 21:55:47.380086
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    pattern = InvalidPattern('pattern problem')
    expected = "InvalidPattern('pattern problem')"
    actual = repr(pattern)
    assert expected == actual

# Generated at 2022-06-21 21:55:58.595760
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle

    # try to create a new proxy object
    pattern = LazyRegex(['a'])

    # verify it's really a proxy
    try:
        pattern.match('b')
    except AttributeError:
        pass
    else:
        raise AssertionError("AttributeError not raised")

    pickled = pickle.dumps(pattern)
    pattern_from_pickle = pickle.loads(pickled)

    # Now that we've loaded it back from a pickle, it should have
    # instantiated the real regex.
    try:
        result = pattern.match('b')
    except AttributeError:
        raise AssertionError('Failed to match after pickle restoring')
    else:
        if result is not None:
            raise AssertionError('Pattern should not have matched')


# Generated at 2022-06-21 21:56:06.749304
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return a dictionary mapping args and kwargs to
    the values supplied when the LazyRegex was created.
    """
    r = LazyRegex(args=("abcdef",), kwargs={"flags":re.IGNORECASE})
    state = r.__getstate__()
    assert state["args"] == ["abcdef"], state
    assert state["kwargs"] == {"flags":re.IGNORECASE}, state


# Generated at 2022-06-21 21:56:18.177615
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class foo(Exception):
        _fmt = "foo is %(bar)s"

# Generated at 2022-06-21 21:56:21.540727
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Method __eq__ of class InvalidPattern should return NotImplemented,
    if the other isn't an InvalidPattern.
    """
    e = InvalidPattern('test')
    assert e != None
    assert e != 0
    assert e != ''


# Generated at 2022-06-21 21:56:37.928451
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestCase

    class TestResetCompile(TestCase):

        def test_reset_compile(self):
            re.compile = lambda pat: re.compile
            self.assertNotEqual(re.compile, _real_re_compile)
            reset_compile()
            self.assertEqual(re.compile, _real_re_compile)

# Generated at 2022-06-21 21:56:45.723345
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern"""

    # Test checking equality between two instances of InvalidPattern
    # with different values
    pattern = InvalidPattern(msg='Test')
    other_pattern = InvalidPattern(msg='Test2')
    result = other_pattern.__eq__(pattern)
    expected_result = False
    if result != expected_result:
        raise AssertionError(
            'result (%s) is not the expected one (%s)' % (result,
                                                          expected_result))

    # Test checking equality between two instances of InvalidPattern
    # with same values
    pattern = InvalidPattern(msg='Test')
    other_pattern = InvalidPattern(msg='Test')
    result = other_pattern.__eq__(pattern)
    expected_result = True
    if result != expected_result:
        raise Assertion

# Generated at 2022-06-21 21:56:57.166867
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    class SubInvalidPattern(InvalidPattern):
        pass
    args = ('test',)
    kwargs = {'foo':'bar'}
    e1 = SubInvalidPattern(*args, **kwargs)
    e2 = SubInvalidPattern(*args, **kwargs)
    e3 = SubInvalidPattern('foobar')
    e4 = InvalidPattern('test', foo='bar')
    e5 = Exception('test')
    # Test for class difference
    if (e1 == e5):
        raise AssertionError('e1 == e5 but e1.__class__ != e5.__class__')
    # Test for __eq__