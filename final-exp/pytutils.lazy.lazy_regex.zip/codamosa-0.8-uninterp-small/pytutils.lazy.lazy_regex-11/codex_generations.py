

# Generated at 2022-06-26 02:15:48.414028
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    _regex_args = ()
    _regex_kwargs = {}
    r = LazyRegex()
    try:
        r._real_regex = None
        r.__dict__['_regex_args'] = _regex_args
        r.__dict__['_regex_kwargs'] = _regex_kwargs
        assert isinstance(r, LazyRegex)
        getattr(r, 'unicode')
    except AttributeError:
        pass


# Generated at 2022-06-26 02:15:59.611084
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('Regex %(arg)s is invalid. %(cause)s')
    var_1._preformatted_string = 'Invalid regex: foo is too short'
    var_1.arg = 'foo'
    var_1.cause = 'spam'
    var_2 = ('Invalid regex: foo is too short')
    var_3 = ('Invalid regex: foo is too short')
    assert (var_2 == var_3)
    var_4 = ('Invalid regex: foo is too short')
    assert (var_3 == var_4)

# Generated at 2022-06-26 02:16:13.354169
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    exception = InvalidPattern('msg')
    exception.__dict__['msg'] = 'msg'
    exception.__dict__['_preformatted_string'] = None
    exception.__dict__['_fmt'] = '%(msg)s'
    exception.__dict__['_preformatted_string'] = None
    exception.__dict__['_fmt'] = '%(msg)s'
    from bzrlib.i18n import gettext
    exception.__dict__['_fmt'] = gettext('%(msg)s')
    exception.__dict__['_preformatted_string'] = 'msg'
    exception.__dict__['_preformatted_string'] = None

# Generated at 2022-06-26 02:16:17.543671
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    e = InvalidPattern('asdf')
    assert str(gettext('Invalid pattern(s) found. %(msg)s')) == 'Invalid pattern(s) found. asdf'
    assert str(e) == 'Invalid pattern(s) found. asdf'


# Generated at 2022-06-26 02:16:22.815291
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_0 = LazyRegex()
    var_1 = {}
    var_1['args'] = ()
    var_1['kwargs'] = {}
    var_0.__setstate__(var_1)
    assert type(var_0._regex_args) is tuple
    assert var_0._regex_args == ()
    assert type(var_0._regex_kwargs) is dict
    assert var_0._regex_kwargs == {}
    assert var_0._real_regex is None


# Generated at 2022-06-26 02:16:33.696554
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_3 = InvalidPattern("foo")
    if var_3 == "foo":
        var_4 = 1
    else:
        var_4 = 0
    var_5 = InvalidPattern("foo")
    if var_5 == "foo":
        var_6 = 1
    else:
        var_6 = 0
    var_7 = InvalidPattern("foo")
    if var_7 == "foo":
        var_8 = 1
    else:
        var_8 = 0
    var_9 = InvalidPattern("foo")
    if var_9 == "foo":
        var_10 = 1
    else:
        var_10 = 0
    var_11 = InvalidPattern("foo")
    if var_11 == "foo":
        var_12 = 1
    else:
        var_12 = 0
    var_13

# Generated at 2022-06-26 02:16:39.643450
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # The previous line works if ui_factory is None.
    var_25 = InvalidPattern('a')
    var_24 = var_25.__unicode__()
    assert(var_24 == u'a')


# Generated at 2022-06-26 02:16:43.411348
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exception0 = InvalidPattern('layover misbehavior.')
    try:
        raise exception0
    except InvalidPattern as e0:
        str0 = str(e0)
        assert 0 == cmp(str0, 'Invalid pattern(s) found. layover misbehavior.')


# Generated at 2022-06-26 02:16:52.847774
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # unit test for __str__
    e = InvalidPattern(1)
    assert isinstance(e.__str__(), str)
    # unit test for __str__
    e = InvalidPattern(1)
    assert isinstance(e.__unicode__(), unicode)
    # unit test for __str__
    e = InvalidPattern(1)

    assert e.__repr__() == 'InvalidPattern(1)'


# Generated at 2022-06-26 02:17:03.810359
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ : do we get a nice message ?"""
    pattern = "([\d]{1}),([\d]{1}),([\d]{1}),([\d]{1})"
    try:
        lazy_compile(pattern)
        raise AssertionError("This should have raised InvalidPattern")
    except InvalidPattern as e:
        if ("^ is not a non-empty string nor a compiled pattern"
            not in str(e)):
            raise AssertionError("Invalid message")



# Generated at 2022-06-26 02:17:17.199364
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    global _real_re_compile
    _real_re_compile = re.compile
    re.compile = lazy_compile

# Generated at 2022-06-26 02:17:23.598013
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    testcase = InvalidPattern('this is a test')
    expected = 'this is a test'
    result = testcase.__str__()
    assert result == expected, \
        "InvalidPattern.__str__(): got %r, expected %r" % (result, expected)


# Generated at 2022-06-26 02:17:31.427010
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method LazyRegex.__getattr__ of class LazyRegex"""
    # Create an instance of LazyRegex
    instance = LazyRegex()
    # Call the __getattr__ method
    result = instance.__getattr__()
    # Check the result
    assert result is None


# Generated at 2022-06-26 02:17:34.974915
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that InvalidPattern's __str__ method does not crash.

    This tests for bug #839355.
    """
    str(InvalidPattern('foo'))



# Generated at 2022-06-26 02:17:38.717053
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    x = InvalidPattern(msg='foo')
    y = unicode(x)
    assert y == 'foo', y


# Generated at 2022-06-26 02:17:44.940091
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('foo')
    var_1._fmt = '%(msg)s'
    var_1.msg = 'bar'
    var_0 = var_1.__unicode__()
    print(var_0)
    assert var_0 == 'bar'

# Generated at 2022-06-26 02:17:48.053771
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern"""
    pass


# Generated at 2022-06-26 02:17:56.430785
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('Test')
    var_2 = var_1.__unicode__()
    var_1 = InvalidPattern('Test')
    var_3 = var_1.__unicode__()
    var_4 = var_2 == var_3
    var_4 = var_4 # not used
    return var_4


# Generated at 2022-06-26 02:17:59.108404
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex("a", "b")
    var_0.group()


# Generated at 2022-06-26 02:18:05.836660
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern(msg = "bzrlib.tests.test_regex.test_case_0")
    var_2 = var_1.__str__()
    var_3 = (type(var_2) is str)

    assert var_3 == True


# Generated at 2022-06-26 02:18:27.619131
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from io import BytesIO
    from io import StringIO
    from bzrlib import __file__ as _bzrlib_path
    from bzrlib import errors
    from bzrlib.errors import BzrError, InternalBzrError
    from bzrlib.trace import mutter, note, warning
    #_fmt = ('Invalid pattern(s) found. %(msg)s')
    #self.msg = _fmt
    var_1 = InvalidPattern('')
    var_p = var_1._get_format_string()
    #var_p = var_1._fmt
    var_2 = InvalidPattern('Invalid pattern(s) found. %s')
    var_p = var_2._get_format_string()
    #var_p = var_2._fmt
   

# Generated at 2022-06-26 02:18:31.817106
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('bzrlib.tests.test_regex.test_InvalidPattern___unicode__')
    var_2 = var_1._format()
    var_3 = var_2.decode('utf8')
    return var_3


# Generated at 2022-06-26 02:18:40.351739
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import i18n
    from bzrlib.i18n import gettext
    i18n.get_i18n_translator(i18n.get_bzr_translations())
    t = gettext
    var_1 = t('Invalid pattern(s) found. %(msg)s')
    var_2 = unicode(var_1, 'utf8')
    var_3 = InvalidPattern(var_2)
    var_4 = var_3.__unicode__()
    var_5 = unicode(var_2, 'utf8')
    var_6 = var_5 == var_4
    var_7 = reset_compile()
    return var_6


# Generated at 2022-06-26 02:18:43.101201
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern(var_0)
    return var_1


# Generated at 2022-06-26 02:18:47.385616
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    err = InvalidPattern("msg")
    assert str(err) == 'Invalid pattern(s) found. msg'
    assert unicode(err) == u'Invalid pattern(s) found. msg'



# Generated at 2022-06-26 02:18:54.323569
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = LazyRegex()
    var_2 = LazyRegex()
    var_1._regex_args = ['abc',]
    var_2._real_regex = var_1
    var_3 = LazyRegex()
    var_3._regex_args = ['abc',]
    var_1._real_regex = var_3
    var_3 = getattr(var_3, 'foo')


# Generated at 2022-06-26 02:18:58.485055
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        tmp_0 = LazyRegex()
        tmp_0.__compile_and_collapse()
        tmp_0._real_re_compile()
    except InvalidPattern as e2:
        r = str(e2)
        r = repr(e2)


# Generated at 2022-06-26 02:19:01.422117
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    assert(str(InvalidPattern(" ")) == 'Invalid pattern(s) found.  ')
    assert(str(InvalidPattern("abc")) == 'Invalid pattern(s) found. abc')


# Generated at 2022-06-26 02:19:06.608945
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Calling StringIO instances like objects with the parameter 'Invalid string'
    var_0 = StringIO('Invalid string')
    # Calling StringIO instances like objects with the parameter ''
    var_1 = StringIO('')
    # Calling InvalidPattern with the parameters ('%(msg)s',) and {}
    
    var_2 = InvalidPattern('%(msg)s')
    # Setting attribute 'msg' of var_2 to var_0.getvalue()
    setattr(var_2, 'msg', var_0.getvalue())
    # Calling assertEqual with the parameters (var_2.__unicode__(), var_0.getvalue())
    assertEqual(var_2.__unicode__(), var_0.getvalue())
    # Setting attribute 'msg' of var_2 to var_1.getvalue()
    setattr

# Generated at 2022-06-26 02:19:11.918817
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test InvalidPattern.__unicode__()."""
    try:
        err = InvalidPattern("foo")
    except:
        err = InvalidPattern("foo")
    else:
        pass
    assert err.__unicode__() == "foo"


# Generated at 2022-06-26 02:19:21.422985
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # _get_format_string returns nothing, thus __unicode__ returns
    # "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    # in a unicode string.
    var_0 = InvalidPattern("")
    var_1 = var_0.__unicode__()
    pass



# Generated at 2022-06-26 02:19:23.712877
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('testing')
    var_2 = unicode(var_1)
    var_3 = repr(var_1)


# Generated at 2022-06-26 02:19:33.012120
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import re
    import os.path
    var_1 = lazy_compile("(?P<name>.*)")
    getattr(var_1, "pattern")
    getattr(var_1, "groupindex")
    var_2 = lazy_compile("(?P<name>.*)")
    var_3 = getattr(var_2, "pattern")
    assert var_3 == "(?P<name>.*)"
    var_4 = getattr(var_2, "groupindex")
    var_5 = {"name": 1}
    assert var_4 == var_5
    var_6 = lazy_compile("(?P<name>.*)")
    var_7 = getattr(var_6, "groups")
    var_8 = 1
    assert var_7 == var_8
    var

# Generated at 2022-06-26 02:19:40.326529
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    '''Test behaviour of _InvalidPattern__unicode__'
    Test that the InvalidPattern class provides a __unicode__ method which
    returns the translated exception message.
    '''
    class MyTestException(InvalidPattern):
        _fmt = "TestException: %(msg)s"


# Generated at 2022-06-26 02:19:46.328588
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    '''Test case for __unicode__'''
    instance = InvalidPattern('foo bar')
    # InvalidPattern.__unicode__ returns unicode
    #self.assertEqual(type(instance.__unicode__()), unicode)
    # InvalidPattern.__unicode__ returns 'foo bar'
    return instance.__unicode__()



# Generated at 2022-06-26 02:19:48.070845
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():

    # We should not crash when printing InvalidPattern
    reg = re.compile('*')


# Generated at 2022-06-26 02:19:52.494980
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    if (__name__ == '__main__'):
        var_0 = install_lazy_compile()
        var_1 = lazy_compile('\|a')
        var_2 = type(var_1).__getattr__(var_1, '_real_regex')
    return (var_0, var_1, var_2)


# Generated at 2022-06-26 02:19:57.633477
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # support for 'isinstance(..., basestring)' in Python 2
    from six import string_types
    try:
        msg = unicode('foo')
    except NameError:
        msg = 'foo'
    e = InvalidPattern(msg)
    assert isinstance(e.__str__(), string_types)


# Generated at 2022-06-26 02:20:05.308265
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import unittest
    from bzrlib.i18n import gettext

    class TestCase(unittest.TestCase):
        "Tests for method __str__ of class InvalidPattern"

        def test___str__(self):
            "A one-line test for method __str__"
            # FIXME: This is a stub. It needs to be implemented.
            raise NotImplementedError(self.test___str__.__doc__)
    unittest.main()


# Generated at 2022-06-26 02:20:10.000648
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.errors import InvalidPattern
    # Private member test
    # Private member test
    # Private member test
    # Private member test
    # Private member test
    # Exception test
    # Exception test

    try:
        raise InvalidPattern('"' + '" ' +str(e))
    except InvalidPattern:
        pass


# Generated at 2022-06-26 02:20:18.973490
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('Invalid pattern(s) found. "^Using the "expected" log message" ')
    var_1 = var_0._format()
    assert(var_1 == 'Invalid pattern(s) found. "^Using the "expected" log message" ')
    var_2 = unicode(var_1)
    assert(var_2 == 'Invalid pattern(s) found. "^Using the "expected" log message" ')


# Generated at 2022-06-26 02:20:23.895178
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('no message')
    if str(e) == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None':
        return 0
    raise AssertionError("str() returned unexpected result")


# Generated at 2022-06-26 02:20:26.666734
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('test message')
    var_1 = unicode(var_0)
    assert var_1 == u'test message', var_1


# Generated at 2022-06-26 02:20:32.585522
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():

    # using the default format
    pattern = InvalidPattern('error')
    assert(str(pattern) == 'Invalid pattern(s) found. error')

    # providing a custom format
    pattern = InvalidPattern('error')
    assert(pattern._fmt == 'Invalid pattern(s) found. %(msg)s')
    pattern._fmt = 'custom msg %(msg)s'
    assert(str(pattern) == 'custom msg error')



# Generated at 2022-06-26 02:20:37.402580
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = LazyRegex.__init__("hello")
    var_2 = LazyRegex._compile_and_collapse("hello")
    var_3 = LazyRegex.__init__("hello")
    var_4 = LazyRegex.__getattr__("hello", "hello")


# Generated at 2022-06-26 02:20:46.264925
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():

    # create a LazyRegex instance
    # var_0 is LazyRegex
    var_0 = LazyRegex()
    # call method __getattr__ of var_0 with attr = "foo"
    # var_1 is unknown
    var_1 = var_0.__getattr__("foo")
    assert isinstance(var_1, basestring)
    # create a LazyRegex instance
    # var_2 is LazyRegex
    var_2 = LazyRegex()
    # call method __getattr__ of var_2 with attr = "foo"
    # var_3 is unknown
    var_3 = var_2.__getattr__("foo")
    assert isinstance(var_3, basestring)
    # call method __getattr__ of var_0 with attr = "

# Generated at 2022-06-26 02:20:47.900603
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_2 = InvalidPattern('hello')
    var_3 = str(var_2)


# Generated at 2022-06-26 02:20:55.215532
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from StringIO import StringIO
    string = StringIO()
    gettext('Invalid pattern(s) found. %(msg)s')
    var_0 = InvalidPattern('test')
    var_1 = var_0._format()
    var_2 = unicode(var_1)
    var_3 = string.getvalue()
    var_4 = var_2 == 'Invalid pattern(s) found. test'
    var_5 = var_3 == ''
    var_5 = var_5 and var_4


# Generated at 2022-06-26 02:21:06.416031
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = LazyRegex()
    assert not(hasattr(var_1, '_real_regex'))
    assert not(hasattr(var_1, '_regex_args'))
    assert not(hasattr(var_1, '_regex_kwargs'))
    assert not(hasattr(var_1, '__copy__'))
    assert not(hasattr(var_1, '__deepcopy__'))
    assert not(hasattr(var_1, 'findall'))
    assert not(hasattr(var_1, 'finditer'))
    assert not(hasattr(var_1, 'match'))
    assert not(hasattr(var_1, 'scanner'))
    assert not(hasattr(var_1, 'search'))

# Generated at 2022-06-26 02:21:17.967008
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import trace
    from bzrlib.i18n import gettext
    gettext(u'invalid standard input')
    var_0 = reset_compile()
    try:
        var_1 = re.compile(u'\x00')
    except InvalidPattern as var_2:
        print(var_2, var_2.__class__)


# Generated at 2022-06-26 02:21:25.113216
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    obj = InvalidPattern("foo")
    assert obj.__unicode__() == "foo"


# Generated at 2022-06-26 02:21:27.930161
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():

    msg = 'error message'
    e = InvalidPattern(msg)
    assert str(e) == msg, str(e)



# Generated at 2022-06-26 02:21:29.423362
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = reset_compile()


# Generated at 2022-06-26 02:21:33.822758
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    t = InvalidPattern('foo')
    assert t._format() == 'foo'

    t = InvalidPattern(u'foo')
    assert t._format() == u'foo'


# Generated at 2022-06-26 02:21:41.872154
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # in case a _preformatted_string is present
    msg = 'foo'
    ex = InvalidPattern(msg)
    s = str(ex)
    assert(s == msg)

    # in case _get_format_string returns a format string
    ex = InvalidPattern('')
    ex._fmt = 'foo'
    s = str(ex)
    assert(s == 'foo')

    # in case an exception occurs during formatting
    ex._fmt = '%(msg)s'
    e = Exception('bar')
    def _(*a, **kw): raise e
    ex._get_format_string = _
    s = str(ex)
    assert(s == '%(msg)s')



# Generated at 2022-06-26 02:21:44.544159
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = "Invalid pattern(s) found. 'foo' "
    with_message = InvalidPattern(msg)
    assert with_message.__unicode__() == msg


# Generated at 2022-06-26 02:21:50.408362
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    # __unicode__ should return a unicode object
    dict = {}
    dict['msg'] = u'compile(pattern, flags=0)'
    e = InvalidPattern('compile(pattern, flags=0)')
    e.msg = u'compile(pattern, flags=0)'
    assertEquals(gettext(unicode(dict['msg'])) % dict, e.__unicode__())


# Generated at 2022-06-26 02:21:53.094401
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(None)
    assert isinstance(var_0.__str__(), str)


# Generated at 2022-06-26 02:21:54.656561
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    inst_0 = InvalidPattern('example')
    var_0 = inst_0.__str__()


# Generated at 2022-06-26 02:21:55.755363
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern()


# Generated at 2022-06-26 02:22:06.586890
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from pickle import loads, dumps
    p = lazy_compile("abc")
    s = dumps(p)
    q = loads(s)
    # There must be a better way to test that __setstate__ has been called.
    # The following doesn't work.
    #q.__setstate__({'args':('abc',),'kwargs':{}})
    assert repr(p) == repr(q)



# Generated at 2022-06-26 02:22:18.488693
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # sanity check: making sure re.compile was actually overridden
    orig_re_compile = _real_re_compile
    assert re.compile is lazy_compile, repr(re.compile)
    reinstall = False

# Generated at 2022-06-26 02:22:22.246302
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('message')
    var_1 = 'Unprintable exception InvalidPattern: dict={}, fmt=%(msg)s, error=None'
    assert var_0._format() == var_1


# Generated at 2022-06-26 02:22:34.509535
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # self.msg = msg
    test_case_0()
    var_0 = InvalidPattern('Invalid pattern(s) found. /foo/: unbalanced parenthesis')
    var_1 = var_0._format()
    var_2 = unicode(var_1)
    var_3 = var_0.__unicode__()
    var_4 = str(var_3)
    var_5 = unicode(var_4)
    assert var_2 == 'Invalid pattern(s) found. /foo/: unbalanced parenthesis'
    assert var_3 == 'Invalid pattern(s) found. /foo/: unbalanced parenthesis'
    assert var_4 == 'Invalid pattern(s) found. /foo/: unbalanced parenthesis'

# Generated at 2022-06-26 02:22:36.905531
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('msg')
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:22:38.974217
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    error = InvalidPattern('msg')
    msg = error.__str__()



# Generated at 2022-06-26 02:22:41.489690
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("abc")
    var_1 = var_0.__str__()
    assert(var_1 == (u'abc'))


# Generated at 2022-06-26 02:22:44.719031
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = install_lazy_compile()
    try:
        var_2 = re.compile('abc')
    except InvalidPattern as e:
        pass
    else:
        raise AssertionError('Expected InvalidPattern exception (bug #586685)')
    var_3 = reset_compile()


# Generated at 2022-06-26 02:22:51.376780
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    e = InvalidPattern('test')
    for attr in dir(e):
        if not attr.startswith('_'):
            assert getattr(e, attr) == getattr(e, attr)
    assert e == e
    var_0 = test_InvalidPattern___unicode__()


# Generated at 2022-06-26 02:22:55.783456
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'I am a bad pattern'
    var_1 = InvalidPattern(msg)
    var_2 = str(var_1)
    var_3 = var_2
    assert(var_3 == 'Invalid pattern(s) found. I am a bad pattern')


# Generated at 2022-06-26 02:23:02.753958
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('a')
    assert var_1.__str__() == 'a', \
        "InvalidPattern.__str__() method not working correctly."


# Generated at 2022-06-26 02:23:07.332213
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_4 = InvalidPattern('test')
    var_5 = var_4._format()
    var_6 = unicode('')
    try:
        var_7 = var_5 == var_6
    except:
        var_7 = False
    if var_7:
        var_8 = True
    else:
        var_8 = False
    assert var_8



# Generated at 2022-06-26 02:23:10.696955
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_0 = LazyRegex()
    var_1 = {"args": (), "kwargs": {}}
    var_0.__setstate__(var_1)


# Generated at 2022-06-26 02:23:12.465515
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    s = InvalidPattern('msg')
    method = s.__unicode__
    expected = 'msg'
    actual = method()
    assert actual == expected, '%s != %s' % (actual, expected)


# Generated at 2022-06-26 02:23:15.180398
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern("test")
    s = unicode(e)
    assert str(type(s)) == "<type 'unicode'>"
    assert s == "test"


# Generated at 2022-06-26 02:23:19.407508
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('test_InvalidPattern___unicode__')
    var_2 = var_1.__unicode__()
    var_3 = isinstance(var_2, unicode)
    assert(var_3)


# Generated at 2022-06-26 02:23:25.712250
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern(u'A')
    var_0 = var_1._format()
    var_0 = var_1.__unicode__()
    var_0 = var_1.__str__()
    var_0 = var_1._get_format_string()
    var_0 = var_1.__repr__()


# Generated at 2022-06-26 02:23:27.233180
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test for this method is already present.
    assert hasattr(InvalidPattern, '__str__')

# Generated at 2022-06-26 02:23:29.274189
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('test_case_0')
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:23:35.334244
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        # Testing exception raised from InvalidPattern.__init__
        var_1 = InvalidPattern('Invalid pattern(s) found. "*" nothing to repeat')
        var_1.__unicode__()
    except InvalidPattern as var_2:
        var_2 = InvalidPattern(u'Invalid pattern(s) found. "*" nothing to repeat')
        var_2.__unicode__()

# Generated at 2022-06-26 02:23:43.194893
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('a')
    var_2 = var_1.__str__()

    assert var_2 != None


# Generated at 2022-06-26 02:23:44.449167
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    str_0 = Instantiate(InvalidPattern)._format()


# Generated at 2022-06-26 02:23:49.259297
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    result = InvalidPattern._format()
    assert result == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'

    result = InvalidPattern.__unicode__()
    assert result == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'

    result = InvalidPattern.__str__()
    assert result == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'

    result = InvalidPattern.__repr__()
    assert result == 'InvalidPattern(Unprintable exception InvalidPattern: dict={}, fmt=None, error=None)'

    result = InvalidPattern._get_format_string()
    assert result is None

# Generated at 2022-06-26 02:23:51.910235
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('a')
    var_0.msg = 'b'


# Generated at 2022-06-26 02:24:01.530844
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    e = InvalidPattern("string %(a)s, %(b)s")
    result = gettext("string %(a)s, %(b)s")
    if result != 'string %(a)s, %(b)s':
        raise AssertionError
    e._get_format_string = e._get_format_string.im_func
    e.a = 'a'
    e.b = 'b'
    e._format = e._format.im_func
    result = e._format()
    if result != 'string a, b':
        raise AssertionError
    result = str(e)
    if result != 'string a, b':
        raise AssertionError
    result = unicode(e)

# Generated at 2022-06-26 02:24:11.296185
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = 'test string'
    err = InvalidPattern(pattern)
    err.msg = 'test string'
    err.another_test_string = 'test string'
    err._fmt = 'test string'
    err._preformatted_string = 'test string'
    __expected___unicode__ = pattern
    result = unicode(err)
    assert result == __expected___unicode__, \
        "InvalidPattern().__unicode__ returned %s, expected %s" % \
        (result, __expected___unicode__)


# Generated at 2022-06-26 02:24:13.593318
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    msg = gettext(u'foo')
    obj = InvalidPattern(msg)
    # call the method (bound or unbound)
    r = obj.__str__()
    # check the result
    expected = 'foo'
    assert r == expected, "%r != %r" % (r, expected)


# Generated at 2022-06-26 02:24:23.624700
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    from StringIO import StringIO
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.tests import features
    from cStringIO import StringIO as _StringIO
    import pickle
    import re
    import sys
    def _mock_compile(pattern, flags=0):
        return _StringIO()
    class TestLazyRegex__getattr__(ExternalBase):
        def test_simple_match(self):
            null = open('/dev/null', 'w')
            old_stdout = sys.stdout
            sys.stdout = null

# Generated at 2022-06-26 02:24:24.523216
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass


# Generated at 2022-06-26 02:24:32.309413
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        var_1 = InvalidPattern(None)
    except:
        var_1 = None
    var_2 = "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    var_2 = unicode(var_2)
    # assertEqual(var_1.__str__(), var_2)


# Generated at 2022-06-26 02:24:46.544253
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'message'
    inst = InvalidPattern(msg)
    s = 'Invalid pattern(s) found. %(msg)s'
    from bzrlib.i18n import gettext
    s = gettext(unicode(s))
    assert (inst._format() == s % dict(msg='message'))
    assert (inst.__unicode__() == u'Invalid pattern(s) found. %(msg)s' % dict(msg='message'))
    assert (inst.__str__() == 'Invalid pattern(s) found. %(msg)s' % dict(msg='message'))
    assert (inst._get_format_string() == s)
    assert (inst.__repr__() == "InvalidPattern(Invalid pattern(s) found. message)")
    inst.msg = 'message2'

# Generated at 2022-06-26 02:24:49.361472
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() -> string"""
    invalid_pattern_0 = InvalidPattern(None)
    s = invalid_pattern_0.__str__()
    assert type(s) in [str, unicode]

# Generated at 2022-06-26 02:25:00.504820
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    example_error_msg_1 = 'Pattern must use chars in range [a-zA-Z0-9]'
    example_error_msg_2 = 'Not a valid regex'
    exception_1 = InvalidPattern(example_error_msg_1)
    exception_2 = InvalidPattern(example_error_msg_2)
    # The following test is not a good test. It only works if the
    # implementation uses the format string (which the implementation
    # might not do in the future).
    assert (str(exception_1) == 'Invalid pattern(s) found. ' +
            example_error_msg_1)
    assert (str(exception_2) == 'Invalid pattern(s) found. ' +
            example_error_msg_2)


# Generated at 2022-06-26 02:25:03.403805
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Calling __str__of an InvalidPattern object should return a str object
    exc = InvalidPattern('msg')
    s = str(exc)
    assert isinstance(s, str)


# Generated at 2022-06-26 02:25:05.112202
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    instance = InvalidPattern("Error msg")
    str = instance.__str__()


# Generated at 2022-06-26 02:25:09.084485
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalid_pattern_0 = InvalidPattern("Invalid pattern(s) found. %(msg)s")
    invalid_pattern_0._preformatted_string = u"Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    invalid_pattern_0.__dict__["msg"] = "Invalid pattern(s) found. %(msg)s"
    unicode_obj_0 = unicode(invalid_pattern_0)
    assert unicode_obj_0 == "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"


# Generated at 2022-06-26 02:25:12.332673
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a unicode object."""
    # __str__ of InvalidPattern should return a unicode object.
    exception = InvalidPattern("message")
    # __str__ must return a str.
    assert isinstance(str(exception), str)


# Generated at 2022-06-26 02:25:19.063986
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Create a new InvalidPattern object
    InvalidPattern_obj_0 = InvalidPattern("This is a test message")
    # Call method __unicode__ of InvalidPattern with arg InvalidPattern_obj_0
    InvalidPattern___unicode___call_result_0 = InvalidPattern_obj_0.__unicode__()
    # Assert that InvalidPattern___unicode___call_result_0 equals "This is a test message"
    assert InvalidPattern___unicode___call_result_0 == "This is a test message"

# Generated at 2022-06-26 02:25:26.215427
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.trace import mutter

    mutter("Testing InvalidPattern.__unicode__")
    # Testing constructor
    invalid_pattern_0 = InvalidPattern("string")
    # 'str' is the closest to 'unicode' here that we can get in Python 2
    __expected = str("Unprintable exception InvalidPattern: dict={}, fmt=%(msg)s, error=None")
    __result = invalid_pattern_0.__unicode__()
    assert __expected == __result


# Generated at 2022-06-26 02:25:28.736833
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern('test_msg')
    except InvalidPattern as e:
        assert str(e) == ('Invalid pattern(s) found. test_msg')