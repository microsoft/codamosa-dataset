

# Generated at 2022-06-26 02:15:48.853564
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from StringIO import StringIO

    from bzrlib.tests import TestCase

    class TestableInvalidPattern(InvalidPattern):
        _fmt = 'some text for %(var_0)s with %(var_1)d'

    e = TestableInvalidPattern(var_0='a', var_1=2)
    expected = """Unprintable exception TestableInvalidPattern:
dict=%r, fmt='some text for %(var_0)s with %(var_1)d', error=None""" \
        % e.__dict__
    TestCase().assertEqualDiff(expected, str(e))



# Generated at 2022-06-26 02:16:00.385651
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex()
    var_0._real_regex = None
    def _mock_re_compile(arg_0, arg_1=None, arg_2=0):
        return arg_0
    _real_re_compile = _mock_re_compile
    var_0._regex_args = (
        ['bzr.*'],
    )
    var_0._regex_kwargs = {
    }
    var_1 = var_0.__getattr__('split')
    var_2 = ['bzr.*']
    assert var_1 == var_2


# Generated at 2022-06-26 02:16:06.614952
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = install_lazy_compile()
    var_2 = lazy_compile('\\w+', 0)
    var_3 = var_2.search('f')
    if var_3 != None:
        return 0
    return 1


# Generated at 2022-06-26 02:16:12.569167
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import _dont_use_this_
    try:
        test_case_0()
    except TypeError:
        # expected exception
        _dont_use_this_.unused_attribute_warnings = 1
    else:
        raise AssertionError

if __name__ == '__main__':
    test_InvalidPattern___unicode__()

# Generated at 2022-06-26 02:16:16.909112
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_2 = LazyRegex(())
    var_3 = var_2.__getattr__('_regex_args')
    try:
        var_2.__getattr__('_real_regex')
        assert False
    except AttributeError:
        pass
    var_4 = LazyRegex((), {'x':3})
    var_4.__getattr__('_regex_kwargs')['x'] = 4


# Generated at 2022-06-26 02:16:20.033520
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test gettext message"""
    try:
        raise InvalidPattern('pattern has invalid data')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. pattern has invalid data'


# Generated at 2022-06-26 02:16:22.337791
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    pass # tested above


# Generated at 2022-06-26 02:16:23.651045
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    obj = InvalidPattern('foo')
    got = obj.__unicode__()
    want = u'Invalid pattern(s) found. foo'


# Generated at 2022-06-26 02:16:28.882010
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('error')
    var_1 = var_0.__str__()
    assert var_1 == 'Invalid pattern(s) found. error'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:16:36.477618
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() -> unicode"""

    # This is a dummy function for use with coverage testing.
    # It is used to test that the __unicode__ method was executed.
    # The only reason gettext is used is to check that it is called in
    # the InvalidPattern.__unicode__ method.
    gettext = InvalidPattern._get_format_string

    # Test that method is called when string is used as unicode string.
    str_0 = InvalidPattern("Dummy string")
    unicode_0 = unicode(str_0)
    gettext()

    # Test that method is called when string is used as a str string.
    str_0 = InvalidPattern("Dummy string")
    str_1 = str(str_0)
    gettext()

    # Test that method is called when string is used as

# Generated at 2022-06-26 02:16:50.156962
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from smtplib import SMTPException
    var_0 = InvalidPattern(SMTPException)
    try:
        var_0._format()
    except SMTPException:
        pass


# Generated at 2022-06-26 02:16:53.268889
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method LazyRegex.__setstate__"""
    var_0 = lazy_compile()
    var_0.__setstate__({})


# Generated at 2022-06-26 02:17:05.881831
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # var_0 is a LazyRegex
    var_0 = LazyRegex()
    # var_0 is a LazyRegex
    var_0 = LazyRegex()
    # var_1 is a LazyRegex
    var_1 = LazyRegex()
    # var_2 is a LazyRegex
    var_2 = LazyRegex()
    # var_3 is a LazyRegex
    var_3 = LazyRegex()
    # var_4 is a LazyRegex
    var_4 = LazyRegex()
    # var_5 is a LazyRegex
    var_5 = LazyRegex()
    # var_6 is a LazyRegex
    var_6 = LazyRegex()
    # var_7 is a LazyRegex
    var_

# Generated at 2022-06-26 02:17:08.681977
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    obj = lazy_compile()
    obj.__setstate__({})


# Generated at 2022-06-26 02:17:12.887216
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test case for method __str__ (line 157).
    var_41 = InvalidPattern(None)

# Generated at 2022-06-26 02:17:25.190452
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # This test is for the case when preformatted string is used.
    e = InvalidPattern("x")
    # preformatted string is used
    assert e._format() == "x"
    # preformatted string is used
    assert str(e) == "x"
    assert e.__str__() == "x"
    assert e.__unicode__() == u"x"
    assert e.__repr__() == "InvalidPattern(x)"
    assert e.__eq__(e)
    # preformatted string is used, and there is no format string
    assert e._get_format_string() is None

    e = InvalidPattern("x")
    e._preformatted_string = "y"
    # preformatted string is used
    assert e._format() == "y"
    # preformatted string

# Generated at 2022-06-26 02:17:31.198166
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()
    var_0.msg = "this is a test message"
    var_1 = var_0.__unicode__()
    var_2 = u'this is a test message'
    assert var_1 == var_2



# Generated at 2022-06-26 02:17:38.616386
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern("")
    var_1._preformatted_string = u"a"
    var_2 = var_1._get_format_string()
    var_3 = var_1._format()
    # FIXME: No var_4
    var_5 = var_1.__unicode__()
    assert var_5 == u"a"
    var_5 = var_1.__str__()
    assert var_5 == "a"
    var_5 = var_1.__repr__()
    assert var_5 == "InvalidPattern(a)"


# Generated at 2022-06-26 02:17:42.918523
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Calling function '__str__' of class 'InvalidPattern'
    assert 'Invalid pattern' in str(InvalidPattern(msg='Invalid pattern(s) found. '))


# Generated at 2022-06-26 02:17:50.472677
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    msg = 'abc'
    exc = InvalidPattern(msg)
    try:
        exc.__str__()
    except TypeError:
        # Old gettext
        raise TestNotApplicable("gettext.gettext can't be used without args")
    except UnicodeDecodeError:
        # No default encoding
        import locale
        raise TestNotApplicable("locale.setlocale() not called")

# Generated at 2022-06-26 02:17:56.710224
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    raise InvalidPattern('foo')


# Generated at 2022-06-26 02:18:09.899669
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_stdout_encoding
    msg = "foo"
    e = InvalidPattern(msg)
    # e._fmt is None, so no format string found.
    assert e.__unicode__() == u"Unprintable exception InvalidPattern: dict={'msg': 'foo'}, fmt=None, error=None"
    # set e._fmt
    e._fmt = "%(msg)s"
    assert e.__unicode__() == u"foo"
    # set e._fmt and e._preformatted_string
    e._fmt = "bar %(msg)s"
    e._preformatted_string = "message"
    assert e.__unicode__() == u"message"
    #

# Generated at 2022-06-26 02:18:12.728303
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = LazyRegex(('a', 'b', 'c',))
    assert var_1.__getattr__('d') == 'e'


# Generated at 2022-06-26 02:18:25.831202
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # test 1:
    var_1 = InvalidPattern('test1')
    var_1.msg = 'test2'
    assert str(var_1) == 'test2', '__unicode__ returned an invalid value'
    var_1._preformatted_string = 'test3'
    assert str(var_1) == 'test3', '__unicode__ returned an invalid value'
    var_1._fmt = 'test4'
    var_1.foo = 'bar'
    import bzrlib.i18n
    orig_gettext = bzrlib.i18n.gettext
    bzrlib.i18n.gettext = lambda x: x
    assert str(var_1) == 'test4', '__unicode__ returned an invalid value'

# Generated at 2022-06-26 02:18:27.156555
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('foo')


# Generated at 2022-06-26 02:18:29.259511
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    expr_0 = lazy_compile()
    expr_1 = expr_0.__getattr__()


# Generated at 2022-06-26 02:18:34.034947
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Create a new instance and assign to a local variable
    var_0 = InvalidPattern("")
    # The output of the call to __str__ should be a string
    assert isinstance(var_0.__str__(), str)

# vim:et:ts=4:sw=4:et

# Generated at 2022-06-26 02:18:35.614639
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    x = InvalidPattern('foo')
    r = repr(x)
    assert r == 'InvalidPattern(foo)'



# Generated at 2022-06-26 02:18:39.071364
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_1 = LazyRegex()
    var_1.__setstate__({
        "args": (),
        "kwargs": {},
        })

if __name__ == '__main__':
    test_case_0()
    test_LazyRegex___setstate__()

# Generated at 2022-06-26 02:18:39.825357
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:18:48.280641
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('')
    assert_equal(var_1.__str__(), '')


# Generated at 2022-06-26 02:18:55.570809
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from StringIO import StringIO
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        instance = InvalidPattern('Message: ')
        buf = StringIO()
        _old_stdout = sys.stdout
        sys.stdout = buf
        instance.__unicode__()
        sys.stdout = _old_stdout
        value = buf.getvalue()
    finally:
        sys.stderr = old_stderr


# Generated at 2022-06-26 02:18:58.524333
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('a')
    var_0._preformatted_string = 'b'
    var_1 = (var_0 == InvalidPattern('a'))
    assert var_1

# Generated at 2022-06-26 02:19:01.135413
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern("")
    assert var_1.__str__() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:19:07.356156
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from cStringIO import StringIO
    from bzrlib.i18n import gettext
    import sys

# Generated at 2022-06-26 02:19:15.867790
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    expected_0 = u'Invalid pattern(s) found. ' + \
        u'Patterns must be defined. ' + \
        u'See "bzr help patterns".'
    actual_0 = InvalidPattern('Patterns must be defined. ' + \
        'See "bzr help patterns".').__unicode__()
    if actual_0 != expected_0: raise AssertionError("expected " +
        repr(expected_0) + " but got " + repr(actual_0))


# Generated at 2022-06-26 02:19:16.827084
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:19:22.536510
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile()
    #var_1 =
    var_0.match("b", "b")
    #var_2 =
    var_0.match("b", "b").span()
    #var_3 =
    var_0.match("b", "b").span()[0]
    #var_4 =
    var_0.match("b", "b").span()[1]


# Generated at 2022-06-26 02:19:26.232669
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ returns unicode object"""
    e = InvalidPattern(u'msg')
    ex = 'msg'
    res = e.__unicode__()
    assert(ex == res)
    e = InvalidPattern('msg')
    res = e.__unicode__()
    assert(ex == res)


# Generated at 2022-06-26 02:19:27.468191
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    a = InvalidPattern('msg')
    assert str(a) == 'msg'

# Generated at 2022-06-26 02:19:40.116286
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern_0 = r'\d+'
    pos_0 = re.compile(pattern_0)
    # Extract the first line of the error message.
    pos_1 = str(pos_0).splitlines()[0]
    pattern_1 = 'invalid group reference'
    pos_2 = pattern_1 in pos_1
    # The first line of the error message contains the string
    # 'invalid group reference'.
    assert(pos_2)



# Generated at 2022-06-26 02:19:41.119505
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("")


# Generated at 2022-06-26 02:19:45.640020
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    p = InvalidPattern('foobar')
    # __unicode__ is not implemented (no _get_format_string)
    assert unicode(p) == u'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r' % (p.__dict__, getattr(p, '_fmt', None), None)

# Generated at 2022-06-26 02:19:47.374327
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    var_2 = str(var_0)


# Generated at 2022-06-26 02:19:55.199830
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    if sys.version_info[0] == 2:
        fmt = "RegExp(%r) is invalid: %s"
    else:
        fmt = "RegExp(%s) is invalid: %s"
    # 1.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no __init__ method.
    # Note: 'InvalidPattern' has no

# Generated at 2022-06-26 02:19:59.821554
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(None)
    try:
        var_0._format()
    except Exception as exc:
        assert isinstance(exc, ValueError)
    else:
        raise AssertionError("no exception raised")



# Generated at 2022-06-26 02:20:03.965174
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'testmsg'
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        if str(e) != msg:
            raise AssertionError('Expected "%s" but got "%s"' % (msg, str(e)))


# Generated at 2022-06-26 02:20:04.886240
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    pass


# Generated at 2022-06-26 02:20:09.597983
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_4 = InvalidPattern('Unprintable exception InvalidPattern: dict={}, '
                           'fmt=%(msg)s, error=None')
    try:
        var_4.__str__()
    except Exception as exc:
        if (not isinstance(exc, NotImplementedError)):
            raise AssertionError


# Generated at 2022-06-26 02:20:12.321881
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_obj = InvalidPattern()
    assert var_obj._format() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:20:21.003189
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():

    # Setup
    e = InvalidPattern('message')
    e._preformatted_string = 'message'

    # Invoke
    actual = e.__unicode__()

    # Verify
    expected = u'message'
    assert actual == expected


# Generated at 2022-06-26 02:20:29.894432
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern("%(msg)s")
    var_0.msg = "msg"
    var_0.__dict__["_preformatted_string"] = "1"
    var_0.__dict__["_fmt"] = _fmt
    var_1 = var_0._get_format_string()
    assert var_1 == 'Invalid pattern(s) found. msg'
    try:
        var_2 = str(var_0)
    except UnicodeDecodeError:
        var_2 = ''
    assert var_2 == 'Invalid pattern(s) found. msg'


# Generated at 2022-06-26 02:20:33.217596
# Unit test for method __str__ of class InvalidPattern

# Generated at 2022-06-26 02:20:36.280156
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(InvalidPattern())
    test_InvalidPattern___str__var_0 = var_0
    test_InvalidPattern___str__var_0


# Generated at 2022-06-26 02:20:37.256620
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass


# Generated at 2022-06-26 02:20:46.237639
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Create an instance of class InvalidPattern
    var_0 = InvalidPattern('test_msg')
    assert isinstance(var_0, InvalidPattern)
    assert isinstance(var_0, ValueError)
    # Call method __unicode__ from class InvalidPattern on instance var_0
    var_1 = var_0.__unicode__()
    f_var_1 = type(var_1)
    assert f_var_1 is unicode
    # Call method __str__ from class InvalidPattern on instance var_0
    var_2 = var_0.__str__()
    f_var_2 = type(var_2)
    assert f_var_2 is str
    # Call method __repr__ from class InvalidPattern on instance var_0
    var_3 = var_0.__repr__()

# Generated at 2022-06-26 02:20:47.418699
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    test_data_0 = InvalidPattern(1)


# Generated at 2022-06-26 02:20:57.319851
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('msg')
    test_value_1 = var_0
    test_value_2 = 'Invalid pattern(s) found. msg'
    test_value_3 = u'Invalid pattern(s) found. msg'
    var_4 = test_value_1 == test_value_2
    var_5 = test_value_1 == test_value_3
    var_6 = test_value_1 != test_value_2
    var_7 = test_value_1 != test_value_3
    var_8 = str(test_value_1)
    var_9 = unicode(test_value_1)
    var_10 = var_8 == test_value_2
    var_11 = var_8 != test_value_2
    var_12 = var_9 == test_value_

# Generated at 2022-06-26 02:21:07.961083
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    # test with a preformatted message
    error = InvalidPattern('This is an error')
    expected_string = "This is an error"
    ustring = unicode(error)
    assert(ustring == expected_string), "Expected: %s, got %s" % (expected_string, ustring)
    # test with an error message with interpolation
    error = InvalidPattern(gettext('This is %s'))
    error._preformatted_string = 'This is an error'
    expected_string = "This is an error"
    ustring = unicode(error)
    assert(ustring == expected_string), "Expected: %s, got %s" % (expected_string, ustring)

# Generated at 2022-06-26 02:21:09.122502
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    test_case_0()
    a = InvalidPattern('')
    assert isinstance(a.__unicode__(), unicode)


# Generated at 2022-06-26 02:21:18.763189
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex()
    assert var_0._real_regex is None
    assert var_0._compile_and_collapse() is None
    assert var_0._real_regex is not None


# Generated at 2022-06-26 02:21:23.104662
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for InvalidPattern.__str__()"""
    # No args
    from bzrlib.i18n import gettext
    inv = InvalidPattern(gettext(u"testing"))
    expected = gettext("testing")
    actual = inv.__str__()
    assert actual == expected

# Generated at 2022-06-26 02:21:25.299501
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    assert var_0.__str__() == 'msg'

# Generated at 2022-06-26 02:21:37.129148
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib._fixtures import (
        TransportServerGlobalFixture,
        )
    from bzrlib import (
        branch as _mod_branch,
        commands,
        errors,
        )
    from bzrlib.tests import (
        fixture_setup,
        test_server,
        )
    from bzrlib.tests.per_interactor import (
        TestCaseWithInteractor,
        )
    from bzrlib.transport import (
        memory,
        )

    class TestCaseWithoutInteractor(TestCaseWithInteractor):

        def setUp(self):
            self.old_interactor = self.overrideAttr(commands, '_interactor',
                                                    None)
            self.branch_count = 0
            self._server = None
            TestCaseWith

# Generated at 2022-06-26 02:21:38.056466
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    case_0 = InvalidPattern("")

# Generated at 2022-06-26 02:21:44.876373
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import _gettext_noop
    from bzrlib.i18n import _gettext_set_output_charset
    from bzrlib.i18n import gettext_lazy
    from bzrlib.i18n import ustr
    import bzrlib.errors
    from bzrlib.lazy_regex import InvalidPattern
    _gettext_set_output_charset('utf-8')
    # Check that InvalidPattern._get_format_string() calls gettext.
    e = InvalidPattern(msg='abc')
    assert isinstance(e, bzrlib.errors.BzrError)
    e = InvalidPattern('abc')

# Generated at 2022-06-26 02:21:46.124450
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern( 'msg' )


# Generated at 2022-06-26 02:21:48.219312
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = "Pattern error"
    var_1 = InvalidPattern(msg)
    assert str(var_1) == msg



# Generated at 2022-06-26 02:21:50.700686
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    inst = InvalidPattern(str())
    # __unicode__ should return unicode
    assert(type(inst.__unicode__()) == unicode)


# Generated at 2022-06-26 02:21:53.389345
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(msg='Testing __str__')
    assert var_0.__str__() == 'Testing __str__'


# Generated at 2022-06-26 02:22:08.495271
# Unit test for method __str__ of class InvalidPattern

# Generated at 2022-06-26 02:22:09.968334
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = str(InvalidPattern('foo'))

# Generated at 2022-06-26 02:22:10.894690
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()
    return

# Generated at 2022-06-26 02:22:13.783003
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    inst_0 = InvalidPattern('')
    expected = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert inst_0.__str__() == expected


# Generated at 2022-06-26 02:22:15.910629
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("foo")
    var_3 = var_0.__str__()


# Generated at 2022-06-26 02:22:17.866290
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = lazy_compile()


# Generated at 2022-06-26 02:22:19.245722
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(None)


# Generated at 2022-06-26 02:22:22.246298
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex()
    try:
        var_0.__getattr__
    except AttributeError:
        pass



# Generated at 2022-06-26 02:22:28.365742
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import unittest
    foo = InvalidPattern(None)
    # Create an instance of a subclass of InvalidPattern
    class _TestInvalidPattern(InvalidPattern):
        def __init__(self, *args):
            InvalidPattern.__init__(self, *args)
            self._preformatted_string = 'bogus message'
    foo = _TestInvalidPattern(None)
    # Create an instance of a subclass of InvalidPattern that is hard to
    # convert to unicode
    class _TestInvalidPatternNoFmt(InvalidPattern):
        def __init__(self, *args):
            InvalidPattern.__init__(self, *args)
            self.not_a_string = object()
    foo = _TestInvalidPatternNoFmt(None)
    # Create an instance of a subclass of InvalidPattern where we throw
    # an error

# Generated at 2022-06-26 02:22:32.236296
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'test message'
    pattern_error = InvalidPattern(msg)
    if pattern_error.__unicode__() == msg:
        pass # ok
    else:
        raise AssertionError


# Generated at 2022-06-26 02:22:38.531118
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass # No unit test available


# Generated at 2022-06-26 02:22:46.047298
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import ui
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_translations_dir
    from bzrlib.i18n import set_language
    from bzrlib.trace import mutter
    try:
        invalidPattern_0 = InvalidPattern()
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        invalidPattern_1 = InvalidPattern(0)
    except TypeError:
        pass
    else:
        raise AssertionError

    mutter("set_language: {}".format('None'))
    set_language(None)
    mutter("set_translations_dir: {}".format('None'))
    set_translations_dir(None)
    invalid

# Generated at 2022-06-26 02:22:49.204502
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    global test_case_0
    test_InvalidPattern___unicode____bindings(
       test_case_0.var_0)


# Generated at 2022-06-26 02:22:52.499860
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg_0 = 'string'
    var_0 = InvalidPattern(msg_0)
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:23:03.692390
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from StringIO import StringIO
    from cStringIO import StringIO as cStringIO
    from io import StringIO as Py3StringIO
    try:
        from StringIO import StringIO as StringIO_v1
    except ImportError:
        StringIO_v1 = None
    if StringIO_v1:
        StringIO_v1_Defined = True
    else:
        StringIO_v1_Defined = False
    try:
        from cStringIO import StringIO as cStringIO_v1
    except ImportError:
        cStringIO_v1 = None
    if cStringIO_v1:
        cStringIO_v1_Defined = True
    else:
        cStringIO_v1_Defined = False

# Generated at 2022-06-26 02:23:05.936347
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Arrange
    ex = InvalidPattern('test')

    # Act
    s = str(ex)

    # Assert
    assert (s is not None)

# Generated at 2022-06-26 02:23:12.181172
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # The method __str__ must return a str.
    # We test that by checking the type of its return value.
    val = InvalidPattern('some message').__str__()
    assertion_type_0 = str
    assert_equal(val.__class__, assertion_type_0)


# Generated at 2022-06-26 02:23:12.806354
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern("msg")


# Generated at 2022-06-26 02:23:15.680730
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Method __str__ of class InvalidPattern
    # Called 1 times.
    # Type of arg #1: Class InvalidPattern
    # Type of arg #2: NoneType
    # Type of arg #3: NoneType
    # Type of arg #4: NoneType
    # Type of arg #5: NoneType
    var_1 = InvalidPattern('')
    var_2 = var_1.__str__()
    assert(var_1)
    assert(var_2 is not None)
    assert(var_2 is not False)
    assert(var_2 != '')


# Generated at 2022-06-26 02:23:17.928390
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:23:33.296124
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import random
    import unittest
    from bzrlib import regex
    for count in xrange(100):
        var_1 = (random.uniform(0, 100),) * random.randrange(0, 100)
        var_2 = {}
        for i in xrange(100):
            var_2[random.uniform(0, 100)] = random.uniform(0, 100)
        var_3 = regex.LazyRegex(var_1, var_2)
        var_4 = unicode(random.uniform(0, 100))
        var_5 = random.uniform(0, 100)
        def func_0(var_6):
            # Function returns var_6
            return var_6

# Generated at 2022-06-26 02:23:35.305552
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'invalid pattern'
    exp_ret_val = u'invalid pattern'
    ret_val = InvalidPattern(msg).__unicode__()
    assert exp_ret_val == ret_val


# Generated at 2022-06-26 02:23:37.034890
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(var_1)


# Generated at 2022-06-26 02:23:39.183204
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    instance = InvalidPattern()
    # verify the output
    assert str(instance) == ""


# Generated at 2022-06-26 02:23:41.702186
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # no test needed, __unicode__ is just a wrapper around _format()
    return

# Generated at 2022-06-26 02:23:47.338411
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    s = "The \u0105 parameter is not a number: '%(non_numeric)s'"
    try:
        raise InvalidPattern(s)
    except InvalidPattern as e:
        assert isinstance(e, InvalidPattern)
        assert isinstance(e, ValueError)
        assert e._get_format_string() is not None
        assert unicode(e) == s


# Generated at 2022-06-26 02:23:48.246157
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pass


# Generated at 2022-06-26 02:23:51.578218
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_00 = InvalidPattern('invalid string ``\\x92``')
    var_00.__unicode__()


# Generated at 2022-06-26 02:23:58.066319
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    regex = LazyRegex()
    regex._real_regex = re.compile(r"(?P<var_0>\w+) = (?P<var_1>\w+)")
    assert regex.flags is None
    assert regex.groups == 2
    assert regex.groupindex == {"var_0": 1, "var_1": 2}
    assert regex.pattern == r"(?P<var_0>\w+) = (?P<var_1>\w+)"


# Generated at 2022-06-26 02:24:01.495249
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # construct object
    try:
        obj = InvalidPattern("msg")
    except:
        obj = InvalidPattern("msg")
    # now check __unicode__
    try:
        obj.__unicode__()
    except:
        pass


# Generated at 2022-06-26 02:24:12.714136
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e_0 = InvalidPattern('message0')
    u_0 = e_0._format()
    if not isinstance(u_0, unicode):
        raise AssertionError()
    u_1 = unicode(u_0)
    if not isinstance(u_1, unicode):
        raise AssertionError()
    return u_1



# Generated at 2022-06-26 02:24:22.773679
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test __unicode__ for class InvalidPattern."""
    def do_test(msg):
        # Test __unicode__ for class InvalidPattern
        # Check unicode output of InvalidPattern when the format string has no
        # placeholders
        ip = InvalidPattern(msg)
        ip._preformatted_string = msg
        ip._fmt = ip._preformatted_string
        unicode(ip)

        # Test __unicode__ for class InvalidPattern
        # Check unicode output of InvalidPattern when the format string has
        # placeholders
        ip = InvalidPattern(msg)
        ip._preformatted_string = msg
        ip._fmt = '%(msg)s'
        unicode(ip)

        # Test __unicode__ for class InvalidPattern
        # Check unicode output of InvalidPattern when we do not have a
       

# Generated at 2022-06-26 02:24:35.413712
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('%(msg)s')
    var_2 = var_1._format()
    var_3 = var_1._get_format_string()
    var_4 = getattr(var_1, '_preformatted_string', None)
    var_5 = var_1.__dict__
    var_6 = 'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r'
    var_7 = (var_1.__class__.__name__, var_5)
    var_8 = var_6 % (var_7, getattr(var_1, '_fmt', None), None)
    var_9 = var_1._format()

# Generated at 2022-06-26 02:24:45.135092
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern
    got_exc_type, got_exc_value = None, None

# Generated at 2022-06-26 02:24:51.012136
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern: __str__"""
    import time, random
    from bzrlib.i18n import gettext

    # We need to monkeypatch gettext before running this test
    def gettext(msg):
        return '%s' % msg

    class TestException(_Exception):
        def _get_format_string(self):
            return '%(msg)s'

    e = TestException('msg')
    assert str(e) == 'msg'
    


# Generated at 2022-06-26 02:24:52.328033
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('msg')


# Generated at 2022-06-26 02:25:00.591559
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Make a simple InvalidPattern
    var_0 = InvalidPattern('msg')
    # Call __str__, which calls _format, returning a 'str' not a 'unicode'
    var_1 = var_0.__str__()
    # Convert to a unicode.
    var_2 = unicode(var_1)
    # Don't care what the content of the exception is, just that it's valid
    # unicode

# This is a unit test for method __unicode__ of class InvalidPattern

# Generated at 2022-06-26 02:25:03.065264
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('error message')
    var_2 = InvalidPattern('another error message')
    assert (bool(var_1 == var_2))


# Generated at 2022-06-26 02:25:04.844601
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('foo')
    var_2 = unicode(var_1)


# Generated at 2022-06-26 02:25:06.855700
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(u'No')
    assert type(var_0.__str__()) is str, \
        "InvalidPattern.__str__ must return a str object"


# Generated at 2022-06-26 02:25:15.694139
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    a_str = "str"
    a_unicode = u"unicode"
    a_other = 123
    var_0 = InvalidPattern(a_str)
    var_1 = InvalidPattern(a_unicode)
    var_2 = InvalidPattern(a_other)

# Generated at 2022-06-26 02:25:18.388913
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('test_case_0')
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:25:19.716966
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # FIXME: implement test
    pass


# Generated at 2022-06-26 02:25:21.633796
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    str_0 = str(var_0)


# Generated at 2022-06-26 02:25:23.676743
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern
    """
    var_0 = InvalidPattern('test')

# Generated at 2022-06-26 02:25:27.361670
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import lazy_gettext as N_

    invalid_pattern = InvalidPattern(N_('not a real message'))
    str(invalid_pattern)



# Generated at 2022-06-26 02:25:30.447604
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = "This is a test"
    var_0 = InvalidPattern(msg)
    string = unicode(var_0)
    assert(string == u'Invalid pattern(s) found. ' + msg)



# Generated at 2022-06-26 02:25:33.847441
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('')
    var_1._preformatted_string = 'foo'
    var_1._fmt = ''
    var_2 = InvalidPattern('')
    var_2._fmt = 'foo'
    var_3 = InvalidPattern('')
    var_4 = InvalidPattern('foo')
    return