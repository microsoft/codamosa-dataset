

# Generated at 2022-06-26 02:15:47.210614
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    obj = InvalidPattern('obj')
    obj._preformatted_string = 'obj'
    assert obj.__unicode__() == 'obj'


# Generated at 2022-06-26 02:15:56.584909
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext

    # make sure a case with a simple message
    x = InvalidPattern('abc')
    assert unicode(x) == gettext(u'abc')

    # make sure a case with a preformatted message
    x = InvalidPattern('abc')
    x._preformatted_string = u'def'
    assert unicode(x) == u'def'



# Generated at 2022-06-26 02:15:59.260810
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    exc = InvalidPattern(u'foo bar')
    assert isinstance(exc.__unicode__(), unicode)


# Generated at 2022-06-26 02:16:07.079749
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exception = InvalidPattern('pattern')
    string = str(exception)
    assert isinstance(string, str), repr(string)
    expected = 'Invalid pattern(s) found. pattern'
    assert string == expected, 'got %s, expected %s' % (repr(string),
                                                       repr(expected))



# Generated at 2022-06-26 02:16:09.818939
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # InvalidPattern.__unicode__() is tested implicitly by
    # test_case_0().
    return



# Generated at 2022-06-26 02:16:12.050740
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():

    # Create an instance of InvalidPattern
    exception = InvalidPattern(msg='Some text')

    # Call method __str__ and check that it's output is correct
    try:
        unicode(exception)
    except NotImplementedError:
        pass

# Generated at 2022-06-26 02:16:14.171191
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    exception = InvalidPattern('msg str')
    expected_string = 'msg str'
    # invoke the __unicode__ method
    actual_string = exception.__unicode__()
    assert actual_string == expected_string


# Generated at 2022-06-26 02:16:21.665492
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import ui
    from bzrlib.ui import _get_formatter
    from bzrlib import osutils
    from bzrlib.i18n import gettext
    _ = gettext
    f = _get_formatter()

    # Test with a format string
    # InvalidPattern._fmt is a format string,
    # so InvalidPattern._get_format_string() returns that string.
    ip = InvalidPattern('msg')
    ip._fmt = 'Invalid pattern(s) found. %(msg)s'
    ip.msg = 'msg'
    assert ip._format() == 'msg'

    # Test with a preformatted message
    # InvalidPattern._fmt is not a format string,
    # so InvalidPattern._get_format_string() returns None.
    ip._preformatted

# Generated at 2022-06-26 02:16:32.566239
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # InvalidPattern.__str__() -> str
    # Calling str() on an instance should return the same object as __str__()
    fmt = 'Invalid pattern(s) found. %(msg)s'
    msg = 'This is a test'
    ip = InvalidPattern(msg=msg)
    ip._fmt = fmt
    expected_str = fmt % {'msg':msg}

    assert expected_str == str(ip)
    assert expected_str == ip.__str__()
    assert expected_str == ip.__unicode__().encode('UTF-8')


if __name__ == '__main__':
    import cProfile
    cProfile.run('re.match("a", "a")')

# Generated at 2022-06-26 02:16:45.096505
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # This comes from re.error
    class AbstractError(Exception):
        pass
    class Error(AbstractError):
        pass
    e = Error("(?P<word>abc|def)+ ends with a * metacharacter", 'breezy')
    try:
        raise e
    except AbstractError:
        pass
    ip = InvalidPattern("Invalid pattern(s) found. ")
    ip._preformatted_string = "%s"
    ip.__dict__['e'] = e
    ip.__dict__['a'] = 'b'
    result = ip.__unicode__() # InvalidPattern('Invalid pattern(s) found. ' + 'abc|def)+ ends with a * metacharacter', 'breezy')

# Generated at 2022-06-26 02:16:52.813815
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'foo'
    e = InvalidPattern(msg)
    assert str(e) == unicode(e)
    assert str(e) == msg


# Generated at 2022-06-26 02:17:05.675032
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # basic non-unicode case
    invalid_pattern_0 = InvalidPattern(str())
    try:
        unicode_0 = invalid_pattern_0.__unicode__()
    except TypeError:
        pass
    else:
        raise AssertionError
    # basic unicode case
    invalid_pattern_0 = InvalidPattern(unicode())
    try:
        unicode_0 = invalid_pattern_0.__unicode__()
    except TypeError:
        pass
    else:
        raise AssertionError
    invalid_pattern_0 = InvalidPattern(None)
    try:
        unicode_0 = invalid_pattern_0.__unicode__()
    except TypeError:
        pass
    else:
        raise AssertionError
    # unicode with a preformatted message
    invalid_pattern_0

# Generated at 2022-06-26 02:17:13.524581
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exc = InvalidPattern('msg')
    # Verify the exception is able to format itself as a string
    assert isinstance(str(exc), str)
    assert isinstance(unicode(exc), unicode)
    # Customize the exceptions message
    exc = InvalidPattern('msg')
    assert 'msg' in str(exc)
    assert 'msg' in unicode(exc)



# Generated at 2022-06-26 02:17:15.052214
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    s = InvalidPattern(msg='invalid').__str__()



# Generated at 2022-06-26 02:17:17.154964
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'foo'
    exception = InvalidPattern(msg)
    assert isinstance(unicode(exception), unicode)
    assert unicode(exception) == msg



# Generated at 2022-06-26 02:17:25.274121
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('test')
    assert str(e) == 'Invalid pattern(s) found. test'
    e = InvalidPattern('test %(msg)s')
    assert str(e) == 'Invalid pattern(s) found. test %(msg)s'
    e._preformatted_string = 'test'
    assert str(e) == 'test'

# test cases to call install_lazy_compile and reset_compile.

# Generated at 2022-06-26 02:17:26.217582
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    b = InvalidPattern('abc')
    assert str(b) == 'abc'

# Generated at 2022-06-26 02:17:36.915346
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    case_data = [
        # This example is taken from an error message Bazaar emitted in
        # the wild.
        (('Invalid pattern(s) found. "' +
          r'^\d+\.\d+\.\d+\.\d+$' +
          '" bad character range'),
         u'Invalid pattern(s) found. '
         u'"^\\d+\\.\\d+\\.\\d+\\.\\d+$" bad character range'),
        ]
    for args, expected in case_data:
        result = str(InvalidPattern(*args))

# Generated at 2022-06-26 02:17:48.838574
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test simple string formatting, InvalidPattern('foo') returns
    # 'foo', InvalidPattern('%s', 'foo') returns 'foo',
    # InvalidPattern('%s%s', 'foo', 'bar') returns 'foobar', and
    # InvalidPattern('%s%s', 'foo', 'bar', 'baz') fails with
    # TypeError.
    # (see http://docs.python.org/lib/built-in-funcs.html#l2h-38
    #  and http://docs.python.org/lib/typesseq-strings.html#l2h-80 )
    assert str(InvalidPattern('foo')) == 'foo'
    assert str(InvalidPattern('%s', 'foo')) == 'foo'

# Generated at 2022-06-26 02:17:55.522053
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = ".*"
    msg = "Invalid pattern: '.*'"
    # verify the class returns an unicode object
    assert isinstance(unicode(InvalidPattern(msg)), unicode)


if __name__ == '__main__':
    test_InvalidPattern___unicode__()

# Generated at 2022-06-26 02:18:02.386743
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __deepcopy__() implicitly tests __str__() because it passes
    # self to TracebackException.__init__.
    import copy
    e = InvalidPattern('error message')
    str(e)
    copy.deepcopy(e)



# Generated at 2022-06-26 02:18:03.964572
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    InvalidPattern().__unicode__()



# Generated at 2022-06-26 02:18:09.161677
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import (
        errors,
        )


# Generated at 2022-06-26 02:18:22.335041
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import re, unittest

    # Empty patterns in a list
    patterns = []
    e = InvalidPattern('Invalid pattern(s)')
    # __unicode__ should return unicode string, but not a str
    u = u'Invalid pattern(s) found. Invalid pattern(s)'
    # __unicode__ should return same string, whether one has been set or not
    s = 'Invalid pattern(s) found. Invalid pattern(s)'
    try:
        # the usual method of re.compile() raises re.error.
        e = re.compile(patterns)
        return False
    except InvalidPattern as e:
        # str() should return same string as __unicode__()
        return e.__unicode__() == e.__str__()



# Generated at 2022-06-26 02:18:24.736298
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # call __getattr__
    #assert False # TODO: implement your test here
    pass # implement your test here


# Generated at 2022-06-26 02:18:34.432413
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern(u"\u4e2d\u56fd")
    if str(e) != "Invalid pattern(s) found. \xe4\xb8\xad\xe5\x9b\xbd":
        raise AssertionError("str not as expected")
    e = InvalidPattern(u"\u4e2d\u56fd")
    e.msg = u"\u4e2d\u56fd"
    if str(e) != "Invalid pattern(s) found. \xe4\xb8\xad\xe5\x9b\xbd":
        raise AssertionError("str not as expected")




# Generated at 2022-06-26 02:18:36.977920
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # unit test for InvalidPattern.__unicode__
    e = InvalidPattern('foo')
    u = unicode(e)
    assert u == 'foo', u

LazyRegex.__doc__ = __doc__

# Generated at 2022-06-26 02:18:47.798442
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_i18n import MultiTestCase

    class TestInvalidPattern(TestCase):

        def test___str__(self):
            error = InvalidPattern(u'')
            # Check whether __str__() is working
            self.assertEquals(error.__str__(), unicode(error).encode('utf-8'))
    return MultiTestCase()



# Generated at 2022-06-26 02:18:58.608448
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """
    The InvalidPattern class holds a (sometimes translated) string.
    The __str__ method should return a string with the message.
    """
    # _format() should return the same string as __str__
    format_str_0 = InvalidPattern('format_str_0')
    assert format_str_0._format() == str(format_str_0)
    # To make sure that the class can be pickled, we check that the
    # exception contains the message and the class name in __str__
    assert 'format_str_0' in str(format_str_0)
    assert 'InvalidPattern' in str(format_str_0)
    # If the class doesn't have a _format attribute we should still
    # be able to return a string

# Generated at 2022-06-26 02:19:01.020082
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    i = InvalidPattern(u'')
    # We will test with a unicode object as a message and by default we should
    # return a 'str' object (not unicode).
    i._preformatted_string = u'a unicode string'
    assert isinstance(str(i), str)
    # TODO: What would we test with a utf8 encoded message?.

# Generated at 2022-06-26 02:19:14.477269
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import bzrlib._lazy_regexes
    v = bzrlib._lazy_regexes.LazyRegex()
    res = v._compile_and_collapse()
    res = v.__getattr__('_regex_attributes_to_copy')
    res = v.__getattr__('_compile_and_collapse')
    res = v.__getattr__('_real_re_compile')
    res = v.__getattr__('_real_regex')


# Generated at 2022-06-26 02:19:17.694501
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    error = InvalidPattern("msg")
    expected_result = "Invalid pattern(s) found. msg"
    assert error.__str__() == expected_result
    assert str(error) == expected_result



# Generated at 2022-06-26 02:19:22.425004
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # simple, with 0 args
    e = InvalidPattern(msg='msg')
    assert type(e) is InvalidPattern
    assert e.msg == 'msg'
    assert str(e) == 'Invalid pattern(s) found. msg'
    u = unicode(e)
    assert type(u) is unicode
    assert u == u'Invalid pattern(s) found. msg'

# Generated at 2022-06-26 02:19:25.516760
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Creating instance for class InvalidPattern
    inst_0 = InvalidPattern('foo')
    # Calling __unicode__
    result_0 = inst_0.__unicode__()
    # Result should be 'foo'
    assert str(result_0) == 'foo'


# Generated at 2022-06-26 02:19:29.050430
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test for method __unicode__( # InvalidPattern) of class InvalidPattern
    # XXX: test/test_regex.py:test_InvalidPattern___unicode__ is disabled until
    # a suitable assertion message is found
    pass #raise TestSkipped('invalid test')


# Generated at 2022-06-26 02:19:37.012890
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # __getattr__ using the default value
    lazy_regex_0 = LazyRegex()
    try:
        lazy_regex_0.__getattr__()
    except TypeError:
        pass
    else:
        raise AssertionError

    # __getattr__ using the default value
    lazy_regex_1 = LazyRegex()
    try:
        lazy_regex_1.__getattr__(attr=None)
    except AttributeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-26 02:19:41.260024
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern(unicode('foo'))
    e._preformatted_string = unicode('bar')
    expected = unicode('bar')
    actual = e.__unicode__()
    assert actual == expected


# Generated at 2022-06-26 02:19:43.616720
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = LazyRegex(('^[0-9]',),{})
    r.match('a')
    return



# Generated at 2022-06-26 02:19:45.958557
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalidpattern_0 = InvalidPattern('')
    unicode_0 = invalidpattern_0.__unicode__()
    assert type(unicode_0) is unicode


# Generated at 2022-06-26 02:19:50.177534
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    instance = InvalidPattern("msg")
    # This will fail if FixedOffset.__str__ does not return a str.
    # It will also fail if FixedOffset.__str__ returns a unicode object.
    # This is easily fixed by adding a __str__ method to FixedOffset.
    assert isinstance(str(instance), str)


# Generated at 2022-06-26 02:20:01.367370
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern(msg='foo message')
    except InvalidPattern as exc:
        # this is an str object
        str_exc = str(exc)
        # this is an unicode object
        unicode_exc = unicode(exc)
        assert isinstance(str_exc, str)
        assert isinstance(unicode_exc, unicode)



# Generated at 2022-06-26 02:20:05.574431
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    class _InvalidPattern(InvalidPattern):
        _fmt = 'the value %(value)d is invalid'
    x = _InvalidPattern(value=42)
    assert isinstance(x.__unicode__(), unicode)

# Generated at 2022-06-26 02:20:10.664351
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalid_pattern_0 = InvalidPattern(str)
    assert str(invalid_pattern_0) == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    invalid_pattern_1 = InvalidPattern(None)
    assert str(invalid_pattern_1) == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:20:12.154422
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:20:17.219108
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__(self) -> unicode

    _fmt strings should be ascii
    """
    from bzrlib.i18n import gettext
    e = InvalidPattern('msg')
    assert e == InvalidPattern('msg')
    assert e != InvalidPattern('other')
    e = InvalidPattern('msg')
    assert e != 'InvalidPattern("msg")'
    assert e != 'msg'



# Generated at 2022-06-26 02:20:20.342912
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    lazy_regex_0 = LazyRegex()
    assertRaises(AttributeError, lazy_regex_0.__getattr__, "group")
    try:
        lazy_regex_0.__getattr__("group")
    except InvalidPattern:
        pass
    assertRaises(AttributeError, lazy_regex_0.__getattr__, "group")


# Generated at 2022-06-26 02:20:25.395497
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    string = gettext('Invalid pattern(s) found. %(msg)s')+'\n'
    e = InvalidPattern('foo')
    assert e.__str__() == string % {'msg':'foo'}


# Generated at 2022-06-26 02:20:36.199406
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext

# Generated at 2022-06-26 02:20:40.038203
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # Input parameters
    # Return type: LazyRegex
    # Return value: None
    lazy_regex_0 = LazyRegex()
    # FIXME
    #assert isinstance(lazy_regex_0.__getattr__('_regex_attributes_to_copy'), list)


# Generated at 2022-06-26 02:20:43.679112
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # InvalidPattern.__str__ -> str
    # Calling function __str__ of class InvalidPattern
    # test for return value
    if (InvalidPattern("msg").__str__() is not None):
        pass
    else:
        raise AssertionError



# Generated at 2022-06-26 02:20:57.280330
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    r = LazyRegex()
    try:
        r.compile
    except AttributeError:
        try:
            r.findall
        except AttributeError:
            try:
                r.finditer
            except AttributeError:
                try:
                    r.match
                except AttributeError:
                    try:
                        r.scanner
                    except AttributeError:
                        try:
                            r.search
                        except AttributeError:
                            try:
                                r.split
                            except AttributeError:
                                try:
                                    r.sub
                                except AttributeError:
                                    try:
                                        r.subn
                                    except AttributeError:
                                        pass

test_case_0()

# Generated at 2022-06-26 02:21:04.635809
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test when string has already been formatted on 'self'
    obj = InvalidPattern("test")
    obj._preformatted_string = "test"
    actual = obj.__str__()
    expected = "test"
    assert actual == expected
    # Test the default
    obj = InvalidPattern("test")
    actual = obj.__str__()
    expected = "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    assert actual == expected


# Generated at 2022-06-26 02:21:11.191479
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Make sure the message is translated
    msg = u'Cannot mix snapshot related keywords with any non-snapshot related keywords'
    error = InvalidPattern(msg)
    assert str(error) == 'Invalid pattern(s) found. Cannot mix snapshot related keywords with any non-snapshot related keywords'

    # And that it works with a non-unicode message.
    msg = 'Cannot mix snapshot related keywords with any non-snapshot related keywords'
    error = InvalidPattern(msg)
    assert str(error) == 'Invalid pattern(s) found. Cannot mix snapshot related keywords with any non-snapshot related keywords'



# Generated at 2022-06-26 02:21:16.887689
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Create an instance of InvalidPattern
    invalidpattern_0 = InvalidPattern("")
    # Call method __unicode__ with parameter "invalidpattern_0" and
    # check that it raises no exceptions and returns the correct value
    unicode(invalidpattern_0)

# Generated at 2022-06-26 02:21:28.774896
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    e = InvalidPattern('a')
    u = unicode(e)
    if u != 'a':
        raise AssertionError("%s != 'a'" % u)
    s = str(e)
    if s != 'a':
        raise AssertionError("%s != 'a'" % s)
    e._preformatted_string = gettext("b")
    u = unicode(e)
    if u != 'b':
        raise AssertionError("%s != 'b'" % u)
    s = str(e)
    if s != 'b':
        raise AssertionError("%s != 'b'" % s)
    e._preformatted_string = 'c'
    u = unicode(e)

# Generated at 2022-06-26 02:21:34.331532
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str object."""
    e = InvalidPattern(u'something')
    s = str(e)
    assert isinstance(s, str)
    assert s == u'something'
    # Test that the base exception has not been overridden
    assert re.error == InvalidPattern

# Generated at 2022-06-26 02:21:38.101573
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = '[]'
    msg = str(re.error('unbalanced square brackets'))
    exception = InvalidPattern(msg)
    result = exception.__unicode__()
    expected = 'Invalid pattern(s) found. ['"'"']] unbalanced square brackets'
    assert result == expected


# Generated at 2022-06-26 02:21:42.387533
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from StringIO import StringIO
    result = StringIO()
    msg = 'This is a test of the emergency broadcast system.  This is only a test.'
    ip = InvalidPattern(msg)
    expected = 'Invalid pattern(s) found. This is a test of the emergency broadcast system.  This is only a test.'
    actual = ip.__unicode__()
    assert actual == expected


# Generated at 2022-06-26 02:21:45.476945
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = u'Invalid regex'
    e = InvalidPattern(msg)
    s = e.__str__()
    assert s == 'Invalid pattern(s) found. Invalid regex'


# Generated at 2022-06-26 02:21:47.973292
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern("msg")
    assert str(e) == "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"


# Generated at 2022-06-26 02:21:55.556319
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.trace import mutter
    mutter('test_InvalidPattern___unicode__: %s', InvalidPattern._fmt)



# Generated at 2022-06-26 02:22:03.049344
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__():

    This is a test of the __str__ method of class InvalidPattern, and is
    intended to be called from a test suite, not directly.
    """
    exception = InvalidPattern(u"e\u258C")
    expected_str = u"Invalid pattern(s) found. \"e\u258C\""
    if str(exception) != expected_str:
        raise AssertionError(
            "InvalidPattern.__str__() problem: expected %r, got %r." \
            % (expected_str, str(exception)))

# Generated at 2022-06-26 02:22:08.664913
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test for InvalidPattern.__str__()
    msg = "Invalid pattern(s) found. p1"
    x = InvalidPattern('p1')
    assert str(x) == msg
    msg = "Unprintable exception InvalidPattern: dict={'msg': 'p2'}, " \
        "fmt=Invalid pattern(s) found. %(msg)s, error=None"
    x = InvalidPattern('p2')
    x._fmt = None
    assert str(x) == msg



# Generated at 2022-06-26 02:22:20.572135
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = 'abc'
    msg = str(re.error('test'))
    e = InvalidPattern(msg)
    e2 = InvalidPattern(msg)
    e3 = InvalidPattern('test2')

    # Test that the format strings is used
    e._fmt = 'Test %(msg)s'
    assert str(e) == 'Test ' + msg
    assert e == e2
    assert not e == e3
    assert e != e3

    # Test that the unicode() function is not called on the values in
    # __dict__ and that the repr() is.
    def fake_unicode(s):
        raise AssertionError('unicode called on %r' % (s,))
    def fake_repr(s):
        return 'repr(%s)' % (s,)
    saved_unicode

# Generated at 2022-06-26 02:22:22.491461
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # called with correct argument
    e = InvalidPattern('msg')
    s = e.__unicode__()



# Generated at 2022-06-26 02:22:24.648290
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('message')
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == u'Invalid pattern(s) found. message'


# Generated at 2022-06-26 02:22:29.475114
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalid_pattern_0 = InvalidPattern()
    assert invalid_pattern_0.__str__() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert type(invalid_pattern_0.__str__()) is str


# Generated at 2022-06-26 02:22:32.570800
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ returns unicode"""
    e = InvalidPattern("foo")
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-26 02:22:34.279614
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    s, msg = '', ''
    e = InvalidPattern(msg)
    assert str(e) == s

# Generated at 2022-06-26 02:22:38.164636
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    instance = InvalidPattern(msg='test')
    assert isinstance(instance.__unicode__(), unicode)
    assert instance.__unicode__() == u'Invalid pattern(s) found. test'



# Generated at 2022-06-26 02:22:45.226910
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    ex = InvalidPattern('some message')
    assert str(ex)



# Generated at 2022-06-26 02:22:49.763012
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    _fmt = 'Invalid pattern(s) found. %(msg)s'
    msg = 'A test message'
    e = InvalidPattern(msg)
    assert str(e) == 'Invalid pattern(s) found. ' + msg


# Generated at 2022-06-26 02:22:58.523143
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern("")
    except InvalidPattern:
        from StringIO import StringIO
        import traceback
        buf = StringIO()
        traceback.print_exc(file=buf)
        value = buf.getvalue()
        assert value.startswith("Traceback (most recent call last)") == True
        assert value.find("Invalid pattern(s) found. ") == True
        assert value.find("Unprintable exception InvalidPattern:") == False
        assert value.endswith("\n") == True


# Generated at 2022-06-26 02:23:07.076179
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    def check(args, kwargs, expected):
        exc = InvalidPattern(args, kwargs)
        observed = str(exc)
        if observed != expected:
            raise AssertionError("%r != %r" % (observed, expected))
    check('0', {}, 'Invalid pattern(s) found. 0')
    check('0', {'a': 1}, "Invalid pattern(s) found. 0")
    checked = False
    try:
        check('%(a)s', {'a': 1}, "Invalid pattern(s) found. 1")
    except KeyError:
        checked = True
    if not checked:
        raise AssertionError("%r != %r" % (observed, expected))



# Generated at 2022-06-26 02:23:12.703910
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must return the exception's error message"""
    e = InvalidPattern('error')
    expected = 'error'
    actual = e.__unicode__()
    assert actual == expected, 'InvalidPattern.__unicode__ returned %s, expected %s' % (actual, expected)


# Generated at 2022-06-26 02:23:15.452953
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Assert that LazyRegex#__getattr__() is working correctly."""
    assert_compile_ok('^-')
    assert_compile_fail('^-', '[')



# Generated at 2022-06-26 02:23:24.282923
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    if sys.version_info[0] < 3:
        msg = 'Unprintable exception InvalidPattern: ' \
            'dict={}, fmt=u\'Invalid pattern(s) found. %(msg)s\', error=None'
    else:
        msg = 'Unprintable exception InvalidPattern: ' \
            'dict={}, fmt=\'Invalid pattern(s) found. %(msg)s\', error=None'
    err = InvalidPattern('Invalid pattern(s) found.')
    assert str(err) == msg


# Generated at 2022-06-26 02:23:28.373843
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from StringIO import StringIO
    out = StringIO()
    i = InvalidPattern('msg')
    i.msg = 'msg\n'
    print >> out, i
    out.seek(0)
    s = out.read()
    assert s == 'Invalid pattern(s) found. msg\n\n'



# Generated at 2022-06-26 02:23:38.948214
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    def __str__():
        try:
            global _fmt
            msg = 'Invalid pattern(s) found. %(msg)s'
            _fmt = msg
            d = dict(_fmt = _fmt)
            s = _fmt % d
            # __str__() should always return a 'str' object
            # never a 'unicode' object.
            return s
        except Exception as e:
            pass # just bind to 'e' for formatting below
        else:
            e = None
        return 'Unprintable exception %s: dict=%r, fmt=%r, error=%r' \
            % (InvalidPattern.__name__,
               dict(_fmt = _fmt),
               _fmt,
               e)

    return __str__()


# Generated at 2022-06-26 02:23:45.119121
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import errors
    e = InvalidPattern('Invalid pattern(s) found. Invalid pattern: .*')
    s = 'Invalid pattern(s) found. Invalid pattern: .*'
    # test for equality
    if e.__unicode__() != s:
        raise AssertionError('actual value was: %s' % (e.__unicode__(),))



# Generated at 2022-06-26 02:23:53.411758
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # this method is only here for coverage of the method.
    lp = InvalidPattern('an error message')
    lp.__unicode__()



# Generated at 2022-06-26 02:23:59.107515
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__()

    Test the __str__ method of InvalidPattern.

    The __str__ method has to return a str (unicode) object.
    """
    ip = InvalidPattern('message')
    # The string is ascii only, so it's safe to use str() on it.
    assert str(ip) == 'Invalid pattern(s) found. message'


# Generated at 2022-06-26 02:24:04.960576
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a ascii str"""
    import bzrlib
    setattr(bzrlib.i18n, 'gettext', lambda s: s)

# Generated at 2022-06-26 02:24:07.062887
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    test_case_0()
# Test cases for function install_lazy_compile

# Generated at 2022-06-26 02:24:14.834583
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__ must raise an exception if _format() fails to do so.
    from bzrlib.i18n import gettext
    # Make sure _format() fails to return a string.
    class InvalidPatternBlind(InvalidPattern):
        def _format(self):
            pass
    ip_blind = InvalidPatternBlind('xx')
    ip_blind._fmt = 'xx'
    # __str__ is not allowed to fail, it must return something.
    assert 'xx' in str(ip_blind)


# Generated at 2022-06-26 02:24:17.553558
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    obj = LazyRegex()
    assert obj.__getattr__('') is None



# Generated at 2022-06-26 02:24:21.392175
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    ip = InvalidPattern('test message')
    assert isinstance(ip.__str__(), str)
    # "get a UnicodeEncodeError if we try to encode the str
    ip.__str__().encode('ascii')



# Generated at 2022-06-26 02:24:24.875713
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('failure')
    # __unicode__() should return a unicode object.
    assert isinstance(unicode(e), unicode)
    # __unicode__() should return a message that contains the string
    # 'failure'.
    assert unicode(e).find('failure') != -1


# Generated at 2022-06-26 02:24:29.649756
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a utf8 string"""
    s = InvalidPattern("msg")
    assert isinstance(s.__str__(), str)
    assert isinstance(s.__unicode__(), unicode)


# Generated at 2022-06-26 02:24:33.541712
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    i = InvalidPattern(msg='msg1')
    s = str(i)
    assert s == 'Invalid pattern(s) found. msg1', s

# Generated at 2022-06-26 02:24:44.669308
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    assert 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'==InvalidPattern('foo').__str__()
    assert 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'==InvalidPattern('').__str__()
    assert 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'==InvalidPattern(None).__str__()
    assert 'baz'==InvalidPattern('foo', msg="bar", _preformatted_string="baz").__str__()

# Generated at 2022-06-26 02:24:48.553961
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern(u'Unprintable Exception')
    # method __unicode__ of class InvalidPattern
    # should return the same value as method __str__ of class InvalidPattern
    assert 'Unprintable Exception' == str(e)
    assert u'Unprintable Exception' == unicode(e)


# Generated at 2022-06-26 02:24:51.679664
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = u'Invalid pattern(s) found. ".*" nothing to repeat'
    e = InvalidPattern(msg)
    u = e.__unicode__()
    # Assert unicode equals
    assert (u == msg)



# Generated at 2022-06-26 02:24:57.047603
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test for all major cases
    msg = 'This is a test message.'
    invalid_pattern_0 = InvalidPattern(msg)
    # Test __str__ returns a 'str' object.
    assert isinstance(invalid_pattern_0.__str__(), str)
    # Test __str__ returns a 'str' identical to the original.
    assert invalid_pattern_0.__str__() == msg



# Generated at 2022-06-26 02:25:07.175064
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    obj = LazyRegex()
    import pickle
    # TODO There are many more cases to test
    # Test __getattr__ for various valid and invalid attribute names
    for attr in ["__copy__", "__deepcopy__", "findall", "finditer", "match",
                 "scanner", "search", "split", "sub", "subn"]:
        obj.__getattr__(attr)
    for attr in [None, 1, 3.14, [], {}]:
        try:
            obj.__getattr__(attr)
            assert False
        except TypeError:
            pass

# Generated at 2022-06-26 02:25:09.766164
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 02:25:13.802556
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # make a LazyRegex object and call __getattr__ on it
    lazy_regex_1 = LazyRegex()
    try:
        lazy_regex_1.xxx
    except AttributeError:
        pass
    else:
        raise AssertionError("expected AttributeError")


# Generated at 2022-06-26 02:25:16.624512
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    lazy_regex_0 = LazyRegex((), {})
    try:
        lazy_regex_0.search(None)
        assert False
    except InvalidPattern:
        assert True


# Generated at 2022-06-26 02:25:20.030598
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    err = InvalidPattern('Invalid pattern found.')
    err._preformatted_string = 'hi'
    assert err.__unicode__() == 'hi'
    assert err.__str__() == 'hi'



# Generated at 2022-06-26 02:25:21.934336
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern(u'Some message')
    e.__unicode__()


# Generated at 2022-06-26 02:25:31.515979
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method InvalidPattern.__unicode__"""
    msg = 'foo'
    exc = InvalidPattern(msg)
    exc._preformatted_string = u'bar'
    expected_unicode_value = exc._preformatted_string
    actual_unicode_value = exc.__unicode__()
    assert expected_unicode_value == actual_unicode_value, \
        "value mismatch"



# Generated at 2022-06-26 02:25:33.257736
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    l = InvalidPattern('msg')
    assert l.__str__() == u'msg'

# vim: set fileencoding=utf-8 :