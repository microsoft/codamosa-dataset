

# Generated at 2022-06-26 02:15:46.517936
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern(u"")
    var_0 = u""


# Generated at 2022-06-26 02:15:48.451212
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exc = InvalidPattern(None)
    assert exc.__str__() == str(exc)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:15:52.405560
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('foo')
    var_1 = var_0._format()
    assert var_1 == u'foo'


# Generated at 2022-06-26 02:15:57.367023
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exc = InvalidPattern('msg')
    exc._fmt = '%(msg)s'

    # test 1
    s = str(exc)
    assert s == 'msg', s



# Generated at 2022-06-26 02:16:00.536938
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test if the format string is invalid
    a = InvalidPattern('test')
    # The corrected format string is 'test'.
    assert a.__unicode__() == 'test', 'Corrected format string is not "test".'


# Generated at 2022-06-26 02:16:06.843080
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_1 = LazyRegex()
    var_2 = {'args':((),), 'kwargs':{}}
    var_3 = var_1.__setstate__(var_2)
    assert(var_3 == None)


# Generated at 2022-06-26 02:16:10.466887
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """This tests the __str__ method of InvalidPattern"""
    # Set up some variables to use in the test.
    expected_result = 'Invalid pattern(s) found. "abc" bad character range'
    var_0 = InvalidPattern('"abc" bad character range')
    assert var_0.__str__() == expected_result


# Generated at 2022-06-26 02:16:20.438972
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():

    # Test case LazyRegex.__getattr__.0
    test_case_0()



if __name__ == '__main__':
    import unittest

    import doctest
    doctest.testmod()

    suite = unittest.TestSuite()

    suite.addTest(doctest.DocTestSuite())
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(
        doctest.DocFileTest('bug_470201-LazyRegex.test')))


    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-26 02:16:27.768473
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = u'not a valid value'
    var_0 = InvalidPattern(msg)
    var_1 = var_0._format()
    var_2 = 'not a valid value'
    var_3 = (var_1 == var_2)
    assert var_3


# Generated at 2022-06-26 02:16:33.875471
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from unittest import TestCase
    from pickle import dumps, loads
    test_case_0()
    test_case_1 = lazy_compile('.*', 0)
    test_case_3 = test_case_1.__getstate__()
    test_case_1.__setstate__(test_case_3)
    test_case_2 = test_case_1.search('Greetings, program!')
    test_case_4 = test_case_2.group(0)
    assert test_case_4 == 'Greetings, program!'


# Generated at 2022-06-26 02:16:46.395179
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # This is a special case, where re.error is raised.
    _re_compile_replace_0 = re.compile
    _re_compile_replace_1 = re.error
    _re_compile_replace_2 = InvalidPattern

# Generated at 2022-06-26 02:16:55.829362
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    def __str__():
        pass
    msg = "test"
    var_0 = InvalidPattern(msg)
    var_1 = var_0._format()
    var_2 = var_1 % dict()
    var_3 = unicode(var_2)
    def _get_format_string():
        return "test"
    var_4 = [var_0]
    var_5 = dict(msg=msg)
    var_6 = var_1 % var_5
    var_7 = unicode(var_6)
    return None



# Generated at 2022-06-26 02:17:04.346591
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    global _fmt
    global msg
    _fmt = ('Invalid pattern(s) found. %(msg)s')
    msg = 'test'
    var_0 = InvalidPattern(msg)
    var_1 = var_0._format()
    var_2 = InvalidPattern._get_format_string(var_0)
    assert var_1 is not None
    assert var_2 is not None
    assert var_1 == u'Invalid pattern(s) found. test'



# Generated at 2022-06-26 02:17:07.077623
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('msg')
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:17:08.471719
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern("")


# Generated at 2022-06-26 02:17:09.931121
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass # Nothing to test


# Generated at 2022-06-26 02:17:14.348521
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('foo')
    var_1 = unicode(var_0)
    # var_1 = u'foo'
    var_2 = str(var_0)
    # var_2 = 'foo'


# Generated at 2022-06-26 02:17:21.455951
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # We cannot use the "lazy_compile" name because it is already bound to the
    # lazy_compile function.
    var_0 = lazy_compile("[a-z]*")
    var_1 = var_0.match("a12bnn")
    var_2 = var_0.group()
    #assert var_1 is None
    assert var_2 == ""


# Generated at 2022-06-26 02:17:26.878962
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    class_0 = InvalidPattern
    var_0 = class_0('foo')
    var_1 = var_0.__str__()
    var_2 = 'Invalid pattern(s) found. foo'
    var_3 = var_1 == var_2
    if(var_3):
        var_4 = "OK"
    else:
        var_4 = "KO"
    # End of test for method __str__ of class InvalidPattern
    return var_4


# Generated at 2022-06-26 02:17:28.494058
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass # No test needed


# Generated at 2022-06-26 02:17:36.422295
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    expected = u'blah'
    s = InvalidPattern(expected)
    result = s.__unicode__()
    if result != expected:
        raise AssertionError('%r != %r' % (result, expected))


# Generated at 2022-06-26 02:17:38.317406
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    test_case_0()



# Generated at 2022-06-26 02:17:46.380174
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__()

    InvalidPattern.__str__()
    Expected result: 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    """
    var_5 = InvalidPattern()
    var_6 = str(var_5)
    var_7 = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert var_6 == var_7


# Generated at 2022-06-26 02:17:54.302949
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import trace
    try:
        from bzrlib import trace
        e = InvalidPattern('H')
        s = str(e)
    except:
        trace.mutter_exception_tb(None, sys.exc_info()[2])



# Generated at 2022-06-26 02:18:00.113223
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern(None)
    var_0.msg = None
    var_0._preformatted_string = '  '
    var_0.e = None

    test_unicode = unicode(var_0)
    assert test_unicode == u'  ', \
        'InvalidPattern.__unicode__ gives %r, expected %r' % (test_unicode, u'  ')
    # FIXME: We can't compare the return value of str to anything, since it
    # depends on locale.


# Generated at 2022-06-26 02:18:01.658216
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__ should return a str for all versions of python
    # See bug lp:332401
    error = InvalidPattern('invalid pattern')
    str(error)

# Generated at 2022-06-26 02:18:05.091340
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert 'foo' in e.__unicode__()



# Generated at 2022-06-26 02:18:07.101337
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern( )
    str_2 = str(var_1)

# Generated at 2022-06-26 02:18:10.891198
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    pattern = u'ab.*\\b'
    expected = 'abc\\nabcabcabc'
    var_1 = lazy_compile(pattern)
    var_2 = var_1.sub(u'ABC', expected)
    assert var_2 == u'ABC\nABCABCABC'


# Generated at 2022-06-26 02:18:24.058132
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():

    from re import compile
    from re import error

    # Try to get a non-existent attribute
    # This should fail with an AttributeError
    try:
       var_2 = LazyRegex._real_regex
    except AttributeError:
        pass
    else:
        raise AssertionError(
            "Failed to raise AttributeError for non-existent attribute")

    # Test a real regex
    var_3 = compile(u'(?P<name>a)(?P<age>b)')
    var_4 = var_3.search(u'aabb')
    var_5 = var_4.groupdict()
    var_6 = var_3.match(u'aabb')
    # Test that the proxy works

# Generated at 2022-06-26 02:18:32.371063
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method LazyRegex::__getattr__."""
    # Insert your code here ...
    raise NotImplementedError("LazyRegex.__getattr__ not implemented")


# Generated at 2022-06-26 02:18:34.881365
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:18:44.859450
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern(str())
    assert type(var_1.__str__()) is str
    var_2 = InvalidPattern(str())
    var_2._preformatted_string = str()
    assert type(var_2.__str__()) is str


# Generated at 2022-06-26 02:18:50.777138
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    fmt = 'Invalid regular expression: "%(pattern)s" - %(msg)s'
    e = InvalidPattern(fmt % {'pattern': 'asdf', 'msg': 'asdf'})
    str_1 = str(e)
    assert str_1 == 'Invalid regular expression: "asdf" - asdf', str_1
    assert True


# Generated at 2022-06-26 02:18:55.323854
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Check that method __str__ is correctly implemented.

    This is a known bug in python 2.5.
    """
    e = InvalidPattern('test reason')
    if not isinstance(Str(e), str):
        raise ValueError('__str__ must return str')


# Generated at 2022-06-26 02:19:00.293701
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():

    # Test 1
    var_0 = InvalidPattern('')
    var_1 = var_0.__unicode__()
    var_2 = u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert var_1 == var_2
    var_3 = unicode(var_0)
    assert var_3 == var_2


# Generated at 2022-06-26 02:19:01.259747
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass


# Generated at 2022-06-26 02:19:07.408700
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex()
    var_1 = var_0.__getattr__
    var_2 = var_0.__getattr__
    var_3 = var_0.__getattr__
    var_4 = var_0.__getattr__
    var_5 = var_0.__getattr__
    var_6 = var_0.__getattr__
    var_7 = var_0.__getattr__
    var_8 = var_0.__getattr__
    var_9 = var_0.__getattr__
    var_10 = var_0.__getattr__
    var_11 = var_0.__getattr__
    var_12 = var_0.__getattr__
    var_13 = var_0.__getattr__
    var_14 = var

# Generated at 2022-06-26 02:19:11.499959
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    s = InvalidPattern("bzrlib.tests.lazy_regex.test_InvalidPattern___str__")
    s = str(s)


# Generated at 2022-06-26 02:19:18.304684
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = 'abc[abc]'
    unpattern = u'abc[abc]'
    e = InvalidPattern('abc[abc]')
    assert(str(e) == 'Invalid pattern(s) found. "' + pattern + '" ')
    assert(unicode(e) == u'Invalid pattern(s) found. "' + unpattern + u'" ')
    assert(isinstance(unicode(e), unicode))
    assert(isinstance(str(e), str))


# Generated at 2022-06-26 02:19:26.135983
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern"""
    msg = "test"
    var_1 = InvalidPattern(msg)
    # No assert statement, this is a check that __str__ doesn't throw an
    # exception
    var_1.__str__()


# Generated at 2022-06-26 02:19:27.429353
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    raise NotImplementedError('')


# Generated at 2022-06-26 02:19:38.149562
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():

    # test case 0
    var_0 = InvalidPattern("")
    assert str(var_0) == "Invalid pattern(s) found. "

    # test case 1
    var_1 = InvalidPattern("a")
    assert str(var_1) == "Invalid pattern(s) found. a"

    # test case 2
    var_2 = InvalidPattern("abc")
    assert str(var_2) == "Invalid pattern(s) found. abc"

    # test case 3
    var_3 = InvalidPattern("ABC")
    assert str(var_3) == "Invalid pattern(s) found. ABC"

    # test case 4
    var_4 = InvalidPattern("")
    assert str(var_4) == "Invalid pattern(s) found. "

    # test case 5
    var_5 = InvalidPattern("")
   

# Generated at 2022-06-26 02:19:40.511197
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Create an instance of InvalidPattern
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:19:42.304208
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:19:47.209380
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import unittest
    class _test_case(unittest.TestCase):
        """test for method __str__ of class InvalidPattern

        """
        def test__str__(self):
            e = InvalidPattern("abc")
            self.assertEqual(str(e), 'abc')
    _test_case().test__str__()


# Generated at 2022-06-26 02:19:49.174305
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("abcd ef")
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:19:50.949447
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.patiencediff import InvalidPattern
    from StringIO import StringIO
    value = StringIO()
    result = InvalidPattern('msg').__str__()
    assert result == 'Invalid pattern(s) found. msg\n', result


# Generated at 2022-06-26 02:19:52.263594
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile()
    var_1 = var_0.__getattr__(None)


# Generated at 2022-06-26 02:19:53.860813
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(None)
    return var_0.__str__()


# Generated at 2022-06-26 02:20:02.148841
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    __instance = InvalidPattern("")
    # call __str__
    __result = __instance.__str__()
    assert type(__result) == str


# Generated at 2022-06-26 02:20:04.765311
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('A singularly meaningless message')
    # In python3, we get a unicode, not a str
    e_str = str(e)



# Generated at 2022-06-26 02:20:14.514076
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    import re
    import sys

    # Call the __unicode__ method of the InvalidPattern class with
    # the 'self' argument set to the invalid_pattern instance
    try:
        re.compile('((?<')
    except InvalidPattern as e:
        msg = str(e)
        if gettext('Invalid pattern(s) found.') not in msg:
            raise AssertionError("Invalid pattern string not found in %r"
                                 % str(e))
        if _get_regex_error_msg('((?<', sys.maxint) != msg:
            raise AssertionError("%r != _get_regex_error_msg('((?<', sys.maxint)"
                                 % msg)


# Generated at 2022-06-26 02:20:16.461402
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern(None)
    assert var_1.__str__() == 'InvalidPattern()'


# Generated at 2022-06-26 02:20:18.112247
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()
    s = var_0.__unicode__()
    assert type(s) == unicode


# Generated at 2022-06-26 02:20:19.237185
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile()


# Generated at 2022-06-26 02:20:20.710996
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    p = InvalidPattern('msg')
    assert str(p) == 'msg'



# Generated at 2022-06-26 02:20:22.165799
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:20:25.928542
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test whether InvalidPattern.__str__ returns a str rather than unicode"""

    e = InvalidPattern('foo')

    # This will raise a TypeError if __str__ does not return a str
    str(e)



# Generated at 2022-06-26 02:20:28.818768
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()
    actual = var_0.__unicode__()
    expected = None
    assert expected == actual, 'expected == actual'


# Generated at 2022-06-26 02:20:35.097952
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-26 02:20:39.163451
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern("")
    var_1 = u"Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r"
    var_1 = var_1 % ({}, None, None)
    assert var_0.__unicode__() == var_1


# Generated at 2022-06-26 02:20:47.321163
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__()"""
    var_0 = InvalidPattern()
    var_1 = InvalidPattern('blah')
    var_2 = InvalidPattern('blah')
    var_2.msg = 'bleh'
    var_3 = InvalidPattern(_fmt='blah')
    var_4 = InvalidPattern(_fmt='blah')
    var_4.msg = 'bleh'
    var_5 = InvalidPattern.__unicode__(var_4)
    var_6 = InvalidPattern.__str__(var_4)
    var_7 = InvalidPattern.__repr__(var_4)
    var_8 = InvalidPattern.__unicode__(var_2)
    var_9 = InvalidPattern.__str__(var_2)
    var_10 = InvalidPattern.__repr__

# Generated at 2022-06-26 02:20:57.240011
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from mock import Mock
    from bzrlib.i18n import gettext
    gettext._ = lambda self: "test_InvalidPattern"
    var_0 = InvalidPattern()
    var_1 = unicode(var_0)
    var_2 = str(var_0)
    assert var_1=="test_InvalidPattern", 'assert failed'
    assert var_2=="test_InvalidPattern", 'assert failed'
    var_0.unprintable_attribute = Mock()
    var_1 = unicode(var_0)

# Generated at 2022-06-26 02:21:08.203969
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test the case where we have a non-ascii format string
    class InvalidTestCase(InvalidPattern):
        _fmt = u'%(foo)s \u00e9'
    exc = InvalidTestCase()
    exc.foo = u'bar'
    # Python 3+ does not allow __str__ of unicode data
    if str is not unicode:
        encoded = u'bar \u00e9'.encode('utf8')
    else:
        encoded = u'bar \u00e9'
    assert str(exc) == encoded
    assert unicode(exc) == u'bar \u00e9'

    # Test the case where we have an exception in the format string
    class InvalidTestCase(InvalidPattern):
        _fmt = u'%(foo)s %(exc)s'

# Generated at 2022-06-26 02:21:23.359796
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # InvalidPattern.__unicode__() is not implemented.
    # This follows the Python 2.6 implementation.
    fmt = "Invalid pattern(s) found. %(msg)s"
    msg = ""
    if msg is None:
        raise AssertionError('msg is None!')
    message = InvalidPattern(msg)
    message._fmt = fmt

    u = message.__unicode__()
    if u is None:
        raise AssertionError('u is None!')

    # u should be a unicode string.
    if not isinstance(u, unicode):
        raise AssertionError('u is not a unicode string!')

    # Now encode it to utf-8 and test that it matches
    if u != msg:
        raise AssertionError('u != msg!')

# Generated at 2022-06-26 02:21:25.605977
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('string')
    var_2 = var_1.__str__()


# Generated at 2022-06-26 02:21:28.823499
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__(self)"""
    var_1 = InvalidPattern('var_1')
    var_2 = unicode(var_1)


# Generated at 2022-06-26 02:21:34.370183
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile()
    var_0._compile_and_collapse()
    var_0._real_regex = re.compile(r'a')
    var_0.__getattr__('search')
    var_0.__getattr__('__deepcopy__')


# Generated at 2022-06-26 02:21:36.029583
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("teststring")
    var_1 = str(var_0)

# Generated at 2022-06-26 02:21:50.620719
# Unit test for method __str__ of class InvalidPattern

# Generated at 2022-06-26 02:21:55.607473
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = "msg"
    exc = InvalidPattern(msg)
    # Test for equality: The _fmt attribute is equal to '%(msg)s'
    # and '%(msg)s' % {'msg':msg} is equal to 'msg'
    assert exc.__str__() == 'Invalid pattern(s) found. msg'


# Generated at 2022-06-26 02:21:58.675940
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern()
    try:
        # Testing whether it raises the exception or not.
        # If the exception is not raised, it means the method itself
        # is broken.
        raise e
    except:
        pass



# Generated at 2022-06-26 02:22:00.013885
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    int_0 = test_case_0()


# Generated at 2022-06-26 02:22:00.962936
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:22:07.285487
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from io import StringIO
    io = StringIO()
    var_1 = InvalidPattern("Patterns : 'a[a-z]+' and 'b[a-z]+'")
    print(var_1, file=io)
    var_2 = u"Patterns : 'a[a-z]+' and 'b[a-z]+'"
    var_2 = var_2.encode('utf8')
    var_3 = io.getvalue()
    assert var_2 == var_3


# Generated at 2022-06-26 02:22:09.363053
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    var_1 = var_0.__str__()
    var_2 = unicode(var_0)
    assert_equal(var_1, var_2)


# Generated at 2022-06-26 02:22:11.970764
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile('hi')
    var_1 = var_0.match('hi')
    assert var_1.group() == 'hi'


# Generated at 2022-06-26 02:22:18.052040
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = 'no exception'
    msg = 'this is a test message'
    exception = InvalidPattern(msg)
    assert exception._format() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    exception._preformatted_string = pattern
    assert exception._format() == pattern
    exception._fmt = pattern
    assert message == exception._format()



# Generated at 2022-06-26 02:22:21.786700
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    my_exc = InvalidPattern('message')
    my_exc._preformatted_string = 'template'
    my_exc._fmt = 'template %(msg)s'
    assert str(my_exc) == 'template message'


# Generated at 2022-06-26 02:22:28.131977
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:22:33.505657
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex"""
    var_0 = lazy_compile()
    var_0._real_regex = object()
    var_1 = object()
    try:
        var_2 = var_0.var_1
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-26 02:22:34.437839
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # __unicode__()
    pass # expected success


# Generated at 2022-06-26 02:22:39.176398
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    inst = InvalidPattern('abc')
    assert(inst is not None)
    assert(isinstance(inst, InvalidPattern))
    assert(inst._format() == 'abc')

# Case1:
# When the message supplied to InvalidPattern is None,
# the message is changed to ''

# Generated at 2022-06-26 02:22:46.350929
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test case for method __str__ of class InvalidPattern."""
    var_1 = InvalidPattern()
    var_2 = InvalidPattern()
    assert var_1 != var_2
    var_3 = InvalidPattern()
    assert var_1 == var_3
    assert isinstance(var_3, InvalidPattern)
    try:
        var_3._format()
    except Exception:
        pass
    else:
        raise AssertionError('Unprintable exception InvalidPattern: dict={}, fmt={}, error={}'.format(
          var_3.__dict__, getattr(var_3, '_fmt', None),))

# Generated at 2022-06-26 02:22:48.150848
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:22:54.958144
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import gettext, gettext, gettext
    s = gettext('Invalid pattern(s) found. %(msg)s')
    exception = InvalidPattern('msg')
    # This test shows that the formatter takes only the
    # first formatting argument.
    assert(exception.__str__() == s % 'msg')



# Generated at 2022-06-26 02:22:59.156441
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import re
    import sys
    import bzrlib
    
    var_0 = InvalidPattern("a")
    var_1 = var_0.__str__()
    assert(var_1 == "a")


# Generated at 2022-06-26 02:23:01.300825
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # a = InvalidPattern(msg)
    # b = a.__unicode__()
    # return b;
    return


# Generated at 2022-06-26 02:23:04.422829
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('')
    var_1 = var_0
    # Start of user code protected zone for InvalidPattern.__str__ body
    # End of user code	protected zone for InvalidPattern.__str__ body


# Generated at 2022-06-26 02:23:12.800960
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 02:23:16.617270
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(u"foo")
    var_1 = InvalidPattern(u"foo")
    var_2 = InvalidPattern(u"bar")
    assert(var_0.__str__() == u"foo")
    assert(var_0 == var_1)


# Generated at 2022-06-26 02:23:26.504770
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    test_cases = [{
        # TestCase #0
        'inputs': [
            # inputs/arguments for method test_case_0
            ('foo'),
            ('bar'),
        ],
    }, {
        # TestCase #1
        'inputs': [
            # inputs/arguments for method test_case_1
            ('foo'),
            ('bar'),
        ],
        'preconditions': ['test_case_0'],
    }]
    for test_case in test_cases:
        test_case_0()
        test_case_1()


# Generated at 2022-06-26 02:23:34.959789
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.tests.test_i18n import _TestCase
    import __builtin__
    class Mock_gettext(object):
        def gettext(self, message):
            return "mock gettext (%s)" % message
    mock_gettext = Mock_gettext()
    def mock_install():
        __builtin__.__dict__['gettext'] = mock_gettext
    def mock_reset():
        __builtin__.__dict__['gettext'] = gettext

# Generated at 2022-06-26 02:23:38.517272
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__()"""
    try:
        raise InvalidPattern('__str__')
    except InvalidPattern as err:
        print(str(err))



# Generated at 2022-06-26 02:23:41.754958
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert InvalidPattern._get_format_string() == 'Invalid pattern(s) found. %(msg)s'


# Generated at 2022-06-26 02:23:53.028035
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(msg=None)
    # String format with parameters.
    var_1 = InvalidPattern(msg='abc %s xyz')
    # No parameters.
    var_2 = InvalidPattern(msg='abc def')
    try:
        # Missing parameter to format string.
        var_3 = InvalidPattern(msg='abc %s xyz')
        if (1):
            raise AssertionError
    except TypeError:
        pass
    try:
        # Two parameters to format string, but only one argument.
        var_4 = InvalidPattern(msg='%s abc %s')
        if (1):
            raise AssertionError
    except TypeError:
        pass

# Generated at 2022-06-26 02:23:56.039334
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # test 1: default case
    var_1 = InvalidPattern()
    assert var_1.__unicode__() == u"Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"


# Generated at 2022-06-26 02:23:58.262610
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_2 = InvalidPattern('foo')
    var_3 = str(var_2)
    assert(var_3 == 'foo')


# Generated at 2022-06-26 02:23:59.202646
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern(u'')
    var_2 = var_1._format()


# Generated at 2022-06-26 02:24:07.015081
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Run the SUT
    var_0 = InvalidPattern('test')


# Generated at 2022-06-26 02:24:18.801902
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_translations
    from bzrlib.i18n import ugettext
    # set the current locale
    locale_path = None
    locale_name = None
    set_translations(locale_path, locale_name)
    orig_gettext = gettext
    # The following method call creates a local copy of gettext
    # which is bound to the current locale.
    def _(s):
        return gettext(s)
    # check the behaviour of the object
    obj = InvalidPattern("value")
    # get the expected result
    expected = _("Invalid pattern(s) found. value").encode("utf8")
    # call the method
    result = obj.__unicode__()
    # check that the

# Generated at 2022-06-26 02:24:20.419211
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('msg')
    var_2 = str(var_1)


# Generated at 2022-06-26 02:24:22.380609
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    inf = InvalidPattern("lorem ipsum")
    assert isinstance(inf, InvalidPattern)
    assert isinstance(unicode(inf), unicode)

# Generated at 2022-06-26 02:24:24.122288
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('')
    var_1 = str(var_0)
    #assert var_1 == ''


# Generated at 2022-06-26 02:24:30.147313
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Invoke the __unicode__ method of the InvalidPattern object.
    try:
        raise InvalidPattern("Sample error message")
    except InvalidPattern as e:
        print(e.__unicode__())

if __name__ == '__main__':
    test_case_0()
    test_InvalidPattern___unicode__()

# Generated at 2022-06-26 02:24:32.362370
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pass


# Generated at 2022-06-26 02:24:42.669013
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext

    _fmt = 'Test fmt %(msg)s'
    e = InvalidPattern('msg')
    e._fmt = _fmt
    if 'Test fmt msg' != unicode(e):
        raise TestNotApplicable('InvalidPattern.__unicode__() failed')
    if 'Test fmt msg' != str(e):
        raise TestNotApplicable('InvalidPattern.__unicode__() failed')
    _fmt = 'Test tmo msg %(msg)s'
    e._fmt = _fmt
    if 'Test tmo msg msg' != unicode(e):
        raise TestNotApplicable('InvalidPattern.__unicode__() failed')

# Generated at 2022-06-26 02:24:49.929838
# Unit test for method __unicode__ of class InvalidPattern

# Generated at 2022-06-26 02:24:52.281760
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg1')
    if not isinstance(var_0.__str__(), str):
        raise AssertionError



# Generated at 2022-06-26 02:25:01.141038
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'Invalid pattern(s) found. foobar'
    e = InvalidPattern("foobar")
    assert str(e) == msg
    assert unicode(e) == msg

# Generated at 2022-06-26 02:25:02.905383
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    my_exception = InvalidPattern('my message')
    result = my_exception.__str__()


# Generated at 2022-06-26 02:25:05.671470
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('msg')
    str(e)
    e = InvalidPattern('msg')
    e._preformatted_string = 'msg2'
    str(e)


# Generated at 2022-06-26 02:25:10.336331
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # test_case_1
    var_0 = InvalidPattern('Invalid patte')
    var_0._preformatted_string = u'Invalid patte'
    var_1 = unicode(var_0)
    assert(var_1 == u'Invalid patte')


# Generated at 2022-06-26 02:25:13.143538
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalid_pattern = _InvalidPattern(msg='foo')
    assert invalid_pattern.__str__() == 'Unprintable exception _InvalidPattern: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:25:16.299534
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_13 = LazyRegex(())
    # Call method on LazyRegex object (var_13)
    try:
        var_13.__getattr__('__getattr__')
    except ValueError:
        pass


# Generated at 2022-06-26 02:25:27.445749
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import bzrlib.i18n
    # This is the first test for a class that needs to obtain a format string
    # from the i18n module. When this test is run, the i18n module may not be
    # setup yet. So we do a little setup for the test
    #
    # TODO: RBC 20060109 In the future we should have a way to run the test
    # suite from inside bzr, so we can test all i18n-related things. For that
    # we'll need to setup the i18n module.
    #
    # This setup is based on the setup in bzrlib.i18n
    #
    bzrlib.i18n._get_pot_file = lambda x: None
    bzrlib.i18n.gettext = lambda x: x

    # Now

# Generated at 2022-06-26 02:25:31.480208
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    from sys import _getframe
    global _real_re_compile, _real_re_compile
    _real_re_compile = re.compile
    re.compile = lazy_compile if False else None
    test_case_0()
    re.compile = _real_re_compile
