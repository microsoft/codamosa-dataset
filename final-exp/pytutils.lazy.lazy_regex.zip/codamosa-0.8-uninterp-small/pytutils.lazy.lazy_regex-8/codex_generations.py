

# Generated at 2022-06-26 02:15:49.932872
# Unit test for function finditer_public
def test_finditer_public():
    class LazyRegexTest(LazyRegex):
        def __init__(self, compiled, string):
            super(LazyRegexTest, self).__init__()
            self._real_regex = compiled
            self.string = string

        def finditer(self, *args, **kwargs):
            for i in range(10):
                yield (i, )
    r = LazyRegexTest(re.compile('t'), "testtrest")
    result = list(re.finditer(r, r.string))
    assert len(result) == 10
    assert result == [(0, ), (1, ), (2, ), (3, ), (4, ), (5, ), (6, ), (7, ), (8, ), (9, )]

# Generated at 2022-06-26 02:16:02.163320
# Unit test for function finditer_public
def test_finditer_public():
    import re
    from bzrlib.tests import TestCase
    from bzrlib.lazy_regex import LazyRegex
    class MockMatch(object):
        def __init__(self, start, end):
            self.start = start
            self.end = end

    class TestCase(TestCase):
        def assertMatchObjects(self, expected, items):
            self.assertEqual(len(expected), len(items))
            for i, item in enumerate(items):
                self.assertEqual(expected[i].start, item.start)
                self.assertEqual(expected[i].end, item.end)

    class TestFinditerPublic(TestCase):
        def test_lazy_regex(self):
            pattern = LazyRegex(("(a)",))

# Generated at 2022-06-26 02:16:04.830437
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('foo')
    var_0.msg = 'the msg'



# Generated at 2022-06-26 02:16:08.913333
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return unicode if unicode() is defined"""
    err = InvalidPattern('foo bar')
    unicode(err)



# Generated at 2022-06-26 02:16:10.531372
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:16:19.766795
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    _lazy_re_compile__return_va = (object() for _ in range(0))

    def _lazy_re_compile__mock(self, *args, **kwargs):
        for x in _lazy_re_compile__return_va:
            yield x
    _lazy_re_compile__mock_default = object()
    _lazy_re_compile__mock_sentinel = object()
    def _lazy_re_compile__mock_callback(self, *args, **kwargs):
        return _lazy_re_compile__mock_default

# Generated at 2022-06-26 02:16:26.682621
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    c = InvalidPattern('a message')
    s = str(c)
    u = unicode(c)
    assert s == 'Invalid pattern(s) found. a message'
    assert u == 'Invalid pattern(s) found. a message'



# Generated at 2022-06-26 02:16:30.126377
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    expect = "Invalid pattern(s) found. Some message"
    actual = InvalidPattern(
                "Some message").__str__()
    assert expect == actual


# Generated at 2022-06-26 02:16:35.782206
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test with a preformatted message
    f = InvalidPattern("foo")
    f._preformatted_string = "bar"
    f.__unicode__() == "bar"


# Generated at 2022-06-26 02:16:39.186253
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    obj_0 = LazyRegex()
    obj_0.__setstate__({'kwargs': {}, 'args': ()})


# Generated at 2022-06-26 02:16:49.777800
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    test_input = InvalidPattern("test_message")
    actual_result = test_input.__str__()
    expected_result = "Invalid pattern(s) found. test_message"
    assert (actual_result == expected_result), \
        "InvalidPattern.__str__ returned unexpected result."


# Generated at 2022-06-26 02:16:52.813200
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exc = InvalidPattern('msg')
    if not(type(exc.__str__()) is str): raise AssertionError


# Generated at 2022-06-26 02:17:02.159401
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern(msg='foo')
    var_1 = var_0.__unicode__()
    assert type(var_1) == unicode,\
        'The return type of InvalidPattern.__unicode__ was not unicode'
    assert var_1 == u'Invalid pattern(s) found. foo',\
        "The value of InvalidPattern.__unicode__ was incorrect"


# Generated at 2022-06-26 02:17:10.344967
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    def test_func():
        gettext.install('bzr', unicode=True, codeset='ascii')
        test_case_0()
        test_case_1()
        gettext.translation(domain='bzr',
                            localedir=None,
                            fallback=True,
                            codeset=None,
                            names=None)
    def test_case_0():
        test_object = InvalidPattern('test_msg')
        expected = 'Invalid pattern(s) found. test_msg'
        s = str(test_object)
        assert s == expected
    def test_case_1():
        test_object = InvalidPattern('test_msg')
        expected = u'Invalid pattern(s) found. test_msg'
       

# Generated at 2022-06-26 02:17:12.290332
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:17:15.793898
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__()"""
    # No arguments
    msg = InvalidPattern.__unicode__(InvalidPattern('abc'))
    assert msg == u'abc', msg


# Generated at 2022-06-26 02:17:19.838039
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = "msg"
    e = InvalidPattern(msg)
    result = e.__unicode__()
    expected = "'%s'" % msg
    assert result == expected, result


# Generated at 2022-06-26 02:17:26.304752
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    old_locale = None
    msg = 'foo'
    try:
        old_locale = test_case_0()
        test_case_0()
        var_0 = InvalidPattern(msg)
        var_1 = var_0._get_format_string()
        assert var_0.__str__() == str(msg)
    finally:
        if old_locale is not None:
            test_case_0()


# Generated at 2022-06-26 02:17:35.164153
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Assert that the message should contain the original exception message
    # from re.error.
    try:
        # Call the function to be tested.
        var_0 = re._compile('[')
        raise AssertionError('InvalidPattern not raised')
    except InvalidPattern as e:
        # We should see the exception message, as unicode
        # e.msg should contain 'unbalanced bracket'
        assert 'unbalanced bracket' in e.msg


# Generated at 2022-06-26 02:17:38.316506
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('foo')
    var_2 = unicode(var_1)


# Generated at 2022-06-26 02:17:44.607578
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    case_0 = InvalidPattern(msg="Hello World")
    test_case_0()

# Generated at 2022-06-26 02:17:49.700933
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import random
    import string
    import sys
    import types
    import unittest
    # The arguments to this method are created by pythontestcase.
    args = tuple()
    # Create the object to be tested.
    obj = InvalidPattern(*args)
    # Do the tests.
    returned1 = obj.__unicode__()
    assert returned1 is not None
    assert isinstance(returned1, str)
    returned2 = obj.__unicode__()
    assert returned2 is not None
    assert isinstance(returned2, str)
    assert returned1 == returned2

# Generated at 2022-06-26 02:17:56.870092
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    i = InvalidPattern("msg")
    # Ensure the message is printed
    str(i)
    i._preformatted_string = u"<format>"
    # Ensure the preformatted message is printed
    str(i)
    # Ensure __repr__() returns the same as __str__()
    assert (repr(i) == str(i))

# Generated at 2022-06-26 02:18:00.964767
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__"""
    msg = 'foo'
    err = InvalidPattern(msg)
    s = str(err)
    assert s == msg


# Generated at 2022-06-26 02:18:04.362020
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    assert str(var_0) == 'Invalid pattern(s) found. msg'


# Generated at 2022-06-26 02:18:12.530854
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    _fmt = gettext('Invalid pattern(s) found. %(msg)s')
    var_0 = InvalidPattern("message")
    try:
        var_1 = var_0.__unicode__()
    except Exception:
        # import traceback; traceback.print_exc();
        raise AssertionError("InvalidPattern.__unicode__ failed: %r" %
                             (_fmt % {"msg": "message"}, ))
    var_2 = unicode(_fmt % {"msg": "message"})
    var_3 = unicode(_fmt % {"msg": "message"})
    # XXX: var_4 = unicode(str(_UTF8_unicode_escape_encode(_fmt % {"msg": "message"})))

# Generated at 2022-06-26 02:18:16.052621
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()
    var_0._preformatted_string = "test"
    var_1 = str(var_0)
    assert var_1 == "test"


# Generated at 2022-06-26 02:18:17.037929
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:18:21.675660
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('Argument')
    assert (str(var_0) == 'Argument'), 'str(var_0) == \'Argument\''


# Generated at 2022-06-26 02:18:22.891283
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    inst = InvalidPattern(None)


# Generated at 2022-06-26 02:18:29.699959
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Setup
    var_1 = InvalidPattern()
    # Exercise and verify
    assert isinstance(var_1.__str__(), str)



# Generated at 2022-06-26 02:18:36.456385
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("Invalid pattern(s) found. %(msg)s")
    var_1 = var_0._format()
    var_2 = var_0.__unicode__()
    var_3 = var_0.__str__()
    var_4 = var_0.__repr__()
    var_5 = var_0.__eq__(var_0)
    var_6 = var_0._get_format_string()


# Generated at 2022-06-26 02:18:37.699223
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # self = InvalidPattern()
    # No return value.
    return


# Generated at 2022-06-26 02:18:39.965273
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__

    This test is supposed to fail, unless InvalidPattern.__unicode__
    is implemented.
    """
    # this test should not fail
    assert True



# Generated at 2022-06-26 02:18:42.778687
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var = InvalidPattern(msg='')
    var.__str__()


# Generated at 2022-06-26 02:18:43.850260
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    InvalidPattern('foo')


# Generated at 2022-06-26 02:18:49.298424
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # create object
    expected = ''
    var_0 = InvalidPattern(expected)
    expected_len = len(expected)
    # call method
    result = str(var_0)
    # assert result
    assert len(result) == expected_len
    assert result == expected


# Generated at 2022-06-26 02:18:51.443760
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = "Invalid pattern(s) found. "
    e = InvalidPattern(msg)
    assert e.__unicode__() == msg



# Generated at 2022-06-26 02:18:54.325055
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    p = InvalidPattern("test")
    u = str(p)
    assert u == "bzrlib.lazy_regex.InvalidPattern(test)"

# Generated at 2022-06-26 02:18:57.369173
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('foo')
    var_0._fmt = 'foo'
    var_0.msg = 'foo'
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:19:04.408253
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_69 = InvalidPattern()
    var_69._preformatted_string = u'preformatted'
    var_69._fmt = u'%(fmt)s'


# Generated at 2022-06-26 02:19:09.893546
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__: works if _fmt is not set."""
    a = InvalidPattern(None)
    # setattr is needed since __slots__ prevent us setting the attribute
    # directly.
    setattr(a, '_preformatted_string', 'preformatted')
    assert unicode(a) == 'preformatted'


# Generated at 2022-06-26 02:19:18.432921
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext

    msg = unicode('test message')
    err = InvalidPattern(msg)

    # check that __str__ returns the same value as _format
    assert_equal(str(err), err._format())

    # monkey patch _get_format_string to use our message
    def get_format_str(self):
        return gettext(unicode('foo: %(msg)s'))
    err._get_format_string = get_format_str
    assert_equal('foo: %s' % msg, str(err))



# Generated at 2022-06-26 02:19:22.126095
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = re._compile("this is not a regex", 0)
    var_1 = type(var_0).__getattr__(var_0, 'pattern')
    var_2 = var_1 == 'this is not a regex'


# Generated at 2022-06-26 02:19:24.989555
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    a = InvalidPattern('abc')
    str(a)
    a._preformatted_string = 'foo'
    str(a)
    a = InvalidPattern('abc\ndef')
    str(a)



# Generated at 2022-06-26 02:19:26.604985
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(var_0)
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:19:35.487307
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pass
    # Test preparation
    text = 'I have a dream that one day this nation will rise up and live out the true meaning of its creed: "We hold these truths to be self-evident, that all men are created equal."'
    expected_text = 'I have a dream that one day this nation will rise up and live out the true meaning of its creed: "We hold these truths to be self-evident, that all men are created equal."'

    # Test
    try:
        raise InvalidPattern(text)
    except InvalidPattern as instance:
        assert isinstance(instance.__str__(), str)
        assert instance.__str__() == expected_text


# Generated at 2022-06-26 02:19:38.180195
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(u'abc')
    exp_0 = u'abc'
    assert var_0._format() == exp_0


# Generated at 2022-06-26 02:19:48.983830
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test with simple message
    e = InvalidPattern('simple message')
    expected = u'simple message'
    actual = e.__unicode__()
    assert actual == expected, '%r != %r' % (actual, expected)
    # Test with complex unicode message.
    msg = u'simple \uffff message'
    e = InvalidPattern(msg)
    expected = msg
    actual = e.__unicode__()
    assert actual == expected, '%r != %r' % (actual, expected)
    # Test with simple message in utf8
    e = InvalidPattern('simple message')
    e._preformatted_string = 'simple message'.encode('utf8')
    expected = 'simple message'
    actual = e.__unicode__()
    assert actual == expected, '%r != %r'

# Generated at 2022-06-26 02:19:52.351170
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    inst_var_1 = InvalidPattern(None)
    try:
        res_var_1 = unicode(inst_var_1)
    except Exception:
        pass
    else:
        assert res_var_1 is not NotImplemented


# Generated at 2022-06-26 02:20:05.009786
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('Invalid pattern(s) found.')
    var_2 = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    var_3 = var_1._format()
    var_4 = var_2 == var_3
    var_5 = getattr(var_1, '_preformatted_string', None)
    var_6 = var_5 is not None
    var_7 = var_6 or var_4
    return var_7


# Generated at 2022-06-26 02:20:11.482556
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Input parameters
    # Parameter msg:
    msg = ''
    # Instantiate class
    instance = InvalidPattern(msg)
    # Call method __str__
    result = instance.__str__()
    # Asserts
    ok_(isinstance(result, str), "Method result type is incorrect")
    assert 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None' == result, "Method __str__ returned incorrect string"



# Generated at 2022-06-26 02:20:13.206696
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('s')
    var_2 = var_1.__str__()


# Generated at 2022-06-26 02:20:14.177834
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:20:15.779578
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(msg='msg')
    var_1 = var_0._format()


# Generated at 2022-06-26 02:20:18.887542
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        var_0 = InvalidPattern(None)
    except:
        var_0 = InvalidPattern(None)
    var_1 = var_0.__str__()
    var_2 = var_0.__str__()
    var_3 = var_0.__str__()


# Generated at 2022-06-26 02:20:21.197035
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    with ExpectedException(AssertionError, '__str__() not overridden in derived class'):
        InvalidPattern().__str__()


# Generated at 2022-06-26 02:20:23.754372
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('foo')
    var_2 = unicode(var_1)


# Generated at 2022-06-26 02:20:34.582956
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    import pickle
    import re
    invalid_pattern = InvalidPattern(msg=re.error(msg='bad character in group name', pattern='(?P<a>b)', pos=2))
    # Assert that __unicode__ matches _get_format_string
    assert(invalid_pattern.__unicode__() == invalid_pattern._get_format_string() % {'msg': invalid_pattern.msg})
    assert(isinstance(invalid_pattern.__unicode__(), unicode))
    # Assert that __str__ matches _get_format_string
    assert(invalid_pattern.__str__() == gettext(invalid_pattern._get_format_string()) % {'msg': invalid_pattern.msg})

# Generated at 2022-06-26 02:20:36.110105
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_3 = InvalidPattern(None)


# Generated at 2022-06-26 02:20:42.723793
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern("msg")
    # If a UnicodeDecodeError is observed, that means that __str__
    # violates the "str" contract - it should never return a unicode object
    unicode(str(e), 'utf8')


# Generated at 2022-06-26 02:20:44.979136
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    expected = 'Invalid pattern(s) found. "foo" '
    actual = str(InvalidPattern('"foo" '))
    assert expected == actual


# Generated at 2022-06-26 02:20:53.606239
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.osutils import getcwd
    from bzrlib.trace import mutter
    _preformatted_string = 'Invalid pattern(s) found'
    _msg = 'pattern(s) found'
    obj = InvalidPattern(_msg)
    _fmt = obj._fmt
    obj._fmt = None
    _gettext = gettext
    gettext = str
    _dict = obj.__dict__
    obj.__dict__ = {}
    try:
        obj._fmt = '%(msg)s'
        mutter('%r', obj)
    finally:
        obj.__dict__ = _dict
        gettext = _gettext
        obj._fmt = _fmt


# Generated at 2022-06-26 02:20:56.167746
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('')
    # verify __unicode__ returns unicode
    assert isinstance(var_0.__unicode__(), unicode)


# Generated at 2022-06-26 02:21:01.125102
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pattern = InvalidPattern(_fmt='The file "%(filename)s" has an invalid format.')
    # We want to be sure __str__ returns a str, it should not return a
    # unicode object.
    assert isinstance(str(pattern), str), "__str__ did not return a str"



# Generated at 2022-06-26 02:21:03.331226
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_2 = InvalidPattern((123))
    var_3 = var_2.__unicode__()


# Generated at 2022-06-26 02:21:05.102929
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('message')
    var_1 = var_0._format()


# Generated at 2022-06-26 02:21:12.764946
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = _real_re_compile('<html[^>]*>')
    var_2 = _real_re_compile('<[a-zA-Z][-a-zA-Z0-9]*')
    # A normal test, with both branches of the 'if' taken
    var_3 = InvalidPattern('bad pattern')
    try:
        # Should raise InvalidPattern
        var_3 = _real_re_compile('<html[^>]*')
    except InvalidPattern as var_4:
        pass
    # A test with Unicode input, using a method that only
    # takes the 'self' parameter
    var_5 = InvalidPattern('\u9084')

# Generated at 2022-06-26 02:21:17.255535
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile('^[ \t\r\n]*#.*$')
    assert var_0.pattern == '^[ \t\r\n]*#.*$'

# Generated at 2022-06-26 02:21:19.140062
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    arg = InvalidPattern('msg')
    rv = arg.__unicode__()


# Generated at 2022-06-26 02:21:28.434079
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.trace import (
        is_quiet,
        mutter,
        show_warning,
        warning,
        )
    var_0 = InvalidPattern('error')
    var_1 = str(var_0)


# Generated at 2022-06-26 02:21:33.733593
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """
    Test for __unicode__ method of InvalidPattern
    """
    InvalidPattern._fmt = None
    InvalidPattern._preformatted_string = None
    InvalidPattern.msg = None
    # call method
    # assert the call has no errors


# Generated at 2022-06-26 02:21:34.669128
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pass


# Generated at 2022-06-26 02:21:35.986735
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern(str())


# Generated at 2022-06-26 02:21:38.685565
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = ''
    obj = InvalidPattern(msg)
    # __unicode__ must return a unicode object
    assert isinstance(obj.__unicode__(), unicode)


# Generated at 2022-06-26 02:21:40.504419
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert InvalidPattern(str).__unicode__() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'



# Generated at 2022-06-26 02:21:43.690073
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('msg')
    if e.__unicode__() != 'msg':
        raise AssertionError

    e = InvalidPattern('')
    if e.__unicode__() != '':
        raise AssertionError



# Generated at 2022-06-26 02:21:49.201636
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__

    A unicode object is constructed from an InvalidPattern instance and
    returned. This object is equal to the str object returned by str(exception)
    """
    exception = InvalidPattern('foo')
    u = unicode(exception)
    s = str(exception)
    assert u == s, "%s != %s" % (u, s)
    assert 'foo' in s, "%s does not contain foo" % s

# Generated at 2022-06-26 02:21:50.780398
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = InvalidPattern('invalid')
    var_0 = pattern.__unicode__()


# Generated at 2022-06-26 02:21:54.126864
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('Error on converting string to int')
    var_2 = str(var_1)
    assert var_2 == 'Error on converting string to int'


# Generated at 2022-06-26 02:22:08.505970
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.lazy_regex import InvalidPattern
    import gettext

    def _get_format_string(self):
        """Return format string for this exception or None"""
        fmt = getattr(self, '_fmt', None)
        if fmt is not None:
            from bzrlib.i18n import gettext
            return gettext(unicode(fmt)) # _fmt strings should be ascii

    def __unicode__(self):
        u = self._format()
        if isinstance(u, str):
            # Try decoding the str using the default encoding.
            u = unicode(u)

# Generated at 2022-06-26 02:22:10.291111
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # No input
    test_case_0()


# Generated at 2022-06-26 02:22:15.033204
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('')
    var_0._fmt = ''
    try:
        var_0._format()
    except TypeError:
        pass
    var_0._preformatted_string = 44
    var_1 = var_0._format()
    var_1 = str(var_0)


# Generated at 2022-06-26 02:22:19.481908
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() of InvalidPattern"""
    u = InvalidPattern('msg')
    assert str(u) == 'Invalid pattern(s) found. msg'
    assert unicode(u) == u'Invalid pattern(s) found. msg'


# Generated at 2022-06-26 02:22:22.936800
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    __tracebackhide__ = True
    # Check that the call InvalidPattern.__unicode__() returns str object
    assert isinstance(InvalidPattern('').__unicode__(), unicode)


# Generated at 2022-06-26 02:22:24.956638
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    inst = InvalidPattern('msg')
    exp = 'msg'
    # Method __str__ of class InvalidPattern, line 84
    res = inst._format()
    assert(res == exp)

# Generated at 2022-06-26 02:22:27.346542
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('foo')
    assert(str(var_0) == 'foo')


# Generated at 2022-06-26 02:22:29.523288
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method InvalidPattern.__str__ in class InvalidPattern"""
    # XXX: not implemented


# Generated at 2022-06-26 02:22:35.573277
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('msg')

# Generated at 2022-06-26 02:22:45.045345
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = lazy_compile()
    var_2 = var_1.__getattr__('_real_regex')
    var_3 = lazy_compile()
    var_4 = var_3.__getattr__('_regex_args')
    var_5 = lazy_compile()
    var_6 = var_5.__getattr__('_regex_kwargs')
    var_7 = lazy_compile()
    var_8 = var_7.__getattr__('__copy__')
    var_9 = lazy_compile()
    var_10 = var_9.__getattr__('__deepcopy__')
    var_11 = lazy_compile()
    var_12 = var_11.__getattr__('findall')
    var_13 = lazy_compile()
   

# Generated at 2022-06-26 02:22:51.650185
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:22:55.982784
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    inst0 = InvalidPattern(None)
    res = inst0.__unicode__()
    if 'invalid' in res:
        pass # passed
    else:
        raise AssertionError('expected:<invalid> but was:<' + res + '>')


# Generated at 2022-06-26 02:22:59.413401
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern("")
    except InvalidPattern as e:
        assert e.__str__() == 'Invalid pattern(s) found. ""'


# Generated at 2022-06-26 02:23:01.891441
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = u'test'
    exception = InvalidPattern(msg)
    result = unicode(exception)
    assert result == u'Invalid pattern(s) found. test'

# Generated at 2022-06-26 02:23:03.652120
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    InvalidPattern('').__str__()

# class LazyRegex


# Generated at 2022-06-26 02:23:05.237508
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert InvalidPattern('').__unicode__() == u''


# Generated at 2022-06-26 02:23:09.540724
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import unittest, bzrlib.regex
    unittest.TestCase.assertEqual(bzrlib.regex.InvalidPattern, type(bzrlib.regex.InvalidPattern().__unicode__()))
    unittest.TestCase.assertEqual(bzrlib.regex.InvalidPattern, type(bzrlib.regex.InvalidPattern(bzrlib.regex.InvalidPattern().__unicode__()).__unicode__()))

# Generated at 2022-06-26 02:23:10.462202
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('')


# Generated at 2022-06-26 02:23:13.055947
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern
    """
    pass # TODO



# Generated at 2022-06-26 02:23:14.026030
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()



# Generated at 2022-06-26 02:23:20.398727
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Simple test for method
    var_0 = InvalidPattern()


# Generated at 2022-06-26 02:23:24.677427
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_4 = lazy_compile()
    try:
        var_4().groups()
    except AttributeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 02:23:32.049507
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = '[a-zA-Z_][a-zA-Z0-9_]*'
    invalid_pattern = InvalidPattern('"' + pattern + '" ' + 'unbalanced parenthesis')
    try:
        _real_re_compile(pattern)
    except re.error as e:
        invalid_pattern = InvalidPattern('"' + pattern + '" ' +str(e))
    # The __unicode__ method returns a unicode string
    expected = u'Invalid pattern(s) found. "' + pattern + '" unbalanced parenthesis'
    assert invalid_pattern.__unicode__() == expected


# Generated at 2022-06-26 02:23:44.125256
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('foo')
    var_1 = var_0.__str__()

# Generated at 2022-06-26 02:23:46.215225
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('msg')
    assert e.__str__() == 'msg'


# Generated at 2022-06-26 02:23:57.217971
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('argument')
    var_1 = InvalidPattern('argument')
    var_1.msg = var_1.msg + '1'
    var_2 = _real_re_compile('(a)')
    var_3 = _real_re_compile('(a)')
    var_3.msg = var_3.msg + '1'
    var_4 = re.sub(var_2, 'b', 'aaa')
    var_5 = re.sub(var_3, 'b', 'aaa')
    var_6 = InvalidPattern('argument')
    # StringIO objects don't have a __eq__ method, so this fails with
    # AttributeError.
    # checking for equality of instance attributes

# Generated at 2022-06-26 02:24:00.664193
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern("argument")
    var_0.msg = 'test'
    var_1 = var_0._format()
    var_1 = unicode(var_1)
    var_2 = var_0.__unicode__()
    var_2 = unicode(var_2)


# Generated at 2022-06-26 02:24:03.628860
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = LazyRegex()
    var_1._compile_and_collapse()
    var_1._real_regex.__getattr__('foo_bar')
    

# Generated at 2022-06-26 02:24:07.016708
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    '''Exercise method __getattr__'''
    # TODO: implement this unit test
    pass



# Generated at 2022-06-26 02:24:11.285741
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # call with 3 args
    args = ('abcd',) * 3
    e = InvalidPattern(*args)
    try:
        raise e
    except InvalidPattern as e:
        pass



# Generated at 2022-06-26 02:24:25.038711
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('')
    var_1._fmt = 'foo'
    var_1.msg = 'bar'
    try:
        var_2 = '%(foo)s' % {'foo':'bar'}
    except KeyError:
        pass
    else:
        raise AssertionError
    try:
        var_2 = var_1._format()
    except Exception:
        pass
    else:
        raise AssertionError
    try:
        var_2 = var_1._format()
    except TypeError:
        pass
    else:
        raise AssertionError
    var_1._preformatted_string = 'foo'
    var_2 = var_1._format()
    if not (var_2 == 'foo'):
        raise AssertionError
   

# Generated at 2022-06-26 02:24:29.366181
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('test message')
    if var_1.__unicode__() != u'test message':
        raise RuntimeError('Method __unicode__ returned incorrect value'
                           )


# Generated at 2022-06-26 02:24:32.477887
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    t = InvalidPattern('Test error message')
    assert str(t) == 'Test error message'


# Generated at 2022-06-26 02:24:36.012270
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('foo')
    # Should print: InvalidPattern(foo)

# Generated at 2022-06-26 02:24:37.660683
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(None)
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:24:44.630528
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode repr of the exception, even
    if the message is not unicode (or even a string)
    """
    e = InvalidPattern('foo')
    u = unicode(e)
    assert isinstance(u, unicode)
    e = InvalidPattern(12)
    u = unicode(e)
    assert isinstance(u, unicode)
    e = InvalidPattern(None)
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-26 02:24:47.748051
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    var_2 = var_1._format()
    assert var_2 == 'Invalid pattern(s) found. %(msg)s'


# Generated at 2022-06-26 02:24:49.781955
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'message'
    x = InvalidPattern(msg)
    assert x.__str__() == msg


# Generated at 2022-06-26 02:24:51.394912
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass  # Nothing to test, __unicode__ does nothing but delegate to __str__


# Generated at 2022-06-26 02:24:56.015848
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Asserts that InvalidPattern.__unicode__() is equivalent to InvalidPattern.__str__()
    var_0 = InvalidPattern('foo')
    var_1 = var_0.__unicode__()
    var_2 = var_0.__str__()
    assert var_1 == var_2


# Generated at 2022-06-26 02:25:02.293487
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('test')


# Generated at 2022-06-26 02:25:04.577187
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('foo')
    assert(var_1.__str__() == 'foo')


# Generated at 2022-06-26 02:25:07.634931
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = lazy_compile()
    try:
        var_1.__getattr__("foo")
        raise Exception("expected AttributeError")
    except AttributeError:
        pass


# Generated at 2022-06-26 02:25:11.337547
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('foo')
    var_1 = var_0._format()
    #assert(var_1 == )


# Generated at 2022-06-26 02:25:12.292180
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    test_case_0()


# Generated at 2022-06-26 02:25:13.551477
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass


# Test case for method __unicode__ of class InvalidPattern

# Generated at 2022-06-26 02:25:18.473367
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern("returned")
    var_1 = var_0.__unicode__()
    assert type(var_1) is unicode
    assert type(var_1) is not str
    assert isinstance(var_1, unicode)
    assert isinstance(var_1, unicode)


# Generated at 2022-06-26 02:25:20.153766
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    InvalidPattern.msg = 'foo'
    assert InvalidPattern.__unicode__() == 'foo'



# Generated at 2022-06-26 02:25:26.640154
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = lazy_compile('|')
    var_0.__deepcopy__ = 'BfU'
    var_0.__copy__ = 'X'
    var_0._compile_and_collapse = 'bI'
    var_0._regex_attributes_to_copy = '"'

    # missing attribute call
    var_0.__getattr__("__getattr__")



# Generated at 2022-06-26 02:25:29.755974
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import osutils
    from bzrlib.transform import show_diff_trees
    if ('\n' in var_0):
        pass
    else:
        pass
    pass

