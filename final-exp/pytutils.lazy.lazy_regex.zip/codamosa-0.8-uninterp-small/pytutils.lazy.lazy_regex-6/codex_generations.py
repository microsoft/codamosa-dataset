

# Generated at 2022-06-26 02:15:43.324519
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern("")


# lp:82693

# Generated at 2022-06-26 02:15:47.773614
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    s = InvalidPattern(msg=u'%s')
    s = s.__unicode__()
    s = s.__unicode__()
    # InvalidPattern._format returned a 'unicode' object
    assert isinstance(s, unicode)


# Generated at 2022-06-26 02:16:01.264914
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    var_1 = var_0._format()
    var_2 = repr(var_0)
    var_3 = str(var_0)
    var_0 = InvalidPattern('msg')
    var_1 = var_0._format()
    var_2 = repr(var_0)
    var_3 = str(var_0)
    var_3
    var_0 = InvalidPattern('msg')
    var_3 = str(var_0)
    var_0 = u'Invalid pattern(s) found. msg'
    var_1 = unicode(var_0)
    var_1
    var_0 = 'msg'
    var_1 = str(var_0)
    var_1
    var_0 = u'Invalid pattern(s) found.'
   

# Generated at 2022-06-26 02:16:03.898341
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    err_0 = InvalidPattern('err_0')
    str_0 = str(err_0)


# Generated at 2022-06-26 02:16:06.918186
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = InvalidPattern('msg')
    assert str(pattern) == 'Invalid pattern(s) found. msg'

# Generated at 2022-06-26 02:16:10.991496
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_1 = install_lazy_compile()
    var_2 = LazyRegex()
    var_3 = var_2.__getattr__('_compile_and_collapse')

# Generated at 2022-06-26 02:16:17.024935
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from cStringIO import StringIO
    try:
        StringIO("").write("a", "")
    except TypeError:
        pass
    e = InvalidPattern("")
    try:
        StringIO("").write("a", "")
    except TypeError:
        pass
    e = InvalidPattern("")
    try:
        StringIO("").write("a", "")
    except TypeError:
        pass
    e = InvalidPattern("")
    try:
        StringIO("").write("a", "")
    except TypeError:
        pass
    e = InvalidPattern("")
    try:
        StringIO("").write("a", "")
    except TypeError:
        pass
    e = InvalidPattern("", "")


# Generated at 2022-06-26 02:16:19.964302
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex()
    var_1 = LazyRegex()
    var_1._compile_and_collapse()
    del var_1


# Generated at 2022-06-26 02:16:24.450321
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    exc = InvalidPattern(msg='test')
    if (exc.__unicode__() != 'test'):
        raise AssertionError



# Generated at 2022-06-26 02:16:31.486331
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('foo')
    var_1 = var_0._format()
    return var_1

if (__name__ == '__main__'):
    var_2 = test_case_0()
    var_10 = test_InvalidPattern___unicode__()
    var_11 = False
    if (var_10 == 'foo'):
        var_11 = True
    print("result: %s" % var_11)

# Generated at 2022-06-26 02:16:37.363917
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = install_lazy_compile()
    var_1 = InvalidPattern('msg')
    var_2 = str(var_1)
    assert var_2 == 'Invalid pattern(s) found. msg'

# Generated at 2022-06-26 02:16:42.606228
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    test_case_0()
    msg = 'Invalid pattern(s) found. '
    var_0 = InvalidPattern(msg)
    assert var_0._get_format_string() is None
    unicode_0 = var_0.__unicode__()
    assert unicode_0 == msg


# Generated at 2022-06-26 02:16:55.697189
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_1 = LazyRegex()
    var_2 = dict()
    var_2["args"] = list()
    var_2["kwargs"] = dict()
    # Testing exception: TypeError
    try:
        del var_1._real_regex
        del var_1._regex_args
        del var_1._regex_kwargs
        var_1.__setstate__(var_2)
        raise var_1._real_regex
        raise var_1._regex_args
        raise var_1._regex_kwargs
    except:
        import sys
        import traceback
        tb = sys.exc_info()[2]

# Generated at 2022-06-26 02:17:00.039687
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    regex = LazyRegex(('\d+',), {})
    # Calls to the _compile_and_collapse() method
    regex._compile_and_collapse()
    # Attribute '_real_regex' is not writable
    setattr(regex, '_real_regex', None)
    # Calls to the __getattr__() method
    regex.__getattr__(None)



# Generated at 2022-06-26 02:17:06.054033
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'msg'
    exc = InvalidPattern(msg)
    got = exc.__unicode__()
    expected = unicode('Invalid pattern(s) found. msg')
    assert got == expected


# Generated at 2022-06-26 02:17:10.093092
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    __expect = 'Invalid pattern(s) found. '
    var_0 = InvalidPattern(__expect)
    __result = var_0.__str__()


# Generated at 2022-06-26 02:17:13.587693
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exception = InvalidPattern('abc')
    s = str(exception)
    assert s == 'abc', s


# Generated at 2022-06-26 02:17:17.558663
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('a')
    var_1 = var_0.__unicode__()
    expected = u'a'
    if var_1 != expected:
        raise AssertionError("""var_1 (u'%s') != expected (u'%s')""" % (var_1, expected))


# Generated at 2022-06-26 02:17:26.360431
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('Foo')
    var_1 = var_0.__unicode__()
    var_2 = InvalidPattern(u'Foo')
    var_3 = var_2.__unicode__()
    var_4 = InvalidPattern(u'Foo')
    var_4._fmt = u"Foo: %(msg)s {%(msg1)s}"
    var_4.msg1 = u'Bar'
    var_5 = var_4.__unicode__()


# Generated at 2022-06-26 02:17:33.654881
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pattern = 'a*b'
    msg = 'nested quantifiers not allowed'
    instance = InvalidPattern(msg)
    others = [InvalidPattern('something else')]
    expected = 'Invalid pattern(s) found. nested quantifiers not allowed'
    actual = instance.__str__()
    assert actual == expected


# Generated at 2022-06-26 02:17:39.068143
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('msg')
    try:
        test.test_support.run_unittest(
            test_InvalidPattern___unicode__
            )
    finally:
        reset_compile()

# Generated at 2022-06-26 02:17:46.194510
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import os
    import sys
    import tempfile
    # test it works with an ordinary path.
    d, f = os.path.split(sys.executable)
    e = InvalidPattern('foo %(basename)s', basename=f)
    assert e.__unicode__() == unicode('foo %s' % (f,))



# Generated at 2022-06-26 02:17:49.679567
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    x = InvalidPattern('Foo')
    assert(str(x) == 'Foo')



# Generated at 2022-06-26 02:17:57.154557
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # s = self._format()
    # if isinstance(s, unicode):
    #     s = s.encode('utf8')
    # else:
    #     # __str__ must return a str.
    #     s = str(s)
    # return s
    #raise NotImplementedError('')
    return


# Generated at 2022-06-26 02:18:01.254148
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = "message"

# Generated at 2022-06-26 02:18:06.742383
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    exc = InvalidPattern('Invalid pattern')
    s = str(exc)
    u = unicode(exc)
    exc._preformatted_string = u'😀'
    s = str(exc)
    u = unicode(exc)


# Generated at 2022-06-26 02:18:09.001666
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    InvalidPattern('')
    InvalidPattern('abc')
    InvalidPattern('abc').__unicode__()
    InvalidPattern('abc').__unicode__


# Generated at 2022-06-26 02:18:13.527605
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    if isinstance(var_0, LazyRegex):
        var_0.__setstate__({
            "kwargs": var_0._regex_kwargs,
            "args": var_0._regex_args,
            })

test_case_0()

# Generated at 2022-06-26 02:18:15.860133
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Create a new instance of the class
    var_1 = InvalidPattern()
    # No expected output for this test


# Generated at 2022-06-26 02:18:22.173095
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('abc')
    var_2 = var_1.__unicode__()
    var_3 = isinstance(var_2, unicode)
    var_4 = isinstance(var_2, str)
    assert ((var_3) and (not (var_4)))


# Generated at 2022-06-26 02:18:34.875084
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test with a Unicode error string.
    e = InvalidPattern('\x80')
    s = unicode(e)
    assert isinstance(s, unicode)
    e = InvalidPattern('\x80')
    s = str(e)
    assert isinstance(s, str)



# Generated at 2022-06-26 02:18:44.451199
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__ returns a default encoding of self._format()
    invalid_pattern_0 = InvalidPattern('global_exclusive=False')
    assert not (invalid_pattern_0.__str__() == 'global_exclusive=False')



# Generated at 2022-06-26 02:18:46.426981
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    bad_re = InvalidPattern('a')
    assert str(bad_re) == 'Invalid pattern(s) found. a'

# Generated at 2022-06-26 02:18:58.055081
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    expected_msg = "Invalid pattern(s) found. 'foo' bar"
    exc = InvalidPattern('bar')
    _preformatted_string = "Invalid pattern(s) found. 'foo' %(msg)s"
    exc._preformatted_string = _preformatted_string

# Generated at 2022-06-26 02:19:00.591285
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = "A(?:B)"
    msg = "Invalid pattern(s) found. %(msg)s"
    exc = InvalidPattern(msg)
    exc.msg = "Bad pattern '" + pattern + "'"
    assert str(exc) == "Bad pattern 'A(?:B)'"
    assert repr(exc) == "InvalidPattern(Bad pattern 'A(?:B)')"


# Generated at 2022-06-26 02:19:02.091149
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'msg'
    instance = InvalidPattern(msg)
    eq = u'msg'
    result = instance.__unicode__()
    assert result == eq, "Got '%s' wanted '%s'" % (result, eq)


# Generated at 2022-06-26 02:19:04.329992
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    import doctest
    doctest.testmod()


__all__ = [
    'InvalidPattern',
    'LazyRegex',
    'lazy_compile',
    'reset_compile',
    ]

# Generated at 2022-06-26 02:19:06.231938
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern(u'foo')
    s = unicode(e)
    assert isinstance(s, unicode)


# Generated at 2022-06-26 02:19:07.889201
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('Invalid pattern')
    s = str(e)
    u = unicode(e)

# Generated at 2022-06-26 02:19:15.646575
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    inst_0 = InvalidPattern(None)
    inst_1 = InvalidPattern('nonsense')
    assert inst_0.__str__() == 'Unprintable exception InvalidPattern: ' \
        'dict={}, fmt=None, error=None'
    assert inst_1.__str__() == 'Unprintable exception InvalidPattern: ' \
        'dict={\'msg\': \'nonsense\'}, fmt=None, error=None'



# Generated at 2022-06-26 02:19:21.573870
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pattern_0 = InvalidPattern('message')
    assert type(pattern_0.__str__()) == str



# Generated at 2022-06-26 02:19:24.478954
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__"""
    # __unicode__ is provided by bzrlib.tests.TestCaseWithTransport.
    raise NotImplementedError(__name__ + '.test_InvalidPattern___unicode__')



# Generated at 2022-06-26 02:19:29.135230
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() returns a str, not a unicode object"""
    ip = InvalidPattern(u'example')
    s = str(ip)
    if isinstance(s, unicode):
        raise AssertionError("__str__ returned a unicode object")
    if not isinstance(s, str):
        raise AssertionError("__str__ returned a non-str object")


# Generated at 2022-06-26 02:19:32.568144
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exc = InvalidPattern('msg')
    assert exc.__str__() == 'Invalid pattern(s) found. msg'
    assert str(exc) == 'Invalid pattern(s) found. msg'



# Generated at 2022-06-26 02:19:35.624599
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalidpattern_0 = InvalidPattern('msg')
    invalidpattern_0._preformatted_string = 'msg'
    invalidpattern_0._fmt = 'msg'
    str_0 = str(invalidpattern_0)

# Generated at 2022-06-26 02:19:43.768471
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    test_pattern = 'test'
    exc_InvalidPattern = InvalidPattern(test_pattern)
    res_InvalidPattern = 'Invalid pattern(s) found. %s' % test_pattern
    assert_equal(str(exc_InvalidPattern), res_InvalidPattern)

    # But if the format string is unicode, we get back a unicode object.
    exc_InvalidPattern._fmt = u'test %(msg)s'
    assert_equal(str(exc_InvalidPattern), res_InvalidPattern)

# unit test for method _format of class InvalidPattern

# Generated at 2022-06-26 02:19:52.876713
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.tests import TestCase
    from bzrlib.i18n import gettext
    from bzrlib.i18n import _get_without_positional_substitutions
    # This checks a special case of the InvalidPattern class.  In this case
    # the _fmt string has no '%' in it, so shouldn't be translated at all.
    class TestInvalidPattern(TestCase):
        _fmt = 'Do you have the right diskette in the drive?'
        def setUp(self):
            super(TestInvalidPattern, self).setUp()
            self.ip = InvalidPattern(self._fmt)
        def test___unicode__(self):
            # test for the case described in the class' docstring
            self.assertEqual(self._fmt, self.ip._format())


# Generated at 2022-06-26 02:19:54.922494
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    s = InvalidPattern('foo')
    assert s.__unicode__() == u'foo'


# Generated at 2022-06-26 02:20:06.451351
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    # testing with regex_args=['(']
    exc = InvalidPattern('The error message')
    exc._preformatted_string = 'preformatted'
    exc._fmt = '%(msg)s'
    exc._get_format_string = lambda: 'translated'
    expected = unicode(gettext('translated'))
    actual = exc.__unicode__()
    assert expected == actual, '__unicode__() is not as expected'
    # testing with regex_args=['[']
    exc = InvalidPattern('The error message')
    exc._preformatted_string = 'preformatted'
    exc._fmt = '%(msg)s'
    exc._get_format_string = lambda: 'translated'

# Generated at 2022-06-26 02:20:08.537680
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    s = 'foo'
    e = InvalidPattern(s)
    e.__unicode__()



# Generated at 2022-06-26 02:20:20.542732
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = LazyRegex(('[A-Za-z0-9_\\-\\.\\+\\%\\*\\~]{1,256}',), {})
    pattern.findall('[A-Za-z0-9_\\-\\.\\+\\%\\*\\~]{1,256}')
    pattern = LazyRegex(('[A-Za-z0-9_\\-\\.\\+\\%\\*\\~]{1,256}',), {})
    pattern.findall('[A-Za-z0-9_\\-\\.\\+\\%\\*\\~]{1,256}')

# Generated at 2022-06-26 02:20:26.958514
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    ip = InvalidPattern("")
    ip._format()
    ip._fmt = "abc"
    ip._format()
    from bzrlib.i18n import gettext
    ip._fmt = '%(msg)s %(something)s'
    ip.something = "foo"
    gettext("abc")
    ip._format()
    gettext("abc")
    ip._format()


# Generated at 2022-06-26 02:20:31.741326
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() -
    __str__ inherits the default behavior from Exception,
    which is to return a string that presents all error information
    of the exception instance.
    """
    e = InvalidPattern('An error occurred')
    assert str(e) == 'Invalid pattern(s) found. An error occurred'


# Generated at 2022-06-26 02:20:34.626204
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # simple cases
    assert unicode(InvalidPattern('foo')) == 'foo'
    # Test __str__
    assert str(InvalidPattern('foo')) == 'foo'

# Generated at 2022-06-26 02:20:43.221720
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__
    # Returns the string representation of the exception.
    # i18n: file+line:Function:Class.method
    exp_err_msg = "file2.py:72:run:ReVcTest.test_case_0"
    exp_err_msg += ": capture groups must be numbered consecutively"
    try:
        test_case_0()
    except InvalidPattern as e:
        e_str = str(e)
    except BaseException as e:
        e_str = str(e)
    else:
        e_str = None
    assert exp_err_msg == e_str

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:20:44.582421
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'A message in a bottle'
    sut = InvalidPattern(msg)
    assert sut.__unicode__() == msg

# Generated at 2022-06-26 02:20:47.197313
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = '('
    error = InvalidPattern('"' + pattern + '" unmatched parenthesis')
    result = error.__unicode__()
    expected = "unmatched parenthesis"
    assert result == expected, (result, expected)

# Generated at 2022-06-26 02:20:48.861729
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'hello world'
    e = InvalidPattern(msg)
    assert e.__unicode__() == msg

# Generated at 2022-06-26 02:20:59.671347
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object, str if possible."""
    class InvalidPattern2(InvalidPattern):
        _fmt = 'This is an error message: %(msg)s'
    # Using a str
    exc = InvalidPattern('test')
    repr(exc) # force a repr, to exercise __repr__
    # make sure the exception doesn't end up with a preformatted string
    exc.__class__._preformatted_string = u'%s'
    unicode(exc)
    exc = InvalidPattern2('test')
    unicode(exc)
    # Using a unicode
    exc = InvalidPattern(u'test')
    unicode(exc)
    exc = InvalidPattern2(u'test')
    unicode(exc)
    exc = InvalidPattern(u'è')

# Generated at 2022-06-26 02:21:09.454247
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    import bzrlib.osutils

    e = InvalidPattern('')
    s = bzrlib.osutils.safe_unicode(u'lorem ipsum')
    s2 = bzrlib.osutils.safe_unicode(u'foo')
    c = InvalidPattern.__bases__[0]
    e._preformatted_string = s
    assert s == e.__unicode__(), e.__unicode__()
    assert isinstance(e.__unicode__(), unicode)
    assert s == str(e), str(e)
    assert isinstance(str(e), str)
    assert s2 == c.__unicode__(c(), s2), c.__unicode__(c(), s2)

# Generated at 2022-06-26 02:21:18.610898
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__()

    The __str__ method shall return a string.
    """
    # Make sure it returns a string
    e = InvalidPattern('')
    assert isinstance(str(e), str)



# Generated at 2022-06-26 02:21:22.371852
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    pattern = '\w+'
    lazy_regex = LazyRegex((pattern))
    # Call __getattr__ explicitly
    result = lazy_regex.__getattr__('pattern')
    expected = pattern
    assert result == expected

# Generated at 2022-06-26 02:21:24.624491
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # method args
    # expected = expected value
    raise NotImplementedError()

# Generated at 2022-06-26 02:21:36.317194
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    regex_arg_0 = 'abc'
    lazy_regex_0 = LazyRegex(regex_arg_0)
    try:
        lazy_regex_0.__setstate__('abc')
    except AttributeError as exception:
        assert type(exception) == AttributeError
    else:
        assert False

    lazy_regex_0 = LazyRegex('abc')
    pickled_lazy_regex_0 = pickle.dumps(lazy_regex_0)
    lazy_regex_1 = pickle.loads(pickled_lazy_regex_0)
    assert lazy_regex_1._regex_args == lazy_regex_0._regex_args


# Generated at 2022-06-26 02:21:37.550281
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    obj = InvalidPattern('foo')
    assert str(obj) == 'Invalid pattern(s) found. foo'


# Generated at 2022-06-26 02:21:40.525038
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lazy_regex_0 = LazyRegex()
    setattr(lazy_regex_0, "args", ('\\','\\'))
    setattr(lazy_regex_0, "kwargs", {})
    try:
        lazy_regex_0.__setstate__({"args": ('\\','\\'), "kwargs": {}})
    except InvalidPattern:
        pass
    except:
        raise AssertionError()
    return



# Generated at 2022-06-26 02:21:44.760820
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # empty constructor
    a = InvalidPattern()
    a._fmt = 'abc %(a)s'
    a.a = 'defg'
    assert a.__unicode__() == 'abc defg'
    a._fmt = u'abc %(a)s'
    assert isinstance(a.__unicode__(), unicode)


# Generated at 2022-06-26 02:21:47.602239
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # __unicode__ returns a unicode object
    invalidpattern_0 = InvalidPattern(u'')
    assert isinstance(invalidpattern_0.__unicode__(), unicode)


# Generated at 2022-06-26 02:21:56.618049
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestNotApplicable
    try:
        from bzrlib.tests.test_matchers import LazyRegexTestCase
    except ImportError:
        raise TestNotApplicable("bzrlib.tests.test_matchers "
            "module not found")
        return
    from bzrlib.tests.test_matchers import LazyRegexTestCase
    raise TestNotApplicable("%s.%s not implemented" \
        % ("bzrlib.tests.test_matchers.LazyRegexTestCase", \
            "test_LazyRegex___getattr__"))


# Generated at 2022-06-26 02:21:59.043760
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    test_str = 'this is the test'
    ip = InvalidPattern(test_str)
    if str(ip) != test_str:
        raise AssertionError



# Generated at 2022-06-26 02:22:11.517943
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__(self: bzrlib.patiencediff.LazyRegex.InvalidPattern) -> str
    """
    obj = InvalidPattern('msg')
    obj.msg = 'Test'
    str1 = obj.__unicode__()
    str2 = obj.__str__()
    # This is actually an error in the translated message, but I don't know
    # how to change the test to allow it to pass regardless of the
    # translation.
    assert str1 == 'Unable to compile regex "msg": Test'
    assert str2 == 'Unable to compile regex "msg": Test'


# Generated at 2022-06-26 02:22:14.896995
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern.

    """
    from bzrlib.lazy_regex import InvalidPattern
    ip = InvalidPattern('error message')
    assert isinstance(ip.__str__(), str)



# Generated at 2022-06-26 02:22:19.288665
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('msg')
    str_obj = str(e)
    assert(str_obj == 'Invalid pattern(s) found. msg')
    assert(str(InvalidPattern(_fmt=str_obj)) == str_obj)



# Generated at 2022-06-26 02:22:21.817521
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalidPattern = InvalidPattern('msg')
    s = invalidPattern.__str__()
    assert(isinstance(s, str))


# Generated at 2022-06-26 02:22:26.242152
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = "InvalidPattern.__unicode__: msg = '%s'"
    tester = InvalidPattern("test_msg")
    try:
        test_result = tester.__unicode__()
        assert test_result == "test_msg"
    except Exception as err:
        print(msg % "failed")
        raise err
    print(msg % "passed")

# Unit tests for method __str__ of class InvalidPattern

# Generated at 2022-06-26 02:22:34.151964
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import errors
    bzr_error = errors.BzrError(u"")
    try:
        raise bzr_error
    except errors.BzrError as e:
        # get the traceback
        tb = e.traceback_string()
    invalid_pattern = InvalidPattern("") 
    invalid_pattern._preformatted_string = tb 
    try:
        raise invalid_pattern
    except InvalidPattern as e:
        s = str(e)


# Generated at 2022-06-26 02:22:40.240696
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ returns unicode string even if _fmt is bytestring
    """
    import bzrlib.errors
    e = bzrlib.errors.BzrError(u"test error")
    e._fmt = "test error"
    at_unicode = e.__unicode__()
    assert isinstance(at_unicode, unicode)

# Generated at 2022-06-26 02:22:43.609932
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    _fmt = 'foo'
    msg = 'bar'
    invalid_pattern_0 = InvalidPattern(msg)
    invalid_pattern_0._fmt = _fmt
    str_0 = invalid_pattern_0.__str__()
    assert isinstance(str_0, str)



# Generated at 2022-06-26 02:22:51.706918
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # set member fields
    args = (u'Invalid pattern(s) found. \'\'',)
    kwargs = {}
    inst = InvalidPattern(*args, **kwargs)
    # call method __unicode__
    ret = inst.__unicode__()
    # check return value
    expected = u'Invalid pattern(s) found. \'\''
    assert ret == expected, \
        'Expected: %r, got: %r' % (expected, ret)


# Generated at 2022-06-26 02:22:55.339067
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lazy_regex_0 = LazyRegex()
    dict_0 = {"args": (), "kwargs": {}}
    lazy_regex_0.__setstate__(dict_0)



# Generated at 2022-06-26 02:23:04.824545
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg1 = 'internally generated error'
    e1 = InvalidPattern(msg1)
    e1_unicode = e1.__unicode__()
    msg2 = '%(msg)s'
    e2 = InvalidPattern(msg2)
    e2_unicode = e2.__unicode__()


# Generated at 2022-06-26 02:23:11.351594
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # test that str(InvalidPattern) returns expected information
    regex = LazyRegex((r'^\d',))
    try:
        regex.match('a')
    except InvalidPattern as e:
        s = str(e)
        exception_type = "bzrlib.lazy_regex.InvalidPattern: "
        unexpected_prefix = "Unprintable exception "
        message = '"^\\d" nothing to repeat at position 1'
        # test that the str message starts with exception name
        assert not s.startswith(unexpected_prefix)
        # test that the str message starts with exception name
        assert s.startswith(exception_type)
        # test for the message
        assert s.find(message) > 0
    else:
        assert False, "InvalidPattern expected"


# Generated at 2022-06-26 02:23:22.278019
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    # Method case 1
    try:
        msg = "this is a message"
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        assert str(e) == gettext('Invalid pattern(s) found. ') + msg

    # Method case 2
    msg = "this is a %(name)s"
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        assert str(e) == gettext('Invalid pattern(s) found. ') + msg

    # Method case 3
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        e._fmt = 'msg: %(msg)s'
        e.name = 'name'
        assert str(e) == gettext('msg: ')

# Generated at 2022-06-26 02:23:25.711877
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalid_pattern_0 = InvalidPattern(None)
    str_0 = str(invalid_pattern_0)


# Generated at 2022-06-26 02:23:28.908013
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'test msg'
    ex = InvalidPattern(msg)
    assert str(ex) == 'Invalid pattern(s) found. test msg'
    assert unicode(ex) == u'Invalid pattern(s) found. test msg'
    assert repr(ex) == 'InvalidPattern(Invalid pattern(s) found. test msg)'

# Generated at 2022-06-26 02:23:31.202225
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('hello')
    u = unicode(e)
    expected = u'hello'
    assert u == expected, 'Got %s expected %s' % (u, expected)

# Generated at 2022-06-26 02:23:33.404285
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern(msg='foo bar')
    except InvalidPattern as e:
        assert str(e) == "Invalid pattern(s) found. foo bar"

# Generated at 2022-06-26 02:23:34.694845
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('msg')
    u = e.__unicode__()



# Generated at 2022-06-26 02:23:47.257843
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Testing method __str__ of class InvalidPattern."""
    # tests for a preformatted message
    args = {'msg': 'Invalid pattern is here.'}
    e = InvalidPattern(**args)
    e.preformat_msg('msg')
    expected = 'Invalid pattern(s) found. Invalid pattern is here.'
    actual = str(e)
    assert expected == actual, ('expected: %s, got: %s' % (expected, actual))
    e = InvalidPattern(None)
    expected = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    actual = str(e)
    assert expected == actual, ('expected: %s, got: %s' % (expected, actual))
    e = InvalidPattern(None)
    e._fmt = 'Error: %(msg)s'
   

# Generated at 2022-06-26 02:23:48.886848
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert InvalidPattern("foo").__unicode__() == "Invalid pattern(s) found. foo"



# Generated at 2022-06-26 02:23:56.522011
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    instance = InvalidPattern('Test')
    eq = str(instance)
    expected = 'Invalid pattern(s) found. Test'
    eq_(eq, expected)


# Generated at 2022-06-26 02:23:59.781940
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = "InvalidPattern.__str__() raised TypeError unexpectedly!"
    try:
        InvalidPattern("test").__str__()
    except TypeError:
        fail(msg)


# Generated at 2022-06-26 02:24:01.913372
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg=u'foo'
    exc = InvalidPattern(msg)
    unicode(exc) == msg


# Generated at 2022-06-26 02:24:12.340712
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # create an instance of the class
    inst = InvalidPattern("Test message")
    # set the attribute '_preformatted_string' to a string value
    inst._preformatted_string = "Test message"
    # call the __unicode__ method
    expected = "Test message"
    actual = inst.__unicode__()
    assert isinstance(actual, unicode)
    assert len(actual) == len(expected)
    assert actual == expected, "Test failed: expected: '%s', got: '%s'" % (
        expected, actual)
    # clean up
    del inst



# Generated at 2022-06-26 02:24:13.495114
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    i = InvalidPattern('foo')
    assert str(i) == 'foo'
    assert unicode(i) == 'foo'

# Generated at 2022-06-26 02:24:16.600468
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Check __str__ method of InvalidPattern"""
    e = InvalidPattern("an error occurred")
    expected = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    observed = e.__str__()
    if (observed != expected):
        raise AssertionError("observed != expected:\n'%s'\n'%s'"
                            % (observed, expected))

# Generated at 2022-06-26 02:24:18.929990
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    A = InvalidPattern(None)
    assert isinstance(A, InvalidPattern)
    assert isinstance(A, ValueError)


# Generated at 2022-06-26 02:24:23.576278
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern("something is wrong")
    assert str(e) == 'Invalid pattern(s) found. something is wrong'
    import pickle
    e = pickle.loads(pickle.dumps(e))
    assert str(e) == 'Invalid pattern(s) found. something is wrong'
    e._preformatted_string = 'foobar'
    assert str(e) == 'foobar'

# Generated at 2022-06-26 02:24:28.302856
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__ is used when printing exceptions
    try:
        raise InvalidPattern('a message')
    except InvalidPattern as e:
        passed = str(e) == "Invalid pattern(s) found. a message"
    else:
        passed = False

    assert(passed)



# Generated at 2022-06-26 02:24:35.857775
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'regex does not match'
    fmt = 'Invalid pattern(s) found. %(msg)s'
    u = unicode(InvalidPattern(msg=msg), 'utf8')
    expected = 'Invalid pattern(s) found. regex does not match'
    assert (str(u) == expected), \
        'InvalidPattern.__unicode__ returned %s; expected %s' % (str(u), expected)


# Generated at 2022-06-26 02:24:44.958472
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    obj = InvalidPattern.__new__(InvalidPattern)
    obj.msg = None
    # call function(obj): InvalidPattern.__str__
    try:
        obj.__str__()
    except TypeError:
        pass
    else:
        assert False, "unexpected success"

test_case_0()
test_InvalidPattern___str__()

# Generated at 2022-06-26 02:24:51.466557
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('test message')
    # __unicode__() should always return a 'unicode' object.
    assert isinstance(e.__unicode__(), unicode)
    # __unicode__() should return the localized message
    assert e.__unicode__() == u'test message'
    # __str__() should always return a 'str' object.
    assert isinstance(e.__str__(), str)
    assert e.__str__() == e.__unicode__().encode('utf8')


# Generated at 2022-06-26 02:24:53.095367
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    s = InvalidPattern("msg")
    l = str(s)


# Generated at 2022-06-26 02:24:55.626501
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test for method __str__ of class InvalidPattern
    # assertEqual(expected, InvalidPattern.__str__(self))
    assert_equal(True, True)



# Generated at 2022-06-26 02:25:01.961714
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex"""
    lazy_regex_0 = LazyRegex()
    try:
        lazy_regex_0.__getattr__('_real_regex')
    except re.error as e:
        pass
    else:
        assert 0, "Test case failed - exception not raised"


# Generated at 2022-06-26 02:25:05.225110
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    #
    # Variation 1: '__doc__' in LazyRegex.__slots__
    #
    lazy_regex_0 = LazyRegex()
    assert lazy_regex_0.__doc__ is None


# Generated at 2022-06-26 02:25:10.269784
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # For the following test, we need to mock the _compile_and_collapse
    # method to keep it from trying to compile the regex, which is not
    # possible in this unit test.
    class MockLazyRegex(LazyRegex):

        def _compile_and_collapse(self):
            # We don't have to create a real _real_regex, just set it to True
            self._real_regex = True
            # Now copy the required attributes from the proxy object
            for attr in self._regex_attributes_to_copy:
                setattr(self, attr, getattr(self, attr))

    # Construct a MockLazyRegex instance using the parameter values from the
    # global LazyRegex instance

# Generated at 2022-06-26 02:25:16.956431
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import (
        errors,
        )
    from bzrlib.tests import TestCase
    class TestInvalidPattern(TestCase):

        def test___unicode__(self):
            self.assertEqual('Unprintable exception InvalidPattern: dict={}, fmt=None, error=None',
                              unicode(errors.InvalidPattern()))
    # Do not use test_suite() here to avoid locking issues
    return TestInvalidPattern('test___unicode__').test_suite()


# Generated at 2022-06-26 02:25:26.469560
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test when there's no preformatted string
    try:
        raise InvalidPattern('hello world')
    except InvalidPattern as e:
        # it should have a message
        m = str(e)
        assert(m)
        # it should have the msg parameter
        assert(e.msg)
    # Test when there is a preformatted string
    try:
        e = InvalidPattern('hello')
        # it should have a preformatted string
        assert(e._fmt)
        e._preformatted_string = 'goodbye'
        m = str(e)
        assert(m == 'goodbye')
    except InvalidPattern as e:
        assert(False)

# Generated at 2022-06-26 02:25:29.605749
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # This test checks that __unicode__() with str return the same string
    # as the _fmt attribute
    ex = InvalidPattern('test')
    ex._fmt = 'test'
    assert 'test' == str(ex)

