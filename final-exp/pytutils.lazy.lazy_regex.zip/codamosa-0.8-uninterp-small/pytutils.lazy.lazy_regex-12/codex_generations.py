

# Generated at 2022-06-26 02:15:50.057200
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import i18n
    import sys
    old_gettext = i18n.gettext
    def my_gettext(text):
        return "my_gettext(%r)" % text
    i18n.gettext = my_gettext

# Generated at 2022-06-26 02:15:53.378146
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_0 = LazyRegex()
    var_0.__setstate__({})


# Generated at 2022-06-26 02:15:57.254377
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern('msg')
    var_1 = 'Invalid pattern(s) found. msg'

    assert(var_0.__str__() == var_1)


# Generated at 2022-06-26 02:16:00.744537
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern"""
    expected = u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    pattern = InvalidPattern('asdf')
    actual = unicode(pattern)
    assert actual == expected, repr(actual)


# Generated at 2022-06-26 02:16:11.541697
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalid_pattern_instance = InvalidPattern()
    invalid_pattern_instance._preformatted_string = u"Some string"
    expected_0 = u"Some string"
    actual_0 = invalid_pattern_instance.__unicode__()
    try:
        assert_equals_str(expected_0, actual_0)
    except AssertionError as ae:
        raise AssertionError(ae.message + "\n expected: " + str(expected_0)
                                               + "\n actual  : " + str(actual_0))


# Generated at 2022-06-26 02:16:16.848215
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__: Return a string representation of the exception"""
    # Make sure the two string representations are ascii encodable. If they
    # aren't then we can't use them in gettext.
    uni = InvalidPattern('\xc3\x9e').__str__()
    str(uni) # force utf8 encoding.
    unicode(uni) # force ascii encoding.

    uni = InvalidPattern('\xc3\x9e').__unicode__()
    unicode(uni) # force ascii encoding.

# vim:et:ts=4:sw=4:et:sts=4

# Generated at 2022-06-26 02:16:20.498770
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalid_pattern_0 = InvalidPattern("")
    var_0 = unicode(invalid_pattern_0)
    assert isinstance(var_0, unicode)
    assert var_0 == u"Invalid pattern(s) found. "


# Generated at 2022-06-26 02:16:33.016774
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern(u'mfes')
    var_0._preformatted_string = u'foo'
    var_1 = InvalidPattern(u'mfes')
    var_1._preformatted_string = u'foo'
    var_2 = InvalidPattern(u'mfes')
    var_2._preformatted_string = u'foo'
    var_3 = InvalidPattern(u'mfes')
    var_3._preformatted_string = u'foo'
    var_4 = InvalidPattern(u'mfes')
    var_4._preformatted_string = u'foo'
    var_5 = InvalidPattern(u'mfes')
    var_5._preformatted_string = u'foo'
    var_6 = InvalidPattern(u'mfes')
    var_6._

# Generated at 2022-06-26 02:16:45.260637
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern("")
    var_2 = InvalidPattern("")
    var_3 = InvalidPattern("")
    var_4 = InvalidPattern("")
    var_5 = InvalidPattern("")
    var_6 = InvalidPattern("")
    var_7 = InvalidPattern("")
    var_8 = InvalidPattern("")
    var_9 = InvalidPattern("")
    var_10 = InvalidPattern("")
    var_11 = InvalidPattern("")
    var_12 = InvalidPattern("")
    var_13 = InvalidPattern("")
    var_14 = InvalidPattern("")
    var_15 = InvalidPattern("")
    var_16 = InvalidPattern("")
    var_17 = InvalidPattern("")
    var_18 = InvalidPattern("")
    var_19 = InvalidPattern("")
    var_20 = InvalidPattern("")

# Generated at 2022-06-26 02:16:56.631007
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__()

    This is a basic unit test to exercise the __str__ method of the
    InvalidPattern exception.
    """
    try:
        raise InvalidPattern(('This is a test.'))
    except InvalidPattern as e:
        e_str = str(e)
        e_repr = repr(e)
        e_unicode = unicode(e)
        e_unicode_utf8 = e_unicode.encode('utf8')
        e_unicode_koi8_r = e_unicode.encode('koi8-r')
        e_unicode_iso8859_1 = e_unicode.encode('iso8859-1')
        e_unicode_cp1252 = e_unicode.encode('cp1252')
        # Can't really test for

# Generated at 2022-06-26 02:17:14.269172
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern()


# Generated at 2022-06-26 02:17:16.105429
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('')


# Generated at 2022-06-26 02:17:21.674666
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Check the value of InvalidPattern.__str__()
    var_1 = InvalidPattern('"foo"bar" ')
    if var_1 == 'Invalid pattern(s) found. "foo"bar" ':
        pass


# Generated at 2022-06-26 02:17:30.815496
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    if __debug__:
        assert type('Foo') is str
        assert type(u'Foo') is unicode
        assert type(1) is int
        assert type(3.14) is float
    assert InvalidPattern.__unicode__(InvalidPattern((
            'Foo'
        ))) == u'Invalid pattern(s) found. "Foo" '
    if __debug__:
        assert type('Foo') is str
        assert type(u'Foo') is unicode
        assert type(1) is int
        assert type(3.14) is float
    assert InvalidPattern.__unicode__(InvalidPattern((
            u'Foo'
        ))) == 'Invalid pattern(s) found. "Foo" '


# Generated at 2022-06-26 02:17:33.813336
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('abc')
    str_0 = str(var_1)


# Generated at 2022-06-26 02:17:38.586659
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('')
    try:
        var_2 = var_1._get_format_string()
    except Exception as var_3:
        var_2 = None
    var_1._get_format_string = lambda : 'd'
    var_2 = var_1._get_format_string()
    var_1._get_format_string = lambda : None
    var_2 = var_1._get_format_string()


# Generated at 2022-06-26 02:17:48.894749
# Unit test for method __str__ of class InvalidPattern

# Generated at 2022-06-26 02:17:53.762994
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern(u'foo')
    #test_str_str = e.__str__()
    test_str_str = str(e)



# Generated at 2022-06-26 02:17:59.943255
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'Invalid pattern(s) found. '
    var_0 = InvalidPattern(msg)
    var_1 = var_0.__unicode__()
    assert isinstance(var_1, unicode), (var_1, type(var_1))
    var_2 = InvalidPattern('')
    var_3 = var_2.__unicode__()
    assert isinstance(var_3, unicode), (var_3, type(var_3))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:18:07.726398
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = ""
    var_0 = InvalidPattern(msg)
    var_0___str__ = var_0.__str__()
    # Test for 'str' type.
    assert isinstance(var_0___str__, str)
    # Test for equality.
    assert var_0___str__ == ''
    # Test for identity.
    assert var_0___str__ is not ''



# Generated at 2022-06-26 02:18:18.344291
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern(msg='error_message: bla')
    unicode(e)

# Generated at 2022-06-26 02:18:28.876939
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('a')
    eq = 'a'
    var_2 = var_1._format()
    eq = 'a'
    var_3 = var_1.__unicode__()
    eq = 'a'
    var_4 = var_1.__str__()
    eq = 'a'
    var_5 = InvalidPattern('b')
    var_6 = str(var_5)
    eq = 'b'
    var_7 = var_5._get_format_string()
    eq = 'b'
    var_8 = var_1 == var_5
    eq = False


# Generated at 2022-06-26 02:18:31.772055
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Method __unicode__ for class InvalidPattern"""
    var_0 = InvalidPattern('foo')
    assert('foo' == unicode(var_0))


# Generated at 2022-06-26 02:18:37.297233
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for __getattr__ of LazyRegex"""
    var_0 = lazy_compile()
    var_0._compile_and_collapse()
    var_0._real_regex = re.compile('abc')
    var_1 = var_0.match('abc')
    var_1 = var_1.group(0)
    assert var_1 == 'abc'



# Generated at 2022-06-26 02:18:41.723697
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__"""
    f = InvalidPattern(u"foo")
    f._fmt = u"%(msg)s"
    assert str(f) == "foo"
    assert unicode(f) == u"foo"
    f = InvalidPattern(u"foo")
    f._fmt = u"%(msg)s %(msg)s"
    assert str(f) == "foo foo"
    assert unicode(f) == u"foo foo"


# Generated at 2022-06-26 02:18:46.377573
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """test_InvalidPattern___unicode__ - 

    Assert that unicode return 'str'.
    """

    # Unit test for method __unicode__ of class InvalidPattern
    var_0 = InvalidPattern('msg')
    str(var_0)



# Generated at 2022-06-26 02:18:50.118206
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern('')
    var_1 = var_0._format()
    assert var_1 == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:18:53.495233
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest, sys
    doctest.run_docstring_examples(InvalidPattern.__str__, globals(),
                                   verbose=False, name="InvalidPattern.__str__")

# Generated at 2022-06-26 02:18:56.913491
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pattern = 'pattern'
    msg = "Message"
    exception = InvalidPattern(msg)
    expected = u'Invalid pattern(s) found. ' + unicode(msg)
    assert unicode(exception) == expected


# Generated at 2022-06-26 02:19:00.293960
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        var_0 = InvalidPattern('message')
    except ValueError:
        pass

# Generated at 2022-06-26 02:19:11.918817
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("")
    assert type(var_0.__str__()) == str


# Generated at 2022-06-26 02:19:22.327678
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib._patiencediff_py import _patiencediff_py
    from bzrlib.i18n import gettext
    from bzrlib.trace import mutter
    from bzrlib.ui import ui_factory

    def test_case_1():
        var_1 = ui_factory.make_ui('stdio')
    def test_case_2():
        var_2 = gettext('Invalid pattern(s) found. %(msg)s')
    def test_case_3():
        var_3 = _patiencediff_py.PatienceSequenceMatcher
    def test_case_4():
        var_4 = InvalidPattern('foo')
        var_4._fmt = gettext('Invalid pattern(s) found. %(msg)s')
        var_4._pre

# Generated at 2022-06-26 02:19:23.686526
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert True
# vim: set fileencoding=utf-8 :

# Generated at 2022-06-26 02:19:26.833720
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    m = InvalidPattern('test message')
    assert(m.__unicode__() == 'test message')

if __name__ == "__main__":
    import sys
    if sys.argv[1] == '-u':
        test_case_0()
        test_InvalidPattern___unicode__()

# Generated at 2022-06-26 02:19:32.186155
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import i18n
    _real_set_output_encoding = i18n._set_output_encoding

# Generated at 2022-06-26 02:19:35.679884
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    exc = InvalidPattern('Cannot determine revision number from revision-id')
    assert exc.__unicode__() == \
        u'Invalid pattern(s) found. \"Cannot determine revision number from revision-id\" re.error'


# Generated at 2022-06-26 02:19:41.300672
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    #
    # InvalidPattern(msg)
    #
    var_0 = InvalidPattern('msg0')
    #
    # format string: 'Invalid pattern(s) found. %(msg)s'
    #
    var_1 = 'Invalid pattern(s) found. msg0'
    assert var_0._format() == var_1


# Generated at 2022-06-26 02:19:46.118990
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    a = InvalidPattern(None)
    b = InvalidPattern('foo')
    c = InvalidPattern('%(msg)s')

    assert str(a) == 'Invalid pattern(s) found. None'
    assert str(b) == "Invalid pattern(s) found. 'foo'"
    assert str(c) == 'Invalid pattern(s) found. %(msg)s'


# Generated at 2022-06-26 02:19:54.593340
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Introduce variables and prepare test
    var_1 = InvalidPattern('abc')
    var_1._fmt = ''
    var_1.msg = 'abc'
    var_1._preformatted_string = ''
    # Execute the code to be tested
    var_2 = str(var_1)
    # Check the result
    assert_true(var_2)
    # Introduce variables and prepare test
    var_3 = InvalidPattern('abc')
    var_3._fmt = ''
    var_3._preformatted_string = 'abc'
    var_3.msg = 'abc'
    # Execute the code to be tested
    var_4 = str(var_3)
    # Check the result
    assert_equals(var_4, 'abc')
    # Introduce variables and prepare test


# Generated at 2022-06-26 02:19:57.950539
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern("")
    # Output formatted string
    var_1 = var_0._format()
    # Check that the output matches what we expect
    assert var_1 == u''



# Generated at 2022-06-26 02:20:14.952314
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() -> unicode

    Return a unicode version of the string representation of the exception.
    This still may contain non-ASCII characters, but it is guaranteed to be
    a unicode object returned by unicode().
    """
    exception = InvalidPattern("message")
    expected = unicode("message")
    actual = exception.__unicode__()
    if isinstance(expected, str):
        # The exception.__unicode__() returns a unicode string.
        assert isinstance(actual, unicode)
    assert expected == actual


# Generated at 2022-06-26 02:20:16.698463
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # self = <bzrlib.patiencediff.InvalidPattern msg=u'Invalid pattern(s) found. '>
    # return self._format()
    return u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'

# Generated at 2022-06-26 02:20:20.152152
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    # Create an instance
    x = LazyRegex()
    try:
        # Call __setstate__ with two values
        x.__setstate__({})
    except TypeError:
        pass
    else:
        raise AssertionError('LazyRegex.__setstate__ did not raise TypeError')



# Generated at 2022-06-26 02:20:26.024140
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_1 = InvalidPattern('string message')
    var_1._preformatted_string = 'preformatted message'
    var_1._fmt = 'message container'
    from bzrlib.i18n import gettext
    var_1._preformatted_string = 'preformatted message'
    var_1._fmt = 'message container'


# Generated at 2022-06-26 02:20:31.741332
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("test_string")
    # Function inlining is performed in a separate stage and
    # the 'test_string' argument is hardcoded.
    var_1 = InvalidPattern("test_string")
    var_1._preformatted_string = "test_string"

    assert_equal(var_0.__str__(), var_1.__str__())



# Generated at 2022-06-26 02:20:33.065416
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pass # TODO: implement your test here


# Generated at 2022-06-26 02:20:42.832051
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import lazy_gettext

    # test with a lazy_gettext object
    e = InvalidPattern(lazy_gettext('foo'))
    __traceback_info__ = e
    msg = e.__unicode__()
    assert(msg == gettext('foo'))

    # test with a unicode object
    e = InvalidPattern(u'bar')
    __traceback_info__ = e
    msg = e.__unicode__()
    assert(msg == u'bar')

    # test with a plain string object
    e = InvalidPattern('bar')
    __traceback_info__ = e
    msg = e.__unicode__()
    assert(msg == u'bar')

# Generated at 2022-06-26 02:20:48.817707
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    global obj
    obj = InvalidPattern.__new__(InvalidPattern)
    obj._preformatted_string = None
    obj._fmt = "Invalid pattern(s) found. %(msg)s"
    obj.msg = "Hello World"
    # assert that the method returns a unicode object.
    assert isinstance(obj.__unicode__(), unicode)
    #assert that the returned unicode is correct
    assert obj.__unicode__() == u"Invalid pattern(s) found. Hello World"
    #assert that the method returns the same when called directly
    assert obj.__unicode__() == unicode(obj)


# Generated at 2022-06-26 02:20:54.988802
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # EDITED
    # Create a blank test case
    var_0 = test_case_0()
    # Create an instance of InvalidPattern
    var_1 = InvalidPattern('Test description')
    # Call its __str__ method
    var_2 = var_1.__str__()
    # Check that the resulting value is equal to 'Invalid pattern(s) found. Test description'
    assert var_2 == 'Invalid pattern(s) found. Test description'



# Generated at 2022-06-26 02:21:02.133751
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # Tests calling method __getattr__ of class LazyRegex with an invalid
    # regex pattern.
    # The invalid regex pattern should result in an InvalidPattern exception.
    try:
        LazyRegex(('*',), {}).__getattr__('_compile_and_collapse')
    except InvalidPattern as e:
        if not isinstance(e, InvalidPattern):
            raise AssertionError
    except Exception as e:
        raise AssertionError


# Generated at 2022-06-26 02:21:18.557658
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()
    try:
        var_0.__unicode__()
    except Exception:
        # var_0.__unicode__() was expected to throw an exception
        var_1 = 1
    else:
        var_1 = 0
    _test_result = var_1
    assert var_1


# Generated at 2022-06-26 02:21:30.561224
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('msg')
    var_2 = _('msg')
    var_3 = InvalidPattern(u'msg')
    var_4 = _(u'msg')
    var_5 = InvalidPattern(u"Unprintable exception InvalidPattern: dict={'args': (), 'msg': 'msg', 'kwargs': {}}, fmt=None, error=%(repr)s")
    var_6 = _(u"Unprintable exception InvalidPattern: dict={'args': (), 'msg': 'msg', 'kwargs': {}}, fmt=None, error=%(repr)s")
    test_case_0()

    #test for method InvalidPattern._get_format_string

    #test for method InvalidPattern._format

    # test for method InvalidPattern.__unicode__
    var_7 = InvalidPattern('msg')


# Generated at 2022-06-26 02:21:34.278648
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    inst = InvalidPattern('a')
    # call function
    result = inst.__unicode__()
    # verify that results are as expected
    assert result == "a"


# Generated at 2022-06-26 02:21:35.213335
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern()


# Generated at 2022-06-26 02:21:36.164652
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    pass # TODO implement test


# Generated at 2022-06-26 02:21:38.485996
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex(('[a-b]',), {})
    var_1 = getattr(var_0, 'findall')



# Generated at 2022-06-26 02:21:43.563689
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern((u"a",))
    try:
        var_1 = var_0._get_format_string()
    except Exception:
        var_2 = None
    else:
        var_2 = var_1
    var_3 = dict()
    var_4 = unicode()
    var_3["msg"] = var_4
    var_5 = var_2 % var_3
    var_6 = var_0.__str__()
    var_7 = var_5 == var_6


# Generated at 2022-06-26 02:21:45.590740
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_0 = lazy_compile()
    var_0.__setstate__({'args': ('a',), 'kwargs': {}})


# Generated at 2022-06-26 02:21:47.339686
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_0 = LazyRegex((), {})
    var_0.__setstate__({})


# Generated at 2022-06-26 02:21:49.480109
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    proxy = LazyRegex(['foo'])
    try:
        proxy.abc
    except AttributeError:
        pass


# Generated at 2022-06-26 02:22:05.964414
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    var_2 = InvalidPattern(var_1)
    var_3 = str(var_2)
    var_4 = var_2.__str__()
    var_5 = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    var_6 = var_3 == var_5
    var_7 = var_4 == var_5


# Generated at 2022-06-26 02:22:07.399438
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern()
    var_1 = str(var_0)


# Generated at 2022-06-26 02:22:11.931197
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_7 = lazy_compile('x', 0)
    var_8 = var_7.__getstate__()
    var_9 = lazy_compile()
    var_9.__setstate__(var_8)


# Generated at 2022-06-26 02:22:15.326256
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'some error'
    e1 = InvalidPattern(msg)
    e2 = InvalidPattern(msg)
    # The two exception objects are different, but their string
    # representation should be identical.
    assert str(e1) == str(e2)

# Generated at 2022-06-26 02:22:21.002319
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    arg_1 = '\w'
    arg_2 = 0
    var_0 = lazy_compile(arg_1, arg_2)
    var_1 = var_0.__getattr__('pattern')
    var_2 = var_1 == '\w'

# Generated at 2022-06-26 02:22:23.632557
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():

    instance = InvalidPattern('msg')
    result = instance.__unicode__()
    assert result.find('Invalid') >= 0

# vim: set fileencoding=utf-8 :

# Generated at 2022-06-26 02:22:27.646911
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("foo")
    var_1 = str(var_0)
    assert var_1 == "Invalid pattern(s) found. foo"


# Generated at 2022-06-26 02:22:34.929192
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test with a str attribute.
    #
    # This test is disallowed by pychecker:
    # pychecker.py -r bzrlib/tests/regex_tests.py
    # *** arg 3 to isinstance() must be type or tuple of types.
    assert isinstance(InvalidPattern('foo'), InvalidPattern)
    assert str(InvalidPattern('foo')) == 'foo'
    import re
    assert str(InvalidPattern(re.error('foo'))) == 'foo'


# Generated at 2022-06-26 02:22:44.676080
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test for entry points that are only in 2.6 or 2.7
    if not hasattr(invalid_pattern_0, '__unicode__'):
        return
    # Test for entry points that are only in 2.6 or 2.7
    if not hasattr(invalid_pattern_1, '__unicode__'):
        return
    # Test for entry points that are only in 2.6 or 2.7
    if not hasattr(invalid_pattern_2, '__unicode__'):
        return
    # Test for entry points that are only in 2.6 or 2.7
    if not hasattr(invalid_pattern_3, '__unicode__'):
        return

# Generated at 2022-06-26 02:22:52.945012
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pattern_instance = InvalidPattern('')
    pattern_instance._preformatted_string = ''
    assert 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None' \
        == pattern_instance.__str__()

    pattern_instance = InvalidPattern('')
    pattern_instance._get_format_string = lambda: None
    assert 'Unprintable exception InvalidPattern: dict={\'msg\': \'\'}, fmt=None, error=None' \
        == pattern_instance.__str__()

# Generated at 2022-06-26 02:23:10.433814
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    from bzrlib import not_a_module

    from bzrlib.regex import LazyRegex
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import ModuleAvailableFeature

    class _test_case_1(TestCase):

        _test_needs_features = [ModuleAvailableFeature('not_a_module')]

        def test_case_0(self):
            var_0 = LazyRegex()
            self.assertRaises(AttributeError, var_0.__getattr__, 'not_a_member')
            exception_var_0 = self.assertRaises(AttributeError, getattr, var_0, 'asdf')
            self.assertIs(exception_var_0.args, ('asdf',))

    _test_case_1(
        )


# Generated at 2022-06-26 02:23:12.658269
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    global var_0
    var_0 = InvalidPattern('')



# Generated at 2022-06-26 02:23:15.730555
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern('toto')
    # Test return value
    var_1.__str__()
    # Test that the expected exception was raised
    try:
        raise Exception
    except Exception:
        pass


# Generated at 2022-06-26 02:23:22.870340
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    var_0 = LazyRegex()
    var_1 = {
            "args": "6e2b6a51-e1d8-46e9-9dea-70dcbfe6c827",
            "kwargs": "6f3e3c2d-9690-414b-86c0-64d8286c7fae",
            }
    var_0.__setstate__(var_1)


# Generated at 2022-06-26 02:23:28.709655
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return str(self).

    >>> class TestError(InvalidPattern):
    ...     _fmt = 'fmt %(x)s'
    ...     def __init__(self, x):
    ...         self.x = x
    >>> print TestError('foo')
    fmt foo
    >>> print TestError('bar')
    fmt bar
    """


# Generated at 2022-06-26 02:23:31.991972
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # This assertion will raise either a ValueError or AssertionError if the
    # message is incorrect.
    AssertionError(InvalidPattern('Invalid pattern(s) found. '
                                  '"\\d+" nothing to repeat at position 0').__unicode__())


# Generated at 2022-06-26 02:23:44.045144
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from pickle import dumps, loads
    from pprint import pformat
    foo = lazy_compile('foo')
    assert(foo.__setstate__ == LazyRegex.__setstate__)
    assert(foo._regex_args == ('foo',))
    assert(foo._regex_kwargs == {})
    assert(foo._real_regex is None)
    s = dumps(foo)
    assert(s != "")
    # print("Dump is:\n%s" % pformat(s))
    bar = loads(s)
    assert(bar is foo)
    assert(bar._regex_args == ('foo',))
    assert(bar._regex_kwargs == {})
    assert(bar._real_regex is None)
    assert(bar.search("abc") == None)

# Generated at 2022-06-26 02:23:55.486587
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("message")
    var_1 = InvalidPattern("message")
    var_2 = list()
    var_3 = None
    var_4 = "\x00"
    var_5 = 0
    var_6 = "\x00"
    var_7 = "\x00"
    var_8 = "\x00"
    var_9 = "\x00"
    var_10 = "\x00"
    var_11 = "\x00"
    var_12 = "\x00"
    var_13 = "\x00"
    var_14 = "\x00"
    var_15 = "\x00"
    var_16 = "\x00"
    var_17 = "\x00"
    var_18 = "\x00"
    var_19 = "\x00"

# Generated at 2022-06-26 02:24:00.167184
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    obj = InvalidPattern.__new__(InvalidPattern)
    var_0 = InvalidPattern._get_format_string(obj)
    InvalidPattern.__init__(obj, 'a')
    var_1 = InvalidPattern._get_format_string(obj)

    assert(var_0 is None)
    assert(var_1 is None)


# Generated at 2022-06-26 02:24:01.954809
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    var_0 = InvalidPattern()
    var_1 = unicode(var_0)


# Generated at 2022-06-26 02:24:14.302705
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    v = InvalidPattern('x')
    assert type(v.__str__()) is str
    assert ': x' in v.__str__()


# Generated at 2022-06-26 02:24:16.810139
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    instance = InvalidPattern(None)
    result = instance.__str__()


# Generated at 2022-06-26 02:24:18.752878
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_1 = InvalidPattern()
    assert(isinstance(var_1.__str__(), str))


# Generated at 2022-06-26 02:24:26.131743
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # __unicode__ must always return a unicode string.
    # Check that the case where all of the attributes of the exception are
    # defined.
    var_1 = InvalidPattern('Message')
    var_1._preformatted_string = 'Error'
    var_2 = var_1._get_format_string()
    var_3 = u'Error'
    var_1._fmt = 'Test case: 0'
    var_4 = var_1._format()
    var_5 = u'Test case: 0'
    # Check that the case when no format string is defined.
    var_6 = InvalidPattern('Message')
    var_7 = var_6._get_format_string()
    var_8 = None
    var_9 = var_6._format()

# Generated at 2022-06-26 02:24:32.428863
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    var_0 = LazyRegex()
    try:
        var_1 = var_0.__getattr__()
    except:
        var_1 = None
    assert var_1 is None or isinstance(var_1,
                                       (bool, int, long, float, complex))



# Generated at 2022-06-26 02:24:34.955732
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():

    # bad regex should raise InvalidPattern
    r = re.compile('(abc')
    e = raises(InvalidPattern, 'r.match("abc")')


# Generated at 2022-06-26 02:24:38.258111
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from StringIO import StringIO
    sio = StringIO()
    err = InvalidPattern("test for InvalidPattern.__str__")
    print(err, file=sio)
    return sio.getvalue()



# Generated at 2022-06-26 02:24:44.552425
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    builder = StringBuilder()
    builder.append("Unprintable exception InvalidPattern: dict={}, fmt=None, error=None")
    builder.append("")
    string_1 = builder.toString()
    var_0 = InvalidPattern("test_InvalidPattern___unicode__")
    var_1 = var_0.__unicode__() # __unicode__ must return a unicode object
    var_2 = var_1 == string_1
    pass # var_2 == True


# Generated at 2022-06-26 02:24:54.281553
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('Not applicable')
    # fmt contains no parameters
    assert unicode(e) == 'Not applicable'
    # fmt contains parameters
    e = InvalidPattern('"%(pattern)s" %(msg)s')
    e.pattern = 'foo'
    e.msg = 'bar'
    assert unicode(e) == '"foo" bar'
    del e.pattern
    assert unicode(e) == '"%(pattern)s" bar'
    # fmt contains known parameter and unknown parameter
    e = InvalidPattern('"%(pattern)s" %(msg)s')
    e.pattern = 'foo'
    e.unknown = 'unknown'
    assert unicode(e) == '"foo" %(msg)s'
    # fmt contains unknown parameter

# Generated at 2022-06-26 02:24:56.703419
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() -> string

    Return a string representation of the exception.
    """
    # __str__ returns a str or unicode object


# Generated at 2022-06-26 02:25:10.497257
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    var_0 = InvalidPattern("")
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:25:14.492208
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    var_0 = InvalidPattern("Test message")
    var_1 = gettext("Test message")
    var_2 = var_0.__unicode__()
    var_3 = var_1 == var_2
    assert(var_3)

# Generated at 2022-06-26 02:25:25.346066
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    # We need to install a function that will return a translated string in
    # order to test InvalidPattern.__unicode__
    def gettext(str):
        return unicode(str)
    import bzrlib.errors
    bzrlib.errors.gettext = gettext
    invalid_pattern_1 = InvalidPattern('expected')
    invalid_pattern_1.msg = 'pattern'
    # Method __unicode__ of class InvalidPattern must return a unicode object
    expected_result = 'Invalid pattern(s) found. pattern'
    actual_result = unicode(invalid_pattern_1)
    assert (expected_result == actual_result), \
        "Expectation %s does not match Actual %s" % \
        (expected_result, actual_result)

# Generated at 2022-06-26 02:25:33.880772
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalidpattern = InvalidPattern()
    unicode_instance = unicode(invalidpattern)
    str_instance = str(invalidpattern)
    repr_instance = repr(invalidpattern)
    assert unicode_instance == unicode(str_instance)
    assert unicode_instance == unicode(repr_instance)


if __name__ == '__main__':
    import sys
    if '--coverage' in sys.argv[1:]:
        import trace
        tracer = trace.Trace(trace=0, count=1)
        tracer.run('reload(__main__)')
        r = tracer.results()
        r.write_results(show_missing=True, summary=True, coverdir=".")
        #import sys; sys.exit(0)

    import doctest