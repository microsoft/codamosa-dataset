

# Generated at 2022-06-24 02:43:11.871482
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    regex = re.compile('^str$')
    for x in regex, regex.match, regex.search:
        assert isinstance(x, LazyRegex)
    reset_compile()



# Generated at 2022-06-24 02:43:18.305088
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    # Test that the pickle format is correctly reconstituted
    from bzrlib import ui
    from bzrlib.tests.blackbox.test_blackbox import TestCaseWithTransport
    from cStringIO import StringIO
    import pickle
    import os
    class LazyRegexTest(TestCaseWithTransport):
        def _check_re(self, re, key):
            out, err = StringIO(), StringIO()
            self.overrideAttr(ui, '_output_streams', out)
            self.overrideAttr(ui, '_error_streams', err)
            print >> ui._output_streams, re
            print >> ui._error_streams, re
            pattern = re._regex_args[0]

# Generated at 2022-06-24 02:43:23.131672
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the install_lazy_compile function

    :return: None
    """
    install_lazy_compile()
    # Ensure that we can compile a regex
    re.compile("(foo)")
    reset_compile()

# Generated at 2022-06-24 02:43:29.794296
# Unit test for function reset_compile
def test_reset_compile():
    """Test function reset_compile."""

    # Check that reset_compile really does reset the compile function
    install_lazy_compile()
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("re.compile has not been reset")

    # Check that multiple calls to reset_compile do nothing
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("re.compile has not been reset")

# Generated at 2022-06-24 02:43:38.093084
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex.

    An instance of LazyRegex class is used to store an attribute
    that is not yet available at the time of creation. This method
    takes the attribute name as parameter, and returns its value.

    The attribute name is converted to lower case before being used
    to access the attribute.
    """
    # Create a LazyRegex instance.
    r = LazyRegex()

    # Attribute _real_regex is not yet available.
    # It is a private attribute of class LazyRegex.
    # Its value is set by method _compile_and_collapse() of class LazyRegex.

# Generated at 2022-06-24 02:43:42.389292
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex.

    Test that state is not accessible before regex is compiled and
    is available (but not evaluated) after compilation.
    """
    lazy_regex = LazyRegex('a')
    state = lazy_regex.__getstate__()
    assert isinstance(state, dict), (
        "state should be dict, it is %r" % state)
    lazy_regex._compile_and_collapse()
    assert lazy_regex.__getstate__() is state, (
        "__getstate__ returned different state after compilation.")


# Generated at 2022-06-24 02:43:47.894813
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    msg = "Message"
    e1 = InvalidPattern(msg)
    e2 = InvalidPattern(msg)
    assert e1 == e2
    e3 = InvalidPattern("Message1")
    assert e3 != e2
    assert e3 != 1
    assert e3 != object()

# Generated at 2022-06-24 02:43:52.578735
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex"""
    proxy = LazyRegex()
    state = {'args':('^a$',), 'kwargs':{}}
    proxy.__setstate__(state)
    assert proxy._regex_args[0] == '^a$'

# Generated at 2022-06-24 02:43:56.201552
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    exc4 = InvalidPattern("some message")
    exc5 = InvalidPattern("some message")
    assert exc4 == exc5

if __name__ == '__main__':
    test_InvalidPattern___unicode__()

# Generated at 2022-06-24 02:44:04.778837
# Unit test for function finditer_public
def test_finditer_public():
    """Test finditer_public function."""
    global re
    from bzrlib.tests import TestCase
    import re as re_base
    saved = re_base.finditer
    re = re_base

# Generated at 2022-06-24 02:44:12.187144
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Method __getstate__ of LazyRegex class must return dictionary

    with arguments of the method __init__
    """
    regex1 = lazy_compile("(\\d+)")
    state1 = regex1.__getstate__()
    regex2 = LazyRegex(state1['args'], state1['kwargs'])
    state2 = regex2.__getstate__()
    assert(state1 == state2)



# Generated at 2022-06-24 02:44:21.010559
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test restoration from pickled state.

    This test checks if the method __setstate__ restores a pickled state
    successfully.
    """
    a = LazyRegex(args=("foo",), kwargs={"flags": re.IGNORECASE})
    a._compile_and_collapse()
    b = LazyRegex()
    b.__setstate__(a.__getstate__())
    # check if an exception is thrown when trying to find a string which
    # does not exist
    try:
        b.findall("bar")
    except InvalidPattern:
        pass
    else:
        raise AssertionError("LazyRegEx did not throw an exception when"
                             " it should have.")
    # check if an exception is thrown when the regex is empty

# Generated at 2022-06-24 02:44:32.708504
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # two InvalidPatterns with the same msg and _fmt should be equal
    a = InvalidPattern('msg')
    b = InvalidPattern('msg')
    assert a == b
    # two InvalidPatterns with the same msg but different _fmt should not be
    # equal
    a = InvalidPattern('msg')
    b = InvalidPattern('msg')
    a._fmt = 'fmt1'
    b._fmt = 'fmt2'
    assert a != b
    # two InvalidPatterns with the different msg but the same _fmt should not
    # be equal
    a = InvalidPattern('msg1')
    b = InvalidPattern('msg2')
    a._fmt = 'fmt'
    b._fmt = 'fmt'
    assert a != b
    # two InvalidPatterns with different msg and _fmt should

# Generated at 2022-06-24 02:44:43.141911
# Unit test for function reset_compile
def test_reset_compile():
    """test_reset_compile ensures that reset_compile() works"""
    # Test that the current re.compile() is the original
    # Note that we don't compare re.compile == _real_re_compile because
    # re.compile could be a different function that still operates
    # like the original (even though such cases are not supported).
    # But re.compile is the right function to use to check that reset
    # works.
    p = re.compile('.')
    # Check that it works when the proxy is not in use
    reset_compile()
    p2 = re.compile('.')
    assert p is p2
    # Call install_lazy_compile again
    reset_compile()
    # Call install_lazy_compile again, but this time use lazy_compile


# Generated at 2022-06-24 02:44:55.687870
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the pickle state of LazyRegex objects."""
    import pickle, cStringIO
    exp_args = (1, 2, 3)
    exp_kwargs = {'a': 1, 'b': 2}
    # Create a LazyRegex object
    lr = LazyRegex(exp_args, exp_kwargs)
    # Test the result of __getstate__.
    dict = lr.__getstate__()
    assert dict == {'args': exp_args, 'kwargs': exp_kwargs}
    # Test that the LazyRegex can be pickled and unpickled
    pickled = pickle.dumps(lr)
    lr_unpickled = pickle.loads(pickled)
    assert lr_unpickled._regex_args == exp_args

# Generated at 2022-06-24 02:45:03.893774
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests.blackbox import ExternalBase

    class TestLazyRegex(ExternalBase):

        def test_lazy_compile(self):
            install_lazy_compile()
            try:
                re_compile = re.compile
                self.assertIs(re_compile, lazy_compile)
                reset_compile()
                self.assertIsNot(re_compile, lazy_compile)
                self.assertIs(re_compile, _real_re_compile)
            finally:
                reset_compile()
                self.assertIs(re_compile, _real_re_compile)

    TestLazyRegex('test_lazy_compile').run_tests()

# Generated at 2022-06-24 02:45:15.096837
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test method __str__ of class InvalidPattern."""

# Generated at 2022-06-24 02:45:20.086102
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # Unicode characters to trigger unicode(e) in __str__.
    msg = u'\N{GREEK CAPITAL LETTER OMEGA}'
    e = InvalidPattern(msg)
    assert repr(e) == 'InvalidPattern(%s)' % msg

# Generated at 2022-06-24 02:45:28.675802
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Unit test the constructor of the LazyRegex class."""
    lazy = LazyRegex()
    assert isinstance(lazy, LazyRegex)

    lazy = LazyRegex(['a', 'b'])
    assert isinstance(lazy, LazyRegex)

    lazy = LazyRegex(['a', 'b'], {'c': 'd'})
    assert isinstance(lazy, LazyRegex)


install_lazy_compile()

# Generated at 2022-06-24 02:45:32.875019
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string."""
    e = InvalidPattern('foo')
    assert isinstance(e.__repr__(), str)
    e = InvalidPattern('f\xc3\xb6\xc3\xb6')
    assert isinstance(e.__repr__(), str)



# Generated at 2022-06-24 02:45:42.434198
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # test the constructor
    # msg is translated
    e = InvalidPattern('error: %(msg)s')
    e.msg = "translated msg"
    # the exception is translated
    s = unicode(e)
    if str(e) != "error: translated msg":
        raise AssertionError("Bad text: %s" % s)
    # msg is not translated
    e = InvalidPattern('error: %s')
    e.msg = "translated msg"
    s = unicode(e)
    if str(e) != "error: translated msg":
        raise AssertionError("Bad text: %s" % s)
    # msg is not translated
    e = InvalidPattern("error: %s" % "translated msg")
    s = unicode(e)

# Generated at 2022-06-24 02:45:49.553679
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('test')
    except InvalidPattern as error:
        assert str(error) == 'Unprintable exception InvalidPattern: dict={\'msg\': \'test\'}, fmt=\'Invalid pattern(s) found. %(msg)s\', error=None'
        assert unicode(error) == u'Unprintable exception InvalidPattern: dict={\'msg\': \'test\'}, fmt=\'Invalid pattern(s) found. %(msg)s\', error=None'

# Generated at 2022-06-24 02:45:52.447944
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    error_msg = "Test message"
    error1 = InvalidPattern(error_msg)
    error2 = InvalidPattern(error_msg)
    assert error1 == error2



# Generated at 2022-06-24 02:45:56.921360
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() works."""
    re.compile = lambda *a, **kw: "This is a test"
    reset_compile()
    from bzrlib.tests import TestCase
    TestCase.assertIs(_real_re_compile, re.compile)

# Generated at 2022-06-24 02:45:59.902458
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert re.compile is lazy_compile
    reset_compile()


# Generated at 2022-06-24 02:46:10.293086
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile works correctly.

    The tests have to be independant of each other, as the changes
    are global for the entire module.
    """
    # Test that we can actually compile regexs in this state
    r1 = re.compile('(?P<name>.*)')
    if r1.groupindex['name'] != 1:
        raise AssertionError('Could not compile regex')

    # Test that it is safe to call this more than once
    install_lazy_compile()
    install_lazy_compile()
    r1 = re.compile('(?P<name>.*)')
    if r1.groupindex['name'] != 1:
        raise AssertionError('Could not compile regex')

    # Test that we can compile more than one regex

# Generated at 2022-06-24 02:46:15.694119
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Ensure install_lazy_compile replaces re.compile as expected"""
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
        regex = re.compile('^test$')
        assert regex._real_regex is None
        regex.match('test')
        assert regex._real_regex is not None
    finally:
        reset_compile()

# Generated at 2022-06-24 02:46:22.230077
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('something')
    assert e.msg == 'something'
    assert e._format() == 'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r' % ({'msg': 'something'}, None, None)
    assert e._get_format_string() == None
    assert str(e) == 'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r' % ({'msg': 'something'}, None, None)
    assert repr(e) == 'InvalidPattern(Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r)' % ({'msg': 'something'}, None, None)
    assert unicode(e) == u'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r'

# Generated at 2022-06-24 02:46:24.859302
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lre = LazyRegex('foo')
    assert getattr(lre, '__slots__') is LazyRegex.__slots__


# Generated at 2022-06-24 02:46:29.758490
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    regex = LazyRegex(args=('(?:a|b)+',), kwargs={})
    pattern = '(?:a|b)+'
    regex.__setstate__({'args': (pattern,), 'kwargs': {}})
    eq = [regex._regex_args[0], pattern]
    assert eq

# Generated at 2022-06-24 02:46:35.126044
# Unit test for function finditer_public
def test_finditer_public():
    string = u'a b c d e'
    pattern = LazyRegex((r' ', 0))

    r1 = re.finditer(pattern, string)
    r2 = re.finditer(r' ', string)

    assert r1.next() == r2.next()
    assert r1.next() == r2.next()
    assert r1.next() == r2.next()
    assert r1.next() == r2.next()

# Generated at 2022-06-24 02:46:42.069806
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests creation of InvalidPattern, and test __str__ method of
    InvalidPattern.
    """
    def get_str(err):
        """get_str returns a string with the same results, no matter
        whether the returned type is str or unicode.
        """
        try:
            return str(err)
        except UnicodeEncodeError:
            return unicode(err).encode('utf-8')

    err = InvalidPattern('pattern')
    # test with format string
    eq = 'Invalid pattern(s) found. pattern'
    eq_(get_str(err), eq)
    # test with format string and extra arguments
    err = InvalidPattern('pattern %s')
    eq = 'Invalid pattern(s) found. pattern %s'
    eq_(get_str(err), eq)
    # test without format string

# Generated at 2022-06-24 02:46:51.153504
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    class TestInvalidPattern(InvalidPattern):
        _fmt = u'An invalid pattern %(pattern)s'
    t = TestInvalidPattern(pattern=u'foo')
    s = t._format()
    if not isinstance(s, unicode):
        raise Exception('InvalidPattern._format() returned %r' % (s,))
    u = t.__unicode__()
    if not isinstance(u, unicode):
        raise Exception('InvalidPattern.__unicode__ returned %r' % (u,))
    # Check that the invalid pattern is in the string
    if u.find(u'foo') == -1:
        raise Exception('InvalidPattern.__unicode__ returned %r' % (u,))
    # Check for a preformatted message
    t._preformatted_string = u'A message'
    u

# Generated at 2022-06-24 02:46:59.684698
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lr = LazyRegex(args=('foo', re.IGNORECASE), kwargs={})
    lr._compile_and_collapse()
    lr.search('abc')
    pickled_str = _pickle.dumps(lr)
    # if LazyRegex.__setstate__ didn't use the 'args' and 'kwargs' in the
    # passed-in 'dict', then the following line will raise an exception as
    # it is trying to search for a pattern that does not exist in the 'abc'
    # string.
    _pickle.loads(pickled_str).search('abc')

# Generated at 2022-06-24 02:47:10.891269
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method __getattr__ of class LazyRegex.

    This test must be executed in the scope of the module where LazyRegex
    is defined.
    """
    import unittest

    from re import error

    # Create a dummy class for testing
    class Dummy(object):
        def __init__(self):
            self.the_attr = 42
            self.the_method = lambda x: x + 1

        def __getattr__(self, attr):
            raise AttributeError('Dummy object')

    class LazyRegexTest(unittest.TestCase):
        def setUp(self):
            self.dummy = Dummy()
            self.proxy = LazyRegex()

        def test__getattr__(self):
            self.proxy._real_regex = self.dummy



# Generated at 2022-06-24 02:47:13.579635
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    pattern = LazyRegex(r'^a', re.I | re.M)
    state = pattern.__getstate__()
    assert state.keys() == ['args', 'kwargs']


# Generated at 2022-06-24 02:47:22.357809
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    _regex_args = (r"abc", )
    _regex_kwargs = {}
    _regex = LazyRegex(_regex_args, _regex_kwargs)
    state = _regex.__getstate__()
    assert state == {
            "args": _regex_args,
            "kwargs": _regex_kwargs,
            }
    # A lazy regex has not been compiled yet.
    assert _regex._real_regex is None



# Generated at 2022-06-24 02:47:25.926263
# Unit test for function reset_compile
def test_reset_compile():
    """Check that reset_compile works"""
    assert re.compile is not _real_re_compile
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-24 02:47:28.002866
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from doctest import DocTestSuite
    suite = DocTestSuite()
    suite.level = 2
    return suite



# Generated at 2022-06-24 02:47:36.529109
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import sys
    if sys.version_info >= (3, 0):
        raise TestSkipped('3.0 no longer has re.error')

    # Should raise InvalidPattern
    try:
        regex = LazyRegex(['[\\'])
    except InvalidPattern as e:
        pass
    else:
        raise TestSkipped("InvalidPattern should have been raised")

    # Should be OK
    regex = LazyRegex(['[\\]'])

    # Should be OK
    regex = LazyRegex(['[\\]]'])

    # should raise InvalidPattern
    try:
        regex = LazyRegex(['[\\])'])
    except InvalidPattern as e:
        pass
    else:
        raise TestSkipped("InvalidPattern should have been raised")

# Generated at 2022-06-24 02:47:46.681781
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test __str__ method of InvalidPattern class"""
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'a %(arg1)s b %(arg2)s c'
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
    ip = MyInvalidPattern('alpha', 'bravo')
    assert str(ip) == 'Unprintable exception MyInvalidPattern: ' \
        'dict={"arg2": "bravo", "arg1": "alpha"}, ' \
        'fmt="a %(arg1)s b %(arg2)s c", error=None'

# Generated at 2022-06-24 02:47:49.903555
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert re.compile is lazy_compile, "install_lazy_compile failed"
    reset_compile()

# Generated at 2022-06-24 02:48:01.260024
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ must restore the state of the object.

    This actually tests the method __setstate__ of class LazyRegex.
    """
    from . import unittest

    class LazyRegexTest(unittest.TestCase):
        def test_setstate(self):
            import pickle
            regex_args = ('^.*$', re.IGNORECASE | re.MULTILINE)
            regex_kwargs = {}
            lazy = LazyRegex(regex_args, regex_kwargs)
            lazy_pickle = pickle.dumps(lazy)
            pickled_lazy = pickle.loads(lazy_pickle)
            self.assertEquals(pickled_lazy._regex_args, regex_args)


# Generated at 2022-06-24 02:48:10.539679
# Unit test for function finditer_public
def test_finditer_public():
    """Finditer_public should work with or without lazy compilation"""
    old_finditer = re.finditer
    try:
        re.finditer = _real_re_compile
        count = 0
        for i in re.finditer(r"\w{3}", "abcd"):
            count += 1
        count2 = 0
        for i in re.finditer(r"\w{3}", "abcd"):
            count2 += 1
        if count != 1 or count2 != 1:
            raise AssertionError
    finally:
        re.finditer = old_finditer

# Generated at 2022-06-24 02:48:14.110260
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ must return a dictionary."""

    # __getstate__ must return a dictionary
    # since the dictionary can't be manipulated (it's read-only),
    # its content is not tested 
    # setup
    l = LazyRegex()

    # test
    assert isinstance(l.__getstate__(), dict)


# Generated at 2022-06-24 02:48:17.501986
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import doctest
    from . import tests

    try:
        tests.TestCase.setUp(None)
        doctest.testmod()
    finally:
        tests.TestCase.tearDown(None)


# Generated at 2022-06-24 02:48:22.017969
# Unit test for function reset_compile
def test_reset_compile():
    try:
        import bzrlib.tests
    except ImportError:
        return
    # check we can reset compile
    install_lazy_compile()
    bzrlib.tests.TestCase.run_tests()
    reset_compile()
    bzrlib.tests.TestCase.run_tests()

# Generated at 2022-06-24 02:48:29.131065
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """For each line in a given file, check if it matches a regex.

    This function takes a regex pattern and a filename; it opens the file and
    reads it line by line to see if the pattern matches. This implementation
    compiles the regex only once, making it efficient when the same pattern
    has to be used on many subjects.

    """
    import gzip
    import bz2

    def process(filename, regex=None):
        if regex is None:
            # default argument; re-use the same compiled regex
            regex = re.compile(r"\w+ \w+")

        fp = open(filename)
        if filename.endswith(".gz"):
            fp = gzip.open(filename)
        elif filename.endswith(".bz2"):
            fp = bz2.B

# Generated at 2022-06-24 02:48:30.196255
# Unit test for function reset_compile
def test_reset_compile():
    # Test that reset_compile can be called multiple times
    for i in range(5):
        reset_compile()

# Generated at 2022-06-24 02:48:33.165887
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that str(InvalidPattern) just works.

    This is a regression test for bug 744427.
    """
    str(InvalidPattern("foo"))

# Generated at 2022-06-24 02:48:44.206526
# Unit test for function lazy_compile
def test_lazy_compile():
    # Check that we actually compile on the first access
    import gc
    _re = re.compile("^$")
    def check_proxy_returns_same_object(pattern, flags=0):
        _proxy = re.compile(pattern, flags)
        # We need to collect the reference to the real_regex, because we
        # will be storing just the proxy object in the list.
        # this isn't an issue in real code as the real_regex will be
        # stored somewhere else as well.
        real_regex = getattr(_proxy, '_real_regex', None)
        _real_regex_id = id(real_regex)
        _l = [_proxy]
        del _proxy
        del real_regex
        gc.collect()

# Generated at 2022-06-24 02:48:55.036872
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex."""
    regex = LazyRegex(args=('foo[0-9]+',), kwargs={'flags': re.IGNORECASE})
    for i in range(5):
        # Each iteration of this loop should be the same as the previous one,
        # which is to say the pickled state should be sufficient to restore
        # the regex. If the regex weren't restored, accessing members of
        # the regex would cause infinite recursion, as __getattr__ would
        # call _regex_args and _regex_kwargs, which would lead back to
        # __getattr__, and so on.
        old_state = regex.__getstate__()
        regex.__setstate__(old_state)
        # Check that the object still proxies attributes

# Generated at 2022-06-24 02:48:58.537513
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ of class LazyRegex"""
    r = LazyRegex(('[^/]+',))
    assert not hasattr(r, "hello")
    r.hello = "world"
    assert hasattr(r, "hello")
    assert r.hello == "world"



# Generated at 2022-06-24 02:49:02.993735
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    x = LazyRegex(("^\d{2}\:\d{2}$",), {})
    x._compile_and_collapse()
    y = pickle.loads(pickle.dumps(x))
    assert (x._real_regex.pattern == y._real_regex.pattern)

# Generated at 2022-06-24 02:49:09.300698
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ of the class LazyRegex

    This can test both if the attribute is missing or not.
    """
    regex = LazyRegex()
    try:
        regex.match("")
    except AttributeError:
        # It may fail if the attribute is missing
        pass
    else:
        # Or it may work if the attribute exists.
        pass

# Generated at 2022-06-24 02:49:17.017877
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    test_input = [(r'ab+c', {}), (r'\w+\s+\d{2,3}', {'flags': re.I})]
    test_output = [{'args': (r'ab+c',), 'kwargs': {}},
                   {'args': (r'\w+\s+\d{2,3}',), 'kwargs': {'flags': re.I}}]
    for i in range(len(test_input)):
        lr = LazyRegex(test_input[i][0], test_input[i][1])
        assert lr.__getstate__() == test_output[i]


# Generated at 2022-06-24 02:49:24.184008
# Unit test for function finditer_public
def test_finditer_public():
    """test the overriden re.finditer method"""

    # Check that a regular re behaves the same
    r = re.compile('a')
    m = r.finditer('ba')
    assert len(list(m)) == 1

    # Check that a LazyRegex behaves the same
    r = lazy_compile('a')
    m = r.finditer('ba')
    assert len(list(m)) == 1

# Generated at 2022-06-24 02:49:29.339943
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import osutils
    from bzrlib.i18n import gettext
    msg = 'msg'
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        # Validate the object's attributes
        s = e._format()
        s = unicode(s)
        if gettext:
            # Translate test should be the same as the untranslated one.
            s = gettext(s)
        # Check that s is a unicode object
        osutils.safe_unicode(s)

# Generated at 2022-06-24 02:49:41.935616
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should provide consistent and stable results"""
    # We can't easily test that two distinct instances will not be "equal",
    # so we just test that the rest of the code behaves consistently when
    # comparing the same instance to itself.

    # Without overriding __eq__, the default 'is' comparison is used, which
    # compares references and not values.
    e = InvalidPattern(None)
    assert e == e

    # With overriding __eq__, the values should be compared.
    # We override __eq__ in LazyRegex and InvalidPattern.
    # If we write
    #   assert LazyRegex() == LazyRegex()
    # the code ends up in the overridden __eq__ method of InvalidPattern.
    # That causes an infinite recursion.
    assert LazyRegex() == LazyRegex()

# Generated at 2022-06-24 02:49:53.748484
# Unit test for function lazy_compile
def test_lazy_compile():
    from breezy.tests import TestCase
    from breezy.tests.per_regex import TestCaseWithRegex

    class TestLazyRegex(TestCaseWithRegex):

        def test_compiling(self):
            # We don't want to create an actual regex, so it doesn't get
            # compiled at creation time. That way if this test fails it doesn't
            # trigger a Python bug, it is really our fault.
            self.regex = LazyRegex(args=(self.regex_text,))
            self.regex.search(self.sample_text)
            # search didn't raise, so the regex must have been compiled.
            self.assertIsNot(self.regex._real_regex, None)


# Generated at 2022-06-24 02:49:55.897118
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Check that a LazyRegex instance can be pickled"""
    r = LazyRegex((), {})
    r.__getstate__()

# Generated at 2022-06-24 02:50:03.791391
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode object.

    This is because that is what it was defined to do.
    """
    e = InvalidPattern('Error: bad pattern')
    u = unicode(e) # __unicode__ returns a unicode object
    u2 = unicode(u) # __unicode__ should always return a unicode object
    assert type(u2) is unicode
    assert u is u2



# Generated at 2022-06-24 02:50:08.967579
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the __getstate__ method of LazyRegex"""
    proxy = LazyRegex(('(a+)',), {'flags': re.IGNORECASE})
    expected = {
        'args': ('(a+)',),
        'kwargs': {'flags': re.IGNORECASE},
        }
    assert proxy.__getstate__() == expected



# Generated at 2022-06-24 02:50:18.183338
# Unit test for function reset_compile
def test_reset_compile():
    """Ensure that reset_compile works as advertised"""
    install_lazy_compile()

    # Reset twice to ensure that it works regardless of the number of calls
    reset_compile()
    reset_compile()

    # Reset to a fresh install.
    install_lazy_compile()
    reset_compile()

    # Ensure that the re.compile is the same as it was when we first imported
    # re, and isn't the lazy_compile
    assert re.compile is _real_re_compile
    assert re.compile is not lazy_compile

# Generated at 2022-06-24 02:50:20.370575
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test that method __repr__ of class InvalidPattern returns a string."""
    ip = InvalidPattern("Keep this")
    print(repr(ip))

# Generated at 2022-06-24 02:50:32.928173
# Unit test for function lazy_compile
def test_lazy_compile():
    import pickle
    install_lazy_compile()

# Generated at 2022-06-24 02:50:42.713157
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Ensure that installing lazy_compile works"""
    re.compile("anything")
    install_lazy_compile()
    # Make sure that subsequent calls still return a real regex object
    assert isinstance(re.compile(""), LazyRegex)
    # But that it doesn't make nested calls lazy too
    assert not isinstance(re.compile(""), LazyRegex)
    reset_compile()
    # After reset, calls return to normal
    assert not isinstance(re.compile(""), LazyRegex)



# Generated at 2022-06-24 02:50:49.199513
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """This test is only needed because we want to be sure the method __eq__ of
    class InvalidPattern will not call methods (findall and search) on
    _real_regex which maybe not initialized.
    """
    def _real_re_compile(s, *args):
        return s
    re.compile = _real_re_compile

# Generated at 2022-06-24 02:51:00.156067
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ is used by pickle to recreate instances of this class
    after pickling.  This method should restore the original state of the
    instance in a way that is consistent with __getstate__ and __init__.
    """
    try:
        import cPickle as pickle
    except ImportError:
        import pickle
    regex_str = r"^((?P<first>\w+)\s+(?P<second>\w+))$"
    regex_args = (regex_str,)
    regex_kwargs = {}
    regex = LazyRegex(regex_args, regex_kwargs)
    # should not be compiled at this point
    assert regex._real_regex is None
    assert regex._regex_args == regex_args
    assert regex._regex_kwargs == regex_kwargs

# Generated at 2022-06-24 02:51:08.548529
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test InvalidPattern.__str__()"""
    # preformatted to str
    ip1 = InvalidPattern('text')
    ip1._preformatted_string = 'text'
    assert str(ip1) == 'text'
    # unicode
    ip2 = InvalidPattern('text')
    assert str(ip2) == 'text'
    # str
    ip3 = InvalidPattern('test')
    assert str(ip3) == 'test'
    # str with formatting
    ip4 = InvalidPattern('%s')
    ip4.s = 'test'
    assert str(ip4) == 'test'

# vim:et:ts=4:sts=4:sw=4:

# Generated at 2022-06-24 02:51:12.121378
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests InvalidPattern.__str__."""
    class MyException(InvalidPattern):
        _fmt = 'MyException: %(msg)s'
    e = MyException('bad')
    str(e)

# Generated at 2022-06-24 02:51:15.308640
# Unit test for function reset_compile
def test_reset_compile():
    # reset_compile should not break if we haven't called install_lazy_compile.
    reset_compile()
    # Reset again, but this time we should actually be resetting.
    reset_compile()

# Generated at 2022-06-24 02:51:27.395564
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    from bzrlib import tests
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import (
        module_built_with_cext,
        )

    tests.minimal_doctest_setup()

    class TestLazyRegex(TestCase):

        def test_reset_compile(self):
            """Reset compile should restore to original value"""
            re.compile = self
            reset_compile()
            self.assertEqual(_real_re_compile, re.compile)

        def test_lazy_compile(self):
            """Lazy compile should return a proxy object"""
            self.assertIsInstance(lazy_compile('foo'), LazyRegex)


# Generated at 2022-06-24 02:51:37.206386
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from cStringIO import StringIO
    from bzrlib.i18n import gettext
    import sys
    try:
        sys.stderr = StringIO()
        code = "import re\nprint re.compile('(', 0)"
        compile(code, "<test>", "exec")
    except InvalidPattern as e:
        fmt = e._get_format_string()
        if fmt is None:
            return
        if fmt != gettext(u'Invalid pattern(s) found. "%(msg)s"'):
            gettext.install(None)
            raise AssertionError(
                "The string returned by _get_format_string()"
                " is not the expected one, instead:"
                " %s is returned"
                % fmt)

# Generated at 2022-06-24 02:51:48.024635
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """This tests the implementation details of InvalidPattern.__str__()
    """
    import bzrlib.errors as errors
    # In python 2 str() is the same as bytes()
    # so this test should work in both python 2 and python 3

    # Test 'unicode' to 'str' conversion
    s = 'my unicode string'
    u = errors.InvalidPattern(s)
    # t is a str object
    t = str(u)
    # this also validates that u'whatever' is interpreted as a unicode string
    # not as a byte string in python 2.
    assert isinstance(t, str)
    assert t == 'Invalid pattern(s) found. my unicode string'

    # Test 'str' to 'str' copy
    s = 'my unicode string'

# Generated at 2022-06-24 02:51:58.372390
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile actually works."""

    # This is a bit of a tricky one to test. We want to make sure that
    # re.compile is actually being changed and that it will restore it to the
    # original function. The only way to do that is to call re.compile and
    # start passing in things like "raw" and "locale" to make sure that
    # lazy_compile passes them through to re.compile()
    #
    # But re.compile() can't be called before we have overriden it!
    #
    # So we have to test that it can be installed, and then manually check
    # the tests.
    install_lazy_compile()

# Generated at 2022-06-24 02:52:01.030133
# Unit test for function finditer_public
def test_finditer_public():
    """Test finditer public."""
    import doctest
    try:
        doctest.testmod()
    except ImportError:
        # doctest is not available.
        pass

# Generated at 2022-06-24 02:52:12.275679
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test object with _preformatted_string
    t1 = InvalidPattern('msg1')
    t1._preformatted_string = 'msg1'
    assert 'msg1' == str(t1)
    assert isinstance(str(t1), str)

    # Test object with _fmt but with no format variables
    t2 = InvalidPattern('msg2')
    t2._fmt = 'msg2'
    assert 'msg2' == str(t2)
    assert isinstance(str(t2), str)

    # Test object with _fmt and format variables
    t3 = InvalidPattern('msg3')
    t3._fmt = 'Invalid pattern(s) found. %(msg)s'
    t3.msg = 'msg3'

# Generated at 2022-06-24 02:52:23.193530
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from bzrlib.tests.per_intertree import TestCaseWithInterTree
    from bzrlib.tests import test_regex
    from bzrlib import tests
    import re

    class TestRegex(TestCaseWithInterTree):
        """Try to reuse TestRegex in test_regex."""

        def setUp(self):
            super(TestRegex, self).setUp()
            self.tree_a = self.make_branch_and_tree('tree_a')
            self.tree_b = self.make_branch_and_tree('tree_b')
            self.tree_a.commit('one', rev_id='a1',
                               allow_pointless=True, local=True)

# Generated at 2022-06-24 02:52:31.429424
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test __setstate__ of class LazyRegex

    When you unpickle a LazyRegex, it should be lazily compiled
    """
    # Create a LazyRegex
    lr = LazyRegex(("pattern",), {"flags": 1})
    # Pickle it
    import pickle
    p = pickle.dumps(lr)
    # Unpickle it
    from bzrlib.tests import TestCase
    lr2 = pickle.loads(p)
    # Verify that it is lazy
    self.assertIsInstance(lr2, LazyRegex)
    self.assertIs(lr2._real_regex, None)

# Generated at 2022-06-24 02:52:37.403569
# Unit test for function reset_compile
def test_reset_compile():
    if re.compile is not lazy_compile:
        raise AssertionError("re.compile should be lazy_compile")
    reset_compile()
    if re.compile is lazy_compile:
        raise AssertionError("re.compile should be the original compile")
    install_lazy_compile()

# Generated at 2022-06-24 02:52:46.230996
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test unicode representation of InvalidPattern

    The InvalidPattern class defines a unicode representation based on its _fmt
    attribute. We are testing that this attribute is correctly used in
    the __unicode__ method.
    """
    msg = 'this is the error message'
    invalid_pattern = InvalidPattern(msg)
    invalid_pattern._fmt = 'Invalid pattern(s) found. %(msg)s'
    unicode_obj = unicode(invalid_pattern)
    assert unicode_obj == 'Invalid pattern(s) found. this is the error message'

# Generated at 2022-06-24 02:52:48.520664
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """test method __getattr__ of LazyRegex"""
    lazy_regex = lazy_compile("^/foo$")
    assert lazy_regex.match("/foo")

# Generated at 2022-06-24 02:52:51.772496
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()
    relcompile = re.compile
    re.compile = None
    reset_compile()
    assert re.compile is relcompile
test_reset_compile()

# Generated at 2022-06-24 02:52:58.375069
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """The __getattr__ method of LazyRegex proxies calls to __getattr__ of the
        compiled regex.
    """
    proxy = LazyRegex(('(a).*(b)', ))
    # At the beginning the compiled regex is None
    assert proxy._real_regex is None
    # Get a member of the compiled regex.
    assert proxy.pattern == 'a.*b'
    # The method has compiled the regex and stored it in _real_regex
    assert isinstance(proxy._real_regex, _real_re_compile)

# Generated at 2022-06-24 02:53:10.422032
# Unit test for function reset_compile
def test_reset_compile():
    """Reset compile restores the original re.compile handler"""
    # Make sure that the compile handler is reset.
    # This may be a duplicate of the previous test, but it is a bit
    # clearer.
    import bzrlib.tests
    test_result = bzrlib.tests.TestResult()
    test_result.expecting_failure(True)
    import bzrlib.regex
    bzrlib.regex.install_lazy_compile()
    bzrlib.regex.install_lazy_compile()
    bzrlib.regex.install_lazy_compile()
    bzrlib.regex.install_lazy_compile()
    bzrlib.regex.install_lazy_compile()
    bzrlib.regex.install