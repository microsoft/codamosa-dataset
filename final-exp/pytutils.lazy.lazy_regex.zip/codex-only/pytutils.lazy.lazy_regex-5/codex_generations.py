

# Generated at 2022-06-24 02:43:18.281828
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import locale
    from StringIO import StringIO
    from breezy.tests import TestCase
    from breezy.tests.per_repository import TestCaseWithRepository

    try:
        # Make sure all strings are in the default encoding
        # (it is set to 'ascii' by the tests).
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error as e:
        TestCaseWithRepository.knownFailure('Could not set locale: %s' % e)

    class TestInvalidPattern(TestCase):

        def test_unicode(self):
            ex = InvalidPattern('foo')
            # see InvalidPattern __unicode__
            self.assertEqualUnicode(ex.__unicode__(), "foo")
            # now with an non-ascii string

# Generated at 2022-06-24 02:43:19.800309
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ of InvalidPattern class"""
    err1 = InvalidPattern('A')
    assert err1 == InvalidPattern('A')
    err2 = InvalidPattern('B')
    assert err2 != err1



# Generated at 2022-06-24 02:43:30.104345
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    for val in [None, [], (), {}, 42, 42.0, '', u'', True, False]:
        for val2 in [None, [], (), {}, 42, 42.0, '', u'', True, False]:
            pat1 = LazyRegex(val, val2)
            pat2 = LazyRegex(val, val2)
            assert isinstance(pat1, LazyRegex)
            assert isinstance(pat2, LazyRegex)
            assert pat1 is not pat2
            assert pat1 == pat2
            pat1_st = pat1.__getstate__()
            pat2_st = pat2.__getstate__()
            assert pat1_st == pat2_st
            new_pat = LazyRegex()

# Generated at 2022-06-24 02:43:38.349950
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests InvalidPattern.__unicode__."""
    from bzrlib.i18n import gettext

    e = InvalidPattern('')
    assert isinstance(e.__unicode__(), unicode)

    e = InvalidPattern('foo')
    assert isinstance(e.__unicode__(), unicode)

    e._preformatted_string = u'foo bar'
    assert isinstance(e.__unicode__(), unicode)

    # Now try with a preformatted string
    e._preformatted_string = u'\N{greek small letter alpha}'
    assert isinstance(e.__unicode__(), unicode)
    e._preformatted_string = u'\N{greek small letter alpha}'.encode('utf8')

# Generated at 2022-06-24 02:43:40.066573
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:43:51.981782
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Check __str__ method of class InvalidPattern returns appropriate string.

    This test method tests the __str__ method of the InvalidPattern class.
    """
    # In the following tests, the 'Invalid pattern(s) found. '
    # string comes from the _fmt class attribute of class InvalidPattern.
    # The 'Unprintable exception InvalidPattern: dict=
    # {'msg': u'my message', '_preformatted_string': None}, fmt=None, error=None'
    # string comes from the __repr__ of class InvalidPattern.
    # It is used when the evaluated format string is None.
    # The 'Unprintable exception InvalidPattern: dict=
    # {'msg': u'my message', '_preformatted_string': None}, fmt=%(msg)s, error=Error'
    # string comes from the

# Generated at 2022-06-24 02:44:01.452651
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    msg = u'\u201c\xaa\u0112\u0110\u0114'
    e = InvalidPattern(msg)
    # Unicode messages are always accepted and returned as Unicode
    e._preformatted_string = msg
    assert e.__repr__() == u"InvalidPattern(%s)" % msg, e.__repr__()
    # Str objects that represent Unicode are accepted and returned
    # as Unicode.
    e._preformatted_string = msg.encode('utf8')
    assert e.__repr__() == u"InvalidPattern(%s)" % msg, e.__repr__()
    # __repr__ for any other string will be encoded in utf8
    e._preformatted_string = msg.encode('latin1')

# Generated at 2022-06-24 02:44:07.902226
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle

    proxy = LazyRegex(("foo",))
    # No instantiation
    assert proxy._real_regex is None

    # Test that we can pickle the object without instantiating it
    proxy2 = pickle.loads(pickle.dumps(proxy))
    assert proxy2._real_regex is None

    # Test that the proxy can be used
    proxy.findall("foo")
    # Proxy is now instantiated
    assert proxy._real_regex is not None

    # Test that the proxy can be pickled after instantiation
    proxy3 = pickle.loads(pickle.dumps(proxy))
    # Proxy is now instantiated
    assert proxy3._real_regex is not None

# Generated at 2022-06-24 02:44:17.693836
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test getstate of LazyRegex.

    The purpose of this test is to ensure that the LazyRegex is
    serializable and deserializable.
    """
    import pickle
    import zlib
    def pickle_load_unpickle(obj):
        return pickle.loads(pickle.dumps(obj))

    object_state = lambda: None
    object_state.args = "foo"
    object_state.kwargs = {"bar": "foo"}
    lz = LazyRegex(object_state.args, object_state.kwargs)
    lz = pickle_load_unpickle(lz)

    assert(lz._regex_args == object_state.args)
    assert(lz._regex_kwargs == object_state.kwargs)

# Generated at 2022-06-24 02:44:23.554430
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    lr = lazy_compile('a')
    pickled = pickle.dumps(lr)
    lr2 = pickle.loads(pickled)
    assert isinstance(lr2, LazyRegex)
    assert lr2._real_regex is None
    assert lr._regex_args == lr2._regex_args
    assert lr._regex_kwargs == lr2._regex_kwargs

# Generated at 2022-06-24 02:44:29.933580
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test LazyRegex class."""
    install_lazy_compile()

    class Test(object):

        def __init__(self, pattern):
            self.pattern = pattern
            self.regex = re.compile(pattern)

    test_obj = Test('^.*$')
    # Check caching
    assert test_obj.regex is re.compile(test_obj.pattern)
    reset_compile()

# Generated at 2022-06-24 02:44:34.149326
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the method __unicode__ of InvalidPattern in i18n.py.

    This test checks that InvalidPattern raises a custom error message.
    """

# Generated at 2022-06-24 02:44:39.790570
# Unit test for function reset_compile
def test_reset_compile():
    import re
    orig_compile = re.compile
    re.compile = lazy_compile
    try:
        reset_compile()
        # The effect of reset_compile() should be to reset re.compile to
        # a non-lazy compile
        assert re.compile == orig_compile
    finally:
        re.compile = orig_compile



# Generated at 2022-06-24 02:44:44.115106
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    a = InvalidPattern(u'test')
    b = InvalidPattern(u'test')
    c = InvalidPattern(u'test2')

    assert a == a
    assert a == b
    assert b == a
    assert a != c
    assert b != c
    assert c != a
    assert c != b

    assert a != object()

# Generated at 2022-06-24 02:44:48.570083
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    r = lazy_compile("a")
    # The state must be empty, since the real regex hasn't been compiled yet
    assert r.__getstate__() == {}

    r = lazy_compile("a")
    r.search("b")
    # Now the state must contain the args and kwargs we passed in
    assert r._regex_args == ("a",)
    assert r._regex_kwargs == {}
    assert r.__getstate__() == {
            "args": ("a",),
            "kwargs": {},
            }


# Generated at 2022-06-24 02:44:52.546122
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    r = lazy_compile("[a-z]")
    state = r.__getstate__()
    expected = {
        'args': ("[a-z]",),
        'kwargs': {},
    }
    assert state == expected, (state, expected)


# Generated at 2022-06-24 02:44:55.977509
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    LazyRegex('hello')
    LazyRegex(r'^(hello|goodbye)$')
    LazyRegex(r'^(hello|goodbye)$', re.IGNORECASE)
    LazyRegex(r'^(hello|goodbye)$', re.IGNORECASE, re.MULTILINE)

# Generated at 2022-06-24 02:44:59.462288
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object"""
    ip = InvalidPattern('test')
    u = ip.__unicode__()
    assert isinstance(u, unicode)



# Generated at 2022-06-24 02:45:08.956184
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    class TestException(Exception):
        _fmt = "Test exception: %(message)s"
    class TestException2(Exception):
        _fmt = "Test exception: %(message)s"
    class TestException3(Exception):
        _fmt = u"Test exception: %(message)s"
    class TestException4(Exception):
        _fmt = "Test exception: %(message)s"

    # Test unicode message
    try:
        raise TestException(message=u"test-message")
    except TestException as e:
        # unicode
        assert(unicode(e) == u"Test exception: test-message")
        # str
        assert(str(e) == "Test exception: test-message")
        # repr

# Generated at 2022-06-24 02:45:18.315243
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    # If a LazyRegex is pickled, it will be pickled as a dict, which
    # __setstate__ needs to be able to recreate from.
    # If a LazyRegex is pickled and unpickled, it should behave just like the
    # original one.
    for regex_string in ['^(?!.*/RCS/|.*/CVS/|\\.{1,2}/|.*/\\.svn/)',
                         '^(?!.*/RCS/|.*/CVS/|\\.{1,2}/|.*/\\.svn/).*$']:
        r = re.compile(regex_string)
        p = pickle.dumps(r)
        pp = pickle.loads(p)

# Generated at 2022-06-24 02:45:23.545338
# Unit test for function reset_compile
def test_reset_compile():
    import sys
    old = re.compile
    try:
        install_lazy_compile()
        if re.compile is not lazy_compile:
            raise AssertionError("re.compile has not been overridden")
        if old is not lazy_compile:
            raise AssertionError("re.compile has been overwritten")
        re.compile = lambda x: 42
        if re.compile is not lazy_compile:
            raise AssertionError("re.compile has not been overridden")
        if old is not lazy_compile:
            raise AssertionError("re.compile has been overwritten")
    finally:
        reset_compile()
    if re.compile is not old:
        raise AssertionError("re.compile has not been restored")



# Generated at 2022-06-24 02:45:31.719295
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """This test is meant to check if the addition of the method __unicode__
    for class InvalidPattern doesn't break existing code.

    It does not test anything about the method itself.
    """
    from bzrlib.ui import ui_factory

    e = it = None

# Generated at 2022-06-24 02:45:40.679445
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Tests method __eq__ of class InvalidPattern"""
    msg = 'Error message text'
    a = InvalidPattern(msg)
    b = InvalidPattern(msg)
    # Check two instances of InvalidPattern with equal attributes
    assert a == b
    # Check two instances of InvalidPattern with different attributes,
    # but same class
    msg = 'Other error message text'
    c = InvalidPattern(msg)
    assert a != c
    # Check two instances with different classes
    msg = 'Error message text'
    class OtherError(Exception):
        def __init__(self, msg): self.msg = msg
    d = OtherError(msg)
    assert a != d
    #Check two instances with different attributes, and different classes
    msg = 'Other error message text'
    e = OtherError(msg)
    assert a != e




# Generated at 2022-06-24 02:45:45.560832
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """tests for method __str__ of class InvalidPattern.

    This test is automatically generated by bzrlib.tests.TestUtil.mktemp.
    To regenerate this test, run 'bzrlib.tests.TestUtil.mktemp <received_filename>'
    """
    # insert the test here.
    raised = False
    try:
        err = InvalidPattern('msg')
        err.msg = None
        u = unicode(err)
    except:
        raised = True
    assert not raised



# Generated at 2022-06-24 02:45:47.112963
# Unit test for function finditer_public
def test_finditer_public():
    """Test functions re.finditer_public"""
    import doctest
    doctest.testmod(re)

# Generated at 2022-06-24 02:45:55.058493
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import sys
    testcases = [
                 (InvalidPattern(u'Error %(msg)s'), u'Error more message'),
                 ]
    if sys.version_info[0] == 2:
        # The next two tests expect UnicodeDecodeErrors
        testcases.extend([
            (InvalidPattern(u'%(msg)s'), None),
            (InvalidPattern('%(msg)s'), None),
            ])

# Generated at 2022-06-24 02:46:01.637552
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # We can't just run this in unit tests as it will also be run by launchpad
    # when importing this module, as that is where the class is defined. And
    # launchpad does not have all the localizations installed
    try:
        raise InvalidPattern('msg')
    except InvalidPattern as e:
        assert 'Invalid pattern(s) found. msg' == str(e)
        assert 'msg' == e.msg

# Generated at 2022-06-24 02:46:08.275218
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile function."""
    # This one should not call real re.compile
    pattern = lazy_compile("foo(.*)")
    # But pattern matching should work
    match = pattern.match("foobar")
    # Now we should have a real regex object
    assert not isinstance(pattern, LazyRegex)
    assert isinstance(pattern, re._pattern_type)
    # Check the match again
    assert match.groups(1) == "bar"


# Generated at 2022-06-24 02:46:18.098708
# Unit test for function finditer_public
def test_finditer_public():
    """Tests the finditer_public() function.

    All calls to re.finditer() in the wild are using either:
      * a string literal
      * a string literal with flags
      * a pattern that was just compiled
      * a pattern that was just compiled with flags
    """
    # Test a string literal
    myregex = re.compile('a*')
    match = re.finditer_public('a*', 'aaaa')
    try:
        match.next()
    except StopIteration:
        raise AssertionError('The iterator is empty')
    # Test a string literal with flags
    match = re.finditer_public('a*', 'aaaa', re.IGNORECASE)
    try:
        match.next()
    except StopIteration:
        raise AssertionError('The iterator is empty')
   

# Generated at 2022-06-24 02:46:29.951365
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the method LazyRegex.__getstate__."""
    r = LazyRegex()
    state = r.__getstate__()
    assert state == {
            "args": (),
            "kwargs": {},
            }

    r = LazyRegex((), {'l': '2'})
    state = r.__getstate__()
    assert state == {
            "args": (),
            "kwargs": {'l': '2'},
            }
    r = LazyRegex(('abc', ), {'l': '2'})
    state = r.__getstate__()
    assert state == {
            "args": ('abc', ),
            "kwargs": {'l': '2'},
            }



# Generated at 2022-06-24 02:46:35.329968
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Testing method __str__ of class InvalidPattern"""

    class TestInvalidPattern(InvalidPattern):
        _fmt = 'Message %(msg)s'

    e = TestInvalidPattern('message')
    assert str(e) == 'Message message', str(e)

    # is the same object idempotent?
    assert str(e) == str(e)

    # is repr(e) == str(e)?
    assert repr(e) == str(e)

# Generated at 2022-06-24 02:46:43.311617
# Unit test for function reset_compile
def test_reset_compile():
    """Check the re.compile() can be reset back to original state.

    This test installs lazy_compile as the default compiler, and tests
    that we can reset back to the original state.
    """
    orig_compile = re.compile
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
        reset_compile()
        assert re.compile is _real_re_compile
    finally:
        re.compile = orig_compile

# Generated at 2022-06-24 02:46:47.517417
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # it is hard to find a good real example in bzr, but at least we can ensure
    # that we are not doing any infinite loop.
    lr = LazyRegex(("[a-z]+",))
    lr.__getattr__("groups")


# Generated at 2022-06-24 02:47:00.159494
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    class TestInvalidPattern__str__(TestCase):

        # types of object 'e' in self._format
        TYPE_EXCEPTION = 'Exception'
        TYPE_NONE = 'None'
        TYPE_UNICODE = 'unicode'
        TYPE_STR = 'str'

        # locales to test
        LOCALE_C = 'C' # default
        LOCALE_RU = 'ru_RU.UTF-8'

        def test_InvalidPattern_default(self):
            msg = 'Invalid pattern'
            e = InvalidPattern(msg)
            self.assertEqual(e.msg, msg)
            self.assertEqual(e._fmt, InvalidPattern._fmt)
            self.assertEqual(e._preformatted_string, None)
            self

# Generated at 2022-06-24 02:47:04.100548
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    class TestException(InvalidPattern):
        _fmt = "TestException %(v1)s %(v2)s %(v3)s"
    e = TestException("test")
    e.v1 = "foo"
    e.v2 = "bar"
    assert unicode(e) == "TestException foo bar test"



# Generated at 2022-06-24 02:47:12.394335
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile overrides re.compile() with lazy_compile"""
    # Make sure we don't pollute any other unit tests
    from re import _compile
    reset_compile()
    install_lazy_compile()
    assert re.compile is not _compile and re.compile is not _real_re_compile
    reset_compile()
    assert re.compile is _compile
    reset_compile()
    assert re.compile is _compile



# Generated at 2022-06-24 02:47:17.127617
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        s = str(e)
        u = unicode(e)
        r = repr(e)
    expected_s = 'Invalid pattern(s) found. foo'
    expected_u = 'Invalid pattern(s) found. foo'
    expected_r = 'InvalidPattern(Invalid pattern(s) found. foo)'
    if (s != expected_s) or (u != expected_u) or (r != expected_r):
        print(">%s<" % s)
        print(">%s<" % u)
        print(">%s<" % r)
        raise AssertionError("InvalidPattern.__str__() failed")

# Generated at 2022-06-24 02:47:21.290022
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ returns the state to use when pickling."""
    lazy_regex = LazyRegex(args=['case', 'ignore'], kwargs={'S': '32'})
    state = lazy_regex.__getstate__()
    assert lazy_regex._regex_args == state['args']
    assert lazy_regex._regex_kwargs == state['kwargs']



# Generated at 2022-06-24 02:47:25.118574
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ of class InvalidPattern must return True if and only if the
    objects are equal."""
    invalid_pattern = InvalidPattern("")
    equal = InvalidPattern("")
    equal.ignore = False
    different1 = InvalidPattern("")
    different1.ignore = True
    different2 = InvalidPattern("")
    different2.msg = "New message."
    assert invalid_pattern == equal
    assert invalid_pattern != different1
    assert invalid_pattern != different2
    assert different1 != different2
    assert invalid_pattern != 1

# Generated at 2022-06-24 02:47:26.345234
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import regex
    doctest.testmod(regex, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 02:47:27.345266
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import sys
    raise InvalidPattern("This is a test")

# Generated at 2022-06-24 02:47:28.346497
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:47:31.592489
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    pattern = LazyRegex(args=('[bB]ranch',))
    pattern.__setstate__(dict(args=('[tT]ag',)))

    assert pattern.match('tag')
    assert not pattern.match('branch')

# Generated at 2022-06-24 02:47:40.523528
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib import tests
    t = tests.TestCase()

    i = InvalidPattern('a normal message')
    r = repr(i)
    t.assertEqual('InvalidPattern(a normal message)', r)

    i = InvalidPattern('a %(message)s with %(args)s and %(kwargs)s')
    i.message = 'message'
    i.args = 'args'
    i.kwargs = 'kwargs'
    r = repr(i)
    t.assertEqual('InvalidPattern(a %(message)s with %(args)s and %(kwargs)s)', r)

# Generated at 2022-06-24 02:47:49.328268
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # Check that it accepts a message and returns it unchanged
    msg = 'Invalid pattern!'
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        assert str(e) == msg

    # Check that it returns 'Unprintable exception InvalidPattern' if the
    # message is not defined
    try:
        raise InvalidPattern(None)
    except InvalidPattern as e:
        assert str(e) == 'Unprintable exception InvalidPattern'

    # Check that it returns 'Unprintable exception InvalidPattern' if
    # it receives a message with error
    try:
        raise InvalidPattern(None)
    except InvalidPattern as e:
        assert str(e) == 'Unprintable exception InvalidPattern'

# Install the lazy compile by default
install_lazy_compile()

# Generated at 2022-06-24 02:47:51.962961
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Make sure we can pickle a LazyRegex."""
    import pickle
    a = LazyRegex(["foo"])
    pickle.dumps(a)

# Generated at 2022-06-24 02:48:00.879448
# Unit test for function finditer_public
def test_finditer_public():
    """Test the function finditer_public"""

    # First try to find the texts "toto" and "titi" in the string
    a = re.finditer('to(ti)?', 'toto titi tutu')
    b = finditer_public('to(ti)?', 'toto titi tutu')
    assert a == b

    # Then test when trying to find the text "toto" in the string
    a = re.finditer('to', 'toto titi tutu')
    b = finditer_public('to', 'toto titi tutu')
    assert a == b

# Generated at 2022-06-24 02:48:12.488132
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    args = ("(abc)",)
    kwargs = {"flags": re.I}
    proxy = LazyRegex(args, kwargs)
    # Check the args and the kwargs
    state = proxy.__getstate__()
    if not isinstance(state, dict):
        raise AssertionError(
            "LazyRegex.__getstate__ returned %r instead of a dict"
            % (state, ))
    if not state.has_key('args'):
        raise AssertionError(
            "LazyRegex.__getstate__ returned a state without args : %r"
            % (state, ))
    if state['args'] != args:
        raise AssertionError(
            "args don't match, expected %r, got %r" % (args, state['args']))

# Generated at 2022-06-24 02:48:22.896345
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('frob')
    from bzrlib.i18n import gettext
    gettext('Invalid pattern(s) found. %(msg)s')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert str(e) == 'Invalid pattern(s) found. frob'
    assert unicode(e) == u'Invalid pattern(s) found. frob'
    # Make sure we don't raise an exception because we couldn't format it.
    e._fmt = '%i'
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    # make sure that the format error is visible
    assert str(e).startswith('Unprintable exception')
    assert unicode(e).startsw

# Generated at 2022-06-24 02:48:26.804368
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the LazyRegex constructor"""
    r = LazyRegex(['[a-z]*'], {'flags':re.UNICODE})
    assert isinstance(r, LazyRegex)



# Generated at 2022-06-24 02:48:33.998762
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that we get the behaviour we expect from lazy_compile"""
    lazy = lazy_compile('foo')
    assert lazy._real_regex is None
    real = lazy._real_re_compile('foo')
    assert lazy._real_regex is None
    assert lazy.findall('foo') == real.findall('foo')
    # Now check that the pattern got compiled
    assert lazy._real_regex is real
    assert lazy.findall('foo') == real.findall('foo')
    assert lazy.findall('bar') == real.findall('bar')
    # Check that pickling works too
    import pickle
    new_lazy = pickle.loads(pickle.dumps(lazy))
    assert new_lazy._real_regex is None

# Generated at 2022-06-24 02:48:40.843633
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    if _real_re_compile is lazy_compile:
        raise AssertionError("re.compile has already been overridden as " \
            "lazy_compile, but this would cause infinite recursion")

    # install temporarily
    install_lazy_compile()
    try:
        doctest.testmod(optionflags=doctest.ELLIPSIS)
    finally:
        reset_compile()

# Generated at 2022-06-24 02:48:44.331335
# Unit test for function finditer_public
def test_finditer_public():
    # If the pattern is a LazyRegex, re.finditer must be overridden to avoid
    # infinite recursion
    regex = re.compile('*')
    for res in regex.finditer('x'):
        pass


# Install lazy compilation support.
install_lazy_compile()

# Generated at 2022-06-24 02:48:51.230871
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile actually works."""
    original_compile = re.compile
    re.compile = None
    try:
        reset_compile()
        if re.compile is not original_compile:
            raise AssertionError("re.compile != original_compile")
        re.compile = None
        reset_compile()
        if re.compile is not original_compile:
            raise AssertionError("re.compile != original_compile")
    finally:
        re.compile = original_compile

# Generated at 2022-06-24 02:48:53.000849
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex = LazyRegex(('^foo',), {})
    regex._compile_and_collapse()
    assert isinstance(regex, re._pattern_type)



# Generated at 2022-06-24 02:49:00.073860
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    _real_re_compile = re.compile
    re.compile = lambda pattern, flags=0: pattern + ' (compiled)'
    try:
        lazy = LazyRegex(('a.*c',))
        assert lazy._regex_args == ('a.*c',) and lazy._regex_kwargs == {}
        assert not hasattr(lazy, 'pattern')
        assert lazy.pattern == 'a.*c (compiled)'
        assert lazy.match('b').re.pattern == 'a.*c (compiled)'
        assert 'a.*c (compiled)' in repr(lazy)
    finally:
        re.compile = _real_re_compile

# Generated at 2022-06-24 02:49:07.897769
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ must return correct dictionary"""
    regex = LazyRegex(r"\d+", re.I)
    dict = regex.__getstate__()
    expected = {
        "args": (r"\d+",),
        "kwargs": {"flags": re.I},
    }
    assert dict == expected, \
        '__getstate__ must return dict: got %s, expected %s' % (dict, expected)



# Generated at 2022-06-24 02:49:15.003351
# Unit test for function finditer_public
def test_finditer_public():
    re.compile = _real_re_compile
    text = "abcabcabcabcabcabcabcabcabc"
    compiled = LazyRegex(("a.c",), {})
    matchingIterator = re.finditer("a.c", text)
    matchingIterator2 = finditer_public("a.c", text)
    assert matchingIterator.next().group(0) == matchingIterator2.next().group(0)
    try:
        matchingIterator = re.finditer(compiled, text)
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError expected")
    matchingIterator2 = finditer_public(compiled, text)
    assert matchingIterator2.next().group(0) == matchingIterator.next().group(0)
    assert matchingIterator2.next().group(0) == matching

# Generated at 2022-06-24 02:49:26.472812
# Unit test for function finditer_public
def test_finditer_public():
    """Test for function finditer_public()."""
    # Make sure that when finditer_public receives a LazyRegex class it
    # correctly accesses its finditer function. And this function, returns
    # all values that match the pattern in a given string
    if getattr(re, 'finditer', False):
        import re
        pattern = LazyRegex((r'([a-zA-Z]+)(\d+)', re.I))
        iterator = finditer_public(pattern, "LazyRegex1 and LazyRegex2")
        match1 = iterator.next()
        match2 = iterator.next()
        assert(match1.group() == "LazyRegex1")
        assert(match2.group() == "LazyRegex2")

# Generated at 2022-06-24 02:49:28.586629
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from doctest import DocTestSuite
    import bzrlib.tests
    return DocTestSuite(bzrlib.tests)

# Generated at 2022-06-24 02:49:33.444369
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the __getstate__ method of LazyRegex."""
    regex = LazyRegex(args=('a',), kwargs={'flags': 1})
    expected = {'args': ('a',), 'kwargs': {'flags': 1}}
    assert regex.__getstate__() == expected



# Generated at 2022-06-24 02:49:45.349817
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ restores a LazyRegex object correctly.

    Note that the LazyRegex object is not actually compiled, so we can't test
    the actual compiled regex.
    """
    test_pattern = r'(.*)'
    lazy_regex = LazyRegex((test_pattern,))
    state = {
        "args": (test_pattern,),
        "kwargs": {},
        }
    lazy_regex.__setstate__(state)
    # check that _regex_args has been set correctly
    assert lazy_regex._regex_args == (test_pattern,)
    # check that _regex_kwargs has been set correctly
    assert lazy_regex._regex_kwargs == {}

# Generated at 2022-06-24 02:49:55.502023
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test that str() on InvalidPattern return a str object"""
    def f(data, msg):
        thing = InvalidPattern(msg)
        thing.__dict__.update(data)
        return (str(thing), thing._format())
    yield f, {}, ''
    yield f, {'a': 'b'}, 'b'
    yield f, {'a': u'b'}, 'b'
    yield f, {'a': 'b', 'msg': 'c'}, 'c'
    yield f, {'a': u'b', 'msg': 'c'}, 'c'
    yield f, {'a': 'b', 'msg': u'c'}, 'c'
    yield f, {'a': u'b', 'msg': u'c'}, u'c'
    # Make sure that __str__

# Generated at 2022-06-24 02:49:58.663126
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that we can override re.compile with lazy_compile."""
    reset_compile()
    install_lazy_compile()
    lr = re.compile("ab*")
    assert isinstance(lr, LazyRegex)
    assert isinstance(lr._real_regex, re._pattern_type)



# Generated at 2022-06-24 02:50:08.637233
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ return a dict with the regex object state.

    getstate is used by the pickle module when serializing the object.
    """
    lr1 = LazyRegex(("foo",))
    state = lr1.__getstate__()
    assert state["args"][0] == "foo"
    assert not state["kwargs"]
    lr2 = LazyRegex(("bar",), {"flags": 2})
    state = lr2.__getstate__()
    assert state["args"][0] == "bar"
    assert state["kwargs"]["flags"] == 2


# Generated at 2022-06-24 02:50:13.666621
# Unit test for function reset_compile
def test_reset_compile():
    # Simple test to make sure reset_compile restores the original function
    install_lazy_compile()
    reset_compile()
    assert re.compile is _real_re_compile

    # There is no need to reset more than once, as the first call sets it to
    # the original
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:50:21.294417
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Ensure that the state that is returned for pickling can be written

    When writing the state, it is expected to be a dictionary and this
    is verified by pickle.dump.
    """
    py_re = re.compile('[A-Z]')

    import cPickle as pickle
    state = pickle.dumps(py_re)

    # We need to check that this is a dictionary as the class is pickled
    # and the __getstate__ must return a dictionary of persistent
    # state.
    assert state.startswith('(c')

# Generated at 2022-06-24 02:50:33.420905
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern."""
    class Tester(object):
        def __init__(self, msg):
            self.msg = msg

    # test when _fmt = None
    e = InvalidPattern(Tester('test'))
    expected = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    # call __str__() method
    observed = str(e)
    assert observed == expected

    # test when _fmt is not None
    e._preformatted_string = 'test message'
    expected = 'test message'
    # call __str__() method
    observed = str(e)
    assert observed == expected

    # test when attribute _fmt is not None
    e._fmt = '%(msg)s'
    expected = 'test'

# Generated at 2022-06-24 02:50:42.715627
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__() returns a string like 
    "InvalidPattern(<message>)"."""
    # FIXME: This test will fail if the method is implemented in this module,
    # but the exception is implemented in another module.
    # It would be better to check that string is like "InvalidPattern(<message>)"
    # instead of checking the specific string.
    from bzrlib.config import errors
    error = errors.InvalidPattern('message')
    assert repr(error) == 'InvalidPattern(message)'

# Generated at 2022-06-24 02:50:55.038145
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test the equality of InvalidPattern

    __eq__ must be defined in terms of __dict__.
    """
    import types
    import new
    msg = 'test'
    instance1 = InvalidPattern(msg)
    instance2 = InvalidPattern(msg)
    assert instance1 == instance2
    instance3 = InvalidPattern(msg)
    # we change the class of instance3. It must still be equal to instance1.
    # copy.deepcopy is known to use __eq__, when deepcopy.
    instance3.__class__ = new.classobj('TestClass', (object,), {})
    instance3.__dict__ = types.DictProxyType(dict())
    assert instance1 == instance3
    # we change the dict of instance3.
    instance3.__dict__ = dict({'msg': 'epyt'})
   

# Generated at 2022-06-24 02:51:04.720809
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Unit test for constructor of class LazyRegex

    """
    cases = ['',
        'a',
        '123',
        'a' * 5000,
        ]
    for case in cases:
        # Test it with default args
        regex = LazyRegex()
        regex._regex_args = (case,)
        regex._regex_kwargs = {}
        regex._compile_and_collapse()
        assert(regex._real_regex.pattern == case)

        # Test it with non-default args
        regex = LazyRegex()
        regex._regex_args = (case,)
        regex._regex_kwargs = {'flags':re.IGNORECASE}
        regex._compile_and_collapse()
        assert(regex._real_regex.pattern == case)
       

# Generated at 2022-06-24 02:51:16.184100
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should set the attribute of LazyRegex on the fly
    so that the next time it is called, the attribute is retrieved from the
    instance of LazyRegex instead of the _real_regex.
    """
    regex_pattern = 'foo'
    # A real regex will be compiled
    regex = LazyRegex((regex_pattern,))
    # The following line will cause the regex to be compiled.
    matcher = regex.match('foo')
    assert isinstance(matcher, re._pattern_type)
    # A second lookup should not compile it again, it should be retrieved
    # from the instance and not the _real_regex.
    matcher1 = regex.match('foo')
    assert isinstance(matcher1, re._pattern_type)

# Generated at 2022-06-24 02:51:25.590955
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ of LazyRegex must set flags and pattern to the proxy."""
    import pickle
    value = pickle.dumps(LazyRegex(args=('\w',), kwargs={'flags': re.IGNORECASE}))
    proxy = pickle.loads(value)
    proxy._compile_and_collapse()
    if re.match(r'A', 'a', flags=re.IGNORECASE) is None:
        raise AssertionError('re.match failed. Flags are not passed to the original re.compile.')

# Generated at 2022-06-24 02:51:31.639875
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert re.compile is lazy_compile
    assert re.compile('foo') is not None
    reset_compile()
    assert re.compile is _real_re_compile
    assert re.compile('foo') is not None

# Generated at 2022-06-24 02:51:36.220778
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    pattern = re.compile(r'\d')
    m = pattern.match('0')
    assert m is not None



# Generated at 2022-06-24 02:51:46.815375
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import bzrlib.locale
    from bzrlib.i18n import gettext

    # When _fmt is not set, str(exception) returns a string with the
    # exception class name and msg.
    exc = InvalidPattern('my msg')
    expected_str = 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    assert str(exc) == expected_str

    # When _fmt is set, str(exception) returns a string with the exception
    # class name and a translated msg.
    exc = InvalidPattern('my msg')
    exc._fmt = "the msg"
    bzrlib.locale.set_default_language('fr_FR.UTF-8')
    exc._preformatted_string = get

# Generated at 2022-06-24 02:51:51.016692
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Create a new proxy object"""
    lr = LazyRegex("test")
    assert lr._real_regex is None
    assert lr._regex_args == ("test",)
    assert lr._regex_kwargs == {}

# Generated at 2022-06-24 02:51:57.598621
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern

    Because this method is overridden for internationalization,
    we want to ensure that all parameters are properly propagated.
    """
    # The default case.
    exception = InvalidPattern(msg="empty")
    expected_result = "InvalidPattern(Invalid pattern(s) found. empty)"
    actual_result = exception.__repr__()
    assert actual_result == expected_result, \
        "Actual result: {0}, Expected result: {1}".format(actual_result, expected_result)

# Generated at 2022-06-24 02:52:06.767688
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib import trace

    # config is created during a test run but not during normal use
    if getattr(trace, "_config", False):
        # turn off traceback as otherwise we produce a lot of backtraces
        # when compiling these regexs.
        # this is a bit hot monkey patching, but should be safe enough.
        trace._config.verbose = False

    invalid_re_string = '*'
    try:
        # if we get an exception here we're doing well.
        _real_re_compile(invalid_re_string)
    except re.error:
        pass
    else:
        raise AssertionError("%r should not be a valid regex" % invalid_re_string)

# Generated at 2022-06-24 02:52:13.764296
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Make sure __setstate__ work properly"""
    import copy
    import pickle

    lr = LazyRegex(('foo',), {})
    lr_c = copy.copy(lr)
    lr_d = copy.deepcopy(lr)
    lr_p = pickle.loads(pickle.dumps(lr))

    lr.match('foobar')
    assert lr_c.match('foobar') is not None
    assert lr_d.match('foobar') is not None
    assert lr_p.match('foobar') is not None


# Generated at 2022-06-24 02:52:22.178774
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern().__unicode__() should return unicode object"""
    from bzrlib.tests import TestCase
    from bzrlib.regex import InvalidPattern

    class TestInvalidPattern(TestCase):

        def test_simple_unicode(self):
            """InvalidPattern().__unicode__() should return unicode object"""
            ip = InvalidPattern('a')
            self.assertIsInstance(unicode(ip), unicode)

        def test_complex_unicode(self):
            """InvalidPattern().__unicode__() should return unicode object"""
            ip = InvalidPattern('a')
            ip._preformatted_string = 'b'
            self.assertIsInstance(unicode(ip), unicode)

    TestInvalidPattern().run_tests()

# Generated at 2022-06-24 02:52:25.586045
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """This test checks that InvalidPattern.__repr__() returns a str"""
    msg = "Invalid pattern(s) found. foo"
    ip = InvalidPattern(msg)
    repr_ip = repr(ip)
    if getattr(repr_ip, 'decode', False):
        # This is probably a Python 2.4 feature
        repr_ip.decode(u'UTF-8') == unicode(repr_ip)
    else:
        # Python 2.5 and above
        str(repr_ip) == repr_ip

# Generated at 2022-06-24 02:52:36.546875
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test install_lazy_compile."""
    import re
    from bzrlib.tests import TestCase

    class TestInstallLazyCompile(TestCase):

        def setUp(self):
            super(TestInstallLazyCompile, self).setUp()
            install_lazy_compile()
            self.compile_func = re.compile

        def test_lazy(self):
            """Test that re.compile returns LazyRegex"""
            self.assertIsInstance(self.compile_func('.'), LazyRegex)

        def tearDown(self):
            reset_compile()
            super(TestInstallLazyCompile, self).tearDown()

# Generated at 2022-06-24 02:52:43.218163
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lazy_regex = LazyRegex((), {})
    state = lazy_regex.__getstate__()
    expected_state = {
        "args": (),
        "kwargs": {},
        }
    assert state == expected_state

if __name__ == '__main__':
    test_LazyRegex___getstate__()

# Generated at 2022-06-24 02:52:55.374031
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError(
            "re.compile should be restored to the original function")
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError(
            "re.compile should be set to lazy_compile")
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError(
            "re.compile should be restored to the original function")

# Test the LazyRegex object itself

# Generated at 2022-06-24 02:53:00.018085
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.lazy_regex import InvalidPattern
    exc_one = InvalidPattern('msg one')
    exc_two = InvalidPattern('msg two')
    exc_one_copy = InvalidPattern('msg one')
    assert exc_one == exc_one
    assert not (exc_one == exc_two)
    assert exc_one == exc_one_copy

# Generated at 2022-06-24 02:53:10.213595
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should always return attribute of LazyRegex.

    This test is needed because coverage 3.6rc1 will not cover __getattr__.
    """
    rgx = LazyRegex()
    for attr in LazyRegex._regex_attributes_to_copy:
        getattr(rgx, attr)
    for attr in LazyRegex.__slots__:
        # Exceptions for attrs starting with '_'
        if attr.startswith('_'):
            continue
        try:
            getattr(rgx, attr)
        except AttributeError:
            pass