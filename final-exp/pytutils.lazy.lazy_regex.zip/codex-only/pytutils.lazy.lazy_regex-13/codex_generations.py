

# Generated at 2022-06-24 02:43:18.281332
# Unit test for function lazy_compile
def test_lazy_compile():
    import os, tempfile

    class FakeFS(object):
        """Fake object representing the filesystem.

        This object records which files are opened, and returns fake
        file objects.
        """

        def __init__(self, tmpdir):
            """Constructor.

            :param tmpdir: Temporary directory name.
            """
            self.calls = []
            self.tmpdir = tmpdir
            self.files = {}

        def __getattr__(self, name):
            """Return a function recording the call and returning a fake file
            object.

            :param name: Name of the function to call.
            """
            assert not name.startswith("__")

# Generated at 2022-06-24 02:43:27.522180
# Unit test for function reset_compile
def test_reset_compile():
    import re
    import bzrlib.lazy_regex as lazy_regex
    def test_re_compile():
        return re.compile

    orig_compile = test_re_compile()
    assert(orig_compile is lazy_regex.lazy_compile)
    lazy_regex.reset_compile()
    assert(test_re_compile() is orig_compile)
    lazy_regex.install_lazy_compile()
    assert(test_re_compile() is lazy_regex.lazy_compile)

# Generated at 2022-06-24 02:43:32.452162
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Check that __repr__ does not raise an exception for all Error
    classes.
    """
    def do(e):
        repr(e)

    do(InvalidPattern('blah'))
    # We should always be able to do:
    do(InvalidPattern(u'blah'))
    # or
    do(InvalidPattern(u'bl\xe0h'))
    # or
    do(InvalidPattern(u'blah'))

# Generated at 2022-06-24 02:43:38.947715
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex

    This test creates a proxy object to a regex and calls some methods of
    _sre.SRE_Pattern class on it.
    """
    regex = LazyRegex(('a',))
    match_obj = regex.match('a')
    if match_obj is None:
        raise AssertionError("Failed to create a match object")
    if match_obj.group() != 'a':
        raise AssertionError("Wrong group")

test_install_lazy_compile = """Test for installing lazy-compile

    We just test here that it is possible to install and uninstall
    the lazy-compile functions.
"""


# Generated at 2022-06-24 02:43:45.833735
# Unit test for function lazy_compile
def test_lazy_compile():
    re.compile = _real_re_compile
    try:
        re.compile('[')
    except re.error as e:
        expected_error = e
    else:
        raise AssertionError('Bad regex did not raise error')
    try:
        re.compile('[', re.VERBOSE)
    except re.error as e:
        expected_verbose_error = e
    else:
        raise AssertionError('Bad verbose regex did not raise error')

    re.compile = lazy_compile
    try:
        re.compile('[')
    except re.error as e:
        raise AssertionError('Lazy compile did raise error explicit re.error which it should not')

# Generated at 2022-06-24 02:43:48.531130
# Unit test for function finditer_public
def test_finditer_public():
    match = re.finditer_public(r'\d', '2')
    assert str(match.next()) == "<_sre.SRE_Match object at 0x7ffb6fdf4e70>"

# Generated at 2022-06-24 02:43:55.612076
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests import TestCase
    import re

    class TestLazyCompile(TestCase):

        def test_lazy_compile(self):
            self.assertEqual(re.compile, _real_re_compile)
            install_lazy_compile()
            self.assertEqual(re.compile, lazy_compile)
            reset_compile()
            self.assertEqual(re.compile, _real_re_compile)

# Generated at 2022-06-24 02:44:01.124365
# Unit test for function reset_compile
def test_reset_compile():
    import re
    from bzrlib.lazy_regex import install_lazy_compile, reset_compile
    install_lazy_compile()
    reset_compile()
    assert re.compile is not test_reset_compile.__globals__['lazy_compile']
    reset_compile()
    assert re.compile is not test_reset_compile.__globals__['lazy_compile']

# Generated at 2022-06-24 02:44:08.302184
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_output_encoding
    from bzrlib.i18n import ui
    from bzrlib.i18n import DefaultTranslations
    from bzrlib.i18n import get_translations
    from bzrlib.i18n import set_translations

    def setUp():
        # set up a dummy gettext object
        # Get available encoding
        encoding = get_translations().charset
        if encoding is None:
            _set_output_encoding(get_translations().charset)
        else:
            _set_output_encoding(encoding)

        # Create dummy translation object
        set_translations(DefaultTranslations())

        # Initialize dummy tranlation object for u

# Generated at 2022-06-24 02:44:13.353643
# Unit test for function finditer_public
def test_finditer_public():
    re.compile = lazy_compile
    assert re.finditer('c', 'abc') == [c for c in 'abc' if c == 'c']
    assert re.finditer(re.compile('c', 0), 'abc') == [c for c in 'abc' if c == 'c']

# Generated at 2022-06-24 02:44:17.124228
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ called when compiled"""
    l = lazy_compile("b")
    l.a = "foo"
    l._compile_and_collapse()
    l.b = "bar"
    assert l.a == "foo"
    assert l.b == "bar"

# Generated at 2022-06-24 02:44:20.841273
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = LazyRegex(('a',), {'b':1})
    assert r._regex_args == ('a',)
    assert r._regex_kwargs == {'b':1}
    assert r._real_regex is None

# Generated at 2022-06-24 02:44:25.083681
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile should restore the original function"""
    re.compile = lazy_compile
    assert re.compile is not _real_re_compile
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:44:33.912942
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import bzrlib.tests
    bzrlib.tests.TestCase.assertEqualDiff = lambda self, a, b: \
        bzrlib.tests.TestCase.assertEqual(self, a, b)


# Generated at 2022-06-24 02:44:43.537589
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern should be able to be converted to a unicode string"""
    from bzrlib.i18n import init_i18n
    init_i18n()
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib.errors import BzrError
    ''')

    class FakeBzrError(BzrError):
        _fmt = 'bzr-fake-error'
    try:
        raise FakeBzrError()
    except FakeBzrError as e:
        # invalid pattern will convert the exception to unicode
        invalid_pattern_e = InvalidPattern(str(e))
        str(invalid_pattern_e)
        unicode(invalid_pattern_e)

# Generated at 2022-06-24 02:44:49.922492
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = "Invalid Pattern"
    exc = InvalidPattern(msg)
    assert exc.msg == msg
    exc = InvalidPattern("Original exception")
    assert exc.msg == "Original exception"



# Generated at 2022-06-24 02:44:57.243230
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import bencode
    from bzrlib._validate_utf8 import InvalidUTF8
    from bzrlib import errors
    # verify that InvalidPattern is a subclass of Exception
    assert issubclass(InvalidPattern, Exception)
    from bzrlib.trace import mutter
    mutter("_fmt = %r, _format = %r" % (InvalidPattern._fmt, InvalidPattern._format))
    # construct an invalied pattern
    invalid_pattern = InvalidPattern('abc')
    mutter("_fmt = %r, _format = %r" % (invalid_pattern._fmt, invalid_pattern._format))
    # Call __str__, it should return the right content
    result = str(invalid_pattern)
    mutter('result = %r' % result)
    # Call __str

# Generated at 2022-06-24 02:45:02.785874
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Calling re.compile should return a LazyRegex object"""
    install_lazy_compile()
    try:
        regex = re.compile('foo')
        assert isinstance(regex, LazyRegex)

        import cPickle
        new_regex = cPickle.loads(cPickle.dumps(regex))
        assert isinstance(new_regex, LazyRegex)

        assert new_regex._regex_args == ('foo',)
        assert new_regex._regex_kwargs == {}
    finally:
        reset_compile()

# Generated at 2022-06-24 02:45:07.798046
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__()

    __setstate__ should not fail when passed a dict containing 'args' and
    'kwargs' entries.
    """
    lr = LazyRegex()
    orig_state = lr.__getstate__()
    lr.__setstate__(orig_state)

# Generated at 2022-06-24 02:45:09.488935
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-24 02:45:14.749157
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should return true for identical messages"""
    assert (InvalidPattern('foo') == InvalidPattern('foo'))
    assert not (InvalidPattern('foo') != InvalidPattern('foo'))
    assert (InvalidPattern('foo') == InvalidPattern('foo'))
    assert not (InvalidPattern('foo') != InvalidPattern('foo'))



# Generated at 2022-06-24 02:45:19.688131
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    r = re.compile(r'.*')
    assert r.match('a')
    assert type(r) is not LazyRegex

# Generated at 2022-06-24 02:45:30.608700
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test format of messages in InvalidPattern (__str__).

    In this test we create a new exception InvalidPatternTest
    by inheriting from InvalidPattern and setting the _fmt string.
    """
    from bzrlib.i18n import gettext
    import sys

    class InvalidPatternTest(InvalidPattern):
        _fmt = "Invalid pattern(s) used: %(error_msg)s"

        def __init__(self):
            self.error_msg = "This is an error message."

    e = InvalidPatternTest()

    # test messages with different encodings
    for encoding in ['utf8', 'latin1', 'cp1252', 'ascii']:
        reload(sys)
        sys.setdefaultencoding(encoding)

# Generated at 2022-06-24 02:45:39.967818
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Method __getstate__ of class LazyRegex should return an empty dict.

    Method __getstate__ of class LazyRegex should return an empty dict
    when the proxied regex has not been compiled yet.

    Method __getstate__ of class LazyRegex should return a dict containing
    the args used to instanciate the object.
    """
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib import tests
    import pickle
    def _test_LazyRegex___getstate__(self):
        obj = LazyRegex()
        self.assertEqual(obj.__getstate__(), {})
        obj = LazyRegex("^some regex", re.I)

# Generated at 2022-06-24 02:45:44.252157
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lazy_regex = LazyRegex(('abc', ), {'flags': re.IGNORECASE})
    state = lazy_regex.__getstate__()
    expected_state = {
        'args': ('abc', ),
        'kwargs': {'flags': 2},
        }
    assert state == expected_state



# Generated at 2022-06-24 02:45:56.155111
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__.

    This method is only called if the attribute is not found and if the regex
    is not yet compiled.
    """
    import doctest
    from bzrlib.tests import TestCase
    from bzrlib.tests.test__getattr__ import doctest_LazyRegex_getattr
    from bzrlib import lazy_regex
    # Make sure that if re.compile is overridden by install_lazy_compile(),
    # it is restored by reset_compile()
    lazy_regex.install_lazy_compile()
    doctest.testmod(lazy_regex)
    lazy_regex.reset_compile()
    doctest.testmod(lazy_regex)

    test = doctest_LazyRegex_getattr.__doc__


# Generated at 2022-06-24 02:46:02.482005
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method LazyRegex.__setstate__"""
    import pickle
    p = LazyRegex(("foo","bar"))
    p.__setstate__(pickle.loads(pickle.dumps(p.__getstate__())))
    # check if __setstate__ really set the object's _real_regex to None
    assert p._real_regex is None

# Generated at 2022-06-24 02:46:13.398333
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__ should behave as expected"""
    # Test for identity
    try:
        raise InvalidPattern("message")
    except InvalidPattern as e:
        assert e == e
        assert not e != e

    # Test for not identity
    try:
        raise InvalidPattern("message 1")
    except InvalidPattern as e1:
        try:
            raise InvalidPattern("message 2")
        except InvalidPattern as e2:
            assert not e1 == e2
            assert e1 != e2
            assert not e2 == e1
            assert e2 != e1

    # Test for equality
    try:
        raise InvalidPattern("message")
    except InvalidPattern as e:
        try:
            raise InvalidPattern("message")
        except InvalidPattern as f:
            assert e == f
            assert f == e

# Generated at 2022-06-24 02:46:16.025960
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    r = re.compile("foo")
    r.findall("bar")
    reset_compile()
    re.compile("foo")
    r.findall("bar")

# Generated at 2022-06-24 02:46:21.227082
# Unit test for function finditer_public
def test_finditer_public():
    """Test function finditer_public.
    """
    # Function finditer_public should return a LazyRegex object
    r1 = re.finditer('ab','ab ab ab')
    assert isinstance(r1, LazyRegex), 'Object is not a LazyRegex'
    # Function finditer_public should return a real _sre.SRE_Pattern object
    r2 = re.finditer('ab','ab ab ab')
    assert isinstance(r2._real_regex, type(re.compile('ab'))), 'Object is not a real _sre.SRE_Pattern'

# Generated at 2022-06-24 02:46:27.137604
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    r = re.compile("foo")
    r.pattern = "bar"
    lazy_regex = LazyRegex([r.pattern], {"flags":r.flags})
    state = lazy_regex.__getstate__()
    assert(state["args"][0] == "bar")
    assert(state["kwargs"]["flags"] == r.flags)


# Generated at 2022-06-24 02:46:38.401924
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # We can't use __init__ (first parameter named 'self') because it is an
    # instance method and not a class method.
    # Besides, we don't need to test __init__ as it is just a constructor.
    from bzrlib.tests import TestCase
    test_case = TestCase()
    lazy_regex = LazyRegex(('test',))
    test_case.assertEqual(None, lazy_regex._real_regex)
    test_case.assertEqual(('test',), lazy_regex._regex_args)
    test_case.assertEqual({}, lazy_regex._regex_kwargs)


# Generated at 2022-06-24 02:46:47.330020
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests for method __unicode__ of class InvalidPattern"""

    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_thread_message_context
    from bzrlib.i18n import CharsetTestMixin

    try:
        set_thread_message_context('InvalidPattern')
        test_unicode = CharsetTestMixin()
        test_unicode.test_unicode(InvalidPattern)
    finally:
        set_thread_message_context(None)

# Generated at 2022-06-24 02:46:52.637047
# Unit test for function finditer_public
def test_finditer_public():
    """Test for the function finditer_public function."""
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    # Unit test for function finditer_public
    test_finditer_public()

# Generated at 2022-06-24 02:46:59.317338
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should produce a 'str' object, never a 'unicode' one.

    >>> from bzrlib.lazy_import import lazy_import
    >>> lazy_import(globals(), """

# Generated at 2022-06-24 02:47:03.256585
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    class E(InvalidPattern):
        pass

    e1 = E('foo')
    e2 = E('foo')
    assert e1 == e2

    e3 = E('bar')
    assert e1 != e3

    # An object of another class is not equal to an InvalidPattern
    assert e1 != 'foo'

# Generated at 2022-06-24 02:47:09.599142
# Unit test for function lazy_compile
def test_lazy_compile():
    # tests for lazy_compile
    regex = lazy_compile('a(.*)b')
    assert regex.groups == 1
    assert regex.match('ab').groups() == ('',)
    assert regex.match('axb').groups() == ('x',)
    assert not regex.match('abx')
    assert regex.match('axbx')


# Generated at 2022-06-24 02:47:16.338273
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test that the method __getstate__ returns proper values"""
    args = 'args'
    kwargs = 'kwargs'

    lazy_regex = LazyRegex(args=args, kwargs=kwargs)
    # No state is being stored if the regex is not being compiled
    assert lazy_regex.__getstate__() == { 'args': args, 'kwargs': kwargs}

    # If the regex is compiled, the state is being changed
    lazy_regex._real_regex = 'real_regex'
    assert lazy_regex.__getstate__() == {'_real_regex': 'real_regex'}


# Generated at 2022-06-24 02:47:21.640350
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that we can override re.compile()"""
    reset_compile()
    install_lazy_compile()
    regex = re.compile("foo")
    assert isinstance(regex, LazyRegex), "re.compile returned %r" % (regex,)
    assert regex.search("foobar")
    reset_compile()
    regex = re.compile("foo")
    assert not isinstance(regex, LazyRegex), "re.compile returned %r" % (regex,)
    assert regex.search("foobar")


# Generated at 2022-06-24 02:47:26.081199
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lazy_reg = LazyRegex()
    lazy_reg.__setstate__({"args":('a',), "kwargs":{}})
    assert lazy_reg._regex_args, ('a',)
    assert lazy_reg._regex_kwargs, {}


# Generated at 2022-06-24 02:47:34.892243
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__()

    Method __getattr__ of class LazyRegex returns members from the proxied
    regex object.  If the regex hasn't been compiled yet, compile it.
    """
    import re
    import StringIO
    import unittest

    class TestCase(unittest.TestCase):
        """Test LazyRegex.__getattr__()."""

        def test_getattr_compile_and_collapse(self):
            """LazyRegex._compile_and_collapse()"""
            global _real_re_compile
            import re
            import StringIO
            import unittest

            class TestCase(unittest.TestCase):
                """Test LazyRegex.__getattr__()."""


# Generated at 2022-06-24 02:47:44.359067
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the install_lazy_compile function.

    The unit tests for re.compile cover the actual regex matching, so we just
    need to make sure that what we've overridden actually works.
    """
    # Make sure it can be called multiple times without error
    install_lazy_compile()
    install_lazy_compile()
    install_lazy_compile()
    install_lazy_compile()
    # See if it is finding the proxy object
    assert re.compile("test") is not None
    # See if it is actually returning the proxy object.
    assert isinstance(re.compile("test"), LazyRegex)



# Generated at 2022-06-24 02:47:48.521592
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should be able to return lazy attributes.

    It should also be able to use normal attributes.
    """
    regex = LazyRegex(args=('testing attributes of LazyRegex',),
                      kwargs=dict(flags=re.I))
    assert regex.search('just a test') is not None
    assert regex.flags == re.I

# Generated at 2022-06-24 02:48:00.046726
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should set _regex_args and _regex_kwargs"""
    lazy_regex = LazyRegex('pattern', flags=re.U)

    # make sure that _real_regex is None
    assert lazy_regex._real_regex is None, lazy_regex._real_regex

    # pickle and restore lazy_regex
    pickle_string = pickle.dumps(lazy_regex)
    restored_lazy_regex = pickle.loads(pickle_string)

    # make sure that _real_regex is None
    assert restored_lazy_regex._real_regex is None, restored_lazy_regex._real_regex

    # make sure that _regex_args and _regex_kwargs are set correctly
   

# Generated at 2022-06-24 02:48:05.658018
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile overrides the original re.compile"""
    re.compile = _real_re_compile
    assert re.compile is _real_re_compile
    install_lazy_compile()
    assert re.compile is not _real_re_compile
    assert re.compile is lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:48:14.781762
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Ensure InvalidPattern.__str__ always returns a 'str' object.
    """
    from bzrlib.i18n import gettext
    class MyInvalidPattern(InvalidPattern):
        _fmt = gettext('Invalid pattern: %(msg)s')
    import locale
    locale.setlocale(locale.LC_ALL, '')
    u = unicode(MyInvalidPattern('some text'))
    s = str(MyInvalidPattern('some text'))
    assert type(s) is str
    assert s.decode('utf8') == u

# Generated at 2022-06-24 02:48:16.921884
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile by calling it twice."""
    reset_compile()
    reset_compile()


# Generated at 2022-06-24 02:48:26.132114
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import bzrlib.tests.per_interversion

    # The pattern on which we perform tests
    pattern = r'\w+'

    # The string on which we perform the searches
    string = "foo and bar"

    # The tests here are very simple:
    # We just compile a regex and compare the result with the expected value
    # So if the result is the expected value, it means __getattr__ works fine

    # re.I
    lazy_regex = lazy_compile(pattern, re.I)
    assert lazy_regex.search(string).group() == "FOO"

    # re.M
    lazy_regex = lazy_compile(pattern, re.M)
    assert lazy_regex.search(string).group() == string

    # re.S
    lazy_regex = lazy_compile

# Generated at 2022-06-24 02:48:30.734575
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should remove the tag 'InvalidPattern'

    This is to ensure that we remove duplicated text.
    """
    msg = "error message"
    item = InvalidPattern(msg)
    result = repr(item)
    expected = "%s('%s')" % (InvalidPattern.__name__, msg)
    assert(result == expected)

# Generated at 2022-06-24 02:48:41.727831
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_translations

    error = InvalidPattern(msg='invalid line')
    assert error.__unicode__() == gettext('Invalid pattern(s) found. invalid line')

    # We wants to test what happens when error._get_format_string()
    # can't translate its message.
    #
    # We need to create a new translation context by replacing
    # _translations and adding a fake translation (for the same
    # language) that doesn't contain the same message.
    #
    # We also check that the exception can still be translated if
    # the variable _preformatted_string is set.
    from bzrlib.i18n import _translations

    real_translations = _translations

# Generated at 2022-06-24 02:48:46.220870
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__() returns the arguments used in re.compile()"""
    pattern = u"a.*b"
    flags = re.IGNORECASE
    lazy = LazyRegex((pattern, flags))
    assert isinstance(lazy, LazyRegex)
    assert lazy.__getstate__() == {"args": (pattern, flags),
                                  "kwargs": {}}



# Generated at 2022-06-24 02:48:53.228160
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test that InvalidPattern.__unicode__ returns an unicode object.

    It should return an unicode object for every kind of InvalidPattern
    objects. For example:

    - If InvalidPattern._fmt is an unicode string, that is the string that
      should be returned.
    - If InvalidPattern._fmt is an unicode string, that is the string that
      should be returned.
    - If InvalidPattern._fmt is a bytes string, that string should be
      decoded using the default encoding before being returned.
    - If InvalidPattern._fmt is not a str or unicode string, it should
      be converted to an unicode string using unicode() before being
      returned.
    - If InvalidPattern._fmt is None, a generic message should be returned.
    """
    from bzrlib.i18n import gettext

# Generated at 2022-06-24 02:49:03.051019
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():

    error = InvalidPattern('this is a test')
    assert isinstance(error, Exception)
    assert isinstance(str(error), str)
    assert str(error) == 'Invalid pattern(s) found. this is a test'
    assert repr(error) == 'InvalidPattern(Invalid pattern(s) found. this is a test)'
    assert str(type(error)) == "<class 'bzrlib.lazy_regex._LazyRegex.InvalidPattern'>"
    assert error.msg == 'this is a test'
    assert isinstance(unicode(error), unicode)
    assert unicode(error) == u'Invalid pattern(s) found. this is a test'

    # checks that a preformatted message is left untouched
    error = InvalidPattern('this is a test')

# Generated at 2022-06-24 02:49:07.612099
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """test InvalidPattern constructor"""
    import doctest
    try:
        doctest.testmod()
    except Exception:
        # This is the point.  We should get the constructor exception
        # not the doctest failure
        raise AssertionError()

# Generated at 2022-06-24 02:49:10.154030
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test InvalidPattern.__str__ method.
    """
    msg = 'test message'
    e = InvalidPattern(msg)
    assert msg == str(e)

# Generated at 2022-06-24 02:49:19.480265
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the _format() method of class InvalidPattern._

    This method is called by both __unicode__() and __str__()
    """
    class ExceptionWithUnicode(InvalidPattern):
        _fmt = u'Unicode string with \u1234'
    e = ExceptionWithUnicode('msg')
    assert u'Unicode string with \u1234' == unicode(e)
    assert str(u'Unicode string with \u1234') == str(e)

# Module initialization
# By default we override the re.compile method, to lazily compile.
install_lazy_compile()

# Tests


# Generated at 2022-06-24 02:49:28.527627
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()

# Generated at 2022-06-24 02:49:34.087626
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """getstate() should return a dict with the regex args used to construct
    the object.
    """
    proxy = LazyRegex(args=('a',), kwargs={'b':'c'})
    state = proxy.__getstate__()
    assert {'args':('a',), 'kwargs':{'b':'c'}} == state


# Generated at 2022-06-24 02:49:46.311305
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of class LazyRegex"""

    from bzrlib import symbol_versioning
    from bzrlib.symbol_versioning import (deprecated_method,
        deprecated_function,
        deprecated_in,
        deprecated_passed,
        )
    from bzrlib.tests import test_symbol_versioning

    class TestClass(symbol_versioning.one_four):
        """A test class to recreate the pattern use in the symbol_versioning
        module.
        """

        @deprecated_method(one_four)
        def deprecated_method(self):
            """A deprecated method"""

    # Ensure the constructor creates a new LazyRegex instance
    test_regex = LazyRegex((r'^(.*?)$', re.MULTILINE))
    # The _real_

# Generated at 2022-06-24 02:49:50.197590
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib.i18n import gettext
    import doctest
    doctest.testmod(gettext)
    msg = 'abc123'
    err = InvalidPattern(msg)
    err1 = InvalidPattern(msg)
    assert err == err1
    assert err != msg
    assert isinstance(unicode(err), unicode)
    assert isinstance(str(err), str)

# Generated at 2022-06-24 02:49:56.206557
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Ensure that re.compile is changed to be a LazyRegex."""
    install_lazy_compile()
    try:
        re.compile('foo')
        msg = "re.compile didn't return a LazyRegex, it returned" \
                " %r" % (re.compile('foo'),)
        raise AssertionError(msg)
    finally:
        reset_compile()


# Generated at 2022-06-24 02:50:08.765872
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Ensure that InvalidPattern.__repr__() functions correctly even if
       the exception contains unprintable characters.
   """
    unicode_str = unicode('\xd0\xbc\xd0\xb8\xd0\xbd\xd0\xb0 \xd0\xbc\xd0\xb8\xd1\x80\xd0\xb0 \xd0\xb3\xd0\xbe\xd0\xbf\xd1\x81\xd0\xb0',
                          'utf8')
    e = InvalidPattern(unicode_str)

# Generated at 2022-06-24 02:50:14.815440
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """
    Unit test for method __getattr__ of class LazyRegex
    """
    pattern = 'regex'
    lazy_regex = LazyRegex((pattern,))
    lazy_regex.__getattr__('regex')
    # Should not have any error.
    # When _real_regex is None, _compile_and_collapse() is called,
    # and _real_regex becomes a _sre.SRE_Pattern object.
    assert(lazy_regex._real_regex is not None)
    # At this point, we already have _real_regex, so
    # _compile_and_collapse() should not be called anymore.
    lazy_regex.__getattr__('regex')
    # Should not have any error.
    # No matter what we pass to

# Generated at 2022-06-24 02:50:23.347582
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__() should raise AttributeError if method does not exist."""
    # LazyRegex instantiated with no args
    r = LazyRegex()
    try:
        r.foobar
    except AttributeError:
        pass
    except:
        raise AssertionError("it should raise AttributeError")
    else:
        raise AssertionError("it should raise AttributeError")

    # LazyRegex instantiated with args
    r = LazyRegex(args=('.',))
    try:
        r.foobar
    except AttributeError:
        pass
    except:
        raise AssertionError("it should raise AttributeError")
    else:
        raise AssertionError("it should raise AttributeError")

# Generated at 2022-06-24 02:50:28.208900
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    state = {'args': ('a',), 'kwargs': {'flags': re.UNICODE}}
    regex = LazyRegex()
    regex.__setstate__(state)
    assert regex._regex_args == ('a', )
    assert regex._regex_kwargs == {'flags': re.UNICODE}


# Generated at 2022-06-24 02:50:37.642897
# Unit test for function finditer_public
def test_finditer_public():
    """Test for function finditer_public."""
    from bzrlib.tests.per_regex import TestCaseWithPatterns, TestCase

    # class named as RegexTestCustom is needed for function _override_re_compile
    class RegexTestCustom(TestCaseWithPatterns):
        _override_re_compile = lambda self: None

    class RegexTest(RegexTestCustom):
        def test_finditer_public(self):
            """Test for function finditer_public."""

            re_public = re.finditer
            # loop over all patterns

# Generated at 2022-06-24 02:50:46.737281
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """LazyRegex can be used as a proxy for re.compile()."""
    try:
        import re as _real_re
        _real_re_compile = _real_re.compile
        _real_re_match = _real_re.match
        _real_re_search = _real_re.search
    except ImportError:
        from sre import compile as _real_re_compile, match as _real_re_match, \
            search as _real_re_search
    original_re_compile = re.compile
    # Make sure that the test is not affected by any imported modules
    del re
    import re
    class DummyRe:
        pass
    re._re = DummyRe()
    re._re.match = _real_re_match
    re._re.search

# Generated at 2022-06-24 02:50:49.894443
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile with re.compile syntactic sugar"""
    pattern = lazy_compile("pattern")
    assert isinstance(pattern, LazyRegex)



# Generated at 2022-06-24 02:50:58.056107
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr_invalid = LazyRegex(('[foo',))
    try:
        lr_invalid.findall('foo')
    except InvalidPattern as e:
        # Check that we have the right msg
        assert e.msg == '"[foo" bad character range'
    else:
        assert False, "Did not get an InvalidPattern exception"
    lr_valid = LazyRegex(('[a-b]',), dict(flags=re.I))
    assert lr_valid.findall('aAbB') == ['a', 'b']



# Generated at 2022-06-24 02:51:04.389621
# Unit test for function reset_compile
def test_reset_compile():
    """We can reset re.compile to the original value"""
    # Call the test twice, once with the compiler already overridden,
    # once not.
    # Ensure we are starting from a known state.
    try:
        re.reset_compile()
    except (AttributeError, NameError):
        pass
    reset_compile()
    try:
        re.reset_compile()
    except (AttributeError, NameError):
        pass
    install_lazy_compile()
    re.reset_compile()



# Generated at 2022-06-24 02:51:15.740519
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of the class LazyRegex"""
    try:
        re.compile('foo(bar')
    except re.error as e:
        # the pattern should not be compiled, since it is invalid
        # and an exception should be raised
        expected_msg = 'unbalanced parenthesis at position 4'
        if e.message != expected_msg:
            raise AssertionError('re.error message "%s" should be "%s"'
                                 % (e.message, expected_msg))
    else:
        raise AssertionError('calling re.compile with an invalid pattern'
                             ' should raise an re.error exception')

    # the pattern should not be compiled, since it is invalid
    # and an exception should be raised
    pattern = re.compile('foo(bar')

# Generated at 2022-06-24 02:51:18.332998
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    def f():
        return LazyRegex(("a{0,1}",))
    f()

# Generated at 2022-06-24 02:51:24.675103
# Unit test for function lazy_compile
def test_lazy_compile():
    lc = lazy_compile('foo(.*)', re.DOTALL)
    assertNotHasAttr(lc, 'match')
    assertNotHasAttr(lc, 'findall')
    lc.match('foo\n')
    assertHasAttr(lc, 'match')
    assertHasAttr(lc, 'findall')


# Generated at 2022-06-24 02:51:31.993035
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Convert this to a list to prevent running the generator twice
    l = list(LazyRegex.__init__.__code__.co_varnames)
    # Should have 4 members: self, args, kwargs, and the dummy return
    # value
    assert len(l) == 4
    assert l == ['self', 'args', 'kwargs', 'return']
    assert isinstance(LazyRegex.__init__.__code__.co_argcount, int)
    # Check that the first argument is self
    assert LazyRegex.__init__.__code__.co_varnames[0] == 'self'
    # Check that the second is args
    assert LazyRegex.__init__.__code__.co_varnames[1] == 'args'
    # Check that the third is k

# Generated at 2022-06-24 02:51:40.103708
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lzr = LazyRegex(['(?m)^a$'])
    lzr_state = lzr.__getstate__()
    expected_state = {'args': ['(?m)^a$'], 'kwargs': {}}
    if lzr_state != expected_state:
        raise AssertionError("""Method __getstate__ of class LazyRegex
returned wrong value."""
                             """\nExpected:%s\nActual:%s"""
                             % (expected_state, lzr_state))


# Generated at 2022-06-24 02:51:44.967077
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    l = LazyRegex(['^[a-zA-Z0-9.!#$%&\'*+-/=?^_`{|}~]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$'])

# Generated at 2022-06-24 02:51:48.785795
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'test message'
    e = InvalidPattern(msg)
    result = True
    # test when the exception message is in unicode
    if str(e) != msg:
        result = False
    e = InvalidPattern(msg.decode('utf8'))
    # test when the exception message is in str
    if result and str(e) != msg:
        result = False
    return result


# Generated at 2022-06-24 02:51:58.765405
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test LazyRegex.__getattr__()"""
    for method in LazyRegex._regex_attributes_to_copy:
        lazy_regex = LazyRegex(('a',))
        # first make sure that the attribute is not already there (since
        # we copy it when we compile).
        try:
            getattr(lazy_regex, method)
        except AttributeError:
            pass
        else:
            raise AssertionError('Method %r is already present.' % method)
        # check that we compile when we need to
        real_regex = lazy_regex._real_re_compile('a')
        real_method = getattr(real_regex, method)
        assert getattr(lazy_regex, method) is real_method
        # check that we don't compile

# Generated at 2022-06-24 02:52:07.584194
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    import bzrlib
    bzrlib.i18n.install_gettext_translations()

    # Test message formatting using a ValueError instance.
    value_error = ValueError()
    invalid_pattern = InvalidPattern(value_error)
    expected = unicode(value_error)
    actual = unicode(invalid_pattern)
    assert_equal(actual, expected)

    # Test message formatting using a string.
    string = "test message"
    invalid_pattern = InvalidPattern(string)
    expected = unicode(string)
    actual = unicode(invalid_pattern)
    assert_equal(actual, expected)

    # Test an exception which does not contain __str__.

# Generated at 2022-06-24 02:52:16.681234
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    from bzrlib import trace
    # create an exception without a detailed message
    exc = InvalidPattern(None)
    # create an exception with a detailed message
    try:
        # create an InvalidPattern exception with a detailed message
        # in the attribute msg (simulate a situation where a method of
        # class InvalidPattern uses a raise statement with a tuple)
        InvalidPattern('abc').msg
    except InvalidPattern as exc:
        # exc is a newly raised InvalidPattern object
        pass
    # check the string representation of the exception object
    trace.note(str(exc))
    # check that the string representation is still valid
    # once the exception object is assigned to an other variable
    exc2 = exc
    trace.note(str(exc2))
    # check that the string representation is

# Generated at 2022-06-24 02:52:19.563913
# Unit test for function reset_compile
def test_reset_compile():
    """Make sure that reset_compile works"""
    try:
        install_lazy_compile()
        reset_compile()
        reset_compile()
        reset_compile()
    finally:
        reset_compile()

# Generated at 2022-06-24 02:52:27.852365
# Unit test for function finditer_public
def test_finditer_public():
    orig_finditer = re.finditer
    try:
        re.finditer = finditer_public

        # Simple case
        pat = lazy_compile('a*')
        res = re.finditer(pat, 'aab')
        res1 = [ ''.join(e.groups()) for e in res]
        assert res1 == [ 'aa', 'b' ]

        # Test that we can still use the original finditer
        res = re.finditer(re.compile('a*'), 'aab')
        res1 = [ ''.join(e.groups()) for e in res]
        assert res1 == [ 'aa', 'b' ]
    finally:
        re.finditer = orig_finditer

# Generated at 2022-06-24 02:52:37.405142
# Unit test for function finditer_public
def test_finditer_public():
    # The function finditer_public() calls 'finditer' on a LazyRegex object.
    # This function is tested.
    s = "ab"
    p = re.compile(s)
    i = re.finditer(s, s)
    i1 = p.finditer(s)
    i2 = finditer_public(p, s)
    assert i.next().group() == i1.next().group()
    assert i.next().group() == i2.next().group()
    raise AssertionError("finditer_public test failed")

# Generated at 2022-06-24 02:52:44.220731
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lr = LazyRegex(args=('foo', 0,), kwargs={'verbose':1,'flags':0})
    assert lr.__getstate__() == {
        "args": ('foo', 0,),
        "kwargs": {'verbose':1,'flags':0}
        }


# Generated at 2022-06-24 02:52:47.444782
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    from bzrlib.tests import test_re
    return doctest.DocTestSuite(test_re)

# Generated at 2022-06-24 02:52:54.976931
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ restores a LazyRegex"""
    import pickle
    composed = LazyRegex((r'\s*(?P<log>\[.+\])\s+'), {})
    restored = pickle.loads(pickle.dumps(composed))
    assert composed is not restored
    assert composed._regex_args == restored._regex_args
    assert composed._regex_kwargs == restored._regex_kwargs



# Generated at 2022-06-24 02:52:58.504043
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern

    This is a test for method __repr__ of class InvalidPattern.
    """
    e = InvalidPattern('pattern not found')
    assert str(e) == "Invalid pattern(s) found. \"pattern not found\""

# Generated at 2022-06-24 02:53:10.110109
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the proper installation of the lazy compiler

    It should be installed on both the original import
    as well as with multiple calls to install_lazy_compile.
    """
    from re import compile
    if compile is not lazy_compile:
        raise AssertionError(
            "re.compile was not overridden on import.")
    install_lazy_compile()
    from re import compile
    if compile is not lazy_compile:
        raise AssertionError(
            "re.compile was not overridden on install_lazy_compile")
    reset_compile()
    from re import compile
    if compile is not lazy_compile:
        raise AssertionError(
            "re.compile was not restored properly.")

