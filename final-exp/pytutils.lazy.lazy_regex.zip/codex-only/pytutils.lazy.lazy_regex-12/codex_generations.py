

# Generated at 2022-06-24 02:43:15.383340
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # If a LazyRegex is uncomplete and a member is accessed it is compiled
    # and returns the requested member.
    args = ('((([^:]+):((?P<ip>[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*)))|'
            '(([^@]+)@(?P<host>[^ ]+)))',
            2)
    kwargs = {}
    lazy_regex = LazyRegex(args, kwargs)
    assert not lazy_regex._real_regex
    names = lazy_regex.groupindex
    assert lazy_regex._real_regex
    assert "ip" in names
    assert "host" in names
    assert lazy_regex._regex_args == args
    assert lazy_regex._re

# Generated at 2022-06-24 02:43:20.510399
# Unit test for function reset_compile
def test_reset_compile():
    """Tests that reset_compile restores re.compile()."""
    original = re.compile
    try:
        re.compile = lazy_compile
        re.compile = _real_re_compile
        re.compile = lazy_compile
        reset_compile()
        re.compile = _real_re_compile
        re.compile = lazy_compile
        reset_compile()
    finally:
        re.compile = original


_real_re_compile = re.compile
re.compile = lazy_compile
__all__ = [
    'install_lazy_compile',
    'InvalidPattern',
    'LazyRegex',
    'lazy_compile',
    'reset_compile',
    ]

# Generated at 2022-06-24 02:43:30.472174
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    from pickle import PicklingError
    from bzrlib.tests import TestCase

    class TestLazyRegex(TestCase):

        def test_getstate(self):
            lazy_regex = LazyRegex(args=('foo',))
            state = lazy_regex.__getstate__()
            self.assertEqual({'args': ('foo',), 'kwargs': {}}, state)

        def test_setstate(self):
            lazy_regex = LazyRegex()
            lazy_regex.__setstate__({'args': ('foo',), 'kwargs': {}})
            state = lazy_regex.__getstate__()
            self.assertEqual({'args': ('foo',), 'kwargs': {}}, state)


# Generated at 2022-06-24 02:43:36.845961
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ of LazyRegex must return dict."""
    sre_pattern = LazyRegex(('ab',), {})
    state = sre_pattern.__getstate__()
    if not isinstance(state, dict):
        raise AssertionError('__getstate__ of LazyRegex must return dict')
test_LazyRegex___getstate__()


# Generated at 2022-06-24 02:43:42.450440
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # Check that __repr__ works as expected
    import bzrlib
    p = bzrlib.trace.InvalidPattern('1234')
    r = repr(p)
    assert r == "InvalidPattern('1234')"


# Generated at 2022-06-24 02:43:52.768781
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase

    class Test(TestCase):

        def test__get_format_string(self):
            err = InvalidPattern('test')
            self.assertIs(None, err._get_format_string())

        def test__get_format_string_with_format(self):
            from bzrlib.i18n import gettext
            err = InvalidPattern('test')
            err._fmt = 'test %(msg)s'
            self.assertEqual(gettext('test %(msg)s'), err._get_format_string())

        def test__format(self):
            err = InvalidPattern('test')
            self.assertEqual('Invalid pattern(s) found. test', err._format())


# Generated at 2022-06-24 02:44:00.937924
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile works"""
    install_lazy_compile()
    try:
        _real_compile = re.compile
        re.compile = _real_re_compile
        re_compile_proxy = lazy_compile(r'^ABC$', re.I)
        compile_result = re.compile(r'^ABC$', re.I)
        assert re_compile_proxy is not compile_result
        assert re_compile_proxy._real_regex is None
        assert compile_result.pattern == re_compile_proxy.pattern
    finally:
        re.compile = _real_compile



# Generated at 2022-06-24 02:44:02.346953
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern("foo")
    # InvalidPattern is a subclass of ValueError
    assert isinstance(e, ValueError)

# Generated at 2022-06-24 02:44:09.330112
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern's __eq__ method should test equivalence of the exception, not identity.
    We do this by creating a class whose __eq__ defers to InvalidPattern's __eq__.
    """
    class InvalidPatternSubclass(InvalidPattern):
        pass
    exc1 = InvalidPattern("message1")
    exc2 = InvalidPattern("message1")
    exc3 = InvalidPatternSubclass("message1")
    exc4 = InvalidPatternSubclass("message2")
    exc5 = InvalidPattern("message2")
    assert exc1 == exc2
    assert exc1 == exc3
    assert exc3 == exc1
    assert not exc1 == exc4
    assert not exc1 == exc5

# Generated at 2022-06-24 02:44:17.453188
# Unit test for function reset_compile
def test_reset_compile():
    """Test the correct functionality of reset_compile"""
    # It is safe to call reset_compile() multiple times, it will always
    # restore re.compile() to the value that existed at import time.
    reset_compile()
    reset_compile()



# Generated at 2022-06-24 02:44:27.626351
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    class TestLazyRegex(LazyRegex):
        _real_regex = None
        _real_re_compile = _real_re_compile
        def __init__(self, args=(), kwargs={}):
            self._real_regex = None
            self._regex_args = args
            self._regex_kwargs = kwargs
    for test_pattern in ('a', '\n'):
        for test_flags in (0, re.IGNORECASE):
            tlr = TestLazyRegex((test_pattern, test_flags))
            r = tlr._compile_and_collapse()
            for attr in r._regex_attributes_to_copy:
                if attr == 'match':
                    continue

# Generated at 2022-06-24 02:44:32.570419
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object"""
    try:
        raise InvalidPattern('plop')
    except InvalidPattern as e:
        u = e.__unicode__()
        assert isinstance(u, unicode), ("__unicode__ should return a unicode"
                                        " object, found %r" % type(u))



# Generated at 2022-06-24 02:44:39.442132
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib import errors
    error = errors.InvalidPattern('')
    other = errors.InvalidPattern('')
    assert error == other
    assert not error != other
    error_other = errors.InvalidPattern('')
    error_other._fmt = 'foo'
    assert error == error_other
    assert not error != error_other
    error_other = errors.InvalidPattern('')
    error_other.msg = 'foo'
    assert error != error_other
    assert not error == error_other
    error_other = errors.InvalidPattern('')
    error_other._preformatted_string = 'foo'
    assert error != error_other
    assert not error == error_other
    error_other = errors.InvalidPattern('')
    error_other._preformatted_string = 'foo'

# Generated at 2022-06-24 02:44:43.141881
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of class InvalidPattern.
    """
    msg = "abc"
    exc = InvalidPattern(msg)
    # check msg
    assert(exc.msg == msg)
    # check str()
    assert(str(exc) == msg)
    # check repr()
    assert(repr(exc) == "InvalidPattern(%s)" % msg)

# Generated at 2022-06-24 02:44:50.953181
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Any error message need to be interpreted as a string and printed.

    This is no longer a problem of StringIO, but a string which contains '%'
    could potentially raise an exception.
    """
    try:
        raise InvalidPattern('test_%s')
    except InvalidPattern as e:
        e.__repr__()

# Generated at 2022-06-24 02:45:01.162125
# Unit test for function finditer_public
def test_finditer_public():
    install_lazy_compile()
    regex = re.compile(r'(?P<test>test)')
    regex2 = re.compile(r'(?P<test>test2)')
    matches = re.finditer(regex, 'test')
    matches2 = re.finditer(regex, 'test2')
    matches3 = re.finditer(regex2, 'test2')
    list_matches = list(matches)
    list_matches2 = list(matches2)
    list_matches3 = list(matches3)
    assert(len(list_matches) == 1)
    assert(len(list_matches2) == 1)
    assert(len(list_matches3) == 1)
    reset_compile()

# Generated at 2022-06-24 02:45:10.295078
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile.

    We need to override the proxy object for the test since we
    can't use the real module level function.
    """
    old_re_compile = _real_re_compile
    try:
        # Set up the proxy
        re._real_re_compile = _real_re_compile
        re.LazyRegex = LazyRegex
        # Now perform the test case
        from bzrlib import lazy_re
        lazy_re.test_lazy_compile()
    finally:
        # Clean up
        del re._real_re_compile
        _real_re_compile = old_re_compile



# Generated at 2022-06-24 02:45:14.549407
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr__ of class InvalidPattern"""
    try:
        raise InvalidPattern('some message')
    except InvalidPattern as e:
        if e.__repr__() != 'InvalidPattern(\'some message\')':
            raise AssertionError(
                'InvalidPattern.__repr__ is not working')

# Generated at 2022-06-24 02:45:25.689651
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ return the error msg in unicode, the
    other methods __repr__ and __str__ are implicit tested.
    """
    msg = u"this is a unicode message"
    exc = InvalidPattern(msg)
    u = unicode(exc)
    if isinstance(u, str):
        raise AssertionError("%r.__unicode__() returns a str object: %r" %
                             (exc, u))
    if u != msg:
        raise AssertionError("%r.__unicode__() returns '%s' instead of '%s'" %
                             (exc, u, msg))
    s = str(exc)

# Generated at 2022-06-24 02:45:33.411710
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test that __getstate__ of LazyRegex returns the expected result."""

    lazy_regex = LazyRegex(('pattern',), {'flags':1})

    state = lazy_regex.__getstate__()

    # The state returned by __getstate__ should be a dict
    assert isinstance(state, dict)

    # Check if the state returns as expected
    assert state == {'args': ('pattern',), 'kwargs': {'flags': 1}}

# Generated at 2022-06-24 02:45:39.405127
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    from bzrlib import tests
    import pickle
    a = LazyRegex(('^\S+.*',), {'flags':re.M})
    s = pickle.dumps(a)
    a1 = pickle.loads(s)
    for attr in a._regex_attributes_to_copy:
        tests.TestCase.assertEqual(a1, a1)
        tests.TestCase.assertIs(getattr(a1, attr), getattr(a, attr))

# Generated at 2022-06-24 02:45:43.380245
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('neato')
    except InvalidPattern as e:
        pass
    assert e.msg == 'neato'
    assert str(e) == 'Invalid pattern(s) found. neato'
    assert repr(e) == 'InvalidPattern(Invalid pattern(s) found. neato)'

# Generated at 2022-06-24 02:45:51.349797
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    try:
        # The regex is not compiled yet
        obj = re.compile(".*")
        assert obj._real_regex is None

        # We have compiled it;
        obj.search("foo")
        assert obj._real_regex is not None

        # We can still call methods on the object
        obj.search("foo")

        # Pickling works too
        obj2 = pickle.loads(pickle.dumps(obj))
        assert obj2._real_regex is None
        obj2.search("foo")
        assert obj2._real_regex is not None

        # Now reset it
        reset_compile()
        assert re.compile is not lazy_compile

    finally:
        reset_compile()
    # It's also still working
    re

# Generated at 2022-06-24 02:45:58.329976
# Unit test for function finditer_public
def test_finditer_public():
    regex = lazy_compile('.')
    # Calling finditer_public with a LazyRegex should return a generator
    finditer_generator = re.finditer(regex, 'a')
    # Calling finditer_public with a string pattern should also return a
    # generator
    real_generator = re.finditer('.', 'a')
    assert finditer_generator.next() == real_generator.next()



# Generated at 2022-06-24 02:46:04.085514
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ method returns the state to use when pickling."""
    # Testing for LazyRegex class
    lazy = LazyRegex("args", {"kwargs": "kwargs"})
    state = lazy.__getstate__()
    assert(type(state) == dict)
    assert(state["args"] == "args")
    assert(state["kwargs"] == {"kwargs": "kwargs"})


# Generated at 2022-06-24 02:46:09.716268
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'Some Message'

    # This is needed to use the _fmt attribute
    class MyException(InvalidPattern):
        _fmt = 'Test: %(msg)s'
    invalid_pattern = MyException(msg)
    assert str(invalid_pattern) == 'Test: ' + msg
    assert unicode(invalid_pattern) == u'Test: ' + unicode(msg)

# Generated at 2022-06-24 02:46:13.709729
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    assert re.compile == lazy_compile
    reset_compile()
    assert re.compile == _real_re_compile

if __name__ == '__main__':
    test_install_lazy_compile()

# Generated at 2022-06-24 02:46:16.420695
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile works as expected"""
    install_lazy_compile()
    pattern = re.compile("^(.+?)(\\d+)$")
    assert isinstance(pattern, LazyRegex)
    assert not pattern._real_regex
    assert pattern.match("foo123")
    assert pattern._real_regex

# Generated at 2022-06-24 02:46:29.052673
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    log = []
    class _Regex(object):
        def __init__(self, log):
            self._log = log
        def __getattr__(self, attr):
            self._log.append(attr)
            return attr
    regex = _Regex(log)
    proxy = LazyRegex()
    proxy._real_re_compile = lambda: regex
    assert proxy._real_regex is None
    proxy.foo
    # _real_regex is compiled
    assert proxy._real_regex == regex
    proxy.bar()
    # _real_regex is compiled and collapsed
    assert 'foo' in log
    assert 'bar' in log
    assert proxy._real_regex == regex


# XXX: cmp, repr, str, getattr, getattribute
# can return arbitrary types. We

# Generated at 2022-06-24 02:46:37.317563
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import os

    class MockRegex(object):
        def __init__(self, pattern='', flags=0):
            self.pattern = pattern
            self.flags = flags

        def _mock_regex_function(self):
            return 'MockRegex._mock_regex_function'

    lr = LazyRegex(args=('pattern',), kwargs={'flags': 0, 'test': True})
    lr._real_re_compile = lambda pattern, flags, **kwargs: MockRegex(
        pattern, flags)

    # The lazy object should be collapsed to the real regex object
    # after each call to `_mock_regex_function()`.
    lr._mock_regex_function()

# Generated at 2022-06-24 02:46:40.973911
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    #__eq__ should ignore the attribute _preformatted_string
    exception1 = InvalidPattern('msg1')
    exception2 = InvalidPattern('msg1')
    exception1._preformatted_string = 'msg1'
    exception2._preformatted_string = 'msg2'
    assert exception1 == exception2

# Generated at 2022-06-24 02:46:51.722138
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should compare the values of the format string and the error"""
    from bzrlib.tests import TestCaseWithTransport
    test = TestCaseWithTransport()
    class_1 = InvalidPattern('error one')
    class_2 = InvalidPattern('error two')
    test.assertNotEqual(class_1, class_2)

    class_1 = InvalidPattern('error one')
    class_2 = InvalidPattern('error one')
    class_2._fmt = 'error three'
    test.assertNotEqual(class_1, class_2)

    class_1 = InvalidPattern('error one')
    class_2 = InvalidPattern('error one')
    test.assertEqual(class_1, class_2)

# Generated at 2022-06-24 02:46:54.356643
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of class LazyRegex."""
    obj = LazyRegex(r'(?:foo)(?:bar)(?P<name>baz)')
    assert isinstance(obj, LazyRegex)


# Generated at 2022-06-24 02:47:01.019868
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method __getattr__ of class LazyRegex."""
    assert hasattr(LazyRegex, '__getattr__')
    proxy = LazyRegex()
    assert proxy._real_regex is None
    assert hasattr(proxy, 'findall')
    # test for bug #323361: we must not use the cached regexp when called with
    # different flags.
    import sys
    if sys.version_info[:2] < (2, 5):
        pattern = '(a)(b)(?i)(c)(d)(?-i)(e)(f)(?i)(g)(h)(?-i)(i)(j)'
    else:
        pattern = '(a)(b)(?i)(c)(d)(?-i)(e)(f)'
    string = 'abcdABCDefghEFGHijIJ'
   

# Generated at 2022-06-24 02:47:04.871097
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import __bzr_i18n_test__
    # We hack the LANGUAGE env var so that gettext() will find the
    # translations for this test.
    __bzr_i18n_test__._setup_testing_translations()

# Generated at 2022-06-24 02:47:06.703626
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod(re)

# Generated at 2022-06-24 02:47:11.942848
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern."""
    msg = 'test'
    e1 = InvalidPattern(msg)
    e2 = InvalidPattern(msg)
    e3 = InvalidPattern(msg + '3')
    e4 = Exception()
    assert e1 == e2
    assert not e1 == e3
    assert not e1 == e4

# Generated at 2022-06-24 02:47:13.579621
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    error = InvalidPattern("test")
    error.msg = 'msg'
    str(error)
    unicode(error)

# Generated at 2022-06-24 02:47:24.535405
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # test with format string
    fmt = '%(msg)s'
    msg = 'msg'
    e = InvalidPattern(msg)
    setattr(e, '_fmt', fmt)
    str_expected = 'msg'
    str_actual = str(e)
    if str_actual != str_expected:
        raise AssertionError(
            "str(e) does not return expected value.\n" \
            "expected: %s\n actual: %s\n" \
            % (str_expected, str_actual))
    e = InvalidPattern(msg)
    str_expected = 'Unprintable exception InvalidPattern: ' \
        'dict={"msg": "msg"}, fmt="%(msg)s", error=None'
    str_actual = str(e)

# Generated at 2022-06-24 02:47:33.522645
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for _LazyRegex__getattr__ method."""
    from cStringIO import StringIO
    from bzrlib.tests import TestSkipped, TestCase

    class TestLazyRegex(TestCase):
        def test__getattr__(self):
            obj = LazyRegex(('a',))
            self.assertRaises(AttributeError, getattr, obj, 'attr')

    class TestLazyRegexWithRealRegex(TestCase):
        def setUp(self):
            self.old_out = StringIO()
            self.addCleanup(setattr, self, 'old_out', None)


# Generated at 2022-06-24 02:47:44.977389
# Unit test for function finditer_public
def test_finditer_public():
    """Unit tests for function finditer_public."""
    from bzrlib import tests
    import re


# Generated at 2022-06-24 02:47:51.067917
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    lazyreg = LazyRegex([], {})
    pickled_lazyreg = pickle.dumps(lazyreg)
    unpickled_lazyreg = pickle.loads(pickled_lazyreg)
    # just check that we do not get following exception:
    # AttributeError: 'LazyRegex' object has no attribute '_regex_args'
    assert(unpickled_lazyreg._regex_args == [])

# Generated at 2022-06-24 02:48:02.530111
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test lazy compilation.
    """
    global re

# Generated at 2022-06-24 02:48:13.712849
# Unit test for function lazy_compile
def test_lazy_compile():
    import unittest

    # We can't just check that re.compile is lazy_compile, because if that is
    # overridden elsewhere, it will not have been replaced by our install()
    # function. Instead we check that the function we get back is the same
    # object as the one we created.
    class TestLazyCompile(unittest.TestCase):
        def test_compile(self):
            self.assertTrue(lazy_compile is re.compile)

        def test_bad_pattern_regex(self):
            # bug #340450: LazyRegex produces a useful error message
            self.assertRaises(InvalidPattern, re.compile, "*")

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 02:48:21.514558
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should always return a 'str' object, never a 'unicode' object."""
    s = str(InvalidPattern('test message'))
    if not isinstance(s, str):
        raise AssertionError
    u = unicode(InvalidPattern('test message'))
    if isinstance(u, str):
        raise AssertionError
    try:
        unicode(InvalidPattern(u'\u0102\u0104'))
    except AssertionError:
        raise AssertionError('Could not create InvalidPattern with non ascii \
message')

# Generated at 2022-06-24 02:48:23.399042
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()

# Generated at 2022-06-24 02:48:32.623616
# Unit test for function finditer_public
def test_finditer_public():
    # finditer_public returns a real regex when it receives one
    r = re.compile('.*')
    e = re.finditer_public(r, '')
    assert isinstance(e, re._pattern_type)

    # finditer_public returns the real regex when it receives a LazyRegex
    r = re.compile('.*')
    e1 = r.finditer('')
    e2 = re.finditer_public(LazyRegex(('',)), '')
    assert e1 == e2

    try:
        # Testing if finditer_public raises InvalidPattern with an invalid regex
        e = re.finditer_public(LazyRegex(('', 1)), '')
    except InvalidPattern:
        pass
    else:
        assert False, "InvalidPattern Exception not raised"

# Generated at 2022-06-24 02:48:41.007439
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # test a string is returned
    e = InvalidPattern('msg')
    assert isinstance(e.__str__(), str)

    # test it returns a preformatted message for a UnicodeDecodeError
    e._preformatted_string = u'unicode'
    assert isinstance(e.__str__(), str)

    # test it returns a preformatted message for a ValueError
    e._preformatted_string = 'foobar'
    assert e.__str__() == 'foobar'

# Generated at 2022-06-24 02:48:43.226768
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    assert repr(InvalidPattern(u'hello world')) == \
        'InvalidPattern(hello world)'

# Generated at 2022-06-24 02:48:51.102259
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # After a call to .match(string) the LazyRegex should no longer be a proxy
    # for the compiled regex but instead forwards directly to the compiled
    # regex.
    re_proxy = LazyRegex(("^(?P<key>.*?)\s+(?P<value>.*?)$", re.MULTILINE))
    try:
        assert isinstance(re_proxy, LazyRegex)
        re_proxy.match("key value")
        assert not isinstance(re_proxy, LazyRegex)
    finally:
        reset_compile()


if __name__ == '__main__':
    install_lazy_compile()

# Generated at 2022-06-24 02:48:55.905588
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Ensure __str__ returns a str type and not a unicode type."""
    s = InvalidPattern("foo")
    # Note: not asserting the value 'foo', just that it is a str type
    assert type(str(s)) == str


# Generated at 2022-06-24 02:49:04.184869
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    r = re.compile('foo')
    r_pickled = b'cbrzrlib.patiencediff.LazyRegex\np0\n(dp1\nS\'kwargs\'\np2\nI00\nsS\'args\'\np3\n(X\x03\x00\x00\x00fooq\x00tb.'
    r = LazyRegex()
    r.__setstate__({"kwargs": {}, "args": ('foo',)})
    assert(r.__getstate__() == {"kwargs": {}, "args": ('foo',)})
    assert(pickle.dumps(r) == r_pickled)

# Generated at 2022-06-24 02:49:13.825231
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that default compile mode can be overridden."""
    import testtools
    def test_regex_compile():
        """Test that lazy_compile is called when re.compile is called."""
        install_lazy_compile()
        try:
            r = re.compile('foo')
            testtools.TestCase.assertIsInstance(r, LazyRegex,
                "re.compile() didn't return a LazyRegex object")
            reset_compile()
            r = re.compile('bar')
            testtools.TestCase.assertIsNot(r, LazyRegex,
                "re.compile() returned a LazyRegex object")
        finally:
            reset_compile()
    test_regex_compile()

# Generated at 2022-06-24 02:49:17.925874
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'Testing something'
    exc = InvalidPattern(msg)
    assert exc.msg == msg
    assert str(exc) == 'Invalid pattern(s) found. ' + msg
    assert repr(exc) == "InvalidPattern('Invalid pattern(s) found. " + msg + "')"

# Generated at 2022-06-24 02:49:28.245954
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern.

    If we compare two different classes, we expect to get NotImplemented.
    """
    ex = InvalidPattern(msg=u'')
    ex2 = InvalidPattern(msg=u'')
    ex3 = InvalidPattern(msg=u'abc')
    ex4 = InvalidPattern(msg=u'xyz')
    # ex and ex2 have the same message
    assert ex == ex2
    # ex and ex3 have different messages
    assert ex != ex3
    # ex2 and ex3 have different messages
    assert ex2 != ex3
    # ex2 and ex4 have different messages
    assert ex2 != ex4

    # ex3 and ex4 have different messages
    assert ex3 != ex4
    # ex3 and ex4 have different message
    assert ex3 != ex4

# Generated at 2022-06-24 02:49:31.283009
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    if re.compile != _real_re_compile:
        raise AssertionError('re.compile is not restored back')

# Generated at 2022-06-24 02:49:43.356107
# Unit test for function reset_compile
def test_reset_compile():
    """Test basic functionality of LazyRegex."""
    import doctest
    import re

    if re.compile != _real_re_compile:
        raise AssertionError("install_lazy_compile failed to configure re")

    # Tests are in a different module to avoid circular import
    from bzrlib import lazy_re_tests
    doctest.testmod(lazy_re_tests, optionflags=doctest.NORMALIZE_WHITESPACE)

    # Finally check that reset_compile() works and doesn't leak
    reset_compile()
    if re.compile != _real_re_compile:
        raise AssertionError("reset_compile failed to reset re")



# Generated at 2022-06-24 02:49:49.180578
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return the state to use when pickling."""
    regex = LazyRegex(args=('^[0-9]+$',), kwargs={'re.IGNORECASE': True})
    state = regex.__getstate__()
    assert state == {'args': ('^[0-9]+$',), 'kwargs': {'re.IGNORECASE': True}}, (
        "__getstate__ should return the state to use when pickling")


# Generated at 2022-06-24 02:49:57.325541
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ on LazyRegex."""
    import cPickle
    args = ("pattern", )
    kwargs = {"flags": re.IGNORECASE}
    rx = LazyRegex(args, kwargs)
    # Not compiled
    assert rx._real_regex is None
    # Not yet an attribute
    assert not hasattr(rx, "match")
    # State
    state = rx.__getstate__()
    assert state["args"] == args
    assert state["kwargs"] == kwargs
    # Compile
    rx.match("abc")
    assert rx._real_regex is not None
    # Not stored in the state
    assert "real_regex" not in state
    # But stored in the pickle
    pickle = cPickle.d

# Generated at 2022-06-24 02:50:09.691941
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that the constructor of LazyRegex works properly."""
    lazy = LazyRegex()
    assert lazy._real_regex is None
    assert lazy._regex_args == ()
    assert lazy._regex_kwargs == {}
    lazy = LazyRegex(())
    assert lazy._real_regex is None
    assert lazy._regex_args == ()
    assert lazy._regex_kwargs == {}
    lazy = LazyRegex((), {})
    assert lazy._real_regex is None
    assert lazy._regex_args == ()
    assert lazy._regex_kwargs == {}
    lazy = LazyRegex((), dict())
    assert lazy._real_regex is None
    assert lazy._regex_args == ()
    assert lazy._regex_kwargs == {}
    lazy = L

# Generated at 2022-06-24 02:50:15.339885
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should return a string.

    InvalidPattern.__str__ should return a str object.
    """
    from cStringIO import StringIO
    from bzrlib.trace import mutter
    mutter_file = StringIO()
    mutter_stream = mutter.get_log_file()
    mutter.set_log_file(mutter_file)
    e = InvalidPattern('error message')
    try:
        str(e)
    finally:
        mutter.set_log_file(mutter_stream)
    mutter_file.seek(0)
    mutter_text = mutter_file.read()

# Generated at 2022-06-24 02:50:23.908229
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """
    Function test_install_lazy_compile tests whether the function install_lazy_compile
    works fine.

    install_lazy_compile()
        - Install the new function to re.compile.
        - re.compile which will then return a LazyRegex object.
        - It tests with different number of arguments supported by re.compile.
        - It then tests when call reset_compile() to return back to original
        - re.compile function.
    """
    # test the function with no arguments
    ptrn = re.compile()
    assert isinstance(ptrn, LazyRegex)
    # we expect some exception when we call this function with LazyRegex object
    # because it doesn't support all the members of compiled regex objects.
    # however, it doesn't matter here.

# Generated at 2022-06-24 02:50:25.884418
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    err = InvalidPattern("Error Message")
    expected = 'InvalidPattern("Error Message")'
    assert repr(err) == expected

# Generated at 2022-06-24 02:50:31.725183
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public

    The function is essentially a decorated version of the private function
    _finditer.  This test is to confirm that it works equivalent to the
    original.
    """
    if not getattr(re, 'finditer', False):
        return True
    for pattern, string, boolean in [
        ('', '', True),
        ('', 'notempty', False),
        ('pattern', 'pattern', True),
        ('pattern', '', False),
        ('pattern', 'notpattern', False),
        ('p*', 'pattern', True),
        ('p*', '', True),
        ('p*', 'notempty', True),
        ]:
        for flags in [0, re.IGNORECASE]:
            if flags & re.IGNORECASE:
                pattern = pattern.upper()
           

# Generated at 2022-06-24 02:50:33.041390
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 02:50:38.526562
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Check if we can get the __getstate__ result of LazyRegex.
    """
    import pickle
    pattern = LazyRegex(('\w+', 'i'), {'flags':re.X})
    state = pattern.__getstate__()
    assert isinstance(state, dict)
    assert state == {
            "args": ('\w+', 'i'),
            "kwargs": {'flags': re.X}
            }
    # Check if we can pickle the __getstate__ dictionary.

# Generated at 2022-06-24 02:50:40.001757
# Unit test for function finditer_public
def test_finditer_public():
    # This function is unit tested in test_lazy_regex
    return

# Generated at 2022-06-24 02:50:42.073627
# Unit test for function reset_compile
def test_reset_compile():
    _real_re_compile = re.compile
    try:
        re.compile = lazy_compile
        reset_compile()
        assert re.compile is _real_re_compile
    finally:
        re.compile = _real_re_compile


# Generated at 2022-06-24 02:50:51.449020
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that we can proxy the regexes properly"""
    try:
        install_lazy_compile()
        reg1 = re.compile('a')
        reg2 = re.compile('b')
        reg3 = re.compile('c')
        reg1.search('c')
        reg2.search('c')
        reg3.search('c')
        # We should have compiled the real_regexes now
        assert reg1._real_regex is not None
        assert reg2._real_regex is not None
        assert reg3._real_regex is not None
    finally:
        reset_compile()

# Generated at 2022-06-24 02:51:01.935836
# Unit test for function finditer_public
def test_finditer_public():
    import unittest
    import re

    class TestFindIterPublic(unittest.TestCase):

        def test_finditer_public(self):
            # re.finditer return a lazy iter, so next(finditer_public(...)) is
            # not the same as next(re.finditer(...))
            # As a general rule, you should prefer using re.finditer
            lazy_re = lazy_compile("(?P<word>\w+)")
            iterator = re.finditer("(?P<word>\w+)", "Hello World")
            next_iterator = finditer_public(lazy_re, "Hello World")
            match = next(iterator)

# Generated at 2022-06-24 02:51:05.463421
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should always return a str."""
    s = InvalidPattern(msg='foo').__str__()
    assert type(s) is str


# Regex compilation is fast enough, and it saves a lot of confusion if we
# don't use the lazy version.
install_lazy_compile()

# Generated at 2022-06-24 02:51:14.750497
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that re.compile() can be overridden"""
    import re
    # first, check that we can restore (even if we don't use it yet)
    re.compile = lazy_compile
    reset_compile()
    # now, we can actually override it
    re.compile = lazy_compile
    # check that it is overridden
    assert re.compile == lazy_compile
    re.compile = _real_re_compile
    # make sure the default is restored
    assert re.compile == _real_re_compile


# Install the function to override the behaviour by default
install_lazy_compile()

# Generated at 2022-06-24 02:51:26.989726
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test method __str__ of InvalidPattern"""
    # test if string is decoded
    utf8_msg = "Error: '\xed\xa0\x80\xed\xb6\x84' not found in "\
               "the MIB for decoding."
    pattern = InvalidPattern(utf8_msg)
    # the message should be decoded to unicode
    assert isinstance(pattern, InvalidPattern)
    assert isinstance(unicode(pattern), unicode)
    assert str(pattern) == utf8_msg.decode('utf8')
    assert unicode(pattern) == utf8_msg.decode('utf8')
    # test if string is already unicode
    ucs4_msg = u"Error: '\ud840\udc94' not found in the MIB for decoding"

# Generated at 2022-06-24 02:51:36.699773
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public"""
    re.compile = _real_re_compile
    string = 'my string'
    pattern = '\w+'
    flags = 0
    assert re.finditer(pattern, string) == re.finditer_public(pattern, string)

    re.compile = lazy_compile
    assert re.finditer(pattern, string) == re.finditer_public(pattern, string)

    re.compile = _real_re_compile
    test = re.finditer_public(re.compile(pattern), string, flags)
    assert test == re.finditer_public(pattern, string)
    assert test == re.finditer_public(pattern, string, flags)
    for i in test:
        assert i

# Generated at 2022-06-24 02:51:45.746762
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests import TestCase
    from bzrlib.trace import mutter
    # The repr of InvalidPattern only prints the error message, so if we
    # want to check the repr, we must use a preformatted one that we can
    # check against.
    invalid_pattern = InvalidPattern('Oh noes')
    invalid_pattern._preformatted_string = 'Oh noes'

# Generated at 2022-06-24 02:51:56.795508
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    import sys
    import unittest

    class TestLazyRegex___getattr__(unittest.TestCase):
        """Test method __getattr__ of class LazyRegex."""
        def test_LazyRegex___getattr__(self):
            """Test method __getattr__ of class LazyRegex."""
            from bzrlib import lazy_regex
            if sys.version_info[:2] == (2, 7):
                pattern = '.*'  # python 2.7 does not accept empty pattern
            else:
                pattern = ''

            lazy_regex.reset_compile()

            self.assertIs(lazy_regex.lazy_compile, _real_re_compile)

# Generated at 2022-06-24 02:52:06.470636
# Unit test for function finditer_public
def test_finditer_public():
    """Test the public version of re.finditer in case this function gets
    overridden by a private version.
    """
    from bzrlib.tests import TestCase
    from re import (S, finditer as public_finditer)

    class TestFinditerPublic(TestCase):

        def test_finditer_proxy(self):
            if not public_finditer:
                return
            # Create a proxy object
            proxy = LazyRegex((r'[0-9]', S))
            # Find all digits with re.finditer using a proxy regex
            proxy_finditer = finditer_public(proxy, "123")
            self.assertIsNot(proxy_finditer, None)
            self.assertIs(proxy_finditer, proxy.finditer("123"))
            # Find all digits with re.finditer using a real regex


# Generated at 2022-06-24 02:52:15.548807
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import sys
    from tempfile import NamedTemporaryFile
    from bzrlib import osutils

    lazy_regex = LazyRegex(('^\d+$', 0))
    # force the creation of the real regex
    str(lazy_regex)

    # Unit test for the __getstate__ and __setstate__
    temp_file = NamedTemporaryFile()
    pickled_regex = LazyRegex(('^\d+$', 0))
    osutils.write_pickle_file(temp_file.name, pickled_regex)
    result = osutils.read_pickle_file(temp_file.name)
    # we must check that we have the same class
    if not isinstance(result, LazyRegex):
        raise AssertionError
    # check that the result is the

# Generated at 2022-06-24 02:52:23.817631
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test if LazyRegex can be pickled."""
    import pickle

    lazy_regex = LazyRegex()
    pickled = pickle.dumps(lazy_regex)
    lazy_regex_restored = pickle.loads(pickled)
    lazy_regex_restored.search('')  # Initialize the object

    # Check if the objects are identical
    assert lazy_regex._regex_args == lazy_regex_restored._regex_args
    assert lazy_regex._regex_kwargs == lazy_regex_restored._regex_kwargs
    assert lazy_regex._real_regex._pattern == lazy_regex_restored._real_regex._pattern
    assert lazy_regex._real_regex.flags == lazy_regex_restored._

# Generated at 2022-06-24 02:52:36.041062
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test it with string containing only ASCII chars
    invalidPattern = InvalidPattern('ASCII string')
    str_invalidPattern = str(invalidPattern)
    assert isinstance(str_invalidPattern, str)
    assert str_invalidPattern == 'Invalid pattern(s) found. ASCII string'
    unicode_invalidPattern = unicode(invalidPattern)
    assert unicode_invalidPattern == u'Invalid pattern(s) found. ASCII string'
    # Test it with string containing accented characters
    invalidPattern = InvalidPattern(u'String with accented characters \xe9')
    str_invalidPattern = str(invalidPattern)
    assert isinstance(str_invalidPattern, str)
    assert str_invalidPattern == 'Invalid pattern(s) found. String with accented characters \xc3\xa9'
    unicode

# Generated at 2022-06-24 02:52:43.175760
# Unit test for function finditer_public
def test_finditer_public():
    s = 'one fish two fish red fish blue fish'
    r = re.compile('fish')
    assert [i for i in re.finditer('fish', s)] == \
        [i for i in re.finditer_public(r, s)]


install_lazy_compile()


# Some tests to make sure that this works correctly

# Generated at 2022-06-24 02:52:53.344593
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ sets the state of LazyRegex."""
    args = ("pattern",)
    kwargs = {"flags": re.LOCALE}
    lazy = LazyRegex(args, kwargs)
    state = lazy.__getstate__()
    assert state == {"args": args, "kwargs": kwargs}
    assert lazy._real_regex is None
    lazy.__setstate__(state)
    assert lazy._regex_args == args
    assert lazy._regex_kwargs == kwargs

# Generated at 2022-06-24 02:53:00.551562
# Unit test for function finditer_public
def test_finditer_public():
    # If a LazyRegex is passed to finditer_public, the function finditer
    # of the LazyRegex is called
    lazy_re = LazyRegex(('.',))
    def finditer_mock(*args, **kwargs):
        return ['Fake']
    lazy_re.finditer = finditer_mock
    output = finditer_public(lazy_re, 'string')
    assert(output == ['Fake'])
    # If a LazyRegex is not passed to finditer_public, the function finditer
    # of a compiled regex is called
    output = finditer_public('(.)', 'string')
    assert(list(output) == ['s', 't', 'r', 'i', 'n', 'g'])

# Generated at 2022-06-24 02:53:04.551977
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    error = InvalidPattern('test message')
    expected_msg = 'Invalid pattern(s) found. test message'
    raiseerror(error, expected_msg)



# Generated at 2022-06-24 02:53:14.209894
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Ensure that class InvalidPattern works as expected.

    This test checks:
      - that the '%' operator for the result of str() is supported.
        As InvalidPattern supports __unicode__, Python3 will call
        __unicode__(self).__mod__(kw) instead of __str__(self).__mod__(kw)
        when the type of kw is unicode.
      - that str() returns bytes and not unicode.
      - that unicode() returns unicode and not bytes.

    This test will fail if InvalidPattern.__str__ returns an unicode object.
    """
    class MyInvalidPattern(InvalidPattern):
        _fmt = u'MyInvalidPattern error %(errno)d'
    i = MyInvalidPattern(errno=1)
    s = u'%s' % i