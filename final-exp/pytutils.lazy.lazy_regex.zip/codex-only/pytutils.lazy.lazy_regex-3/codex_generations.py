

# Generated at 2022-06-24 02:43:10.513912
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    e = InvalidPattern("test message")
    r = repr(e)
    assert r == 'InvalidPattern("test message")'

# Generated at 2022-06-24 02:43:14.940608
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ of LazyRegex should compile a regex object on first use"""
    regex_proxy = LazyRegex(args=["^([0-9]+)$"])
    # The regex should not have been compiled yet
    assert regex_proxy._real_regex is None

    # Calling a method on the regex should compile it
    regex_proxy.match("42")
    assert regex_proxy._real_regex is not None

# Generated at 2022-06-24 02:43:20.651234
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS,
                    extraglobs={'InvalidPattern': InvalidPattern,
                                'unicode': unicode,
                                'str': str,
                                'u': unicode,
                                })


if __name__ == "__main__":
    test_InvalidPattern()

# Generated at 2022-06-24 02:43:29.861040
# Unit test for function lazy_compile
def test_lazy_compile():
    re.compile = _real_re_compile
    regexp = re.compile("\d+").pattern
    install_lazy_compile()
    try:
        lazy_re = lazy_compile("\d+")
        reset_compile()
        re.compile = _real_re_compile
        re_re = re.compile("\d+")
        assert(regexp == lazy_re.pattern == re_re.pattern)
        # test that the regex is really compiled on demand
        assert(re_re is not lazy_re._real_regex)
        assert(re_re is lazy_re._real_regex)
    finally:
        reset_compile()

# Generated at 2022-06-24 02:43:33.206655
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Method __repr__ of class InvalidPattern should return a string equal to
    'InvalidPattern(my-message).
    """
    e = InvalidPattern('my-message')
    assert repr(e) == 'InvalidPattern(my-message)'


# Generated at 2022-06-24 02:43:37.753116
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that LazyRegex objects proxy as expected and are lazy.

    Only the first test is in this module because the rest require monkey
    patching re.compile to use the LazyRegex object.
    """
    import doctest
    import bzrlib.tests
    return doctest.DocTestSuite(bzrlib.tests.test_lazy_regex,
                                optionflags=doctest.NORMALIZE_WHITESPACE)


# Generated at 2022-06-24 02:43:38.473981
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:43:43.350343
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ must call _compile_and_collapse() iff _real_regex is None"""
    re_compile = LazyRegex()
    assert re_compile._real_regex is None
    # calling any accessible methods must trigger compilation
    re_compile.match("")
    assert re_compile._real_regex
    # calling __getattr__ must not recompile it
    assert re_compile.search("")
    # calling inaccessible methods must trigger compilation
    assert re_compile.__copy__()
    assert re_compile.__deepcopy__()
    assert re_compile.findall("")
    assert re_compile.finditer("")
    assert re_compile.match("")
    assert re_compile.scanner("")
    assert re_compile.search

# Generated at 2022-06-24 02:43:53.878954
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from . import tests
    tests.BlackboxTestCase(tests.TestCaseWithTransport).assertThat(
        're.compile(".*")',
        tests.MatchesException(Exception,
                               r'must be string without null bytes or callable'))

    install_lazy_compile()
    # now with lazy_compile enabled, see that the same call works.
    tests.TestCaseWithTransport.assertEqual('', re.compile(".*").pattern)

    # But now that re.compile() is lazy, we can't compare it with
    # _real_re_compile.

# Generated at 2022-06-24 02:43:55.172280
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern(None)
    test_str = str(e)
    test_unicode = unicode(e)
    assert 'Invalid pattern' in test_str
    assert 'Invalid pattern' in test_unicode

# Generated at 2022-06-24 02:43:59.783253
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    proxy = LazyRegex(['abc'])
    # ensure that we were assigned the proxy
    assert proxy._regex_args[0] == 'abc'
    # ensure that the regex hasn't been compiled yet
    assert proxy._real_regex is None

# Test that we do get an object, even if we pass in a bad pattern

# Generated at 2022-06-24 02:44:08.744047
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    p = LazyRegex(args=("foo",), kwargs={"flags": re.IGNORECASE, "verbose": "True"})
    p._compile_and_collapse()
    import pickle
    pp = pickle.loads(pickle.dumps(p))
    assert pp._regex_kwargs == p._regex_kwargs
    assert pp._regex_args == p._regex_args
    assert pp._real_regex.pattern == p._real_regex.pattern
    assert pp._real_regex.flags == p._real_regex.flags

# Generated at 2022-06-24 02:44:09.978840
# Unit test for function finditer_public
def test_finditer_public():
    """Tests the function finditer_public."""
    import doctest
    doctest.testmod(re, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 02:44:12.827134
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    s = LazyRegex(("abc"), {"flags": 2})
    assert s.__getstate__() == dict(args=("abc",), kwargs={"flags": 2})


# Generated at 2022-06-24 02:44:19.775627
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile modifies re.compile"""
    from bzrlib import tests
    from bzrlib.tests import (
        test_regex,
        )
    try:
        install_lazy_compile()
        test_regex.TestCompile.test_compile()
    finally:
        reset_compile()


if __name__ == '__main__':
    # Import bzrlib so that we can run test_suite
    import bzrlib
    bzrlib.initialize()
    bzrlib.tests.run_suite(locals())

# Generated at 2022-06-24 02:44:28.937166
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    from bzrlib import osutils

    if sys.platform == "win32":
        from bzrlib.tests import test_osutils
        # We depend on the encoding used by osutils.get_user_encoding in
        # InvalidPattern.__str__, so we have to patch it.
        test_osutils.patch_get_user_encoding(test_osutils.FakeUserEncoding("utf8"))
        try:
            # The user encoding is set to utf-8, and _fmt is ascii. On
            # Windows, this means that the result of _get_format_string()
            # will be a unicode object.
            e = InvalidPattern("")
        finally:
            test_osutils.restore_get_user_encoding()

# Generated at 2022-06-24 02:44:34.829643
# Unit test for function finditer_public
def test_finditer_public():
    """Test that re.finditer calls the LazyRegex.finditer function."""
    pattern = '^[0-9]+$'
    string = '12345'
    flags = 0
    result = finditer_public(pattern, string, flags)
    assert pattern == result.next().group(0)
    pattern = lazy_compile(pattern)
    result = finditer_public(pattern, string, flags)
    assert pattern == result.next().group(0)

# Generated at 2022-06-24 02:44:45.129012
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the LazyRegex type."""

    import pickle
    lr = lazy_compile(r'(\w+) (\w+)(?:\s+(\w+))?', re.IGNORECASE)

    assert lr.pattern is None
    assert lr.flags is None
    assert lr.groups is None
    assert lr.groupindex is None
    assert lr.pattern is None

    # Check that it actually lazily compiles on access.
    assert isinstance(lr.match('this is a test'), re.MatchObject)
    assert lr.pattern == r'(\w+) (\w+)(?:\s+(\w+))?'
    assert lr.flags == re.IGNORECASE

    # Check that compilation is done only once
    assert lr._real_regex is not None
   

# Generated at 2022-06-24 02:44:50.820373
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test that InvalidPattern.__repr__ returns a Pythonic representation of
    the exception.
    """
    err = InvalidPattern('Invalid pattern "abcd".')
    eq = 'InvalidPattern("Invalid pattern \\"abcd\\".")'
    assert repr(err) == eq



# Generated at 2022-06-24 02:44:59.848973
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """"""
    # Try a simple lazy_compile
    proxy_regex = lazy_compile('^test$')

    # Verify that it is indeed a proxy
    assert isinstance(proxy_regex, LazyRegex)
    assert proxy_regex._real_regex is None

    # Try a real compile call
    # TODO: this is an instance method of the proxy, can we make it work?
    # proxy_regex._compile_and_collapse()
    real_regex = re.compile(proxy_regex._regex_args[0],
                            *proxy_regex._regex_args[1:],
                            **proxy_regex._regex_kwargs)

    # verify that we have a real regex
    assert real_regex._real_regex is not None


# Generated at 2022-06-24 02:45:06.557291
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.trace import mutter
    try:
        raise InvalidPattern(mutter("Testing method __repr__ for InvalidPattern"))
    except InvalidPattern as e:
        assert e.__repr__() == "InvalidPattern('Testing method __repr__ for InvalidPattern')"
        assert e.__str__() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'

# Generated at 2022-06-24 02:45:12.513426
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should return True if and only if the object is identical."""
    # create an object
    a = InvalidPattern("foo")
    b = InvalidPattern("foo")
    # the objects are equal
    assert a == b
    # change the value of b
    b.msg = "bar"
    # the objects are not equal
    assert not a == b

# Generated at 2022-06-24 02:45:22.804355
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # __init__ does not accept keywords
    try:
        InvalidPattern('%(msg)s', msg='x')
    except TypeError:
        pass
    else:
        raise AssertionError("InvalidPattern accepts keywords")
    # __init__.__doc__
    assert InvalidPattern.__init__.__doc__ == TypeError.__init__.__doc__
    # __unicode__
    msg = unicode("msg")
    ip = InvalidPattern(msg)
    s = unicode(ip)
    assert s == u'Invalid pattern(s) found. msg'
    assert ip.msg == msg
    assert ip._format() == s
    # __str__
    s = str(ip)
    assert s == 'Invalid pattern(s) found. msg'
    assert ip.msg == msg
    # __eq__


# Generated at 2022-06-24 02:45:29.426168
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex.

    Create a proxy object and get its pickled state.
    """
    p = LazyRegex(('a(b?c)', ), {'flags': re.IGNORECASE})
    state = p.__getstate__()
    expected_state = {
        "args": ('a(b?c)', ),
        "kwargs": {'flags': re.IGNORECASE},
        }
    if expected_state != state:
        raise AssertionError('State in pickled object is not the same as'
            ' expected state.')

# Generated at 2022-06-24 02:45:32.830251
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r0 = LazyRegex(args=('hi',))
    import pickle
    p = pickle.dumps(r0)
    r1 = pickle.loads(p)
    assert r0.__dict__ == r1.__dict__


# Generated at 2022-06-24 02:45:42.389038
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    import bzrlib.lazy_regex
    # install
    bzrlib.lazy_regex.install_lazy_compile()
    compiled_re = re.compile('foo')
    assert isinstance(compiled_re, LazyRegex)
    # reset
    bzrlib.lazy_regex.reset_compile()
    compiled_re = re.compile('foo')
    assert isinstance(compiled_re, re._pattern_type)
    # install again (should not raise)
    bzrlib.lazy_regex.install_lazy_compile()
    compiled_re = re.compile('foo')
    assert isinstance(compiled_re, LazyRegex)
    # reset again (should not raise)

# Generated at 2022-06-24 02:45:52.221279
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    import doctest
    if sys.version_info[0] == 2:
        from bzrlib.tests import test_i18n
        test_i18n._install_gettext_translations(domain='bzrlib')
    text = doctest.testmod(name='InvalidPattern.__str__',
                           optionflags=doctest.ELLIPSIS)
    if sys.version_info[0] == 2:
        test_i18n._remove_gettext_translations(domain='bzrlib')
    return text.failed

# Generated at 2022-06-24 02:46:00.167032
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for LazyRegex.__getattr__

    This test asserts that self._real_regex is set to the right value.
    """
    # __getattr__ is called only if the attribute is missing.
    # So, the only case where we should end up calling __getattr__
    # is when the attribute is missing.
    # To test this, we will create a list of attributes, add them to the
    # class and then call getattr on the instance, expecting a
    # AttributeError to be raised.
    test = ['__init__', '_compile_and_collapse', '_real_re_compile',
                 '__getstate__', '__setstate__', '__getattr__']

# Generated at 2022-06-24 02:46:06.108674
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Check that the attribute _real_regex is not initialized on an attribute access."""
    # Create a LazyRegex object
    regex = LazyRegex()
    assert regex._real_regex is None
    regex.pattern
    assert regex._real_regex is not None
    # Reset the attribute _real_regex
    regex._real_regex = None
    regex.flags
    assert regex._real_regex is not None



# Generated at 2022-06-24 02:46:10.748849
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e1 = InvalidPattern('foo')
    e2 = InvalidPattern('foo')
    assert e1 == e2
    assert e1 is not e2



# Generated at 2022-06-24 02:46:17.144263
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should compare attributes, not identity"""
    class MyError(InvalidPattern):
        _fmt = 'foo %(bar)s, %(baz)s'
    e1 = MyError('bar value', 'baz value')
    e2 = MyError('bar value', 'baz value')
    assert e1 == e2
    assert e2 == e1
    assert not (e1 != e2)
    assert not (e2 != e1)


_regex_internal_cache = {}


# Generated at 2022-06-24 02:46:24.752730
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of InvalidPattern class."""
    sut = InvalidPattern(
        'Invalid pattern(s) found. Invalid pattern "*.c" found')
    expected = r'InvalidPattern\(Invalid pattern\(s\) found\. Invalid pattern "\\*.c" found\)'
    observed = repr(sut)
    assert expected == observed, \
        'InvalidPattern()__repr__ is %s and not %s' % (observed, expected)

# Generated at 2022-06-24 02:46:32.386291
# Unit test for function lazy_compile
def test_lazy_compile():
    import cStringIO
    import sys
    import bzrlib.tests

# Generated at 2022-06-24 02:46:44.102379
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the LazyRegex object works as expected."""
    import os
    import sys
    from cStringIO import StringIO
    from bzrlib import tests

    install_lazy_compile()

    # Check that a simple 'no error' case works
    myregex = lazy_compile("^\S")
    str = "no match"
    assert str == myregex.match(str).group()

    # Check that a regexp error is still reported
    myregex = lazy_compile("\S[")
    exc = tests.TestCase.assertRaises(InvalidPattern, myregex.match, "")

    # Check that a proper regex is returned
    myregex = lazy_compile("^\S")

# Generated at 2022-06-24 02:46:53.568770
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():

    class _LazyRegexTest(object):
        __slots__ = ['_real_regex', '_regex_args', '_regex_kwargs',] + \
            LazyRegex._regex_attributes_to_copy


    # Test if _compile_and_collpase() works well
    def _test_compile_and_collapse(regex):
        regex._regex_args = (".*",)
        regex._regex_kwargs = {}
        regex._compile_and_collapse()
        for attr in LazyRegex._regex_attributes_to_copy:
            if getattr(regex, attr) is not getattr(regex._real_regex, attr):
                raise AssertionError("Compile and collapse failed.")

    # Test if

# Generated at 2022-06-24 02:47:01.644750
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    if re.compile is not lazy_compile:
        raise TestSkipped('re.compile() is already overridden by something')
    try:
        reset_compile()
        pattern = "Hello World"
        assert isinstance(re.compile(pattern), re._pattern_type)
        install_lazy_compile()
        assert isinstance(re.compile(pattern), LazyRegex)
        reset_compile()
        assert isinstance(re.compile(pattern), re._pattern_type)
    finally:
        reset_compile()
        del re.compile

# Generated at 2022-06-24 02:47:04.645856
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Make sure the constructor of LazyRegex works correctly"""
    lz = LazyRegex(('foo', re.IGNORECASE), {'foo': 'bar'})
    assert lz._regex_args == ('foo', re.IGNORECASE)
    assert lz._regex_kwargs == {'foo': 'bar'}

# Generated at 2022-06-24 02:47:09.598912
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for InvalidPattern.__unicode__()."""
    msg = "This is the exception message."
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        assert unicode(e) == msg


# Generated at 2022-06-24 02:47:11.319578
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)

# Generated at 2022-06-24 02:47:15.537318
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it.
    """
    regex = LazyRegex(('a',))
    if regex.pattern != 'a':
        raise AssertionError(
            "__getattr__ should return a member from the proxied regex object")

# Generated at 2022-06-24 02:47:22.263906
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr = LazyRegex(('a', 'b', 'c'), {'d':True})
    assert lr._compile_and_collapse._func_name == '_compile_and_collapse'
    assert lr._real_regex is None
    assert lr._regex_args == ('a', 'b', 'c')
    assert lr._regex_kwargs == {'d':True}


# Generated at 2022-06-24 02:47:32.556422
# Unit test for function finditer_public
def test_finditer_public():
    """Test function re.finditer_public().
    """
    # getattr(re, 'finditer') may return None if not available.
    if getattr(re, 'finditer', False):
        # re.finditer is available
        r = lazy_compile('(bzr)')
        # The proxy object should return the expected value.
        list_iterator_objects = list(re.finditer(r, 'alice and bob'))
        m = list_iterator_objects[0].group(0)
        eq_(m, 'bzr')

# Generated at 2022-06-24 02:47:44.027992
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the function lazy_compile"""
    install_lazy_compile()
    # 'test_lazy_compile' should be unicode as we pass it as a unicode string
    # to lazy_compile.
    test_lazy_compile = u'test_lazy_compile'
    l_re = re.compile(test_lazy_compile)
    assert isinstance(l_re, LazyRegex)
    assert len(vars(l_re)) == 3
    # Check that the regex is not compiled until requested
    assert l_re._real_regex is None
    # We should be able to access regex attributes
    assert not l_re.match('not_matching')
    # The regex should be compiled now
    assert l_re._real_regex is not None

# Generated at 2022-06-24 02:47:47.088594
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Make sure that the str() of InvalidPattern is usable in unicode()"""
    u = unicode(InvalidPattern('string'))
    # We only care that this doesn't raise an exception
    assert isinstance(u, unicode)


# Generated at 2022-06-24 02:47:57.520613
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile overrides re.compile()

    and that calling reset_compile restores the original value.
    """
    orig_compile = re.compile
    install_lazy_compile()
    try:
        lazy_pattern = re.compile('foo')
        # The pattern was created lazily
        assert isinstance(lazy_pattern, LazyRegex)
        # But can be used as the real thing
        lazy_pattern.search('bar, foo baz')
        reset_compile()
        # But now we are back to the original compile mode
        assert re.compile is orig_compile
    finally:
        reset_compile()

# Generated at 2022-06-24 02:48:04.849546
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return the correct value after the regex is compiled.
    """
    pattern = r'a(bc)(de)(f(g)h)i'
    r = LazyRegex((pattern, re.I | re.L))
    regex_string = pattern.upper()
    regex_flags = re.I | re.L
    assert r._regex_args == (pattern, regex_flags)
    assert r._regex_kwargs == {}
    assert r._real_regex is None
    assert r.pattern == regex_string
    assert r.flags == regex_flags
    assert r.groups == 4
    assert r.groupindex == {}


# Generated at 2022-06-24 02:48:11.294163
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() resets back to the original re.compile()"""
    install_lazy_compile()
    reset_compile()
    install_lazy_compile()
    reset_compile()
    assert lazy_compile == re.compile
    reset_compile()
    assert _real_re_compile == re.compile

# Generated at 2022-06-24 02:48:12.853405
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 02:48:23.222034
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__(other) => True | False | NotImplemented"""
    def _eq(_self, other):
        """_self is an InvalidPattern object. other can be anything."""
        return _self.__eq__(other)

    # If neither self nor other are InvalidPattern objects, returns NotImplemented
    assert NotImplemented == _eq(InvalidPattern('test'), object())

    # If other is not an InvalidPattern object, returns NotImplemented
    assert NotImplemented == _eq(InvalidPattern('test'), object())

    # If self and other have not the same properties, returns False
    self = InvalidPattern('test')
    self.arg1 = 1
    self.arg2 = 'arg2'
    other = InvalidPattern('test')
    other.arg1 = 0

# Generated at 2022-06-24 02:48:29.975355
# Unit test for function finditer_public
def test_finditer_public():
    """Test the function finditer_public.

    This function is defined as a function instead of a method because of
    the decorator `getattr(re, 'finditer', False)`.
    """
    real_re_finditer = re.finditer

    def _finditer_real_re_compile_error(*args, **kwargs):
        raise ValueError("finditer is broken")

    def _finditer_return_mock_generator(*args, **kwargs):
        yield "finditer's first result"

    # We want to make sure finditer_public calls re.finditer.
    # But we can't do that, because re.finditer is finditer_public.
    # So we swap in a stub version of re.finditer that throws an exception if
    # called as expected, while finditer_public is expected to catch the

# Generated at 2022-06-24 02:48:41.490491
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib import osutils
    # Test constructor of class LazyRegex in case args or kwargs is None
    test_args = osutils.split_basename('lazy_regex_test_args')
    test_kwargs = {'test_key1':'test_value1', 'test_key2':'test_value2'}
    test_pattern = LazyRegex(args=None, kwargs=None)
    test_pattern.__init__(args=test_args, kwargs=test_kwargs)
    assert test_pattern._regex_args == (None,)
    assert test_pattern._regex_kwargs == {'test_key1':'test_value1', 'test_key2':'test_value2'}

# Generated at 2022-06-24 02:48:44.768310
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = "Dummy error message"
    ex = InvalidPattern(msg)
    assert str(ex) == msg
    assert "%s" % ex == msg
    assert unicode(ex) == msg
    assert u"%s" % ex == msg


# Generated at 2022-06-24 02:48:55.609737
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ method of InvalidPattern class works correctly.

    The method __eq__ of class InvalidPattern is tested.
    """
    e1 = InvalidPattern('message')
    e1.foo = 'bar'
    e2 = InvalidPattern('message')
    e2.foo = 'bar'
    e3 = InvalidPattern('different message')
    e3.foo = 'bar'
    e4 = InvalidPattern('message')
    e4.foo = 'different bar'
    e5 = InvalidPattern('message')
    e5.foo = 'bar'
    e5.bar = 'something'
    e6 = InvalidPattern('message')
    e6.foo = 'bar'
    e6._preformatted_string = 'something'
    e7 = InvalidPattern('message')
    e7.bar = 'foo'
    e

# Generated at 2022-06-24 02:49:05.213472
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test of method __getattr__ of class LazyRegex.

    The method __getattr__ of LazyRegex is used to get the value of
    an attribute in the object re.compile. The result is to test the
    object re.compile after the substitution of lazy_compile in the
    method re.compile.
    """
    # Create an object LazyRegex
    o_lr = LazyRegex()

    # Test of method __getattr__ of class LazyRegex
    # raise an error, because _real_regex is None

# Generated at 2022-06-24 02:49:14.513776
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test that InvalidPattern.__eq__ works"""
    # First we try with identical messages
    e1 = InvalidPattern('this is a message')
    e2 = InvalidPattern('this is a message')
    e3 = 'not an InvalidPattern instance'
    if not (e1 == e2):
        raise AssertionError('InvalidPattern instances with identical messages'
                             ' are not equal')
    if e1 == e3:
        raise AssertionError('Expected InvalidPattern instances to be unequal to'
                             ' arbitrary object')
    if e1 != e2:
        raise AssertionError('Expected InvalidPattern instances with identical'
                             ' messages to be equal')
    if not (e1 != e3):
        raise AssertionError('Expected InvalidPattern instances to be unequal to'
                             ' arbitrary object')

   

# Generated at 2022-06-24 02:49:22.486460
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex"""
    lazy_regex = LazyRegex(("[a-z]",), {'flags' : re.IGNORECASE})
    state = lazy_regex.__getstate__()
    assert isinstance(state, dict)
    assert state['args'] == ("[a-z]",)
    assert state['kwargs'] == {'flags' : re.IGNORECASE}


# Generated at 2022-06-24 02:49:25.925099
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests.test_re import test_lazy_compile
    install_lazy_compile()
    try:
        test_lazy_compile.test_lazy_compile()
    finally:
        reset_compile()

# Generated at 2022-06-24 02:49:30.005002
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that the constructor of the LazyRegex class works correctly."""
    proxy = LazyRegex((), {"flags": re.IGNORECASE})
    assert proxy._regex_args == ()
    assert proxy._regex_kwargs == {'flags': re.IGNORECASE}


# Generated at 2022-06-24 02:49:36.253050
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test the constructor of class LazyRegex.

    This test performs regression testing for a bug where the constructor
    of LazyRegex did not assign a value to self._real_regex.  The bug was
    caught by pychecker.  The test case passed despite the bug, but I am
    not removing the test case, because this is a mistake that I could
    easily make again.
    """
    LazyRegex()

# Generated at 2022-06-24 02:49:47.896925
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Make sure InvalidPattern.__eq__ works in various cases

    And also that InvalidPattern.__ne__ works as well
    """
    def eq(a, b):
        # assert equality
        assert a == b, "%r != %r" % (a, b)
        assert b == a, "%r != %r" % (b, a)
        assert not (a != b), "%r == %r" % (a, b)
        assert not (b != a), "%r == %r" % (b, a)
    def ne(a, b):
        # assert equality
        assert a != b, "%r == %r" % (a, b)
        assert b != a, "%r == %r" % (b, a)
        assert not (a == b), "%r != %r" % (a, b)


# Generated at 2022-06-24 02:49:53.597841
# Unit test for function lazy_compile
def test_lazy_compile():
    def do_compile(pattern, flags=0):
        return re.compile(pattern, flags)

    # test a few different flags
    # test the re.VERBOSE flag
    regexp = do_compile("""
        (?x)                        # set flag VERBOSE
        \s*                         # optional whitespace
        (\d{4})                     # exactly 4 digits
        (?P<sep>[-/])               # separator, either '-' or '/'
        (\d{1,2})                   # 1 or 2 digits
        \2                          # exactly the same as the previous
        (\d{1,2})                   # 1 or 2 digits
        \s*                         # optional whitespace
        $                           # end of string
        """)
    # test the re.IGNORECASE flag
    regexp_

# Generated at 2022-06-24 02:50:03.094562
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test that it is possible to compare InvalidPattern objects.
    """
    class AnException(Exception):
        pass
    e1 = InvalidPattern('Error 1')
    e2 = InvalidPattern('Error 2')
    e3 = InvalidPattern('Error 1')
    e4 = AnException('Error 1')
    try:
        e1 == e2
    except ValueError:
        pass
    else:
        raise AssertionError(
            "Comparison of InvalidPattern objects should fail unless" \
            " the exception is of the same type")
    e2 == e2
    e2 == e4
    e1 == e3

# Generated at 2022-06-24 02:50:08.887616
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ must return True only if the class type and its attributes are identical"""
    i1 = InvalidPattern("msg1")
    i2 = InvalidPattern("msg2")
    assert i1 != i2
    i1_copy = InvalidPattern("msg1")
    assert i1 == i1_copy
    assert i1 != None
    assert i1 != i1.__dict__
    assert i1 != str(i1)

# Generated at 2022-06-24 02:50:20.397724
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile() works."""
    # Test we can replace re.compile with lazy_compile
    install_lazy_compile()

# Generated at 2022-06-24 02:50:24.834501
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    test_case = LazyRegex(("foo", ), {})
    assert(test_case._regex_args == ("foo", ))
    assert(test_case._regex_kwargs == {})

# Generated at 2022-06-24 02:50:33.099407
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ of LazyRegex should return attribute from its wrapped regex.

    If the wrapped regex hasn't been compiled yet, it should compile it.
    """
    obj = LazyRegex()
    assert obj.findall is re.findall
    assert obj.finditer is re.finditer
    assert obj.match is re.match
    assert obj.scanner is re.scanner
    assert obj.search is re.search
    assert obj.split is re.split
    assert obj.sub is re.sub
    assert obj.subn is re.subn

# Generated at 2022-06-24 02:50:38.557186
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'Invalid pattern "foo" - bar'
    e = InvalidPattern(msg)
    # The constructor should set the message as msg attribute
    assert e.msg == msg
    # The str() should just return the same msg.
    assert str(e) == msg
    assert unicode(e) == msg
    # A repr() should return "<class name>(msg)"
    assert repr(e) == 'InvalidPattern(%s)' % msg
    assert e == InvalidPattern('Invalid pattern "foo" - bar')
    assert e != InvalidPattern('Invalid pattern "foo" - bar ')

# Generated at 2022-06-24 02:50:43.572204
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the install_lazy_compile function"""
    reset_compile()

# Generated at 2022-06-24 02:50:55.508712
# Unit test for function lazy_compile
def test_lazy_compile():
    """This test also covers most of the LazyRegex code."""
    install_lazy_compile()
    # This should work
    r = re.compile('(foo)')
    # This should not be the same object as re._compile
    assert not isinstance(r, _real_re_compile)
    assert isinstance(r, LazyRegex)
    # Now actually use it, to force compilation
    m = r.match('foo')
    # The compiled object should be available
    assert r._real_regex is not None
    # And it should have copied all the relevant attributes
    for attr in LazyRegex._regex_attributes_to_copy:
        assert getattr(r, attr) is not None
    # And it should have matched OK

# Generated at 2022-06-24 02:51:05.039968
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Defines a test suite for the constructor of class LazyRegex.

    To run the test suite in isolation, use the following command:
    python -m testtools.run bzrlib.tests.test_re_compile.test_LazyRegex
    """
    from testtools.matchers import Equals
    from testtools.testcase import ExpectedException

    def test_LazyRegex_constructor_initializes_attributes_given_no_arguments():
        r = LazyRegex()
        expected = ()
        actual = (r._regex_args, r._regex_kwargs)
        Equals(expected)(actual)


# Generated at 2022-06-24 02:51:17.167296
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile."""
    # By default, it doesn't compile until you actually use it
    lazy = lazy_compile('testing')
    assert len(lazy.__dict__) == 1
    assert '_real_regex' not in lazy.__dict__
    assert lazy.match('te') is not None
    assert '_real_regex' in lazy.__dict__
    assert isinstance(lazy._real_regex, _real_re_compile('', 0).__class__)

    # Make sure the regex is still the same
    install_lazy_compile()
    old_regex = re.compile('testing')
    reset_compile()
    assert isinstance(re.compile('testing'), _real_re_compile('', 0).__class__)
    assert re.comp

# Generated at 2022-06-24 02:51:26.525981
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() resets to original value.

    This test must be run before re.compile is ever overridden for this
    import. It will always reset to the original compile function.
    """
    # Ensure that re.compile is the same value that it was at import time
    re.compile = _real_re_compile

    # Change re.compile() to be something other than the original value
    re.compile = lazy_compile

    # Reset to the original value.
    reset_compile()

    # Ensure it worked.
    assert(re.compile is _real_re_compile)



# Generated at 2022-06-24 02:51:27.654747
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    e = InvalidPattern('test')
    assert repr(e) == 'InvalidPattern(\'test\')'

# Generated at 2022-06-24 02:51:37.235623
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern("a Message")
    except InvalidPattern as e:
        assert(str(e) == 'Invalid pattern(s) found. "a Message"')
    try:
        raise InvalidPattern("a %(message)s" % {'message':"Message"})
    except InvalidPattern as e:
        assert(str(e) == 'Invalid pattern(s) found. "a Message"')
    try:
        raise InvalidPattern("%(message)s" % {'message':"a Message"})
    except InvalidPattern as e:
        assert(str(e) == 'Invalid pattern(s) found. "a Message"')

# Generated at 2022-06-24 02:51:45.418086
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ restores the regex correctly"""
    lr = LazyRegex([r'(?P<a>a)'])
    lr = lr.__setstate__({'args': [r'(?P<b>b)'], 'kwargs':{'flags':re.I}})
    assert lr._regex_args == [r'(?P<b>b)']
    assert lr._regex_kwargs['flags'] == re.I
    m = lr.match('b')
    assert m.group('b') == 'b'


# Generated at 2022-06-24 02:51:56.457224
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """This test checks __str__, __unicode__, __repr__ and _format methods."""

    # Check unicode and ascii strings
    msg = 'AbCd'
    exp_str = 'Invalid pattern(s) found. "AbCd"'
    exp_repr = 'InvalidPattern("AbCd")'
    exp_uni = u'Invalid pattern(s) found. "AbCd"'
    exp_fmt = 'Invalid pattern(s) found. "AbCd"'
    test_str = InvalidPattern(msg)
    exp_str = '%s' % exp_str

    test_unicode = InvalidPattern(msg)
    exp_unicode = u'%s' % exp_uni

    test_repr = InvalidPattern(msg)
    exp_repr = '%r' % exp_re

# Generated at 2022-06-24 02:52:06.186632
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # __unicode__ must return a utf-8 string.
    ip = InvalidPattern('The error message')
    if isinstance(ip.__unicode__(), unicode):
        raise AssertionError(
            '__unicode__ should return utf-8 string')
    ip = InvalidPattern(u'The error message')
    if isinstance(ip.__unicode__(), unicode):
        raise AssertionError(
            '__unicode__ should return utf-8 string')
    try:
        ip = InvalidPattern(u'\xc3\xa9')
    except UnicodeDecodeError:
        raise AssertionError(
            'UnicodeDecodeError not allowed here')

# Generated at 2022-06-24 02:52:15.303403
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the code that collapses the proxy to the real regex"""
    # We use a local function to create the test regex, so that we can
    # force the compile in one place, and look at the attribute in another.
    def get_test_regex():
        """Create a test regex"""
        return LazyRegex(("^abc$",))

    regex = get_test_regex()

    # regex.findall should be a bound method to the proxy, the actual object
    # is None
    assert regex.findall("abc") is None

    # Now actually compile the regex
    regex = get_test_regex()
    regex._compile_and_collapse()

    # The compiled object is now available, and we can use the
    # method.
    assert regex.findall("abc") == ["abc"]

    # The attribute

# Generated at 2022-06-24 02:52:21.710992
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    # Test that the __getattr__ of class LazyRegex is not executed when the
    # member is found in self or self.__class__
    class MyLazyRegex(LazyRegex):
        def __getattr__(self, attr):
            raise AssertionError('__getattr__ should not be executed')
    regex = MyLazyRegex()
    regex.valid
    regex.__class__.valid

test_LazyRegex___getattr__()

# Generated at 2022-06-24 02:52:29.711939
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ip = InvalidPattern('invalid')
    u = unicode(ip)
    # Output should be "Invalid pattern(s) found. invalid"
    if u != u'Invalid pattern(s) found. invalid':
        raise AssertionError(
            "InvalidPattern.__unicode__() didn't return expected string")
    if str(ip) != 'Invalid pattern(s) found. invalid':
        raise AssertionError(
            "InvalidPattern.__str__() didn't return expected string")
    # If a the second argument is a Unicode string or a bytestring,
    # then the output should contain the original error string.
    ip = InvalidPattern(u'\xd1')
    u = unicode(ip)

# Generated at 2022-06-24 02:52:39.861573
# Unit test for function reset_compile
def test_reset_compile():
    """This test fails if reset_compile() doesn't properly restore re.compile"""
    # Put the old value of re.compile in a local
    old_compile = re.compile
    try:
        # install the new function
        install_lazy_compile()
        # check that it is the new value
        assert re.compile == lazy_compile
        # restore the old re.compile
        reset_compile()
        # check that it has the old value
        assert re.compile == old_compile
    finally:
        # clean up so the test harness doesn't think we've broken the
        # interpreter
        reset_compile()
        assert re.compile == old_compile

# Generated at 2022-06-24 02:52:49.598266
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests import TestCase

    class Test(TestCase):
        """Unit test for method __repr__ of class InvalidPattern."""

        def test___repr__(self):
            # Test __repr__ with a unicode message.
            i = InvalidPattern('\xf1\xf2\xf3\xf4\xf5')

            # Try repr(i).
            if repr(i) != ("InvalidPattern(u'\\xf1\\xf2\\xf3\\xf4\\xf5')"):
                self.fail("InvalidPattern(u'\\xf1\\xf2\\xf3\\xf4\\xf5') != "
                    "repr(i)")

            # Try repr(i) again.

# Generated at 2022-06-24 02:52:53.878018
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() must return a unicode object."""
    e = InvalidPattern('msg')
    assert type(e) is InvalidPattern
    assert type(e.msg) is str
    assert type(e.__unicode__()) is unicode



# Generated at 2022-06-24 02:53:00.028689
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import tests
    from bzrlib.tests.blackbox import test_sftp_transport
    old_cwd = test_sftp_transport.TestCaseWithSFTPServer.cwd
    try:
        test_sftp_transport.TestCaseWithSFTPServer.cwd = \
            tests.load_tests.enhance_import_path
        doctest.testmod(bzrlib.errors)
    finally:
        test_sftp_transport.TestCaseWithSFTPServer.cwd = old_cwd

# Generated at 2022-06-24 02:53:03.031305
# Unit test for function finditer_public
def test_finditer_public():
    if __name__ == "__main__":
        import doctest
        doctest.testmod()

# Generated at 2022-06-24 02:53:07.530452
# Unit test for function reset_compile
def test_reset_compile():
    def fake_compile(*args):
        pass
    re.compile = fake_compile
    reset_compile()
    re.compile('test')
    re.compile = fake_compile
    try:
        reset_compile()
    except AssertionError:
        pass

# Generated at 2022-06-24 02:53:10.988495
# Unit test for function finditer_public
def test_finditer_public():
    """Test the wrapping of finditer in a way that makes it callable, even
    when it is a LazyRegex.
    """
    re.finditer('an interesting regex', "some text")

