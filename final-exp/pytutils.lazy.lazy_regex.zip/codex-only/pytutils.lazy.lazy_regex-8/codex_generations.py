

# Generated at 2022-06-24 02:43:13.111457
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    exc = InvalidPattern(u'msg')
    try:
        raise exc
    except InvalidPattern as e:
        try:
            unicode(repr(e))
        except UnicodeError as e_:
            unicode(repr(e_))



# Generated at 2022-06-24 02:43:21.783206
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test LazyRegex.__setstate__.

    The __setstate__ method is called when an object is unpickled.
    In case of LazyRegex, it must reset its member attributes to the
    correct value.
    """
    # a LazyRegex created with the default constructor
    lazy = LazyRegex()
    # then we pickle it
    pickled = pickle.dumps(lazy)
    # then we unpickle it
    unpickled = pickle.loads(pickled)
    # it must be correct
    assert unpickled._regex_args == ()
    assert unpickled._regex_kwargs == {}

# Generated at 2022-06-24 02:43:29.781133
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should restore the state properly."""
    object = LazyRegex()
    # first use only.
    setattr(object, "_regex_args", (1,))
    setattr(object, "_regex_kwargs", {"key":"value"})

    # second use
    object.__setstate__({"args": (2,), "kwargs": {"key2":"value2"}})
    # test
    regex_args = getattr(object, "_regex_args")
    regex_kwargs = getattr(object, "_regex_kwargs")
    assert (regex_args == (2,))
    assert (regex_kwargs == {"key2":"value2"})



# Generated at 2022-06-24 02:43:34.694768
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode string"""
    from bzrlib.tests import TestCase
    import string
    for test_string in [u'', u'a', u'\xe5', u'a\xe5'.encode('utf-8')]:
        ip = InvalidPattern(test_string)
        self.assertTrue(isinstance(ip.__unicode__(), unicode))



# Generated at 2022-06-24 02:43:40.957148
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile function for unit tests"""
    install_lazy_compile()

# Generated at 2022-06-24 02:43:50.772879
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test getstate() when the regex has not yet been compiled.

    This will test that we preserve the arguments for re.compile()
    """
    lr = LazyRegex(args=('abc',), kwargs=dict(IGNORECASE=True))
    state = lr.__getstate__()
    if state != {'args': ('abc',), 'kwargs': {'IGNORECASE': True}}:
        raise AssertionError(
            "expected {'args': ('abc',), 'kwargs': {'IGNORECASE': True}}"
            "got %r" % (state,))
    return True


# Generated at 2022-06-24 02:43:55.097969
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('msg')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. msg'
    else:
        raise AssertionError('did not catch expected exception.')
    try:
        raise InvalidPattern('msg')
    except InvalidPattern as e:
        assert unicode(e) == u'Invalid pattern(s) found. msg'
    else:
        raise AssertionError('did not catch expected exception.')

# Generated at 2022-06-24 02:44:00.976196
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile() restores the original re.compile function."""
    install_lazy_compile()
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("Failed to reset re.compile() back to original")
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("reset_compile() failed when called twice")

# Generated at 2022-06-24 02:44:04.632894
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should work as normal after _compile_and_collapse

    Bug #380317 <https://bugs.launchpad.net/bzr/+bug/380317> reports that
    LazyRegex.__getattr__ fails to work as expected after _compile_and_collapse.
    This test ensures that the attribute fetched is the same.
    """
    regex = lazy_compile('foo')
    regex._compile_and_collapse()

    # Check that any attribute of the object can be fetched
    for attr in dir(regex._real_regex):
        # _real_regex isn't accessible directly
        if not attr.startswith('_'):
            getattr(regex, attr)



# Generated at 2022-06-24 02:44:16.177644
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    e = InvalidPattern(u'foo')
    # 1. __str__ falls back to _format
    # 1.1 _format falls back to __repr__
    assert str(e) == "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    # 1.2 _format fall back to _get_format_string and
    # 1.2.1 __get_format_string returns None
    fmt = "Invalid pattern(s) found. %(msg)s"
    e._fmt = fmt
    assert str(e) == u"Unprintable exception InvalidPattern: dict={}, fmt=%r, error=None" % fmt
    # 1.2.2 __get_format_string returns fmt


# Generated at 2022-06-24 02:44:27.415697
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import _get_valid_encoding

    class InvalidPatternTest(InvalidPattern):
        _fmt = 'Format %(format)s'

    old_gettext = gettext

# Generated at 2022-06-24 02:44:30.312417
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern"""
    exc = InvalidPattern('Unknown error')
    assert repr(exc) == "InvalidPattern('Unknown error')"

# Generated at 2022-06-24 02:44:38.155818
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for the method __setstate__() of LazyRegex class
    
    This test adds a call to __setstate__() into __init__() method
    of LazyRegex class. This is used to test the code added in 
    __setstate__() method.
    """
    from bzrlib import tests
    def LazyRegex_with_setstate_test(object):
        """Class LazyRegex with a call to __setstate__() in __init__"""
        pass

    LazyRegex_with_setstate_test.__init__ = LazyRegex.__init__
    LazyRegex_with_setstate_test.__setstate__ = LazyRegex.__setstate__


# Generated at 2022-06-24 02:44:41.246858
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    pattern = re.compile(r'hello')
    assert isinstance(pattern, LazyRegex)
    reset_compile()
    pattern = re.compile(r'hello')
    assert not isinstance(pattern, LazyRegex)

# Generated at 2022-06-24 02:44:44.589217
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test that two InvalidPatterns are equal if they're created with the same
    parameters.
    """
    x = InvalidPattern('xyz')
    y = InvalidPattern('xyz')
    z = InvalidPattern('abc')
    assert (x == y)
    assert (x != z)
    assert (y != z)

# Generated at 2022-06-24 02:44:55.808863
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit-test for InvalidPattern.__eq__()

    This test will not pass if you change the code to not inherit from
    ValueError, because then InvalidPattern would loose all its attributes
    because of the special ValueError handling in Python.
    """
    from bzrlib.trace import mutter
    import doctest
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_errors import TestCaseWithTransport
    TestCase = doctest._normalize_module(TestCase)
    TestCaseWithTransport = doctest._normalize_module(TestCaseWithTransport)

    class TestInvalidPattern(TestCaseWithTransport):

        def test__eq__(self):
            i1 = InvalidPattern('foo')
            i2 = InvalidPattern('foo')

# Generated at 2022-06-24 02:44:57.967521
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    return doctest.DocFileSuite('../doc/developers/news-format.txt')

# Generated at 2022-06-24 02:45:04.610858
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test _getstate__ method of LazyRegex"""
    regex = LazyRegex(args=("^hello.*$",), kwargs={"flags": re.IGNORECASE})
    regex.__getstate__() # raises no exception



# Generated at 2022-06-24 02:45:07.631235
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    class DummyFormat(InvalidPattern):
        _fmt = 'dummy'

    e = DummyFormat('msg')
    assert str(e) == u'dummy'

# Generated at 2022-06-24 02:45:13.762530
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ of an InvalidPattern must be implemented and working"""
    def check_eq(message1, message2, expected):
        ip1 = InvalidPattern(message1)
        ip2 = InvalidPattern(message2)
        if (not ip1 == ip2) != expected:
            raise AssertionError('invalid result of InvalidPatterns comparison'
                                 'for message1="%s", message2="%s"' %
                                 (message1, message2))
    check_eq('a', 'b', False)
    check_eq('a', 'a', True)

# Generated at 2022-06-24 02:45:22.877398
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Check __repr__ of InvalidPattern"""
    # check basic string
    e = InvalidPattern('foo bar')
    assert str(e) == 'foo bar'
    assert repr(e) == "InvalidPattern('foo bar')"
    # check unicode
    e = InvalidPattern(u'foo \xe9')
    assert str(e) == 'foo \xc3\xa9'
    assert repr(e) == "InvalidPattern('foo \\xe9')"
    # check multiline string
    e = InvalidPattern('foo\nbar')
    assert str(e) == 'foo\nbar'
    assert repr(e) == "InvalidPattern('foo\\nbar')"
    # check repr escapes multiline string
    e = InvalidPattern('foo\nbar')

# Generated at 2022-06-24 02:45:29.315728
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """### Creation of a LazyRegex instance."""
    args = ("[a-z]+", )
    kwargs = {"flags": re.IGNORECASE}
    rx = LazyRegex(args, kwargs)
    assert rx._real_regex is None, "Instance should not have compiled."
    assert rx._regex_args == args, "_regex_args was not stored."
    assert rx._regex_kwargs == kwargs, "_regex_kwargs was not stored."



# Generated at 2022-06-24 02:45:34.463493
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Make sure a LazyRegex is returned if re.compile is overridden"""
    try:
        install_lazy_compile()
        regex = re.compile('foo')
        reset_compile()
    except:
        reset_compile()
        raise
    if not isinstance(regex, LazyRegex):
        raise AssertionError("re.compile() did not return a LazyRegex")



# Generated at 2022-06-24 02:45:39.590417
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    pattern = LazyRegex(args=('pattern', ), kwargs={})
    pattern.__setstate__({'args': ('new_pattern', ), 'kwargs': {}})
    import pickle
    pattern_pickled = pickle.dumps(pattern)
    pattern_unpickled = pickle.loads(pattern_pickled)
    assert pattern_unpickled._regex_args == ('new_pattern', )

# Generated at 2022-06-24 02:45:48.597582
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for __unicode__ for InvalidPattern.

    This is to make sure that the unicode of an error message is correctly
    formatted by launching an exception of InvalidPattern with
    no preformatted message.
    """
    try:
        # Some long string to use as message
        msg = 'Invalid pattern: ".*[(\[{\<\|]"'
        # Launch an exception of InvalidPattern.
        raise InvalidPattern(msg)
    except InvalidPattern as error:
        # Format the error message.
        error_msg = str(error)
        # Check that the length of error message is correct.

# Generated at 2022-06-24 02:45:55.940377
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method LazyRegex.__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, it should compile it.
    """
    lre = LazyRegex(args=('^', ), kwargs={})
    import re
    assert isinstance(lre, LazyRegex)
    assert isinstance(re.compile('^'), LazyRegex)
    assert lre.__getattr__('pattern') == '^'
    assert lre.pattern == '^'
    assert re.compile('^').pattern == '^'
    assert re.compile('^').match('a') == None
    assert re.compile('a').match('a') != None
    assert re.compile('a', flags=re.IGNORECASE).match('A') != None

# Generated at 2022-06-24 02:46:07.306809
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import trace

    def _test(self, kwargs, unicode_encoding='utf8', ascii_encoding='ascii',
              expect=None):
        self.assertEqual(expect, unicode(InvalidPattern(**kwargs)))
        self.assertIsInstance(unicode(InvalidPattern(**kwargs)), unicode)
        self.assertEqual(expect,
            unicode(InvalidPattern(**kwargs), unicode_encoding))
        self.assertIsInstance(
            unicode(InvalidPattern(**kwargs), unicode_encoding), unicode)
        self.assertEqual(expect.encode(ascii_encoding),
            str(InvalidPattern(**kwargs)))

# Generated at 2022-06-24 02:46:16.557516
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    from bzrlib import tests
    from sys import version_info
    if version_info < (2, 7):
        raise tests.TestSkipped("LazyRegex '__getstate__' is Python 2.7+ feature")
    lr = LazyRegex()
    pickled_lr = lr.__getstate__()
    lr = LazyRegex(*pickled_lr["args"], **pickled_lr["kwargs"])
    pickled_lr = lr.__getstate__()
    lr = LazyRegex(**{'args': pickled_lr["args"], 'kwargs': pickled_lr["kwargs"]})
    pickled_lr = lr.__getstate__()

# Generated at 2022-06-24 02:46:27.955816
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test that LazyRegex.__setstate__ works correctly in normal cases."""
    obj = LazyRegex(["A"], {"flags": re.IGNORECASE})
    obj.__setstate__({'args': [r'^\s*(\d{1,3})[ \t]*(#.*)?$',],
                      'kwargs': {'flags': re.IGNORECASE}})
    assert(obj._regex_args == [r'^\s*(\d{1,3})[ \t]*(#.*)?$',])
    assert(obj._regex_kwargs == {'flags': re.IGNORECASE})



# Generated at 2022-06-24 02:46:39.935030
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the LazyRegex class"""
    test_regex = lazy_compile("([0-9]+)")
    import gc
    gc.collect()
    # It should not be compiled yet
    gc.collect()
    try:
        test_regex.groups
        raise Exception("Regex should not be compiled yet")
    except AttributeError:
        pass
    # Test that an attribute error will be raised if we use an illegal regex
    try:
        test_regex = lazy_compile("(")
        raise Exception("Should have got an error for invalid regex")
    except InvalidPattern as e:
        pass

    # Once we use it, it should be compiled
    m = test_regex.match("abc123def")
    gc.collect()
    gc.collect()

# Generated at 2022-06-24 02:46:51.538741
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Check that InvalidPattern.__eq__() returns the expected result.

    """
    e1 = InvalidPattern('msg1')
    e2 = InvalidPattern('msg2')
    e3 = InvalidPattern('msg1')
    e4 = Exception('msg1')

    # Different class
    if e1.__eq__(e4):
        raise AssertionError('%s.__eq__(%s) should return False' %
                            (e1.__class__.__name__, e4.__class__.__name__))
    # Different message
    if e1.__eq__(e2):
        raise AssertionError('%s.__eq__(%s) should return False' %
                            (e1.__class__.__name__, e2.__class__.__name__))
    #

# Generated at 2022-06-24 02:46:56.494928
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex can be constructed, and then compiled."""
    rx = LazyRegex(args=['foo', re.IGNORECASE])
    import bzrlib.trace
    bzrlib.trace._log_memory()
    rx.findall('foobar')
    bzrlib.trace._log_memory()

# Generated at 2022-06-24 02:47:04.770445
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    lr = LazyRegex(args=('foo',), kwargs={'flags': re.I})
    bad_lr = LazyRegex(args=('?',), kwargs={'flags': re.I})
    assert lr._real_regex is None
    assert lr._regex_args == ('foo',)
    assert lr._regex_kwargs == {'flags': re.I}
    # Make sure that pickling succeeds
    pickled_lr = pickle.dumps(lr)
    restored_lr = pickle.loads(pickled_lr)
    assert restored_lr._real_regex is None
    assert restored_lr._regex_args == ('foo',)
    assert restored_lr._regex_kwargs == {'flags': re.I}


# Generated at 2022-06-24 02:47:09.624704
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():

    for msg in [None, '', ' ', '   ']:
        try:
            raise InvalidPattern(msg)
        except InvalidPattern as e:
            assert e.msg == msg


test_suite = 'test_regex_lazy'

# Generated at 2022-06-24 02:47:15.546799
# Unit test for function lazy_compile
def test_lazy_compile():
    compile = re.compile
    re.compile = lazy_compile

    empty_lazy_re = compile("")
    assert(empty_lazy_re is not None)

    re.compile = compile
    old_compile = compile
    re.compile = lazy_compile

    assert_raises(InvalidPattern, compile, "[")
    assert_raises(InvalidPattern, compile, "[")

    # Install the old behavior
    re.compile = old_compile



# Generated at 2022-06-24 02:47:21.742440
# Unit test for function finditer_public
def test_finditer_public():
    # re.compile has been replaced with LazyRegex object
    install_lazy_compile()
    try:
        # assert not raises:
        re.finditer("d", "da do")
        re.finditer("d", "da do", re.I)
    finally:
        # restore re.compile
        reset_compile()
        re.finditer()

# Generated at 2022-06-24 02:47:27.300596
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    re.compile = lazy_compile
    regex = re.compile('abc')
    assert regex is not None
    assert not 'findall' in vars(regex)
    assert regex.findall('abc') == ['abc']
    assert 'findall' in vars(regex)



# Generated at 2022-06-24 02:47:31.451270
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test LazyRegex.__getstate__."""
    lr = re.compile('abc')
    state = lr.__getstate__()
    if state["args"] != ('abc',) or state["kwargs"] != { }:
        return False
    return True


# Generated at 2022-06-24 02:47:37.124413
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """
    >>> lazy_regex = LazyRegex(('a',), {})
    >>> assert(lazy_regex._real_regex == None)
    >>> assert(lazy_regex._regex_args == ('a',))
    >>> assert(lazy_regex._regex_kwargs == {})
    """


# Generated at 2022-06-24 02:47:46.923684
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ of class LazyRegex should return a member from the proxied regex object.

    Test for https://bugs.launchpad.net/bzr/+bug/393491
    The problem was that the class LazyRegex was not returning the match built-in method,
    instead it was returning <bound method LazyRegex.__getattr__ of <bzrlib.lazy_re._lazy_re.LazyRegex object at 0x7f34ec951cd0>>.
    """

    proxy_regex = re.compile(r'[A-Z][a-z]*')
    match = proxy_regex.match('ABCDE')
    m = match.group()
    print(m)

# Install default proxy object
install_lazy_compile()

# Generated at 2022-06-24 02:47:59.042832
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    def check_repr(expected, error_class, args, kwargs={}):
        got = repr(error_class(*args, **kwargs))
        if got != expected:
            raise AssertionError('%r != %r' % (expected, got))
    check_repr('InvalidPattern()', InvalidPattern, [])
    check_repr('InvalidPattern(Branch name has to start with alphabetic '
               'character.)', InvalidPattern, ['Branch name has to start with '
               'alphabetic character.'])
    check_repr('InvalidPattern(Branch name has to start with alphabetic '
               'character., value=\'\')', InvalidPattern,
               ['Branch name has to start with alphabetic character.'],
               {'value': ""})

# Generated at 2022-06-24 02:48:06.700474
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern"""

    # __eq__ compares all the attributes
    class A(InvalidPattern):
        _fmt = 'Error: %(msg)s'

    a1 = A('a1')
    a2 = A('a2')
    a3 = A('a1')
    a4 = A('a1')
    a4.x = 1
    a5 = A('a1')
    a5._fmt = 'Foo: %(msg)s'
    a6 = A('a1')
    a6._preformatted_string = 'Bar'

    # Equal
    assert a1 == a1
    assert a3 == a3
    assert a3 == a1
    assert a3 == a4

    # Not equal, because of different messages
    assert a1 != a

# Generated at 2022-06-24 02:48:12.721674
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ is called by the pickle module."""
    self = LazyRegex()
    self.__setstate__({'args': ('aaa',), 'kwargs': {'aaa': 'bbb'}})
    self.__getattr__('findall')
    # Now we call the method __getattr__ to set the real_regex (the
    # attribute _real_regex has not been set before).
    self.__setstate__({'args': ('aaa2',), 'kwargs': {'aaa': 'bbb2'}})
    self.__getattr__('findall')



# Generated at 2022-06-24 02:48:23.104765
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import install_gettext_translations

    class DummyTransUnit(object):

        def gettext(self, string, *args):
            return string

        def ugettext(self, string, *args):
            return string

    def test(expected_str, expected_unicode, fmt):
        exception = InvalidPattern(fmt)
        s = str(exception)
        u = unicode(exception)
        if s != expected_str:
            raise AssertionError(
                'Got "%s" instead of "%s" for output of str(InvalidPattern)' %
                (s, expected_str))

# Generated at 2022-06-24 02:48:28.398440
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # re.compile calls LazyRegex
    from bzrlib.tests.test_regex import TestLazyRegex

    # re.compile returns LazyRegex
    TestLazyRegex.test_install_lazy_compile()

    # remove LazyRegex function install_lazy_compile
    reset_compile()

# Generated at 2022-06-24 02:48:31.441154
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    n1 = InvalidPattern("error1")
    n2 = InvalidPattern("error2")
    n3 = InvalidPattern("error1")
    assert n1 != n2
    assert n1 == n3


# Generated at 2022-06-24 02:48:35.025989
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    try:
        # This is a bit of a black box test, we don't really care what happens
        # just that it works.
        re.compile("^")
    finally:
        reset_compile()



# Generated at 2022-06-24 02:48:44.926731
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ returns the data necessary for
    pickling.
    """
    regex = LazyRegex(['regular expression', re.IGNORECASE])
    try:
        1 / 0 # Force an exception.
    except:
        regex._regex_args = 'file.cc:50: error: something'
        regex._regex_kwargs = {'key': 'value'}
        regex.error = SyntaxError('dummy')
        state = regex.__getstate__()
    else:
        raise AssertionError('lazy_compile_test.test_LazyRegex___getstate__'
                             ' failed.')

# Generated at 2022-06-24 02:48:55.779728
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    def test_pickleable(r):
        assert isinstance(r, LazyRegex)
        assert isinstance(pickle.loads(pickle.dumps(r)), LazyRegex)
    test_pickleable(LazyRegex('a'))
    test_pickleable(LazyRegex('a', re.I))
    test_pickleable(LazyRegex('a', re.L))
    test_pickleable(LazyRegex('a', re.M))
    test_pickleable(LazyRegex('a', re.S))
    test_pickleable(LazyRegex('a', re.U))
    test_pickleable(LazyRegex('a', re.X))

# Generated at 2022-06-24 02:48:56.497634
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    obj = LazyRegex()

# Generated at 2022-06-24 02:49:01.037893
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Testing method LazyRegex.__getstate__"""
    lr = LazyRegex(args=("abc",), kwargs={'re.IGNORECASE': True})
    state = lr.__getstate__()
    assert state == {
        "args": ("abc",),
        "kwargs": {'re.IGNORECASE': True},
        }

# Generated at 2022-06-24 02:49:08.254967
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    a_lazy_regex = LazyRegex()
    a_lazy_regex.__setstate__({'args':["pattern"], 'kwargs':{}})
    assert a_lazy_regex._real_regex is None
    assert a_lazy_regex._regex_args == ["pattern"]
    assert a_lazy_regex._regex_kwargs == {}

# Generated at 2022-06-24 02:49:15.129555
# Unit test for function lazy_compile
def test_lazy_compile():
    # Ensure it fails if given invalid regex
    for bad in ['', '*', 'a]', 'a[', '[]', '[', ']']:
        try:
            re.compile(bad)
        except InvalidPattern:
            pass
        else:
            raise AssertionError('%r should have failed' % (bad,))

    # Ensure it fails if given invalid flags
    import sys
    if sys.version_info[1] < 5:
        try:
            re.compile('a', -1)
        except InvalidPattern:
            pass
        else:
            raise AssertionError('%r should have failed' % (bad,))
        try:
            re.compile('a', re.I, re.I)
        except ValueError:
            pass

# Generated at 2022-06-24 02:49:22.392651
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a valid Python expression"""
    msg = u"Invalid pattern(s) found. 'das'  "
    e = InvalidPattern(msg)
    repr = unicode(e)
    if repr[0] != '<' or repr[-1] != '>':
        raise AssertionError("InvalidPattern.__repr__ should return a "
                                 "valid python expression")

# Generated at 2022-06-24 02:49:30.047112
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy  compile works as expected."""
    install_lazy_compile()

# Generated at 2022-06-24 02:49:42.830078
# Unit test for function finditer_public

# Generated at 2022-06-24 02:49:49.886174
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a str object.

    This was a bug on Py2 and Py3. The method __unicode__ returns a
    unicode object, not a str object. So, the repr of an InvalidPattern
    object contains a unicode object, which is not a str.
    """
    e = InvalidPattern("msg")
    assert isinstance(repr(e), str)

# Generated at 2022-06-24 02:49:56.518539
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()
    try:
        import re as r
        install_lazy_compile()
        if r.compile is not lazy_compile:
            raise AssertionError("re.compile should be the same as lazy_compile")
        reset_compile()
        if r.compile is lazy_compile:
            raise AssertionError("re.compile should be the same as _real_re_compile")
    finally:
        reset_compile()

# Generated at 2022-06-24 02:50:01.497592
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    exc = InvalidPattern('my msg')
    # create identical object
    exc2 = InvalidPattern('my msg')
    # test identical
    assert exc == exc2
    # create non-identical object
    exc3 = InvalidPattern('my msg2')
    # test non-identical
    assert exc != exc3

# Generated at 2022-06-24 02:50:10.714697
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    def check(args, kwargs, expected_msg):
        err = InvalidPattern(args, kwargs)
        if err.msg != expected_msg:
            raise AssertionError('%r.msg == %r != %r' % (err, err.msg,
                                                        expected_msg))
    check('a%(b)s', dict(b=1), 'a1')
    check('a%s', ('b',), 'ab')
    check('', (), '')
    check('a%(b)s %(c)s', dict(c='c'))
    check('', (), '', dict(a='a'))

# Generated at 2022-06-24 02:50:22.264633
# Unit test for function finditer_public
def test_finditer_public():
    """Check that finditer_public can handle LazyRegex, and return
    an iterator for the iterable.
    """
    # Test with a LazyRegex
    x = lazy_compile("a.*z")
    assert isinstance(x, LazyRegex)
    x_finditer = finditer_public(x, "abcdez")
    assert isinstance(x_finditer, re._pattern_type), \
           "finditer_public should have returned an iterator"
    # Test with a string
    y = "a.*z"
    assert not isinstance(y, LazyRegex)
    y_finditer = finditer_public(y, "abcdez")
    assert isinstance(y_finditer, re._pattern_type), \
           "finditer_public should have returned an iterator"

# Generated at 2022-06-24 02:50:24.719943
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ must return the arguments of the regex"""
    l = LazyRegex(('^foo ', False))
    state = l.__getstate__()
    assert state["args"] == ('^foo ', False)
    assert state["kwargs"] == {}

# Generated at 2022-06-24 02:50:35.424834
# Unit test for function finditer_public
def test_finditer_public():
    r = re.compile("a")
    # re.finditer works without problem by default
    assert isinstance(re.finditer(r, "a"), type(r.finditer("")))
    assert isinstance(re.finditer(r, "aa"), type(r.finditer("")))
    assert isinstance(re.finditer(r, "ab"), type(r.finditer("")))

    # re.finditer works well with a LazyRegex
    lr = LazyRegex((r,))
    assert isinstance(re.finditer(lr, "a"), type(lr.finditer("")))
    assert isinstance(re.finditer(lr, "aa"), type(lr.finditer("")))

# Generated at 2022-06-24 02:50:44.565520
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test if LazyRegex implements the method __getattr__ correctly."""
    from bzrlib.tests import TestCase
    lz = LazyRegex([], {})
    t = TestCase()
    t.assertEqual(lz.__getattr__('_real_regex'), None)
    lz._real_regex = 1
    t.assertEqual(lz.__getattr__('_real_regex'), 1)
    lz._real_regex = None
    t.assertRaises(AttributeError, lz.__getattr__, '_real_regex')



# Generated at 2022-06-24 02:50:55.884019
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string representation at least
    containing the exception message.

    For example, a message like 'No closing parenthesis' should be included
    in the string representation.
    """
    # Enable i18n
    from bzrlib import i18n
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_translations_factory
    set_translations_factory(i18n._translations_factory)
    try:
        from bzrlib.i18n import _i18n_init_bzrlib
        _i18n_init_bzrlib()
    except ImportError:
        # Silently ignore it.
        pass
    # Test InvalidPattern

# Generated at 2022-06-24 02:50:58.209162
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ of InvalidPattern should return a string"""
    err = InvalidPattern("foo")
    assert isinstance(repr(err), basestring)

# Generated at 2022-06-24 02:51:02.101983
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    r = re.compile('^(echo)')
    r._real_regex is None
    r.search('echo')
    r._real_regex is not None


# Generated at 2022-06-24 02:51:04.959696
# Unit test for function reset_compile
def test_reset_compile():
    """Test for function reset_compile"""
    install_lazy_compile()
    install_lazy_compile()
    reset_compile()
    reset_compile()


# Test for the LazyRegex type

# Generated at 2022-06-24 02:51:14.951123
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests if InvalidPattern.__unicode__ returns a 'unicode' string

    If the original exception had a preformatted message, then it will return
    a 'unicode' string. Otherwise it will return a string and try to convert
    it to a 'unicode' string using the default encoding.
    """
    ip = InvalidPattern('just a message')
    assert isinstance(ip.__unicode__(), unicode), \
                        "__unicode__ did not return a 'unicode' string"
    ip._preformatted_string = 'just a message'
    assert isinstance(ip.__unicode__(), unicode), \
                        "__unicode__ did not return a 'unicode' string"

# Generated at 2022-06-24 02:51:27.123298
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    try:
        re.compile('')
    except TypeError:
        re_compile_no_kwargs = False
    else:
        re_compile_no_kwargs = True
    try:
        re.compile('', '')
    except TypeError:
        re_compile_no_flags = False
    else:
        re_compile_no_flags = True
    try:
        re.compile('', flags='')
    except TypeError:
        re_compile_flags = False
    else:
        re_compile_flags = True

    if re_compile_flags:
        # Test case 1
        lazy_re = LazyRegex('abc', flags='s')

# Generated at 2022-06-24 02:51:36.997386
# Unit test for function finditer_public
def test_finditer_public():
    if not getattr(re, 'finditer', False):
        # there is no public finditer available
        return
    re.compile = _real_re_compile
    text = 'hello world'
    m = re.match('hello\s(.*)', text)
    m2 = re.finditer('hello\s(.*)', text).next()
    eq = m.group(1) == m2.group(1)
    re.compile = lazy_compile
    m3 = re.match('hello\s(.*)', text)
    eq = eq and m.group(1) == m3.group(1)
    m4 = re.finditer('hello\s(.*)', text).next()
    eq = eq and m.group(1) == m4.group(1)

# Generated at 2022-06-24 02:51:45.942616
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() returns dict with args and kwargs"""
    regex = LazyRegex(('foo',), {'flags':re.IGNORECASE})
    state = regex.__getstate__()
    expected_state = dict(args=('foo',), kwargs={'flags':re.IGNORECASE})
    # assertEqual doesn't give good feedback on mismatches in dicts
    # so we do the comparison ourselves.
    if not dict_equals(state, expected_state):
        raise AssertionError("Regex __getstate__ returned unexpected result."
                             " Expected: %r, got %r" % (expected_state, state))



# Generated at 2022-06-24 02:51:56.864467
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    import bzrlib.lazy_regex
    real_re_compile = bzrlib.lazy_regex._real_re_compile
    bzrlib.lazy_regex._real_re_compile = lambda *args, **kwargs: "42"
    lazy_regex = bzrlib.lazy_regex.LazyRegex(["1"])
    assert lazy_regex.foo() == "42"
    bzrlib.lazy_regex._real_re_compile = real_re_compile

# We could also add a method to LazyRegex for finditer, but I think the
# method in re is probably going to be the most efficient way to do it.
# But I don't want

# Generated at 2022-06-24 02:52:02.423178
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object, not a str object."""
    class InvalidPattern_example(InvalidPattern):
        """Example subclass of InvalidPattern"""
        _fmt = ('Test message %(msg)s')
    ip = InvalidPattern_example("example message")
    u = unicode(ip)
    assert isinstance(u, unicode)
    assert not isinstance(u, str)


# Generated at 2022-06-24 02:52:13.298447
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.osutils import get_user_encoding
    from bzrlib.tests import (
        TestSkipped,
        )
    try:
        import locale
        locale.setlocale(locale.LC_ALL, '')
    except Exception:
        raise TestSkipped('Cannot use locale module')
    try:
        get_user_encoding(for_subprocess=True)
    except ValueError:
        raise TestSkipped('Cannot get user encoding')
    old_gettext = gettext

# Generated at 2022-06-24 02:52:18.112388
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern

    Test that the output of __unicode__ is a unicode string.
    """
    e = InvalidPattern('test')
    assert isinstance(unicode(e), unicode)
    # add a preformatted message
    e._preformatted_string = unicode('test')
    assert isinstance(unicode(e), unicode)


# Generated at 2022-06-24 02:52:28.472028
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex."""
    import doctest
    from bzrlib.tests import TestCase
    from bzrlib import trace

    trace.disable_verbose_warning_registry()

    from bzrlib.tests import test_regex_py, test_regex_py3

    tests = (test_regex_py, test_regex_py3)
    if test_regex_py3 is None:
        tests = (test_regex_py,)

    suite = lambda: doctest.DocTestSuite(test_regex_py,
        optionflags=doctest.ELLIPSIS|doctest.NORMALIZE_WHITESPACE)
    TestCase.load_tests(tests, suite,
                        lambda name: LazyRegex((name,)))

# Generated at 2022-06-24 02:52:35.087224
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that access to methods of LazyRegex proxy objects works correctly.
    """
    import doctest
    try:
        from bzrlib import doctest_compile
    except ImportError:
        doctest_compile = re.compile
    doctest.testmod(doctest_compile)

# Generated at 2022-06-24 02:52:42.991666
# Unit test for function reset_compile
def test_reset_compile():
    """For the reset_compile routine"""
    original_re_compile = _real_re_compile
    # The string '^[az]' should match the string 'az'
    assert _real_re_compile('^[az]').match('az')
    install_lazy_compile()
    # The string '^[az]' should match the string 'az'
    assert re.compile('^[az]').match('az')
    reset_compile()
    # The string '^[az]' should match the string 'az'
    assert _real_re_compile('^[az]').match('az')
    # re.compile should be the same as the original _real_re_compile
    assert re.compile is original_re_compile

    # ensure that install_lazy_compile can

# Generated at 2022-06-24 02:52:52.016470
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method LazyRegex.__getstate__"""
    lr = LazyRegex({'a':1}, {'b':2})
    state = lr.__getstate__()
    expected = {
        "args": ({'a':1},),
        "kwargs": {'b':2},
        }
    assert state == expected, \
           "Unexpected state: %r expected: %r" % (state, expected)


# Generated at 2022-06-24 02:52:58.837087
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that __getattr__ works as expected by checking that the LazyRegex
    proxy forwards all attributes to the actual regex.
    """
    # Setup an LazyRegex proxy around a real regex
    str1 = "this is a test"
    str2 = "this is a test"
    p = re.compile(r'\b\w+\b')
    p = LazyRegex([p.pattern, p.flags])
    p._real_regex = p.compile(str1)
    # This should not raise an exception
    p.match(str2)

# Generated at 2022-06-24 02:53:05.596430
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test restores from a pickled state."""
    pattern = LazyRegex(args=('pattern',), kwargs={'flags': 0})
    pattern.__setstate__(
        {'args': ('pattern',), 'kwargs': {'flags': 0}})
    assert pattern._regex_args == ('pattern',)
    assert pattern._regex_kwargs == {'flags': 0}


# Generated at 2022-06-24 02:53:08.228812
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('test')
    except InvalidPattern as e:
        assert e.__str__() == 'invalid pattern(s) found. test'
