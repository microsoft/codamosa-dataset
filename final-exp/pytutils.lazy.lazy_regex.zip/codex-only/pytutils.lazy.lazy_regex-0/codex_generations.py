

# Generated at 2022-06-24 02:43:17.771572
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('%s')
    except InvalidPattern as e:
        # Override the expected message with a string containing a
        # unicode character.
        e.msg = u'\u041f\u0440\u0438\u0432\u0435\u0442'
        s = str(e)
        u = unicode(e)
        assert s == 'Invalid pattern(s) found. \xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
        assert u == u'Invalid pattern(s) found. \u041f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-24 02:43:22.021395
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    _test_InvalidPattern = InvalidPattern("some message")

    assert repr(_test_InvalidPattern) == "InvalidPattern('some message')"



# Generated at 2022-06-24 02:43:26.670082
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import doctest
    install_lazy_compile()
    try:
        doctest.testmod(sys.modules[__name__])
    finally:
        reset_compile()



# Generated at 2022-06-24 02:43:29.329351
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test to verify that method __str__ works correctly"""
    try:
        raise InvalidPattern('msg')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. msg'

# Generated at 2022-06-24 02:43:33.798506
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import doctest
    doctest.testmod()
# test_InvalidPattern___eq__()

# Generated at 2022-06-24 02:43:36.456560
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__() of InvalidPattern have to return a str."""
    class TestException(InvalidPattern):
        """Sample exception class."""

    e = TestException('some message')
    assert isinstance(e.__repr__(), str)

# Generated at 2022-06-24 02:43:42.370329
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ should return a dictionary."""
    from six import PY3
    if PY3:
        # ignore the test with Python 3, the encoding
        # used in the dictionary returned by __getstate__ is
        # not a str but a bytes object.
        return
    
    proxy_object = LazyRegex(args=('foo',), kwargs={'flags': re.RE})
    state = proxy_object.__getstate__()
    assert(isinstance(state, dict)), \
           'LazyRegex.__getstate__ should return a dictionary.'
    assert(len(state) == 2), \
           'The dictionary returned by LazyRegex.__getstate__ should \
           have 2 entries.'



# Generated at 2022-06-24 02:43:43.690812
# Unit test for function reset_compile
def test_reset_compile():
    reset_compile()


# Generated at 2022-06-24 02:43:53.898268
# Unit test for function lazy_compile
def test_lazy_compile():
    "lazy_compile should work"
    bad_regex = '\\'
    import bzrlib.tests
    bzrlib.tests.compile_regex(bad_regex, InvalidPattern)
    bzrlib.tests.compile_regex(bad_regex, InvalidPattern,
                               flags=re.IGNORECASE)
    # test that _get_format_string is used
    try:
        lazy_regex = re.compile(r'(?P<%s>foo)')
    except InvalidPattern as e:
        if str(e) != 'Invalid pattern(s) found. "\\\\(?P\\\\<%s\\\\>foo)" ' \
                   'unbalanced parenthesis':
            raise AssertionError('InvalidPattern raised with wrong message')
    else:
        raise Assert

# Generated at 2022-06-24 02:43:57.196096
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that re.compile returns LazyRegex objects."""
    install_lazy_compile()
    r = re.compile("a(.*)c")
    assert isinstance(r, LazyRegex)

# Generated at 2022-06-24 02:44:07.326909
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import pickle
    LazyRegex()
    LazyRegex(['a'])
    LazyRegex(['a'], {'flags': 0})
    LazyRegex(['a'], {'flags': 0}, {})

    # Check that __getstate__ returns the right things
    lr = LazyRegex(['a'], {'flags': 0})
    state = lr.__getstate__()
    assert state["args"] == (['a'],)
    assert state["kwargs"] == {'flags': 0}

    # Check that __setstate__ works
    lr.__setstate__(state)
    assert getattr(lr, "_regex_args") == (['a'],)
    assert getattr(lr, "_regex_kwargs") == {'flags': 0}

   

# Generated at 2022-06-24 02:44:12.886622
# Unit test for function reset_compile
def test_reset_compile():
    class SReSub(object):
        """XXX: python re raises TypeError instead of error in group(s)"""
    re.sub = SReSub
    reset_compile()
    re.compile('a')

# Generated at 2022-06-24 02:44:21.487834
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test construction of LazyRegex()"""

    import pickle

    regex = LazyRegex((r'.*', 5), {'b': 'c'})
    assert regex._regex_args == (r'.*', 5)
    assert regex._regex_kwargs == {'b': 'c'}

    # Check that the _real_regex is None
    assert regex._real_regex is None

    # Check that __getstate__ works.
    s = pickle.dumps(regex)
    r = pickle.loads(s)
    assert r._regex_args == (r'.*', 5)
    assert r._regex_kwargs == {'b': 'c'}
    assert r._real_regex is None

    # Check that the lazy regex is actually lazy

# Generated at 2022-06-24 02:44:29.369603
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    # if method __setstate__ it is not properly implemented
    # pickle will fail with AttributeError: 'LazyRegex' object has no attribute
    # '_real_regex'
    import pickle
    import cStringIO
    f = cStringIO.StringIO()
    pickle.dump(LazyRegex((), {}), f)


# Module initialization
# install_lazy_compile()

# Generated at 2022-06-24 02:44:33.967700
# Unit test for function reset_compile
def test_reset_compile():
    compile_value = re.compile
    install_lazy_compile()
    re.reset_compile()
    if re.compile is not compile_value:
        raise AssertionError('reset_compile() did not restore' \
                             ' the compile value correctly')

# Generated at 2022-06-24 02:44:43.537332
# Unit test for function lazy_compile
def test_lazy_compile():
    compile = re.compile

# Generated at 2022-06-24 02:44:54.936768
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    # On creation, the _real_regex should not exist.
    regex = LazyRegex(('abc',), {})
    dict = regex.__getstate__()
    # After the call, the _real_regex still should not exist.
    assert_equals('abc', dict['args'][0])
    assert_true(dict['kwargs'] == {})
    dict['args'][0] = '123'
    # The dict obtained by the call of __getstate__ should not be
    # affected by other changes on the object.
    assert_equals('abc', regex._regex_args[0])



# Generated at 2022-06-24 02:45:02.101583
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Assert that the state of a LazyRegex can be serialized.
    """
    import pickle

    regex = LazyRegex(args=('a',))
    state = regex.__getstate__()
    unpickled_state = pickle.loads(pickle.dumps(state))
    if state != unpickled_state:
        raise AssertionError(
            "unpickled state (%r) does not match state (%r)"
            % (unpickled_state, state))


# Generated at 2022-06-24 02:45:05.424453
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test for construction of InvalidPattern with msg."""
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert e.msg == 'foo'


# Generated at 2022-06-24 02:45:13.439464
# Unit test for function finditer_public
def test_finditer_public():
    # first check that finditer raise an exception 'AttributeError' if receives
    # as first argument a LazyRegex
    try:
        re.finditer(LazyRegex())
    except AttributeError:
        pass
    else:
        raise AssertionError('finditer should raise AttributeError'
                ' when received LazyRegex')
    # now check that finditer works correctly with a non LazyRegex
    match = re.finditer('b+', 'aba').next()
    assert match.group() == 'b'

# Generated at 2022-06-24 02:45:22.245848
# Unit test for function reset_compile
def test_reset_compile():
    import bzrlib.tests.blackbox as tests

    # Reset compile to guard against the test being a noop on
    # win32. This can happen if the test is imported and run from
    # another test.
    reset_compile()

    # Install the lazy compile, and reset to the real one, and
    # check that it all works as expected.
    install_lazy_compile()
    reset_compile()
    tests.run_bzr_subprocess('version')

# Generated at 2022-06-24 02:45:30.764604
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__"""
    import bzrlib.i18n
    # test_InvalidPattern___repr__.test_InvalidPattern___repr__.test_gettext:
    # gettext.install('bzr', unicode=True)
    # UnicodeDecodeError: 'ascii' codec can't decode byte 0xc2 in position 5: ordinal not in range(128)
    # FIXME: http://bugs.python.org/issue6203

# Generated at 2022-06-24 02:45:40.145202
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test __eq__ of class InvalidPattern"""
    # Note: Python 2.4 does not have equality for exception classes,
    #       so we test with the objects themselves.
    myexception = InvalidPattern('foo')
    assert myexception == myexception
    sameexception = InvalidPattern('foo')
    assert myexception == sameexception
    assert not (myexception != sameexception)
    other_type_exception = ValueError('baz')
    assert not (myexception == other_type_exception)
    assert myexception != other_type_exception
    assert myexception != 'foo'
    assert not ('foo' == myexception)
    assert 'foo' != myexception
    assert myexception != 42
    assert 42 != myexception
    assert myexception._get_format_string

# Generated at 2022-06-24 02:45:44.471867
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Check all the constructor arguments are stored in the instance."""
    proxy_regex = LazyRegex(("a", ), {"b": 1, "c": 2})
    assert proxy_regex._regex_args == ("a", )
    assert proxy_regex._regex_kwargs == {"b": 1, "c": 2}

# Generated at 2022-06-24 02:45:49.572811
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests import TestSkipped
    t = InvalidPattern("test")
    try:
        repr(t)
    except UnicodeDecodeError:
        # test for bug #497267
        raise TestSkipped("bug #497267")
    foo = ""
    try:
        foo + u'\u2026'
    except UnicodeDecodeError:
        # test for bug #759611
        raise TestSkipped("bug #759611")

# Generated at 2022-06-24 02:46:01.007994
# Unit test for function lazy_compile
def test_lazy_compile():
    from bzrlib import tests
    import re

    def check_match_works(pattern):
        # Check that the regex actually works
        match_obj = pattern.match('test')
        if match_obj is not None:
            raise AssertionError()
        match_obj = pattern.match('pass')
        if match_obj is None:
            raise AssertionError()
        if match_obj.group(0) != 'pass':
            raise AssertionError()

    def check_compile_works(pattern):
        # Check that passing the proxy to compile works
        new_pattern = re.compile(pattern)
        # When compiled the pattern should no longer be a proxy
        if isinstance(new_pattern, LazyRegex):
            raise AssertionError()
        check_match_works(new_pattern)



# Generated at 2022-06-24 02:46:09.242176
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__() should compare the arguments passed to the
    constructor.
    """
    class SubInvalidPattern(InvalidPattern):
        _preformatted_string = 'foo'
    good_eq_exception = SubInvalidPattern('foo')
    bad_eq_exception = SubInvalidPattern('bar')
    assert good_eq_exception == good_eq_exception
    assert not good_eq_exception == bad_eq_exception
    assert good_eq_exception == SubInvalidPattern('foo')
    assert not good_eq_exception == SubInvalidPattern('bar')

# Generated at 2022-06-24 02:46:17.915946
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Tests for bug #71403

    The re module should accept lazy regexes.
    """
    install_lazy_compile()
    try:
        # Check that we can do re.compile()
        re.compile("(a|b)")
        # Check that we can pass a lazy regex to re.match
        m = re.match(lazy_compile("a"), "abc")
        m.group(0)
        # Check that we can pass a lazy regex to re.search
        m = re.search(lazy_compile("a"), "abc")
        m.group(0)
    finally:
        reset_compile()


if __name__ == "__main__":
    test_install_lazy_compile()

# Generated at 2022-06-24 02:46:27.955451
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import re
    try:
        re.compile(r'pattern')
    except re.error as e:
        # e is the re.error exception
        # Here we are checking that the InvalidPattern exception constructed
        # below has the same message as the original re.error exception.
        msg = str(e)
        try:
            re.compile(r'pattern')
        except InvalidPattern as f:
            assert f.msg == msg
        else:
            raise AssertionError("InvalidPattern exception not raised")
    else:
        raise AssertionError("re.error exception not raised")

# Generated at 2022-06-24 02:46:29.502107
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Check whether repr gives the right output"""
    i = InvalidPattern('Illegal format')
    assert repr(i) == "InvalidPattern('Illegal format')"

# Generated at 2022-06-24 02:46:39.024295
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    class TestInvalidPattern(InvalidPattern):
        _fmt = 'A unit test'
        def __init__(self, msg):
            self.msg = msg

    ip = TestInvalidPattern('a message')
    assert ip.__unicode__() == 'A unit test'
    ip._preformatted_string = 'preformatted'
    assert ip.__unicode__() == 'preformatted'
    try:
        raise TestInvalidPattern('a message')
    except TestInvalidPattern as e:
        ip = e
    assert ip.__unicode__() == "Unprintable exception TestInvalidPattern: "\
        "dict={'msg': 'a message'}, fmt='A unit test', "\
        "error=None"

# Generated at 2022-06-24 02:46:47.942065
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # test constructor
    regex = LazyRegex(("abc"))
    assert regex._real_regex == None
    assert regex._regex_args == ("abc", )
    assert regex._regex_kwargs == {}
    regex2 = LazyRegex(("abc", "IGNORECASE"), {"flags": re.LOCALE})
    assert regex2._real_regex == None
    assert regex2._regex_args == ("abc", "IGNORECASE")
    assert regex2._regex_kwargs == {"flags": re.LOCALE}

# Generated at 2022-06-24 02:46:50.560739
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod(re)

# Generated at 2022-06-24 02:46:55.285859
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """InvalidPattern should accept Unicode input"""
    try:
        raise InvalidPattern(
            u'This is a test message: \u20ac\u2022\u2026\u2020')
    except InvalidPattern as e:
        msg = str(e)
        assert msg.startswith('Invalid pattern(s) found. "This is a test message:')

# Generated at 2022-06-24 02:47:01.164599
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ calls the function on a compiled regex"""
    string = 'a b c'
    list = []
    def fake_match(self, string):
        list.append(string)
        return _real_re_compile('a').match(string)
    lr = LazyRegex(args=('a',))
    lr.match = fake_match
    lr.match(string)
    assert list == [string]



# Generated at 2022-06-24 02:47:02.293354
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    msg = 'dummy'
    obj1 = InvalidPattern(msg)
    obj2 = InvalidPattern(msg)
    assert(obj1 == obj2)



# Generated at 2022-06-24 02:47:13.730996
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # test a normal case
    ip = InvalidPattern('foo')
    assert str(ip) == "Invalid pattern(s) found. foo"
    # the most simple case
    ip = InvalidPattern('')
    assert str(ip) == "Invalid pattern(s) found. "
    # test a normal case with str and unicode in the message
    ip = InvalidPattern('foo "bar"')
    assert str(ip) == "Invalid pattern(s) found. foo \"bar\""
    # test a normal case with non-ascii characters in the message
    ip = InvalidPattern('föö')
    assert str(ip) == "Invalid pattern(s) found. föö"
    # a case with a non-ascii character in the message and with str and
    # unicode in the message

# Generated at 2022-06-24 02:47:20.090452
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern."""
    import testtools
    # Call the __repr__ method of the object
    invalid_pattern = InvalidPattern('Invalid pattern')
    invalid_pattern.__repr__()

# Generated at 2022-06-24 02:47:31.670585
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test of __str__ method of InvalidPattern class.
    """
    err = InvalidPattern('msg')
    assert str(err) == 'Invalid pattern(s) found. msg'
    assert repr(err) == "InvalidPattern('Invalid pattern(s) found. msg')"

    msg = u'test msg with umlauts: \xe4\xf6\xfc\xc4\xd6\xdc\xdf'
    err = InvalidPattern(msg)
    assert str(err) == 'Invalid pattern(s) found. test msg with umlauts: äöüÄÖÜß'
    assert repr(err) == ("InvalidPattern('Invalid pattern(s) found. test msg "
                         "with umlauts: \xe4\xf6\xfc\xc4\xd6\xdc\xdf')")

# Generated at 2022-06-24 02:47:35.834909
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex._real_regex must be created after first use"""
    re_lazy = LazyRegex(('abc',))
    re_lazy.findall('abc')
    assert re_lazy._real_regex

# Generated at 2022-06-24 02:47:45.827223
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test LazyRegex"""

    # LazyRegex should work even if we create a lazy re for a real re.
    p = LazyRegex(("a.*d", 0))
    real_re = p._real_re_compile("a.*d", 0)
    # The lazy re and the real re should match the same things
    assert p.search("abcd") == real_re.search("abcd")
    # The lazy re should still be a LazyRegex
    assert isinstance(p, LazyRegex)
    # The lazy re can be pickled and unpickled
    assert p == pickle.loads(pickle.dumps(p))


# Unit tests for method _compile_and_collapse of class LazyRegex

# Generated at 2022-06-24 02:47:48.747581
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    error = InvalidPattern('')
    assert isinstance(str(error), str)

# Generated at 2022-06-24 02:48:00.225262
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    try:
        # From module re
        raise InvalidPattern('pattern')
    except InvalidPattern as exc:
        eq = (exc == exc)
        ne = (exc != exc)
        assert eq and not ne
    try:
        # From module re
        raise InvalidPattern('pattern')
    except InvalidPattern as exc1:
        try:
            # From module re
            raise InvalidPattern('pattern')
        except InvalidPattern as exc2:
            eq = (exc1 == exc2)
            ne = (exc1 != exc2)
            assert eq and not ne

# Generated at 2022-06-24 02:48:05.448686
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should always return a 'str' object."""
    def get_str_type():
        return str('some string')

    orig_str_type = get_str_type()
    # This should never raise any exception
    InvalidPattern('some message')
    after_str_type = get_str_type()
    if orig_str_type != after_str_type:
        raise AssertionError('%r != %r' % (orig_str_type, after_str_type))

# Generated at 2022-06-24 02:48:06.577422
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:48:16.573659
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ method of LazyRegex should return the right attribute"""
    r1 = re.compile('bzr')
    r2 = LazyRegex()._real_regex
    # They should have the same attributes
    attributes = ['__copy__', '__deepcopy__', 'findall', 'finditer', 'match',
                  'scanner', 'search', 'split', 'sub', 'subn']
    for attr in attributes:
        a1 = getattr(r1, attr)
        a2 = getattr(r2, attr)
        if a1 != a2:
            return False
    return True



# Generated at 2022-06-24 02:48:25.869325
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    # When __setstate__ is called on a LazyRegex object, it should set the
    # "args" and "kwargs" arguments of the object to the values of the
    # "args" and "kwargs" keys of the "dict" argument.
    args = ("a",)
    kwargs = {"b": 1}
    state_dict = {"args": args, "kwargs": kwargs}
    obj = LazyRegex()
    obj.__setstate__(state_dict)
    # Note that we used setattr() to set the "_regex_args" and
    # "_regex_kwargs" attributes of "obj", because the LazyRegex has no
    # __init__() method so it has no way of creating the "_regex_args" and
    # "_regex_kwargs" attributes.


# Generated at 2022-06-24 02:48:28.048932
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    assert repr(InvalidPattern('a')) == "InvalidPattern('a')"


# Generated at 2022-06-24 02:48:38.705857
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile implementation."""

    import re

    reset_compile()

    # Regular compile works
    re.compile('^a$')

    # Lazy compile doesn't
    lazy_compile('^a$')

    # If we install lazy_compile, it will work now
    install_lazy_compile()
    re.compile('^a$')

    # But it doesn't work if we don't install it
    reset_compile()

    try:
        re.compile('^a$')
    except TypeError as e:
        if str(e) != "re.compile() argument must be string or compiled pattern":
            raise e

# Generated at 2022-06-24 02:48:44.124411
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test constructor for class LazyRegex"""
    ls = LazyRegex('^\S+:$', re.M)
    assert ls._regex_args == ('^\S+:$', re.M)
    assert ls._regex_kwargs == {}
    assert ls._real_regex is None
    assert ls.pattern == '^\S+:$'
    assert ls.flags == re.M
    # make sure we did not override the original re.compile()
    assert _real_re_compile is not ls._real_re_compile



# Generated at 2022-06-24 02:48:51.134234
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests the method __str__ of class InvalidPattern"""
    # Strangely, py.test has not a fixture for this, even if it is a basic
    # fixture, so it is a test itself
    import locale
    try:
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error as e:
        # some test machines such as Launchpad buildd's don't have locales
        # configured so we skip when that occurs
        from bzrlib.tests import TestSkipped
        import warnings
        warnings.warn('Skipping test_InvalidPattern___str__ because of '
                      'unconfigured locales: %r' % (e,))
        raise TestSkipped('unconfigured locale')

# Generated at 2022-06-24 02:48:56.606395
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Tests for Invalid pattern"""

    # InvalidPattern can be instantiated with an error message
    e = InvalidPattern("Error message")
    # The error message is stored
    eq = "Invalid pattern(s) found. Error message"
    eq_(str(e), eq)

# vim:ai:et:sts=4:sw=4:tw=0:

# Generated at 2022-06-24 02:49:00.864292
# Unit test for function finditer_public
def test_finditer_public():
    """Test for function finditer_public"""
    re_string = r'ABC'
    string = '123ABCABCABCABC'
    flags = 0
    if not getattr(re, 'finditer', False):
        return
    assert finditer_public(re_string, string, flags) == re.finditer(re_string, string, flags)

# Generated at 2022-06-24 02:49:12.268334
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function.
    """
    global re
    import re as orig_re

    def restore_re():
        re = orig_re
    install_lazy_compile()

    # Test that no exception is thrown and that the compiled regex
    # is still matches.
    r = re.compile('a')
    restore_re()
    assert r.match('a')

    # Test that the regex is only compiled once.
    install_lazy_compile()
    r = re.compile('b')
    restore_re()
    assert r.match('b')
    assert r.match('b')

    # Test that an invalid pattern is caught
    install_lazy_compile()
    exc = None

# Generated at 2022-06-24 02:49:14.356544
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test repr() returns the expected string."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:49:21.359917
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """tests that InvalidPattern.__eq__ works"""
    a = InvalidPattern('test')
    b = InvalidPattern('test')
    c = InvalidPattern('test2')
    d = InvalidPattern('test', other='stuff')
    e = InvalidPattern('test', other='stuff')
    assert a == b
    assert a != c
    assert a != d
    assert d == e

# Generated at 2022-06-24 02:49:27.163532
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr__ of class InvalidPattern"""
    from bzrlib import ui
    ui.ui_factory = ui.SilentUIFactory()

    m = InvalidPattern('message')
    c = InvalidPattern('message')
    d = InvalidPattern('other message')

    # Test that repr is sort of like __repr__
    assert repr(m).startswith('InvalidPattern(')

    assert m != 'InvalidPattern(message)'

    assert m == c
    assert m != d

# Generated at 2022-06-24 02:49:34.564692
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """test InvalidPattern.__eq__"""

    # test all the cases
    u1, u2 = InvalidPattern("test"), InvalidPattern("test")
    v1, v2 = InvalidPattern("test"), InvalidPattern("test2")
    w1, w2 = InvalidPattern("test"), 1
    assert (u1 == u2)
    assert (u1 != v1)
    assert (v1 != w1)
    assert (u1 != w1)
    assert (v1 != w1)
    assert (w1 != v1)

# Generated at 2022-06-24 02:49:46.673210
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    class InvalidPattern2(InvalidPattern):
        _fmt = '%(msg)s'

    class InvalidPattern3(InvalidPattern):
        _fmt = None

    class InvalidPattern4(InvalidPattern):
        _fmt = '%(file_id)s: %(msg)s'
        def __init__(self, file_id, msg):
            self.file_id = file_id
            self.msg = msg

    class InvalidPattern5(InvalidPattern):
        _fmt = '%(file_id)s: %(msg)s'
        def __init__(self, file_id, msg):
            self.file_id = file_id
            self.msg = msg
        def __unicode__(self):
            return 'invalid unicode'

    class InvalidPattern6(InvalidPattern):
        _

# Generated at 2022-06-24 02:49:54.787531
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() restores the original compile function."""
    global _real_re_compile
    _real_re_compile_import = _real_re_compile
    install_lazy_compile()
    reset_compile()
    global re
    _real_re_compile = re.compile
    reset_compile()
    global re
    _real_re_compile = re.compile
    if _real_re_compile is not _real_re_compile_import:
        raise AssertionError("re.compile is not the original, but reset_compile"
                             " should reset to the original.")

# Generated at 2022-06-24 02:50:00.362186
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern."""
    try:
        raise InvalidPattern('An Errormsg')
    except InvalidPattern as e:
        s = str(e)
        assert s in 'Invalid pattern(s) found. An Errormsg', s
        u = unicode(e)
        assert u in u'Invalid pattern(s) found. An Errormsg', u

# Generated at 2022-06-24 02:50:09.879632
# Unit test for function finditer_public
def test_finditer_public():
    """
    >>> test_string = "test"
    >>> import re
    >>> compile_test = re.compile(test_string)
    >>> isinstance (compile_test, LazyRegex)
    True
    >>> lazy_test = LazyRegex(test_string)
    >>> isinstance (lazy_test, LazyRegex)
    True
    >>> finditer_public(compile_test, test_string)
    <callable-iterator object at 0x...>
    >>> finditer_public(lazy_test, test_string)
    <callable-iterator object at 0x...>
    """


# Generated at 2022-06-24 02:50:13.293963
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import random
    import string
    for i in range(100):
        msg = ''.join([random.choice(string.letters) for i in range(10)])
        err = InvalidPattern(msg)
        assert err.msg == msg, (msg, err.msg)

# Generated at 2022-06-24 02:50:19.740797
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test if we can set a LazyRegex state.

    This will invoke the methods __setstate__ and __getstate__
    """
    import pickle
    global_lazyregex_object = LazyRegex(args=('abc',))
    pickled_object = pickle.dumps(global_lazyregex_object)
    new_global_lazyregex_object = pickle.loads(pickled_object)



# Generated at 2022-06-24 02:50:25.550667
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Verify that InvalidPattern constructor initializes the object properly.
    """
    bad_pattern_msg = "simple error from re.compile."
    e = InvalidPattern(bad_pattern_msg)
    assert e.msg == bad_pattern_msg


# Generated at 2022-06-24 02:50:36.069044
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile works correctly."""

    # make sure that we have a clean state to start with
    reset_compile()

    # we expect that the original re.compile() works fine
    re.compile("a")

    # now install lazy_compile
    install_lazy_compile()

    # this should work fine
    r = re.compile("a")

    # check that we actually got back a LazyRegex
    assert isinstance(r, LazyRegex)

    # check that the proxy is working
    assert r.pattern == "a"

    # but that it doesn't actually compile until called
    assert r._real_regex is None

    # now call something that causes it to compile
    r.match("a")

    # check that it has been compiled
    assert r._

# Generated at 2022-06-24 02:50:46.369403
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import trace
    from io import BytesIO
    sio = trace.UnicodeIO()
    handler = trace.LogHandler(sio)
    tracer = trace.Trace(handler)
    try:
        tracer.runfunc(InvalidPattern.__unicode__,
                       InvalidPattern("my message"))
    finally:
        tracer.uninstall()

# Generated at 2022-06-24 02:50:57.847029
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    a = LazyRegex(("[a-z]+", re.IGNORECASE))
    b = LazyRegex(("[a-z]+",))
    # __getattr__ will only be called if the attribute is
    # not in the object; in this case the attribute is
    # the previously created pattern
    assert a.pattern == re.compile("[a-z]+", re.IGNORECASE).pattern
    assert b.pattern == re.compile("[a-z]+").pattern
    # Calling findall with the compiled regex is just like
    # calling findall with a regular regex
    assert re.findall(a, "AbCdE") == re.findall(re.compile("[a-z]+", re.IGNORECASE), "AbCdE")

# Generated at 2022-06-24 02:51:04.880161
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """This test makes sure that LazyRegex works correctly after pickling

    There is the bug #871287 for the details.
    """
    import pickle
    x = LazyRegex(args = ('[0-9]',), kwargs = {'flags': 0})
    y = pickle.loads(pickle.dumps(x))
    if hasattr(y, '__getstate__'):
        del y.__getstate__
    if hasattr(y, '_compile_and_collapse'):
        del y._compile_and_collapse
    return x, y

# Generated at 2022-06-24 02:51:13.953161
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """This test reproduces Bug #565517"""
    from pickle import dumps
    from bzrlib.repofmt.knitrepo import KnitRepositoryFormat
    from bzrlib.repofmt.packrepo import PackRepositoryFormat
    from bzrlib.repofmt.weaverepo import WeaveRepositoryFormat
    for fmt in [KnitRepositoryFormat(), PackRepositoryFormat(), WeaveRepositoryFormat()]:
        for k, v in dumps(fmt).iteritems():
            lazy_regex = LazyRegex()
            setattr(lazy_regex, k, v)
            dumps(lazy_regex)

# Generated at 2022-06-24 02:51:18.002782
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    install_lazy_compile()
    p = re.compile('foo')
    assert isinstance(p, LazyRegex), p
    reset_compile()

# Generated at 2022-06-24 02:51:28.761239
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() works as expected.

    install_lazy_compile() overrides re.compile() to return a LazyRegex object.
    This test thus checks to ensure that we get one back, and that it doesn't
    actually compile the regex.

    TODO: jam 20080314 This test can be removed if we ever get the ability to
    call reset_compile() in setUp() rather than in tearDown()
    """
    install_lazy_compile()
    r = re.compile('foo')
    assert isinstance(r, LazyRegex)
    assert not hasattr(r, '_real_regex')
    reset_compile()
    r = re.compile('foo')
    assert not isinstance(r, LazyRegex)

# Generated at 2022-06-24 02:51:37.456756
# Unit test for function lazy_compile
def test_lazy_compile():
    """Unit test for function lazy_compile"""
    install_lazy_compile()
    try:
        regex = re.compile("test")
    finally:
        reset_compile()
    assert(isinstance(regex, LazyRegex))
    assert(regex._real_regex is None)
    assert(regex._regex_args == ("test",))
    assert(regex._regex_kwargs == {})
    regex2 = re.compile("^test$")
    assert(isinstance(regex2, LazyRegex))
    assert(regex2._real_regex is None)
    assert(regex2._regex_args == ("^test$",))
    assert(regex2._regex_kwargs == {})
    # Check that getting an attribute actually compiles the

# Generated at 2022-06-24 02:51:46.159197
# Unit test for function reset_compile
def test_reset_compile():
    old_compile = re.compile
    install_lazy_compile()
    try:
        # we need to make sure the override is working
        assert re.compile is lazy_compile
        reset_compile()
        assert re.compile is old_compile, \
            "failed to restore original re.compile, found %s" % (re.compile,)
        reset_compile()
        assert re.compile is old_compile, \
            "reset_compile is not idempotent, second call saw %s" % \
            (re.compile,)
    finally:
        reset_compile()

# Generated at 2022-06-24 02:51:51.683745
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    r = re.compile("foo")
    assert isinstance(r, LazyRegex)
    assert repr(r).startswith("LazyRegex(")
    reset_compile()


if __name__ == '__main__':
    test_install_lazy_compile()

# Generated at 2022-06-24 02:52:00.094663
# Unit test for function lazy_compile
def test_lazy_compile():
    # Test that lazily compiled regexes work
    r1 = LazyRegex()
    # Lazy regexes are actually a regular expression
    assert isinstance(r1, re._pattern_type)
    r1.match("foo")
    assert isinstance(r1, re._pattern_type)

    r2 = re.compile("foo")
    assert r1 == r2

    # Basic match and search test
    r3 = LazyRegex(("^$",))
    assert r3.match("")
    assert r3.search("")
    assert not r3.match("a")
    assert not r3.search("a")

    # Test visibility
    r4 = LazyRegex(("foo",))
    assert not hasattr(r4, 'match')
    r4.match("foo")
    assert has

# Generated at 2022-06-24 02:52:06.825090
# Unit test for function lazy_compile
def test_lazy_compile():
    import pickle
    # Make sure it works if we access members before compiling
    regex = lazy_compile('test')
    regex.test()
    # Make sure it can be pickled/unpickled properly
    pickled = pickle.dumps(regex)
    unpickled = pickle.loads(pickled)
    unpickled.test()



# Generated at 2022-06-24 02:52:09.328062
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string"""
    err = InvalidPattern("pattern error here")
    assert isinstance(err.__repr__(), str)


# Generated at 2022-06-24 02:52:13.377071
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string representation of the object."""
    try:
        raise InvalidPattern("invalid pattern")
    except InvalidPattern as e:
        s = repr(e)
    eq = 'InvalidPattern("invalid pattern")'
    assert eq == s, '%r != %r' % (eq, s)


# Generated at 2022-06-24 02:52:15.671816
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    err = InvalidPattern('a message')
    assert err.msg == 'a message'
    assert str(err) == 'Invalid pattern(s) found. a message'



# Generated at 2022-06-24 02:52:24.740153
# Unit test for function finditer_public
def test_finditer_public():
    """Test for function finditer_public"""
    pattern = '^\S+$'
    flags = re.M
    string = 'test abc def'

    # Test finditer_public
    out = re.finditer(pattern, string, flags)
    assert list(out) == [
        re.match('^\S+$', 'test', re.M),
        re.match('^\S+$', 'abc', re.M),
        re.match('^\S+$', 'def', re.M)
    ]

# Generated at 2022-06-24 02:52:36.894554
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase
    from bzrlib.i18n import gettext, ugettext

    def install_gettext(self):
        """Monkeypatch gettext to return ascii strings"""
        self._i18n_setUp()
        self.overrideAttr(bzrlib, 'gettext', gettext)
        self.overrideAttr(bzrlib, 'ugettext', ugettext)

    class TestInvalidPattern(TestCase):

        def test_equal(self):
            e1 = InvalidPattern(u'foo')
            e2 = InvalidPattern(u'foo')
            self.assertEqual(e1, e2)

        def test_not_equal_class(self):
            e1 = InvalidPattern(u'foo')

# Generated at 2022-06-24 02:52:44.933565
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() from a LazyRegex should return a dictionary."""
    obj = LazyRegex()
    state = obj.__getstate__()
    if type(state) != type({}):
        return False
    if len(state.keys()) != 3:
        return False
    if 'args' not in state.keys():
        return False
    if 'kwargs' not in state.keys():
        return False
    return True


# Generated at 2022-06-24 02:52:47.051704
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import (
        lazy_regex,
        )
    return doctest.DocTestSuite(lazy_regex)

# Generated at 2022-06-24 02:52:53.390691
# Unit test for function reset_compile
def test_reset_compile():
    import re
    old_compile = re.compile
    try:
        re.compile = 'not re.compile'
        reset_compile()
        assert re.compile is old_compile
    finally:
        re.compile = old_compile


# Unit tests for function install_lazy_compile and reset_compile

# Generated at 2022-06-24 02:52:59.513197
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    o = LazyRegex(('test_LazyRegex___getstate__', re.UNICODE | re.IGNORECASE))
    d = o.__getstate__()
    global_environ_a = {}
    global_environ_b = {}

# Generated at 2022-06-24 02:53:08.005037
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile wrapper.
    """
    from cStringIO import StringIO
    import traceback
    output = StringIO()
    install_lazy_compile()
    try:
        class Foo(object):
            pass
        foo = Foo()
        lazy_compile(foo)
        traceback.print_exc(file=output.write)
    finally:
        reset_compile()
    assert output.getvalue().find(
        'TypeError: expected string or buffer') >= 0
    output.close()
