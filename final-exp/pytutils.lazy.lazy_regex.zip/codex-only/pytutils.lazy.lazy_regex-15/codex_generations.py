

# Generated at 2022-06-24 02:43:13.944809
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    args=("pattern",)
    kwargs={"flags": 0}
    lazy_re = LazyRegex(args, kwargs)
    lazy_re_c = LazyRegex(*args, **kwargs)
    assert lazy_re.__getstate__() == {'args': args,
                                      'kwargs': kwargs}
    lazy_re.__setstate__(lazy_re_c.__getstate__())
    assert lazy_re.__getstate__() == lazy_re_c.__getstate__()

# Generated at 2022-06-24 02:43:20.584944
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a string, even when __unicode__ does not"""
    class NonStringException(InvalidPattern):

        def __unicode__(self):
            return u"\u2603"
    try:
        raise NonStringException("\u2603")
    except NonStringException as e:
        s = str(e)
        assert isinstance(s, str)

# Generated at 2022-06-24 02:43:30.635317
# Unit test for function finditer_public
def test_finditer_public():
    # re.finditer should be unchanged when called with a real regex
    _real_re_compile = re.compile
    real_finditer = re.finditer
    try:
        re.compile = lambda pattern, flags, fake=None: pattern 
        re.finditer = finditer_public
        myre = re.compile('a(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(.?)(b)')
        my = real_finditer(myre, 'a         b')
        for item in my:
            assert item.end() == 16
        # should not raise an error
        re.finditer('c(\w)', 'c1')
    finally:
        re.finditer = real_finditer
        re.compile = _real_re

# Generated at 2022-06-24 02:43:38.195564
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Set up a LazyRegex initialized with args and kwargs, pickle it, and
    then set it up again.  Verify that the arguments are preserved."""
    source = LazyRegex(["abc"], {"flags": re.IGNORECASE})
    import pickle
    pickled = pickle.dumps(source)
    target = pickle.loads(pickled)
    assert (target._regex_args, target._regex_kwargs) == \
        (source._regex_args, source._regex_kwargs)



# Generated at 2022-06-24 02:43:42.852463
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib._tests.blackbox import ExternalBase

    class TestCase(ExternalBase):

        def test_invalid(self):
            ex1 = InvalidPattern('test_msg')
            ex2 = InvalidPattern('test_msg')
            self.assertEqual(ex1, ex2)

    TestCase.run_tests()

# Generated at 2022-06-24 02:43:49.627082
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    try:
        p = re.compile('foo')
        assert isinstance(p, LazyRegex)
        # Access a member of the object - this is when it must be compiled
        p.search
        assert isinstance(p._real_regex, _real_re_compile('foo').__class__)
    finally:
        reset_compile()



# Generated at 2022-06-24 02:44:00.976227
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib.tests import TestCase
    from bzrlib import ui
    from StringIO import StringIO

    class TestLazyRegex(TestCase):

        def test_copy(self):
            s = '(no bug) branch nick of "foo" is "baz"'
            regexp = LazyRegex(('\(', re.I),
                               {'pattern':s})
            self.assertEqual(None, regexp._real_regex)
            regexp_copy = regexp.__copy__()
            self.assertEqual(None, regexp_copy._real_regex)
            regexp.match(s)
            regexp_copy.match(s)
            self.assertNotEqual(None, regexp._real_regex)

# Generated at 2022-06-24 02:44:04.088512
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    if sys.version_info[0] > 2:
        # Test with UnicodeEncodeError
        e = UnicodeEncodeError('ascii', u'\u0100', 0, 1, u'ordinal not in range')
        err = InvalidPattern(e)
        assert err.msg == e
        str(err)

# Generated at 2022-06-24 02:44:11.275849
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr = LazyRegex("foo")
    lr = LazyRegex("foo", re.I)
    lr = LazyRegex("foo", re.I | re.M)
    lr = LazyRegex("foo", re.I | re.M, re.X)
    lr = LazyRegex("foo", re.I, re.M, re.X)
    lr = LazyRegex("foo", re.I, re.M, re.X, re.U)
    lr = LazyRegex("foo", re.I, re.M, re.X, re.U, re.S)
    lr = LazyRegex("foo", re.I, re.M, re.X, re.U, re.S, re.L)
    lr = LazyRe

# Generated at 2022-06-24 02:44:20.311477
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Try to get the representation of an InvalidPattern."""
    pattern = InvalidPattern(msg='Invalid pattern(s) found. %(msg)s')
    # The two following methods were used to check that the representation of
    # pattern has the form:
    # InvalidPattern(Unprintable exception InvalidPattern:
    #                dict={'msg': 'Invalid pattern(s) found. %(msg)s'},
    #                fmt='Invalid pattern(s) found. %(msg)s', error=None)
    # The first method checks that the representation of pattern ends with the
    # two substrings 'dict={' and 'error=None)',
    # where the 'dict=' and the 'msg=' are respectively the prefix and the key
    # of the dictionary forming the arguments of the Unprintable exception.
    # The second method checks that the representation of pattern begins

# Generated at 2022-06-24 02:44:25.404807
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    proxy = lazy_compile('a')
    state = proxy.__getstate__()
    expected_state = {'args': ('a', ), 'kwargs': {}}
    assert state == expected_state, \
        'Return value of __getstate__() is not the tuple that is expected.'



# Generated at 2022-06-24 02:44:33.543379
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex."""
    import pickle
    pickle_string = pickle.dumps(LazyRegex(("^foo", ), {}))
    obj = pickle.loads(pickle_string)
    # No need to compare obj and old_obj because they are the same
    # object.
    # There is a bug. __setstate__() isn't called and the attribute
    # _regex_kwargs is not initialized.
    # But the content of this attribute doesn't change the result of
    # the test.
    assert isinstance(obj, LazyRegex)
    assert obj._regex_args == ("^foo", )

# Generated at 2022-06-24 02:44:38.166721
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    assert str(InvalidPattern('foo')) == "Invalid pattern(s) found. foo"
    assert unicode(InvalidPattern('foo')) == "Invalid pattern(s) found. foo"
    assert repr(InvalidPattern('foo')) == "InvalidPattern('foo')"

# Generated at 2022-06-24 02:44:42.438863
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('my message')
    except InvalidPattern as e:
        if str(e) != 'Invalid pattern(s) found. my message':
            raise AssertionError('Unexpected string representation of '
                                 'InvalidPattern: "%s"' % str(e))
        if repr(e) != 'InvalidPattern(Invalid pattern(s) found. my message)':
            raise AssertionError('Unexpected repr of InvalidPattern: "%s"' %
                                 repr(e))
        if e.msg != 'my message':
            raise AssertionError('Unexpected attribute msg of InvalidPattern')
        try:
            e.msg = 'my new message'
        except AttributeError:
            pass
        else:
            raise AssertionError('Should not be able to modify msg')

# Generated at 2022-06-24 02:44:52.628160
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern("a test message")
    assert e.msg == "a test message"

    # A test for bug #118741
    class MyException(InvalidPattern):
        _fmt = '%(msg)s!'
    e = MyException("a test message")
    expect = "a test message!"
    actual = unicode(e)
    assert actual == expect, "Expected '%s', actual '%s'" % (expect, actual)



# Generated at 2022-06-24 02:44:55.808391
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import tests

    e = InvalidPattern('Test exception')
    u = unicode(e)
    # must return a Unicode object
    tests.TestCase.assertIsInstance(u, unicode)
    tests.TestCase.assertTrue(len(u) > 0)

# Generated at 2022-06-24 02:45:01.072705
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile restores re.compile"""
    assert re.compile is not _real_re_compile
    reset_compile()
    assert re.compile is _real_re_compile
    # Calling reset_compile multiple times is safe
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-24 02:45:03.368338
# Unit test for method __eq__ of class InvalidPattern

# Generated at 2022-06-24 02:45:08.996045
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # InvalidPattern should return a message that can be printed to the user.
    # (and the test runner, of course)
    # We should never return a unicode object, because some parts of bzrlib
    # may try to print that as ascii.
    err = InvalidPattern('test')
    str(err)
    unicode(err)


# Generated at 2022-06-24 02:45:12.562852
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = lazy_compile
    reset_compile()
    regex = re.compile(".*")
    assert isinstance(regex, _real_re_compile)



# Generated at 2022-06-24 02:45:25.497738
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib import tests
    import re
    list_result = []
    for m in re.finditer("(?P<name>\w+)", "Joe Gagne"):
        list_result.append(m.group("name"))
    tests.TestCase.assertEqual(["Joe", "Gagne"], list_result)
    list_result = []
    for m in re.finditer(re.compile("(?P<name>\w+)"), "Joe Gagne"):
        list_result.append(m.group("name"))
    tests.TestCase.assertEqual(["Joe", "Gagne"], list_result)
    list_result = []
    for m in re.finditer(lazy_compile("(?P<name>\w+)"), "Joe Gagne"):
        list_result

# Generated at 2022-06-24 02:45:30.853212
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    a = InvalidPattern('bad pattern')
    assert a.msg == 'bad pattern'
    assert a._fmt, '_fmt is not None'
    b = InvalidPattern('bad pattern')
    assert a == b

# Generated at 2022-06-24 02:45:36.844646
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ is called by doctest to print a exception when a test fails.
    It must be simple and short to be readable.
    """
    # We can't use assertRaises because it calls `repr` on the exception
    # instead of `str`
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        pass
    assert repr(e) == "InvalidPattern('foo')"



# Generated at 2022-06-24 02:45:40.815264
# Unit test for function finditer_public
def test_finditer_public():
    """The function finditer_public must return an iterator.

    It does nothing else.
    It should not raise an exception on LazyRegex which doesn't define finditer.
    """
    assert getattr(re, 'finditer', False)
    re.finditer("string", None)



# Generated at 2022-06-24 02:45:43.551088
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test function lazy_compile"""
    import doctest
    return doctest.testmod(re)[0]


if __name__ == '__main__':
    test_lazy_compile()

# Generated at 2022-06-24 02:45:52.967667
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() method must return a dict object.

    This dict object must contain keys "args" and "kwargs".
    """
    regex = LazyRegex(args=('a', 'b', 'c'), kwargs={'kw1': 'kw1', 'kw2': 'kw2'})
    state = regex.__getstate__()
    # "args" and "kwargs" keys are required
    assert "args" in state
    assert "kwargs" in state
    assert len(state) == 2



# Generated at 2022-06-24 02:46:04.345314
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    import sys
    if sys.version_info < (2, 6):
        from cStringIO import StringIO
        unicode_type = unicode
        def getunicode(s):
            return unicode_type(s, 'utf8')
        unicode = getunicode
    else:
        unicode = unicode
    # set translations to empty strings
    # Note that it may be difficult to test also the case when translations
    # are not empty as translations depend on the system language.
    gettext.install("", names="bzr")
    # Test case containing only a simple __str__
    class SimpleError(InvalidPattern):
        _fmt = "simple"
    e = SimpleError("msg")
    assert unicode(e) == u"simple"
    # Test

# Generated at 2022-06-24 02:46:07.608558
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Encoding bug of method __unicode__ of class InvalidPattern

    A message already encoded as Unicode should not be reencoded.
    """
    message = u'Pattern not found.'
    e = InvalidPattern(message)
    assert unicode(e) == message

# Generated at 2022-06-24 02:46:16.581971
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():

    class UnicodeValue(object):
        def __str__(self):
            return unicode('abc')

    class StrWithInvalidEncoding(object):
        def __str__(self):
            return '\xff'

    class UnknownStr(object):
        def __str__(self):
            raise ValueError()

    ip = InvalidPattern('msg')
    assert isinstance(ip, InvalidPattern)
    assert isinstance(ip.__unicode__(), unicode)
    assert ip.__unicode__() is not None

    # provide a _fmt and check that we are getting it back
    InvalidPattern._fmt = 'a %(msg)s'
    assert isinstance(ip.__unicode__(), unicode)
    assert ip.__unicode__() is not None

# Generated at 2022-06-24 02:46:29.326000
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # With a string
    e = InvalidPattern('some msg')
    assert str(e) == 'some msg'
    assert e.msg == 'some msg'

    # With unicode
    e = InvalidPattern(u'\xe9')
    assert isinstance(str(e), str)
    assert str(e) == u'\xe9'
    assert isinstance(e.msg, unicode)
    assert e.msg == u'\xe9'

    # With unicode string containing utf8, but decodable
    e = InvalidPattern('\xe9')
    assert isinstance(str(e), str)
    assert str(e) == '\xc3\xa9'
    assert isinstance(e.msg, unicode)
    assert e.msg == u'\xe9'

    # With unicode string containing ut

# Generated at 2022-06-24 02:46:37.117304
# Unit test for function finditer_public
def test_finditer_public():
    """Ensure that re.finditer works with LazyRegex

    This is a regression test for a bug.
    """
    inst = re.finditer('a', 'a')
    match = next(inst)
    assert match
    assert match.group() == 'a'
    install_lazy_compile()
    try:
        inst = re.finditer('a', 'a')
        match = next(inst)
        assert match
        assert match.group() == 'a'
    finally:
        reset_compile()

# Generated at 2022-06-24 02:46:47.193773
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestNotApplicable

    if _real_re_compile is not lazy_compile:
        install_lazy_compile()
    else:
        # can't really test this
        raise TestNotApplicable("re.compile is already lazy_compile")
    try:
        re.compile("foo")
    except TypeError:
        raise AssertionError("re.compile is already lazy_compile")
    reset_compile()
    try:
        re.compile("foo")
    except TypeError:
        raise AssertionError("re.compile is no longer lazy_compile")


# Generated at 2022-06-24 02:46:52.113447
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod(optionflags=doctest.REPORT_NDIFF, verbose=False)

__test__ = {'test_finditer_public': test_finditer_public}

# Generated at 2022-06-24 02:47:02.404447
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern("")
    e._preformatted_string = u"foo"
    assert unicode(e) == u"foo"

    e2 = InvalidPattern("")
    e2._preformatted_string = u"bar"
    assert unicode(e) == u"foo"
    assert unicode(e2) == u"bar"

    e3 = InvalidPattern("")
    e3.foo = "bar"
    e3.bar = "bas"
    assert unicode(e3) == u"Unprintable exception InvalidPattern: " \
            "dict={'foo': 'bar', 'bar': 'bas'}, fmt=None, error=None"

    e4 = InvalidPattern("")
    e4._fmt = u'foo'
    e4.foo = "bar"

# Generated at 2022-06-24 02:47:13.736883
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern
    """
    # test passing two equal InvalidPattern objects
    err_msg = 'err'
    ip1 = InvalidPattern(err_msg)
    ip2 = InvalidPattern(err_msg)
    actual = ip1.__eq__(ip2)
    expected = True
    msg = ("ip1.__eq__(ip2) returned %s, expected %s" % (actual, expected))
    assert actual == expected, msg

    # test passing two InvalidPattern objects with different messages
    err_msg1 = 'err1'
    err_msg2 = 'err2'
    ip1 = InvalidPattern(err_msg1)
    ip2 = InvalidPattern(err_msg2)
    actual = ip1.__eq__(ip2)
    expected = False

# Generated at 2022-06-24 02:47:21.909639
# Unit test for function reset_compile
def test_reset_compile():
    import re

    re.compile = lambda x: x
    reset_compile()
    re.compile = lambda x: x
    reset_compile()
    re.compile = lambda x: x
    reset_compile()
    # We need to check that that is the same as the re.compile in this module
    # so that we can actually test if reset works
    assert re.compile is _real_re_compile



# Generated at 2022-06-24 02:47:32.376856
# Unit test for function finditer_public
def test_finditer_public():
    """Simple test for LazyRegex.finditer(s).  """

    # finditer_public(s) must be equivalent with re.compile(s).finditer()
    s = 'abc'
    matches = re.compile(s).finditer('aaabcaaabc')
    matches2 =  re.finditer(s, 'aaabcaaabc')
    for m, m2 in zip(matches, matches2):
        assert m.group() == m2.group()
    assert m2.group() == 'abc'

    # finditer_public(LazyRegex(s)) must be equivalent with re.finditer(s)
    matches3 =  re.finditer(LazyRegex(s), 'aaabcaaabc')

# Generated at 2022-06-24 02:47:41.214265
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ of class LazyRegex should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it
    """
    # setup
    class Foo(object):
        def __init__(self):
            self.bar = 'hello world'
        def __getattr__(self, attr):
            return getattr(self, attr)
    proxy_regex = LazyRegex()
    proxy_regex._real_regex = Foo()
    # exercise
    proxy_regex.bar
    # verify
    # it should not throw exception

# Generated at 2022-06-24 02:47:49.913735
# Unit test for function reset_compile
def test_reset_compile():
    # Make sure that the function does what it says and sets compile
    # back to the way it was when it was imported
    from bzrlib.tests import TestNotApplicable
    if re.compile is not lazy_compile:
        # If re.compile isn't lazy_compile then we can't do a full test, since
        # we don't know what function it is set back to.
        raise TestNotApplicable('re.compile is not lazy_compile')
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError('re.compile is not properly reset')
    # And make sure that it continues to work properly even if it is
    # called multiple times
    reset_compile()
    reset_compile()

# Generated at 2022-06-24 02:47:55.789428
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Create a new regular expression object.
    """
    x = LazyRegex(('a',), {'b':1})
    assert x.__class__ == LazyRegex
    assert x._real_regex == None
    assert x._regex_args == ('a',)
    assert x._regex_kwargs == {'b':1}



# Generated at 2022-06-24 02:48:05.164858
# Unit test for function reset_compile
def test_reset_compile():
    # Test that re.compile can be restored to its original state
    install_lazy_compile()
    reset_compile()
    re.compile('foo')

# Some libraries calls re.match() ==> _sre.match() which is not callable
# nor function like.
if getattr(re, 'match', False):
    def match_public(pattern, string, flags=0):
        if isinstance(pattern, LazyRegex):
            return pattern.match(string)
        else:
            return _real_re_compile(pattern, flags).match(string)
    re.match = match_public

## class Regex(object):
##     """A regex object which is compiled on demand.

##     The compile will happen the first time an attribute is accessed on the
##     object.  This allows a

# Generated at 2022-06-24 02:48:16.922810
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # encoding_err() is a helper function which make a UnicodeEncodeError
    # with the specified 'encoding' and 'object'
    # This function is used to check the behavior of InvalidPattern in the
    # case where Python fails to encode a string with the default encoding.
    # It seems that the occurrence of such a case is rather unlikely, but
    # I'd like to check it just in case.
    def encoding_err(encoding, object):
        return UnicodeEncodeError(encoding, u'abc', 0, 1, 'abc'.encode(encoding))
    def assert_equal(obj, expected):
        actual = obj.__unicode__()
        if expected != actual:
            raise AssertionError('%r != %r' % (expected, actual))

# Generated at 2022-06-24 02:48:21.359291
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('a')
    assert e.msg == 'a'
    assert str(e) == 'Invalid pattern(s) found. a'
    e = InvalidPattern('a')
    assert e.msg == 'a'
    assert str(e) == 'Invalid pattern(s) found. a'

# Generated at 2022-06-24 02:48:32.173964
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ should return a dictionary with the current arguments and keyword arguments
    used to construct the LazyRegex."""
    _args = ('^[\\d]+$',)
    _kwargs = {'flags': re.U}
    try:
        _real_re_compile(*_args, **_kwargs)
    except re.error as e:
        raise InvalidPattern('"' + _args[0] + '" ' +str(e))
    _l = LazyRegex(_args, _kwargs)
    state = _l.__getstate__()
    # TODO: Find a better way to compare dictionaries
    expected_state = {
        "args": _args,
        "kwargs": _kwargs,
        }

# Generated at 2022-06-24 02:48:41.059213
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # str
    error = InvalidPattern(u"\xa4\xa2\xa4\xa4\xa4\xa6")
    error.filename = "/my/filename.py"
    error.lineno = 10
    error.colno = 0
    expected = u"Invalid pattern(s) found. \xa4\xa2\xa4\xa4\xa4\xa6"
    assert(str(error) == unicode(expected))
    assert(str(error) == expected)


if __name__ == '__main__':
    test_InvalidPattern()

# Generated at 2022-06-24 02:48:43.037047
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex constructor accepts 1 or 2 args."""
    LazyRegex()
    LazyRegex('')
    LazyRegex((), {})

# Generated at 2022-06-24 02:48:47.932626
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() will restore the original re.compile()"""
    try:
        install_lazy_compile()
        reset_compile()
        re.compile = lambda x:None
        reset_compile()
        if re.compile != _real_re_compile:
            raise AssertionError(
                "reset_compile didn't restore re.compile to its original value")
    finally:
        reset_compile()

# Generated at 2022-06-24 02:48:57.963404
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test __setstate__ of LazyRegex"""
    r = LazyRegex(args=(), kwargs={'flags': re.IGNORECASE})
    r.__setstate__({'args': (), 'kwargs': {'flags': re.IGNORECASE}})
    assert r._regex_args == ()
    assert r._regex_kwargs == {'flags': re.IGNORECASE}

    r = LazyRegex(args=('test',), kwargs={})
    r.__setstate__({'args': ('test',), 'kwargs': {}})
    assert r._regex_args == ('test',)
    assert r._regex_kwargs == {}

# Generated at 2022-06-24 02:49:09.398650
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that proxy objects are compiled lazily."""
    import copy
    import pickle
    global _real_re_compile
    old_compile = _real_re_compile

    # Switch to using a global, so we can swap this in and out during
    # testing.
    global _real_re_compile
    fails = []
    _real_re_compile = fails.append
    try:
        a = LazyRegex('abc')
        proxy_copy = copy.copy(a)
        proxy_deepcopy = copy.deepcopy(a)
        pickle.dumps(a)
    finally:
        _real_re_compile = old_compile
    if fails:
        raise AssertionError(
            "LazyRegex's copy and deepcopy methods caused compilation")

# Generated at 2022-06-24 02:49:15.266573
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    lazy = LazyRegex()
    state = lazy.__getstate__()
    assert state == {
        "args": (),
        "kwargs": {},
        }

    lazy = LazyRegex(('test', ), {'a': 'b'})
    state = lazy.__getstate__()
    assert state == {
        "args": ('test',),
        "kwargs": {'a': 'b'},
        }


# Generated at 2022-06-24 02:49:22.532908
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    args = ("foo",)
    kwargs = {}
    lr = LazyRegex(args, kwargs)
    lr._real_regex = re.compile("bar")
    dict = pickle.dumps(lr, 2)
    dict = pickle.loads(dict)
    assert dict["args"] == args
    assert dict["kwargs"] == kwargs

# Generated at 2022-06-24 02:49:30.124534
# Unit test for function reset_compile
def test_reset_compile():
    """Check re.compile is reset properly and that it doesn't break re.
    """
    install_lazy_compile()
    reset_compile()
    # Check that calling reset_compile() twice doesn't break anything
    reset_compile()
    # Check that re.findall still works
    # lazily compiled regexs will only work if the
    # __getattr__ is called for the first time after
    # the proxy is pickled - at which point
    # _compile_and_collapse is called.
    re.compile = lambda *args, **kwargs: LazyRegex(args, kwargs)
    assert re.findall('foo', 'foo') == ['foo']
    # Check that re.sub works, because it calls findall

# Generated at 2022-06-24 02:49:42.884974
# Unit test for function finditer_public
def test_finditer_public():
    # LazyRegex object
    lre = re.compile("(.+)", re.DOTALL)
    m = re.finditer("(.+)", "bzrlib\n", re.DOTALL)
    assert m.next().group() == "bzrlib\n"
    # Regex object
    r = re.compile("(.+)", re.DOTALL)
    m = re.finditer("(.+)", "bzrlib\n", re.DOTALL)
    assert m.next().group() == "bzrlib\n"

# Some libraries calls re.search which fails it if receives a LazyRegex.

# Generated at 2022-06-24 02:49:51.489712
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() returns a dictionary with the key 'args' and 'kwargs'
    that contain the values passed to re.compile() when initializing
    LazyRegex.
    """
    regex = lazy_compile(r'^bzr\s.+', re.IGNORECASE)
    state = regex.__getstate__()
    assert state['args'][0] == r'^bzr\s.+'
    assert state['kwargs']['flags'] == re.IGNORECASE


# Generated at 2022-06-24 02:49:53.305286
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test calling a regex method that doesn't exist"""
    # calling a regex method that doesn't exist should raise an AttributeError
    regex = re.compile('^foo')
    regex.not_exist()

# Generated at 2022-06-24 02:49:59.366916
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore the state of a LazyRegex"""
    a = LazyRegex((r".",), {"flags": 1})
    a._compile_and_collapse()
    b = LazyRegex()
    b.__setstate__(a.__getstate__())
    assert (a._real_regex is not None) and (b._real_re_compile is not None)

# Generated at 2022-06-24 02:50:05.218330
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Default case
    testobj = LazyRegex()
    assert testobj._real_regex is None
    assert testobj._regex_args == ()
    assert testobj._regex_kwargs == {}
    # Positional args
    testobj = LazyRegex(('abc', 'd+', 'ef'))
    assert testobj._real_regex is None
    assert testobj._regex_args == ('abc', 'd+', 'ef')
    assert testobj._regex_kwargs == {}
    # Keyword args
    testobj = LazyRegex(kwargs={'f':'gh'})
    assert testobj._real_regex is None
    assert testobj._regex_args == ()
    assert testobj._regex_kwargs == {'f':'gh'}
    # Positional

# Generated at 2022-06-24 02:50:09.216314
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function"""
    from bzrlib.tests import TestCase

    # We use a local copy of lazy_compile() that does not call
    # _real_re_compile for brevity and efficiency.
    _real_lazy_compile = LazyRegex

    class TestLazyCompile(TestCase):
        """Test the lazy compilation of regexs.

        At the time of writing, all of this is just defensive
        programming. The original use case for this code has been
        removed.
        """

        def test_compilation(self):
            regex = _real_lazy_compile()
            self.assertRaises(AttributeError, getattr, regex, '_real_regex')
            regex = _real_lazy_compile(('a*b',))
            self.assertFalse

# Generated at 2022-06-24 02:50:15.999377
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() works in the face of LazyRegex."""
    # Install the LazyRegex substitute
    install_lazy_compile()
    # Now test that reset_compile() will restore the original functionality
    reset_compile()
    # We know that LazyRegex is a new-style class, so this is a good
    # way to test that we are back to the original re.compile()
    assert type(re.compile('a')) is not LazyRegex
    # Calling reset_compile() again should be safe.
    reset_compile()
    assert type(re.compile('a')) is not LazyRegex

# Generated at 2022-06-24 02:50:21.854711
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Class LazyRegex method __getstate__ is working as expected."""

    # Test with positive case.
    lre = LazyRegex(("ab*",), {"flags": re.IGNORECASE})
    dict = lre.__getstate__() # Call the method under test.
    # Assertion about expected dict.
    expected = {
        "args": ("ab*",),
        "kwargs": {"flags": re.IGNORECASE}
        }
    assert dict == expected



# Generated at 2022-06-24 02:50:30.420167
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile() really reset re.compile to its original value.

    The test is a bit hackish in a way, but it works pretty well.
    """
    re.compile = lambda *args, **kwargs: 'not re.compile'
    reset_compile()
    re_compile = re.compile
    if re_compile('test') != _real_re_compile('test'):
        raise AssertionError(
            "re.compile has not been reset to its original value")

# Generated at 2022-06-24 02:50:35.920805
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    msg_unicode = u'\xd7\xa9\xd7\x9c\xd7\x95\xd7\x9d'
    ip = InvalidPattern(msg_unicode)
    assert str(ip) == gettext(msg_unicode).encode('utf-8')
    assert unicode(ip) == gettext(msg_unicode)

# Generated at 2022-06-24 02:50:40.871245
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    obj = LazyRegex(args=('pattern',), kwargs={'flags': re.DOTALL})
    assert obj._regex_args == ('pattern',)
    assert obj._regex_kwargs == {'flags': re.DOTALL}


# Generated at 2022-06-24 02:50:45.344461
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""

    obj = LazyRegex("a", {"b": "c"},)
    dict = obj.__getstate__()

    assert dict["args"] == ("a",), "args not set"
    assert dict["kwargs"] == {"b": "c"}, "kwargs not set"



# Generated at 2022-06-24 02:50:50.999981
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    try:
        re.compile('foo')
        assert False, 'should have raised an exception'
    except TypeError:
        pass
    reset_compile()
    install_lazy_compile()
    try:
        re.compile('foo')
        assert False, 'should have raised an exception'
    except TypeError:
        pass

# Generated at 2022-06-24 02:50:54.181627
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore all attributes"""
    o = LazyRegex(("pattern", ), {"flags": 0})
    o.finditer("string")
    o.__setstate__({"args": ("pattern", ), "kwargs": {"flags": 0}})
    o.finditer("string")

# Generated at 2022-06-24 02:50:59.831396
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must return a unicode object.
    """
    from bzrlib.i18n import gettext
    gettext('') # To set a default message catalog
    invalid_pattern = InvalidPattern('foo')
    u = invalid_pattern.__unicode__()
    assert isinstance(u, unicode), "__unicode__ must return a unicode object"


# Generated at 2022-06-24 02:51:09.979969
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that LazyRegex.__getattr__ works for attributes of _sre.SRE_Pattern.

    This is the method that allows to temporarily replace
    _sre.SRE_Pattern.__getattr__ by a method that will look for the attribute
    in the real regex in case that it does not exist in the proxy and that it
    was not caught before.
    """
    # Note that we expect that the proxy will not have all attributes of
    # _sre.SRE_Pattern, so it is better to test that it works for a few
    # attributes and not to try to test all attributes.
    proxy = LazyRegex((u'a(b)',), {u'flags': re.I})
    # Call __getattr__ because attributes are not copied to the proxy object.

# Generated at 2022-06-24 02:51:13.380922
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    proxy = LazyRegex(re.compile('test').match('test', 0, 4))

    if proxy.match('test') is None:
        raise AssertionError("LazyRegex constructor failed")

# Generated at 2022-06-24 02:51:23.426931
# Unit test for function reset_compile
def test_reset_compile():
    global re
    import re
    # being called on import time, we expect re.compile to be its default value
    # And we expect reset_compile to return it to this value as well
    import sys
    re_compile_on_import = sys.modules['re'].compile
    # If this fails, reset_compile() doesn't work.
    reset_compile()
    # And we expect re.compile to be set to default value
    assert re is sys.modules['re']
    assert re.compile is re_compile_on_import

# Generated at 2022-06-24 02:51:31.298431
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object."""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import _i18n_default_encoding

# Generated at 2022-06-24 02:51:39.294943
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Proxy object's state is its regex."""
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_state(self):
            proxy = LazyRegex(args=('[0-9a-f]+', ), kwargs={})
            self.assertEqual({
                "args": ('[0-9a-f]+', ),
                "kwargs": {},
                }, proxy.__getstate__())
    Test().run()


# Generated at 2022-06-24 02:51:45.746557
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it.
    """
    # Create LazyRegex object without compiling it
    lr = LazyRegex(('a', re.IGNORECASE))
    assert lr._real_regex is None, \
        "The regex must not be compiled yet"

    # Check that an attr is returned, this compiles the regex
    attr = lr.pattern
    assert lr._real_regex, \
        "The regex must be compiled"
    assert attr == lr._real_regex.pattern, \
        "Wrong attr returned"

# Generated at 2022-06-24 02:51:56.743372
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method _format of class InvalidPattern.

    Test that the exception raised when we compile a pattern with a bad
    syntax, returns the proper unicode message.
    """
    from bzrlib.i18n import gettext
    from cStringIO import StringIO

    def _set_up_gettext(encoding=None, languages=[], gettext_callables=None):
        """Set up translation for gettext."""
        if encoding is None:
            encoding = 'utf-8'
        if gettext_callables is None:
            def gettext_uid(s):
                return unicode(s)
            def gettext_did(s):
                return s
            gettext_callables = (gettext_uid, gettext_did)
        global gettext
        gettext = gettext_callables[0]
       

# Generated at 2022-06-24 02:52:00.088484
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'this is a message'
    e = InvalidPattern(msg)
    assert str(e) == msg
    assert repr(e) == 'InvalidPattern(\'this is a message\')'

# Generated at 2022-06-24 02:52:05.791141
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() actually works.
    """
    install_lazy_compile()
    reset_compile()
    if not _real_re_compile is re.compile:
        raise AssertionError("reset of re.compile failed.")

# Generated at 2022-06-24 02:52:14.890869
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method __setstate__ of class LazyRegex."""
    import cPickle
    import copy

    # Original object.
    lazy_regex = LazyRegex(('this is a (test) pattern',), {'flags': re.IGNORECASE})

    # We don't want to check the value of the following attributes
    # of the original object as they change each time this test
    # is run. So we reset them to None.
    lazy_regex._real_regex = None
    lazy_regex._regex_args = None
    lazy_regex._regex_kwargs = None

    # Create a deep copy of the original object with pickle.
    state = cPickle.dumps(lazy_regex)
    lazy_regex_copy = copy.deepcopy(lazy_regex)

# Generated at 2022-06-24 02:52:23.398138
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import random
    import re
    import shutil
    import sys
    import tempfile

    filename = tempfile.mktemp()
    shutil.copyfile(__file__, filename)
    # This will load up the file into the module cache, so the next time
    # it is loaded the patched re module will be loaded.
    # We have to do this before installing lazy_compile because
    # lazy_compile will be installed into the cached re module not the
    # one we are actively importing from.
    importlib.invalidate_caches()
    importlib.import_module('bzrlib.lazy_regex')

    sys.path.insert(0, filename)

# Generated at 2022-06-24 02:52:33.260211
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the install_lazy_compile function.

    This is a separate test module because of the side effects of the
    install_lazy_compile function.
    """
    import doctest
    from bzrlib.tests import TestCaseInTempDir

    install_lazy_compile()
    try:
        suite = doctest.DocTestSuite('bzrlib.lazy_regex')
        suite.layer = TestCaseInTempDir
        test_result = suite.run(doctest.DocTestRunner(verbose=0))
    finally:
        reset_compile()

    if not test_result.wasSuccessful():
        raise test_result

# Generated at 2022-06-24 02:52:37.848213
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__() works"""
    e = InvalidPattern(msg='foo')
    self.assertEqual(e, InvalidPattern(msg='foo'))
    self.assertNotEqual(e, InvalidPattern(msg='bar'))
    self.assertNotEqual(e, Exception())

# Generated at 2022-06-24 02:52:43.967724
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Illustration of exception InvalidPattern"""
    # Create an instance of class InvalidPattern
    obj = InvalidPattern(msg='bad pattern')
    # Access to __repr__ method
    r = obj.__repr__()
    assert r == "InvalidPattern(u'bad pattern')"
    return



# Generated at 2022-06-24 02:52:49.292497
# Unit test for function finditer_public
def test_finditer_public():
    re.compile = _real_re_compile
    assert re.finditer("\w+", "foo\nbar\n")
    install_lazy_compile()
    # proxy object
    proxy = re.compile("\w+")
    found = re.finditer(proxy, "foo\nbar\n")
    assert found
    # class object
    found = re.finditer(proxy.__class__, "foo\nbar\n")
    assert found
    reset_compile()

# Generated at 2022-06-24 02:52:58.987500
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must be able to restore the state of a LazyRegex"""
    import cPickle

    proxy = LazyRegex((r'(from) (\S+)', re.I | re.S), {})
    proxy._compile_and_collapse()

    # use pickle to store an internal representation of the state
    pickled_state = cPickle.dumps(proxy.__getstate__())

    # the state will be restored in a new LazyRegex
    proxy2 = LazyRegex()
    proxy2.__setstate__(cPickle.loads(pickled_state))

    # check that proxy2 has the expected state
    proxy2._compile_and_collapse()
    regex = proxy2._real_regex
    assert regex.pattern == '(from) (\\S+)'


# Generated at 2022-06-24 02:53:03.613471
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod(name='bzrlib.lazy_regex',
                    globs={'u': unicode, 'str':str},
                    optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 02:53:05.595895
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = "Test message"
    ip = InvalidPattern(msg)
    assert str(ip) == msg

# Generated at 2022-06-24 02:53:14.944829
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    args = ("[A-Z]{4}[0-9]{2}[a-zA-Z0-9]{3}",)
    kwargs = dict(flags=re.I)
    my_regex = LazyRegex(args, kwargs)
    assert my_regex._regex_args == args
    assert my_regex._regex_kwargs == kwargs
    assert not hasattr(my_regex, 'match')
    assert not hasattr(my_regex, 'search')
    # _compile_and_collapse() should initialize the real regex
    my_regex._compile_and_collapse()
    assert hasattr(my_regex, 'match')
    assert hasattr(my_regex, 'search')