

# Generated at 2022-06-24 02:43:15.415773
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """This test case is for method __setstate__ of class LazyRegex.

    Because __setstate__ sets the object member directly, it's hard to test the
    output of the method by calling the method itself. So we call method
    __getstate__ to get the object state, and make sure the object state is
    expected.
    """
    from bzrlib.lazy_regex import LazyRegex
    regex = LazyRegex(args=('abc',), kwargs={'flags':re.I})
    regex_state = regex.__getstate__()
    assert regex_state == {
        "args": ('abc',),
        "kwargs": {'flags':re.I},
        }

# Generated at 2022-06-24 02:43:26.284501
# Unit test for function lazy_compile
def test_lazy_compile():
    # Note: it's not worth making this a mutable test, because to actually
    # check anything it would have to capture the output of re.compile, which
    # requires changing or replacing re.compile, which is going to happen
    # anyway if we use lazy_compile

    # But it is worth making it an external test so it runs after the
    # lazy_compile has been installed:
    import unittest

    class TestLazyCompile(unittest.TestCase):

        def test_lazy_compile(self):
            lr = lazy_compile('foo')
            self.assertEqual(lr.pattern, 'foo')
            self.assertEqual(lr.flags, 0)
            self.assertEqual(lr.groups, 0)
            self.assertEqual(lr.groupindex, {})

# Generated at 2022-06-24 02:43:31.196509
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests.blackbox import TestCaseWithTransport
    import re


# Generated at 2022-06-24 02:43:40.271207
# Unit test for function reset_compile
def test_reset_compile():
    """Ensure reset_compile restores the original compile function."""
    install_lazy_compile()
    regex = re.compile('(?P<foo>.*)')
    reset_compile()
    assert regex._real_regex is None
    regex = re.compile('(?P<foo>.*)')
    assert regex.match('foo') is not None
    assert regex._real_regex is not None
    assert regex.match('foo').groupdict()['foo'] == 'foo'

    # Check that things are still working
    regex = re.compile('(?P<foo>.*)')
    assert regex.match('foo') is not None

    # And still working after we replace it again:
    install_lazy_compile()

# Generated at 2022-06-24 02:43:52.116068
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    import sys
    def _to_unicode(s):
        """Convert bytes to unicode in python2, str to unicode in python3"""
        if sys.version_info[0] == 2 and isinstance(s, str):
            return s.decode('ascii')
        # python3, just make sure we have a unicode object
        return unicode(s)
    x = InvalidPattern('test')
    # check if the unicode string can be converted back to str
    str(x)
    # check the unicode string
    x_unicode = x.__unicode__()
    assert isinstance(x_unicode, unicode)
    assert x_unicode == _to_unicode(u'Invalid pattern(s) found. test')
    x

# Generated at 2022-06-24 02:43:59.073942
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # This test checks that the method __getstate__ of class LazyRegex
    # returns a constant dictionary to be used when the object is
    # pickled.
    lazy_obj = lazy_compile('(?P<name>[a-z]+)')
    first_state = lazy_obj.__getstate__()
    second_state = lazy_obj.__getstate__()
    assert first_state is second_state
    assert first_state == { 'args': ('(?P<name>[a-z]+)',), 'kwargs': {} }

# Generated at 2022-06-24 02:44:06.105679
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for the InvalidPattern.__unicode__() method.

    This method should return a unicode object.
    """
    statement = 'lalala'
    e = InvalidPattern(statement)
    u = unicode(e)
    assert isinstance(u, unicode)
    assert statement in u

# Generated at 2022-06-24 02:44:13.686032
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() sets re.compile back to its original value"""
    install_lazy_compile()
    re.compile = "something else"
    assert re.compile is not lazy_compile
    reset_compile()
    assert re.compile is not lazy_compile
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:44:16.790370
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ex = InvalidPattern('Invalid regex')
    assert ex.msg == 'Invalid regex'
    assert ex.__str__() == 'Invalid pattern(s) found. Invalid regex'
    assert str(ex) == 'Invalid pattern(s) found. Invalid regex'

# Generated at 2022-06-24 02:44:27.032867
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test to verify method InvalidPattern.__unicode__()

    Unicode strings should be returned from this method.
    """
    from bzrlib.i18n import gettext
    msg = gettext('Some unicode message')
    ex = InvalidPattern(msg)
    result = unicode(ex)
    if not isinstance(result, unicode):
        raise AssertionError('Expected a unicode object but got a %s object'
                             % type(result))
    if result != msg:
        raise AssertionError('Expected "%s" but got "%s"' % (msg, result))

test_suite = getattr(__import__(__name__), 'test_suite')

# Generated at 2022-06-24 02:44:36.351020
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ must compare all attributes."""
    class MyInvalidPattern(InvalidPattern):
        """A class with additional attributes."""
        __slots__ = ['_fmt', 'a', 'b']
        _fmt = 'MyInvalidPattern'

    i1 = MyInvalidPattern('1')
    i2 = MyInvalidPattern('2')
    i3 = MyInvalidPattern('1')
    i3.a = 1
    i3.b = 2
    i4 = MyInvalidPattern('1')
    i4.a = 1
    i4.b = 3
    i5 = MyInvalidPattern('1')
    i5.a = 3
    i5.b = 2
    i6 = MyInvalidPattern('1')
    i6.a = 3
    i6.b = 3

    # all attributes must have the same

# Generated at 2022-06-24 02:44:39.902155
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import re
    regex = LazyRegex(args=('foo.*', re.I, re.X))
    assert not hasattr(regex, '_real_regex')
    assert regex._regex_args == ('foo.*', re.I, re.X)
    assert regex._regex_kwargs == {}

# Generated at 2022-06-24 02:44:47.192661
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function works."""
    # we need to make sure that re.compile is lazy_compile and not
    # the original re.compile
    install_lazy_compile()
    try:
        lazy_pattern = lazy_compile("foo", re.IGNORECASE)
        assert isinstance(lazy_pattern, LazyRegex)

        # Make sure the compiled regex is actually useful
        match1 = lazy_pattern.match("FOO")
        assert match1.group() == "FOO"
        match2 = lazy_pattern.match("foo")
        assert match2.group() == "foo"
        match3 = lazy_pattern.match("bar")
        assert match3 is None
    finally:
        reset_compile()
    # Check that we don't get recursion when re-

# Generated at 2022-06-24 02:44:52.460641
# Unit test for function reset_compile
def test_reset_compile():
    # Precondition
    assert re.compile != lazy_compile
    install_lazy_compile()
    assert re.compile == lazy_compile
    # Test
    re.compile = 'foobar'
    reset_compile()
    assert re.compile != 'foobar'
    assert re.compile == _real_re_compile

# Generated at 2022-06-24 02:44:53.982501
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    return doctest.DocTestSuite(setUp=install_lazy_compile)

# Generated at 2022-06-24 02:45:00.918412
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Check that the LazyRegex constructor works as expected."""
    lazy = LazyRegex(('^(\\w+)', ), {'flags': re.MULTILINE})
    assert lazy._regex_args == ('^(\\w+)', )
    assert lazy._regex_kwargs == {'flags': re.MULTILINE}



# Generated at 2022-06-24 02:45:02.818107
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib import tests
    from bzrlib.tests import test_regex
    test_suite = tests.TestUtil.load_tests(test_regex)
    reset_compile()



# Generated at 2022-06-24 02:45:07.849032
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    from bzrlib import tests
    # TODO: Take this test out, as it is testing Bazaar internals
    tests.SymlinkFeature.known_failure('This test is testing Bazaar internals.')
    doctest.testmod(re, optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 02:45:17.495882
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    class A(Exception):
        _fmt = 'a'
    class B(A):
        _fmt = 'b'
    class C(B):
        _fmt = 'c'
    class D(B):
        _preformatted_string = 'd'
    class E(B):
        _fmt = 'e'
        def _format(self):
            return super(E, self)._format() + 'x'
    class F(B):
        def _get_format_string(self):
            return None
    class G(B):
        _fmt = 'g'
        def _get_format_string(self):
            return None

# Generated at 2022-06-24 02:45:22.320658
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    x = LazyRegex((r'?', re.VERBOSE))
    assert x._real_regex is None
    assert len(x._regex_args) == 2
    assert x._regex_args[0] == r'?'
    assert x._regex_args[1] == re.VERBOSE
    assert len(x._regex_kwargs) == 0


# Generated at 2022-06-24 02:45:30.826167
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    try:
        LazyRegex(re.compile('(?P<a>a)(?P<b>b)'))
    except ValueError:
        pass
    else:
        raise AssertionError
    regex = LazyRegex(['(?P<a>a)(?P<b>b)'])
    regex._compile_and_collapse()
    regex = LazyRegex(['(?P<a>a)(?P<b>b)'], {'flags': re.I})
    regex._compile_and_collapse()
    try:
        LazyRegex(['(?P<a>a)(?P<b>b)'], {'flags': 99})
    except ValueError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-24 02:45:40.190586
# Unit test for function finditer_public
def test_finditer_public():
    """Test function re.finditer.

    It does not test the behavior with flags, as re.finditer is only called with
    flags=0 currently.
    """
    class CheckFinditer(object):
        def __init__(self):
            self.asserts = []
        def __call__(self, pattern, string, flags=0):
            self.asserts.append((pattern, string, flags))

    re.finditer = CheckFinditer()
    lazy = lazy_compile('a')
    re.finditer(lazy, 'abc')
    re.finditer(lazy, 'ab\n\n')
    re.finditer('a', lazy)
    re.finditer('a', 'ab\n\n')
    re.finditer('a', 'a')

# Generated at 2022-06-24 02:45:48.480586
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib._lazy_re import LazyRegex, finditer_public
    test_pattern = LazyRegex(['a'])
    test_string = 'abc'
    iter_test = finditer_public(test_pattern, test_string)
    # get iterator
    it = iter(iter_test)
    # get first element
    first_el = it.next()
    # check
    assert first_el.group() == 'a'
    #not sure how to check the following line. Following line not implemented
    #in python 2.6
    #assert first_el.span() == (0, 1)
    # get remaining elements
    rem_el = it
    # check
    #print rem_el

# Generated at 2022-06-24 02:45:50.868615
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method InvalidPattern.__repr__"""
    msg = "some problem"
    a = InvalidPattern(msg)
    assert a.__repr__() == 'InvalidPattern(%s)' % msg, "Unexpected repr()"

# Generated at 2022-06-24 02:45:59.517040
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    pattern = "bzr"                                             # pattern
    flags = re.IGNORECASE                                       # flags
    proxy = LazyRegex(args=(pattern, flags))                    # proxy
    state = proxy.__getstate__()                                # state
    args = state["args"]                                        # args
    kwargs = state["kwargs"]                                    # kwargs
    args_expected = (pattern, flags)                            # args_expected
    kwargs_expected = {}                                        # kwargs_expected
    assert args == args_expected                                # args == args_expected
    assert kwargs == kwargs_expected                            # kwargs == kwargs_expected

# Generated at 2022-06-24 02:46:03.064701
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() works as expected."""
    install_lazy_compile()
    proxy = re.compile("^foo$")
    assert proxy is not None
    assert isinstance(proxy, LazyRegex)
    reset_compile()

# Generated at 2022-06-24 02:46:13.978959
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Testing method __getattr__ of class LazyRegex.

    This test checks, method __getattr__ of class LazyRegex does not raise
    any exception, if exception occurs, it will be handled by
    test_lazy_pattern.
    """
    lazy_regex = LazyRegex((r'^', re.M))

# Generated at 2022-06-24 02:46:16.246064
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    re.compile = _real_re_compile
    install_lazy_compile()
    try:
        pattern = re.compile(r".")
        assert pattern.findall("a") == ["a"]
    finally:
        reset_compile()

# Generated at 2022-06-24 02:46:18.864734
# Unit test for function reset_compile
def test_reset_compile():
    """Test will fail if the restore function doesn't work"""
    import re
    re.compile('foo')
    install_lazy_compile()
    re.compile('foo')
    reset_compile()
    re.compile('foo')

# Generated at 2022-06-24 02:46:23.087786
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = lambda *args: 42
    reset_compile()
    assert re.compile('.', re.I).search('foo')

# Generated at 2022-06-24 02:46:32.424436
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should return a unicode object"""
    import bzrlib.tests
    from bzrlib.i18n import gettext

    def _check_unicode(expected, error):
        error.msg = 'Internal error'
        # __str__ is expected to return a 'str' object
        s = str(error)
        e = 'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r' \
            % (error.__dict__, None, expected)
        # verify that the string matches what is expected
        bzrlib.tests.TestCase.assertEqual(s, e)
        # __str__ must return a 'str' object
        self.assertIsInstance(s, str)

        # __unicode__ is expected to return a 'unicode' object

# Generated at 2022-06-24 02:46:38.718685
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string."""
    msg = 'the error message'
    err = InvalidPattern(msg)
    result = str(err)
    # The result should be a string
    assert isinstance(result, str)
    # A sample of the result
    assert result.startswith('InvalidPattern(')
    assert result.endswith(')')
    # The result should contain the message
    assert result.find(msg) != -1

# Generated at 2022-06-24 02:46:40.309910
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string with the exception name and args"""
    e = InvalidPattern('')
    assert repr(e) == "InvalidPattern('')", repr(e)

# Generated at 2022-06-24 02:46:47.082340
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy = LazyRegex(('^http.*',), {'flags':re.I})
    assert lazy._regex_args == ('^http.*',)
    assert lazy._regex_kwargs == {'flags':re.I}
    assert lazy._real_regex is None

# Generated at 2022-06-24 02:46:57.632937
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    re.compile = _real_re_compile
    t1 = re.compile('[\w]+')
    t2 = re.compile('[\w]+', re.I)
    re.compile = lazy_compile
    l1 = LazyRegex(['[\w]+'], {})
    l2 = LazyRegex(['[\w]+'], {'flags': re.I})
    re.compile = _real_re_compile
    assert type(t1) == type(l1._real_regex)
    assert type(t2) == type(l2._real_regex)

# Generated at 2022-06-24 02:47:05.237592
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test unicode() of InvalidPattern."""
    # default format
    err = InvalidPattern('test')
    u = str(err)
    assert isinstance(u, unicode)
    assert u == 'Invalid pattern(s) found. test'

    # format with values
    err = InvalidPattern('%s %s')
    err._fmt = 'test %s %s'
    err.arg1 = 'arg1'
    err.arg2 = 'arg2'
    u = unicode(err)
    assert isinstance(u, unicode)
    assert u == 'test arg1 arg2'
    s = str(err)
    assert isinstance(s, str)
    assert s == 'test arg1 arg2'

    # test with '%s' in the error message. It is not a value placeholder,
    #

# Generated at 2022-06-24 02:47:15.486517
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # Use a dummy value for 'msg' that is a fixed value for the test.
    # And also ensure that msg is different from the value used in the
    # __unicode__ method.
    from bzrlib.i18n import gettext
    e = InvalidPattern('123')
    e.msg = gettext('dummy')
    e2 = InvalidPattern('123')
    e2.msg = gettext('dummy')
    assert e == e2
    e2 = InvalidPattern('123')
    e2.msg = gettext('dummy2')
    assert e != e2
    e2 = InvalidPattern('124')
    e2.msg = gettext('dummy')
    assert e != e2
    assert e != 1
    assert e != '123'

# Generated at 2022-06-24 02:47:24.875470
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex will compile in its __getattr__ method"""
    from bzrlib import osutils
    from bzrlib.tests.per_repository_reference import TestCaseWithRepository
    from bzrlib.tests import (
        features,
        test_repository,
        )

    class TestCase(TestCaseWithRepository):

        def test_getattr(self):
            repo = self.make_repository('.')
            tree = repo.revision_tree(repo.get_revision(None))
            tree.lock_read()
            self.addCleanup(tree.unlock)
            tree.lock_read()
            self.addCleanup(tree.unlock)
            # Go though osutils.pipeline_delete to force a lazy_compile to
            # happen

# Generated at 2022-06-24 02:47:31.873925
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """The '_real_regex' attribute of a LazyRegex object should be computed in
    the first call to __getattr__
    """
    l = LazyRegex(r'(a)(b)(c)')
    assert l._real_regex is None
    assert l.findall('abbc') == [('a', 'b', 'c')]
    assert l._real_regex is not None
    assert l.findall('abbc') == [('a', 'b', 'c')]
    assert l._real_regex is not None


# Generated at 2022-06-24 02:47:43.066331
# Unit test for function finditer_public
def test_finditer_public():
    lazy_regex = lazy_compile('[a-z]+[A-Z]+[0-9]+')
    tested_string = 'hueHUE1'
    iterator = finditer_public(lazy_regex, tested_string)
    assert iterator.next().group() == 'hueHUE1'
    try:
        iterator.next()
        assert False
    except StopIteration:
        pass


# Some libraries calls re.search which fails it if receives a LazyRegex.
if getattr(re, 'search', False):
    def search_public(pattern, string, flags=0):
        if isinstance(pattern, LazyRegex):
            return pattern.search(string)
        else:
            return _real_re_compile(pattern, flags).search(string)
    re.search = search

# Generated at 2022-06-24 02:47:49.793547
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ should return the state to use when pickling."""
    old_compile = re.compile
    try:
        re.compile = LazyRegex
        # Test with an uninitialized LazyRegex
        regex = re.compile('l((a)+)')
        state = regex.__getstate__()
        # Test with an initialized LazyRegex
        regex = re.compile('l((a)+)')
        regex._compile_and_collapse()
        state = regex.__getstate__()
    finally:
        re.compile = old_compile


# Generated at 2022-06-24 02:47:54.682262
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    r1 = re.compile('(a|b)+')
    s1 = r1.__getstate__()
    r2 = LazyRegex()
    r2.__setstate__(s1)
    s2 = r2.__getstate__()
    assert s1 == s2



# Generated at 2022-06-24 02:48:04.505363
# Unit test for function reset_compile
def test_reset_compile():
    import sys
    from bzrlib.tests import TestCase
    from bzrlib import osutils

    class TestResetCompile(TestCase):

        def test_reset_safe_to_call_twice(self):
            if sys.version_info >= (2, 5):
                # this test doesn't apply to Python >= 2.5
                return
            try:
                import regex # Pyrex implementation of regex not supported
            except ImportError:
                # regex module not installed, is optional.
                return
            orig_compile = regex.compile
            regex.compile = lambda x:x
            try:
                reset_compile()
                reset_compile()
            finally:
                regex.compile = orig_compile


# Generated at 2022-06-24 02:48:16.573447
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test the class InvalidPattern behave well in various cases

    Test:
     - preformatted message
     - i18n message
     - unicode

    Ensure that we get valid string no matter the type of message
    """
    preformatted_msg = "A preformatted message"
    i18n_msg = "A non-preformatted message"
    unicode_charset = "utf-8"
    e = InvalidPattern(preformatted_msg)
    assert e.msg == preformatted_msg
    assert e._get_format_string() is None # do not format
    assert unicode(e) == preformatted_msg
    assert str(e) == preformatted_msg

    e = InvalidPattern(i18n_msg)
    assert e.msg == i18n_msg
    assert e._get_

# Generated at 2022-06-24 02:48:27.351530
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should return the same value as __dict__"""
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'dict=%(dict)s'
    ip1 = MyInvalidPattern('some message')
    ip1.dict = {'foo': 'bar'}
    ip2 = MyInvalidPattern('some message')
    ip2.dict = {'foo': 'bar'}
    # objects are equal by values
    assert ip1 == ip2
    # different message
    assert ip1 != MyInvalidPattern('another message')
    # another InvalidPattern, but same message
    assert ip1 != InvalidPattern('some message')
    # same InvalidPattern, but no message
    assert ip1 != InvalidPattern()



# Generated at 2022-06-24 02:48:30.925575
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    lazy_re = LazyRegex("[0-9]+", re.VERBOSE)
    state = lazy_re.__getstate__()
    assert state == {"args": ("[0-9]+", re.VERBOSE), "kwargs": {}}



# Generated at 2022-06-24 02:48:41.834861
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    from bzrlib.tests import TestCase

    class TestInstallLazyCompile(TestCase):

        def test_install_lazy_compile(self):
            """Ensure that install_lazy_compile() works correctly."""
            self.assertIsNot(re.compile, lazy_compile)
            install_lazy_compile()
            self.assertIs(re.compile, lazy_compile)
            reset_compile()
            self.assertIsNot(re.compile, lazy_compile)

        def test_lazy_compile(self):
            """Ensure that lazy_compile() works correctly."""
            # The proxy object must be callable to be compatible with the
            # re.compile interface
            proxy = lazy_compile('a')
            self.assertIs

# Generated at 2022-06-24 02:48:44.565288
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    s = "foo"
    re.compile(s)
    install_lazy_compile()
    re.compile(s)
    reset_compile()
    re.compile(s)

# Generated at 2022-06-24 02:48:55.387974
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    import re
    # format string with no parameters
    ip = InvalidPattern('this is a test')
    assert ip.__str__() == 'this is a test'
    # format string with some parameters
    ip = InvalidPattern('"%(msg)s"')
    ip.msg = 'another test'
    assert ip.__str__() == '"another test"'
    # format string with non-string parameter
    ip = InvalidPattern('"%(code)s"')
    ip.code = 42
    # s/__str__/__repr__/ because there is a __str__ override in class exceptions
    assert ip.__repr__() == '"42"'
    # format string with a unicode parameter
    ip = InvalidPattern('"%(msg)s"')


# Generated at 2022-06-24 02:49:04.885509
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_errors import TestCaseWithFilteredLogStream

    class TestInvalidPattern__eq__(TestCaseWithFilteredLogStream):

        def test__eq__(self):
            # Check that InvalidPattern objects are correctly compared for
            # equality.
            builder = self.make_branch_builder('a')
            builder.start_series()
            builder.build_snapshot('a', None,
                [('add', ('', 'root-id', 'directory', ''))])
            rev1 = builder.finish_series()
            builder.start_series()
            builder.build_snapshot('a', [rev1],
                [('modify', ('', 'root-id', 'directory', ''))])
            revision_id = builder.finish_series

# Generated at 2022-06-24 02:49:11.351759
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Check that the format string is accepted by the format operator."""
    import StringIO
    sio = StringIO.StringIO()


# Generated at 2022-06-24 02:49:21.715634
# Unit test for function reset_compile
def test_reset_compile():
    old_re_compile = re.compile
    try:
        def do_test(**kwargs):
            re.compile = lazy_compile
            reset_compile()
            old_re_compile(**kwargs)
            install_lazy_compile()
            re.compile(**kwargs)
            reset_compile()
            re.compile(**kwargs)
        do_test(**{'pattern': '.*', 'flags': 0})
        do_test(**{'pattern': '.*'})
        do_test()
    finally:
        re.compile = old_re_compile

# Generated at 2022-06-24 02:49:24.230638
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the lazy_compile routine actually works."""
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-24 02:49:27.892005
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test restoring from a pickled state.

    Test to be sure __setstate__ doesn't generate exception. The only but is
    that this test is a little entangled with the previous tests.
    """
    lazy_regex = LazyRegex()
    lazy_regex.__setstate__(lazy_regex.__getstate__())

# Generated at 2022-06-24 02:49:36.197893
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() actually restores the original compile()."""
    global _real_re_compile
    try:
        install_lazy_compile()
    except Exception:
        pass
    else:
        raise Exception('Lazy regexs should not be installed by default')
    reset_compile()
    try:
        install_lazy_compile()
    except Exception:
        raise Exception('Lazy regexs were not installed')
    try:
        reset_compile()
    except Exception:
        raise Exception('reset_compile failed')



# Generated at 2022-06-24 02:49:41.725620
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test the constructor of InvalidPattern"""
    test_str = 'test string'
    e = InvalidPattern(test_str)
    assert e.msg == test_str
    # make sure the message gets formatted
    assert str(e) == InvalidPattern._fmt % {'msg': test_str}

# Generated at 2022-06-24 02:49:44.116704
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    obj = LazyRegex(('foo',))
    assert isinstance(obj, LazyRegex)


# Generated at 2022-06-24 02:49:47.183537
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from doctest import DocTestSuite
    return DocTestSuite()

# Generated at 2022-06-24 02:49:50.509415
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return the same thing as str()."""
    msg = "File not found"
    e1 = InvalidPattern(msg)
    assert_equal(repr(e1), str(e1))


# Generated at 2022-06-24 02:49:52.311229
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern"""
    pattern = InvalidPattern('blah')
    assert(repr(pattern) == "InvalidPattern('blah')")

# Generated at 2022-06-24 02:50:01.162977
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method InvalidPattern.__unicode__"""
    msg = 'Some message with unicode (\xf4) and \\ escape chars'
    exc = InvalidPattern(msg)
    u = unicode(exc)
    # verify that given message is preserved
    if msg != u:
        raise AssertionError("Message differs, expected '%s' got '%s'" \
                % (msg, u))
    # verify that no strange characters are included in the result
    if '?' in u:
        raise AssertionError("Message contains '?', got '%s'" % u)

# Generated at 2022-06-24 02:50:09.610140
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # Empty exception
    e = InvalidPattern("")
    assert e.__repr__() == 'InvalidPattern("")'
    # Exception with message
    e = InvalidPattern("Error message")
    assert e.__repr__() == 'InvalidPattern("Error message")'
    # Exception with non ascii characters (with utf8 encoding)
    e = InvalidPattern("Error 'message' with non ASCII characters")
    assert e.__repr__() == "InvalidPattern(\"Error 'message' with non ASCII characters\")"

# Generated at 2022-06-24 02:50:19.174421
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Ensure InvalidPattern.__repr__ doesn't raise."""
    import bzrlib.regex
    bzrlib.regex.InvalidPattern('foo').__repr__()


# We run the unit tests in this module when it is run as main.
if __name__ == '__main__':
    import sys, unittest
    from . import test_regex

    def load_tests(loader, basic_tests, pattern):
        return test_regex.load_tests(loader, basic_tests, pattern)

    # update_defaults is used when testing doctests. If we aren't testing
    # doctests, it will be None.
    update_defaults = getattr(sys.modules['__main__'], 'update_defaults', None)
    if update_defaults is not None:
        update_

# Generated at 2022-06-24 02:50:22.331113
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Check that a simple __repr__ of InvalidPattern works"""
    msg = 'Error: invalid pattern.'
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        repr(e)

        # And that repr(unicode(e)) works
        repr(unicode(e))

        # And that repr(str(e)) works
        repr(str(e))



# Generated at 2022-06-24 02:50:26.793760
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern"""

# Generated at 2022-06-24 02:50:28.661388
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import doctest
    from bzrlib.errors import InvalidPattern
    doctest.testmod(InvalidPattern)

# Generated at 2022-06-24 02:50:31.974411
# Unit test for function finditer_public
def test_finditer_public():
    """test_finditer_public: re.finditer(LazyRegex) should work."""
    re.finditer(LazyRegex(['abc']), 'abc')

# Generated at 2022-06-24 02:50:35.835481
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ must return unicode object"""
    ex = InvalidPattern(msg='foo')
    assert isinstance(unicode(ex), unicode)


# Generated at 2022-06-24 02:50:46.214295
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    class TestInvalidPattern___str__(TestCase):
        def test___str__(self):
            import string
            import random
            # test str(e) is a str object
            e = InvalidPattern('error')
            self.assertIsInstance(str(e), str)
            # test str(e) is a utf-8 encoded str if u'error' is used
            e = InvalidPattern(u'error')
            self.assertEqual(str(e), 'error')
            # test the encoding is preserved
            # the str to encode will be picked from 'string.printable'
            s = [c for c in string.printable if ord(c) < 128]
            # the str will be generated by random.sample()

# Generated at 2022-06-24 02:50:57.690476
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    import re
    import traceback
    from bzrlib import osutils
    from bzrlib.osutils import filesdiff

    def _test_LazyRegex():
        from bzrlib.lazy_regex import LazyRegex
        from bzrlib import osutils
        from bzrlib.osutils import filesdiff

        # test case 1
        lr = LazyRegex(('a[a-z]',))
        r = re.compile('a[a-z]')
        s = 'abc'
        m = lr.search(s)
        msg = 'pattern=%r, string=%r, flags=%r' % (lr.pattern, s, lr.flags)
        m1 = r.search(s)
        assert m == m1, msg

        # test

# Generated at 2022-06-24 02:51:01.767408
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for method __getstate__ of class LazyRegex."""
    x = LazyRegex(('a',),{})
    state = x.__getstate__()
    if state["args"] != ('a',) or state["kwargs"] != {}:
        raise AssertionError


# Generated at 2022-06-24 02:51:06.373580
# Unit test for function reset_compile
def test_reset_compile():
    original_compile = re.compile
    try:
        re.compile = "Something completely different"
        reset_compile()
        # If the test passes, reset_compile() will have restored the original value
        if re.compile is not original_compile:
            raise AssertionError("reset_compile did not restore re.compile() to the original value")
    finally:
        re.compile = original_compile

# Generated at 2022-06-24 02:51:11.910971
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test equality of InvalidPatterns"""
    import copy
    msg = "some msg"
    p1 = InvalidPattern(msg)

    # same object
    p2 = p1
    assert p1 == p2

    # equal object
    p2 = InvalidPattern(msg)
    assert p1 == p2

    # object with different message
    p2 = InvalidPattern("something else")
    assert not p1 == p2

    # different class
    p2 = ValueError(msg)
    assert not p1 == p2

    # no __eq__ method (note: none of the other comparisons such as <, > etc
    # are defined
    p2 = copy.copy(p1)
    del p2.__eq__
    assert not p1 == p2

    # other is not an object
    assert not p1 == None

# Generated at 2022-06-24 02:51:17.222615
# Unit test for function reset_compile
def test_reset_compile():
    real_compile = re.compile

    re.compile = fake = object()
    try:
        reset_compile()
        assert real_compile is re.compile
    finally:
        re.compile = real_compile


# Test suite for the LazyRegex objects themselves.

# Generated at 2022-06-24 02:51:24.133357
# Unit test for function lazy_compile
def test_lazy_compile():
    # Some regexs are "lazy" in the sense that they are only used
    # in error conditions and should never be reached.
    try:
        lazy_compile("*")
    except re.error:
        pass
    install_lazy_compile()
    try:
        lazy_compile("*")
    except re.error:
        pass
    reset_compile()


# Generated at 2022-06-24 02:51:31.688759
# Unit test for function finditer_public
def test_finditer_public():
    """Some libraries call re.finditer which fails it if receives a LazyRegex.

    If a LazyRegex is used in re.finditer, finditer_public should use the
    finditer method of LazyRegex instead of re.finditer.
    """
    from bzrlib import tests
    import re
    test_regex = re.compile('hello (world)')
    test_lazy_regex = LazyRegex(('hello (world)',))
    test_string = 'hello world'
    # A list of tuples. First item is a regex and second the string used in
    # re.finditer. Both should return the same result.

# Generated at 2022-06-24 02:51:35.452411
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return str(self)"""
    obj = InvalidPattern("some random error")
    assert str(obj) == repr(obj)

# Generated at 2022-06-24 02:51:41.703009
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestCase
    class TestReset(TestCase):
        def test_reset(self):
            """reset_compile resets the compile function to the original one"""
            self.assertEquals(_real_re_compile, re.compile)
            install_lazy_compile()
            self.assertNotEquals(_real_re_compile, re.compile)
            reset_compile()
            self.assertEquals(_real_re_compile, re.compile)

# Generated at 2022-06-24 02:51:50.594558
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # equality case
    x = InvalidPattern('abc')
    y = InvalidPattern('abc')
    e = x == y
    assert e

    # not equal case
    x = InvalidPattern('abc')
    y = InvalidPattern('xyz')
    e = x == y
    assert not e

    # Reference
    x = InvalidPattern('abc')
    y = x
    e = x == y
    # Python 2.6.5's object.__eq__() raises TypeError on an object being
    # compared with itself. We try to be more robust.
    assert e


# Generated at 2022-06-24 02:51:58.200415
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    l = LazyRegex('^branch ', re.IGNORECASE)
    l._compile_and_collapse()
    m = l.search('Branch')
    eq = [m.start(), m.end()]
    eq = [(0, 7)]
    eq = [((0, 7),)]
    eq = [(0, 7)]
    eq = [((0, 0),)]
    eq = [((0, 0),)]
    eq = [((0, 0),)]
    eq = [((0, 0),)]
    eq = [((0, 0),)]
    eq = [((0, 0),)]
    eq = ['']

# Generated at 2022-06-24 02:52:07.216283
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern."""

    # Test unicode implementation.
    e = InvalidPattern(u'\xb5')
    assert isinstance(unicode(e), unicode)
    # Cannot use u'\xb5' here because it would be translated to
    # latin1 which would fail the test
    assert unicode(e) == u'Invalid pattern(s) found. \xb5'

    # Test that it handles a preformatted message
    e = InvalidPattern('Unicode \xb5')
    e._preformatted_string = unicode(e)
    assert unicode(e) == u'Invalid pattern(s) found. Unicode \xb5'

    # Test str implementation.
    e = InvalidPattern(u'\xb5')
    assert isinstance(str(e), str)


# Generated at 2022-06-24 02:52:14.120190
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # we need a real regex for method __getstate__
    _real_regex = re.compile('abc')
    class LazyRegexTest(LazyRegex):
        '''A simple subclass of LazyRegex to test method __getattr__'''
        def __init__(self, real_regex):
            LazyRegex.__init__(self)
            self._real_regex = real_regex

        def _compile_and_collapse(self):
            pass

    proxy = LazyRegexTest(_real_regex)
    assert proxy.pattern == 'abc'


# Generated at 2022-06-24 02:52:20.220202
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex __getattr__ does not return the attributes of a proxy object.

    It returns the attributes of the real regex object instead.
    """
    # Setup
    regex = LazyRegex(('^pattern$',))
    # Action
    flags = regex.flags
    # Verify
    # As the whole test suite is run with -O, the flags of the real regex object
    # are 0, not re.IGNORECASE.
    assert flags == 0, "LazyRegex.flags is not the flags of the real regex."



# Generated at 2022-06-24 02:52:29.036564
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile mostly emulates the usual re.compile"""
    re.compile = _real_re_compile
    # Test the basics of compiling and not compiling
    test_compile = lazy_compile("some pattern")
    assert test_compile is not None
    assert test_compile._real_regex is None
    found_match = test_compile.match("some string")
    assert found_match is not None
    assert test_compile._real_regex is not None

    # Test pickling
    from cPickle import loads, dumps
    test_compile = lazy_compile("some pattern")
    assert test_compile is not None
    assert test_compile._real_regex is None
    pickled = dumps(test_compile)

# Generated at 2022-06-24 02:52:34.029914
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of class InvalidPattern"""
    try:
        raise InvalidPattern('msg')
    except Exception as e:
        pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:52:42.631188
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    def _assert_string(expected, ip):
        """Assert that expected == str(ip) for test purpose"""
        result = str(ip)
        if expected != result:
            from bzrlib.tests import TestUtil
            TestUtil.raise_warn(
                'expected: %r\nactual: %r' % (expected, result))

    obj = InvalidPattern('a\nb')
    _assert_string('Invalid pattern(s) found. a\\nb', obj)

    # test for bug #993083
    #     UnicodeDecodeError: 'ascii' codec can't decode byte 0xe2 in position
    #     1: ordinal not in range(128)

# Generated at 2022-06-24 02:52:50.441836
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should restore from a pickled state.

    This test case is separated from test_regex because we don't want a full
    test suite to be run each time we just wanted to test a LazyRegex instance
    restored from a pickled state.
    """
    import pickle
    # create a LazyRegex instance with normal re.compile as default
    lazyre = LazyRegex(args=("^bazaar$",), kwargs={"flags": re.IGNORECASE})
    # create a pickled instance from lazyre
    pickled = pickle.dumps(lazyre)
    # restore from pickled instance
    lazyre2 = pickle.loads(pickled)
    # we should be able to use re.findall with the pickled instance
    # as by default re

# Generated at 2022-06-24 02:52:55.130055
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Assert that __unicode__ of InvalidPattern instances is sane."""
    value = InvalidPattern('foo bar')
    result = unicode(value)
    # result is a unicode object
    assert(isinstance(result, unicode))
    # result is what we expect.
    assert(result == u'foo bar')

# Generated at 2022-06-24 02:52:58.034679
# Unit test for function finditer_public
def test_finditer_public():
    # finditer_public should return a generator
    r = re.compile('.')
    g = finditer_public(r, 'aa')
    assert isinstance(g, types.GeneratorType)

# Generated at 2022-06-24 02:53:09.651043
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test install_lazy_compile() and reset_compile()."""
    import re
    # putting this here because it might have been overridden.
    global _real_re_compile
    original_real_compile = _real_re_compile
    # Create a proxy object which won't be compiled until accessed.
    install_lazy_compile()
    lazy_regex = re.compile("foo")
    # Calling re.compile() should return a LazyRegex object.
    assert isinstance(lazy_regex, LazyRegex)
    # Now restore the original re.compile().
    reset_compile()
    # Check that re.compile() has been restored.
    assert re.compile is original_real_compile
    # Check that the proxy object still works.