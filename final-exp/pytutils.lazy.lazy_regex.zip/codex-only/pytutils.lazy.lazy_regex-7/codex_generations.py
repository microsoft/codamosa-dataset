

# Generated at 2022-06-24 02:43:13.114169
# Unit test for function finditer_public
def test_finditer_public():
    # This is not suppose to work because of isinstance(pattern, LazyRegex)
    # return pattern.finditer(string)
    # But it works, it was a problem with the way I was testing it.
    # The if is never executed.
    s = "this is some text"
    # Here pattern is an object of type LazyRegex
    pattern = LazyRegex(['text'])
    for m in finditer_public(pattern, s):
        # Here we are calling the method finditer from the class LazyRegex.
        # The only way to test this is to modify LazyRegex.finditer and
        # add some print statemets
        pass

# Generated at 2022-06-24 02:43:17.760176
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    re_args = ('s', )
    re_kwargs = {'i': 1, 'l': 2}
    regex = LazyRegex(re_args, re_kwargs)
    state = regex.__getstate__()
    assert state == {'args': re_args, 'kwargs': re_kwargs}, \
        '__getstate__ does not return the correct dictionary'

# Generated at 2022-06-24 02:43:27.795342
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    import sys
    import traceback

    re.compile = None
    install_lazy_compile()
    if re.compile is not lazy_compile:
        if sys.exc_info()[0]:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            # exc_traceback (a traceback object) contains the call stack
            traceback.print_tb(exc_traceback)
        raise AssertionError(
            "install_lazy_compile didn't work, re.compile is not lazy_compile")



# Generated at 2022-06-24 02:43:36.205039
# Unit test for function reset_compile
def test_reset_compile():
    # Test that re.compile still works but returns LazyRegex objects
    import re
    really_a_regex = re.compile('.')
    msg = "really_a_regex should be a LazyRegex not %s" % type(really_a_regex)
    assert isinstance(really_a_regex, LazyRegex), msg
    reset_compile()
    # Test that re.compile still works and returns _sre.SRE_Pattern objects
    really_a_regex_2 = re.compile('.')
    assert isinstance(really_a_regex_2, re._pattern_type), \
        "really_a_regex_2 should be a _sre.SRE_Pattern not %s" % (
            type(really_a_regex_2))


# Generated at 2022-06-24 02:43:42.395295
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""

    msg = u'It did not work'
    error = InvalidPattern(msg)
    assert str(error) == msg, 'InvalidPattern.__str__ is broken'



# Generated at 2022-06-24 02:43:52.744684
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the private method __setstate__ of LazyRegex.

    This test can only be used with lazy evaluation for re.compile, hence it is
    not run by default.
    """
    import StringIO
    import pickle

    # We don't want to actually compile the regexes, so we stub out both
    # compile and finditer
    compiled = False
    pattern_list = []

    def stubbed_re_compile(pattern, flags=0):
        compiled = True
        pattern_list.append(pattern)
        return pattern

    def stubbed_finditer(pattern, string, flags=0):
        if isinstance(pattern, LazyRegex):
            raise AssertionError("finditer should not have been called")

# Generated at 2022-06-24 02:43:59.662043
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ must return a unicode object."""
    import re

# Generated at 2022-06-24 02:44:04.817405
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('foo')
    str(e)
    unicode(e)
    e = InvalidPattern(u'foo')
    str(e)
    unicode(e)

# Generated at 2022-06-24 02:44:12.870001
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    import doctest
    from bzrlib.tests import TestUtil

    # This is a bit hacky, but it's better than nothing.
    # Doctest is somewhat complex to set up.
    # We also test unicode to ensure that no ValueError is raised
    doctest.testmod(TestUtil, raise_on_error=True,
                    optionflags=doctest.ELLIPSIS
                    |doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 02:44:16.767286
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex"""
    state = {"args": ("^/foo$",), "kwargs": {}}
    obj = LazyRegex()
    obj.__setstate__(state)
    # Check that obj._real_regex is None
    assert obj._real_regex is None, obj._real_regex



# Generated at 2022-06-24 02:44:27.572122
# Unit test for function finditer_public
def test_finditer_public():
    # Make sure that finditer_public has been installed
    assert(getattr(re, 'finditer', False))

    assert(re.search('a', 'a') == finditer_public('a', 'a'))
    assert(re.search('a', 'b') == finditer_public('a', 'b'))

    pattern = re.compile('a')
    assert(re.search('a', 'a') == finditer_public(pattern, 'a'))
    assert(re.search('a', 'b') == finditer_public(pattern, 'b'))

    lazy_pattern = lazy_compile('a')
    assert(re.search('a', 'a') == finditer_public(lazy_pattern, 'a'))

# Generated at 2022-06-24 02:44:36.013707
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex's magic method __getattr__ should return real attribute"""
    lazy_regex = LazyRegex([r"(\d+)"])
    # Make sure that LazyRegex has not a real attribute
    # to be found by the magic method __getattr__.
    for attr in LazyRegex._regex_attributes_to_copy:
        assert not hasattr(lazy_regex, attr)
    # Try to get an attribute from lazy_regex.
    # The magic method __getattr__ should return the real attribute.
    for attr in LazyRegex._regex_attributes_to_copy:
        assert hasattr(lazy_regex, attr)

# Generated at 2022-06-24 02:44:41.166873
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class Test(InvalidPattern):
        """A test exception"""
        _fmt = 'A test exception'

    exc = Test('Test message')
    def must_raise_AssertionError():
        # InvalidPattern.__init__ must set 'msg' argument as 'msg' attribute.
        exc.msg

    # test that getattr fails
    try:
        must_raise_AssertionError()
    except AttributeError:
        pass
    else:
        raise AssertionError("getattr must fail")

    # test that getattr returns unicode
    assert isinstance(str(exc), str)
    assert isinstance(exc.msg, unicode)

    # test that __str__ returns str
    assert isinstance(str(exc), str)
    assert isinstance(unicode(exc), unicode)


# Generated at 2022-06-24 02:44:45.848659
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test case for __getstate__ of class LazyRegex"""
    r = LazyRegex(("some pattern",))
    state = r.__getstate__()
    assert state == {"args":("some pattern",), "kwargs":{}}
    r = LazyRegex(("some pattern",), {"I":42})
    state = r.__getstate__()
    assert state == {"args":("some pattern",), "kwargs":{"I":42}}


# Generated at 2022-06-24 02:44:54.262052
# Unit test for function lazy_compile
def test_lazy_compile():
    # Make sure the module is fully lazy-reloaded
    import bzrlib.lazy_regex
    from bzrlib.lazy_regex import (
        LazyRegex,
        lazy_compile,
        _real_re_compile,
        )
    reload(bzrlib.lazy_regex)

    re.compile = lazy_compile
    x = re.compile("^((?P<user>.*?)@(?P<host>.*?):)?(?P<path>.*)$")
    x.match("test@test2:some/path")



# Generated at 2022-06-24 02:45:04.109844
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__

    This is a complete test of the InvalidPattern.__unicode__ method,
    which will return a Unicode string.
    """
    from bzrlib import errors
    import sys

    # We use errors.BzrError to get some bzrlib specific handling.
    class UnicodeTest(errors.BzrError):
        """An exception with Unicode error messages"""

        def __init__(self, unicode_string, ascii_string=None):
            """Create a new UnicodeTest exception.

            :param unicode_string: The initial Unicode message.
            :param ascii_string: The initial ASCII message.
            """
            exceptions.Exception.__init__(self, unicode_string, ascii_string)
            # We set _preformatted_string to avoid having

# Generated at 2022-06-24 02:45:15.245770
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # Test if LazyRegex raises AttributeError when the attribute is absent
    # from the regular expression object.
    # The regular expression object didn't have an attribute called __test__.
    # This attribute is not in _regex_attributes_to_copy either.
    # LazyRegex.__getattr__() should raise AttributeError when the attribute
    # is absent and it should not crash.
    # This test should be removed after upgrade to python 2.5 which doesn't
    # have the problem of attribute absence in regular expression object.
    try:
        obj = LazyRegex([""])
        obj.__test__
    except AttributeError:
        pass

# Generated at 2022-06-24 02:45:21.467688
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    r = re.compile('test')
    install_lazy_compile()
    r2 = re.compile('test')
    reset_compile()
    r3 = re.compile('test')
    assert r.pattern == r2.pattern
    assert r.pattern == r3.pattern
    assert r is not r2
    assert r2 is not r3

# Generated at 2022-06-24 02:45:28.754518
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore a LazyRegex from a pickled state"""
    import pickle
    # pickle and unpickle
    l = LazyRegex(('regex', ), {})
    d = pickle.dumps(l)
    l2 = pickle.loads(d)
    # l and l2 should be equal
    assert(l == l2)
    # they should not be the same object
    assert(l is not l2)

# Generated at 2022-06-24 02:45:31.442093
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('test message')
    eq = e.__eq__('other')
    assert eq is NotImplemented
    e2 = InvalidPattern('test message')
    eq2 = e.__eq__(e2)
    assert eq2



# Generated at 2022-06-24 02:45:38.803944
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern.

    This test just verifies that __eq__ can be called and returns a value.
    """
    error = InvalidPattern('')
    error2 = InvalidPattern('')
    error3 = InvalidPattern('msg')
    error4 = object()
    eq = error.__eq__(error2)
    assert isinstance(eq, bool)
    eq = error.__eq__(error3)
    assert isinstance(eq, bool)
    eq = error.__eq__(error4)
    assert eq is NotImplemented



# Generated at 2022-06-24 02:45:46.623825
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr__ of class InvalidPattern"""
    class TestRepr(InvalidPattern):
        pass
    test_instance = TestRepr('Message')
    result = test_instance.__repr__()
    expected = "TestRepr('Message')"
    # Check that result is valid and is a string.
    if not isinstance(result, str):
        raise AssertionError('result is not a string: %r' % (result,))
    # Check that result is equal to the expected value.
    if result != expected:
        raise AssertionError('result is not equal to expected. result: %s' \
                             ' expected: %s' % (result, expected))

# Generated at 2022-06-24 02:45:54.757175
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ must return the state to use when pickling.

    It is important to __getstate__ return only the state needed for
    __setstate__ to be able to usefully restore the state.  The state
    should not be tied to the implementation of the class, the state can
    be changed if the implementation changes.

    This test ensures the implementation of LazyRegex does not change
    accidentally.
    """
    l = LazyRegex(args=('foo',), kwargs={'flags': re.L})
    # make sure the attributes that were just set are not None
    l._regex_args
    l._regex_kwargs
    got = l.__getstate__()

# Generated at 2022-06-24 02:46:06.472755
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the behavior of LazyRegex"""
    from bzrlib import tests
    import re
    test_pattern = r'(\(.*\))'
    test_string = r"(bzr '(C:\\Program Files\\bzr\\bzr.bat' -d 'C:\Program Files\bzr' serve --inet --directory 'C:\Documents and Settings\Siddharth Agarwal\My Documents\My Dropbox\bzr-work' --allow-writes --strict-locks)"

# Generated at 2022-06-24 02:46:13.123139
# Unit test for function finditer_public
def test_finditer_public():
    if not getattr(re, 'finditer'):
        return
    # Test that it forwards to LazyRegex.finditer
    lazy_re = LazyRegex(('.', ))
    lazy_re.finditer = lambda s: iter(range(3))
    it = re.finditer('.', 'abc')
    assert hasattr(it, 'next')
    assert it.next() == 0
    assert it.next() == 1
    assert it.next() == 2

# Generated at 2022-06-24 02:46:16.772944
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern __eq__ compares only msg"""
    e1 = InvalidPattern('msg1')
    e2 = InvalidPattern('msg2')
    import doctest; doctest.ELLIPSIS_MARKER = '???'
    assert e1 == e1
    assert e1 != e2


# Generated at 2022-06-24 02:46:22.756735
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__() should return a string."""
    # _fmt is a class attribute
    assert InvalidPattern._fmt is not None
    msg = 'invalid regular expression'
    e = InvalidPattern(msg)
    u = unicode(e)
    assert isinstance(u, unicode)
    # __str__() should always return a 'str' object
    s = str(e) # should return a 'str' object
    assert isinstance(s, str)
    # __repr__() should return a 'str' object
    assert isinstance(repr(e), str)
    # ensure that exception with empty message gives a nice error message
    e = InvalidPattern('')
    s = str(e)
    assert 'Unprintable exception InvalidPattern' in s
    # ensure that exception with None message gives

# Generated at 2022-06-24 02:46:25.326179
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    re.compile('test')

# Generated at 2022-06-24 02:46:30.636505
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern.

    This test is needed if we want bzrlib.tests.__init__.py to check that the
    module was correctly reloaded.
    """
    msg = "msg"
    ex = InvalidPattern(msg)
    assert repr(ex) == "InvalidPattern('" + msg + "')"


# Install the lazy compiler as the default compile mode.
install_lazy_compile()

# re.compile() will now return lazy compiled regex - anything using regex
# objects that we don't control should give a LazyRegex object.

# Generated at 2022-06-24 02:46:37.162916
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test constructor of class LazyRegex"""
    lr = LazyRegex()
    assert lr._regex_args == ()
    assert lr._regex_kwargs == {}
    assert lr._real_regex is None
    lr = LazyRegex(('abc'), {})
    assert lr._regex_args == ('abc',)
    assert lr._regex_kwargs == {}
    assert lr._real_regex is None


# Generated at 2022-06-24 02:46:39.489410
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern"""
    ip = InvalidPattern('Message')
    assert str(ip) == 'InvalidPattern(Message)'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:46:46.951928
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ returns a str object, containing the message.

    This is important for "assert not bzr_trace(msg)" to work.
    """
    # Create the exception object
    e = InvalidPattern('foo')
    # __str__ returns a str object
    assert type(str(e)) is str
    # __str__ returns the expected string
    assert str(e).endswith('foo')



# Generated at 2022-06-24 02:46:53.134415
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """If method __repr__ of class InvalidPattern does not return a string with
    the format 'NAME(STRING)', there will be a bug."""
    exc = InvalidPattern("Test")
    exc_repr = repr(exc)
    assert exc_repr == "InvalidPattern('Test')"


# Generated at 2022-06-24 02:47:03.068379
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test the constructor of InvalidPattern."""
    # The easy case: no arguments
    try:
        e = InvalidPattern()
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")
    # The easy case: one argument
    try:
        e = InvalidPattern("hello")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")
    # Test with one argument.
    e = InvalidPattern("hello")
    if e.msg != "hello":
        raise AssertionError("msg was not set correctly: %s" % (e.msg,))
    # Test when used as an exception.
    try:
        raise InvalidPattern("hello")
    except InvalidPattern as e:
        if e.msg != "hello":
            raise Assertion

# Generated at 2022-06-24 02:47:14.118177
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    import sys
    # Call install_lazy_compile() once so we can check if it works
    install_lazy_compile()

# Generated at 2022-06-24 02:47:21.801323
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    import pickle
    # Setup a LazyRegex
    lazy_regex = LazyRegex()
    # Compile the proxy object
    lazy_regex._compile_and_collapse()
    # Serialize the proxy object
    pickled_regex = pickle.dumps(lazy_regex)
    # Now restore the proxy object
    restored_regex = pickle.loads(pickled_regex)
    # Now the restored proxy object should be compiled the same as the original one
    for attribute in lazy_regex._regex_attributes_to_copy:
        if getattr(lazy_regex, attribute) != getattr(restored_regex, attribute):
            return False
    return True


# Generated at 2022-06-24 02:47:31.953872
# Unit test for function reset_compile
def test_reset_compile():
    # This will be updated as we reset_compile() and then re-enter this function
    assert _real_re_compile is not lazy_compile
    # This is the original compile function
    _global_original_compile = _real_re_compile
    install_lazy_compile()
    assert re.compile is lazy_compile
    # Now reset_compile
    reset_compile()
    # Now make sure re.compile has its original value
    assert re.compile == _global_original_compile
    # But _real_re_compile hasn't changed
    assert _real_re_compile is _global_original_compile
    # Not call reset_compile again and re-enter test_reset_compile
    test_reset_compile()

# Generated at 2022-06-24 02:47:43.167122
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    if not hasattr(gettext, '_msgids'):
        gettext._msgids = {}
    gettext._msgids.clear()
    def _gettext(string):
        gettext._msgids[string] = 'translation of %s' % string
        return gettext._msgids[string]

    msg = 'msg1'
    e = InvalidPattern(msg)
    # We use assertEquals because __str__ must return a str object.
    # But __unicode__ returns a 'unicode' object.
    # The following will raise an exception in case of failure.
    assert e.__str__() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'


# Generated at 2022-06-24 02:47:50.955076
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should return the attribute of the
    _real_regex object"""
    fake_regex = LazyRegex(args='abc')
    # fake_regex._real_regex is None, thus raise an exception
    try:
        fake_regex.pattern
    except AttributeError:
        pass
    else:
        raise AssertionError(
            "LazyRegex.__getattr__ didn't raise AttributeError")
    # set a member of fake_regex
    fake_regex._real_regex = re.compile('abc')
    # check if the member is the attribute of _real_regex

# Generated at 2022-06-24 02:47:56.107910
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    args = ('^',)
    kwargs = {'flags': re.I}
    regex = LazyRegex(args, kwargs)
    assert regex._real_regex is None
    assert regex._regex_args == args
    assert regex._regex_kwargs == kwargs



# Generated at 2022-06-24 02:48:05.095797
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import six
    # No arguments
    e = InvalidPattern(None)
    if six.PY3:
        expected = "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    else:
        expected = "Unprintable exception InvalidPattern: dict={}, fmt=None, error=None"
    e._preformatted_string = expected
    assert str(e) == expected
    # With arguments
    e = InvalidPattern('Some error message')
    if six.PY3:
        expected = "Invalid pattern(s) found. 'Some error message'"
    else:
        expected = "Invalid pattern(s) found. 'Some error message'"
    assert str(e) == expected

# Unit tests for method _format of class InvalidPattern

# Generated at 2022-06-24 02:48:09.558952
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should give a well formatted error message."""
    err = InvalidPattern('the error message')
    assert repr(err) == 'InvalidPattern(the error message)'



# Generated at 2022-06-24 02:48:13.319418
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Should be able to pickle and recover a LazyRegex instance.
    """
    import pickle
    inst = lazy_compile(r'(.*)')
    inst.__setstate__(pickle.loads(pickle.dumps(inst.__getstate__())))

# Generated at 2022-06-24 02:48:14.382939
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:48:24.297574
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unpickling a LazyRegex should work properly.

    This is needed because LazyRegex has __slots__.
    """
    import cPickle
    # Check unpickling of a simple LazyRegex.
    pickled = cPickle.dumps(LazyRegex(('a',), {}))
    lazy_regex = cPickle.loads(pickled)
    # check it works
    match = lazy_regex.match('a')
    assert match is not None
    # Check it works for a more complicated one
    pickled = cPickle.dumps(LazyRegex(('a',), dict(IGNORECASE=True)))
    lazy_regex = cPickle.loads(pickled)
    match = lazy_regex.match('A')
    assert match is not None


#

# Generated at 2022-06-24 02:48:35.610986
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex.

    Test the method __getstate__ of the class LazyRegex. This method should
    return the correct state, to be pickled.
    """
    lazy = LazyRegex(('abc'))
    # If the method returns a dictionary, we can test its behaviour
    if isinstance(lazy.__getstate__(), dict):
        state = lazy.__getstate__()
        # the state should have a key "args"
        assert "args" in state
        # the value of the key "args" should be a tuple
        assert isinstance(state["args"], tuple)
        # the tuple should have ONE item
        assert len(state["args"]) == 1
        # the first item of the tuple should be "abc"

# Generated at 2022-06-24 02:48:43.197790
# Unit test for function finditer_public
def test_finditer_public():
    """Test for function finditer_public"""
    # Calling finditer_public with a lazy regex should call the finditer
    # method of the LazyRegex
    class MyLazyRegex(LazyRegex):
        def finditer(self, string):
            return iter(['result'])
    regex = MyLazyRegex()
    finditer_public(regex, 'string')
    # Calling finditer_public with a real regex should return the same result
    # as calling it directly on the regex
    regex = _real_re_compile('regex')
    finditer_public(regex, 'string')

# Generated at 2022-06-24 02:48:53.877222
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method LazyRegex.__getattr__

    When class attribute _real_regex is not None, that means the LazyRegex
    is compiled, then we should call the method of the real regex object.

    When class attribute _real_regex is None, that means the LazyRegex is not
    compiled, then we should call the method LazyRegex._compile_and_collapse
    to compile the LazyRegex.
    """
    from mock import Mock
    from bzrlib.tests import TestCase
    lazy_regex = LazyRegex(('pattern',))
    # Compile the LazyRegex
    lazy_regex._real_regex = Mock()
    lazy_regex._real_regex.match.return_value = True

# Generated at 2022-06-24 02:49:00.716592
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Install lazy_compile as the default regex compiling system.

    This will make all regexes lazy compiled, including regexes created
    by the Python standard library.  So we use a unique regex pattern here.
    """
    install_lazy_compile()
    pattern = r'Perforce error: ".*" is not under client\'s root'
    pattern_obj = re.compile(pattern)
    assert isinstance(pattern_obj, LazyRegex), "no proxy object used"
    actual_regex = re.compile(pattern)
    assert actual_regex.match('Perforce error: "//branches/wacky/blah" is not under client\'s root')

# Generated at 2022-06-24 02:49:12.151376
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    # Note that re.compile and lazy_compile are now synonymous:
    assert re.compile is lazy_compile
    assert lazy_compile is re.compile

# Generated at 2022-06-24 02:49:17.821579
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    import sys

    def _(s):
        return s

    if sys.version_info[0] == 2:
        # python 2.x
        test_InvalidPattern___str___python2(_)
    else:
        # python 3.x
        test_InvalidPattern___str___python3(_)



# Generated at 2022-06-24 02:49:26.472721
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() and install_lazy_compile() work correctly."""
    _real_re_compile('hello')
    install_lazy_compile()
    r = _real_re_compile('hello')
    assert isinstance(r, LazyRegex)
    reset_compile()
    r = _real_re_compile('hello')
    assert not isinstance(r, LazyRegex)
    install_lazy_compile()
    r = _real_re_compile('hello')
    assert isinstance(r, LazyRegex)

# Generated at 2022-06-24 02:49:29.259905
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() works and properly restores to the
    original value.
    """
    reset_compile()
    assert re.compile == _real_re_compile

# Generated at 2022-06-24 02:49:35.015070
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ must return a str.
    
    __str__ must return a str, not a unicode object, otherwise it causes
    a TypeError when exiting a bzr command.
    """
    text = "some text"
    error = InvalidPattern(text)
    s = str(error)
    assert isinstance(s, str)
    assert text in s


# Generated at 2022-06-24 02:49:47.178002
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class A(InvalidPattern):
        _fmt = '%(msg)s'
        def __init__(self, x, s=u'hello'):
            self.msg = x
            self.s = s
        def __str__(self):
            return u'%s %s' % (self.msg, self.s)

    class B(InvalidPattern):
        _fmt = u'%(msg)s'

    class C(InvalidPattern):
        _fmt = u'%(msg)s'

    class D1(InvalidPattern):
        _fmt = u'%(msg)s'
    class D2(D1):
        _fmt = u'%(msg)s'

    assert str(A(u'a')) == 'a hello'

# Generated at 2022-06-24 02:49:50.616193
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the method __unicode__ of the class InvalidPattern.

    This test is written because of the complexity of the method.
    """
    msg = 'Bad pattern'
    obj = InvalidPattern(msg)
    assert msg == str(obj), '__str__() should return the message of the error'
    assert msg == unicode(obj), '__unicode__() should return the message of the error'



# Generated at 2022-06-24 02:49:58.444420
# Unit test for function reset_compile
def test_reset_compile():
    # Test that the first reset_compile() works
    global real_re_compile
    orig_compile = re.compile
    re.compile = lambda *a, **kw: 'n'
    reset_compile()
    try:
        assert re.compile is _real_re_compile
    finally:
        re.compile = orig_compile
    # Test that the second reset_compile() works
    orig_compile = re.compile
    re.compile = lambda *a, **kw: 'n'
    reset_compile()
    try:
        assert re.compile is _real_re_compile
    finally:
        re.compile = orig_compile
    # Test that re.compile is reset when reset_compile is imported

# Generated at 2022-06-24 02:50:08.133770
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase
    class InvalidPatternTestCase(TestCase):
        def test_InvalidPattern_eq(self):
            e1 = InvalidPattern('foo')
            e2 = InvalidPattern('foo')
            e3 = InvalidPattern('bar')
            self.assertTrue(e1 == e2)
            self.assertFalse(e1 == e3)

    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

    tearDownModule = test_InvalidPattern___eq__.tearDownModule
    tearDownModule()
    setUpModule(TestCase)

# Generated at 2022-06-24 02:50:15.254143
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern"""
    # prepare exception arguments
    error = ValueError(123)
    args = ("foo",)
    kwargs = {123: "abc"}

    try:
        # call a method that raises ValueError with arguments
        raise InvalidPattern("foo").with_traceback(error, args, kwargs)
    except InvalidPattern as e1:
        # check if e1 and e2 are equal
        e2 = InvalidPattern("foo").with_traceback(error, args, kwargs)
        assert e1 == e2

# Generated at 2022-06-24 02:50:23.879256
# Unit test for function lazy_compile
def test_lazy_compile():
    from bzrlib.tests import TestCase

    class TestLazy(TestCase):

        def test_lazy_regex_collapse(self):
            # Test that our proxy object collapses into a full regex object
            # once we access any of its members.
            proxy = lazy_compile("foo(.*)")
            self.assertIs(proxy.match("foo"), None)
            self.assertIsInstance(proxy, re._pattern_type)
            self.assertIsInstance(proxy, re._pattern_type)

        def test_lazy_regex_collapse_pickle(self):
            # Test the pickling roundtrips
            proxy = lazy_compile("foo(.*)")
            state = proxy.__getstate__()
            self.assertIs(state, proxy.__getstate__())


# Generated at 2022-06-24 02:50:34.429872
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method LazyRegex.__setstate__

    This is a white-box test.
    """
    lazy_regex = LazyRegex()
    state = {
        "args": ("^", "abcd"),
        "kwargs": {"flags": re.I}
        }
    lazy_regex.__setstate__(state)
    real_regex = _real_re_compile(*state["args"], **state["kwargs"])
    for attr in LazyRegex._regex_attributes_to_copy:
        if getattr(real_regex, attr) != getattr(lazy_regex, attr):
            raise AssertionError(str(attr) + " attribute is not equal between"
                                 " real regex and lazy regex.")

# Generated at 2022-06-24 02:50:38.721408
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestUtil
    TestUtil.test_suite().run(defaultTest='test_reset_compile')

# Generated at 2022-06-24 02:50:44.238693
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test for function install_lazy_compile()."""

    old_compile = re.compile

    install_lazy_compile()
    try:
        assert re.compile is not old_compile
        assert re.compile is lazy_compile
        assert re.compile('regex') is not None
    finally:
        reset_compile()
        assert re.compile is old_compile



# Generated at 2022-06-24 02:50:49.487186
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Set state for instance."""
    lr = LazyRegex()
    lr.__setstate__(dict(args=("foo",), kwargs=dict(flags=1)))
    assert lr._regex_args == ("foo",)
    assert lr._regex_kwargs == dict(flags=1)

# Generated at 2022-06-24 02:50:58.468692
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the method __getattr__ of the LazyRegex class

    This test is to avoid a bug that was introduced in the process of adding
    LazyRegex. In the past, the compilation of the regex was happening by
    __getstate__ which was being called by pickle when serializing objects.
    This is no longer the case, as __getstate__ returns state as an empty
    dictionary. The serialization of the LazyRegex object no longer causes the
    regex compilation.
    """
    regex = LazyRegex(("^\w+$",))
    assert regex.pattern == '^\w+$'
    assert regex._real_regex is not None

# Generated at 2022-06-24 02:51:06.907342
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Exception InvalidPattern.__unicode__()"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import lazy_gettext
    from bzrlib.i18n import install_gettext_handler
    from bzrlib.i18n import install_gettext_translations
    from bzrlib.osutils import get_user_encoding
    from bzrlib.trace import mutter
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_i18n import TestInstall

    # TestCase.tearDown() calls TestCase.get_transport_log().

# Generated at 2022-06-24 02:51:19.600357
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test install_lazy_compile function."""
    # reset_compile() would restore the original 're.compile'
    _real_re_compile = re.compile
    # Override re.compile with a dummy function
    def dummy_compile(regexp, flags):
        return 'compiled-' + regexp

    re.compile = dummy_compile
    install_lazy_compile()
    assert re.compile is not _real_re_compile
    # re.compile should use LazyRegex
    compiled_regex = re.compile('\d+')
    assert isinstance(compiled_regex, LazyRegex)
    assert re.match(compiled_regex, '42')
    assert re.compile('.*') == 'compiled-.*'

# Generated at 2022-06-24 02:51:29.826643
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    r = re.compile('abc')
    assert isinstance(r, LazyRegex)
    assert r._real_regex is None
    assert r.search('abc')
    assert isinstance(r._real_regex, type(re.compile('abc')))
    # We can call reset_compile() any number of times, and it will always
    # restore the original functionality
    reset_compile()
    assert re.compile is _real_re_compile

    # Compile time errors are caught
    try:
        re.compile('abc(')
    except InvalidPattern:
        pass
    else:
        raise AssertionError('Expected InvalidPattern exception')


if __name__ == '__main__':
    test_lazy_compile()

# Generated at 2022-06-24 02:51:39.551063
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    msg = 'This is an error message'
    e = InvalidPattern(msg)
    assert e.msg == msg
    assert e._get_format_string() is None
    assert str(e) == ('Invalid pattern(s) found. ' + msg)
    assert unicode(e) == ('Invalid pattern(s) found. ' + msg)
    assert repr(e) == 'InvalidPattern(Invalid pattern(s) found. ' + msg + ')'
    assert e == InvalidPattern(msg)

    # Test that class InvalidPattern has a special string or Unicode
    # attribute _fmt that is used as the format string for exception e
    # if _fmt is not None.
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'My Invalid Pattern Exception'

    e = MyInvalidPattern(msg)
    assert e._get_format_

# Generated at 2022-06-24 02:51:48.711214
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__() must return a string"""
    msg = 'test'
    e = InvalidPattern(msg)
    s = repr(e)
    # make sure it's a string
    if not isinstance(s, str):
        raise AssertionError('repr(InvalidPattern(%r)) = %r, but must be a string' %
            (msg, s))
    # make sure it contains the message
    if s.find(msg) == -1:
        raise AssertionError('repr(InvalidPattern(%r)) = %r, but must contain the message' %
            (msg, s))



# Generated at 2022-06-24 02:51:54.958918
# Unit test for function finditer_public
def test_finditer_public():
    import bzrlib.tests.test_re_compile_lazy as T
    re.finditer = T.finditer_py26
    import re
    # Test that this is the function from the re module
    rex = re.compile('.')
    match = rex.finditer('abc').next()
    T.TestCase.assertTrue(isinstance(match, T.SRE_Match))

# Generated at 2022-06-24 02:51:56.830742
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('')
    # The following should not raise an exception.
    str(e)
    unicode(e)
    repr(e)

# Generated at 2022-06-24 02:52:06.470673
# Unit test for function finditer_public
def test_finditer_public():
    """Test function finditer_public() of module re."""
    class DummyRegex(object):
        def finditer(pattern, string):
            return (('dummy', 'string'), ('dummy', 'string'))
    def test_compile(pattern, flags=0):
        return DummyRegex()

    import sys
    import bzrlib.tests
    bzrlib.tests.TestCaseWithMemoryTransport.tearDown()
    old_re_finditer = re.finditer
    re.finditer = bzrlib.tests.re.finditer_public
    old_re_compile = re.compile
    re.compile = test_compile
    tmp_stdout = sys.stdout
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 02:52:07.839155
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    assert repr(InvalidPattern('foo')) == "InvalidPattern(foo)"

# Generated at 2022-06-24 02:52:09.553762
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    doctest.testmod()

# vim: tabstop=4 expandtab shiftwidth=4

# Generated at 2022-06-24 02:52:18.522222
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re_object = re.compile('foo')
    install_lazy_compile()
    lazy_re_object = re.compile('foo')
    reset_compile()
    # Make sure re.compile returns the correct object type
    assert isinstance(re_object, re._pattern_type)
    assert isinstance(lazy_re_object, LazyRegex)

    # Make sure re.compile doesn't return the same object (they're all unique)
    assert re_object is not lazy_re_object

    # Make sure re.compile returns the same object each time it's called
    re_object = re.compile('foo')
    assert re_object is re.compile('foo')
    assert re_object is re.compile('foo')

    install_lazy_compile()
    # Make

# Generated at 2022-06-24 02:52:24.861438
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the function lazy_compile"""
    lazy_re = lazy_compile('^.*$')
    # Check that the regex is compiled on demand
    assert lazy_re is not None
    # Check that the regex doesn't exist until accessed
    assert lazy_re._real_regex is None
    # Check that the access creates the regex
    assert lazy_re._real_regex is not None



# Generated at 2022-06-24 02:52:34.154922
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    def check_equal(d1, d2):
        inst1 = InvalidPattern(None)
        inst2 = InvalidPattern(None)
        inst1.__dict__ = d1
        inst2.__dict__ = d2
        return (inst1 == inst2)

    assert check_equal({}, {})
    assert check_equal({'a': 1}, {'a': 1})
    assert check_equal({'a': 1}, {'a': 2})
    assert not check_equal({'a': 1}, {})
    assert not check_equal({}, {'a': 1})

# Generated at 2022-06-24 02:52:39.195301
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Testing method __getstate__ of class LazyRegex"""
    regex = lazy_compile('(a)(b)')
    state = regex.__getstate__()
    regex2 = LazyRegex(state["args"])
    assert regex2.__getstate__() == state



# Generated at 2022-06-24 02:52:41.077410
# Unit test for function finditer_public
def test_finditer_public():
    re.finditer('[abc]', 'abc')

# Generated at 2022-06-24 02:52:44.052820
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    ip = InvalidPattern('Unicode string')
    assert isinstance(ip.__unicode__(), unicode)

# Generated at 2022-06-24 02:52:52.375155
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class MyException(InvalidPattern):
        _fmt = '%(msg)s'
    e = MyException('hello')

# Generated at 2022-06-24 02:52:55.604298
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    n = InvalidPattern('msg')
    s = repr(n)
    assert s.startswith('InvalidPattern(')
    assert s.endswith(')')
    assert 'msg' in s

# Generated at 2022-06-24 02:52:59.938117
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex"""
    def test():
        lr = LazyRegex('foo')
        state = lr.__getstate__()
        return state == {
            "args": ('foo',),
            "kwargs": {},
            }
    # test
    assert test()



# Generated at 2022-06-24 02:53:11.847298
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test that LazyRegex can be unpickled"""
    # Create a LazyRegex, compile it so that it is actually a real regex,
    # and then pickle and unpickle it.
    regex = LazyRegex()
    (regex.match)("test")
    regex_state = regex.__getstate__()
    del regex
    new_regex = LazyRegex()
    new_regex.__setstate__(regex_state)

    # Check that the new regex is the same as the old
    # (match returns None if there is no match)
    if (new_regex.match)("test") != None:
        raise Exception("unpickled regex does not match")