

# Generated at 2022-06-24 02:43:14.419149
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy compilation of regexs."""
    import pickle
    r = re.compile("(?P<a>a)(?P<b>b)(?P<c>c)")
    if hasattr(re, 'finditer'):
        r2 = re.finditer("(?P<a>a)(?P<b>b)(?P<c>c)")
    p = lazy_compile("(?P<a>a)(?P<b>b)(?P<c>c)")
    if hasattr(re, 'finditer'):
        p2 = re.finditer("(?P<a>a)(?P<b>b)(?P<c>c)")
    # Test that the proxy object has not yet compiled
    # (i.e. that it has no attributes which aren't

# Generated at 2022-06-24 02:43:20.443988
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ resets state as expected"""
    a = LazyRegex(("abc", 10))
    a._compile_and_collapse()
    a.__setstate__({"args": ("abc", 10)})
    assert a._real_regex is None
    assert (a._regex_args == ("abc", 10))

# Generated at 2022-06-24 02:43:29.985700
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile() restores re.compile to its original value"""
    # This test will fail if run after reset_compile() is called, so we
    # set a flag that tells us if it's already been called. This can be
    # removed once we no longer need to be able to call reset_compile()
    # from a test.
    if hasattr(test_reset_compile, 'called'):
        return
    test_reset_compile.called = True
    orig_compile = re.compile
    try:
        install_lazy_compile()
        reset_compile()
    finally:
        re.compile = orig_compile
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:43:33.361793
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Should always return a str object using class name, evolvings values of self.__dict__

    >>> test = InvalidPattern('test message')
    >>> test.__repr__()
    "InvalidPattern('test message')"
    """



# Generated at 2022-06-24 02:43:40.680108
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import tempfile
    import pickle
    import shutil

    # create temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-24 02:43:50.739835
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """docstring for test_InvalidPattern___eq__"""
    # Initialize some variables
    msg = "test msg"
    ip1 = InvalidPattern(msg)
    ip2 = InvalidPattern(msg)

    # Test the equality between two exceptions with the same msg
    assert ip1 == ip2

    # Test the equality between two exceptions with different msg
    ip3 = InvalidPattern("another msg")
    assert ip1 != ip3

    # Test the equality between an exception and another object
    assert ip1 != msg

    # Test the equality between an exception and None
    assert ip1 is not None

    # Test the equality between an exception and a class
    assert ip1 != InvalidPattern

# Generated at 2022-06-24 02:43:59.030916
# Unit test for function reset_compile
def test_reset_compile():
    import sys
    import re
    import unittest
    import testtools
    class TestReset(unittest.TestCase):
        """Test behaviour of reset_compile()"""
        def test_nesting(self):
            """Test that reset_compile() can be called multiple times"""
            sys.modules['re'].compile = lambda x: x
            reset_compile()
            reset_compile()
            reset_compile()
            self.assertEqual(re.compile('foo'), 'foo')
    testtools.run_unittest(TestReset)

# Generated at 2022-06-24 02:44:08.510723
# Unit test for method __unicode__ of class InvalidPattern

# Generated at 2022-06-24 02:44:11.186727
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """test for method __getattr__ of class LazyRegex"""
    l_re = lazy_compile('foo[0-9]+')
    assert l_re.match('foo23')
    assert not l_re.match('bar')

# Generated at 2022-06-24 02:44:13.040392
# Unit test for function finditer_public
def test_finditer_public():
    """Test finditer_public function."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:44:15.425981
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile works"""
    import bzrlib.tests
    bzrlib.tests.RunTest(install_lazy_compile)

# Generated at 2022-06-24 02:44:17.394883
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Using the test pattern.*"""
    ip = InvalidPattern("test pattern")
    assert repr(ip) == "InvalidPattern('test pattern')"

# Generated at 2022-06-24 02:44:22.086351
# Unit test for function reset_compile
def test_reset_compile():
    import doctest
    if doctest.register_optionflag('RE_COMPILE_RESETS'):
        doctest.set_unittest_reportflags(doctest.REPORT_ONLY_FIRST_FAILURE
                                         | doctest.RE_COMPILE_RESETS)
    reset_compile()

# Generated at 2022-06-24 02:44:27.729244
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() works as documented."""
    orig_re_compile = re.compile
    try:
        re.compile = object()
        reset_compile()
        assert re.compile == orig_re_compile
    finally:
        re.compile = orig_re_compile

# Generated at 2022-06-24 02:44:35.490634
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern.

    Test that the method returns a string of the form:
    <class name>(<message>)
    """
    exp_msg = 'Invalid pattern \"^\\\"%(\\d+)\\\"\\s+\\\"(.*)\\\"\\s*$\": '\
        'multiple repeat'
    ip = InvalidPattern(exp_msg)
    exp_str = 'InvalidPattern(Invalid pattern \"^\\\"%(\\d+)\\\"\\s+'\
        '\\\"(.*)\\\"\\s*$\": multiple repeat)'
    assert ip.__repr__() == exp_str

# Generated at 2022-06-24 02:44:41.068384
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    exc = InvalidPattern('Invalid pattern: '(InvalidPattern('msg')))
    assert repr(exc) == "InvalidPattern('Invalid pattern: '(InvalidPattern('msg')))"

# Generated at 2022-06-24 02:44:48.907493
# Unit test for function lazy_compile
def test_lazy_compile():
    if not _real_re_compile is re.compile:
        raise AssertionError("_real_re_compile != re.compile")
    import re as re_module
    if not _real_re_compile is re_module.compile:
        raise AssertionError("_real_re_compile != re_module.compile")

# Generated at 2022-06-24 02:44:52.844305
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for method __getstate__ of class LazyRegex"""
    proxy_obj = LazyRegex(('a',), {'flags': 1})
    state = proxy_obj.__getstate__()
    assert state['args'] == ('a',)
    assert state['kwargs'] == {'flags': 1}

# Generated at 2022-06-24 02:44:56.942405
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    a = InvalidPattern("a")
    b = InvalidPattern("a")
    c = InvalidPattern("b")
    d = 1
    l = [a, b, c, d]
    l.remove(InvalidPattern("a"))
    l.remove(InvalidPattern("b"))
    l.remove(InvalidPattern("a"))
    if l == [1]:
        pass
    else:
        raise AssertionError("method __eq__ of class InvalidPattern does not work")

# Generated at 2022-06-24 02:45:04.227472
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object in utf8 encoding.
    
    It should be a string that can be printed to the console.
    """
    # In python2.x this str is not a unicode object and can be printed
    # to the console.
    error = InvalidPattern('message')
    s = str(error)
    assert isinstance(s, str)

    # In python3.x this str is a unicode object and must be encoded to a
    # str object before being printed to the console.
    error = InvalidPattern('message')
    s = str(error)
    assert isinstance(s, str)

    error = InvalidPattern(u'message')
    s = str(error)
    assert isinstance(s, str)



# Generated at 2022-06-24 02:45:13.078951
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() returns a correct text representation

    This method is present to test that the InvalidPattern.__unicode__()
    method always returns a unicode-object with the correct text
    representation. This avoids the situation that in some situations
    the object is decoded by the default encoding and in other situations
    it is not decoded.
    """
    p = InvalidPattern('this is a test')
    assert(isinstance(p.__unicode__(), unicode))
    assert(p.__unicode__() == u'this is a test')

# Generated at 2022-06-24 02:45:22.828166
# Unit test for function finditer_public
def test_finditer_public():
    """Test if finditer_public works properly.

    This function tries to test if the function 'finditer_public' works
    properly. It intends to test the behavior of 'finditer_public' in
    the case that we pass a LazyRegex to it and that we pass a string
    of characters to it.
    """
    import re

    # Test pattern - re.finditer must return 5 objects of MatchObject
    text = 'a a a a a'
    pattern = LazyRegex(['a'])
    if isinstance(pattern, LazyRegex):
        result = re.finditer(pattern, text)
    else:
        result = re.finditer(pattern, text)
    assert len(list(result)) == 5

    # Test pattern - re.finditer must return 0 object of MatchObject

# Generated at 2022-06-24 02:45:25.651527
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public"""
    reg = lazy_compile("a")
    obj = finditer_public(reg, "aaa")
    it = obj.next()
    assert it.span() == (0,1)

# Generated at 2022-06-24 02:45:31.265790
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test constructor of class LazyRegex."""
    regex = LazyRegex()
    assert regex._real_regex is None

    regex = LazyRegex((), {'flags':0})
    assert regex._real_regex is None


# Generated at 2022-06-24 02:45:40.775526
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test: InvalidPattern.__repr__, InvalidPattern.__str__ and
    InvalidPattern.__unicode__."""
    import sys
    if sys.version_info[0] < 3:
        string_type = str
    else:
        string_type = bytes

    def check_invalida_pattern(pat, msg, repr_expected=None,
                                unicode_expected=None, str_expected=None):
        try:
            re.compile(pat)
        except InvalidPattern as e:
            if repr_expected is not None:
                assert repr_expected == e.__repr__(), \
                "Unexpected repr for pattern '%s'" % pat

# Generated at 2022-06-24 02:45:49.471218
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Utility function to test install_lazy_compile

    It creates a new instance of re module, initializes it with the
    original object of re module type and then calls install_lazy_compile.
    """
    # Create a new re module since any change in the original will break
    # unit tests for re.
    new_re = type(re)()
    new_re.__dict__.update(re.__dict__)
    new_re.__dict__.update({'_compile_replacement': _real_re_compile})
    install_lazy_compile()
    import bzrlib.tests.blackbox.test_lazy_compile
    bzrlib.tests.blackbox.test_lazy_compile.TestCase.re = new_re

# Generated at 2022-06-24 02:45:52.756734
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ proxies until the regex is really needed."""
    lr = LazyRegex()
    # no exception
    lr.pattern
    lr.groups

# Generated at 2022-06-24 02:46:01.501389
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib.tests import TestCase
    class FinditerPublicTests(TestCase):

        def test_finditer_public_return_type(self):
            case = [('abc', 'abc', re.search, False),
                    ('abc', 'abc', re.finditer, True)]
            for regex_str, regex_str_r, regex_method, return_type in case:
                regex = lazy_compile(regex_str)
                m = regex_method(regex, regex_str_r)
                self.assertEqual(return_type, isinstance(m, re.MatchObject))

# Generated at 2022-06-24 02:46:06.383755
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Unit test of constructor for class LazyRegex."""
    lr = LazyRegex()
    assert lr._regex_args == ()
    assert lr._regex_kwargs == {}, \
        '_regex_kwargs should be {} but got %r' % (lr._regex_kwargs,)


# Generated at 2022-06-24 02:46:13.757915
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('fatal error')
    # test _format
    assert str(e) == 'Invalid pattern(s) found. fatal error'
    assert e == InvalidPattern('fatal error')
    assert e != InvalidPattern('warning error')
    # test _get_format_string
    assert e._get_format_string() == 'Invalid pattern(s) found. %(msg)s'


# Generated at 2022-06-24 02:46:14.687465
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod(re)

# Generated at 2022-06-24 02:46:16.894226
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Just run the gettext extractor
    from bzrlib.i18n import _
    _('''Invalid pattern(s) found. %(msg)s''')

# Generated at 2022-06-24 02:46:29.476331
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method __getattr__ passes calls to real _sre.SRE_Pattern objects"""
    proxy_regex = LazyRegex()
    # test __getattr__ calls on _real_regex member
    proxy_regex._real_regex = re._compile
    # call findall method of _real_regex
    assert(proxy_regex.findall(r"\w+\.\w+", "test.test") == ["test.test"])
    # call match method of _real_regex
    assert(proxy_regex.match(r"\w+\.\w+", "test.test") is not None)
    # test __getattr__ calls on partially initialized _real_regex member
    proxy_regex = LazyRegex()
    proxy_regex._real_regex = re._comp

# Generated at 2022-06-24 02:46:37.162155
# Unit test for function reset_compile
def test_reset_compile():
    import bzrlib.tests
    bzrlib.tests.simple_tests.setup_simple_tests()
    from ..tests import test_lazy_compile
    from .. import lazy_compile
    from . import (
        re as _mod_re,
        )
    compiler = lazy_compile
    try:
        _mod_re.compile = compiler
        test_lazy_compile.test_suite()
    finally:
        _mod_re.compile = _real_re_compile.im_func

# Generated at 2022-06-24 02:46:47.238722
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Ensure description() and __unicode__() are consistent.

    The unicode of the description should be identical to __unicode__.
    """
    import sys
    encoding = sys.stdin.encoding
    try:
        i = InvalidPattern('msg')
        u = unicode(i)
    except UnicodeDecodeError:
        print('unicode conversion failed: encoding=%r' % (encoding,))
        raise
    else:
        # We can only test that they are equal if we can convert both
        # to unicode.
        assert u == unicode(i.msg), '%r != %r' % (u, i.msg)

# Generated at 2022-06-24 02:46:59.456783
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """For coverage, check that __setstate__ works.
    """
    lazy = LazyRegex(args=('foo',), kwargs={'flags':re.IGNORECASE})
    assert lazy._real_regex is None
    assert lazy._regex_args == ('foo',)
    assert lazy._regex_kwargs == {'flags':re.IGNORECASE}
    from cStringIO import StringIO
    import pickle
    pickle_str = pickle.dumps(lazy)
    lazy2 = pickle.loads(pickle_str)
    assert lazy2._real_regex is None
    assert lazy2._regex_args == ('foo',)
    assert lazy2._regex_kwargs == {'flags':re.IGNORECASE}

# Generated at 2022-06-24 02:47:03.342005
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex proxies should work correctly."""
    regex = LazyRegex('.*')
    # Note: the 'is' test is important, it ensures that the first reference
    # to the underlying object copies all attributes.
    assert regex.match('foo') is not None
    assert regex.match('bar') is not None



# Generated at 2022-06-24 02:47:09.756216
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test monkey-patching of re.compile()."""
    install_lazy_compile()
    try:
        r = re.compile('a')
        if not isinstance(r, LazyRegex):
            raise AssertionError("re.compile() didn't return a LazyRegex object")
    finally:
        reset_compile()

# Generated at 2022-06-24 02:47:14.641369
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # equality on instances of different classes
    other_class = type('other_class', (object,), {})
    oth = other_class()
    ip = InvalidPattern('')
    assert ip != oth
    # equality on instances of the same class
    ip2 = InvalidPattern('')
    assert ip != ip2
    ip2.msg = 'a message'
    assert ip != ip2

# Generated at 2022-06-24 02:47:17.149879
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    raise InvalidPattern(msg='something bad happened')
    raise InvalidPattern(msg='foo%(bar)s')
    raise InvalidPattern(msg='foo%(bar)s' % {'bar':'baz'})

# Generated at 2022-06-24 02:47:20.733135
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'hi %(name)s'
    e = MyInvalidPattern('foo')
    e.name = 'bar'
    str(e)


# Generated at 2022-06-24 02:47:31.754872
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__() of InvalidPattern should return a string"""
    from bzrlib.tests import TestCaseWithTransport
    import re
    class TestInvalidPattern(TestCaseWithTransport):

        def test_InvalidPattern___repr__(self):
            """__repr__() of InvalidPattern should return a string"""
            x = InvalidPattern(u'foo')
            self.assertIsInstance(x.__repr__(), str)
    test_suite = TestInvalidPattern('test_InvalidPattern___repr__')
    import unittest
    result = unittest.TestResult()
    test_suite.run(result)
    # TestCaseWithTransport (used as TestCase class above) has its own TestResult
    # with a special TestCaseWithTransport.addError method (rather than
    # TestResult.add

# Generated at 2022-06-24 02:47:42.927139
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ in class LazyRegex

    If an attribute is not found in the object, __getattr__ is invoked.
    If the regex hasn't been compiled yet, compile it. Once we have
    compiled, the only time we should come here is actually if the
    attribute is missing. Throw AttributeError in that case.
    """
    import bzrlib.tests
    lazy_regex = LazyRegex()
    # Real regex has not been compiled yet.
    # 'match' is a attribute, so it should be returned.
    # 'invalid' is not an attribute, and so should throw AttributeError.
    # 'real_regex' is an attribute defined in this class, so should be
    # returned.

# Generated at 2022-06-24 02:47:46.598971
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex_setstate__do_not_fail.

    This test should not raise an exception when
    LazyRegex.__setstate__ will be called with an empty dictionary.
    """
    LazyRegex().__setstate__({})



# Generated at 2022-06-24 02:47:56.222382
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__() should behave as documented

    See https://bugs.launchpad.net/bzr/+bug/195435
    """
    i1 = InvalidPattern("msg1")
    i2 = InvalidPattern("msg2")

    # same class, different instances
    assert i1 != i2
    # same class, same instances
    i3 = InvalidPattern("msg1")
    assert i1 == i3
    # different classes should return NotImplemented
    class MyException(InvalidPattern):
        pass
    i4 = MyException("msg1")
    assert i1 != i4
    assert i1 != NotImplemented

# Generated at 2022-06-24 02:48:05.449179
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test install_lazy_compile()."""

    r = re.compile('foo')
    install_lazy_compile()
    lr = re.compile('foo')

    # Check that lazy_compile is the default mode
    assert re.compile is lazy_compile
    assert lr._real_regex is None

    # Check that the regex was collapsed
    lr.search('bar')
    assert lr._real_regex is not None

    # Check that the return value matched
    assert lr.search('bar') is None
    assert lr.search('foobar') is not None

    reset_compile()
    assert re.compile is not lazy_compile
    assert re.compile is _real_re_compile

    # Check that re-install has no effect
    install_

# Generated at 2022-06-24 02:48:15.304646
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ of class LazyRegex must restore its original state"""
    import sys
    import pickle
    if sys.version_info < (2, 5):
        return
    proxy = LazyRegex(('^foo$',), {'flags': re.IGNORECASE})
    proxy._compile_and_collapse()
    saved = pickle.dumps(proxy)
    proxy = LazyRegex(('^bar$',), {'flags': re.IGNORECASE})
    proxy.__setstate__(pickle.loads(saved))
    assert proxy.match('foo').group() == 'foo'

# Generated at 2022-06-24 02:48:24.927280
# Unit test for method __getattr__ of class LazyRegex

# Generated at 2022-06-24 02:48:27.991703
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Check that the default behaviour of __getattr__ works"""
    lz = LazyRegex()
    # The regex has not been compiled yet, so asking for an attribute should
    # give us a function rather than an attribute error
    assert callable(lz.search)
    assert lz._real_regex is not None



# Generated at 2022-06-24 02:48:29.158584
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    ip = InvalidPattern('foobar')
    assert repr(ip) == "InvalidPattern('foobar')"

# Generated at 2022-06-24 02:48:31.802431
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    install_lazy_compile()
    assert re.compile is lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-24 02:48:39.572647
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Calling a method is only possible, if the real regex already exists."""
    lazy_regex = LazyRegex(('match',))
    try:
        lazy_regex.match('')
        # This should not happen
        assert False
    except AttributeError:
        pass
    lazy_regex._compile_and_collapse()
    try:
        lazy_regex.match('')
    except AttributeError:
        # This should not happen
        assert False

# Generated at 2022-06-24 02:48:45.810366
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # Arrange
    my_lazy_regex = LazyRegex(args=('test',), kwargs={'key':'value',})
    # Act
    state = my_lazy_regex.__getstate__()
    # Assert
    key_set = set(state)
    # It is important that "args" and "kwargs" are the only keys in the dict
    assert key_set == set(['args', 'kwargs'])
    assert state['args'] == ('test',)
    assert state['kwargs'] == {'key':'value',}



# Generated at 2022-06-24 02:48:51.134039
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Given an InvalidPattern instance, its __repr__ method should return a
    valid python string that creates an InvalidPattern instance equivalent to
    the original one.
    """
    ip = InvalidPattern("foo")
    # We don't care about the exact value, just that we can eval it,
    # and it gives us something that is a InvalidPattern, and has the
    # right attributes.
    ip_recreated = eval(ip.__repr__())
    assert isinstance(ip_recreated, InvalidPattern)
    assert ip.msg == ip_recreated.msg

# Generated at 2022-06-24 02:49:00.782031
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() restores the original compile function."""
    import bzrlib.lazy_regex
    # make sure re.compile is the original version.
    bzrlib.lazy_regex.reset_compile()
    # and now it should be a different object
    if bzrlib.lazy_regex.lazy_compile is re.compile:
        raise AssertionError(
            "reset_compile did not restore re.compile")
    result = re.compile(".*")
    bzrlib.lazy_regex.install_lazy_compile()

# Generated at 2022-06-24 02:49:04.231771
# Unit test for function reset_compile
def test_reset_compile():
    # Make sure that reset_compile works
    reset_compile()
    import bzrlib.tests
    bzrlib.tests.run_tests(bzrlib.tests.SlowTestSuite)

# Generated at 2022-06-24 02:49:09.395688
# Unit test for function reset_compile
def test_reset_compile():
    orig_compile = re.compile
    try:
        re.compile = 'hoho'
        reset_compile()
        eq = re.compile == _real_re_compile
    finally:
        re.compile = orig_compile
    assert eq

# Generated at 2022-06-24 02:49:20.015496
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """InvalidPattern has the expected properties"""
    msg = "hello world"
    i = InvalidPattern(msg)
    # Properties should be as expected
    assert i.msg == msg
    assert i._fmt == "Invalid pattern(s) found. %(msg)s"
    assert i._get_format_string() == "Invalid pattern(s) found. %(msg)s"
    assert type(i.__repr__()) == str
    assert type(i.__str__()) == str
    assert type(i.__unicode__()) == unicode
    assert type(i.__unicode__().encode('utf8')) == str

    i2 = InvalidPattern(msg)
    # The 2 objects should be equal
    assert i == i2
    i2.msg = "hello universe"
    # They should no longer be equal

# Generated at 2022-06-24 02:49:24.409121
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile works."""
    re.compile = "foo"
    try:
        reset_compile()
        if re.compile == "foo":
            raise AssertionError(
                "reset_compile did not reset re.compile.")
    finally:
        reset_compile()

# Generated at 2022-06-24 02:49:28.528462
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern

    Test if a unicode string gets converted to str during printing
    """
    from StringIO import StringIO
    buf = StringIO()
    err = InvalidPattern(u'unicode')
    buf.write(unicode(err))
    buf.seek(0)
    assert buf.read().decode('utf-8') == u'InvalidPattern(unicode)'

# Generated at 2022-06-24 02:49:29.466065
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    return doctest.DocTestSuite(re)

# Generated at 2022-06-24 02:49:33.175870
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    assert u"Invalid pattern(s) found. foo bar" == \
           unicode(InvalidPattern("foo bar"))
    assert u"Unprintable exception InvalidPattern: dict={}, fmt=None, error=None" == \
           unicode(InvalidPattern())

# Generated at 2022-06-24 02:49:45.819965
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Some tests for LazyRegex.__getattr__

    This tests that the __getattr__ method does proxy correctly, and has
    the correct return values. Other tests will have to ensure that
    the regex is compiled correctly.
    """
    regex = LazyRegex(('^abc$',))
    # Test that members are proxied
    assert regex.groups == 0
    # Test that members that call methods are handled correctly
    assert regex.match('abc') is None

    class TestClass:
        """A simple class with a custom __copy__ method"""
        def __copy__(self):
            return 'copied'

        def __deepcopy__(self):
            return 'deep copied'

    # Test that custom methods are handled correctly (See bug #720302)
    regex = LazyRegex(('^abc$',))

# Generated at 2022-06-24 02:49:55.884526
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern"""
    from bzrlib.tests import TestCase
    class TestEq(TestCase):
        def test_simplest(self):
            """Test the simplest case"""
            e1 = InvalidPattern(u'abc')
            e2 = InvalidPattern(u'abc')
            self.assertEqual(e1, e2)

        def test_different_messages(self):
            """Test when messages are different"""
            e1 = InvalidPattern(u'abc')
            e2 = InvalidPattern(u'def')
            self.assertNotEqual(e1, e2)

        def test_different_types(self):
            """Test when types are different"""
            e1 = InvalidPattern(u'abc')
            e2 = ValueError()
            self.assertNotEqual

# Generated at 2022-06-24 02:50:02.045734
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method InvalidPattern.__str__"""
    fmt = 'Could not find %(pattern)s in %(string)s'
    p = InvalidPattern(fmt % dict(pattern='abc', string='xyz'))
    # __str__ should return a str for ascii strings.
    p._fmt = 'Could not find %(pattern)s in %(string)s'
    assert isinstance(p.__str__(), str)
    # __str__ should return a str for unicode strings.
    p._fmt = u'Could not find %(pattern)s in %(string)s'
    assert isinstance(p.__str__(), str)
    # __str__ should return a str for non ascii utf-8 strings.

# Generated at 2022-06-24 02:50:12.075012
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ returns attributes from the real object"""
    from bzrlib.tests.blackbox import ExternalBase
    class LazyRegexTest(ExternalBase):
        def test_finditer(self):
            # Make sure LazyRegex.finditer() works.
            import re
            import bzrlib.lazy_re
            bzrlib.lazy_re.install_lazy_compile()
            p = re.compile('abc')
            i = p.finditer('fghabckl')
            self.assertEqual(list(i), list(p.finditer('fghabckl')))
    # Run the test suite
    test = LazyRegexTest()

# Generated at 2022-06-24 02:50:21.455838
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex
    """
    # Test 1: Call method __getattr__ with a known attribute
    try:
        my_pattern = LazyRegex((r'ab',))
        my_pattern.findall('abc')
    except AttributeError:
        # Test failed
        return 1
    # Test 2: Call method __getattr__ with an unknown attribute
    try:
        my_pattern = LazyRegex((r'ab',))
        my_pattern.unknown_attr
        # Test failed
        return 1
    except AttributeError:
        # Test passed
        return 0


# Generated at 2022-06-24 02:50:33.554951
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """check the InvalidPattern constructor."""
    class SomeException(Exception):
        _fmt = "some exception (%(foo)s)"
    class SomeExceptionBis(Exception):
        pass

    # no format string
    e = InvalidPattern("foo")
    assert e.__repr__() == 'InvalidPattern(foo)'
    assert e.__str__() == 'foo'
    assert e.__unicode__() == u'foo'

    # with format string
    e = InvalidPattern("foo")
    assert e.__repr__() == 'InvalidPattern(foo)'
    assert e.__str__() == 'InvalidPattern(foo)'
    assert e.__unicode__() == u'InvalidPattern(foo)'

    # with a preformatted unicode message
    e = InvalidPattern(SomeException(foo="unicode"))
   

# Generated at 2022-06-24 02:50:41.950033
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # This test is here instead of tests/test_errors.py to avoid cyclical
    # imports.
    class MyInvalidPattern(InvalidPattern):
        pass
    i = InvalidPattern(u'foo')
    i2 = InvalidPattern(u'foo')
    i3 = InvalidPattern(u'bar')
    i4 = MyInvalidPattern(u'foo')
    assert i == i2
    assert i != i3
    assert i != i4



# Generated at 2022-06-24 02:50:52.501765
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile matches the behaviour of compile"""
    # Test that a simple regex works
    regex = lazy_compile(r'a')
    assert regex.match('a')
    assert not regex.match('b')
    # Test that it handles flags
    regex = lazy_compile(r'a', re.IGNORECASE)
    assert regex.match('A')
    # Test that it handles nested proxy objects
    regex = lazy_compile(regex)
    assert regex.match('A')
    # Test it doesn't compile unnecessarily
    proxy_regex = lazy_compile(r'b')
    assert proxy_regex.match('b') is None
    assert proxy_regex._real_regex is None



# Generated at 2022-06-24 02:51:02.755504
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib import _i18n

    # setup environment for buildbot.
    _i18n._set_gettext_callable(gettext, 'bzr')
    # using LazyRegex instead of re.compile so that InvalidPattern is raised.
    # 1. simple InvalidPattern.__str__
    try:
        LazyRegex(r'(')
    except InvalidPattern as err:
        pass
    else:
        raise AssertionError('InvalidPattern not raised')
    s = str(err)
    assert(s == "Unbalanced parenthesis")
    u = unicode(err)
    assert(u == "Unbalanced parenthesis")
    # 2. InvalidPattern.__str__ with error

# Generated at 2022-06-24 02:51:10.144302
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    ip = InvalidPattern('a msg')
    repr(ip)
    str(ip)
    unicode(ip)
    # The following creates an unicode object for the error message
    ip = InvalidPattern('\u1234')
    repr(ip)
    str(ip)
    unicode(ip)
    ip = InvalidPattern('\u1234')
    ip._fmt = 'msg %(msg)s'
    ip._preformatted_string = 'my preformatted message'
    repr(ip)
    str(ip)
    unicode(ip)

# Generated at 2022-06-24 02:51:17.840635
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Method __getstate__ of class LazyRegex returns the arguments of the
    original call to re.compile"""
    args = ('test',)
    kwargs = {'flags': 0}
    lazy = LazyRegex(args, kwargs)
    state = lazy.__getstate__()
    if state != {'args': ('test',), 'kwargs': {'flags': 0}}:
        raise AssertionError()



# Generated at 2022-06-24 02:51:21.785744
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    invalid_pattern = InvalidPattern('A message')
    if 'A message' != str(invalid_pattern):
        raise AssertionError('__str__() of InvalidPattern not working')


# Generated at 2022-06-24 02:51:30.638460
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # Make sure we're not overriding anything (other unit test might leave us
    # in a strange state).
    reset_compile()

    # Make sure this test case leaves the regex engine in a working
    # state.
    original_re_compile = re.compile

    # Now install_lazy_compile()
    install_lazy_compile()
    # make sure re.compile was replaced by lazy_compile()
    self.assertIs(lazy_compile, re.compile)

    # do some basic testing that we're getting the right object
    regex = re.compile("foo", re.I)
    self.assertIs(LazyRegex, type(regex))
    self.assertEqual("foo", regex._regex_args[0])

# Generated at 2022-06-24 02:51:36.650486
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ raises exception AttributeError"""
    # Prepare
    rex = LazyRegex(args=('message',))
    rex._real_regex = None
    # Execute
    try:
        rex.match('')
    except AttributeError:
        return
    # Verify
    raise AssertionError('No exception raised')


# Generated at 2022-06-24 02:51:43.644147
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the LazyRegex proxy object."""
    # Setup
    install_lazy_compile()
    regex = re.compile("(ab)+")
    # Exercise
    try:
        reset_compile()
        reset_compile()
        re.compile("(ab)+")
    finally:
        install_lazy_compile()
    # Verify
    assert isinstance(regex, LazyRegex)
    reset_compile()

# Unit tests for functions install_lazy_compile and reset_compile

# Generated at 2022-06-24 02:51:55.050243
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern."""
    from bzrlib.tests.test_i18n import MockTranslations
    from bzrlib import i18n

    # msg contains '%%s' for testing % sign
    invalid_pattern = InvalidPattern('%%s')
    invalid_pattern._fmt = 'Invalid pattern(s) found. %(msg)s'
    # MockTranslations is used to test format string
    i18n.translations = MockTranslations()
    # testing Russian locale
    i18n._set_localecode('ru_RU.UTF-8')
    # msg contains Russian text for testing translations

# Generated at 2022-06-24 02:52:01.928721
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile() works as described."""
    from bzrlib.tests import TestCase
    cm = TestCase.make_memory_fs()
    reset_compile()
    install_lazy_compile()
    # Calling install_lazy_compile() twice should do nothing
    install_lazy_compile()
    # Calling install_lazy_compile() twice should do nothing
    reset_compile()
    # reset_compile() twice should do nothing
    reset_compile()
    # reset_compile() twice should do nothing
    regex = re.compile('foo.*')
    self.assertTrue(isinstance(regex, LazyRegex))
    regex = re.compile('foo.*', cm.case_sensitive)

# Generated at 2022-06-24 02:52:06.989969
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Check to ensure InvalidPattern object has a working __str__"""
    e = InvalidPattern('foo')
    assert str(e) == 'Invalid pattern(s) found. foo'
    e = InvalidPattern('bar')
    assert str(e) == 'Invalid pattern(s) found. bar'

# Generated at 2022-06-24 02:52:09.534721
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    p = re.compile('bzr.*')
    reset_compile()
    p = re.compile('bzr.*')

# Generated at 2022-06-24 02:52:18.482259
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Testing InvalidPattern.__str__"""
    # The string we print out should be utf8 even if the user's
    # locale is not utf8
    import bzrlib.i18n
    import bzrlib.ui
    bzrlib.i18n._get_translator = lambda x: None
    bzrlib.ui._config_encoding = 'UTF-8'
    # Test simple unicode strings
    msg = 'a unicode string'
    e = InvalidPattern(msg)
    assert isinstance(e.__str__(), str)
    # Test a message which is not ascii but can be encoded in utf8
    msg = '\xc3\xa4 unicode string'
    e = InvalidPattern(msg)
    assert isinstance(e.__str__(), str)
    # Test

# Generated at 2022-06-24 02:52:23.875060
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    # note that we cannot use real repr, since repr also call __repr__
    msg = 'msg'
    i = InvalidPattern(msg)
    expected = 'InvalidPattern("msg")'
    result = 'InvalidPattern("%s")' % i.msg
    assert expected == result, 'InvalidPattern.__repr__()'

# Generated at 2022-06-24 02:52:26.536934
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    try:
        LazyRegex('')
    except InvalidPattern as e:
        print(e)
    else:
        raise AssertionError('Did not catch InvalidPattern')

# Generated at 2022-06-24 02:52:31.213966
# Unit test for function lazy_compile
def test_lazy_compile():
    install_lazy_compile()
    assert re.compile is not _real_re_compile
    # Now reset it
    reset_compile()
    assert re.compile is _real_re_compile


if __name__ == '__main__':
    test_lazy_compile()

# Generated at 2022-06-24 02:52:36.191722
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile resets to the original state."""
    re.reset_compile()
    re.compile("a(b|c)*d")
    assert re.compile is not lazy_compile


# Generated at 2022-06-24 02:52:44.595258
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile works correctly

    This is done by calling install_lazy_compile() twice, and then
    testing that reset_compile() has restored the original functionality.
    """
    install_lazy_compile()
    reset_compile()
    install_lazy_compile()
    reset_compile()
    assert _real_re_compile is re.compile

if __name__ == '__main__':
    test_reset_compile()

# Generated at 2022-06-24 02:52:49.955056
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile restores re.compile

    >>> import re
    >>> _real_re_compile = re.compile
    >>> re.compile('foo') == _real_re_compile('foo')
    True
    >>> re.compile = lazy_compile
    >>> re.compile('foo') == _real_re_compile('foo')
    False
    >>> reset_compile()
    >>> re.compile('foo') == _real_re_compile('foo')
    True
    """



# Generated at 2022-06-24 02:52:56.485532
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must correctly set the attributes of the LazyRegex"""
    instance = LazyRegex()
    instance.__setstate__({'args': ('(?P<foo>.*)',), 'kwargs': {}})
    assert instance._regex_args == ('(?P<foo>.*)',)
    assert instance._regex_kwargs == {}


# Unit tests for method _compile_and_collapse of class LazyRegex

# Generated at 2022-06-24 02:53:06.260132
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """This test checks that after calling __setstate__ method a proxy object
    can retrieve regular expression attributes.
    """
    regex = LazyRegex(args=("foo.*",))
    state = {'args':('foo.*',), 'kwargs':{}}
    regex.__setstate__(state)
    #retrieving a regular expression object
    regex.findall("foo one\nfoo two")
    #retrieve a regular expression attributes
    #no exception is raised which means that setattr has been applied
    regex.__class__
    #retrieve a regular expression attributes again
    #no exception is raised which means that setattr has been applied
    regex.__class__

