

# Generated at 2022-06-24 02:43:09.419433
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    e = InvalidPattern('Invalid Revno 123.456')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'Invalid Revno 123.456'



# Generated at 2022-06-24 02:43:15.316439
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # The regular expression
    regex = LazyRegex(("(ab)",))
    # When the proxy has not been compiled, it returns a proxy to the attribute
    # of the real regex.
    regex_proxy = getattr(regex, "match")
    assert regex_proxy == regex._real_re_compile("(ab)").match
    # Once the proxy has been compiled, it returns the attribute of the real
    # regex.
    regex._real_regex = "real regex"
    assert regex._real_regex == getattr(regex, "_real_regex")


# Generated at 2022-06-24 02:43:22.645078
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should fail if _fmt is not ascii

    This test is not intended to validate translations, but to make sure that
    the underlying implementation is not using unicode_literals.
    """
    class InvalidPatternTest1(InvalidPattern):
        _fmt = "foo"

    class InvalidPatternTest2(InvalidPattern):
        _fmt = u"foo"

    class InvalidPatternTest3(InvalidPattern):
        _fmt = "foo".decode("ascii")

    # Make sure failures are reported.
    try:
        InvalidPatternTest2(msg="msg")
    except Exception as e:
        pass
    else:
        raise AssertionError(
            "`_fmt` should not be unicode with implicit unicode_literals")

# Generated at 2022-06-24 02:43:26.464585
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    exc = InvalidPattern('foo')
    assert exc == InvalidPattern('foo')
    assert exc != InvalidPattern('bar')
    assert exc != 'foo'
    assert exc != 4

# Generated at 2022-06-24 02:43:28.570209
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    r = re.compile('.*')
    r.search('foo')

# Generated at 2022-06-24 02:43:39.584358
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that LazyRegex.__getattr__ works as expected."""
    # Create a proxy object that should compile the regex when accessed.
    pattern = lazy_compile('some_regex')

    # Regex attributes should be unavailable before accessing the regex.
    e = raises(AttributeError, getattr, pattern, 'findall')
    assert_equal('_real_regex', str(e.__context__))

    # Regex attributes should be available after accessing the regex.
    # Any regex attribute should work.
    pattern.findall('abcd')
    assert_equal(['ab'], pattern.findall('abab'))
    assert_equal(r'(?i)Some$', str(pattern))
    assert_equal(0, pattern.groups)

# Generated at 2022-06-24 02:43:51.782867
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ of LazyRegex"""
    from bzrlib.tests import TestCase, TestCaseWithTransport

    # In order to test __getattr__, first we have to hack re.compile
    # and make it return LazyRegex, then change _real_re_compile to
    # return the *original* re.compile
    # (i.e. we are testing that the *proxy* works as expected)
    install_lazy_compile()
    global _real_re_compile
    _real_re_compile = re._real_re_compile
    reset_compile()

    class Test__getattr__(TestCaseWithTransport):
        """Test __getattr__ of LazyRegex"""


# Generated at 2022-06-24 02:44:01.381524
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must be able to restore from a pickled state.
    """
    s = r'[0-9].[0-9].[0-9]'
    reg = lazy_compile(s, re.I)
    # reg is a LazyRegex with _regex_args=('[0-9].[0-9].[0-9]',),
    # _regex_kwargs={'flags': 2}, _real_regex=None
    reg_pickled = reg.__getstate__()
    # reg_pickled is a dictionary {'args': ('[0-9].[0-9].[0-9]',),
    # 'kwargs': {'flags': 2}}
    restored_reg = LazyRegex()
    restored_reg.__setstate__(reg_pickled)

# Generated at 2022-06-24 02:44:04.508504
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test of method __getattr__ of LazyRegex class.
    """

    lr = LazyRegex()
    attr = 'findall'
    lr.findall = attr
    result = lr.findall
    expected = attr
    assert result == expected, (result, expected, 'Test failed.')

    # Make sure __getattr__ doesn't mind being called multiple times
    result = lr.findall
    expected = attr
    assert result == expected, (result, expected, 'Test failed.')



# Generated at 2022-06-24 02:44:14.396951
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern"""

    # Create a new object and check if it is equal to itself.
    exception1 = InvalidPattern("Test exception 1")
    assert exception1 == exception1

    # Create a new object and check if it is different than the first one.
    exception2 = InvalidPattern("Test exception 2")
    assert not exception1 == exception2

    # Create a new object and use it as the same class, but subclass.
    # Check that it is different to the first object.
    class MyException(InvalidPattern):
        pass
    exception3 = MyException("Test exception 3")
    assert not exception1 == exception3



# Generated at 2022-06-24 02:44:26.256645
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex."""
    import datetime
    proxy = LazyRegex([r"a"])
    assert proxy.__class__ is LazyRegex
    assert getattr(proxy, '_real_regex') is None
    assert proxy.__getattr__('__class__') is LazyRegex
    # Compile and collapse
    now = datetime.datetime.now()
    proxy._compile_and_collapse()
    assert getattr(proxy, '_real_regex').__class__ is re._pattern_type
    assert proxy.__getattr__('__class__') is re._pattern_type
    proxy._real_regex.match(r"a")
    # Ensure that we don't get stuck calling the _compile_and_collapse again
    assert proxy

# Generated at 2022-06-24 02:44:27.197874
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # It should be possible to create a LazyRegex without arguments
    LazyRegex()


# Generated at 2022-06-24 02:44:36.476733
# Unit test for function lazy_compile
def test_lazy_compile():
    regex = LazyRegex(args="^Hello([A-Z]*)\$", kwargs={"re.MULTILINE":True})
    assert regex._real_regex is None
    assert isinstance(regex, LazyRegex)
    assert regex.match("HelloWorld\n").group(0) == "HelloWorld"
    assert regex.match("HelloWorld") is None
    assert regex._real_regex is not None
    assert isinstance(regex._real_regex, type(_real_re_compile("^hello$")))
    assert not isinstance(regex._real_regex, LazyRegex)
    assert regex.match("HelloWorld\n").group(0) == "HelloWorld"
    assert regex.match("HelloWorld") is None

# Generated at 2022-06-24 02:44:44.103729
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile restores the original re.compile."""
    re.compile = lazy_compile
    regex = re.compile('[a-z]')
    if regex.__class__ is not LazyRegex:
        raise AssertionError('re.compile was not overridden to lazy_compile')
    reset_compile()
    regex = re.compile('[a-z]')
    if regex.__class__ is LazyRegex:
        raise AssertionError('re.compile was not restored to real compile')

# Generated at 2022-06-24 02:44:49.707270
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test __unicode__ method of class InvalidPattern"""
    e = InvalidPattern("msg")
    s = unicode(e)
    if s != u"Invalid pattern(s) found. msg":
        raise AssertionError("(%s) != (%s)" % (s, u"Invalid pattern(s) found. msg"))

# Generated at 2022-06-24 02:44:54.342814
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ should succeed."""
    # This test case is designed to test method __getattr__ of class LazyRegex.
    # Method __getattr__ should succeed.
    import re
    pattern = LazyRegex("ab")
    m = pattern.match("ab")
    if m is None:
        raise ValueError("m should not be None.")



# Generated at 2022-06-24 02:45:01.214335
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__() should return equality of self.__dict__."""
    ex1 = InvalidPattern("message")
    ex2 = InvalidPattern("message")
    ex3 = InvalidPattern("diff")
    ex4 = InvalidPattern("")
    assert ex1 == ex2
    assert not ex1 == ex3
    assert not ex1 == ex4
    assert not ex3 == ex4



# Generated at 2022-06-24 02:45:13.204779
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ should return a 'str', never a 'unicode' object."""
    # If method __str__ returns a 'unicode' object, it raises an error.
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
        from ConfigParser import ConfigParser
        config = ConfigParser()
        config.readfp(StringIO("[section]\nentry=value\n"))
        def _decode_list(list_):
            return [(x.decode('utf-8') if isinstance(x, str) else x) for x in list_]

# Generated at 2022-06-24 02:45:20.910453
# Unit test for function reset_compile
def test_reset_compile():
    import re
    test_re_compile = "test_re_compile"
    lazy_compile()
    re.compile('foo')
    assert re.compile != test_re_compile
    reset_compile()
    re.compile('foo')
    assert re.compile == test_re_compile

# Generated at 2022-06-24 02:45:30.676423
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile() can be called multiple times.

    reset_compile() can be called multiple times at any point after
    import_lazy_compile() is called. It should not raise an exception.
    """
    # Compile the module to get rid of the import time assignment to
    # _real_re_compile
    import bzrlib.lazy_regex
    reload(bzrlib.lazy_regex)
    # Compiling it will have reset the flag to lazy_compile and we can
    # check that resetting it works

# Generated at 2022-06-24 02:45:35.083093
# Unit test for function reset_compile
def test_reset_compile():
    _real_re_compile = re.compile
    try:
        install_lazy_compile()
        reset_compile()
        if re.compile is not _real_re_compile:
            raise AssertionError("reset_compile didn't work")
    finally:
        re.compile = _real_re_compile



# Generated at 2022-06-24 02:45:44.677519
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex.

    This test does NOT test the functionality of __setstate__, but only
    the number of attributes in the LazyRegex object before and after
    __setstate__.
    """
    from bzrlib.tests.test_regex import TestCase
    import pickle

    class SetStateTestCase(TestCase):

        def test_setstate(self):
            before = LazyRegex("(").__getstate__()
            after = LazyRegex().__setstate__(before)
            self.assertIs(None, after)
            before = LazyRegex("(").__getstate__()
            after = LazyRegex().__setstate__(before)
            self.assertIs(None, after)
            lazy_regex = LazyRe

# Generated at 2022-06-24 02:45:56.201199
# Unit test for function finditer_public
def test_finditer_public():
    """Test extension to re.finditer, which allows LazyRegex arguments."""
    from bzrlib.tests.matchers import ValidRegex
    from bzrlib.tests import TestCase
    regex_string = '.*'
    m1 = ValidRegex(regex_string, finditer=True).match(regex_string)
    m2 = ValidRegex(regex_string, finditer=True).match(regex_string)
    m3 = ValidRegex(regex_string, finditer=False).match(regex_string)
    m4 = ValidRegex(regex_string, finditer=False).match(regex_string)
    def check(r, *ranges):
        """Assert that the regex has the correct matches."""

# Generated at 2022-06-24 02:46:07.437783
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """test the method `InvalidPattern.__unicode__`.

    This test function is automatically discovered by
    `testtools.TestCase.load_tests_from_module`.
    """
    from bzrlib.tests import TestCase

    class TestInvalidPattern(TestCase):

        def test_gettext_not_imported(self):
            """__unicode__() with _get_format_string() returning None"""
            msg = 'The gettext module is not imported.'
            e = InvalidPattern(msg)

            self.assertEqual(
                'Unprintable exception InvalidPattern: '
                'dict={\'msg\': u\'%s\'}, fmt=None, error=None' % msg,
                unicode(e))


# Generated at 2022-06-24 02:46:10.966331
# Unit test for function finditer_public
def test_finditer_public():
    import doctest
    doctest.testmod()


# Override the default compiled regex method to use lazy compilation
install_lazy_compile()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:46:19.725277
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test to verify the re.compile can be overriden."""
    import bzrlib.repository

    class OverridingRepository(bzrlib.repository.Repository):
        """A Repository which overrides all regex compilation."""
        def __init__(self):
            install_lazy_compile()
            super(OverridingRepository, self).__init__()
        def lock_read(self):
            reset_compile()
            return super(OverridingRepository, self).lock_read()
        def lock_write(self):
            reset_compile()
            return super(OverridingRepository, self).lock_write()
        def lock_tree_write(self):
            reset_compile()
            return super(OverridingRepository, self).lock_tree_

# Generated at 2022-06-24 02:46:24.557191
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    '''This test is to fix bug #671377'''
    r = re.compile('^a')
    assert r.pattern == '^a'
    assert r.__doc__ == re.Pattern.__doc__

# Generated at 2022-06-24 02:46:29.286881
# Unit test for function reset_compile
def test_reset_compile():
    original_compile = re.compile
    re.compile = lazy_compile
    try:
        reset_compile()
    finally:
        re.compile = original_compile
    # Check that the original function is restored
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:46:32.148053
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that unknown attribute return None"""
    regex = LazyRegex(['a'])
    assert regex.foo is None


# Generated at 2022-06-24 02:46:37.294146
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method InvalidPattern.__unicode__."""
    # Test with a message
    obj = InvalidPattern('msg')
    assert obj.__unicode__() == u'msg'
    # Test with no message
    obj = InvalidPattern(None)
    # No assert on this one, we don't know what the output will be
    obj.__unicode__()

# Generated at 2022-06-24 02:46:40.801120
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile restores the original compile method."""
    re.compile = lambda *args: args
    try:
        reset_compile()
    except Exception as e:
        assert(False), "reset_compile raised exception: %s" % e

# Generated at 2022-06-24 02:46:48.263011
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    test = re.compile('test')
    assert type(test) is LazyRegex
    assert test._real_regex is None
    assert test.pattern == 'test'
    reset_compile()
    test = re.compile('test')
    assert type(test) is type(re.compile('test'))
    assert test.pattern == 'test'

# Generated at 2022-06-24 02:46:52.675062
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    regex = LazyRegex(('^branch ', re.I), {})
    dict = regex.__getstate__()
    assert dict['args'] == ('^branch ', re.I)
    assert dict['kwargs'] == {}


# Generated at 2022-06-24 02:47:02.775598
# Unit test for function finditer_public
def test_finditer_public():
    """LazyRegexes should be handled correctly in re.finditer"""
    from cStringIO import StringIO
    from bzrlib.trace import mutter

    # Test that if the pattern is not a LazyRegex, re.finditer works
    # normally
    sio = StringIO()
    mutter_stream = (lambda msg: sio.write(str(msg) + '\n'))

    mutter_stream(_real_re_compile('foo'))
    mutter_stream(re.finditer('foo', 'foo'))

    result = sio.getvalue()
    sio.close()

    assert '<_sre.SRE_Pattern object at' in result, 'Wrong output from finditer'

    # Test that if the pattern is a LazyRegex, the finditer works
    # correctly

# Generated at 2022-06-24 02:47:07.272368
# Unit test for function lazy_compile
def test_lazy_compile():
    r = lazy_compile("[")
    try:
        r.match("a")
    except re.error as e:
        assert "unmatched" in str(e), str(e)
    else:
        assert False


# Generated at 2022-06-24 02:47:14.398406
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ returns unicode object composed of
    the message and the arguments.
    """
    expected_msg = "invalid UUID 'foo'"
    try:
        raise InvalidPattern("invalid UUID '%(uuid)s'")
    except InvalidPattern as err:
        # err.msg must not be unicode because it's used in __str__
        err.msg = "invalid UUID 'foo'"
        assert err.__unicode__() == expected_msg, \
            "InvalidPattern.__unicode__ raised exception %s." % (err)



# Generated at 2022-06-24 02:47:17.590669
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_re import LazyCompileTests
    install_lazy_compile()
    try:
        LazyCompileTests.test_suite()
    finally:
        reset_compile()

# Generated at 2022-06-24 02:47:21.837931
# Unit test for function finditer_public
def test_finditer_public():
    """re.finditer should return a generator (see issue #1513)."""
    s = 'aabb'
    pat = '[ab]'

    m = re.finditer(pat, s)
    assert isinstance(m, types.GeneratorType)
    assert getattr(m.next(), 'group', None) != None

# Generated at 2022-06-24 02:47:32.301219
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    # Test case 1
    err = InvalidPattern('msg')
    assert err.__str__() == 'Invalid pattern(s) found. msg'
    # Test case 2
    class TestException(InvalidPattern):
        _fmt = 'test fmt message'
    err = TestException('msg')
    # For now, test the message manually, so that if gettext changes we don't
    # break this test, rather than relying on a hardcoded string.
    assert err.__str__() == 'test fmt message'
    # Test case 3
    err = InvalidPattern('msg')
    err.other = 'other'
    # Expect a line like:
    # 'Unprintable exception InvalidPattern: dict={'other': 'other', 'msg': 'msg'}, fmt=None, error=None

# Generated at 2022-06-24 02:47:36.614543
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Validating that the __repr__ method of class InvalidPattern works"""
    # Constructing the class with a valid string message
    msg = "Good"
    m = InvalidPattern(msg)
    # Printing the class

# Generated at 2022-06-24 02:47:44.157949
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore the state of LazyRegex correctly"""

    regex = re.compile("(.*)")
    expected_regex_args = regex.pattern
    expected_regex_kwargs = dict(regex.groupindex )

    # Check for a standard LazyRegex
    after_pickle = LazyRegex()
    after_pickle.__setstate__({"args":(expected_regex_args,), "kwargs":expected_regex_kwargs})
    assert (after_pickle._regex_args, after_pickle._regex_kwargs) == ((expected_regex_args,),
                                                                      expected_regex_kwargs)

    # Check for a LazyRegex who was already collapsed
    after_pickle = LazyRegex()
    after_pickle

# Generated at 2022-06-24 02:47:51.648672
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Check if InvalidPattern instances are equal."""
    msg1 = "First message."
    msg2 = "Second message."
    ip1 = InvalidPattern(msg1)
    ip2 = InvalidPattern(msg1)
    ip3 = InvalidPattern(msg2)
    # msg1 == msg1
    assert ip1 == ip2
    # msg1 != msg2
    assert ip1 != ip3
    # msg1 != None
    assert ip1 != None
    # msg1 != "some string"
    assert ip1 != "some string"
    # msg1 != 12345
    assert ip1 != 12345
    # msg1 != CustomClass()
    assert ip1 != CustomClass()


# Generated at 2022-06-24 02:47:58.536924
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """The method InvalidPattern.__repr__() must return something like
       'InvalidPattern(<msg>)'.
    """
    error_pattern = "Invalid pattern(s) found. <msg>"
    msg = u"Unicode message"
    e = InvalidPattern(msg)

    assert e.__repr__() == "%s(%r)" % (e.__class__.__name__, str(msg))

# Generated at 2022-06-24 02:48:06.418508
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """This tests the method __setstate__.

    If you read the code of this method you'll find out that it does not
    really make sense.
    """
    lr = LazyRegex()
    lr.__setstate__({'args': ('abc.*def',), 'kwargs': {'flags': 0}})
    # If we read the code of __setstate__ of class LazyRegex then we
    # will find out that this set the attributes:
    #
    #   lr._regex_args = {'args': ('abc.*def',), 'kwargs': {'flags': 0}}
    #   lr._regex_kwargs = {'args': ('abc.*def',), 'kwargs': {'flags': 0}}
    #
    # which is not what is intended. The method should be implemented like this

# Generated at 2022-06-24 02:48:14.037208
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern."""
    import doctest
    _fmt = getattr(InvalidPattern, '_fmt', None)
    if _fmt is not None:
        del InvalidPattern._fmt
    try:
        doctest.testmod(optionflags=doctest.REPORT_ONLY_FIRST_FAILURE)
    finally:
        if _fmt is not None:
            InvalidPattern._fmt = _fmt

# Generated at 2022-06-24 02:48:22.779500
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """This function tests the constructor of class LazyRegex.

    There is a bug when calling the copy.deepcopy method on a
    LazyRegex object. This test shows the bug.
    """
    import copy
    rex = re.compile('^/home/foo/bar/file\.gz')
    lrex = LazyRegex(('^/home/foo/bar/file\.gz',))

    # This is the line which shows the bug
    lrex_c = copy.deepcopy(lrex)


# Install the default lazy compile on import, so that calling
# re.compile() will return a lazy compiled object by default.
install_lazy_compile()

# Generated at 2022-06-24 02:48:32.410384
# Unit test for function finditer_public
def test_finditer_public():
    # The functions finditer() return an iterator. Calling next()
    # on the iterator raise StopIteration when the end of the string
    # has been reached.

    # We want to test finditer_public() returns an iterator.
    # To do it we call next() on the returned iterator.

    # We raise a ValueError when we try to call next() on an
    # iterator of a string which has no match.
    # So the function finditer_public() returns an iterator.

    import re
    pattern = r'ab.'
    string = 'a'
    pattern_obj = re.compile(pattern)
    iterator = finditer_public(pattern, string)
    try:
        next(iterator)
    except ValueError:
        pass

if __name__ == '__main__':
    test_finditer_public()

# Generated at 2022-06-24 02:48:43.476441
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method __getattr__ of class LazyRegex."""
    # This tests __getattr__

    import sys

    test_regex = LazyRegex()

    # The regex must not be compiled yet
    assert test_regex._real_regex is None
    # Get an attribute
    assert hasattr(test_regex, "pattern")
    # The regex must be compiled now
    assert test_regex._real_regex is not None
    # This must call the real regex object
    regex_pattern = test_regex.pattern
    assert test_regex._real_regex.pattern == regex_pattern

    # Get the attribute flags and check that it is the same as
    # the real regex object
    regex_flags = test_regex.flags

# Generated at 2022-06-24 02:48:49.578604
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() restores compiled regex to original state."""
    global _real_re_compile
    _real_re_compile = re.compile
    install_lazy_compile()
    reset_compile()
    # this should be the default compile function again.
    assert re.compile is _real_re_compile
    # We should be able to call this any number of times, so call it
    # again just to make sure.
    reset_compile()
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:48:57.090609
# Unit test for function finditer_public
def test_finditer_public():
    string = "abcdefghijk"
    pattern = LazyRegex()
    pattern._regex_args = ("^a",)
    found = finditer_public(pattern, string)
    first = found.next()
    import re
    # Check to see if finditer_public calls pattern.finditer
    assert isinstance(first, re.MatchObject)
    # Check to see if finditer_public doesn't call pattern.finditer
    assert isinstance(finditer_public("^a", string), re.MatchObject)

# Generated at 2022-06-24 02:49:05.448983
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ of LazyRegex should return dictionary with args and kwargs.

    This test shows that __getstate__ returns a dictionary with the args and
    kwargs that were passed to the LazyRegex object.
    """
    import pickle
    some_regex = re.compile("pattern", re.IGNORECASE)
    lazy_regex = LazyRegex(some_regex.pattern, some_regex.flags)
    state = lazy_regex.__getstate__()
    assert state["args"] == ("pattern",)
    assert state["kwargs"] == {"flags": re.IGNORECASE}

# Generated at 2022-06-24 02:49:12.751637
# Unit test for function finditer_public
def test_finditer_public():
    """Tests for function finditer_public"""
    from bzrlib.tests import TestCase
    finditer_public('a', 'abc')
    finditer_public(re.compile('a'), 'abc')
    finditer_public(lazy_compile('a'), 'abc')
    TestCase.assertRaises(InvalidPattern, finditer_public, '', '')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:49:24.678353
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for method __getstate__ of class LazyRegex"""
    from bzrlib.tests import TestCase

    class TestLazyRegex__getstate__(TestCase):
        """Test for method __getstate__ of class LazyRegex"""

        def setUp(self):
            # Create a LazyRegex object to be used in the test
            self.lazy_regex = LazyRegex(
                args=('ab',),
                kwargs={'flags': re.IGNORECASE},
                )

        def test_getstate_return_a_dict(self):
            """Test that __getstate__ return a dict"""
            self.assertIsInstance(self.lazy_regex.__getstate__(), type({}))


# Generated at 2022-06-24 02:49:32.154567
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that LazyRegex proxy works"""
    compile_args = (r"^\s*(?:#|$)", )
    compile_kwargs = {'flags': re.IGNORECASE | re.MULTILINE}
    p = LazyRegex(compile_args, compile_kwargs)

    assert p._real_regex is None

    assert p.search('abc') is not None
    assert p._real_regex is not None

    assert p._real_regex.search('abc') is not None

# Generated at 2022-06-24 02:49:44.996712
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex

    Passing an invalid regex pattern throws InvalidPattern.
    """
    import pickle
    pickled_lazy_regex_args = pickle.dumps({
            "args": ('[',),
            "kwargs": {},
            })
    pickled_lazy_regex_kwargs = pickle.dumps({
            "args": (),
            "kwargs": {'pattern': '['},
            })
    lazy_regex = LazyRegex()
    try:
        pickle.loads(pickled_lazy_regex_args, lazy_regex)
        raise AssertionError('Unpickling an invalid regex pattern'
            ' should throw InvalidPattern')
    except InvalidPattern as e:
        pass

# Generated at 2022-06-24 02:49:52.957718
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method LazyRegex.__getstate__"""
    lr = LazyRegex(args=(r'a', ), kwargs={})
    state = lr.__getstate__()
    assert state == {'args': (r'a', ), 'kwargs': {}}
    lr = LazyRegex(args=(r'a', ), kwargs={'flags': 42})
    state = lr.__getstate__()
    assert state == {'args': (r'a', ), 'kwargs': {'flags': 42}}


# Generated at 2022-06-24 02:49:59.356058
# Unit test for function finditer_public
def test_finditer_public():
    """Test the finditer override when LazyRegex is used."""
    from bzrlib.tests import TestCase

    class test_finditer_public(TestCase):
        def test_finditer_public(self):
            p = lazy_compile('\w+')
            self.assertEqual(list(finditer_public(p, 'foo')),
                                [m for m in p.finditer('foo')])
            p = lazy_compile('\d+')
            self.assertEqual(list(finditer_public(p, 'foo')),
                                [m for m in p.finditer('foo')])

    test_finditer_public().test_finditer_public()

# Generated at 2022-06-24 02:50:04.780073
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of class InvalidPattern"""
    msg = "error message"
    exc = InvalidPattern(msg)
    # Check class type
    assert isinstance(exc, InvalidPattern)
    # Check message attribute
    assert getattr(exc, 'msg') == msg


# Generated at 2022-06-24 02:50:07.139208
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex objects should call their regex on demand """
    regex = LazyRegex(["a"])
    assert regex.pattern is None
    regex = LazyRegex(["a"])
    regex.search("a")
    assert regex.pattern is not None
    regex = LazyRegex(["a"])
    regex.match("a")
    assert regex.pattern is not None

# Generated at 2022-06-24 02:50:17.085233
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should not raise an exception"""
    class MyException(InvalidPattern):
        _fmt = 'Exception %(msg)s'

    e1 = MyException('msg')
    e2 = MyException('msg')
    e3 = MyException('msg2')

    # The following lines should not raise an exception
    assert e1 == e1
    assert e1 != e3
    # It should work with a real Unicode object in e1
    e1 = MyException(u'msg')
    assert e1 == e2
    # It should work with a real Unicode object in e2
    e2 = MyException(u'msg')
    assert e1 == e2
    # It should work with a Unicode object with accents in e1
    e1 = MyException(u'ms\xe8g')
    assert e1 == e2

# Generated at 2022-06-24 02:50:21.695981
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""
    import pickle
    proxy = LazyRegex()
    proxy_state = proxy.__getstate__()
    expected_state = {
            "args": (),
            "kwargs": {},
            }
    assert expected_state == proxy_state, \
        "Unexpected proxy state: %s" % str(proxy_state)



# Generated at 2022-06-24 02:50:25.011787
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    from bzrlib.tests.regexs import test_suite
    return doctest.DocTestSuite()

# Generated at 2022-06-24 02:50:35.329509
# Unit test for function finditer_public
def test_finditer_public():
    if hasattr(re, 'finditer'):
        # Test whether finditer_public can handle LazyRegex object
        re.finditer = None
        pattern = LazyRegex(["a+"], {})
        pattern._real_regex = object()
        pattern._real_regex.finditer = lambda string: 'abc'
        iterator = finditer_public(pattern, 'abcde')
        assert iterator == 'abc'

        # Test whether finditer_public can handle non LazyRegex object
        pattern = object()
        pattern.finditer = lambda string: 'bc'
        iterator = finditer_public(pattern, 'abcde')
        assert iterator == 'bc'
    else:
        # We don't need to test finditer_public as re.finditer isn't patched
        pass

# Generated at 2022-06-24 02:50:37.058035
# Unit test for function reset_compile
def test_reset_compile():
    import doctest, bzrlib.tests
    return doctest.DocTestSuite(bzrlib.tests.test_regex_lazy_compile)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:50:42.880303
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method InvalidPattern.__eq__"""
    class Dummy(InvalidPattern):
        _fmt = ('KeyError: %(key)s')
    error1 = Dummy("Key not found")
    error2 = Dummy("Key not found")
    error3 = Dummy("Another error")
    assert error1 == error2
    assert error2 == error1
    assert error1 != error3

# Generated at 2022-06-24 02:50:54.615186
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__(attr) should return a member from the proxied regex object.
    """
    lazyregex = LazyRegex()
    # If the regex hasn't been compiled yet, _real_regex should be None
    # and raise AttributeError.
    try:
        lazyregex.findall()
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError not raised by LazyRegex().')
    # set _real_regex to a value and test again.
    lazyregex._real_regex = '_real_regex'
    try:
        lazyregex.findall()
    except AttributeError:
        raise AssertionError('AttributeError raised by LazyRegex().')



# Generated at 2022-06-24 02:51:04.348486
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test function for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext

    # check the default behaviour
    e = InvalidPattern("")
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError("__unicode__ doesn't return a unicode object")

    # now set _preformatted_string, it should take precedence
    e._preformatted_string = u"foo"
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError("__unicode__ doesn't return a unicode object")
    if u != "foo":
        raise AssertionError("__unicode__ doesn't return the expected unicode object")

    # check the string is translated
   

# Generated at 2022-06-24 02:51:07.025716
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.i18n import gettext
    gettext(u'Invalid pattern(s) found. %(msg)s')
    i = InvalidPattern('msg')
    i.msg = 'Invalid pattern(s) found. %(msg)s'
    repr(i)

# Generated at 2022-06-24 02:51:11.962993
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that lazy_compile works as expected"""
    install_lazy_compile()
    regex = re.compile('a')
    reset_compile()
    assert isinstance(regex, LazyRegex)


# Test basic LazyRegex operations.

# Generated at 2022-06-24 02:51:24.719663
# Unit test for function finditer_public
def test_finditer_public():
    # the original finditer() works
    re.finditer("^Foo", "Foo bar")
    re.finditer("^Foo", "Foo bar", re.I | re.S)
    # a LazyRegex with pattern as Unicode is not accepted
    try:
        re.finditer(u'^Foo', "Foo bar")
        assert False, "LazyRegex with pattern as Unicode should fail"
    except TypeError as err:
        assert "ordinal" in str(err)
    # a LazyRegex with pattern as bytes is accepted
    re.finditer(b'^Foo', b"Foo bar")
    re.finditer(b'^Foo', b"Foo bar", re.I | re.S)
    # Unicode finditer()

# Generated at 2022-06-24 02:51:31.556377
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method __eq__ of class InvalidPattern

    Class InvalidPattern overrides method __eq__. This test proves it was
    indeed overridden. Before this test was added, the test suite would
    raise an exception that method __eq__ was not implemented.
    """
    ip1 = InvalidPattern('msg')
    ip2 = InvalidPattern('msg')
    assert ip1 == ip2

# Generated at 2022-06-24 02:51:36.573505
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__ should compare all attributes by value."""
    a = InvalidPattern('')
    b = InvalidPattern('')
    assert a == a
    assert a == b
    b.msg = 'foo'
    assert a != b

# Generated at 2022-06-24 02:51:45.735516
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Some of the various cases in which an InvalidPattern can be created are
    tested in this function.
    """
    # The following are tested in this function:
    # InvalidPattern(msg)
    #   Unicode message encoded in utf8
    #   Unicode message
    #   String message
    #   String message encoded in unicode
    try:
        raise InvalidPattern('hah')
    except InvalidPattern as e:
        # This tests the case when a Unicode message is encoded in utf8
        assert str(e) == 'hah'
    try:
        raise InvalidPattern(u'f\xedch')
    except InvalidPattern as e:
        # This tests the case when the message is a real Unicode
        assert str(e) == 'f\xc3\xadch'

# Generated at 2022-06-24 02:51:53.104616
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    p = LazyRegex(("^[\\w][\\w\\-\\d\\.]*\\w$"), dict())
    dict_state = {'args': ("^[\\w][\\w\\-\\d\\.]*\\w$",), 'kwargs': {}}
    p.__setstate__(dict_state)
    assert p._regex_args == ("^[\\w][\\w\\-\\d\\.]*\\w$",)


# Generated at 2022-06-24 02:52:00.908078
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the LazyRegex class used by lazy_compile"""
    reset_compile()
    # Test that it lazily compiles
    lazy_re = LazyRegex(r"lazy")
    assert(lazy_re._real_regex is None)
    assert(re.match(lazy_re, "lazydog"))
    assert(lazy_re._real_regex is not None)

    # It should be possible to copy the proxy object
    lazy_re2 = lazy_re.__copy__()
    assert(lazy_re is not lazy_re2)
    assert(lazy_re._real_regex is lazy_re2._real_regex)

    # The proxy object should work like the regex object
    assert(re.match(lazy_re, "lazycat"))

   

# Generated at 2022-06-24 02:52:10.494350
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Unit test for getstate.

    __getstate__ should return a dict containing the arguments of the
    constructor.
    """
    proxy = LazyRegex(('foo',), {'bar': 'baz'})
    dict = proxy.__getstate__()
    if dict['args'] != ('foo',) or dict['kwargs'] != {'bar': 'baz'}:
        raise AssertionError(
            "__getstate__ returned an unexpected dictionary."
            "\nExpected: {'args': ('foo',), 'kwargs': {'bar': 'baz'}}"
            "\nGot: %s" % dict)



# Generated at 2022-06-24 02:52:18.072522
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lazy_regex = LazyRegex()
    lazy_regex.__setstate__({'args': ('^a.*z$',), 'kwargs': {'flags': re.IGNORECASE}})
    if lazy_regex._regex_args != ('^a.*z$',):
        raise AssertionError("lazy_regex.regex_args is not ('^a.*z$',)")
    if lazy_regex._regex_kwargs != {'flags': re.IGNORECASE}:
        raise AssertionError("lazy_regex.regex_kwargs are not {'flags': re.IGNORECASE}")


# Generated at 2022-06-24 02:52:28.441579
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__ should provide useful equality semantics"""
    import doctest
    doctest.testmod()
    e1 = InvalidPattern('msg')
    e2 = InvalidPattern('msg')
    e3 = InvalidPattern('other msg')
    e4 = ValueError(InvalidPattern('msg'))

    # Our __eq__ is based on __dict__. So this is a necessary constraint.
    # If these fail, we are broken and need to fix it!
    assert e1.__dict__ == {'msg': u'msg'}
    assert e2.__dict__ == {'msg': u'msg'}
    assert e3.__dict__ == {'msg': u'other msg'}

    # As normal, identity is most important
    assert e1 is e1
    assert e1 is not e2
    assert e1

# Generated at 2022-06-24 02:52:40.233954
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() must return a 'str' object
    """
    from bzrlib.transport.http import HttpError
    from bzrlib.trace import mutter
    import sys

    # error message should be 'str' on python2
    if sys.version_info[0] < 3:
        exc_str = '' + 'ascii'
    elif sys.version_info[0] >= 3:
        # and 'unicode' on python 3
        exc_str = '' + 'utf8'
    else:
        return
    if not isinstance(exc_str, str):
        raise AssertionError("test_InvalidPattern___str__ is not valid on "
                             "this python version.")
    args = ('msg',)
    kwargs = {}

# Generated at 2022-06-24 02:52:43.967703
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile can be called multiple times without error."""
    re.compile = _real_re_compile
    re.compile('a')
    reset_compile()
    reset_compile()

# Generated at 2022-06-24 02:52:56.526459
# Unit test for function finditer_public
def test_finditer_public():
    from bzrlib import tests
    import re
    # Test with a real pattern
    real_pattern = "hello world"
    foo = re.finditer(real_pattern, "hello world")
    tests.assertIsInstance(foo, re.SRE_Match)
    # Test with a LazyRegex
    lazy_pattern = LazyRegex(("hello world",))
    bar = re.finditer(lazy_pattern, "hello world")
    # Here it is tricky to test it because LazyRegex.finditer returns
    # an iterator which doesn't have a class of its own but implements
    # all the methods.
    tests.assertIsInstance(bar, object)
    tests.assertIs(bar._real_regex, None)
    # And now the moment of truth...
    bar.next()

# Generated at 2022-06-24 02:53:02.688864
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib.tests import TestCase
    import re
    class TestLazyRegex(TestCase):

        def test_init(self):
            LazyRegex(('a',), {})

    test_lazy_regex = TestLazyRegex('test_init')
    test_suite = test_lazy_regex.test_suite()
    return test_suite



# Generated at 2022-06-24 02:53:06.880677
# Unit test for function reset_compile
def test_reset_compile():
    """Reset_compile restores original value of re.compile"""
    original = re.compile
    install_lazy_compile()
    new = re.compile
    reset_compile()
    assert re.compile is original
