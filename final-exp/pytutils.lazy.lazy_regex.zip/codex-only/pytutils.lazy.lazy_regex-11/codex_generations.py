

# Generated at 2022-06-24 02:43:12.056025
# Unit test for function reset_compile
def test_reset_compile():
    original_compile = re.compile
    re.compile = lambda x: None
    try:
        reset_compile()
    finally:
        re.compile = original_compile



# Generated at 2022-06-24 02:43:18.412407
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Ensure overriding __getattr__ works as expected"""
    import re
    class TestClass(object):
        def __init__(self):
            self._real_regex = None
        def _compile_and_collapse(self):
            self._real_regex = "compiled"
        def __getattr__(self, attr):
            if self._real_regex is None:
                self._compile_and_collapse()
            # Once we have compiled, the only time we should come here
            # is actually if the attribute is missing.
            return getattr(self._real_regex, attr)
    tc = TestClass()
    # Nothing compiled yet; we should get the instance
    # When the attribute exists, we shouldn't go into the __getattr__ code

# Generated at 2022-06-24 02:43:22.748591
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Ensure that InvalidPattern.__eq__ is implemented in a sane way.

    Two InvalidPatterns which do not have the same format string and
    __dict__ are not equal.
    """
    from bzrlib.i18n import gettext
    class IP1(InvalidPattern):
        _fmt = gettext('Invalid pattern(s) found. %(msg)s')
    class IP2(InvalidPattern):
        _fmt = gettext('Invalid patterns found. %(msg)s')
    ip1 = IP1('abc')
    ip2 = IP2('abc')
    ip3 = IP1('xyz')
    ip4 = IP2('xyz')
    def check_ip(a, b, expected):
        eq = a == b
        ne = a != b
        if eq and ne:
            raise Assert

# Generated at 2022-06-24 02:43:28.655230
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """test exception InvalidPattern"""

# Generated at 2022-06-24 02:43:31.681569
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    install_lazy_compile()
    assert re.compile is lazy_compile
    reset_compile()
    assert re.compile is _real_re_compile



# Generated at 2022-06-24 02:43:39.152166
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should always return a string"""

    # If you are not using to_unicode and to_string consistently (everywhere)
    # then this test is likely to fail.
    from bzrlib.i18n import gettext

    # A try/except block is used so that the outcome of this test can be
    # compared to test_InvalidPattern___unicode__, which does not use
    # a try/except block.

# Generated at 2022-06-24 02:43:45.850072
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Testing method __getattr__ in class LazyRegex
    """
    #TODO: This would be better as a doctest
    try:
        re.compile('(a')
    except re.error:
        pass
    else:
        raise AssertionError('Should have raised re.error')

    # Recreate the error since its __init__ won't do anything if the
    # compile fails
    try:
        re.compile('(a')
    except re.error:
        e = re.error('error')
    if e.__class__ is not re.error:
        raise AssertionError('Expected e.__class__ to be re.error')
    if e.__class__ is not InvalidPattern:
        raise AssertionError('Expected e.__class__ to be InvalidPattern')

   

# Generated at 2022-06-24 02:43:54.680553
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return the attribute of the real regex object
    _real_regex.

    Attributes with name of _real_regex_attributes_to_copy should be copied
    in the proxy for performance.
    """
    class DummyPattern(object):
        """A Dummy regex pattern object.

        It is used to fake the real regex object in the following test case.
        """

    class DummyRegex(LazyRegex):
        """A Dummy LazyRegex object.

        Another class, not LazyRegex, can inherit from LazyRegex, so a
        DummyRegex class is needed to test the method __getattr__ of class
        DummyRegex.
        """
        _real_regex_attributes_to_copy = []

    dum = DummyRegex()
    # The

# Generated at 2022-06-24 02:43:58.288010
# Unit test for function reset_compile
def test_reset_compile():
    test_compile = object()
    re.compile = test_compile
    reset_compile()
    assert _real_re_compile is re.compile

# Unit tests for function install_lazy_compile

# Generated at 2022-06-24 02:44:05.852834
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import _i18n_pyx as _i18n
    def _reset_translator():
        _i18n.set_output_encoding()
        _i18n.set_comparison_encoding()
        _i18n.set_translation_target(None)
        _i18n._translations = {}
    def _set_translator(lang_code):
        _i18n.set_output_encoding('UTF-8')
        _i18n.set_comparison_encoding('UTF-8')
        _i18n._translations = {}
        _i18n.set_translation_target(lang_code)
    _reset_translator()
    # First we try with a message containing only ascii
    test_msg = u'test'

# Generated at 2022-06-24 02:44:17.454992
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for InvalidPattern.__eq__()
    """
    def check_equal(a, b):
        msg = "%s should be equal with %s" % (str(a), str(b))
        assert a == b, msg
    def check_not_equal(a, b):
        msg = "%s should not be equal with %s" % (str(a), str(b))
        assert a != b, msg
    e = InvalidPattern('a')
    check_equal(e, e)
    check_equal(e, InvalidPattern('a'))
    check_equal(e, InvalidPattern('b'))
    check_not_equal(e, InvalidPattern('a', 'c'))
    check_not_equal(e, InvalidPattern(''))
    check_not_equal(e, InvalidPattern())
    check_

# Generated at 2022-06-24 02:44:21.648741
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ returns a dict with the right keys and values"""
    lazy_regex = lazy_compile('some pattern')
    state = lazy_regex.__getstate__()
    assert state == {"args": ('some pattern',), "kwargs": {}}


# Generated at 2022-06-24 02:44:30.397874
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern objects should be equal to other InvalidPattern objects
    with the same attributes.

    The __eq__ method of InvalidPattern should implement this equality.

    """
    attrs = {'a': 'b'}
    a = InvalidPattern('xyz')
    a.__dict__.update(attrs)

    b = InvalidPattern('abc')
    b.__dict__.update(attrs)

    c = InvalidPattern('abc')

    assert (a == b)
    assert (b != c)

# Generated at 2022-06-24 02:44:38.183612
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import cPickle as pickle
    import pickletools

    def state_dis(state):
        """Disassemble a pickle STATE opcode."""
        # STATE is a pickle opcode that starts a tuple, and it's followed by a
        # bunch of PUT opcodes.
        dis = pickletools.dis(state + pickle.dumps('bogus'))
        for op, arg, pos in dis:
            if op.code == pickle.PUT:
                yield arg

    # Create a LazyRegex object and pickle it
    r = LazyRegex((), {})
    data = pickle.dumps(r)
    # Disassemble the pickle
    dis = state_dis(data)

    # We can use a different pickle protocol, the only important thing is the
    # first item in

# Generated at 2022-06-24 02:44:39.750278
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-24 02:44:42.523464
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit tests for method __eq__ of class InvalidPattern"""
    e = InvalidPattern('foo')
    f = InvalidPattern('bar')
    g = InvalidPattern('foo')

    assert e is not g
    assert e == g
    assert f != g

# Generated at 2022-06-24 02:44:49.383133
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import i18n
    m = i18n.gettext("foo")
    e = InvalidPattern(m)
    e.msg = m
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u"foo"

# Generated at 2022-06-24 02:44:52.077375
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    l = LazyRegex(args=('b',))

    # If the regex hasn't been compiled yet, compile it
    attr = l.pattern
    expected_attr = 'b'
    assert attr == expected_attr

# Generated at 2022-06-24 02:45:00.767534
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ of LazyRegex should return the 'args' and 'kwargs' used in
    the constructor.
    """
    class MockLazyRegex(LazyRegex):
        def _compile_and_collapse(self):
            pass

    lazy_object = MockLazyRegex((), {})
    args, kwargs = lazy_object.__getstate__()
    assert args == ()
    assert kwargs == {}
    lazy_object = MockLazyRegex(("foo", "bar"), {"baz": "qux"})
    args, kwargs = lazy_object.__getstate__()
    assert args == ("foo", "bar")
    assert kwargs == {"baz": "qux"}

# Generated at 2022-06-24 02:45:10.817428
# Unit test for function lazy_compile
def test_lazy_compile():
    p = lazy_compile('foo')
    if p._real_regex is not None:
        raise AssertionError

    p.search('foo')
    if p._real_regex is None:
        raise AssertionError
    # Check that we have the same interface as the real object
    m = p.search('foo')
    m.group()
    m.groups()

    regexs = []
    def my_compile(pattern, *args, **kwargs):
        regex = _real_re_compile(pattern, *args, **kwargs)
        regexs.append(regex)
        return regex

    re.compile = my_compile
    # We've overridden re.compile now and should be using it.
    p = lazy_compile('foo')

# Generated at 2022-06-24 02:45:17.513968
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # test the case where the attribute is in _regex_attributes_to_copy
    obj = LazyRegex()
    obj._compile_and_collapse()
    for attr in LazyRegex._regex_attributes_to_copy:
        assert hasattr(obj, attr)
    # test the case where the attribute is not in _regex_attributes_to_copy
    # and the regex has not been compiled
    obj = LazyRegex()
    assert not hasattr(obj, '__getstate__')
    # test the case where the attribute is not in _regex_attributes_to_copy
    # and the regex has been compiled
  

# Generated at 2022-06-24 02:45:23.041080
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # Check we are not already installing the compile wrapper
    if re.compile is not lazy_compile:
        # Install the compile wrapper
        install_lazy_compile()
        # Check the compile wrapper is installed
        assert re.compile is lazy_compile
        # Uninstall the compile wrapper
        reset_compile()
        # Check the compile wrapper is uninstalled
        assert re.compile is not lazy_compile

test_install_lazy_compile()

# Generated at 2022-06-24 02:45:28.011308
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regexp = "[0-9]+"
    lazyRegex = re.compile(regexp)
    assert isinstance(lazyRegex, LazyRegex)
    assert lazyRegex._real_regex is None
    assert lazyRegex._regex_args == (regexp, )
    assert lazyRegex._regex_kwargs == {}
    assert lazyRegex.match("123")

# Generated at 2022-06-24 02:45:37.505549
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex."""
    from cStringIO import StringIO
    from bzrlib.tests import TestCase
    from bzrlib.tests.per_regex import TestCaseWithRegex

    class TestRegex(TestCaseWithRegex):

        def test_getstate(self):
            """Test get state use in LazyRegex."""
            p = r'(?P<name>\w+) (?P<surname>\w+) (?P<age>\d+)'
            r = LazyRegex((p,))
            state = r.__getstate__()
            self.assertEqual({'args': (p,), 'kwargs': {}}, state)


# Generated at 2022-06-24 02:45:43.292960
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that we can install and uninstall lazy_compile"""
    install_lazy_compile()
    regex = re.compile('a.*b')
    assert isinstance(regex, LazyRegex)
    assert regex.search('abc') == _real_re_compile('a.*b').search('abc')
    reset_compile()
    regex = re.compile('a.*b')
    assert isinstance(regex, _real_re_compile)

# Generated at 2022-06-24 02:45:48.559401
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__() should return a dictionary representation of
    the object, used by pickle.
    """
    regex = LazyRegex('test', {'test_kw_arg': 'test'})
    state = regex.__getstate__()
    expected_state = {
        'args': ('test',),
        'kwargs': {'test_kw_arg': 'test'},
        }
    assert state == expected_state



# Generated at 2022-06-24 02:45:53.643559
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test if __str__ correctly converts the unicode message to utf8"""
    msg = u'abc'
    ip = InvalidPattern(msg)
    assert(ip.__str__() == 'abc')
    msg = u'abc\xe9d\xf3'
    ip = InvalidPattern(msg)
    assert(ip.__str__() == 'abc\xc3\xa9d\xc3\xb3')

# Generated at 2022-06-24 02:46:05.202721
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test if LazyRegex method __getattr__ works as expected"""
    regex = re.compile("\w{2}")
    proxy_regex = re.compile("\w{2}")

    # Before use any method, assert that the regex object is not compiled
    assert proxy_regex._real_regex is None

    # Use the regex object with and without being lazy
    assert regex.findall("aa bb cc") == proxy_regex.findall("aa bb cc")

    # Once the proxy object is used, assert that the regex object is compiled
    assert proxy_regex._real_regex is not None

    # Now, test that accessing to a invalid attribute raises an AttributeError
    # for the real regex object and for the proxy one.

# Generated at 2022-06-24 02:46:15.726842
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """This tests for errors in the constructor of class InvalidPattern."""
    # Any str causes the exception to be raised
    try:
        raise InvalidPattern("foo")
    except ValueError:
        pass
    else:
        raise AssertionError("InvalidPattern should raise ValueError")
    # Invalid format string shows the exception
    try:
        raise InvalidPattern("%(foo")
    except ValueError as e:
        if not str(e).startswith("invalid format string"):
            raise AssertionError("InvalidPattern should raise ValueError "
                    "with invalid format string, but got %r" % str(e))
    else:
        raise AssertionError("InvalidPattern should raise ValueError")

# Generated at 2022-06-24 02:46:21.843936
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    # Test LazyRegex.__getstate__ with a regular pattern
    lr = LazyRegex(("^.*$",), {})
    s = lr.__getstate__()
    # Test LazyRegex.__getstate__ with a pattern based on a compiled one
    p = re.compile('^.*$')
    lr = LazyRegex((p,), {})
    s = lr.__getstate__()



# Generated at 2022-06-24 02:46:28.363733
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test __repr__ method of InvalidPattern."""
    obj = InvalidPattern("Invalid pattern found")
    assert repr(obj) == "InvalidPattern('Invalid pattern found')"
    obj = InvalidPattern("invalid pattern")
    assert repr(obj) == "InvalidPattern('invalid pattern')"
    assert repr(obj) == "InvalidPattern('invalid pattern')"
    obj = InvalidPattern("")
    assert repr(obj) == "InvalidPattern('')"

# Generated at 2022-06-24 02:46:32.055781
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib import tests
    tests.SyntaxTestCase.load_tests(__file__, globals(), [''])

# Generated at 2022-06-24 02:46:42.234311
# Unit test for function reset_compile
def test_reset_compile():
    original_re_compile = re.compile
    try:
        import bzrlib.lazy_regex as lazy_regex
        lazy_regex.install_lazy_compile()
        if re.compile is not lazy_regex.lazy_compile:
            raise AssertionError(
                "re.compile has been overridden but is not" \
                " lazy_compile")
        lazy_regex.reset_compile()
        if re.compile is not original_re_compile:
            raise AssertionError(
                "re.compile has been overridden but is not" \
                " the original value")
    finally:
        re.compile = original_re_compile

# Generated at 2022-06-24 02:46:44.341528
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    class TestInvalidPattern(InvalidPattern):
        _fmt = ('Invalid pattern(s) found. %(msg)s')

    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 02:46:47.099419
# Unit test for function reset_compile
def test_reset_compile():
    """reset_compile restores original re.compile"""
    install_lazy_compile()
    reset_compile()



# Generated at 2022-06-24 02:46:54.153199
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr = LazyRegex((r'foo',), {})
    re.compile = _real_re_compile
    assert lr.match('foobar')
    try:
        lr = LazyRegex((r'(foo',), {})
    except InvalidPattern:
        pass
    else:
        raise AssertionError("Missing ')' not detected")

# Generated at 2022-06-24 02:47:00.758228
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # InvalidPattern.__unicode__() should return unicode
    from bzrlib.errors import BzrError

    # The exception raises in BzrError.__init__()
    ex = BzrError(u'Missing argument (format): %s')
    # The checked exception
    exc = InvalidPattern(u'Missing argument (format): %s')
    # The error message of ex and exc should be equal
    assert str(ex) == str(exc)

# Generated at 2022-06-24 02:47:05.533582
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. foo'
        assert repr(e) == 'InvalidPattern(Invalid pattern(s) found. foo)'
        try:
            raise InvalidPattern('bar')
        except InvalidPattern as e2:
            assert e == e2
            assert e2 == e
            assert str(e2) == 'Invalid pattern(s) found. bar'
            assert repr(e2) == 'InvalidPattern(Invalid pattern(s) found. bar)'
            assert e != e2
            assert e2 != e

# Generated at 2022-06-24 02:47:07.966714
# Unit test for function finditer_public
def test_finditer_public():
    re.compile = _real_re_compile
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:47:09.920798
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Tests that repr() of InvalidPattern does not raise an exception."""
    repr(InvalidPattern('foo'))

# Generated at 2022-06-24 02:47:12.347791
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr = LazyRegex(('[0-9]+',))
    assert isinstance(lr, LazyRegex)
    return lr



# Generated at 2022-06-24 02:47:20.547430
# Unit test for function finditer_public
def test_finditer_public():
    # The different classes are import in different places
    from bzrlib.diff import get_diff_options_from_help
    from bzrlib.diff import Option
    from bzrlib.diff import ui
    from bzrlib.diff import _ExtractOptionsTest
    from bzrlib.tests import TestCase

    class ExtractOptionsTest(_ExtractOptionsTest):
        """ExtractOptionsTest specific to re.finditer_public

        This is done to have only one test.
        """

        def check_help_extraction_of_option(self, lines, expected_options,
                                            expected_usage=None):
            """Check extraction of options.

            This function detects if the test should be done.
            If not, it eases the call to the generic case.
            """

# Generated at 2022-06-24 02:47:25.666112
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test the method LazyRegex.__getstate__()"""
    regex = LazyRegex(args=("12",))
    state = regex.__getstate__()
    assert state == {"args":("12",), "kwargs":{}}


# Generated at 2022-06-24 02:47:34.284466
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # We don't use the test_suite() function because we need to pass
    # a keyword argument to _real_re_compile.
    global _real_re_compile
    _real_re_compile = re.compile

    def make_exc(pattern, error_msg):
        try:
            lazy_compile(pattern)
        except InvalidPattern as e:
            return e


# Generated at 2022-06-24 02:47:41.672332
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    x = re.compile('foo')
    assert isinstance(x, LazyRegex)
    install_lazy_compile()
    try:
        y = re.compile('bar')
        assert isinstance(y, LazyRegex)
        z = re.search('baz')
        assert z is None
    finally:
        reset_compile()
    a = re.compile('def')
    assert not isinstance(a, LazyRegex)

# Generated at 2022-06-24 02:47:46.925218
# Unit test for function finditer_public
def test_finditer_public():
    """Unit test for function finditer_public
    
    This test creates a LazyRegex object, and calls the replacement of the
    re.finditer function.
    """
    lr = LazyRegex(args=('b',), kwargs={})
    assert(finditer_public(lr, 'abc') == [])

# Some libraries calls re.split which fails it if receives a LazyRegex.

# Generated at 2022-06-24 02:47:53.501261
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern(a) returns 'InvalidPattern(a)'"""
    a = "test"
    out = InvalidPattern(a).__repr__()
    expected = 'InvalidPattern(test)'
    # Test if the __repr__ method is working properly.
    # If the following test fails, it would create an error while building
    # the documentation, when the exception InvalidPattern is raised.
    assert(out == expected)



# Generated at 2022-06-24 02:48:03.589675
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """test that constructor of LazyRegex can handle errors in re.compile()"""

    # test dealing with exceptions when LazyRegex is created
    e = None

# Generated at 2022-06-24 02:48:12.855351
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile
    install_lazy_compile()
    # Should have been overridden
    assert re.compile is not _real_re_compile
    # Should have been overridden with lazy_compile
    assert re.compile is lazy_compile
    # Should be able to compile a regex
    re.compile('a')
    # Should be able to restore
    reset_compile()
    assert re.compile is _real_re_compile
    # Should be able to compile a regex
    re.compile('a')

# Generated at 2022-06-24 02:48:16.531011
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile resets to the original compile."""
    re.compile = lambda *args, **kwargs: "compile"
    reset_compile()
    assert re.compile('a') == 'a'

# Generated at 2022-06-24 02:48:20.222372
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Check constructor of LazyRegex"""
    r = LazyRegex(('^(?:bla)*$',), {'re.DOTALL': False})
    assert type(r) == LazyRegex

# Duplicate of re.compile, in order to get coverage

# Generated at 2022-06-24 02:48:26.888727
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    caught_exception = False
    # test if constructor throws an exception
    try:
        LazyRegex(('some_string',))
    except e:
        caught_exception = True

    if not caught_exception:
        raise AssertionError('constructor for class LazyRegex should raise exception because some_string is invalid')

# Generated at 2022-06-24 02:48:32.623232
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test LazyRegex.__init__()."""
    r = LazyRegex()
    assert isinstance(r, LazyRegex)
    assert r._regex_args == ()
    assert r._regex_kwargs == {}
    r = LazyRegex(('foo',), {'flag':'a'})
    assert isinstance(r, LazyRegex)
    assert r._regex_args == ('foo',)
    assert r._regex_kwargs == {'flag':'a'}


# Generated at 2022-06-24 02:48:43.809991
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test method '__eq__' of class InvalidPattern.

    InvalidPattern.__eq__ uses a number of attributes to compare objects
    for equality. It turns out that some attributes are None under
    some situations and sometimes not. See bug 775558 for an example.
    """
    from bzrlib.trace import mutter
    from bzrlib.i18n import gettext

    # Set the message in the domain bzrlib
    msg = 'My message'
    gettext(msg, domain='bzrlib')

    # Create a class that inherits from class InvalidPattern
    class MyInvalidPattern(InvalidPattern):
        """A class inheriting from class InvalidPattern."""
        # Overwrite attribute _fmt with a format string
        _fmt = gettext("Invalid pattern found. %(msg)s")

    # Here come the

# Generated at 2022-06-24 02:48:49.447613
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """InvalidPattern.__eq__ should return True if objects are equal and
    False if they are not.
    """
    if InvalidPattern('msg') != InvalidPattern('msg'):
        raise AssertionError("Expected equal objects to be equal.")
    if InvalidPattern('msg') == InvalidPattern('msg2'):
        raise AssertionError("Expected different objects to not be equal.")
    if InvalidPattern('msg',) != InvalidPattern('msg',):
        raise AssertionError("Expected equal objects to be equal.")

# Generated at 2022-06-24 02:48:55.779547
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalid_pattern = InvalidPattern('This is a pattern')
    unicode_message = unicode('Invalid pattern(s) found. '
                              '"This is a pattern"')
    if str(invalid_pattern) != unicode_message:
        raise AssertionError('The __str__ method of InvalidPattern does not '
                             'return the expected message.')

# Generated at 2022-06-24 02:49:00.813422
# Unit test for function reset_compile
def test_reset_compile():
    import sys
    re.compile = lazy_compile
    reset_compile()
    if not re.compile is _real_re_compile:
        sys.exit("Expect re.compile is _real_re_compile")
    reset_compile()
    if not re.compile is _real_re_compile:
        sys.exit("Expect re.compile is _real_re_compile")
test_reset_compile()
# end test_reset_compile

# Generated at 2022-06-24 02:49:12.232773
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    from bzrlib.trace import format_exception_only as format_exc_only
    from bzrlib.trace import format_exception as format_exc
    import sys

    # We try a few options for raising an InvalidPattern, to make sure all
    # the cases are covered.
    class TestException(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super(TestException, self).__init__(*args, **kwargs)

    # Test case 1: A plain exception is raised
    try:
        raise TestException()
    except TestException as e:
        tb = sys.exc_info()[2]
        exc_msg = str(e)  # exc_

# Generated at 2022-06-24 02:49:19.297566
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex does not initialize the underlying regex."""
    lr = LazyRegex('.')
    # _real_regex is not initialized
    assert lr._real_regex is None
    # But compile_and_collapse works
    assert lr._compile_and_collapse() == lr._real_regex
    assert lr._real_regex is not None


# Generated at 2022-06-24 02:49:24.497502
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that the __str__ method of InvalidPattern returns a str instead of
    a unicode object.
    """
    ip = InvalidPattern('test pattern')
    s = str(ip)
    # s should be a str or a subclass of str.
    assert(isinstance(s, str))
    # s should not be an unicode object
    assert(not isinstance(s, unicode))

# Generated at 2022-06-24 02:49:28.939932
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('message')
    assert e.msg == 'message'
    assert str(e) == 'Invalid pattern(s) found. message'
    assert repr(e) == "InvalidPattern('message')"
    assert unicode(e) == u'Invalid pattern(s) found. message'

# Generated at 2022-06-24 02:49:33.015402
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    import doctest
    results = doctest.testmod(bzrlib.errors)
    if results.failed:
        raise AssertionError('doctest of %s from %s has failed.' % (__name__,
                                                                     __file__))

# Generated at 2022-06-24 02:49:45.696444
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function."""
    p = lazy_compile('a')

    # Test that the object returns the right type
    import sre_compile
    assert type(p) == LazyRegex

    # Test that compiling works.
    assert type(p._real_regex) == sre_compile.SRE_Pattern
    assert p.sub('b', 'a') == 'b'

    # Test that replacing re.compile works.
    install_lazy_compile()

# Generated at 2022-06-24 02:49:50.148479
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = lazy_compile
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError(
            "reset_compile failed to restore the original compile routine")

# Generated at 2022-06-24 02:49:52.138908
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Unit test for method __repr__ of class InvalidPattern."""
    error = InvalidPattern('msg')
    repr(error)


# Generated at 2022-06-24 02:49:55.284211
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr__ of class InvalidPattern"""
    err = InvalidPattern('Some message')
    # check that the repr is valid
    eval(repr(err))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:50:07.878404
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import tests
    from bzrlib.tests.test_i18n import setup_test_i18n
    if tests.is_running_from_subunit():
        raise tests.TestSkipped('Cannot test str(InvalidPattern) in subunit.')
    setup_test_i18n()
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert str(e) == "Invalid pattern(s) found. foo"
        assert unicode(e) == u"Invalid pattern(s) found. foo"
        e._fmt = ("Your regex '%(pattern)s' is invalid. %(msg)s")
        e.msg = "bar"
        e.pattern = r"\w"

# Generated at 2022-06-24 02:50:14.166975
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test get attribute on lazy regex."""
    pattern = r"a.*b"
    string = "a starting with a and ending with b"
    lr = LazyRegex((pattern, re.IGNORECASE))
    match = lr.match(string)
    if match is None:
        raise AssertionError("match failed with pattern %s and string %s"
                            % (pattern, string))


# Generated at 2022-06-24 02:50:23.790997
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile works."""
    import re, sys
    import bzrlib.tests
    # override the original, save the new one.
    regex = re.compile("hello")
    install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError("re.compile is not now a LazyRegex. "
            "Instead it is %r" % (re.compile,))
    # reset_compile should restore the original.
    reset_compile()
    if re.compile is not _real_re_compile:
        raise AssertionError("re.compile is not now the original. "
            "Instead it is %r" % (re.compile,))


# Generated at 2022-06-24 02:50:27.859485
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = "not the original"
    reset_compile()

# Generated at 2022-06-24 02:50:32.778069
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that the LazyRegex constructor works"""
    pattern = LazyRegex((r"a", re.IGNORECASE), kwargs={})
    assert pattern._regex_args == (r"a", re.IGNORECASE)
    assert pattern._regex_kwargs == {}

# Generated at 2022-06-24 02:50:39.969768
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib.tests.blackbox import TestCaseWithBlackbox
    from bzrlib.tests.test_trace import LoggingStream

    class TestLazyRegex(TestCaseWithBlackbox):

        def setUp(self):
            super(TestLazyRegex, self).setUp()
            # To show what triggers the regex compilation
            # we replace _compile_and_collapse by our custom
            # method.
            LazyRegex._compile_and_collapse = self._compile_and_collapse

        def _compile_and_collapse(self):
            self.trace("re.compile(%s, %s)" % (self._regex_args,
                    self._regex_kwargs))
            # Call the original method

# Generated at 2022-06-24 02:50:46.085113
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('a')

    # __str__ and __unicode__ must return a str
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert 'a' in str(e)
    assert 'a' in unicode(e)

    # __str__ and __unicode__ must return the expected value
    msg = 'Error trying to compile "*": multiple repeat'
    e = InvalidPattern('*')
    assert msg in str(e)
    assert msg in unicode(e)

# Generated at 2022-06-24 02:50:51.449184
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test InvalidPattern exception.

    Converts InvalidPattern exception to unicode, utf8 and string
    and assert that the output is a string and unicode objects
    respectively.
    """
    e = InvalidPattern('This is a test')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-24 02:50:55.173479
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lr1 = LazyRegex(("^a", ))
    lr2 = LazyRegex(("^b", ))
    lr3 = LazyRegex(("^a", ))
    lr4 = LazyRegex()

    assert lr1 != lr2
    assert lr1 == lr3
    assert lr1 != lr4

# Generated at 2022-06-24 02:51:01.393796
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ must return a string"""
    msg = unicode("Failed to compile pattern")
    e1 = InvalidPattern(msg)
    assert str(e1) == msg
    assert repr(e1) == 'InvalidPattern(%r)' % msg
    msg = str("Failed to compile pattern")
    e2 = InvalidPattern(msg)
    assert str(e2) == msg
    assert repr(e2) == 'InvalidPattern(%r)' % msg

# Generated at 2022-06-24 02:51:08.699481
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__"""

    from bzrlib.tests import TestNotApplicable
    try:
        class InvalidPatternSub(InvalidPattern):
            """Subclass for testing purpose."""

    except TypeError:
        raise TestNotApplicable("__eq__ of InvalidPattern is not implemented")

    # InvalidPattern can compare with itself
    error = InvalidPattern('some error')
    assert error == error
    assert not error != error

    # InvalidPattern can compare with different values
    error2 = InvalidPattern('some error')
    assert error == error2
    assert not error != error2

    # InvalidPatternSub can compare with itself
    sub_error = InvalidPatternSub('some error')
    assert sub_error == sub_error
    assert not sub_error != sub_error

    # InvalidPattern can compare with InvalidPatternSub
    assert error == sub_error

# Generated at 2022-06-24 02:51:20.779772
# Unit test for function lazy_compile
def test_lazy_compile():
    from bzrlib import tests
    # have to import this here, as this is being called during import time.
    install_lazy_compile()

    # Make sure that the re module is still behaving normally
    r1 = re.compile("a")
    r2 = re.compile("a")
    r3 = re.compile("b")
    r4 = re.compile("a",re.IGNORECASE)
    tests.TestCase.assertNotEqual(r1,r2)
    tests.TestCase.assertEqual(r1,r3)
    tests.TestCase.assertEqual(r1,r4)

    # And that we can also get lazy regexs
    l1 = lazy_compile("a")
    l2 = lazy_compile("a")
    l3 = lazy_

# Generated at 2022-06-24 02:51:25.242295
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method __getattr__ of class LazyRegex"""
    pattern = '.*'
    string = "foo"
    regex = lazy_compile(pattern)
    assert regex.match(string) is not None



# Generated at 2022-06-24 02:51:29.035995
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    args = (r'\btest\b', re.MULTILINE)
    kwargs = {'flags': re.MULTILINE}
    regex = LazyRegex(args, kwargs)
    assert regex._regex_args == args
    assert regex._regex_kwargs == kwargs


# Generated at 2022-06-24 02:51:32.848289
# Unit test for function reset_compile
def test_reset_compile():
    """Ensure that reset_compile properly restores re.compile"""
    def test_func():
        pass
    re.compile = test_func
    reset_compile()
    assert_equal(re.compile, _real_re_compile)

# Generated at 2022-06-24 02:51:43.910104
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of the InvalidPattern class should create a Unicode string"""
    from bzrlib.i18n import gettext

    class TestException(InvalidPattern):
        _fmt = (
            "\n"
            "Some patterns are invalid. %(msg)s\n"
            "These patterns might be valid Perl regular expressions, but "
            "are not valid patterns for Bazaar: %(msglist)s\n"
            "See \"help regex\" for more information about Perl regular "
            "expressions that are used in Bazaar.\n"
            )

    # invalid msg
    exc_not_unicode = TestException(msg='a')
    assert isinstance(exc_not_unicode.msg, str)
    assert isinstance(exc_not_unicode.__unicode__(), unicode)

    # invalid

# Generated at 2022-06-24 02:51:45.412063
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Should not raise any exception
    InvalidPattern('').__unicode__()

# Generated at 2022-06-24 02:51:50.116669
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test __eq__ method of InvalidPattern class"""
    ip = InvalidPattern('Error message')
    ip2 = InvalidPattern('Error message')
    ip3 = InvalidPattern('Error message 3')
    assert( ip == ip2 )
    assert( ip3 != ip )

# Generated at 2022-06-24 02:51:58.474506
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # Test that the basic features of class InvalidPattern are working.
    from bzrlib import osutils
    message = 'Test message'
    ap = InvalidPattern(message)
    try:
        osutils.raise_unicode_exception(ap)
    except UnicodeError:
        # This is the expected result due to a unicode_exception bug.
        # This is a known bug and we don't need to test it further.
        pass
    try:
        osutils.raise_unicode_exception(ap)
    except UnicodeError:
        # This is the expected result due to a unicode_exception bug.
        # This is a known bug and we don't need to test it further.
        pass

# Generated at 2022-06-24 02:52:02.556369
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must set the same state than __getstate__"""
    regex = LazyRegex(args=('FROM:.*<.*\\@.*>',))
    state = regex.__getstate__()
    regex.__setstate__(state)
    assert state == regex.__getstate__()

# Generated at 2022-06-24 02:52:13.308307
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex

    If a LazyRegex is pickled and then unpickled, then the argument used
    to create the LazyRegex object are preserved.
    """
    args = ['[0-9]{2}:[0-9]{2}', re.S]
    kwargs = {'anchor': True}
    lr = LazyRegex(args, kwargs)
    lr_dict = lr.__getstate__()
    lr.__setstate__(lr_dict)
    # Get the value args were set to.
    lr_args = getattr(lr, "_regex_args")
    # Get the value kwargs were set to.
    lr_kwargs = getattr(lr, "_regex_kwargs")


# Generated at 2022-06-24 02:52:22.347136
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from unittest import TestCase

    class TestInvalidPattern___eq__(TestCase):

        def test_differ__class(self):
            class _Dummy(InvalidPattern):
                _fmt = ''
            _object = _Dummy('')
            self.assertNotEqual(_object, InvalidPattern(''))

        def test_differ__dict(self):
            _object1 = InvalidPattern('')
            _object1.foo = 'bar'
            _object2 = InvalidPattern('')
            _object2.spam = 'eggs'
            self.assertNotEqual(_object1, _object2)

        def test_differ__fmt(self):
            class _Dummy(InvalidPattern):
                _fmt = 'foo'
            _object1 = _Dummy('')
            _object

# Generated at 2022-06-24 02:52:27.924769
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test the __eq__ method of the InvalidPattern exception"""
    # We don't test the non implemented case because it raises NotImplemented
    # which is error prone to test.
    pattern1 = InvalidPattern("some message")
    pattern2 = InvalidPattern("another message")
    pattern3 = InvalidPattern("some message")
    pattern4 = InvalidPattern("some message")
    pattern4.extra = "some extra data"
    assert pattern1 != pattern2
    assert pattern1 == pattern3
    assert pattern1 != pattern4

# Generated at 2022-06-24 02:52:36.414793
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    import weakref
    lazy_regex = LazyRegex((r"abc",), {})
    old_re_compile = re.compile
    _real_re_compile(r"abc")
    re.compile = old_re_compile
    ref = weakref.ref(lazy_regex)
    del lazy_regex
    if ref() is not None:
        raise AssertionError("LazyRegex constructor does not work.")



# Generated at 2022-06-24 02:52:48.100140
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy = LazyRegex(('(a)', ), {})
    # For starters, LazyRegex is a subclass of object
    assert isinstance(lazy, object)

    # Check that we can serialize and unserialize
    import cPickle
    reser = cPickle.loads(cPickle.dumps(lazy))
    # And the compiled regex isn't part of the serialized data
    assert reser._real_regex is None

    # Check that we can get state
    state = lazy.__getstate__()
    assert state['args'] == ('(a)', )
    assert state['kwargs'] == {}

    # Check that setting state also works
    lazy.__setstate__(state)
    assert lazy._regex_args == ('(a)', )
    assert lazy._regex_kwargs

# Generated at 2022-06-24 02:52:55.419906
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    install_lazy_compile()
    try:
        test_lazy_proxy = re.compile("test")
        assert(test_lazy_proxy is not None)
        assert(test_lazy_proxy._real_regex is None)
        result = test_lazy_proxy.match("test")
        assert(test_lazy_proxy._real_regex is not None)
        assert(result is not None)
    finally:
        reset_compile()


# Generated at 2022-06-24 02:53:06.831856
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that lazy_compile actually works"""
    # Set it back to normal
    reset_compile()
    # check that the default compile works
    regex = re.compile(r'\w+')
    assert regex.pattern == r'\w+'
    # Now make it compile lazily
    install_lazy_compile()
    assert re.compile is lazy_compile
    regex = re.compile(r'\w+')
    assert regex.pattern == r'\w+'
    assert regex._real_regex is None
    # Now we access it, so it should be compiled
    assert regex.pattern == r'\w+'
    assert regex._real_regex is not None
    # Now reset it
    reset_compile()
    assert re.compile is not lazy_compile
   