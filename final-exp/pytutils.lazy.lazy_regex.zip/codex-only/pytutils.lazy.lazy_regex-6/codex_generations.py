

# Generated at 2022-06-24 02:43:15.594785
# Unit test for function finditer_public
def test_finditer_public():
    """Test if finditer_public works as expected."""
    lazy_pattern = lazy_compile('[ab]*')
    matches=list(finditer_public(lazy_pattern, 'aabbaa'))
    assert len(matches) == 2
    locations=[(match.start(), match.end()) for match in matches]
    assert locations == [(0, 0), (2, 4)]


# importing this module will make all regexes lazy, though you can
# explicitly use lazy_compile to create one.
install_lazy_compile()

# Generated at 2022-06-24 02:43:18.094721
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    import sys
    import six
    if sys.version_info.major == 3:
        assert six.text_type(InvalidPattern('fake message')) == \
            'InvalidPattern(\\\'fake message\\\')'
    else:
        assert str(InvalidPattern('fake message')) == \
            'InvalidPattern(\'fake message\')'

# Generated at 2022-06-24 02:43:29.666436
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    import bzrlib._lazy_regex
    assert isinstance(bzrlib._lazy_regex.InvalidPattern('test'), Exception)
    assert isinstance(unicode(bzrlib._lazy_regex.InvalidPattern('')), str)
    import re
    try:
        re.compile('')
        assert False, "InvalidPattern must be raised"
    except bzrlib._lazy_regex.InvalidPattern as e:
        assert e.msg in e.__unicode__()
        assert e._format() == e.__unicode__()

# Generated at 2022-06-24 02:43:33.324001
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """This test checks that the __unicode__ method of InvalidPattern
    returns a proper unicode object.
    """
    import bzrlib.errors as errors
    err = errors.InvalidPattern("pattern foo matches nothing")
    unicode(err)



# Generated at 2022-06-24 02:43:35.032150
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex = LazyRegex(patterns=['^test$'])
    assert_equal('test', regex.pattern)


# Generated at 2022-06-24 02:43:40.379212
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should be case insensitive"""

    ip_one = InvalidPattern('the msg')
    ip_two = InvalidPattern('the msg')
    ip_three = InvalidPattern('The msg')
    ip_four = InvalidPattern('not a msg')
    ip_five = InvalidPattern('')
    ip_six = InvalidPattern(None)

    assert(ip_one == ip_two)
    assert(ip_one == ip_three)
    assert(ip_one != ip_four)
    assert(ip_one == ip_five)
    assert(ip_one == ip_six)

# Generated at 2022-06-24 02:43:49.423553
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ of class LazyRegex"""
    lazy = LazyRegex(('foo',), {})
    dict = {'args': ('bar',), 'kwargs': {}}
    lazy.__setstate__(dict)
    assert getattr(lazy, '_regex_args', None) == ('bar',)
    assert getattr(lazy, '_regex_kwargs', None) == {}
    assert getattr(lazy, '_real_regex', None) == None

# Generated at 2022-06-24 02:43:54.593357
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ works"""
    a = InvalidPattern(u'Un printable exception')
    assert(isinstance(a.__unicode__(), unicode))
    assert(u'Un printable exception' in a.__unicode__())

# Generated at 2022-06-24 02:44:00.543284
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex.__getattr__."""

    lr = LazyRegex()
    try:
        lr.findall()
    except AttributeError:
        pass
    else:
        raise AssertionError("LazyRegex.__getattr__" \
                             " not raising AttributeError")
    lr._compile_and_collapse()
    lr.findall("a")

# Generated at 2022-06-24 02:44:07.741015
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    # Test with a preformatted string
    e = InvalidPattern('Invalid message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    if sys.version_info[0] < 3:
        # Test with a str in _fmt
        e = InvalidPattern('Invalid message')
        e._fmt = 'format message'
        assert str(e) == 'format message'
    # Test with a unicode in _fmt
    e = InvalidPattern('Invalid message')
    e._fmt = u'format message'
    assert str(e) == 'format message'

# Generated at 2022-06-24 02:44:13.724194
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a string."""
    import doctest
    doctest.testmod()
    msg = 'test message'
    e = InvalidPattern(msg)
    s = repr(e)
    assert isinstance(s, str)
    assert s.startswith('InvalidPattern(')
    assert msg in s
    assert s.endswith(')')

# Generated at 2022-06-24 02:44:18.321897
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    instance = LazyRegex(None, None)
    ret = instance.__getstate__()
    assert ret == {'args': None, 'kwargs': None}



# Generated at 2022-06-24 02:44:24.975244
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Method test_LazyRegex___getattr__ of class LazyRegex"""
    # add a new method to the LazyRegex class
    class MyLazyRegex(LazyRegex):
        def __init__(self):
            LazyRegex.__init__(self)
            self._real_regex = self._real_re_compile("(?P<name>.*)")
            # add the attributes _regex_args and _regex_kwargs (needed by
            # the object returned by re.compile)
            setattr(self, "_regex_args", ["(?P<name>.*)"])
            setattr(self, "_regex_kwargs", {})
            self.__getattr__ = self.getattr_for_test

# Generated at 2022-06-24 02:44:33.801081
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test for method __eq__ of class InvalidPattern"""
    # Dummy class for testing method __eq__
    class DummyInvalidPattern(InvalidPattern):
        _fmt = ''
    # 1. Both objects are valid
    # Create 2 instances of DummyInvalidPattern
    dummy_obj_1 = DummyInvalidPattern(None)
    dummy_obj_2 = DummyInvalidPattern(None)
    assert dummy_obj_1 == dummy_obj_2
    # 2. Both objects are invalid
    # Create 2 instances of InvalidPattern
    invalid_obj_1 = InvalidPattern(None)
    invalid_obj_2 = InvalidPattern(None)
    assert invalid_obj_1 == invalid_obj_2
    # 3. Only one object is invalid
    # Create an instance of InvalidPattern and an instance of DummyInvalidPattern
    invalid_obj_1

# Generated at 2022-06-24 02:44:43.501096
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Exercise the __unicode__ method of InvalidPattern class.

    __unicode__ should return a unicode object and it should be possible to
    translate the returned string.
    """
    import bzrlib.i18n
    old_translate = bzrlib.i18n._translate
    old_default_encoding = bzrlib.i18n._default_encoding

# Generated at 2022-06-24 02:44:52.118718
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that the lazy compile proxy actually works.

    This could be a little more thorough, but I'm just trying to catch
    regressions.
    """
    install_lazy_compile()
    try:
        pattern1 = re.compile('foo')
        pattern2 = re.compile('foo')
        # Make sure that two LazyRegexs don't compare equal.
        assert not (pattern1 == pattern2)
        # Now check that they compile and are equal
        assert pattern1 == pattern1._real_regex
        assert pattern1 == pattern2._real_regex
        assert len(pattern1.findall('foo')) == 1
        assert len(pattern1.findall('foofoo')) == 2
    finally:
        reset_compile()

# Generated at 2022-06-24 02:45:02.170847
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import (
        errors,
        )
    # This tests a preformatted error message string
    e = errors.InvalidPattern('error msg\n')
    e._preformatted_string = 'preformatted: %s' % e.msg
    str(e)
    # This tests a message which is constructed from the msg attribute
    e = errors.InvalidPattern('error msg\n')
    e._fmt = 'error #%(msg)s'
    str(e)
    # This tests a message which is constructed from the msg attribute
    # but the msg attribute is not unicode
    e = errors.InvalidPattern('error msg\n')
    e._fmt = 'error #%(msg)s'
    str(e)

# Generated at 2022-06-24 02:45:13.418815
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr__ of class InvalidPattern.
    """
    from bzrlib.tests import TestCase
    from bzrlib import osutils
    from bzrlib import tests
    from bzrlib.i18n import gettext, _
    tests.i18n_setup()

    class TestableInvalidPattern(InvalidPattern):
        _fmt = 'Regex error: %(msg)s'

    tst = TestCase()
    msg = 'fake error from re.compile'

    pattern = TestableInvalidPattern(msg)
    tst.assertEqual(str(pattern),
                    'Regex error: fake error from re.compile')
    # tst.assertEqual(unicode(pattern),
    #                 u'Regex error: fake error from re.compile')
    # t

# Generated at 2022-06-24 02:45:22.851910
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the basic functionality of lazy_compile()."""
    compile = lazy_compile
    # When compiling a regex, we should receive a proxy back
    assert isinstance(compile('c'), LazyRegex)
    # We should also find that the proxy compiles
    assert compile('c').search('abc') is not None
    # Proxies should also be picklable
    import pickle
    unpickled = pickle.loads(
            pickle.dumps(compile('.*'), pickle.HIGHEST_PROTOCOL))
    assert unpickled.match('abc') is not None
    # and that reset_compile() is reversible
    reset_compile()
    assert re.compile is not compile
    assert re.compile is _real_re_compile



# Generated at 2022-06-24 02:45:28.427545
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex.

    This test can prevent from regressions in the method.

    The test checks that we can get an attribute from a compiled regex.
    """
    pattern = lazy_compile('^a')
    # Here we call pattern.search()
    if pattern.search('a'):
        return True
    # The regex wasn't compiled before we called search, so we should have
    # thrown an exception here
    return False

# Generated at 2022-06-24 02:45:32.965246
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test the method __eq__ of class InvalidPattern"""
    m = "a message"
    e1 = InvalidPattern(m)
    e2 = InvalidPattern(m)
    e3 = InvalidPattern("another message")
    assert e1 == e2, "Expected e1 == e2"
    assert e1 != e3, "Expected e1 != e3"

# Generated at 2022-06-24 02:45:43.206833
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for LazyRegex.__getstate__().

    Test if the state is correctly persisted.
    """
    from cStringIO import StringIO
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.transport import get_transport
    import pickle

    test_data = [
        (r'(?i)foo', {}),
        (r'(?i)foo', {'flags': re.IGNORECASE}),
        (r'foo', {'flags': re.IGNORECASE}),
    ]

    for regex, kwargs in test_data:
        regex_object = lazy_compile(regex, **kwargs)


# Generated at 2022-06-24 02:45:49.870033
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__() should return the state to use when pickling."""
    r = LazyRegex(['a'])
    state = r.__getstate__()
    assert state == {
        "args": ['a'],
        "kwargs": {},
        }


# Generated at 2022-06-24 02:45:59.314694
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Testing str() of InvalidPattern instances."""
    string = 'abc'
    error = InvalidPattern(string)
    assert str(error) == string, 'str(error) != string'
    assert unicode(error) == string, 'unicode(error) != string'
    # now test the same with an utf8 string
    # this is a not too bad looking smiley face (:-)
    string = '\xc3\xbc'
    error = InvalidPattern(string)
    assert str(error) == string, 'str(error) != string'
    assert unicode(error) == string, 'unicode(error) != string'

# Generated at 2022-06-24 02:46:03.770194
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Unit test for function install_lazy_compile"""
    original = re.compile
    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
        assert re.compile('foo') is not None
    finally:
        reset_compile()
        assert re.compile is original

# Generated at 2022-06-24 02:46:07.349646
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ of class InvalidPattern should return a string"""
    s = 'Invalid pattern(s) found. %(msg)s'
    e = InvalidPattern(s)
    r = repr(e)
    assert(type(r) == str)

# Generated at 2022-06-24 02:46:13.665850
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Check that InvalidPattern.__repr__() gives the expected result, as
    expected by HPSS (test test_regex_wrappers.TestLazyRegex.test_repr).
    """
    msg = 'I18N_MSG_ID_1'
    e = InvalidPattern(msg)
    s = repr(e)
    expected = 'InvalidPattern(I18N_MSG_ID_1)'
    assert s == expected

# Generated at 2022-06-24 02:46:18.649530
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile function.

    This function tests that reset_compile does restore the
    original function to re.compile().

    This function is not intended to be called directly.
    It is automatically called by the test framework.
    """
    from bzrlib import tests
    global test_reset_compile
    test_reset_compile = tests.expecting_errors(None)
    reset_compile()
    test_reset_compile = tests.expecting_errors(ValueError)
    reset_compile()



# Generated at 2022-06-24 02:46:30.539897
# Unit test for function finditer_public
def test_finditer_public():
    """__doc__ for test_finditer_public."""

    pattern = lazy_compile('a')
    result = finditer_public(pattern, 'aaa')
    # Return a iterator
    _real_iterator = iter(result)
    for i, l in enumerate(_real_iterator):
        text, match = l.group(), l.groups()
        if i == 0:
            assert text == 'a'
            assert match == ()
        elif i == 1:
            assert text == 'a'
            assert match == ()
        elif i == 2:
            assert text == 'a'
            assert match == ()
        else:
            raise AssertionError(
                "Should not be here: text, match: %s,%s" % (text, match))
    assert i == 2
    pattern = None
    result

# Generated at 2022-06-24 02:46:37.769874
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import testtools
    e = InvalidPattern(u"foo")
    testtools.TestCase.assertEqual(e, InvalidPattern(u"foo"))
    testtools.TestCase.assertEqual(e, InvalidPattern(u"foo".encode('utf-8')))
    testtools.TestCase.assertNotEqual(e, InvalidPattern(u"baz"))
    testtools.TestCase.assertRaises(TypeError, e.__eq__, 1)
    testtools.TestCase.assertRaises(TypeError, e.__eq__, Exception())

# Generated at 2022-06-24 02:46:50.017974
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import unittest
    import sys
    utf8enc = None
    utf16enc = None
    for enc in ['utf_8', 'cp1131', 'ascii']:
        try:
            'abc'.decode(enc)
        except (LookupError, UnicodeError):
            continue
        if utf8enc is None:
            utf8enc = enc
        elif utf16enc is None:
            utf16enc = enc
            break
    if utf16enc is None:
        raise unittest.SkipTest('missing utf8 and utf16 encoding')
    enc = sys.getdefaultencoding()

# Generated at 2022-06-24 02:46:54.633899
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    reset_compile()
    assert re.compile is _real_re_compile
    install_lazy_compile()
    reset_compile()
    assert re.compile is _real_re_compile


# Install the lazy compile by default
install_lazy_compile()

# Generated at 2022-06-24 02:47:02.250408
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set the state of the _real_regex attribute."""
    from pickle import loads
    from pickle import dumps
    re_args = ("^(|.*?[\\/])foo$",)
    re_kwargs = {"flags":re.IGNORECASE}
    lr = LazyRegex(re_args, re_kwargs)
    lr._compile_and_collapse()
    dumps(lr)
    lr = loads(dumps(lr))
    assert lr._real_regex == re.compile(*re_args, **re_kwargs)

# Generated at 2022-06-24 02:47:06.061328
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # We test here InvalidPattern.__unicode__ because
    # InvalidPattern is used in re.py also, in which case
    # it is used with a preformatted message.
    err = InvalidPattern(unicode('The message'))
    assert err.__unicode__() == unicode('The message')

# Generated at 2022-06-24 02:47:11.545301
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern"""

    msg = 'foo'
    ex = InvalidPattern(msg)
    assert repr(ex) == "InvalidPattern('" + msg + "')"
    # unicode message
    ex = InvalidPattern(u'foo')
    assert repr(ex) == "InvalidPattern('" + msg + "')"



# Generated at 2022-06-24 02:47:19.934593
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    # Verify that two InvalidPatterns are equal if they have the same
    # attributes
    msg = 'foo'
    ip1 = InvalidPattern(msg)
    ip2 = InvalidPattern(msg)
    note('verify two InvalidPatterns with same attributes are equal')
    eq(ip1, ip2)

    # Verify that two InvalidPatterns are not equal if they have different
    # attributes
    msg1 = 'foo'
    msg2 = 'foo2'
    ip1 = InvalidPattern(msg1)
    ip2 = InvalidPattern(msg2)
    note('verify two InvalidPatterns with different attributes are not equal')
    ne(ip1, ip2)

    # Verify that two InvalidPatterns are not equal if they have different
    # class
    msg = 'foo'
    ip1 = InvalidPattern(msg)
    ip2

# Generated at 2022-06-24 02:47:31.679449
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    import sys
    import unittest
    class TestCase(unittest.TestCase):
        def test_default(self):
            err1 = InvalidPattern('some message')
            err2 = InvalidPattern('some message')
            self.assertEqual(err1, err2)
            self.assertEqual(err2, err1)
            # Check the behavior of equality when the exception contains a
            # list
            err1 = InvalidPattern(['some message', 'another message'])
            err2 = InvalidPattern(['some message', 'another message'])
            self.assertEqual(err1, err2)
            self.assertEqual(err2, err1)
            err3 = InvalidPattern(['some message', 'Another message'])

# Generated at 2022-06-24 02:47:42.837024
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # This test should not use str(instance_of_InvalidPattern)
    # but rather instance_of_InvalidPattern.__unicode__() instead
    # so that a UnicodeDecodeError is raised if and only if
    # instance_of_InvalidPattern.__unicode__() returns a unicode
    # object and the default encoding is unable to decode the unicode
    # object.
    ip1 = InvalidPattern('message')
    ip2 = InvalidPattern('message')
    ip3 = InvalidPattern('something else')
    # test repr()
    repr(ip1)
    repr(ip3)
    # test str()
    str(ip1)
    str(ip3)
    # test comparisons
    ip1 == ip1
    ip1 != ip3
    ip1 >= ip2
    ip2 <= ip1
    ip1 > ip

# Generated at 2022-06-24 02:47:44.733387
# Unit test for function reset_compile
def test_reset_compile():
    """Reset re.compile back to normal"""
    reset_compile()
    re.compile("^")

# Generated at 2022-06-24 02:47:48.994118
# Unit test for function finditer_public
def test_finditer_public():
    regex = re.compile('(?P<name>[^@:]+)@(?P<host>[^:]+)')
    rgx_iter = finditer_public(regex, "foo@bar")
    match = rgx_iter.next()
    assert match.groupdict() == {'name': 'foo', 'host': 'bar'}

# Generated at 2022-06-24 02:47:56.516531
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Calls __eq__ of InvalidPattern with various arguments, and
    check if the result matches expectation.
    """
    first = InvalidPattern('a')
    # pass same object
    second = first
    assert first == second
    # pass same type, same attribute
    second = InvalidPattern('a')
    assert first == second
    # pass same type, different attibute
    second = InvalidPattern('b')
    assert first != second
    # pass different type, anything
    second = ValueError()
    assert first != second

# Generated at 2022-06-24 02:48:00.663855
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    l = LazyRegex(('a', ), {'b': 'c'})
    assert l._regex_args == ('a', )
    assert l._regex_kwargs == {'b': 'c'}
    assert l._real_regex is None

# Generated at 2022-06-24 02:48:03.787723
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Check that LazyRegex.__getattr__ works as expected."""
    lr = LazyRegex(('a*',))
    # Don't trigger compilation
    assert not lr._real_regex
    assert lr.match('aaaa')



# Generated at 2022-06-24 02:48:09.453924
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__() restores LazyRegex object from pickled object

    If an object of class LazyRegex is unpickled and then __setstate__() is
    called on it then the object should be restored and all its attributes
    correctly set
    """
    x = lazy_compile('(a)')
    x._compile_and_collapse()
    a = x.match('a').group(0)
    s = cPickle.dumps(x, -1)
    y = cPickle.loads(s)
    assert(a == 'a')
    assert(y._real_regex.match('a').group(0) == 'a')

# Generated at 2022-06-24 02:48:11.702354
# Unit test for function reset_compile
def test_reset_compile():
    """Test the reset_compile function."""
    reset_compile()
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-24 02:48:14.923682
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should return a string"""
    error = InvalidPattern('Invalid pattern')
    assert isinstance(repr(error), str)
    assert repr(error) == "InvalidPattern(Invalid pattern)"

# Generated at 2022-06-24 02:48:24.023942
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set _regex_args, _regex_kwargs"""
    args = ("some", "regex",)
    kwargs = {"flags": re.UNICODE}
    lazy_regex = lazy_compile(*args, **kwargs)
    state = lazy_regex.__getstate__()
    new_lazy_regex = LazyRegex()
    new_lazy_regex.__setstate__(state)
    new_lazy_regex._compile_and_collapse()
    assert new_lazy_regex._real_regex.pattern == "some regex"
    assert new_lazy_regex._real_regex.flags == re.UNICODE

# Generated at 2022-06-24 02:48:26.882419
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    lr = LazyRegex(('^.*$',))
    assert lr.pattern == '^.*$'



# Generated at 2022-06-24 02:48:34.737905
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    import pickle
    re_compile = LazyRegex(args = ('abc',), kwargs = {'x' : 123})
    re_compile._compile_and_collapse()
    assert re_compile.__getstate__() == {'args': ('abc',), 'kwargs': {'x': 123}}
    assert re_compile.__getstate__() == pickle.loads(pickle.dumps(re_compile)).__getstate__()


# Generated at 2022-06-24 02:48:38.905231
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Test constructor of class InvalidPattern"""
    exc = InvalidPattern('mismatch')
    assert repr(exc) == repr(eval(repr(exc)))

# Unit tests for basic LazyRegex

# Generated at 2022-06-24 02:48:45.489612
# Unit test for function finditer_public
def test_finditer_public():
    """Some libraries will call re.finditer directly, which fails if it
    receives a LazyRegex. So this function will handle it.
    """
    from bzrlib.tests.matchers import HasLength

    if not getattr(re, 'finditer', False):
        # Do nothing if the function does not exist
        return

    for pat in ['.*', '.*', '.*?', '.*?']:
        pat = lazy_compile('.*')
        result = re.finditer(pat, "abcd")
        assert len(list(result)) == 1


# Install lazy compilation as the default mode
install_lazy_compile()

# Generated at 2022-06-24 02:48:51.836018
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex

    The __setstate__ method sets the state of the object from the pickle.
    """
    pattern = '.*'
    lazy_obj = LazyRegex((pattern,))
    expected_state = {
        "args": (pattern,),
        "kwargs": {},
        }
    pickled_state = lazy_obj.__getstate__()
    assert expected_state == pickled_state
    lazy_obj.__setstate__(pickled_state)
    assert lazy_obj._regex_args == (pattern,)
    assert lazy_obj._regex_kwargs == {}

# Generated at 2022-06-24 02:48:56.322803
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern

    The method __unicode__ should return a unicode object.
    """
    ip = InvalidPattern('msg')
    u = ip.__unicode__()
    assert(isinstance(u, unicode))
    assert(u == 'msg')


# Generated at 2022-06-24 02:48:58.746648
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() returns a str object."""
    msg = 'InvalidPattern test'
    exception = InvalidPattern(msg)
    assert (isinstance(exception.__str__(), str))


# Generated at 2022-06-24 02:49:02.861795
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ and __str__ are used to format messages for InvalidPattern.

    it is a bug if __repr__ or __str__ fail.
    """
    e = InvalidPattern('test')
    msg = repr(e)
    assert msg is not None
    assert msg != ""
    assert 'InvalidPattern' in msg
    assert 'test' in msg

    msg = str(e)
    assert msg is not None
    assert msg != ""
    assert 'InvalidPattern' in msg
    assert 'test' in msg

# Generated at 2022-06-24 02:49:13.346870
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib.tests import (
        test_i18n,
        )
    import bzrlib.tests.blackbox
    # We do this here rather than in the library code because it needs the
    # doctest module, which is not available on every platform.
    # TODO: add a 'strict' option, and call it from test_i18n.
    doctest.DONT_ACCEPT_TRUE_FOR_1 = False
    # We can't import these from bzrlib.tests because that triggers the
    # i18n initialization
    blacklist = [
        test_i18n,
        ]
    for blackbox_mod in bzrlib.tests.blackbox.modules:
        blacklist.append(blackbox_mod.__name__)

# Generated at 2022-06-24 02:49:24.985806
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile = _real_re_compile

# Generated at 2022-06-24 02:49:34.459162
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test that LazyRegex can compile arbitrary regexs"""
    test_regex = '[a-z]*'
    lazy_regex = LazyRegex((test_regex, ), {})
    regex = re.compile(test_regex)

    for i in 'abcdefghijklmnopqrstuvwxyz':
        m_regex = regex.match(i)
        m_lazy_regex = lazy_regex.match(i)
        assert m_regex is not None
        assert m_lazy_regex is not None
        assert m_regex.group() == m_lazy_regex.group()



# Generated at 2022-06-24 02:49:46.593295
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test that str(InvalidPattern) is valid unicode"""
    import sys
    # Test with an ascii message
    message1 = "an ascii message"
    error1 = InvalidPattern(message1)
    if not isinstance(str(error1), unicode):
        raise AssertionError("str(InvalidPattern) should be unicode")
    # Test with a unicode message
    message2 = u"a \xa7 unicode message"
    error2 = InvalidPattern(message2)
    if not isinstance(str(error2), unicode):
        raise AssertionError("str(InvalidPattern) should be unicode")
    # Test with an ascii message with a non ascii character in the dict
    message3 = "an ascii message"
    error3 = InvalidPattern(message3)
    error3

# Generated at 2022-06-24 02:49:49.326844
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """test that the install_lazy_compile function works.

    The test is not so much whether it works, but that it doesn't
    cause infinite recursion.
    """
    install_lazy_compile()
    reset_compile()

# Generated at 2022-06-24 02:49:57.020886
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy_regex = LazyRegex('(a)')
    global _real_re_compile
    def custom_re_compile(pattern, flags=0):
        return 'Custom regex object'
    # override
    _real_re_compile = custom_re_compile
    # Now we call match and it should compile the pattern
    assert lazy_regex.match('a') == 'Custom regex object'
    # reset
    re.compile = _real_re_compile
    # Now the LazyRegex should behave as a normal regex
    assert lazy_regex.match('a')



# Generated at 2022-06-24 02:50:06.736573
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    def check(s):
        """Assert that the repr of InvalidPattern(s) matches expected value."""
        expected = 'InvalidPattern(Invalid pattern(s) found. %s)' % s
        e = InvalidPattern(s)
        actual = repr(e)
        if expected != actual:
            raise AssertionError('%r != %r' % (expected, actual))

    check('foo')
    check('foo%(bar)s%(baz)r')
    check('foo%(bar)s')


# Generated at 2022-06-24 02:50:12.279635
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ must not fail calling sub classes methods,
    even when those are not defined.
    """
    class MyLazyRegex(LazyRegex):
        pass
    mylazy_regex = MyLazyRegex()
    state = mylazy_regex.__getstate__()
    # state must be a dictionary
    assert isinstance(state, dict)
    # state must have a key "args"
    assert state.has_key("args")
    # state must have a key "kwargs"
    assert state.has_key("kwargs")

# Generated at 2022-06-24 02:50:16.173542
# Unit test for function finditer_public
def test_finditer_public():
    """Test for function re.finditer returns a LazyRegex object."""
    pattern = re.compile(b'[ab]c')
    found = re.finditer(pattern, b'abc')
    assert(isinstance(found, re.finditer(pattern, b'abc').__class__))

# Module initialization: override compile to be lazy
install_lazy_compile()

# Generated at 2022-06-24 02:50:24.380959
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test case for method __getattr__ of class LazyRegex.

    This unittest is also a functional test for both lazy_compile and
    LazyRegex.
    """
    # check that the basic compile works
    lr = lazy_compile('foo')
    lr.search('bar')
    # check that the real regex object is returned
    lr2 = lazy_compile('foo')
    real_regex = lr2.search('bar')
    expected = re.compile('foo').search('bar')
    assert real_regex == expected
    # do this twice to check real regex caching
    lr2.search('bar')
    real_regex = lr2.search('bar')
    expected = re.compile('foo').search('bar')
    assert real_regex == expected


# Generated at 2022-06-24 02:50:29.236313
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object with a valid preformatted
    message.
    """
    msg = 'This is an error message'
    e = InvalidPattern(msg)
    assert isinstance(e.__unicode__(), unicode)
    assert str(e) == msg
    assert unicode(e) == msg



# Generated at 2022-06-24 02:50:35.604402
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # Just test creating the object
    lazy = lazy_compile('[^A]+', re.I)
    # Now check that the objects are preserved through pickling
    import cPickle
    unpickled = cPickle.loads(cPickle.dumps(lazy))
    if unpickled is not lazy:
        raise AssertionError(
            "Pickling changed the object from %r -> %r" % (lazy, unpickled))



# Generated at 2022-06-24 02:50:41.343323
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Ensure method InvalidPattern.__eq__ works."""
    err1 = InvalidPattern("Message 1")
    err1_copy = InvalidPattern("Message 1")
    err2 = InvalidPattern("Message 2")
    err3 = ValueError("Message 1")

    assert err1 == err1_copy
    assert err1 != err2
    assert err1 != err3

# Generated at 2022-06-24 02:50:44.574009
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ should be able to raise the exception with eval"""
    e = InvalidPattern('Test')
    A = eval(repr(e))
    B = InvalidPattern('Test')
    assert A == B


# Generated at 2022-06-24 02:50:51.000224
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method `__setstate__` of `LazyRegex`

    This test is more a reminder of how `__setstate__` works
    than a real unit test.
    """
    _real_regex = LazyRegex()
    pickled_state = _real_regex.__getstate__()
    _real_regex = LazyRegex()
    _real_regex.__setstate__(pickled_state)

# Generated at 2022-06-24 02:50:57.649778
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Ensure InvalidPattern.__str__ returns unicode for most locales"""
    # make sure that this test does what we expect
    assert isinstance(InvalidPattern._fmt, str)
    # make a new InvalidPattern with a non-ascii string, then unicode(...)
    # will do codepoint->character translation
    p = InvalidPattern(_fmt=u'\N{LATIN SMALL LETTER A WITH GRAVE}')
    # if the text was decoded with the default locale, then this will be a
    # unicode already, but if it was ascii then we decode it with the
    # default locale
    x = unicode(p)
    # re-encode with utf8.  This will work in any locale

# Generated at 2022-06-24 02:51:06.440985
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test that __getstate__ does not compile the regex, and also that it
    does not need the methods to be compiled for it to work.
    """
    import pickle
    compiled = False
    def _real_re_compile(*args, **kwargs):
        # The LazyRegex will compile the regex, we don't want to happen while
        # testing __getstate__ so we raise an exception if that happens.
        global compiled
        compiled = True
        raise Exception("re.compile must not be called while testing LazyRegex.__getstate__")

    class DummyLazyRegex(LazyRegex):
        """Dummy for testing"""
        _real_re_compile = _real_re_compile
    dummy_regex = DummyLazyRegex("foo", re.IGNORECASE)
   

# Generated at 2022-06-24 02:51:18.976520
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for LazyRegex.__getstate__()"""
    lazy_regex = LazyRegex('bzr*')
    reg = _real_re_compile('bzr*')
    # LazyRegex is not initialized yet because reg is not yet computed
    assert(lazy_regex._real_regex == None)
    # LazyRegex is initialized after a search
    reg.search('something')
    assert(lazy_regex._real_regex != None)
    # We are checking that lazy_regex returns the same state as reg
    # when it is not yet initialized
    assert(lazy_regex.__getstate__() == {'args':('bzr*',), 'kwargs':{}})
    # Same check as above but now LazyRegex is initialized
    _real

# Generated at 2022-06-24 02:51:26.947568
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__ method of LazyRegex

    __getstate__ is used by methods that serialize an object.
    """
    reg = LazyRegex(('ab?',), {})
    state = reg.__getstate__()
    try:
        state['args']
    except KeyError:
        raise AssertionError("KeyError exception: 'args'")

    try:
        state['kwargs']
    except KeyError:
        raise AssertionError("KeyError exception: 'kwargs'")

# Generated at 2022-06-24 02:51:33.298199
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test of method __getstate__ of class LazyRegex.

    This test is a bit complicated because it needs to be sure to
    pickle the object before it is compiled.  The LazyRegex object uses
    __getstate__ to perform some magic to allow this.
    """
    import cPickle
    from bzrlib.tests import TestCase

    class Test(TestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.pattern = LazyRegex('(a|b)*.c')

        def test_pickle(self):
            # If the pattern was compiled when we tried to pickle it, pickle
            # would have failed because the _real_regex is not picklable
            pickled_pattern = cPickle.dumps(self.pattern)
            unpick

# Generated at 2022-06-24 02:51:41.713249
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that re.compile works before and after install_lazy_compile()"""
    try:
        # Test that re.compile still works before we have installed
        # the alternative regex compiler.
        _real_re_compile('a')
        # Now install our alternative regex compiler.
        install_lazy_compile()
        # Test that re.compile still works
        _real_re_compile('b')
        # Test that the new compiler works.
        lazy_compile('c')
    finally:
        # Make sure that we don't pollute the global namespace.
        reset_compile()

# Generated at 2022-06-24 02:51:51.480414
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # We have to have the module reloaded, with the original import of
    # re.compile.
    import bzrlib.regex_hacked
    import bzrlib.regex
    import re
    bzrlib.regex_hacked.install_lazy_compile()
    # Ensure that the original function was captured, and that re.compile
    # was overridden.
    assert bzrlib.regex.compile is bzrlib.regex_hacked._real_re_compile
    assert re.compile is bzrlib.regex_hacked.lazy_compile

# Generated at 2022-06-24 02:51:59.758885
# Unit test for function finditer_public
def test_finditer_public():
    # If the private module function finditer_public is not defined
    # the test is skipped.
    if not finditer_public:
        return
    # finditer public should do the same as the original finditer.
    assert finditer_public(r'\(', '(te)st')[0].group(0) == '('
    assert finditer_public(r'\(', '(te)st').next().group(0) == '('

    # finditer_public should work with a lazy regex
    lazy = lazy_compile(r'\(', re.S)
    assert finditer_public(lazy, '(te)st')[0].group(0) == '('
    assert finditer_public(lazy, '(te)st').next().group(0) == '('

# Generated at 2022-06-24 02:52:04.306823
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method LazyRegex.__getattr__"""

    test_regex = re.compile(r'(\d+)')
    test_str = '123 456'
    test_sub = '444'

    lazy_regex = lazy_compile(r'(\d+)')
    assert(lazy_regex._real_regex is None)

    # check that the lazy regex is the same as the usual one
    # after being accessed
    result = lazy_regex.findall(test_str)
    assert(result == test_regex.findall(test_str))

    result = lazy_regex.finditer(test_str)
    assert(list(result) == list(test_regex.finditer(test_str)))

    result = lazy_regex.match(test_str)


# Generated at 2022-06-24 02:52:06.798213
# Unit test for function finditer_public
def test_finditer_public():
    pattern = LazyRegex(('def', 0))
    m = pattern.finditer_public('abc def ghi')
    text = next(m).group()
    assert text == 'def'

# Generated at 2022-06-24 02:52:08.590986
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import doctest
    doctest.testmod()

# Install the default
install_lazy_compile()

# Generated at 2022-06-24 02:52:14.321210
# Unit test for function finditer_public
def test_finditer_public():
    install_lazy_compile()
    try:
        pattern = re.compile(r'.*')
        result = re.finditer(pattern, 'string')
        iter_pattern = iter(pattern)
        first_p = iter_pattern.next()
        assert result.next().group() == first_p.group()
    finally:
        reset_compile()

try:
    import psyco
except ImportError:
    pass
else:
    psyco.bind(LazyRegex)

# Generated at 2022-06-24 02:52:16.814562
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    x = InvalidPattern("this is my message")
    assert x.__str__() == "Invalid pattern(s) found. this is my message"


# Generated at 2022-06-24 02:52:22.535726
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests.per_internals import TestCaseWithMemoryTransport

    class TestInvalidPattern(TestCaseWithMemoryTransport):
        def test_eq(self):
            ip1 = InvalidPattern(u'msg1')
            ip2 = InvalidPattern(u'msg1')
            ip3 = InvalidPattern(u'msg2')
            self.assertEqual(ip1, ip2)
            self.assertNotEqual(ip1, ip3)

    TestInvalidPattern.run_tests()

# Generated at 2022-06-24 02:52:32.157273
# Unit test for function finditer_public
def test_finditer_public():
    """Tests for finditer_public."""
    # Test for lazy regex
    test_string = 'abcabcabc'
    test_pattern = 'ab'
    expected_result = list(re.finditer(test_pattern, test_string))
    lazy = lazy_compile(test_pattern)
    actual_result = list(finditer_public(lazy, test_string))
    self.assertEquals(actual_result, expected_result)

    # Test for normal regex
    test_string = 'abcabcabc'
    test_pattern = 'ab'
    expected_result = list(re.finditer(test_pattern, test_string))
    lazy = lazy_compile(test_pattern)
    actual_result = list(finditer_public(test_pattern, test_string))

# Generated at 2022-06-24 02:52:38.946612
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    pattern = re.compile('(?P<foo>\(.*\))')
    try:
        pattern.match('')
    except re.error as e:
        invalid = InvalidPattern(str(e))
        assert str(invalid) == 'Invalid pattern(s) found. "^(?P<foo>\\(.*\\))$" unbalanced parenthesis'
    else:
        raise AssertionError('re.error not raised')

# Generated at 2022-06-24 02:52:46.549040
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    regex = LazyRegex(args=('^hello',))
    regex2 = LazyRegex(args=('^goodbye',))
    regex3 = LazyRegex(args=('^hello',))
    assert isinstance(regex, LazyRegex)
    assert not regex == regex2
    assert not regex == None
    assert regex == regex3
    try:
        regex.match('match')
        assert False, "Should have raised error"
    except re.error:
        pass
    assert regex.match('helloworld')

# Generated at 2022-06-24 02:52:52.276124
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    exc = InvalidPattern('msg')
    assert isinstance(exc._format(), unicode)
    assert exc._get_format_string() is None
    assert exc.__eq__(exc)
    assert not exc.__eq__(InvalidPattern('blah'))

# Install the lazy regex by default
install_lazy_compile()

# Generated at 2022-06-24 02:52:59.730878
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # Using the default LazyRegex proxy object is the same as calling __getattr__
    # directly when the real regex hasn't been compiled yet.
    proxy = lazy_compile('a')
    assert proxy.search('a') is proxy.__getattr__('search')('a')

    # After the regex has been compiled, using the proxy object is the same
    # as using the actual regex object returned by the underlying compilation.
    proxy.match('a')
    assert proxy.search('a') is proxy.__getattr__('search')('a')

    # AttributeError is raised when an attribute is missing.
    raises(AttributeError, getattr, proxy, 'nonexistent')

# Generated at 2022-06-24 02:53:06.310944
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('abc')
    e2 = InvalidPattern('abc')
    e3 = InvalidPattern('def')
    e4 = ValueError('abc')
    assert e1 == e1
    assert e1 == e2
    assert e2 == e1
    assert e1 != e3
    assert e1 != e4
    assert e4 != e1