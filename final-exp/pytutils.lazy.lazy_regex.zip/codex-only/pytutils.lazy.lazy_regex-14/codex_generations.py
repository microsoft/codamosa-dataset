

# Generated at 2022-06-24 02:43:18.281288
# Unit test for function finditer_public
def test_finditer_public():
    regex_1 = re.compile(r'relative')
    regex_2 = re.compile(r'relative')
    match_first_regex = re.compile(r'relative')
    match_second_regex = re.compile(r'absolute')
    test_string = "relatively"
    assert [] == [x.group(0) for x in finditer_public(match_second_regex, test_string)]
    assert ['relative'] == [x.group(0) for x in finditer_public(match_first_regex, test_string)]
    assert ['relative'] == [x.group(0) for x in finditer_public(regex_1, test_string)]

# Generated at 2022-06-24 02:43:29.635487
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function."""
    from bzrlib.tests import TestCase
    install_lazy_compile()

# Generated at 2022-06-24 02:43:40.175509
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests for method __unicode__ of class InvalidPattern

    This test checks that method __unicode__ of class InvalidPattern
    return a unicode string object. It is important because
    gettext.gettext needs a unicode string object
    """

    class MyInvalidPattern(InvalidPattern):
        """A subclass of InvalidPattern"""
        pass

    class MyOtherInvalidPattern(MyInvalidPattern):
        """A subclass of MyInvalidPattern"""
        _fmt = 'A test: %(msg)s'

    # Test invalid patterns.
    def _build_invalid_pattern(msg):
        return MyInvalidPattern(msg)

    # This is not a real InvalidPattern object. We just use it to test
    # the format string applied to a InvalidPattern object
    invalid_pattern = _build_invalid_pattern('this is a msg')
    result

# Generated at 2022-06-24 02:43:49.147717
# Unit test for function finditer_public
def test_finditer_public():
    """Test that re.finditer calls LazyRegex.finditer when requested."""
    re.compile = _real_re_compile
    re.finditer = finditer_public
    pattern = lazy_compile('^(1+)(2*)$')
    result = re.finditer(pattern, '12')
    assert next(result).groups() == ('1', '2')

# Install lazy compile if not already installed
if re.compile is not lazy_compile:
    install_lazy_compile()

# Generated at 2022-06-24 02:43:54.500466
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile installs a function that still works."""
    install_lazy_compile()
    try:
        re.compile('a(b)c').match('abc')
    finally:
        reset_compile()

# Generated at 2022-06-24 02:43:59.495599
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    class Foo(InvalidPattern):
        _fmt = 'a test %(msg)s'
    e = Foo('test')
    str(e)
    # now with unicode
    class Foo(InvalidPattern):
        _fmt = u'a test %(msg)s'
    e = Foo('test')
    str(e)

# Install the lazy compi

# Generated at 2022-06-24 02:44:06.909604
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile function"""
    re_compile = re.compile
    try:
        re.compile = lazy_compile
        assert not hasattr(re.compile, 'findall')
        regex = re.compile('a')
        assert hasattr(regex, 'findall')
        regex = re.compile('a', re.I)
        assert hasattr(regex, 'findall')
    finally:
        re.compile = re_compile

# Generated at 2022-06-24 02:44:16.114412
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    """Unit test for constructor of class InvalidPattern"""
    import sys
    # This test is written as it is because it is not certain that
    # Python will provide a `str' object in the future.
    e = InvalidPattern('msg')
    expected_msg = u'Invalid pattern(s) found. msg'
    if sys.version_info[0] >= 3:
        # Python 3 returns a `bytes' object by default.
        expected_msg = expected_msg.encode('utf8')
    assert str(e) == expected_msg


# Generated at 2022-06-24 02:44:27.348820
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should correct restore LazyRegex"""
    import pickle
    def test_setstate(regex, args, kwargs):
        proxy = LazyRegex(args, kwargs)
        proxy.match
        restored_proxy = pickle.loads(pickle.dumps(proxy))
        restored_proxy.match
        assert restored_proxy._regex_args == args
        assert restored_proxy._regex_kwargs == kwargs
        assert restored_proxy._real_regex._pattern == regex._pattern

    test_setstate(_real_re_compile('foo'), ('foo',), {})
    test_setstate(_real_re_compile(u'f\xf2o'), (u'f\xf2o',), {})

# Generated at 2022-06-24 02:44:30.939906
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test method __repr__ of class InvalidPattern

    This test checks that the method InvalidPattern.__repr__ doesn't
    raise any exception and returns a string.
    """
    error = InvalidPattern('error')
    repr(error)

# Generated at 2022-06-24 02:44:38.532081
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy = LazyRegex(('[tT]est',), {'flags':re.I})
    if hasattr(lazy, '__slots__'):
        for slot in lazy.__slots__:
            assert slot != '_real_regex'
    assert lazy._real_regex is None
    assert lazy._regex_args == ('[tT]est',)
    assert lazy._regex_kwargs == {'flags':re.I}
    assert hasattr(lazy, '__getattr__')
    assert hasattr(lazy, '__getstate__')
    assert hasattr(lazy, '__setstate__')
    assert hasattr(lazy, '_compile_and_collapse')
    assert hasattr(lazy, '_real_re_compile')
    assert hasattr

# Generated at 2022-06-24 02:44:41.287785
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # catch an exception, because it is not only the class that is being tested,
    # but also the code in the exception handler.
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert str(e) == 'foo'

# Generated at 2022-06-24 02:44:48.918625
# Unit test for function lazy_compile
def test_lazy_compile():
    """Ensure that LazyRegex works correctly."""
    # We can't ship this code in the bzrlib module because then we'll
    # get a recursive import.
    import bzrlib
    re = bzrlib.lazy_regex.re
    re.compile = lazy_compile
    regex = re.compile('a')
    try:
        # if the regex isn't compiled yet, we get an AttributeError
        regex.foo
        raise AssertionError('regex already compiled')
    except AttributeError:
        pass
    regex.match('a')
    # If the regex is now compiled, we don't get an AttributeError
    regex.foo

# Generated at 2022-06-24 02:44:57.195823
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should return a 'str' object."""
    class CustomIP(InvalidPattern):
        _fmt = "Something fails (%(something)s)"
        def __init__(self, something):
            self.something = something
    # an instance msg is a 'str'
    assert isinstance(CustomIP("").__str__(), str)
    # a class msg is an 'unicode'
    assert isinstance(CustomIP("")._get_format_string(), unicode)
    # a non-ascii msg is encoded properly
    try:
        custom_ip = CustomIP("\xe9")
    except UnicodeDecodeError:
        # This is not a valid ascii string, so we can't expect it to work.
        pass

# Generated at 2022-06-24 02:45:00.678649
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    try:
        raise InvalidPattern('msg')
    except InvalidPattern as e:
        assert str(e) == 'Unprintable exception InvalidPattern: ' \
                         'dict={\'msg\': \'msg\'}, fmt=None, error=None'


# Generated at 2022-06-24 02:45:04.250392
# Unit test for function finditer_public
def test_finditer_public():
    lazy = lazy_compile('a(b)')
    f = finditer_public(lazy, 'ab')
    assert getattr(f, "__iter__", None) is not None, f

# Generated at 2022-06-24 02:45:13.079116
# Unit test for function install_lazy_compile
def test_install_lazy_compile():

    try:
        install_lazy_compile()
        assert re.compile is lazy_compile
        proxy = re.compile("foo")
        assert isinstance(proxy, LazyRegex)

        # Verify that the proxy object creates an actual regex on demand
        real_regex = proxy.match("foo")
        assert isinstance(real_regex, _real_re_compile("foo").__class__)
        assert real_regex.__class__ is _real_re_compile("foo").__class__
    finally:
        reset_compile()


# Generated at 2022-06-24 02:45:25.535976
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    # Does it work without a format string?
    a = InvalidPattern('')
    b = InvalidPattern('')
    assert a == b
    # does it handle a format string?
    a = InvalidPattern('%(msg)s')
    # does it handle a preformatted string?
    b = InvalidPattern('preformatted message')
    # Check that the format string works
    c = InvalidPattern('format string %(msg)s')
    assert a == c
    assert str(a) == 'format string '
    assert unicode(a) == u'format string '
    assert repr(a) == "InvalidPattern('format string %(msg)s')"
    # Check that the preformatted string works
    assert str(b) == 'preformatted message'
    assert unicode(b) == b'preformatted message'

# Generated at 2022-06-24 02:45:35.040925
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Demonstrate the method __getattr__ of class LazyRegex."""
    from bzrlib.tests import TestCase

    lazy_regex_obj1 = LazyRegex([r'(^.+\d$)'])
    # call method __getattr__
    regex_obj1 = lazy_regex_obj1.match('123')
    # check function match
    self.assertEquals('123', regex_obj1.group(0))
    # call method __getattr__
    regex_obj2 = lazy_regex_obj1.match('1234')
    self.assertEquals('1234', regex_obj2.group(0))

# Generated at 2022-06-24 02:45:38.706243
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a string object"""
    class TestInvalidPattern(InvalidPattern):
        _fmt = 'a string %(value)s'
    i = TestInvalidPattern('value')
    s = str(i)
    assert isinstance(s, str), str(i)

# Generated at 2022-06-24 02:45:47.870724
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method __getstate__ of class LazyRegex"""

    # Here we test the output of __getstate__ method

    # Some valid arguments
    t1 = LazyRegex(args=('a',), kwargs={ })
    assert t1.__getstate__() == {
        u'args': (u'a',),
        u'kwargs': { }
        }

    t2 = LazyRegex(args=(), kwargs={'flags': re.IGNORECASE})
    assert t2.__getstate__() == {
        u'args': ( ),
        u'kwargs': { 'flags': re.IGNORECASE }
        }

    t3 = LazyRegex(args=('a', 'b'), kwargs={'flags': re.IGNORECASE})
    assert t3

# Generated at 2022-06-24 02:45:53.600639
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    foo = LazyRegex(("foo",))
    assert foo._real_regex is None
    assert foo._regex_args == ("foo",)
    assert foo._regex_kwargs == {}
    foo = LazyRegex(("foo",), dict(flag=1))
    assert foo._real_regex is None
    assert foo._regex_args == ("foo",)
    assert foo._regex_kwargs == dict(flag=1)



# Generated at 2022-06-24 02:45:58.990916
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Test to see if LazyRegex is constructed properly"""
    #1. Test to see if constructor is constructed properly
    lazyregex_obj = LazyRegex('(^|\W)bar(\W|$)', re.I)
    assert lazyregex_obj._real_regex == None
    assert lazyregex_obj._regex_args == ('(^|\W)bar(\W|$)', )
    assert lazyregex_obj._regex_kwargs == {'flags': re.IGNORECASE}

# Generated at 2022-06-24 02:46:09.462634
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the lazy_compile module"""
    # Regexs should not be compiled until they are actually used
    import sys
    import cPickle
    import gc
    if sys.version_info[0] > 2:
        # Python 3.x
        string_types = str
    else:
        # Python 2.x
        string_types = (str, unicode)
    proxy_regex = re.compile("(a)")
    compiled_regex = re.compile("(b)")
    assert proxy_regex is not compiled_regex
    assert type(proxy_regex) is not type(compiled_regex)
    assert isinstance(proxy_regex, LazyRegex)
    assert isinstance(compiled_regex, re._pattern_type)

# Generated at 2022-06-24 02:46:18.634221
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # this test needs to be run with Unicode strings
    try:
        u''
    except NameError:
        raise TestSkipped('Unicode strings are not supported.')

    msg = b'Foo'
    exc = InvalidPattern(msg)
    # test with ascii msg
    assert exc.__unicode__() == unicode(msg.decode('ascii'))
    # test with unicode msg
    msg = unicode('Foo')
    exc = InvalidPattern(msg)
    assert exc.__unicode__() == msg
    # test with arbitrary object
    msg = object()
    exc = InvalidPattern(msg)
    assert exc.__unicode__() == unicode(repr(msg))
    # test with _preformatted_string
   

# Generated at 2022-06-24 02:46:30.510846
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Unit test for function install_lazy_compile"""
    if re.compile is not lazy_compile:
        install_lazy_compile()
    if re.compile is not lazy_compile:
        raise AssertionError("re.compile has not been overridden as "
            "lazy_compile")
    # make sure that the object we get back is indeed a proxy object.
    regex = re.compile("a")
    assert regex.__class__.__name__ == "LazyRegex"
    assert not regex._real_regex
    # calling a method on the proxy should compile it on demand
    regex.match("a")
    assert regex._real_regex
    # and we should be able to call the original function too.

# Generated at 2022-06-24 02:46:40.675863
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import errors
    class Subclass(errors.InvalidPattern):
        _fmt = 'Invalid string(s) found. %(msg)s'
    subclass_obj = Subclass('msg value')
    # A subclass of InvalidPattern should use _fmt to format the message
    subclass_result = unicode(subclass_obj)
    expected = 'Invalid string(s) found. msg value'
    if expected != subclass_result:
        raise AssertionError('Subclass does not use _fmt to format the '
            'message. Expected "%s", got "%s"' % (expected, subclass_result))
    # Just InvalidPattern should have a default message.
    msg = 'msg value'
    obj = errors.InvalidPattern(msg)
    result = unicode(obj)

# Generated at 2022-06-24 02:46:45.272257
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('msg1')
    e2 = InvalidPattern('msg2')
    e3 = InvalidPattern('msg1')
    e4 = Exception()

    for x in (e1, e2, e3, e4):
        if x is e1:
            assert x == e1
            assert x != e2
            assert x == e3
        elif x is e2:
            assert x != e1
            assert x == e2
            assert x != e3
        elif x is e3:
            assert x != e1
            assert x != e2
            assert x == e3
        elif x is e4:
            assert x != e1
            assert x != e2
            assert x != e3



# Generated at 2022-06-24 02:46:51.599559
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""

    t = InvalidPattern('what is going on')

    # this should be a str object
    assert isinstance(str(t), str)

    setattr(t, '_fmt', 'I don\'t know %(msg)s')
    assert isinstance(str(t), str)

    setattr(t, '_fmt', 'Invalid pattern(s) found. %(msg)s')
    assert isinstance(str(t), str)



# Generated at 2022-06-24 02:46:53.895683
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    test_invalid_pattern = InvalidPattern('a message')
    assert test_invalid_pattern == InvalidPattern('a message')



# Generated at 2022-06-24 02:46:56.756991
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    import doctest
    verbose = 0
    if __name__ == '__main__':
        verbose = 1
    doctest.testmod(verbose=verbose)

# Generated at 2022-06-24 02:47:04.890742
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re

    def check_proxy(proxy):
        """Check the proxy doesn't compile until a method is called"""
        if not isinstance(proxy, LazyRegex):
            raise AssertionError()
        if proxy._real_regex is not None:
            raise AssertionError()

    check_proxy(re.compile('foo'))
    check_proxy(re.compile('foo', re.IGNORECASE))
    re.compile('foo[0-9]+')
    check_proxy(re.compile('foo(?P<number>[0-9]+)'))
    check_proxy(re.compile('foo', re.I))
    check_proxy(re.compile('foo', re.IGNORECASE))
    check_proxy(re.compile('foo', re.L))
   

# Generated at 2022-06-24 02:47:15.776708
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Unicode characters in exception message
    ip = InvalidPattern('\xc3\xa9\xc3\xae\xc3\xaf')
    msg_unicode = unicode(ip)
    # In Python 3, unicode is just str
    if str is unicode:
        assert isinstance(msg_unicode, str), 'InvalidPattern.__unicode__() should return a str object'
    else:
        assert isinstance(msg_unicode, unicode), 'InvalidPattern.__unicode__() should return a unicode object'
    # Unicode characters in _fmt
    ip._fmt = '\xc3\xa9\xc3\xae\xc3\xaf'
    msg_unicode = unicode(ip)

# Generated at 2022-06-24 02:47:19.292857
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test for lazy_compile"""
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-24 02:47:31.549636
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    def check(a, b):
        """Check a == b"""
        return a == b and b == a

    # Test different types
    assert not check(InvalidPattern('x'), InvalidPattern('y'))
    assert not check(InvalidPattern('x'), KeyError('x'))

    # Test different attributes
    assert not check(InvalidPattern('x'), InvalidPattern('y'))
    assert not check(InvalidPattern('x'), InvalidPattern(msg='x'))
    assert not check(InvalidPattern(msg='x'), InvalidPattern(msg='y'))

    # Test same object
    e = InvalidPattern('x')
    assert check(e, e)

    # Test same object except for message
    assert check(InvalidPattern('x'), InvalidPattern(msg='x'))
    assert check(InvalidPattern(msg='x'), InvalidPattern('x'))



# Generated at 2022-06-24 02:47:36.564547
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test that InvalidPattern returns a valid unicode string."""
    e = InvalidPattern("some message")
    unicode_string = unicode(e)


test_suite = testmod()

if __name__ == '__main__':
    install_lazy_compile()
    test_compile()

# Generated at 2022-06-24 02:47:43.809172
# Unit test for function finditer_public
def test_finditer_public():
    """Test re.finditer_public."""
    # Test if a match is found
    lazy_pat = lazy_compile(r"a(.)")
    matches = finditer_public(lazy_pat, "abc")
    match = matches.next()
    assert(match.group(1) == "b")
    # Test if no match is found
    matches = finditer_public(lazy_pat, "xyz")
    assert(matches.next() is None)
    # Test if finditer_public uses the real finditer for compiled regexes
    matches = finditer_public(re.compile(r"a(.)"), "abc")
    match = matches.next()
    assert(match.group(1) == "b")

# Generated at 2022-06-24 02:47:51.175178
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test the proxy for regex compilation.

    This test ensures that a valid pattern compiles and an invalid one
    raises InvalidPattern.
    """
    lazy = lazy_compile(r"a")
    # Ensure the '_real_regex' attribute is not set and then try to call
    # 'match' on the proxy
    assert lazy._real_regex is None
    # Compile and then make sure the attribute is set
    assert lazy.match("a")
    assert lazy._real_regex is not None
    assert not lazy.match("b")
    # reset_compile the proxy and make sure it compiles again
    lazy._real_regex = None
    assert lazy.match("a")
    assert lazy._real_regex is not None
    assert not lazy.match("b")
    # reset_compile the proxy and make

# Generated at 2022-06-24 02:47:59.638971
# Unit test for function reset_compile
def test_reset_compile():
    orig_re_compile = _real_re_compile
    # we need to ensure that lazy_compile is not the current re.compile
    # or we will get infinite recursion
    if re.compile is lazy_compile:
        raise AssertionError(
            "re.compile has already been overridden as lazy_compile, but this would" \
            " cause infinite recursion")
    install_lazy_compile()
    reset_compile()
    assert re.compile is orig_re_compile

# Generated at 2022-06-24 02:48:09.506896
# Unit test for function lazy_compile
def test_lazy_compile():
    lc=lazy_compile('ab')
    assert isinstance(lc, LazyRegex)
    assert lc._real_regex is None
    assert lc._regex_args == ('ab',)
    assert lc._regex_kwargs == {}
    lc=lazy_compile('ab', 0x08|0x10, 'utf-8')
    assert lc._real_regex is None
    assert lc._regex_args == ('ab', 0x08|0x10)
    assert lc._regex_kwargs == {'code': 'utf-8'}

if __name__ == '__main__':
    test_lazy_compile()

# Generated at 2022-06-24 02:48:16.707559
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test of method __repr__ of class InvalidPattern."""
    # Test with _fmt attribute defined
    e = InvalidPattern('My message')
    e._fmt = 'Error message: %(msg)s'
    repr(e) == "InvalidPattern('Error message: My message')"
    # Test with _fmt attribute not defined
    e = InvalidPattern('My message')
    repr(e) == "InvalidPattern('Unprintable exception InvalidPattern: dict={'msg': 'My message'}, fmt=None, error=None')"

# Generated at 2022-06-24 02:48:20.043897
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test for method __getstate__ of class LazyRegex"""

    obj = LazyRegex('a')
    state = obj.__getstate__()
    assert state == {'args': ('a',), 'kwargs': {}}


# Generated at 2022-06-24 02:48:28.141252
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should handle unicode and str messages"""
    # _fmt is ascii and __init__ is called with unicode
    u = unicode(InvalidPattern('hoho'))
    # _fmt is ascii and __init__ is called with ascii str
    s = str(InvalidPattern('hoho'))
    # _fmt is unicode and __init__ is called with unicode
    u2 = unicode(InvalidPattern(unicode('hoho')))
    # _fmt is unicode and __init__ is called with ascii str
    s2 = str(InvalidPattern(unicode('hoho')))
    if u != u2 or u != s or u != s2:
        # we use a preformatted message in case of simple
        # gettext problems
        raise Assert

# Generated at 2022-06-24 02:48:34.438751
# Unit test for function finditer_public
def test_finditer_public():
    class Mock_Pattern(object):
        def finditer(self, string):
            return iter([None, None])

    p = Mock_Pattern()
    it = re.finditer(p, 'foo')
    line = 0
    for m in it:
        line += 1
    if line != 2:
        raise AssertionError("finditer_public failed")

# Generated at 2022-06-24 02:48:44.526841
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Ensures the methods __setstate__ and __getstate__ work correctly.

    This is regression test for bug #616888 which exposed a bug in
    LazyRegex.__setstate__, and this test ensures that bug is not
    reintroduced, i.e. make sure we don't leave any regression here.
    """
    import pickle

    regex = LazyRegex(('x',))
    pickled_regex = pickle.dumps(regex)
    unpickled_regex = pickle.loads(pickled_regex)
    assert isinstance(unpickled_regex, LazyRegex), \
        'unpickled_regex must be a LazyRegex instance'

# Generated at 2022-06-24 02:48:48.883735
# Unit test for function finditer_public
def test_finditer_public():
    import re
    test_pattern = r'^(start.*?)\s*=\s*(\S+)'
    test_string = 'start-revision = 5'
    result = re.finditer(test_pattern, test_string).next()
    assert(result.group(1) == 'start-revision')
    assert(result.group(2) == '5')

# Generated at 2022-06-24 02:48:55.563983
# Unit test for function finditer_public
def test_finditer_public():
    """Testing of function finditer() from Python re module."""
    pattern = "^.*$"
    data = ["toto", "titi", "tata"]
    for i, j in enumerate(re.finditer(pattern, data[i]) for i in range(3)):
        print("s:", i, j.group())
        assert i + 1 == len(j.group())



# Generated at 2022-06-24 02:48:58.575985
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() allows a regex to be compiled."""
    re.compile('a')
    # It doesn't always work, it relies on the fact that the first part
    # of the test already called re.compile

# Generated at 2022-06-24 02:49:09.933934
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    assert InvalidPattern('bla bla') == InvalidPattern('bla bla')
    assert InvalidPattern('bla bla') != InvalidPattern('blaa blaa')
    assert InvalidPattern('bla bla') != object()
    assert repr(InvalidPattern('bla bla')) == "InvalidPattern('bla bla')"
    s = str(InvalidPattern('bla bla'))
    assert isinstance(s, str)
    u = unicode(InvalidPattern('bla bla'))
    assert isinstance(u, unicode)
    # check that the string is correctly translated
    from bzrlib.i18n import gettext
    _real_gettext = gettext
    gettext = lambda x: u'%s_translated' % x

# Generated at 2022-06-24 02:49:21.381530
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore _real_regex, _regex_args and _regex_kwargs
    """
    args = (r"^\s*comments\s*=.*$",)
    kwargs = dict()
    lazy_regex = LazyRegex(args, kwargs)
    # we should be able to pickle and restore LazyRegexes
    restored_lazy_regex = LazyRegex().__setstate__(lazy_regex.__getstate__())
    assert restored_lazy_regex._real_regex is None
    assert restored_lazy_regex._regex_args == args
    assert restored_lazy_regex._regex_kwargs == kwargs
    # and we should be able to use them

# Generated at 2022-06-24 02:49:25.965506
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ should return True if all class attribute are equal."""
    exc = InvalidPattern('foo')
    exc.a = 1
    exc.b = None
    other = InvalidPattern('foo')
    other.a = 1
    other.b = None
    assert exc == other


if __name__ == '__main__':
    install_lazy_compile()

# Generated at 2022-06-24 02:49:30.424207
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Testing method __repr__ of class InvalidPattern"""
    # Given an exception
    e = InvalidPattern(ValueError("Invalid"))
    # Method __repr__ returns a string
    #   InvalidPattern(Invalid)
    rev = "InvalidPattern(Invalid)"
    result = e.__repr__()
    assert result == rev, result


# Generated at 2022-06-24 02:49:33.174826
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests.regex_proxy import test_regex_proxy
    test_regex_proxy.test_suite().run(_make_memory_reporter())

# Generated at 2022-06-24 02:49:37.620372
# Unit test for function reset_compile
def test_reset_compile():
    """Test that reset_compile() works"""
    import doctest
    from . import lazy_regex_test
    doctest.testmod(lazy_regex_test, optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-24 02:49:48.731849
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ must return a str"""
    from bzrlib.i18n import gettext
    try:
        gettext(u'\x80')
    except UnicodeDecodeError:
        # If a unicode object cannot be decoded using the default encoding,
        # then __repr__ must return a str
        error_msg = unicode(
            'invalid start byte (codec can\'t decode byte 0x80)'
            ' in position 0: ordinal not in range(128)')
        e = InvalidPattern(error_msg)
        r = repr(e)
        assert isinstance(r, str), "__repr__ must return a str not %r" % r

# Generated at 2022-06-24 02:49:52.315529
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    import pickle
    state = pickle.dumps(LazyRegex(("[a-z]"), {'flags': re.I}))
    lazy = pickle.loads(state)
    assert lazy.search("Z") is not None
    assert lazy.search("z") is None

# Generated at 2022-06-24 02:49:56.792632
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must return a unicode object."""
    exc = InvalidPattern('Invalid pattern(s) found. "%s" %s'
                         % ('bzr', 'error message'))
    assert isinstance(exc.__unicode__(), unicode)


# Generated at 2022-06-24 02:50:00.620571
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy_regex = LazyRegex(('^an?', re.IGNORECASE))
    regex1 = lazy_regex.match('A')
    regex2 = lazy_regex.match('b')

# Generated at 2022-06-24 02:50:09.862102
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    re.compile('abc')
    orig_re = re.compile
    install_lazy_compile()
    try:
        re_compile_f = re.compile
        re.compile('abc')
        r = re_compile_f('abc')
        if not isinstance(r, LazyRegex):
            raise AssertionError("expected LazyRegex, got %r" % (r,))
    finally:
        reset_compile()
        if re.compile is not orig_re:
            raise AssertionError("re.compile is not restored")



# Generated at 2022-06-24 02:50:17.118601
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib.tests import TestCase
    import copy

    class TestInvalidPattern(TestCase):

        def test___eq__(self):
            error1 = InvalidPattern('foo')
            error2 = InvalidPattern('bar')

            self.assertFalse(error1 == error2)
            self.assertFalse(error2 == error1)

            error1a = copy.deepcopy(error1)

            self.assertTrue(error1 == error1a)
            self.assertTrue(error1a == error1)

            error1.msg = 'bar'

            self.assertFalse(error1 == error1a)
            self.assertFalse(error1a == error1)

    TestInvalidPattern('test___eq__').run()

# Generated at 2022-06-24 02:50:24.856425
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test lazy_regex.LazyRegex.__setstate__

    Create and pickle a LazyRegex object and check that it's restored
    properly from pickle data.
    """
    from bzrlib.tests import TestCase, TestCaseWithTransport
    from bzrlib import tests
    import pickle
    t = LazyRegex([tests.TEST_EMAIL_PATTERN])
    t.__setstate__({"args": [tests.TEST_EMAIL_PATTERN], "kwargs": {}})
    if not isinstance(t, LazyRegex):
        failure("__setstate__ does not return a LazyRegex object")

# Generated at 2022-06-24 02:50:31.974420
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for a bug that was introduced with Python 2.4

    The bug is that the regex is instantiated before we set the _regex_args.
    This results in a NoneType object has no attribute 'groups'
    """
    import cPickle
    lazy = LazyRegex()
    # This fails with the following exception:
    #  AttributeError: 'NoneType' object has no attribute 'groups'
    cPickle.dumps(lazy, 2)

# Generated at 2022-06-24 02:50:38.589816
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """The method __unicode__ of InvalidPattern converts the error message to
    unicode.

    In Python2, it uses the default encoding, while in Python3 it simply calls
    the unicode() constructor.
    """
    msg = 'cannot compile "abc"'
    invalid_pattern = InvalidPattern(msg)
    try:
        unicode(invalid_pattern)
    except UnicodeDecodeError:
        # The error message is encoded in default encoding:
        # if the default encoding is not utf8, a UnicodeDecodeError will be
        # raised.
        if getattr(msg, 'decode', None):
            raise
        else:
            # Python3
            pass



# Generated at 2022-06-24 02:50:45.232737
# Unit test for function lazy_compile
def test_lazy_compile():
    class MockReObject(object):
        def __init__(self):
            self.compiled = False
        def compile(self, *args, **kwargs):
            self.compiled = True
            return self
        def finditer(self, *args, **kwargs):
            return self
    saved_compile = re.compile

# Generated at 2022-06-24 02:50:56.630294
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__() reinitialises the object from a saved state

    The saved state is generated by __getstate__().
    """
    expected_args = (r'^(?P<name>.*)$',)
    expected_kwargs = {'re.UNICODE': False}
    lr = LazyRegex(expected_args, expected_kwargs)
    state = lr.__getstate__()
    assert state == {'args': expected_args, 'kwargs': expected_kwargs}
    lr2 = LazyRegex()
    lr2.__setstate__(state)
    assert lr2._regex_args == expected_args
    assert lr2._regex_kwargs == expected_kwargs
    assert lr2._real_regex is None

# Generated at 2022-06-24 02:51:01.935270
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Ensure that we correctly handle unpickling an LazyRegex"""
    lazy = LazyRegex(['foo', re.I])
    import pickle
    new_lazy = pickle.loads(pickle.dumps(lazy))
    assert new_lazy._regex_args[0] == 'foo'
    assert new_lazy._regex_args[1] == re.I

# Generated at 2022-06-24 02:51:05.464436
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    lazy_pattern = LazyRegex([r'a*'])
    lazy_pattern._compile_and_collapse()
    assert isinstance(lazy_pattern._real_regex, re._pattern_type), \
        '_real_regex should be an instance of _pattern_type'


# Generated at 2022-06-24 02:51:17.735259
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """Constructor of class LazyRegex"""
    lr = LazyRegex()
    assert lr._regex_args == () and lr._regex_kwargs == {}, lr

    lr = LazyRegex("(a*)", re.I)
    assert lr._regex_args == ("(a*)",) and lr._regex_kwargs == {'flags': re.I}, \
        (lr._regex_args, lr._regex_kwargs)

    lr = LazyRegex("(a*)", flags=re.I)
    assert lr._regex_args == ("(a*)",) and lr._regex_kwargs == {'flags': re.I}, \
        (lr._regex_args, lr._regex_kwargs)

    lr

# Generated at 2022-06-24 02:51:25.945534
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    lr = lazy_compile("^a")
    d = lr.__getstate__()
    old_real_regex = lr._real_regex
    real_regex = lr._real_re_compile("^b")
    lr._real_regex = real_regex
    lr.__setstate__(d)
    assert lr._real_regex == old_real_regex
    assert lr._regex_args == ("^a",)
    assert lr._regex_kwargs == {}

# Generated at 2022-06-24 02:51:36.536431
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__() recovers from a previously pickled state."""
    # Create a LazyRegex instance.
    # Its attributes have not been copied from the object returned
    # by re.compile().
    lazy_regex = LazyRegex()
    # Set the attributes used for pickling to simulate
    # the state of a pickled object.
    lazy_regex._regex_args = ('a',)
    lazy_regex._regex_kwargs = {'flags': re.IGNORECASE}
    # Try to recover the state of a previously pickled instance.
    lazy_regex.__setstate__(lazy_regex.__getstate__())
    # Check that the instance has been recovered.
    # The attributes used for pickling must have been reset.
    assert lazy_regex

# Generated at 2022-06-24 02:51:38.900108
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    try:
        raise InvalidPattern("a message")
    except Exception as e:
        e_ref = e
    assert(repr(e_ref) == "InvalidPattern('a message')")

# Generated at 2022-06-24 02:51:45.663283
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ sets attributes '_regex_args' and '_regex_kwargs'."""
    state = {'args': ('',), 'kwargs': {}}
    lazy_regex = LazyRegex()
    lazy_regex.__setstate__(state)
    eq(lazy_regex._regex_args, state['args'])
    eq(lazy_regex._regex_kwargs, state['kwargs'])


# Generated at 2022-06-24 02:51:54.635699
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should be able to create a 'str' from any unicode"""
    class UnicodePrintException(Exception):
        """An exception with a unicode message, but a __str__ that prints
        a str.
        """
        def __unicode__(self):
            return u'\N{HIRAGANA LETTER A}'
        def __str__(self):
            return '\xE3\x81\x82'
    e = UnicodePrintException()
    err = InvalidPattern(e)
    str(err) # we don't care what it is, we just want to make sure it works

# Generated at 2022-06-24 02:51:55.397458
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:52:05.157028
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy regex compilation."""
    # Test the function with an invalid pattern.
    # I would have used ')' here, but re.finditer won't find that
    # in the pattern.
    invalid_patterns = ['(', 'a++b']
    for invalid_pattern in invalid_patterns:
        try:
            re.compile(invalid_pattern)
        except re.error:
            pass
        else:
            raise AssertionError("compiling %r didn't raise re.error, but"
                                 " should." % invalid_pattern)

    # Test the function with a valid pattern.
    valid_patterns = ['a*b', 'a|b']
    for valid_pattern in valid_patterns:
        re.compile(valid_pattern)

    # Test the function with an invalid pattern and flags


# Generated at 2022-06-24 02:52:11.891376
# Unit test for function finditer_public
def test_finditer_public():
    re.compile = _real_re_compile
    for re_input in (
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
    ):
        x = re.finditer(r'a(b(c(d(e(f(g))))))', re_input)
        y = finditer_public(r'a(b(c(d(e(f(g))))))', re_input)
        assert list(y) == list(x)
    re.compile = lazy_comp

# Generated at 2022-06-24 02:52:22.990534
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test the method __setstate__ of the class LazyRegex."""
    from StringIO import StringIO
    from pickle import dumps, load, HIGHEST_PROTOCOL
    args = ('\\d+',)
    kwargs = dict(flags=re.VERBOSE)
    object_ = LazyRegex(*args, **kwargs)
    # Overwrite _real_regex to force to use __setstate__
    object_._real_regex = None
    # Check that __getstate__ doesn't raise an exception
    state = object_.__getstate__()
    # Check that __setstate__ doesn't raise an exception
    object_.__setstate__(state)
    # Check that dumps doesn't raise an exception
    dumps(object_, HIGHEST_PROTOCOL)
    # Check that load doesn't raise

# Generated at 2022-06-24 02:52:27.130318
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import random
    import sys
    random.seed(0)
    for i in range(100):
        x = random.randrange(sys.maxint)
        e = InvalidPattern(str(x))
        f = InvalidPattern(str(x))
        assert e == f
        assert e != None
        f = InvalidPattern(str(x+1))
        assert e != f

# Generated at 2022-06-24 02:52:39.026803
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test __unicode__() for InvalidPattern."""
    from bzrlib.i18n import gettext
    e = InvalidPattern("test message")
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == e.msg

    e = InvalidPattern("test message with %(foo)s")
    e.foo = 'Foo'
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == gettext("test message with %(foo)s") % {'foo': 'Foo'}

    # This must work if UnicodeDecodeError is raised
    e = InvalidPattern("test message with %(foo)s")
    e.foo = '\xFF'
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-24 02:52:46.310109
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore the state of the object. In particular,
    it should restore the state of members _regex_args and _regex_kwargs.
    """
    lazy = LazyRegex('foo')
    state = lazy.__getstate__()
    lazy.__setstate__(state)
    # When we restore state, _regex_args and _regex_args should be set
    # correctly. We expect that foo is matched.
    assert lazy.search('foo').group() == 'foo'

# Generated at 2022-06-24 02:52:57.663853
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    import doctest
    from bzrlib.tests.test_blackbox import ExternalBase
    from bzrlib.tests import TestCase
    from bzrlib.tests.matchers import DocTestMatches
    from bzrlib.errors import BzrError
    from bzrlib.i18n import gettext
    from bzrlib.trace import show_error
    # Doctest of method __eq__
    # Here the test is run twice, the first time use
    # a class that extends from BzrError and the second time
    # we use a class that has the same behaviour of InvalidPattern
    # (using the class InvalidPattern directly causes an error
    # in doctest, probably because it inherits from ValueError
    # and ValueError is also used in doctest). This is required
    # to check that the docstring

# Generated at 2022-06-24 02:53:07.176330
# Unit test for function finditer_public
def test_finditer_public():
    import re
    from bzrlib.tests.test_regex import TestRegex
    test_case = TestRegex()
    test_case.test_finditer()

# Some libraries call re.split which fails it if receives a LazyRegex.
if getattr(re, 'split', False):
    def split_public(pattern, string, maxsplit=0):
        if isinstance(pattern, LazyRegex):
            return pattern.split(string, maxsplit)
        else:
            return _real_re_compile(pattern).split(string, maxsplit)
    re.split = split_public
