

# Generated at 2022-06-24 02:43:14.973430
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """ test __repr__ method of InvalidPattern"""
    err_msg = u'fre\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8\xf8bar'
    ip = InvalidPattern(err_msg)
    repr(ip) # for coverage



# Generated at 2022-06-24 02:43:19.864119
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__ must not compare _fmt and _preformatted_string"""
    e1 = InvalidPattern('msg1')
    e2 = InvalidPattern('msg2')
    e3 = InvalidPattern('')
    e4 = InvalidPattern('')
    e4._preformatted_string = 'msg4'
    assert e1 != e2
    assert e1 != e3
    assert e3 != e4
    assert e1 != type('test_InvalidPattern___eq__', (object,), {})()

# Generated at 2022-06-24 02:43:23.087976
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    proxy = lazy_compile('abc')
    state = proxy.__getstate__()
    assert state == {'args': ('abc',), 'kwargs': {}}, state

# Generated at 2022-06-24 02:43:28.921039
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    # the constructor of class LazyRegex should not find the real regex
    # before it is requested.
    lazyregex = lazy_compile(r'^\w+:$')
    assert lazyregex._real_regex is None
    # It should be compiled on the first access
    assert lazyregex.match('abc:') is not None
    assert lazyregex._real_regex is not None

# Generated at 2022-06-24 02:43:31.681022
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    if re.compile is not lazy_compile:
        raise AssertionError
    reset_compile()
    if re.compile is lazy_compile:
        raise AssertionError

# Generated at 2022-06-24 02:43:34.874750
# Unit test for function lazy_compile
def test_lazy_compile():
    r = lazy_compile('bar')
    assert r.match('foo') is None
    assert r.match('bar')
    assert r.match('bar')


# Generated at 2022-06-24 02:43:41.606594
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test converting close method of regular expression to proxy method

    The conversion is done by method LazyRegex.__getattr__.  We need to
    make sure that __getattr__ only convert attributes of a compiled
    regular expression.  This test is to make sure that __getattr__
    behaves as expected.
    """
    proxy = LazyRegex()

    # Access 'foo' which is not a compiled regular expression should
    # raise AttributeError.
    try:
        proxy.foo
    except AttributeError:
        pass
    else:
        raise AssertionError('access to non-existent attribute of proxy object '
                             'should raise AttributeError')

    # Access 'foo' which is not a compiled regular expression should
    # raise AttributeError.

# Generated at 2022-06-24 02:43:45.720092
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    InvalidPattern("")
    InvalidPattern("Invalid pattern(s) found. Expecting a project name or URL.")

# Generated at 2022-06-24 02:43:50.749594
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ returns the correct value."""
    rex = LazyRegex(["foo"], {"flags": re.IGNORECASE})
    eq = {
        "args": ["foo"],
        "kwargs": {"flags": re.IGNORECASE},
        }
    assert rex.__getstate__() == eq



# Generated at 2022-06-24 02:43:55.799234
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # These are just for clarity below
    compile = re.compile
    lazy_compile = LazyRegex

    # Reset to original if needed
    reset_compile()
    # Should be the same as the original compile
    assert re.compile is _real_re_compile
    # The lazy compile function should be a different one which proxies
    assert lazy_compile is not re.compile

    # Install the new mode of operation
    install_lazy_compile()
    # Should now be the same as re.compile
    assert re.compile is lazy_compile
    # The lazy compile function should be a different one which proxies
    assert lazy_compile is not re.compile

    # Reset back to original
    reset_compile()
    # Should now be back to the original mode

# Generated at 2022-06-24 02:43:58.682362
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    pattern = LazyRegex(('foobar'))
    assert pattern._real_regex is None
    assert pattern._regex_args == ('foobar',)


# Generated at 2022-06-24 02:44:09.906320
# Unit test for function reset_compile
def test_reset_compile():
    global _real_re_compile
    # reset_compile is called by bzrlib.__init__, so run it here to
    # ensure we have the original value.
    reset_compile()
    _real_re_compile = re.compile
    # reset_compile will reset the value to this, so capture the
    # original one.
    orig_re_compile = _real_re_compile
    # Set re.compile to a different value

# Generated at 2022-06-24 02:44:15.958485
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    # If the compile has been installed, reset it first.
    if re.compile is not _real_re_compile:
        reset_compile()

    install_lazy_compile()
    try:
        obj = re.compile("bar")
        # The type should really be LazyRegex
        if not isinstance(obj, LazyRegex):
            raise AssertionError("re.compile did not install LazyRegex")
    finally:
        reset_compile()

# Generated at 2022-06-24 02:44:23.469802
# Unit test for function reset_compile
def test_reset_compile():
    from bzrlib.tests import TestCase
    from bzrlib.tests.matchers import HasLayout
    import re
    class TestResetCompile(TestCase):

        def test_reset_compile(self):
            self.assertIs(_real_re_compile, re.compile)
            install_lazy_compile()
            self.assertIs(lazy_compile, re.compile)
            reset_compile()
            self.assertIs(_real_re_compile, re.compile)

        def test_reset_compile_nested(self):
            self.assertIs(_real_re_compile, re.compile)
            install_lazy_compile()
            self.assertIs(lazy_compile, re.compile)
            reset_compile()
            self

# Generated at 2022-06-24 02:44:33.531981
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test __repr__ of class InvalidPattern"""
    from bzrlib.i18n import gettext

    # Without arguments
    e = InvalidPattern('')
    assert repr(e) == 'InvalidPattern(\'\')'

    # With arguments
    e_attr = dict(msg='error')
    # use a gettext function which will return the arg as a unicode string
    e_fmt = gettext(u'%(msg)s')
    e = InvalidPattern(**e_attr)
    assert repr(e) == 'InvalidPattern(u\'error\')'

    # With arguments and format
    e = InvalidPattern(e_fmt, **e_attr)
    assert repr(e) == 'InvalidPattern(u\'error\')'

    # With arguments and unicode format

# Generated at 2022-06-24 02:44:42.682831
# Unit test for function finditer_public
def test_finditer_public():
    """
    Test to make sure that re.finditer will work with LazyRegex objects.
    """
    from bzrlib.tests import TestCase
    from bzrlib.patiencediff import _patience_filter
    class TestFinditer(TestCase):
        def test_finditer_public_patience_filter(self):
            """
            Test to make sure that re.finditer will work with LazyRegex objects.
            """
            # TODO: jam 20080205 Implementing this unit test requires a fix to
            #       _patience_filter so that it returns the iterators from
            #       re.finditer, rather than lists of strings.  This is an
            #       optimization which is probably not needed in practice.
            pass

# Generated at 2022-06-24 02:44:54.571852
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    from bzrlib.tests import TestCase

    class TestLazyRegex(TestCase):

        def test_pass_no_args(self):
            r = LazyRegex()
            self.assertIs(None, r._real_regex)

        def test_pass_some_args(self):
            r = LazyRegex('(compile me)')
            self.assertIs(None, r._real_regex)


# If called as a script, run unit tests.
if __name__ == '__main__':
    import sys
    import bzrlib.tests
    bzrlib.tests.run_suite(sys.modules[__name__])

# Generated at 2022-06-24 02:44:59.005759
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    l = lazy_compile(" foobar")
    l.__getstate__()
    # this is the test
    l._regex_args[0] = ""



# Generated at 2022-06-24 02:45:09.367358
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test the install_lazy_compile and reset_compile functions."""
    reset_compile()
    regex1 = re.compile("a.*a")
    install_lazy_compile()
    regex2 = re.compile("a.*a")
    reset_compile()
    regex3 = re.compile("a.*a")
    if regex1 is not regex3:
        raise AssertionError("resetting re.compile() didn't produce the "
                             "same regex object")
    if not isinstance(regex2, LazyRegex):
        raise AssertionError("lazy_compile didn't return a LazyRegex object")

# Generated at 2022-06-24 02:45:16.506075
# Unit test for function finditer_public
def test_finditer_public():
    """Test that finditer_public can find unicode characters"""
    from bzrlib.tests import TestCase
    # test that a LazyRegex can be used
    r = lazy_compile(u'a')
    # compile the proxy object
    i = r.finditer(u'a')
    il = list(i)
    # test that a match was found
    TestCase().assertLength(1, il)
    # test that a unicode character can be matched
    i = r.finditer(u'\xe4')
    TestCase().assertLength(1, list(i))

# Generated at 2022-06-24 02:45:26.064685
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """__eq__() method of InvalidPattern works correctly."""

    class DerivedInvalidPattern(InvalidPattern):
        _fmt = ('Foo bar')

    p1a = InvalidPattern('Bar foo')
    p1b = InvalidPattern('Bar foo')
    p2a = DerivedInvalidPattern('Bar foo')
    p2b = DerivedInvalidPattern('Bar foo')

    expected_equal = (
        (p1a, p1b),  # using the @property behaviour above
        (p1a, p1a),
        (p2a, p2a),
        (p2a, p2b),
        (p2b, p2a),
    )

# Generated at 2022-06-24 02:45:33.793825
# Unit test for function reset_compile
def test_reset_compile():
    install_lazy_compile()
    re_compile_ref = re.compile

    # calling install_lazy_compile() again should do nothing
    install_lazy_compile()
    assert re.compile is re_compile_ref

    reset_compile()
    assert re.compile is _real_re_compile
    # calling reset_compile() again should do nothing
    reset_compile()
    assert re.compile is _real_re_compile


# Generated at 2022-06-24 02:45:43.386522
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test if LazyRegex returns the expected values for __getattr__.
    """
    # Test with an empty pattern
    proxy = LazyRegex(args=['', 0])
    assert proxy.findall('') == [''], (
        'LazyRegex.findall(\'\') returned %s instead of [\'\']'
        % (repr(proxy.findall(''))))
    assert proxy.findall('a') == [], (
        'LazyRegex.findall(\'a\') returned %s instead of [\'\']'
        % (repr(proxy.findall('a'))))
    # Test with non-empty pattern
    proxy = LazyRegex(args=['[a-z]*', 0])

# Generated at 2022-06-24 02:45:54.009436
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    def check_state(r, args, kwargs):
        assert r._real_regex is None
        assert r._regex_args == args
        assert r._regex_kwargs == kwargs


    r = LazyRegex(args=('a',), kwargs={'regex': 'a',
                                       'flags': [1,2,3]})
    check_state(r, ('a',), {'regex': 'a',
                            'flags': [1,2,3]})

    r.__setstate__({'args': ('b',),
                    'kwargs': {'regex': 'b',
                               'flags': [4,5,6]}})

# Generated at 2022-06-24 02:46:05.671466
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    r = LazyRegex(('^\d{10}$', ))
    try:
        r.findall('a')
    except AttributeError:
        pass
    else:
        assert False, "LazyRegex.findall should raise AttributeError at this stage"
    try:
        r.findall('123456789012345')
    except Exception as e:
        if str(e) == "'NoneType' object has no attribute 'groups'":
            raise tests.TestNotApplicable('No regex implementation')
        raise e
    assert r.findall('123456789012345') == ['123456789012345']
    assert r.findall('123456789012') == []
    assert r.findall('123456789012') == []


# Generated at 2022-06-24 02:46:16.461592
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should not replace slots"""

    class TestState(object):
        """Just a test class to test that slots are not changed in __setstate__
        """
        __slots__ = ['a', 'b']

        def __init__(self):
            self.a = None
            self.b = None

        def __getstate__(self):
            return {'a': 'a', 'b': 'b'}

        def __setstate__(self, dict):
            self.a = dict['a']
            self.b = dict['b']

    test_set_state = TestState()
    setattr(test_set_state, 'c', 'c')
    # test that __getstate__ and __setstate__ work well with slots

# Generated at 2022-06-24 02:46:25.337973
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should re-initialise the instance."""
    regex = LazyRegex(('abc',), dict(re.I))
    # The instance is not initialised, _real_regex is None
    regex.__setstate__(dict(args=('cba',), kwargs=dict(re.X)))
    # The instance is re-initialised, _real_regex is not None
    assert regex._real_regex is None, \
           "Expected to find None, found %r." % regex._real_regex

# Generated at 2022-06-24 02:46:32.248657
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method LazyRegex.__setstate__ restoring from a pickled state."""
    args = ("a.*b",)
    kwargs = {"flags":re.IGNORECASE}
    lazy_regex = LazyRegex(args, kwargs)
    states = (
        {"args": None, "kwargs": {"flags": 0}},
        {"args": ("a.*b",), "kwargs": None},
        {"args": args, "kwargs": kwargs},
        )
    for state in states:
        lazy_regex.__setstate__(state)
        if lazy_regex._regex_args != state["args"] or \
           lazy_regex._regex_kwargs != state["kwargs"]:
            raise AssertionError("Fails restoring from %r" % state)

# Generated at 2022-06-24 02:46:37.729045
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Check that the __repr__ method of class InvalidPattern works properly.

    This test is not in the test_re module because it would be executed by
    default by the bzr suite, while it is intended to test code in this
    module, which is not executed by default.
    """
    e = InvalidPattern("lalala")
    assert repr(e) == "InvalidPattern(lalala)"

# Generated at 2022-06-24 02:46:47.439505
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    if getattr(re, 'compile', False):
        reset_compile()
    install_lazy_compile()
    # Setting the attribute to a different value is not enough to break the
    # test, because the original value is stored in a module attribute.
    # Setting the module attribute directly breaks it.
    def _foo(): pass
    re._compile = _foo
    def _foo2(): pass
    setattr(re, 'compile', _foo2)
    try:
        reset_compile()
    finally:
        re._compile = _real_re_compile



# Generated at 2022-06-24 02:46:59.175377
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    try:
        raise InvalidPattern('some message')
    except InvalidPattern as e:
        import sys
        if sys.version_info[0] >= 3:
            expected = 'Invalid pattern(s) found. "some message"'
        else:
            expected = 'Invalid pattern(s) found. u"some message"'
        # check that it prints nicely as str and unicode
        if str(e) != expected:
            raise AssertionError('InvalidPattern str output is %r, expected %r'
                                 % (str(e), expected))
        if unicode(e) != expected:
            raise AssertionError('InvalidPattern unicode output is %r, expected %r'
                                 % (unicode(e), expected))



# Generated at 2022-06-24 02:47:10.067903
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test lazy_compile function"""
    regex = re.compile(r'^[ \t\r\f\v]+')
    # Copy members to local variables to avoid a lazy compile when
    # accessing them
    match = regex.match
    split = regex.split

    re.compile = lazy_compile

# Generated at 2022-06-24 02:47:14.884781
# Unit test for function lazy_compile
def test_lazy_compile():
    """Test that re.compile can be overridden as lazy_compile"""
    re.compile = _real_re_compile
    re.compile = lazy_compile

    try:
        regex = re.compile('foo')
    except re.error:
        raise AssertionError("Error calling lazy_compile")

    reset_compile()



# Generated at 2022-06-24 02:47:21.322905
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import (
        gettext,
        )
    gettext(u"hello")
    msg = u"An error message"
    try:
        raise InvalidPattern(msg)
    except InvalidPattern as e:
        expected = msg.encode("utf8")
        observed = e.__str__()
        assert expected == observed, "%s != %s" % (expected, observed)
        #__unicode__ should return unicode, not UTF-8 encoded str
        expected = msg
        observed = unicode(e)
        assert expected == observed, "%s != %s" % (expected, observed)



# Generated at 2022-06-24 02:47:31.874699
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """__getstate__() should return {"args": self._regex_args,
                                    "kwargs": self._regex_kwargs}"""
    r = LazyRegex()
    state = r.__getstate__()
    self.assertTrue(isinstance(state, dict))
    self.assertEqual({'args': (), 'kwargs': {}}, state)

    r2 = LazyRegex(['foo(?P<foo>[0-9]+)(ba(?P=foo)+r)?'],
                                                    {'flags': re.IGNORECASE})
    state = r2.__getstate__()
    self.assertTrue(isinstance(state, dict))

# Generated at 2022-06-24 02:47:42.289461
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Tests whether the pickled state can be restored correctly."""
    import pickle

    state = {"args": ("foo", "bar"), "kwargs": {"debug": 111}}
    lazy_regex = LazyRegex()
    lazy_regex.__setstate__(state)

    assert state == lazy_regex.__getstate__()
    # Make sure the pickle state can be correctly restored
    state2 = {"args": ("foo", "bar"), "kwargs": {"debug": 111}}
    lazy_regex2 = LazyRegex()
    lazy_regex2.__setstate__(pickle.loads(pickle.dumps(state2)))
    assert state2 == lazy_regex2.__getstate__()


# Generated at 2022-06-24 02:47:46.065511
# Unit test for function finditer_public
def test_finditer_public():
    """Test the function finditer_public.
    """
    import doctest
    from bzrlib import tests
    import re

    def _load_tests():
        return doctest.DocTestSuite(re)

    tests.test_suite.addTest(_load_tests)

# Generated at 2022-06-24 02:47:50.831990
# Unit test for function finditer_public
def test_finditer_public():
    from breezy.tests import TestCase

    class ReTest(TestCase):

        def test_finditer_public(self):
            re_LazyRegex = LazyRegex(('a', ))
            re_SRE_Pattern = _real_re_compile('a')
            self.assertEqual(
                list(finditer_public(re_LazyRegex, 'a')),
                list(finditer_public(re_SRE_Pattern, 'a')))

    ReTest('test_finditer_public').run()

# Generated at 2022-06-24 02:47:55.155243
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """__repr__ returns a string that can be evaluated to
    recreate an object.
    """
    repr_str = repr(InvalidPattern('foo'))
    exec('obj = %s'%repr_str)
    assert obj.msg == 'foo'

# Generated at 2022-06-24 02:48:00.224202
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Testing __setstate__ of class LazyRegex"""
    regex = LazyRegex((), {})
    regex.__setstate__({"args": ["pattern"], "kwargs": {"flags": 0}})
    assert regex._regex_args == ("pattern",)
    assert regex._regex_kwargs == {"flags": 0}


# Generated at 2022-06-24 02:48:05.128596
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    reset_compile()
    install_lazy_compile()
    real_re_compile = re.compile
    reset_compile()
    assert real_re_compile is re.compile
    reset_compile()
    install_lazy_compile()
    assert re.compile(r'foo') != real_re_compile(r'foo')

# Generated at 2022-06-24 02:48:16.112644
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    """Test that install_lazy_compile and reset_compile work"""
    import re
    # This should be the real re.compile function
    assert re.compile is _real_re_compile
    install_lazy_compile()
    # This should be lazy_compile
    assert re.compile is lazy_compile
    reset_compile()
    # Back to the real function
    assert re.compile is _real_re_compile
    reset_compile()
    # Still the real function
    assert re.compile is _real_re_compile
    install_lazy_compile()
    # Back to lazy_compile
    assert re.compile is lazy_compile



# Generated at 2022-06-24 02:48:19.466146
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object, not a unicode object"""
    try:
        raise InvalidPattern(u"bla!")
    except InvalidPattern as e:
        assert isinstance(str(e), str)

# Generated at 2022-06-24 02:48:20.827801
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    assert LazyRegex([])


# Generated at 2022-06-24 02:48:25.004230
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    from bzrlib.i18n import gettext
    fmt = "*%(msg)s*"
    gettext(fmt) # force translation to get '_' marker in fmt.
    error = InvalidPattern("test message")
    assert error._fmt == fmt
    assert error.msg == "test message"
    assert str(error) == "*test message*"


# Generated at 2022-06-24 02:48:33.134110
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should be able to restore a pickled LazyRegex"""
    import pickle
    args = ("^(https?:|ftp:)//",)
    kwargs = {"flags": 0}
    proxy = LazyRegex(args, kwargs)
    # force compile the proxy and then pickle it
    proxy.match("http://www.example.com")
    pickled = pickle.dumps(proxy)
    # restore the pickled proxy and test it
    new_proxy = pickle.loads(pickled)
    # the proxy should have been restored
    assert(new_proxy.match("http://www.example.com"))
    # the proxy should be a LazyRegex
    assert(isinstance(new_proxy, LazyRegex))
    # the proxy should still be lazy

# Generated at 2022-06-24 02:48:38.050322
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    pattern = lazy_compile('\d')
    assert(pattern.pattern == '\d')
    assert(pattern.match('2'))


# Generated at 2022-06-24 02:48:46.321099
# Unit test for function lazy_compile
def test_lazy_compile():
    """The LazyRegex object is a proxy to the real regex object."""
    # Replace the compile function, so we can see the lazy compile
    # in action
    global _real_re_compile
    _real_re_compile = lambda *args, **kwargs: 'original regex'
    regex = lazy_compile('test regex')
    # Check the proxy actually works
    eq = [
        getattr(regex, attr)
        for attr in LazyRegex._regex_attributes_to_copy
        ]
    eq = eq + [
        getattr(regex, 'a_new_attribute', None)
        ]
    eq = eq + [
        hasattr(regex, attr)
        for attr in LazyRegex._regex_attributes_to_copy
        ]
   

# Generated at 2022-06-24 02:48:48.894880
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return str(self)"""
    msg = 'foo'
    ipat = InvalidPattern(msg)
    assert repr(ipat) == 'InvalidPattern(%r)' % (msg,)

# Generated at 2022-06-24 02:48:52.066894
# Unit test for function reset_compile
def test_reset_compile():
    re.compile = lazy_compile
    reset_compile()
    re.compile = lazy_compile
    reset_compile()

# Generated at 2022-06-24 02:48:56.039266
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex __getattr__ actually works."""
    lr = lazy_compile('^abc')
    assert [x.start() for x in lr.finditer('abc def')] == [0]
    assert lr.pattern == '^abc'



# Generated at 2022-06-24 02:49:07.142106
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should rebuild the regex after pickle."""
    #
    # Create a regex pattern
    regex = LazyRegex(('^bzr: \\(bzr ([0-9\\.]+), ', re.VERBOSE))
    # Test the pattern
    match = regex.search('bzr: (bzr 1.13) using python 2.3.3 on linux2')
    #
    # Ensure that the pattern is compiled
    assert regex._real_regex is not None
    #
    # Save the pattern state
    state = regex.__getstate__()
    #
    # Reset the pattern
    regex._real_regex = None
    #
    # Test the pattern again: it should fail to compile the pattern this time

# Generated at 2022-06-24 02:49:13.013293
# Unit test for function finditer_public
def test_finditer_public():
    search_results = re.finditer('foo', 'foobar')
    assert isinstance(search_results, list)
    assert len(search_results) == 1
    for search_result in search_results:
        assert isinstance(search_result, type(re.search('foo', 'foobar')))


# We install LazyRegex as the default re.compile as some of the code will
# use re.compile directly, and we want it to get a LazyRegex proxy object
install_lazy_compile()

# Generated at 2022-06-24 02:49:17.874430
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """ \
    Test if method __str__ returns an utf-8 encoded string
    """
    exception = InvalidPattern('Some message')
    # Ensure that exception.__str__ is <type 'str'> (i.e. not unicode)
    msg = str(exception)
    assert(isinstance(msg, str))

# Generated at 2022-06-24 02:49:23.043224
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of class InvalidPattern should return a str object."""
    class TestInvalidPattern(InvalidPattern):
        _fmt = 'Test case'

    str_exc = str(TestInvalidPattern('Test case'))
    assert isinstance(str_exc, str)



# Generated at 2022-06-24 02:49:30.471925
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    msg = 'the error message'
    exception = InvalidPattern(msg)
    # InvalidPattern(msg).__eq__(InvalidPattern(msg)) must return True
    assert exception.__eq__(InvalidPattern(msg))
    # InvalidPattern(msg).__eq__(InvalidPattern(othermsg)) must return False
    othermsg = 'the other message'
    assert not exception.__eq__(InvalidPattern(othermsg))
    # InvalidPattern(msg).__eq__(InstanceOfDiffClass) must return False
    class DiffClass(object):
        pass
    assert not exception.__eq__(DiffClass())

# Generated at 2022-06-24 02:49:43.305263
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from cStringIO import StringIO
    import sys
    import traceback
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import UnicodeFilenameFeature

    class TestInvalidPattern___str__(TestCase):
        """Test method __str__ of class InvalidPattern."""

        def test(self):
            # test the default case
            e = InvalidPattern('msg')
            self.assertEqual('Invalid pattern(s) found. "msg"', str(e))
            # str(e) should be the same as repr(e)
            self.assertEqual(e, eval(repr(e)))
            self.assertEqual('Invalid pattern(s) found.',
                             InvalidPattern('')._format())
            # test a preformatted message

# Generated at 2022-06-24 02:49:45.362247
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    LazyRegex()

# Generated at 2022-06-24 02:49:55.502574
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    def check(fmt, expected):
        """Check InvalidPattern.__unicode__(fmt) against expected.

        :param fmt: value to be passed to the constructor
        :param expected: expected value returned by __unicode__
        """
        invalid_pattern = InvalidPattern(fmt)
        # The default returned value is unicode
        result = unicode(invalid_pattern)
        try:
            # See if it decodes as ascii
            unicode(result, 'ascii')
        except UnicodeError:
            raise AssertionError("__unicode__(%r) returned '%s' which does not " \
                "decode as ascii" % (fmt, result))

# Generated at 2022-06-24 02:50:00.765871
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test __getstate__ of class LazyRegex

    Test the correctness of method __getstate__.
    """
    lzy = LazyRegex(args=('a',), kwargs={'flags':1})
    assert lzy.__getstate__() == {'args': ('a',), 'kwargs': {'flags':1}}

# Generated at 2022-06-24 02:50:11.507248
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex___getattr__: check that we get an attribute from the proxy."""
    # We must check that __getattr__ works with an attribute that exist on
    # real regex i.e. _sre.SRE_Pattern. We can't check directly attr because
    # it is a property which call __getattr__.
    # The attribute 'subn' is a method of the _sre.SRE_Pattern class.
    # We use it because it is not a property.
    # We use the following regex because we need a regex which is compiled.
    pattern = lazy_compile('\w+\s+\w+[!?]?\s*\Z', re.MULTILINE)
    assert getattr(pattern, 'subn') == re.subn

# Generated at 2022-06-24 02:50:15.447300
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    err = InvalidPattern('msg')
    assert str(repr(err)) == 'InvalidPattern(msg)'


# Generated at 2022-06-24 02:50:23.727678
# Unit test for function finditer_public
def test_finditer_public():
    """Check that finditer_public works.

    This function is necessary to avoid infinite recursion in the setUp() of
    TestLazyRegex.
    """
    import re

    a_re = re.compile('A(.)')
    def _iter(regex, string):
        return iter([(0, 1, 'B')])
    # Patching the finditer of the regex (which is what re.finditer will call)
    a_re.finditer = _iter
    match_iter = finditer_public(a_re, 'ABC')
    try:
        res = match_iter.next()
    except AttributeError:
        res = next(match_iter)
    assert res == (0, 1, 'B')

test_finditer_public()

# Generated at 2022-06-24 02:50:34.647635
# Unit test for method __repr__ of class InvalidPattern

# Generated at 2022-06-24 02:50:45.922389
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    from bzrlib.tests.pycheck import Checker
    import re as _re

    check = Checker()
    try:
        # check that the real re.compile exists
        check.called_function("re.compile")
        _real_re_compile("abc")
    finally:
        check.finished()
    try:
        # check that the new re.compile exists
        check.called_function("re.compile")
        install_lazy_compile()
        lazy_re_compile("abc")
    finally:
        check.finished()
    try:
        # check that the new re.compile exists
        check.called_function("re.compile")
        _re.compile("abc")
    finally:
        check.finished()

# Generated at 2022-06-24 02:50:52.184132
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex."""
    import pickle
    obj = LazyRegex(args=('a',), kwargs={'flags': 0})
    pickle_string = pickle.dumps(obj)
    obj2 = pickle.loads(pickle_string)
    if obj != obj2:
        raise AssertionError('LazyRegex objects are not equal.')

# Generated at 2022-06-24 02:51:02.543482
# Unit test for function install_lazy_compile
def test_install_lazy_compile():
    import re
    import __builtin__
    from bzrlib.tests import TestCase
    from StringIO import StringIO

    class TestInstallLazyCompile(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.real_re_compile = re.compile

        def tearDown(self):
            TestCase.tearDown(self)
            re.compile = self.real_re_compile

            # Fixup __builtin__. As the module might be already reloaded
            # by the test suite.
            if getattr(__builtin__, 're', False) and \
                    __builtin__.re.compile == lazy_compile:
                __builtin__.re.compile = self.real_re_compile


# Generated at 2022-06-24 02:51:05.720141
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """Test for method __repr of class InvalidPattern

    We check that __repr__ returns a string which is conform to the expected
    output.
    """
    error = InvalidPattern("test")
    assert repr(error) == "InvalidPattern('test')"



# Generated at 2022-06-24 02:51:12.489074
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test method __setstate__ of class LazyRegex"""
    import pickle
    proxy = LazyRegex(('a', ), ())
    proxy.__setstate__({'args': ('a', ), 'kwargs': ()})
    reloaded_proxy = pickle.loads(pickle.dumps(proxy))
    if not isinstance(reloaded_proxy, LazyRegex):
        raise AssertionError('__setstate__ not working')

# Generated at 2022-06-24 02:51:18.772345
# Unit test for constructor of class InvalidPattern
def test_InvalidPattern():
    e = InvalidPattern('msg')
    if e.msg != 'msg':
        raise AssertionError
    if e.__str__() != 'Invalid pattern(s) found. msg':
        raise AssertionError
    if e.__repr__() != 'InvalidPattern(Invalid pattern(s) found. msg)':
        raise AssertionError

# Generated at 2022-06-24 02:51:29.288532
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import sys
    if sys.version_info[0] == 3:
        exec("def u(x): return 'u'+repr(x)") # noqa: F821; pylint: disable=exec-used

    def assertEqualUnicode(e, expected):
        """Test e.__unicode__() == expected"""
        got = str(e)
        if sys.version_info[0] == 3:
            got = got[1:] # skip prepended 'u'
        if expected == u(''):
            assert got == ''
        else:
            assert got == expected, "%r != %r" % (got, expected)

    # no fmt, no vars
    e = InvalidPattern(None)

# Generated at 2022-06-24 02:51:34.623037
# Unit test for constructor of class LazyRegex
def test_LazyRegex():
    """LazyRegex(args, kwargs) creates a proxy object to re.compile(args, kwargs)
    """
    args = ('pattern', re.LOCALE|re.IGNORECASE)
    kwargs = dict(groupindex={'w': 5})
    lazy = LazyRegex(args, kwargs)
    assert isinstance(lazy, LazyRegex)


# Generated at 2022-06-24 02:51:42.012535
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # __unicode__ must return a unicode object, even if the message is
    # preformatted (already a unicode object) or a str object or whatever.
    msg = InvalidPattern('foo')
    assert isinstance(msg.__unicode__(), unicode)
    msg = InvalidPattern(u'foo')
    assert isinstance(msg.__unicode__(), unicode)
    # exception message should always be unicode

# Generated at 2022-06-24 02:51:53.566323
# Unit test for function reset_compile
def test_reset_compile():
    """Test reset_compile in a simple way.

    This isn't very comprehensive, but it does
    ensure that changes are restricted to this module
    """
    # This test is a bit confusing, because it will
    # actually test the reset_compile *function*, not
    # the reset_compile method.
    # first install lazy compile
    install_lazy_compile()
    # check that it has been installed
    assert re.compile is lazy_compile
    # now reset it
    reset_compile()
    # check that it was reset to the original
    assert re.compile is _real_re_compile
    # now reset it again
    reset_compile()
    # check that it is still the original
    assert re.compile is _real_re_compile

# Generated at 2022-06-24 02:52:00.004604
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():

    class MyLazyRegex(LazyRegex):
        _real_regex = True
        x = 0

    r1 = MyLazyRegex()
    r2 = MyLazyRegex()
    assert r1.x == 0
    r1.x = 1
    delattr(r2, 'x')
    assert r2.x == 0

    r1 = MyLazyRegex()
    r2 = MyLazyRegex()
    assert r1.y == r2.y
    r2.y = 1
    assert r1.y != r2.y
    del r1.y
    assert r1.y == 0

# Generated at 2022-06-24 02:52:04.021097
# Unit test for function reset_compile
def test_reset_compile():
    def local_compile():
        pass
    re.compile = local_compile
    install_lazy_compile()
    reset_compile()
    assert re.compile == local_compile

# Generated at 2022-06-24 02:52:08.403872
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    e1 = InvalidPattern('This is a message')
    e2 = InvalidPattern('This is a message')
    e3 = InvalidPattern('This is another message')
    assert(e1==e2)
    assert(e1 != e3)
    assert(e2 != e3)

# Generated at 2022-06-24 02:52:12.892387
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Test the method __eq__ of class InvalidPattern"""
    exc = InvalidPattern("msg")
    assert exc == exc # identical object
    assert exc == InvalidPattern("msg") # identical objects
    exc_other = InvalidPattern("other message")
    assert exc != exc_other
    assert exc != exc_other._format() # object and debug string
    assert exc != InvalidPattern("msg2") # different messages

# Generated at 2022-06-24 02:52:14.747123
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    """InvalidPattern.__repr__ should return a python literal"""
    e = InvalidPattern(None)
    exec('x = %r' % (e,))



# Generated at 2022-06-24 02:52:20.413903
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """Test method LazyRegex.__getstate__"""
    a = LazyRegex()
    class Dummy: pass
    b = Dummy()
    b.__state = a.__getstate__()
    # The private attribute "_regex_args" should not be saved
    assert "args" in b.__state
    assert "kwargs" in b.__state
    assert "regex_args" not in b.__state
    assert "regex_kwargs" not in b.__state


# Generated at 2022-06-24 02:52:21.235990
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import errors
    return doctest.DocTestSuite(errors)

# Generated at 2022-06-24 02:52:25.380497
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ must restore the same object we pickled"""
    pattern = LazyRegex("(a|b)*")
    state = pattern.__getstate__()
    pattern.__setstate__(state)
    assert pattern._real_regex is None, \
        "pattern._real_regex must be None after __setstate__"

# Generated at 2022-06-24 02:52:31.226291
# Unit test for method __getstate__ of class LazyRegex
def test_LazyRegex___getstate__():
    """LazyRegex.__getstate__ must return a dictionary"""
    lazy_one = LazyRegex()
    state = lazy_one.__getstate__()
    assert isinstance(state, dict)

    lazy_two = LazyRegex(("^\w+$", ))
    state = lazy_two.__getstate__()
    assert isinstance(state, dict)


# Generated at 2022-06-24 02:52:38.013722
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    error = InvalidPattern('test_message')
    # We expect a single line
    assert '\n' not in repr(error)
    # We expect the message
    assert 'test_message' in repr(error)
    # We expect the exception type
    assert 'InvalidPattern' in repr(error)
    # The message must be escaped
    error = InvalidPattern('"')
    assert '\\"' in repr(error)

# Generated at 2022-06-24 02:52:48.927693
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    from bzrlib import errors

    # Create a couple of objects
    ex1 = InvalidPattern('An error occurred')
    ex2 = errors.BzrError('An error occurred')

    # They are not equal to None or to a different instance
    assert not ex1 == None
    assert not ex2 == None
    assert NotImplemented == ex1.__eq__(None)
    assert NotImplemented == ex2.__eq__(None)
    assert not ex1 == ex2
    assert NotImplemented == ex1.__eq__(ex2)

    # But they are equal to themselves
    assert ex1 == ex1
    assert ex2 == ex2

    # Two InvalidPattern instances with the same attributes are equals
    ex3 = InvalidPattern('An error occurred')
    assert ex1 == ex3

# Generated at 2022-06-24 02:52:56.690383
# Unit test for method __eq__ of class InvalidPattern
def test_InvalidPattern___eq__():
    """Unit test for method __eq__ of class InvalidPattern"""
    # Create two different objects
    a = InvalidPattern("msg1")
    b = InvalidPattern("msg2")
    # Check that they are not equal
    assert a != b
    # Check that they are not equal with operator '=='
    assert not a == b
    # Create two different objects
    c = InvalidPattern("msg")
    d = InvalidPattern("msg")
    # Check that they are equal
    assert c == d
    # Check that they are equal with operator '!='
    assert not c != d

# Generated at 2022-06-24 02:52:59.259436
# Unit test for function lazy_compile
def test_lazy_compile():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

if __name__ == '__main__':
    test_lazy_compile()

# Generated at 2022-06-24 02:53:11.279477
# Unit test for method __repr__ of class InvalidPattern
def test_InvalidPattern___repr__():
    from bzrlib.tests import TestCase
    from bzrlib import (
        debug,
        errors,
        )

    # TODO(jelmer): Test with different locales.
    class TestInvalidPattern(TestCase):

        # __repr__ should return a str object
        def test___repr___returns_str(self):
            error = errors.InvalidPattern(
                "Invalid regex pattern: '(unclosed [ at position 1')")
            self.assertIsInstance(error.__repr__(), str)

        # __repr__ should return a str object containing the exception name
        def test___repr___returns_exception_name(self):
            error = errors.InvalidPattern(
                "Invalid regex pattern: '(unclosed [ at position 1')")