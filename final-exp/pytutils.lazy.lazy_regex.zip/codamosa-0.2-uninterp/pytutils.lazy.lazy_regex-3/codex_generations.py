

# Generated at 2022-06-18 04:16:38.927953
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    e.msg = 'test message'
    assert e.__unicode__() == gettext('Invalid pattern(s) found. %(msg)s') % {'msg': 'test message'}
    # Test with a format string and an error
    e = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    e.msg = 'test message'

# Generated at 2022-06-18 04:16:49.215858
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test for a preformatted message
    e = InvalidPattern('msg')
    e._preformatted_string = 'preformatted'
    assert e.__unicode__() == 'preformatted'
    # Test for a message without format string
    e = InvalidPattern('msg')
    assert e.__unicode__() == 'msg'
    # Test for a message with format string
    e = InvalidPattern('msg')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'msg'
    # Test for a message with format string and extra attributes
    e = InvalidPattern('msg')
    e._fmt = '%(msg)s %(extra)s'
    e.extra = 'extra'
    assert e.__

# Generated at 2022-06-18 04:16:56.459920
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that InvalidPattern.__str__() returns a str object.

    This is a regression test for bug #836983.
    """
    import sys
    if sys.version_info[0] == 2:
        # Python 2.x
        assert isinstance(InvalidPattern('foo').__str__(), str)
    else:
        # Python 3.x
        assert isinstance(InvalidPattern('foo').__str__(), bytes)

# Generated at 2022-06-18 04:17:05.856023
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    assert unicode(e) == u'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unicode(e) == u'format string'
    # Test with a format string and a gettext function
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unic

# Generated at 2022-06-18 04:17:08.681558
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    e = InvalidPattern('foo')
    assert isinstance(str(e), str)
    e = InvalidPattern(u'foo')
    assert isinstance(str(e), str)
    e = InvalidPattern(u'foo'.encode('utf8'))
    assert isinstance(str(e), str)


# Generated at 2022-06-18 04:17:15.924201
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str object"""
    from bzrlib.i18n import gettext
    # gettext should return a unicode object
    msg = gettext('Invalid pattern(s) found. %(msg)s')
    e = InvalidPattern(msg)
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    # gettext should return a unicode object
    msg = gettext('Invalid pattern(s) found. %(msg)s')
    e = InvalidPattern(msg)
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-18 04:17:21.954959
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test that InvalidPattern.__unicode__() returns a unicode object.

    This is a regression test for bug #73589.
    """
    msg = u"\u00e9"
    e = InvalidPattern(msg)
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError("InvalidPattern.__unicode__() did not return a "
                             "unicode object.")

# Generated at 2022-06-18 04:17:31.767865
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore the state of a LazyRegex object"""
    import pickle
    lazy_regex = LazyRegex(args=('^foo',), kwargs={'flags': re.IGNORECASE})
    state = lazy_regex.__getstate__()
    lazy_regex_restored = LazyRegex()
    lazy_regex_restored.__setstate__(state)
    assert lazy_regex_restored._regex_args == ('^foo',)
    assert lazy_regex_restored._regex_kwargs == {'flags': re.IGNORECASE}
    assert lazy_regex_restored._real_regex is None
    # check that pickle works
    pickle.dumps(lazy_regex)

# Generated at 2022-06-18 04:17:42.924677
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test that __unicode__ returns a unicode object
    e = InvalidPattern('test')
    assert isinstance(unicode(e), unicode)
    # Test that __unicode__ returns a unicode object even if the message
    # is a str object
    e = InvalidPattern('test')
    e._preformatted_string = 'test'
    assert isinstance(unicode(e), unicode)
    # Test that __unicode__ returns a unicode object even if the message
    # is a unicode object
    e = InvalidPattern('test')
    e._preformatted_string = u'test'
    assert isinstance(unicode(e), unicode)
    # Test that __unicode__ returns a unicode object even if the message
    # is a non-

# Generated at 2022-06-18 04:17:53.432953
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation
    from bzrlib.i18n import _set_gettext_fallback
    from bzrlib.i18n import _set_ugettext_fallback
    from bzrlib.i18n import _set_gettext_translation
    from bzrlib.i18n import _set_ugettext_translation
    from bzrlib.i18n import _set_gettext_output_charset

# Generated at 2022-06-18 04:18:00.752240
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    e = InvalidPattern('msg')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-18 04:18:08.546742
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it
    """
    # Create a LazyRegex object
    lazy_regex = LazyRegex(('^a',))
    # The regex hasn't been compiled yet
    assert lazy_regex._real_regex is None
    # Get the attribute 'match'
    match = lazy_regex.match
    # The regex has been compiled
    assert lazy_regex._real_regex is not None
    # The attribute 'match' is a function
    assert callable(match)
    # The attribute 'match' is the same as the attribute 'match' of the
    # proxied regex object
    assert match is lazy_regex._real_regex.match

# Generated at 2022-06-18 04:18:13.665348
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    from bzrlib.tests import TestCase
    class TestInvalidPattern(TestCase):
        def test_str(self):
            e = InvalidPattern('foo')
            self.assertIsInstance(str(e), str)
            self.assertIsInstance(unicode(e), unicode)
    TestInvalidPattern('test_str').run()

# Generated at 2022-06-18 04:18:16.552078
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    e = InvalidPattern('foo')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-18 04:18:25.216759
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    # Create a LazyRegex object
    lr = LazyRegex(('a',))
    # Check that the real regex is not created
    assert lr._real_regex is None
    # Check that the attribute is not found
    try:
        lr.search
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError not raised')
    # Check that the real regex is created
    assert lr._real_regex is not None
    # Check that the attribute is found
    lr.search


# Generated at 2022-06-18 04:18:31.725468
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str object"""
    # We need to use a preformatted string because we can't use
    # gettext in a test.
    e = InvalidPattern('preformatted string')
    e._preformatted_string = 'preformatted string'
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-18 04:18:38.772250
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation
    from bzrlib.i18n import ustr

    # Test with default encoding
    set_default_encoding('utf8')
    set_default_language('en')
    set_default_translation(None)
    e = InvalidPattern('message')
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == u'Invalid pattern(s) found. message'
    assert isinstance(e.__str__(), str)
    assert e.__

# Generated at 2022-06-18 04:18:46.243878
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_domain
    from bzrlib.i18n import _get_default_translation_domain
    from bzrlib.i18n import _get_default_language
    from bzrlib.i18n import _get_translation_domain
    from bzrlib.i18n import _get_language
    from bzrlib.i18n import _set_translation_domain
    from bzrlib.i18n import _set_language
    from bzrlib.i18n import _get_translation_domains

# Generated at 2022-06-18 04:18:55.310058
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_user_selected_languages
    from bzrlib.i18n import _set_user_selected_languages
    from bzrlib.i18n import _translations
    from bzrlib.i18n import _user_selected_languages
    from bzrlib.i18n import _user_selected_languages_set
    from bzrlib.i18n import _user_selected_languages_string

# Generated at 2022-06-18 04:19:03.727270
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('foo')
    e._preformatted_string = 'bar'
    assert e.__unicode__() == 'bar'
    # Test with a format string
    e = InvalidPattern('foo')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'foo'
    # Test with a format string and a gettext function
    e = InvalidPattern('foo')
    e._fmt = '%(msg)s'
    e._get_format_string = lambda: gettext('%(msg)s')
    assert e.__unicode__() == 'foo'

# Generated at 2022-06-18 04:19:17.169703
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('test message')
    e._preformatted_string = 'test message'
    assert e.__unicode__() == 'test message'
    # Test with a format string
    e = InvalidPattern('test message')
    e._fmt = 'test message'
    assert e.__unicode__() == 'test message'
    # Test with a format string and a dict
    e = InvalidPattern('test message')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'test message'
    # Test with a format string and a dict and an error
    e = InvalidPattern('test message')
    e._fmt = '%(msg)s'
    e.error

# Generated at 2022-06-18 04:19:20.209883
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.i18n import gettext
    gettext("")
    e = InvalidPattern("foo")
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-18 04:19:31.748012
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    e = InvalidPattern("test")
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == u"Invalid pattern(s) found. test"
    assert isinstance(e.__str__(), str)
    assert e.__str__() == "Invalid pattern(s) found. test"
    assert e.__repr__() == 'InvalidPattern(Invalid pattern(s) found. test)'
    assert e == InvalidPattern("test")
    assert e != InvalidPattern("test2")
    assert e != "test"
    assert e != 1

# Generated at 2022-06-18 04:19:37.421180
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    e = InvalidPattern("test")
    assert str(e) == "Invalid pattern(s) found. test"
    assert unicode(e) == u"Invalid pattern(s) found. test"
    assert repr(e) == "InvalidPattern(Invalid pattern(s) found. test)"

# Generated at 2022-06-18 04:19:43.043138
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_domain
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_current_translation_domain
    from bzrlib.i18n import _get_current_language
    from bzrlib.i18n import _get_current_encoding
    from bzrlib.i18n import _get_default_encoding
    from bzrlib.i18n import _get_default_language

# Generated at 2022-06-18 04:19:54.422557
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf-8')

# Generated at 2022-06-18 04:20:01.188543
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_console
    from bzrlib.i18n import ui
    from bzrlib.i18n import _get_encoding
    from bzrlib.i18n import _get_language
    from bzrlib.i18n import _get_timezone
    from bzrlib.i18n import _get_unicode_console
    from bzrlib.i18n import _set_encoding
   

# Generated at 2022-06-18 04:20:06.729949
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it
    """
    # Create a LazyRegex object
    lazy_regex = LazyRegex(('a',))
    # Check that the regex hasn't been compiled yet
    assert lazy_regex._real_regex is None
    # Get the attribute 'pattern' from the LazyRegex object
    pattern = lazy_regex.pattern
    # Check that the regex has been compiled
    assert lazy_regex._real_regex is not None
    # Check that the attribute 'pattern' is the same as the pattern
    # passed to the LazyRegex object
    assert pattern == 'a'


# Generated at 2022-06-18 04:20:15.862092
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str object"""
    # This test is needed because __str__ of InvalidPattern returns a str
    # object, but __str__ of the parent class Exception returns a unicode
    # object.
    #
    # This test is needed because the test suite of bzrlib uses
    # bzrlib.tests.TestCaseWithTransport which overrides the method
    # assertRaises to check that the exception raised is a subclass of
    # Exception. This method calls str() on the exception raised.
    #
    # If __str__ of InvalidPattern returns a unicode object, the test suite
    # will fail with the following error:
    #
    #   TypeError: catching classes that do not inherit from BaseException is
    #   not allowed
    #
    # This test is needed because the test suite of b

# Generated at 2022-06-18 04:20:23.940494
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex"""
    # Create a LazyRegex object
    lazy_regex = LazyRegex()
    # Get the state of the object
    state = lazy_regex.__getstate__()
    # Create a new LazyRegex object
    lazy_regex_2 = LazyRegex()
    # Restore the state of the new object
    lazy_regex_2.__setstate__(state)
    # Check that the state of the new object is the same as the original
    # object
    assert lazy_regex_2.__getstate__() == state

# Generated at 2022-06-18 04:20:33.105473
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    # Test that the method __getattr__ returns the expected attribute
    # when the attribute is present in the object
    pattern = LazyRegex(('a',))
    assert pattern.pattern == 'a'
    # Test that the method __getattr__ raises an AttributeError when
    # the attribute is not present in the object
    try:
        pattern.pattern_not_present
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError not raised')


# Generated at 2022-06-18 04:20:37.262662
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    import sys
    if sys.version_info[0] == 2:
        # In python2, __str__ must return a str object
        assert isinstance(InvalidPattern('msg').__str__(), str)
    else:
        # In python3, __str__ must return a str object
        assert isinstance(InvalidPattern('msg').__str__(), str)

# Generated at 2022-06-18 04:20:44.672330
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    # __str__ should return a str object
    e = InvalidPattern('foo')
    assert isinstance(str(e), str)
    # __str__ should return a str object even if the message is unicode
    e = InvalidPattern(u'foo')
    assert isinstance(str(e), str)
    # __str__ should return a str object even if the message is unicode
    # and contains non-ascii characters
    e = InvalidPattern(u'\u1234')
    assert isinstance(str(e), str)
    # __str__ should return a str object even if the message is unicode
    # and contains non-ascii characters and the default encoding is ascii
    import sys
    old_default_encoding = sys.getdefaultencoding()
    sys

# Generated at 2022-06-18 04:20:53.729863
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    assert unicode(e) == u'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unicode(e) == u'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = 'format string %(msg)s'
    assert str(e) == 'format string format string'

# Generated at 2022-06-18 04:21:05.278238
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    e.msg = 'message'
    assert str(e) == gettext('Invalid pattern(s) found. %(msg)s') % {'msg': 'message'}
    # Test with a format string and a non-ascii character
    e = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    e.msg = 'message\xe9'

# Generated at 2022-06-18 04:21:09.054488
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    e = InvalidPattern("test")
    assert str(e) == "Invalid pattern(s) found. test"
    assert unicode(e) == u"Invalid pattern(s) found. test"

# Generated at 2022-06-18 04:21:14.396972
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext(u'Invalid pattern(s) found. %(msg)s')
    msg = u'foo'
    e = InvalidPattern(msg)
    assert e.__unicode__() == u'Invalid pattern(s) found. foo'

# Generated at 2022-06-18 04:21:23.093767
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test for a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    # Test for a message with a format string
    e = InvalidPattern('%(msg)s')
    e.msg = 'formatted message'
    assert str(e) == 'formatted message'
    # Test for a message with a format string and a gettext function
    e = InvalidPattern('%(msg)s')
    e.msg = 'formatted message'
    e._get_format_string = lambda: gettext('%(msg)s')

# Generated at 2022-06-18 04:21:28.047329
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('foo')
    e._preformatted_string = 'bar'
    assert str(e) == 'bar'
    assert unicode(e) == u'bar'
    # Test with a format string
    e = InvalidPattern('foo')
    e._fmt = '%(msg)s'
    assert str(e) == 'foo'
    assert unicode(e) == u'foo'
    # Test with a format string and a gettext
    e = InvalidPattern('foo')
    e._fmt = '%(msg)s'
    gettext(u'%(msg)s')
    assert str(e) == 'foo'

# Generated at 2022-06-18 04:21:38.983153
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    # __unicode__ should return a unicode object
    e = InvalidPattern('foo')
    u = unicode(e)
    assert isinstance(u, unicode)
    # __unicode__ should return a unicode object even if the message is
    # encoded in utf8
    e = InvalidPattern('\xc3\xa9')
    u = unicode(e)
    assert isinstance(u, unicode)
    # __unicode__ should return a unicode object even if the message is
    # encoded in latin1
    e = InvalidPattern('\xe9')
    u = unicode(e)
    assert isinstance(u, unicode)
    # __unicode__ should return a unicode object even if the message is
    # encoded in latin1


# Generated at 2022-06-18 04:21:51.475855
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str object"""
    # We need to test that __str__ returns a str object.
    # This is because we have a test that checks that the exception
    # raised by re.compile is a str object.
    # We can't test that the result is a str object because we don't
    # know what the default encoding is.
    # So we test that it is not a unicode object.
    e = InvalidPattern('foo')
    assert not isinstance(e.__str__(), unicode)

# Generated at 2022-06-18 04:22:01.984590
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    e.a = 'a'
    e.b = 'b'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = 'format string %(a)s %(b)s'
    e.a = 'a'


# Generated at 2022-06-18 04:22:07.223181
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_console
    from bzrlib.i18n import ui
    from bzrlib.i18n import ui_factory
    from bzrlib.i18n import ui_factory_set_encoding
    from bzrlib.i18n import ui_factory_set_language
    from bzrlib.i18n import ui_factory_set_timezone

# Generated at 2022-06-18 04:22:13.304414
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    msg = "test message"
    e = InvalidPattern(msg)
    assert str(e) == "Invalid pattern(s) found. " + msg
    assert unicode(e) == u"Invalid pattern(s) found. " + msg

# Generated at 2022-06-18 04:22:21.560282
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test that __str__ returns a str object
    e = InvalidPattern('test')
    assert isinstance(str(e), str)
    # Test that __str__ returns a str object even if the message is unicode
    e = InvalidPattern(u'test')
    assert isinstance(str(e), str)
    # Test that __str__ returns a str object even if the message is unicode
    # and contains non-ascii characters
    e = InvalidPattern(u't\xe9st')
    assert isinstance(str(e), str)

# Generated at 2022-06-18 04:22:30.357644
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf-8')
    # Test with a preformatted message
    e = InvalidPattern('This is a preformatted message')
    e._preformatted_string = 'This is a preformatted message'
    assert str(e) == 'This is a preformatted message'
    assert unicode(e) == u'This is a preformatted message'
    # Test with a message that needs to be formatted
    e = InvalidPattern('This is a message that needs to be formatted')
    e._fmt = 'This is a message that needs to be formatted'

# Generated at 2022-06-18 04:22:40.831064
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == 'format string'
    # Test with a format string and arguments
    e = InvalidPattern('format string')
    e._fmt = 'format string %(arg1)s %(arg2)s'
    e.arg1 = 'arg1'
    e.arg2 = 'arg2'
    assert e.__unicode

# Generated at 2022-06-18 04:22:48.170517
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_domain
    from bzrlib.i18n import _get_default_translation_domain
    from bzrlib.i18n import _get_default_language
    from bzrlib.i18n import _get_translation_domains
    from bzrlib.i18n import _get_translations
    from bzrlib.i18n import _set_translations
    from bzrlib.i18n import _set_translation_domains
    from bzrlib.i18n import _set_default_language

# Generated at 2022-06-18 04:22:52.425261
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext('Invalid pattern(s) found. %(msg)s')
    e = InvalidPattern('msg')
    e.__unicode__()

# Generated at 2022-06-18 04:23:02.813236
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf-8')
    msg = gettext('Invalid pattern(s) found. %(msg)s')
    e = InvalidPattern('msg')
    assert e.__unicode__() == msg % {'msg': 'msg'}
    e = InvalidPattern(u'msg')
    assert e.__unicode__() == msg % {'msg': u'msg'}
    e = InvalidPattern(u'\u1234')
    assert e.__unicode__() == msg % {'msg': u'\u1234'}

# Generated at 2022-06-18 04:23:12.821098
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should return a str object"""
    # The message is a unicode object
    e = InvalidPattern(u'foo')
    assert isinstance(e.__str__(), str)
    # The message is a str object
    e = InvalidPattern('foo')
    assert isinstance(e.__str__(), str)
    # The message is a non-string object
    e = InvalidPattern(1)
    assert isinstance(e.__str__(), str)

# Generated at 2022-06-18 04:23:14.657707
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:23:24.206944
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern.

    This test is needed because the method __str__ of class InvalidPattern
    is not trivial.
    """
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('a preformatted message')
    e._preformatted_string = 'a preformatted message'
    assert str(e) == 'a preformatted message'
    assert unicode(e) == u'a preformatted message'
    # Test with a format string
    e = InvalidPattern('a format string')
    e._fmt = 'a format string'
    assert str(e) == 'a format string'
    assert unicode(e) == u'a format string'
    # Test with a format string and a message
    e = InvalidPattern

# Generated at 2022-06-18 04:23:35.628626
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern."""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_encoding
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_default_encoding
    from bzrlib.i18n import _get_default_language
    from bzrlib.i18n import _get_default_timezone
    from bzrlib.i18n import _get_unicode_encoding

# Generated at 2022-06-18 04:23:43.912619
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    import bzrlib.tests
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_unicode_encoding
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_language
    from bzrlib.i18n import set_user_unicode_encoding
    from bzrlib.i18n import ustr

    # Test that the method returns a unicode object
    # when the default encoding is 'ascii'
    set_default_encoding('ascii')


# Generated at 2022-06-18 04:23:54.096607
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    e = InvalidPattern("foo")
    assert str(e) == "Invalid pattern(s) found. foo"
    assert unicode(e) == u"Invalid pattern(s) found. foo"
    assert repr(e) == "InvalidPattern('Invalid pattern(s) found. foo')"
    e = InvalidPattern("foo")
    e._preformatted_string = "bar"
    assert str(e) == "bar"
    assert unicode(e) == u"bar"
    assert repr(e) == "InvalidPattern('bar')"
    e = InvalidPattern("foo")
    e._fmt = "bar"

# Generated at 2022-06-18 04:23:56.622673
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:23:59.985119
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    e = InvalidPattern('msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:24:09.745463
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.i18n import gettext
    gettext('')
    e = InvalidPattern('msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'Invalid pattern(s) found. msg'
    e = InvalidPattern('msg')
    e._fmt = '%(msg)s'
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'msg'
    e = InvalidPattern('msg')
    e._fmt = '%(msg)s'
    e._preformatted_string = u'preformatted'
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:24:16.629574
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    assert unicode(e) == u'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unicode(e) == u'format string'
    # Test with a format string and a gettext function
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unic

# Generated at 2022-06-18 04:24:22.969250
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:24:31.359043
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern

    This test is needed because the method __str__ of class InvalidPattern
    is overridden.
    """
    msg = 'Invalid pattern(s) found. %(msg)s'
    e = InvalidPattern('msg')
    assert str(e) == msg % {'msg': 'msg'}
    assert unicode(e) == msg % {'msg': 'msg'}
    assert repr(e) == 'InvalidPattern(%s)' % msg % {'msg': 'msg'}

# Generated at 2022-06-18 04:24:39.343017
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string')
   

# Generated at 2022-06-18 04:24:50.437265
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf8')
    e = InvalidPattern('test')
    assert e.__unicode__() == gettext('Invalid pattern(s) found. test')
    e = InvalidPattern('test')
    e._preformatted_string = 'test'
    assert e.__unicode__() == 'test'
    e = InvalidPattern('test')
    e._preformatted_string = u'test'
    assert e.__unicode__() == u'test'
    e = InvalidPattern('test')
    e._preformatted_string = '\xc3\xa9'
    assert e.__unicode

# Generated at 2022-06-18 04:25:00.816633
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == gettext('format string')
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == gettext('format string')
    # Test with a format string and a dict

# Generated at 2022-06-18 04:25:11.140127
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string and a dict')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'format string and a dict'
    # Test with a format string and a dict with a unicode value

# Generated at 2022-06-18 04:25:21.417686
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_console
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_language
    from bzrlib.i18n import set_user_timezone
    from bzrlib.i18n import set_user_unicode_console
    from bzrlib.i18n import ui

    # Test with default values
    set_default_encoding

# Generated at 2022-06-18 04:25:23.836526
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    e = InvalidPattern('msg')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-18 04:25:33.945989
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test the method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import ugettext_lazy_noop
    from bzrlib.i18n import ugettext_lazy_noop_factory
    from bzrlib.i18n import ugettext_lazy_factory
    from bzrlib.i18n import ugettext_factory
    from bzrlib.i18n import ugettext_no

# Generated at 2022-06-18 04:25:36.347754
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    e = InvalidPattern('foo')
    assert isinstance(str(e), str)


# Generated at 2022-06-18 04:25:51.317896
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern."""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    msg = "Invalid pattern(s) found. %(msg)s"
    e = InvalidPattern(msg)
    e._preformatted_string = msg
    assert str(e) == msg
    # Test with a format string
    msg = "Invalid pattern(s) found. %(msg)s"
    e = InvalidPattern(msg)
    e._fmt = msg
    assert str(e) == gettext(msg) % {'msg': msg}
    # Test with a format string and a unicode message
    msg = u"Invalid pattern(s) found. %(msg)s"
    e = InvalidPattern(msg)
    e._fmt = msg

# Generated at 2022-06-18 04:26:02.397262
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test method __getattr__ of class LazyRegex"""
    import re
    from bzrlib.tests import TestCase

    class TestLazyRegex(TestCase):

        def test_getattr(self):
            """Test method __getattr__ of class LazyRegex"""
            # Test that the method __getattr__ of class LazyRegex returns
            # the expected value.
            #
            # The method __getattr__ of class LazyRegex returns a member
            # from the proxied regex object.
            # If the regex hasn't been compiled yet, compile it.
            #
            # The method __getattr__ of class LazyRegex is called when
            # an attribute lookup has not found the attribute in the usual
            # places (i.e. it is not an instance attribute nor is it found
            # in the

# Generated at 2022-06-18 04:26:05.612396
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    e = InvalidPattern('foo')
    assert isinstance(unicode(e), unicode)


# Generated at 2022-06-18 04:26:13.297729
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that the LazyRegex.__getattr__ method works as expected.

    The method should compile the regex and return the attribute if it
    exists.
    """
    lr = LazyRegex(('a',))
    assert lr.pattern == 'a'
    assert lr.match('a')
    assert not lr.match('b')
    assert lr._real_regex is not None
    assert lr._regex_args == ('a',)
    assert lr._regex_kwargs == {}



# Generated at 2022-06-18 04:26:20.226372
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import ugettext_translate
    from bzrlib.i18n import ugettext_unicode
    from bzrlib.i18n import ugettext_unicode_lazy

# Generated at 2022-06-18 04:26:24.344079
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a dict with more than one entry
    e = InvalidPattern('format string')