

# Generated at 2022-06-18 04:16:37.787128
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test with a unicode message
    msg = u'\xe9'
    exc = InvalidPattern(msg)
    assert isinstance(exc.__str__(), str)
    assert isinstance(exc.__unicode__(), unicode)
    assert exc.__str__() == msg.encode('utf8')
    assert exc.__unicode__() == msg
    # Test with a str message
    msg = '\xe9'
    exc = InvalidPattern(msg)
    assert isinstance(exc.__str__(), str)
    assert isinstance(exc.__unicode__(), unicode)
    assert exc.__str__() == msg
    assert exc.__unicode__() == msg.decode('utf8')

# Generated at 2022-06-18 04:16:42.788548
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return a member from the proxied regex object.

    If the regex hasn't been compiled yet, compile it
    """
    # Test that the regex is compiled when an attribute is accessed
    lr = LazyRegex(('a',))
    lr.match('a')
    # Test that the regex is compiled when an attribute is accessed
    lr = LazyRegex(('a',))
    lr.match('a')
    # Test that the regex is compiled when an attribute is accessed
    lr = LazyRegex(('a',))
    lr.match('a')
    # Test that the regex is compiled when an attribute is accessed
    lr = LazyRegex(('a',))
    lr.match('a')
    # Test that the regex is compiled when an attribute is accessed
    lr

# Generated at 2022-06-18 04:16:50.280801
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import _get_lazy_ugettext
    from bzrlib.i18n import _get_lazy_ugettext_noop
    from bzrlib.i18n import _get_lazy_ugettext_lazy
    from bzrlib.i18n import _get_lazy_ugettext_lazy_noop

# Generated at 2022-06-18 04:17:01.391257
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    assert unicode(e) == u'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unicode(e) == u'format string'
    # Test with a format string and a gettext function
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    assert unic

# Generated at 2022-06-18 04:17:10.727886
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_method
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import ugettext_translate
    from bzrlib.i18n import ugettext_unicode
    from bzrlib.i18n import ugettext_utf8
    from bzrlib.i18n import u

# Generated at 2022-06-18 04:17:17.757460
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex"""
    # Create a LazyRegex object
    lazy_regex = LazyRegex()
    # Pickle and unpickle the object
    import pickle
    pickled_lazy_regex = pickle.dumps(lazy_regex)
    unpickled_lazy_regex = pickle.loads(pickled_lazy_regex)
    # Check that the object has been correctly unpickled
    assert unpickled_lazy_regex._regex_args == ()
    assert unpickled_lazy_regex._regex_kwargs == {}
    assert unpickled_lazy_regex._real_regex is None

# Generated at 2022-06-18 04:17:28.443837
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return the attribute from the real regex object.

    If the regex hasn't been compiled yet, compile it
    """
    # Create a LazyRegex object
    lazy_regex = LazyRegex(('^a',))
    # Check that the attribute 'pattern' is not yet defined
    try:
        lazy_regex.pattern
    except AttributeError:
        pass
    else:
        raise AssertionError("Attribute 'pattern' should not be defined")
    # Check that the attribute 'pattern' is defined after calling __getattr__
    lazy_regex.__getattr__('pattern')
    if lazy_regex.pattern != '^a':
        raise AssertionError("Attribute 'pattern' should be '^a'")

# Generated at 2022-06-18 04:17:36.233538
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test that the method __str__ of class InvalidPattern returns a str
    # object.
    #
    # This test is needed because the method __str__ of class InvalidPattern
    # uses the method _format() which returns a unicode object.
    #
    # The method _format() is used by the method __str__ of class
    # InvalidPattern.
    #
    # The method _format() is used by the method __unicode__ of class
    # InvalidPattern.
    #
    # The method __unicode__ of class InvalidPattern returns a unicode object.
    #
    # The method __unicode__ of class InvalidPattern uses the method _format()
    # which returns a unicode object.
    #
    # The method _format() is used by the method __str__ of

# Generated at 2022-06-18 04:17:45.612666
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('This is a preformatted message')
    e._preformatted_string = 'This is a preformatted message'
    assert str(e) == 'This is a preformatted message'
    assert unicode(e) == u'This is a preformatted message'
    # Test with a format string
    e = InvalidPattern('This is a format string')
    e._fmt = 'This is a format string'
    assert str(e) == 'This is a format string'
    assert unicode(e) == u'This is a format string'
    # Test with a format string and a dict
    e = InvalidPattern('This is a format string')

# Generated at 2022-06-18 04:17:50.489882
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set the state of the object"""
    regex = LazyRegex()
    regex.__setstate__({'args': (r'\d+',), 'kwargs': {}})
    assert regex._regex_args == (r'\d+',)
    assert regex._regex_kwargs == {}

# Generated at 2022-06-18 04:18:04.027569
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_console
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_language
    from bzrlib.i18n import set_user_timezone
    from bzrlib.i18n import set_user_unicode_console
    from bzrlib.i18n import set_user_verbose

# Generated at 2022-06-18 04:18:14.383783
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf-8')
    msg = gettext('Invalid pattern(s) found. %(msg)s')
    ip = InvalidPattern('test')
    assert str(ip) == 'Invalid pattern(s) found. test'
    ip = InvalidPattern(u'\u00e9')
    assert str(ip) == 'Invalid pattern(s) found. \xc3\xa9'
    ip = InvalidPattern(u'\u00e9')
    assert unicode(ip) == u'Invalid pattern(s) found. \xe9'

# Generated at 2022-06-18 04:18:16.464706
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-18 04:18:18.706495
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    e = InvalidPattern('msg')
    assert isinstance(str(e), str)


# Generated at 2022-06-18 04:18:28.507765
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    set_user_selected_languages(['fr'])

# Generated at 2022-06-18 04:18:39.106352
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_default_encoding
    from bzrlib.i18n import _get_default_language
    from bzrlib.i18n import _get_default_translator
    from bzrlib.i18n import _set_default_encoding
    from bzrlib.i18n import _set_default_language
    from bzrlib.i18n import _set_default_translator

# Generated at 2022-06-18 04:18:46.537386
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_domain
    from bzrlib.i18n import set_default_translation
    from bzrlib.i18n import _get_translation
    from bzrlib.i18n import _get_translation_from_domain
    from bzrlib.i18n import _get_translation_from_domain_and_language
    from bzrlib.i18n import _get_translation_from_language
    from bzrlib.i18n import _get_translation_from_module

# Generated at 2022-06-18 04:18:56.772749
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    set_user_selected_languages(['fr'])
    e = InvalidPattern('msg')
    e._fmt = 'Invalid pattern(s) found. %(msg)s'
    assert e.__str__() == 'Invalid pattern(s) found. msg'
    set_user_selected_languages(['en'])
    assert e.__str__() == 'Invalid pattern(s) found. msg'
    set_user_selected_languages(['fr'])
    e._fmt = 'Invalid pattern(s) found. %(msg)s'

# Generated at 2022-06-18 04:19:02.806575
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    set_user_selected_languages(['fr'])
    try:
        e = InvalidPattern('msg')
        e._fmt = 'Invalid pattern(s) found. %(msg)s'
        e.msg = 'msg'
        assert e.__unicode__() == gettext('Invalid pattern(s) found. msg')
    finally:
        set_user_selected_languages(None)

# Generated at 2022-06-18 04:19:12.510669
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import setup_default_encoding
    from bzrlib.i18n import setup_gettext
    from bzrlib.i18n import setup_logging
    from bzrlib.i18n import setup_timezone
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_encoding
    from bzrlib.i18n import _get_language

# Generated at 2022-06-18 04:19:30.487781
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a message
    e = InvalidPattern('format string')
    e._fmt = '%(msg)s'
    assert e.__unicode__() == 'format string'
    # Test with a format string and a message and some other attributes
    e = InvalidPattern('format string')

# Generated at 2022-06-18 04:19:40.079971
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext(u"Invalid pattern(s) found. %(msg)s")
    gettext(u"Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r")
    gettext(u"Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r")
    gettext(u"Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r")
    gettext(u"Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r")
    gettext(u"Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r")

# Generated at 2022-06-18 04:19:49.026961
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern.

    This test is needed because the method __str__ of class InvalidPattern
    is overridden.
    """
    from bzrlib.tests import TestCase
    class TestInvalidPattern(TestCase):
        def test___str__(self):
            """Test method __str__ of class InvalidPattern."""
            # Test that __str__ returns a str object
            self.assertIsInstance(str(InvalidPattern('test')), str)
            # Test that __str__ returns a unicode object
            self.assertIsInstance(unicode(InvalidPattern('test')), unicode)
    TestInvalidPattern('test___str__').run()

# Generated at 2022-06-18 04:19:59.090600
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    import bzrlib.tests
    import bzrlib.tests.test_i18n
    import bzrlib.tests.test_i18n_support

    # Test that the message is correctly formatted
    # when the exception is raised
    try:
        raise InvalidPattern('test')
    except InvalidPattern as e:
        assert str(e) == 'Invalid pattern(s) found. test'

    # Test that the message is correctly formatted
    # when the exception is created
    e = InvalidPattern('test')
    assert str(e) == 'Invalid pattern(s) found. test'

    # Test that the message is correctly formatted
    # when the exception is created and the _fmt attribute
    # is set
   

# Generated at 2022-06-18 04:20:08.699720
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a message that needs to be translated
    e = InvalidPattern('message to translate')
    e._fmt = 'message to translate'
    assert e.__unicode__() == gettext('message to translate')
    # Test with a message that needs to be translated and contains a %s
    e = InvalidPattern('message to translate with %s')
    e._fmt = 'message to translate with %s'
    e.msg = 'a message'
    assert e.__unicode

# Generated at 2022-06-18 04:20:16.678488
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == gettext('format string')
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = 'format string %(msg)s'
    e.msg = 'message'
    assert e.__unicode__() == gettext('format string message')
    # Test with a format

# Generated at 2022-06-18 04:20:26.857481
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    # Test for a preformatted message
    e = InvalidPattern(u'This is a preformatted message')
    e._preformatted_string = u'This is a preformatted message'
    assert str(e) == 'This is a preformatted message'
    assert unicode(e) == u'This is a preformatted message'
    # Test for a message with a format string
    e = InvalidPattern(u'This is a message with a format string')
    e._fmt = u'This is a message with a format string'
    assert str(e) == 'This is a message with a format string'
    assert unicode(e) == u'This is a message with a format string'
    # Test for a message with a format string and a dict

# Generated at 2022-06-18 04:20:36.419583
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_translator
    from bzrlib.i18n import _set_translator
    from bzrlib.i18n import _translator
    from bzrlib.i18n import _translators
    from bzrlib.i18n import _unset_translator

    # setup
    set_default_encoding('UTF-8')
    set_default_

# Generated at 2022-06-18 04:20:44.128158
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_default_encoding
    from bzrlib.i18n import _get_default_language
    from bzrlib.i18n import _set_gettext_default_domain
    from bzrlib.i18n import _set_gettext_output_charset
    from bzrlib.i18n import _set_gettext_translation_domain
    from bzrlib.i18n import _set_gettext_translation_output_

# Generated at 2022-06-18 04:20:47.201502
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    e = InvalidPattern('foo')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)


# Generated at 2022-06-18 04:20:54.528643
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:21:00.868800
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_domain
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import _get_translation_domain
    from bzrlib.i18n import _set_translation_domain
    from bzrlib.i18n import _translations

    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = ugettext_lazy('preformatted message')
    assert e.__unicode

# Generated at 2022-06-18 04:21:04.206025
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    e = InvalidPattern('msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:21:11.076194
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.i18n import gettext
    gettext('foo')
    e = InvalidPattern('foo')
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(unicode(e), unicode)
    assert isinstance(e.__str__(), str)
    assert isinstance(str(e), str)
    assert isinstance(repr(e), str)
    assert isinstance(e.__repr__(), str)

# Generated at 2022-06-18 04:21:13.776530
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext('Invalid pattern(s) found. %(msg)s')
    msg = 'foo'
    e = InvalidPattern(msg)
    assert e.__unicode__() == u'Invalid pattern(s) found. foo'

# Generated at 2022-06-18 04:21:16.543685
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object"""
    e = InvalidPattern('foo')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-18 04:21:24.409232
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_translator
    from bzrlib.i18n import _set_translator
    from bzrlib.i18n import _translator

    # Test with default encoding
    set_default_encoding('UTF-8')
    set_default_language('en')
    set_default_translation(None)
    _set_translator(None)
    # Test with a non

# Generated at 2022-06-18 04:21:32.446530
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_output
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_timezone
    from bzrlib.i18n import ui
    from bzrlib.i18n import ui_factory
    from bzrlib.i18n import ui_factory_set_encoding

# Generated at 2022-06-18 04:21:43.771802
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    assert unicode(e) == u'preformatted message'
    # Test with a message from _fmt
    e = InvalidPattern('message from _fmt')
    e._fmt = 'message from _fmt'
    assert str(e) == 'message from _fmt'
    assert unicode(e) == u'message from _fmt'
    # Test with a message from _fmt and a gettext translation
    e = InvalidPattern('message from _fmt with gettext')
    e

# Generated at 2022-06-18 04:21:53.872438
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation

    # Test with default encoding
    set_default_encoding('UTF-8')
    set_default_language('en_US')
    set_default_translation(None)
    e = InvalidPattern('Invalid pattern(s) found. %(msg)s')
    e.msg = 'foo'
    assert e.__unicode__() == u'Invalid pattern(s) found. foo'

    # Test with default encoding
    set_default_encoding('UTF-8')
    set_default_language

# Generated at 2022-06-18 04:22:04.411359
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import ugettext_lazy_noop
    from bzrlib.i18n import ugettext_lazy_noop_translate
    from bzrlib.i18n import ugettext_lazy_translate
    from bzrlib.i18n import ugettext_translate
    from bzrlib.i18n import _gettext_lazy

# Generated at 2022-06-18 04:22:15.701900
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    import bzrlib.tests
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_selected_languages
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import ugettext_noop_lazy
    from bzrlib.i18n import ugettext_translate
    from bzrlib.i18n import ugettext_translate_lazy
    from bzrlib.i18n import ugettext_translate_noop

# Generated at 2022-06-18 04:22:25.827091
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == 'format string'
    # Test with a format string and a dict
    e = InvalidPattern('format string and a dict')
    e._fmt = 'format string %(msg)s'
    e.msg = 'and a dict'
    assert str(e) == 'format string and a dict'

# Generated at 2022-06-18 04:22:36.751782
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_display
    from bzrlib.i18n import ustr

    # Test that the method __unicode__ of class InvalidPattern returns a
    # unicode object.
    set_default_encoding('utf-8')
    set_default_language('en_US')
    set_default_translation_display('bzr')
    e = InvalidPattern('msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

    # Test that the method __unicode

# Generated at 2022-06-18 04:22:39.569546
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test that InvalidPattern.__unicode__() returns a unicode object."""
    e = InvalidPattern('foo')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-18 04:22:41.152796
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    e = InvalidPattern('foo')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'foo'


# Generated at 2022-06-18 04:22:48.334535
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert isinstance(e.__unicode__(), unicode)
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert isinstance(e.__unicode__(), unicode)
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = '%(msg)s'
    assert isinstance(e.__unicode__(), unicode)
    # Test with a format string, a dict and a gettext object
    e = InvalidPattern

# Generated at 2022-06-18 04:23:00.085592
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf-8')
    e = InvalidPattern('test')
    assert e.__unicode__() == gettext('test')
    e = InvalidPattern(u'test')
    assert e.__unicode__() == gettext(u'test')
    e = InvalidPattern(u'\u00e9')
    assert e.__unicode__() == gettext(u'\u00e9')
    e = InvalidPattern(u'\u00e9'.encode('utf-8'))
    assert e.__unicode__() == gettext(u'\u00e9')
    e = Invalid

# Generated at 2022-06-18 04:23:04.392279
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    e = InvalidPattern('test')
    assert isinstance(str(e), str)


# Generated at 2022-06-18 04:23:09.841754
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert str(e) == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert str(e) == gettext('format string')
    # Test with a format string and a parameter
    e = InvalidPattern('format string')
    e._fmt = 'format string %(msg)s'
    assert str(e) == gettext('format string format string')
    # Test with a format string and a parameter
    e = InvalidPattern('format string')
    e._

# Generated at 2022-06-18 04:23:16.505487
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:23:20.850450
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    msg = "test"
    e = InvalidPattern(msg)
    assert str(e) == "Invalid pattern(s) found. test"

# Generated at 2022-06-18 04:23:27.775582
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_domain
    from bzrlib.i18n import ustr

    # Set the default language to 'en'
    set_default_language('en')
    # Set the default translation domain to 'bzr'
    set_default_translation_domain('bzr')

    # Create an instance of InvalidPattern
    invalid_pattern = InvalidPattern('test')

    # Check that the method __unicode__ returns a unicode object
    result = invalid_pattern.__unicode__()
    assert isinstance(result, unicode)

    # Check that the method __unicode__ returns the

# Generated at 2022-06-18 04:23:33.178972
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str object"""
    from bzrlib.i18n import gettext
    gettext("Invalid pattern(s) found. %(msg)s")
    msg = "invalid pattern"
    e = InvalidPattern(msg)
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-18 04:23:42.030524
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('This is a preformatted message')
    e._preformatted_string = 'This is a preformatted message'
    assert e.__unicode__() == 'This is a preformatted message'
    # Test with a format string
    e = InvalidPattern('This is a format string')
    e._fmt = 'This is a format string'
    assert e.__unicode__() == 'This is a format string'
    # Test with a format string with a parameter
    e = InvalidPattern('This is a format string with a parameter')
    e._fmt = 'This is a format string with a parameter: %(msg)s'

# Generated at 2022-06-18 04:23:45.570688
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    e = InvalidPattern('foo')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:23:55.121727
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test that the message is correctly formatted
    # and that the message is correctly translated
    # We test

# Generated at 2022-06-18 04:24:05.974064
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object."""
    # This test is needed because the method __unicode__ of class
    # InvalidPattern is overriden.
    # The method __unicode__ of class InvalidPattern should return a unicode
    # object.
    # The method __unicode__ of class InvalidPattern is overriden to return a
    # unicode object.
    # The method __unicode__ of class InvalidPattern is overriden to return a
    # unicode object.
    # The method __unicode__ of class InvalidPattern is overriden to return a
    # unicode object.
    # The method __unicode__ of class InvalidPattern is overriden to return a
    # unicode object.
    # The method __unicode__ of class InvalidPattern is overriden to return a
    # unicode object.


# Generated at 2022-06-18 04:24:13.901782
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import ugettext

    # Test that __str__ returns a str object
    msg = 'Invalid pattern(s) found. %(msg)s'
    e = InvalidPattern(msg)
    s = str(e)
    assert isinstance(s, str)

    # Test that __str__ returns a str object when the message is unicode
    msg = u'Invalid pattern(s) found. %(msg)s'
    e = InvalidPattern(msg)
    s = str(e)
    assert isinstance(s, str)

    # Test that __str__ returns a str object when the message is unicode
    # and the format string is translated

# Generated at 2022-06-18 04:24:25.200562
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib import _i18n
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_unicode_encoding
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_default_encoding
    from bzrlib.i18n import _get_unicode_encoding
    from bzrlib.i18n import _set_gettext_translation
    from bzrlib.i18n import _set_gettext_fallback
    from bzrlib.i18n import _set

# Generated at 2022-06-18 04:24:39.205505
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('test')
    e._preformatted_string = 'test'
    assert e.__unicode__() == 'test'
    # Test with a format string
    e = InvalidPattern('test')
    e._fmt = 'test %(msg)s'
    assert e.__unicode__() == 'test test'
    # Test with a format string and a non-ascii character
    e = InvalidPattern('test')
    e._fmt = 'test %(msg)s'
    e.msg = u'\xe9'
    assert e.__unicode__() == u'test \xe9'
    # Test with a format string and a non-ascii character

# Generated at 2022-06-18 04:24:50.310494
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object"""
    from bzrlib.i18n import gettext
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert isinstance(e.__unicode__(), unicode)
        assert isinstance(unicode(e), unicode)
        assert isinstance(gettext(unicode(e)), unicode)
        assert isinstance(str(e), str)
        assert isinstance(e.__str__(), str)
        assert isinstance(e.__repr__(), str)
        assert isinstance(repr(e), str)
    try:
        raise InvalidPattern(u'foo')
    except InvalidPattern as e:
        assert isinstance(e.__unicode__(), unicode)

# Generated at 2022-06-18 04:25:00.779526
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_encoding
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_language
    from bzrlib.i18n import set_user_timezone
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_encoding
    from bzrlib.i18n import _get_language

# Generated at 2022-06-18 04:25:11.073039
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == gettext('format string')
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = 'format string %(msg)s'
    e.msg = 'message'
    assert e.__unicode__() == gettext('format string message')
    # Test with a format

# Generated at 2022-06-18 04:25:21.381409
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_timezone
    from bzrlib.i18n import set_unicode_encoding
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_timezone
    from bzrlib.i18n import ustr
    from bzrlib.i18n import _get_user_encoding
    from bzrlib.i18n import _get_user_timezone
    from bzrlib.i18n import _

# Generated at 2022-06-18 04:25:28.528905
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    set_default_encoding('utf-8')
    msg = gettext('Invalid pattern(s) found. %(msg)s')
    e = InvalidPattern('test')
    assert str(e) == 'Invalid pattern(s) found. test'
    assert unicode(e) == u'Invalid pattern(s) found. test'
    e = InvalidPattern(u'\u00e9')
    assert str(e) == 'Invalid pattern(s) found. \xc3\xa9'
    assert unicode(e) == u'Invalid pattern(s) found. \xe9'
    e = InvalidPattern(u'\u00e9')

# Generated at 2022-06-18 04:25:38.874100
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_option
    from bzrlib.i18n import set_user_option_ascii
    from bzrlib.i18n import set_user_option_unicode
    from bzrlib.i18n import set_user_option_utf8
    from bzrlib.i18n import set_user_option_utf8_with_bom
    from bzrlib.i18n import set_user_option_utf8_with_bom_and_crlf
    from bzrlib.i18n import set_user_option_utf8_with_crlf
    from bzrlib.i18n import set_

# Generated at 2022-06-18 04:25:45.262398
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_unicode_mode
    from bzrlib.i18n import set_user_encoding
    from bzrlib.i18n import set_user_selected_languages
    from bzrlib.i18n import set_user_selected_languages_from_env
    from bzrlib.i18n import set_user_selected_languages_from_string
    from bzrlib.i18n import set_user_selected_languages_from_config
    from bzrlib.i18n import set_user_selected_languages_from_config_file


# Generated at 2022-06-18 04:25:53.450825
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # This is a test for bug #816061.
    # The problem was that InvalidPattern.__unicode__() was not
    # returning a unicode object.
    # The problem was that InvalidPattern.__unicode__() was calling
    # InvalidPattern._format() which was returning a str object
    # instead of a unicode object.
    # The problem was that InvalidPattern._format() was calling
    # InvalidPattern._get_format_string() which was returning a str
    # object instead of a unicode object.
    # The problem was that InvalidPattern._get_format_string() was
    # calling gettext() which was returning a str object instead of
    # a unicode object.
    # The problem was that gettext() was calling
    # bzrlib.i18

# Generated at 2022-06-18 04:26:04.444149
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    # Test with a preformatted message
    e = InvalidPattern('preformatted message')
    e._preformatted_string = 'preformatted message'
    assert e.__unicode__() == 'preformatted message'
    # Test with a format string
    e = InvalidPattern('format string')
    e._fmt = 'format string'
    assert e.__unicode__() == gettext('format string')
    # Test with a format string and a dict
    e = InvalidPattern('format string')
    e._fmt = 'format string %(msg)s'
    e.msg = 'message'
    assert e.__unicode__() == gettext('format string message')
    # Test with a format

# Generated at 2022-06-18 04:26:18.179698
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    # Test with a preformatted message
    e = InvalidPattern('foo')
    e._preformatted_string = 'bar'
    assert str(e) == 'bar'
    assert unicode(e) == u'bar'
    # Test with a format string
    e = InvalidPattern('foo')
    e._fmt = '%(msg)s'
    assert str(e) == 'foo'
    assert unicode(e) == u'foo'
    # Test with a format string and a preformatted message
    e = InvalidPattern('foo')
    e._fmt = '%(msg)s'
    e._preformatted_string = 'bar'
    assert str(e) == 'bar'
    assert unicode(e) == u'bar'
   

# Generated at 2022-06-18 04:26:28.592986
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_default_encoding
    from bzrlib.i18n import set_default_language
    from bzrlib.i18n import set_default_translation_method
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import ugettext_lazy
    from bzrlib.i18n import ugettext_noop
    from bzrlib.i18n import _get_default_encoding
    from bzrlib.i18n import _get_default_language
    from bzrlib.i18n import _get_default_translation_method