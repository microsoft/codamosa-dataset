

# Generated at 2022-06-12 07:44:07.405332
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern

    InvalidPattern has some special handling for the __str__ and __unicode__
    methods, as these are the ones that will normally be called when formatting
    the message.
    """
    msg = InvalidPattern('my message')
    # Test the case that the _fmt field is set
    msg._fmt = '%(msg)s'
    assert str(msg) == 'my message'
    assert unicode(msg) == u'my message'
    # Test the case that the _fmt field is not set
    del msg._fmt
    assert str(msg) == 'Unprintable exception InvalidPattern: dict={\'msg\': ' \
                  '\'my message\'}, fmt=None, error=None'

# Generated at 2022-06-12 07:44:11.692788
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__()

    The method __unicode__ should return a unicode string.
    """
    e = InvalidPattern('foo')
    from bzrlib.tests import TestCase
    TestCase.assertIsInstance(e.__unicode__(), unicode)



# Generated at 2022-06-12 07:44:19.887813
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test that the method __getattr__ of LazyRegex actually works.

    The best way to test the method is to use it, so that's what we do.
    """
    if not getattr(re, 'finditer', False):
        raise TestNotApplicable(
            "The method __getattr__ of LazyRegex is not needed")
    iter = re.finditer('ab*', 'abracadabra')
    for match in iter:
        match.group(0)

# Generated at 2022-06-12 07:44:30.380707
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import _i18n
    from bzrlib.tests import TestCase

    # Test proper decoding
    _i18n.setup_i18n()
    e = InvalidPattern('a')
    default_encoding = _i18n.default_encoding()
    try:
        e.msg = 'abcdefgh'
        e_str = str(e)
        e_unicode = unicode(e)
        e_str_decoded = e_str.decode(default_encoding)
        self.assertEqualDiff(e_unicode, e_str_decoded)
    finally:
        _i18n.reset_i18n()

    # Test proper formatting
    e = InvalidPattern(u'\N{CYRILLIC CAPITAL LETTER A}')

# Generated at 2022-06-12 07:44:41.240369
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.osutils import get_user_encoding
    # The user encoding is used to encode the string
    from bzrlib import (
        _i18n_pyx as _i18n,
        )
    _i18n._setup_i18n()
    text = u'Custom message'
    exc = InvalidPattern(text)
    expected = exc.__str__().decode(get_user_encoding())
    # Adding a newline because the code format the message with a newline
    # and that's why unicode(exc) != exc.__unicode__()
    if not expected.endswith(u'\n'):
        expected = expected + u'\n'
    assert unicode(exc) == expected, "invalid message format"

# Generated at 2022-06-12 07:44:48.229773
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern must return a text.

    With the the method __str__, can generate a text message with
    information about the exception.
    """
    from bzrlib.i18n import gettext
    # With a unicode object
    error = InvalidPattern('iso-8859-1')
    output = error.__str__()
    # With a unicode object
    error = InvalidPattern(u'iso-8859-1')
    output = error.__str__()
    # With a str object
    error = InvalidPattern('iso-8859-1')
    output = error.__str__()
    # With unicode and gettext
    error = InvalidPattern(gettext(u'iso-8859-1'))
    output = error.__str__()

# Generated at 2022-06-12 07:44:59.740041
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.tests import TestCase

    class TestInvalidPattern(TestCase):

        def test___unicode__(self):
            self.assertEqual(u'',
                             invalid_pattern.InvalidPattern(u'').__unicode__())
            self.assertEqual(u'foo',
                             invalid_pattern.InvalidPattern(u'foo').__unicode__())
            self.assertEqual(u'foo\xb1',
                             invalid_pattern.InvalidPattern(u'foo\xb1').__unicode__())
            self.assertEqual(u'foo\xb1bar',
                             invalid_pattern.InvalidPattern(u'foo\xb1bar').__unicode__())

    import sys; sys.modules[__name__].__name__ = '__main__'

# Generated at 2022-06-12 07:45:08.603445
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the method __unicode__ of the class InvalidPattern.

    The purpose is to check that this method returns a str containing
    adequate information so that the user knows what the problem is.
    """
    # We use a fake _fmt string so we can test that this is used.
    e = InvalidPattern('mushroom')
    e._fmt = '%(msg)s'
    e._preformatted_string = None
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == 'mushroom'

    # We test that the _fmt string is used from bzrlib.i18n
    e = InvalidPattern('mushroom')
    e._fmt = '%(msg)s'
    e._preformatted_string = None
    LazyRegex._

# Generated at 2022-06-12 07:45:17.037454
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.trace import mutter
    def test(msg, expected):
        try:
            raise InvalidPattern(msg)
        except InvalidPattern as e:
            mutter(str(e))
            mutter(e)
            mutter(repr(e))
            actual = str(e)
        mutter(actual)
        mutter(expected)
        if actual != expected:
            from bzrlib.tests import TestNotApplicable
            raise TestNotApplicable(
                "expected: %r, but the actual is: %r" % (expected, actual))

    # msg is type 'str'.
    test('Invalid pattern(s) found. %(msg)s',
         'Invalid pattern(s) found. ".*" nothing to repeat')

    # msg is type 'unicode'.

# Generated at 2022-06-12 07:45:24.789187
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return the regex property when it is called."""
    regex = LazyRegex(['.'])
    # Before calling the __getattr__, the _real_regex is None.
    # But the __getattr__ will find the real regex property and return it.
    assert regex._real_regex is None
    # After calling the __getattr__, the real regex is not None any more.
    assert regex.groups is 1
    assert regex._real_regex is not None

# Generated at 2022-06-12 07:45:34.731919
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    invalid_pattern = InvalidPattern(u'foo')
    # str() is used by class __str__ and __repr__ and so we need to make sure
    # it does not raise an exception.
    str(invalid_pattern)

# Generated at 2022-06-12 07:45:42.431179
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib import _i18n

    _i18n._get_text_dict()['Invalid pattern(s) found. %(msg)s'] = \
        'invalid pattern(s) found: %(msg)s'

    invalid_pattern = InvalidPattern('invalid regex')
    assert unicode(invalid_pattern).encode('utf8') == \
        'invalid pattern(s) found: invalid regex'

    invalid_pattern = InvalidPattern(u'invalid regex')
    assert unicode(invalid_pattern).encode('utf8') == \
        'invalid pattern(s) found: invalid regex'

    invalid_pattern = InvalidPattern('invalid regex'.decode('utf8'))

# Generated at 2022-06-12 07:45:49.548800
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext

    gettext('something')

    expected_str = "Unprintable exception InvalidPattern: dict={'msg': 'me'}, fmt='Invalid pattern(s) found. %(msg)s', error=AttributeError('_get_format_string',)"
    ip = InvalidPattern('me')
    str(ip)
    assert(str(ip) == expected_str)

    ip._preformatted_string = 'test'
    assert(str(ip) == 'test')

# Generated at 2022-06-12 07:45:59.995539
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import _i18n_pyx as _i18n
    from bzrlib.i18n import ui

    import os

    # Test what happens when we have no translation.
    # The method __unicode__ should return the same string as converting
    # the exception to a string.
    # We want to test this before there is any message catalog created,
    # so we remove all the existing message catalogs.
    _i18n.install()
    m = _i18n._get_message_catalog()
    m.destroy()
    # We want to check that the domain is not found. To do so we delete
    # the directory containing the message catalogs.
    m.path = []
    def no_translation_f():
        return None
    m._gettext_adapter.gettext = no_

# Generated at 2022-06-12 07:46:04.802395
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # call __str__() of InvalidPattern before any other method
    # to check also internal initialization.
    expected = 'Invalid pattern(s) found. "abc" unbalanced parenthesis'
    actual = LazyRegex(args=('abc',)).__str__()
    if expected != actual:
        raise Exception('expected:\n%r\nactual:\n%r' % (expected, actual))

# Generated at 2022-06-12 07:46:13.832902
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex."""
    # Create the LazyRegex
    x = LazyRegex(('some pattern',), {})
    # Pickle the LazyRegex
    test_y = pickle.dumps(x)
    # Recreate y
    y = LazyRegex()
    y.__setstate__(pickle.loads(test_y))
    # Check that they are equal
    assert x == y
    assert x._regex_args == y._regex_args
    assert x._regex_kwargs == y._regex_kwargs

# Generated at 2022-06-12 07:46:23.762419
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method InvalidPattern.__str__"""
    def checkstr(ex, expected):
        actual = str(ex)
        if not isinstance(actual, str):
            raise AssertionError(
                "InvalidPattern.__str__ returned a non-string: %r" % type(actual))
        if expected != actual:
            raise AssertionError(
                "InvalidPattern.__str__: expected %r, got %r"
                % (expected, actual))

# Generated at 2022-06-12 07:46:25.689325
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    pattern = lazy_compile()
    pattern.__setstate__({'args':('a',)})
    pattern.__setstate__({'kwargs':{'flags':0}})

# Generated at 2022-06-12 07:46:32.556381
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return the same string as __unicode__."""
    exc = InvalidPattern('msg')
    str_ = str(exc)
    unic = unicode(exc)
    utf8 = unic.encode('utf8')
    assert str_ == utf8, \
        "__str__ doesn't return the same string as __unicode__"

test_suite = 'bzrlib.tests.test_regex.test_suite'

# Generated at 2022-06-12 07:46:37.583019
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex."""
    def method():
        return 3
    regex = LazyRegex(('pattern',), {'verbose': True})
    regex._real_regex = re.compile('pattern', verbose=True)
    regex._real_regex.method = method
    proxy_method = regex.method
    assert proxy_method() == 3
    assert isinstance(proxy_method, type(regex.method))
    assert proxy_method is regex.method

# Generated at 2022-06-12 07:46:57.624116
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import bzrlib.trace

    def side_effect_get_fmt_string(self):
        return self._fmt

    old_get_fmt_string = bzrlib.trace.InvalidPattern._get_format_string
    bzrlib.trace.InvalidPattern._get_format_string = side_effect_get_fmt_string
    try:
        e = InvalidPattern('error')
        assert str(e) == 'error'
    finally:
        bzrlib.trace.InvalidPattern._get_format_string = old_get_fmt_string


_real_re_compile('.*')

# Generated at 2022-06-12 07:47:05.255258
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should restore the state of the object."""
    p = LazyRegex(('(?P<a>a(?P<b>b)?)', re.I))
    # state of the object before __setstate__ is called
    state_before = p.__getstate__()
    if state_before['args'][0] != '(?P<a>a(?P<b>b)?)' or \
        state_before['args'][1] != re.I or \
        state_before['kwargs'] != {}:
        return False
    # Now we call __setstate__
    p.__setstate__(state_before)
    state_after = p.__getstate__()
    return state_before == state_after



# Generated at 2022-06-12 07:47:11.556854
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPatterns should be printable

    This is important because InvalidPatterns are raised all over the place,
    and it is important that they be printable.
    """
    e = InvalidPattern('bad regex')
    # Try to print the exception, which should succeed.
    t = str(e)
    s = e.__str__()

# Unit tests for method _get_format_string of class InvalidPattern

# Generated at 2022-06-12 07:47:16.087106
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Unit test for method __getattr__ of class LazyRegex"""
    # Every LazyRegex object should have all the entries in
    # _regex_attributes_to_copy.
    lre = LazyRegex()
    for i in LazyRegex._regex_attributes_to_copy:
        getattr(lre, i)

# Generated at 2022-06-12 07:47:22.375399
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """LazyRegex.__setstate__ should set the arguments of re.compile."""
    lzreg = LazyRegex()
    lzreg_state = lzreg.__getstate__()

    lzreg = LazyRegex()
    lzreg.__setstate__(lzreg_state)

    assert lzreg._regex_args == ()
    assert lzreg._regex_kwargs == {}


# Generated at 2022-06-12 07:47:25.497728
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    e = InvalidPattern('msg')
    # Test that unicode conversion will throw no exception
    unicode(e)


# Generated at 2022-06-12 07:47:30.971834
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ returns a str"""
    from bzrlib.i18n import gettext
    fmt = gettext(unicode("This is an error: %(value)s"))
    value = "test"
    error = InvalidPattern(fmt % {"value": value})
    assert (isinstance(str(error), str))



# Generated at 2022-06-12 07:47:42.364513
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() works with all kinds of arguments"""

    # This is the default of the class, but should also be available in the
    # instance.
    format_string = InvalidPattern._fmt
    # This should be available in the instance
    instance_format_string = InvalidPattern._get_format_string()
    # This is a format string for the 'msg' argument
    msg_format_string = u"%(msg)s"

    # create an InvalidPattern with a unicode string
    p = InvalidPattern(u"\u00a0")
    # check if __str__ works with a unicode string
    got = p.__str__()
    assert isinstance(got, str)
    expected = p._format()
    assert got == expected

    # check if __str__ works with an empty string

# Generated at 2022-06-12 07:47:45.333876
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    lazy_re = LazyRegex(["^a"])
    assert not hasattr(lazy_re, 'pattern')
    assert lazy_re.pattern == "^a"
    assert hasattr(lazy_re, 'pattern')


# Generated at 2022-06-12 07:47:50.925868
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__().

    The method __unicode__ must return a unicode object.
    """
    msg = u"Illegal regex pattern in file 'filename' at line 1: 'pattern'."
    e = InvalidPattern(msg)
    u = e.__unicode__()
    # __unicode__ must return a unicode object.
    assert isinstance(u, unicode)
    assert u == msg

# Generated at 2022-06-12 07:48:04.592943
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should be implemented correctly."""
    e = InvalidPattern('msg')
    # The InvalidPattern.__unicode__() should not raise an exception.
    # TODO: check how InvalidPattern.__unicode__() behaves in other languages.
    e.__unicode__()

# Generated at 2022-06-12 07:48:12.808483
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test class InvalidPattern method __unicode__.

    This test is here because the method is only defined in this module
    making harder to create the test.
    """
    test_invalid_pattern = InvalidPattern('Invalid regex: unbalanced parenthesis')
    expected_result = u'Invalid regex: unbalanced parenthesis'
    result = test_invalid_pattern.__unicode__()
    if result != expected_result:
        raise AssertionError('InvalidPattern.__unicode__() does not work'
            ' as expected.\nExpected: %s\nGot: %s' % (expected_result, result))

# Generated at 2022-06-12 07:48:21.662517
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import bzrlib.tests
    bzrlib.tests.TestCaseWithTransport.tearDown = (lambda self: None)
    from bzrlib import (
        tests,
        i18n,
        )
    from bzrlib.tests.blackbox import ExternalBase

    def get_msg_gettext(input_msg):
        i18n.install_gettext_translations(bzrlib.tests.TestCaseWithTransport)
        str_msg = str(i18n.gettext(input_msg))
        return str_msg

    class Test(ExternalBase):

        def setUp(self):
            self.overrideEnv('LANGUAGE', 'en_ZZ.UTF-8')
            ExternalBase.setUp(self)


# Generated at 2022-06-12 07:48:29.325931
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must return unicode object"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import ugettext
    from bzrlib.i18n import lazy_gettext

# Generated at 2022-06-12 07:48:36.511315
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return an ascii string when called."""
    # create a new instance of InvalidPattern
    ip = InvalidPattern("")
    # call the __str__ method
    ip_str = ip.__str__()
    # the result should be an ascii string
    if isinstance(ip_str, unicode):
        raise AssertionError("expected an ascii string, got %r" % (ip_str,))
    # if we get here (we didn't raise AssertionError), test has passed.

# Generated at 2022-06-12 07:48:47.478867
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method InvalidPattern.__unicode__()."""

    exc = InvalidPattern('test')
    assert unicode(exc) == u'test', \
        "InvalidPattern.__unicode__() should return u'test', got %r" % \
        unicode(exc)

    exc = InvalidPattern(123)
    assert unicode(exc) == u'123', \
        "InvalidPattern.__unicode__() should return u'123', got %r" % \
        unicode(exc)

    exc = InvalidPattern(exc)

# Generated at 2022-06-12 07:48:51.991887
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    return doctest.DocTestSuite(
        'bzrlib.lazy_regex',
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS,
        )

# Generated at 2022-06-12 07:49:00.577150
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() can return a str even if __unicode__() returns a unicode."""
    class Foo(object):
        def __unicode__(self):
            return u('\xb7')
        def __str__(self):
            return '-'
    e = InvalidPattern('a %r',
                       Foo())
    # The format should then convert the Foo object to a str, because 's'
    # is used, even if the unicode object was returned.
    eq = u('a \xb7')
    eq = eq.encode('utf8')
    assert str(e) == eq

# Generated at 2022-06-12 07:49:03.314418
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """chr(128) in the message caused UnicodeDecodeError"""
    try:
        raise InvalidPattern('None' + chr(128))
    except InvalidPattern as e:
        s = str(e)
        u = unicode(e)

# Generated at 2022-06-12 07:49:13.296285
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str not a unicode"""
    from bzrlib.i18n import gettext
    gettext('b') # just to ensure that the language is set

    from bzrlib.trace import mutter
    # mutter the log so that we can test the exception formatting
    mutter('$msg', msg='a message')

    try:
        # We must clear the log to be able to test properly
        import bzrlib.trace
        bzrlib.trace._clear_log()
        raise InvalidPattern('a message')
    except InvalidPattern as e:
        # should be str
        s = str(e)
        assert isinstance(s, str)

        # should be unicode
        u = unicode(e)
        assert isinstance(u, unicode)

        # should be unicode

# Generated at 2022-06-12 07:49:29.224512
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__() should return a unicode object"""

# Generated at 2022-06-12 07:49:35.228947
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ return the same value as __str__.

    This avoid that the error message for a InvalidPattern is not printable
    by those code that rely on str(e) to display the error message and
    not on unicode(e).
    """
    message = "This is a test"
    e = InvalidPattern(message)
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == e.__str__()
    assert e.__unicode__() == message

# Generated at 2022-06-12 07:49:37.391045
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern("msg")
    expected = "msg"
    actual = e.__unicode__()
    assert(expected == actual)

# Generated at 2022-06-12 07:49:48.401813
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a str"""
    class A(object):
        def __str__(self):
            return 'a'
    class B(object):
        def __str__(self):
            return u'b'
    class C(object):
        def __str__(self):
            return str('c')
    class D(object):
        def __str__(self):
            return unicode('d')
    class E(object):
        def __str__(self):
            return A()

    def E__str__():
        return 'e'
    E.__str__ = E__str__

    for cls, expected in ((A, 'a'), (B, 'b'), (C, 'c'), (D, 'd'), (E, 'e')):
        instance = cls()

# Generated at 2022-06-12 07:49:55.271434
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """This test demonstrates that __unicode__ method from InvalidPattern class
    can accepting both str and unicode parameters.
    """
    # Test 1: args is a str
    args = 'foobar'
    e = InvalidPattern(args)
    u = unicode(e)
    assert args in u

    # Test 2: args is a unicode
    args = u'foobar'
    e = InvalidPattern(args)
    u = unicode(e)
    assert args in u

# Generated at 2022-06-12 07:50:03.236816
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test unicode representation of InvalidPattern.

    This tests that the unicode representation is well formatted whatever the
    internal format used to create InvalidPattern.
    """
    from bzrlib.i18n import gettext
    for format_string in (None, '', 'Hello %(value)s!',
                          'Hello %(value)s but not %(bad)s!',
                          '%(value)s'):
        gettext(format_string)
        e = InvalidPattern('Hello world!')
        setattr(e, '_fmt', format_string)
        e.value = 'world'
        e.bad = 'everyone else'
        unicode(e)
        unicode(e).encode('utf8')
        e._preformatted_string = 'Preformatted error message'

# Generated at 2022-06-12 07:50:08.935426
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import bzrlib.tests
    exception = InvalidPattern('pattern')
    bzrlib.tests.TestCase.assertEqual(exception.__unicode__(),
        'Invalid pattern(s) found. pattern')

if __name__ == '__main__':
    import bzrlib.tests
    bzrlib.tests.TestUtil.test_suite()

# Generated at 2022-06-12 07:50:17.316087
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unicode(InvalidPattern) should return unicode"""
    # Any unicode string is acceptable, since these exceptions are never seen
    # by users (they are used to implement test assertions only).
    try:
        raise InvalidPattern('a unicode string')
    except InvalidPattern as e:
        u = unicode(e)
    # Test for UnicodeEncodeError is merely for coverage
    try:
        raise InvalidPattern('a unicode string')
    except InvalidPattern as e:
        try:
            s = str(e)
        except UnicodeEncodeError:
            pass

# Generated at 2022-06-12 07:50:28.284361
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__() of LazyRegex yields expected result."""
    from bzrlib.tests.timings import log_time

    def check_match_result(match_result_list, target_list):
        """Checks that the match result list is equal to the target list.

        :param match_result_list: The match result list to check.
        :param target_list: The expected match result list.
        """
        match_result_list = [result.group(0) for result in match_result_list]
        def convert_to_tuple(s):
            if s is None:
                return ()
            return tuple([s])
        match_result_list = [convert_to_tuple(s) for s in match_result_list]

# Generated at 2022-06-12 07:50:32.882324
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Check that calling __getattr__ will compile the regex."""
    # Create a LazyRegex
    r = lazy_compile('.*')
    # Now get a member
    r.__getattr__('search')
    # Check that the regex has been compiled
    if r._real_regex is None:
        raise AssertionError("The regex hasn't been compiled")
    # Check that the real regex has the 'search' attribute
    if not r._real_regex.search("test"):
        raise AssertionError("The regex doesn't match")

# Generated at 2022-06-12 07:50:48.004820
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        # Test default message
        e = InvalidPattern(None)
        assert 'Invalid pattern(s) found' in str(e)
        # Test message with %
        e = InvalidPattern('foo %s')
        assert 'foo %s' in str(e)
        # Test message without %
        e = InvalidPattern('foo')
        assert 'foo' in str(e)
    finally:
        del e

# Generated at 2022-06-12 07:50:55.256594
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ from LazyRegex returns the attribute from the real regex.
    """
    lr = LazyRegex(('s'))
    # regex has not been compiled yet
    assert lr._real_regex is None
    # so no _sre.SRE_Pattern object exists
    try:
        lr.match('s')
    except AttributeError as e:
        assert str(e) == "'NoneType' object has no attribute 'match'"
    else:
        raise AssertionError('should raise AttributeError')

    class FakeSRE_Pattern(object):
        match = 'an attribute of a compiled regex'

    lr._real_regex = FakeSRE_Pattern()
    assert lr.match == 'an attribute of a compiled regex'



# Generated at 2022-06-12 07:51:04.331443
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Make sure an InvalidPattern can be converted to unicode."""
    from bzrlib.trace import mutter

    class FooException(InvalidPattern):
        """InvalidPattern without _fmt"""
        pass

    class BarException(InvalidPattern):
        """InvalidPattern with _fmt"""
        def _get_format_string(self):
            return '%(msg)s'

    for exc in (FooException(msg='Foo'),
                BarException(msg='Bar')):
        mutter('Exception: %r', exc)
        mutter('As unicode: %r', unicode(exc))
        mutter('As string: %r', str(exc))

    try:
        raise FooException('Foo')
    except FooException:
        mutter('Exception: %r', _i18n_exc)
        mutter

# Generated at 2022-06-12 07:51:09.625448
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    save_gettext = gettext
    try:
        gettext = lambda x: x
        x = InvalidPattern("message")
        assert unicode(x) == 'Invalid pattern(s) found. message'
    finally:
        gettext = save_gettext



# Generated at 2022-06-12 07:51:15.252827
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('(?P<name>foo)')
    assert str(e) == "Invalid pattern(s) found. '(?P<name>foo)'"
    e._preformatted_string = 'hullo'
    assert str(e) == 'hullo'
    assert repr(e) == "InvalidPattern('hullo')"
    # This should not raise
    unicode(e)

# Generated at 2022-06-12 07:51:26.615899
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ method of InvalidPattern should always return a unicode object.

    It should use the _format() method and the method encoding should always
    return a unicode object.
    """
    def _format():
        s = 'Unprintable exception InvalidPattern'
        if isinstance(s, str):
            # Try decoding the str using the default encoding.
            s = unicode(s)
        elif not isinstance(s, unicode):
            # Try to make a unicode object from it, because __unicode__ must
            # return a unicode object.
            s = unicode(s)
        return s

    i = InvalidPattern('test')
    i._format = _format
    s = i.__unicode__()
    # s should be a unicode object.
    assert isinstance(s, unicode)

# Generated at 2022-06-12 07:51:32.162733
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # The object attributes should be printed when we call __unicode__
    e = InvalidPattern("error message")
    e._fmt = ''
    assert '{msg: %s}' % (e.msg,) == e.__unicode__()

    # The type and the attributes should be printed when we call __unicode__
    # and _fmt was not set
    e = InvalidPattern("error message")
    assert 'InvalidPattern({msg: %s})' % (e.msg,) == e.__unicode__()


# Generated at 2022-06-12 07:51:40.041316
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for LazyRegex.__getattr__"""
    regex = LazyRegex(("foo", 0))
    # match method should be lazy loaded from _real_regex
    from bzrlib.trace import mutter
    mutter("%r", hasattr(regex, "match"))
    assert hasattr(regex, "match")
    assert not hasattr(regex, "_real_regex")
    regex.match("bar")
    assert hasattr(regex, "_real_regex")


# Unit tests for module lazy_re.py

# Generated at 2022-06-12 07:51:48.727371
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern
    """

    class DummySyntaxError(object):

        def __repr__(self):
            return "<SyntaxError>"

        def __unicode__(self):
            return '!SyntaxError!'

        def __str__(self):
            return '!SyntaxError!'

    def _format(obj):
        try:
            return obj.__unicode__()
        except AttributeError:
            return obj.__str__()

    class InvalidPatternTest(InvalidPattern):

        _fmt = ('Invalid pattern(s) found. %(syntaxerror)s # %(msg)s')

        def __init__(self, syntaxerror, msg):
            self.syntaxerror = syntaxerror
            self.msg = msg


# Generated at 2022-06-12 07:51:54.552325
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exceptions = [InvalidPattern('Hello'),
                  InvalidPattern('\u263a'),
                  InvalidPattern('Foo\nBar\nBaz'),
                  InvalidPattern('\xffBar\x00\x00\t\0Baz'),
                  ]
    for e in exceptions:
        assert type(str(e)) == str
        assert type(unicode(e)) == unicode

# Generated at 2022-06-12 07:52:09.165698
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode string"""
    error = InvalidPattern('error message')
    unicode_error = error.__unicode__()
    try:
        unicode_error.encode('ascii')
    except UnicodeEncodeError:
        raise AssertionError('InvalidPattern.__unicode__() should return '
            'a unicode string')

# Generated at 2022-06-12 07:52:10.261605
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern"""
    pass



# Generated at 2022-06-12 07:52:10.992797
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:52:13.410322
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should return a str, not a unicode."""
    err = InvalidPattern(u'foo')
    str(err)

# Generated at 2022-06-12 07:52:22.348713
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Some doc tests to make sure the __unicode__ method works as we
    # expect.
    # This first one has a non-ASCII character in the _fmt string.
    # We want to make sure that it is decoded as utf-8 and '%' is
    # handled properly.
    class MyInvalidPattern(InvalidPattern):
        _fmt = 'R\xe9sum\xe9'
    ex = MyInvalidPattern('msg')
    got = unicode(ex)
    # The encoding of both strings must be the same.
    assert got.encode('utf-8') == 'R\xc3\xa9sum\xc3\xa9'

# Unit tests for method _format of class InvalidPattern

# Generated at 2022-06-12 07:52:27.205432
# Unit test for method __getattr__ of class LazyRegex

# Generated at 2022-06-12 07:52:30.521663
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test the __getattr__ method of class LazyRegex"""
    regex = LazyRegex(("^abc$",))
    assert regex._real_regex is None
    assert regex.pattern == "^abc$"
    assert regex._real_regex is not None

# Generated at 2022-06-12 07:52:39.663332
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from StringIO import StringIO
    from bzrlib import trace
    from bzrlib.i18n import gettext

    # Make sure that lazy_compile is not installed
    gettext('foo')
    if re.compile is lazy_compile:
        raise AssertionError('re.compile is already set to lazy_compile which '
                              'would cause this test to fail')
    install_lazy_compile()
    # make sure that _fmt is not used
    _fmt_backup = InvalidPattern._fmt
    InvalidPattern._fmt = None
    msg = gettext('foo')
    assert msg == u'foo'
    _preformatted_string_backup = InvalidPattern._preformatted_string
    InvalidPattern._preformatted_string = None
    # check that __str__

# Generated at 2022-06-12 07:52:43.213748
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('error message')
    expected = 'Invalid pattern(s) found. error message'
    if str(e) != expected:
        raise AssertionError(
            '__str__: %r != %r' % (str(e), expected))



# Generated at 2022-06-12 07:52:48.814807
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode object"""
    from bzrlib import errors
    msg = 'this is an invalid pattern'
    ip = errors.InvalidPattern(msg)
    assert isinstance(ip.__unicode__(), unicode)
    assert unicode(ip) == unicode(msg)



# Generated at 2022-06-12 07:53:07.745470
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern class must return a unicode object even if
    _fmt is a string"""
    class MyException(InvalidPattern):
        _fmt = 'this is a '
        def __init__(self):
            InvalidPattern.__init__(self, 'format string')

    my_exception = MyException()
    # __str__ of a unicode object returns a string object
    assert isinstance(unicode(my_exception), unicode)
    # __str__ of a string object returns a string object
    assert isinstance(str(my_exception), str)

# Generated at 2022-06-12 07:53:14.676810
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern._format() returns a string"""
    msg = 'This is a test string'
    e = InvalidPattern(msg)
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == msg, 'Failed to get unicode string'
    str_e = str(e)
    assert isinstance(str_e, str), 'Failed to get a str string'
    assert str_e == msg, 'Failed to get str string'
    repr_e = repr(e)
    assert isinstance(repr_e, str), 'Failed to get a str string'
    assert repr_e == 'InvalidPattern(\'%s\')' % msg, \
        'Failed to get str string'

# Generated at 2022-06-12 07:53:22.254208
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__() should return a proper string objects."""

    # first we test that the original without Unicode support is OK.
    class UnicodeErrorTest(Exception):
        """Unicode exception test."""
        # This string should never be in Unicode form, it must be ascii.
        _fmt = 'UnicodeErrorTest(%(msg)s)'

        def __init__(self, msg):
            self.msg = msg

    uni_str_obj = u'blah'
    enc_str_obj = uni_str_obj.encode('utf-8')
    unicode_test = UnicodeErrorTest(uni_str_obj)
    assert unicode_test.msg == uni_str_obj

# Generated at 2022-06-12 07:53:31.113933
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_user_option
    set_user_option('i18n_translate', False)

    # make sure __unicode__ returns a unicode object
    e = InvalidPattern('foo')
    eq = gettext('Invalid pattern(s) found. foo')
    assert_(unicode(e), eq)

    # make sure __unicode__ returns a unicode object even if fmt is unicode
    e._fmt = unicode('Invalid pattern(s) found. %(msg)s')
    eq = unicode('Invalid pattern(s) found. foo')
    assert_(unicode(e), eq)

    # make sure __unicode__ returns a unicode object even if it was initialized
    # with a unicode string
    e = Invalid

# Generated at 2022-06-12 07:53:35.444932
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern should not raise an exception when used with
    unicode data."""
    msg = '\xe9\x87\x8d\xe8\xaf\x86\xe5\x88\xab' #unicode data
    e = InvalidPattern(msg)
    unicode(e)
    str(e)

# Generated at 2022-06-12 07:53:41.058870
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():

    class Tmp(InvalidPattern):
        _fmt = 'a %(msg)s b'

    t1 = Tmp('c')
    t2 = InvalidPattern('d')

    assert isinstance(t1, InvalidPattern)
    assert t1.__unicode__() == u'a c b'
    assert t2.__unicode__() == u'Invalid pattern(s) found. d'

# Generated at 2022-06-12 07:53:45.204430
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__: _fmt strings should be ascii"""
    from bzrlib.i18n import gettext
    try:
        gettext('hello world')
    except UnicodeEncodeError:
        from bzrlib.errors import BzrError
        raise BzrError('_fmt strings should be ascii')

# Generated at 2022-06-12 07:53:51.459486
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase

    from bzrlib.i18n import gettext

    class DummyGettext(object):

        def __getattr__(self, attr):
            return gettext(attr)

    class TestInvalidPattern(TestCase):

        def setUp(self):
            super(TestInvalidPattern, self).setUp()
            self.overrideAttr(bzrlib.i18n, 'gettext', DummyGettext())
            self.pattern = InvalidPattern('test')

        def test__str__no_fmt(self):
            self.pattern._fmt = None
            self.assertIsInstance(str(self.pattern), str)

        def test__str__fmt(self):
            self.pattern._fmt = '%(msg)s'
            self.assertIs

# Generated at 2022-06-12 07:53:57.897582
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    e = InvalidPattern('Invalid pattern(s) found. '
            'Regex: "^\?(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d\d\d)\\t\?([^\\t]+)" '
            'Error: unmatched "\?"')
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__repr__(), str)