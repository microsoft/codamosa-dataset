

# Generated at 2022-06-12 07:44:07.251480
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should return defined attribute of real regex object."""
    obj = LazyRegex()
    assert obj.__getattr__('pattern') == None


# Generated at 2022-06-12 07:44:11.042080
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex proxies methods"""
    pat = LazyRegex('x', "")
    compiled = pat._real_regex
    match = pat.match
    assert pat._real_regex is compiled
    assert pat.match is match

# Generated at 2022-06-12 07:44:13.516346
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method InvalidPattern.__str__()"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:44:18.468268
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    err = InvalidPattern('format string')
    u = err.__str__()
    if not isinstance(u, unicode):
        raise AssertionError()


# Generated at 2022-06-12 07:44:22.381031
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode object

    This test ensures that __unicode__ returns a unicode object and not
    a decoded str object.
    """
    msg = 'This is a test message'
    ip = InvalidPattern(msg)
    u = unicode(ip)
    assert isinstance(u, unicode)
    assert u == msg


# Generated at 2022-06-12 07:44:31.908588
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() produces the right output

    Method is not documented so we don't know what it should do for values
    of args different from "preformatted string" and "message",
    so we have to take care of them (and make sure that our implementation
    is compatible with them).
    """
    class TestInvalidPattern(InvalidPattern):
        _fmt = '%(msg)s'
        def __init__(self,msg):
            self.msg = msg
    for attr in ('_fmt', 'msg', '_preformatted_string'):
        msg = 'error message'
        ip = TestInvalidPattern(msg)
        setattr(ip, attr, msg)
        # if the preformatted message is set, it should be returned
        ip.__str__() == msg
    # Check that the

# Generated at 2022-06-12 07:44:35.322993
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern class must return a str object"""
    test_exc = InvalidPattern("test")
    assert isinstance(str(test_exc), str)



# Generated at 2022-06-12 07:44:38.531810
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Ensure InvalidPattern generates a unicode object"""
    try:
        raise InvalidPattern('test')
    except InvalidPattern as e:
        assert isinstance(unicode(e), unicode)


# Generated at 2022-06-12 07:44:47.034635
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Test for class name, format string, and attributes
    from bzrlib.i18n import gettext
    ip = InvalidPattern("something")
    ip._fmt = 'foo%(msg)s'
    ip.msg = 'bar'
    expected = gettext('foo%(msg)s') % {'msg': 'bar'}
    assert ip.__str__() == expected

    # Test for preformatted string
    ip = InvalidPattern("something")
    ip._preformatted_string = "preformatted string"
    assert ip.__str__() == "preformatted string"

    # Test for removing non-ascii characters
    ip = InvalidPattern("something")
    ip._fmt = 'foo%(msg)s'
    ip.msg = u'bar\u0100'

# Generated at 2022-06-12 07:44:52.628131
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ returns unicode instance"""
    p = InvalidPattern("msg")
    import sys
    if sys.version_info[0] >= 3:
        assert(isinstance(p.__unicode__(), str))
    else:
        assert(isinstance(p.__unicode__(), unicode))


# Generated at 2022-06-12 07:45:04.068787
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern must behave correctly when __unicode__() is called."""
    e = InvalidPattern('test')
    # We call __unicode__() because __str__() is used on exceptions it could
    # raise another exception that we want avoid.
    u = unicode(e)
    # If __unicode__() returns an unicode object, then we have nothing to do.
    if isinstance(u, unicode):
        return
    # If __unicode__() returns an str object, then we try to decode it using
    # the default encoding.
    assert isinstance(u, str)
    u = unicode(u)
    # If the decoding succeeds, then we have nothing to do.
    assert isinstance(u, unicode)
    # If the decoding fails, then we try to make an unicode object from
    # the str

# Generated at 2022-06-12 07:45:11.183280
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method `__str__` from class InvalidPattern."""
    # We use an explicit unicode string as an exception message.
    # This message is what the user should see.
    unicode_msg = u'\u00d1'
    try:
        raise InvalidPattern(unicode_msg)
    except InvalidPattern as e:
        # Unicode message (unicode object) is the same one we passed to the
        # constructor
        assert e.msg == unicode_msg
        # _fmt is an ascii string (a default message in case the _format method
        # fails).
        assert e._fmt == 'Invalid pattern(s) found. %(msg)s'
        # The message as a str object is decoded from unicode
        assert str(e) == unicode_msg.encode('utf8')


# Generated at 2022-06-12 07:45:18.102407
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import i18n
    from StringIO import StringIO
    try:
        i18n.gettext(u"fake string")
    except i18n.TranslateError:
        # The locale is not set, so we will fallback to the default
        # value (the string itself)
        return
    # The locale is set, so we should get the translated value
    e = InvalidPattern("fake error message")
    s = StringIO()
    # The function print_exception use the method __str__, so we can
    # just call it to test it.
    traceback.print_exception(type(e), e, None, file=s)
    s = s.getvalue()

# Generated at 2022-06-12 07:45:29.194377
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # test a simple exception message
    e = InvalidPattern("this is the message")
    assert(str(e) == unicode(e) == "this is the message")
    assert(e.__str__() == "this is the message")
    assert(e.__unicode__() == u"this is the message")

    # test a exception message containing extra parameters
    e = InvalidPattern("extra param %(p)s")
    e.p = "myparam"
    assert(str(e) == unicode(e) == "extra param myparam")
    assert(e.__str__() == "extra param myparam")
    assert(e.__unicode__() == u"extra param myparam")

    # test an exception message that already has been formatted
    e = InvalidPattern("this is the %(p)s")
    e

# Generated at 2022-06-12 07:45:35.411280
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test method __str__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    message = gettext('Invalid pattern(s) found. %(msg)s')
    e = InvalidPattern(message) # str(e) should just return message
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == u'Invalid pattern(s) found. Invalid pattern(s) found. %(msg)s'

# Generated at 2022-06-12 07:45:39.463560
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should raise a UnicodeDecodeError with
    a valid message.

    This test passes when InvalidPattern.__unicode__ raises a UnicodeDecodeError
    with a message containing the text 'Unprintable exception InvalidPattern:'
    """
    try:
        raise InvalidPattern("")
    except InvalidPattern as e:
        str(e)

# Generated at 2022-06-12 07:45:50.034168
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ should create a readable string

    The method __str__ of InvalidPattern has a complex construct in order to try
    to return a readable string for the user. At least it should try to return
    a string if it's possible.
    """
    # If there is a preformatted string Initialize it and use it.
    # See http://osdir.com/ml/python.bazaar-vcs.general/2006-11/msg00056.html
    # for the original discussion about it.
    ip = InvalidPattern(None)
    ip._preformatted_string = 'preformatted'
    eq_(str(ip), 'preformatted')

    # If there's no preformatted string, try to format the message with _fmt.
    ip = InvalidPattern(None)
    ip._preformatted_string = None


# Generated at 2022-06-12 07:45:58.240260
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Method __unicode__ of class InvalidPattern should always return a str

    Needed to make sure that the code in wt/local/__init__.py (create_branch)
    will never fail due to a UnicodeEncodeError.
    """
    import sys
    if sys.version_info[0] < 3:
        from bzrlib.tests import hints
        hints.add_hint(InvalidPattern, "__unicode__", 'str')
    else:
        isinstance("", unicode) # make checker happy

test_InvalidPattern___unicode__()

# Generated at 2022-06-12 07:46:08.811145
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import StringIO
    # This test may fail on Windows because we don't know what the
    # encoding is for the os.stderr there.
    old_err = os.dup(sys.__stderr__.fileno())
    try:
        if sys.platform == 'win32':
            quality = 'poor'
        else:
            quality = 'good'
        err_out = StringIO.StringIO()
        os.dup2(err_out.fileno(), sys.__stderr__.fileno())
        try:
            invalid_pattern = InvalidPattern('\x00abc')
        finally:
            os.dup2(old_err, sys.__stderr__.fileno())
    except UnicodeDecodeError as e:
        quality = 'poor'

# Generated at 2022-06-12 07:46:17.557564
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    regex = LazyRegex(("^\[([^\]]+)\]:\s+(.*)$",), {})
    regex.__setstate__(dict(args=("^\[([^\]]+)\]:\s+(.*)$",), kwargs={}))
    regex = LazyRegex(("(?:[^\\]|^)\\(\\w\\w\\w",), {})
    regex.__setstate__(dict(args=("(?:[^\\]|^)\\(\\w\\w\\w",), kwargs={}))

# Generated at 2022-06-12 07:46:27.974677
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from gettext import gettext as _
    # Test including a unicode character
    e = InvalidPattern('"h\xe9" bad character')
    if e.__unicode__() != u'"h\xe9" bad character':
        raise AssertionError('%s != u"h\xe9" bad character' % e.__unicode__())
    # Test including a format string
    e = InvalidPattern('"%(word)s" bad character')
    e._fmt = u'%(word)s'
    e.word = u'h\xe9'
    if e.__unicode__() != u'h\xe9':
        raise AssertionError('%s != u"h\xe9"' % e.__unicode__())
    # Test

# Generated at 2022-06-12 07:46:30.848717
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    try:
        raise InvalidPattern(u'An error occured')
    except InvalidPattern as e:
        assert u'An error occured' == e.__unicode__()


# Generated at 2022-06-12 07:46:38.712666
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Regular expression object can be accessed after it is compiled."""
    # In this test, it is ensured that a compiled regular expression
    # object is accessible after it is compiled.
    #
    # In other words, if the following statements are executed,
    #
    #     lr = LazyRegex(['^[abcd]+.*$'])
    #     lr._compile_and_collapse()
    #
    # then the following statement should not fail
    #
    #     lr.match('abc')
    #
    # This is because the _compile_and_collapse() method sets the 'match'
    # attribute of the LazyRegex object using the 'match' attribute of the
    # compiled regular expression object.

    test_pattern = '^[abcd]+.*$'
    lr = LazyRe

# Generated at 2022-06-12 07:46:48.804346
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """This test is checking __unicode__ method of InvalidPattern class.

    Note that this test has no test_ prefix, so bzrlib.tests.blackbox.TestCase
    won't find and run it.  It is run from
    bzrlib.tests.blackbox.test_i18n.TestCaseI18n.test_find_potential_test_modules.
    """
    # This is a way to check that InvalidPattern is fully translated.  It
    # forces the translation infrastructure to evaluate the __unicode__ method,
    # which is the only way of making sure that the translation happens.  If
    # InvalidPattern is actually translated, we get the expected result,
    # otherwise it falls back to the default translation lookup, which is the
    # _fmt string.
    from bzrlib.i18n import gettext


# Generated at 2022-06-12 07:47:00.199757
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import unittest

    class InvalidPattern___unicode__Test(unittest.TestCase):
        def assert_InvalidPattern_equality(self, a, b):
            # Must use assertEqual rather than assertSameEquality because of
            # the way unittest.assertRaises works
            self.assertEqual(a, b)
            # The InvalidPattern class defines __eq__()

        def test_unicode_from_default_encoding(self):
            a = InvalidPattern('a message')
            self.assert_InvalidPattern_equality(
                a, InvalidPattern(unicode('a message')))
            self.assert_InvalidPattern_equality(
                a, InvalidPattern(u'a message'))
            self.assertEqual(unicode(a), u'a message')

# Generated at 2022-06-12 07:47:07.826650
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method `__unicode__` of class `InvalidPattern`.
    """
    e = InvalidPattern('x'*60 + '\n' + 'y'*60)
    try:
        unicode(e)
    except UnicodeDecodeError:
        raise AssertionError("UnicodeDecodeError while getting the message")
    # The message of an UnicodeDecodeError is not unicode, but
    # a `str` object.
    assert isinstance(str(e), str)

# Generated at 2022-06-12 07:47:14.782295
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ returns unicode.

    unicode(e) should not raise an UnicodeError when e is an exception
    instance.

    This is a bare test as it cannot compare the error message as
    it depends on the system's language.
    """
    def f():
        raise InvalidPattern('Failed to compile %s'
                             % re.escape('(?!('))
    try:
        f()
    except InvalidPattern as e:
        unicode(e)

# Generated at 2022-06-12 07:47:22.503943
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unicode string representation of an exception"""
    msg = u'\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0435\u043d\u0438\u0435'\
        u' \u0443\u0441\u043b\u0443\u0433\u0438'
    e = InvalidPattern(msg)

    # __unicode__ should return a unicode string
    result = e.__unicode__()
    assert isinstance(result, unicode)



# Generated at 2022-06-12 07:47:33.276958
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__().

    It verifies that __unicode__() returns an Unicode object.
    """
    import locale
    locale.setlocale(locale.LC_ALL, ('en_US', 'UTF8'))
    msg = "some message"
    exc = InvalidPattern(msg)
    assert isinstance(exc.__unicode__(), unicode), "__unicode__() should return a unicode object"
    assert exc.__unicode__() == msg, "__unicode__() should return the string contained in msg"

    # Test if the UnicodeDecodeError raised during the __unicode__()
    # call is properly handled.
    msg = "foobar"
    exc = InvalidPattern(msg)
    exc._preformatted_string = "foobar".encode('ascii')
   

# Generated at 2022-06-12 07:47:37.885284
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('foo')
    # __str__ should always return a 'str' object
    # never a 'unicode' object.
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)

# Generated at 2022-06-12 07:47:51.620631
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from breezy.tests import TestCase
    from breezy.i18n import gettext
    gettext(u'test')

    class TestInvalidPattern(InvalidPattern):
        _fmt = ('test')

    class TestCase1(TestCase):

        def test_InvalidPattern___str__1(self):
            t = TestInvalidPattern(u"test")
            self.assertEqual('test', str(t))
            self.assertEqual('test', t.__str__())
        def test_InvalidPattern___str__2(self):
            t = TestInvalidPattern(u"test")
            self.assertEqual(u'test', unicode(t))
            self.assertEqual(u'test', t.__unicode__())

# Generated at 2022-06-12 07:48:00.038109
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return unicode object"""

    # InvalidPattern.__unicode__() should return unicode object if it is given
    # unicode string.
    u = u'\u3072\u3089\u304c\u306a'
    e = InvalidPattern(u)
    # Check if it is a unicode object.
    assert isinstance(e.__unicode__(), unicode)

    # InvalidPattern.__unicode__() should return unicode object if it is given
    # byte string.
    s = u.encode('euc-jp')
    e = InvalidPattern(s)
    # Check if it is a unicode object.
    assert isinstance(e.__unicode__(), unicode)

    # __unicode__() should return unicode object even if it is given


# Generated at 2022-06-12 07:48:02.845493
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern should always return a unicode object"""
    u = InvalidPattern("An invalid pattern")
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:48:10.178858
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.trace import mutter
    my_format = 'My pattern "%(pattern)s" is invalid'
    my_pattern = '%a'
    my_exception = InvalidPattern(my_format % {'pattern': my_pattern})
    my_exception._fmt = my_format
    my_exception.pattern = my_pattern
    result = my_exception.__unicode__()
    mutter('result="%r"', result)
    assert result == u'My pattern "%s" is invalid' % my_pattern

# Generated at 2022-06-12 07:48:19.800629
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern.
    """
    # test default return
    e1 = InvalidPattern('msg')
    assert str(e1) == u"Invalid pattern(s) found. msg"
    assert unicode(e1) == u"Invalid pattern(s) found. msg"
    assert repr(e1) == "InvalidPattern(Invalid pattern(s) found. msg)"

    # test with a preformatted message
    e2 = InvalidPattern('msg')
    e2._preformatted_string = 'a formatted message'
    assert str(e2) == u"a formatted message"
    assert unicode(e2) == u"a formatted message"
    assert repr(e2) == "InvalidPattern(a formatted message)"

    # test with a _fmt string
    e3 = InvalidPattern('msg')

# Generated at 2022-06-12 07:48:28.229820
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib import (
        debug,
        )
    from bzrlib.tests import TestCase

    TestCase.overrideEnv('LANG', 'en_US.utf8')
    TestCase.overrideEnv('LANGUAGE', 'en_AU:en')

    ip = InvalidPattern('msg')
    u = ip.__unicode__()
    # assertIn is added in python 2.7, need to check if it's available
    # since we support python 2.6.
    if debug.python_has_assert_in:
        self.assertIn('msg', u)

    TestCase.overrideEnv('LANG', 'fr_FR.utf8')
    TestCase.overrideEnv('LANGUAGE', 'fr_FR:fr')

    ip = InvalidPattern('msg')
   

# Generated at 2022-06-12 07:48:34.234216
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ should set the private attributes."""
    regex = LazyRegex(('abc',))
    regex_pickle = regex.__getstate__()
    regex_reconstruct = LazyRegex()
    regex_reconstruct.__setstate__(regex_pickle)
    assert regex_reconstruct._regex_args == ('abc',)
    assert regex_reconstruct._real_regex is None

# Generated at 2022-06-12 07:48:35.536437
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    test_Exception___str__(InvalidPattern)


# Generated at 2022-06-12 07:48:42.400633
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object"""
    import bzrlib.tests
    class DummyException(InvalidPattern):
        _fmt = 'message %(msg)s'
        def __init__(self):
            self.msg = u'test'
    e = DummyException()
    bzrlib.tests.TestCase.assertIsInstance(unicode(e), unicode)


# Generated at 2022-06-12 07:48:46.756447
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should compile the regex if necessary."""
    regex = LazyRegex(("foo",))
    # Since the regex hasn't been compiled yet, it should fail with an
    # AttributeError
    import pytest
    pytest.raises(AttributeError, regex.match, "bar")
    # Now, if we ask for a member it will compile the regex, and we
    # can use it
    regex.match("foo").group()

# Generated at 2022-06-12 07:49:02.349878
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ must return str contaning unicode chars"""
    # Make sure it can return the preformatted string when the string is
    # correctly encoded
    m_expected = u'preformatted message'
    m_actual = InvalidPattern(u'preformatted message').__str__()
    if not isinstance(m_actual, str):
        raise TestSkipped('InvalidPattern.__str__ does not return a str object')
    if m_actual != m_expected:
        raise TestSkipped('InvalidPattern.__str__ does not return a str object')

    m_expected = u'preformatted message'
    # Set a unicode string instead
    m_actual = InvalidPattern(m_expected)._format()

# Generated at 2022-06-12 07:49:12.335687
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests the unicode representation of InvalidPattern.

    Test that InvalidPattern.__unicode__() produces the same string for
    the same exception object, even if the current encoding is different.
    """
    # Encoding used to test InvalidPattern.__unicode__()
    test_encoding = 'iso-8859-1'
    # Create a InvalidPattern exception
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as t:
        ex = t
    # get the unicode representation with the test encoding
    unicode_rep = ex.__unicode__()
    # Change the encoding to something else
    import sys
    old_encoding = sys.getdefaultencoding()
    sys.setdefaultencoding('utf-8')
    # Get the unicode representation with the new encoding

# Generated at 2022-06-12 07:49:22.253205
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """test method __getattr__ of class LazyRegex"""
    class Mock(object):
        _call_count = 0
        _return_value = None

        def __init__(self, *args, **kwargs):
            pass

        def __getattr__(self, attr):
            self._call_count += 1
            return self._return_value

    # method `finditer' of re module
    regex = LazyRegex()

    (_real_re_compile, re.compile) = (re.compile, Mock())
    regex.finditer("foo", "bar")
    re.compile = _real_re_compile

    # method `finditer' is not present in the real object
    Mock._return_value = AttributeError

# Generated at 2022-06-12 07:49:29.343207
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import bzrlib.trace
    try:
        _real_re_compile('(', 0)
    except InvalidPattern as e:
        assert e.__unicode__() == u'Invalid pattern(s) found. "(": nothing to repeat'
    else:
        raise AssertionError('unreachable')

# set a default so we don't accidentally compile regexs early
install_lazy_compile()

# Generated at 2022-06-12 07:49:37.301023
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import os.path
    import string
    import sys
    import unittest

    from bzrlib import osutils
    from bzrlib import symbol_versioning

    from bzrlib.tests import TestCaseInTempDir


# Generated at 2022-06-12 07:49:48.294861
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Ensure that the unicode value of the InvalidPattern is correctly
    formatted in all cases.
    """
    from cStringIO import StringIO
    from bzrlib.i18n import gettext

    # capture the stderr (stdout for jython) output to test it
    f = StringIO()
    import sys
    saved = sys.stderr

# Generated at 2022-06-12 07:49:58.980744
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    import sys
    import locale
    # construct an InvalidPattern object
    msg = 'Invalid pattern found'
    err = InvalidPattern(msg)
    # gettext calls should return always the same string, regardless the
    # current locale
    str_default = str(err)
    # but anyway, the string must be printable
    print(str(err))

    # gettext is enabled, now the string must be returned localized
    locale.setlocale(locale.LC_ALL, '')
    try:
        gettext("Test")
    except ValueError as e:
        if "unknown locale" in str(e):
            # The current locale is not supported by gettext
            # Now gettext will return the string just translated
            return
        # The error is another
        raise
   

# Generated at 2022-06-12 07:50:10.112014
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import bzrlib.i18n
    from bzrlib.i18n import _i18n_pygettext as pygettext
    from bzrlib.i18n import _i18n_install as install_i18n
    from bzrlib.i18n import gettext

    install_i18n()
    # This will fail if there are any translation errors
    initialize = pygettext.enumerate_modules(bzrlib)

    # this will fail if there is a translation error
    # or if a string isn't unicode
    initialize()

    # This will fail if the __unicode__ doesn't work.
    # E.g. it may create a string by accident.
    # The cause of the exception is printed in the test output.
    # The string should be displayed as:
    # Invalid pattern

# Generated at 2022-06-12 07:50:14.049342
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    def _test(s):
        invalid_pattern = InvalidPattern(s)
        assert invalid_pattern.__str__() == s

    _test("string")

# Generated at 2022-06-12 07:50:19.606514
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern always creates a str"""
    e = InvalidPattern("foo")
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__str__().decode('utf8'), unicode)
    assert e.__unicode__() == e.__str__().decode('utf8')

# Generated at 2022-06-12 07:50:32.554773
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # We don't want to override re.compile
    # during the following tests
    import re
    _real_re_compile = re.compile

    # Reset re.compile to lazy_compile
    install_lazy_compile()

    # Test the simplest case
    r = re.compile('a')
    assert r._real_regex is None, \
        "Expected _real_regex to be None"
    assert r.findall('a') == ['a'], \
        "Expected ['a'], got %s" % r.findall('a')
    assert r._real_regex is not None, \
        "Expected _real_regex to be not None"

    # Reset re.compile
    reset_compile()

    # Restore original re.compile

# Generated at 2022-06-12 07:50:42.698371
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test InvalidPattern.__unicode__

    """
    # make sure that the preformatted message is used.
    e = InvalidPattern(None)
    e.msg = 'test message'
    e._preformatted_string = 'test preformatted message'
    assert e.__unicode__() == 'test preformatted message', (
        "Formatting the exception with a preformatted message failed.")

    e = InvalidPattern('test message')
    assert e.__unicode__() == u'test message', (
        "Formatting the exception with a simple message failed.")

    # make sure that the message can contain unicode characters.
    e = InvalidPattern(u'test message unicode \u1234')

# Generated at 2022-06-12 07:50:49.610064
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Ensure __str__ works.

    Tests test_InvalidPattern___str__ in bzrlib.lazy_regex
    """
    instance = InvalidPattern('my message')
    assert str(instance) == 'Invalid pattern(s) found. my message'
    instance = InvalidPattern('message\nwith newline')
    assert str(instance) == 'Invalid pattern(s) found. message\nwith newline'
    instance._preformatted_string = 'hello'
    assert str(instance) == 'hello'

# Generated at 2022-06-12 07:51:00.752842
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Class InvalidPattern provides a valid __str__ implementation"""
    from bzrlib.trace import mutter
    from bzrlib.tests.per_interpreter import TestCase
    from bzrlib import osutils
    from bzrlib.errors import BzrError

    class TestInvalidPattern(TestCase):
        def setUp(self):
            super(TestInvalidPattern, self).setUp()
            self.addCleanup(setattr, BzrError, '_fmt', BzrError._fmt)
            BzrError._fmt = '%(msg)s'

        def test_InvalidPattern___str__(self):
            test_text = 'test'
            ip = InvalidPattern(test_text)
            self.assertTrue(test_text in str(ip))

    # A test with a

# Generated at 2022-06-12 07:51:07.432990
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should be ascii even if error message is utf-8

    This test uses the same format and value as the unit test test_test_ui.test_exception.
    """
    error = InvalidPattern('Invalid pattern(s) found. "%(msg)s"')
    error.msg = '\xc6 foo bar baz'
    str_error = str(error)
    # the error message is 'Unprintable exception InvalidPattern:...'
    # which is an ascii string
    assert isinstance(str_error, str)
    assert(str_error.startswith('Unprintable exception InvalidPattern'))


# Generated at 2022-06-12 07:51:11.547058
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Ensure InvalidPattern.__unicode__ returns us-ascii."""
    invalid_pattern = InvalidPattern("Someting wrong")
    # Just calling unicode on the exception will do this for us.
    unicode(invalid_pattern)

# Generated at 2022-06-12 07:51:18.348976
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Ensure that InvalidPattern.__str__() works.

    In particular, if InvalidPattern._fmt is not an unicode object, it should be
    decoded to unicode before applying the message.
    """

    # _fmt is unicode
    ip = InvalidPattern('')
    ip._fmt = u'foo'
    unicode(ip)

    # _fmt is ascii
    ip = InvalidPattern('')
    ip._fmt = 'foo'
    unicode(ip)

    # _fmt is str, utf-8 encoded
    ip = InvalidPattern('')
    ip._fmt = 'f\xc3\xb9\xc3\xb9'.decode('utf-8')
    unicode(ip)

# Generated at 2022-06-12 07:51:29.443543
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests for method __str__ of class InvalidPattern

    This test is isolated to better understand what the method does.
    """
    class subInvalidPattern(InvalidPattern):
        """A class derived from InvalidPattern"""

    # __str__ must return a str object, not an unicode object. So "__str__"
    # must be a str object.
    # The method must return the empty string if self.msg is None.
    # TODO: jam 20051021 I don't think that's right.
    assert str(InvalidPattern("")) == ""
    # TODO: jam 20051021 I don't think that's right.
    assert str(InvalidPattern(None)) == ""

    # Otherwise the returned string must contains message and the returned
    # string must be a str object.
    assert str(InvalidPattern("message")) == "message"

# Generated at 2022-06-12 07:51:40.254748
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return the formatted error"""
    e = InvalidPattern('')
    # a preformatted message string
    e._preformatted_string = 'a formatted msg'
    eq = (
        "Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r" \
        % ({'msg': ''}, None, None))
    assert e.__unicode__() == u'a formatted msg'

    # test a string
    e._preformatted_string = 'a string msg'
    assert e.__unicode__() == u'a string msg'

    # test a unicode
    e._preformatted_string = u'a unicode msg'
    assert e.__unicode__() == u'a unicode msg'

    # test a non-string
    e._pre

# Generated at 2022-06-12 07:51:48.887938
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # test with _fmt and no %
    ip = InvalidPattern(None)
    ip._fmt = 'this is a string'
    assert isinstance(ip.__unicode__(), unicode)
    assert unicode(ip) == ip.__unicode__()
    assert str(ip) == unicode(ip).encode('utf8')
    # test with _fmt and %s
    ip = InvalidPattern('message')
    ip._fmt = 'this is a %s'
    assert ip.__unicode__() == 'this is a message'
    # test with _fmt and %(keyword)
    ip = InvalidPattern(None)
    ip.keyword = 'message'
    ip._fmt = 'this is a %(keyword)s'

# Generated at 2022-06-12 07:52:02.601618
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Check whether InvalidPattern.__unicode__() works, at least for
    error messages that are ASCII strings.
    """
    from cStringIO import StringIO
    from bzrlib import test_i18n
    from bzrlib.i18n import gettext
    from bzrlib.i18n import set_output_encoding
    test_i18n._setup_i18n()

    msg = 'this is an ascii message'
    ip = InvalidPattern(msg)
    output = StringIO()
    save_stdout = sys.stdout

# Generated at 2022-06-12 07:52:04.086202
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:52:12.621085
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ must return a unicode instance

    It will try to decode the message using the default encoding.
    """
    import bzrlib.trace
    bzrlib.trace.config_stack.push_location(path='bzrlib.tests',
                                            lineno=0, file='bzrlib.tests')
    try:
        e = InvalidPattern(u'foobar')
        # __unicode__ should return a unicode instance
        unicode(e)
        # __str__ should encode the message
        str(e)
    finally:
        bzrlib.trace.config_stack.pop_location()
    # In case of error, the test will fail in the python interpreter
    # and the traceback will contain more information to locate the problem.

# Generated at 2022-06-12 07:52:17.010415
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex.__getattr__ works well"""
    import bzrlib.regex
    import re
    r = bzrlib.regex.LazyRegex(("a+b", re.I))
    attr = r.__getattr__('pattern')
    assert_equal("a+b", attr)



# Generated at 2022-06-12 07:52:20.532204
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests that InvalidPattern works with non-ascii args."""
    e = InvalidPattern(u'\u2600')
    unicode(e)
    str(e).decode('ascii')
    repr(e)


# Generated at 2022-06-12 07:52:23.987014
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode object

    This test is a simple regression test for bug #761661.
    """
    instance =  InvalidPattern('test')
    assert isinstance(instance.__unicode__(), unicode)



# Generated at 2022-06-12 07:52:32.902593
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern"""
    from bzrlib.i18n import gettext
    original_gettext = gettext
    gettext = str

# Generated at 2022-06-12 07:52:35.912692
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should only return a str"""
    class A(InvalidPattern):
        _fmt = 'An error message.'
    a = A('An error message.')
    assert(type(str(a)) == str)


# Generated at 2022-06-12 07:52:43.091112
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test the basic case where str and unicode differ
    e = InvalidPattern('a str message')
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() != e.__str__()
    assert unicode(e) == e.__unicode__()
    # Test the case where str and unicode are the same
    e = InvalidPattern(u'a unicode message')
    assert e.__unicode__() == e.__str__()
    assert unicode(e) == e.__unicode__()

# Generated at 2022-06-12 07:52:54.139684
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test_InvalidPattern___str__

    Only test this method because _fmt is the only attribute that should
    be used to format the result.
    """
    ip = InvalidPattern('msg')
    eq = 'Invalid pattern(s) found. msg'
    result = str(ip)
    assert(result == eq)

    ip = InvalidPattern('msg%(x)s')
    eq = 'Invalid pattern(s) found. msg%(x)s'
    result = str(ip)
    assert(result == eq)

    ip = InvalidPattern('msg%(x)s')
    ip.x = 'x'
    eq = 'Invalid pattern(s) found. msgx'
    result = str(ip)
    assert(result == eq)

    ip = InvalidPattern('msg')

# Generated at 2022-06-12 07:53:12.127484
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """The __init__ of this class is called from various places.
    This is a test for the most common usage: the _fmt attribute is set
    to a str and the __init__() is called with a message.
    """
    pattern = "([a-z]+) (binary|text|tree) ([0-9]+)(\.([0-9]+))?"
    msg = "Invalid version: %s" % pattern
    e = InvalidPattern(msg)
    expected = u"Invalid version: ([a-z]+) (binary|text|tree) ([0-9]+)(\.([0-9]+))?"
    eq = expected == e.__unicode__()
    assert eq, u"expected:\n%s\ngot:\n%s" % (expected, e.__unicode__())

# Generated at 2022-06-12 07:53:17.331505
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test for method LazyRegex.__getattr__.

    Method revealed exception.
    """
    proxy = LazyRegex(('^b|z$',))
    try:
        proxy.match('a')
    except AttributeError:
        # ok
        pass
    else:
        raise Exception('__getattr__ failed.')


# Generated at 2022-06-12 07:53:25.885429
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.testing import TestCase
    from bzrlib.i18n import gettext
    gettext("foo %s", encoding=None)
    class MockException(Exception):
        def __init__(self, message, *args, **kwargs):
            super(MockException, self).__init__(*args, **kwargs)
            self.message = message
        def __unicode__(self):
            return self.message
        def __str__(self):
            return self.message.encode('utf-8')
    class test_InvalidPattern___str__(TestCase):
        def test_no_format(self):
            exc = InvalidPattern('')
            self.assertEqual(str(exc), 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None')

# Generated at 2022-06-12 07:53:35.067823
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    from cStringIO import StringIO
    from bzrlib.i18n import gettext
    from bzrlib.i18n import _set_gettext_functions

    # set up dummy gettext functions for tests
    def gettext_noop(txt, **kw):
        return txt
    def ugettext_noop(txt, **kw):
        return txt
    def install():
        _set_gettext_functions(gettext_noop, ugettext_noop)
    install()

    try:
        import __builtin__
        unicode = getattr(__builtin__, 'unicode', unicode)
    except ImportError:
        # py3k
        pass

    # unformatted message

# Generated at 2022-06-12 07:53:36.472309
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:53:44.259363
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should always return utf-8 string"""

# Generated at 2022-06-12 07:53:50.973943
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    from bzrlib import osutils

    # test case class. can be used by tests.
    # It takes an expected exception message,
    # and a list of unicode strings to use as paths.
    # the test will fail if the exception message is not the expected
    # (as provided when creating the instance), or if the unicode strings
    # can't be encoded using the default encoding.
    class _TestCase(TestCase):

        def test_unicode_repr(self):
            invalid = InvalidPattern(self.msg)
            # ensure that the exception message is the expected one.
            self.assertEqual(str(invalid), self.msg)
            # and ensure that the unicode strings can be encoded to utf8
            # if they can't, this assertion will fail.
           

# Generated at 2022-06-12 07:53:57.802908
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern"""
    from bzrlib.tests import TestCase
    class TestInvalidPattern(InvalidPattern):
        _fmt = 'TestMessage'

    testcase = TestCase()
    testcase.assertEquals('TestMessage', str(TestInvalidPattern('TestMessage')))
    testcase.assertEquals(
        'Unprintable exception TestInvalidPattern: '
        'dict={\'msg\': \'TestMessage\'}, fmt=\'TestMessage\', error=None',
        str(InvalidPattern('TestMessage')))