

# Generated at 2022-06-12 07:44:07.693124
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = 'msg'
    exception = InvalidPattern(msg)
    result = unicode(exception)
    assert isinstance(result, unicode)



# Generated at 2022-06-12 07:44:18.736293
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test Unicode conversion of InvalidPattern"""
    err = InvalidPattern('abc %s', 'def')
    err._preformatted_string = 'abc def'

    # The following 'u' prefix is only needed because without it Python
    # assumes that 'abc def' is a ascii string and converts it to a unicode
    # string by encoding it with the ascii codec.
    # >>> u'abc'.__class__.__name__
    # 'unicode'
    # >>> 'abc'.__class__.__name__
    # 'str'
    UnicodeStr = u'abc def'
    assert isinstance(err.__unicode__(), UnicodeStr)

    # Should work if the string is already unicode
    err = InvalidPattern('abc %s', u'def')
    err._preformatted_string = UnicodeStr

# Generated at 2022-06-12 07:44:23.632220
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ returns a unicode string"""
    msg1 = 'msg1'
    e1 = InvalidPattern(msg1)

    # __unicode__ should return unicode
    result1 = e1.__unicode__()
    assert isinstance(result1, unicode), \
        "__unicode__() should return a unicode object"

    # result1 should be the same as msg1, but decoded
    assert result1 == msg1.decode('utf8'), \
        "result1 should be the same as msg1, but decoded"

    msg2 = u'msg2'
    e2 = InvalidPattern(msg2)
    assert e2.__unicode__() == msg2, \
        "e2.__unicode__() should be the same as msg2"


# Generated at 2022-06-12 07:44:26.586684
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test ..class::InvalidPattern.__unicode__"""
    try:
        raise InvalidPattern('foo')
    except InvalidPattern as e:
        assert e.__unicode__() == 'foo'



# Generated at 2022-06-12 07:44:36.152746
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """
    Test InvalidPattern.__str__()
    """
    from bzrlib.i18n import gettext
    import sys
    if sys.version_info[0] > 2:
        unicode_type = str
    else:
        unicode_type = unicode
    # exemples for unit tests taken from bzrlib.i18n.py
    assert gettext('gettext') == 'gettext'
    assert gettext(b'gettext') == 'gettext'
    assert gettext('gettext%s') == 'gettext%s'
    assert gettext('gettext%s') % '!@#' == 'gettext!@#'
    assert gettext(unicode_type('gettext%s')) % '!@#' == 'gettext!@#'

# Generated at 2022-06-12 07:44:37.103953
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:44:46.273593
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from cStringIO import StringIO
    import sys

    class Exc(InvalidPattern):
        pass

    # unicode message
    e = Exc(u"unicode")
    s = unicode(e)
    # only unicode is supported by setattr in Python 2.4
    e._fmt = u"preformatted %(msg)s"
    s1 = unicode(e)
    assert s != s1, "%s != %s" % (s, s1)

    # unicode message and unicode format
    e = Exc(u"unicode")
    e._fmt = u"preformatted %(msg)s"
    s = unicode(e)
    # overwrite the preformatted message
    e._fmt = u"new unicode format"
    s1 = unicode(e)
    assert s

# Generated at 2022-06-12 07:44:50.605252
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test string representation of InvalidPattern exception."""
    error = InvalidPattern(msg="test")
    str_error = str(error)
    expected = ('Invalid pattern(s) found. test')
    assert str_error == expected



# Generated at 2022-06-12 07:45:00.152577
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """This test fails with python2.7, which is why we have it here.

    python2.7 is not supported by bzrlib anyway.
    """
    from bzrlib.i18n import _i18n_pygettext
    msg = _i18n_pygettext(u"Invalid pattern(s) found. %(msg)s")
    assert isinstance(msg, unicode)
    s = InvalidPattern(u'foo bar')
    with_encoding = (u'Unprintable exception InvalidPattern: dict={'
        '"msg": "foo bar"}, fmt=Invalid pattern(s) found. %(msg)s, error=None')
    assert unicode(s) == with_encoding

# Generated at 2022-06-12 07:45:04.680895
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ for InvalidPattern returns str, not unicode"""
    class TestException(InvalidPattern):
        _fmt = "TestException: %(msg)s"

    exc = TestException('hello world')
    s = str(exc)
    assert isinstance(s, str)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:45:17.013284
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should work."""
    from bzrlib.i18n import _i18n_py_aware_gettext as gettext
    def check_obj(obj, expected_result):
        if obj.__str__() != expected_result:
            raise AssertionError("%s.__str__() returned %s instead of %s" %
                                 (obj.__class__.__name__, obj.__str__(), expected_result))
    def check_str(str, expected_result):
        check_obj(InvalidPattern(str), expected_result)
    check_str("msg", "msg")
    check_str("", "")
    # By default, the format method of the exception returns the _fmt string,
    # which is the same as the __str__ method. But this is not the

# Generated at 2022-06-12 07:45:26.369751
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern should not raise error if _fmt has not
    been translated yet.
    """
    from bzrlib import i18n
    # Make sure we don't translate _fmt to force __unicode__ to use
    # _get_format_string and return _fmt as is.
    i18n.set_translator(i18n.Translator())
    msg = "A message"
    e = InvalidPattern(msg)
    try:
        __ = unicode(e)
    finally:
        # restore translator
        i18n.set_translator(i18n.get_global_translator())

# Generated at 2022-06-12 07:45:28.916631
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    return doctest.DocTestSuite(optionflags=doctest.ELLIPSIS,
                                checker=doctest.OutputChecker())

# Generated at 2022-06-12 07:45:38.732636
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for InvalidPattern.__unicode__

    When __unicode__ returns non unicode, it should be decoded automatically.
    When __unicode__ returns unicode, it should be kept so.
    When __unicode__ returns non string object, it should be converted to
    unicode.
    """

    def _check_unicode(obj, expected):
        unicode_result = unicode(obj)
        # __unicode__ should return unicode
        assert isinstance(unicode_result, unicode)
        assert unicode_result == expected

    class InvalidPatternWithNonUnicodeReturn(InvalidPattern):
        """__unicode__() returns non unicode string 'a'"""
        def __unicode__(self):
            return 'a'

# Generated at 2022-06-12 07:45:48.463400
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for __unicode__() method of InvalidPattern class."""
    expr = u"1 + 2 + ВЗРЫВ"

    # Test limited size of error message
    error = InvalidPattern('a' * 20000 + 'b')
    error2 = InvalidPattern('a' * 20000 + 'b')
    assert error == error2
    assert str(error) == str(error2)
    assert unicode(error) == unicode(error2)
    assert str(error) == 'a' * (1024 - len('Invalid pattern(s) found. ')) + 'b'
    assert unicode(error) == u'a' * (1024 - len('Invalid pattern(s) found. ')) + u'b'

    # Test that the message is correctly decoded
    error = InvalidPattern(expr)


# Generated at 2022-06-12 07:45:59.550464
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """A test for method __str__ of class InvalidPattern"""
    class SubInvalidPattern(InvalidPattern):
        _fmt = '%(msg)s'

    e = SubInvalidPattern('spam')

    # test for values that are str and unicode
    for value in ['spam', u'spam']:
        e.msg = value
        assert str(e) == 'spam'
        assert unicode(e) == u'spam'

    # tests for non string and non unicode values
    class Foo(object):
        def __str__(self):
            return 'spam'

        def __unicode__(self):
            return u'spam'

    e.msg = Foo()
    assert str(e) == 'spam'
    assert unicode(e) == u'spam'


# test

# Generated at 2022-06-12 07:46:07.348371
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests.blackbox import ExternalBase

    class _InvalidPattern(InvalidPattern):
        _fmt = u"Incorrect number %(incorrect_number)d"

    class TestInvalidPattern(ExternalBase):

        def test_InvalidPattern___str__(self):
            e = _InvalidPattern(incorrect_number=1)
            self.assertEqualDiff(str(e), 'Incorrect number 1')

    from bzrlib.tests import TestUtil
    TestUtil.test_suite().addTest(
        TestUtil.TestLoader().loadTestsFromTestCase(TestInvalidPattern))

# Generated at 2022-06-12 07:46:15.678939
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """__setstate__ method should restore a LazyRegex object correctly.
    """
    p = re.compile('(a+)*b')
    unserialized_proxy = LazyRegex()
    unserialized_proxy.__setstate__({'args': [], 'kwargs': {}})
    unserialized_proxy.__setstate__({'args': ('(a+)*b',), 'kwargs': {}})
    assert unserialized_proxy == p, "unserialized_proxy should be equal to p"

# Generated at 2022-06-12 07:46:25.145818
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    msg = 'Invalid pattern(s) found. %(msg)s'
    err = InvalidPattern('test')
    err._fmt = msg
    err._preformatted_string = None
    assert err._preformatted_string is None
    assert err._get_format_string() is None
    assert u'Invalid pattern(s) found. test' == err.__unicode__()
    assert 'Invalid pattern(s) found. test' == str(err)
    assert 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None' == repr(err)
    err._preformatted_string = 'preformatted'
    assert u'preformatted' == err.__unicode__()
    # preformatted, even if not unicode
    err._

# Generated at 2022-06-12 07:46:29.118664
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    # test that the method returns a str object
    err = InvalidPattern('some error')
    assert isinstance(err.__str__(), str)


# Generated at 2022-06-12 07:46:37.108180
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # Check method __str__ returns a str, not unicode
    # (method __str__ must return str, not unicode)
    e = InvalidPattern('message')
    assert isinstance(str(e), str)
    # Check method __str__ and method __unicode__ return the same
    # (method __str__ must return str(__unicode__()))
    assert unicode(e) == str(e)


# Generated at 2022-06-12 07:46:47.588373
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # check __str__() returns a str object
    s = InvalidPattern('msg')
    str(s)
    # check __str__() returns a str in the default encoding
    s = InvalidPattern('r\xe9sum\xe9')
    str(s)
    # check __str__() returns a str for a unicode object
    s = InvalidPattern('foobar')
    s._fmt = u'foobar'
    str(s)
    # check __str__() returns a str for a unicode object with a UnicodeError
    s = InvalidPattern('foobar')
    s._fmt = u'foobar\xe9'
    str(s)
    # check __str__() returns a str for a preformatted string
    s = InvalidPattern('foobar')

# Generated at 2022-06-12 07:46:59.247830
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test that __unicode__ of an UnicodeError gives a message as expected.
    from bzrlib import tests, i18n
    tests.TestCase.tearDown(None)

# Generated at 2022-06-12 07:47:03.516252
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import unittest

    class TestCase(unittest.TestCase):
        def test___unicode__(self):
            from bzrlib import _trace
            self.assertEqual(
                unicode(InvalidPattern('fake_msg')), u'fake_msg')
            s = 'Unprintable exception InvalidPattern: dict={}, fmt=%(msg)s, ' \
                'error=None' % dict(msg='fake_msg')
            self.assertEqual(
                unicode(InvalidPattern('fake_msg')),
                unicode(s))

    import bzrlib.tests.test_builtins
    bzrlib.tests.test_builtins.TestCase.__name__ = 'TestCase'
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    unitt

# Generated at 2022-06-12 07:47:10.990688
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern"""
    try:
        raise InvalidPattern(None)
    except InvalidPattern as e:
        assert e.__str__() == 'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    try:
        raise InvalidPattern('message')
    except InvalidPattern as e:
        assert e.__str__() == 'Unprintable exception InvalidPattern: dict={}, fmt=%(msg)s, error=None'

# Generated at 2022-06-12 07:47:19.222834
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Method __unicode__ of class InvalidPattern

    This unit test checks to make sure that InvalidPattern.__unicode__
    returns a unicode object. Since we should strive to always use unicode
    objects in bzrlib.
    """
    # test a easy simple case
    msg = "This is a error message"
    ip = InvalidPattern(msg)
    text = ip.__unicode__()
    assert(type(text) == type(u''))
    assert(text == u"This is a error message")
    # test with a unicode argument
    # from http://www.columbia.edu/~fdc/utf8/
    # the french words 'Levitra, c\'est pas grave'
    msg = u'Levitra, c\'est pas grave'
    ip = InvalidPattern(msg)
    text

# Generated at 2022-06-12 07:47:21.199799
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    try:
        raise InvalidPattern('testing')
    except InvalidPattern as e:
        s = str(e)
        assert s == 'testing', 'got %r' % (s,)
    else:
        raise AssertionError('InvalidPattern() not raised')

# Generated at 2022-06-12 07:47:32.283517
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ for InvalidPattern should return non-empty unicode()"""

    # Create some non-printable characters in 's'
    s = '\n'.join(['\xc3\xa1' for i in xrange(10)])
    ip = InvalidPattern(s)
    assert isinstance(unicode(ip), unicode)
    assert len(unicode(ip)) > 0

    # Test a string that is not a str or unicode object
    ip = InvalidPattern(u'\x01')
    assert len(unicode(ip)) > 0

    # Test that FormatException.__str__ returns an str object
    ip = InvalidPattern(u'\x01')
    assert len(str(ip)) > 0

    # Test that Exception.__str__ returns an str object

# Generated at 2022-06-12 07:47:36.420698
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ should return a unicode string"""
    try:
        raise InvalidPattern('A test message')
    except InvalidPattern as e:
        u = unicode(e)
        assert isinstance(u, unicode)



# Generated at 2022-06-12 07:47:42.773540
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """invalid pattern strings must not be unicode
    # FIXME: This test is not portable.
    # It should use bzrlib.tests.TestCase.assertRaises
    """
    ip = InvalidPattern('a')
    try:
        unicode(ip)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError(
            'str is unicode, we should not have been able to decode it.')

# Generated at 2022-06-12 07:47:57.951748
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test the public method InvalidPattern.__str__.

    verify:
      - str(InvalidPattern()) returns a string.
      - repr(InvalidPattern()) returns a string representation of InvalidPattern()
    """
    from bzrlib.i18n import gettext

    msg = "Invalid pattern(s) found. '%(msg)s'"
    msg_expected = gettext(unicode(msg))
    ip = InvalidPattern('test')
    s = ip.__str__()
    if not isinstance(s, str):
        raise AssertionError("Invalid pattern returned an invalid string value.")
    u = ip.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError("Invalid pattern returned an invalid unicode value.")
    # use the same test for str() and repr() but with a different message

# Generated at 2022-06-12 07:47:59.465637
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    e = InvalidPattern('foo')
    assert unicode(e) == 'foo'


# Generated at 2022-06-12 07:48:04.975720
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    import bzrlib.errors

    suite = doctest.DocTestSuite(bzrlib.errors)
    runner = doctest.DocTestRunner()
    result = runner.run(suite)
    if not result.wasSuccessful():
        raise Exception("%d of %d tests failed" % (len(result.failures),
            result.attempted))

# Generated at 2022-06-12 07:48:08.333217
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test __getattr__ method of class LazyRegex"""
    if LazyRegex.__getattr__.__name__ != '__getattr__':
        raise AssertionError("Test error")


# Generated at 2022-06-12 07:48:17.686975
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ must compile the real regex and return the requested
    attribute, even if it is a callable.
    """
    from bzrlib import (
        lazy_regex,
        tests,
        )
    from bzrlib.tests import (
        features,
        test_patterns,
        )

    # We could use an asymmetric mock object, but it's easier to just
    # replace the real re.compile with a function that returns a known
    # (fake) regex object.
    # The test is also faster this way.
    regex = re._pattern_type

    def fake_compile(*args, **kwargs):
        return regex(args[0])

    lazy_regex._real_re_compile = fake_compile

    # Install lazy_compile
    lazy_regex.install

# Generated at 2022-06-12 07:48:26.737451
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Test a message that doesn't need decoding
    ex = InvalidPattern('something')
    ex._preformatted_string = 'something'
    assert isinstance(ex.__unicode__(), unicode)
    assert ex.__unicode__() == u'something'
    # Test a message that needs decoding
    ex = InvalidPattern('something')
    ex._preformatted_string = 'something'.encode('utf8')
    assert isinstance(ex.__unicode__(), unicode)
    assert ex.__unicode__() == u'something'
    # Test a message that needs encoding to unicode
    ex = InvalidPattern('something')
    ex._preformatted_string = u'something'
    assert isinstance(ex.__unicode__(), unicode)
    assert ex.__unicode__() == u'something'

# Generated at 2022-06-12 07:48:29.463724
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern class should have method __str__ implemented."""
    e = InvalidPattern('message')
    str(e)

# Generated at 2022-06-12 07:48:32.085936
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import errors
    doctest.testmod(errors, verbose=True)

# Generated at 2022-06-12 07:48:35.577134
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """There should be a method __str__ which should return an unicode value."""
    from bzrlib.i18n import gettext
    gettext.install('bzr')
    e = InvalidPattern('error message')
    str(e)

# Generated at 2022-06-12 07:48:47.075987
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern.

    This test of class InvalidPattern is in module lazy_regex since
    class InvalidPattern is defined only in that module
    """
    from bzrlib.tests import TestCase

    class Test__str__(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.msg = 'Unprintable exception %s: dict=%r, fmt=%r, error=%r' \
                % (InvalidPattern.__name__,
                    InvalidPattern.__dict__,
                    getattr(InvalidPattern, '_fmt', None),
                    None)

        def test___str__(self):
            ip = InvalidPattern('msg')
            self.assertEqualDiff(str(ip), self.msg)


# Generated at 2022-06-12 07:48:54.986274
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    msg = "this is a test message"
    err = InvalidPattern(msg)
    eq = unicode(err)
    assert eq == u"Invalid pattern(s) found. this is a test message"


# Generated at 2022-06-12 07:49:02.312189
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    old_gettext = gettext
    try:
        def gettext_debug(msg):
            return msg
        gettext = gettext_debug
        e = InvalidPattern('foo %(bar)s')
        e.bar = 'baz'
        if unicode(e) != u'foo baz':
            raise AssertionError(
                "method __unicode__ of class InvalidPattern produces wrong "
                "output: %r" % unicode(e))
    finally:
        gettext = old_gettext

# Generated at 2022-06-12 07:49:06.852398
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    # Create a LazyRegex
    r = LazyRegex()
    # Access an attribute
    r.split('pattern', 'a string')
    # The attribute must have been copied
    assert getattr(r, 'split') is getattr(r._real_regex, 'split')


# Some tests for the pickling cases

# Generated at 2022-06-12 07:49:17.774152
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() returns unicode or str

    InvalidPattern.__str__() should always return a str or a unicode.
    It should never return a lazy_regex.
    """

    # For example InvalidPattern.__str__() should not return a
    # lazy_regex when it is used as part of a unicode string.
    from bzrlib.tests.blackbox import TestCaseWithTransport
    class _TestCaseWithTransport(TestCaseWithTransport):

        def test_InvalidPattern___str__(self):
            pattern = LazyRegex(["unterminated.*"])

# Generated at 2022-06-12 07:49:25.446771
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__() returns the correct string."""

    class _TestInvalidPattern(InvalidPattern):
        _fmt = '%(msg)s'

    test_pattern = _TestInvalidPattern('test message')
    if str(test_pattern) != 'test message':
        raise AssertionError('__str__() should return the correct string. '
                             '%s != test message' % str(test_pattern))

# Generated at 2022-06-12 07:49:31.210213
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern returns a str object"""
    class TestException(InvalidPattern):
        _fmt = u'TestException'
        def __init__(self):
            self.args = ('foo',)

    # Test that __str__ is not unicode and contains some string
    str_obj = str(TestException())
    assert isinstance(str_obj, str)
    assert len(str_obj) > 0

# Generated at 2022-06-12 07:49:33.202167
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of class InvalidPattern is tested."""
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:49:42.973627
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test for method __str__ of class InvalidPattern"""
    from bzrlib import (
        gettext,
        )
    from bzrlib._gettext import lgettext
    msg = 'my_msg'
    expected_result = 'my_msg'
    ip = InvalidPattern(msg)
    result = ip.__str__()
    assert result == expected_result

    from bzrlib._gettext import gettext
    msg = 'my_msg'
    ip._fmt = 'Unable to continue. %(msg)s'
    expected_result = 'Unable to continue. my_msg'
    result = ip.__str__()
    assert result == expected_result

    msg = u'my_msg'
    ip._fmt = 'Unable to continue. %(msg)s'
    expected

# Generated at 2022-06-12 07:49:54.115734
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit tests for InvalidPattern.__unicode__"""
    # Test case 1
    exc = InvalidPattern('invalid regex')
    expected = u"Invalid pattern(s) found. invalid regex"
    actual = unicode(exc)
    assert actual == expected, "Actual: %r, Expected: %r" % (actual, expected)

    # Test case 2
    exc = InvalidPattern('invalid regex')
    exc._fmt = '%(msg)s'
    expected = u"invalid regex"
    actual = unicode(exc)
    assert actual == expected, "Actual: %r, Expected: %r" % (actual, expected)

    # Test case 3
    exc = InvalidPattern('invalid regex')
    exc._fmt = '%(msg)s'

# Generated at 2022-06-12 07:49:56.839258
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = 'empty patterns not allowed'
    e = InvalidPattern(msg)
    assert str(e) == 'Invalid pattern(s) found. empty patterns not allowed'

# Generated at 2022-06-12 07:50:06.895724
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern uses _format()"""
    class InvalidPattern(InvalidPattern):
        """Test class for InvalidPattern"""
        def _format(self):
            return unicode('Text for _format')

    ip = InvalidPattern('This does not matter')
    assert_(ip.__unicode__() == unicode('Text for _format'))



# Generated at 2022-06-12 07:50:14.400793
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    def str(x):
        return unicode(x).encode('utf8')
    assert str(InvalidPattern(unicode('foo'))) == str('foo')
    assert str(InvalidPattern('foo')) == str('foo')
    assert str(InvalidPattern(u'foo')) == str('foo')

    assert str(InvalidPattern('foo\nbar')) == str('foo\nbar')
    assert str(InvalidPattern(u'foo\nbar')) == str('foo\nbar')

    # An invalid byte sequence still results in a unicode error.
    assert str(InvalidPattern('foo\xffbar')) == str('foo\xffbar')
    assert str(InvalidPattern('foo\xffbar')) == str('foo\xffbar')

    assert repr(InvalidPattern(unicode('foo'))) == repr('foo')
   

# Generated at 2022-06-12 07:50:19.185981
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    def _test(msg):
        x = InvalidPattern(msg)
        unicode(x)
    # should not raise UnicodeEncodeError
    _test(gettext('abc'))



# Generated at 2022-06-12 07:50:23.862674
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test of method __unicode__ of class InvalidPattern."""
    msg = 'regular expression too large'
    exc = InvalidPattern(msg)
    u = exc.__unicode__()
    assert isinstance(u, unicode)
    assert msg in u
    assert exc.msg == u


# Generated at 2022-06-12 07:50:31.741990
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from cStringIO import StringIO
    from bzrlib import trace
    old_stderr = trace._stderr
    old_stdout = trace._stdout
    try:
        trace._stdout = new_stdout = StringIO()
        trace._stderr = new_stderr = StringIO()
        try:
            raise InvalidPattern(u"\xe9")
        except InvalidPattern as e:
            trace.warning(e)
            trace.note(e)
            trace.info(e)
    finally:
        trace._stderr = old_stderr
        trace._stdout = old_stdout
    new_stderr.seek(0)
    new_stdout.seek(0)
    stderr_content = new_stderr.read()

# Generated at 2022-06-12 07:50:34.254430
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # __unicode__() should return a unicode() object
    e = InvalidPattern('msg')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-12 07:50:40.919204
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ must always return unicode"""
    class DummyException(InvalidPattern):
        _fmt = 'foo: %(msg)s'
    from bzrlib.tests import TestCase

    TestCase.skipIf(not hasattr(DummyException, '__unicode__'),
                    'No __unicode__ method in Python 2.4')

    exc = DummyException('bar')
    TestCase.assertEqual(u'foo: bar', unicode(exc))



# Generated at 2022-06-12 07:50:45.582518
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test__InvalidPattern___unicode__.

    With this test for unicode we are also testing repr which is a
    method that is used in the __unicode__ method.
    This is a doctest.
    >>> from bzrlib.lazy_regex import InvalidPattern
    >>> _ = InvalidPattern("test")
    """


# Generated at 2022-06-12 07:50:50.260350
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the InvalidPattern.__unicode__() method.

    This method should return a 'unicode' object.
    """
    error = InvalidPattern('Invalid regular expression')
    u = unicode(error)
    assert isinstance(u, unicode), "__unicode__() should always return a 'unicode' object not: %r" % u

# Generated at 2022-06-12 07:50:57.278489
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests.per_errors import TestCaseWithTransport

    class test_InvalidPattern(TestCaseWithTransport):
        def test___str__(self):
            import bzrlib.errors
            error = bzrlib.errors.InvalidPattern(
                                    'illegal multibyte sequence')
            self.assertEqual(str(error),
                'illegal multibyte sequence')

# Generated at 2022-06-12 07:51:06.582936
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object"""
    from bzrlib.i18n import gettext
    msg = 'Bridge over troubled water'
    e = InvalidPattern(msg)
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == msg
    assert u == gettext(u)
    assert str(u) == msg



# Generated at 2022-06-12 07:51:16.520722
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    # No _fmt string, no error
    e = InvalidPattern(None)
    gettext(unicode(e)) # Should not raise UnicodeEncodeError
    # No _fmt string, with error argument
    e = InvalidPattern(None, error='error message')
    gettext(unicode(e)) # Should not raise UnicodeEncodeError
    # With _fmt string, no error
    e = InvalidPattern('error message')
    gettext(unicode(e)) # Should not raise UnicodeEncodeError
    # With _fmt string, with error
    e = InvalidPattern('error %%(error)s message', error='internal')
    gettext(unicode(e)) # Should not raise UnicodeEncodeError
    # With _fmt string, with error, no gettext
   

# Generated at 2022-06-12 07:51:28.231468
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Method __str__ of InvalidPattern class must be return a str object."""
    s = 'a'
    # Unicode is not a subclass of a str object
    u = unicode(s)
    s = InvalidPattern(s)
    assert isinstance(s, InvalidPattern)
    assert isinstance(s, Exception)
    assert isinstance(s.__str__(), str)
    assert not isinstance(s.__str__(), unicode)
    s = InvalidPattern(u)
    assert isinstance(s, InvalidPattern)
    assert isinstance(s, Exception)
    assert isinstance(s.__str__(), str)
    assert not isinstance(s.__str__(), unicode)
    # Check if we can print the exception
    try:
        raise InvalidPattern(s)
    except InvalidPattern as e:
        print

# Generated at 2022-06-12 07:51:31.052451
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod(name="__str__", optionflags=doctest.ELLIPSIS,
                    extraglobs={'InvalidPattern': InvalidPattern})

# Generated at 2022-06-12 07:51:41.979575
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """__unicode__ of InvalidPattern should return utf-8"""
    from bzrlib.i18n import gettext
    from bzrlib.i18n import bzrlib_i18n_config
    from bzrlib.i18n import i18n_stub
    from bzrlib.tests import TestCase
    import os
    import sys

    class Test(TestCase):
        """Test class for test_InvalidPattern___unicode__"""

        def setUp(self):
            """Setup basic internationalization to test InvalidPattern"""
            TestCase.setUp(self)
            i18n_stub.enable_fake()
            bzrlib_i18n_config._setup_translation()

        def tearDown(self):
            TestCase.tearDown(self)
            i18n_st

# Generated at 2022-06-12 07:51:49.878736
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.trace import mutter
    mutter("""
        Note for translators: to run the tests for this module, you need to
        load the full lp:bzr module.
    """)
    assert str(InvalidPattern("a test")) == "Invalid pattern(s) found. a test"
    assert unicode(InvalidPattern("a test")) == u"Invalid pattern(s) found. a test"
    msg = str(InvalidPattern("\xe7 is a c with a cedilla"))
    assert u"is a c with a cedilla" in unicode(msg, 'utf8')
    assert "is a c with a cedilla" not in str(msg)
    assert str(InvalidPattern("\xe7 is a c with a cedilla".decode('utf8'))) == msg



# Generated at 2022-06-12 07:52:00.098511
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext, set_output_encoding
    # gettext and set_output_encoding are used to simulate the correct
    # I18N environment
    import sys

    # Tests without i18n
    e = InvalidPattern(None)
    # Set preformatted string for error message
    e._preformatted_string = "preformatted message"
    # __unicode__ should return preformatted message, if it is unicode
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u"preformatted message"
    # Test __str__ method
    s = e.__str__()
    assert isinstance(s, str)
    assert s == u"preformatted message"

    # Error message unicode
    e = InvalidPattern

# Generated at 2022-06-12 07:52:03.377064
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    doctest.testmod()


__all__ = ['lazy_compile', 'install_lazy_compile', 'reset_compile']

# Generated at 2022-06-12 07:52:10.869301
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """test that InvalidPattern.__str__ makes a valid str."""
    def check_invalid_pattern(msg):
        exc = InvalidPattern(msg)
        result = str(exc)
        assert isinstance(result, str)
    check_invalid_pattern(u'invalid regexp: nothing to repeat at position 10')
    check_invalid_pattern(u"unbalanced parenthesis")
    check_invalid_pattern(u'bad character in group name')
    check_invalid_pattern(u'syntax error at position 0')
    check_invalid_pattern(u'unterminated character set at position 0')

# Generated at 2022-06-12 07:52:21.159749
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext

    gettext.setup_testing_defaults()

    # test object with no attributes
    ip = InvalidPattern(None)
    u = ip.__unicode__()
    assert u == u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None'
    # an object which has an _fmt attribute
    ip = InvalidPattern('msg2')
    ip._fmt = 'Hello %(msg)s'
    u = ip.__unicode__()
    assert u == u'Hello msg2'
    # an object which has an error attribute
    ip = InvalidPattern('msg3')
    ip._fmt = 'Hello %(msg)s'
    ip.error = 'error1'
    u = ip.__unicode__()
    assert u == u

# Generated at 2022-06-12 07:52:29.960982
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ should compile and return the requested attribute."""
    regex = LazyRegex(('hello'))
    assert regex._real_regex is None
    assert regex == 'hello'
    assert regex.findall('') == []
    assert regex._real_regex == _real_re_compile('hello')

# Generated at 2022-06-12 07:52:34.592440
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    class MyInvalidPattern(InvalidPattern):
        """The class to test."""
        _fmt = "This is the format."
    expected_string = "This is the format."
    my_exception = MyInvalidPattern("This is the message.")
    my_exception_str = str(my_exception)
    my_exception_str_str = str(my_exception_str)
    assert my_exception_str == expected_string
    assert my_exception_str_str == expected_string

# Generated at 2022-06-12 07:52:41.922933
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    msg = u"\u1234"
    e = InvalidPattern(msg)
    if msg != e.__unicode__():
        raise AssertionError("__unicode__ did not return the same string")
    # set a new format string that is not ascii
    e._fmt = gettext(msg)
    # and finally test the format string
    if e.__unicode__() != u"\u1234 " + msg:
        raise AssertionError("__unicode__ did not return the same string")


# Generated at 2022-06-12 07:52:53.314541
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.tests.blackbox import ExternalBase

    class TestInvalidPattern_unicode(ExternalBase):
        """Unit test for InvalidPattern.__unicode__"""

        def test_unicode_exceptions_with_preformatted_string(self):
            class UnicodeException(Exception):

                def __init__(self, str):
                    Exception.__init__(self)
                    self._preformatted_string = str

            e = UnicodeException("some exception")

            # Ensure that it is the preformatted string that is returned from
            # __str__ and __unicode__ and repr().
            self.assertEqual("some exception", str(e))
            self.assertEqual('some exception', e.__unicode__())
            self.assertEqual("UnicodeException('some exception',)", repr(e))


# Generated at 2022-06-12 07:53:00.961803
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Check that InvalidPattern.__unicode__() always returns a unicode string.
    """
    def _test_InvalidPattern___unicode__(self):
        # Ensure __unicode__() returns a unicode string, not a
        # 'str' object.
        u = self.__unicode__()
        self.assertIsInstance(u, unicode)
        return u

    # First, try with a preformatted string that is already a
    # unicode string, and that has explicit formatting substitutions.
    # This is in fact the usual case.
    ip = InvalidPattern('%s : %s')
    ip._preformatted_string = u'a unicode string'
    ip.a = 'a'
    ip.b = 'b'
    _test_InvalidPattern___unicode__(ip)

    # Then,

# Generated at 2022-06-12 07:53:09.838285
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return a unicode string, even
    if the original message was a str.
    """
    e = InvalidPattern('bad things occured')
    assert(isinstance(unicode(e), unicode))
    e = InvalidPattern(u'bad things occured')
    assert(isinstance(unicode(e), unicode))
    # an error in the original message should be reported
    e = InvalidPattern(u'bad things occured %s' % u'\xe9')
    assert(isinstance(unicode(e), unicode))

# Generated at 2022-06-12 07:53:16.081727
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that exceptions implement __str__ without raising exceptions.

    We cannot assert the exact message as it is translated.
    """
    msg = "some message"
    s = str(InvalidPattern(msg))
    assert s.startswith('Invalid pattern(s) found. "')
    assert msg in s
    assert s.endswith('"')

    # string is preformatted
    s = str(InvalidPattern('"%s"'))
    assert s.startswith('Invalid pattern(s) found. ')
    assert s.endswith('"%s"')
    # not a string
    s = str(InvalidPattern(None))
    assert s == 'Unprintable exception InvalidPattern: dict=%r, fmt=%r, error=%r'\
        % (None, None, None)
    # not a string

# Generated at 2022-06-12 07:53:22.874620
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ must return a str object"""

    # Test the case where _get_format_string returns a str
    e = InvalidPattern('msg')
    e._fmt = '%(msg)s'
    s = str(e)
    assert isinstance(s, str), "%r is not an instance of str" % s
    assert s == 'msg', "%r != 'msg'" % s

    # Test the case where _get_format_string returns a unicode
    e = InvalidPattern('msg')
    e._fmt = u'%(msg)s'
    s = str(e)
    assert isinstance(s, str), "%r is not an instance of str" % s
    assert s == 'msg', "%r != 'msg'" % s

    # Test the case where _get_format_string returns None
    e

# Generated at 2022-06-12 07:53:27.189394
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import doctest
    from bzrlib import tests
    tests.set_memcached_support(False)
    try:
        return doctest.DocTestSuite('bzrlib.regex._lazy_re')
    except TypeError:
        # bug in unittest, see https://bugs.launchpad.net/bugs/366887
        return None



# Generated at 2022-06-12 07:53:36.596949
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ works"""
    from bzrlib.tests import TestCase
    from re import escape, IGNORECASE, VERBOSE, DOTALL, MULTILINE, I

    class Test_LazyRegex(TestCase):

        def test_LazyRegex___getattr__(self):
            #LazyRegex is a subclass of re._pattern_type
            self.assertTrue(issubclass(LazyRegex, re._pattern_type))
            #the class contains all methods
            #(except __getstate__ and __setstate__)
            #of the real _sre.SRE_Pattern.
            if hasattr(re, '_sre'):
                SRE_Pattern = re._sre.SRE_Pattern

# Generated at 2022-06-12 07:53:55.649781
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that InvalidPattern has a working __str__"""
    e = InvalidPattern('foo')
    if str(e) != 'Invalid pattern(s) found. foo':
        raise AssertionError('__str__ method failed. Got "%s" % (str(e),)')


# TODO: jelmer, 2009-03-12: The following tests are disabled due to failing
# on one of the bots. It's unclear why they fail as they pass locally on GNU/Linux.
# They may be access tests that manage to incur a race condition on
# Mac OS X.

# if sys.platform == "darwin":
#     # Unit test for method __unicode__ of class InvalidPattern
#     def test_InvalidPattern___unicode__():
#         """Test that InvalidPattern has a working __unicode__"""
#         e = InvalidPattern('

# Generated at 2022-06-12 07:53:57.850113
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # The __str__ method should return a str object.
    p = InvalidPattern(u'My Exception')
    str(p)

# Generated at 2022-06-12 07:54:06.171018
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    from bzrlib.i18n import gettext, install_gettext_translations
    import gettext as gettext_module
    from bzrlib import config
    from bzrlib.osutils import get_user_encoding
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import UnicodeFilenameFeature

    install_gettext_translations(gettext_module)
    u = u'This string contains a \u1234 character.'