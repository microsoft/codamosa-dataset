

# Generated at 2022-06-12 07:44:15.789782
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.trace import mutter, note
    def _gettext(x):
        return x
    # Test format string
    m = InvalidPattern('hello world')
    m._fmt = u'%(msg)s'
    assert 'hello world' == str(m)
    # Test format string in another language
    m = InvalidPattern('hello world')
    m._fmt = u'%(msg)s'
    old = gettext
    gettext = _gettext
    try:
        assert 'hello world' == unicode(m)
    finally:
        gettext = old

# Generated at 2022-06-12 07:44:20.197494
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """The method __unicode__ of class InvalidPattern should return
    an unicode object.
    """
    e = InvalidPattern('test')
    unicode(e)
    try:
        u = unicode(e)
    except UnicodeDecodeError:
        raise AssertionError(
            '__unicode__ of InvalidPattern should return an unicode object')

# Generated at 2022-06-12 07:44:26.943960
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test the method __unicode__ of the class InvalidPattern"""
    # pychecker complains if we don't use the function
    import bzrlib.lazy_regex; bzrlib.lazy_regex
    val = InvalidPattern(u"abc")
    expected = u"abc"
    assert val.__unicode__() == expected
    val = InvalidPattern(u"abc".encode('utf-8'))
    assert val.__unicode__() == expected
    val = InvalidPattern(u"U+%04X"%(0x10001))
    expected = u"U+10001"
    assert val.__unicode__() == expected


# Generated at 2022-06-12 07:44:32.884651
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """LazyRegex should compile and collapse when access a member.

    This test creates a LazyRegex object and access to one of its members
    (match) in order to test if works correctly when the object has not been
    compiled yet.
    """
    pattern = r'a'
    str_data = 'a'
    p = LazyRegex((pattern,))
    p.match(str_data)


# Generated at 2022-06-12 07:44:36.728721
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should produce a unicode object."""
    x = InvalidPattern("hello world")
    y = unicode(x)
    assert isinstance(y, unicode), 'expected a unicode object'

# Generated at 2022-06-12 07:44:41.288156
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Check the __unicode__ method of class InvalidPattern.
    This tests that the __unicode__ method returns the expected value.
    """
    msg = 'patterns are not allowed'
    e = InvalidPattern(msg)
    r = unicode(e)
    assert_equal(r, msg)

# Generated at 2022-06-12 07:44:45.210842
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib import trace
    import sys
    old_stdout = sys.stdout

# Generated at 2022-06-12 07:44:49.759559
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    error = InvalidPattern('test message')
    # str method should return an encoded string
    assert isinstance(unicode(error), unicode)
    # str method should return an encoded string
    assert isinstance(str(error), str)

# Module level unit test


# Generated at 2022-06-12 07:45:00.767551
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Test for method __setstate__ of class LazyRegex."""
    from bzrlib.tests import TestCase
    from bzrlib.tests.per_regular_expression import TestCaseWithRegularExpression
    class TestLazyRegex(TestCaseWithRegularExpression):
        """Test case for method __setstate__ of class LazyRegex."""

        def testLazyRegex___setstate__(self):
            """Test LazyRegex.__setstate__"""
            obj = LazyRegex(self.regex_args, self.regex_kwargs)
            obj.__setstate__(obj.__getstate__())
            self.assertEqualDiff(obj.__getstate__(), {'args':self.regex_args, 'kwargs':self.regex_kwargs})

    return TestL

# Generated at 2022-06-12 07:45:03.896220
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests the __unicode__ method of the InvalidPattern class"""
    pattern_invalid = InvalidPattern("Test message")
    assert unicode(pattern_invalid) == pattern_invalid._get_format_string()



# Generated at 2022-06-12 07:45:16.629177
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern."""
    # Tests of basic functionality
    import bzrlib.tests
    class TestCase(bzrlib.tests.TestCase):
        def test_result(self):
            # No _fmt and empty __dict__
            self.assertEqual(InvalidPattern('').__unicode__(), u'Unprintable exception InvalidPattern: dict={}, fmt=None, error=None')
            # _fmt and empty __dict__
            self.assertEqual(InvalidPattern('').__unicode__(), u'Invalid pattern(s) found. ')
            # _fmt with a single placeholder, and empty __dict__
            self.assertEqual(InvalidPattern('%(msg)s').__unicode__(), u'Invalid pattern(s) found. ')

    return

# Generated at 2022-06-12 07:45:22.746353
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test new InvalidPattern exception's __unicode__() method"""
    err = InvalidPattern('No valid pattern found')
    err.replacement_patterns = [
        ('bad-pattern', 'foo-bar', 'fixed pattern'),
    ]
    assert (unicode(err) ==
        'Invalid pattern(s) found. No valid pattern found\n'
        'Bad pattern: "bad-pattern" (use fixed pattern instead)')

# Generated at 2022-06-12 07:45:33.400272
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test that InvalidPattern.__str__ is compatible with python3.

    In python3, unicode strings are strings, in python2 they are not.
    """
    import sys
    class InvalidPatternTester(InvalidPattern):
        _fmt = 'unicode: %(u)s'
        def __init__(self, u):
            self.u = u

    i = InvalidPatternTester(u'\u1234')
    if sys.version_info[0] > 2:
        # In python3, unicode is a string.
        # The preformatted string should be unicode.
        assert isinstance(i.__str__(), unicode)
        assert u'unicode: \u1234' == i.__str__()

# Generated at 2022-06-12 07:45:41.696052
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method InvalidPattern.__unicode__"""
    failures = []
    def check(msg):
        try:
            raise InvalidPattern(msg)
        except InvalidPattern as e:
            u = unicode(e)
            if isinstance(u, unicode):
                pass
            else:
                failures.append('InvalidPattern.__unicode__ failed for '
                                'msg=%r, output=%r' % (msg, u))
    check(u'\N{GREEK SMALL LETTER ALPHA}\N{GREEK CAPITAL LETTER OMEGA}')
    check('abc')
    check(u'\N{GREEK SMALL LETTER ALPHA}\N{GREEK CAPITAL LETTER OMEGA}'
          'abc')

# Generated at 2022-06-12 07:45:46.948957
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib import lazy_regex
    msg = 'foo bar'
    e = lazy_regex.InvalidPattern(msg)
    # not sure what's best for gettext in the test...
    e._fmt = gettext(unicode(e._fmt))
    assert(unicode(e).find(msg) > 0)

# Generated at 2022-06-12 07:45:56.290364
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    if not hasattr(re, 'finditer'):
        # finditer() is not available.
        return
    try:
        # This call really wants a compiled regex, not a LazyRegex,
        # so it will raise an InvalidPattern exception
        re.finditer(LazyRegex(args=(), kwargs={}), '')
    except InvalidPattern as e:
        u = unicode(e)
        assert isinstance(u, unicode), \
            "__unicode__ should return 'unicode' object"
    else:
        raise AssertionError("InvalidPattern should have been raised")

# Generated at 2022-06-12 07:46:03.211239
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import doctest
    from bzrlib.tests import TestCase
    from bzrlib.errors import InvalidPattern
    import bzrlib.errors

    class _TestCase(TestCase):
        def test_InvalidPattern___unicode__(self):
            # _preformatted_string is ascii
            e = InvalidPattern('hello world')
            self.assertEqual(unicode(e), u'hello world')
            # _preformatted_string is unicode
            e = InvalidPattern(u'hello world')
            self.assertEqual(unicode(e), u'hello world')
            # the exception message has no _fmt
            e = InvalidPattern('hello world')
            e._fmt = None
            self.assertEqual(unicode(e), u'hello world')
            # the exception message has _

# Generated at 2022-06-12 07:46:10.212682
# Unit test for method __setstate__ of class LazyRegex
def test_LazyRegex___setstate__():
    """Unit test for method __setstate__ of class LazyRegex"""
    proxy = LazyRegex((r"hello",))
    assert not proxy._real_regex
    dict = proxy.__getstate__()
    # Restore from a pickled state
    proxy.__setstate__(dict)
    assert not proxy._real_regex
    assert dict["args"] == proxy._regex_args
    assert dict["kwargs"] == proxy._regex_kwargs

# Generated at 2022-06-12 07:46:20.765356
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern.

    See bug #464313 for details.
    """
    # test with a preformatted string
    error = InvalidPattern('[Ee]')
    error._preformatted_string = 'E'
    u = unicode(error)
    assert type(u) is unicode
    assert u == 'E'
    # test without a preformatted string
    error = InvalidPattern('[Ee]')
    u = unicode(error)
    assert type(u) is unicode
    assert u == u'Invalid pattern(s) found. "[Ee]"'
    # test with a non-ascii preformatted string
    error = InvalidPattern('[Ee]')
    error._preformatted_string = 'E\xe9'

# Generated at 2022-06-12 07:46:27.890868
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Unit test method __str__ of class InvalidPattern"""

    class C(InvalidPattern):
        _fmt = 'foo'

    ex = C('bar')
    try:
        str(ex)
    except UnicodeDecodeError:
        # As expected, since we're not passing any preformatted message
        pass
    else:
        raise AssertionError('Unable to raise UnicodeDecodeError')

    ex._preformatted_string = 'bar'
    try:
        str(ex)
    except UnicodeDecodeError:
        # As expected, since we're passing a preformatted message
        pass
    else:
        raise AssertionError('Unable to raise UnicodeDecodeError')

    ex._preformatted_string = u'bar'
    ex = C('bar')

# Generated at 2022-06-12 07:46:35.388694
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    exc = InvalidPattern('msg')
    try:
        raise InvalidPattern('msg')
    except InvalidPattern as exc:
        # the format of the message should be str
        assert isinstance(str(exc), str)
        assert isinstance(repr(exc), str)
        assert isinstance(exc.__unicode__(), unicode)

# Generated at 2022-06-12 07:46:39.075153
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__()."""
    exception = InvalidPattern('something')
    got = unicode(exception)
    expected = "Invalid pattern(s) found. something"
    if got != expected:
        raise AssertionError(got)


# Generated at 2022-06-12 07:46:49.082836
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    import sys
    err = InvalidPattern('hello')
    if sys.version_info < (3, 0):
        if str(err) != 'hello':
            raise AssertionError(str(err) + " != 'hello'")
    elif str(err) != "'hello'":
        raise AssertionError(str(err) + " != 'hello'")

    error = InvalidPattern(u'\xe9rror')
    if sys.version_info < (3, 0):
        if unicode(error) != u'\xe9rror':
            raise AssertionError(unicode(error) + " != '\xe9rror'")
    elif str(error) != "'\\xe9rror'":
        raise AssertionError(str(error) + " != '\\xe9rror'")

# Generated at 2022-06-12 07:47:00.520057
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """InvalidPattern.__str__ should return a str"""
    from bzrlib.i18n import gettext
    err = InvalidPattern('msg')
    s = u'Unprintable exception InvalidPattern: dict={}, fmt=%(msg)s, error=None'

    # __str__ should always return str, even if the message is Unicode
    # it should be encoded.
    assert(isinstance(err.__str__(), str))

    # If no format string that is used to create __str__,
    # it should return a string to give some info.
    assert(s == err.__str__())

    # Test that making a default unicode string, with fmt, works
    err = InvalidPattern('msg')
    err._fmt = u'Unprintable exception %(__class__)s, error = %(error)s'

# Generated at 2022-06-12 07:47:07.592313
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should always return a 'str'

    See http://doc.bazaar-vcs.org/latest/developers/api/re-lazy.html
    "3.3. Note about InvalidPattern.__str__()"
    """

# Generated at 2022-06-12 07:47:17.555778
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Check that the method InvalidPattern._format() returns a 'str', not a unicode.

    This is needed to support the method __str__ of class InvalidPattern
    and so be able to print InvalidPattern exceptions as strings (and
    not as objects).
    """
    # _preformatted_string is None
    format_string = 'Invalid pattern(s) found. "%(pattern)s" %(msg)s'
    e = InvalidPattern('"%(pattern)s" %(msg)s')
    e._fmt = format_string
    e.pattern = "invalid_pattern"
    e.msg = "invalid_msg"
    s = e._format()
    assert isinstance(s, str)
    # _preformatted_string is not None

# Generated at 2022-06-12 07:47:25.786754
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # test without parameters
    e = InvalidPattern('message')
    assert(e.__unicode__() == u'message')
    # test with parameters
    e = InvalidPattern('%(param1)s %(param2)s')
    e.param1 = 'message'
    e.param2 = '1'
    assert(e.__unicode__() == u'message 1')
    # test with some utf-8 encoded bytes
    e = InvalidPattern('%(param1)s')
    e.param1 = b'm' + chr(0xc3).encode('utf8') + chr(0xa4).encode('utf8')
    assert(e.__unicode__() == u'm\u00e4')

# Generated at 2022-06-12 07:47:32.534690
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests if method __unicode__ of class InvalidPattern returns a Unicode string.
    """
    import sys
    if sys.version_info[0] == 2:
        from bzrlib.pyutils import ensure_unicode
    else:
        from bzrlib.pyutils import ensure_unicode
    e = InvalidPattern('dummy message')
    assert isinstance(e, UnicodeError)


if __name__ == '__main__':
    test_InvalidPattern___unicode__()

# Generated at 2022-06-12 07:47:39.686475
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # This test makes sure that __str__() always returns a str object.
    err1 = InvalidPattern(u'some unicode message')
    err2 = InvalidPattern(u'\N{SNOWMAN}')
    err3 = InvalidPattern('some ascii message')
    assert isinstance(str(err1), str)
    assert isinstance(str(err2), str)
    assert isinstance(str(err3), str)



# Generated at 2022-06-12 07:47:47.503800
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Exercise __str__ method of InvalidPattern"""
    from bzrlib import lazy_regex_tests
    def check_str(e):
        # Check that this does not raise an exception
        str(e)
        unicode(e)
        repr(e)
        # Check that str does not produce unicode, and vice versa
        assert not isinstance(str(e), unicode)
        assert not isinstance(unicode(e), str)
    from bzrlib.i18n import gettext
    gettext("foo")
    # call again to make sure we are using cached version.
    gettext("foo")
    try:
        raise InvalidPattern("foo")
    except InvalidPattern as e:
        check_str(e)

# Generated at 2022-06-12 07:48:00.336800
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test for method __unicode__ of class InvalidPattern"""
    # Test for the behaviour of __unicode__ when the _fmt member is set
    from bzrlib.i18n import gettext
    from bzrlib import _i18n_pyx as _i18n
    # We have to use to use the correct domain to get a translated string.
    _i18n._set_domain('bzr')
    msg = 'Invalid pattern(s) found. Test'
    exception = InvalidPattern(msg)
    assert exception.__unicode__() == gettext(msg)
    # Test for the behaviour of __unicode__ when the _fmt member is not set
    exception._fmt = None

# Generated at 2022-06-12 07:48:07.694644
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.i18n import gettext
    from bzrlib.tests import TestCase
    class TC(TestCase):
        def get_format_string(self):
            return self.gettext('Invalid pattern(s) found. %(msg)s')
        def test__format(self):
            e = InvalidPattern('"abcdefg" ' + self.gettext('bad character range') + '.')
            self.assertEqual(str(e), self.gettext('Invalid pattern(s) found. "abcdefg" bad character range.'))
    test_suite = TestSuite()
    test_suite.addTest(
        load_tests(TC, [], None))
    return test_suite

# Generated at 2022-06-12 07:48:17.070041
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Test LazyRegex.__getattr__

    Make sure that LazyRegex.__getattr__ compile the regex and copy all the
    attributes from the real regex to LazyRegex.
    """
    re_compile = LazyRegex(args=('test[0-9]',))

    # check that the real regex is None and all attributes except the list in
    # LazyRegex._regex_attributes_to_copy are not yet copied.
    assert re_compile._real_regex is None
    for attr in re_compile._regex_attributes_to_copy:
        assert not hasattr(re_compile, attr)

    # compile the regex by accessing one of the attribute in
    # LazyRegex._regex_attributes_to_copy
    re_compile.match

# Generated at 2022-06-12 07:48:26.318196
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    def unix_test():
        try:
            raise InvalidPattern('test')
        except InvalidPattern as e:
            if isinstance(str(e), unicode):
                raise AssertionError(
                    "InvalidPattern.__str__ must return an str, not an unicode")
            elif not isinstance(str(e), str):
                raise AssertionError(
                    "InvalidPattern.__str__ must return an str, got %r"
                    % type(str(e)))
    unix_test()
    def win_test():
        try:
            raise InvalidPattern('test')
        except InvalidPattern as e:
            if isinstance(str(e), str):
                raise AssertionError(
                    "InvalidPattern.__str__ must return an unicode, not an str")

# Generated at 2022-06-12 07:48:31.717979
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return the same as __unicode__"""
    class LocalInvalidPattern(InvalidPattern):
        _fmt = '%(msg)s'
    m = LocalInvalidPattern('this is a message')
    assert m.__unicode__() == m.__str__()

# Generated at 2022-06-12 07:48:36.548560
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    error = InvalidPattern("message")
    s = str(error)
    assert s == "Invalid pattern(s) found. message", (
        "str(error) does not match with expected result")
    u = unicode(error)
    assert u == u"Invalid pattern(s) found. message", (
        "unicode(error) does not match with expected result")


# Generated at 2022-06-12 07:48:44.714914
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """A test for method __unicode__ of class InvalidPattern"""

    # Create an instance of class InvalidPattern
    instance = InvalidPattern('msg')

    # Call method __unicode__
    try:
        result = instance.__unicode__()
    except Exception as error:
        # If the call raises an exception, fail test.
        failTest('Calling method __unicode__ raised exception "%s"'
                 % str(error))
    else:
        # If the call does not raise an exception, check result.
        assert(result == u"msg")

# Generated at 2022-06-12 07:48:49.601659
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import bzrlib.errors
    from bzrlib.i18n import gettext

    e = InvalidPattern('snippet')
    s = e.__unicode__()
    gettext(unicode(s))
    bzrlib.errors.BzrError(s)



# Generated at 2022-06-12 07:49:00.702963
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    from bzrlib.tests import TestCase
    # XXX: the part of this test that checks that we get 'str' instead
    #      of 'unicode' back should probably be run in Python 2.3
    #      as well, but it would fail with the proxy object.
    # XXX: the other part of this test that checks that we can return
    #      a 'unicode' object from __unicode__ as well as a 'str'
    #      object should be run in Python 2.3 as well, but it would
    #      fail with the proxy object.
    class Test_InvalidPattern___unicode__(TestCase):
        """Tet InvalidPattern.__unicode__()."""

        def test_unicode_format(self):
            """__unicode__ uses format strings for unicode objects."""

# Generated at 2022-06-12 07:49:05.143930
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase
    class TestInvalidPattern(TestCase):
        def test_InvalidPattern___str__(self):
            e = InvalidPattern('msg')
            self.assertEqual('Invalid pattern(s) found. msg', str(e))
    test_InvalidPattern___str__.todo = 'Fix InvalidPattern to work with python3'

# Generated at 2022-06-12 07:49:20.746568
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method __str__ of class InvalidPattern."""
    class __Dummy_InvalidPattern_Class(InvalidPattern):
        _fmt = ('Invalid pattern(s) found. %(msg)s')
        def __init__(self, msg):
            self.msg = msg

    # Test for Unknown parameter
    exc = __Dummy_InvalidPattern_Class('foo')
    exc._format_string = None # make sure _get_format_string won't return
                              # anything.
    exc._preformatted_string = 'Foo!'

# Generated at 2022-06-12 07:49:32.334968
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern

    The unicode of an InvalidPattern object  should be the
    content of the "msg" attribute, even if that attribute
    contains an unicode object.
    """
    import doctest
    from bzrlib import tests
    tests.initialize(None) # Get localized messages
    docexample = '''
    >>> pat = InvalidPattern("pattern")
    >>> u'%s' % pat
    u'pattern'
    >>> pat.msg = u'\xc9cole'
    >>> u'%s' % pat
    u'\\xc9cole'
    '''
    doctest.testmod(optionflags=doctest.ELLIPSIS, extraglobs={'InvalidPattern':
        InvalidPattern})

# Generated at 2022-06-12 07:49:34.298020
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a bytestring"""
    ip = InvalidPattern('boo')
    assert isinstance(str(ip), str)

# Generated at 2022-06-12 07:49:44.717804
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """test for method __unicode__ of class InvalidPattern"""
    from bzrlib.lazy_regex import InvalidPattern
    def str_func(x):
        return str(x)
    def unicode_func(x):
        return unicode(x)
    def check_str_return(e, str_func):
        """Ensure that the string function returns a str and
        not a unicode object.
        """
        result = str_func(e)
        if isinstance(result, unicode):
            raise AssertionError('String function returned unicode.'
                                 ' Expected str.')
    def check_unicode_return(e, unicode_func):
        """Ensure that the unicode function returns a unicode and
        not a str object.
        """

# Generated at 2022-06-12 07:49:54.322491
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    msg = u'Message with \N{LATIN SMALL LETTER A WITH ACUTE}'
    e = InvalidPattern(msg)
    # In Python 2.7 and higher InvalidPattern overrides __str__ to return
    # the utf-8-encoded version of the unicode string.
    if hasattr(e, '__str__'):
        expected = msg.encode('utf-8')
    # In Python 2.6, InvalidPattern relies on __unicode__ which returns
    # the unicode string, which then gets encoded using the ASCII
    # encoding.
    else:
        expected = msg.encode('ascii', 'replace')
    assert str(e) == expected

# Generated at 2022-06-12 07:50:02.846640
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib.tests import TestCase, TestCaseWithTransport
    import sys

    bad_re_test = b'bla\x80'

    class TestInvalidPattern(TestCase):

        def test_invalid_pattern_contains_unicode(self):
            self.assertRaises(UnicodeDecodeError, re.compile, bad_re_test)
            try:
                re.compile(bad_re_test)
            except re.error as e:
                # Assert that the message can be converted to unicode
                unicode(str(e))


# Generated at 2022-06-12 07:50:12.471786
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """__getattr__ returns a member from the proxied regex object.
    If the regex hasn't been compiled yet, compile it.
    Bug #738140.
    """
    import re
    from bzrlib.tests.per_regex import TestCase

    class TestLazyRegex(TestCase):

        def test_findall(self):
            self.compile('.')
            self.assertTrue(hasattr(self.pattern, 'findall'))

        def test_finditer(self):
            self.compile('.')
            self.assertTrue(hasattr(self.pattern, 'finditer'))

        def test_match(self):
            self.compile('.')
            self.assertTrue(hasattr(self.pattern, 'match'))

        def test_scanner(self):
            self

# Generated at 2022-06-12 07:50:23.907006
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test the InvalidPattern.__str__() function."""

    # Add a str attribute to the class, to force a simple string to be formatted
    class Foo(InvalidPattern):
        _fmt = '%(str)s'
    class Bar(InvalidPattern):
        _fmt = '%(str)s'
        def _get_format_string(self):
            # override the format string
            return 'overridden %(str)s'
    class Baz(InvalidPattern):
        # It is not safe to override __str__ if _fmt is not set.
        def __str__(self):
            return 'never called'

    msg = 'msg'
    for cls in (Foo, Bar, Baz):
        e = cls(msg)
        assert str(e) == msg, repr(cls)
        assert unic

# Generated at 2022-06-12 07:50:29.838435
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Tests for method __str__ of class InvalidPattern.

    Test that calling __str__ on an InvalidPattern raises no
    exception and returns a str object.
    """
    from bzrlib.tests import TestCase
    class TestInvalidPattern__str__(TestCase):
        def test_InvalidPattern__str__(self):
            InvalidPattern('some %(msg)s')
    TestInvalidPattern__str__('test_invalid_pattern').test_InvalidPattern__str__()


# Generated at 2022-06-12 07:50:40.380597
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # we need to be able to consider the string that is expected
    # as unicode, so will always cast to unicode.
    # TODO: jam 20070525 Forcing unicode here and in the exception is
    #  a hack, but will suffice until we refactor the exception messages
    #  so that they are all wrapped in _fmt which will mean we know
    #  that the format string we get from _get_format_string will always
    #  be unicode.
    from bzrlib.trace import mutter
    from bzrlib.i18n import (
        gettext,
        gettext_noop,
        )

    def _assert_valid(msg_str):
        # check that the string is valid
        mutter('got: %s', msg_str)

# Generated at 2022-06-12 07:50:53.402332
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__ should return utf8"""
    import bzrlib.i18n # needed to install translations
    import bzrlib.lazy_regex
    # Install a translated message
    bzrlib.i18n.install_gettext_translations()

    e = bzrlib.lazy_regex.InvalidPattern('message')
    u = e.__unicode__()

    # __unicode__() should return a unicode object
    from bzrlib.tests import TestCase
    TestCase().assertTrue(isinstance(u, unicode))

    # The message should be translatable
    from bzrlib.i18n import gettext
    TestCase().assertEqual(u, gettext('Invalid pattern(s) found. message'))

# Generated at 2022-06-12 07:51:03.804949
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern must return a 'str' object"""
    class TestInvalidPattern(InvalidPattern):
        _fmt = "%(msg)s"

    msg = "abc"
    e = TestInvalidPattern(msg)
    assert str(e) == msg

    if hasattr(test_InvalidPattern___str__, 'u'): # py3k
        u = test_InvalidPattern___str__.u
    else:
        # unicode string
        u = unicode('\xc2\xa2', 'utf8') # 2-byte sequence, non-ascii
        test_InvalidPattern___str__.u = u
    msg = u
    e = TestInvalidPattern(msg)
    assert str(e) == msg
    assert str(e) == msg.encode('utf8')


# Generated at 2022-06-12 07:51:08.838837
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__ is a forwarder to __unicode__
    test_expected = unicode(InvalidPattern('msg'))
    test_actual = str(InvalidPattern('msg'))
    if test_expected != test_actual:
        raise AssertionError('expected {!r}, got {!r}'.format(test_expected,
                                                              test_actual))

# Generated at 2022-06-12 07:51:17.104599
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Ensure that InvalidPattern.__unicode__ works with non-ASCII data"""
    # Get a unicode repr of the InvalidPattern exception,
    # and ensure that it is unicode
    utf8_string = "\xc3\xa9moi"
    i = InvalidPattern(utf8_string)
    if not isinstance(i.__unicode__(), unicode):
        raise AssertionError("__unicode__ returned non-unicode")
    # Ensure that the unicode repr contains the unicode data
    # we used to initialize the exception
    if unicode(utf8_string) not in unicode(i):
        raise AssertionError("unicode(utf8_string) not in unicode(i)")

# Generated at 2022-06-12 07:51:28.896892
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    # __str__ should return a utf-8 string
    e = InvalidPattern('\xc3\xa9')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert str(e) == '\xc3\xa9'
    assert unicode(e) == u'\xe9'
    # __str__ should return an ascii string
    e = InvalidPattern('abc')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert str(e) == 'abc'
    assert unicode(e) == u'abc'
    # __str__ should return a utf-8 string
    e = InvalidPattern(u'\xe9')
    assert isinstance(str(e), str)

# Generated at 2022-06-12 07:51:39.956536
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ should return a 'str' object.

    The unicode codepoint '0x192' is valid and is equivalent to 'Latin Small
    Letter F with Hook' (see http://en.wikipedia.org/wiki/F_with_hook).
    This test ensures that __str__ return a 'str' object.
    """
    msg = "Invalid pattern: \'\xC6\x92\'"
    exception = InvalidPattern(msg)
    # __str__ must return a str object.
    s = str(exception)
    if isinstance(s, unicode):
        raise AssertionError("__str__ must return a 'str' object, got a '%s'."
                             % s.__class__.__name__)

if __name__ == '__main__':
    test_InvalidPattern___str__()

# Generated at 2022-06-12 07:51:46.378627
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Check that __getattr__ doesn't do infinite recursion"""
    _real_re_compile = re.compile
    re.compile = lambda *args, **kwargs: LazyRegex(args, kwargs)
    regex = re.compile('regex')
    try:
        regex.match('abcd')
    except RuntimeError:
        pass
    else:
        raise AssertionError('LazyRegex.__getattr__ should trigger infinite recursion')
    re.compile = _real_re_compile

# Generated at 2022-06-12 07:51:51.762036
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    # Create an object with data
    class MyException(InvalidPattern):
        _fmt = 'This is my exception: %(msg)s'
        def __init__(self, msg):
            self.msg = msg

    # Test unicode
    expected = 'This is my exception: hello world'
    actual = MyException('hello world').__unicode__()
    assert actual == expected, 'Expected: %s, got: %s' % (expected, actual)

    # Test str
    expected = 'This is my exception: hello world'
    actual = str(MyException('hello world'))
    assert actual == expected, 'Expected: %s, got: %s' % (expected, actual)

# Generated at 2022-06-12 07:52:01.546965
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern.

    This test also calls __str__.
    """
    def check(cls, __dict__, expected):
        # call __unicode__ and verify that it returns the expected unicode
        # object.
        obj = cls(None)
        obj.__dict__.clear()
        obj.__dict__.update(__dict__)
        u = unicode(obj)
        # the expected unicode must be a unicode instance
        if not isinstance(expected, unicode):
            raise AssertionError('expected must be an unicode instance')
        if not isinstance(u, unicode):
            raise AssertionError('expected an unicode instance, got %s'
                                 % repr(u))

# Generated at 2022-06-12 07:52:10.486123
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    #  __unicode__() should return a unicode string
    e = InvalidPattern('This is an error message')
    s = unicode(e)
    #  __unicode__() should return the same string as __str__()
    e = InvalidPattern('This is an error message')
    s1 = unicode(e)
    s2 = str(e)
    assert(s1 == s2)
    #  __unicode__() should return the same string as __repr__()
    e = InvalidPattern('This is an error message')
    s1 = unicode(e)
    s2 = repr(e)
    assert(s1 == s2)


# Generated at 2022-06-12 07:52:25.862102
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    from bzrlib import tests
    from bzrlib.tests import TestCase

    # Test the case when _fmt has a value.
    invalid_pattern = InvalidPattern('Invalid pattern')
    invalid_pattern._fmt = 'Invalid pattern(s) found. %(msg)s'
    invalid_pattern.msg = 'Invalid pattern'
    self.assertEqual('Invalid pattern(s) found. Invalid pattern',
                     str(invalid_pattern))

    # Test the case when _fmt is not defined.
    invalid_pattern = InvalidPattern('Invalid pattern')
    invalid_pattern.msg = 'Invalid pattern'
    self.assertEqual('Unprintable exception InvalidPattern: dict=%r, fmt=None,'
                     ' error=None' % invalid_pattern.__dict__,
                         str(invalid_pattern))

    # Test

# Generated at 2022-06-12 07:52:31.196457
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """Check that LazyRegex.__getattr__ returns the expected value.

    The proxy object LazyRegex has no attribute "_real_regex", so
    accessing it triggers the method _compile_and_collapse, which
    sets the attribute "_real_regex" to a real _sre.SRE_Pattern object.
    The method _compile_and_collapse also copies some properties
    of the real _sre.SRE_Pattern object to the proxy object, so that
    accessing it again directly returns the expected value, without
    triggering method _compile_and_collapse again.
    """
    lr = LazyRegex([r'\d+'])

    # attribute "_real_regex" is not set, so triggering
    # method _compile_and_collapse

# Generated at 2022-06-12 07:52:33.767372
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern should return a str"""
    e = InvalidPattern('some message')
    # this should return a str, and not raise any exception
    str(e)


# Generated at 2022-06-12 07:52:36.703408
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern

    Test that the method returns its message as unicode.
    """
    e = InvalidPattern('invalid')
    assert isinstance(unicode(e), unicode)


# Generated at 2022-06-12 07:52:40.592273
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Unit test for method __unicode__ of class InvalidPattern"""
    pattern = 'syntax error'
    e = InvalidPattern(pattern)
    assert e.__unicode__() == pattern
    e = InvalidPattern('')
    assert e.__unicode__() == ''

# Generated at 2022-06-12 07:52:51.754174
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern"""
    # when argument has unicode characters, we should get unicode object
    e = InvalidPattern(u'\u00c0')
    assert type(e.__unicode__()) == unicode
    # when argument has only ascii characters, we should get unicode object
    e = InvalidPattern('abc')
    assert type(e.__unicode__()) == unicode
    # even when argument is a str, we should get unicode object
    e = InvalidPattern(str('abc'))
    assert type(e.__unicode__()) == unicode
    # if no argument is given, we should get unicode object, too.
    e = InvalidPattern()
    assert type(e.__unicode__()) == unicode
    # If anything goes wrong, we should get unicode object,

# Generated at 2022-06-12 07:52:58.155626
# Unit test for method __getattr__ of class LazyRegex
def test_LazyRegex___getattr__():
    """This tests the case that the attribute is not cached"""

    def test_match(string):
        m = re.search(reg, string)
        if m is not None:
            return m.group(0)
        else:
            return None

    reg = LazyRegex()
    reg._real_re_compile = lambda *args, **kwargs: re.compile('\d+')
    # 1. The attribute is not cached, and the proxy object is matched.
    string = "abc123"
    assert string == test_match(string)
    # 2. The attribute is not cached, and the proxy object is not matched.
    string = "abc"
    assert None == test_match(string)



# Generated at 2022-06-12 07:53:10.161731
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test method __unicode__ of class InvalidPattern."""
    import bzrlib

    # Part 1: Test InvalidPattern.__unicode__ with a non-unicode string.
    try:
        raise InvalidPattern('error')
    except InvalidPattern as e:
        result = unicode(e)
        assert result == 'error'

    # Part 2: Test InvalidPattern.__unicode__ with a unicode string.
    try:
        error = '\u6101'
        raise InvalidPattern(error)
    except InvalidPattern as e:
        result = unicode(e)
        assert result == error

    # Part 3: Test InvalidPattern.__unicode__ with a non-unicode string
    #         using an unknown encoding.

# Generated at 2022-06-12 07:53:12.963153
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """Test for method InvalidPattern.__str__()"""
    import cStringIO
    e = InvalidPattern('msg')
    out = cStringIO.StringIO()
    out.write(str(e))
    assert out.getvalue() == 'msg'


# Generated at 2022-06-12 07:53:16.860808
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern's __unicode__ method should return a unicode object when
    passed a str object.
    """
    e = InvalidPattern('foo')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:53:31.244381
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """InvalidPattern.__unicode__() should return a unicode object."""
    # This is a regression test for bug #292101
    msg = u'test'
    e = InvalidPattern(msg)
    assert isinstance(e.__unicode__(), unicode)
    assert unicode(e) == u'Invalid pattern(s) found. test'
    # Call it twice as __unicode__ is intended to be idempotent.
    assert isinstance(e.__unicode__(), unicode)
    assert unicode(e) == u'Invalid pattern(s) found. test'
    assert isinstance(str(e), str)
    assert str(e) == 'Invalid pattern(s) found. test'
    assert e.__unicode__() == unicode(e)

# Generated at 2022-06-12 07:53:36.762576
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Tests that InvalidPattern.__unicode__() works."""
    obj = InvalidPattern('my message')
    u = obj.__unicode__()
    # The message must be a unicode object.
    from bzrlib.tests import TestCase
    TestCase.assertIsInstance(u, unicode)
    # check that the message contains 'my message'
    self.assertIn(u'my message', u)


# Generated at 2022-06-12 07:53:46.774114
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    import codecs
    utf8_encoder = codecs.getencoder('utf-8')
    class UTF8Exception(Exception):
        def __init__(self, msg, str_value=None):
            self.__str__ = str_value
        def __unicode__(self):
            return u"\u263a"
    e = UTF8Exception(u"\u263a")

    invalid = InvalidPattern('testing')
    invalid._preformatted_string = u"\u263a"
    assert invalid.__unicode__() == u"\u263a"
    assert invalid.__str__() == "\xe2\x98\xba"

    invalid = InvalidPattern('testing')
    invalid._preformatted_string = "'%(foo)s'"
    invalid.foo = u"\u263a"

# Generated at 2022-06-12 07:53:51.854849
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """Test __unicode__ method of InvalidPattern class"""
    from breezy.tests import (
        TestCase,
        )

    class TestInvalidPattern(TestCase):

        def test_invalid_pattern(self):
            msg = u'magic\u1234'
            e = InvalidPattern(msg)
            self.assertEqualDiff(u'Invalid pattern(s) found. magic\u1234',
                                 str(e))

# Generated at 2022-06-12 07:53:54.079863
# Unit test for method __str__ of class InvalidPattern
def test_InvalidPattern___str__():
    """__str__ of InvalidPattern must return a str object"""
    e1 = InvalidPattern('something')
    assert isinstance(str(e1), str)

# Generated at 2022-06-12 07:54:03.674888
# Unit test for method __unicode__ of class InvalidPattern
def test_InvalidPattern___unicode__():
    """This tests the __unicode__ method of class InvalidPattern.

    This method does not use any input or output in unicode. So we can
    safely call it with a str parameter (as this is the normal case).
    """
    from bzrlib.i18n import gettext
    class_name = InvalidPattern.__name__
    e = InvalidPattern('my fmt %(arg1)s')
    e.arg1 = 'arg1'
    e.arg2 = 'arg2'
    ut = unicode(e)
    assert_('arg1' in ut)
    assert_('arg2' in ut)
    st = str(e)
    assert_('arg1' in st)
    assert_('arg2' in st)
    assert_(class_name not in ut)