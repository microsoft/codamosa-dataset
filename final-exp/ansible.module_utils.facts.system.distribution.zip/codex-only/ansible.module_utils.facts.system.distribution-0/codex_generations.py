

# Generated at 2022-06-23 00:58:30.546698
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec=dict())
    dist = Distribution(module)

    _system = platform.system
    _release = platform.release
    _version = platform.version


# Generated at 2022-06-23 00:58:39.930550
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(required=True, type='str'),
            fact_data=dict(required=True, type='str'),
            fact_name=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    # TODO: mock module.run_command, module.get_bin_path

# Generated at 2022-06-23 00:58:49.960660
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    # This is a unit test for a method that is not exposed at the module level
    # The purpose of this unit test is to make sure that the method can be
    # unit tested without having to expose the method for testing
    # which is hard to do, because the method can be overridden.
    # In addition, the method overrides are dependent on the python
    # version as well, so this is not as easy as it sounds.

    # test 1:
    # confirm return of expected results using the default method
    # which is the method being tested by this unit test
    module_args = dict(
        files=[dict(name='Alpine', path='/etc/alpine-release')],
    )
    collected_facts = dict(distribution_file_parsed=[])
    distribution_files = DistributionFiles(module_args, collected_facts, {})

# Generated at 2022-06-23 00:59:00.590661
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distribution_files = DistributionFiles()
    res = distribution_files.parse_distribution_file_Mandriva("Mandriva", "DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2011.0\nDISTRIB_CODENAME=Hydrogen\nDISTRIB_DESCRIPTION=\"Mandriva Linux release 2011.0 (Hydrogen)\"\n", '/etc/lsb-release', {'cpu_architecture': 'x86_64', 'distribution_release': 'NA'})
    assert res == (True, {'distribution': 'Mandriva', 'distribution_version': '2011.0', 'distribution_release': 'Hydrogen'})

# Generated at 2022-06-23 00:59:10.766973
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    """
    Unit test for method parse_distribution_file_Slackware
    of class DistributionFiles
    """
    return_object = DistributionFiles().parse_distribution_file_Slackware(
        "Slackware",
        "Slackware 14.2",
        "/etc/slackware-version"
    )
    assert isinstance(return_object, tuple), "Invalid return type"
    assert len(return_object) == 2, "Invalid return object length"
    assert isinstance(return_object[0], bool), "Invalid return type"
    assert isinstance(return_object[1], dict), "Invalid return type"
    assert return_object[1]['distribution'] == "Slackware", "Invalid return value"

# Generated at 2022-06-23 00:59:15.310974
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    dist_file_name = "Alpine"
    dist_file_path = "/etc/alpine-release"
    dist_file_content = b"3.8\n"

    distribution_file = DistributionFiles(None, None, None, None)

    # some_fact_to_pass_to_method expected to be >= 2.6
    some_fact_to_pass_to_method = "2.6"

    parsed_dist_file, parsed_dist_file_facts = distribution_file.parse_distribution_file_Alpine(dist_file_name, dist_file_content, dist_file_path, some_fact_to_pass_to_method)
    assert parsed_dist_file == True
    assert parsed_dist_file_facts['distribution'] == dist_file_name
    assert parsed_dist_file_

# Generated at 2022-06-23 00:59:27.551301
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    # Setup
    module = AnsibleModuleMock()
    dist = Distribution(module)
    dist.module.run_command = run_command_mock
    dist.module.get_file_content = get_file_content_mock
    # Setup for test 1
    run_command_mock.side_effect_append_returns = [
        [0, '', ''],
        [0, 'OpenBSD 6.6-STABLE (GENERIC) #341: Tue Mar 17 16:59:43 MDT 2020', ''],
    ]
    get_file_content_mock.side_effect_append_returns = [
        ['OpenBSD 6.6-STABLE (RAMDISK_CD) #0: Sun Feb 23 22:10:06 UTC 2020', '', 0],
    ]

# Generated at 2022-06-23 00:59:30.498452
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    from ansible.module_utils.facts.collector import Collectors, FactCollector
    Collectors._collectors = []
    distro = DistributionFactCollector()
    assert isinstance(distro, FactCollector)



# Generated at 2022-06-23 00:59:41.254436
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    from ansible.module_utils.facts import DistributionFiles
    distfiles = DistributionFiles()
    # This test is only valid for FlatcarLinux

# Generated at 2022-06-23 00:59:50.479724
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    i = Distribution(DummyModule())
    o = i.get_distribution_SunOS()

    assert o['distribution'] == 'Solaris'
    assert o['distribution_version'] == '10'
    assert o['distribution_release'] == '5.10'
    assert o['distribution_major_version'] == '10'

# Generated at 2022-06-23 00:59:53.953598
# Unit test for function get_uname
def test_get_uname():
    from ansible.module_utils.facts.utils import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_uname(module) is not None


# Generated at 2022-06-23 01:00:05.468874
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Setup
    module = MockModule()
    distro_files = DistributionFiles(module)

    # Test: Coreos
    distro = 'CoreOS'
    name = 'Coreos'
    data = 'GROUP=stable'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    result = distro_files.parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert result == (True, {'distribution_release': 'stable'})

    # Test: not Coreos
    distro = 'rhel'
    name = 'Coreos'
    data = 'GROUP=stable'
    path = '/etc/os-release'

# Generated at 2022-06-23 01:00:16.508217
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distro_file = DistributionFiles()
    # test data
    test_data = {}
    test_data['name'] = 'Mandriva'

# Generated at 2022-06-23 01:00:18.525694
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    dist = Distribution(None)
    assert dist.get_distribution_SMGL() == {'distribution': 'Source Mage GNU/Linux'}



# Generated at 2022-06-23 01:00:29.710900
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
  """ Test get_distribution_DragonFly returns correctly """
  expected = {
    'distribution_release': platform.release(),
    'distribution_major_version': match.group(1),
    'distribution_version': '%s.%s.%s' % match.groups()[:3]
  }
  distribution_facts = Distribution(module).get_distribution_DragonFly()
  assert(distribution_facts['distribution_release']) == expected['distribution_release']
  assert(distribution_facts['distribution_major_version']) == expected['distribution_major_version']
  assert(distribution_facts['distribution_version']) == expected['distribution_version']



# Generated at 2022-06-23 01:00:40.884145
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    d = Distribution(None)
    expected_results = {
        'distribution': 'MacOSX',
        'distribution_major_version': '10',
        'distribution_release': 'El Capitan',
        'distribution_version': '10.11.6'
    }
    fake_out = "ProductName:    Mac OS X\nProductVersion: 10.11.6"
    fake_data = "10.11.6"
    fake_out_split_data = ['10', '11', '6']
    fake_data2 = "10"
    with patch('ansible.module_utils.facts.system.platform.system') as mock_system:
        mock_system.return_value = 'Darwin'

# Generated at 2022-06-23 01:00:53.157915
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Initialize DistributionFiles class
    distribution_files = DistributionFiles()
    # Create dict with line from file /etc/os-release

# Generated at 2022-06-23 01:00:57.005199
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    """
    This method is used to test parse_distribution_file_ClearLinux method of DistributionFiles class.
    """
    distributionfiles_obj = DistributionFiles()
    assert distributionfiles_obj.parse_distribution_file_ClearLinux(None, None, None, None) == (False, {})

# Generated at 2022-06-23 01:01:09.509204
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    t = DistributionFiles(None, {}, {})
    assert t.parse_distribution_file_Coreos('CoreOS', 'GROUP=stable', '/etc/os-release', {'distribution_release': 'NA'})[1] == {'distribution_release': 'stable'}
    # test path /etc/os-release as well
    assert t.parse_distribution_file_Coreos('CoreOS', 'GROUP=stable', '/etc/os-release', {'distribution_release': 'NA'})[1] == {'distribution_release': 'stable'}
    # default return
    assert t.parse_distribution_file_Coreos('CoreOS', 'NOT_CORRECT', '/etc/os-release', {'distribution_release': 'NA'})[1] == {}


# Generated at 2022-06-23 01:01:14.777665
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    assert Distribution.get_distribution_FreeBSD() == {'distribution_release': '12.0-RELEASE', 'distribution_version': '12.0', 'distribution_major_version': '12'}

# Generated at 2022-06-23 01:01:26.660099
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    """
    Unit test for method get_distribution_facts of class Distribution
    """
    module = mock.MagicMock()
    module.run_command.side_effect = [
        (0, """AIX Version 7.2
        Execute the following command to install the software:
        installp -acXd . java7.sdk.71.64.ppc
        java7.sdk.71.64.ppc: 7.1.0.0.20111109_0249 Service Pack 810.44
        ###########################################################
        """, ''),
        (0, '7.1.0.0', ''),
        (0, '7.1.0.0', ''),
    ]

    dist = Distribution(module=module)
    facts = dist.get_distribution_facts()


# Generated at 2022-06-23 01:01:33.061571
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():

    # given
    module = Mock(name='module')
    collected_facts = {'os_family': 'FreeBSD', 'distribution': 'FreeBSD'}

    fact_collector = DistributionFactCollector()

    # when
    result = fact_collector.collect(module=module, collected_facts=collected_facts)

    # then
    assert result == {'os_family': 'FreeBSD', 'distribution': 'FreeBSD'}


# Generated at 2022-06-23 01:01:45.817919
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    obj = DistributionFiles({})
    # On local Fedora system:
    truth_data = {
        'distribution_file_path': '/etc/os-release',
        'distribution_file_variety': 'RedHat',
        'distribution_file_parsed': True,
        'distribution': 'Fedora',
        'distribution_version': '27',
        'distribution_major_version': '27',
        'distribution_minor_version': '0',
        'distribution_release': 'NA'
    }
    parsed, data = obj.process_dist_files()
    assert (parsed == '/etc/os-release' and data == truth_data)


if __name__ == '__main__':
    # simple test the init method
    obj = DistributionFiles({})

# Generated at 2022-06-23 01:01:55.448622
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    """
    This test verifies the following:
        - Instantiation of class DistributionFiles
        - class member files is accessible
    """
    distribution_files = DistributionFiles()
    files = distribution_files.files
    assert isinstance(files, list), "distribution_files.files is not a list."
    distribution_varieties = []
    for f in files:
        distribution_varieties.append(f['name'])
    for dv in ['Amazon', 'Alpine', 'SUSE', 'Debian', 'Mandriva', 'CentOS', 'NA', 'Coreos', 'Flatcar', 'ClearLinux']:
        assert dv in distribution_varieties, "Missing distribution_variety %s in distribution_files.files" % dv


# Generated at 2022-06-23 01:02:01.819507
# Unit test for constructor of class Distribution
def test_Distribution():
    """
    Test constructor of class Distribution

    :return:
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    families = ['Debian', 'RedHat', 'Suse', 'Solaris', 'Alpine', 'ClearLinux', 'AIX', 'HP-UX', 'Darwin', 'FreeBSD', 'Gentoo', 'Archlinux', 'Altlinux', 'Mandrake', 'Slackware', 'Flatcar', 'CoreOS', 'DragonFly']
    distro = Distribution(module)
    facts = distro.get_distribution_facts()
    if facts['os_family'] not in families:
        raise RuntimeError("Invalid os family found: " + facts['os_family'])


# Generated at 2022-06-23 01:02:04.001703
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    df = DistributionFactCollector()
    assert df.collect() == {}, df.collect()



# Generated at 2022-06-23 01:02:14.515730
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    def test(uname_v, expected_result, expected_distribution_major_version, expected_distribution_version):
        module = DummyModule()
        module.run_command.return_value = (0, uname_v, None)
        distribution = Distribution(module)
        dragonfly_facts = distribution.get_distribution_DragonFly()
        assert expected_result == dragonfly_facts['distribution_release']
        assert expected_distribution_major_version == dragonfly_facts.get('distribution_major_version', None)
        assert expected_distribution_version == dragonfly_facts.get('distribution_version', None)

# Generated at 2022-06-23 01:02:26.798995
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    d = DistributionFiles()
    name = 'OpenWrt'
    data = '''NAME="OpenWrt"
VERSION="18.06.1"
ID=openwrt
ID_LIKE=lede
PRETTY_NAME="OpenWrt 18.06.1"
'''
    path = 'whatever'
    collected_facts = {}
    expected_result = ({'distribution': 'OpenWrt', 'distribution_version': '18.06.1', 'distribution_release': 'lede'}, True)
    result = d.parse_distribution_file_OpenWrt(name, data, path, collected_facts)
    assert result == expected_result, "The method parse_distribution_file_OpenWrt of class DistributionFiles returned %s when %s was expected" % (str(result), str(expected_result))

# Generated at 2022-06-23 01:02:40.842300
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    import json
    import os
    import platform
    import re
    import subprocess
    import tempfile
    import unittest
    import textwrap

    class TestGetDistributionSunOS(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile()
            self.addCleanup(self.temp_file.close)
            self.run_command_outputs = {
                ('/sbin/sysctl -n kern.version'): '',
                ('/usr/bin/uname -v'): '',
                ('/usr/bin/uname -r'): '',
            }
            self.read_file_outputs = {}
            self.write_file_outputs = {}
            self.exists_outputs = {}

# Generated at 2022-06-23 01:02:46.775216
# Unit test for function get_uname
def test_get_uname():
    assert get_uname({'run_command': run_command_mock}, ('-v')) == \
        'Linux version 4.1.12-60.32.1.el7uek.x86_64 (mock builder@x86-023.build.eng.bos.redhat.com) (gcc version 4.8.5 20150623 (Red Hat 4.8.5-16) (GCC) ) #2 SMP Fri Dec 8 15:05:34 PST 2017'


# Generated at 2022-06-23 01:02:59.621102
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.distribution import DistributionFiles

    dfiles = DistributionFiles()
    filepath = '/usr/lib/os-release'

# Generated at 2022-06-23 01:03:11.393079
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    f = DistributionFiles()
    name = 'Amazon'
    path = '/etc/os-release'
    #data = (b'NAME="Amazon Linux"\nVERSION="2"\nID="amzn"\nID_LIKE="centos rhel fedora"\nVERSION_ID="2"\nPRETTY_NAME="Amazon Linux 2"\nANSI_COLOR="0;33"'
    data = 'NAME="Amazon Linux"\nVERSION="2"\nID="amzn"\nID_LIKE="centos rhel fedora"\nVERSION_ID="2"\nPRETTY_NAME="Amazon Linux 2"\nANSI_COLOR="0;33"'

    # data = b'NAME="Amazon Linux"\nVERSION="2"\nID="amzn"\nID_LIKE="centos rhel

# Generated at 2022-06-23 01:03:22.093022
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # Test empty
    facts = DistributionFiles(dict()).parse_distribution_file_Slackware(name='', data='', path='', collected_facts={})
    assert not facts['distribution_file_parsed']
    assert facts['distribution_file_path'] == ''
    assert facts['distribution_file_variety'] == ''
    assert facts['distribution'] == ''
    assert facts['distribution_version'] == ''

    # Slackware 14.2
    data = """
        Welcome to Slackware 14.2, the Noblest Operating System in the World!

                            Slackware
        """
    facts = DistributionFiles(dict()).parse_distribution_file_Slackware(name='Slackware', data=data, path='', collected_facts={})
    assert facts['distribution_file_parsed']


# Generated at 2022-06-23 01:03:32.908500
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module_args = {'module_name': 'AnsibleTestModule', 'module_args': ''}

    dist1 = Distribution(module_args)
    version = platform.release()
    version = version.replace('v', '')

    ret = dist1.get_distribution_DragonFly()
    assert version == ret['distribution_version']
    assert version == ret['distribution_release']

    dist2 = Distribution(module_args)
    version = '1.6.2'
    ret = dist2.get_distribution_DragonFly()
    assert version == ret['distribution_version']
    assert version == ret['distribution_release']

    dist3 = Distribution(module_args)
    version = '2.4.2-RELEASE'
    ret = dist3.get_distribution_DragonFly()

# Generated at 2022-06-23 01:03:42.964082
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    class Module:
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
        def get_bin_path(self, name, opts='', ignore_errors=False):
            return name

    class Facts:
        def __init__(self):
            self.distribution = 'OpenWrt'
            self.distribution_release = 'unknown'

        def get(self, key):
            if not key:
                return {}
            return getattr(self, key)

    class DistributionFiles:
        def __init__(self):
            self.module = Module()
            self.collected_facts = Facts()


# Generated at 2022-06-23 01:03:50.977953
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    reader = DistributionFiles()
    name = 'Flatcar'
    with open('../tests/data/os-release') as f:
        data = f.read()
    path = '/etc/os-release'
    collected_facts = {'distribution': 'NA'}
    parsed, flatcar_facts = reader.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert parsed
    assert flatcar_facts['distribution_release'] == '5.5.8'



# Generated at 2022-06-23 01:04:02.346610
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    dist_file = DistributionFiles()


# Generated at 2022-06-23 01:04:15.088382
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_obj = DistributionFiles()
    test_data = """NAME="Amazon Linux"
VERSION="2"
ID="amzn"
ID_LIKE="centos rhel fedora"
VERSION_ID="2"
PRETTY_NAME="Amazon Linux 2"
ANSI_COLOR="0;33"
CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
HOME_URL="https://amazonlinux.com/"
""".splitlines()
    distribution = 'Amazon'
    path = '/etc/os-release'
    parsed_dist_file_facts = dist_file_obj.parse_distribution_file_Amazon(distribution, test_data, path, {})

# Generated at 2022-06-23 01:04:19.858964
# Unit test for constructor of class Distribution
def test_Distribution():
    module = MockAnsibleModule()
    module.run_command.return_value = (0, '', '')
    d = Distribution(module)
    module.fail_json.assert_not_called()


# Generated at 2022-06-23 01:04:29.447149
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():

    ### Test 1
    # Update the facts to be used for testing
    # TODO: remove the following line, once facts are passed in from the caller
    facts = {}

    # Test 1
    # test_case1_data is the /etc files to be created for this test
    test_case1_data = {'/etc/SuSE-release': '''
    # cat /etc/SuSE-release
    openSUSE 13.1 (x86_64)
    VERSION = 13.1
    CODENAME = Bottlerocket
    '''}

    # TODO: Use the following code to update test_case1_data
    #filenames = {}
    #for k, v in test_case1_data.iteritems():
    #    filename = create_temp_file(v)
    #   filenames[k

# Generated at 2022-06-23 01:04:39.244776
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    import sys,os
    sys.path.append(os.path.realpath(os.path.join(os.path.dirname(__file__),"../..")))
    from lib.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Get the facts
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_NetBSD()

    assert distribution_facts['distribution_release'] == '6.1.5'

    assert distribution_facts['distribution_major_version'] == '6'

    assert distribution_facts['distribution_version'] == '6.1'


# Generated at 2022-06-23 01:04:49.628221
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    name = 'Amazon Linux AMI'
    data = 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': '2018.03', 'distribution_major_version': '2018'}

# Generated at 2022-06-23 01:05:00.553985
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    class MockModule(object):
        def __init__(self):
            self.run_command_result = (0, 'OpenBSD 6.4-stable (GENERIC) #907: Fri Nov 16 03:52:10 MST 2018', '')

        def run_command(self, cmd, use_unsafe_shell):
            return self.run_command_result

    f = Distribution(MockModule())
    assert f.get_distribution_OpenBSD() == {
        'distribution_version': '6.4-stable',
        'distribution_release': 'stable'
    }, "Could not detect release of OpenBSD"


# Generated at 2022-06-23 01:05:13.885886
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    d_f_obj = DistributionFiles()
    error_key = []
    ok_key = []
    #TODO: Add tests here
    #TODO: Check if the function returns something or if it just modifies the object
    #TODO: Check if it modifies the object in the way we want

# Generated at 2022-06-23 01:05:24.603721
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    """
    Runs the method get_distribution_DragonFly method of class Distribution on a test system
    and returns the resulting facts

    This works by running a test ansible-playbook and getting the resulting ansible facts
    :return: a dict containing the resulting ansible facts
    """
    # run an ansible-playbook on the test playbook using the test inventory
    ansible_result = run_test_ansible_module(path.join(path.dirname(__file__), 'test-playbooks', 'test_Distribution.yml'))

    # the facts should be in the 'ansible_facts' section
    facts = ansible_result['ansible_facts']

    return facts


# Generated at 2022-06-23 01:05:37.172590
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    """ Test method parse_distribution_file_SUSE. """
    import os

    from ansible.module_utils.facts import DistributionFiles

    df = DistributionFiles()
    dist_info = {
        'distribution': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA',
        'distribution_release': 'NA',
        'distribution_file_paths': {},
        'distribution_file_facts': {}
    }
    # test with SLES12SP2 /etc/os-release
    data = 'NAME="SLES"\nVERSION="12-SP2"\nID="sles"\nVERSION_ID="12.2"\nPRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"'
    path = '/etc/os-release'


# Generated at 2022-06-23 01:05:45.101650
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    # TODO: implement this.
    #  for now just verify no exceptions are thrown.
    m = AnsibleModule(argument_spec={'fact': {'type': 'str'}})  # TODO: fake_ansible_module.py

    fact_name = m.params.get('fact')
    if not fact_name:
        fact_name = 'all'

    self = DistributionFiles(m)
    collected_facts = {}
    collected_facts[fact_name] = None
    self.process_dist_files(collected_facts)


if __name__ == '__main__':
    test_DistributionFiles_process_dist_files()

# Generated at 2022-06-23 01:05:52.838781
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    """
    Test parse_distribution_file_Alpine of DistributionFiles class
    """
    test_obj = DistributionFiles()
    path = './tests/unit/files/os-release-alpine'
    data = get_file_content(path)
    name = 'Alpine'
    collected_facts = {}

    res, facts = test_obj.parse_distribution_file_Alpine(name, data, path, collected_facts)
    if res:
        assert 'Alpine' in facts['distribution']
    assert res, "Unable to pass test_DistributionFiles_parse_distribution_file_Alpine"

# Generated at 2022-06-23 01:05:55.243164
# Unit test for constructor of class Distribution
def test_Distribution():
    dist = Distribution(module=AnsibleModule(argument_spec={}))
    return dist



# Generated at 2022-06-23 01:06:05.676110
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    from ansible.module_utils.facts.collector import DistributionFiles
    df = DistributionFiles()
    data = 'DISTRIB_ID=OpenWrt\r\nDISTRIB_RELEASE=18.06.1\r\nDISTRIB_REVISION=r8006-959b9c3f46\r\nDISTRIB_CODENAME=dunfell\r\nDISTRIB_TARGET=ar71xx/generic\r\nDISTRIB_DESCRIPTION=OpenWrt 18.06.1 r8006-959b9c3f46\r\nDISTRIB_TAINTS=\r\n'

# Generated at 2022-06-23 01:06:08.070750
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    test_obj = Distribution(None)
    assert test_obj.get_distribution_Darwin() == {'distribution': 'MacOSX'}



# Generated at 2022-06-23 01:06:16.607515
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    collected_facts = {'distribution': 'NA',
                       'distribution_version': 'NA', 'distribution_major_version': 'NA',
                       'distribution_release': 'NA'}
    # empty name
    distribution_files = DistributionFiles()
    distribution_files.dist_files = {'name': {'data': '', 'path': 'path'}}
    result = distribution_files.process_dist_files(collected_facts)
    for k in ('distribution', 'distribution_version', 'distribution_major_version', 'distribution_release'):
        assert result[k] == 'NA'
    # valid CentOS
    distribution_files = DistributionFiles()
    data = ''' NAME="CentOS Linux"
VERSION="8 (Core)"
'''

# Generated at 2022-06-23 01:06:29.672636
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    """
    Test of method parse_distribution_file_NA of class DistributionFiles
    """
    dist_file_obj = DistributionFiles()
    distribution_facts = {'distribution_version': 'NA'}
    dist_file_content = 'unique_file_content'
    distribution_name = 'NA'
    distribution_path = '/path/to/file'
    parsed_dist_file_facts, valid = dist_file_obj.parse_distribution_file_NA(distribution_name, dist_file_content, distribution_path, distribution_facts)

    assert valid, "Validation of parse_distribution_file_NA() failed."
    assert parsed_dist_file_facts['distribution'] == 'NA', "Parse of distribution_name by parse_distribution_file_NA() failed."
    assert parsed_dist_file_

# Generated at 2022-06-23 01:06:40.854170
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist = DistributionFiles()
    assert dist
    assert dist.files.keys() == [
        'Ubuntu', 'Debian', 'Mandriva', 'RedHat', 'SuSE', 'Gentoo',
        'Mandrake', 'TurboLinux', 'Slackware', 'VA-Linux', 'UnitedLinux', 'Asianux',
        'Yellowdog', 'Puppy', 'Novell', 'Frugalware', 'Oracle', 'Alpine', 'ClearLinux',
        'SteamOS', 'FIESTA', 'Raspbian', 'Kali', 'Parrot', 'Devuan', 'Cumulus',
        'OpenWrt', 'Linux Mint', 'NA', 'Coreos', 'Flatcar', 'Amazon', 'CentOS'
    ]

# Generated at 2022-06-23 01:06:52.462547
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    """Unit Test for parse_distribution_file_Alpine"""

    distro_files = DistributionFiles()
    name = 'Alpine'
    data = "3.10.3"
    path = "/etc/alpine-release"
    collected_facts = {}
    expected_parse_distribution_file_Alpine = (True, {'distribution': 'Alpine', 'distribution_version': '3.10.3'})
    parse_distribution_file_Alpine = distro_files.parse_distribution_file_Alpine(name, data, path, collected_facts)
    assert expected_parse_distribution_file_Alpine == parse_distribution_file_Alpine



# Generated at 2022-06-23 01:06:59.379800
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, 'Just a Test', ''))
    distribution = Distribution(module)
    value = distribution.get_distribution_SMGL()
    assert value == {'distribution': 'Source Mage GNU/Linux'}


# Generated at 2022-06-23 01:07:07.218941
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    d = DistributionFiles()
    assert d.parse_distribution_file_Amazon("Amazon", "", "", {}) == (False, {})
    assert d.parse_distribution_file_Amazon("Amazon", "/etc/os-release", "/etc/os-release", {}) == (True, {'distribution': 'Amazon'})
    assert d.parse_distribution_file_Amazon("Amazon", "/etc/issue", "/etc/issue", {}) == (True, {'distribution': 'Amazon'})


# Generated at 2022-06-23 01:07:19.363543
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    df = DistributionFiles({}, None)

    assert df.parse_distribution_file_SUSE('openSUSE Leap',
                                           'NAME=openSUSE Leap\nVERSION_ID="42.3"',
                                           '',
                                           {'distribution_version': '42.3'}) == (True, {'distribution': 'openSUSE Leap', 'distribution_release': '42.3'})

# Generated at 2022-06-23 01:07:23.865357
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    myLogger = logging.getLogger('get_distribution_SMGL')
    import ansible.module_utils.basic as basic
    dist = Distribution(basic)
    d1 = dist.get_distribution_SMGL()
    myLogger.error('d1 is %s', d1)


# Generated at 2022-06-23 01:07:26.905609
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distro = Distribution(module=None)
    assert distro.get_distribution_DragonFly() == {'distribution_release': platform.release()}

# Generated at 2022-06-23 01:07:34.932137
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        # supports_check_mode=True,
    )

# Generated at 2022-06-23 01:07:39.862573
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    with pytest.raises(Exception) as excinfo:
        from ansible.module_utils.facts import Distribution
        d = Distribution()
        d.get_distribution_HPUX()
        assert False
    assert "Missing required module (platform)" in str(excinfo.value)


# Generated at 2022-06-23 01:07:51.430938
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    df = DistributionFiles()
    collected_facts = dict()
    # collected_facts = dict(distribution_version=None)
    dist_file_contents = '''
DISTRIB_ID=MandrivaLinux
DISTRIB_RELEASE=2013.0
DISTRIB_CODENAME=mib
DISTRIB_DESCRIPTION="Mandriva Linux 2013.0"
'''
    path = 'N.A.'
    name = "Mandriva"
    data = dist_file_contents
    parsed_dist_file, parsed_dist_file_facts = df.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert parsed_dist_file is True

# Generated at 2022-06-23 01:07:57.282426
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():

    distribution_facts = Distribution(None).get_distribution_HPUX()

    # test the things that this code sets
    assert 'distribution_release' in distribution_facts
    assert 'distribution_version' in distribution_facts
    assert 'distribution_major_version' in distribution_facts

    # check the actual value for distribution_version matches the expected pattern
    assert re.search(r'^A\.[0-9]+\.[0-9]+$', distribution_facts['distribution_version']) is not None



# Generated at 2022-06-23 01:08:05.441512
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    import unittest
    from unittest.mock import patch
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):

        def run_command(self, args, use_unsafe_shell=False):
            return 0, 'HPUX-OE B.11.31.14304', ''
    module = TestModule()

    distribution_obj = Distribution(module)
    data = distribution_obj.get_distribution_HPUX()
    assert data['distribution_version'] == 'B.11.31'
    assert data['distribution_release'] == '14304'



# Generated at 2022-06-23 01:08:10.969610
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule({'platform': 'OpenBSD'})
    distribution = Distribution(module)
    actual = distribution.get_distribution_OpenBSD()
    expected = {'distribution_release': '6.4', 'distribution_version': '6.4'}
    assert actual == expected

# Generated at 2022-06-23 01:08:22.296218
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # prepare the test object
    module = AnsibleModule(argument_spec={})
    obj = Distribution(module)

    # prepare test data
    lines = ['10.15.6', '19F101']
    t_ansible_runner(lines=lines, backend="command",
                     command="'/usr/bin/sw_vers -productVersion'", become=False,
                     module_args=dict(),
                     ansible_facts=dict())
    with patch.object(obj.module, "run_command") as r:
        r.return_value = [0, "\n".join(lines), '']
        result = obj.get_distribution_Darwin()

    assert result == {'distribution': 'MacOSX', 'distribution_major_version': '10',
            'distribution_version': '10.15.6'}