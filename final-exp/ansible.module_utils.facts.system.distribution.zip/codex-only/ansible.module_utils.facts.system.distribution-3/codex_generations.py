

# Generated at 2022-06-23 00:58:27.653379
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = type('', (), {})()
    module.run_command = lambda *args, **kargs: (0, '10.3-STABLE', '')
    os_distribution = Distribution(module)
    expected = {
        'distribution_release': '10.3-STABLE',
        'distribution_version': '10.3',
        'distribution_major_version': '10'
    }
    actual = os_distribution.get_distribution_FreeBSD()
    assert actual == expected

# Generated at 2022-06-23 00:58:38.656718
# Unit test for constructor of class Distribution
def test_Distribution():
    import os
    import sys
    import unittest
    # Create a class with just the module's main function, and only if it doesn't exist yet
    # AnsibleModule is in ansible.module_utils.basic
    if 'ansible.module_utils.basic' not in sys.modules:
        sys.modules['ansible.module_utils.basic'] = module.AnsibleModule
    if 'Distribution' not in sys.modules:
        sys.modules['Distribution'] = Distribution
    if 'DistributionFiles' not in sys.modules:
        sys.modules['DistributionFiles'] = DistributionFiles
    if 'LinuxDistribution' not in sys.modules:
        sys.modules['LinuxDistribution'] = LinuxDistribution
    if 'LinuxFactFiles' not in sys.modules:
        sys.modules['LinuxFactFiles'] = LinuxFactFiles

# Generated at 2022-06-23 00:58:49.086916
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """
    test get_distribution_SunOS() of Distribution
    """
    fake_module = MagicMock()
    fake_module.run_command = MagicMock(return_value=(0, '', ''))
    fake_module.get_bin_path = MagicMock(return_value='')
    fake_module.get_file_content = MagicMock(return_value='')
    fake_module.file_exists = MagicMock(return_value=False)

    get_file_content_mock = MagicMock(return_value='')
    with patch.dict(Distribution.__dict__, {'get_file_content': get_file_content_mock}):
        dist = Distribution(fake_module)


# Generated at 2022-06-23 00:59:01.882868
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    import platform
    fake_module = MagicMock()

    fake_platform = MagicMock()
    fake_platform.platform = platform.platform
    fake_platform.system.return_value = "Darwin"
    fake_platform.release.return_value = "18.2.0"
    fake_platform.version.return_value = "Darwin Kernel Version 18.2.0: Fri Oct  5 19:41:49 PDT 2018; root:xnu-4903.221.2~2/RELEASE_X86_64"

    fake_module.run_command.return_value = (0, "", "")
    fake_smgl = MagicMock()
    fake_smgl.system = 'SGML'
    fake_smgl.release = "18.2.0"

# Generated at 2022-06-23 00:59:03.077193
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # file_content =
    pass

# Generated at 2022-06-23 00:59:12.139630
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    dist_file_facts = DistributionFiles().parse_distribution_file_Mandriva(
        "Mandriva",
        """DISTRIB_ID=MDS
DISTRIB_RELEASE=2008.0
DISTRIB_CODENAME=2oo8
DISTRIB_DESCRIPTION="Mandriva Linux 2008.0"
""",
        "/etc/mandriva-release",
        {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    )
    assert dist_file_facts == (
        True,
        {'distribution': 'Mandriva', 'distribution_release': '2oo8', 'distribution_version': '2008.0'}
    )

# Generated at 2022-06-23 00:59:21.358645
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    df = DistributionFiles()
    df.module = _AnsibleModule()
    df.collected_facts = {
        'distribution': 'CentOS',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA'
    }

    # Test with CentOS Stream
    name = 'CentOS-7'
    path = '/etc/os-release'

# Generated at 2022-06-23 00:59:31.382307
# Unit test for constructor of class Distribution
def test_Distribution():

    class MockModule(object):
        def __init__(self, run_command_results, check_enable_selinux_results, get_mount_results, normalize_module_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []
            self.check_enable_selinux_results = check_enable_selinux_results
            self.check_enable_selinux_calls = []
            self.get_mount_results = get_mount_results
            self.get_mount_calls = []
            self.normalize_module_results = normalize_module_results
            self.normalize_module_calls = []


# Generated at 2022-06-23 00:59:33.663533
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    collector = DistributionFactCollector()
    assert collector.name == 'distribution'
    assert isinstance(collector._fact_ids, set)
    assert 'distribution_release' in collector._fact_ids


# Generated at 2022-06-23 00:59:40.700592
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    test = DistributionFiles(None)
    name = 'OpenWrt'
    data = '''
    DISTRIB_ID=OpenWrt
    DISTRIB_RELEASE=15.01
    DISTRIB_REVISION=r487-5e43896
    DISTRIB_CODENAME=chaos_calmer
    DISTRIB_TARGET=ramips/mt7620
    DISTRIB_ARCH=mipsel_24kc
    DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.01"
    DISTRIB_TAINTS=no-all
    '''.strip()
    path = '/etc/openwrt_release'

# Generated at 2022-06-23 00:59:49.398018
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    d = DistributionFiles()
    assert d.parse_distribution_file_Amazon(None, None, None, None) == (True, {})
    assert d.parse_distribution_file_Amazon('Amazon', "AMAZON Linux", None, None) == (True, {'distribution': 'Amazon'})
    assert d.parse_distribution_file_Amazon('Amazon', "AMAZON Linux", '/etc/os-release', {'distribution': 'Amazon'}) == (True, {'distribution': 'Amazon'})

# Generated at 2022-06-23 01:00:00.684802
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import distribution_file_parsing_functions
    df = DistributionFiles()
    bfc = BaseFactCollector()

    # TODO: FIXME: add unit test for creating temp directory
    # TODO: FIXME: add unit test for creating temp files (process_dist_files)
    # TODO: FIXME: add unit test for getting path to dist files (process_dist_files)

    # dist_file_dict is a dict containing dicts of dist_file_name=dist_file_path, ie:
    # {ubuntu: /etc/lsb-release, etc}
    dist_file_dict = df.get_dist_files()
    # dist_files_facts is a dict containing dicts

# Generated at 2022-06-23 01:00:09.417817
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-23 01:00:14.578099
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    fixture = DistributionFixture()
    fixture.setup_distribution_facts()
    distro = Distribution(fixture.mock_module)
    distribution_facts = distro.get_distribution_facts()
    expected = fixture.expected_results()
    fixture.mock_module.fail_json.assert_not_called()
    assert distribution_facts == expected



# Generated at 2022-06-23 01:00:22.971133
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    mod = AnsibleModule(argument_spec={})
    parsed, dist_file_facts = DistributionFiles(mod).parse_distribution_file_NA('NA', 'NAME=NA', '/etc/os-release', {})
    assert parsed is True
    assert dist_file_facts['distribution'] == 'NA'
    assert dist_file_facts['distribution_version'] == 'NA'
    assert dist_file_facts['distribution_major_version'] == 'NA'
    assert dist_file_facts['distribution_release'] == 'NA'


# Generated at 2022-06-23 01:00:28.219913
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    distro_facts = Distribution(module=None).get_distribution_facts()
    distro_fact_collector = DistributionFactCollector()
    assert distro_fact_collector.name == 'distribution'
    assert distro_facts.keys() == distro_fact_collector._fact_ids



# Generated at 2022-06-23 01:00:29.395086
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    pass



# Generated at 2022-06-23 01:00:35.641293
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = FakeAnsibleModule()
    distribution = Distribution(module)
    expected_output = {
        'distribution_version': 'B.11.31',
        'distribution_release': '1486'
    }
    assert (distribution.get_distribution_HPUX() == expected_output)



# Generated at 2022-06-23 01:00:41.137079
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})

    distribution = Distribution(module)

    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '10'
    assert sunos_facts['distribution_release'] == 'Oracle Solaris 10'
    assert sunos_facts['distribution_major_version'] == '10'



# Generated at 2022-06-23 01:00:45.806925
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    """Returns dict with distribution, distribution_release and distribution_version fields."""
    distribution_darwin = Distribution.get_distribution_Darwin(object)
    assert distribution_darwin == {'distribution': 'MacOSX'}
    assert distribution_darwin['distribution'] == 'MacOSX'



# Generated at 2022-06-23 01:00:50.439217
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    D = DistributionFactCollector()
    assert D.name == 'distribution'
    assert D._fact_ids == set(['distribution_version',
                               'distribution_release',
                               'distribution_major_version',
                               'os_family'])


# Generated at 2022-06-23 01:00:53.522951
# Unit test for constructor of class Distribution
def test_Distribution():
    from ansible.module_utils.facts.collector.distribution import Distribution
    distribution = Distribution(module=None)
    return True


# Generated at 2022-06-23 01:01:03.088148
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    module = AnsibleModule(
        argument_spec=dict(
            collected_facts=dict(type='dict', required=True),
        ),
        supports_check_mode=True,
    )

    df = DistributionFiles(module)
    # case 1:
    name = 'Amazon'
    data = """ID=amzn
ID_LIKE=rhel fedora
NAME="Amazon Linux AMI"
VERSION="2015.03"
VERSION_ID="2015.03"
PRETTY_NAME="Amazon Linux AMI 2015.03"
ANSI_COLOR="0;33"
CPE_NAME="cpe:/o:amazon:linux:2015.03:ga"
HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
"""
    path = '/etc/os-release'

# Generated at 2022-06-23 01:01:12.130619
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    collected_facts = {}
    collected_facts['distribution_file_paths'] = (
        '/etc/os-release', '/etc/system-release', '/etc/system-release-cpe',
        '/etc/redhat-release'
    )
    collected_facts['distribution_file_content'] = [
        'NAME="Amazon Linux AMI"',
        'NAME="Amazon Linux"',
        'NAME="AmazonAMI"',
        'Amazon Linux release 2015.03',
        'Amazon Linux release 2015.03 (Final)'
    ]
    distro_file_obj = DistributionFiles()
    ret = distro_file_obj.parse_distribution_file_Amazon(
        'Amazon', 'Amazon Linux AMI', '/etc/os-release', collected_facts
    )
    assert ret[0] == True
    assert ret

# Generated at 2022-06-23 01:01:24.974067
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    # TODO: test distro like 'Alpine'
    # TODO: test distro like 'Flatcar'

    # init Distribution
    distribution = Distribution(module=module)

    # init test data
    # test_data keys are files in /etc, values are the content of those files

# Generated at 2022-06-23 01:01:30.866824
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # check parsing of a good file
    data = "Slackware 14.2"
    parsed, returned_facts = DistributionFiles().parse_distribution_file_Slackware(None, data, None, None)
    assert parsed is True
    assert returned_facts['distribution'] == 'Slackware'
    # check parsing of a bad file
    data = "Arch Linux"
    parsed, returned_facts = DistributionFiles().parse_distribution_file_Slackware(None, data, None, None)
    assert parsed is False



# Generated at 2022-06-23 01:01:40.300414
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = AnsibleModule(argument_spec={})
    test_data = []
    test_data.append({
        'stream': 'Debian',
        'expected_facts': {'distribution': 'Debian'},
        'distro_data': 'Debian'
    })
    test_data.append({
        'stream': '"Debian"',
        'expected_facts': {'distribution': 'Debian'},
        'distro_data': '"Debian"'
    })
    test_data.append({
        'stream': 'Cumulus\n',
        'expected_facts': {'distribution': 'Cumulus Linux'},
        'distro_data': 'Cumulus\n'
    })

# Generated at 2022-06-23 01:01:50.763702
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_file_facts = {}
    my_module = type('', (), {})()
    my_module.run_command = lambda x: ("", "", "")
    my_module.get_bin_path = lambda x: "some_path"

    try:
        distribution_files = DistributionFiles(module=my_module, facts=distribution_file_facts)
    except NameError:
        distribution_files = DistributionFiles()
    assert distribution_files is not None

    distribution_files.get_distribution = lambda: "Coreos"


# Generated at 2022-06-23 01:01:53.579631
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    """
    This test is written to check the __init__ function of class DistributionFactCollector
    """
    try:
        distributionfactcollector = DistributionFactCollector()
    except Exception as e:
        raise AssertionError(e)



# Generated at 2022-06-23 01:01:59.817194
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(
        argument_spec={},
    )
    dist = Distribution(module)
    dist_data = dist.get_distribution_OpenBSD()
    distro = dist_data.get('distribution', None)
    dist_rel = dist_data.get('distribution_release', None)
    dist_vers = dist_data.get('distribution_version', None)
    assert 'OpenBSD' == distro
    assert dist_rel
    assert '-' in dist_rel
    assert dist_vers == dist_rel

# Generated at 2022-06-23 01:02:00.841077
# Unit test for function get_uname
def test_get_uname():
    assert "Linux" in get_uname(module, '-a')



# Generated at 2022-06-23 01:02:10.035282
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    dist_files = DistributionFiles(None)
    dist_files._parse_distribution_file_Flatcar = MagicMock()
    collected_facts = {'distribution': 'flatcar', 'distribution_file_parsed': True}
    dist_files.parse_distribution_file('flatcar-linux', 'data', 'path', collected_facts)
    dist_files._parse_distribution_file_Flatcar.assert_called_once_with('flatcar-linux', 'data', 'path', collected_facts)

# Generated at 2022-06-23 01:02:14.755195
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    test_module = AnsibleModule(argument_spec=dict())
    test_distro = Distribution(test_module)
    test_data = test_distro.get_distribution_DragonFly()
    assert test_data['distribution_release'] == '5.8-RELEASE'


# Generated at 2022-06-23 01:02:26.842890
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Prepare environment for method to be tested.
    os_release_content = '''NAME="Amazon Linux"
#ID="amzn"
#ID_LIKE=rhel fedora
VERSION_ID="2"
VERSION="2 (2017.02)"
PRETTY_NAME="Amazon Linux 2"
ANSI_COLOR="0;33"
CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
HOME_URL="http://amazonlinux.com/"
'''
    os_release_path = '/etc/os-release'
    collected_facts = {'distribution': 'RedHat', 'distribution_version': 'NA'}
    # Prepare instance of DistributionFiles class, which we are going to test.
    distribution_files = DistributionFiles()

# Generated at 2022-06-23 01:02:27.882295
# Unit test for function get_uname
def test_get_uname():
    assert not get_uname(True)


# Generated at 2022-06-23 01:02:40.279870
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    """
    Unit test for method parse_distribution_file_Flatcar() of class DistributionFiles
    """
    class MockModule(object):
        """
        Mock class for ansible.module_utils.facts.system.distribution_files.Module
        """
        def __init__(self, params):
            self.params = params
            self.run_command_calls = list()

        def run_command(self, args, check_rc=None):
            self.run_command_calls.append(args)
            return (0, 'GROUP=alpha', '')

    class MockCollectedFacts(object):
        """
        Mock class for ansible.module_utils.facts.system.distribution_files.CollectedFacts
        """
        def __init__(self):
            self.data = dict()

       

# Generated at 2022-06-23 01:02:51.932593
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    test_script = dict()
    test_script['run_command'] = dict()
    test_script['run_command']['return_code'] = 0
    test_script['run_command']['stdout'] = \
'''
HPUX11i-OE-core/A.11.31.1405.0 (B.11.31.1405.0)
'''
    test_script['run_command']['stderr'] = \
'''
'''
    test_obj = Distribution.get_distribution_HPUX(test_script)
    assert test_obj['distribution_version'] == 'A.11.31'
    assert test_obj['distribution_release'] == '1405.0'


# Generated at 2022-06-23 01:03:02.976874
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    df = DistributionFiles()
    name = 'Debian'
    path = '/etc/os-release'
    facts = {}
    data = '''
NAME="Debian GNU/Linux"
VERSION_ID="9"
PRETTY_NAME="Debian GNU/Linux 9 (stretch)"
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
'''
    expected = {
        'distribution': 'Debian',
        'distribution_release': 'stretch',
    }
    parsed, centos_facts = df.parse_distribution_file_Debian(name, data, path, facts)
    assert parsed
    assert len(centos_facts) == len(expected)

# Generated at 2022-06-23 01:03:13.718284
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    """Test distribution Dragonfly in the Distribution class"""
    dragonfly_out = "DragonFly v5.1.0.300.g3a3a3a-RELEASE #0: Sun Feb 24 01:24:46 UTC 2019\n"
    dfly_facts = GetDistribution().get_distribution_DragonFly()
    assert dfly_facts['distribution'] == 'DragonflyBSD'
    assert dfly_facts['distribution_version'] == '5.1'
    assert dfly_facts['distribution_release'] == '5.1-RELEASE'

if __name__ == "__main__":
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.system import GetDistribution

# Generated at 2022-06-23 01:03:15.808209
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    module = AnsibleModule(argument_spec={})
    distro_file_obj = DistributionFiles(module)
    assert distro_file_obj is not None


# Generated at 2022-06-23 01:03:22.805378
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    os_facts = {}
    paths = ['/etc/slackware-version']
    module = None
    distro_files = DistributionFiles(module, paths, os_facts)
    data = 'Slackware 14.2'
    path = '/etc/slackware-version'
    name = 'Slackware'
    ret, slackware_facts = distro_files.parse_distribution_file_Slackware(name, data, path, os_facts)
    assert ret is True
    assert slackware_facts['distribution'] == 'Slackware'
    assert slackware_facts['distribution_version'] == '14.2'
    assert len(slackware_facts) == 2

    data = 'Slackware 1.0'
    ret, slackware_facts = distro_files.parse_distribution_file

# Generated at 2022-06-23 01:03:33.845728
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    collected_facts = {}
    df = DistributionFiles(collected_facts)

# Generated at 2022-06-23 01:03:45.859108
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Initialize mock object
    distribution_files_obj = DistributionFiles()

    # mock DistributionFiles.parse_distribution_file_ClearLinux

# Generated at 2022-06-23 01:03:57.795751
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    class_instance = DistributionFiles()
    data = "NAME=\"Debian GNU/Linux\"\nVERSION=\"10 (buster)\"\nID=debian\nHOME_URL=\"https://www.debian.org/\"\nSUPPORT_URL=\"https://www.debian.org/support\"\nBUG_REPORT_URL=\"https://bugs.debian.org/\""
    name = "Debian"
    path = "/etc/os-release"
    collected_facts = {'distribution_release': 'NA'}
    expected_results = ({'distribution': 'Debian', 'distribution_release': 'buster'}, True)
    result = class_instance.parse_distribution_file_Debian(name, data, path, collected_facts)
    assert(result == expected_results)


# Generated at 2022-06-23 01:04:06.042831
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    test_module = os.path.join(fixtures_path, 'get_distribution_HPUX.py')
    result = run_ansible_module(test_module, {})
    assert result.get('changed', False), "DistributionHPUXFacts did change the system"
    assert result['ansible_facts']['distribution_version'] == "B.11.23", "HPUX version is B.11.23"
    assert result['ansible_facts']['distribution_release'] == "43", "HPUX release is 43"
# # Unit test for method get_distribution_AIX of class Distribution

# Generated at 2022-06-23 01:04:16.991090
# Unit test for constructor of class Distribution
def test_Distribution():
    module = AnsibleModule(argument_spec={})

    distribution = Distribution(module)

    assert distribution.get_distribution_AIX()['distribution_version'] == '7.1'

    assert distribution.get_distribution_Darwin()['distribution'] == 'MacOSX'

    assert distribution.get_distribution_DragonFly()['distribution'] == 'DragonFly'

    assert distribution.get_distribution_FreeBSD()['distribution'] == 'FreeBSD'

    assert distribution.get_distribution_HPUX()['distribution'] == 'HP-UX'

    assert distribution.get_distribution_OpenBSD()['distribution'] == 'OpenBSD'

    assert distribution.get_distribution_SunOS()['distribution'] == 'SunOS'


# Generated at 2022-06-23 01:04:27.537416
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    distribution_files = DistributionFiles({})
    col_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}
    # Case:1 Distribution is Alpine
    data = "3.10.0-514.21.1.el7.x86_64"
    (parsed, parsed_dist_facts) = distribution_files.parse_distribution_file_Alpine('Alpine', data, 'path', col_facts)
    assert parsed == True
    assert parsed_dist_facts['distribution'] == 'Alpine'
    # Case:2 Distribution is not Alpine
    data = "Red Hat Enterprise Linux Server release 7.4 (Maipo)"

# Generated at 2022-06-23 01:04:37.166656
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = MagicMock()
    path = '/etc/mandriva-release'
    data = 'Mandriva Linux release 2010.0 (Official) for i586'
    name = 'Mandriva'
    collected_facts = {}
    distribution_files_creator = DistributionFiles(module)
    parsed_dist_file_facts = distribution_files_creator.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert parsed_dist_file_facts[0] == True
    assert parsed_dist_file_facts[1]['distribution_release'] == 'Official'


# Generated at 2022-06-23 01:04:48.446449
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Test without any data
    test_df = DistributionFiles()
    name = 'Coreos'
    data = ''
    path = ''
    collected_facts = {'distribution_version':'NA', 'distribution':'NA', 'distribution_release':'NA'}
    # the call to parse_distribution_file_Coreos
    parsed, parse_facts = test_df.parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert parsed == False
    assert parse_facts == {}

    # Test with valid data

# Generated at 2022-06-23 01:04:53.568670
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distfiles = DistributionFiles()
    name = 'Slackware'
    data = 'Slackware 14.2'
    path = 'test'
    collected_facts = {}
    parsed, facts = distfiles.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed is True
    assert 'Slackware' in facts['distribution']


# Generated at 2022-06-23 01:05:01.825234
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist_collector = DistributionFiles()

    assert len(dist_collector.distributions_dict) > 0
    assert len(dist_collector.distribution_files_dict) > 0
    assert dist_collector.distribution_files_dict['Amazon'] == ['/etc/os-release']
    assert dist_collector.distribution_files_dict['RedHat'] == ['/etc/redhat-release', '/etc/eos-release']

    for key in dist_collector.distributions_dict:
        assert len(dist_collector.distributions_dict[key].keys()) > 0
        for dist_key in dist_collector.distributions_dict[key]:
            assert dist_key in ['distribution', 'file', 'parse']


# Generated at 2022-06-23 01:05:14.403472
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-23 01:05:21.527541
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    t = DistributionFiles()
    assert t.parse_distribution_file_OpenWrt(name='OpenWrt', data='OpenWrt', path='foo',
                                             collected_facts={}) == (True, {'distribution': 'OpenWrt'})
    assert t.parse_distribution_file_OpenWrt(name='OpenWrt', data='', path='foo',
                                             collected_facts={}) == (False, {})

# Generated at 2022-06-23 01:05:31.477383
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    import os

    from ansible.module_utils.facts.system.distribution import DistributionFiles

    distribution_file_facts = DistributionFiles(dict())

# Generated at 2022-06-23 01:05:42.500262
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    """
    Test get_distribution_FreeBSD method of class Distribution
    """
    import platform
    m = MagicMock()
    def side_effect1(*args, **kwargs):
        return [0, '12.0-RELEASE', None]
    def side_effect2(*args, **kwargs):
        return [0, '12.0-RELEASE-p1', None]
    def side_effect3(*args, **kwargs):
        return [0, '12.1-RELEASE', None]
    m.run_command.side_effect = [side_effect1(), side_effect2(), side_effect3()]
    d = Distribution(m)
    result = d.get_distribution_FreeBSD()

    assert result['distribution_version'] == '12.0'

# Generated at 2022-06-23 01:05:49.542850
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    df = DistributionFiles()
    data = 'Slackware'
    path = ''
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}
    result = df.parse_distribution_file_Slackware('Slackware',data,path,collected_facts)
    expected = True, {'distribution': 'Slackware', 'distribution_version': 'NA'}
    assert result == expected


# Generated at 2022-06-23 01:05:59.141537
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    source_data = '{"NAME": "Flatcar Linux", "ID": "flatcar", "VERSION": "2602.4.0 (Celadon Canary)", "BUILD_ID": "2018-09-14-0500", "BUILD_ID": "2018-09-14-0500", "BUILD_ID": "2018-09-14-0500", "BUILD_ID": "2018-09-14-0500", "BUILD_ID": "2018-09-14-0500", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",}'
    parsed_dist_file = DistributionFiles.parse_distribution_file_Flatcar('Flatcar', source_data, '', {})
    assert parsed_dist_file

# Generated at 2022-06-23 01:06:07.372375
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    """DistributionFiles - basic class checks"""
    d = DistributionFiles({}, [], {}, {}, {}, {})
    os_facts = {}
    _name = 'NA'
    _path = ''
    _data = ''
    _collected_facts = {}
    obj = DistributionFiles({}, [], {}, {}, {}, {})
    assert not d.process_dist_files(os_facts, _name, _path, _data, _collected_facts)

# Generated at 2022-06-23 01:06:08.336397
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles

# Generated at 2022-06-23 01:06:17.652732
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_obj = DistributionFiles() # create object of class DistributionFiles
    path = '/etc/os-release' # string to use as a file path
    file_content = '''NAME="Amazon Linux AMI"
                      VERSION="2018.03"
                      ID="amzn"
                      ID_LIKE="rhel fedora"
                      VERSION_ID="2018.03"
                      PRETTY_NAME="Amazon Linux AMI 2018.03"
                      ANSI_COLOR="0;33"
                      CPE_NAME="cpe:/o:amazon:linux:2018.03:ga"
                      HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
                      ''' # string to use as file content

# Generated at 2022-06-23 01:06:23.306317
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Setup
    test_object = DistributionFiles(None)
    distribution_name = 'NA'
    distribution_content = ''
    distribution_path = ''
    collected_facts = {}

    # Exercise
    test_object.parse_distribution_file_NA(distribution_name, distribution_content, distribution_path, collected_facts)


# Generated at 2022-06-23 01:06:35.236468
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    content = '''DISTRIB_ID="OpenWrt"
DISTRIB_RELEASE="Chaos Calmer"
DISTRIB_REVISION="r47273"
DISTRIB_TARGET="ath79/generic"
DISTRIB_ARCH="mips_24kc"
DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"
DISTRIB_TAINTS=""
'''

    params = {}
    result = {
        "distribution": "OpenWrt",
        "distribution_version": "Chaos Calmer",
        "distribution_release": "r47273"
    }

    dist_file = DistributionFiles(params)
    assert dist_file.parse_distribution_file_OpenWrt("name", content, "path", {}) == (True, result)


# Unit test

# Generated at 2022-06-23 01:06:40.111181
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Create an instance of DistributionFiles
    distribution_files = DistributionFiles({}, [], [], "", "", "", "")
    parsed = distribution_files.parse_distribution_file_Amazon('Amazon', 'Amazon', '/etc/os-release', {})
    assert parsed[0]



# Generated at 2022-06-23 01:06:49.873158
# Unit test for function get_uname
def test_get_uname():
    from ansible.module_utils.facts.utils import ModuleTestCase
    class MockModule(object):
        def run_command(self, cmd):
            if cmd == ['uname', '-v']:
                return (0, 'A', None)
        def get_bin_path(self, path, opt_dirs=[]):
            return 'uname'
    module = MockModule()
    rc, out, err = module.run_command(['uname', '-v'])
    assert rc == 0
    assert out == 'A'
    assert get_uname(module) == 'A'


# Generated at 2022-06-23 01:06:57.531972
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    """ Tests the "get_distribution_AIX" method of class "Distribution"
    """

    class MockModule(object):
        def run_command(self, cmd, **args):
            return 0, "7 4", ""

    mock = MockModule()

    # For now it just test the default
    d = Distribution(mock)
    res = d.get_distribution_AIX()

    expected = {
        'distribution_major_version': '7',
        'distribution_version': '7.4'
    }

    assert res == expected



# Generated at 2022-06-23 01:07:06.936066
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    distributionFiles = DistributionFiles(module)
    # test
    assert distributionFiles.parse_distribution_file_Coreos('Coreos', '', '/etc/os-release', {
        'distribution_version': 'NA',
        'distribution': 'NA',
        'distribution_release': 'NA'
    }) == (True, {'distribution_release': 'stable'})
# Test for method distribution_file_facts() of class DistributionFiles

# Generated at 2022-06-23 01:07:15.883103
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distfile = DistributionFiles()

    name = 'NA'
    data = '\n'.join(['NAME=CentOS', 'VERSION=7'])
    path = ''
    collected_facts = {'distribution_version': 'NA'}
    exp_parse_success = True
    exp_parsed_facts = {'distribution': 'CentOS',
                        'distribution_version': '7'}
    parse_success, parsed_facts = distfile.parse_distribution_file_NA(name,
                                                                      data,
                                                                      path,
                                                                      collected_facts)
    assert parse_success == exp_parse_success
    assert parsed_facts == exp_parsed_facts


# Generated at 2022-06-23 01:07:19.108128
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(None) is not None



# Generated at 2022-06-23 01:07:21.135477
# Unit test for constructor of class Distribution
def test_Distribution():
    dist = Distribution(module=None)
    assert dist != None


# Generated at 2022-06-23 01:07:33.008593
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    m = DistributionFiles()
    old_python_ver = sys.version_info
    # python 2
    sys.version_info = tuple([2] + sys.version_info[1:])

# Generated at 2022-06-23 01:07:45.173335
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    '''Method parse_distribution_file_Coreos of class DistributionFiles, return data dictionary
    with distribution_release as key for valid Flatcar distribution.
    '''

# Generated at 2022-06-23 01:07:51.014199
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # TODO: change to use fixture
    module = AnsibleModule(
    )
    distribution_object = Distribution(module)
    assert distribution_object.get_distribution_SunOS() == {'distribution': 'Solaris', 'distribution_version': '11', 'distribution_release': '11.4', 'distribution_major_version': '11'}



# Generated at 2022-06-23 01:07:59.243731
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distributionfiles = DistributionFiles()
    distributionfiles.module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

# Generated at 2022-06-23 01:08:05.471263
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    expected = {'distribution_release': '5.7-RELEASE'}
    actual = distribution.get_distribution_DragonFly()
    assert expected == actual


# Generated at 2022-06-23 01:08:07.195512
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    # Implement me
    return None


# Generated at 2022-06-23 01:08:10.783443
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module=module)

    result = distribution.get_distribution_AIX()

    assert 'distribution_major_version' in result
    assert 'distribution_version' in result
    return True



# Generated at 2022-06-23 01:08:20.178742
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Amazon Linux 1
    module = AnsibleModule(argument_spec=dict())
    file_data1 = 'NAME="Amazon Linux AMI"\nVERSION="2017.12"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2017.12"\nPRETTY_NAME="Amazon Linux AMI 2017.12"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2017.12:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path1 = '/etc/system-release'