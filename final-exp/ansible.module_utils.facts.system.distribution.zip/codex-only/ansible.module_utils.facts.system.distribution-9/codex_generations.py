

# Generated at 2022-06-23 00:58:21.135117
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    facts = distribution.get_distribution_FreeBSD()
    assert facts['distribution'] == 'FreeBSD'



# Generated at 2022-06-23 00:58:27.654062
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    from ansible.module_utils.facts.system.distribution import Distribution
    import unittest.mock as mock

    # create the mock module
    test_module = mock.MagicMock()

    # create the distribution object and run the mocked module
    distribution = Distribution(test_module)
    distribution_facts = distribution.get_distribution_SMGL()

    assert distribution_facts['distribution'] == 'Source Mage GNU/Linux'


# Generated at 2022-06-23 00:58:37.645383
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    distro_module = DistributionFiles(MockModule())
    dist_file_facts = {}
    # no dist_files
    dist_files = distro_module.process_dist_files(dist_file_facts, [])
    assert len(dist_files) == 0
    # 1 dist_file
    dist_files = distro_module.process_dist_files(dist_file_facts, ['os-release'])
    assert len(dist_files) == 1
    # 2 dist_files
    dist_files = distro_module.process_dist_files(dist_file_facts, ['os-release', 'lsb-release'])
    assert len(dist_files) == 2


# Generated at 2022-06-23 00:58:41.565860
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        smgl = Distribution('module')
        facts = smgl.get_distribution_SMGL()
        assert facts['distribution'] == 'Source Mage GNU/Linux'

# Generated at 2022-06-23 00:58:49.654026
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    """
    Test if method get_distribution_Darwin works correctly
    """
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "ProductVersion: 10.14.6\nBuildVersion: 18G6020", ""))
    distribution = Distribution(module)
    result = distribution.get_distribution_Darwin()
    assert result['distribution'] == 'MacOSX'
    assert result['distribution_major_version'] == '10'
    assert result['distribution_version'] == '10.14.6'


# Generated at 2022-06-23 00:58:57.580896
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    df = DistributionFiles({})
    assert df.files == ['/etc/issue', '/etc/redhat-release', '/etc/SuSE-release', '/etc/os-release', '/etc/lsb-release', '/etc/debian_version', '/etc/system-release', '/etc/alpine-release', '/etc/arch-release', '/etc/coreos/update.conf', '/usr/lib/os-release', '/etc/issue.net']


# Generated at 2022-06-23 00:59:08.424491
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    from ansible_collections.testns.testcoll.plugins.module_utils.facts.system.distribution import Distribution
    import pytest

    class MockModule:
        def __init__(self):
            self.run_command_expect = None
            self.run_command_result = None

        def run_command(self, cmd, check_rc=False):
            if cmd != self.run_command_expect:
                raise Exception("Unexpected command: %s" % cmd)
            return self.run_command_result

    module = MockModule()
    module.run_command_expect = r"/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'"

# Generated at 2022-06-23 00:59:11.061763
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('Windows 10') != None
    assert get_uname('Linux') != None
    assert get_uname('Darwin') != None


# Generated at 2022-06-23 00:59:20.390777
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule({})
    distribution_files = DistributionFiles(module)
    data = '''
    DISTRIB_ID=MandrivaLinux
    DISTRIB_RELEASE=2014.1
    DISTRIB_CODENAME=Connie
    DISTRIB_DESCRIPTION="Mandriva Linux 2014.1"
    '''
    name = "Mandriva"
    path = '/etc/lsb-release'
    collected_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA'
    }
    expected_mandriva_facts = {
        'distribution': 'Mandriva',
        'distribution_release': 'Connie',
        'distribution_version': '2014.1'
    }
    parsed, mandriva_

# Generated at 2022-06-23 00:59:27.550923
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    dist_file_facts = {}
    test_data = '3.10.3'
    name = 'Alpine'
    path = 'NA'
    collected_facts = {}
    dist_file_facts['distribution'] = 'Alpine'
    dist_file_facts['distribution_version'] = test_data
    result = DistributionFiles.parse_distribution_file_Alpine(DistributionFiles(), name, test_data, path, collected_facts)
    assert result == (True, dist_file_facts)


# Generated at 2022-06-23 00:59:31.966075
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution = Distribution(None)
    distribution_results = distribution.get_distribution_OpenBSD()
    distribution_results_expected = {
        'distribution_release': '6.4',
        'distribution_version': '6.4'
    }
    assert distribution_results == distribution_results_expected

# Generated at 2022-06-23 00:59:40.440448
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    ''' test parse_distribution_file_Slackware '''
    # test data
    df_data = """
Slackware 14.2.0
"""
    df_name = 'Slackware'
    collected_facts = {
        'distribution': 'NA',
        'distribution_major_version': 'NA',
        'distribution_version': 'NA',
        'lsb': {
            'distcodename': 'NA',
            'distdescription': 'NA',
            'distid': 'NA',
            'distrelease': 'NA',
            'distshortid': 'NA',
            'majdistrelease': 'NA',
            'minordistrelease': 'NA'
        }
    }

    # expected result

# Generated at 2022-06-23 00:59:43.174788
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # TODO: replace with a mock
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    returned_value = dist.get_distribution_DragonFly()
    assert returned_value == {'distribution_release': '5.8-RELEASE'}

# Generated at 2022-06-23 00:59:51.306024
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    df = DistributionFiles()
    fake_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA'
    }

    # Debian
    parse_dist_facts = df.parse_distribution_file_Debian('Debian', 'PRETTY_NAME="Debian GNU/Linux 9 (stretch)"', '/etc/os-release', fake_facts)
    assert parse_dist_facts[0] == True, parse_dist_facts[1]
    assert parse_dist_facts[1]['distribution'] == 'Debian', parse_dist_facts[1]
    assert parse_dist_facts[1]['distribution_version'] == 'NA', parse_dist_facts[1]
    assert parse

# Generated at 2022-06-23 01:00:03.667880
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    data = {"os_facts": {}, "collected_facts": {}}
    data["collected_facts"] = {"distribution_file_facts": {}}
    distro_file = DistributionFiles(data)

    # for each test, 'data' is the distro file content, and 'version' the version detected

# Generated at 2022-06-23 01:00:15.016817
# Unit test for method get_distribution_facts of class Distribution

# Generated at 2022-06-23 01:00:26.241009
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    facts = dict()
    facts['product_name'] = 'NA'
    facts['distribution'] = 'NA'
    facts['distribution_release'] = 'NA'
    facts['distribution_major_version'] = 'NA'
    facts['distribution_version'] = 'NA'

    d = DistributionFiles()

    # Test 1 - distribution_file_parsers test 1
    # Test is done by testing .dist files in turn
    distribution_file_parsers = d.distribution_file_parsers
    for name in distribution_file_parsers.keys():
        data = get_file_content(os.path.join(dist_files_path, name))
        parsed_dist_file_facts = d.parse_distribution_file(name, data, facts)

# Generated at 2022-06-23 01:00:37.486410
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=False),
            contents=dict(type='str', required=False),
            collected_facts=dict()
        )
    )

    coreos_facts = {}
    coreos_facts['distribution_release'] = 'beta'


# Generated at 2022-06-23 01:00:49.976466
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """ Test if reading from /etc/release works properly """
    from ansible.module_utils.facts import Distribution
    # create mock object
    class MockModule:
        def run_command(self, cmd, data=None, check_rc=False, close_fds=True, executable=None,
                        use_unsafe_shell=False, env_string=None):
            # return a tuple
            return (0, '', '')
    module = MockModule()
    # mock function "get_file_content"
    # TODO: this mock code is not working, need to fix it
    # Distribution.get_file_content = (lambda x: "/etc/product")
    # mock function "get_uname"
    Distribution.get_uname = (lambda x, y: "testversion")
    SunOS = Distribution(module)


# Generated at 2022-06-23 01:01:00.834267
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    dist_file = DistributionFiles({})
    flatcar_data = 'GROUP="beta"\nID="flatcar"\nVERSION="1911.3.0"\nVERSION_ID="1911.3.0"\nBUILD_ID="2797"\n'
    io_data = StringIO(flatcar_data)
    collected_facts = {'distribution': 'flatcar', 'distribution_release': 'NA'}

    result = dist_file.parse_distribution_file_Flatcar('flatcar', io_data.read(), '/etc/flatcar-release', collected_facts)

    assert result == (True, {'distribution_release': 'beta'})

collect

# Generated at 2022-06-23 01:01:10.164403
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # Same test as for get_distribution_FreeBSD
    assert get_distribution_AIX() == {'distribution_major_version': '6', 'distribution_version': '6.1', 'distribution_release': '1'}
    assert get_distribution_HPUX() == {'distribution_release': '1122', 'distribution_version': 'B.11.31'}
    assert get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.15.3'}
    assert get_distribution_FreeBSD() == {'distribution_release': '11.3-RELEASE-p10', 'distribution_major_version': '11', 'distribution_version': '11.3'}

# Generated at 2022-06-23 01:01:23.111181
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    mod = AnsibleModule({})
    distfiles = DistributionFiles(mod)

    # test Debian
    data = dedent("""
        NAME="Debian GNU/Linux"
        VERSION="8 (jessie)"
        ID=debian
        ID_LIKE=debian
        ANSI_COLOR="1;31"
        HOME_URL="http://www.debian.org/"
        SUPPORT_URL="http://www.debian.org/support/"
        BUG_REPORT_URL="https://bugs.debian.org/"
        """)
    parsed_facts = distfiles.parse_distribution_file('Debian', data, '/etc/os-release')
    assert parsed_facts['distribution'] == 'Debian'
    assert parsed_facts['distribution_release'] == 'jessie'

# Generated at 2022-06-23 01:01:33.763146
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModuleMock()
    dist_files = DistributionFiles(module)
    collected_facts = {'distribution_release': 'NA'}
    name = 'Flatcar'
    path = '/etc/os-release'

# Generated at 2022-06-23 01:01:46.013976
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    ALAS_FILE_NAME = 'alas.txt'
    ALAS_FILE_CONTENT = '4.4.6-300.fc24'

    DISTRIBUTION_FILE_FACTS = 'ansible_facts.distribution_file'
    DISTRIBUTION_FILE_PATH = 'ansible_facts.distribution_file_path'
    DISTRIBUTION_FILE_PARSED = 'ansible_facts.distribution_file_parsed'
    DISTRIBUTION_FILE_VARIETY = 'ansible_facts.distribution_file_variety'
    DISTRIBUTION_FILE_FACTS_MISSING = 'ansible_facts.distribution_file_facts_missing'
    DISTRIBUTIONS_MODULE_PATH = get_file_content('/etc/ansible/distributions.json')

   

# Generated at 2022-06-23 01:01:56.352665
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # pylint: disable=protected-access
    collected_facts = DistributionFiles()._get_distribution_files_facts()


# Generated at 2022-06-23 01:02:00.597112
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    dummy_module = DummyAnsibleModule()
    fact_collector = DistributionFactCollector()
    fact_collector.collect(module=dummy_module, collected_facts={})
    assert 'distribution_version' in dummy_module.collected_facts
    assert 'distribution_release' in dummy_module.collected_facts

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Distribution Files fact class
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-23 01:02:13.010336
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModule(argument_spec={})
    dist_file_parser = DistributionFiles(module)
    data = "NAME=Flatcar Container Linux\nID=flatcar\nVERSION=1373.6.0\nVERSION_ID=1373.6.0\nBUILD_ID=2016-01-08-0142\nPRETTY_NAME=\"Flatcar Container Linux 1373.6.0 (Container Linux by CoreOS)\"\nANSI_COLOR=\"0;32\"\nHOME_URL=\"https://coreos.com/\"\nBUG_REPORT_URL=\"https://bugs.coreos.com/\"\nCONTAINER=oci"
    name = "flatcar"
    path = "/etc/os-release"
    collected_facts = {}

# Generated at 2022-06-23 01:02:26.392374
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    """
    Test the Flatcar parsing method
    """
    # Read in an example Flatcar os-release file
    with open('tests/data/flatcar_os_release.txt') as flatcar_file:
        data = flatcar_file.read()

    # Create instance of DistributionFiles class
    dist_files = DistributionFiles()
    # Set some defaults for the collected_facts dictionary
    # which is argument parsed from a YAML file
    collected_facts = {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA', 'distribution_file_variety': 'NA', 'distribution_file_path': 'NA', 'distribution_file_parsed': False, 'distribution_file_paths': []}
    # Set the path to the os-release file
    flatcar_

# Generated at 2022-06-23 01:02:38.858188
# Unit test for method process_dist_files of class DistributionFiles

# Generated at 2022-06-23 01:02:44.773781
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    from ansible.module_utils.facts.collector.distribution import Distribution

    distribution = Distribution(None)
    distribution_NetBSD_facts = distribution.get_distribution_NetBSD()
    assert distribution_NetBSD_facts.get('distribution_release') == platform.release()
    assert distribution_NetBSD_facts.get('distribution_major_version') == '9'
    assert distribution_NetBSD_facts.get('distribution_version') == '9.1'



# Generated at 2022-06-23 01:02:53.735925
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    d = DistributionFiles()
    facts = {}
    centos_file_content = '''
LSB_VERSION="core-4.1-amd64:core-4.1-noarch:core-3.2-amd64:core-3.2-noarch:core-4.0-amd64:core-4.0-noarch:core-3.1-amd64:core-3.1-noarch"
CentOS Stream release 5.2 (Verne)
'''
    expected_facts = {
        "distribution_release": "Stream",
    }
    centos_stream = d.parse_distribution_file_CentOS("CentOS", centos_file_content, "path", facts)
    for key in expected_facts:
        assert centos_stream[1][key] == expected_facts[key]


# Generated at 2022-06-23 01:02:59.848749
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(argument_spec={})
    for os_name in Distribution.OS_FAMILY.keys():
        if os_name == 'MacOSX':
            continue
        module.params['_ansible_sys_platform'] = os_name.lower()
        distro = Distribution(module=module)
        facts = distro.get_distribution_facts()
        if not facts.get('distribution'):
            raise Exception('Distribution for %s not present in %s' % (os_name, facts))
        print('Passed for %s' % os_name)
        if not facts.get('distribution_major_version'):
            raise Exception('Major version for %s not present in %s' % (os_name, facts))
        print('Passed for %s major version' % os_name)


# Generated at 2022-06-23 01:03:04.347040
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    """Unit tests for facts.get_distribution_FreeBSD()."""

    # Fact._module needs to be set to an instance of the FakeModule class,
    # otherwise the test fails

    module = fake_module_class(**_regular_facts)
    module.run_command = _mock_command_for_distribution
    module._module.run_command = _mock_command_for_distribution
    test_object = Distribution(module)


# Generated at 2022-06-23 01:03:06.562581
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    def mock_run_command(self, cmd, use_unsafe_shell=False):
        return (0, "HPUX.OE.A.09.00.0000.000000.0", "")
    Distribution.get_distribution_HPUX = mock_run_command
    d = Distribution(None)
    return d.get_distribution_HPUX()

# Generated at 2022-06-23 01:03:15.901960
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule(argument_spec={})
    distro_file_facts = DistributionFiles(module)
    # distro_file_facts = DistributionFiles()
    # distro_file_facts is an instance of DistributionFiles class
    name = 'OpenWrt'
    path = '/etc/nil'
    collected_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA',
        'distribution_file_path': 'NA',
        'distribution_file_variety': 'NA',
        'distribution_file_parsed': False
    }

# Generated at 2022-06-23 01:03:29.674924
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    """
    Test case for method parse_distribution_file_OpenWrt of class DistributionFiles
    """
    distribution_files = DistributionFiles(dict())
    input_data = """
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=15.05.1
DISTRIB_REVISION=r48532
DISTRIB_CODENAME=chaos_calmer
DISTRIB_TARGET=ramips/rt305x
DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"
DISTRIB_TAINTS=no-all
"""
    expected_output = {'distribution': 'OpenWrt',
                       'distribution_version': '15.05.1',
                       'distribution_release': 'chaos_calmer'}
    assert distribution_files.parse_distribution_

# Generated at 2022-06-23 01:03:40.130689
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Note: lazy import to speed up import time
    import collections
    import sys
    import tempfile
    import os
    import textwrap

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.collector.distribution import DistributionFiles

    # This print is not really needed, it helps the unit test stand alone
    print("Testing parse_distribution_file_Debian of class DistributionFiles")

    def get_bin_path(program):
        return program

    def get_file_content(filename):
        return collected_facts[filename]

    def get_distribution():
        return None


# Generated at 2022-06-23 01:03:40.875405
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    pass


# Generated at 2022-06-23 01:03:50.290723
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    """Unit test for method parse_distribution_file_SUSE of class DistributionFiles"""
    class ModuleMock():
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name):
            return 'mocked_commands/' + name

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            if cmd.endswith('dpkg'):
                return 0, 'mocked output for dpkg', 'mocked stderr for dpkg'
            return 0, '', ''

    module_mock = ModuleMock()
    dist_files = DistributionFiles(module_mock)

    # case for parse_distribution_file_SUSE
    # os-release

# Generated at 2022-06-23 01:04:01.783615
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_files = DistributionFiles()
    label1 = "clearlinux"
    result1, fact1 = distribution_files.parse_distribution_file_ClearLinux(label1, "NAME=\"clearlinux\"","/etc/os-release", {})
    assert result1 and fact1["distribution"] == "clearlinux"
    label2 = "clearlinux"
    result2, facts2 = distribution_files.parse_distribution_file_ClearLinux(label2, "","/etc/os-release", {})
    assert not result2
    label3 = "clearlinux"
    result3, facts3 = distribution_files.parse_distribution_file_ClearLinux(label3, "NAME=\"clearlinux\"","/etc/os-release", {})
    assert result3
    label4 = "clearlinux"
    result4, facts4 = distribution

# Generated at 2022-06-23 01:04:14.566987
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # First find an AIX, for this test to work correctly
    hostname = socket.gethostname()
    if '.' in hostname:
        fqdn = hostname
    else:
        fqdn = socket.getfqdn(hostname)

    if not fqdn.endswith('.aix.cc.swin.edu.au'):
        raise Exception('This is not AIX')

    test_module = AnsibleModule(argument_spec={})  # without the argument_spec the AnsibleModule complains about missing options
    test_distribution_AIX = Distribution(test_module)
    test_distribution_AIX.get_distribution_AIX()

# Generated at 2022-06-23 01:04:15.895933
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    pass

# Generated at 2022-06-23 01:04:27.051971
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    test_obj = DistributionFiles()
    test_data = '''
        SLES_SAP 12 SP2
        NAME="SLES_SAP"
        VERSION="12.2"
        VERSION_ID="12.2"
        PRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"
        ID="sles_sap"
        ANSI_COLOR="0;32"
        CPE_NAME="cpe:/o:suse:sles_sap:12:sp2"
    '''
    expected_result = {
        'distribution': 'SLES_SAP',
        'distribution_major_version': '12',
        'distribution_version': '12.2',
        'distribution_release': '2',
    }
    # test_obj.parse_distribution_file_S

# Generated at 2022-06-23 01:04:39.118411
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_file_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA'
    }
    df = DistributionFiles(None)
    parsed, facts = df.parse_distribution_file_SUSE("openSUSE", "openSUSE 13.1 (Bottle) (x86_64)\nVERSION = 13.1\nCODENAME = Bottle\n", '/etc/SuSE-release', dist_file_facts)
    assert parsed == True
    assert facts['distribution'] == 'openSUSE'
    assert facts['distribution_version'] == '13.1'
    assert facts['distribution_release'] == 'Bottle'


# Generated at 2022-06-23 01:04:46.208427
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    dist_file = DistributionFiles()
    assert dist_file.parse_distribution_file_Coreos('CoreOS', 'GROUP=stable', '', {}) == (True, {'distribution_release': 'stable'})
    assert dist_file.parse_distribution_file_Coreos('CoreOS', 'GROUP=alpha', '', {}) == (True, {'distribution_release': 'alpha'})
    assert dist_file.parse_distribution_file_Coreos('CoreOS', '', '', {}) == (False, {})



# Generated at 2022-06-23 01:04:56.441208
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    d = DistributionFiles()
    fact_dict = {'distribution': '', 'distribution_version': '', 'distribution_release': ''}
    # test process_dist_files for valid facts
    for file_name, file_content in d.dist_files.items():
        dist_file_facts = d.process_dist_file(file_name, file_content, 'test_path', fact_dict)
        distribution = dist_file_facts['distribution']
        version = dist_file_facts['distribution_version']
        release = dist_file_facts['distribution_release']

# Generated at 2022-06-23 01:04:59.320382
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    assert Distribution(None).get_distribution_SunOS() == {'distribution': 'SmartOS', 'distribution_release': 'SmartOS snv_151a\n', 'distribution_version': 'snv_151a'}

# Generated at 2022-06-23 01:05:05.462307
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    import platform

    module = Mock()
    module.run_command.return_value = (0, '10.10.5', '')
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()

    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.10.5'

# Generated at 2022-06-23 01:05:20.822404
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # create an instance of DistributionFiles for testing
    test_distfile = DistributionFiles()

    # create a collection of facts for testing
    # FIXME: should not be mutating collected_facts here
    collected_facts = {'distribution': 'NA',
                       'distribution_release': 'NA',
                       'distribution_version': 'NA'}
    # Test a known Debian release

# Generated at 2022-06-23 01:05:29.871904
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    test_module = Mock()
    test_module.run_command.return_value = 0, 'Linux', ''
    test_module.get_bin_path.return_value = '/usr/bin/'
    test_module.params.get.return_value = ''
    test_collector = DistributionFactCollector(test_module)
    collected_facts = test_collector.collect()
    assert collected_facts.get('distribution', None) is not None
    assert collected_facts.get('distribution', None) == 'Linux'
    assert collected_facts.get('distribution_version', None) is not None
    assert collected_facts.get('distribution_release', None) is not None
    assert collected_facts.get('distribution_major_version', None) is not None


# Generated at 2022-06-23 01:05:39.422954
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = {}
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results[cmd]

        def get_bin_path(self, cmd, default=None, opt_dirs=[]):
            return '/usr/bin/' + cmd

    mmod = MockModule()
    d = Distribution(mmod)
    if d.get_distribution_SMGL() == {'distribution': 'Source Mage GNU/Linux'}:
        return True



# Generated at 2022-06-23 01:05:50.413888
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    """
    Test for method get_distribution_HPUX of class Distribution
    :return:
    """
    d = Distribution({})

    #
    # There's no good way to test this without the target system matching all the conditions below
    # However, we can test with a mocked system to get the code coverage.
    #
    d.module.run_command = lambda args, use_unsafe_shell: (0, '', '')

    # Invalid data
    d.module.run_command = lambda args, use_unsafe_shell: (0, '', '')
    assert d.get_distribution_HPUX() == {}

    # Valid data

# Generated at 2022-06-23 01:05:52.358901
# Unit test for constructor of class Distribution
def test_Distribution():
    distro = Distribution(module=None)
    assert distro is not None



# Generated at 2022-06-23 01:06:03.653122
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Mock facts with Amazon Information
    os_release_path_facts = {
        "distribution_file_path":"/etc/os-release",
        "distribution_file_distro_name":"Amazon",
        "distribution_file_content":"""NAME="Amazon Linux AMI"
VERSION="2015.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2015.03"
PRETTY_NAME="Amazon Linux AMI 2015.03"
""",
        "distribution_file_data":"""NAME="Amazon Linux AMI"
VERSION="2015.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2015.03"
PRETTY_NAME="Amazon Linux AMI 2015.03"
""",
    }
    amazon_summary_path_

# Generated at 2022-06-23 01:06:13.917975
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    _platform_system = os.name
    os.name = 'posix'
    platform.system = lambda: 'FreeBSD'
    platform.release = lambda: '10.1-RELEASE'

    del os.environ['PATH']
    os.environ['PATH'] = '/bin:/usr/bin'

    d = Distribution(AnsibleModule)
    result = d.get_distribution_FreeBSD()

    assert result == dict(
        distribution='FreeBSD',
        distribution_release='10.1-RELEASE',
        distribution_major_version='10',
        distribution_version='10.1'
    )

    del os.environ['PATH']
    os.environ['PATH'] = '/bin:/usr/bin'

    platform.release = lambda: '10.1-RELEASE-p1'


# Generated at 2022-06-23 01:06:24.268353
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distribution = Distribution(None)
    dragonfly_facts = distribution.get_distribution_DragonFly()
    assert dragonfly_facts

    assert dragonfly_facts['distribution_release'] == platform.release()

    rc, out, dummy = distribution.module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dragonfly_facts['distribution_major_version'] == match.group(1)
        assert dragonfly_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]



# Generated at 2022-06-23 01:06:36.816983
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # Testing with '5.5.1-STABLE'
    out = '5.5.1-STABLE'
    module = Mock()
    module.run_command.return_value = 0, out, ''
    distribution = Distribution(module)
    res = distribution.get_distribution_DragonFly()
    assert res == {'distribution_release': '5.5.1-STABLE'}

    module = Mock()
    module.run_command.return_value = 0, '', ''
    distribution = Distribution(module)
    res = distribution.get_distribution_DragonFly()
    assert res == {'distribution_release': ''}

    # Testing with '4.9.0-RELEASE'
    out = '4.9.0-RELEASE'
    module = Mock()

# Generated at 2022-06-23 01:06:40.382204
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(['-v']) == 'Darwin Kernel Version 14.3.0: Mon Mar 23 11:59:05 PDT 2015; root:xnu-2782.20.48~5/RELEASE_X86_64'


# Generated at 2022-06-23 01:06:53.450669
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    class TestModule(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def run_command(self, cmd):
            return 0, '', ''

    name = 'CentOS'
    data = 'CentOS Stream'
    path = '/etc/os-release'
    collected_facts = {
        'distribution_release': 'NA',
    }
    mock_module = Mock(name='module')
    test_module = TestModule(mock_module)
    distribution_files = DistributionFiles(test_module, collected_facts)
    parsed_dist_file, parsed_dist_file_facts = distribution_files.parse_distribution_file(name, data, path)
    assert parsed_dist

# Generated at 2022-06-23 01:07:01.945479
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    import platform
    import re
    import textwrap
    from ansible.module_utils.facts.system import Distribution

    def test_parsing_method(name, data, path, collected_facts, expected_result, expected_return=True, expected_facts={}):
        collected_facts['distribution'] = name
        dist_files = DistributionFiles(module=None)
        result = dist_files._parse_distribution_file(name, data, path, collected_facts)
        assert result == expected_return
        assert expected_result == dist_files.distribution_file_parsing_results

        if result and expected_facts:
            assert expected_facts == dist_files.distribution_file_parsing_facts

    distribution_facts = {}
    system = platform.system()
    distribution_facts['distribution'] = system


# Generated at 2022-06-23 01:07:09.720691
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    # https://mangolassi.it/topic/18667/python-unit-test-failing-with-recent-pip-versions
    import unittest.mock as mock
    # We don't want AnsibleModule to be executed during unit testing:
    # https://stackoverflow.com/questions/46904850/patching-an-object-from-a-different-module-import-in-python-unit-tests
    from ansible.utils.display import Display
    mock_ansible_module = mock.MagicMock()
    # mock_ansible_module.run_command()
    mock_ansible_module.run_command.return_value = 0, '', ''
    mock_ansible_module.get_bin_path.return_value = '/usr/bin/python'
    mock_ansible_

# Generated at 2022-06-23 01:07:18.493773
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    '''
    This method unit test the method parse_distribution_file_CentOS
    '''
    distfile_path = '/etc/centos-release'
    distfile_name = 'CentOS'
    distfile_data = 'CentOS Stream'

    collected_facts = {}
    obj = DistributionFiles()
    parsed, result = obj.parse_distribution_file_CentOS(distfile_name, distfile_data, distfile_path, collected_facts)
    assert parsed and result == {'distribution_release': 'Stream'}


# Generated at 2022-06-23 01:07:29.240584
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    #
    # Create a stubbed module where params are set to values that
    # would normally be set by the ansible module
    #
    loader = DictDataLoader({})
    basedir = os.path.dirname(__file__)
    env = Environment(loader=loader, variable_manager=VariableManager())
    module = AnsibleModule(argument_spec={}, loader=loader, environment=env)
    #
    # Instantiate the fact collector
    #
    distribution_fact_collector = DistributionFactCollector(module=module)
    #
    # Collect the facts
    #
    facts_dict = distribution_fact_collector.collect(collected_facts={})

    #
    # Assert that 'linux' is the distribution family
    #
    assert facts_dict['os_family'] == 'Linux'

    #


# Generated at 2022-06-23 01:07:38.271205
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(argument_spec={})

    # test class instantiation
    dist = Distribution(module=module)

    # test with different distributions
    return_value = {}
    return_value['RedHat'] = {
        'distribution': 'RedHat',
        'distribution_release': '6.2',
        'distribution_version': '6.2',
        'os_family': 'RedHat',
    }

    return_value['Debian'] = {
        'distribution': 'Debian',
        'distribution_release': 'wheezy/sid',
        'distribution_version': '7.0',
        'os_family': 'Debian',
    }


# Generated at 2022-06-23 01:07:48.117510
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():

    # Create instance of the class Distribution
    sample_obj = Distribution(module=None)

    # Testing the method get_distribution_NetBSD
    distribution_facts = sample_obj.get_distribution_NetBSD()
    assert distribution_facts
    assert distribution_facts == {'distribution_release': platform.release()}

if __name__ == '__main__':
    # Create instance of the class Distribution
    sample_obj = Distribution(module=None)

    # Testing the method get_distribution_NetBSD
    distribution_facts = sample_obj.get_distribution_NetBSD()
    assert distribution_facts
    assert distribution_facts == {'distribution_release': platform.release()}

# Generated at 2022-06-23 01:07:57.351999
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = FakeAnsibleModule()
    distributionFacts = Distribution(module)
    data = """
    OpenIndiana Development oi_151.1.15 illumos-9f40a0aa56
    """
    module.get_file_content = MagicMock(return_value=data)
    module.run_command = MagicMock(return_value=(0, "oi_151.1.15", ""))
    expected = {
        "distribution": "OpenIndiana",
        "distribution_release": "OpenIndiana Development oi_151.1.15 illumos-9f40a0aa56",
        "distribution_version": "oi_151.1.15"
    }

    data = """
    Joyent Instance
    """
    module.get_file_content = MagicMock(return_value=data)

# Generated at 2022-06-23 01:08:07.171744
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 01:08:18.998237
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    import os
    import platform
    import pytest
    import sys

    # simply raise exception if 'parsing_exceptions.py' doesn't exist
    sys.path.append(os.getcwd())
    from parsing_exceptions import DistrosParsingExceptions

    pytest.skip()
