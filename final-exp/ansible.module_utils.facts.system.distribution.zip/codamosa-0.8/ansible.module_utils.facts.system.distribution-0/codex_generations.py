

# Generated at 2022-06-11 04:28:58.134688
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    """
    test_Distribution_get_distribution_Darwin is a unit test for the
    get_distribution_Darwin methods of class Distribution.
    """
    test_distribution_a = Distribution()
    test_distribution_b = Distribution()

    test_sw_vers_a_data = [0, "ProductName:    Mac OS X\nProductVersion: 10.9.5\nBuildVersion:   13F34\n", '']
    test_sw_vers_b_data = [0, "ProductName:    Mac OS X\nProductVersion: 10.10.5\nBuildVersion:   13F34\n", '']

    test_module_a = MagicMock()
    test_module_a.run_command().__str__.return_value = test_sw_vers_a_data
    test

# Generated at 2022-06-11 04:29:06.852669
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    name = 'NA'
    data = "NAME=Hobbiton\nVERSION=1.2.3"
    path = 'path/to/os-release'
    collected_facts = {
        'distribution': 'NA',
        'distribution_version': 'NA',
    }
    dist_files = DistributionFiles()
    (parsed, facts) = dist_files.parse_distribution_file_NA(name, data, path, collected_facts)
    assert parsed
    assert facts['distribution'] == 'Hobbiton'
    assert facts['distribution_version'] == '1.2.3'

# Generated at 2022-06-11 04:29:13.967018
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_files = DistributionFiles()
    centos_data_with_stream = "CentOS Stream\n"
    centos_data_without_stream = "CentOS\n"

    centos_facts = {'distribution_release': 'NA'}
    distribution_files.parse_distribution_file_CentOS('CentOS Stream', centos_data_with_stream, '', centos_facts)
    assert centos_facts['distribution_release'] == 'Stream'
    centos_facts['distribution_release'] = 'NA'
    distribution_files.parse_distribution_file_CentOS('CentOS', centos_data_without_stream, '', centos_facts)
    assert centos_facts['distribution_release'] == 'NA'



# Generated at 2022-06-11 04:29:18.681984
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # A test object of class DistributionFiles
    testDistributionFiles = DistributionFiles(None)

    # From /etc/os-release
    # The file content of the distribution file
    data = '''
NAME="Debian GNU/Linux"
VERSION_ID="8"
VERSION="8 (jessie)"
ID=debian
HOME_URL="http://www.debian.org/"
SUPPORT_URL="http://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
'''
    # The distribution file path
    path = '/etc/os-release'
    # The distribution name
    name = 'Debian'
    # test the function parse_distribution_file_Debian
    # of the class DistributionFiles with input data, path and name
    # and the assertion result should be True

# Generated at 2022-06-11 04:29:22.432437
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    assert DistributionFiles().parse_distribution_file_Mandriva(
        'Mandriva',
        'NAME="Mandriva Linux"',
        '',
        {}
    ) == (True, {'distribution': 'Mandriva'})

# Generated at 2022-06-11 04:29:32.977438
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    test_class = DistributionFiles()

# Generated at 2022-06-11 04:29:44.050149
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # unit test for get_distribution_DragonFly
    #
    # mocked output from 'sw_vers -productVersion',
    # to be returned by :func:`ansible_distribution_DragonFly.get_distribution_DragonFly`
    #
    # Args: None
    #
    # Returns:
    #     mocked output from 'sw_vers -productVersion'
    #
    module = AnsibleModule(argument_spec={})

    m = mock.mock_open()
    # mock the context manager to avoid the actual open and read

# Generated at 2022-06-11 04:29:52.904785
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    lines = [
        "/usr/bin/oslevel: oslevel: -r is required.",
        "/usr/bin/oslevel",
        "/usr/bin/oslevel: oslevel: -r is required.",
        "/usr/bin/oslevel: oslevel: -r is required.",
        "7.1",
        "7100-03-03-1715",
    ]

    d = Distribution(None)
    results = d.get_distribution_AIX()
    assert results == {
        'distribution_major_version': '7',
        'distribution_release': '1715',
        'distribution_version': '7.1'
    }

# Generated at 2022-06-11 04:29:54.847355
# Unit test for function get_uname
def test_get_uname():
    module = AnsibleModule(argument_spec={})
    assert get_uname(module) == platform.uname().version



# Generated at 2022-06-11 04:30:05.885370
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    """
    Unit test for method get_distribution_Darwin of class Distribution.
    Mock is used to simulate the call to platform.system() and the existence of /usr/bin/sw_vers
    """
    from ansible.utils.distribution import Distribution
    from ansible.module_utils._text import to_bytes

    m_path_exists = Mock(return_value=True)
    platform.system = Mock(return_value=to_bytes('darwin'))
    m_load_file = Mock(return_value=to_bytes('10.12.6'))
    m_run_command = Mock(return_value=(0, to_bytes('0x1234'), to_bytes('')))

# Generated at 2022-06-11 04:30:36.355275
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    """
    Test the method parse_distribution_file_Flatcar of class   DistributionFiles
    """
    d = DistributionFiles()
    # sample data
    data = '''GROUP=stable
VERSION_ID="2612.2.0"
BUILD_ID="2018-08-28_21-05-34"
NAME="Flatcar Container Linux by Kinvolk"
ID=flatcar
ID_LIKE=coreos
VERSION="2612.2.0"
VERSION_CODENAME="edgware"'''
    _facts = {}
    for item in data.splitlines():
        _facts[item.split("=")[0]] = item.split("=")[1].strip('"')
    # sample test
    _name = 'flatcar'
    _path = '/etc/flatcar-release'
    collected_

# Generated at 2022-06-11 04:30:45.576637
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    print("test_DistributionFiles_parse_distribution_file_Slackware")
    with open('./test_distribution_files/slackware_version') as f:
        slackware_version_file = f.read()
    dist_file_facts = DistributionFiles.parse_distribution_file_Slackware(name='Slackware', data=slackware_version_file, path='/etc/slackware-version', collected_facts={})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1]['distribution'] == 'Slackware'
    assert dist_file_facts[1]['distribution_version'] == '14.2'


# Generated at 2022-06-11 04:30:55.080174
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule(argument_spec={})

    dist_file_facts = DistributionFiles(module).parse_distribution_file_Mandriva(name='Mandriva',
                                                              data='DISTRIB_ID=Mandriva\nDISTRIB_RELEASE="2011.0"\nDISTRIB_CODENAME="Hydrogen"\nDISTRIB_DESCRIPTION="Mandriva Linux 2011.0"',
                                                              path='/etc/mandriva-release',
                                                              collected_facts={'distribution': 'Mandriva', 'distribution_version': 'NA', 'distribution_release': 'NA'})
    assert dist_file_facts['parsed']
    assert dist_file_facts['distribution_file_path'] == '/etc/mandriva-release'
    assert dist

# Generated at 2022-06-11 04:31:01.994460
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files_obj = DistributionFiles()
    collected_facts = {'distribution': 'flatcar', 'distribution_release': 'NA'}
    data = '[Match]\nGroup=docker\n'
    name = 'NA'
    path = '/usr/lib/os-release'
    distribution_file_parsed, distribution_file_facts = distribution_files_obj.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert distribution_file_parsed == True
    assert distribution_file_facts == {'distribution_release': 'docker'}



# Generated at 2022-06-11 04:31:12.714663
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    """
    Check that parse_distribution_file_OpenWrt() correctly extracts the distro and distribution release
    """
    testdistro = DistributionFiles()
    name="OpenWrt"
    data = """
DISTRIB_DESCRIPTION="OpenWrt 19.07.4"
DISTRIB_ID="OpenWrt"
DISTRIB_RELEASE="19.07.4"
DISTRIB_REVISION="r13028-86b99e9f46"
DISTRIB_TARGET="x86/generic"
DISTRIB_TARGET_ID=""
DISTRIB_TARGET_VARIANT=""
DISTRIB_TARGET_VARIANT_ID=""
DISTRIB_VERSION="19.07.4"
"""

    _path = '/etc/openwrt_release'
    assert testdistro.parse

# Generated at 2022-06-11 04:31:24.260805
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})

    # set up the values to be used in the tests
    rc, out, err = module.run_command('uname -r')
    platform_release = out.strip()
    rc, out, err = module.run_command('uname -v')
    uname_v = out.strip()

    # this module is for NetBSD only so ensure that the os is NetBSD
    module.run_command('uname')
    if platform.system() == 'NetBSD':
        ansible_facts = Distribution(module).get_distribution_NetBSD()
        assert ansible_facts['distribution'] == 'NetBSD'
        assert ansible_facts['distribution_major_version'] == platform_release.split('.')[0]
        assert ansible_facts['distribution_version']

# Generated at 2022-06-11 04:31:34.765524
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # pylint: disable=protected-access
    data = "PRETTY_NAME=\"Mandriva Linux 2010.1\"\nNAME=\"Mandriva Linux\"\nVERSION=\"2010.1 (Official)\"\nVERSION_ID=\"2010.1\"\nPRETTY_NAME=\"Mandriva Linux 2010.1 (Official)\"\nANSI_COLOR=\"0;31\"\nCPE_NAME=\"cpe:/o:mandriva:linux:2010.1:official\"\nHOME_URL=\"http://www.mandriva.com/\"\nSUPPORT_URL=\"http://www.mandriva.com/en/support\"\nBUG_REPORT_URL=\"http://qa.mandriva.com/\""
    path = '/etc/mandriva-release'
    collected_facts = {}
    module = DEFA

# Generated at 2022-06-11 04:31:42.976735
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    '''
        This method is unit tested. Please extend the tests to cover all
        distributions if you have them available.
    '''
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'NetBSD 7.1 (GENERIC) #0: Fri Jul 28 21:39:41 UTC 2017', ''))
    distribution = Distribution(module)
    result = distribution.get_distribution_NetBSD()
    assert result == {
        'distribution_release': '7.1',
        'distribution_major_version': '7',
        'distribution_version': '7.1'
    }

# Generated at 2022-06-11 04:31:53.584334
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    uname_m = {'kernel_name': 'OpenBSD',
               'kernel_release': '6.1',
               'kernel_version': '#57',
               'machine': 'amd64',
               'processor': 'amd64',
               'system': 'OpenBSD',
               'version': '6.1'}

    module = MagicMock()
    module.run_command.side_effect = [[0, '6.1-BETA', '']]
    module.get_bin_path.side_effect = ['/sbin/sysctl']
    module.get_file_content.side_effect = ['']
    module.get_uname.side_effect = ['']
    d = Distribution(module)
    facts = d.get_distribution_OpenBSD()

# Generated at 2022-06-11 04:32:03.791124
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import platform
    import platform
    module = type('Module', (object,), {'run_command': mock_run_command, '_diff_requires_change': True, '_module_path': 'path'})()

    dist = Distribution(module)
    # Test case 1: Error in run_command() call
    mock_run_command.side_effect = lambda x, use_unsafe_shell: (127, '', '')
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts == {}

    # Test case 2: HPUX OE installed
    mock_run_command.side_effect = None

# Generated at 2022-06-11 04:33:02.227173
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    os_facts = OSFacts()
    os_facts.parse_distribution_file('OpenWrt', '''DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=18.06.2''', '')
    assert os_facts.facts['distribution'] == 'OpenWrt'
    assert os_facts.facts['distribution_version'] == '18.06.2'



# Generated at 2022-06-11 04:33:12.554210
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    df = DistributionFiles()
    name='clearlinux'
    path='/etc/os-release'
    data="""
NAME="Clear Linux OS"
VERSION_ID=23890
ID=clear-linux-os
VERSION="23890 (Boreas)"
""".strip()
    collected_facts={
            'distribution':'Clear Linux',
            'distribution_major_version':'23890',
            'distribution_release':'Boreas',
            'distribution_version':'23890',
            }
    expected_clear_facts = {'distribution': 'Clear Linux OS',
                            'distribution_major_version': '23890',
                            'distribution_release': 'clear-linux-os',
                            'distribution_version': '23890'}
    # parsed, parsed_clear_facts = df

# Generated at 2022-06-11 04:33:22.610121
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    """unit test for the parse_distribution_file_flatcar method in the DistributionFiles class
    """

    module = AnsibleModule(argument_spec={})
    df = DistributionFiles()

    # No 'GROUP'
    data = "TEST_DATA"
    path = 'TEST_PATH'
    name = 'TEST_NAME'
    # No 'flatcar'
    flatcar_facts, flatcar_parsed = df.parse_distribution_file_Flatcar(name, data, path, {})
    assert not flatcar_parsed
    assert not flatcar_facts

    distribution_release = "A"
    data = "GROUP=" + distribution_release
    path = 'TEST_PATH'
    name = 'flatcar'
    flatcar_facts, flatcar_parsed = df.parse_dist

# Generated at 2022-06-11 04:33:32.961231
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    coreos_facts = {}
    # FIXME: pass in ro copy of facts for this kind of thing
    distro = get_distribution()


# Generated at 2022-06-11 04:33:37.529113
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    mod = FakeModule()

    dist = Distribution(module=mod)
    expected = {
        'distribution': 'MacOSX',
        'distribution_major_version': '10',
        'distribution_version': '10.9.1',
    }
    assert dist.get_distribution_Darwin() == expected


# Generated at 2022-06-11 04:33:40.539725
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    assert Distribution(module=None).get_distribution_OpenBSD() == {
        'distribution_release': '6.3',
        'distribution_version': '6.3'
    }

# Generated at 2022-06-11 04:33:50.265072
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    test_dist_file_name = 'CentOS'
    test_file_path = '/etc/centos-release'
    test_data = 'CentOS Linux release 7.9.2009 (Core)'
    test_collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    test_result = DistributionFiles().parse_distribution_file_CentOS(test_dist_file_name, test_data, test_file_path, test_collected_facts)
    assert test_result == (False, {})

    test_data_1 = '''
CentOS Linux release 8.0.1905 (Core) 
'''

# Generated at 2022-06-11 04:33:58.361993
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Arrange
    # parse_distribution_file_Debian
    centos_facts = { 'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA',
                     'distribution_major_version': 'NA'}
    # Act
    d = DistributionFiles()
    # parse_distribution_file_Debian
    parsed_dist_file, parsed_dist_file_facts = d.parse_distribution_file_Debian(
        'Debian', 'Debian', '/etc/lsb-release', centos_facts)
    # Assert
    assert parsed_dist_file_facts['distribution'] == "Debian"


# Generated at 2022-06-11 04:34:08.784900
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():

    dist_files = DistributionFiles()
    dist_files.module = AnsibleModule(argument_spec = dict())

    name = 'OpenWrt'
    data = '''
    foo bar baz
    DISTRIB_ID="OpenWrt"
    DISTRIB_RELEASE="Bleeding Edge"
    DISTRIB_REVISION="r12345"
    DISTRIB_CODENAME="foo"
    DISTRIB_TARGET="bar"
    DISTRIB_DESCRIPTION="OpenWrt Nightly Build"
    DISTRIB_TAINTS="foo bar"
    '''

    parsed, facts = dist_files.parse_distribution_file_OpenWrt(name, data, '/etc/lsb-release', {})
    assert parsed is True

# Generated at 2022-06-11 04:34:19.155023
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    collected_facts = {}
    collected_facts = {}
    collected_facts['distribution'] = 'NA'
    collected_facts['distribution_version'] = 'NA'
    collected_facts['distribution_release'] = 'NA'
    collected_facts['distribution_major_version'] = 'NA'
    collected_facts['distribution_file_path'] = 'NA'
    collected_facts['distribution_file_parsed'] = False
    collected_facts['distribution_file_variety'] = 'NA'


    obj = DistributionFiles(module)
    # case 1 - OpenWRT
    name = 'OpenWrt'
    path = '/etc/openwrt_version'

# Generated at 2022-06-11 04:35:31.789700
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    from ansible.module_utils.facts.collector import DistributionFiles
    from ansible.module_utils.facts import Collector

    _collector = Collector()
    _distribution_files = DistributionFiles(_collector)

    assert _distribution_files.parse_distribution_file_Mandriva('Mandriva', 'DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2017.0\nDISTRIB_CODENAME=Heisenbug\nDISTRIB_DESCRIPTION="Mandriva Linux release 2017.0 (Heisenbug)"\n', '/etc/lsb-release', {}) == (True, {'distribution': 'Mandriva', 'distribution_release': 'Heisenbug', 'distribution_version': '2017.0'})



# Generated at 2022-06-11 04:35:39.231350
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    if os.path.isfile("/usr/bin/oslevel"):
        dist = Distribution(module)
        dist_dict = dist.get_distribution_AIX()
        assert dist_dict['distribution_major_version']
        assert dist_dict['distribution_version']
    else:
        pytest.skip("System is not AIX")



# Generated at 2022-06-11 04:35:43.837157
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    from unittest import TestCase

    class TestDistribution(TestCase):

        def test_get_distribution_DragonFly(self):
            from ansible.module_utils import basic
            from ansible_collections.community.general.plugins.module_utils.distribution import Distribution
            distribution = Distribution(basic.AnsibleModule)
            dragonfly_facts = distribution.get_distribution_DragonFly()
            assert dragonfly_facts['distribution_release'] == platform.release()
            rc, out, dummy = basic.AnsibleModule().run_command("/sbin/sysctl -n kern.version")
            match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)

# Generated at 2022-06-11 04:35:52.831593
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    """Unit test for method parse_distribution_file_NA of class DistributionFiles"""
    df = DistributionFiles()
    #
    # Vars
    name = 'NA'
    #
    # Test cases

# Generated at 2022-06-11 04:35:59.258188
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files = DistributionFiles()
    distribution_files.data = {
        '/etc/os-release': 'NAME="Amazon Linux AMI" VERSION="2018.03" ID="amzn" ID_LIKE="rhel fedora" VERSION_ID="2018.03" PRETTY_NAME="Amazon Linux AMI 2018.03" ANSI_COLOR="0;33" CPE_NAME="cpe:/o:amazon:linux:2018.03:ga" HOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n',
        '/etc/system-release': 'Amazon Linux AMI release 2018.03\n'
    }

# Generated at 2022-06-11 04:36:09.233947
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    '''test method parse_distribution_file_Flatcar of class DistributionFiles'''
    # create a DistributionFiles instance
    test_instance = DistributionFiles()

    # create a test MockedAnsibleModule for DistributionFiles.get_file_content
    test_module = MockedAnsibleModule(
        argument_spec={}
    )
    test_instance.module = test_module

    # make a MockedAnsibleModule for DistributionFiles.get_distribution_files_facts
    test_module2 = MockedAnsibleModule(
        argument_spec={}
    )

    # create a test MockedAnsibleModule for DistributionFiles.parse_distribution_file_Ubuntu
    test_module3 = MockedAnsibleModule(
        argument_spec={}
    )

# Generated at 2022-06-11 04:36:17.069416
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    lsb_release_data = "NAME=\"Clear Linux OS for Intel Architecture\"\nID=clear-linux\nVERSION_ID=31480\nPRETTY_NAME=\"Clear Linux OS for Intel Architecture 31480\"\nANSI_COLOR=\"1;34\"\nHOME_URL=\"https://clearlinux.org/\"\nSUPPORT_URL=\"https://clearlinux.org/support\""

# Generated at 2022-06-11 04:36:26.829601
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    name = 'SUSE'
    data = '''openSUSE Leap 15.0 (x86_64)
VERSION = 15.0
CODENAME = Leap
# /etc/SuSE-release is deprecated and will be removed in the future, use /etc/os-release instead
'''
    path = '/etc/SuSE-release'
    collected_facts = {}

    distroFacts = DistributionFiles()
    # TODO: get it working without collected_facts argument
    parsed, facts = distroFacts.parse_distribution_file_SUSE(name, data, path, collected_facts)

    assert parsed is True
    assert facts == {'distribution_version': '15.0', 'distribution': 'openSUSE', 'distribution_major_version': '15', 'distribution_release': '0'}

#

# Generated at 2022-06-11 04:36:31.532361
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # with this pattern, it will not match
    assert DistributionFiles().parse_distribution_file_Coreos('Coreos', '', '', {})[0] is False
    # with this pattern, it will match and extract a release
    assert 'release' in DistributionFiles().parse_distribution_file_Coreos('Coreos', 'GROUP=CoreOS', '', {})[1]



# Generated at 2022-06-11 04:36:38.506833
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    subject = DistributionFiles()
    result = subject.parse_distribution_file_SUSE(
        name='SUSE',
        data='''
NAME=openSUSE
VERSION = "Tumbleweed"
VERSION_ID = "20180410"
PRETTY_NAME = "openSUSE Tumbleweed"
```
''',
        path='/etc/os-release',
        collected_facts={'distribution_version': 'NA'}
    )[1]
    assert result['distribution'] == 'openSUSE'
    assert result['distribution_release'] == '20180410'


# Generated at 2022-06-11 04:37:43.803425
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    ansible_facts = {}
    dist_files = DistributionFiles(ansible_facts)
    name = 'Slackware'
    with open('test/test_data_files/Slackware-release') as f:
        data = f.read()
    path = 'test/test_data_files/Slackware-release'
    parsed, parsed_facts = dist_files.parse_distribution_file_Slackware(name, data, path, parsed_facts)
    assert parsed == True
    assert parsed_facts['distribution'] == 'Slackware'
    assert parsed_facts['distribution_version'] == '14.2'

# Generated at 2022-06-11 04:37:51.782817
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    """
    This function contains the tests for the method get_distribution_Darwin of class Distribution
    """

    mock_module = MagicMock()
    mock_module.run_command.return_value = 0, "10.15.6\n", ""

    distribution_object = Distribution(mock_module)
    distribution_facts = distribution_object.get_distribution_Darwin()

    assert distribution_facts['distribution'] == "MacOSX"
    assert distribution_facts['distribution_major_version'] == "10"
    assert distribution_facts['distribution_version'] == "10.15.6"
    assert distribution_facts['os_family'] == "Darwin"

# Generated at 2022-06-11 04:38:02.489265
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    class Module:
        def get_bin_path(self, arg):
            return '/bin/test'

        def run_command(self, cmd):
            return 0, 'GROUP=current', ''

    class AnsibleModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    module = Module()
    am = AnsibleModule()
    df = DistributionFiles(module, am.params)
    facts = {
        "distribution_release": "NA",
    }

# Generated at 2022-06-11 04:38:08.654974
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Arrange
    facts = {}
    name = 'CentOS'

    path = '/etc/os-release'
    data = "NAME=\"CentOS Stream\""

    collected_facts = DistributionFiles(facts).collect_distribution_facts()

    # Act
    parsed, centos_facts = DistributionFiles(facts).parse_distribution_file_CentOS(name, data, path, collected_facts)

    # Assert
    assert parsed
    assert centos_facts['distribution_release'] == 'Stream'

# Generated at 2022-06-11 04:38:16.438575
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    def mock_get_distribution(self):
        return 'clearlinux'

    d = DistributionFiles()
    d.get_distribution = mock_get_distribution
    d.module = Mock()
    d.module.run_command = Mock(return_value=(0, '', ''))
    assert (True, {'distribution': 'Clear Linux OS', 'distribution_version': '31050'}) == d.parse_distribution_file_ClearLinux('clear-linux-os', 'NAME="clear-linux-os" VERSION_ID=31050 ID=clear-linux-os', '', {})
    assert (False, {}) == d.parse_distribution_file_ClearLinux('clear-linux-os', '', '', {})

