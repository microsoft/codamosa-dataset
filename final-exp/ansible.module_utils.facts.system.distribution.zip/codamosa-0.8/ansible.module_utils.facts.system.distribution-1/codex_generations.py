

# Generated at 2022-06-11 04:29:07.724302
# Unit test for method get_distribution_OpenBSD of class Distribution

# Generated at 2022-06-11 04:29:19.292816
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    class_inst = DistributionFiles(None)
    name = 'Mandriva'
    data = '''OVERRIDES="Mandriva"
DISTRIB_ID="Mandriva"
DISTRIB_RELEASE="2014.2"
DISTRIB_CODENAME="2014.2"
DISTRIB_DESCRIPTION="Mandriva 2014.2"'''
    path = '/etc/lsb-release'
    collected_facts = {
        'distribution': 'NA',
        'distribution_version': 'NA',
        'distribution_release': 'NA'
    }
    ret = class_inst.parse_distribution_file_Mandriva(name, data, path, collected_facts)

# Generated at 2022-06-11 04:29:30.069336
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dfile = DistributionFiles(None)

    # suse pattern
    assert dfile.parse_distribution_file_SUSE('SLES', 'SLES 15.1 (x86_64)', '/etc/SuSE-release', {})[1]['distribution_release'] == '1'
    assert dfile.parse_distribution_file_SUSE('SLES', 'SLES 15.2 (x86_64)', '/etc/SuSE-release', {})[1]['distribution_release'] == '2'
    assert dfile.parse_distribution_file_SUSE('SLES', 'SLES 15.2.2 (x86_64)', '/etc/SuSE-release', {})[1]['distribution_release'] == '2'

    # suse pattern with no minor release
    assert dfile.parse_distribution

# Generated at 2022-06-11 04:29:41.021085
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    class dictobj(object):
        def __init__(self, d=None):
            self.__dict__.update(d)

    mod = AnsibleModule(argument_spec={})
    dist = DistributionFiles(mod)

    fake_open = ['openSUSE Leap 15.1 (x86_64)\n',
                 'openSUSE Leap 15.1 (i586)\n',
                 'openSUSE Leap 15.2 (x86_64)\n',
                 'openSUSE Leap 15.2 (i586)\n',
                 'openSUSE Leap 15.3 (x86_64)\n',
                 'openSUSE Leap 15.3 (i586)\n',
                 'openSUSE Leap 15.2 (x86_64)\n',
                 'openSUSE Leap 15.2 (i586)\n']

    slessap

# Generated at 2022-06-11 04:29:45.605664
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    """ Unit test for class Distribution: method get_distribution_DragonFly """
    mod = AnsibleModule(argument_spec={})
    dist = Distribution(mod)
    data = dist.get_distribution_DragonFly()
    assert 'distribution_release' in data
    return



# Generated at 2022-06-11 04:29:51.011499
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    d = Distribution(module)

    freebsd_facts = d.get_distribution_FreeBSD()

    assert type(freebsd_facts) is dict
    assert 'distribution' in freebsd_facts
    assert 'distribution_release' in freebsd_facts



# Generated at 2022-06-11 04:30:00.763220
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_file_facts = DistributionFiles()
    file_path = '/etc/os-release'
    file_content = """NAME="Amazon Linux"
            VERSION="2"
            ID="amzn"
            ID_LIKE="centos rhel fedora"
            VERSION_ID="2"
            PRETTY_NAME="Amazon Linux 2"
            ANSI_COLOR="0;33"
            CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
            HOME_URL="https://amazonlinux.com/"
            """
    distribution_file_name = 'Amazon'
    # Actual Amazon Linux with distribution ID=amzn

# Generated at 2022-06-11 04:30:04.373767
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    distribution = Distribution(module)
    out = distribution.get_distribution_HPUX()
    assert out is not None



# Generated at 2022-06-11 04:30:08.925995
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModuleMock({})
    distribution = Distribution(module)
    test_dict = {'distribution_version': '9.99', 'distribution_release': 'NetBSD-9.99-amd64'}
    assert distribution.get_distribution_NetBSD() == test_dict



# Generated at 2022-06-11 04:30:14.361053
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = Mock()
    module.run_command.return_value = (0, '6.1.9.0', '')
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '6'
    assert aix_facts['distribution_version'] == '6.1'



# Generated at 2022-06-11 04:30:50.760622
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = MockOsUtilModule('/usr/sbin/swlist')
    dist = Distribution(module=module)
    rc, out, err = module.run_command(r"/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'", use_unsafe_shell=True)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == out.splitlines()[0].split()[-1].strip()


_distro = None



# Generated at 2022-06-11 04:31:00.777615
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModule(argument_spec={})
    dfiles = DistributionFiles(module)

    name = 'Flatcar_Linux'
    path = '/usr/share/oem/release-flatcar.txt'
    data = """GROUP=stable
ID=flatcar
VERSION_ID=1234
PRETTY_NAME="Flatcar Container Linux by Kinvolk 1234 (Flatcar Container Linux 1234.1.0)"
HOME_URL="https://www.flatcar-linux.org/"
BUG_REPORT_URL="https://issues.flatcar-linux.org/"
FLATCAR_BUILD=1234"""
    parsed_dist_file = 'Flatcar_Linux'
    parsed_dist_file_facts = {'distribution_release': 'stable'}


# Generated at 2022-06-11 04:31:02.981402
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    assert Distribution.get_distribution_Darwin(Distribution) == {'distribution': 'MacOSX'}

# Generated at 2022-06-11 04:31:13.649536
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # Mock out Module Class and instantiate DistributionFiles
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/bin/ls'
    module.run_command.return_value = 0, '', ''
    d = DistributionFiles(module)
    data = 'Slackware 14.2'
    name = 'Slackware'
    path = '/etc/slackware-version'
    collected_facts = dict()

# Generated at 2022-06-11 04:31:21.054098
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    for test_input, expected_output in test_input_output_get_distribution_NetBSD:
        dist = Distribution(test_input)
        distribution_facts = dist.get_distribution_NetBSD()
        assert distribution_facts['distribution_release'] == expected_output['distribution_release']
        assert distribution_facts['distribution_major_version'] == expected_output['distribution_major_version']
        assert distribution_facts['distribution_version'] == expected_output['distribution_version']



# Generated at 2022-06-11 04:31:32.330530
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    return_facts = {}
    return_facts['distribution_file_path'] = '/etc/os-release'
    return_facts['distribution_file_parsed'] = 'yes'
    return_facts['distribution'] = 'Clear Linux'
    return_facts['distribution_version'] = '28000'
    return_facts['distribution_major_version'] = '28000'
    return_facts['distribution_release'] = 'os'
    return_facts['distribution_file_variety'] = 'ClearLinux'
    return_facts['distribution_file_parsed_success'] = True

    test_data = '''
NAME="Clear Linux"
ID=clearlinux
VERSION_ID=28000
'''

    test_obj = DistributionFiles()
    result = test_obj.parse_distribution_file

# Generated at 2022-06-11 04:31:41.934397
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    class Amodule:
        class AnansibleModule:
            def __init__(self):
                self.params = {}
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.ansible_module = self.AnansibleModule()
    class Bdistribution:
        def __init__(self):
            self.distribution = ""
    class Cplatform:
        def __init__(self):
            self.system = ""
    class Dfile:
        def __init__(self):
            self.isfile = lambda x: False
        def read(self):
            return ""

    mymodule = Amodule()
    distro = Bdistribution()
    platform = Cplatform()
    myfile = Dfile()


# Generated at 2022-06-11 04:31:52.464728
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():

    """Test method get_distribution_AIX of class Distribution"""
    my_ansible_module = AnsibleModule(argument_spec=dict())
    os_release_file_reader = OSReleaseFileReader(my_ansible_module)
    os_release_file_reader.os_release_files = ['test_data/os-release-aix-invalid', 'test_data/os-release-aix']

    distribution = Distribution(my_ansible_module)

    my_ansible_module.run_command = MagicMock(return_value=(0, '7.2.0.0', ''))

    # call the method to test
    result = distribution.get_distribution_AIX()

    # Check the results

# Generated at 2022-06-11 04:31:57.999287
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: need more test cases here
    assert parse_distribution_file_SUSE("SUSE", "openSUSE 13.1 (Bottle)", "data", "collected_facts") == False
    assert parse_distribution_file_SUSE("SUSE", "SUSE Linux Enterprise Server 12", "data", "collected_facts") == False


# Generated at 2022-06-11 04:31:59.166349
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    # TODO: unittest
    pass



# Generated at 2022-06-11 04:32:34.292107
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    dist_file_obj = DistributionFiles(module=None)

    test_input_data = '# coreos-config'
    # test_input_py_dist_facts = {
    #     'distribution': 'CoreOS',
    #     'distribution_release': 'Alpha'
    # }

    test_input_file_name = 'CoreOS'
    test_input_file_path = '/usr/share/coreos/release'
    test_input_distro_name = 'CoreOS'

# Generated at 2022-06-11 04:32:41.456450
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    dist_files = DistributionFiles()
    # Testing if distribution is Debian and release is Stretch
    data = open('/etc/os-release', 'r').read()
    name = 'test'
    dist_facts = dist_files.parse_distribution_file_Debian(name, data, '/etc/os-release', {})
    assert dist_facts[1]['distribution'] == 'Debian'
    assert dist_facts[1]['distribution_release'] == 'stretch/sid'

    # Testing if distribution is Kali and release is Kali
    data = open('/etc/lsb-release', 'r').read()
    dist_facts = dist_files.parse_distribution_file_Debian(name, data, '/etc/lsb-release', {})

# Generated at 2022-06-11 04:32:52.198760
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-11 04:32:56.268536
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    """ Unit test for method get_distribution_HPUX of class Distribution """
    module = AnsibleModule(argument_spec={})
    (distribution_facts, dummy_loader, dummy_paths) = Facts(module=module).populate()
    distribution_facts.get_distribution_HPUX()



# Generated at 2022-06-11 04:33:07.177841
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    if not HAS_PLATFORM:
        module.fail_json(msg="the python 'platform' module is required")
    if not HAS_UNAME:
        module.fail_json(msg="the python 'os' module is required")
    if sys.platform != 'hp-ux':
        module.fail_json(msg="The test environment is not HPUX")
    if (sys.version_info[0] == 2 and sys.version_info[1] >= 7) or sys.version_info[0] > 2:
        is_old_hpux = False
    else:
        is_old_hpux = True
    distro = Distribution(module)
    hpux_facts = distro.get_distribution_HPUX()

# Generated at 2022-06-11 04:33:11.205276
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    darwin_facts = {
        'distribution': 'MacOSX',
        'distribution_major_version': '10.14',
        'distribution_version': '10.14.6'
    }
    assert Distribution.get_distribution_Darwin() == darwin_facts

# Generated at 2022-06-11 04:33:21.492011
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):  # pylint: disable=unused-argument
            pass
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, 'CentOS Stream', ''))
    distrobject = DistributionFiles(module)
    name = 'CentOS'
    data = 'CentOS Stream'
    path = '/etc/os-release'
    collected_facts = {}
    collected_facts['distribution_version'] = 'NA'
    collected_facts['distribution_release'] = 'NA'
    collected_facts['distribution'] = 'NA'

# Generated at 2022-06-11 04:33:31.821999
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    def test_helper(test_data, expected_facts):
        # test_data is a tuple consisting of data that should be returned from get_file_content method
        # and data that should be returned from platform.dist()
        # test_data can be a tuple of tuples, in case there is more than one file that should be
        # read with get_file_content method
        # expected_facts is a dictionary of expected results

        if type(test_data) != tuple:
            # test_data should be a tuple
            raise Exception("test_data should be a tuple")

        if len(test_data) == 1:
            # test_data is an empty tuple, we assume that get_file_content should return empty string
            # because we have no file to read.
            file_content_data = ('', )
            platform_dist_data

# Generated at 2022-06-11 04:33:35.849519
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    data = 'CentOS Stream'
    dummy_collected_facts = {}
    result_dict = DistributionFiles.parse_distribution_file_CentOS('CentOS', data, 'random_path', dummy_collected_facts)
    assert result_dict == (True, {'distribution_release': 'Stream'})


# Generated at 2022-06-11 04:33:40.021134
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distro = Distribution(module=None)
    netbsd_facts = distro.get_distribution_NetBSD()
    assert 'distribution_version' in netbsd_facts and 'distribution_release' in netbsd_facts and 'distribution_major_version' in netbsd_facts



# Generated at 2022-06-11 04:34:12.168175
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    module = AnsibleModule(argument_spec={})
    distribution_files = DistributionFiles(module)
    name = 'Clear Linux'
    data = 'NAME="Clear Linux OS"'
    path = '/etc/os-release'
    collected_facts = {'distribution': 'NA'}
    failed, result = distribution_files.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    assert not failed
    assert result['distribution'] == 'Clear Linux OS'


# Generated at 2022-06-11 04:34:22.929146
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    """
    test the method parse_distribution_file_Debian
    """
    def mock_get_distribution(self):
        """
        mocks get_distribution, this is our test data
        """
        return 'Debian'

    def mock_get_file_content(path):
        """
        mock_get_file_content, this is our test data
        """
        if path == '/etc/lsb-release':
            return '''
                DISTRIB_ID=Ubuntu
                DISTRIB_RELEASE=17.10
                DISTRIB_CODENAME=artful
                DISTRIB_DESCRIPTION="Ubuntu 17.10"
            '''

# Generated at 2022-06-11 04:34:33.142401
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    d = DistributionFiles()
    # Sample file
    file_name = '/etc/lsb-release'
    # Sample data
    file_data = '\n'.join(['description:    Slackware 14.2', 'version:        14.2', 'slackware:      14.2'])
    # For testing purposes
    facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}
    parsed_dist_file_facts = d.parse_distribution_file_Slackware('Slackware', file_data, file_name, facts)
    assert parsed_dist_file_facts == (True, {'distribution': 'Slackware', 'distribution_version': '14.2'})

# Generated at 2022-06-11 04:34:38.214662
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    object = DistributionFiles()
    data = '''NAME=Ubuntu
VERSION="18.04 LTS (Bionic Beaver)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 18.04 LTS"'''
    expected_debian_facts = {'distribution': 'Ubuntu'}
    parsed_dist_file, parsed_dist_file_facts = object.parse_distribution_file_Debian('', data, '', {})
    assert parsed_dist_file == True
    assert parsed_dist_file_facts == expected_debian_facts

# Generated at 2022-06-11 04:34:42.107696
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution_OpenBSD = Distribution(module)
    distribution_OpenBsd_facts = distribution_OpenBSD.get_distribution_OpenBSD()

    assert distribution_OpenBsd_facts['distribution_version'] in ('5.8', '6.0', '6.1', '6.2', '6.3', '6.4')


# Generated at 2022-06-11 04:34:46.555888
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = Mock()
    module.run_command.return_value = 0, "HPUX-OE.B.11.31.1705", ""
    dist = Distribution(module)
    assert dist.get_distribution_HPUX() == {"distribution_version": "B.11", "distribution_release": "1705"}


# Generated at 2022-06-11 04:34:51.265469
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():

    # Test 1
    expected = {
        'distribution': 'Amazon',
        'distribution_version': '2'
    }
    data = """NAME="Amazon Linux"
VERSION="2"
ID="amzn"
ID_LIKE="centos rhel fedora"
VERSION_ID="2"
PRETTY_NAME="Amazon Linux 2"
ANSI_COLOR="0;33"
CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
HOME_URL="https://amazonlinux.com/"

CENTOS_MANTISBT_PROJECT="CentOS-2"
CENTOS_MANTISBT_PROJECT_VERSION="2"
REDHAT_SUPPORT_PRODUCT="amzn"
REDHAT_SUPPORT_PRODUCT_VERSION="2"
"""
    facts = dict

# Generated at 2022-06-11 04:35:01.643878
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    test_module = AnsibleModule(
        argument_spec = dict(
            collected_facts=dict(required=False, type='dict')
        )
    )

    distfile = DistributionFiles(test_module)

    fetched_path = '/etc/coreos/update.conf'
    fetched_data = '''
GROUP=stable-channel
SERVER=https://stable.release.core-os.net/amd64-usr/
'''
    fetched_name = 'CoreOS'
    fetched_facts = {}
    fetched_facts['distribution_version'] = 'NA'
    fetched_facts['distribution_release'] = 'NA'

    distribution_file_facts = distfile.parse_distribution_file_Coreos(fetched_name, fetched_data, fetched_path, fetched_facts)



# Generated at 2022-06-11 04:35:10.683752
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    distribution_facts = Distribution(module).get_distribution_facts()
    distribution_facts_keys = ('distribution', 'distribution_release', 'distribution_version', 'distribution_major_version', 'os_family')
    assert isinstance(distribution_facts, dict)
    assert set(distribution_facts.keys()) == set(distribution_facts_keys)
    assert distribution_facts.get('distribution') == platform.system()
    assert distribution_facts.get('distribution_release') == platform.release()
    assert distribution_facts.get('distribution_version') == platform.version()
    assert distribution_facts.get('distribution_major_version') == platform.release()

# Generated at 2022-06-11 04:35:20.179443
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    d = DistributionFiles()
    f = open('tests/unit/modules/ansible/module_utils/facts/user_mode/distribution_files/os-release_coreos', 'r')
    os_release_data = f.read()
    f.close()
    f = open('tests/unit/modules/ansible/module_utils/facts/user_mode/distribution_files/lsb_release_coreos', 'r')
    lsb_release_data = f.read()

    # Test with path: /etc/lsb-release
    parse_bool, parse_data = d.parse_distribution_file_Coreos('CoreOS', lsb_release_data, '/etc/lsb-release', {})
    assert parse_bool and parse_data['distribution_release'] == 'stable'

    # Test with

# Generated at 2022-06-11 04:36:43.146646
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    '''
    Unit test for method get_distribution_OpenBSD of class Distribution
    '''
    __tracebackhide__ = True
    module = get_module_mock()

    def mock_run_command(command, check_rc=True, environ_update=None, data=None, binary_data=False, temp_data=None,
                         run_as_root=False, use_unsafe_shell=False, **kwargs):
        # OpenBSD outputs kern.version as follows "OpenBSD 4.8-current (GENERIC) #0: Thu Feb 13 20:32:47 MST 2020"
        rc = 0
        out = "OpenBSD 4.8-current (GENERIC) #0: Thu Feb 13 20:32:47 MST 2020"
        err = ""
        return rc, out, err

    module

# Generated at 2022-06-11 04:36:48.793608
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files = DistributionFiles()
    module = None
    # do preparation here
    path = 'test'
    collected_facts = {}
    collected_facts['distribution'] = 'Flatcar'
    collected_facts['distribution_version'] = '0.1'
    data = "test"
    distribution_files.parse_distribution_file_Flatcar(None, data, path, collected_facts)


# Generated at 2022-06-11 04:36:56.674903
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_files_obj = DistributionFiles()
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}
    file_name = 'clear-linux-os'
    file_content = 'NAME="Clear Linux OS"'
    file_path = '/etc/os-release'
    expected_output = {'distribution': 'Clear Linux OS', 'distribution_version': 'NA', 'distribution_release': u'NA'}
    assert distribution_files_obj.parse_distribution_file_ClearLinux(file_name, file_content, file_path, collected_facts) == (True, expected_output)



# Generated at 2022-06-11 04:37:06.673261
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # create an instance of DistributionFiles
    dist_files = DistributionFiles()

    # test_case 01
    name = 'SUSE'

# Generated at 2022-06-11 04:37:11.164845
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    mac_facts = {'distribution': 'MacOSX',
                 'distribution_release': '12.2.0',
                 'distribution_version': '12.2.0'}
    facts = Distribution(None)
    distribution_facts = facts.get_distribution_Darwin()
    assert distribution_facts == mac_facts

# Generated at 2022-06-11 04:37:21.416157
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # prepare test object
    dist_file = DistributionFiles()
    module3 = AnsibleModule(argument_spec={})
    # prepare test data
    # path_to_file, data_to_read, name_of_distribution, linux_distribution_data, linux_distribution_version_data
    name_of_distribution = "SUSE"
    linux_distribution_data = "SUSE LINUX"
    linux_distribution_version_data = "15"
    # to test openSUSE file os-release

# Generated at 2022-06-11 04:37:30.566518
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
  module = AnsibleModule(argument_spec={})
  module.run_command = mock.MagicMock(return_value=(0, '', ''))
  module.get_file_content = mock.MagicMock(return_value='SunOS')
  module.get_uname = mock.MagicMock(return_value='5.10')
  distribution = Distribution(module=module)
  sunos_facts = distribution.get_distribution_SunOS()
  assert(sunos_facts['distribution'] == 'Solaris')
  assert(sunos_facts['distribution_version'] == 'SunOS')
  assert(sunos_facts['distribution_major_version'] == '10')
  assert(sunos_facts['distribution_release'] == 'SunOS')

# Generated at 2022-06-11 04:37:40.773480
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    class MockModule(object):
        def __init__(self, name, data):
            self.params = {}
            self.name = name
            self.data = data

        def run_command(self, cmd):
            return 0, self.name, ''

        def get_bin_path(self, path, opts=''):
            return '/bin/dpkg'

        def fail_json(self, *args, **kwargs):
            return False

    class MockFacts(dict):
        def __init__(self, name, data):
            self['distribution'] = 'Ubuntu'
            self['distribution_version'] = 'NA'
            self['distribution_release'] = 'NA'
            self['distribution_file_parsed'] = False

    distro = DistributionFiles()

# Generated at 2022-06-11 04:37:42.293063
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(str(['-v'])) is not None



# Generated at 2022-06-11 04:37:51.872908
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    from ansible.module_utils.facts.collector.solaris import Distribution
    module = FakeModule()
    init = Distribution(module)

    #Test for Solaris 10
    module.run_command = Fake_run_command(['5.10'])
    module.get_file_content = Fake_get_file_content(['Solaris 10 10/09 s10x_u8wos_08a X86'])
    returned_values = init.get_distribution_SunOS()
    expected_values = {'distribution': 'Solaris', 'distribution_version': '10', 'distribution_release': 'Solaris 10 10/09 s10x_u8wos_08a X86', 'distribution_major_version': '10'}
    assert returned_values == expected_values

    #Test for Solaris 11