

# Generated at 2022-06-11 04:28:55.995363
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    dfiles = DistributionFiles()
    data = 'NAME="Clear Linux"'
    path = '/etc/os-release'
    name = 'Clear Linux'
    collected_facts = {}
    parsed_clear_linux, clear_linux_facts = dfiles.parse_distribution_file_ClearLinux(name=name, data=data, path=path, collected_facts=collected_facts)
    assert parsed_clear_linux
    assert clear_linux_facts['distribution'] == 'Clear Linux'

# Generated at 2022-06-11 04:29:07.054956
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    d = DistributionFiles(None)
    facts = {}
    data = 'NAME="Gentoo Base System" ID=gentoo PRETTY_NAME="Gentoo/Linux"'
    path = '/etc/os-release'
    name = 'ClearLinux'
    result = d.parse_distribution_file_ClearLinux(name, data, path, facts)
    assert result == (False, {})
    data = 'NAME="Clear Linux" VERSION_ID=1716 ID=clear-linux VERSION="1716 (Boreas)"'
    result = d.parse_distribution_file_ClearLinux(name, data, path, facts)

# Generated at 2022-06-11 04:29:14.086931
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, "/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'", ""))
    result = Distribution(module).get_distribution_HPUX()
    assert("distribution_version" in result and result["distribution_version"] == "A.11.31")


# Generated at 2022-06-11 04:29:24.714481
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    test_file = '''NAME=CentOS Linux
VERSION="7 (Core)"
ID="centos"
ID_LIKE="rhel fedora"
VERSION_ID="7"
PRETTY_NAME="CentOS Linux 7 (Core)"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:centos:centos:7"
HOME_URL="https://www.centos.org/"
BUG_REPORT_URL="https://bugs.centos.org/"

CENTOS_MANTISBT_PROJECT="CentOS-7"
CENTOS_MANTISBT_PROJECT_VERSION="7"
REDHAT_SUPPORT_PRODUCT="centos"
REDHAT_SUPPORT_PRODUCT_VERSION="7"
'''


# Generated at 2022-06-11 04:29:29.605274
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    test_module = type('module', (object,), {})
    test_module.run_command = FakeModule.run_command
    test_module.get_file_content = FakeModule.get_file_content
    test_module.get_uname = FakeModule.get_uname
    test_module.file_exists = FakeModule.file_exists
    distribution = Distribution(test_module)
    assert "CURRENT" == distribution.get_distribution_DragonFly()['distribution_release']


# Generated at 2022-06-11 04:29:33.924904
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distfiles = DistributionFiles()
    test_data = 'CentOS Stream'
    result = distfiles.parse_distribution_file_CentOS('CentOS', test_data,
                                                      '/etc/lsb-release', {})
    assert result[1]['distribution_release'] == 'Stream'

# Generated at 2022-06-11 04:29:45.210580
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    file_data = """NAME="Debian GNU/Linux"
VERSION="10 (buster)"
ID=debian
ID_LIKE=debian
PRETTY_NAME="Debian GNU/Linux 10 (buster)"
VERSION_ID="10"
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
"""

    basic_facts = dict(
        distribution='NA',
        distribution_major_version='NA',
        distribution_version='NA',
        distribution_release='NA',
    )
    df = DistributionFiles(None, facts=basic_facts)
    collect_facts = basic_facts
    name = 'Debian'
    path = "file_name"
    parse_distribution_file = df.parse_

# Generated at 2022-06-11 04:29:50.663088
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    fixture = Distribution(module=object)
    fixture.module.run_command = MagicMock(return_value=(0, """9""", ""))
    expected = {'distribution_version': '9', 'distribution_major_version': '9'}
    actual = fixture.get_distribution_AIX()
    assertDeepAlmostEqual(actual, expected)



# Generated at 2022-06-11 04:29:54.766142
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = MagicMock()
    module.run_command.return_value = (0, '10.13.4', '')
    distribution = Distribution(module)
    assert distribution.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.13.4'}


# Generated at 2022-06-11 04:30:05.782287
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    """
    Note: This test is based on /usr/src/sys/conf/newvers.sh
    """

# Generated at 2022-06-11 04:30:32.470252
# Unit test for function get_uname
def test_get_uname():
    def run_command(cmd):
        out = 'Linux dev-stack-precise-image-master-20 4.1.0-x86_64-linode58 #3 SMP Sun Aug 30 16:50:01 UTC 2015 x86_64 x86_64 x86_64 GNU/Linux'
        return 0, out, None
    assert get_uname(run_command, '-v') == out



# Generated at 2022-06-11 04:30:42.464856
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    parsed_dict = {}
    parsed_dict['distribution'] = 'Mandriva'
    parsed_dict['distribution_version'] = '2010.2'
    parsed_dict['distribution_release'] = 'Spring'

    dist_path = '/etc/mandriva-release'

    with open(dist_path) as f:
        content = f.read()

    dist_files = DistributionFiles(module, [dist_path])
    parsed_dist_file = dist_files.parse_distribution_file_Mandriva(
        'Mandriva', content, dist_path, {})
    assert parsed_dist_file[1] == parsed_dict



# Generated at 2022-06-11 04:30:51.396075
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    openbsd_6_1_system = 'OpenBSD 6.1 (GENERIC)'
    openbsd_6_1_rc1_system = 'OpenBSD 6.1-rc1 (GENERIC)'
    openbsd_6_1_release_system = 'OpenBSD 6.1-RELEASE (GENERIC.MP)'
    openbsd_7_0_system = 'OpenBSD 7.0 (GENERIC.MP)'

    openbsd_facts = Distribution(module=None).get_distribution_OpenBSD()

    assert(openbsd_facts['distribution'] == 'OpenBSD')
    assert(openbsd_facts['distribution_version'] == '6.1')
    assert(openbsd_facts['distribution_release'] == 'release')

# Generated at 2022-06-11 04:30:56.998565
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    all_facts = {}
    all_facts['distribution'] = 'DragonflyBSD'
    all_facts['distribution_version'] = '4.7.1-RELEASE'
    all_facts['distribution_major_version'] = '4'

    dist = Distribution(module=None)

    facts = dist.get_distribution_DragonFly()

    assert facts == all_facts


# Generated at 2022-06-11 04:31:04.889072
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    slackware_data = "Slackware 14.1.0"
    slackware_file_path = "Slackware-14.1.0-install-dvd.iso"
    class Dummy:
        pass
    module = Dummy()
    module.get_bin_path = lambda x: "/bin/%s" % x

    d = DistributionFiles()
    d.module = module
    d.distribution_files = [slackware_file_path]
    collected_facts = {}
    with open(slackware_file_path) as slackware_file:
        data = slackware_file.read()
        d.parse_distribution_file_Slackware(data, slackware_file_path, collected_facts)
        assert collected_facts['distribution'] == "Slackware"
        assert collected_facts

# Generated at 2022-06-11 04:31:15.774872
# Unit test for method get_distribution_OpenBSD of class Distribution

# Generated at 2022-06-11 04:31:27.384479
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    module = AnsibleModule(argument_spec={})
    distribution_files = DistributionFiles(module)

# Generated at 2022-06-11 04:31:37.250964
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    import pytest
    class MyModule(object):
        def __init__(self):
            self.run_command_result = (0, '5.3', '')
        def run_command(self, command):
            return self.run_command_result
    mymodule = MyModule()
    d = Distribution(module=mymodule)
    result = {'distribution_major_version': '5', 'distribution_version': '5.3'}
    assert d.get_distribution_AIX() == result
    mymodule.run_command_result = (1, '', '')
    assert d.get_distribution_AIX() == result
    mymodule.run_command_result = (0, '5', '')

# Generated at 2022-06-11 04:31:47.999131
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    collected_facts = {}
    distribution_files = DistributionFiles(collected_facts)
    distribution_files.DISTRO_PARSERS = (
        (re.compile('OpenWrt'), distribution_files.parse_distribution_file_OpenWrt)
    )
    # FIXME: add relevant data to test against
    data = None
    name = 'OpenWrt'
    path = ''
    rc, parsed_dist_file_facts = distribution_files.parse_distribution_file_OpenWrt(name, data, path, collected_facts)
    assert rc
    assert parsed_dist_file_facts['distribution'] == 'OpenWrt'
    assert parsed_dist_file_facts['distribution_version'] == 'DISTRIB_RELEASE="(.*)"'

# Generated at 2022-06-11 04:31:53.106123
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    os = Distribution(module)
    data = os.get_distribution_SunOS()
    assert data['distribution']=='Oracle' and data['distribution_release']=='Solaris 11.4'

if __name__ == '__main__':
    test_Distribution_get_distribution_SunOS()

# Generated at 2022-06-11 04:32:21.123394
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    """
    Unit test for method get_distribution_facts of class Distribution

    Unit tests are best written as functions that return either True or False.
    This is done because nose will stop executing tests on the first failure
    """
    module = get_module()

    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_facts()

    if distribution_facts['distribution'] == 'Linux':
        # for linux we can filter out the non-relevant facts
        linux_specific_facts = dict()
        for key, value in distribution_facts.items():
            if key.startswith('distribution'):
                linux_specific_facts[key] = value
        distribution_facts = linux_specific_facts

# Generated at 2022-06-11 04:32:25.404729
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    """
    This function tests the functionality of get_distribution_NetBSD
    """
    dist = Distribution(FakeAnsibleModule('FreeBSD'))
    actual = dist.get_distribution_NetBSD()
    expected = {
        'distribution_release': '8.1',
    }
    assert actual == expected, "%s is the actual output and %s is the expected output" % (actual, expected)

# Generated at 2022-06-11 04:32:32.910110
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    m = MagicMock()
    m.run_command.return_value = ['', 'NetBSD 7.1 (GENERIC)\n', '']

    netbsd_facts = Distribution(m).get_distribution_NetBSD()
    assert netbsd_facts['distribution'] == 'NetBSD'
    assert netbsd_facts['distribution_major_version'] == '7'
    assert netbsd_facts['distribution_version'] == '7.1'
    assert netbsd_facts['distribution_release'] == '7.1'



# Generated at 2022-06-11 04:32:39.082499
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = MagicMock()
    facts = Distribution(module)
    expected_result = {'distribution_release': '7.0', 'distribution': 'NetBSD',
                       'distribution_major_version': '7', 'distribution_version': '7.0'}
    module.run_command.side_effect = [{0: '', 1: '7.0', 2: ''}, {0: '', 1: 'NetBSD 7.0 (GENERIC)', 2: ''}]
    result = facts.get_distribution_NetBSD()
    assert expected_result == result

# Generated at 2022-06-11 04:32:50.238267
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # DistributionFiles._distribution_files_SUSE = []
    path = os.path.dirname(__file__)

    data = open(os.path.join(path, "../sample_data/SUSE-release"), "r").read()
    name = 'SUSE'

    facts = {
        "distribution_release": "NA",
        "distribution_version": "12.2"
    }
    d = DistributionFiles(None)
    suse_facts = d.parse_distribution_file_SUSE(name, data, path, facts)[1]
    assert suse_facts['distribution'] == 'openSUSE Leap'
    assert suse_facts['distribution_release'] == '42.1'
    assert suse_facts['distribution_version'] == '12.2'


# Generated at 2022-06-11 04:32:58.056380
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    import re
    import sys
    import platform
    import os.path

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, use_unsafe_shell=False):
            if sys.platform != 'sunos5':
                raise Exception("run_command should not be called")
            if use_unsafe_shell:
                raise Exception("use_unsafe_shell should not be passed to run_command")


# Generated at 2022-06-11 04:33:02.688297
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    test_module = FakeAnsibleModule()

    hpux_facts = Distribution(test_module).get_distribution_HPUX()

    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '1493'


# Generated at 2022-06-11 04:33:09.143848
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    for dist_name in ('Solaris', 'SmartOS', 'OpenIndiana', 'NexentaOS'):
        distribution = Distribution(None)
        distribution.module.run_command = MagicMock(side_effect=[('0', '{} 11'.format(dist_name), '')])
        distribution.get_distribution_SunOS()
        distribution.module.run_command.assert_called_once_with('/usr/bin/uname -v')


# Generated at 2022-06-11 04:33:17.270502
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    module = AnsibleModule(argument_spec={})
    distro_files = DistributionFiles(module)

    assert distro_files.parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})

    assert not distro_files.parse_distribution_file_CentOS('CentOS', 'CentOS Linux', '/etc/os-release', {})


if __name__ == '__main__':
    # Test for method parse_distribution_file_CentOS of class DistributionFiles
    test_DistributionFiles_parse_distribution_file_CentOS()

# Generated at 2022-06-11 04:33:27.386680
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    os = Mock()
    os.system = "SunOS"
    os.release = "5.10"
    os.version = "Generic_151445-09"
    os.platform = "sunos5"
    with patch.dict(distribution.__dict__, {"system":os}):
        assert distribution.get_distribution_SunOS() == {
            'distribution': 'Solaris',
            'distribution_major_version': '10',
            'distribution_release': 'Solaris 10',
            'distribution_version': '10'
        }
        os.release = "5.11"

# Generated at 2022-06-11 04:34:35.087447
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = type("Module", (object,), {})
    module.run_command = run_command
    distribution = Distribution(module)
    result = distribution.get_distribution_HPUX()
    assert result['distribution_version'] == 'B.11.11'
    assert result['distribution_release'] == '1108'
test_Distribution_get_distribution_HPUX()



# Generated at 2022-06-11 04:34:42.298027
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule(argument_spec={})
    loader = Mock()

    openwrt_txt = """
DISTRIB_ID="OpenWrt"
DISTRIB_RELEASE="Attitude Adjustment"
DISTRIB_REVISION="r36088"
DISTRIB_CODENAME="attitude_adjustment"
DISTRIB_TARGET="brcm47xx/mips74k"
DISTRIB_DESCRIPTION="OpenWrt Attitude Adjustment r36088"
DISTRIB_TAINTS="no-all busybox"
"""

# Generated at 2022-06-11 04:34:52.074527
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    dist_file = DistributionFiles()
    test_paths = {
        'debian': '/etc/os-release',
        'ubuntu': '/etc/os-release',
        'steamos': '/etc/os-release',
        'devuan': '/etc/os-release',
        'cumulus': '/etc/os-release',
        'linuxmint': '/etc/os-release',
        'kali': '/etc/os-release',
        'parrot': '/etc/os-release',
        'lsb_release': '/etc/lsb-release',
        'no_lsb': '/etc/coreos/lsb-release'
    }

    data_file = '/tmp/ansible_fact_collector_testing_data_deb'

# Generated at 2022-06-11 04:35:02.457001
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    d = DistributionFiles({})
    name = 'Slackware'
    data = 'This is a test of Slackware 14.1'
    path = '/etc/slackware-release'

    # Test expected True
    true_data = data[:]
    true_expected = ('Slackware', {'distribution': 'Slackware', 'distribution_version': '14.1'})
    true_output = d.parse_distribution_file_Slackware(name, true_data, path, {})
    assert true_output[0] == (True, true_expected[1])

    # Test expected False
    false_data = data[:]
    false_output = d.parse_distribution_file_Slackware(name, false_data, path, {})

# Generated at 2022-06-11 04:35:11.196597
# Unit test for function get_uname
def test_get_uname():
    # python -m pytest test_utils.py -vv -s
    import pytest
    import platform
    class Module(object):
        def run_command(self, command):
            if platform.system() != "Darwin":
                return 0, platform.uname(0), ""
            return 0, platform.uname(0) + " " + platform.uname(4), ""
    module = Module()
    for flag in ['-a', '-p', '-i', '-n', '-r', '-s', '-v', '-m']:
        out = get_uname(module, flag)
        if isinstance(out, bytes):
            out = out.decode('utf-8')

# Generated at 2022-06-11 04:35:20.761819
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    facts = {'distribution': 'NA',
             'distribution_file_path': '/etc/os-release',
             'distribution_file_variety': 'NA',
             'distribution_file_parsed': False,
             'distribution_file_details': {},
             'distribution_version': 'NA',
             'distribution_major_version': 'NA',
             'distribution_release': 'NA',
             'distribution_file_distro': 'NA',
             }
    df = DistributionFiles(dict())

# Generated at 2022-06-11 04:35:31.070912
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files = DistributionFiles()
    distribution_files.module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    collection_facts = {}

# Generated at 2022-06-11 04:35:34.094757
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    obj = Distribution(module)
    assert obj.get_distribution_NetBSD()["distribution_release"] == platform.release()

# Generated at 2022-06-11 04:35:39.182282
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():

    # TODO: find a better way to test this, currently requires either passing mock data or collecting data from a host
    test_instance = DistributionFiles()
    tested_method = test_instance.parse_distribution_file_Coreos
    assert tested_method



# Generated at 2022-06-11 04:35:44.044541
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    df = DistributionFiles()
    dist_file_facts = df.process_dist_files(
        {'distribution': 'NA', 'distribution_file_variety': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'},
        {},
        {}
    )
    assert dist_file_facts['distribution'] == 'NA'


# Generated at 2022-06-11 04:36:17.337345
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    class Struct(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class ModuleMock(object):
        def __init__(self, return_value, distribution_facts, distribution_version, distribution_release, distribution_major_version, distribution_version_full, distribution_name, distribution_major_version_full):
            self.run_command = return_value

        def get_bin_path(self, executable, default=None, opt_dirs=[]):
            return '/usr/sbin/swlist'

    class MockOS(object):
        def __init__(self):
            self.pid = 1234
            self.environ = {"PATH": "/usr/bin:/usr/sbin"}
            self.putenv = None


# Generated at 2022-06-11 04:36:27.090628
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: use mock or something
    facts = AnsibleModule(dict(test_case='test_001'))
    facts.distribution = 'Ubuntu'
    facts.distribution_version = '20.04'
    facts.distribution_release = 'focal'
    x = DistributionFiles(facts)

    # test Ubuntu
    name = 'Ubuntu'
    with open('/tmp/ubuntu_test_01', 'w') as f:
        data = '''PRETTY_NAME="Ubuntu 20.04 LTS"
NAME="Ubuntu"
VERSION="20.04 LTS (Focal Fossa)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 20.04.1 LTS"
VERSION_ID="20.04"'''
        f.write(data)

# Generated at 2022-06-11 04:36:36.537432
# Unit test for method get_distribution_facts of class Distribution

# Generated at 2022-06-11 04:36:43.988168
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = 'ansible_test'
    distribution = Distribution(module)
    sunos_facts = {}
    # Test for Nexenta
    data = 'NexentaOS_NXOS 7_2 snv_111b X86 Copyright 2009-2015 Nexenta Systems, Inc.  All rights reserved.'
    sunos_facts['distribution'] = 'Nexenta'
    sunos_facts['distribution_release'] = data.strip()
    sunos_facts['distribution_version'] = '7_2'
    assert distribution.get_distribution_SunOS() == sunos_facts
    # Test for OmniOS
    data = 'OmniOS r151032d  dbf6a5c7f0bf stable 2015-10-15'
    sunos_facts['distribution'] = 'OmniOS'
    sunos

# Generated at 2022-06-11 04:36:50.567679
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = object()
    module.run_command = MagicMock(return_value=[0, 'OpenBSD 6.6-current (GENERIC.MP) #0: Tue Nov 12 14:37:34 UTC 2019', ''])
    distribution = Distribution(module)
    expected = {
        'distribution_version': '6.6-current',
        'distribution_release': 'current'
    }

    actual = distribution.get_distribution_OpenBSD()

    assert expected == actual


# Generated at 2022-06-11 04:36:58.136849
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    class module:
        def run_command(self, cmd, use_unsafe_shell=False, check_rc=False):
            return (0, '6.1.0.0', '')
    test_module = module()
    test_obj = Distribution(module=test_module)
    data = test_obj.get_distribution_AIX()
    assert data['distribution'] == 'AIX'
    assert data['distribution_version'] == '6.1'
    assert data['distribution_release'] == '0.0'
    assert data['distribution_major_version'] == '6'



# Generated at 2022-06-11 04:37:08.181811
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distro_files = DistributionFiles()
    fake_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}

# Generated at 2022-06-11 04:37:15.499603
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    print('* get_distribution_FreeBSD')
    import pytest
    module_argv = dict(ANSIBLE_MODULE_ARGS=dict(paths='/etc/freebsd-update.conf'))
    module = AnsibleModule(**module_argv)
    dist = Distribution(module)
    res = dist.get_distribution_FreeBSD()
    assert res == {'distribution_release': '11.0-RELEASE-p3', 'distribution_major_version': '11', 'distribution_version': '11.0'}



# Generated at 2022-06-11 04:37:25.525123
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModule(
        argument_spec=dict(
            distribution_file_paths=dict(type='dict', default=dict()),
        )
    )
    d = DistributionFiles({}, module)

    # Test no results
    name = 'flatcar'
    data = ''
    path = '/etc/flatcar-release'
    collected_facts = {'distribution_release': 'NA'}
    expected = (False, {})
    assert d.parse_distribution_file_Flatcar(name, data, path, collected_facts) == expected

    # Test results
    name = 'flatcar'

# Generated at 2022-06-11 04:37:31.273342
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distfile = DistributionFiles()
    collected_facts = {}
    name = 'flatcar'
    data = 'GROUP=beta'
    path = '/etc/os-release'
    result = distfile.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result[0] == True
    assert result[1]['distribution'] == 'Flatcar'
    assert result[1]['distribution_release'] == 'beta'

