

# Generated at 2022-06-11 04:28:49.602533
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles

# Generated at 2022-06-11 04:28:57.824943
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    init_mock_distributions()
    mock_distribution_data.update({
        'system': 'OpenBSD',
        'version': '5.5',
        'release': '5.5',
    })
    mock_distribution_data['platform'] = 'OpenBSD-5.5-i386'
    distribution_data = Distribution(mocked_module).get_distribution_OpenBSD()
    assert distribution_data == {
        'distribution_version': '5.5',
        'distribution_release': 'release',
    }



# Generated at 2022-06-11 04:29:05.907237
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distfiles = DistributionFiles()
    distfiles.module = AnsibleModule(argument_spec={})
    distfiles.module.params = {
        'path': '/etc/centos-release',
        'name': 'CentOS',
        'data': 'CentOS release 8 (Core)',
    }
    assert distfiles.parse_distribution_file_CentOS(distfiles.module.params['name'],
                                                     distfiles.module.params['data'],
                                                     distfiles.module.params['path'],
                                                     {}) == (False, {})

# Generated at 2022-06-11 04:29:13.671195
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules.system.distribution import DistributionFiles

    distro_files = ['/etc/lsb-release', '/etc/debian_version', '/etc/redhat-release', '/etc/os-release']

    class MockModule(object):
        def __init__(self, params):
            pass

        def get_bin_path(self, executable):
            return executable


# Generated at 2022-06-11 04:29:22.286150
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    from ansible.module_utils.facts import Distribution
    import platform
    system = platform.system()
    cleanedname = system.replace('-', '')
    distfunc = getattr(Distribution, 'get_distribution_' + cleanedname)
    dist_func_facts = distfunc()
    if system == 'Darwin':
        assert dist_func_facts['distribution'] == 'MacOSX'
        assert 'distribution_major_version' in dist_func_facts.keys()
        assert 'distribution_version' in dist_func_facts.keys()
    else:
        assert dist_func_facts == {}



# Generated at 2022-06-11 04:29:32.834982
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: mock collected_facts and module.run_command
    distro_file = DistributionFiles({'collect_default_facts': True, 'content': []})
    dist = distro_file.parse_distribution_file_Debian("Debian", "Debian\n", '/etc/os-release', {"distribution_major_version": "NA", "distribution_release": "NA", "distribution_version": "NA"})
    assert dist[1]['distribution'] == 'Debian'
    dist = distro_file.parse_distribution_file_Debian("Debian", "Ubuntu\n", '/etc/os-release', {"distribution_major_version": "NA", "distribution_release": "NA", "distribution_version": "NA"})

# Generated at 2022-06-11 04:29:43.946595
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    """Unit test for method get_distribution_AIX of class Distribution"""
    module = AnsibleModule(
        argument_spec = dict()
    )

    current_path = os.path.dirname(os.path.abspath(__file__))
    test_data_path = os.path.join(current_path, "test_data")

    class MockData:
        def __init__(self, return_value):
            self.return_value = return_value


# Generated at 2022-06-11 04:29:54.102627
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Test Case 1:
    test_data = """NAME=Fedora
    VERSION="27 (Twenty Seven)"
    ID=fedora
    VERSION_ID=27
    """

    test_collected_facts = {
        'distribution': 'NA',
        'distribution_file_variety': 'NA',
        'distribution_file_path': '/etc/os-release',
        'distribution_file_parsed': 'True',
        'distribution_file_distro': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA'
    }
    distribution_files = DistributionFiles()
    distribution_files.module = MagicMock()
    distribution_files.module.run_command = MagicMock()
    fact = distribution_files.parse_distribution

# Generated at 2022-06-11 04:29:57.170779
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    x = Distribution(module=None)
    assert x.get_distribution_HPUX() == {'distribution_version': 'B.11.31', 'distribution_release': '105342'}

# Generated at 2022-06-11 04:30:08.066769
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    name = 'NA'
    # data = """
    #  NAME="Amazon Linux AMI"
    #  VERSION="2014.09"
    #  ID="amzn"
    #  ID_LIKE="rhel fedora"
    #  VERSION_ID="2014.09"
    #  PRETTY_NAME="Amazon Linux AMI 2014.09"
    #  ANSI_COLOR="0;33"
    #  CPE_NAME="cpe:/o:amazon:linux:2014.09:ga"
    #  HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
    #  """

# Generated at 2022-06-11 04:30:41.273854
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    from ansible.module_utils.facts import DistroFactsParser
    distro_facts_parser = DistroFactsParser()


# Generated at 2022-06-11 04:30:48.893662
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    d = DistributionFiles(None)
    d_file = '/etc/os-release'
    data = 'NAME="Clear Linux" ID=clear-linux-os VERSION_ID=24300'
    name = 'ClearLinuxOS'
    path = '/etc/os-release'
    collected_facts = dict()
    parsed_data, parsed_dist_file_data = d.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    assert parsed_data
    assert parsed_dist_file_data == {'distribution': 'Clear Linux', 'distribution_version': '24300', 'distribution_major_version': '24300'}



# Generated at 2022-06-11 04:30:53.431557
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    dist = Distribution()
    # at the moment this test is ignoring the module passed in
    dist_facts = dist.get_distribution_HPUX()
    expected_facts = {'distribution_version': 'B.11.31', 'distribution_release': '0923141448'}
    assert dist_facts == expected_facts



# Generated at 2022-06-11 04:30:55.697964
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    dist_file_handler = DistributionFiles()
    if dist_file_handler.parse_distribution_file_Mandriva('Mandriva', "", "", {})[1]:
        return True

    return False


# Generated at 2022-06-11 04:30:59.585480
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = None
    dist = Distribution(module)
    assert dist.get_distribution_SunOS() == {'distribution': 'SmartOS', 'distribution_release': 'OpenIndiana Hipster', 'distribution_major_version': '19.6', 'distribution_version': '19.6'}


# Generated at 2022-06-11 04:31:00.578332
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    pass



# Generated at 2022-06-11 04:31:10.936132
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_files = DistributionFiles()
    collected_facts = {'distribution_version': 'NA'}

# Generated at 2022-06-11 04:31:17.226890
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    darwin_facts_dict = {'distribution': 'MacOSX',
                         'distribution_major_version': '10.9',
                         'distribution_release': '13F34',
                         'distribution_version': '10.9.4'}
    darwin_facts = Distribution(None).get_distribution_Darwin()
    assert darwin_facts == darwin_facts_dict



# Generated at 2022-06-11 04:31:27.091128
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    a = Distribution(None)
    assert a.get_distribution_HPUX.__doc__ != None, "No doc for method get_distribution_HPUX"
    assert a.get_distribution_HPUX.__name__ == "get_distribution_HPUX", "The method get_distribution_HPUX should be named 'get_distribution_HPUX'"
    assert isinstance(a.get_distribution_HPUX(), dict) == True,  "Return value of method get_distribution_HPUX should be type 'dict' not type '" + str(type(a.get_distribution_HPUX())) + "'"



# Generated at 2022-06-11 04:31:30.428836
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(dict())
    distribution = Distribution(module)
    distribution.get_distribution_OpenBSD() == {'distribution_release': '6.3', 'distribution_version': '6.3'}

# Generated at 2022-06-11 04:32:00.974333
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles

# Generated at 2022-06-11 04:32:03.100279
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files = DistributionFiles()
    assert distribution_files
    assert distribution_files.parse_distribution_file_Coreos


# Generated at 2022-06-11 04:32:13.872558
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    fact_data = {'distribution': 'Flatcar', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    distribution_files = DistributionFiles(None)
    df_data = "NAME=Flatcar Linux\nID=flatcar\nVERSION_ID=2533.7.0\nVERSION_CODENAME=\nBUILD_ID=2019.12.23.113822\nPRETTY_NAME=\"Flatcar Linux 2533.7.0 (Stable)\"\nANSI_COLOR=\"1;32\"\nHOME_URL=\"https://flatcar-linux.org/\"\nBUG_REPORT_URL=\"https://github.com/flatcar-linux/flatcar-linux/issues/new\""
    rc, dist_facts = distribution_files.parse_distribution_file

# Generated at 2022-06-11 04:32:16.800923
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    lib = DistributionFiles()
    assert lib.parse_distribution_file_Mandriva('Mandriva', 'foo', '', {}) == (False, {'distribution': 'Mandriva'})



# Generated at 2022-06-11 04:32:22.926281
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    print("unit test for method parse_distribution_file_Slackware")
    with open('Slackware-release', 'r') as f:
        data = f.read()
    df = DistributionFiles()
    df.parse_distribution_file_Slackware('Slackware', data, 'Slackware-release', {})
    print("unit test done")

if __name__ == '__main__':
    test_DistributionFiles_parse_distribution_file_Slackware()

# Generated at 2022-06-11 04:32:28.692472
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    test_classes = [DistributionFiles]
    loader = unittest.TestLoader()
    suites_list = []
    for test_class in test_classes:
        suite = loader.loadTestsFromTestCase(test_class)
        suites_list.append(suite)

    big_suite = unittest.TestSuite(suites_list)

    runner = unittest.TextTestRunner()
    results = runner.run(big_suite)

# Generated at 2022-06-11 04:32:36.698039
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = Mock()
    module.run_command.return_value = 0, 'OpenBSD 5.9-current (GENERIC.MP) #1: Sat Apr 16 21:41:25 MDT 2016     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC.MP', ''
    distribution = Distribution(module)
    result = distribution.get_distribution_OpenBSD()
    # TODO: Add assert here
    module.run_command.assert_called_once_with('/sbin/sysctl -n kern.version')


# Generated at 2022-06-11 04:32:38.530099
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('python2.7')
    assert get_uname('python3.8')


# Generated at 2022-06-11 04:32:49.723004
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module_mock = AnsibleModuleMock()
    # FIXME: pass in ro copy of facts for this kind of thing
    distro = 'coreos'  # hack to fool method into running
    distribution_files = DistributionFiles(module_mock)

    file_name = 'coreos-release'
    file_path = '/etc/%s' % file_name
    test_data = """
COREOS_RELEASE_GROUP=stable
COREOS_RELEASE_ID=1234.0.0
COREOS_RELEASE_BOARD=amd64-usr
COREOS_RELEASE_VERSION=1234.0.0
"""
    return_data = distribution_files.parse_distribution_file_Coreos(distro, test_data, file_path, None)

# Generated at 2022-06-11 04:32:57.780281
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    collected_facts = {'distribution': 'NA',
                       'distribution_version': 'NA',
                       'distribution_release': 'NA',
                       'distribution_major_version': 'NA',
                       'distribution_release': 'NA',
                       'kernel': {'release': '4.4.0-1045-aws', 'version': '4.4.0-1045.49'},
                       'distribution_file_parsed': []}

    # Run method
    dist_file = DistributionFiles()
    dist_file_facts = dist_file.parse_distribution_file_Amazon('amazon', 'Amazon', '/etc/lsb-release', collected_facts)
    # Check results
    assert dist_file_facts['distribution_version'] == 'NA'

# Generated at 2022-06-11 04:33:54.562460
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    result = Distribution(None).get_distribution_AIX()
    assert isinstance(result, dict), 'Result is not a dictionary'
    assert 'distribution' in result, 'Result does not contain distribution'
    assert 'distribution_major_version' in result, 'Result does not contain distribution_major_version'
    assert 'distribution_version' in result, 'Result does not contain distribution_version'
    assert 'distribution_release' in result, 'Result does not contain distribution_release'

# Generated at 2022-06-11 04:33:57.135979
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # arrange
    module = AnsibleModule(argument_spec={})

    # set up module
    module._bootstrap()

    # assert
    assert True is not False



# Generated at 2022-06-11 04:34:02.332593
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    from ansible.module_utils.facts import Distribution
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_AIX()
    assert distribution_facts['distribution_major_version'] == '6'
    assert distribution_facts['distribution_version'] == '6.1'
    assert distribution_facts['distribution_release'] == '1'



# Generated at 2022-06-11 04:34:12.211298
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distribution_files = DistributionFiles()

    name = 'Mandriva'
    data = 'DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2010.2\nDISTRIB_CODENAME=TwoStone\nDISTRIB_DESCRIPTION="Mandriva Linux release 2010.2 (TwoStone)"\n'
    path = '/etc/lsb-release'
    collected_facts = {}
    expected_boolean, expected_mandriva_facts = True, {'distribution': 'Mandriva', 'distribution_release': 'TwoStone', 'distribution_version': '2010.2'}
    actual_boolean, actual_mandriva_facts = distribution_files.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert actual_boolean == expected_

# Generated at 2022-06-11 04:34:22.990657
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'openSUSE'
    data = """
PRETTY_NAME="openSUSE Leap 15.0"
NAME="openSUSE Leap"
VERSION="15.0"
ID=opensuse
ID_LIKE="suse"
VERSION_ID="15.0"
PRETTY_NAME="openSUSE Leap 15.0"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:leap:15.0:ga"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://www.opensuse.org/"
    """
    path = ''

# Generated at 2022-06-11 04:34:33.550492
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    df = DistributionFiles({})


# Generated at 2022-06-11 04:34:41.732501
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module_name = 'ansible.module_utils.facts.system.distribution.Distribution'
    print(f'Test {Distribution.__name__}::{Distribution.get_distribution_HPUX.__name__}')
    test_module = types.ModuleType(module_name)
    test_module.run_command = Mock(return_value=(0, 'HPUX.OE.11.31.131028.risc', ''))
    distribution = Distribution(test_module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts == {'distribution_version': '11.31', 'distribution_release': '131028'}, "Returned OS information does not match"

# Generated at 2022-06-11 04:34:43.452009
# Unit test for function get_uname
def test_get_uname():
    module = None
    assert get_uname(module, '-s') is not None



# Generated at 2022-06-11 04:34:53.304775
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # name, data, path, collected_facts
    collected_facts = { 'distribution_version': 'NA', 'distribution_release': 'NA'}

    df = DistributionFiles(module)

    # Debian 8.1
    data = """PRETTY_NAME="Debian GNU/Linux 8 (jessie)"
NAME="Debian GNU/Linux"
VERSION_ID="8"
VERSION="8 (jessie)"
ID=debian
HOME_URL="http://www.debian.org/"
SUPPORT_URL="http://www.debian.org/support/"
BUG_REPORT_URL="https://bugs.debian.org/"
"""
    #name, data, path, collected_facts

# Generated at 2022-06-11 04:35:03.664631
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    path = "/etc/os-release"

    distribution = "RedHat"
    distribution_file_path = "/etc/redhat-release"

    distribution_file_variety = "Fedora"
    distribution_file_Atomic = "/etc/fedora-release"
    distribution_file_AtomicHost = "/etc/redhat-release"
    distribution_file_OEL = "/etc/redhat-release"
    distribution_file_path_OEL = "/etc/oracle-release"
    distribution_file_CentOS = "/etc/centos-release"
    distribution_file_path_CentOS = "/etc/system-release"
    distribution_file_path_Scientific = "/etc/system-release-cpe"
    distribution_file_CloudLinux = "/etc/redhat-release"
    distribution_file_Ovirt

# Generated at 2022-06-11 04:36:42.367870
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # unit tests for the parse_distribution_file_SUSE method
    distro_files = DistributionFiles()

    # if path is /etc/os-release, version and release can be found in the same line,
    # this test is for that case.

# Generated at 2022-06-11 04:36:48.696234
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = MagicMock()
    module.run_command.return_value = (0, 'OpenBSD 5.8 (GENERIC) #0: Wed Apr 13 01:30:21 UTC 2016\n', None)
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_OpenBSD()
    assert distribution_facts['distribution_version'] == '5.8'
    assert distribution_facts['distribution_release'] == 'GENERIC'


# Generated at 2022-06-11 04:36:58.010630
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    """
    Test parsing of Debian-based distribution files.

    :return:
    """
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, cmd, required=False, opt_dirs=None):
            return cmd

        def run_command(self, cmd):
            # TODO: MOck out the run_command
            return 0, '', ''

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, item):
            return self.facts[item]

    # test when os-release isn't there

# Generated at 2022-06-11 04:37:07.337072
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # setup
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    dist_facts = DistributionFiles(module).parse_distribution_file("", "", "", "")

    # run tested method
    name = 'Flatcar'
    data = 'GROUP="2015.09.01"'
    path = '/etc/lsb-release'
    collected_facts = {'distribution_release': 'NA'}
    flatcar_facts = dist_facts.parse_distribution_file_Flatcar(name, data, path, collected_facts)

    # assert actual == expected
    assert flatcar_facts == (True, {'distribution_release': '2015.09.01'})


# Generated at 2022-06-11 04:37:17.547523
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    test_cases = (
        ('CentOS', '/etc/system-release', 'CentOS Linux release 8.2.2004 (Core)', {}, False, {}),
        ('CentOS', '/etc/system-release', 'CentOS Stream release 8.2.2004', {}, True, {'distribution_release': 'Stream'}),
    )
    for dist, path, data, collected_facts, expected_parsed, expected_facts in test_cases:
        collected_facts = copy.deepcopy(collected_facts)
        d = DistributionFiles()
        parsed_dist_file, parsed_dist_file_facts = d.parse_distribution_file_CentOS(dist, data, path, collected_facts)
        del parsed_dist_file_facts['distribution_file_parsed']
        del parsed_dist_file_

# Generated at 2022-06-11 04:37:27.291440
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    d_files = DistributionFiles(None)
    collected_facts = {}
    collected_facts['distribution_major_version'] = 'NA'
    collected_facts['distribution_release'] = 'NA'
    collected_facts['distribution_version'] = 'NA'
    data = 'Amazon'
    path = '/etc/issue'
    name = 'Amazon'

    parsed_dist_file, parsed_dist_file_facts = d_files.parse_distribution_file_Amazon(name, data, path, collected_facts)
    assert parsed_dist_file == True
    assert parsed_dist_file_facts['distribution'] == 'Amazon'
    assert parsed_dist_file_facts['distribution_version'] == collected_facts['distribution_version']

# Generated at 2022-06-11 04:37:35.765387
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    dist_file = DistributionFiles(None)
    data = "DISTRIB_RELEASE=\"SNAPSHOT\"\nDISTRIB_CODENAME=\"SNAPSHOT\"\n"
    path = "/etc/os-release"
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    name = 'OpenWrt'
    status, result = dist_file.parse_distribution_file_OpenWrt('OpenWrt', data, path, collected_facts)
    assert status == True
    assert result == {'distribution': 'OpenWrt', 'distribution_version': 'SNAPSHOT', 'distribution_release': 'SNAPSHOT'}



# Generated at 2022-06-11 04:37:44.044604
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_class = DistributionFiles()
    test_distribution_files = {
        'Slackware': {
            '/etc/slackware-version': 'Slackware 14.2',
            '/etc/slackware-release': 'Slackware 14.2',
        }
    }
    test_facts = {'distribution': 'NA'}
    test_result = test_class.parse_distribution_file('Slackware', test_distribution_files, test_facts)
    assert 'slackware' in test_result[0].lower()



# Generated at 2022-06-11 04:37:53.939484
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    test_module = FakeModule(platform='sunos')
    dist = Distribution(test_module)
    test_module.add_file('/etc/release', 'Solaris 10 10/09 s10x_u8wos_08a X86\n')
    test_module.add_file('/etc/product', 'name: Oracle Solaris\n')
    test_module.add_file('/etc/product', 'Image: Solaris 10 10/09 s10x_u8wos_08a X86\n')
    _uname = FakeUname(platform='sunos')
    uname_version = '5.10'
    test_module.add_command('uname', '', '', 0, uname_version)
    test_facts = dist.get_distribution_SunOS()

# Generated at 2022-06-11 04:37:57.048964
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution = Distribution(None)
    distribution.module = FakeModule()
    distribution.get_distribution_Darwin()
    assert distribution.module.run_command.called