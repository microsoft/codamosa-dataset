

# Generated at 2022-06-11 04:29:01.831236
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    set_module_args({})
    my_obj = Distribution(AnsibleModule)
    result = my_obj.get_distribution_NetBSD()
    assert result['distribution_release'] == '9.1_STABLE'
    assert result['distribution_major_version'] == '9'
    assert result['distribution_version'] == '9.1'


# Generated at 2022-06-11 04:29:10.717516
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import platform
    from ansible.module_utils.facts.system import skip_if_none
    from ansible.module_utils.facts.system.distribution import get_file_content
    from ansible.module_utils._text import to_bytes
    distribution = Distribution(None)
    distribution.module.run_command = lambda x: (0, b'', b'')
    assert distribution.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.13.6'}
    DistroFacts = get_distro_facts()
    facts = DistroFacts().populate()

# Generated at 2022-06-11 04:29:21.481981
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    test_class_inst = DistributionFiles()

    data = """
NAME="openSUSE Tumbleweed"
VERSION = "20151118"
ID = opensuse
ID_LIKE = "suse"
VERSION_ID = "20151118"
PRETTY_NAME = "openSUSE Tumbleweed (20151120) (x86_64)"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:tumbleweed:20151120"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://www.opensuse.org/"
CODENAME="Tumbleweed"
"""
    # SUSE Leap
    if os.path.exists('/etc/os-release'):
        os.remove('/etc/os-release')

# Generated at 2022-06-11 04:29:32.067195
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    data = 'DISTRIB_ID="OpenWrt"'
    distribution_file = DistributionFiles()
    assert distribution_file.parse_distribution_file_OpenWrt('OpenWrt', data, '/etc/parameters', {}) == (True, {'distribution_release': '', 'distribution_version': '', 'distribution': 'OpenWrt'})
    data = 'DISTRIB_ID="OpenWrt"\n'\
           'DISTRIB_RELEASE="Backfire (10.03.1)"'
    assert distribution_file.parse_distribution_file_OpenWrt('OpenWrt', data, '/etc/parameters', {}) == (True, {'distribution_release': 'Backfire (10.03.1)', 'distribution_version': '', 'distribution': 'OpenWrt'})
   

# Generated at 2022-06-11 04:29:43.093992
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    test_dist_files = DistributionFiles(test_module, 'Amazon')
    test_facts = {}
    test_dist_files.parse_distribution_file_Amazon('Amazon', '', '/etc/os-release', test_facts)
    assert test_facts == {}
    test_facts = {}
    test_dist_files.parse_distribution_file_Amazon('Amazon', '', '/etc/system-release', test_facts)
    assert test_facts == {'distribution': 'Amazon', 'distribution_version': 'NA'}
    test_facts = {}

# Generated at 2022-06-11 04:29:53.475856
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # test data
    # TODO: consider something with SLES for SAP to verify SLES_SAP distribution
    content_sles12sp1_os_release = 'NAME="SLES" VERSION="12-SP1" VERSION_ID="12.1" PRETTY_NAME="SUSE Linux Enterprise Server 12 SP1" ID="sles" ANSI_COLOR="0;32" CPE_NAME="cpe:/o:suse:sles:12:sp1" BUG_REPORT_URL="https://bugs.opensuse.org" HOME_URL="https://www.suse.com/"'

# Generated at 2022-06-11 04:30:01.057355
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    M = MagicMock()

    M.run_command.return_value = (0,
                                  'HPUX_OE_11.23.0.0_CO_01.157827.0.0.20151201.0630   A.11.23.0.0',
                           'err')
    d = Distribution(M)

    expected = {'distribution_version': 'A.11.23.0.0', 'distribution_release': '0'}
    assert expected == d.get_distribution_HPUX()


# Generated at 2022-06-11 04:30:11.718024
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec={
            'path': {'required': False, 'type': 'str'},
            'data': {'required': False, 'type': 'str'},
            'name': {'required': False, 'type': 'str'},
            'collected_facts': {'required': False, 'type': 'dict'},
        }
    )
    DISTRIB_RELEASE_RE = re.compile(r'^DISTRIB_RELEASE=(.*)')
    # first test is success
    test_data = '''GROUP=stable
            VERSION=1955.3.0'''
    module.params['path'] = '/etc/os-release'
    module.params['data'] = test_data
    module.params['name'] = 'CoreOS'
    module.params

# Generated at 2022-06-11 04:30:21.782878
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    '''
    get_distribution_NetBSD()
    '''

    if not IS_NETBSD:
        raise SkipTest("Not a NetBSD host")

    module = FakeModule()

    fake_output = """
NetBSD 6.2.3_PATCH (GENERIC) #0: Thu Aug  9 23:24:48 UTC 2012
    """

    module.run_command = MagicMock(return_value=(0, fake_output, ''))

    facter = Distribution(module)
    actual = facter.get_distribution_NetBSD()

    expected = {
        'distribution_release': '6.2.3_PATCH',
        'distribution_major_version': '6',
        'distribution_version': '6.2'
    }

    assert actual == expected, "Actual: " + repr

# Generated at 2022-06-11 04:30:28.652912
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    out = '7100-00-01-1041'
    with patch('ansible.module_utils.facts.collector.Distribution.Distribution.module.run_command', return_value=(0, out, None)):
        d = Distribution(MagicMock())
        aix_facts = d.get_distribution_AIX()
        assert dict(distribution_major_version='7100', distribution_version='7100.00', distribution_release='00') == aix_facts


# Generated at 2022-06-11 04:31:05.882058
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    from textwrap import dedent
    from ansible.module_utils.facts.system.distribution import Distribution

    class FakeModule:
        def __init__(self, oslevel_result, oslevel_stdout, oslevel_stderr):
            self.oslevel_result = oslevel_result
            self.oslevel_stdout = oslevel_stdout
            self.oslevel_stderr = oslevel_stderr

        def run_command(self, cmd, check_rc=False, use_unsafe_shell=False):
            if cmd == "/usr/bin/oslevel":
                return self.oslevel_result, self.oslevel_stdout, self.oslevel_stderr


# Generated at 2022-06-11 04:31:16.759069
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    dist_files = DistributionFiles()
    name = "OpenWrt"
    data = 'DISTRIB_ID="OpenWrt"\nDISTRIB_RELEASE="15.05.1"\nDISTRIB_REVISION="r48532"\nDISTRIB_CODENAME="chaos_calmer"\nDISTRIB_TARGET="ar71xx/generic"\nDISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"\nDISTRIB_TAINTS="no-all busybox"\n'  # noqa
    path = "/etc/openwrt_release"
    collected_facts = {"distribution_version": "NA", "distribution_release": "NA", "distribution_major_version": "NA"}
    result = dist_files.parse_distribution_file_

# Generated at 2022-06-11 04:31:28.334315
# Unit test for function get_uname
def test_get_uname():
    # 1. get_uname
    uname_command_1 = "cat /proc/version"
    uname_command_2 = "/bin/uname -r"
    if os.path.isfile(uname_command_1):
        uname_command = uname_command_1
    elif os.path.isfile(uname_command_2):
        uname_command = uname_command_2
    out = os.popen(uname_command).read()
    assert out == get_uname()
    # 2. get_uname with flags
    uname_command_2_2 = "/bin/uname -a"
    if os.path.isfile(uname_command_2_2):
        uname_command_2 = uname_command_2_2
    out = os

# Generated at 2022-06-11 04:31:32.420685
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distributionFiles = DistributionFiles()
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    distributionFiles.parse_distribution_file_Mandriva('Mandriva', '', '', collected_facts)

# Generated at 2022-06-11 04:31:33.898360
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    result = Distribution().get_distribution_HPUX()
    assert result == 'HPUX'


# Generated at 2022-06-11 04:31:41.163875
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    fake_module = FakeModule()
    fake_module.platform_release = '12.1-RELEASE-p3'
    test = Distribution(fake_module)
    facts = test.get_distribution_FreeBSD()
    assert facts['distribution_major_version'] == '12'
    assert facts['distribution_version'] == '12.1'
    assert facts['distribution_release'] == '12.1-RELEASE-p3'
    fake_module.platform_release = '12.1-CURRENT'
    facts = test.get_distribution_FreeBSD()
    assert facts['distribution_major_version'] == '12'
    assert facts['distribution_version'] == '12.1'
    assert facts['distribution_release'] == '12.1-CURRENT'
    fake_module.platform_release

# Generated at 2022-06-11 04:31:51.637258
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_files = DistributionFiles()

    osrelease_data = 'NAME="openSUSE Leap"\nVERSION="42.3"\nVERSION_ID="42.3"\nPRETTY_NAME="openSUSE Leap 42.3"\nID=opensuse\nANSI_COLOR="0;32"\nCPE_NAME="cpe:/o:opensuse:leap:42.3"\nBUG_REPORT_URL="https://bugs.opensuse.org"\nHOME_URL="https://opensuse.org/"\nID_LIKE="suse"\n'
    osrelease_path = "/etc/os-release"
    collected_facts = {'distribution_release': 'NA'}
    name = "SUSE"


# Generated at 2022-06-11 04:32:02.220072
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    distribution = Distribution(module)

    facts = {'distribution': None, 'distribution_version': None, 'distribution_release': None}
    facts['distribution'], facts['distribution_version'], facts['distribution_release'] = distribution.get_distribution_facts().get('distribution', None), distribution.get_distribution_facts().get('distribution_version', None), distribution.get_distribution_facts().get('distribution_release', None)

    if facts['distribution'] not in ('Linux', 'AIX', 'HP-UX', 'Darwin', 'FreeBSD', 'SunOS'):
        module.exit_json(changed=False, ansible_facts=facts)


# Generated at 2022-06-11 04:32:13.016408
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():

    linux = DistributionFiles()
    file_name = 'os-release'
    file_path = os.path.join(os.path.dirname(__file__), 'data/', file_name)
    dist_file_data = get_file_content(file_path)
    # test dist file parsing
    name = 'Debian'
    path = 'os-release'
    facts = {}
    dist_file_parsed, dist_file_parsed_facts = linux.parse_distribution_file_Debian(name, dist_file_data, path, facts)
    assert dist_file_parsed
    assert dist_file_parsed_facts['distribution'] == 'Debian'
    assert dist_file_parsed_facts['distribution_release'] == '9.9'

# Generated at 2022-06-11 04:32:22.521899
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    data = 'DISTRIB_ID="Ubuntu"\n' + \
           'DISTRIB_RELEASE=14.04\n' + \
           'DISTRIB_CODENAME=trusty\n' + \
           'DISTRIB_DESCRIPTION="Ubuntu 14.04.2 LTS"\n'
    distfiles = DistributionFiles('ubuntu', data, '/etc/lsb-release')
    distfiles.parse_distribution_file_Debian('Ubuntu', data, '/etc/lsb-release', {})
    assert distfiles.parsed_dist_file_facts['distribution'] == 'Ubuntu'
    assert distfiles.parsed_dist_file_facts['distribution_release'] == 'trusty'
    assert 'distribution_version' not in distfiles.parsed_dist_file

# Generated at 2022-06-11 04:32:50.560652
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    sunos_facts = {}
    sunos_facts['distribution'] = 'SmartOS'
    sunos_facts['distribution_version'] = '2016051T183021Z'
    sunos_facts['distribution_release'] = 'joyent_2016051T183021Z'
    sunos_facts['distribution_major_version'] = '5.11'
    return sunos_facts


# Generated at 2022-06-11 04:32:54.924254
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    x = DistributionFiles()
    assert x.parse_distribution_file_ClearLinux("RedHat", "NAME=\"Clear Linux\"", "/etc/os-release", {})[0] == True
    assert x.parse_distribution_file_ClearLinux("RedHat", "NAME=\"Fedora\"", "/etc/os-release", {})[0] == False



# Generated at 2022-06-11 04:32:58.216040
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    mytest = Distribution(module=None)
    assert mytest.get_distribution_DragonFly() == {'distribution_release': '4.9.3-RELEASE'}

# Generated at 2022-06-11 04:33:08.972839
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist = DistributionFiles()
    unfound = {'distribution': 'NA', 'distribution_version': 'NA',
               'distribution_major_version': 'NA', 'distribution_release': 'NA'}
    assert dist.parse_distribution_file_Amazon('Amazon', '', '/etc/system-release', unfound)[1] == {'distribution': 'Amazon', 'distribution_version': 'NA'}
    assert dist.parse_distribution_file_Amazon('Amazon', 'Amazon Linux 2016.03', '/etc/system-release', unfound)[1] == {'distribution': 'Amazon', 'distribution_version': '2016.03', 'distribution_major_version': '2016', 'distribution_minor_version': '03'}

# Generated at 2022-06-11 04:33:19.251137
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    simple_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    simple_module.run_command = MagicMock(return_value=(0, "NetBSD 7.0.1 (GENERIC) #0: Thu Nov  2 21:18:47 UTC 2017\n    mkrepro@mkrepro.NetBSD.org:/usr/src/sys/arch/amd64/compile/GENERIC", ""))
    distribution = Distribution(simple_module)
    distribution_NetBSD_output = distribution.get_distribution_NetBSD()
    assert distribution_NetBSD_output == {'distribution': 'NetBSD', 'distribution_release': '7.0.1', 'distribution_version': '7.0', 'distribution_major_version': '7'}

# Generated at 2022-06-11 04:33:29.426959
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    '''
    This method checks if the method get_distribution_NetBSD of class Distribution
    is producing the correct output for a NetBSD machine.
    '''
    # Creating the module stub
    from ansible_collections.ansible.community.plugins.module_utils.common.text.converters import to_unicode
    from ansible.module_utils._text import to_bytes

    class AnsiModuleStub(object):
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == 'uname -r':
                return (0, '8.99.34', '')

# Generated at 2022-06-11 04:33:39.423415
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = FakeModule()

    class FakeUnixCommand(object):
        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            sysctl_version_string = 'NetBSD 8.2 (GENERIC.MP) #0: Thu May 30 15:58:01 UTC 2019'
            command = args[0]
            if command == '/sbin/sysctl -n kern.version':
                return 0, sysctl_version_string, None
            elif command == '/sbin/sysctl -n kern.version.full':
                return 0, sysctl_version_string, None
            return 0, '', ''

    # use a real fake (and not mock)
    module.run_command = FakeUnixCommand().run_command
    distributions = Distribution

# Generated at 2022-06-11 04:33:48.357517
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    test_module = BasicModule()
    test_module.platform_release = "10.3-RELEASE-p11"
    test_class = Distribution(test_module)
    assert test_class.get_distribution_FreeBSD() == {'distribution_major_version': '10', 'distribution_release': '10.3-RELEASE-p11', 'distribution_version': '10.3'}
    test_module.platform_version = "trueos"
    assert test_class.get_distribution_FreeBSD() == {'distribution_major_version': '10', 'distribution_release': '10.3-RELEASE-p11', 'distribution_version': '10.3', 'distribution': 'TrueOS'}

# Generated at 2022-06-11 04:33:55.630189
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    darwin_version = '10.15.7'
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0,darwin_version,''))
    dist = ansible_collections.ansible.community.plugins.distro.Distribution(module)
    dist_facts = dist.get_distribution_Darwin()

    assert dist_facts['distribution'] == 'MacOSX'
    assert dist_facts['distribution_major_version'] == '10'
    assert dist_facts['distribution_version'] == darwin_version



# Generated at 2022-06-11 04:34:06.075212
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    module = AnsibleModule(argument_spec=dict())
    dist_file = DistributionFiles(module)
    collected_facts = {'distribution': 'NA', 'distribution_release': 'NA',
                       'distribution_version': 'NA', 'distribution_major_version': 'NA'}

    name = 'Slackware'
    path = '/etc/slackware-version'
    data = '''\
Slackware 14.2
'''
    expected = {'distribution': name, 'distribution_version': '14.2'}
    parsed_dist, parsed_dist_facts = dist_file.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed_dist == True
    assert parsed_dist_facts == expected



# Generated at 2022-06-11 04:34:31.314881
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # Check the function
    # assert ...
    pass


# Generated at 2022-06-11 04:34:40.302026
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    dat0 = 'CentOS Stream - 8'
    dat1 = 'CentOS Linux release 8.2.2004 (Core)'
    dat2 = 'CentOS Linux release 8.1.1911 (Core)'
    # Expected output should be in each test function.
    # dict{'distribution_release': 'Stream'}

    # testcase 1
    test_obj = DistributionFiles()
    result = test_obj.parse_distribution_file_CentOS('CentOS Stream - 8', dat0, 'file', {})[1]
    expected = {'distribution_release': 'Stream'}
    # verify if output matches expected
    assert result == expected

    # testcase 2
    test_obj = DistributionFiles()

# Generated at 2022-06-11 04:34:44.506688
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    test_module = AnsibleModule(argument_spec={})
    test_distribution = Distribution(test_module)
    test_result = {'distribution_release': '6.6', 'distribution_version': '6.6'}
    assert test_distribution.get_distribution_OpenBSD() == test_result

# Generated at 2022-06-11 04:34:51.373677
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.ansible_release import __version__ as ANSIBLE_VERSION

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    distro = Distribution(module)

    distribution_facts = {
        'distribution': 'HPUX',
        'distribution_release': 'H.11.11',
        'distribution_version': 'B.11.11'
    }


# Generated at 2022-06-11 04:34:56.612124
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    file_path = 'test/unit/files/flatcar-release'
    data = 'GROUP=edge'
    expected_facts = {'distribution_release': 'edge'}
    return_facts = DistributionFiles.parse_distribution_file_Flatcar('flatcar', data, file_path, {})
    assert(return_facts == expected_facts)



# Generated at 2022-06-11 04:35:06.122510
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    text = """NAME="CoreOS"
ID=coreos
VERSION=1002.6.0
VERSION_ID=1002.6.0
BUILD_ID=
PRETTY_NAME="CoreOS 1002.6.0 (Container Linux by CoreOS)"
ANSI_COLOR="38;5;75"
HOME_URL="https://coreos.com/"
BUG_REPORT_URL="https://github.com/coreos/bugs/issues"
COREOS_BOARD="amd64-usr"
"""
    distfacts = DistributionFiles()
    corefacts = distfacts.parse_distribution_file('CoreOS', text, '/etc/coreos/update.conf', {})[1]
    assert corefacts['distribution_release'] == 'Container Linux by CoreOS'


# Generated at 2022-06-11 04:35:13.633887
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    di = DistributionFiles()

# Generated at 2022-06-11 04:35:20.534981
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = MockModule()
    module.run_command = Mock(return_value=(0, "HPUX 11.34 OE B.11.31.1542 HPU-UX_B.11.31_IA/PA_11.31 1542\n", ""))
    dist = Distribution(module)
    dist_facts = dist.get_distribution_HPUX()
    assert dist_facts == {
        'distribution_version': 'B.11.31',
        'distribution_release': '1542',
    }



# Generated at 2022-06-11 04:35:27.441508
# Unit test for function get_uname
def test_get_uname():
    module = __import__('ansible.module_utils.facts.system.distribution')
    module.run_command = lambda c: (0, 'Linux', None)
    assert get_uname(module, '-v') == 'Linux'
    module.run_command = lambda c: (1, None, '')
    assert get_uname(module, '-v') is None
    module.run_command = lambda c: (1, None, None)
    assert get_uname(module, '-v') is None


# Generated at 2022-06-11 04:35:38.920867
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # this test will fail on non debian-like distros
    distro_files = {'NA': '/etc/os-release'}

    distro_data = """NAME=Debian
VERSION="10 (buster)"
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
"""

    module = AnsibleModule(argument_spec={})
    distro_file_obj = DistributionFiles(module)
    na_facts = distro_file_obj.parse_distribution_file_NA('NA', distro_data, '/etc/os-release', {})

    expected_na_facts = {'distribution': 'Debian', 'distribution_version': '10 (buster)'}

# Generated at 2022-06-11 04:36:07.074111
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    run_testcase(
        DistributionFiles,
        DistributionFiles.parse_distribution_file_Coreos,
        ('name', "data", 'path', 'collected_facts'),
        dict(name='CoreOS', data="GROUP=beta\n"),
        dict(distribution_release="beta"),
    )

# Generated at 2022-06-11 04:36:14.638697
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    test_class = DistributionFiles()
    name = 'Raspbian'
    data = 'Raspbian GNU/Linux 8 (jessie)'
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA'}
    should_parse_distribution_file, debian_facts = \
        test_class.parse_distribution_file_Debian(name, data, path, collected_facts)
    assert should_parse_distribution_file
    assert debian_facts['distribution_release'] == 'jessie'
    # TODO: add other test cases
    # TODO: remove this function



# Generated at 2022-06-11 04:36:23.490549
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    test_distribution = Distribution(test_module)

    test_data_Solaris = """
    Oracle Solaris 11.4 SPARC
              Copyright (c) 2018, Oracle Corporation.
              All rights reserved.
              Assembled 28 January 2018
    """

    test_data_SmartOS = """
    SmartOS 20160113T001901Z
    """

    test_data_OmniOS = """
    OmniOS r151007s v223
    """

    test_data_OpenIndiana = """
     OpenIndiana Development oi_151.1.13 X86  Copyright 2010 Oracle and/or its affiliates.
    """


# Generated at 2022-06-11 04:36:28.122245
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    data = "NAME=\"MockOS\"\nID=mockos\nVERSION_ID=0.1\n"
    parsed_dist_file_facts = parse_distribution_file_Mandriva('Mandriva', data, 'MockOS', {})
    assert parsed_dist_file_facts is True


# Generated at 2022-06-11 04:36:37.425662
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    fail_if = [
        dict(
            name='CoreOS',
            data='',
            path='/etc/os-release',
            expected=dict(
                distribution_release=None
            )
        ),
        dict(
            name='CoreOS',
            data='GROUP="beta"',
            path='/etc/os-release',
            expected=dict(
                distribution_release='beta'
            )
        ),
        dict(
            name='CoreOS',
            data='GROUP="stable"',
            path='/etc/os-release',
            expected=dict(
                distribution_release='stable'
            )
        )
    ]

# Generated at 2022-06-11 04:36:41.083218
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # arrange
    df = DistributionFiles()
    name = 'Amazon'
    data = 'test'
    path = '/etc/system-release'
    collected_facts = {}

    # act
    actual = df.parse_distribution_file_Amazon(name, data, path, collected_facts)

    # assert
    expected = (False, {})
    assert actual == expected


# Generated at 2022-06-11 04:36:49.732206
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: verify is needed for this test
    distribution_files = DistributionFiles()

# Generated at 2022-06-11 04:36:54.790991
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution = Distribution(module=None)
    module = Mock()
    distribution.module = module
    setattr(module, 'run_command', mocked_run_command_get_distribution_HPUX)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts == {
        'distribution_version': 'B.11.31',
        'distribution_release': '20170501'
    }

# Generated at 2022-06-11 04:37:02.410481
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    expected_dict = {"distribution_release": "4.6.0-RELEASE", 'distribution': 'DragonFlyBSD'}
    module = AnsibleModule(argument_spec={})
    fact = Distribution(module)
    fact.get_distribution_DragonFly = MagicMock(return_value=expected_dict)

    result = fact.get_distribution_DragonFly()
    assert expected_dict == result

if __name__ == "__main__":
    import doctest
    failed, total = doctest.testmod()
    if failed:
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-11 04:37:12.563096
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    dist_files = DistributionFiles()

    name = 'Debian'
    # data = 'Debian GNU\/Linux 8\.11 \('
    path = '/etc/os-release'
    data = "NAME=\"Debian GNU/Linux\"\n"
    data += "VERSION=\"8 (jessie)\"\n"
    data += "VERSION_ID=\"8\"\n"
    data += "ID=debian\n"
    data += "ANSI_COLOR=\"1;31\"\n"
    data += "HOME_URL=\"http://www.debian.org/\"\n"
    data += "SUPPORT_URL=\"http://www.debian.org/support\"\n"
    data += "BUG_REPORT_URL=\"https://bugs.debian.org/\"\n"

# Generated at 2022-06-11 04:37:47.990747
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    """
    Test of method parse_distribution_file_Amazon of class DistributionFiles from file 'distribution_files.py'
    """
    # Create an object of class DistributionFiles
    _DistributionFiles = DistributionFiles(module=None)
    # Create an object of class AnsibleModule
    # Used to create a fake AnsibleModule to be used as parameter for method parse_distribution_file_Amazon
    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.debug = False
            self.run_command = None
            self.get_bin_path = None
            self.fail_json = None

    _AnsibleModule_obj = AnsibleModule()
    # Create an object of class Arch
    # Used to create a fake Arch to be used as parameter for

# Generated at 2022-06-11 04:37:50.393442
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dragonfly_facts = {
            'distribution_release': '4.8-RELEASE'
    }
    assert Distribution.get_distribution_DragonFly() == dragonfly_facts

# Generated at 2022-06-11 04:38:01.366439
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_file_name = 'SUSE'
    dist_file_data = """SUSE Linux Enterprise Server 11 (x86_64)
VERSION = 11
PATCHLEVEL = 4"""
    dist_file_path = '/etc/SuSE-release'
    dist_file_facts = {
        'distribution_release': 'NA',
        'distribution_version': '11'
    }

    # Mock object
    mock_module = Mock()

# Generated at 2022-06-11 04:38:08.566796
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    f = DistributionFiles()
    name = 'NA'
    data = 'NAME=Fedora\nVERSION="31 (Twenty One Planet)"'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA'}
    parsed_dist_file_facts = f.parse_distribution_file_NA(name, data, path, collected_facts)
    assert parsed_dist_file_facts == (True, {'distribution': 'Fedora', 'distribution_version': '31 (Twenty One Planet)'})

test_DistributionFiles_parse_distribution_file_NA()

# Generated at 2022-06-11 04:38:16.324605
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """
    Unit test for the get_distribution_SunOS() method.
    """

    # Create a module stub.
    module = AnsibleModule(argument_spec=dict())
    module.run_command = run_command_mock_for_test_Distribution_get_distribution_SunOS

    # Generate the facts - FIXME: this method is not an object method, at least not in 2.9
    facts = Distribution(module).get_distribution_SunOS()

    assert facts == {'distribution': 'SmartOS',
                     'distribution_version': '20160210T223644Z',
                     'distribution_release': 'SmartOS 20160210T223644Z x86_64 i86pc'}

