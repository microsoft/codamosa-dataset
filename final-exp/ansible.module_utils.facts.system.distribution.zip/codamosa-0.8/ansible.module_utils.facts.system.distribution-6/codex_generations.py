

# Generated at 2022-06-11 04:28:57.719439
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # Parameters
    name = 'flatcar'
    data = "GROUP=edge"
    path = '/etc/arch-release'

    # Generate collected facts object
    collected_facts = {}
    collected_facts.update({'distribution_release': 'NA', 'distribution_version': 'NA', 'distribution': 'NA'})

    # Create DistributionFiles object
    distro_files = DistributionFiles()

    # Call parse_distribution_file_Flatcar method
    result = distro_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)

    # Compare results with expected values
    assert result == (True, {'distribution_release': 'edge'})


# Generated at 2022-06-11 04:29:07.969442
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    facts = {'distribution': 'NA', 'distribution_version': 'NA'}
    distro_files = DistributionFiles(dict(module=None, collected_facts=facts))

    data = 'NAME="Clear Linux"\nVERSION_ID=26000\nID=clear-linux-os\nPRETTY_NAME="Clear Linux OS 26000"\nANSI_COLOR="0;34"'
    _, parsed_values = distro_files.parse_distribution_file_ClearLinux('clearlinuxOS', data, '', facts)
    assert parsed_values['distribution'] == 'Clear Linux OS'
    assert parsed_values['distribution_major_version'] == '26000'
    assert parsed_values['distribution_version'] == '26000'



# Generated at 2022-06-11 04:29:19.337651
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    """
    Tests for method get_distribution_NetBSD of class Distribution
    """
    my_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # mock get_uname
    my_module.get_uname = MagicMock(
        return_value='NetBSD 7.0 (GENERIC) #0: Fri Dec  1 01:55:09 UTC 2017\n        builds@wb34:/big/builds/abuild/201712010000Z-obj/big/builds/abuild/src/sys/arch/x86/compile/GENERIC'
    )

    actual_result = Distribution(module=my_module).get_distribution_NetBSD()

# Generated at 2022-06-11 04:29:25.860658
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    test_file_content = '''# /usr/share/coreos/lsb-release
#

DISTRIB_ID=Flatcar
DISTRIB_RELEASE=1065.8.0
DISTRIB_CODENAME=" "
DISTRIB_DESCRIPTION="Flatcar Container Linux 1065.8.0 (Beta) "
GROUP=stable
ID=flatcar
VERSION=1065.8.0
VERSION_ID=1065.8.0
BUILD_ID=2018-08-02-1245
PRETTY_NAME="Flatcar Container Linux 1065.8.0 (Beta)"
ANSI_COLOR="38;5;75"
LOGO=flatcar
HOME_URL=https://www.flatcar-linux.org/
'''

# Generated at 2022-06-11 04:29:33.073607
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    def do_test(test_data, expected_results):
        d = DistributionFiles(None)
        actual_results = d.parse_distribution_file_ClearLinux('', test_data, '', {'distribution_release': 'NA', 'distribution_version': 'NA'})
        assert actual_results == expected_results

    with pytest.raises(AssertionError):
        do_test('clearlinux', (False, {}))
    with pytest.raises(AssertionError):
        do_test('clearlinux\nNAME="Clear Linux"', (False, {}))
    with pytest.raises(AssertionError):
        do_test('clearlinux\nNAME="Clear Linux"\nVERSION_ID=31370', (False, {}))

# Generated at 2022-06-11 04:29:42.934947
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = MagicMock()
    module.run_command.return_value = 1234, 'NetBSD 8.99.4 (GENERIC) #0: Fri May 24 15:53:34 CEST 2019  root@build.netbsd.org:/usr/obj/sys/arch/amd64/compile/GENERIC amd64', None
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_major_version'] == '8'
    assert netbsd_facts['distribution_version'] == '8.99'
    assert netbsd_facts['distribution_release'] == '8.99.4'



# Generated at 2022-06-11 04:29:50.944738
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = type('MockModule', (object,), {'run_command': Mock()})
    module.run_command.return_value = [0, 'OpenBSD 6.2 (GENERIC) #1539: Mon Nov  6 15:59:48 MST 2017\ndale@dale-desktop:/usr/src/sys/arch/amd64/compile/GENERIC', '']
    distribution = Distribution(module)
    assert distribution.get_distribution_OpenBSD() == {'distribution_version': '6.2', 'distribution_release': 'snapshot'}


# Generated at 2022-06-11 04:30:00.720862
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    """Test method parse_distribution_file_SUSE of class DistributionFiles.
    """
    dist_files = DistributionFiles()
    parsed_dist_file_facts = {}
    dist_facts = {'distribution': 'NA', 'distribution_release': 'NA',
                  'distribution_version': 'NA', 'distribution_major_version': 'NA'}
    # TODO: this test should be moved to test/units/files/system/distribution.py
    # TEST: /etc/os-release
    # Case: SLES
    os_release = 'NAME="SLES" VERSION="12 SP2" ID="sles" ID_LIKE="suse opensuse" VERSION_ID="12.2"'
    dist_file_name = 'SUSE'
    dist_file_path = '/etc/os-release'

# Generated at 2022-06-11 04:30:01.827190
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: write tests
    pass

# Generated at 2022-06-11 04:30:12.482273
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles

# Generated at 2022-06-11 04:30:48.482813
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # test for multiple versions of SUSE
    assert DistributionFiles.parse_distribution_file_SUSE('/etc/os-release', "NAME=SLES\nVERSION_ID=\"12.1\"")[1] == {'distribution_version': '12.1', 'distribution': 'SLES', 'distribution_major_version': '12'}
    assert DistributionFiles.parse_distribution_file_SUSE('/etc/os-release', "NAME=openSUSE Leap\nVERSION_ID=\"42.2\"")[1] == {'distribution_version': '42.2', 'distribution': 'openSUSE Leap', 'distribution_major_version': '42'}

# Generated at 2022-06-11 04:30:50.037759
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    facts = Distribution()
    facts.module = Mock()
    facts.get_distribution_FreeBSD()

# Generated at 2022-06-11 04:30:56.416803
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # test Distribution.get_distribution_HPUX()
    distribution = Distribution(None)
    distribution_get_distribution_HPUX_facts = distribution.get_distribution_HPUX()
    distribution_get_distribution_HPUX_facts_keys = ['distribution_release', 'distribution_version']
    assert all(key in distribution_get_distribution_HPUX_facts for key in distribution_get_distribution_HPUX_facts_keys)

# Generated at 2022-06-11 04:30:59.423889
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    assert DistributionFiles.parse_distribution_file_Slackware('Slackware', 'Slackware 12.3.0', '/tmp/test', {}) == (True, {'distribution': 'Slackware', 'distribution_version': '12.3.0'})



# Generated at 2022-06-11 04:31:09.522901
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    test = DistributionFiles()
    # create facts object only with necessary keys
    facts = {'distribution_version' : 'NA', 'distribution_release' : 'NA'}
    # SuSE enterprise server
    name = 'SUSE'

# Generated at 2022-06-11 04:31:20.890679
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    """
    Test for parse_distribution_file_NA.
    """
    distribution_files = DistributionFiles({}, None, None)

# Generated at 2022-06-11 04:31:32.145925
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    sunos_distribution_facts = {
        'distribution_version': '10',
        'distribution': 'Solaris',
        'distribution_release': 'Solaris 10 10/09 s10x_u8wos_08a X86',
        'distribution_major_version': '10'
    }
    distribution = Distribution(module=None)
    get_distribution_SunOS_facts = distribution.get_distribution_SunOS()
    for key in sunos_distribution_facts.keys():
        if get_distribution_SunOS_facts[key] != sunos_distribution_facts[key]:
            print("FAILED: get_distribution_SunOS result differs from the expected one, check get_distribution_SunOS and test_Distribution_get_distribution_SunOS methods")
            sys.exit

# Generated at 2022-06-11 04:31:36.452958
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # expected values:
    rc_expected = 0
    out_expected = '7.1'
    err_expected = None
    # testing
    d = Distribution(None)
    rc, out, err = d.get_distribution_AIX()
    assert rc == rc_expected
    assert out == out_expected
    assert err == err_expected

# Generated at 2022-06-11 04:31:42.919918
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    """ Unit test for get_distribution_DragonFly"""
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    import mock

    distribution = Distribution(None)

    distribution_files = DistributionFiles(module=None)
    distribution_files.process_dist_file = mock.MagicMock(return_value=(False, []))

    distribution.get_distribution_DragonFly()

# Generated at 2022-06-11 04:31:46.237775
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    """
    Test method parse_distribution_file_SUSE() of class DistributionFiles
    """
    # TODO: create unit tests for method(s)
    #       - parse_distribution_file_SUSE
    pass

# Generated at 2022-06-11 04:32:26.171314
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    df = DistributionFiles()
    df.module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'path': {'type': 'str', 'required': False},
        },
        supports_check_mode=True,
    )
    assert df.parse_distribution_file_Slackware('Slackware', 'foo bar baz\nSlackware  14.1 \nbar baz', '', {}) == (True, {'distribution': 'Slackware', 'distribution_version': '14.1'})

# Generated at 2022-06-11 04:32:36.368081
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    mandriva_data = '''NAME="Mandriva Linux"
    VERSION="2004 (Limited Edition)"
    ID="mandriva"
    VERSION_ID="2004"
    '''
    mandriva_name = 'Mandriva'
    mandriva_path = '/etc/mandriva-release'
    mandriva_collected_facts = {'distribution': 'Mandriva',
                                'distribution_version': '2004',
                                'distribution_release': 'NA'}

    distfiles = DistributionFiles()
    parsed_mandriva, mandriva_facts = distfiles.parse_distribution_file_Mandriva(mandriva_name, mandriva_data, mandriva_path, mandriva_collected_facts)

    assert parsed_mandriva is True

# Generated at 2022-06-11 04:32:47.538137
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    modobj = AnsibleModule(argument_spec={})
    fake_data = ("GROUP=stable")
    d = DistributionFiles(modobj)
    assert d.parse_distribution_file_Coreos(distro, fake_data, path, {}) == \
        (True, {'distribution_release': 'stable'})
    fake_data = ("GROUP=beta")
    assert d.parse_distribution_file_Coreos(distro, fake_data, path, {}) == \
        (True, {'distribution_release': 'beta'})
    fake_data = ("GROUP=alpha")
    assert d.parse_distribution_file_Coreos(distro, fake_data, path, {}) == \
        (True, {'distribution_release': 'alpha'})


# Generated at 2022-06-11 04:32:54.015058
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # Only run tests if platform_.dist()[0] matches
    if platform.dist()[0].lower() == "openwrt":
        dist_file = DistributionFiles.parse_distribution_file_OpenWrt
        testdata = r"""
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=14.07
DISTRIB_REVISION=r42625
DISTRIB_CODENAME=barrier_breaker
DISTRIB_TARGET=ar71xx/generic
DISTRIB_DESCRIPTION="OpenWrt Barrier Breaker 14.07"
DISTRIB_TAINTS=no
"""

# Generated at 2022-06-11 04:32:58.767981
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    """
    Test method get_distribution_facts of class Distribution
    """
    dist = Distribution()
    facts = dist.get_distribution_facts()
    print("Distribution Facts: %s" % facts)
    assert type(facts['distribution']) is str

test_Distribution_get_distribution_facts()


# Generated at 2022-06-11 04:33:07.955812
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    fake_module = FakeAnsibleModule({})
    fake_distribution_facts = FakeDistributionFacts()
    return_facts = fake_distribution_facts.parse_distribution_file_CentOS("CentOS Stream", "CentOS Stream", "", "")
    assert return_facts == (True, {'distribution_release': "Stream"}), 'CentOS Stream should be true and return \
    {distribution_release: "Stream"}'
    return_facts = fake_distribution_facts.parse_distribution_file_CentOS("CentOS", "CentOS", "", "")
    assert return_facts == (False, {}), 'CentOS should return False and empty dict'



# Generated at 2022-06-11 04:33:10.521841
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution = Distribution(module=MagicMock())
    result = distribution.get_distribution_SunOS()
    assert isinstance(result, dict)



# Generated at 2022-06-11 04:33:17.918674
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    # create a module object
    module = AnsibleModule({})

    # create Distribution instance
    distro = Distribution(module)

    # get facts for the current distribution
    facts = distro.get_distribution_facts()

    # assert that there is some distribution facts
    assert all(facts)

    # assert keys have some value
    assert all(facts.values())

    # assert they are strings
    assert all(isinstance(x, str) for x in facts.values())


# Unit test the method get_distribution_Darwin of class Distribution

# Generated at 2022-06-11 04:33:28.020366
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    distribution_files = DistributionFiles()

# Generated at 2022-06-11 04:33:33.006406
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    fixture = DistributionFiles()
    result = fixture.parse_distribution_file_SUSE('SUSE', 'SUSE Linux Enterprise Server 12 SP2', '/etc/os-release', {'distribution_release': 'NA', 'distribution_version': '12'})
    expected = ({'distribution_release': 'SP2'}, True)
    assert result == expected


# Generated at 2022-06-11 04:34:42.870107
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_release = 'B.11.31'
    distribution_version = 'B.11.31'
    distribution_major_version = 'B'
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_release'] == distribution_release
    assert hpux_facts['distribution_version'] == distribution_version
    assert hpux_facts['distribution_major_version'] == distribution_major_version

# Generated at 2022-06-11 04:34:52.609013
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles

# Generated at 2022-06-11 04:34:57.966587
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    '''Test for parse_distribution_file_Flatcar of class DistributionFiles'''
    os_create = DistributionFiles(dict())
    res, data = os_create.parse_distribution_file_Flatcar('flatcar', 'GROUP=beta', '', '{}')
    assert res == True
    assert data['distribution_release'] == 'beta'



# Generated at 2022-06-11 04:35:07.676313
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # GIVEN an instance of the DistributionFiles class
    dist_files = DistributionFiles()
    # GIVEN a parsed distribution file
    parsed_file = dist_files.parse_distribution_file_ClearLinux('clearlinux', "NAME=\"Clear Linux\"\nVERSION_ID=31450\nID=clear-linux-os\nHOME_URL=\"/\"\nSUPPORT_URL=\"https://clearlinux.org/support\"\nBUG_REPORT_URL=\"https://github.com/clearlinux/distribution/issues\"\n", '', {})
    # WHEN I parse the distribution file
    parsed = parsed_file[0]
    facts = parsed_file[1]
    # THEN the file is parsed, distribution and version are collected.
    assert parsed, "File Not Parsed"

# Generated at 2022-06-11 04:35:12.784809
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    """
    Should Return distribution version and release
    """
    from ansible.module_utils.facts.system.distribution import Distribution
    import ansible.module_utils.basic as basic
    test_module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    dist = Distribution(test_module)
    out = dist.get_distribution_HPUX()
    assert out.get('distribution_version', '') == 'B.11.31'
    assert out.get('distribution_release', '') == '15'

# Generated at 2022-06-11 04:35:21.430151
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Testing with valid input.
    test_data = 'NAME="Mandriva Linux"\nVERSION="2010.0"\nID="mandriva"\nVERSION_ID="2010.0"\nPRETTY_NAME="Mandriva Linux 2010.0"\n'
    file_facts = distribution_files_class.parse_distribution_file_Mandriva("Mandriva", test_data, "/etc/os-release", {})
    assert len(file_facts) == 2
    assert file_facts[0]
    assert file_facts[1]["distribution"] == "Mandriva"
    assert file_facts[1]["distribution_version"] == "2010.0"


# Generated at 2022-06-11 04:35:28.072243
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    from ansible.module_utils.facts import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts import Platform

    class TestModule(object):
        def run_command(self, *args, **kwargs):
            return 0, "10.15.3\n", ""
            return 0, "10.15.3", ""


# Generated at 2022-06-11 04:35:39.593608
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Initialise an instance of the class DistributionFiles
    distribution_files_obj = DistributionFiles()
    # Test when "data" contains "GROUP=STABLE"
    name = "CoreOS"

# Generated at 2022-06-11 04:35:48.835423
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    def test_should_return_distribution_Solaris(self):
        distribution_facts = self.get_distribution_SunOS()
        assert distribution_facts['distribution'] == 'Solaris'
        assert distribution_facts['distribution_major_version'] == '5'
        assert distribution_facts['distribution_version'] == '5.10'
        assert distribution_facts['distribution_release'] == 'Solaris 10 10/09 s10s_u8wos_08a X86'

    def test_should_return_distribution_Oracle_Solaris(self):
        distribution_facts = self.get_distribution_SunOS()
        assert distribution_facts['distribution'] == 'Solaris'
        assert distribution_facts['distribution_major_version'] == '5'

# Generated at 2022-06-11 04:35:52.352468
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec=dict())
    dist = Distribution(module)
    out = dist.get_distribution_Darwin()
    assert out['distribution'] == 'MacOSX'


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 04:37:20.943490
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    TestFactManager.add_dist_file_facts(data='Amazon Linux 2 release',
                                          path='/etc/os-release',
                                          file_name='os-release',
                                          is_parsed=False,
                                          name='Amazon',
                                          parsed_dist_file=True,
                                          parsed_dist_file_facts={'distribution': 'Amazon', 'distribution_version': '2'}
                                        )


# Generated at 2022-06-11 04:37:30.506458
# Unit test for method get_distribution_facts of class Distribution

# Generated at 2022-06-11 04:37:40.723306
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

        def fail_json(self, **kwargs):
            pass

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return (1, '', 'Error')
            # return (0, '', '')

    class FakeFacts(object):
        distribution = 'NA'
        distribution_version = 'NA'
        distribution_release = 'NA'
        distribution_file_openwrt_facts = {'distribution': 'OpenWrt'}

# Generated at 2022-06-11 04:37:43.489754
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    assert Distribution(module).get_distribution_OpenBSD() == {'distribution_release': '5.7', 'distribution_version': '5.7'}

# Generated at 2022-06-11 04:37:46.254570
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # Object for class Distribution
    distribution = Distribution()
    assert distribution.get_distribution_AIX() == {'distribution_major_version': '7', 'distribution_version': '7.1'}

# Generated at 2022-06-11 04:37:48.033879
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    result = Distribution.get_distribution_DragonFly()
    assert result != None


# Generated at 2022-06-11 04:37:58.823316
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    '''
    Unit test for method get_distribution_SunOS of class Distribution
    '''
    distribution = Distribution()


# Generated at 2022-06-11 04:38:08.308251
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles

# Generated at 2022-06-11 04:38:16.738259
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # Create a module_arguments
    module_arguments = {
        'username': 'root',
        'password': 'password',
        'host': 'localhost',
        'port': 22,
        'timeout': 10
    }
    # Create a mock module
    mock_module = MagicMock()
    mock_module.params = module_arguments
    mock_module.run_command = MagicMock()

    # Create a Distribution object
    dist = Distribution(module=mock_module)

    # Run test
    result = dist.get_distribution_AIX()

    # Test result
    assert '7.1' in result['distribution_version']
    assert '7' in result['distribution_major_version']
    assert '7.1' in result['distribution_release']
