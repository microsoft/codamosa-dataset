

# Generated at 2022-06-11 04:29:00.717350
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    d = DistributionFiles(module)


# Generated at 2022-06-11 04:29:05.241748
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
  distro = Distribution('AIX')
  aix_facts = distro.get_distribution_AIX()
  assert 'distribution' == 'AIX'
  assert 'distribution_release' == 6.1
  assert 'distribution_version' == '6.1'


# Generated at 2022-06-11 04:29:13.273515
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    """Test the parse_distribution_file_ClearLinux method
    of the DistributionFiles class
    """
    # Create a test instance of the class DistributionFiles
    testDistributionFiles = DistributionFiles()

    # Create test data to be passed to the method
    name = "clearlinux"
    data = '''NAME="Clear Linux OS"
        VERSION="28110"
        ID="clearlinux"
        ID_LIKE="fedora"
        VERSION_ID="28110"
        PRETTY_NAME="Clear Linux OS 28110"
        '''
    path = "test/test_file"
    collected_facts = {"distribution_major_version": "28110",
                       "distribution_version": "28110"}
    res_exp = True

# Generated at 2022-06-11 04:29:24.053229
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    import os
    import stat
    import tempfile
    import pytest
    from ansible.module_utils.distro import DistributionFiles
    from ansible.module_utils.facts import Collector


# Generated at 2022-06-11 04:29:30.083065
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    fact_collector = DistributionFactsCollector(module=module)
    distribution = Distribution(module=module)
    netbsd_facts = distribution.get_distribution_NetBSD()

    assert netbsd_facts == {'distribution_release': '9.0_BETA', 'distribution_major_version': '9', 'distribution_version': '9.0'}


# Generated at 2022-06-11 04:29:36.893795
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-11 04:29:47.432214
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dragonfly_data = {
        "distribution": 'DragonFlyBSD',
        "distribution_version": '5.5.0',
        "distribution_major_version": '5',
        "distribution_release": '5.5-RELEASE-p3'
    }

    module = AnsibleModule(argument_spec={})
    module.run_command = mock.MagicMock(return_value=(0, 'v5.5.0-RELEASE-p3', ''))
    d = Distribution(module)

    # run the test
    facts = d.get_distribution_DragonFly()

    # are the facts returned?
    assert facts == dragonfly_data


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 04:29:56.174459
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    import platform

    from ansible.module_utils.facts.system.distribution import Distribution

    distro = Distribution(module=None)
    sunos_facts = distro.get_distribution_SunOS()

    if platform.system() == 'SunOS':
        assert sunos_facts['distribution'] == 'Solaris'
        assert sunos_facts['distribution_release'] == '11.3'

    sunos_facts_smartos = distro.get_distribution_SunOS(data='SmartOS 16.09.0')
    assert sunos_facts_smartos['distribution'] == 'SmartOS'
    assert sunos_facts_smartos['distribution_release'] == 'SmartOS 16.09.0'
    assert sunos_facts_smartos['distribution_version'] == '16.09.0'

   

# Generated at 2022-06-11 04:30:00.084888
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    assert Distribution.get_distribution_AIX() == {
        'distribution_version': '7.2',
        'distribution_major_version': '7',
        'distribution_release': '2'
    }

# Generated at 2022-06-11 04:30:10.705800
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_files = DistributionFiles()

# Generated at 2022-06-11 04:30:54.262381
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    ret = {}
    ret['distribution_release'] = '4.99.1'
    ret['distribution_version'] = '4.99'
    ret['distribution_major_version'] = '4'

    module = FakeModule()
    module.run_command = lambda cmd: ('', 'NetBSD 4.99.1 (GENERIC) #0: 2004-07-10 18:12:46 UTC\n', '')
    d = Distribution(module)

    assert d.get_distribution_NetBSD() == ret


# Generated at 2022-06-11 04:31:02.285606
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = run_command_mock
    test_module.get_file_content = get_file_content_mock
    distribution = Distribution(test_module)
    print("get_distribution_HPUX")
    test1 = distribution.get_distribution_HPUX()
    # The swlist command returns different version on different systems
    test2 = distribution.get_distribution_HPUX()
    # This test makes sure that the code is not broken but it doesn't
    # test if the code returns the right data.
    assert test1
    assert test1
    assert test1 == test2


# Generated at 2022-06-11 04:31:04.492335
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution = Distribution()
    response = distribution.get_distribution_HPUX()
    assert response == {}


# Generated at 2022-06-11 04:31:13.233385
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = Mock()
    module.run_command = Mock(return_value=(0, '7.1.0.0', ''))
    distro = Distribution(module)
    assert distro.get_distribution_AIX() == {'distribution_major_version': '7', 'distribution_version': '7.1'}
    module.run_command = Mock(return_value=(0, '7.1', ''))
    distro = Distribution(module)
    assert distro.get_distribution_AIX() == {'distribution_major_version': '7', 'distribution_version': '7.1'}



# Generated at 2022-06-11 04:31:21.107757
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)

    module.run_command = lambda *args, **kwargs_run_command: ('1.4.6-RELEASE', '', 0)
    facts = distro.get_distribution_DragonFly()
    assert facts['distribution_release'] == '1.4.6-RELEASE'
    assert facts['distribution_major_version'] == '1'
    assert facts['distribution_version'] == '1.4.6'


# Generated at 2022-06-11 04:31:23.804863
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    assert Distribution(module).get_distribution_DragonFly() == {}


# Generated at 2022-06-11 04:31:34.296840
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)
    netbsd_facts = {
        'distribution': 'NetBSD',
        'distribution_major_version': '1',
        'distribution_release': '1.2',
        'distribution_version': '1.2'
    }
    if sys.platform != 'netbsd':
        module.fail_json(msg='test_Distribution_get_distribution_NetBSD only works on NetBSD')
    # When platform is NetBSD and sysctl command is executed successfully

# Generated at 2022-06-11 04:31:41.362400
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Creating an instance of DistributionFiles
    distrib_files = DistributionFiles(module)
    # Creating a dict to pass as parameter to DistributionFiles constructor
    distribution_file_data = {}
    distribution_file_data['distribution'] = "NA"
    distribution_file_data['distribution_version'] = "NA"
    distribution_file_data['distribution_major_version'] = "NA"
    distribution_file_data['distribution_release'] = "NA"
    distrib_files.parsed_facts = distribution_file_data
    # Creating a dict to pass as parameter to parse_distribution_file_Coreos
    distribution_file_data = {}
    distribution_file_data['name'] = "coreos"
    distribution_file_data['data'] = "GROUP=stable"
    # We need this path in case of

# Generated at 2022-06-11 04:31:51.965797
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    #
    # Test SUSE data
    #
    # Test SUSE openSUSE Leap
    #
    # /etc/os-release from openSUSE Leap 15.2
    #
    os_release = '''NAME=openSUSE
VERSION="15.2"
ID=opensuse
ID_LIKE="suse"
VERSION_ID="15.2"
PRETTY_NAME="openSUSE Leap 15.2"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:leap:15.2"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://www.opensuse.org/"
'''
    facts = {}
    facts['distribution'] = 'NA'
    facts['distribution_version'] = 'NA'
   

# Generated at 2022-06-11 04:32:02.485685
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    file_data = '''
NAME="openSUSE Leap"
VERSION = "15.0"
'''
    dist_files = DistributionFiles()
    assert dist_files.parse_distribution_file_SUSE('suse', file_data, '/etc/os-release', {'distribution_release': 'NA', 'distribution_version': '15.0'}) == (True,{'distribution': 'openSUSE Leap', 'distribution_release': '0'})
    assert dist_files.parse_distribution_file_SUSE('suse', file_data, '/etc/os-release', {'distribution_release': '15.0', 'distribution_version': 'NA'}) == (True,{'distribution': 'openSUSE Leap', 'distribution_release': '0'})

# Generated at 2022-06-11 04:32:49.442299
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Create an instance of class DistributionFiles
    distro_files = DistributionFiles()
    # Create a dictionary of facts to parse the distribution file and use this to call the method
    # Note: here the distribution file content is 'NAME="Clear Linux"'
    facts = dict(distribution_file_variety='Clear Linux',
                 distribution_file_path='/etc/os-release',
                 distribution_file_content='NAME="Clear Linux"')

    # Call method to parse the distribution file
    valid, parsed_facts = distro_files.parse_distribution_file_ClearLinux('Clear Linux', facts['distribution_file_content'], facts['distribution_file_path'], facts)

    # Assert
    assert valid is True
    assert parsed_facts == {'distribution': 'Clear Linux'}



# Generated at 2022-06-11 04:32:57.615755
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():

    def test_parse_distribution_file_SUSE(file_content, distribution, distribution_version, distribution_release):
        """
        @param file_content: OS release file content
        @param distribution: Expected distribution name
        @param distribution_version: Expected distribution version
        @param distribution_release: Expected distribution release
        """

        distribution_facts = {
            'distribution': 'NA',
            'distribution_version': 'NA',
            'distribution_release': 'NA',
            'distribution_major_version': 'NA',
        }
        dist_file_facts = {
            'distribution_file_variety': 'SUSE',
            'distribution_file_path': '/etc/os-release'
        }


# Generated at 2022-06-11 04:33:08.456676
# Unit test for method get_distribution_SunOS of class Distribution

# Generated at 2022-06-11 04:33:13.977029
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    #Arrange
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)
    dist = Distribution(module)

    #Act
    dist_data = dist.get_distribution_AIX()

    # Assert
    assert_equals(dist_data, {'distribution_major_version': '6', 'distribution_version': '6.1'})


# Generated at 2022-06-11 04:33:23.907137
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # arrange
    module = AnsibleModule(argument_spec={})
    collected_facts = {'distribution': 'NA'}
    df = DistributionFiles()

    # act
    name1 = 'Mandriva'
    path1 = '/etc/mandriva-release'
    data1 = '''Mandriva Linux release 2010.1 (Official) for i586
'''
    parsed_distribution_file1, parsed_dist_file_facts1 = df.parse_distribution_file_Mandriva(name1, data1, path1, collected_facts)
    name2 = 'Mandriva'
    path2 = '/etc/lsb-release'

# Generated at 2022-06-11 04:33:26.533062
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    assert Distribution.get_distribution_DragonFly() == {
        'distribution_release': platform.release()
    }



# Generated at 2022-06-11 04:33:33.315145
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    class MockModule:
        def run_command(self, cmd, use_unsafe_shell=None):
            return 0, "10.11.6", ""

    expected_output = {
        'distribution': 'MacOSX',
        'distribution_major_version': '10',
        'distribution_version': '10.11.6'
    }
    module = MockModule()
    distribution = Distribution(module=module)
    output = distribution.get_distribution_Darwin()

    assert output == expected_output

# Generated at 2022-06-11 04:33:43.284148
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    assert DistributionFiles.parse_distribution_file_Mandriva(
        "", "", "", {"distribution_release": "NA", "distribution_version": "NA"}) == (False, {})
    assert DistributionFiles.parse_distribution_file_Mandriva(
        "", "#Mandriva", "", {"distribution_release": "NA", "distribution_version": "NA"}) == (True, {'distribution': 'Mandriva'})
    assert DistributionFiles.parse_distribution_file_Mandriva(
        "", "", "/etc/os-release", {"distribution_release": "NA", "distribution_version": "NA"}) == (
        False, {})

# Generated at 2022-06-11 04:33:52.832473
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    import os
    import platform

    __name__ = "Distribution"
    dist_RHEL = Distribution(os)
    distribution_facts = {
        'distribution': platform.system(),
        'distribution_release': platform.release(),
        'distribution_version': platform.version(),
        'distribution_major_version': "",
        'os_family': platform.system(),
    }

    hpux_facts = distribution_facts
    out = 'HPUX.OE B.11.31.1409 MU#1'

    if platform.system() == 'Linux':
        os.system(r"echo '{}' > /etc/issue".format(out))

        hpux_facts = dist_RHEL.get_distribution_HPUX()

        # remove the file

# Generated at 2022-06-11 04:34:02.882336
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    df = DistributionFiles()
    # tests should be done with a temporary directory which contains all test files
    # so, first copy all test files to a temporary directory
    tempdir = os.tempnam()
    os.mkdir(tempdir)
    for f in glob.glob('/tmp/ansible_facts/distribution_files/*'):
        shutil.copy2(f, tempdir)
    # test with temporary directory
    df.file_facts['distribution_file_path'] = tempdir + "/etc/os-release"
    df.file_facts['distribution_file_content'] = get_file_content(df.file_facts['distribution_file_path'])
    collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    name = 'SUSE'
   

# Generated at 2022-06-11 04:35:14.500993
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distro_files = DistributionFiles()
    collected_facts = {'distribution':'Coreos'}
    path = '/etc/os-release'
    name = 'Coreos'

# Generated at 2022-06-11 04:35:24.713457
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule({})
    collected_facts = {'distribution': 'NA',
                       'distribution_release': 'NA',
                       'distribution_version': 'NA'}
    distribution_files = DistributionFiles()

    test_data = '''DISTRIB_RELEASE="Backfire (10.03.1)"
DISTRIB_REVISION="r29489"
DISTRIB_TARGET="atheros-2.6"
DISTRIB_ARCH="mips_24kc"
DISTRIB_DESCRIPTION="Backfire (10.03.1)
'''
    parsed, facts = distribution_files.parse_distribution_file_OpenWrt('OpenWrt', test_data, '', collected_facts)
    assert parsed == True
    # TODO: these test should check that the returned data is appropriate
   

# Generated at 2022-06-11 04:35:34.788148
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    """
    Test get_distribution_NetBSD returns the right values
    """
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, "OpenBSD 6.0 (GENERIC) #0: Mon Oct 10 23:58:47 UTC 2016", None))
    test_object = Distribution(module)
    result = test_object.get_distribution_NetBSD()
    assert result == {"distribution_release": "6.0", "distribution_major_version": "6", "distribution_version": "6.0"}

    module.run_command = MagicMock(return_value=(0, "OpenBSD 6.2 (GENERIC) #0: Mon Nov 21 09:02:42 UTC 2016", None))
    result = test_object.get_distribution_NetBSD()

# Generated at 2022-06-11 04:35:43.327094
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    mock_module = MagicMock(name="mock_module")
    mock_module.get_bin_path = MagicMock(name="mock_module.get_bin_path")
    mock_module.run_command = MagicMock(name="mock_module.run_command")
    distribution_files = DistributionFiles(module=mock_module)
    distribution_files.parse_distribution_file_Debian()
    distribution_files.parse_distribution_file_Debian('name', 'data', 'path', 'collected_facts')



# Generated at 2022-06-11 04:35:52.352103
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    facts = Facts()
    dist_file_facts = DistributionFiles(facts).parse_distribution_file_Flatcar("Flatcar", "test", "test", facts)
    assert dist_file_facts[0] == False
    assert dist_file_facts[1] == {}

    facts.get_distribution = MagicMock(return_value="Flatcar")
    flatcar_file_facts = DistributionFiles(facts).parse_distribution_file_Flatcar("Flatcar", "test", "test", facts)
    assert flatcar_file_facts[0] == False
    assert flatcar_file_facts[1] == {}

    flatcar_file_facts = DistributionFiles(facts).parse_distribution_file_Flatcar("Flatcar", "GROUP='stable'", "test", facts)
    assert flatcar_

# Generated at 2022-06-11 04:36:02.017890
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    class MockModule():
        def run_command(self, cmd):
            return 0, '', ''

        def get_bin_path(self, cmd):
            return cmd

    test_distribution_files = DistributionFiles(MockModule())

    dist_release_file_data = """NAME=openSUSE\nVERSION_ID="12.1"""
    _ok, suse_facts = test_distribution_files.parse_distribution_file_SUSE('', dist_release_file_data, '/etc/os-release', {})
    assert suse_facts['distribution'] == 'openSUSE'
    assert suse_facts['distribution_release'] == '12.1'
    assert suse_facts['distribution_version'] == '12.1'

# Generated at 2022-06-11 04:36:05.975554
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    facts = Distribution(module).get_distribution_Darwin()
    assert facts['distribution'] == 'MacOSX'
    assert facts['distribution_version']
    assert facts['distribution_major_version']

# Generated at 2022-06-11 04:36:15.129938
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = Mock()
    dist_files = DistributionFiles(module)
    data = """
GROUP=stable
ID=coreos
VERSION=1353.3.0
VERSION_ID=1353.3.0
PRETTY_NAME="CoreOS 1353.3.0 (Coeur Rouge)"
ANSI_COLOR="0;31"
HOME_URL="https://coreos.com/"
BUG_REPORT_URL="https://bugs.coreos.com/"
COREOS_BOARD=amd64-usr
"""
    for i in ['CoreOS', 'NA']:
        for j in ['CoreOS', 'NA']:
            setattr(module, 'params', dict(
                distribution_file_facts_names=j,
                distribution_file_facts_paths=i))
            ret = dist_files.parse_distribution

# Generated at 2022-06-11 04:36:24.303758
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    # initialize module object
    module = AnsibleModule({
        'path': ['/etc/fedora-release'],
        '_ansible_tmpdir': 'tmp'
    }, supports_check_mode=True)
    # initialize distribution files object
    dist_files = DistributionFiles(module)
    # initialize test collections facts
    test_collected_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA',
    }
    # create assign test data for dist files
    dist_files_testdata = []
    # No dist file is valid execution path
    dist_files_testdata.append((True, test_collected_facts.copy()))

    # Add valid dist file to testdata
   

# Generated at 2022-06-11 04:36:33.836899
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    """test function get_distribution_NetBSD of class Distribution"""
    out1 = """NetBSD 6.1.5 (GENERIC) #0: Sat Sep 21 09:17:32 UTC 2013
    builds@b6.netbsd.org:/home/builds/ab/HEAD/amd64/201309210000Z-obj/home/builds/ab/HEAD/src/sys/arch/amd64/compile/GENERIC
    amd64"""