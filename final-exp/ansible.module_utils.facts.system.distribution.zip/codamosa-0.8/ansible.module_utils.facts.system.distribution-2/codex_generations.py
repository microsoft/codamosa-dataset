

# Generated at 2022-06-11 04:29:49.193610
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    '''
    Test Distribution.get_distribution_DragonFly for multiple release strings
    '''
    from ansible.module_utils.facts.system.distribution import Distribution

    facts = dict()
    d = Distribution(facts)

    get_distribution_DragonFly = d.get_distribution_DragonFly

    # dragonfly_facts = {'distribution_release': platform.release()}
    # rc, out, dummy = self.module.run_command("/sbin/sysctl -n kern.version")
    # match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    # if match:
    #     dragonfly_facts['distribution_major_version'] = match.group(1)
    #     dragonfly

# Generated at 2022-06-11 04:29:57.692075
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # CentOS 4 and 5
    name = 'CentOS'
    data = """
NAME="CentOS Linux"
VERSION="7 (Core)"
ID="centos"
ID_LIKE="rhel fedora"
VERSION_ID="7"
PRETTY_NAME="CentOS Linux 7 (Core)"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:centos:centos:7"
HOME_URL="https://www.centos.org/"
BUG_REPORT_URL="https://bugs.centos.org/"

CENTOS_MANTISBT_PROJECT="CentOS-7"
CENTOS_MANTISBT_PROJECT_VERSION="7"
REDHAT_SUPPORT_PRODUCT="centos"
REDHAT_SUPPORT_PRODUCT_VERSION="7"
    """
   

# Generated at 2022-06-11 04:30:08.585784
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    collect_file_facts_obj = DistributionFiles()
    assert collect_file_facts_obj.parse_distribution_file_ClearLinux(
        "clearlinux", 'NAME="Clear Linux OS"', '/etc/os-release', {}
    ) == (True, {'distribution': 'Clear Linux OS'})
    assert collect_file_facts_obj.parse_distribution_file_ClearLinux(
        "clearlinux", 'VERSION_ID=26300', '/etc/os-release', {}
    ) == (True, {'distribution_major_version': '26300', 'distribution_version': '26300'})

# Generated at 2022-06-11 04:30:18.957734
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    dist_file_paths = ['/etc/mandriva-release']
    dist_file_names = ['Mandriva']
    dist_file_contents = ['Mandriva Linux release 2011.0 (Official) for x86_64']
    dist_file_details = zip(dist_file_names, dist_file_contents, dist_file_paths)

    module = AnsibleModule({})
    df = DistributionFiles(module)
    collected_facts = {'distribution': 'NA'}

    for i in dist_file_details:
        name, data, path = i
        print("Testing %s %s %s" % i)
        parsed_dist_file, parsed_dist_file_facts = df.parse_distribution_file_Mandriva(name, data, path, collected_facts)

# Generated at 2022-06-11 04:30:27.324289
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    slackware = DistributionFiles()
    slackware.distribution_files = {'slackware': '/etc/slackware-version'}
    data = 'Slackware 10.0'
    name = 'slackware'
    (parsed, new_facts) = slackware.parse_distribution_file_Slackware(name, data, '', {})
    assert parsed is True
    assert 'distribution' in new_facts
    assert new_facts['distribution'] == 'Slackware'
    assert 'distribution_version' in new_facts
    assert new_facts['distribution_version'] == '10.0'

# Generated at 2022-06-11 04:30:36.799772
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    from ansible.module_utils.facts.collector import DistributionFiles

    # Arrange
    module = FakeModule()
    distribution_files = DistributionFiles(module)

    # Act
    name = 'flatcar'

# Generated at 2022-06-11 04:30:46.869112
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    dist_files = DistributionFiles()

    name='Openwrt'
    data="""DISTRIB_ID='OpenWrt'
DISTRIB_RELEASE='18.06.0'
DISTRIB_REVISION='r0'
DISTRIB_TARGET='x86/64'
DISTRIB_ARCH='x86_64'
DISTRIB_DESCRIPTION='OpenWrt 18.06.0 r0'
DISTRIB_TAINTS='no-all busybox'
DISTRIB_CODENAME='LEDE'
"""
    path='/etc/lede-release'
    collected_facts = {'distribution': 'NA',
                       'distribution_release': 'NA',
                       'distribution_version': 'NA',
                       'distribution_major_version': 'NA'}

    output = dist_files

# Generated at 2022-06-11 04:30:53.891444
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    dist = DistributionFiles('darwin', ModuleStub())
    flatcar_file = '''GROUP="alpha"
ID="flatcar"
VERSION="2676.2.0 (Dev)"
VERSION_ID="2676.2.0"
BUILD_ID="2017-04-08-1837"
PRETTY_NAME="Flatcar Container Linux (Alpha)"
ANSI_COLOR="1;34"
HOME_URL="https://coreos.com/flatcar/"
BUG_REPORT_URL="https://github.com/coreos/bugs/issues/new"
'''
    name = 'Flatcar'
    data = flatcar_file
    path = '/usr/share/coreos/lsb-release'  # TODO: unused
    facts = {}  # TODO: unused

    (result, parsed_facts) = dist

# Generated at 2022-06-11 04:31:01.880959
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # TEST 1: tests the situation that GROUP key is not present in file `/etc/os-release`
    # process is aborted with an exception
    # TODO: full support #15230, #15228
    os_release_file_missing_group = "/usr/lib/os-release"
    if os_release_file_missing_group in os.listdir('/usr/lib'):
        with pytest.raises(AnsibleExitJson) as err:
            dist = DistributionFiles(create_distro_instance('CoreOs'))
            dist.parse_distribution_file_Coreos('CoreOs', data=None, path=os_release_file_missing_group)

# Generated at 2022-06-11 04:31:10.326224
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = ansible_fake()
    dist = Distribution(module)
    dist.module.run_command = lambda x: (0, 'v4.8.1-RELEASE', None)
    dragonfly_facts = dist.get_distribution_DragonFly()
    distribution_major_version = dragonfly_facts['distribution_major_version']
    distribution_version = dragonfly_facts['distribution_version']
    distribution_release = dragonfly_facts['distribution_release']
    assert distribution_major_version == '4'
    assert distribution_version == '4.8.1'
    assert distribution_release == platform.release()

# Generated at 2022-06-11 04:31:35.983626
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    from ansible.module_utils.facts.distribution.clearlinux.distribution_files_clearlinux import DistributionFiles
    distro_files = DistributionFiles()
    clear_facts = {}
    name = 'clearlinux'
    data = 'NAME="Clear Linux"'
    path = ''
    collected_facts = {}
    assert distro_files.parse_distribution_file_ClearLinux(name, data, path, collected_facts) == (True, {'distribution': 'Clear Linux'})



# Generated at 2022-06-11 04:31:41.883831
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    #  Flatcar_facts - coreos distribution_release
    # input
    flatcar_facts = {}
    distro = get_distribution()
    if distro.lower() == 'flatcar':
        release = re.search("^GROUP=(.*)", data)
        if release:
            flatcar_facts['distribution_release'] = release.group(1).strip('"')
    return True, flatcar_facts

# Generated at 2022-06-11 04:31:47.241573
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    d = Distribution('/bin/bash')

    netbsd_facts = {
        "distribution_release": "6.2_STABLE",
        "distribution_major_version": "6",
        "distribution_version": "6.2"
    }
    assert netbsd_facts == d.get_distribution_NetBSD()



# Generated at 2022-06-11 04:31:57.947813
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles

# Generated at 2022-06-11 04:32:08.810364
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    input1 = """TEST
    """

# Generated at 2022-06-11 04:32:18.371420
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    dist_files = DistributionFiles()
    centos_facts = {}
    collected_facts = {}
    data = "CentOS Stream"

    ret, centos_facts = dist_files.parse_distribution_file_CentOS("CentOS", data, "", collected_facts)
    assert ret == True
    assert centos_facts["distribution_release"] == "Stream"

    centos_facts = {}
    ret, centos_facts = dist_files.parse_distribution_file_CentOS("CentOS", data, "/etc/os-release", collected_facts)
    assert ret == True
    assert centos_facts["distribution_release"] == "Stream"
    data = "CentOS"
    centos_facts = {}

# Generated at 2022-06-11 04:32:26.529234
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    global module_tmpdir
    global module_facts # pylint: disable=global-statement
    module_tmpdir = tempfile.mkdtemp()
    os.environ['TEST_VAR_DIR'] = module_tmpdir
    module_facts['os']['name'] = 'OpenBSD'
    module_facts['os']['version_info'] = {'major': 6, 'minor': 5, 'build': 0, 'revision': 0}
    experiment = Distribution(module=FakeAnsibleModule(module_facts))
    expected = {'distribution_version': '6.5', 'distribution_release': 'release'}
    actual = experiment.get_distribution_OpenBSD()
    assert actual == expected
    shutil.rmtree(module_tmpdir)


# Generated at 2022-06-11 04:32:36.736996
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # init
    dist_files = DistributionFiles()
    test_name = 'SUSE'
    test_path = '/etc/os-release'
    test_data = '''NAME="SLES"
VERSION="15.0"
VERSION_ID="15.0"
PRETTY_NAME="SUSE Linux Enterprise Server 15"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:15"
'''
    collected_facts = dict()

    # run
    test_results = dist_files.parse_distribution_file(test_name, test_data, test_path, collected_facts)

    # verify
    test_results['data_parsed']['distribution'].should.equal('SLES')

# Generated at 2022-06-11 04:32:48.036320
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Setup
    # SUT
    sut = DistributionFiles()

    # Test
    # execute
    data = 'Amazon Linux AMI release 2015.09'

    # Check
    ok, amazon_facts = sut.parse_distribution_file_Amazon('Amazon', data, 'path', 'collected_facts')
    assert ok

    # Test
    # execute
    data = 'Amazon Linux release 2.0.20190228'

    # Check
    ok, amazon_facts = sut.parse_distribution_file_Amazon('Amazon', data, 'path', 'collected_facts')
    assert ok

    # Test
    # execute
    data = 'Amazon Linux release 2.0 (2018.03)'

    # Check

# Generated at 2022-06-11 04:32:53.092345
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    """
    Test method Distribution.get_distribution_OpenBSD()
    """
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)

    openbsd_facts = {'distribution_release': '6.7', 'distribution_version': '6.7'}

    assert distribution.get_distribution_OpenBSD() == openbsd_facts



# Generated at 2022-06-11 04:33:14.885911
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: generate a mock distribution file for Amazon in order to correctly unit test this method
    assert False

# Generated at 2022-06-11 04:33:24.563074
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Test case for data containing Debian
    data = "DISTRIB_ID=Debian\n" \
           "DISTRIB_RELEASE=10\n" \
           "DISTRIB_CODENAME=buster\n" \
           "DISTRIB_DESCRIPTION=\"Debian GNU/Linux 10 (buster)\""
    result = parse_distribution_file_Debian('Debian', data, 'file_path', None)
    assert result[0] is True
    assert result[1]['distribution'] == 'Debian'
    assert result[1]['distribution_release'] == 'buster'

    # Test case for data containing Ubuntu

# Generated at 2022-06-11 04:33:34.859830
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles

# Generated at 2022-06-11 04:33:44.750896
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():

    # Read input files
    distribution_file_names = []
    input_files = glob.glob('input/*_distribution_file')
    for input_file in input_files:
        distribution_file_names.append(input_file.split('_distribution_file')[0].split('/')[1])

    for distribution_file_name in distribution_file_names:

        # Read distribution data
        distribution_file_data = []
        with open('input/' + distribution_file_name + '_distribution_file') as f:
            for line in f:
                distribution_file_data.append(line)

        # Read distribution facts
        distribution_facts = []

# Generated at 2022-06-11 04:33:54.305189
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    m = DistributionFiles()
    data = """
    PRETTY_NAME="OpenWrt 18.06.2"
    NAME="OpenWrt"
    ID=openwrt
    ID_LIKE=lede
    SUPPORT_URL="https://github.com/openwrt/openwrt/"
    BUG_REPORT_URL="https://bugs.openwrt.org/"
    """
    path = '/etc/openwrt_release'
    collected_facts = {}
    assert m.parse_distribution_file_OpenWrt("OpenWrt", data, path, collected_facts) == (True, {'distribution': 'OpenWrt',
                                                                                              'distribution_release': '',
                                                                                              'distribution_version': '18.06.2'})



# Generated at 2022-06-11 04:33:58.740054
# Unit test for function get_uname
def test_get_uname():
    module = FakeModule()
    assert get_uname(module) == 'Linux fake-vm 4.1.12-coreos-r1 #1 SMP Tue Aug 23 19:15:42 UTC 2016 x86_64 GNU/Linux\n'
    assert get_uname(module, '-m') == 'x86_64\n'


# Generated at 2022-06-11 04:34:03.973314
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    class_Distribution = Distribution(module=None)
    string_to_return = class_Distribution.get_distribution_DragonFly()
    assert string_to_return == {'distribution_release': '5.8-RELEASE', 'distribution_major_version': '5',
                                'distribution_version': '5.8.2'}



# Generated at 2022-06-11 04:34:13.910221
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_file_Amazon = DistributionFiles()
    name = 'Amazon'
    path = '/etc/os-release'
    collected_facts = {}
    data = "NAME=\"Amazon Linux\"\nVERSION=\"2\"\nID=\"amzn\"\nID_LIKE=\"centos rhel fedora\"\nVERSION_ID=\"2\"\nPRETTY_NAME=\"Amazon Linux 2\"\nANSI_COLOR=\"0;33\"\nCPE_NAME=\"cpe:2.3:o:amazon:amazon_linux:2\"\nHOME_URL=\"https://amazonlinux.com/\"\nBUG_REPORT_URL="
    parsed_dist_file, parsed_dist_file_facts = distribution_file_Amazon.parse_distribution_file_Amazon(name, data, path, collected_facts)
    assert parsed_dist_file

# Generated at 2022-06-11 04:34:14.633816
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    pass

# Generated at 2022-06-11 04:34:25.638624
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files = DistributionFiles()

# Generated at 2022-06-11 04:34:56.475785
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    d = DistributionFiles()
    path = '/etc/openwrt_version'
    data = 'DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=Bleeding Edge\nDISTRIB_REVISION=r10324-86d78f7b3f\nDISTRIB_CODENAME=barrier_breaker\nDISTRIB_TARGET=ar71xx/generic\nDISTRIB_DESCRIPTION=OpenWrt Barrier Breaker r10324\nDISTRIB_TAINTS=no-all\n'
    name = 'OpenWrt'
    collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    returnval = d.parse_distribution_file_OpenWrt(name, data, path, collected_facts)
    assert returnval[0]

# Generated at 2022-06-11 04:35:06.371829
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    fake_module = FakeModule()
    fake_module.run_command = FakeRunCommand()
    dist = Distribution(fake_module)

    fake_module.run_command.results = [
        0, 'NetBSD 7.0 (INSTALL) #0: Fri Dec  2 00:56:21 UTC 2016', ''
    ]

    actual_result = dist.get_distribution_NetBSD()
    expected_result = {'distribution_release': '7.0',
                       'distribution_major_version': '7',
                       'distribution_version': '7.0'}

    assert actual_result == expected_result

    fake_module.run_command.results = [
        0, 'NetBSD 8.0_BETA (GENERIC) #0: Mon Nov 21 12:53:53 UTC 2016', ''
    ]



# Generated at 2022-06-11 04:35:13.774276
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_facts = DistributionFiles()

    data = "NAME=Amazon Linux AMI\n" \
           "VERSION=\"2018.03\"\n" \
           "ID=\"amzn\"\n" \
           "ID_LIKE=\"rhel fedora\"\n" \
           "VERSION_ID=\"2018.03\"\n" \
           "PRETTY_NAME=\"Amazon Linux AMI 2018.03\"\n" \
           "ANSI_COLOR=\"0;33\"\n" \
           "CPE_NAME=\"cpe:/o:amazon:linux:2018.03:ga\"\n" \
           "HOME_URL=\"http://aws.amazon.com/amazon-linux-ami/\"\n" \
           "Amazon Linux AMI release 2018.03\n"


# Generated at 2022-06-11 04:35:21.731313
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    assert DistributionFiles.parse_distribution_file_OpenWrt(None, 'OpenWrt', 'path', 'collected_facts')[0]
    assert len(DistributionFiles.parse_distribution_file_OpenWrt(None, 'OpenWrt', 'path', 'collected_facts')[1]) == 3
    assert not DistributionFiles.parse_distribution_file_OpenWrt(None, '', 'path', 'collected_facts')[0]
    assert len(DistributionFiles.parse_distribution_file_OpenWrt(None, '', 'path', 'collected_facts')[1]) == 0



# Generated at 2022-06-11 04:35:32.143213
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    data = 'NAME="Clear Linux OS"\nID=clear-linux-os\nVERSION_ID=25880\nPRETTY_NAME="Clear Linux OS 25880"\nANSI_COLOR="1;32"\nHOME_URL="https://clearlinux.org/"\nSUPPORT_URL="https://clearlinux.org/support"\nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"\nBUILD_ID="x86_64-64-zoo-n0y5-kvm-clear-20200511-01"\n';
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    dist = DistributionFiles(module=None)
    parsed, data = dist.parse_dist

# Generated at 2022-06-11 04:35:42.025150
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    dist_file_obj = DistributionFiles()
    dist_file_obj.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    dist_file_obj.module.run_command = MagicMock(return_value=(0, 'Libvirt', ''))

    # actual method call
    dist_file_obj.distribution_file_data = {'/etc/os-release': 'GROUP="stable"\nID="flatcar"'}
    dist_file_obj.get_distribution_facts()

    # assertions
    assert dist_file_obj.collected_facts['distribution_release'] == 'stable'


# Generated at 2022-06-11 04:35:48.912698
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    """
    Test method get_distribution_AIX of class Distribution
    """
    module = FakeModule()
    module._run_command = MagicMock()
    module._run_command.return_value = 0, '7200-03-03-1615', ''
    distribution_facts = Distribution(module)

    expected_result = {'distribution_major_version': '7200',
                       'distribution_version': '7200.3.3',
                       'distribution_release': '3'}

    assert expected_result == distribution_facts.get_distribution_AIX()



# Generated at 2022-06-11 04:35:56.938534
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # create mock for module
    mock_module = MagicMock()
    # mock the run_command to return a desired output
    mock_module.run_command.return_value = (0, r"7200-00-00-0000", None)

    # create instance of class Distribution
    distribution = Distribution(mock_module)
    # run the match method with desired args
    distribution_facts = distribution.get_distribution_AIX()
    # assert that the returned value from the method is as desired
    assert distribution_facts['distribution_major_version'] == '7200'
    assert distribution_facts['distribution_version'] == '7200.0'
    assert distribution_facts['distribution_release'] == '0'
    # check the number of times the run_command was called.
    mock_module.run_command.assert_

# Generated at 2022-06-11 04:36:00.446072
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec=dict())
    dist = Distribution(module=module)

    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'


# Generated at 2022-06-11 04:36:06.628563
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    m = MagicMock()
    from ansible.module_utils.facts.system.distribution import Distribution
    distribution = Distribution(m)
    m.run_command.return_value = (0, '10.14.6', '')
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-11 04:36:32.789001
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    suse_facts = {}
    suse_facts['distribution'] = 'SUSE'
    suse_facts['distribution_release'] = 'Leap'
    suse_facts['distribution_version'] = '42.3'
    return suse_facts


# Generated at 2022-06-11 04:36:41.426338
# Unit test for method get_distribution_Darwin of class Distribution

# Generated at 2022-06-11 04:36:45.171611
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    # Given:
    module = FakeModule()
    distribution = Distribution(module)

    # When:
    result = distribution.get_distribution_OpenBSD()

    # Then:
    assert result['distribution_version'] == '6.7'
    assert result['distribution_release'] == 'release'


# Generated at 2022-06-11 04:36:49.777245
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_OpenBSD
    key, value = distribution_facts.popitem()
    assert key == 'distribution_version'
    assert value == platform.release()

# Generated at 2022-06-11 04:36:59.032329
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    mock = MagicMock(return_value="NetBSD 7.1 (GENERIC)")
    with patch("ansible.module_utils.facts.collector.Distribution.get_distribution_SunOS") as sunos_mock:
        sunos_mock.return_value = {}
        with patch("ansible.module_utils.facts.collector.Distribution.get_distribution_SMGL") as smgl_mock:
            smgl_mock.return_value = {}
            with patch("ansible.module_utils.facts.collector.Distribution.get_distribution_Darwin") as darwin_mock:
                darwin_mock.return_value = {}

# Generated at 2022-06-11 04:37:07.690759
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    data = "NAME=\"Clear Linux OS for Intel Architecture\""
    name = "clearlinux"
    path = "/etc/os-release"
    collected_facts = {"distribution": "NA"}

    # FIXME: mock

    dist_file_obj = DistributionFiles({})
    #parsed_dist_file, parsed_dist_file_facts = dist_file_obj.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    #print("parsed_dist_file: %s" % parsed_dist_file)
    #print("parsed_dist_file_facts: %s" % parsed_dist_file_facts)



# Generated at 2022-06-11 04:37:17.918176
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    collected_facts = {
        "distribution": "NA",
        "distribution_file_path_variety": [],
        "distribution_file_path": [],
        "distribution_file_parsed": False,
        "distribution_file_variety": [],
        "distribution_file_path_variety": "NA",
        "distribution_file_path": "NA",
        "distribution_major_version": "NA",
        "distribution_minor_version": "NA",
        "distribution_version": "NA",
        "distribution_release": "NA"
    }
    # TODO: test SLES and SLES_SAP
    df = DistributionFiles(module)
    # OpenSUSE

# Generated at 2022-06-11 04:37:24.075764
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = FakeAnsibleModule()

    openbsd_facts = {'distribution_release': 'OpenBSD 5.5',
                     'distribution_major_version': '5',
                     'distribution_version': 'OpenBSD 5.5'}
    module.run_command = lambda *args: FakeCommand((0, openbsd_facts['distribution_release'], ''))
    distribution = Distribution(module)
    assert distribution.get_distribution_NetBSD() == openbsd_facts

# Generated at 2022-06-11 04:37:33.326961
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    """
    Test method 'get_distribution_AIX'
    """

    fake_module = FakeModule()
    fake_module.run_command = fake_run_command

    distro = Distribution(fake_module)

    test_oslevel_stdout = """
7100-03-00-0000

"""
    test_oslevel_rc = 0
    test_oslevel_stderr = None

    fake_module.run_command_values['/usr/bin/oslevel'] = (test_oslevel_stdout,
                                                          test_oslevel_rc,
                                                          test_oslevel_stderr)

    details = distro.get_distribution_AIX()


# Generated at 2022-06-11 04:37:43.998685
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    data = {'platform.release': "5.3.3-RELEASE"}
    # monkey patch platform.release
    old_release = platform.release
    platform.release = MagicMock(return_value=data['platform.release'])
    # monkey patch module.run_command
    old_run_command = module.run_command
    module.run_command = MagicMock(return_value=(0, "DragonFly v5.3.3-RELEASE #3   Fri May  8 14:48:25 CDT 2020    root@build6.nyi.dragonflybsd.org:/usr/obj/build/home/justin/src/sys/GENERIC  x86_64", ""))
    distribution_facts = distribution.get_dist

# Generated at 2022-06-11 04:38:12.394213
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    test_input_data = 'DISTRIB_RELEASE="14.07"\nDISTRIB_CODENAME="barrier_breaker"'
    test_input_name = 'OpenWrt'
    with mock.patch('ansible.module_utils.facts.system.distribution.collect_distribution_file_facts.open') as mock_open:
        mock_open.return_value.__enter__.return_value.read.return_value = test_input_data
        distfiles_facts = DistributionFiles()

# Generated at 2022-06-11 04:38:17.463812
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    FBSD = Distribution(MagicMock())
    FBSD.module.run_command.return_value = (0, 'FreeBSD 12.1-RELEASE-p5', '')
    facts = FBSD.get_distribution_FreeBSD()
    assert facts['distribution_major_version'] == '12'
    assert facts['distribution_version'] == '12.1'
    assert facts['distribution_release'] == '12.1-RELEASE-p5'
