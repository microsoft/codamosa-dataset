

# Generated at 2022-06-24 23:53:46.812380
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    data = 'NAME="Amazon Linux AMI"\n' \
           'VERSION="2017.09"\n' \
           'ID="amzn"\n' \
           'ID_LIKE="rhel fedora"\n' \
           'VERSION_ID="2017.09"\n' \
           'PRETTY_NAME="Amazon Linux AMI 2017.09"\n' \
           'ANSI_COLOR="0;33"\n' \
           'CPE_NAME="cpe:/o:amazon:linux:2017.09:ga"\n' \
           'HOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n' \
           'Amazon Linux AMI 2017.09'

# Generated at 2022-06-24 23:53:57.520700
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_files_0 = DistributionFiles()
    name = "OpenWrt"
    data = """
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=12.09
DISTRIB_REVISION=r36088
DISTRIB_CODENAME=attitude_adjustment
DISTRIB_TARGET=ar71xx/generic
DISTRIB_DESCRIPTION="OpenWrt Attitude Adjustment 12.09"
DISTRIB_TAINTS=no-all
"""
    path = "/etc/openwrt_release"
    collected_facts = {}
    distribution_files_0.parse_distribution_file_OpenWrt(name, data, path, collected_facts)



# Generated at 2022-06-24 23:54:05.952281
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    path = '../tests/data/distribution_files/debian'
    files = os.listdir(path)
    distribution_fact_collector_0 = DistributionFactCollector()

    for file in files:
        filename = os.path.join(path, file)
        if not os.path.isfile(filename):
            continue
        with open(filename, 'r') as datafile:
            data = datafile.read()

        # We need to provide mock valued for collected_facts so the value can be used for parsing the file
        collected_facts = {'distribution_release': 'NA',
                           'distribution_version': 'NA',
                           'distribution_file_parsed': False,
                           }

        # A naive approach of getting the distribution name from the filename
        # distribution_file_name = os.path

# Generated at 2022-06-24 23:54:15.257808
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = Dummy_ansible_module()
    distribution_0 = Distribution(module)

# Generated at 2022-06-24 23:54:17.300051
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    d = Distribution({"test":"test"})
    hpux_facts = {'distribution_release': 'B.11.31', 'distribution_version': 'B.11.31'}
    assert d.get_distribution_HPUX() == hpux_facts


# Generated at 2022-06-24 23:54:21.993270
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files_0 = DistributionFiles()
    name = 'NA'
    with open('tests/unit/os/data/etc_os-release', 'r') as os_release_file:
        data = os_release_file.read()
    path = '/etc/os-release'
    collected_facts = {
        'distribution_release': 'NA',
    }
    result = distribution_files_0.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result == (True, {'distribution_release': '1912.3.0'})


# Generated at 2022-06-24 23:54:27.119629
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    # Test results on Ubuntu 12.04
    assert 'distribution' in Distribution(module=None).get_distribution_facts()
    assert 'distribution_version' in Distribution(module=None).get_distribution_facts()
    assert 'distribution_release' in Distribution(module=None).get_distribution_facts()

    # Test results on CentOS 5.7
    assert 'distribution' in Distribution(module=None).get_distribution_facts()
    assert 'distribution_version' in Distribution(module=None).get_distribution_facts()
    assert 'distribution_release' in Distribution(module=None).get_distribution_facts()

    # Test results on RHEL 6.8
    assert 'distribution' in Distribution(module=None).get_distribution_facts()

# Generated at 2022-06-24 23:54:28.868969
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_1 = Distribution(module="Module")

    # get_distribution_SunOS either raises an exception or returns nothing
    try:
        distribution_1.get_distribution_SunOS()
    except Exception:
        pass



# Generated at 2022-06-24 23:54:39.726821
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_fact_collector = DistributionFactCollector()
    name = 'NA'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA'}

    data = '''NAME=Arch Linux
VERSION="rolling"
ID=arch
BUILD_ID=rolling
PRETTY_NAME="Arch Linux"
ANSI_COLOR="0;36"
HOME_URL="https://www.archlinux.org/"
DOCUMENTATION_URL="https://wiki.archlinux.org/"
SUPPORT_URL="https://bbs.archlinux.org/"
BUG_REPORT_URL="https://bugs.archlinux.org/"
'''
    expected_facts = {
        'distribution': 'Arch Linux',
        'distribution_version': 'rolling'
    }
    actual_dist = distribution

# Generated at 2022-06-24 23:54:48.982773
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files_0 = DistributionFiles()

    # Coreos
    distribution_files_0.parse_distribution_file_Coreos('coreos', 'GROUP="CoreOS"', '/usr/sbin/coreos-install', {'distribution_release': 'NA'})

    # FreeBSD
    distribution_files_0.parse_distribution_file_Coreos('FreeBSD', '', '/usr/sbin/coreos-install', {'distribution_release': 'NA'})



# Generated at 2022-06-24 23:55:15.972668
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Call parse_distribution_file_Debian without each of its arguments
    distribution_files_0 = DistributionFiles()
    distribution_files_0.parse_distribution_file_Debian()


# Generated at 2022-06-24 23:55:26.559393
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_HPUX = Distribution(None)
    hpux_facts_expected = {
        'distribution_version': 'B.11.31',
        'distribution_release': '1588473500'
    }
    data = " HPUX_BASE                                                B.11.31.1588473500                                                      HP-UX Base Operating Environment (HPUX_BASE)                           HP-UX                                                 HP 11.31                                                                             "
    hpux_facts = distribution_HPUX.get_distribution_HPUX(data)
    assert hpux_facts_expected == hpux_facts


# Generated at 2022-06-24 23:55:38.773472
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-24 23:55:46.111126
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModuleMock()
    distribution = Distribution(module)
    dragonFly_facts = distribution.get_distribution_DragonFly()
    assert 'DragonflyBSD' in dragonFly_facts['distribution_release']
    assert 'DragonFlyBSD' in dragonFly_facts['distribution_release']
    assert '3.0' in dragonFly_facts['distribution_major_version']


# unit test for method get_distribution_NetBSD of class Distribution

# Generated at 2022-06-24 23:55:47.996300
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    fake_module = FakeModule()
    dist = Distribution(fake_module)
    assert dist.get_distribution_FreeBSD() == {}


# Generated at 2022-06-24 23:55:51.770440
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = Distribution(module)
    dragonfly_facts = {'distribution': 'DragonflyBSD',
                       'distribution_release': '4.4-RELEASE',
                       'distribution_version': '4.4'}
    assert Distribution.get_distribution_DragonFly(module) == dragonfly_facts


# Generated at 2022-06-24 23:56:00.884661
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    distribution_fact_collector_0 = DistributionFactCollector()

# Generated at 2022-06-24 23:56:03.553657
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # Arrange
    # Act
    distribution = Distribution(Missing)
    distribution_facts = distribution.get_distribution_HPUX()
    # Assert
    # TODO: Assert values retrieved from HP-UX

# Generated at 2022-06-24 23:56:08.775497
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files_0 = DistributionFiles()
    distribution_files_0.parse_distribution_file_Coreos(
        'CoreOS', 'GROUP=stable', None, None
    )


# Generated at 2022-06-24 23:56:16.362154
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    configuration = """
    NAME=OpenWrt
    VERSION_ID=18.06.1
    DISTRIB_ID=OpenWrt
    DISTRIB_RELEASE=18.06.1
    DISTRIB_CODENAME=chaos_calmer
    DISTRIB_TARGET=ar71xx/generic
    DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 18.06.1"
    DISTRIB_TAINTS=no-all busybox"""
    distribution_file_data = configuration
    distribution_file_name = 'OpenWrt'
    distribution_file_path = '/etc/openwrt_release'
    distribution_files = DistributionFiles()

# Generated at 2022-06-24 23:56:43.881116
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_fact_collector_0 = DistributionFactCollector()
    distribution_fact_collector_0.parse_distribution_file_NA('NA', 'NAME="Red"; VERSION="8.0"', 'NA', 'NA')


# Generated at 2022-06-24 23:56:50.426212
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    mock_module_0 = type('', (), {})()
    mock_module_0.run_command = MagicMock(return_value=(0, "10.6.3", ""))
    mock_module_0.exit_json = MagicMock()
    mock_module_0.warn = MagicMock()

    distribution_0 = Distribution(module=mock_module_0)
    distribution_0.get_distribution_Darwin()
    mock_module_0.run_command.assert_called_once_with("/usr/bin/sw_vers -productVersion")


# Generated at 2022-06-24 23:57:01.891229
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files_0 = DistributionFiles()


# Generated at 2022-06-24 23:57:12.992219
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles

# Generated at 2022-06-24 23:57:19.499603
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    coreos_facts = {}
    name = 'CoreOS'
    path = '/etc/coreos/update.conf'
    data = 'GROUP=stable-channel'
    collected_facts = {}

    test_case_0 = DistributionFiles()
    test_case_0.parse_distribution_file_Coreos(name, data, path, collected_facts)
    test_case_0.parse_distribution_file_Flatcar(name, data, path, collected_facts)


# Generated at 2022-06-24 23:57:25.188498
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    distribution_obj = Distribution(module)
    openbsd_facts = distribution_obj.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_release'] == platform.release()


# Generated at 2022-06-24 23:57:31.210580
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    test_Distribution_instance = Distribution(module)
    test_Distribution_get_distribution_AIX_output = test_Distribution_instance.get_distribution_AIX()
    test_Distribution_get_distribution_AIX_output_keys = ['distribution_major_version', 'distribution_version', 'distribution_release']
    # TODO: Add assertion to check if the expected keys are present in the dictionary
    test_Distribution_get_distribution_AIX_output.keys()


# Generated at 2022-06-24 23:57:36.276143
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_0 = Distribution(module=None)
    distribution_0.get_distribution_facts()


# Generated at 2022-06-24 23:57:41.893619
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distributionFiles_parse_distribution_file_Slackware_0 = DistributionFiles()
    distributionFiles_parse_distribution_file_Slackware_0.parse_distribution_file_Slackware('name', 'data', 'path', 'collected_facts')


# Generated at 2022-06-24 23:57:47.487292
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_0 = Distribution(module=AnsibleModule())
    distribution_facts = distribution_0.get_distribution_OpenBSD()

if __name__ == '__main__':
    if sys.version_info[0] != 2 or sys.version_info[1] != 7:
        print("Currently python2.7 is not supported.")
        sys.exit(1)

    if len(sys.argv) < 2:
        print("ERROR:: No test case provided.")
        sys.exit(1)

    test_case = sys.argv[1]
    print("INFO:: Running test case: %s" %(test_case))

    if test_case == 'test_case_0':
        test_case_0()

# Generated at 2022-06-24 23:58:13.329388
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_0 = Distribution(module_0)
    facts_0 = distribution_0.get_distribution_OpenBSD()


# Generated at 2022-06-24 23:58:23.784734
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    # Initialize required information
    module = MagicMock(spec=AnsibleModule, params={}, check_mode=True)

    # Initialize class instance
    distribution_instance = Distribution(module)

    # Run test method
    result = distribution_instance.get_distribution_FreeBSD()

    # Helper result
    expect_result = {'distribution_release': '10.4-RELEASE'}

    # Check if result is as expected
    assert isinstance(result, dict), "Result is of type %s, expected dict." % (type(result))
    assert result == expect_result, "Result is %s, expected %s" % (result, expect_result)


# Generated at 2022-06-24 23:58:31.930368
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distribution_fact_collector_1 = DistributionFactCollector()
    distribution_file_list_1 = [('/etc/lsb-release', ['DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2011.0\nDISTRIB_CODENAME=Sauvage\nDISTRIB_DESCRIPTION="Mandriva Linux 2011.0"\n'])]
    distribution_fact_collector_1.distribution_file_facts = distribution_fact_collector_1.parse_distribution_files(distribution_file_list_1)
    assert distribution_fact_collector_1.distribution_file_facts['file_facts']['/etc/lsb-release']['distribution'] == 'Mandriva'
    assert distribution_fact_collector_1.distribution_file_facts

# Generated at 2022-06-24 23:58:36.280743
# Unit test for function get_uname
def test_get_uname():
    print("\nTesting get_uname")
    # Test case 1
    print("Test case 1")
    module_1 = get_uname("-v")
    print("Test case 1: ", module_1)


# Generated at 2022-06-24 23:58:43.910709
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    data = "ID=coreos\nGROUP=stable\nVERSION=1010.6.0\n"
    distribution_facts = {}
    distribution_facts['distribution'] = 'CoreOS'
    distribution_facts['distribution_version'] = '1010.6.0'
    distribution_files = DistributionFiles()
    distribution_files.parse_distribution_file_Coreos(distribution_facts['distribution'], data, None, distribution_facts)
    assert distribution_facts['distribution_release'] == 'stable'


# Generated at 2022-06-24 23:58:54.339586
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'os-release')
    test_data = get_file_content(test_file)
    test_facts = {
        'distribution': 'NA',
        'distribution_version': 'NA'
    }

    collected_facts = {
        'distribution': 'NA',
        'distribution_version': 'NA',
        'distribution_file_facts': {
            'distribution_file_name': 'os-release',
            'distribution_file_path': test_file,
            'distribution_file_variety': 'NA',
            'distribution_file_parsed': True,
        }
    }

    distribution_fact_collector

# Generated at 2022-06-24 23:58:57.189311
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    assert DistributionFiles().parse_distribution_file_CentOS('CentOS Linux', 'CentOS Stream', '/etc/centos-release', {})[1]['distribution_release'] == 'Stream'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:59:07.453954
# Unit test for method process_dist_files of class DistributionFiles

# Generated at 2022-06-24 23:59:15.761450
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    dist_file_name = 'clearlinux-version'
    data = '''NAME="Clear Linux OS for Intel Architecture"
VERSION_ID=24500
ID=clear-linux-os
ID_LIKE=fedora
VERSION="2.445.0 (alpha)"
HOME_URL="https://clearlinux.org/"
BUG_REPORT_URL="https://github.com/clearlinux/distribution/issues/new"'''
    path = '/usr/lib/os-release'
    # TODO: collect_facts is a system fact, don't pass it as argument, just create it here
    collected_facts = {'distribution_version': 'NA'}
    result_success, result_facts = DistributionFiles().parse_distribution_file_ClearLinux(
        dist_file_name, data, path, collected_facts)

    assert result_

# Generated at 2022-06-24 23:59:24.532314
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Parse file
    distribution_files_0 = DistributionFiles()
    parsed_distribution_file = distribution_files_0.parse_distribution_file('Amazon',
                                                                             get_file_content('/etc/system-release'),
                                                                             '/etc/system-release',
                                                                             test_data.collected_facts)
    assert parsed_distribution_file['distribution'] == 'Amazon'
    assert parsed_distribution_file['distribution_version'] == '2'

    # Parse file
    distribution_files_0 = DistributionFiles()

# Generated at 2022-06-25 00:01:17.633281
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distfile_data = """
        NAME=Flatcar Container Linux
        ID=flatcar
        VERSION=2673.4.0
        VERSION_ID=2673.4.0
        BUILD_ID=2018-12-28-0219
        ANSI_COLOR="38;5;75"
        HOME_URL="https://flatcar-linux.org/"
        DOCUMENTATION_URL="https://flatcar-linux.org/docs"
        SUPPORT_URL="https://flatcar-linux.org/support"
        BUG_REPORT_URL="https://github.com/flatcar-linux/flatcar-linux/issues/"
        """
    flatcar_facts = {}

# Generated at 2022-06-25 00:01:29.813344
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distribution_fact_collector_0 = DistributionFactCollector()
    name_0 = 'Slackware'
    data_0 = 'Slackware 15.0\n'
    path_0 = 'path'
    collected_facts_0 = {
        'distribution': 'NA',
        'distribution_version': 'NA',
    }
    return_value_0 = distribution_fact_collector_0.parse_distribution_file_Slackware(name_0, data_0, path_0, collected_facts_0)
    print("Return value: ", return_value_0)
    assert return_value_0[0] == True
    assert return_value_0[1] == {'distribution': 'Slackware', 'distribution_version': '15.0'}



# Generated at 2022-06-25 00:01:38.904698
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_fact_collector_1 = DistributionFactCollector()

    distribution_file_path = "/etc/os-release"
    distribution_file_data = """"
NAME="Amazon Linux AMI"
VERSION="2018.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2018.03"
PRETTY_NAME="Amazon Linux AMI 2018.03"
ANSI_COLOR="0;33"
CPE_NAME="cpe:/o:amazon:linux:2018.03:ga"
HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
""".strip()
    collected_facts = {'distribution': 'Amazon', 'distribution_version': '2018.03'}
    file_variety = 'amz'

    # Test Call

# Generated at 2022-06-25 00:01:46.714055
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # First test: if SuSE release file is found, distribution should be SuSE Linux Enterprise
    dist_files_0 = DistributionFiles()
    # Second test: if openSUSE release file is found, distribution should be openSUSE and distribution release should contain openSUSE version (Leap/Tumbleweed)
    dist_files_1 = DistributionFiles()
    # Third test: if SLES release file is found, distribution should be SLES and distribution release should contain SLES SP version
    dist_files_2 = DistributionFiles()
    # Fourth test: if SLES for SAP release file is found, distribution should be SLES for SAP and distribution release should contain SLES SP version
    dist_files_3 = DistributionFiles()

# Generated at 2022-06-25 00:01:56.633267
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files_0 = DistributionFiles()

    # test 1 SLES
    name = 'SUSE'
    data = '''
NAME="SLES"
VERSION_ID="12.4"
'''
    path = '/etc/os-release'
    collected_facts = {'distribution_version': '12.4', 'distribution_release': 'NA'}
    result = distribution_files_0.parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert result[0] == True
    assert result[1] == {'distribution': 'SLES', 'distribution_version': '12.4', 'distribution_major_version': '12'}

    # test 2 SLES
    name = 'SUSE'

# Generated at 2022-06-25 00:02:07.313090
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # Test case 0
    module = Distribution(module=None)

    test_case_0()

    # Test case 1
    sunos_facts = module.get_distribution_SunOS()

    # Test case 2
    sunos_facts = module.get_distribution_SunOS()

    # Test case 3
    sunos_facts = module.get_distribution_SunOS()

    # Test case 4
    sunos_facts = module.get_distribution_SunOS()

    # Test case 5
    sunos_facts = module.get_distribution_SunOS()

    # Test case 6
    sunos_facts = module.get_distribution_SunOS()

    # Test case 7
    sunos_facts = module.get_distribution_SunOS()

    # Test case 8

# Generated at 2022-06-25 00:02:13.436970
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    module = AnsibleModule(supports_check_mode=False)
    facts = {}
    # create a test distribution file
    test_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-25 00:02:24.029663
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # Run test
    test_data_dir = os.path.dirname(os.path.realpath(__file__)) + '/../test_data/'
    data = get_file_content(test_data_dir + 'distribution_file_openwrt')
    distribution_files = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = distribution_files.parse_distribution_file('OpenWrt', data, '/etc/openwrt_release', {})

    # Assert test
    assert parsed_dist_file_facts['distribution'] == 'OpenWrt'
    assert parsed_dist_file_facts['distribution_release'] == 'Chaos Calmer'
    assert parsed_dist_file_facts['distribution_version'] == '15.05'



# Generated at 2022-06-25 00:02:27.392829
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_fact_collector_0 = DistributionFactCollector()
    result = distribution_fact_collector_0.parse_distribution_file_Flatcar('flatcar', 'GROUP=stable', '/var/etc/release', {})
    assert result[0] == True
    assert result[1]['distribution_release'] == 'stable'


# Generated at 2022-06-25 00:02:38.457185
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_fact_collector = DistributionFactCollector()
    name = 'Coreos'
    path = '/etc/os-release'