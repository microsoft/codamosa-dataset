

# Generated at 2022-06-24 23:54:00.722890
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'L<3R\x0b!U\r%%,! '
    distribution_0 = DistributionFiles(str_0)
    distribution_0.parse_distribution_file_Mandriva()


# Generated at 2022-06-24 23:54:03.369587
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_0 = Distribution('WAP#8&v4B]\x0e')
    distribution_0.get_distribution_Darwin()


# Generated at 2022-06-24 23:54:11.239532
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_facts = {}
    data = 'Amazon'
    path = '/etc/system-release'
    distribution_file_0 = DistributionFiles()
    name = 'Amazon'
    collected_facts = ''
    ret = distribution_file_0.parse_distribution_file_Amazon(name, data, path, collected_facts)
    assert ret[0] == True
    assert ret[1] == {'distribution': 'Amazon'}


# Generated at 2022-06-24 23:54:12.950216
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: FIXME: implement
    print("UNITTEST :: SKIPPING")


# Generated at 2022-06-24 23:54:19.858652
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_files = DistributionFiles({})

    name = 'SUSE'
    data = "NAME=openSUSE\nVERSION = 13.2 (Harlequin) (x86_64)"
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    expected_distribution_file_facts = {'distribution_major_version': '13',
                                        'distribution_version': '13.2',
                                        'distribution': 'openSUSE',
                                        'distribution_release': 'Harlequin'}
    distribution_file_facts = dist_files.parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert distribution_file_facts[1] == expected_distribution_file_facts



# Generated at 2022-06-24 23:54:25.568978
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = '/etc/os-release'
    str_1 = 'NAME="Clear Linux"\nVERSION="2134"\nID=clearlinux\nVERSION_ID=2134\nPRETTY_NAME="Clear Linux 2134"\nANSI_COLOR="1;32"\nHOME_URL="https://clearlinux.org/"\nSUPPORT_URL="https://clearlinux.org/support"\nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues/new"\nPRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy"\nBUILD_ID="22032.0.0"\n'
    distribution_0 = DistributionFiles(str_0)
    str_2 = 'Clear Linux'
    str_3 = ''
    var_0

# Generated at 2022-06-24 23:54:30.801719
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    lsb_release_data = '''
DISTRIB_ID=Ubuntu
DISTRIB_RELEASE=14.04
DISTRIB_CODENAME=trusty
DISTRIB_DESCRIPTION="Ubuntu 14.04 LTS"
'''
    os_release_data = '''
NAME="Ubuntu"
VERSION="14.04.1 LTS, Trusty Tahr"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 14.04.1 LTS"
VERSION_ID="14.04"
HOME_URL="http://www.ubuntu.com/"
SUPPORT_URL="http://help.ubuntu.com/"
BUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"
'''


# Generated at 2022-06-24 23:54:39.851061
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    str_0 = 'L<3R\x0b!U\r%%,! '
    distribution_0 = Distribution(str_0)
    str_1 = 'G\x1b4/\x7f\x0e%c\x10!\x15" '
    data_1 = str_1
    name_2 = 'Slackware'
    path_2 = 'filepath'
    collected_facts_2 = {}
    parsed_dist_file_2, parsed_dist_file_facts_2 = distribution_0.parse_distribution_file_Slackware(name_2, data_1, path_2, collected_facts_2)


# Generated at 2022-06-24 23:54:51.015499
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_file_manager = DistributionFiles(None)

    suite = unittest.TestSuite()
    suite.addTest(ParseDistributionFileSUSETestCase('test_openSUSE_Tumbleweed'))
    suite.addTest(ParseDistributionFileSUSETestCase('test_openSUSE_Leap_15'))
    suite.addTest(ParseDistributionFileSUSETestCase('test_openSUSE_Leap_42_3'))
    suite.addTest(ParseDistributionFileSUSETestCase('test_SLES'))
    suite.addTest(ParseDistributionFileSUSETestCase('test_SLES_SP_2'))

    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-24 23:54:58.879998
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    facter = Facter({})
    fs = facter._filesystem
    os_release_path0 = '/usr/lib/os-release'
    data0 = 'NAME="Clear Linux" VERSION_ID=26700 ID=clear-linux VERSION=26700-64 HOME_URL="https://clearlinux.org/" DOCUMENTATION_URL="https://clearlinux.org/documentation" SUPPORT_URL="https://clearlinux.org/support" BUG_REPORT_URL="https://clearlinux.org/bugs"'
    collected_facts0 = {'distribution_release': 'NA', 'distribution_version': 'NA', 'distribution': 'NA'}
    distribution_files0 = DistributionFiles(facter)
    fs.create_file(os_release_path0)

# Generated at 2022-06-24 23:55:44.385281
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    str_0 = 'L<3R\x0b!U\r%%,! '
    str_0_arr = [str_0]
    str_1 = 'DISTRIB_ID=SUSE Linux Enterprise Server'
    str_1_arr = [str_1]
    str_2 = 'DISTRIB_ID=openSUSE'
    str_2_arr = [str_2]
    str_3 = 'DISTRIB_RELEASE="11"'
    str_3_arr = [str_3]
    str_4 = 'DISTRIB_RELEASE="12.0"'
    str_4_arr = [str_4]
    str_5 = 'DISTRIB_CODENAME="Tumbleweed"'
    str_5_arr = [str_5]

# Generated at 2022-06-24 23:55:53.852133
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    hpux_facts = {'distribution_release': 'B.11.31'}
    distribution = Distribution(hpux_facts)
    get_distribution_HPUX = distribution.get_distribution_HPUX()
    assert get_distribution_HPUX == {'distribution_release': 'B.11.31', 'distribution_version': 'B.11'}

# Generated at 2022-06-24 23:56:02.333908
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():

    # FIXME: Test will fail because no module object passed in as an arg

    # Test method args
    str_0 = 'L<3R\x0b!U\r%%,! '
    distribution_0 = Distribution(str_0)

    # Test conditions
    assert not distribution_0.get_distribution_NetBSD()


# Generated at 2022-06-24 23:56:07.859723
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    flatcar_file_content = '''ID=flatcar\nVERSION_ID=2504.4.0\nGROUP=stable\nLIBC_VERSION=libc6'
    '''
    parsed_flatcar_facts = {'distribution': 'flatcar',
                            'distribution_release': 'stable',
                            'distribution_version': '2504.4.0'}


# Generated at 2022-06-24 23:56:17.426494
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'L<3R\x0b!U\r%%,! '
    distribution_0 = Distribution(str_0)
    name_0 = 'Mandriva'
    data_0 = 'L<3R\x0b!U\r%%,! '
    path_0 = '/etc/lsb-release'
    collected_facts_0 = {}
    return_value_0 = DistributionFiles.parse_distribution_file_Mandriva(distribution_0, name_0, data_0, path_0, collected_facts_0)


# Generated at 2022-06-24 23:56:28.056036
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    v8 = {}
    name_0 = 'Amazon'
    data_0 = 'NAME="Amazon Linux"\nVERSION="2"\nID="amzn"\nID_LIKE="centos rhel fedora"\nVERSION_ID="2"\nPRETTY_NAME="Amazon Linux 2"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"\nHOME_URL="https://amazonlinux.com/"\n\n'
    path_0 = '/etc/os-release'
    collected_facts_0 = {}
    distribution_files_0 = DistributionFiles()

# Generated at 2022-06-24 23:56:33.629756
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # SetUp
    str_0 = 'L<3R\x0b!U\r%%,! '
    distribution_0 = Distribution(str_0)
    # AssertionError
    try:
        distribution_0.get_distribution_DragonFly()
    except AssertionError as e:
        print(e)


# Generated at 2022-06-24 23:56:44.515720
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():

    test_file_0 = '/etc/os-release'
    name_0 = 'ClearLinux'
    data_0 = ('NAME="Clear Linux OS"\n'
              'VERSION_ID=29670\n'
              'PRETTY_NAME="Clear Linux OS 29670"\n'
              'ID=clear-linux-os')
    path_0 = test_file_0
    collected_facts_0 = {'distribution_major_version': 'NA', 'distribution_release': 'NA'}
    expected_0 = True
    expected_1 = {'distribution': 'Clear Linux OS', 'distribution_release': 'clear-linux-os', 'distribution_major_version': '29670', 'distribution_version': '29670'}

    dist_file = DistributionFiles()
    actual_0, actual_1

# Generated at 2022-06-24 23:56:52.856221
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    dist = DistributionFiles()
    distribution_file_path = '/etc/os-release'

# Generated at 2022-06-24 23:56:57.758420
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # Test case with "str" argument
    str_0 = '$\r\r\r\r\r\r\r\r\r\r\r!U\r%%,! '
    DistributionFiles(str_0).parse_distribution_file_OpenWrt()


# Generated at 2022-06-24 23:57:30.767920
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # FIXME: pass in ro copy of facts for this kind of thing
    dist = get_distribution()

    if dist.lower() == "flatcar":
        test_data = open(get_distribution_file_path(dist, "flatcar-release")).read()
        df = DistributionFiles()
        if not df.parse_distribution_file_Flatcar(dist, test_data, "flatcar-release", {}):
            fail('failed: DistributionFiles_parse_distribution_file_Flatcar')


# Generated at 2022-06-24 23:57:34.082036
# Unit test for function get_uname
def test_get_uname():
    try:
        assert True
    except AssertionError:
        print("AssertionError:")
        pass


# Generated at 2022-06-24 23:57:39.190290
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    str = '$\x1e\x1c\x1f\x04\x19\x00\x01\x00\x1a\x00\x10'
    distribution = Distribution(str)

    # Testing with correct arguments
    # No exception
    distribution.get_distribution_HPUX()


# Generated at 2022-06-24 23:57:40.353332
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # FIXME: implement
    assert False


# Generated at 2022-06-24 23:57:42.027586
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: test Slackware
    pass


# Generated at 2022-06-24 23:57:48.532389
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = '/etc/os-release'
    str_1 = 'Clear Linux OS'
    str_2 = '/etc/os-release:\nNAME="Clear Linux OS"\nVERSION="25030"\nID=clearlinux\nVERSION_ID=25030\n'
    str_3 = '/etc/redhat-release'
    str_4 = 'CentOS'
    dict_0 = {'distribution': 'Clear Linux OS', 'distribution_major_version': '25030', 'distribution_version': '25030', 'distribution_release': 'clearlinux'}
    dict_1 = {'distribution': 'NA', 'distribution_major_version': 'NA', 'distribution_version': 'NA'}

# Generated at 2022-06-24 23:57:53.826622
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Start test
    print("Start test of method parse_distribution_file_CentOS")
    # Create object
    distribution_files_obj = DistributionFiles()
    # Call method
    result = distribution_files_obj.parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
    # Check result
    expected = (True, {'distribution_release': 'Stream'})
    print("Expected:")
    print(expected)
    print("Result:")
    print(result)
    if result != expected:
        raise AssertionError("Expected: {0} Got: {1}".format(expected, result))


# Generated at 2022-06-24 23:57:59.320488
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    str_0 = 'L<3R\x0b!U\r%%,! '
    distribution_0 = Distribution(str_0)
    hpux_facts_0 = distribution_0.get_distribution_HPUX()
    hpux_facts_1 = distribution_0.get_distribution_HPUX()
    assert_equals(hpux_facts_1, hpux_facts_0)


# Generated at 2022-06-24 23:58:06.039271
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_1 = '\x0c5\x0c\x0c\x16\x1f\x0c\x16\x0c\x0c\x0c\x0c'
    distribution_1 = Distribution(str_1)
    assert distribution_1.get_distribution_OpenBSD() == {'distribution_release': '6.5', 'distribution_version': '6.5'}
    str_2 = '\x0b\x1e\x0e\x0c\x0c\x0c\x0c\x0c\x0c\x0c\x0c\x0c'
    distribution_2 = Distribution(str_2)

# Generated at 2022-06-24 23:58:15.423931
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_0 = Distribution(str_0)
    # Test with arguments.
    assert distribution_0.get_distribution_SunOS() == {'distribution': 'L<3R\n!U\r%%,! '}
    assert distribution_0.get_distribution_SunOS() == {'distribution': 'L<3R\n!U\r%%,! '}

    # Test with kwargs.
    #result = distribution_0.get_distribution_SunOS(**{'distribution': 'L<3R\n!U\r%%,! '})
    #assert result == {'distribution': 'L<3R\x0b!U\r%%,! '}
    #assert result == {'distribution': 'L<3R\x0b!U\r%%,! '}



# Generated at 2022-06-24 23:58:44.986528
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    file_facts = {}
    distribution_files = DistributionFiles(None)
    distribution_files.process_dist_files(file_facts)
    assert 'distribution_file_path' in file_facts
    assert 'distribution_file_variety' in file_facts

# Generated at 2022-06-24 23:58:54.208421
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_obj1 = DistributionFactCollector()
    distribution_file_paths = []
    for path in test_obj1.distribution_file_paths:
        if os.path.exists(path):
            distribution_file_paths.append(path)
    if not distribution_file_paths:
        distribution_file_paths = [os.path.join('/etc', 'os-release')]

    test_obj1_results = test_obj1.get_distribution_facts(distribution_file_paths)
    var_1 = test_obj1.parse_distribution_file_Slackware('Slackware', '', '', test_obj1_results)
    return var_1


# Generated at 2022-06-24 23:59:00.966370
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_file_clearlinux_0 = DistributionFiles()
    name_0 = 'clearlinux'
    data_0 = 'NAME="Clear Linux" ID=clearlinux VERSION_ID=3193 VERSION="3193 (2018-01-26)" VERSION_CODENAME="Polaris" PRETTY_NAME="Clear Linux 3193 (2018-01-26)" ANSI_COLOR="1;33" HOME_URL="https://clearlinux.org/" SUPPORT_URL="https://clearlinux.org/community" BUG_REPORT_URL="https://github.com/clearlinux/distribution/issues" PRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy"'
    path_0 = '/etc/os-release'

# Generated at 2022-06-24 23:59:11.574186
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # input
    path = '/etc/slackware-version'
    name = 'Slackware'
    data = '14.2'
    collected_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA'
    }

    # run method
    distribution_files = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = distribution_files.parse_distribution_file_Slackware(name, data, path, collected_facts)

    assert parsed_dist_file == True
    assert parsed_dist_file_facts == {'distribution': 'Slackware', 'distribution_version': '14.2'}


# Generated at 2022-06-24 23:59:21.797614
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_file_paths = {'file_path': '/etc/os-release', 'file_name': 'NA', 'name': 'OpenWrt'}
    distribution_fact_collector_0 = DistributionFactCollector()
    distribution_fact_collector_0.distribution_files = [distribution_file_paths]

# Generated at 2022-06-24 23:59:29.915758
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_files_0 = DistributionFiles()
    var_1 = get_distribution_files(distribution_files_0, {}, {}, "OpenWrt")
    distribution_files_0.parse_distribution_file_OpenWrt(
        "Kali", "/etc/os-release", "OpenWrt", var_1)


# Generated at 2022-06-24 23:59:30.944826
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_0 = Distribution()
    distribution_0.get_distribution_AIX()


# Generated at 2022-06-24 23:59:38.915331
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distribution_fact_collector = DistributionFactCollector()
    distributed_facts = {}
    dist_name = 'Slackware'
    dist_file_path = '/etc/slackware-version'
    dist_file_data = 'Slackware 14.1'
    distributed_facts['distribution'] = 'NA'
    distributed_facts['distribution_version'] = 'NA'
    # Normal test case - check that dist_name is Slackware and collected_facts['distribution'] is unchanged
    result = distribution_fact_collector.parse_distribution_file(dist_name, dist_file_data, dist_file_path, distributed_facts)
    assert result['distribution'] == 'Slackware' and distributed_facts['distribution'] == 'NA'

    # Negative test case - check that dist_name is Amazon and collected_facts

# Generated at 2022-06-24 23:59:48.359566
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_files_0 = DistributionFiles()
    file_path_0 = 'file-path-0'
    file_content_0 = """DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=12.09.1
DISTRIB_REVISION=r30124-9e03b96560
DISTRIB_CODENAME=attitude_adjustment
DISTRIB_TARGET=ar71xx/generic
DISTRIB_DESCRIPTION="OpenWrt Attitude Adjustment 12.09.1"
DISTRIB_TAINTS=
"""

# Generated at 2022-06-24 23:59:50.902030
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_files_0 = DistributionFiles()
    var_0 = distribution_files_0.parse_distribution_file_CentOS(get_uname(), '/etc/system-release', '/etc/system-release', {})


# Generated at 2022-06-25 00:01:35.867523
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dragonfly_facts = {
        'distribution_release': platform.release()
    }

    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        dragonfly_facts['distribution_major_version'] = match.group(1)
        dragonfly_facts['distribution_version'] = '%s.%s.%s' % match.groups()[:3]

    assert(dragonfly_facts['distribution_version'] == Distribution.get_distribution_DragonFly(distribution_fact_collector_0)['distribution_version'])

# Generated at 2022-06-25 00:01:37.011073
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    test_class = Distribution(None)
    test_class.get_distribution_AIX()


# Generated at 2022-06-25 00:01:38.417056
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_darwin_0 = Distribution(module='var_1')
    var_2 = get_distribution_Darwin(distribution_darwin_0)


# Generated at 2022-06-25 00:01:39.909993
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_0 = Distribution()
    distribution_facts = distribution_0.get_distribution_Darwin()
    print(distribution_facts)


# Generated at 2022-06-25 00:01:51.074938
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution_0 = Distribution(module_0)
    sunos_facts_0 = {'distribution_release': platform.release()}
    platform_release_0 = platform.release()
    sunos_facts_0['distribution_release'] = platform_release_0
    rc_0, out_0, dummy_0 = distribution_0.module.run_command("/sbin/sysctl -n kern.version")
    match_0 = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out_0)
    if match_0:
        sunos_facts_0['distribution_major_version'] = match_0.group(1)

# Generated at 2022-06-25 00:01:54.632207
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # FIXME: test with a file that exsits and has valid contenets

    path = "path"
    data = 'GROUP="alpha"'
    name = "Flatcar Linux"
    distribution_files = DistributionFiles()
    collected_facts = {}

    distribution_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)


# Generated at 2022-06-25 00:01:59.952224
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_fact_collector = DistributionFactCollector()
    distfiles = distribution_fact_collector.distfiles

    # name, data, path, collected_facts
    name = 'Coreos'
    data = '''GROUP=stable
     ID=coreos
   VERSION=1103.2.0
   VERSION_ID=1103.2.0
   BUILD_ID=2016-02-24-1533
   PRETTY_NAME="CoreOS 1103.2.0 (Stable)"
   ANSI_COLOR="38;5;75"
   HOME_URL="https://coreos.com/"
   DOCUMENTATION_URL="https://coreos.com/os/docs/latest/"
   SUPPORT_URL="https://bugs.coreos.com"'''
    path = '/etc/os-release'
   

# Generated at 2022-06-25 00:02:03.343357
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_0 = Distribution(module=None)
    distribution_facts_0 = distribution_0.get_distribution_HPUX()
    var_0 = distribution_facts_0.get('distribution_release')


# Generated at 2022-06-25 00:02:10.569949
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distributionFiles = DistributionFiles()
    name = 'Clear Linux OS'
    data = 'NAME="Clear Linux OS"\nID=clearlinux\nVERSION_ID="31260"\nPRETTY_NAME="Clear Linux OS"\nANSI_COLOR="1;34"\nHOME_URL="http://clearlinux.org/"\nDOCUMENTATION_URL="https://docs.01.org/clearlinux/latest"\nSUPPORT_URL="https://01.org/clearlinux/support"\nBUG_REPORT_URL="https://01.org/clearlinux/community/report-an-issue"\n'
    path = '/etc/os-release'

# Generated at 2022-06-25 00:02:14.189171
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_fact_collector_0 = DistributionFactCollector()
    var_0 = Distribution(distribution_fact_collector_0).get_distribution_OpenBSD()
    assert var_0 == {'distribution_release': '5.6', 'distribution_version': '5.6'}
