

# Generated at 2022-06-24 23:53:57.340279
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # Set up fixture
    distribution_fact_collector_1 = DistributionFactCollector()
    distribution_fact_collector_1.module.params = {"etc_os_paths": ['/etc/os-release']}

    # Run test method
    parsed = distribution_fact_collector_1.parse_distribution_file('Flatcar', 'GROUP="stable"', '/etc/os-release')

    # Verify test
    assert parsed[1]['distribution_release'] == 'stable'


# Generated at 2022-06-24 23:54:00.080074
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    print("test_Distribution_get_distribution_FreeBSD")
    dist = Distribution(ModuleStub())
    freebsd_facts = dist.get_distribution_FreeBSD()
    print(freebsd_facts)


# Generated at 2022-06-24 23:54:09.931346
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distribution_files_0 = DistributionFiles(module=None)

    name = 'Slackware'
    data = 'Slackware 8.1.0'
    path = 'some/unlikely/slackware/file/path'
    collected_facts = {}
    result = distribution_files_0.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert result[0]

    # FIXME: mock and improve test coverage
    data = 'otherware 8.1.0'
    result = distribution_files_0.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert not result[0]


# Generated at 2022-06-24 23:54:17.580549
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Create object of class DistributionFiles
    distribution_files_0 = DistributionFiles()

    # Create object of class CollectedFacts
    collected_facts_0 = CollectedFacts()

    # Create object of class DistributionFactCollector
    distribution_fact_collector_0 = DistributionFactCollector()

    # Set collected_facts_0.distribution_version to a value
    collected_facts_0.distribution_version = '13.2'

    # Set collected_facts_0.distribution to a value
    collected_facts_0.distribution = 'NA'

    # Set collected_facts_0.distribution_release to a value
    collected_facts_0.distribution_release = 'NA'

    # Call the method parse_distribution_file_SUSE of class DistributionFiles
    distribution_files_0.parse_distribution_

# Generated at 2022-06-24 23:54:22.574782
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dist = Distribution(None)
    dist_facts = dist.get_distribution_DragonFly()
    assert dist_facts and 'distribution_release' in dist_facts

if __name__ == '__main__':
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    suite.addTest(loader.loadTestsFromTestCase(test_case_0))

    suite.addTest(loader.loadTestsFromTestCase(test_Distribution_get_distribution_DragonFly))

    unittest.TextTestRunner(verbosity=2).run(suite)
    print('%s' % suite)

# Generated at 2022-06-24 23:54:31.026626
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    #
    # This test case will be executed with module_setup == True, because it
    # uses the module_utils/facts.py file.
    #
    dist_files = DistributionFiles({'ANSIBLE_MODULE_SETUP': True, 'ANSIBLE_MODULE_ARGS': None})
    dist_file_name = 'lsb-release'

# Generated at 2022-06-24 23:54:34.052596
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    test_case_0()
    return True

if __name__ == '__main__':
    print(test_Distribution_get_distribution_NetBSD())

# Generated at 2022-06-24 23:54:44.435909
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():

    # Should return True, and suse_facts = {'distribution': 'SLES', 'distribution_version': '15'}
    name = 'SUSE'
    data = '''NAME="SLES"
VERSION="12"
VERSION_ID="12"
PRETTY_NAME="SUSE Linux Enterprise Server 12"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12"'''
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA'}
    distribution_fact_collector_0 = DistributionFactCollector()

    # Uncomment following line to check the output

# Generated at 2022-06-24 23:54:48.979128
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_fact_collector_0 = DistributionFactCollector()

    # Test case 0
    name = 'CentOS Linux'
    data = ''
    path = ''
    collected_facts = {}
    res = distribution_fact_collector_0.parse_distribution_file_CentOS(name, data, path, collected_facts)
    assert res == (False, {})


# Generated at 2022-06-24 23:54:55.600483
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_fact_collector_1 = DistributionFactCollector()
    amazon_image = """NAME="Amazon Linux AMI"
VERSION="2017.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2017.03"
PRETTY_NAME="Amazon Linux AMI 2017.03"
ANSI_COLOR="0;33"
CPE_NAME="cpe:/o:amazon:linux:2017.03:ga"
HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
"""
    collected_facts_1 = { 'distribution': 'NA', 'distribution_major_version': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA' }

# Generated at 2022-06-24 23:55:34.465711
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    test_data = '''
Flatcar
GROUP=stable
VERSION_ID=267.1.0
VERSION_CODENAME=blueprint
'''
    path = "/etc/flatcar-release"
    flatcar_facts = collections.namedtuple("flatcar_facts", "name, data, path, collected_facts")
    flatcar_facts.name = "Flatcar"
    flatcar_facts.data = test_data
    flatcar_facts.path = path
    flatcar_facts.collected_facts = None
    distribution_files_obj = DistributionFiles()
    distribution_files_obj.logger = FakeLogger()
    distribution_files_obj.collectors = []
    distribution_files_obj.params = []
    distribution_files_obj.collector_paths = [dist_files_path]



# Generated at 2022-06-24 23:55:39.977167
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    test_case = 0
    if test_case == 0:
        test_case_0()
    else:
        raise Exception('Unimplemented test case: %s' % str(test_case))

if __name__ == '__main__':
    test_Distribution_get_distribution_facts()

# Generated at 2022-06-24 23:55:47.082670
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = MagicMock()
    dist = Distribution(module)

    module.run_command.return_value = (0, "7.1", "")
    aix_facts = dist.get_distribution_AIX()
    assert 'distribution_major_version' in aix_facts
    assert 'distribution_version' in aix_facts
    assert 'distribution_release' in aix_facts
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'

    module.run_command.return_value = (0, "7.1.1", "")
    aix_facts = dist.get_distribution_AIX()

# Generated at 2022-06-24 23:55:56.183342
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    from ansible.module_utils.facts.collector.distribution import DistributionFiles
    distribution_files_0 = DistributionFiles()
    collected_facts = {
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA'
    }
    distribution_name = 'NA'
    file_path = '/etc/os-release'
    file_content = '''
NAME="SLES"
VERSION_ID="12"
'''
    print("result: ", distribution_files_0.parse_distribution_file_SUSE(distribution_name, file_content, file_path, collected_facts))


# Generated at 2022-06-24 23:56:00.803172
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # test for netbsd release 5.1
    pinfo = platform.platform()
    pversion = platform.version()
    prelease = platform.release()
    print(pinfo, pversion, prelease)

# Generated at 2022-06-24 23:56:07.674046
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Test Case 1 - clearlinux.conf file
    dist_name = 'Cumulus Linux'
    dist_data = ('NAME="clearlinux"\n'
                 'VERSION="2721"\n'
                 'ID=clearlinux\n'
                 'VERSION_ID=2721')
    dist_path = '/usr/share/defaults/etc/os-release'
    dist_collector = DistributionFactCollector()
    # validate results
    is_collectable, dist_facts = dist_collector.parse_distribution_file_ClearLinux(dist_name, dist_data, dist_path,\
                                                                                    {'distribution_version': 'NA', 'distribution_release': 'NA'})

# Generated at 2022-06-24 23:56:19.311264
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    suse_facts = {}
    suse_facts['distribution_major_version'] = 'NA'
    suse_facts['distribution_version'] = 'NA'
    suse_facts['distribution_release'] = 'NA'
    suse_facts['distribution'] = 'NA'

    # Check for sles without patch version
    data = '''SUSE Linux Enterprise Server 12 (x86_64)'''
    parsed_suse_facts = DistributionFiles.parse_distribution_file_SUSE('suse', data, '', suse_facts)
    assert(parsed_suse_facts['distribution_major_version'] == '12')
    assert(parsed_suse_facts['distribution_version'] == '12')

# Generated at 2022-06-24 23:56:30.546726
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    distribution_fact_collector_1 = DistributionFactCollector()
    distribution_files_1 = DistributionFiles()
    #Test 1: distribution_files empty.
    available_dist_files_1 = []
    expected_dist_files_1 = []
    collected_facts_1 = {}
    distribution_files_1.process_dist_files(collected_facts_1, distribution_fact_collector_1, available_dist_files_1)
    assert expected_dist_files_1 == collected_facts_1['distribution_files']
    #Test 2: distribution_files not empty.
    available_dist_files_2 = [{'name': 'test_name', 'path': 'test_path', 'content': 'test_content'}]

# Generated at 2022-06-24 23:56:40.040001
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles

# Generated at 2022-06-24 23:56:48.409593
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_fact_collector_0 = DistributionFactCollector()
    distribution_fact_collector_0.get_distribution_facts = Mock()
    collected_facts = {}
    distribution_fact_collector_0.get_distribution_facts.return_value = collected_facts
    distribution_files_1 = DistributionFiles()

    # case 1
    name = "SUSE"
    data = "NAME=SUSE Linux Enterprise Server"
    path = "/etc/os-release"
    parsed_dist_file_facts = {}
    parsed_dist_file_facts['distribution'] = 'SLES'
    parsed_dist_file_facts['distribution_release'] = '12'
    parsed_dist_file_facts['distribution_version'] = '12.1'

    distribution_fact_collector_0.get_distribution

# Generated at 2022-06-24 23:57:38.640759
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    distribution_fact_collector_0 = DistributionFactCollector()



# Generated at 2022-06-24 23:57:45.695474
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Setup
    distribution_files_0 = DistributionFiles()

    # Test data

# Generated at 2022-06-24 23:57:52.080856
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    """Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles"""
    distribution_file = DistributionFiles(None)

    # Test 0
    name = "clearlinux"
    data = "NAME=\"Clear Linux OS\"\nVERSION=\"31120\"\nID=clear-linux-os\nVERSION_ID=31120\nPRETTY_NAME=\"Clear Linux OS 31120\"\nANSI_COLOR=\"0;33\"\nHOME_URL=\"https://www.clearlinux.org/\"\nSUPPORT_URL=\"https://community.clearlinux.org/\"\nBUG_REPORT_URL=\"https://github.com/clearlinux/distribution/issues\""
    path = "/etc/os-release"

# Generated at 2022-06-24 23:57:54.493437
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    dist = Distribution(AnsibleModule)
    dist.get_distribution_AIX()


# Generated at 2022-06-24 23:58:04.396477
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    parsed_facts = {}
    distribution_files = DistributionFiles()
    parsed_facts['distribution'] = 'Amazon'
    parsed_facts['distribution_version'] = '1.0'
    distribution_files.parse_distribution_file_Amazon('Amazon', '/etc/os-release',
                                                      parsed_facts)
    distribution_files.parse_distribution_file_Amazon('Amazon', '/etc/system-release',
                                                      parsed_facts)

if __name__ == '__main__':
    test_case_0()
    test_DistributionFiles_parse_distribution_file_Amazon()

# Generated at 2022-06-24 23:58:08.629815
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    dist = Distribution(module)
    dist_facts = dist.get_distribution_AIX()
    assert dist_facts['distribution_major_version'] in ['6', '7', '8']
    assert dist_facts['distribution_version'] in ['6.1', '7.1', '7.2', '8.1']


# Generated at 2022-06-24 23:58:14.855787
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():

    # test case 1
    data = get_distribution_HPUX()

    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '06'

    # test case 2
    data = get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'A.11.31'
    assert hpux_facts['distribution_release'] == '06'


# Generated at 2022-06-24 23:58:25.090478
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    facts_collected = {
        'distribution': 'NA',
        'distribution_major_version': 'NA',
        'distribution_version': 'NA',
        'distribution_release': 'NA',
        'distribution_file_path': 'NA',
        'distribution_file_variety': 'NA',
        'distribution_file_parsed': 'NA'
    }

    # openSUSE Leap 42.3
    dist_file_path = '/etc/os-release'
    with open(os.path.join(os.path.dirname(__file__), 'files', 'os-release-openSUSE.txt'), 'r') as f:
        os_release_content = f.read()

# Generated at 2022-06-24 23:58:37.750036
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distribution_fact_collector_0 = DistributionFactCollector()
    distribution_file_data = """
NAME="Mandriva Linux"
VERSION="2010.1 (Official) - Kernel 2.6.35.3-desktop-1mnb"
ID=mandriva
VERSION_ID=2010.1
CODENAME="Dyne"
PRETTY_NAME="Mandriva Linux 2010.1 (Official) - Kernel 2.6.35.3-desktop-1mnb (x86_64)"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:mandrakesoft:linux:2010.1:desktop:x86_64"
"""

# Generated at 2022-06-24 23:58:45.577148
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # HP-UX Output from module.run_command
    out_0 = 'HPUX_OEM_B.11.31.13102020\n'
    distribution_0 = Distribution()
    distribution_facts_0 = distribution_0.get_distribution_HPUX()
    rc_0 = 0
    out_1 = 'HPUX_OEM_B.11.31.13102020.13102020\n'
    distribution_1 = Distribution()
    distribution_facts_1 = distribution_1.get_distribution_HPUX()
    rc_1 = 0


# Generated at 2022-06-24 23:59:40.995197
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-24 23:59:43.737452
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    class_obj = Distribution(object)
    output = class_obj.get_distribution_Darwin()
    assert 'distribution' in output, 'method get_distribution_Darwin did not return key distribution'
    assert 'distribution_version' in output, 'method get_distribution_Darwin did not return key distribution_version'


# Generated at 2022-06-24 23:59:51.517478
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    module = basic.AnsibleModule(
            argument_spec = dict(),
            supports_check_mode = True
        )
    module.run_command = lambda x: (0, 'RELEASE', '')

    distr = Distribution(module=module)
    assert distr.get_distribution_FreeBSD() == {'distribution_release': 'RELEASE'}


# Generated at 2022-06-24 23:59:58.956679
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # test variables
    data = "ID=amzn\nNAME=\"Amazon Linux AMI\"\nVERSION=\"2018.03\"\nID_LIKE=\"rhel fedora\"\nVERSION_ID=\"2018.03\"\nPRETTY_NAME=\"Amazon Linux AMI 2018.03\"\nANSI_COLOR=\"0;33\"\nCPE_NAME=\"cpe:/o:amazon:linux:2018.03:ga\"\nHOME_URL=\"http://aws.amazon.com/amazon-linux-ami/\"\n"
    path = "/etc/os-release"
    name = "Amazon"

    # test code
    distribution_fact_collector = DistributionFactCollector()
    distribution_fact_collector_parse_distribution_file_Amazon(distribution_fact_collector, data, path, name)

# Unit test

# Generated at 2022-06-25 00:00:03.595218
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '10.12.2', '')
    distribution = Distribution(mock_module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.12.2'


# Generated at 2022-06-25 00:00:09.064867
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = MockModule()
    distribution_DragonFly = Distribution(module)

    data = {'platform': 'DragonFly', 'platform_release': 'v4.4.4-RELEASE'}
    monkeypatch_platform(data)
    result = distribution_DragonFly.get_distribution_DragonFly()
    assert result == {'distribution_release': 'v4.4.4-RELEASE'}

    data = {'platform': 'DragonFly', 'platform_version': 'v4.4.4-STABLE'}
    monkeypatch_platform(data)
    result = distribution_DragonFly.get_distribution_DragonFly()
    assert result == {'distribution_version': '4.4.4', 'distribution_major_version': '4'}


# Generated at 2022-06-25 00:00:10.617590
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_0 = Distribution(None)
    distribution_facts_0 = distribution_0.get_distribution_facts()
    # Test distribution_facts_0 and print the results if they fail



# Generated at 2022-06-25 00:00:16.127670
# Unit test for method get_distribution_SunOS of class Distribution

# Generated at 2022-06-25 00:00:27.132614
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_fact_collector_0 = DistributionFactCollector()
    name_0 = "Amazon"

# Generated at 2022-06-25 00:00:38.633201
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Given: arguments for method parse_distribution_file_Amazon
    name = "Amazon Linux AMI"
    data = "Amazon Linux AMI release 2013.03"
    path = "/etc/system-release"
    collected_facts = {'distribution': 'NA'}

    # When: method parse_distribution_file_Amazon is called
    distribution_files_0 = DistributionFiles()
    parsed_distribution_file_Amazon_facts = distribution_files_0.parse_distribution_file_Amazon(name, data, path, collected_facts)

    # Then: method parse_distribution_file_Amazon should return expected distribution facts
    parsed_distribution_file_Amazon_facts_expected = True, {'distribution': 'Amazon'}
    assert parsed_distribution_file_Amazon_facts == parsed_distribution_file_Amazon_facts

# Generated at 2022-06-25 00:01:43.197878
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock()
    module.run_command.side_effect = [('GROUP=alpha', '', 0)]

    data = {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    distribution_fact_collector_0 = DistributionFactCollector()

    distribution_fact_collector_0.parse_distribution_file_Flatcar('Flatcar', '', '/usr/share/oem/release', data)
    assert data['distribution_release'] == 'alpha'


# Generated at 2022-06-25 00:01:52.252850
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)

    rc, out, err = module.run_command("uname -r")

    # Test with DragonFlyBSD 4.8.1-RELEASE
    module.run_command = MagicMock(return_value=(0, "4.8.1-RELEASE", ""))
    distribution_facts = distribution.get_distribution_DragonFly()
    assert distribution_facts['distribution_major_version'] == '4'
    assert distribution_facts['distribution_version'] == '4.8.1'
    assert distribution_facts['distribution_release'] == 'RELEASE'

    # Test with DragonFlyBSD 4.2.3-STABLE

# Generated at 2022-06-25 00:01:59.912686
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    (new_module_obj, distribution_obj) = get_Distribution_obj()
    test_get_distribution_OpenBSD = distribution_obj.get_distribution_OpenBSD()
    assert 'distribution_release' in test_get_distribution_OpenBSD
    assert 'distribution_version' in test_get_distribution_OpenBSD


# Generated at 2022-06-25 00:02:05.719587
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    import platform

    platform.system.return_value = 'Darwin'
    distribution_fact_collector = DistributionFactCollector()
    assert 'MacOSX' == distribution_fact_collector._get_distribution_Darwin()


# Generated at 2022-06-25 00:02:12.318972
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-25 00:02:22.695548
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files_obj = DistributionFiles()
    name = 'SUSE'

    data_openSUSE = [
        "openSUSE 13.2 (Harlequin) (x86_64)",
        "VERSION = 13.2",
        "PRETTY_NAME = \"openSUSE 13.2 (Harlequin) (x86_64)\""
    ]
    data_SLES = [
        "SUSE Linux Enterprise Server 12",
        "VERSION = 12",
        "PATCHLEVEL = 2",
        "VERSION_ID = 12.2",
        "PRETTY_NAME = \"SUSE Linux Enterprise Server 12 SP2\""
    ]

# Generated at 2022-06-25 00:02:33.321303
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files = DistributionFiles()