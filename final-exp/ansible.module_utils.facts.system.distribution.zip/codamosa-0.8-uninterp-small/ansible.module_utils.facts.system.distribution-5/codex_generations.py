

# Generated at 2022-06-24 23:53:17.371703
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_file_fact_0 = DistributionFiles()
    name_0 = 'suse'
    data_0 = """
KDE_SU_VERSION=20120213-21.3
NAME="SLES"
VERSION="12-SP1"
VERSION_ID="12.1"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP1"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp1"
"""
    path_0 = '/etc/os-release'
    collected_facts_0 = {
        'lsb': {
            'distribution': 'SUSE Linux Enterprise Server',
            'distribution_release': '12.1',
            'distribution_version': '12'
        }
    }

    var_

# Generated at 2022-06-24 23:53:21.312007
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Arrange
    distribution_file_obj_0 = DistributionFiles()
    distribution_file_obj_0.dist_files_map = {'centos': ['/etc/centos-release']}

    # Act
    var_0, var_1 = distribution_file_obj_0.parse_distribution_file('centos', 'CentOS Linux release 8.1.1911')

    # Assert
    assert var_0 == False
    assert var_1 == {}


# Generated at 2022-06-24 23:53:32.848233
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module_0 = MagicMock()
    module_0.run_command.return_value = [
        0,
        """
                    SmartOS 16.4.1 20160613T133928Z i86pc i386 i86pc\n
                    OpenIndiana Development oi_151a8 (illumos 7f6b371)\n
                    OmniOS r151022 stable 20180213 omnios-151022-5f2d22a\n
                    NexentaOS_x86 5.11_4.4\n
                    """,
        ""
    ]

# Generated at 2022-06-24 23:53:44.763140
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_obj_0 = Distribution(module=1)
    sunos_facts = distribution_obj_0.get_distribution_SunOS()
#   Verify the type of sunos_facts is dict
    assert isinstance(sunos_facts, dict)
#   Verify keys in sunos_facts
    expected_keys = {'distribution', 'distribution_release', 'distribution_version', 'distribution_major_version'}
    assert sunos_facts and all(k in sunos_facts.keys() for k in expected_keys), "Function get_distribution_SunOS returned unexpected keys %r" % sunos_facts.keys()
#   Verify that the the value of sunos_facts['distribution'] is "SmartOS"

# Generated at 2022-06-24 23:53:51.445255
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():

    distribution_file_0 = DistributionFiles('/etc/os-release', 'clearlinux')
    var_0 = distribution_file_0.parse_distribution_file('clearlinux', 'NAME="Clear Linux"\nID=clear-linux-os\nVERSION_ID="30750"\nHOME_URL="https://clearlinux.org/"\nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues/new"')
    print("test_DistributionFiles_parse_distribution_file_ClearLinux result: " + str(var_0))



# Generated at 2022-06-24 23:53:57.917681
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files_0 = DistributionFiles()
    var_1 = distribution_files_0.parse_distribution_file_Flatcar("Flatcar", "GROUP=stable\n", "", {"distribution": "Flatcar", "distribution_release": "1412.10.0", "distribution_version": "NA"})



# Generated at 2022-06-24 23:54:03.332584
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # Imports
    # Declaration
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    distribution_0 = Distribution(
        module = module_0
    )
    # Setup
    # Call to get_distribution_HPUX
    hpux_facts_0 = distribution_0.get_distribution_HPUX()
    # Assertion
    assert hpux_facts_0 is not None


# Generated at 2022-06-24 23:54:13.114221
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    args = []

    command_output_0 = """
ProductName:	Mac OS X
ProductVersion:	10.14.6
BuildVersion:	18G103
"""
    stubs.set_command_outputs(command_output_0)

    # Call method
    method = DistributionFactCollector().get_distribution_Darwin
    defined_args = [ ]
    args = [ ]
    for arg in defined_args:
        args.append(eval(arg))
    retobj = method(*args)

    # Check for correct return type
    method = DistributionFactCollector().get_distribution_Darwin
    defined_args = [ ]
    args = [ ]
    for arg in defined_args:
        args.append(eval(arg))
    returnobj = method(*args)
    assert isinstance(returnobj, dict)

# Generated at 2022-06-24 23:54:23.871549
# Unit test for function get_uname
def test_get_uname():
    import ansible.module_utils.facts.system.distribution.test_data
    path = 'ansible/module_utils/facts/system/distribution/test_data/get_file_content_0.json'
    json_data = ansible.module_utils.facts.system.distribution.test_data.load_fixture(path)

    class AnsibleModule:
        def __init__(self):
            self.params = dict()
        def run_command(self, command):
            if command == ['uname', '-v']:
                return 0, "4.4.0-1041-aws", ''
            if command == ['uname', '-s']:
                return 0, "Linux", ''
            if command == ['uname', '-o']:
                return 0, "GNU/Linux", ''

# Generated at 2022-06-24 23:54:31.796465
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distro = DistributionFiles()
    distro_file = {'path': '/etc/os-release', 'data': 'NAME="OpenWrt"\nVERSION_ID="18.06"\nDISTRIB_CODENAME="stable"\nDISTRIB_TARGET="ramips/mt7621"\nDISTRIB_DESCRIPTION="OpenWrt 18.06"\nDISTRIB_RELEASE="18.06"\n'}
    collected_facts = {'distribution': 'NA', 'distribution_major_version': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    success, parsed_facts = distro.parse_distribution_file_OpenWrt(None, distro_file['data'], distro_file['path'], collected_facts)
    assert success

# Generated at 2022-06-24 23:55:20.187221
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():

    # Unit test for method get_distribution_NetBSD of class Distribution

    # From module ansible/module_utils/facts/system/distribution/aix.py
    def get_distribution_AIX():

        aix_facts = {}
        rc, out, err = self.module.run_command("/usr/bin/oslevel")
        data = out.split('.')
        aix_facts['distribution_major_version'] = data[0]
        if len(data) > 1:
            aix_facts['distribution_version'] = '%s.%s' % (data[0], data[1])
            aix_facts['distribution_release'] = data[1]
        else:
            aix_facts['distribution_version'] = data[0]
        return aix_facts

    #

# Generated at 2022-06-24 23:55:32.871933
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Given
    parsed_dist_files = DistributionFiles()

    # When
    name = 'Mandriva'
    data = 'NAME="Mandriva Linux"\nVERSION="2010.1"\nID=mdv\nVERSION_ID="2010.1"\nPRETTY_NAME="Mandriva Linux 2010.1"\nANSI_COLOR="1;31"\nCPE_NAME="cpe:/o:mandrivalinux:mandriva_linux:2010.1"\nHOME_URL="http://www.mandriva.com/"\nBUG_REPORT_URL="http://qa.mandriva.com/"'
    path = 'NA'
    collected_facts = {'distribution_major_version': 'NA'}
    parsed_dist_file_facts = 'NA'
    parsed_dist_file

# Generated at 2022-06-24 23:55:35.796879
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    (true, false) = (True, False)
    obj = DistributionFiles()
    result = obj.parse_distribution_file_Debian('name', 'data', 'path', 'collected_facts')
    print(str(result))


# Generated at 2022-06-24 23:55:42.682347
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    file_content_0 = 'dragonflybsd'
    file_content_1 = 'Gentoo/DragonflyBSD'
    file_content_2 = 'Gentoo/DragonFlyBSD'
    my_obj = Distribution()
    my_obj.module.get_file_content = MagicMock(side_effect=[file_content_0, file_content_1, file_content_2])
    my_obj.module.run_command = MagicMock(return_value=(2, '', ''))
    my_obj.get_distribution_DragonFly()


# Generated at 2022-06-24 23:55:46.832855
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Test with a string
    name = 'Mandriva'
    data = 'Mandriva Linux release 2014.0 (Cooker) for x86_64'
    path = 'test'
    collected_facts = {}
    x = DistributionFiles()
    result = x.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert 'distribution' in result[1]
    assert 'distribution_release' in result[1]


# Generated at 2022-06-24 23:55:56.823430
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # set up the mocks
    ansible_module = AnsibleModule(
        argument_spec = dict()
    )
    get_file_content_mock = MagicMock(side_effect = test_case_0)

    with patch.dict(Distribution.__dict__, {'get_file_content': get_file_content_mock}):
        # set up the class
        distribution = Distribution(ansible_module)

        # set up the return values
        rc0 = 0
        out0 = ()
        err0 = ()
        get_file_content_mock.return_value = out0

        # run the code to test
        return_value = distribution.get_distribution_Darwin()

        # make the assertions
        assert return_value == {}

# Generated at 2022-06-24 23:56:04.676350
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    print("Testing parse_distribution_file_NA")
    print("==============================")

    # TODO: Test error path with bad parameters

    distributionFiles = DistributionFiles(None)

    strFileName = 'ansible/module_utils/facts/system/distribution/test_data/parse_distribution_file_NA_0.txt'
    with open(strFileName) as file:
        strData = file.read()

    strResult = distributionFiles.parse_distribution_file_NA('NA', strData, '', {})

    print("Result: " + str(strResult))
    print("==============================")

    assert(strResult[0] == True)

    print("Result: " + str(strResult[1]))
    print("==============================")

    assert(strResult[1] != None)

   

# Generated at 2022-06-24 23:56:10.067463
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    obj_ = DistributionFiles()
    name_ = "Clear Linux"
    data_ = "NAME=\"Clear Linux for Intel Architecture\" VERSION_ID=31670 ID=clear-linux-os VERSION=\"31670 (Clear)"
    path_ = "/etc/os-release"
    collected_facts_ = DistributionFiles_collected_facts()
    return_0 = obj_.parse_distribution_file_ClearLinux(name_, data_, path_, collected_facts_)

    assert return_0[0] == True
    assert return_0[1] == "Clear Linux for Intel Architecture"
    assert return_0[2] == "NA"
    assert return_0[3] == "clear-linux-os"
    assert return_0[4] == "31670"
    assert return_0[5] == "31670"
   

# Generated at 2022-06-24 23:56:19.290254
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    instance = Distribution(module)

    with open(str_0) as f:
        mock_data = json.load(f)

    with patch.object(instance, 'get_distribution_DragonFly') as mock_get_distribution_DragonFly:

        mock_get_distribution_DragonFly.return_value = mock_data

        assertEqual(instance.get_distribution_DragonFly(), mock_data)

        mock_get_distribution_DragonFly.assert_called_once_with()


# Generated at 2022-06-24 23:56:28.177429
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    #
    # setup test data
    #
    str_0 = 'ansible/module_utils/facts/system/distribution/test_data/get_file_content_0.json'
    get_file_content_0 = json.loads(open(str_0).read())
    collected_facts_0 = {}
    collected_facts_0['distribution_release'] = 'NA'
    collected_facts_0['distribution_version'] = '2.99'
    #
    # test DistributionFiles.parse_distribution_file_SUSE with all inputs...
    #
    str_1 = 'ansible/module_utils/facts/system/distribution/test_data/parse_distribution_file_SUSE_1.json'

# Generated at 2022-06-24 23:56:54.556784
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_0 = Distribution()
    distribution_0.get_distribution_Darwin()


# Generated at 2022-06-24 23:56:56.619857
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    test_obj = Distribution(module)
    test_result = test_obj.get_distribution_OpenBSD()
    print('get_distribution_OpenBSD() result:')
    print(test_result)


# Generated at 2022-06-24 23:57:03.665481
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_file_facts = DistributionFiles().parse_distribution_file_Amazon("Amazon", "Amazon Linux AMI release 2016.03", "/etc/os-release", {})
    assert distribution_file_facts['distribution_version'] == '2016.03'
    assert distribution_file_facts['distribution_major_version'] == '2016'
    assert distribution_file_facts['distribution_minor_version'] == '03'

    distribution_file_facts = DistributionFiles().parse_distribution_file_Amazon("Amazon", "Amazon Linux (2016.03) LTS Release Candidate", "/etc/system-release", {})
    assert distribution_file_facts['distribution_version'] == '2016.03'
    assert distribution_file_facts['distribution_major_version'] == '2016'

# Generated at 2022-06-24 23:57:06.748037
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_instance_0 = Distribution()
    var_0 = distribution_instance_0.get_distribution_HPUX()


# Generated at 2022-06-24 23:57:17.676242
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_fact_collector = DistributionFactCollector()
    dist_file_path_1 = '/tmp/ansible_facts.d/ansible_distribution_file_OpenWrt.fact'
    dist_file_path_2 = '/tmp/ansible_facts.d/ansible_distribution_file_OpenWrt_2.fact'
    dist_file_path_3 = '/tmp/ansible_facts.d/ansible_distribution_file_OpenWrt_3.fact'
    test_input_1 = ('OpenWrt', 'OpenWrt', 'DISTRIB_RELEASE=12.09',
                    dist_file_path_1, {'distribution_release': 'NA', 'distribution_version': 'NA'},
                    )

# Generated at 2022-06-24 23:57:22.800742
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # setup test
    test_0 = Distribution(module=None)
    # test against expected output
    assert test_0.get_distribution_NetBSD() == {'distribution_version': '9.0', 'distribution_release': '9.0', 'distribution_major_version': '9'}


# Generated at 2022-06-24 23:57:30.330626
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_fact_collector_0 = DistributionFactCollector()
    test_str_0 = '''
    GROUP="stable"
    VERSION=1689.8.0
    ID=coreos
    '''
    expected_out_0 = {'distribution_release': 'stable'}
    assert distribution_fact_collector_0.parse_distribution_file_Coreos('CoreOS', test_str_0, '/etc/os-release', distribution_fact_collector_0.collected_facts) == (True, expected_out_0)


# Generated at 2022-06-24 23:57:39.924196
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    dist = Distribution(module=None)
    out = dist.get_distribution_AIX()
    if out['distribution_major_version'] == None:
        print("distribution_major_version: None")
    else:
        print("distribution_major_version: " + out['distribution_major_version'])
    if out['distribution_version'] == None:
        print("distribution_version: None")
    else:
        print("distribution_version: " + out['distribution_version'])


# Generated at 2022-06-24 23:57:46.458738
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    flatcar_facts = {}
    collected_facts = {
        'distribution_version': '2473.1.0',
        'distribution_file_variety': 'Flatcar',
        'distribution': 'Flatcar',
        'distribution_file_path': '/etc/coreos/update.conf',
        'distribution_major_version': '2473',
    }

    dist_file_path = '/etc/coreos/update.conf'
    data = 'GROUP=alpha'
    name = 'Flatcar'
    dist_files_0 = DistributionFiles()
    result_0 = dist_files_0.parse_distribution_file_Flatcar(name, data, dist_file_path, collected_facts)
    assert result_0 == (True, {'distribution_release': 'alpha'})

# Generated at 2022-06-24 23:57:53.955963
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    ansible_module = AnsibleModule(argument_spec={})
    os_distribution = Distribution(ansible_module)

    rc, out, err = os_distribution.module.run_command("/usr/bin/sw_vers -productVersion")

    if rc != 0:
        # if sw_vers is not present, return the value of platform.system()
        os_distribution_return_value = platform.system()
    else:
        os_distribution_return_value = out

    dist_return_val = os_distribution.get_distribution_Darwin()

    if dist_return_val['distribution'] == os_distribution_return_value:
        print("Correctly detected os as: " + os_distribution_return_value)

# Generated at 2022-06-24 23:58:45.891036
# Unit test for function get_uname
def test_get_uname():
    mock_module = MagicMock()
    output = get_uname(mock_module)
    assert output is None

    # Test path with expected output
    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=[0, 'Hello', ''])
    output = get_uname(mock_module)
    assert output == 'Hello'


# Generated at 2022-06-24 23:58:50.417563
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_files_0 = DistributionFiles()

    # OpenWrt
    distribution_files_0.parse_distribution_file_OpenWrt(
        "OpenWrt",
        "DISTRIB_ID=OpenWrt\n"
        "DISTRIB_RELEASE=12.09",
        "/etc/openwrt_release",
        {}
    )
    distribution_files_0.parse_distribution_file_OpenWrt(
        "OpenWrt",
        "DISTRIB_ID=OpenWrt\n"
        "DISTRIB_RELEASE=12.09\n"
        "DISTRIB_CODENAME=\"attitude_adjustment\"",
        "/etc/openwrt_release",
        {}
    )
    distribution_files_0.parse_distribution_file_OpenWrt

# Generated at 2022-06-24 23:58:56.242919
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    parsed_dist_file, parsed_dist_file_facts = DistributionFiles.parse_distribution_file_Slackware(
        name='Slackware',
        data='data',
        path='/etc/slackware-version',
        collected_facts={}
    )
    assert parsed_dist_file == True
    assert parsed_dist_file_facts == {
        'distribution': 'Slackware',
        'distribution_version': 'data'
    }


# Generated at 2022-06-24 23:59:00.708390
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    assert Distribution.get_distribution_facts() in ('Linux', 'MacOSX', 'AIX', 'HP-UX', 'FreeBSD', 'OpenBSD', 'SunOS', 'DragonFly', 'NetBSD', 'SMGL')


# Generated at 2022-06-24 23:59:04.391602
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_class = Distribution(module=None)
    var_0 = distribution_class.get_distribution_facts()


# Generated at 2022-06-24 23:59:10.281600
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():

    distribution_fact_collector_0 = DistributionFactCollector()
    distribution_fact_collector_0.file_contents = {'testing': ''}
    distribution_fact_collector_0.distribution_files = {'testing': 0}

    var_0 = distribution_fact_collector_0.parse_distribution_file_NA('NA', '', 'testing', {})
    print(var_0)


# Generated at 2022-06-24 23:59:16.602489
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # set up
    distribution_fact_collector = DistributionFactCollector()
    distribution_files_0 = DistributionFiles()

    # test
    distribution_files_0.parse_distribution_file_Flatcar("NAME=flatcar", "/run/os-release", "", "")
    # tear down


# Generated at 2022-06-24 23:59:25.400017
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    print("UnitTest for get_distribution_facts")
    distribution_0 = Distribution(module = None)

# Generated at 2022-06-24 23:59:27.093015
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_0 = Distribution(module)
    distribution_0.get_distribution_AIX()


# Generated at 2022-06-24 23:59:33.095484
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_fact_col = DistributionFactCollector()
    path = "/etc/slackware-version"
    name = "Slackware"
    data = "Slackware 14.2"
    collected_facts = {"distribution": "Slackware", "distribution_version": "14.2"}
    dist_fact_col.parse_distribution_file_Slackware(name, data, path, collected_facts)


# Generated at 2022-06-25 00:01:43.899048
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    data = "NAME=\"Sabayon\"\nID=\"sabayon\"\nPRETTY_NAME=\"Sabayon Linux 15.11\"\nVERSION_ID=\"15.11\"\nHOME_URL=\"http://www.sabayon.org/\"\nSUPPORT_URL=\"http://wiki.sabayon.org/\"\nBUG_REPORT_URL=\"https://github.com/Sabayon/spins/issues\"\nANSI_COLOR=\"0;31\"\nLOGO=distributor-logo\nCPE_NAME=\"cpe:/o:sabayon:linux:15.11\"\n"
    path = "/etc/os-release"
    name = "Sabayon"
    mandriva_facts = {}
    collected_facts = {}
    collected_facts['distribution']

# Generated at 2022-06-25 00:01:47.126056
# Unit test for method get_distribution_FreeBSD of class Distribution

# Generated at 2022-06-25 00:01:54.187018
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_file_0 = DistributionFiles()
    distribution_file_0.paths = None
    distribution_file_0.data = None

# Generated at 2022-06-25 00:02:00.050892
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distribution_files_0 = DistributionFiles()
    name_0 = " Slackware "
    data_0 = " \n\n # \n\n NAME = Slackware\nVERSION = 14.1\nID = slackware\nID_LIKE = slackware-14.0\nVERSION_ID = 14.1\nPRETTY_NAME = Slackware 14.1\nANSI_COLOR = \"0;34\"\nHOME_URL = \"http://www.slackware.com/\"\nSUPPORT_URL = \"http://www.slackware.com/support/\"\nBUG_REPORT_URL = \"http://www.slackware.com/support/\"\n"
    path_0 = "/etc/os-release"

# Generated at 2022-06-25 00:02:02.477881
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_0 = Distribution(None)
    var_0 = distribution_0.get_distribution_HPUX()


# Generated at 2022-06-25 00:02:10.411268
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles

# Generated at 2022-06-25 00:02:13.823445
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_files = DistributionFiles()
    dist_files_content = ""
    path = ""
    collected_facts = {}
    assert dist_files.parse_distribution_file_Slackware(dist_files_content, path, collected_facts) == ("", {})


# Generated at 2022-06-25 00:02:17.584763
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    os_facts_0 = Distribution({'ANSIBLE_MODULE_ARGS': {}})
    os_facts_0.get_distribution_NetBSD()


# Generated at 2022-06-25 00:02:26.141236
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files_0 = DistributionFiles()
    var_0 = "Amazon"
    var_1 = 'NAME="Amazon Linux AMI"\nVERSION="2019.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2019.03"\nPRETTY_NAME="Amazon Linux AMI 2019.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2019.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n\nAmazon Linux AMI release 2019.03\n'
    var_2 = "/etc/system-release"

# Generated at 2022-06-25 00:02:32.497970
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_fact_collector = DistributionFactCollector()
    distfile = DistributionFiles(distribution_fact_collector)
    # Test the method parse_distribution_file_CentOS of class DistributionFiles
    var = distfile.parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/centos-release', {})
    # Test the method parse_distribution_file_CentOS of class DistributionFiles
    var = distfile.parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/redhat-release', {})
    # Test the method parse_distribution_file_CentOS of class DistributionFiles
    var = distfile.parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
