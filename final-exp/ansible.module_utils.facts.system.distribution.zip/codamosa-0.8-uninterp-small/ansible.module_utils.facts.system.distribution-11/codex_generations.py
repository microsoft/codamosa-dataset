

# Generated at 2022-06-24 23:53:30.551831
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    file_facts = {'distribution': 'NA',
                  'distribution_file_path': 'NA'}
    collected_facts = {'ansible_lsb': {'codename': 'xenial',
                                       'distid': 'Ubuntu',
                                       'description': 'Ubuntu 16.04.6 LTS',
                                       'major_release': '16',
                                       'release': '16.04'},
                       'ansible_pkg_mgr': 'apt',
                       'distribution': 'Ubuntu',
                       'distribution_file_path': 'NA',
                       'distribution_file_variety': 'Ubuntu',
                       'distribution_release': 'xenial',
                       'distribution_version': '16.04'}
    dist_files = DistributionFiles(None)
    dist_file_facts

# Generated at 2022-06-24 23:53:32.984575
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = '__adhoc_playbook__'
    distribution_0 = DistributionFiles(str_0)
    # nothing to assert here, just make sure it doesn't crash
    distribution_0.parse_distribution_file_ClearLinux('blah', 'blah', 'blah', 'blah')


# Generated at 2022-06-24 23:53:38.268463
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    str_0 = '__adhoc_playbook__'
    distribution_0 = Distribution(str_1)
    str_1 = '__adhoc_playbook__'
    distribution_0 = Distribution(str_1)
    var_1 = distribution_0.get_distribution_SunOS()


# Generated at 2022-06-24 23:53:48.644016
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    s = 'OpenWrt\n'
    name = 'OpenWrt'

# Generated at 2022-06-24 23:53:53.263573
# Unit test for function get_uname
def test_get_uname():
    test_uname = 'Linux'
    module_0 = mock.MagicMock()
    output_0 = get_uname(module_0, test_uname)
    assert output_0 == True


# Generated at 2022-06-24 23:53:57.917565
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    str_0 = '__adhoc_playbook__'
    distribution_0 = Distribution(str_0)
    var_0 = distribution_0.get_distribution_DragonFly()


# Generated at 2022-06-24 23:54:05.097556
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    str_0 = '__adhoc_playbook__'
    distribution_0 = Distribution(str_0)
    str_1 = 'flatcar'
    str_2 = '__adhoc_playbook__'
    str_3 = '__adhoc_playbook__'
    str_4 = '__adhoc_playbook__'
    collected_facts_0 = collected_facts()
    bo_0, var_0 = distribution_0.DistributionFiles.parse_distribution_file_Flatcar(str_1, str_2, str_3, collected_facts_0)
    assert bo_0
    assert var_0


# Generated at 2022-06-24 23:54:13.471447
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = '__adhoc_playbook__'
    distribution_0 = DistributionFiles(str_0)
    assert ((distribution_0.parse_distribution_file_Mandriva('Mandriva', 'Linux 2.6.32-5-amd64 (Debian-5.5.34+lenny5) 2013-06-24 09:45 x86_64 GNU/Linux\n', '', ''))[0] == False)
    assert ((distribution_0.parse_distribution_file_Mandriva('Mandriva', 'Distribution   : Mandriva Linux 2010.1\n', '', ''))[0] == True)


# Generated at 2022-06-24 23:54:14.812803
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distribution = Distribution('__adhoc_playbook__')
    distribution_DragonFly_facts = distribution.get_distribution_DragonFly()


# Generated at 2022-06-24 23:54:21.224676
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Test setup
    # Test of method get_distribution_Darwin in class Distribution
    distribution_Darwin_0 = Distribution('__adhoc_playbook__')

    # Test setup
    data_0 = 'NAME="Amazon Linux AMI" VERSION="2018.03" ID="amzn" ID_LIKE="rhel fedora" ' \
             'VERSION_ID="2018.03" PRETTY_NAME="Amazon Linux AMI 2018.03" ANSI_COLOR="0;33" ' \
             'CPE_NAME="cpe:/o:amazon:linux:2018.03:ga" HOME_URL="http://aws.amazon.com/amazon-linux-ami/" ' \
             'Amazon Linux release 2018.03'
    path_0 = '/etc/system-release'
    collected_facts_0 = {}
    distribution_files_

# Generated at 2022-06-24 23:55:17.921604
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_1 = 'Linux'
    str_2 = 'Mandriva Linux release 2010.0 (Official) for x86_64'
    str_3 = 'DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2013.0\nDISTRIB_CODENAME=Adelie\nDISTRIB_DESCRIPTION="Mandriva Linux release 2013.0 (Adelie)"'
    str_4 = '_collect_distribution_files: Trying to parse /etc/20130506-update-issue.txt'
    str_5 = '_collect_distribution_files: Trying to parse /etc/SuSE-release'
    str_6 = '_collect_distribution_files: Trying to parse /etc/SuSE-brand'

# Generated at 2022-06-24 23:55:24.403950
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution = Distribution(module = None)
    distribution.module = mock.MagicMock()
    distribution.module.run_command.return_value = 0, 'NetBSD', ''
    platform.release.return_value = ''


    # Call method
    expected_result = {}
    expected_result['distribution_release'] = ''
    expected_result['distribution_major_version'] = '6'
    expected_result['distribution_version'] = '6.99.1'

    actual_result = distribution.get_distribution_NetBSD()

    # Verify calls
    distribution.module.run_command.assert_has_calls([call("/sbin/sysctl -n kern.version")])
    assert expected_result == actual_result


# Generated at 2022-06-24 23:55:25.787277
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    assert_equal(Distribution.get_distribution_OpenBSD(str_0), expectValue_0)
    raise Exception('Test Failed')

test_case_0()

# Generated at 2022-06-24 23:55:28.436765
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():

    fact_T_0 = Distribution(module='test')
    fact_T_0.get_distribution_FreeBSD()

    assert True, fact_T_0


# Generated at 2022-06-24 23:55:40.508213
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    obj = DistributionFiles()
    # Slackware
    name = 'Slackware'
    data = '_s390_\nSlackware 14.1\n'
    path = 'path'
    collected_facts = {'lsb': {'distributor_id': 'Slackware', 'codename': '14.1', 'description': 'Slackware 14.1', 'release': '14.1'}, 'distribution_version': '14.1', 'distribution': 'Slackware', 'distribution_release': '14.1', 'lsb_distrib_release': '14.1', 'lsb_distrib_id': 'Slackware'}
    testobj = (obj,name,data,path,collected_facts)

# Generated at 2022-06-24 23:55:49.904624
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    obj = DistributionFiles()
    name = 'Clear Linux'

# Generated at 2022-06-24 23:55:54.346236
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    collected_facts_0 = {
        'distribution_release':
        'NA',
        'distribution':
        'NA',
        'distribution_version':
        'NA',
        'distribution_file_parsed':
        False}

    dist_file_0 = DistributionFiles()
    dist_file_0.parse_distribution_file_CentOS('CentOS', str_0, path_0,
                                               collected_facts_0)


# Generated at 2022-06-24 23:56:03.381029
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    # Assert objects
    facts = elif_0()
    distribution = Distribution(facts)
    distribution.module = Module()
    distribution.module.run_command = MagicMock(return_value=(0, 'FreeBSD 9.3-RELEASE-p16', ''))

    result = distribution.get_distribution_FreeBSD()

    assert result['distribution_release'] == '9.3-RELEASE-p16'
    assert result['distribution'] == 'FreeBSD'

# Generated at 2022-06-24 23:56:04.203365
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    pass


# Generated at 2022-06-24 23:56:07.518240
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    system = Distribution.get_distribution_HPUX()


# Generated at 2022-06-24 23:57:12.615490
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Example from test/integration/targets/centos7.0-3.2.38_1.el7.x86_64
    collected_facts = {
        'distribution_release': 'NA',
        'distribution_version': '7.0.1406',
        'distribution_major_version': '7',
        'distribution_file_parsed': False,
        'distribution_file_path': '/etc/centos-release',
        'distribution_file_variety': 'CentOS',
        'distribution_file_id': 'centos-release',
        'distribution': 'CentOS',
        'os_family': 'RedHat',
        'systemd': True,
    }
    distribution_files_0 = DistributionFiles(False)

# Generated at 2022-06-24 23:57:17.019150
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_0 = Distribution(bool_0)
    var_0 = distribution_0.get_distribution_AIX()
    assert var_0 == {'distribution_version': '7.2', 'distribution_major_version': '7'}


# Generated at 2022-06-24 23:57:24.043333
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # Test case with only required args
    distribution_files_0 = DistributionFiles(True)
    name_0 = 'Slackware'
    data_0 = 'Slackware 12.1.0'
    path_0 = '/etc/slackware-release'
    collected_facts_0 = {}
    # Test case with the bare minimum of facts for this file
    # This is really the expected distribution_files-Suse.txt file
    parsed_dist_file_facts_0 = {'distribution': 'Slackware', 'distribution_version': '12.1.0'}
    return distribution_files_0.parse_distribution_file_Slackware(name_0, data_0, path_0, collected_facts_0) == (True, parsed_dist_file_facts_0)


# Generated at 2022-06-24 23:57:25.689049
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    Distribution_0 = Distribution(bool(), bool())
    var_0 = Distribution_0.get_distribution_HPUX()
    return var_0

test()

# Generated at 2022-06-24 23:57:28.614353
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    dist_0 = Distribution()
    dist_0.module = None
    bool_0 = None
    var_0 = dist_0.get_distribution_HPUX(bool_0)


# Generated at 2022-06-24 23:57:33.170162
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    assert DistributionFiles.parse_distribution_file_ClearLinux("clearlinux", "NAME='Clear Linux OS'", "/etc/os-release", None) == (True, {'distribution': "Clear Linux OS", 'distribution_major_version': '29160', 'distribution_version': '29160'})
    assert DistributionFiles.parse_distribution_file_ClearLinux("clearlinux", None, None, None) == (False, {})
    assert DistributionFiles.parse_distribution_file_ClearLinux("clearlinux", "NAME='Fedora CoreOS'", None, None) == (False, {})
    assert DistributionFiles.parse_distribution_file_ClearLinux("clearlinux", "NAME=''", None, None) == (False, {})


# Generated at 2022-06-24 23:57:43.872215
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Method instance creation
    str_0 = "NA"
    str_1 = ""
    str_2 = "/etc/os-release"
    dict_0 = {}
    bool_0 = False
    distribution_files_0 = DistributionFiles(bool_0)
    # type assertions
    assert isinstance(distribution_files_0, DistributionFiles)
    assert isinstance(str_0, str)
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)
    assert isinstance(dict_0, dict)
    assert isinstance(bool_0, bool)
    # Method invocation
    tuple_0 = distribution_files_0.parse_distribution_file_Debian(str_0, str_1, str_2, dict_0)
    # type assertions

# Generated at 2022-06-24 23:57:49.193693
# Unit test for function get_uname
def test_get_uname():
    module = AnsibleModule(argument_spec=dict())
    flags = (True)
    expected = True
    actual = get_uname(module, flags)
    assert actual == expected


# Generated at 2022-06-24 23:57:53.629858
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    Distribution_0 = Distribution(bool_0)
    var_0 = Distribution_0.get_distribution_HPUX()


# Generated at 2022-06-24 23:57:55.668749
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    dist = Distribution(None)
    dist.get_distribution_AIX()


# Generated at 2022-06-24 23:58:55.007778
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_0 = Distribution("", "")
    var_0 = distribution_0.get_distribution_OpenBSD()


# Generated at 2022-06-24 23:58:59.963799
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files_1 = DistributionFiles()

    # Testing for case 0
    # FIXME: this test needs to be rewritten, it depends on non-deterministic things like os.stat
    #test_case_0()

    # Testing for case 1
    distribution_files_1 = DistributionFiles()
    str_0 = 'CoreOS'
    str_1 = 'CentOS'
    str_2 = 'GROUP=stable'
    str_3 = '/usr/share/coreos/release'

# Generated at 2022-06-24 23:59:11.022731
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    collected_facts = {'distribution_version': 'NA', 'distribution': 'CentOS', 'distribution_release': 'NA'}
    name = "clearlinux"
    data = """
    NAME="Clear Linux"
    VERSION_ID=29660
    VERSION="29660 (Intel Skylake)"
    ID=clear
    ID_LIKE=fedora
    PRETTY_NAME="Clear Linux 29660 (Intel Skylake)"
    CPE_NAME="cpe:/o:clearlinux:clear:29660"
    HOME_URL="https://clearlinux.org/"
    """
    path = "/etc/os-release"
    dist_file_facts = DistributionFiles(collected_facts).parse_distribution_file_ClearLinux(name, data, path, collected_facts)

# Generated at 2022-06-24 23:59:18.107288
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    rc_0, out_0, err_0 = module.run_command("/usr/bin/oslevel")
    data_0 = out_0.split('.')
    aix_facts_0 = {}
    aix_facts_0['distribution_major_version'] = data_0[0]
    if (len( data_0 ) > 1 ) :
        aix_facts_0['distribution_version'] = '%s.%s' % (data_0[0], data_0[1])
        aix_facts_0['distribution_release'] = data_0[1]
    else:
        aix_facts_0['distribution_version'] = data_0[0]
    bool_0 = isinstance( aix_facts_0, dict )
    assert bool_0 == True

# Generated at 2022-06-24 23:59:24.941759
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    bool_0 = False
    distribution_files_0 = DistributionFiles(bool_0)
    var_0 = distribution_files_0.parse_distribution_file_Flatcar('/usr/lib/os-release', 'CoreOS_311.0.0_azure_vmware.vmdk.bz2')
    var_0 = distribution_files_0.parse_distribution_file_Flatcar('/usr/lib/os-release', 'CoreOS_313.0.0_azure_vmware.vmdk.bz2')
    var_0 = distribution_files_0.parse_distribution_file_Flatcar('Linux_3.16.0-4-amd64', 'Linux_3.16.0-4-amd64')
    var_0 = distribution_files_0.parse_distribution

# Generated at 2022-06-24 23:59:26.381636
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    obj = Distribution()

    test_distribution_Darwin = obj.get_distribution_Darwin()


# Generated at 2022-06-24 23:59:35.005697
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():

    # Example from get_distribution_info.py
    x = DistributionFiles(False)

    # sample from os-release
    os_release_str = 'NAME="Mandriva Linux"\nVERSION="2010.1 (Official) - Spring"\nID=mandriva\nVERSION_ID=2010.1\nPRETTY_NAME="Mandriva Linux 2010.1 (Official) - Spring"\nANSI_COLOR="1;31"\nCPE_NAME="cpe:/o:mandriva:linux:2010.1:spring"'
    mandriva = x.parse_distribution_file_Mandriva('Mandriva', os_release_str, '/etc/os-release', {})

# Generated at 2022-06-24 23:59:39.211424
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    bool_0 = False
    distribution_files_0 = DistributionFiles(bool_0)
    var_0 = "Linux Mint 1.0"
    var_1 = " Linux Mint 1.0 "
    var_2 = DistributionFiles.parse_distribution_file_NA(distribution_files_0, var_0, var_0, var_1, var_1)
    output = {"distribution": "Linux Mint", "distribution_version": "1.0"}
    assert var_2 == (True, output)

test_case_0()
test_DistributionFiles_parse_distribution_file_NA()

# Generated at 2022-06-24 23:59:40.468598
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # Initializing the test values
    ds = Distribution(module)
    result = ds.get_distribution_HPUX()
    assert True == bool(result)


# Generated at 2022-06-24 23:59:42.024568
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_0 = Distribution({})
    # Test the zero argument edge case
    var_0 = distribution_0.get_distribution_facts()

test_case_0()

# Generated at 2022-06-25 00:00:53.436237
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module_0 = Distribution(None)
    var_0 = module_0.get_distribution_Darwin()


# Generated at 2022-06-25 00:01:01.577923
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files_0 = DistributionFiles(True)
    name_0 = 'SUSE'
    data_0 = 'SuSE Linux 11.1 (i586) VERSION = 11.1 CODENAME = Celadon'
    path_0 = '/etc/SuSE-release'
    collected_facts_0 = {'distribution': 'SUSE', 'distribution_version': '11.1', 'distribution_release': 'NA'}
    tuple_0 = distribution_files_0.parse_distribution_file_SUSE(name_0, data_0, path_0, collected_facts_0)
    print(tuple_0)


# Generated at 2022-06-25 00:01:09.651338
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    bool_0 = False
    distribution_files_0 = DistributionFiles(bool_0)

    # Test case 1
    data_1 = '''NAME="Amazon Linux AMI"
VERSION="2018.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2018.03"
PRETTY_NAME="Amazon Linux AMI 2018.03"
ANSI_COLOR="0;33"
CPE_NAME="cpe:/o:amazon:linux:2018.03:ga"
HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
'''
    path_1 = '/etc/os-release'
    collected_facts_1 = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    bool_1, dictionary_0 = DistributionFiles.parse_

# Generated at 2022-06-25 00:01:20.365939
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    bool_0 = False
    distribution_files_0 = DistributionFiles(bool_0)

    arg_0 = 'Amazon'
    arg_1 = 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    arg_2 = '/etc/os-release'
    arg_3 = {}

# Generated at 2022-06-25 00:01:25.628517
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    sunos_facts_test = {}
    # get_distribution_SunOS() has no return statement.
    sunos_facts_test['distribution'] = "Solaris"
    sunos_facts_test['distribution_version'] = "11"
    sunos_facts_test['distribution_major_version'] = "11"
    sunos_facts_test['distribution_release'] = "Oracle Solaris 11.4"
    return sunos_facts_test
    

# Generated at 2022-06-25 00:01:29.850342
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # Setup
    distribution_0 = Distribution(None)

    # Assignments
    distribution_major_version_0 = distribution_0.get_distribution_NetBSD()['distribution_major_version']

    # Testing
    assert distribution_major_version_0 == None


# Generated at 2022-06-25 00:01:30.806947
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    var_0 = Distribution(None)
    var_0.get_distribution_AIX()


# Generated at 2022-06-25 00:01:31.916302
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Test code should go here
    pass


# Generated at 2022-06-25 00:01:37.877014
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    bool_0 = False
    name_0 = 'Debian'
    data_0 = 'Debian 10 (buster)'
    path_0 = '/etc/os-release'
    collected_facts_0 = {'distribution_release': 'NA'}
    distribution_files_0 = DistributionFiles(bool_0)
    var_0 = distribution_files_0.parse_distribution_file_Debian(name_0, data_0, path_0, collected_facts_0)


# Generated at 2022-06-25 00:01:47.542831
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_0 = Distribution()
    distribution_00 = distribution_0.get_distribution_OpenBSD()
    if isinstance(distribution_00, object):
        var_0 = distribution_00.__class__.__name__
    else:
        var_0 = type(distribution_00)
    if var_0 != 'dict':
        exit(1)
    openbsd_facts_0 = distribution_0.get_distribution_OpenBSD()
    if openbsd_facts_0['distribution_version'] != '6.7':
        exit(1)
    openbsd_facts_1 = distribution_0.get_distribution_OpenBSD()
    if openbsd_facts_1['distribution_release'] != 'release':
        exit(1)


# Generated at 2022-06-25 00:02:20.729496
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_0 = Distribution(bool_0)
    facts_0 = distribution_0.get_distribution_HPUX()
    assert isinstance(facts_0, dict)


# Generated at 2022-06-25 00:02:28.626104
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    yaml_provisioner_file_name_0 = "yaml_provisioner_test_0.yaml"
    _bool_0 = False
    _distribution_files_0 = DistributionFiles(_bool_0)
    _val_0 = 'test_val_0'
    _distribution_file_name_0 = 'Coreos'
    _path_0 = 'test_path_0'
    _collected_facts_0 = 'test_collected_facts_0'
    _facts_0 = 'test_facts_0'
    _dict_0 = 'test_dict_0'
    _facts_1 = 'test_facts_1'
    _dict_1 = 'test_dict_1'
    _facts_2 = 'test_facts_2'