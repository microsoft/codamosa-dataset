

# Generated at 2022-06-24 23:53:16.745658
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_AIX = Distribution(object)

    # Get the distribution_AIX of the Distribution class
    distribution_AIX_facts = distribution_AIX.get_distribution_AIX()

    # Check if it is dictionary
    assert type(distribution_AIX_facts).__name__ == 'dict'


# Generated at 2022-06-24 23:53:22.423979
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():

    str_0 = 'F='
    distribution_0 = Distribution(str_0)

    # Call the method.
    distribution_facts_0 = distribution_0.get_distribution_facts()
    print(distribution_facts_0)


# Generated at 2022-06-24 23:53:32.942785
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    if sys.version_info[0] < 3:
        print('python version must be greater than 3')
        return


# Generated at 2022-06-24 23:53:42.757854
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    str_1 = 'NetBSD 6.99.45 (GENERIC) #0: Thu Sep 29 08:49:07 UTC 2016'
    distribution_1 = Distribution(object)
    distribution_1.module.run_command = lambda *args, **kwargs: (0, str_1, '')
    expected_1 = {'distribution_major_version': '6', 'distribution_version': '6.99', 'distribution_release': '6.99.45-RELEASE'}
    actual_1 = distribution_1.get_distribution_NetBSD()
    assert actual_1 == expected_1


# Generated at 2022-06-24 23:53:44.528768
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_facts_0 = Distribution(module).get_distribution_facts()


# Generated at 2022-06-24 23:53:49.386711
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'F='
    distribution_fact_collector_0 = DistributionFactCollector(str_0)
    str_1 = 'F='
    str_2 = 'F='
    str_3 = 'F='
    str_4 = 'F='
    str_5 = 'Mandriva Linux release 2010.2 (Official) for i586'
    boolean_1 = distribution_fact_collector_0.parse_distribution_file_Mandriva(str_1, str_2, str_3, str_4, str_5)
    assert True and boolean_1


# Generated at 2022-06-24 23:53:58.320413
# Unit test for function get_uname
def test_get_uname():
    str_1 = 'F='
    distribution_fact_collector_1 = DistributionFactCollector(str_1)
    str_2 = '-v'
    test_get_uname_0 = get_uname(distribution_fact_collector_1, str_2)
    str_3 = '0'
    str_4 = 'F='
    distribution_fact_collector_2 = DistributionFactCollector(str_4)
    str_5 = '-v'
    str_6 = '-v'
    test_get_uname_1 = get_uname(distribution_fact_collector_2, str_5, str_6)
    str_7 = '0'
    str_8 = 'F='
    distribution_fact_collector_3 = DistributionFactCollector(str_8)


# Generated at 2022-06-24 23:54:03.736007
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distribution = Distribution(None)
    distribution.module = None
    distribution.module.run_command = None
    distribution.module.run_command = lambda x: (0, 'v4.8.1-RELEASE', '')
    result = distribution.get_distribution_DragonFly()
    assert result == {'distribution_release': 'release', 'distribution_major_version': '4', 'distribution_version': '4.8.1'}



# Generated at 2022-06-24 23:54:07.589735
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():

    distribution_0 = Distribution(module=None)
    assert callable(getattr(distribution_0, "get_distribution_facts", None)) == True
    distribution_facts_0 = distribution_0.get_distribution_facts()

    assert distribution_facts_0['distribution'] == 'Linux'


# Generated at 2022-06-24 23:54:15.034559
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # Make sure module is not broken
    assert(test_case_0() != 1)
    # Make sure that check of distribution file is correct
    assert(True == DistributionFactCollector('CoreOS').parse_distribution_file_Flatcar('CoreOS', "", '', {})[0])
    assert(True == DistributionFactCollector('flatcar').parse_distribution_file_Flatcar('flatcar', "", '', {})[0])
    # Make sure that wrong distro file returns False
    assert(False == DistributionFactCollector('CoreOS').parse_distribution_file_Flatcar('CentOS', "", '', {})[0])


# Generated at 2022-06-24 23:54:58.560415
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    str_0 = 'x'
    path_0 = 'F'
    data_0 = 'y'
    collected_facts_0 = {'distribution': 'PC-BSD', 'distribution_release': '10.2-RELEASE', 'distribution_version': '10.2', 'distribution_major_version': '10'}
    name_0 = 'a'
    flatcar_facts_0 = {'distribution_release': '10.2-RELEASE', 'distribution': 'PC-BSD', 'distribution_version': '10.2', 'distribution_major_version': '10'}
    flatcar_facts_0_out = DistributionFiles(str_0).parse_distribution_file_Flatcar(name_0, data_0, path_0, collected_facts_0)
    assert flatcar_

# Generated at 2022-06-24 23:55:00.471947
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    dist = Distribution(None)
    dist.get_distribution_NetBSD()


# Generated at 2022-06-24 23:55:10.444791
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'a'
    str_1 = 'V'
    str_2 = 'u'
    str_3 = 'M'
    str_4 = 'r'
    distribution_files_0 = DistributionFiles(str_0, str_1, str_2)
    distribution_files_0.dist_files = [{'name':'Mandr', 'path':'/etc', 'data':'Mandriva'}]
    distribution_files_0.collected_facts['distribution_release'] = 'NA'
    str_5 = ''
    distribution_files_0.collected_facts['distribution_version'] = str_5
    bool_0 = distribution_files_0.parse_distribution_file_Mandriva(str_3, str_4)
    assert bool_0 == True
    str_6

# Generated at 2022-06-24 23:55:13.417560
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    str_0 = 'F='
    distribution_fact_collector_0 = DistributionFactCollector(str_0)

    aix_facts_0 = distribution_fact_collector_0.get_distribution_AIX()



# Generated at 2022-06-24 23:55:22.121041
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = 'CentOS release 6.10 (Final)\nCentOS Linux release 7.6.1810 (Core)\nCentOS Linux release 8.0.1905 (Core)\nCentOS-8 - AppStream - 20200121\nCentOS-8 - Base - 20200121\nCentOS-8 - Extras - 20200121\nCentOS-8 - PowerTools - 20200121\nCentOS-7 - AppStream - 20200031\nCentOS-7 - Base - 20200031\nCentOS-7 - Extras - 20200031\nCentOS-7 - PowerTools - 20200031\n'
    distribution_fact_collector_0 = DistributionFactCollector(str_0)

    # User defined function called from DistributionFiles._parse_distribution_file_ClearLinux()
    # Input: str
    # Output: str


# Generated at 2022-06-24 23:55:33.070423
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    str_0 = 'OpenIndiana Hipster'
    str_1 = 'SmartOS 20180213T181203Z'
    str_2 = 'OmniOS r151007'
    str_3 = 'NexentaOS_1234 v4.0.0'

    distribution_0 = Distribution(None)
    distribution_0.get_distribution_SunOS()

    distribution_1 = Distribution(None)
    distribution_1.get_distribution_SunOS()

    distribution_2 = Distribution(None)
    distribution_2.get_distribution_SunOS()

    distribution_3 = Distribution(None)
    distribution_3.get_distribution_SunOS()


# Generated at 2022-06-24 23:55:44.226699
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    global distro_file_facts
    test_str_0 = 'DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=15.05.1\nDISTRIB_REVISION=\nDISTRIB_CODENAME=chaos_calmer\nDISTRIB_TARGET=ar71xx/generic\nDISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"\nDISTRIB_TAINTS=\n'
    test_data_0 = test_str_0
    test_name_0 = 'OpenWrt'
    test_path_0 = 'this/is/a/path'
    test_collected_facts_0 = {'distribution_version': 'NA', 'distribution_release': 'NA'}

# Generated at 2022-06-24 23:55:55.281947
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_files_0 = DistributionFiles('str_0')
    dict_0 = {'name': 'Clear Linux', 'data': 'NAME="Clear Linux"', 'path': 'str_1'}
    distribution_files_0.parse_distribution_file_ClearLinux(dict_0)
    dict_1 = {'name': 'clearlinux', 'data': 'NAME="Clear Linux"', 'path': 'str_1'}
    distribution_files_0.parse_distribution_file_ClearLinux(dict_1)
    dict_2 = {'name': 'clearlinux', 'data': 'NAME="CLeaR Linux"', 'path': 'str_1'}
    distribution_files_0.parse_distribution_file_ClearLinux(dict_2)


# Generated at 2022-06-24 23:56:04.774157
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    str_0 = 'F='
    distribution_fact_collector_0 = DistributionFactCollector(str_0)


if __name__ == "__main__":
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-case', action='append', type=int)
    args = parser.parse_args(sys.argv[1:])
    if args.test_case is not None:
        for n in args.test_case:
            eval(f'test_case_{n}()')
    else:
        for n in range(10):
            eval(f'test_case_{n}()')

# Generated at 2022-06-24 23:56:06.085132
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distribution_0 = Distribution(str_0)
    distribution_0.get_distribution_DragonFly()


# Generated at 2022-06-24 23:56:35.302588
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    NetBSD_facts = {
        'distribution': 'NetBSD',
        'distribution_major_version': '6',
        'distribution_release': '6.1.5',
        'distribution_version': '6.1'}
    dist_instance = Distribution(module)
    module.run_command = mock.Mock()
    module.run_command.side_effect = [
        (0, 'NetBSD 6.1.5 (GENERIC) #0: Fri Nov 22 04:14:53 UTC 2013  mkrepro@mkrepro.NetBSD.org:/usr/src/sys/arch/amd64/compile/GENERIC', ''),
        (0, '6.1', '')]
    assert NetBSD_facts == dist_instance.get_distribution_NetBSD()


# Generated at 2022-06-24 23:56:41.405566
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    str_0 = 'F='
    distribution_fact_collector_0 = DistributionFactCollector(str_0)
    distribution_fact_collector_0.facts['distribution'] = 'CoreOS'
    distribution_fact_collector_0.facts['distribution_release'] = '1235.12.0'
    str_1 = 'GROUP=Short Lived Branch'
    str_2 = 'group=Short Lived Branch'
    bool_0, dict_0 = distribution_fact_collector_0.parse_distribution_file_Coreos('',str_1,'system-release',distribution_fact_collector_0.facts)
    # AssertionError: False != True : False != True

# Generated at 2022-06-24 23:56:52.877097
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = 'F='
    distribution_fact_collector_0 = DistributionFactCollector(str_0)
    str_1 = 'NAME="Clear Linux OS"\nID=clearlinux\nVERSION_ID=31000\nVERSION="31000"'
    str_2 = 'clearlinux'
    str_3 = 'test_path'
    str_4 = ''
    boolean_0, boolean_1, boolean_2, boolean_3, boolean_4, boolean_5, boolean_6, boolean_7, boolean_8, boolean_9, boolean_10, boolean_11, boolean_12, boolean_13, boolean_14, boolean_15, boolean_16, boolean_17, boolean_18, boolean_19, boolean_20, boolean_21, boolean_22, boolean_23, boolean_24, boolean_25, boolean_26

# Generated at 2022-06-24 23:56:55.476631
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files_0 = DistributionFiles()
    assert distribution_files_0.parse_distribution_file_Amazon(str_0, str_1, str_2, distribution_fact_collector_0) == (bool_0, str_3)


# Generated at 2022-06-24 23:57:03.422790
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-24 23:57:06.565690
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distfiles = DistributionFiles()

    distfiles.parse_distribution_file_OpenWrt('', '', '', '')


# Generated at 2022-06-24 23:57:17.376561
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # test case 0
    str_0 = '\n'
    str_0 += 'NAME="openSUSE Leap"\n'
    str_0 += 'VERSION = "15.2"\n'
    str_0 += 'ID = "opensuse-leap"\n'
    str_0 += 'VERSION_ID = "15.2"\n'
    str_0 += 'PRETTY_NAME = "openSUSE Leap 15.2"\n'
    str_0 += 'ANSI_COLOR = "0;32"\n'
    str_0 += 'CPE_NAME = "cpe:/o:opensuse:leap:15.2"\n'
    str_0 += 'BUG_REPORT_URL = "https://bugs.opensuse.org"\n'

# Generated at 2022-06-24 23:57:21.621507
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    str1 = 'VERSION="14.2"\n'
    str2 = 'Slackware'
    distribution_fact_collector1 = DistributionFactCollector(str1)
    parser1 = distribution_fact_collector1.get_parser(str2)
    assert parser1.distribution_file_parsers['Slackware'].__name__ == 'parse_distribution_file_Slackware'


# Generated at 2022-06-24 23:57:32.264341
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = 'F='
    distribution_fact_collector_0 = DistributionFactCollector(str_0)
    str_1 = 'NAME="Clear Linux"'
    str_2 = 'NAME="Ubuntu"'
    str_3 = 'VERSION_ID=3333'
    str_4 = 'ID=notclearlinux'
    str_5 = 'Release'
    str_6 = 'not_clear'
    str_7 = 'Clear Linux'
    str_8 = 'CentOS Stream'
    str_9 = 'Foundry release not_clear'

    flag = distribution_fact_collector_0.parse_distribution_file_ClearLinux(str_7, str_0, str_6, str_5)
    assert flag == (True, {})
    flag = distribution_fact_collector_0.parse_distribution

# Generated at 2022-06-24 23:57:43.826607
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    ff_0 = DistributionFiles(None)
    str_data_0 = 'VERSION_ID="13.1"\nVERSION="13.1 (Bottle)\nNAME="openSUSE"'
    str_name_0 = 'openSUSE'
    str_path_0 = '/etc/os-release'
    dict_0 = {}
    dict_0['distribution'] = 'openSUSE'
    dict_0['distribution_release'] = 'Bottle'
    dict_0['distribution_version'] = '13.1'
    dict_0['distribution_major_version'] = '13'

    ret_0 = ff_0.parse_distribution_file_SUSE(str_name_0, str_data_0, str_path_0, dict_0)


# Generated at 2022-06-24 23:58:10.192740
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files_0 = DistributionFiles()
    distribution_files_0.module = MagicMock()
    distribution_files_0.module.get_bin_path.return_value = "/usr/bin/dpkg"

    # Testing with:
    data = "NAME=CoreOS\nID=coreos\nVERSION=1353.7.0\nVERSION_ID=1353.7.0\nBUILD_ID=\nPRETTY_NAME=CoreOS 1353.7.0\nANSI_COLOR=\"1;31\"\nHOME_URL=https://coreos.com/\nLOGO=\nBUG_REPORT_URL=https://issues.coreinfrastructure.org/projects/coreos\n"


# Generated at 2022-06-24 23:58:19.007029
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_files = DistributionFiles()

    # Test case 0

# Generated at 2022-06-24 23:58:23.461310
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    darwin_facts = {}
    darwin_facts['distribution'] = 'MacOSX'
    rc, out, err = Distribution.get_distribution_Darwin(darwin_facts['distribution'])
    data = out.split()[-1]
    if data:
        darwin_facts['distribution_major_version'] = data.split('.')[0]
        darwin_facts['distribution_version'] = data


# Generated at 2022-06-24 23:58:32.335080
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """
    Unit test for get_distribution_SunOS, which gets the distribution name, version and major version
    """
    print("\ntest_Distribution_get_distribution_SunOS")
    distribution_0 = Distribution(module=MagicMock())
    dsunos_0 = distribution_0.get_distribution_SunOS()
    print("\ndsunos_0: ")
    print(dsunos_0)
    print("\nTest that the keys of dsunos_0 are unique and there are no duplicates.")
    print("\nThere should be three (3) unique keys for dsunos_0, 'distribution', 'distribution_version' and 'distribution_major_version'.")
    print("\nIf there are more than three (3) keys present then there are duplicates.")

# Generated at 2022-06-24 23:58:41.224082
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # Values defined in the freebsd_facts dict will be used to validate
    # the values returned by the module
    darwin_facts = {}
    darwin_facts['distribution'] = 'MacOSX'
    darwin_facts['distribution_major_version'] = '12'
    darwin_facts['distribution_version'] = '12.2.2'
    darwin_facts['distribution_release'] = '16C67'

    # set the class up
    distribution = Distribution()

    # Get the return values of the class
    darwin_return = distribution.get_distribution_Darwin()
    # Compare the values with the ones returned

# Generated at 2022-06-24 23:58:47.340828
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():

    sunos_facts = get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_release'] == 'SmartOS 16.9.0.1'
    assert sunos_facts['distribution_version'] == '16.9.0.1'
    return

# Generated at 2022-06-24 23:58:53.273544
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():

    test_distribution_files_0 = DistributionFiles()

    test_distribution_files_0.parse_distribution_file_Mandriva('Mandriva', 'DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2009.0\nDISTRIB_CODENAME=MyPersonnalCooker\n', '', {'distribution_release': 'NA', 'distribution_version': 'NA'})


# Generated at 2022-06-24 23:58:53.952135
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    pass


# Generated at 2022-06-24 23:58:58.449554
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files_0 = DistributionFiles()
    name_0 = 'flatcar'
    data_0 = 'BOARD="amd64-usr" BUILD="2021.02.2" GROUP="stable"'
    path_0 = '/etc/flatcar/release'
    collected_facts_0 = None
    distribution_files_0.parse_distribution_file_Flatcar(name_0, data_0, path_0, collected_facts_0)


# Generated at 2022-06-24 23:59:09.056976
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    clear_data = '''NAME="Clear Linux OS"
ID=clear-linux-os
ID_LIKE=fedora
VERSION="27700"
VERSION_ID="27700"
PRETTY_NAME="Clear Linux OS"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:clearlinux:clear_linux:27700"
HOME_URL="https://clearlinux.org/"
SUPPORT_URL="https://clearlinux.org/support"
BUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"
PRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy/"
VERSION_CODENAME=""
LOGO=clear-logo'''
    distribution_files_0 = DistributionFiles()
    assert distribution_files_0.parse_distribution

# Generated at 2022-06-24 23:59:30.425947
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    float_0 = 2290.53077
    distribution_0 = Distribution(float_0)
    aix_facts = distribution_0.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.2'


# Generated at 2022-06-24 23:59:38.766439
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)
    assert_equal(False, distribution_files_0.parse_distribution_file_NA('NA', '', '', {'distribution_version': 'NA'}))
    assert_equal(False, distribution_files_0.parse_distribution_file_NA('NA', 'NAME="', '', {'distribution_version': 'NA'}))
    assert_equal(False, distribution_files_0.parse_distribution_file_NA('NA', 'NAME="Xenial", VERSION="', '', {'distribution_version': 'NA'}))

# Generated at 2022-06-24 23:59:43.860099
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-24 23:59:51.303160
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    data_0 = "DISTRIB_ID=MandrivaLinux\n"
    assert DistributionFiles.parse_distribution_file_Mandriva(
        "MandrivaLinux", data_0, "path", "collected_facts") == (True, {
            'distribution': 'Mandriva',
            'distribution_release': 'DISTRIB_CODENAME',
            'distribution_version': 'DISTRIB_RELEASE'
        })


# Generated at 2022-06-24 23:59:53.455693
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_0 = Distribution()
    assert distribution_0.get_distribution_HPUX() == {'distribution_version': u'11.31', 'distribution_release': u'0'}


# Generated at 2022-06-25 00:00:05.079105
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)
    name_0 = 'Slackware'
    data_0 = 'Slackware 13.0'
    path_0 = '/etc/slackware-version'
    collected_facts_0 = {}
    collected_facts_0 = collected_facts_0.copy()
    collected_facts_0['distribution_release'] = 'NA'

    assert distribution_files_0.parse_distribution_file_Slackware(name_0, data_0, path_0, collected_facts_0) == (True,
                                                                                                                {'distribution': 'Slackware',
                                                                                                                 'distribution_version': '13.0'})


# Generated at 2022-06-25 00:00:15.017711
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)
    str_0 = 'NAME="Amazon Linux AMI"\nVERSION="2012.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2012.03"\nPRETTY_NAME="Amazon Linux AMI release 2012.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2012.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n\nAmazon Linux AMI release 2012.03'
    str_1 = '/etc/system-release'
    facts_0 = {}

# Generated at 2022-06-25 00:00:22.124539
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = get_module_instance()
    distribution_files_0 = DistributionFiles(module)
    collected_facts_0 = {
        'distribution_release': 'NA',
        'distribution_version': 'NA',
    }
    distribution_files_0.parse_distribution_file_Debian(
        "''",
        "''",
        "''",
        collected_facts_0,
    )
    return collected_facts_0


# Generated at 2022-06-25 00:00:29.121775
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    float_0 = 8787.9430594
    float_1 = 4927.612
    float_2 = 2408.9979
    distribution_0 = Distribution(float_2)
    distribution_1 = Distribution(float_0)
    distribution_2 = Distribution(float_1)
    distribution_get_distribution_darwin_0 = distribution_0.get_distribution_Darwin()
    distribution_get_distribution_darwin_1 = distribution_1.get_distribution_Darwin()
    distribution_get_distribution_darwin_2 = distribution_2.get_distribution_Darwin()


# Generated at 2022-06-25 00:00:39.762440
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)
    name_0 = 'Kali'
    name_1 = 'Mint'
    name_2 = 'Ubuntu'
    name_3 = 'SteamOS'
    name_4 = 'Devuan'
    name_5 = 'Mandriva'
    name_6 = 'Cumulus'
    name_7 = 'Slackware'
    name_8 = 'Amazon Linux'
    name_9 = 'OpenWrt'
    name_10 = 'Alpine'
    name_11 = 'SUSE Linux Enterprise'
    name_12 = 'SUSE Linux'
    name_13 = 'Debian'
    name_14 = 'NA'
    name_15 = 'CoreOS'

# Generated at 2022-06-25 00:01:04.784017
# Unit test for function get_uname
def test_get_uname():
    # Test with default value for argument 'flags' (line)
    get_uname()

    # Test with the following value for 'flags': [('-v',)]
    flags = [('-v',)]
    # get_uname(flags=flags)

    # Test with the following value for 'flags': ['fake-uname-flag']
    flags = ['fake-uname-flag']
    # get_uname(flags=flags)



# Generated at 2022-06-25 00:01:10.685556
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)

    # test case for when 'CentOS Stream' not in data
    assert distribution_files_0.parse_distribution_file_CentOS("", "", "", {}) == (False, {})

    # test case for when 'CentOS Stream' in data
    assert distribution_files_0.parse_distribution_file_CentOS("CentOS Stream", "CentOS Stream", "", {}) == (True, {'distribution_release': 'Stream'})


# Generated at 2022-06-25 00:01:17.834414
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)
    # string test
    data = "/etc/os-release"
    # string test
    path = ""
    # dict test
    collected_facts = {}
    try:
        retval = distribution_files_0.parse_distribution_file_OpenWrt(data, path, collected_facts)
    except SystemExit:
        return


# Generated at 2022-06-25 00:01:25.272659
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    float_0 = 6609.8
    distribution_0 = Distribution(float_0)
    freebsd_facts_0 = distribution_0.get_distribution_FreeBSD()
    float_1 = -5969.0
    distribution_1 = Distribution(float_1)
    freebsd_facts_1 = distribution_1.get_distribution_FreeBSD()
    float_2 = 4207.9317
    distribution_2 = Distribution(float_2)
    freebsd_facts_2 = distribution_2.get_distribution_FreeBSD()
    float_3 = 6096.86044
    distribution_3 = Distribution(float_3)
    freebsd_facts_3 = distribution_3.get_distribution_FreeBSD()


# Generated at 2022-06-25 00:01:29.204068
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module_0 = Distribution('module_0')
    sunos_facts = module_0.get_distribution_SunOS()
    assert(sunos_facts['distribution'] == 'Solaris')


# Generated at 2022-06-25 00:01:37.440646
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    float_0 = 2582.2264
    distribution_files_0 = DistributionFiles(float_0)

    name_0 = 906.895878
    data_0 = '''GROUP=stable
'''
    path_0 = 'wcjbdl'
    collected_facts_0 = {'distribution': "tI'mz"}

    coreos_0 = distribution_files_0.parse_distribution_file_Coreos(name_0, data_0, path_0, collected_facts_0)

    assert coreos_0[0]
    assert coreos_0[1]['distribution_release'] == 'stable'


# Generated at 2022-06-25 00:01:44.156064
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)
    name_0 = 'flatcar'
    data_0 = 'GROUP=\t"5.5.1"'
    path_0 = 'etc/os-release'
    collected_facts_0 = {
        'distribution_release': '',
        'distribution': 'CoreOS',
        'distribution_major_version': '',
        'distribution_version': ''
    }
    assert(distribution_files_0.parse_distribution_file_Flatcar(name_0, data_0, path_0, collected_facts_0) == (True, {'distribution_release': '5.5.1'}))


# Generated at 2022-06-25 00:01:45.988914
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_1 = Distribution()
    distribution_facts = distribution_1.get_distribution_facts()


# Generated at 2022-06-25 00:01:48.681474
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    output = DistributionFiles()
    output.parse_distribution_file_Flatcar("name_0", "data_1", "path_2", "collected_facts_3")


# Generated at 2022-06-25 00:01:50.549972
# Unit test for function get_uname
def test_get_uname():
    args_0 = defaultdict(dict)
    args_0.get('module')
    args_0.get('flags')
    get_uname(args_0)


# Generated at 2022-06-25 00:02:15.403230
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    float_0 = 2422.2
    module_0 = DistributionFiles(float_0)
    # test for 'clearlinux' not in name.lower()
    name_0 = 'CentOS'

# Generated at 2022-06-25 00:02:18.516553
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    dist = Distribution(None)
    out = dist.get_distribution_OpenBSD()
    assert isinstance(out, dict)


# Generated at 2022-06-25 00:02:19.938619
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution_get_distribution_NetBSD = Distribution.get_distribution_NetBSD()


# Generated at 2022-06-25 00:02:24.031188
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution_0 = Distribution(module_0)
    class0_0 = distribution_0.get_distribution_HPUX()
    class0_0.__setattr__('module', module_1)
    class0_0.get_distribution_HPUX()


# Generated at 2022-06-25 00:02:25.356205
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module_0 = Distribution(786)
    module_0.get_distribution_AIX()


# Generated at 2022-06-25 00:02:31.745707
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    float_0 = 2290.53077
    distribution_files_0 = DistributionFiles(float_0)

    # Case 1:
    # Amazon Linux 2.0.20191118 - amzn2.0
    name_1 = 'Amazon Linux 2.0.20191118 - amzn2.0'
    data_1 = """NAME="Amazon Linux 2"
VERSION="2"
ID="amzn"
ID_LIKE="centos rhel fedora"
VERSION_ID="2"
PRETTY_NAME="Amazon Linux 2"
ANSI_COLOR="0;33"
CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
HOME_URL="https://amazonlinux.com/"
""".splitlines()

    path_1 = '/etc/os-release'

    # Case 2:
   