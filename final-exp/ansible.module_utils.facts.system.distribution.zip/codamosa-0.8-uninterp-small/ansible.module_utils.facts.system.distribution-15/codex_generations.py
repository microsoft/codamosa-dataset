

# Generated at 2022-06-24 23:53:10.413843
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_0 = Distribution('q\x8b=\xdf')
    distribution_0.get_distribution_SunOS()


# Generated at 2022-06-24 23:53:20.080754
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # set up object
    dist_files = DistributionFiles(None)
    # compare with expected result
    dist_file_path = '/etc/os-release'
    dist_file_data = 'NAME="SLES" VERSION="12.0" ID="sles" ID_LIKE="suse" VERSION_ID="12.0" PRETTY_NAME="SUSE Linux Enterprise Server 12 SP0" ANSI_COLOR="0;32" CPE_NAME="cpe:/o:suse:sles:12:0" BUG_REPORT_URL="https://bugs.opensuse.org" HOME_URL="https://www.suse.com/"'
    dist_file_name = 'SLES'
    dist_file_variety = 'RedHat'
    parsed_dist_file = True
    parsed_dist_file_facts

# Generated at 2022-06-24 23:53:29.185434
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    '''
    Test DistributionFiles.parse_distribution_file_Coreos()
    '''
    d = DistributionFiles()
    name = 'Coreos'
    with open('/etc/os-release') as f:
        data = f.read()
    msg = 'The value of "data" is {}.'.format(data)
    assert True, msg
    path = '/etc/os-release'
    collected_facts = {}
    collected_facts['distribution'] = 'Coreos'
    collected_facts['distribution_version'] = 'NA'
    collected_facts['distribution_release'] = 'NA'
    collected_facts['distribution_major_version'] = ''

# Generated at 2022-06-24 23:53:32.002523
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    str_0 = 'a\n.C$!LDf'
    distribution_0 = Distribution(str_0)
    dict_0 = distribution_0.get_distribution_FreeBSD()
    assert dict_0 is not None, "\nExpected:\n<dict object>\nActual:\n%s" % dict_0


# Generated at 2022-06-24 23:53:34.634952
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    str_0 = 's}sM&'
    str_1 = 'n~x)d'
    str_2 = '&X\"zd'
    # test line 315
    assert str_0 == str_1 == str_2


# Generated at 2022-06-24 23:53:42.449740
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_0 = Distribution('')
    uname_v = platform.uname()[3]
    distribution_version = None
    assert distribution_0.get_distribution_SunOS() == {'distribution': 'SunOS', 'distribution_release': uname_v, 'distribution_version': uname_v}

# Test nested function get_file_contents

# Generated at 2022-06-24 23:53:44.882950
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    str_1 = '|wvK'
    distribution_1 = Distribution(str_1)
    assert str(distribution_1) == 'Darwin'


# Generated at 2022-06-24 23:53:52.024272
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    import re
    platform_1 = get_platform()
    if not re.match(r'NetBSD', platform_1):
        return
    distribution_2 = Distribution(platform_1)
    call_function_0 = vars(distribution_2)['get_distribution_NetBSD']()


# Generated at 2022-06-24 23:53:55.429393
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module_0 = Distribution('Distribution')
    distribution_0 = module_0.get_distribution_Darwin()
    assert distribution_0 == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.15.5'}


# Generated at 2022-06-24 23:53:57.846992
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    # logger.debug('Running unit tests for method get_distribution_OpenBSD of class Distribution')
    test_case = DistributionFiles([])
    test_case_0()


# Generated at 2022-06-24 23:54:22.393671
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    str_0 = 'get_distribution_NetBSD'
    name = 'Slackware'
    data = ''
    path = '/etc/os-release'
    collected_facts = {}
    return DistributionFiles().parse_distribution_file_Slackware(name, data, path, collected_facts)


# Generated at 2022-06-24 23:54:27.362312
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    print("Test get_distribution_DragonFly is chosen.")
    try:
        print("=========================1")
        test_case_0()
        print("=========================2")
        # get_distribution_DragonFly()
    except Exception:
        print("Exception encountered.")
        __case_exception_msg = ""
        __exc_type, __exc_obj, __exc_tb = sys.exc_info()
        __case_exception_msg = 'Exception type : ' + str(__exc_type) + \
            'Exception detail : ' + str(__exc_obj)
        print(__case_exception_msg)
    finally:
        print("=========================3")
        print("Test is over.")
        return


# Generated at 2022-06-24 23:54:32.704912
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():

    # Uncomment one of the following two lines to test for the test case 0
    #emm = Distribution.get_distribution_NetBSD(str_0)
    #emm = Distribution.get_distribution_NetBSD(str_0)

    if isEqual(emm, str_0):
        return 0
    else:
        return 1


# Generated at 2022-06-24 23:54:37.274553
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    distribution = Distribution(module)

    # from ansible_collections.community.general.plugins.modules.os_distribution import Distribution
    # distribution = Distribution(module=module)
    # distribution.get_distribution_AIX()
    assert True == True


# Generated at 2022-06-24 23:54:47.235524
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    dist_file = DistributionFiles()
    name_0 = 'Mandriva'
    data_0 = '''NAME="Mandriva Linux"
PRETTY_NAME="Mandriva Linux 2011.0"
'''
    path_0 = '/etc/lsb-release'
    collected_facts_0 = dict()
    collected_facts_0['distribution'] = 'NA'
    collected_facts_0['distribution_version'] = 'NA'
    collected_facts_0['distribution_release'] = 'NA'
    collected_facts_0['distribution_file_variety'] = 'NA'
    collected_facts_0['distribution_file_path'] = 'NA'
    collected_facts_0['distribution_file_parsed'] = 'NA'

# Generated at 2022-06-24 23:54:53.136979
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_0 = 'get_distribution_OpenBSD'
    str_1 = 'get_distribution_OpenBSD'
    str_2 = 'get_distribution_AIX'
    str_3 = 'get_distribution_Darwin'
    str_4 = 'get_distribution_HPUX'
    str_5 = 'get_distribution_Linux'
    str_6 = 'get_distribution_SunOS'
    str_7 = 'get_distribution_FreeBSD'
    str_8 = 'get_distribution_DragonFly'
    str_9 = 'get_distribution_NetBSD'


# Generated at 2022-06-24 23:54:58.783262
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    str_0 = 'get_distribution_Fedora'
    str_1 = ''
    str_2 = 'get_distribution_CentOS'
    str_3 = '/tmp/ansible_rh_facts_payload_3wJzWI'
    str_4 = '/tmp/ansible_rh_facts_payload_8Wf62b'
    str_5 = 'get_distribution_RedHat'
    str_6 = 'distribution_file_path'
    str_7 = 'get_distribution_Mandriva'
    str_8 = 'get_distribution_Mandriva'
    str_9 = 'get_distribution_SUSE'
    str_10 = 'get_distribution_SUSE'
    str_11 = 'get_distribution_SUSE'

# Generated at 2022-06-24 23:55:09.354942
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    df = DistributionFiles()
    name = 'Mandriva'
    data = 'NAME="Mandriva Linux"\nVERSION="2010.1"\nID="mandriva"\nVERSION_ID="2010.1"\nPRETTY_NAME="Mandriva Linux 2010.1"\nANSI_COLOR="1;31"\nCPE_NAME="cpe:/o:mandrivalinux:linux:2010.1:community"\nHOME_URL="http://www.mandriva.com/"\nSUPPORT_URL="http://www.mandriva.com/en/support"\nBUG_REPORT_URL="http://qa.mandriva.com/"\n'
    path = '/etc/lsb-release'

# Generated at 2022-06-24 23:55:18.889582
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    data = '''
# Test case 1
NAME="CentOS Linux"
# Test case 2
NAME=CentOS Linux
# Test case 3
NAME=CentOS
# Test case 4
VERSION=7
# Test case 5
NAME=CentOS Linux
VERSION=7
# Test case 6
VERSION="7 (Core)"
# Test case 7
NAME="CentOS Linux"
VERSION="7 (Core)"
# Test case 8
NAME=centos
VERSION=7.2.1511
# Test case 9
NAME=centos
VERSION="7.2.1511"
'''
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}

# Generated at 2022-06-24 23:55:24.995788
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    str_0 = 'get_distribution_NetBSD'

    # The line below will be modified by the framework. Do not modify it.
    # str_0 = 'get_distribution_NetBSD'
    obj_0 = DistributionFiles(None)
    _ret_0 = obj_0.parse_distribution_file_Slackware(str_0, 'get_distribution_NetBSD', 'get_distribution_NetBSD', 'get_distribution_NetBSD')
    if _ret_0:
        if (not _ret_0[0]):
            raise Exception('Test Case Failed: (%s != %s)' % (_ret_0[0], _ret_0[1]))

# Generated at 2022-06-24 23:55:57.578912
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    src_0 = DistributionFiles()
    name_0 = 'N/A'
    data_0 = ''
    path_0 = '/etc/os-release'
    collected_facts_0 = {}
    (flatcar_facts_0, flatcar_facts_1) = src_0.parse_distribution_file_Flatcar(name_0, data_0, path_0, collected_facts_0)
    assert flatcar_facts_1 == {}
    assert flatcar_facts_0 is False


# Generated at 2022-06-24 23:56:05.236793
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    str_0 = 'mariadb.org'
    str_1 = 'SLES'
    str_2 = 'DATA'
    int_0 = 0
    int_1 = 21
    str_3 = 'ftp.hosteurope.de'
    str_4 = '10.0'
    str_5 = 'openSUSE_Tumbleweed'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool

# Generated at 2022-06-24 23:56:06.695446
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    test_case_0()
    dist = Distribution(module='module')
    out = dist.get_distribution_DragonFly()
    print(out)


# Generated at 2022-06-24 23:56:10.911953
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    path = 'distribution_file_path'
    data = 'distribution_file_data'
    collected_facts = {'distribution_version': 'NA'}
    file_name = 'file_name'

    distribution_files = DistributionFiles()
    suse_facts = distribution_files.parse_distribution_file_SUSE(file_name, data, path, collected_facts)
    assert suse_facts == (False, {})


# Generated at 2022-06-24 23:56:15.378462
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    obj = Distribution()
    obj.get_distribution_FreeBSD()
    test_case_0()


# Generated at 2022-06-24 23:56:26.342524
# Unit test for function get_uname
def test_get_uname():
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.run_command = test_get_uname_run_command
    class RunCommandMock():
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'test run_command_out'
            self.run_command_err = 'test run_command_err'
    def test_get_uname_run_command(*args):
        run_command_mock = RunCommandMock()
        return run_command_mock.run_command_rc, run_command_mock.run_command_out, run_command_mock.run_command_err
    ansible_module_mock = AnsibleModule

# Generated at 2022-06-24 23:56:27.936779
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_files = DistributionFiles()
    distribution_files.parse_distribution_file_NA()


# Generated at 2022-06-24 23:56:30.051973
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement test
    pass


# Generated at 2022-06-24 23:56:38.126450
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    testcase = [('/etc/os-release', '##THIS IS A TEST##\nNAME="Clear Linux"\nVERSION="23232"\nID=clear-linux-os\n', 'clear-linux-os', {'distribution': 'Clear Linux', 'distribution_version': '23232', 'distribution_release': 'clear-linux-os', 'distribution_major_version': '23232'})]

    obj_DistributionFiles = DistributionFiles()

    for t in testcase:
        if len(t) == 4:
            try:
                result = obj_DistributionFiles.parse_distribution_file_ClearLinux(t[2], t[1], t[0], t[3])
            except:
                raise Exception("parse_distribution_file_ClearLinux raises exception: %s"%(t[0]))

# Generated at 2022-06-24 23:56:39.484054
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    str_0 = 'get_distribution_NetBSD'


# Generated at 2022-06-24 23:57:12.663819
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = Distribution(str_0)

    def test_get_distribution_AIX(self):
        aix_facts = {}
        rc, out, err = self.module.run_command("/usr/bin/oslevel")
        data = out.split('.')
        aix_facts['distribution_major_version'] = data[0]
        if len(data) > 1:
            aix_facts['distribution_version'] = '%s.%s' % (data[0], data[1])
            aix_facts['distribution_release'] = data[1]
        else:
            aix_facts['distribution_version'] = data[0]
        return aix_facts


# Generated at 2022-06-24 23:57:18.037840
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_0 = 'c\n.C$!LDf'
    distribution_0 = Distribution(str_0)
    rc, out, err = distribution_0.module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'OpenBSD\s[0-9]+.[0-9]+-(\S+)\s.*', out)
    if match:
        distribution_release = match.groups()[0]
    else:
        distribution_release = 'release'
    str_1 = 'n\x0cpz\x15\x1f\x19\x1a\x07\r\x1f\x1e\x1d\x1c\x1b\x0f\x16\x19\x1e'

# Generated at 2022-06-24 23:57:24.679513
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    print('')
    print('**************************************************')
    print('* Test cases for method get_distribution_OpenBSD *')
    print('**************************************************')
    print('')
    # Test case 0
    print('Test case 0')
    # module.run_command(...)
    print('  module.run_command(...)')
    Distribution.get_distribution_OpenBSD()
    # Assign parameters
    # Assign variables


# Generated at 2022-06-24 23:57:29.135158
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    path_0 = 'F.9_'
    data_0 = '4\teeg'
    name_0 = 'd@fWG**8>$'
    assert DistributionFiles().parse_distribution_file_Slackware(name_0, data_0, path_0) == (False, {})


# Generated at 2022-06-24 23:57:34.337332
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    c_0 = DistributionFiles()
    # Expected output: {'distribution_file_path': '/etc/oracle-release', 'distribution_file_variety': 'Oracle', 'distribution_file_parsed': True, 'distribution': 'OracleLinux', 'distribution_release': '7', 'distribution_version': '7.2'}
    c_0.process_dist_files(['/etc/oracle-release', '/etc/redhat-release'])


# Generated at 2022-06-24 23:57:39.928510
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Case 0
    name_0 = 'zI'
    data_0 = '_yI\\u\x02\x7f\x0e\x13\x1f\x1f\x1a\t)\x1e\x11\x05\x1c\t!"\x1a!\t\x06\x1c\x06\x16\x02\x03\\\x0f5'
    path_0 = '3q'
    collected_facts_0 = {'distribution_release': 'NA', 'distribution_version': 'NA', 'distribution_major_version': 'NA'}
    distribution_files_0 = DistributionFiles(None)

# Generated at 2022-06-24 23:57:47.034736
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'c\n.C$!LDf'
    distribution_0 = Distribution(str_0)
    str_1 = 'Kali'
    str_2 = '=\nKali Linux Rolling\n'
    str_3 = 'kali.repo'
    distribution_0.get_all_from_path = mock.MagicMock(return_value=str_2)
    distribution_0.distribution_file_facts = {}
    DistributionFiles.parse_distribution_file_Mandriva(distribution_0, str_1, str_2, str_3)
    str_4 = 'distribution_release'
    str_5 = 'kali_linux_rolling'
    str_6 = 'distribution'
    str_7 = 'mandriva'

# Generated at 2022-06-24 23:57:53.976341
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    DISTRIBUTION_FILE_PATH = '/etc/os-release'
    DISTRIBUTION_FILE_DATA = 'NAME="OpenWrt"\nDISTRIB_ID="openwrt"\nVERSION_ID="15.05.1"\nDISTRIB_RELEASE="Chaos Calmer"\nDISTRIB_REVISION="r7258-5eb055306f"\nDISTRIB_CODENAME="chaos_calmer"\nDISTRIB_TARGET="sunxi"\nDISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"\nDISTRIB_TAINTS=""\n'
    DISTRIBUTION = 'OpenWrt'
    DISTRIBUTION_VAR = 'NA'
    DISTRIBUTION_VERSION_VAR = 'NA'
    DISTRIBUTION_MAJOR

# Generated at 2022-06-24 23:57:59.762490
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    str_0 = 'v]Q$j\x7fF?\x00\x00\x01\x00\x00\x00}'
    distribution_0 = Distribution(str_0)

    # Test with correct argument

    rc_1, out_1, err_1 = distribution_0.get_distribution_FreeBSD()

    assert rc_1 == 0
    assert out_1 == ''
    assert err_1 == ''


# Generated at 2022-06-24 23:58:06.725164
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    """Test parse_distribution_file_Flatcar"""
    str_0 = 'ture see up there.\nHITACHI'
    obj = DistributionFiles(str_0)
    str_0 = 'v'
    str_1 = ' /foo/bar'
    str_2 = 'GROUP=Stable'
    pyansible_collected_facts_0 = {'distribution_release': 'NA'}
    tuple_0 = (str_0, str_1, str_2, pyansible_collected_facts_0)
    # call method with test argument
    result = obj.parse_distribution_file_Flatcar(tuple_0)
    assert result[0] == True


# Generated at 2022-06-24 23:58:41.276108
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dfile = {
        'parse_distribution_file_Amazon': [
            {"path": "path/to/file", "data": "Amazon", "distribution_version": "1.2.3", "collection_facts": "Not yet implemented"},
            {"path": "path/to/file", "data": "Amazon", "distribution_version": "1.2.3", "collection_facts": "Not yet implemented"},
            {"path": "path/to/file", "data": "Amazon", "distribution_version": "1.2.3", "collection_facts": "Not yet implemented"},
            {"path": "path/to/file", "data": "Amazon", "distribution_version": "1.2.3", "collection_facts": "Not yet implemented"},
        ]
    }
    return dfile


# Generated at 2022-06-24 23:58:50.698078
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    d_0 = DistributionFiles(_path='c:\Windows\System32')
    dist_file_variety_0 = 'Slackware'
    data_0 = '0.1.2.3'
    path_0 = 'c:\Windows\System32'
    collected_facts_0 = dict()
    return_0 = d_0.parse_distribution_file_SUSE(dist_file_variety_0, data_0, path_0, collected_facts_0)

    assert return_0[0] == True
    assert return_0[1]['distribution'] == 'Slackware'


# Generated at 2022-06-24 23:58:54.096325
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_0 = 'c\n.C$!LDf'
    distribution_0 = Distribution(str_0)
    ann_0 = distribution_0.get_distribution_OpenBSD()
    assert ann_0 is not None


# Generated at 2022-06-24 23:59:00.231985
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    string_0 = 'ndriva'
    string_1 = ''
    string_2 = 'd\n.C$!LDf'
    path_0 = '\x1e\x02\x2c'
    path_1 = '/'
    distribution_files_0 = DistributionFiles()
    bool_0 = distribution_files_0.parse_distribution_file_Debian(string_0, string_1, path_0, path_1)
    assert bool_0 == False
    bool_0 = distribution_files_0.parse_distribution_file_Debian(string_0, string_2, path_0, path_1)
    assert bool_0 == False


# Generated at 2022-06-24 23:59:11.338919
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    distribution_0 = Distribution('4.4.77-1.coreos.el7.centos.x86_64')
    rc, out, err = distribution_0.module.run_command(
        "/usr/bin/python -c 'import sys;'")
    distribution_0.module.run_command(
        'if ! /usr/bin/getent passwd vagrant ; then sudo useradd -m vagrant -u 1000 -s /bin/bash; echo vagrant:vagrant | sudo chpasswd; fi')
    rc, out, err = distribution_0.module.run_command(
        'sudo mkdir -p /var/log/ansible/facts; sudo chown -R vagrant:vagrant /var/log/ansible/facts')

# Generated at 2022-06-24 23:59:21.400414
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Test with an invalid distribution file
    dist_file_facts = Distribution.parse_distribution_file_ClearLinux('clearlinux', '', '', {})
    assert not dist_file_facts[0]

    # Test with a valid distribution file
    data = 'NAME="Clear Linux"\nID="clear-linux-os"\nVERSION_ID=24990\nVERSION="24990 (Maipo)"\nPRETTY_NAME="Clear Linux 24990 (Maipo)"\nANSI_COLOR="0;34"\nHOME_URL="https://clearlinux.org/"\nSUPPORT_URL="https://clearlinux.org/support"\nBUG_REPORT_URL="https://github.com/clearlinux/clr-bug-tool/issues"\n'
    dist_file_facts = Distribution.parse_distribution_

# Generated at 2022-06-24 23:59:33.801832
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    data_0 = 'NAME="Amazon Linux AMI"\nVERSION="2017.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2017.03"\nPRETTY_NAME="Amazon Linux AMI 2017.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2017.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path_0 = '/etc/os-release'
    collected_facts_0 = {}
    dist_file_facts_0 = DistributionFiles.parse_distribution_file_Amazon('name_0', data_0, path_0, collected_facts_0)

# Generated at 2022-06-24 23:59:40.223336
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'c\n.C$!LDfd'
    distribution_0 = Distribution(str_0)
    distribution_0.distribution = 'Mandriva'
    distribution_1 = Distribution(str_0)
    distribution_1.distribution = 'c'
    distribution_2 = Distribution(str_0)
    distribution_2.distribution = 'Debian'
    distribution_3 = Distribution('\nbS+_S\n]y"~')
    distribution_3.distribution = 'c'
    str_1 = 'n+G)b]*"fh'
    distribution_4 = Distribution(str_1)
    distribution_4.distribution = 'Debian'
    distribution_5 = Distribution('HN]%/0$6G')
    distribution_5.distribution = 'RedHat'


# Generated at 2022-06-24 23:59:45.119015
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'Mandriva'
    str_1 = 'Mandriva Linux release 2011.0 (Official) for x86_64'
    str_2 = 'DISTRIB_RELEASE=2011.0'
    str_3 = 'DISTRIB_CODENAME=Official'
    flag_0 = True
    ret_0 = DistributionFiles.parse_distribution_file_Mandriva()
    print(ret_0)


# Generated at 2022-06-24 23:59:54.343804
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_files_0 = DistributionFiles()
    str_0 = 'c\n.C$!LDf'
    name_0 = distribution_files_0.split_distro_file_name(str_0)
    data_0 = get_file_content(str_0)
    path_0 = str_0
    collected_facts_0 = {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    parsed_dist_file_0, parsed_dist_file_facts_0 = distribution_files_0.parse_distribution_file_ClearLinux(name_0, data_0, path_0, collected_facts_0)
    assert parsed_dist_file_0
    assert parsed_dist_file_facts_0['distribution'] == 'Clear Linux'
   

# Generated at 2022-06-25 00:01:01.033967
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    with pytest.raises(TypeError, match="str_0: expected str, got int"):
        test_case_0()


# Generated at 2022-06-25 00:01:05.392127
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_0 = 'OpenBSD\t6.4\tGENERIC#1692\toptimized'
    str_1 = 'OpenBSD\t6.4\t(GENERIC)\t#1692\toptimized'
    distribution_0 = Distribution(str_0)
    distribution_1 = Distribution(str_1)
    distribution_2 = Distribution(str_0)
    distribution_3 = Distribution('SmartOS')


# Generated at 2022-06-25 00:01:07.844701
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_1 = Distribution(str_1)
    result = distribution_1.get_distribution_facts()
    assert result is None


# Generated at 2022-06-25 00:01:13.884773
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_0 = 'T\t|zj'
    distribution_0 = Distribution(str_0)
    assert distribution_0.get_distribution_OpenBSD() == {
        'distribution_version': '5.9',
        'distribution_release': 'release'
    }
    str_1 = '4q'
    distribution_1 = Distribution(str_1)
    assert distribution_1.get_distribution_OpenBSD() == {
        'distribution_version': '5.9',
        'distribution_release': 'release'
    }
    str_2 = '6d!8Z*WX'
    distribution_2 = Distribution(str_2)

# Generated at 2022-06-25 00:01:24.194719
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():

    # data = 'Debian GNU/Linux 9.8 \n \n'
    # data = 'Raspbian GNU/Linux 9.8 \n \n'
    # data = 'Ubuntu 16.04.6 LTS \n \n'
    # data = 'SteamOS 2.156 \n \n'
    # data = 'Kali GNU/Linux Rolling \n \n'
    data = 'Linux Mint 18.3 Sylvia \n \n'
    # data = 'Dummy data \n \n'
    # data = 'PRETTY_NAME="Debian GNU/Linux stretch (testing)"\nNAME="Debian GNU/Linux"\nVERSION_ID="stretch"\nVERSION="9 (stretch)"\nID=debian\nHOME_URL="https://www.debian.org/"\nSUPPORT_URL="https://www

# Generated at 2022-06-25 00:01:32.560720
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    print("Testing DistributionFiles.parse_distribution_file_Flatcar")
    str_0 = 'c\n.C$!LDf'
    distribution_0 = Distribution(str_0)

    name_0 = ''
    data_0 = 'GROUP=stable\nID=amd64-usr'
    path_0 = '/usr/share/coreos/release'
    collected_facts_0 = {}

    # Actual result
    (is_parsed, actual_parsed_dist_file_facts_0) = distribution_0.parse_distribution_file_Flatcar(name_0, data_0, path_0, collected_facts_0)
    print("actual_parsed_dist_file_facts_0: " + str(actual_parsed_dist_file_facts_0))
    #

# Generated at 2022-06-25 00:01:37.402894
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():

    # Declare strings for the test
    str_0 = ''
    str_1 = ''

    # Call the method
    list_0 = Distribution(str_0).get_distribution_HPUX(str_1)

    # Check the results
    if (len(list_0) == 0):
        return (True, "Empty list")
    elif ( ( list_0['distribution_version'] == 'B.11.31') and ( list_0['distribution_release'] == '138835') ):
        return (True, list_0)
    else:
        return (False, list_0)


# Generated at 2022-06-25 00:01:38.215763
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # Run the test
    test_case_0()


# Generated at 2022-06-25 00:01:41.585339
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    from ansible.module_utils.facts.collector.distribution import get_distribution
    from ansible.module_utils.facts.collector.system import get_file_content

    distro = get_distribution()
    distribution_files = DistributionFiles(distro)
    test_data = {}
    facts = {}
    distribution_files.parse_distribution_file_Slackware('Slackware', test_data, '', facts)


# Generated at 2022-06-25 00:01:45.172261
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    test_case_0()


# Generated at 2022-06-25 00:02:35.556019
# Unit test for function get_uname
def test_get_uname():
    str_0 = 'c\n.C$!LDf'
    str_1 = '<'
    str_2 = 'c\n.C$!LDf'
    str_3 = 'c\n.C$!LDf'
    str_4 = '$Z5'
    str_5 = 'c\n.C$!LDf'
    str_6 = '<'
    str_7 = 'L-#z'
    module_0 = BaseFactCollector(str_0, str_1)
    module_0.run_command = lambda x: (0, str_2, str_3)
    flags_0 = str_4
    # assert get_uname(module_0, flags_0) == str_5
    flags_1 = [str_6, str_7]
    #