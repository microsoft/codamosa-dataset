

# Generated at 2022-06-24 23:53:11.853383
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    test_Distribution_instance_0 = Distribution(module=ModuleStub())
    var_0 = test_Distribution_instance_0.get_distribution_DragonFly()


# Generated at 2022-06-24 23:53:22.248501
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_files_0 = DistributionFiles()
    data = "NAME=Clear Linux\nVERSION_ID=30600"
    name = "clearlinux"
    path = "/dummy_path"
    collected_facts = {
        'distribution_major_version': 'NA',
        'distribution_version': 'NA',
        'distribution_release': 'NA'
    }

    # Test case 0
    var_0 = distribution_files_0.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    assert var_0 == (True,{'distribution': 'Clear Linux', 'distribution_major_version': '30600', 'distribution_version': '30600', 'distribution_release': 'ID'})


# Generated at 2022-06-24 23:53:27.795119
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_obj_0 = Distribution(module=AnsibleModule(argument_spec={}))
    distribution_obj_0.module.run_command = MagicMock(return_value=(0, 'OpenBSD 6.3-stable (GENERIC.MP) #6: Mon Aug 13 00:38:33 MDT 2018', None))
    assert distribution_obj_0.get_distribution_OpenBSD() == {'distribution_release': '6.3', 'distribution_version': '6.3'}


# Generated at 2022-06-24 23:53:30.739758
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_0 = Distribution()
    distribution_0.run_command = MagicMock(name='run_command')
    distribution_0.run_command.return_value = (1, "out", 1)
    var_0 = distribution_0.get_distribution_AIX()
    assert var_0 == {}


# Generated at 2022-06-24 23:53:36.372642
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    distribution_fact_collector_0 = DistributionFactCollector()
    # Call method parse_distribution_file_Debian with parameter name=Amazon, data=, path=/tmp/facts, collected_facts={'virtualization_hypervisor': 'NA', 'distribution_version': 'NA', 'distribution_file_parsed': False, 'distribution': 'RedHat', 'distribution_release': 'NA', 'virtualization_type': 'NA', 'distribution_file_path': '', 'distribution_file_variety': 'Unknown', 'distribution_major_version': 'NA'}
    name_0 = 'Amazon'
    data_0 = ''
    path_0 = '/tmp/facts'

# Generated at 2022-06-24 23:53:42.982245
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    print("Testing DistributionFiles.parse_distribution_file_Slackware")
    distribution_files_0 = DistributionFiles()
    var_0 = distribution_files_0.parse_distribution_file_Slackware('name', 'data', 'path', 'collected_facts')
    assert var_0[0]
    assert var_0[1]['distribution'] == 'Slackware'


# Generated at 2022-06-24 23:53:44.721494
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution_obj = Distribution(module)
    distribution_obj.get_distribution_NetBSD()


# Generated at 2022-06-24 23:53:53.707500
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    d_0 = Distribution(module=None)
    d_0.module.run_command = lambda x: (1, "HPUX_B.11.31_LR_OVS_PA_RISC_11.31_0000.iso                                               HP-UX Operating Environment  B.11.31      0001635088   HP-UX_B.11.31_11.31_PA_RISC", "")
    d_0.get_distribution_HPUX()


# Generated at 2022-06-24 23:54:04.887410
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():

    # Create fixture
    distribution_files_1 = DistributionFiles({})
    distribution_files_1.distribution_fact_collector = DistributionFactCollector()

    # Create test input
    param_0 = 'Mandriva'

# Generated at 2022-06-24 23:54:09.360770
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    distribution_files_instance_0 = DistributionFiles()
    distribution_files_instance_0.parse_distribution_file_Debian('name_0', 'data_0', 'path_0', 'collected_facts_0')


# Generated at 2022-06-24 23:54:53.865611
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files_0 = DistributionFiles()
    parsed_distribution_file_amazon = distribution_files_0.parse_distribution_file('Amazon', 'Amazon', '/etc/issue', None)
    assert parsed_distribution_file_amazon['distribution'] == 'Amazon'


# Generated at 2022-06-24 23:54:58.115114
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dist = Distribution(module=None)
    assert 'freebsd' in dist.get_distribution_DragonFly()['distribution_release']


# Generated at 2022-06-24 23:55:08.810092
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_files_1 = DistributionFiles()
    data_0 = "PRETTY_NAME=\"OpenWrt 8.09\"\n"
    data_0 = data_0 + "DISTRIB_DESCRIPTION=\"OpenWrt 8.09\"\n"
    data_0 = data_0 + "DISTRIB_RELEASE=\"\"\n"
    data_0 = data_0 + "DISTRIB_REVISION=\"\"\n"
    data_0 = data_0 + "DISTRIB_CODENAME=\"\"\n"
    data_0 = data_0 + "DISTRIB_TARGET=\"brcm47xx/mips74k\"\n"
    data_0 = data_0 + "DISTRIB_ARCH=\"mips\"\n"

# Generated at 2022-06-24 23:55:19.460015
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    collected_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA',
        'distribution_file_variety': 'Debian',
        'distribution_file_path': 'NA',
    }

    distro_data = """
    PRETTY_NAME="Debian GNU/Linux 9 (stretch)"
    NAME="Debian GNU/Linux"
    VERSION_ID="9"
    VERSION="9 (stretch)"
    ID=debian
    HOME_URL="https://www.debian.org/"
    SUPPORT_URL="https://www.debian.org/support"
    BUG_REPORT_URL="https://bugs.debian.org/"
    """
    name = 'NA'

# Generated at 2022-06-24 23:55:24.795045
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)
    res = distro.get_distribution_HPUX()
    assert res == {
        'distribution_release': 'B.11.31',
        'distribution_version': 'B.11.31'
    }


# Generated at 2022-06-24 23:55:32.408774
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files_class_0 = DistributionFiles()
    var_0 = distribution_files_class_0.parse_distribution_file_SUSE('NA', 'SLES 12.1 (x86_64)\nVERSION = 12\nPATCHLEVEL = 1', '/etc/SuSE-release', {'distribution_release': 'NA', 'distribution_version': '12.1'})
    assert var_0[0]


# Generated at 2022-06-24 23:55:36.235527
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    try:
        distribution_fact_collector_1 = DistributionFactCollector()
        distribution_fact_collector_1.get_distribution_OpenBSD()
    except:
        pass


# Generated at 2022-06-24 23:55:37.538663
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    os = Distribution()
    # TODO: Add test case here


# Generated at 2022-06-24 23:55:42.720380
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    data = "GROUP=stable\n"
    path = "/etc/coreos/update.conf"
    ret_val_0, ret_data_0 = DistributionFiles().parse_distribution_file_Coreos('coreos', data, path, {'distribution_release': 'NA'})
    assert ret_data_0['distribution_release'] == 'stable'
    assert ret_val_0 == True


# Generated at 2022-06-24 23:55:48.599596
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    assert Distribution(module=AnsibleModule()).get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_version': '10.15', 'distribution_major_version': '10'}


# Generated at 2022-06-24 23:56:38.138597
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    print("Testing method parse_distribution_file_NA")
    distribution_0 = DistributionFiles()

    data_0 = 'NAME=Fedora\n'
    path_0 = '/etc/os-release'
    collected_facts_0 = {'distribution_version': 'NA'}
    name_0 = "NA"

    parsed_dist_file_facts_0 = {'distribution': 'Fedora'}

    distribution_0.parse_distribution_file_NA(name_0, data_0, path_0, collected_facts_0)
    assert parsed_dist_file_facts_0 == distribution_0.parse_distribution_file_NA(name_0, data_0, path_0, collected_facts_0)[1]

    #print(parsed_dist_file_facts_0)
    return

# Generated at 2022-06-24 23:56:46.252460
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():

    # Unit test for method get_distribution_AIX of class Distribution
    # Test case 0
    dist_facts_0 = {}
    dist_facts_0['distribution'] = 'AIX'
    dist_facts_0['distribution_version'] = '7.1'
    dist_facts_0['distribution_major_version'] = '7'
    dist_facts_0['distribution_release'] = '1'
    dist_facts_0['os_family'] = 'AIX'

    dist_0 = Distribution(None)
    # Test case 0
    dist_0_retval = dist_0.get_distribution_AIX()
    assert dist_0_retval == dist_facts_0['distribution_major_version']


# Generated at 2022-06-24 23:56:50.545462
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # Ignore the next line because Distribution is not being used strictly
    distribution_Darwin = Distribution(get_distribution())
    assert distribution_Darwin.get_distribution_Darwin() == {'distribution': 'MacOSX',
                                                             'distribution_version': '10.14.6',
                                                             'distribution_major_version': '10'}


# Generated at 2022-06-24 23:57:00.446628
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    """
    Test module parse_distribution_file_Amazon
    """
    testdataA = "/etc/os-release"
    testdataB = "/etc/system-release"

    disttestA = DistributionFiles()

    # Test with /etc/os-release
    disttestA.parse_distribution_file_Amazon('Amazon', get_file_content(testdataA), testdataA, {})

    # Test with /etc/system-release
    disttestA.parse_distribution_file_Amazon('Amazon', get_file_content(testdataB), testdataA, {})


# Generated at 2022-06-24 23:57:04.257571
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    dist = Distribution()
    data = dist.get_distribution_NetBSD()
    assert data['distribution_release'] == 'NetBSD-8.1-release'
    assert data['distribution_major_version'] == '8'
    assert data['distribution_version'] == '8.1'


# Generated at 2022-06-24 23:57:09.958052
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distribution_files = DistributionFiles()
    if distribution_files.parse_distribution_file_Mandriva("Mandriva", "Mandriva"):
        # method parse_distribution_file_Mandriva returned true
        pass
    else:
        # method parse_distribution_file_Mandriva returned false
        pass


# Generated at 2022-06-24 23:57:14.333537
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distribution_0 = Distribution()
    distribution_0.module.run_command = Mock(return_value=(0, "v4.4.1-RELEASE-p11-HBSD", ""))
    facts = distribution_0.get_distribution_DragonFly()
    assert facts['distribution'] == 'DragonFlyBSD'
    assert facts['distribution_major_version'] == '4'
    assert facts['distribution_version'] == '4.4.1'
    assert facts['os_family'] == 'DragonFlyBSD'
    assert facts['distribution_release'] == 'RELEASE'


# Generated at 2022-06-24 23:57:18.802995
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    distribution_0 = Distribution(module=module_0)
    out = distribution_0.get_distribution_DragonFly()
    assert out.get('distribution_release') == '11.0-RELEASE'


# Generated at 2022-06-24 23:57:21.162131
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    print('Testing parse_distribution_file_Debian')
    df_0 = DistributionFiles()
    df_0.parse_distribution_file_Debian()


# Generated at 2022-06-24 23:57:31.928745
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    """Test method 'DistributionFiles.parse_distribution_file_NA()'"""
    dist_files = DistributionFiles()
    path = '/etc/os-release'

    name = 'NA'

# Generated at 2022-06-24 23:58:17.993980
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distribution_files = DistributionFiles()
    distribution_file_name = 'Slackware'
    distribution_file_data = '\nSlackware 14.1 \n'
    distribution_file_path = '/etc/slackware-version'
    distribution_file_facts = {}
    result = distribution_files.parse_distribution_file_Slackware(distribution_file_name, distribution_file_data, distribution_file_path, distribution_file_facts)
    assert result == (True, {'distribution': 'Slackware', 'distribution_version': '14.1'})



# Generated at 2022-06-24 23:58:27.086640
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_files = DistributionFiles()
    distribution_file_path = '/etc/os-release'
    distribution_file_name = 'NA'

# Generated at 2022-06-24 23:58:38.346373
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files = DistributionFiles()
    os_release_content = """\
ID=coreos
NAME=CoreOS
VERSION=1068.0.20190125
VERSION_ID=1068.0.20190125
BUILD_ID=
PRETTY_NAME="CoreOS 1068.0.20190125"
ANSI_COLOR="1;34"
HOME_URL="https://coreos.com/"
BUG_REPORT_URL="https://github.com/coreos/bugs/issues"
COREOS_BOARD=amd64-usr
GROUP=stable
"""
    name = "Coreos"
    path = "/etc/os-release"
    collected_facts = {"distribution_release": "NA"}

# Generated at 2022-06-24 23:58:44.901314
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    distribution_0 = DistributionFiles()
    name, data, path, collected_facts = 'Mandriva', '', '', {}
    result, mandriva_facts = distribution_0.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    print(mandriva_facts)


if __name__ == '__main__':
    import sys
    import os
    import string
    import pprint
    import inspect
    import __builtin__
    print('Test Cases for class DistributionFiles')
    print('Running test case 0: ')
    test_case_0()

# Generated at 2022-06-24 23:58:54.760557
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files_0 = DistributionFiles()

    arg_0 = "Flatcar"
    arg_1 = "NAME='Flatcar Container Linux'\nID=flatcar\nVERSION_ID='20200805.2.1'\nBUILD_ID='f8ad30e-2020-08-05T20:48:21Z'\nPRETTY_NAME='Flatcar Container Linux 20200805.2.1 (f8ad30e)';\nANSI_COLOR='1;32';\nHOME_URL='https://www.flatcar-linux.org/';\nLOGO=static/flatcar.svg"
    arg_2 = "/etc/os-release"

    # collected_facts = {'distribution_release': 'NA'}
    collected_facts = {}

    expected = True
    expected_

# Generated at 2022-06-24 23:58:55.903786
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    distribution_0 = Distribution()
    distribution_1 = Distribution()


# Generated at 2022-06-24 23:58:59.519380
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_obj = Distribution()
    distribution_obj.module = FakeAnsibleModule()
    dict_fact = distribution_obj.get_distribution_Darwin()
    assert dict_fact['distribution'] == 'MacOSX'
    assert dict_fact['distribution_major_version'] == '10'
    assert dict_fact['distribution_version'] == '10.14.1'


# Generated at 2022-06-24 23:59:10.516859
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_0 = DistributionFiles()
    name_0 = 'Slackware'
    data_0 = '''
SLACKWARE_VERSION=14.2
SLACKWARE_VERSION=14.2
SLACKWARE_VERSION=14.2
SLACKWARE_VERSION=14.2
'''
    path_0 = './test_data/distribution_file_0.txt'
    collected_facts_0 = {}
    test_0 = dist_file_0.parse_distribution_file_Slackware(name_0, data_0, path_0, collected_facts_0)
    assert test_0[0] == True
    assert test_0[1] == {'distribution': 'Slackware', 'distribution_version': '14.2'}


# Generated at 2022-06-24 23:59:17.777045
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_f = DistributionFiles()
    assert distribution_f.parse_distribution_file_Amazon('Amazon', '/etc/os-release',
                                                         'Amazon\nNAME="Amazon Linux AMI"',
                                                         'collected_facts') == (True, {'distribution': 'Amazon'})

    assert distribution_f.parse_distribution_file_Amazon('Amazon', '/etc/system-release',
                                                         'Amazon Linux release 2.0 (2018.03)',
                                                         'collected_facts') == (True, {'distribution': 'Amazon',
                                                                                      'distribution_version': '2.0'})


# Generated at 2022-06-24 23:59:26.133500
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    test_module = DistributionFiles()

# Generated at 2022-06-25 00:01:00.482109
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    
    distribution_HPUX = Distribution()

    rc, out, err = distribution_HPUX.module.run_command("/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'", use_unsafe_shell=True)
    assert 0 == rc


# Generated at 2022-06-25 00:01:03.026092
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution = Distribution()
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'


# Generated at 2022-06-25 00:01:06.859402
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # Tests call will succeed
    mock_module = MagicMock()
    get_distribution_DragonFly = Distribution(mock_module).get_distribution_DragonFly()
    print(get_distribution_DragonFly)
    assert get_distribution_DragonFly == {}


# Generated at 2022-06-25 00:01:18.551498
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    distribution_files = DistributionFiles()
    parsed_facts = {}
    # Test case 0 (Normal case)
    data = r'''PRETTY_NAME="Debian GNU/Linux 8 (jessie)"
NAME="Debian GNU/Linux"
VERSION_ID="8"
VERSION="8 (jessie)"
ID=debian
HOME_URL="http://www.debian.org/"
SUPPORT_URL="http://www.debian.org/support/"
BUG_REPORT_URL="https://bugs.debian.org/"'''
    facts = {'distribution_version': "8", 'distribution_release': 'NA'}
    parsed_facts = distribution_files.parse_distribution_file_Debian('Debian', data, '/etc/os-version', facts)

# Generated at 2022-06-25 00:01:26.283070
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_0 = Distribution()
    root_dir_0 = '/usr/bin/oslevel'
    rc_0, out_0, err_0 = distribution_0.module.run_command("/usr/bin/oslevel")
    data_0 = out_0.split('.')
    aix_facts_0 = {}
    aix_facts_0['distribution_major_version'] = data_0[0]
    if len(data_0) > 1:
        aix_facts_0['distribution_version'] = '%s.%s' % (data_0[0], data_0[1])
        aix_facts_0['distribution_release'] = data_0[1]
    else:
        aix_facts_0['distribution_version'] = data_0[0]
    a

# Generated at 2022-06-25 00:01:34.311100
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # test case:
    distribution_files = DistributionFiles()
    name = 'Mandriva'
    data = """
NAME="Mandriva Linux"
VERSION="2010.1 (Official) - Spring"
ID=mandriva
""".strip()
    path = '/etc/lsb-release'
    collected_facts = {}
    parsed, facts = distribution_files.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert(parsed)
    assert(facts['distribution'] == 'Mandriva')
    assert(facts['distribution_release'] == 'Spring')
    assert(facts['distribution_version'] == '2010.1')

    # test case:

# Generated at 2022-06-25 00:01:45.911115
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    # Test #1: test process_dist_files() on a supported system
    dist_file_facts_test1 = DistributionFiles().process_dist_files('NA', {}, {}, {})
    assert 'NA' in dist_file_facts_test1['distribution_file_parsed']
    assert 'CoreOS' in dist_file_facts_test1['distribution_file_parsed']
    # Test #2: test process_dist_files() on an unsupported system
    dist_file_facts_test2 = DistributionFiles().process_dist_files('NA', {}, {}, {'distribution': 'UnsupportedDistro'})
    assert 'NA' in dist_file_facts_test2['distribution_file_parsed']

# Generated at 2022-06-25 00:01:50.793087
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_darwin = Distribution()
    distribution_darwin.module = MagicMock()
    distribution_darwin.module.run_command = MagicMock(return_value=0, side_effect=[
        ("10.10.5", "", ""),
    ])
    distribution_darwin.get_distribution_Darwin()
    distribution_darwin.module.run_command.assert_called_once_with('/usr/bin/sw_vers -productVersion')


# Generated at 2022-06-25 00:01:53.841715
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution_netbsd = Distribution()
    facts = distribution_netbsd.get_distribution_NetBSD()
    assert facts == {'distribution_release': '8.99.1', 'distribution_major_version': '8', 'distribution_version': '8.99'}


# Generated at 2022-06-25 00:01:59.786279
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution = Distribution()

    distribution.module = FakeAnsibleModule()
    distribution.module.run_command = mock_run_command(
        rc=0, out="HPUX_OE_11.31_1788_000 #1:2018-05-15 10:18:14 +00:00:00 root@hostname:/tmp/build_root/1394/sources/BUILD/hp-uxoe/src/1788.000/hppa2.0w-hp-hpux11.31/CORE_PATCH/opt/ooce/bin/../../hp-uxoe-base/product/1788.000/bin/../../examples/bin/../include/uuid.h", err="")

    distribution_facts = distribution.get_distribution_HPUX()

    assert distribution_facts['distribution_version']