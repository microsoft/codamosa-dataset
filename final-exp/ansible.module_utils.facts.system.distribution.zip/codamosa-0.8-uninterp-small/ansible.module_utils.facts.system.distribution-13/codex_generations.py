

# Generated at 2022-06-24 23:53:18.996834
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    dict_0 = {
        'run_command': get_command_0
    }
    distribution_0 = Distribution(dict_0)
    dict_1 = distribution_0.get_distribution_AIX()
    assert dict_1 == expected_dict_0


# Generated at 2022-06-24 23:53:20.630499
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution_1 = Distribution(None)
    distribution_1.get_distribution_NetBSD()


# Generated at 2022-06-24 23:53:31.970046
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    dict = { 'run_command_environ_update': {'LANG': 'C'},
            'ansible_facts': {'ansible_system': 'SunOS',
                              'ansible_machine': 'sun4v',
                              'ansible_kernel': '5.11',
                              'ansible_sunos_sun4': 'k'},
            'run_command_python_interpreter': 'python',
            'run_command_supports_check_mode': False,
            'run_command_supports_shell': False,
            'run_command_uses_shell': False,
            'run_command_working_dir': None}
    distribution_0 = Distribution(dict)
    sunos_facts = distribution_0.get_distribution_SunOS()
    print(sunos_facts)



# Generated at 2022-06-24 23:53:43.564524
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    context = unittest.TestCase()
    assert context is None, 'unittest.TestCase() must have a context so we can capture the stdout and stderr'
    PID = str(os.getpid())
    with tempfile.NamedTemporaryFile(prefix='ansible-test-Distribution-get_distribution_DragonFly'+PID) as tmpfile:
        tmpfile.write(u'/sbin/sysctl -n kern.version\n'.encode('utf-8'))
        tmpfile.write(u'kernel version  = DragonFly v5.2.2-RELEASE\n'.encode('utf-8'))
        tmpfile.flush()
        context.data = tmpfile.name
        context.module = get_module()

# Generated at 2022-06-24 23:53:50.237481
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():

    # If I set distribution, is parsed correctly
    f_class = DistributionFiles()
    f_class.facts['distribution'] = 'Flatcar'
    input_data = 'alpha'
    input_path = '/etc/os-release'
    bool_parsed, p_facts = f_class.parse_distribution_file_Flatcar("flatcar", input_data, input_path, f_class.facts)
    assert bool_parsed, "assert failed - parse_distribution_file_Flatcar - returned False"
    assert p_facts['distribution_release'] == 'alpha', "assert failed - parse_distribution_file_Flatcar - not return correct distribution_release"


# Generated at 2022-06-24 23:53:52.145313
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    dict_0 = {}
    distribution_0 = Distribution(dict_0)
    sunos_facts = distribution_0.get_distribution_SunOS()


# Generated at 2022-06-24 23:54:03.516762
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    file_data_0 = {
        '/etc/os-release': 'NAME="Amazon Linux" VERSION="2" ID="amzn" ID_LIKE="rhel fedora" VERSION_ID="2" PRETTY_NAME="Amazon Linux 2" ANSI_COLOR="0;33" CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2" HOME_URL="https://amazonlinux.com/"',
        '/etc/issue': 'Amazon Linux AMI release 2015.03'
    }
    parsed_0 = {
        'distribution': 'Amazon',
        'distribution_file_path': '/etc/os-release',
        'distribution_file_variety': 'Amazon',
        'distribution_release': 'NA',
        'distribution_version': '2'
    }
    collected_

# Generated at 2022-06-24 23:54:11.190632
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    dict_0 = {}
    distribution_0 = Distribution(dict_0)
    file_path_0 = distribution_0.files_data[0].file_path
    file_path_0 = file_path_0.replace('distribution', 'distribution_file')
    distribution_0.files_data = [DistributionFile(file_path_0, file_path_0, file_path_0)]
    distribution_0.files_data[0].path = '/etc/os-release'
    file_content_0 = get_file_content(file_path_0)
    distribution_0.files_data[0].content = file_content_0
    file_name_0 = distribution_0.files_data[0].file_name
    distribution_0.files_data[0].parse()
    distribution_1 = Distribution

# Generated at 2022-06-24 23:54:16.837758
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    dict_0 = {}
    distribution_0 = Distribution(dict_0)
    rc, out, err = distribution_0.module.run_command("/usr/bin/oslevel")
    data = out.split('.')
    aix_facts = {}
    aix_facts['distribution_major_version'] = data[0]
    if len(data) > 1:
        aix_facts['distribution_version'] = '%s.%s' % (data[0], data[1])
        aix_facts['distribution_release'] = data[1]
    else:
        aix_facts['distribution_version'] = data[0]
    aix_facts_0 = distribution_0.get_distribution_AIX()
    assert aix_facts_0 == aix_facts

# Unit test

# Generated at 2022-06-24 23:54:19.693635
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():

    # This is a test for a method in class Distribution
    dict_0 = {}
    distribution_0 = Distribution(dict_0)
    dict_1 = distribution_0.get_distribution_Darwin()
    assert dict_1['distribution'] == 'MacOSX'
    assert dict_1['distribution_major_version'] == '13'
    assert dict_1['distribution_version'] == '10.9.5'


# Generated at 2022-06-24 23:55:06.610418
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    obj = DistributionFiles()
    name = 'flatcar'
    data = 'flatcar'
    path = 'flatcar'
    collected_facts = DistributionFiles()
    obj.parse_distribution_file_Flatcar(name, data, path, collected_facts)


# Generated at 2022-06-24 23:55:12.355589
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    cmd = "printf 'Amazon Linux' > /root/test/a/amazon-release"
    run_command(cmd)
    cmd = "printf 'Amazon Linux' > /root/test/b/redhat-release"
    run_command(cmd)
    cmd = "printf 'NAME=\"Amazon Linux\"\nVERSION=\"2\"\nID=\"amzn\"\nID_LIKE=\"centos rhel fedora\"\nVERSION_ID=\"2\"\nPRETTY_NAME=\"Amazon Linux 2\"\nANSI_COLOR=\"0;33\"\nCPE_NAME=\"cpe:2.3:o:amazon:amazon_linux:2\"\nHOME_URL=\"https://amazonlinux.com/\"\n' > /root/test/c/os-release"
    run_command(cmd)
    test_obj = DistributionFiles

# Generated at 2022-06-24 23:55:21.134115
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # build up test object
    _obj = DistributionFiles(None, None, None)
    name_0 = 'name'
    data_0 = 'data'
    path_0 = 'path'
    collected_facts_0 = 'collected_facts'

    # call test function
    actual_return_value = _obj.parse_distribution_file_Slackware(name_0, data_0, path_0, collected_facts_0)
    assert actual_return_value == (False,{})

    # build up 2nd test object
    _obj = DistributionFiles(None, None, None)
    name_1 = 'name'
    data_1 = 'Slackware'
    path_1 = 'path'
    collected_facts_1 = 'collected_facts'
    # call test function
    actual_return_

# Generated at 2022-06-24 23:55:22.819507
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    openbsd_facts = Distribution(module).get_distribution_OpenBSD()
    assert f.get_distribution_OpenBSD() == openbsd_facts

# Generated at 2022-06-24 23:55:34.464643
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # globals
    global mock_run_command

    # prepare test data
    name = 'suse'
    path = '<path>'
    collected_facts = {'distribution_version': '12.3'}
    # prepare mocks

    # perform the test
    data = '''
    NAME=openSUSE Leap
    VERSION_ID="15.1"
    VERSION="15.1 (Leap)"
    ID="opensuse-leap"
    ID_LIKE="suse opensuse"
    '''

    expt_result_0 = {'distribution': 'openSUSE Leap', 'distribution_version': '15.1', 'distribution_release': 'leap', 'distribution_major_version': '15'}
    str_0 = DistributionFiles()
    assert str_0.parse

# Generated at 2022-06-24 23:55:37.496343
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    obj = Distribution()
    x = obj.get_distribution_Darwin()
    assertTrue(isinstance(x, dict))


# Generated at 2022-06-24 23:55:45.933725
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if 'Darwin' in get_distribution():
        module.exit_json(skipped=True)

    b_0 = DistributionFiles(module)

    name = str()
    # Unused argument 'path'
    # path = str()

    # Test case with empty data
    data = ''
    p_0 = b_0.parse_distribution_file_Mandriva(name, data)
    assert not p_0, "Expected False but got %s" % p_0

    # Test case with data = 'Mandriva Linux release 2010.0 (Official) for i586'
    data = 'Mandriva Linux release 2010.0 (Official) for i586'

# Generated at 2022-06-24 23:55:56.309596
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # FIXME
    # TEST CASE NOT FINISHED
    tmp = DistributionFiles()
    tmp.module = None

    flatcar_data = '''GROUP=stable
ID=flatcar
VERSION_ID=1298.6.0

'''
    facts_0 = {'path': '/usr/share/oem/flatcar.conf', 'data': flatcar_data, 'name': 'flatcar', 'kernel_name': 'linux'}
    facts_0['distribution'] = 'NA'
    facts_0['distribution_major_version'] = 'NA'
    facts_0['distribution_version'] = 'NA'
    facts_0['distribution_release'] = 'NA'

# Generated at 2022-06-24 23:55:57.405631
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'run_command'


# Generated at 2022-06-24 23:56:00.366047
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule({})
    distribution = Distribution(module)
    assert distribution.get_distribution_HPUX() == {'distribution_release': 'B.11.31', 'distribution_version': 'B.11.31'}

# Generated at 2022-06-24 23:56:46.887490
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    app = DistributionFiles()
    str_0 = 'NAME="Red Hat Enterprise Linux Server"'
    str_1 = 'VERSION="7.2 (Maipo)"'
    str_2 = 'ID="rhel"'
    str_3 = 'ID_LIKE="fedora"'
    str_4 = 'VARIANT="Server"'
    str_5 = 'VARIANT_ID="server"'
    str_6 = 'VERSION_ID="7.2"'
    str_7 = 'PRETTY_NAME="Red Hat Enterprise Linux" VERSION_ID="7.2"'
    str_8 = 'ANSI_COLOR="0;31"'
    str_9 = 'CPE_NAME="cpe:/o:redhat:enterprise_linux:7.2:GA:server"'

# Generated at 2022-06-24 23:56:51.714494
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():

    tmp_platform = platform.release
    platform.release = lambda x : '6.3-STABLE'
    tmp_module = module
    module.run_command = lambda x : (0, 'OpenBSD 6.3-STABLE (GENERIC)', '')

    distribution = Distribution(module)
    distribution.get_distribution_OpenBSD()

    platform.release = tmp_platform
    module = tmp_module



# Generated at 2022-06-24 23:56:55.448916
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # TODO: make this better
    # module = AnsibleModule()
    # hpux_class = Distribution(module)
    # distribution_HPUX = hpux_class.get_distribution_HPUX()
    # print(distribution_HPUX['distribution_version'])
    # print(distribution_HPUX['distribution_release'])
    return None



# Generated at 2022-06-24 23:57:05.578098
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # This should be a valid test, but it is not, because run_command is mocked
    distribution = Distribution(autospec=True)
    assert distribution.get_distribution_SunOS() == {'distribution': 'Solaris', 'distribution_major_version': '10', 'distribution_release': 'Solaris 10 11/06 s10x_u3wos_10 X86', 'distribution_version': '10'}

import platform as python_platform
platform.system.return_value = 'Linux'
platform.release.return_value = '10'
platform.version.return_value = '1'
import re

# Generated at 2022-06-24 23:57:09.596695
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    str_0 = test_case_0()
    distro_files = DistributionFiles(None)
    distro_files.parse_distribution_file_Coreos(str_0, str_0, str_0, str_0)



# Generated at 2022-06-24 23:57:15.146590
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    print("test_Distribution_get_distribution_NetBSD")
    # Note: the class instance will be initialized in the line below
    # Distribution_instance = Distribution()
    # test case
    print("test case 0")
    result = Distribution.get_distribution_NetBSD()
    # verify results
    print("result is: " + str(result))
    assert str(result) == str_0, "Test case 0 failed"


# Generated at 2022-06-24 23:57:25.610318
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-24 23:57:27.167467
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # Tests that we return the SunOS facts
    out = Distribution.get_distribution_SunOS()
    assert out['out'] == 'Out'


# Generated at 2022-06-24 23:57:31.663405
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    arg_0 = 'name'
    arg_1 = 'data'
    arg_2 = 'path'
    arg_3 = 'collected_facts'
    obj = DistributionFiles()
    func_return_value = obj.parse_distribution_file_Slackware(arg_0, arg_1, arg_2, arg_3)
    assert isinstance(func_return_value, (tuple, list))
    assert len(func_return_value) == 2
    assert isinstance(func_return_value[0], bool)
    assert func_return_value[0]
    assert isinstance(func_return_value[1], dict)
    assert func_return_value[1] == {}


# Generated at 2022-06-24 23:57:43.786674
# Unit test for function get_uname
def test_get_uname():
    black_list = []
    if get_uname(module, flags='-i'):
        black_list.append('machine')
    if get_uname(module, flags='-n'):
        black_list.append('nodename')
    if get_uname(module, flags='-r'):
        black_list.append('kernelrelease')
    if get_uname(module, flags='-s'):
        black_list.append('kernel')
    if get_uname(module, flags='-p'):
        black_list.append('processor')
    if get_uname(module, flags='-v'):
        black_list.append('kernelversion')
    if get_uname(module, flags='-m'):
        black_list.append('hardware')

# Generated at 2022-06-24 23:58:19.165894
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    distribution = Distribution(module)
    distribution.get_distribution_FreeBSD()


# Generated at 2022-06-24 23:58:22.522959
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_fixture = DistributionFiles(tempfile.mktemp())
    if not dist_file_fixture.parse_distribution_file_Amazon(str_0, str_1, str_2, str_3):
        raise AssertionError("parse_distribution_file_Amazon method of DistributionFiles class returned False unexpectedly")


# Generated at 2022-06-24 23:58:31.641776
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    str_0 = 'DISTRIB_ID=MandrivaLinux'
    DistributionFiles_0 = DistributionFiles()
    DistributionFiles_0._get_distribution_facts = test_case_0
    DistributionFiles_0._get_uname_info = test_case_0
    DistributionFiles_0.parse_distribution_file = test_case_0
    DistributionFiles_0.run_command = test_case_0
    DistributionFiles_0.get_file_content = test_case_0
    str_1 = 'Mandriva'
    str_2 = '/etc/lsb-release'
    dict_0 = {}
    dict_1 = DistributionFiles_0.parse_distribution_file_Mandriva(str_1, str_0, str_2, dict_0)


# Generated at 2022-06-24 23:58:41.113448
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    test_case = 'test_case_0'

# Generated at 2022-06-24 23:58:50.770301
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    dist = DistributionFiles()
    name = 'CoreOS'
    data = 'GROUP=stable'
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'coreos', 'distribution_version': '1298.7.0'}
    expected_1 = True
    expected_2 = {'distribution_release': 'stable'}
    returned_1, returned_2 = dist.parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert(returned_1 == expected_1)
    assert(returned_2 == expected_2)


# Generated at 2022-06-24 23:58:53.525356
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    print("Test case: OS-Windows-10")
    print("OS-Windows-10 = ", end = "")
    str_0 = 'run_command'


# Generated at 2022-06-24 23:58:58.848741
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    begin_test('DistributionFiles.parse_distribution_file_NA')
    distribution_files = DistributionFiles()

    #test_case_0
    name = 'NA'
    data = ''
    path = ''
    collected_facts = {'distribution_version': 'NA'}
    expected = {'distribution': 'NA', 'distribution_version': 'NA'}
    actual = distribution_files.parse_distribution_file_NA(name, data, path, collected_facts)
    assert actual == expected

    end_test()


# Generated at 2022-06-24 23:59:00.666616
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    mock = Mock()
    mock.run_command = test_case_0

    obj = Distribution(mock)
    obj.get_distribution_OpenBSD()


# Generated at 2022-06-24 23:59:08.920437
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    str_0 = 'Clear Linux'
    instance_0 = ModuleUtil(Module())
    func_0 = DistributionFiles(instance_0)
    ret_0 = func_0.parse_distribution_file_ClearLinux(instance_0, str_0)
    print('ret_0: %s' % ret_0)
    assert ret_0


if __name__ == "__main__":
    test_case_0()
    test_DistributionFiles_parse_distribution_file_ClearLinux()

# Generated at 2022-06-24 23:59:16.450573
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    obj = DistributionFiles()
    name = 'Ubuntu'
    data = 'Ubuntu'
    path = '/etc/os-release'
    collected_facts = {}
    obj.parse_distribution_file_Debian(name, data, path, collected_facts)
    assert 1 == 0


# Generated at 2022-06-24 23:59:56.913738
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    cwd = os.getcwd()
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', required=True),
            name=dict(type='str', required=True),
            path=dict(type='str', required=True)
        ),
        supports_check_mode=False
    )

    if module._name == 'main':
        module.exit_json(changed=False)

    data = module.params['data']
    name = module.params['name']
    path = module.params['path']
    
    collected_facts = dict()
    x = DistributionFiles(module)
    (parsed_dist_file, parsed_dist_file_facts) = x.parse_distribution_file_Amazon(name, data, path, collected_facts)
    assert parsed

# Generated at 2022-06-24 23:59:58.728392
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution = Distribution(module=AnsibleModule(argument_spec=dict()))
    out = distribution.get_distribution_OpenBSD()
    assert out['distribution_release'] == ['6.7']


# Generated at 2022-06-25 00:00:02.037655
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: Implement test case 0
    # TODO: Implement test case 1
    # TODO: Implement test case 2
    # TODO: Implement test case 3
    # TODO: Implement test case 4
    # TODO: Implement test case 5
    # TODO: Implement test case 6
    # TODO: Implement test case 7
    pass


# Generated at 2022-06-25 00:00:06.150295
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Setup
    name = 'Mandriva'
    data = 'Mandriva Linux release 2011.0 (Official) for x86_64'
    path = '/etc/mandriva-release'
    collected_facts = {'distribution_version': 'NA', 'distribution': 'NA'}

    # Invoke method
    DistributionFiles.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    
    # Return type
    return


# Generated at 2022-06-25 00:00:15.883302
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    str_0 = "SLACKWARE\n"
    str_1 = "SLACKWARE\n"
    str_2 = "SLACKWARE\n"
    str_3 = "SLACKWARE\n"
    str_4 = "SLACKWARE\n"
    str_5 = "SLACKWARE\n"
    str_6 = "SLACKWARE\n"
    set_7 = {"Slackware", "SLACKWARE"}
    str_8 = "SLACKWARE\n"
    str_9 = "SLACKWARE\n"
    str_10 = "SLACKWARE\n"
    str_11 = "SLACKWARE\n"
    str_12 = "SLACKWARE\n"
    str_13 = "SLACKWARE\n"
    str_14 = "SLACKWARE\n"
   

# Generated at 2022-06-25 00:00:18.372640
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # No assertion. If reached this point, test passed.
    print('Test passed')


# Generated at 2022-06-25 00:00:21.777175
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    print("Testing get_distribution_SunOS...")

    out = _create_distribution()
    print("%r" % (out,))


# Generated at 2022-06-25 00:00:23.473841
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    obj = Distribution()
    obj.get_distribution_SunOS()


# Generated at 2022-06-25 00:00:31.066813
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    str_0 = 'test_Distribution_get_distribution_OpenBSD'
    str_1 = 'command'
    str_2 = 'sw_vers -productVersion'
    str_3 = 'sw_vers -productVersion'
    str_4 = 'release'
    str_5 = 'release'
    str_6 = 'release'
    str_7 = 'release'
    str_8 = '0.2'
    str_9 = '0.2'
    str_10 = 'command'
    str_11 = '/sbin/sysctl -n kern.version'
    str_12 = '0.1'
    str_13 = '/sbin/sysctl -n kern.version'
    str_14 = '0.2'

# Generated at 2022-06-25 00:00:41.017664
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    test_facts = {}
    test_facts['distribution_release'] = 'NA'
    test_facts['distribution_version'] = 'NA'

    test_case_0_data = read_file_data('distribution_files/suse-release')
    test_case_0_expected_result_0 = True
    test_case_0_expected_result_1 = {'distribution': 'SUSE Linux Enterprise Server', 'distribution_release': '12', 'distribution_version': '12'}
    test_case_0_actual_results = DistributionFiles(None, None).parse_distribution_file_SUSE( 'SLES', test_case_0_data, '/etc/os-release', test_facts )
    assert test_case_0_actual_results[0] == test_case_0_expected_result

# Generated at 2022-06-25 00:01:28.982656
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    try:
        v_0 = DistributionFiles(int_0)
        int_1 = 2632
        v_0.get_distribution_SunOS(int_1)
        return 0
    except:
        return 1


# Generated at 2022-06-25 00:01:32.460602
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = Distribution(int)
    assert isinstance(module, Distribution) is True
    distribution_HPUX = module.get_distribution_HPUX()
    assert distribution_HPUX['distribution_release'] == 'B.11.31.1611'
    assert distribution_HPUX['distribution_version'] == 'B.11.31'


# Generated at 2022-06-25 00:01:33.446303
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    pass


# Generated at 2022-06-25 00:01:40.797413
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    int_0 = 1
    distribution_0 = Distribution(int_0)
    freebsd_facts_0 = distribution_0.get_distribution_FreeBSD()
    assert False


# Generated at 2022-06-25 00:01:48.962725
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # This test should be implemented with the help of a real system
    # Unfortunately, I don't have this possibility.
    test_system = Distribution('test')
    expected = {
        'distribution_release': '0.0',
        'distribution_major_version': '0',
        'distribution_version': '0.0',
    }
    assert test_system.get_distribution_NetBSD() == expected


# Generated at 2022-06-25 00:01:56.797908
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    int_1 = -2135066671
    distribution_files_1 = DistributionFiles(int_1)
    name_1 = "*Z|&#oH+d~r"
    data_1 = "*Z|&#oH+d~r"
    path_1 = "!_bJjm7Rg$b(%QH^"
    collected_facts_1 = {'distribution_version': 'NA', 'distribution_release': 'NA', 'distribution_major_version': 'NA'}
    expected_value_1 = (True, {'distribution': "Clear Linux", 'distribution_version': "31470", 'distribution_release': "clearlinux", 'distribution_major_version': "31470"})

# Generated at 2022-06-25 00:02:06.495468
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # Input parameters
    name_0 = "u1"
    data_0 = "\n    Slackware 15.0\n    "
    path_0 = "/etc/issue"
    collected_facts_0 = {}

    # Expected return value
    output_0 = (True, {'distribution': 'Slackware'})

    # Call the method
    int_0 = 2627
    distribution_files_0 = DistributionFiles(int_0)
    output = distribution_files_0.parse_distribution_file_Slackware(name_0, data_0, path_0, collected_facts_0)
    assert output == output_0


# Generated at 2022-06-25 00:02:11.171450
# Unit test for function get_uname
def test_get_uname():
    distribution_files_obj = DistributionFiles(2627)
    with pytest.raises(AssertionError):
        distribution_files_obj.get_uname(module=2627)


# Generated at 2022-06-25 00:02:20.510070
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    obj = DistributionFiles()
    name = 'Debian'
    data = '''NAME="Debian GNU/Linux"
VERSION_ID="10"
VERSION="10 (buster)"
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
'''
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA'}
    expected_result = (True, {'distribution': 'Debian', 'distribution_version': '10', 'distribution_major_version': '10', 'distribution_minor_version': 'NA'})

# Generated at 2022-06-25 00:02:23.743794
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    int_0 = 2627
    distribution_0 = Distribution(int_0)
    dragonfly_facts_0 = distribution_0.get_distribution_DragonFly()
