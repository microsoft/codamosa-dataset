

# Generated at 2022-06-24 23:53:45.286980
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dist0 = Distribution()

    var0 = dist0.get_distribution_DragonFly()
    print(var0)


# Generated at 2022-06-24 23:53:52.150771
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
  facts = Distribution(None).get_distribution_Darwin()
  assert facts['distribution'] == 'MacOSX'
  assert facts['distribution_major_version'] == '18'
  assert facts['distribution_version'] == '18.7'


# Generated at 2022-06-24 23:53:58.998199
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_facts = {}
    sysinfo = {}
    name = "Slackware"
    data = "Slackware 14.2"
    path = "/tmp/ansible_facts"
    collected_facts = {}
    DistributionFiles(sysinfo).parse_distribution_file_Slackware(name, data, path, collected_facts)

    return True



# Generated at 2022-06-24 23:54:07.148290
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Create an instance of DistributionFiles for testing
    distfiles_0 = DistributionFiles(module_0)
    # Test with name='SUSE'
    name_0 = 'SUSE'
    # Test with data='SUSE Linux Enterprise Server 12 SP3 (x86_64)\nVERSION = 12\nPATCHLEVEL = 3\nVERSION_ID = 12.3\n'
    data_0 = 'SUSE Linux Enterprise Server 12 SP3 (x86_64)\nVERSION = 12\nPATCHLEVEL = 3\nVERSION_ID = 12.3\n'
    # Test with path='/etc/os-release'
    path_0 = '/etc/os-release'
    # Test with collected_facts={'distribution_version': '12.3'}

# Generated at 2022-06-24 23:54:16.063620
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    testCase_1 = DistributionFiles(module=None)

    name_1 = 'clearlinux'

    path_1 = '/etc/default/clear-container-cloud'

    data_1 = 'NAME="Clear Linux"\nID=clear-linux\nID_LIKE=clear-linux\nVERSION="30166"\nVERSION_ID=30166\nPRETTY_NAME="Clear Linux OS"\nANSI_COLOR="1;32"\nHOME_URL="https://clearlinux.org/"\nSUPPORT_URL="https://clearlinux.org/support"\nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"\nPRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy"\nBUILD_ID="30166"\n'

    parsed

# Generated at 2022-06-24 23:54:17.122451
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    # must be tested
    distribution = Distribution(None)
    distribution.get_distribution_HPUX()


# Generated at 2022-06-24 23:54:19.366260
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distributionfiles_class = DistributionFiles(dict())
    assert distributionfiles_class != None
    distributionfiles_class.parse_distribution_file_Amazon("var_0", "var_1", "var_2", "var_3")


# Generated at 2022-06-24 23:54:25.111305
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    dist_file = DistributionFiles()
    distribution_0 = None
    name_0 = 'NA'

# Generated at 2022-06-24 23:54:30.377194
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    os.environ["PATH"] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    distribution_files = DistributionFiles()
    name = 'OpenWrt'
    data = "NAME=\"OpenWrt\"\nID=openwrt\nID_LIKE=lede\nVERSION=\"19.07.3\"\nVERSION_ID=\"19.07.3\"\nPRETTY_NAME=\"OpenWrt 19.07.3\"\nBUILD_ID=\"r11753-86e04e9f46\"\n\n"
    path = '/etc/openwrt_release'
    collected_facts = {}
    distribution_files.parse_distribution_file_OpenWrt(name, data, path, collected_facts)

# Generated at 2022-06-24 23:54:35.862617
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_0 = None
    distributionFiles_0 = DistributionFiles(distribution_0)
    name_0 = 'flatcar'
    data_0 = ''
    path_0 = ''
    collected_facts_0 = {}
    return distributionFiles_0.parse_distribution_file_Flatcar(name_0, data_0, path_0, collected_facts_0)


# Generated at 2022-06-24 23:55:06.232867
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    parsed_name = 'clearlinux'
    parsed_data = 'clearlinux'
    parsed_path = 'clearlinux'
    parsed_collected_facts = 'clearlinux'
    df = DistributionFiles()
    if not isinstance(df.parse_distribution_file_ClearLinux(parsed_name, parsed_data, parsed_path, parsed_collected_facts), tuple):
        raise AssertionError("Return type of parse_distribution_file_ClearLinux is not a tuple")


# Generated at 2022-06-24 23:55:17.225168
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():

    distribution_files = DistributionFiles()

    data = "NAME=\"Clear Linux\"\nVERSION_ID=30000\nID=clear-linux\n"
    path = ""

    collected_facts = {}
    collected_facts['distribution'] = "clearlinux"
    result, result_facts = distribution_files.parse_distribution_file_ClearLinux("clearlinux", data, path, collected_facts)
    assert result
    assert result_facts['distribution'] == "Clear Linux"
    assert result_facts['distribution_release'] == "clear-linux"
    assert result_facts['distribution_major_version'] == "30000"
    assert result_facts['distribution_version'] == "30000"
    assert not result_facts['distribution_release']



# Generated at 2022-06-24 23:55:19.265385
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_1 = None
    var_1 = Distribution(distribution_1).get_distribution_Darwin()


# Generated at 2022-06-24 23:55:25.232642
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    df = DistributionFiles()
    data = """ID=coreos
VERSION=920.2.0
VERSION_ID=920.2.0
BUILD_ID=373.g9d13879.0
PRETTY_NAME="CoreOS 920.2.0 (Classic)"
ANSI_COLOR="38;5;75"
HOME_URL="https://coreos.com/"
BUG_REPORT_URL="https://issues.coreos.com"
COREOS_BOARD=amd64-usr
COREOS_OEM_ID=amd64-usr
COREOS_OEM_NAME="AMD64 Usr"
COREOS_CHANNEL=stable
COREOS_VERSION=920.2.0
COREOS_BRANCH_ID=373.g9d13879.0
GROUP=stable
"""
    result,

# Generated at 2022-06-24 23:55:26.984046
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_0 = Distribution()
    var_0 = distribution_0.get_distribution_OpenBSD()
    assert isinstance(var_0, dict), "Test 0"


# Generated at 2022-06-24 23:55:35.526611
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Create a new DistributionFiles object
    distribution_files_obj = DistributionFiles()

    # Create a new argument object for method parse_distribution_file_NA
    arg0 = None
    arg1 = None
    arg2 = None
    arg3 = None

    # Invoke method parse_distribution_file_NA
    retval = distribution_files_obj.parse_distribution_file_NA(arg0, arg1, arg2, arg3)

    # Output return value from method parse_distribution_file_NA
    print(retval)


# Generated at 2022-06-24 23:55:36.345734
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    pass


# Generated at 2022-06-24 23:55:41.008697
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution_1 = Distribution()
    facts = distribution_1.get_distribution_AIX()
    assert 'distribution_major_version' in facts
    assert 'distribution_version' in facts


# Generated at 2022-06-24 23:55:44.160210
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_1 = Distribution(None)
    dist_facts = distribution_1.get_distribution_SunOS()
    assert 'distribution_version' in dist_facts


# Generated at 2022-06-24 23:55:48.441166
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    hpux_facts = Distribution().get_distribution_HPUX()

    test_case = (hpux_facts)
    print(test_case)

    assert hpux_facts is not None

# Generated at 2022-06-24 23:56:20.158343
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    ansible_0 = DistributionFiles()
    ansible_1 = ansible_0.parse_distribution_file_Amazon('Amazon', 'Amazon Linux AMI release 2017.09', '/etc/system-release-cpe', {})
    assert ansible_1[0] == True
    assert ansible_1[1]['distribution'] == 'Amazon'
    assert ansible_1[1]['distribution_version'] == '2017.09'


# Generated at 2022-06-24 23:56:31.536776
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    test_ansible_module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'data': dict(required=True),
        'path': dict(required=True),
        'collected_facts': dict(required=True)
    })

    distributionFiles_obj = DistributionFiles(test_ansible_module)
    parsed_dist_file_facts = distributionFiles_obj.parse_distribution_file_OpenWrt(
        'name', 'data', 'path', 'collected_facts')

# Generated at 2022-06-24 23:56:42.083354
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
        module = AnsibleModule(
                argument_spec = dict(
                    path = dict(default='/etc/os-release', type='str'),
                ),
                supports_check_mode=True,
        )
        test_input_data_str = """
NAME="Debian GNU/Linux"
VERSION_ID="8"
VERSION="8 (jessie)"
ID=debian
HOME_URL="http://www.debian.org/"
SUPPORT_URL="http://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
"""
        test_input_path_str = "/etc/os-release"
        distribution_file_0 = DistributionFiles(module)

# Generated at 2022-06-24 23:56:45.208163
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    distribution_1 = Distribution(None)
    var_1 = distribution_1.get_distribution_FreeBSD()


# Generated at 2022-06-24 23:56:53.892222
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_0 = None
    name_0 = 'test_string'
    data_0 = 'test_string'
    path_0 = 'test_string'
    collected_facts_0 = {'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1'}
    obj = DistributionFiles(module=None)
    result_var_0, result_var_1 = obj.parse_distribution_file_SUSE(name_0, data_0, path_0, collected_facts_0)
    print(result_var_0, result_var_1)


# Generated at 2022-06-24 23:57:02.391591
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files = DistributionFiles(module=None)
    name = "Amazon"
    data = "NAME=\"Amazon Linux AMI\"\nVERSION=\"2016.09\"\nID=\"amzn\"\nID_LIKE=\"rhel fedora\"\nVERSION_ID=\"2016.09\"\nPRETTY_NAME=\"Amazon Linux AMI 2016.09\"\nANSI_COLOR=\"0;33\"\nCPE_NAME=\"cpe:/o:amazon:linux:2016.09:ga\"\nHOME_URL=\"http://aws.amazon.com/amazon-linux-ami/\"\n\n"
    path = "/etc/os-release"
    collected_facts = {}
    actual_result = distribution_files.parse_distribution_file_Amazon(name, data, path, collected_facts)

# Generated at 2022-06-24 23:57:04.724226
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_1 = None
    distribution_1 = Distribution(distribution_1)
    distribution_1.get_distribution_Darwin()


# Generated at 2022-06-24 23:57:07.556966
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    assert run_module("DistributionFiles", "parse_distribution_file_OpenWrt") is True


# Generated at 2022-06-24 23:57:09.508198
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    assert globals()['get_distribution_NetBSD'] == Distribution.get_distribution_NetBSD


# Generated at 2022-06-24 23:57:13.165968
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution = Distribution(None)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == "SmartOS"
    assert sunos_facts['distribution_version'] == "20150401"


# Generated at 2022-06-24 23:58:05.709167
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    dragonfly_facts = {}
    rc, out, dummy = distribution_0.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        dragonfly_facts['distribution_major_version'] = match.group(1)
        dragonfly_facts['distribution_version'] = '%s.%s.%s' % match.groups()[:3]



# Generated at 2022-06-24 23:58:08.194443
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution = Distribution(None)
    assert 'distribution_version' in distribution.get_distribution_HPUX()
    assert 'distribution_release' in distribution.get_distribution_HPUX()


# Generated at 2022-06-24 23:58:10.220573
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    drfly = Distribution.get_distribution_DragonFly(None)
    assert drfly == None


# Generated at 2022-06-24 23:58:16.499140
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_files = DistributionFiles({})
    name = 'CoreOS'
    data = 'GROUP=stable'
    path = '/etc/lsb-release'
    collected_facts = {'distribution_version': 'NA'}
    expected_result = (True, {'distribution_release': 'stable'})
    result = distribution_files.parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert result == expected_result, 'Test failed'


# Generated at 2022-06-24 23:58:23.694985
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_0 = DistributionFiles()
    name_0 = 'clearlinux'
    data_0 = '''NAME="Clear Linux"
VERSION="32007"
ID=clear-linux
ID_LIKE=fedora
VERSION_ID=32007
PRETTY_NAME="Clear Linux 32007"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:clearlinux:clear-linux:32007"
HOME_URL="https://clearlinux.org/"
SUPPORT_URL="https://clearlinux.org/support"
BUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"'''
    path_0 = ''
    collected_facts_0 = dict()

# Generated at 2022-06-24 23:58:29.831573
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution = Distribution(None)
    print(distribution.get_distribution_SunOS())
    print(distribution.get_distribution_Darwin())

test_case_0()
test_Distribution_get_distribution_SunOS()

# todo: add unit test for Distribution.get_distribution_FreeBSD
# todo: add unit test for Distribution.get_distribution_NetBSD


# Generated at 2022-06-24 23:58:31.917262
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    distribution_obj = Distribution(module)
    distribution_obj.get_distribution_SunOS()


# Generated at 2022-06-24 23:58:41.140453
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles

# Generated at 2022-06-24 23:58:47.715010
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    dist = DistributionFiles()
    data_ = {
        "NAME": "Clear Linux",
        "VERSION_ID": "27620",
        "ID": "clear-linux-os",
        "VERSION_CODENAME": "",
        "PRETTY_NAME": "Clear Linux OS 27620"
    }
    path_ = '/etc/os-release'
    data = ""
    for name, value in data_.items():
        data += "{}=\"{}\"\n".format(name, value)

    facts = {
        'distribution': 'Clear Linux',
        'distribution_release': 'NA',
        'distribution_version': 'NA'
    }
    _status, var_0 = dist.parse_distribution_file_ClearLinux(
        'Clear Linux', data, path_, facts)

#

# Generated at 2022-06-24 23:58:49.764482
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_1 = Distribution(module='module')
    distribution_1.get_distribution_OpenBSD()


# Generated at 2022-06-24 23:59:15.506286
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution_1 = None
    distfunc = getattr(Distribution, 'get_distribution_Darwin')
    distfunc(distribution_1)


# Generated at 2022-06-24 23:59:16.410404
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    test_case_0()


# Generated at 2022-06-24 23:59:19.719675
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # Unit test for method get_distribution_DragonFly() of class Distribution

    distribution_0 = Distribution()
    setattr(distribution_0, 'module', 'AnsibleModule')
    dict_0 = distribution_0.get_distribution_DragonFly()
    assert dict_0 != {}



# Generated at 2022-06-24 23:59:21.222945
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    test_module = None
    instance = Distribution(test_module)
    assert None == instance.get_distribution_AIX()


# Generated at 2022-06-24 23:59:32.100595
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_0 = "Flatcar"
    data_0 = """
    # cloud-config
    coreos:
      update:
        reboot-strategy: off
    """
    path_0 = "/etc/coreos/update.conf"
    collected_facts_0 = {
        "distribution_release": "NA"
    }
    inst_0 = DistributionFiles([], {})
    (res_0, flatcar_facts_0) = inst_0.parse_distribution_file_Flatcar(distribution_0, data_0, path_0, collected_facts_0)


# Generated at 2022-06-24 23:59:37.961568
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_0 = 'clearlinux'
    name_0 = 'clear-linux-os'
    data_0 = 'NAME="Clear Linux OS"'
    path_0 = '/usr/lib/os-release'
    collected_facts_0 = {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    ret = DistributionFiles.parse_distribution_file_ClearLinux(distribution_0, name_0, data_0, path_0, collected_facts_0)


# Generated at 2022-06-24 23:59:44.079412
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    distribution_0 = None
    openbsd_facts = {'distribution_version': '6.1', 'distribution_release': 'amd64'}
    assert Distribution(distribution_0).get_distribution_OpenBSD() == openbsd_facts


# Generated at 2022-06-24 23:59:53.645201
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    distribution_0 = None
    # Call method parse_distribution_file_ClearLinux of DistributionFiles
    distribution_files_0 = DistributionFiles(distribution_0)
    distribution_file_name_0 = string_generator()
    distribution_file_contents_0 = string_generator()
    distribution_file_path_0 = string_generator()
    distribution_file_facts_0 = {'NA': string_generator()}
    return_value_1 = distribution_files_0.parse_distribution_file_ClearLinux(distribution_file_name_0, distribution_file_contents_0, distribution_file_path_0, distribution_file_facts_0)
    assert return_value_1 == (False, {})


# Generated at 2022-06-25 00:00:02.642634
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution_1 = 'coreos'
    data_1 = ['GROUP=1234.1.0']
    path_1 = ''
    collected_facts_1 = {'distribution_release': 'NA'}
    var_1 = get_uname(distribution_1)
    var_2 = parse_distribution_file_Coreos(data_1, path_1, collected_facts_1, var_1)
    print(var_2)


# Generated at 2022-06-25 00:00:12.637860
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-25 00:01:24.572818
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    obj_DistributionFiles = DistributionFiles("ansible_collected_facts", "raw_content", "path")
    obj_DistributionFiles.parse_distribution_file_Mandriva("name", "data", "path", "collected_facts")
    # No exception
    return True


# Generated at 2022-06-25 00:01:28.800686
# Unit test for method get_distribution_OpenBSD of class Distribution

# Generated at 2022-06-25 00:01:31.507903
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():

    distribution_files_obj = DistributionFiles()
    # Run test case
    test_case_0()


# Generated at 2022-06-25 00:01:39.377368
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    DistributionFiles = class_for_name("ansible.module_utils.facts.system.distribution.DistributionFiles", globals())

    name_0 = 'name_0'
    data_0 = 'Debian'
    path_0 = '/etc/os-release'
    collected_facts_0 = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    test_return = DistributionFiles.parse_distribution_file_Debian(name_0, data_0, path_0, collected_facts_0)
    assert isinstance(test_return, tuple)
    assert test_return[0] == True
    assert isinstance(test_return[1], dict)



# Generated at 2022-06-25 00:01:47.343507
# Unit test for function get_uname
def test_get_uname():
    from ansible.module_utils.facts.machine import get_uname
    distribution_1 = '-'
    var_1 = get_uname(distribution_1)
    distribution_2 = '-'
    var_2 = get_uname(distribution_2, flags='-s')
    v = "Other"
    if var_2 == "FreeBSD":
        v = "FreeBSD"
    if v in ["FreeBSD", "Linux"]:
        var_3 = get_uname(distribution_2, flags='-r')
    distribution_4 = '-'
    v = "Other"
    if var_2 == "AIX":
        v = "AIX"
    if v == "AIX":
        var_4 = get_uname(distribution_4, flags='-v')
    distribution_5

# Generated at 2022-06-25 00:01:48.506229
# Unit test for function get_uname
def test_get_uname():
    test_case_0()

# Test function get_uname with data from file

# Generated at 2022-06-25 00:01:52.644854
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_0 = None
    var_0 = DistributionFiles(distribution_0)
    var_0.parse_distribution_file_NA('NA', 'some text', None, None)


# Generated at 2022-06-25 00:02:04.760570
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    with patch('os.path.isfile', return_value=False):
        distFiles = DistributionFiles()
        distFiles.module = AnsibleModuleMock()

        distribution_0 = None
        path_0 = "/etc/os-release"
        data_0 = "ID=openwrt\nID_LIKE=lede\nPRETTY_NAME=\"OpenWrt Chaos Calmer 15.05\"\nVERSION_ID=\"15.05\"\nDISTRIB_RELEASE=\"15.05\"\nDISTRIB_CODENAME=\"chaos_calmer\"\nDISTRIB_TARGET=\"ramips/rt305x\"\nDISTRIB_DESCRIPTION=\"OpenWrt Chaos Calmer 15.05\"\nDISTRIB_TAINTS=\n"
        parsed_dist_file, parsed_dist_facts = dist

# Generated at 2022-06-25 00:02:14.625700
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    from ansible.module_utils.facts.system.distribution import Distribution
    distribution_0 = Distribution(None)

    # Creation of the mock object Distribution_0
    Distribution_0 = Mock()

    # Call method
    result_0 = distribution_0.get_distribution_Darwin()

    # Assertions
    assert result_0 == {
        'distribution': 'MacOSX', 'distribution_major_version': '16', 'distribution_version': '16.7.0'
    }

    # Creation of the mock object distribution_0
    distribution_0 = Mock()

    # Call method
    result_1 = distribution_0.get_distribution_Darwin()

    # Assertions

# Generated at 2022-06-25 00:02:15.647459
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    test_case_0()    
