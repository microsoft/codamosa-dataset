

# Generated at 2022-06-17 01:56:13.784492
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'clearlinux'
    data = 'NAME="Clear Linux" VERSION_ID=25000 ID=clear-linux-os'
    path = '/etc/os-release'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}
    parsed_dist_file, parsed_dist_file_facts = dist_files.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    assert parsed_dist_file is True
    assert parsed_dist_file_facts['distribution'] == 'Clear Linux'
    assert parsed_dist_file_facts['distribution_version'] == '25000'
    assert parsed_dist_file_facts['distribution_major_version']

# Generated at 2022-06-17 01:56:15.541023
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # TODO: implement test
    pass


# Generated at 2022-06-17 01:56:21.490783
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_obj = DistributionFiles()
    test_obj.module = AnsibleModuleMock()
    test_obj.module.run_command = run_command_mock
    test_obj.module.get_bin_path = get_bin_path_mock
    test_obj.module.get_file_content = get_file_content_mock
    test_obj.module.get_file_lines = get_file_lines_mock
    test_obj.module.get_platform_subclass = get_platform_subclass_mock
    test_obj.module.get_distribution = get_distribution_mock
    test_obj.module.get_distribution_version = get_distribution_version_mock
    test_obj.module.get_distribution_release = get_distribution_release_mock


# Generated at 2022-06-17 01:56:26.048176
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: add unit tests
    pass


# Generated at 2022-06-17 01:56:27.489330
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:56:34.830052
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Test with valid data
    data = '''NAME="Mandriva Linux"
VERSION="2010.0 (Official) - Spring"
ID=mandriva
VERSION_ID=2010.0
PRETTY_NAME="Mandriva Linux 2010.0 (Official) - Spring"
ANSI_COLOR="1;31"
CPE_NAME="cpe:/o:mandriva:linux:2010.0:spring"
HOME_URL="http://www.mandriva.com/"
SUPPORT_URL="http://www.mandriva.com/en/support"
BUG_REPORT_URL="http://qa.mandriva.com/"
'''
    name = 'Mandriva'
    path = '/etc/mandriva-release'

# Generated at 2022-06-17 01:56:39.222204
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    facts = dist.get_distribution_OpenBSD()
    assert facts['distribution_release'] == platform.release()
    assert facts['distribution_version'] == platform.release()
    assert facts['distribution'] == 'OpenBSD'



# Generated at 2022-06-17 01:56:51.731028
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Test for SLES
    data = '''
NAME="SLES"
VERSION="12-SP2"
VERSION_ID="12.2"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp2"
'''
    path = '/etc/os-release'
    name = 'SUSE'
    collected_facts = {'distribution_version': '12.2', 'distribution_release': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert dist_file_facts['distribution'] == 'SLES'

# Generated at 2022-06-17 01:56:53.216493
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 01:57:02.463164
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles

# Generated at 2022-06-17 01:57:30.551405
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: implement test
    pass


# Generated at 2022-06-17 01:57:35.591571
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 01:57:37.613556
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # TODO: add unit test
    pass

# Generated at 2022-06-17 01:57:46.823382
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-17 01:57:47.818787
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:57:51.355510
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 01:57:59.505213
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Test with CentOS Stream
    data = 'NAME="CentOS Stream"'
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', data, '/etc/os-release', {})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1]['distribution_release'] == 'Stream'

    # Test with CentOS
    data = 'NAME="CentOS"'
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', data, '/etc/os-release', {})
    assert dist_file_facts[0] == False
    assert dist_file_facts[1] == {}


# Generated at 2022-06-17 01:58:12.210450
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    dist_files = DistributionFiles()
    data = 'GROUP=stable'
    path = '/usr/share/coreos/lsb-release'
    collected_facts = {'distribution': 'Flatcar', 'distribution_release': 'NA'}
    name = 'Flatcar'
    parsed_dist_file, parsed_dist_file_facts = dist_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert parsed_dist_file is True
    assert parsed_dist_file_facts['distribution_release'] == 'stable'

# Generated at 2022-06-17 01:58:22.432823
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Test with a valid Clear Linux distribution file
    name = 'clearlinux'
    data = 'NAME="Clear Linux OS"\nVERSION="27000"\nID=clearlinux\nVERSION_ID=27000\nPRETTY_NAME="Clear Linux OS 27000"\nANSI_COLOR="1;32"\nCPE_NAME="cpe:/o:clearlinux:clear_linux:27000"\nHOME_URL="https://clearlinux.org/"\nSUPPORT_URL="https://clearlinux.org/support"\nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"\nPRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy"\nBUILD_ID="27000"\n'
    path = '/etc/os-release'
   

# Generated at 2022-06-17 01:58:27.388544
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.15.7'


# Generated at 2022-06-17 01:59:07.645594
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 01:59:09.754773
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: add unit test
    pass


# Generated at 2022-06-17 01:59:16.841702
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_release'] == platform.release()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution'] == 'OpenBSD'


# Generated at 2022-06-17 01:59:18.149779
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:59:27.746493
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    df = DistributionFiles(module)
    data = '''
# This file is auto-generated by coreos-metadata
GROUP=stable
VERSION=1235.9.0
ID=coreos
VERSION_ID=1235.9.0
BUILD_ID=
PRETTY_NAME="CoreOS 1235.9.0 (Coeur Rouge)"
ANSI_COLOR="38;5;75"
HOME_URL="https://coreos.com/"
BUG_REPORT_URL="https://issues.coreos.com/"
COREOS_BOARD=amd64-usr
'''
    name = 'CoreOS'
    path = '/etc/os-release'

# Generated at 2022-06-17 01:59:32.774024
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_OpenBSD()
    assert distribution_facts['distribution_version'] == '6.5'
    assert distribution_facts['distribution_release'] == 'stable'


# Generated at 2022-06-17 01:59:36.469717
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    assert netbsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert netbsd_facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 01:59:41.641416
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_facts()

    assert distribution_facts['distribution'] == platform.system()
    assert distribution_facts['distribution_release'] == platform.release()
    assert distribution_facts['distribution_version'] == platform.version()
    assert distribution_facts['os_family'] == distribution.OS_FAMILY.get(distribution_facts['distribution'], None) or distribution_facts['distribution']



# Generated at 2022-06-17 01:59:54.184563
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_files = DistributionFiles()
    name = 'Amazon'
    data = 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path = '/etc/os-release'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}

# Generated at 2022-06-17 01:59:58.626006
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution_release'] == 'release'


# Generated at 2022-06-17 02:00:33.927505
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:00:40.606787
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Test for CentOS Stream
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
    assert dist_file_facts == (True, {'distribution_release': 'Stream'})

    # Test for CentOS
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS', '/etc/os-release', {})
    assert dist_file_facts == (False, {})



# Generated at 2022-06-17 02:00:41.970072
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: write unit test for method parse_distribution_file_Debian of class DistributionFiles
    pass


# Generated at 2022-06-17 02:00:43.712402
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: FIXME: test this method
    pass


# Generated at 2022-06-17 02:00:55.139596
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles

# Generated at 2022-06-17 02:00:56.212074
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: implement test
    pass


# Generated at 2022-06-17 02:00:57.779698
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: FIXME: add unit tests
    pass


# Generated at 2022-06-17 02:01:01.684325
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:01:05.414659
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    assert netbsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert netbsd_facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 02:01:13.308141
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distro_files = DistributionFiles()
    name = 'Flatcar'
    data = 'GROUP=stable'
    path = '/etc/flatcar/release'
    collected_facts = {}
    expected_result = (True, {'distribution_release': 'stable'})
    result = distro_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result == expected_result


# Generated at 2022-06-17 02:01:58.769071
# Unit test for method process_dist_files of class DistributionFiles

# Generated at 2022-06-17 02:02:06.379138
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    dist_facts = dist.get_distribution_DragonFly()
    assert dist_facts['distribution_release'] == platform.release()
    assert dist_facts['distribution_version'] == '4.8.1'
    assert dist_facts['distribution_major_version'] == '4'


# Generated at 2022-06-17 02:02:13.459849
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    expected = {
        'distribution_release': '6.3',
        'distribution_version': '6.3'
    }
    actual = dist.get_distribution_OpenBSD()
    assert actual == expected


# Generated at 2022-06-17 02:02:19.137233
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160308T180133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20160308T180133Z joyent_20160308T180133Z'
    assert sunos_facts['distribution_major_version'] == '5'



# Generated at 2022-06-17 02:02:29.534364
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # test for Debian
    data = '''
    PRETTY_NAME="Debian GNU/Linux 8 (jessie)"
    NAME="Debian GNU/Linux"
    VERSION_ID="8"
    VERSION="8 (jessie)"
    ID=debian
    HOME_URL="http://www.debian.org/"
    SUPPORT_URL="http://www.debian.org/support"
    BUG_REPORT_URL="https://bugs.debian.org/"
    '''
    path = '/etc/os-release'
    name = 'Debian'
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_Debian(name, data, path, collected_facts)
    assert dist_file

# Generated at 2022-06-17 02:02:36.118382
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.2'
    assert aix_facts['distribution_release'] == '2'


# Generated at 2022-06-17 02:02:44.295077
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 02:02:45.214476
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:02:48.994261
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: FIXME: split distro file parsing into its own module or class
    dist_file_facts = DistributionFiles().parse_distribution_file_Slackware('Slackware', 'Slackware 14.2', '/etc/slackware-version', {})
    assert dist_file_facts['distribution'] == 'Slackware'
    assert dist_file_facts['distribution_version'] == '14.2'


# Generated at 2022-06-17 02:02:53.954348
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    assert freebsd_facts['distribution'] == 'FreeBSD'
    assert freebsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert freebsd_facts['distribution_version'] == '.'.join(platform.release().split('.')[:2])


# Generated at 2022-06-17 02:03:50.496659
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:03:56.087288
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # Test with DragonFlyBSD
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    dragonfly_facts = distribution.get_distribution_DragonFly()
    assert dragonfly_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dragonfly_facts['distribution_major_version'] == match.group(1)
        assert dragonfly_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]
    # Test with Gentoo/DragonFly

# Generated at 2022-06-17 02:04:02.101186
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    assert freebsd_facts['distribution'] == 'FreeBSD'
    assert freebsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert freebsd_facts['distribution_version'] == platform.release().split('-')[0]


# Generated at 2022-06-17 02:04:05.246759
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 02:04:08.526147
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution_release'] == 'release'


# Generated at 2022-06-17 02:04:10.053109
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(None) == None


# Generated at 2022-06-17 02:04:15.317314
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec=dict())
    dist = Distribution(module)
    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20180309T180133Z'
    assert sunos_facts['distribution_release'] == 'joyent_20180309T180133Z'
    assert sunos_facts['distribution_major_version'] == '11'



# Generated at 2022-06-17 02:04:17.743812
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 02:04:19.538171
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:04:22.967511
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_DragonFly() == {'distribution_release': '5.8-RELEASE'}


# Generated at 2022-06-17 02:05:25.207043
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Setup
    dist_files = DistributionFiles()
    name = 'Amazon'
    data = 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path = '/etc/os-release'

# Generated at 2022-06-17 02:05:27.807562
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement this
    pass


# Generated at 2022-06-17 02:05:31.986171
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '11'
    assert sunos_facts['distribution_release'] == 'Oracle Solaris 11.4'
    assert sunos_facts['distribution_major_version'] == '11'

