

# Generated at 2022-06-17 01:56:24.093718
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 01:56:29.007894
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 01:56:36.980095
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 01:56:46.601176
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160308T180105Z'
    assert sunos_facts['distribution_release'] == 'joyent_20160308T180105Z'
    assert sunos_facts['distribution_major_version'] == '5.11'



# Generated at 2022-06-17 01:56:49.751425
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_OpenBSD() == {'distribution_version': '6.6', 'distribution_release': 'amd64'}


# Generated at 2022-06-17 01:56:59.853727
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    dist_files = DistributionFiles()

# Generated at 2022-06-17 01:57:09.913898
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '11.4'
    assert sunos_facts['distribution_release'] == '11.4'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 01:57:17.400393
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles

# Generated at 2022-06-17 01:57:28.820416
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Test with valid data
    data = '''NAME="Mandriva Linux"
VERSION="2010.1 (Official) - Spring"
ID=mandriva
VERSION_ID=2010.1
PRETTY_NAME="Mandriva Linux 2010.1 (Official) - Spring"
ANSI_COLOR="1;31"
CPE_NAME="cpe:/o:mandriva:linux:2010.1:spring"
HOME_URL="http://www.mandriva.com/"
SUPPORT_URL="http://www.mandriva.com/en/support"
BUG_REPORT_URL="http://qa.mandriva.com/"
'''
    name = 'Mandriva'
    path = '/etc/mandriva-release'

# Generated at 2022-06-17 01:57:31.795256
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    facts = dist.get_distribution_Darwin()
    assert facts['distribution'] == 'MacOSX'
    assert facts['distribution_major_version'] == '10'
    assert facts['distribution_version'] == '10.12.6'



# Generated at 2022-06-17 01:58:00.834962
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    facts = dist.get_distribution_FreeBSD()
    assert facts['distribution_release'] == platform.release()
    assert facts['distribution'] == 'FreeBSD'
    assert facts['distribution_major_version'] == platform.release().split('.')[0]
    assert facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 01:58:03.562771
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: add unit test
    pass


# Generated at 2022-06-17 01:58:12.081083
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distro_files = DistributionFiles()
    name = 'Flatcar'
    data = 'GROUP=stable'
    path = '/etc/flatcar/release'
    collected_facts = {}
    expected_result = True, {'distribution_release': 'stable'}
    result = distro_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result == expected_result


# Generated at 2022-06-17 01:58:13.128633
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:58:19.391407
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    darwin_facts = dist.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.12.6'



# Generated at 2022-06-17 01:58:26.016979
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    assert freebsd_facts['distribution'] == 'FreeBSD'
    assert freebsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert freebsd_facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 01:58:33.862375
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    openbsd_facts = dist.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution_release'] == 'release'


# Generated at 2022-06-17 01:58:41.415582
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '11'
    assert sunos_facts['distribution_release'] == '11.4'
    assert sunos_facts['distribution_major_version'] == '11'



# Generated at 2022-06-17 01:58:53.448863
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Test with empty data
    data = ''
    name = 'NA'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_NA(name, data, path, collected_facts)
    assert dist_file_facts == (True, {'distribution': 'NA', 'distribution_version': 'NA'})

    # Test with data
    data = 'NAME="NA"\nVERSION="NA"'
    name = 'NA'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_NA(name, data, path, collected_facts)
    assert dist_file_

# Generated at 2022-06-17 01:58:59.613512
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_FreeBSD()['distribution_release'] == platform.release()


# Generated at 2022-06-17 01:59:22.005063
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement test
    pass


# Generated at 2022-06-17 01:59:25.872950
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution_release'] == 'release'


# Generated at 2022-06-17 01:59:30.622505
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    assert dist.get_distribution_HPUX() == {'distribution_version': 'B.11.31', 'distribution_release': '1588'}


# Generated at 2022-06-17 01:59:34.691511
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 01:59:44.294607
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_facts = DistributionFiles()
    name = 'Slackware'
    data = 'Slackware 14.2'
    path = '/etc/slackware-version'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}
    parsed_dist_file_facts = dist_file_facts.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed_dist_file_facts[0] == True
    assert parsed_dist_file_facts[1]['distribution'] == 'Slackware'
    assert parsed_dist_file_facts[1]['distribution_version'] == '14.2'


# Generated at 2022-06-17 01:59:48.918475
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_SunOS() == {'distribution': 'SmartOS', 'distribution_release': 'SmartOS 16.9.0', 'distribution_version': '16.9.0'}


# Generated at 2022-06-17 01:59:58.824554
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 02:00:06.103352
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    assert dist.get_distribution_AIX() == {'distribution_major_version': '7', 'distribution_version': '7.1', 'distribution_release': '1'}


# Generated at 2022-06-17 02:00:14.262536
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Test for CentOS Stream
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
    assert dist_file_facts['distribution_release'] == 'Stream'
    # Test for CentOS
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS', '/etc/os-release', {})
    assert dist_file_facts['distribution_release'] == 'NA'


# Generated at 2022-06-17 02:00:21.946398
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 02:01:07.839907
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: mock data
    pass


# Generated at 2022-06-17 02:01:12.680998
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:01:20.373039
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    dragonfly_facts = dist.get_distribution_DragonFly()
    assert dragonfly_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dragonfly_facts['distribution_major_version'] == match.group(1)
        assert dragonfly_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]


# Generated at 2022-06-17 02:01:27.315544
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20180309T180133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20180309T180133Z joyent_20180309T220133Z'
    assert sunos_facts['distribution_major_version'] == '11'



# Generated at 2022-06-17 02:01:34.343972
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'OpenWrt'
    data = '''
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=18.06.4
DISTRIB_REVISION=r7676-cddd7b4c77
DISTRIB_CODENAME=reboot
DISTRIB_TARGET=ramips/mt7621
DISTRIB_DESCRIPTION="OpenWrt 18.06.4 r7676-cddd7b4c77"
DISTRIB_TAINTS=no-all
'''
    path = '/etc/openwrt_release'

# Generated at 2022-06-17 02:01:39.223664
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'



# Generated at 2022-06-17 02:01:45.086968
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:01:52.564327
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 02:01:56.522789
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    dist_facts = dist.get_distribution_AIX()
    assert dist_facts['distribution_major_version'] == '7'
    assert dist_facts['distribution_version'] == '7.2'
    assert dist_facts['distribution_release'] == '2'


# Generated at 2022-06-17 02:01:58.325860
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:02:55.798639
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 02:03:04.456175
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    dist_file_facts = DistributionFiles().parse_distribution_file_Mandriva('Mandriva', 'DISTRIB_ID=MandrivaLinux\nDISTRIB_RELEASE=2010.0\nDISTRIB_CODENAME=Henry\nDISTRIB_DESCRIPTION="Mandriva Linux 2010.0"\n', '/etc/lsb-release', {})
    assert dist_file_facts == (True, {'distribution': 'Mandriva', 'distribution_version': '2010.0', 'distribution_release': 'Henry'})


# Generated at 2022-06-17 02:03:11.821073
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.15.4'


# Generated at 2022-06-17 02:03:14.779014
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:03:20.967881
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Test for SLES
    data = '''
NAME="SLES"
VERSION="12-SP3"
VERSION_ID="12.3"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP3"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp3"
'''
    dist_file_facts = DistributionFiles().parse_distribution_file_SUSE('SUSE', data, '/etc/os-release', {})
    assert dist_file_facts['distribution'] == 'SLES'
    assert dist_file_facts['distribution_release'] == 'SP3'
    assert dist_file_facts['distribution_version'] == '12.3'

    # Test for SLES for SAP

# Generated at 2022-06-17 02:03:27.490861
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20170705T221133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20170705T221133Z joyent_20170705T221133Z'
    assert sunos_facts['distribution_major_version'] == '11'



# Generated at 2022-06-17 02:03:37.440887
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # Test with a valid file
    test_file = '/usr/share/defaults/coreos/update.conf'
    test_data = 'GROUP=stable'
    test_name = 'Flatcar'
    test_path = '/etc/os-release'
    test_collected_facts = {'distribution': 'Flatcar', 'distribution_release': 'NA', 'distribution_version': 'NA'}
    test_flatcar_facts = {'distribution_release': 'stable'}
    test_dist_file_facts = {'distribution_file_path': test_path, 'distribution_file_variety': test_name, 'distribution_file_parsed': True}
    test_dist_file_facts.update(test_flatcar_facts)
    test_dist_file_facts.update

# Generated at 2022-06-17 02:03:44.040604
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.2'
    assert aix_facts['distribution_release'] == '2'


# Generated at 2022-06-17 02:03:48.841433
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 02:03:52.889304
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    assert netbsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert netbsd_facts['distribution_version'] == platform.release()
