

# Generated at 2022-06-17 01:56:35.777574
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 01:56:39.389674
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    assert dist.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.15.4'}


# Generated at 2022-06-17 01:56:40.722522
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: write unit tests
    pass


# Generated at 2022-06-17 01:56:50.306315
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20170705T181133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20170705T181133Z joyent_20170705T181133Z'
    assert sunos_facts['distribution_major_version'] == '5'


# Generated at 2022-06-17 01:56:57.020171
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_files = DistributionFiles()
    name = 'CentOS'
    data = 'CentOS Stream'
    path = '/etc/centos-release'
    collected_facts = {'distribution_release': 'NA'}
    expected_result = (True, {'distribution_release': 'Stream'})
    result = distribution_files.parse_distribution_file_CentOS(name, data, path, collected_facts)
    assert result == expected_result



# Generated at 2022-06-17 01:56:58.294944
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 01:57:02.495529
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'flatcar'
    data = 'GROUP=stable'
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA'}
    expected_result = {'distribution_release': 'stable'}
    result = dist_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result[1] == expected_result


# Generated at 2022-06-17 01:57:09.352457
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles

# Generated at 2022-06-17 01:57:17.247587
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # Test with empty data
    dist_file_facts = DistributionFiles().parse_distribution_file_Flatcar('flatcar', '', '', {})
    assert dist_file_facts[0] == False
    assert dist_file_facts[1] == {}

    # Test with valid data
    dist_file_facts = DistributionFiles().parse_distribution_file_Flatcar('flatcar', 'GROUP="stable"', '', {})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1] == {'distribution_release': 'stable'}


# Generated at 2022-06-17 01:57:23.608257
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_FreeBSD()
    assert distribution_facts['distribution'] == 'FreeBSD'
    assert distribution_facts['distribution_release'] == platform.release()
    assert distribution_facts['distribution_version'] == platform.release()
    assert distribution_facts['distribution_major_version'] == platform.release().split('.')[0]


# Generated at 2022-06-17 01:58:05.181314
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160606T002709Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20160606T002709Z joyent_20160606T002709Z'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 01:58:14.440974
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    # Test Debian
    data = '''
PRETTY_NAME="Debian GNU/Linux 9 (stretch)"
NAME="Debian GNU/Linux"
VERSION_ID="9"
VERSION="9 (stretch)"
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
'''
    name = 'Debian'
    path = '/etc/os-release'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}

# Generated at 2022-06-17 01:58:23.812159
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Test with CentOS Stream
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1]['distribution_release'] == 'Stream'

    # Test with CentOS
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS', '/etc/os-release', {})
    assert dist_file_facts[0] == False
    assert dist_file_facts[1] == {}

    # Test with CentOS Stream
    dist_file_facts = DistributionFiles().parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
    assert dist_file_

# Generated at 2022-06-17 01:58:24.666914
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: add test for this method
    pass

# Generated at 2022-06-17 01:58:35.276175
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_facts = DistributionFiles()
    name = 'Slackware'
    data = 'Slackware 14.2'
    path = '/etc/slackware-version'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}
    parsed_dist_file_facts = dist_file_facts.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed_dist_file_facts['distribution'] == 'Slackware'
    assert parsed_dist_file_facts['distribution_version'] == '14.2'


# Generated at 2022-06-17 01:58:36.459594
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:58:41.869097
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_release'] == platform.release()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution'] == 'OpenBSD'


# Generated at 2022-06-17 01:58:42.840128
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: add tests
    pass


# Generated at 2022-06-17 01:58:43.969441
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:58:48.275675
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Test with a valid file
    test_data = 'NAME="Clear Linux"\nVERSION_ID=25000\nID=clear-linux-os\nVERSION="25000 (Ootpa)"\nID_LIKE=fedora\n'
    test_path = '/etc/os-release'
    test_name = 'clearlinux'
    test_collected_facts = {}
    test_collected_facts['distribution_release'] = 'NA'
    test_collected_facts['distribution_version'] = 'NA'
    test_collected_facts['distribution'] = 'NA'
    test_collected_facts['distribution_major_version'] = 'NA'
    test_distribution_files = DistributionFiles()

# Generated at 2022-06-17 02:00:07.176314
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Test with a valid file
    name = 'Mandriva'
    data = '''NAME="Mandriva Linux"
VERSION="2011.0"
ID=mandriva
VERSION_ID=2011.0
PRETTY_NAME="Mandriva Linux 2011.0"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:mandriva:linux:2011.0:community"
HOME_URL="http://www.mandriva.com/"
BUG_REPORT_URL="http://qa.mandriva.com/"
'''
    path = '/etc/lsb-release'
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    distribution_files = DistributionFiles()

# Generated at 2022-06-17 02:00:18.652956
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Create an instance of DistributionFiles
    dist_files = DistributionFiles()
    # Create a mock of collected_facts
    collected_facts = {}
    # Create a mock of data

# Generated at 2022-06-17 02:00:29.322099
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    data = re.search(r'(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT|RC|PRERELEASE).*', freebsd_facts['distribution_release'])
    if data:
        assert freebsd_facts['distribution_major_version'] == data.group(1)
        assert freebsd_facts['distribution_version'] == '%s.%s' % (data.group(1), data.group(2))


# Generated at 2022-06-17 02:00:40.298676
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Test with empty data
    data = ''
    name = 'Debian'
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA'}
    distribution_files = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = distribution_files.parse_distribution_file_Debian(name, data, path, collected_facts)
    assert parsed_dist_file is False
    assert parsed_dist_file_facts == {}

    # Test with Debian data

# Generated at 2022-06-17 02:00:44.881969
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_release'] == platform.release()
    assert openbsd_facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 02:00:55.706233
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'Slackware'
    data = 'Slackware 14.2'
    path = '/etc/slackware-version'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}
    parsed_dist_file, parsed_dist_file_facts = dist_files.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed_dist_file
    assert parsed_dist_file_facts['distribution'] == 'Slackware'
    assert parsed_dist_file_facts['distribution_version'] == '14.2'


# Generated at 2022-06-17 02:01:00.894408
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '1493'


# Generated at 2022-06-17 02:01:15.175662
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    collected_facts = {'distribution_version': '13.2'}
    name = 'SUSE'
    data = '''openSUSE 13.2 (x86_64)
VERSION = 13.2
CODENAME = Harlequin
# /etc/SuSE-release is deprecated and will be removed in the future, use /etc/os-release instead
'''
    path = '/etc/SuSE-release'
    parsed_dist_file, parsed_dist_file_facts = dist_files.parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert parsed_dist_file is True
    assert parsed_dist_file_facts['distribution'] == 'openSUSE'
    assert parsed

# Generated at 2022-06-17 02:01:17.047756
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement test
    pass


# Generated at 2022-06-17 02:01:18.440253
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: test this method
    pass


# Generated at 2022-06-17 02:02:27.724565
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:02:30.827804
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    assert dist.get_distribution_OpenBSD() == {'distribution_version': '6.6', 'distribution_release': 'amd64'}


# Generated at 2022-06-17 02:02:41.690108
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Test for SLES
    data = """
NAME="SLES"
VERSION="12-SP2"
VERSION_ID="12.2"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp2"
"""
    path = '/etc/os-release'
    name = 'SUSE'
    collected_facts = {'distribution_release': 'NA', 'distribution_version': '12.2'}
    dist_file_facts = DistributionFiles().parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert dist_file_facts['distribution'] == 'SLES'
    assert dist_file_facts['distribution_release']

# Generated at 2022-06-17 02:02:45.133659
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:02:50.721489
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Setup
    dist_files = DistributionFiles()
    name = 'CentOS'
    data = 'CentOS Stream'
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA'}

    # Exercise
    centos_facts = dist_files.parse_distribution_file_CentOS(name, data, path, collected_facts)

    # Verify
    assert centos_facts[0] == True
    assert centos_facts[1] == {'distribution_release': 'Stream'}


# Generated at 2022-06-17 02:02:54.158652
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_release'] == platform.release()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution'] == 'OpenBSD'


# Generated at 2022-06-17 02:03:06.883100
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_facts = DistributionFiles().parse_distribution_file_Amazon('Amazon', 'Amazon', '/etc/os-release', {})
    assert dist_file_facts['distribution'] == 'Amazon'
    assert dist_file_facts['distribution_version'] == 'NA'
    dist_file_facts = DistributionFiles().parse_distribution_file_Amazon('Amazon', 'Amazon Linux AMI release 2018.03', '/etc/system-release', {})
    assert dist_file_facts['distribution'] == 'Amazon'
    assert dist_file_facts['distribution_version'] == '2018.03'
    assert dist_file_facts['distribution_major_version'] == '2018'
    assert dist_file_facts['distribution_minor_version'] == '03'
    dist_file_facts = DistributionFiles().parse_dist

# Generated at 2022-06-17 02:03:10.255258
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: create test data
    # TODO: create test
    pass


# Generated at 2022-06-17 02:03:16.809975
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Test with empty data
    dist_file_facts = DistributionFiles().parse_distribution_file_Coreos('CoreOS', '', '/etc/os-release', {})
    assert dist_file_facts == (False, {})

    # Test with valid data
    dist_file_facts = DistributionFiles().parse_distribution_file_Coreos('CoreOS', 'GROUP=stable', '/etc/os-release', {})
    assert dist_file_facts == (True, {'distribution_release': 'stable'})

    # Test with invalid data
    dist_file_facts = DistributionFiles().parse_distribution_file_Coreos('CoreOS', 'GROUP=stable', '/etc/os-release', {'distribution': 'NA'})
    assert dist_file_facts == (False, {})



# Generated at 2022-06-17 02:03:25.395397
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_release'] == platform.release()
    assert openbsd_facts['distribution_version'] == platform.release()

# Generated at 2022-06-17 02:04:17.928949
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Test for SLES
    name = 'SUSE'
    data = '''
NAME="SLES"
VERSION="12-SP3"
VERSION_ID="12.3"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP3"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp3"
'''
    path = '/etc/os-release'
    collected_facts = {'distribution_version': '12.3'}
    dist_file_facts = DistributionFiles().parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert dist_file_facts['distribution'] == 'SLES'
    assert dist_file_facts['distribution_release'] == '0'

    #

# Generated at 2022-06-17 02:04:22.319095
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_OpenBSD() == {'distribution_version': '6.6', 'distribution_release': 'release'}


# Generated at 2022-06-17 02:04:26.976880
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_DragonFly()
    assert distribution_facts['distribution_release'] == platform.release()
    assert distribution_facts['distribution_version'] == '4.8.1'


# Generated at 2022-06-17 02:04:37.742723
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_facts = DistributionFiles().parse_distribution_file_Amazon('Amazon', 'Amazon', '/etc/os-release', {})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1]['distribution'] == 'Amazon'
    assert dist_file_facts[1]['distribution_version'] == 'NA'

    dist_file_facts = DistributionFiles().parse_distribution_file_Amazon('Amazon', 'Amazon Linux AMI release 2016.03', '/etc/issue', {})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1]['distribution'] == 'Amazon'
    assert dist_file_facts[1]['distribution_version'] == '2016.03'
    assert dist_file_facts[1]['distribution_major_version']

# Generated at 2022-06-17 02:04:48.479010
# Unit test for method get_distribution_facts of class Distribution

# Generated at 2022-06-17 02:04:53.771207
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:05:01.010176
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    data = '''
NAME="SLES"
VERSION="12-SP2"
VERSION_ID="12.2"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp2"
'''
    name = 'SUSE'
    path = '/etc/os-release'
    parsed_dist_file, parsed_dist_file_facts = dist_files.parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert parsed_

# Generated at 2022-06-17 02:05:05.075438
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:05:09.161353
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:05:12.389136
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'
