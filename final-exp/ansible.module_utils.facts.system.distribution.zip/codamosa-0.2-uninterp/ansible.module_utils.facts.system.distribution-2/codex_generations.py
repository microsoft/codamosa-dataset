

# Generated at 2022-06-17 01:56:15.206893
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_DragonFly() == {'distribution_release': '5.8-RELEASE'}


# Generated at 2022-06-17 01:56:15.864129
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:56:21.779451
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles

# Generated at 2022-06-17 01:56:31.375595
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    dist_file_facts = DistributionFiles().parse_distribution_file_OpenWrt('OpenWrt', 'DISTRIB_RELEASE="18.06.1"\nDISTRIB_CODENAME="Chaos Calmer"', '/etc/openwrt_release', {})
    assert dist_file_facts['distribution'] == 'OpenWrt'
    assert dist_file_facts['distribution_version'] == '18.06.1'
    assert dist_file_facts['distribution_release'] == 'Chaos Calmer'


# Generated at 2022-06-17 01:56:37.937055
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Test with empty data
    data = ""
    name = "NA"
    path = "/etc/os-release"
    collected_facts = {'distribution_version': 'NA'}
    dist_file = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = dist_file.parse_distribution_file_NA(name, data, path, collected_facts)
    assert parsed_dist_file is True
    assert parsed_dist_file_facts == {}

    # Test with data containing NAME and VERSION
    data = "NAME=Fedora\nVERSION=28 (Workstation Edition)\nID=fedora\nVERSION_ID=28\n"
    name = "NA"
    path = "/etc/os-release"
    collected_facts = {'distribution_version': 'NA'}
    dist

# Generated at 2022-06-17 01:56:38.899089
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:56:47.363292
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    netbsd_facts = dist.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    assert netbsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert netbsd_facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 01:56:51.729203
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:57:06.284322
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Test with Amazon Linux 2
    # /etc/os-release
    data = 'NAME="Amazon Linux"\nVERSION="2"\nID="amzn"\nID_LIKE="centos rhel fedora"\nVERSION_ID="2"\nPRETTY_NAME="Amazon Linux 2"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"\nHOME_URL="https://amazonlinux.com/"\n'
    path = '/etc/os-release'
    name = 'Amazon'
    collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA', 'distribution': 'NA'}

# Generated at 2022-06-17 01:57:12.557808
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    aix_facts = dist.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 01:57:53.375367
# Unit test for method parse_distribution_file_NA of class DistributionFiles

# Generated at 2022-06-17 01:58:05.583400
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles

# Generated at 2022-06-17 01:58:14.841133
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    dist_files = DistributionFiles()
    name = 'clearlinux'
    data = '''NAME="Clear Linux"
VERSION_ID=27000
ID=clear-linux-os
VERSION="27000 (Buster)"
PRETTY_NAME="Clear Linux OS 27000 (Buster)"
ANSI_COLOR="1;34"
HOME_URL="https://clearlinux.org/"
SUPPORT_URL="https://clearlinux.org/support"
BUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"
PRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy"'''
    path = '/etc/os-release'
    collected_facts = {}

# Generated at 2022-06-17 01:58:27.502920
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    dragonfly_facts = distribution.get_distribution_DragonFly()
    assert dragonfly_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dragonfly_facts['distribution_major_version'] == match.group(1)
        assert dragonfly_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]

# Generated at 2022-06-17 01:58:36.242473
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    assert freebsd_facts['distribution'] == 'FreeBSD'
    assert freebsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert freebsd_facts['distribution_version'] == platform.release().split('-')[0]

# Generated at 2022-06-17 01:58:42.005652
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    darwin_facts = dist.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 01:58:50.349114
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_facts()
    assert distribution_facts['distribution'] == 'Linux'
    assert distribution_facts['distribution_release'] == '7.6.1810'
    assert distribution_facts['distribution_version'] == '7.6.1810'
    assert distribution_facts['os_family'] == 'RedHat'



# Generated at 2022-06-17 01:58:58.405897
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # test for SLES
    data = '''SUSE Linux Enterprise Server 11 (x86_64)
VERSION = 11
PATCHLEVEL = 3'''
    dist_file_facts = DistributionFiles().parse_distribution_file_SUSE('SUSE', data, '/etc/SuSE-release', {'distribution_version': '11'})
    assert dist_file_facts[0] == True
    assert dist_file_facts[1]['distribution'] == 'SLES'
    assert dist_file_facts[1]['distribution_release'] == '3'
    assert dist_file_facts[1]['distribution_version'] == '11.3'

    # test for openSUSE

# Generated at 2022-06-17 01:59:07.732052
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    dragonfly_facts = distribution.get_distribution_DragonFly()
    assert dragonfly_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dragonfly_facts['distribution_major_version'] == match.group(1)
        assert dragonfly_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]

# Generated at 2022-06-17 01:59:15.452985
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    dist_facts = dist.get_distribution_DragonFly()
    assert dist_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dist_facts['distribution_major_version'] == match.group(1)
        assert dist_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]


# Generated at 2022-06-17 01:59:48.203277
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_DragonFly() == {'distribution_release': '5.8-RELEASE'}

# Generated at 2022-06-17 01:59:58.394619
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    dist_file_facts = DistributionFiles(module).parse_distribution_file_OpenWrt("OpenWrt", "DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=18.06.1\nDISTRIB_REVISION=r7258-5eb055306f\nDISTRIB_CODENAME=reboot\nDISTRIB_TARGET=ar71xx/generic\nDISTRIB_DESCRIPTION=\"OpenWrt 18.06.1 r7258-5eb055306f\"\nDISTRIB_TAINTS=no-all\n", "/etc/openwrt_release", {})

# Generated at 2022-06-17 02:00:01.558905
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    assert dist.get_distribution_AIX() == {'distribution_major_version': '7', 'distribution_version': '7.1', 'distribution_release': '1'}


# Generated at 2022-06-17 02:00:03.521410
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:00:16.336459
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Setup
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'NA'
    data = '''
NAME="Amazon Linux AMI"
VERSION="2018.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2018.03"
PRETTY_NAME="Amazon Linux AMI 2018.03"
ANSI_COLOR="0;33"
CPE_NAME="cpe:/o:amazon:linux:2018.03:ga"
HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
'''
    path = '/etc/os-release'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}

    # Test
    result = dist_files.parse_dist

# Generated at 2022-06-17 02:00:23.651182
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_release'] == 'SmartOS 16.4.0'
    assert sunos_facts['distribution_version'] == '16.4.0'


# Generated at 2022-06-17 02:00:24.919763
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:00:36.636576
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'Mandriva'
    data = '''
NAME="Mandriva Linux"
VERSION="2010.1 (Official) - Spring"
ID=mandriva
VERSION_ID=2010.1
PRETTY_NAME="Mandriva Linux 2010.1 (Official) - Spring"
ANSI_COLOR="1;31"
CPE_NAME="cpe:/o:mandriva:linux:2010.1:spring"
HOME_URL="http://www.mandriva.com/"
BUG_REPORT_URL="http://qa.mandriva.com/"
'''
    path = '/etc/mandriva-release'

# Generated at 2022-06-17 02:00:37.535660
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(None) == None


# Generated at 2022-06-17 02:00:43.912100
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_facts = DistributionFiles().parse_distribution_file_Amazon('Amazon', 'Amazon Linux AMI release 2016.03', '/etc/system-release', {})
    assert dist_file_facts['distribution'] == 'Amazon'
    assert dist_file_facts['distribution_version'] == '2016.03'
    assert dist_file_facts['distribution_major_version'] == '2016'
    assert dist_file_facts['distribution_minor_version'] == '03'


# Generated at 2022-06-17 02:01:24.878402
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160308T180133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20160308T180133Z joyent_20160308T180133Z'
    assert sunos_facts['distribution_major_version'] == '5'


# Generated at 2022-06-17 02:01:30.324721
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20180322T181133Z'
    assert sunos_facts['distribution_release'] == 'joyent_20180322T181133Z'
    assert sunos_facts['distribution_major_version'] == '18'



# Generated at 2022-06-17 02:01:34.707214
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution_release'] == 'release'


# Generated at 2022-06-17 02:01:39.509682
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.15.7'


# Generated at 2022-06-17 02:01:47.132721
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    dist_facts = dist.get_distribution_Darwin()
    assert dist_facts['distribution'] == 'MacOSX'
    assert dist_facts['distribution_major_version'] == '10'
    assert dist_facts['distribution_version'] == '10.15.7'



# Generated at 2022-06-17 02:01:55.921923
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # Test with valid data
    data = '''
NAME="Mandriva Linux"
VERSION="2010.1 (Official) - Spring"
ID=mandriva
VERSION_ID=2010.1
PRETTY_NAME="Mandriva Linux 2010.1 (Official) - Spring"
ANSI_COLOR="38;5;64"
CPE_NAME="cpe:/o:mandriva:linux:2010.1:spring"
HOME_URL="http://www.mandriva.com/"
SUPPORT_URL="http://www.mandriva.com/en/support"
BUG_REPORT_URL="http://qa.mandriva.com/"
'''
    collected_facts = {}
    collected_facts['distribution'] = 'NA'
    collected_facts['distribution_version'] = 'NA'

# Generated at 2022-06-17 02:02:05.135318
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'OpenWrt'
    data = '''
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=18.06.1
DISTRIB_REVISION=r7258-5eb055306f
DISTRIB_CODENAME=reboot
DISTRIB_TARGET=ramips/mt7621
DISTRIB_DESCRIPTION="OpenWrt 18.06.1 r7258-5eb055306f"
DISTRIB_TAINTS=no-all
'''
    path = '/etc/openwrt_release'
    collected_facts = {}

# Generated at 2022-06-17 02:02:07.408376
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 02:02:14.307726
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 02:02:15.331124
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:03:35.873064
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 02:03:48.155304
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 02:03:51.031358
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(['-v']) == '4.4.0-31-generic'


# Generated at 2022-06-17 02:04:02.567359
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 02:04:05.653114
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 02:04:08.389649
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    facts = dist.get_distribution_OpenBSD()
    assert facts['distribution_version'] == platform.release()
    assert facts['distribution_release'] == 'release'


# Generated at 2022-06-17 02:04:10.456015
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_OpenBSD() == {'distribution_release': '6.6', 'distribution_version': '6.6'}


# Generated at 2022-06-17 02:04:18.370061
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Test with /etc/os-release
    data = 'NAME="SLES"\nVERSION="12-SP2"\nVERSION_ID="12.2"\nPRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"\nID="sles"\nANSI_COLOR="0;32"\nCPE_NAME="cpe:/o:suse:sles:12:sp2"\nBUG_REPORT_URL="https://bugs.suse.com"\nHOME_URL="https://www.suse.com/"\nID_LIKE="suse"'
    path = '/etc/os-release'
    name = 'SUSE'
    collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    dist_file_facts = DistributionFiles().parse_dist

# Generated at 2022-06-17 02:04:23.156482
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 02:04:24.096612
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(None) == None
