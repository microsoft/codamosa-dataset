

# Generated at 2022-06-17 01:56:24.898810
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 01:56:29.440565
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == '6.6'
    assert openbsd_facts['distribution_release'] == 'stable'



# Generated at 2022-06-17 01:56:33.469664
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.13.6'


# Generated at 2022-06-17 01:56:38.906981
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 01:56:51.344763
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # Setup
    dist_file_facts = DistributionFiles()
    name = 'Amazon'
    data = 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path = '/etc/os-release'
    collected_facts = {'distribution': 'Amazon', 'distribution_version': '2018.03'}

    # Test

# Generated at 2022-06-17 01:56:52.799212
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: add unit test
    pass


# Generated at 2022-06-17 01:57:02.251670
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    dist_file_facts = DistributionFiles()
    name = 'SUSE'
    data = '''
NAME="openSUSE Leap"
VERSION="15.2"
ID="opensuse-leap"
ID_LIKE="suse opensuse"
VERSION_ID="15.2"
PRETTY_NAME="openSUSE Leap 15.2"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:leap:15.2"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://www.opensuse.org/"
'''
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    parsed_dist_file, parsed_dist_file_

# Generated at 2022-06-17 01:57:05.737174
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.14.6'


# Generated at 2022-06-17 01:57:18.156706
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Test with a valid file
    data = 'NAME="Clear Linux OS"\nVERSION_ID=31350\nID=clear-linux-os\n'
    name = 'clearlinux'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA', 'distribution_release': 'NA'}
    dist_file = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = dist_file.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    assert parsed_dist_file
    assert parsed_dist_file_facts['distribution'] == 'Clear Linux OS'
    assert parsed_dist_file_facts['distribution_version'] == '31350'

# Generated at 2022-06-17 01:57:19.491414
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: add unit test for method parse_distribution_file_Amazon of class DistributionFiles
    pass


# Generated at 2022-06-17 01:57:54.321574
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: add unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
    pass

# Generated at 2022-06-17 01:58:06.421809
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'Mandriva'
    data = '''
    DISTRIB_ID=MandrivaLinux
    DISTRIB_RELEASE=2010.2
    DISTRIB_CODENAME=2010.2
    DISTRIB_DESCRIPTION="Mandriva Linux 2010.2"
    '''
    path = '/etc/lsb-release'
    collected_facts = {'distribution_version': 'NA'}
    parsed_dist_file, parsed_dist_file_facts = dist_files.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert parsed_dist_file
    assert parsed_dist_file_facts['distribution'] == 'Mandriva'
    assert parsed_dist_file

# Generated at 2022-06-17 01:58:08.115428
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    # TODO: write unit test for method process_dist_files of class DistributionFiles
    pass


# Generated at 2022-06-17 01:58:11.422987
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: add unit test for method parse_distribution_file_SUSE of class DistributionFiles
    pass


# Generated at 2022-06-17 01:58:18.207359
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '11'
    assert sunos_facts['distribution_release'] == '11.4'
    assert sunos_facts['distribution_major_version'] == '11'



# Generated at 2022-06-17 01:58:28.147344
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 01:58:34.414983
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '1588'


# Generated at 2022-06-17 01:58:35.311539
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:58:41.763565
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_facts = DistributionFiles()
    name = 'Amazon'
    data = 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    path = '/etc/os-release'
    collected_facts = {'distribution': 'Amazon', 'distribution_version': '2018.03'}
    parsed_dist_file_facts = dist_file_facts.parse_distribution_file_Amazon

# Generated at 2022-06-17 01:58:53.708225
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-17 01:59:32.824220
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 01:59:39.020194
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20180309T180133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20180309T180133Z joyent_20180309T180133Z'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 01:59:51.695478
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles

# Generated at 2022-06-17 01:59:55.519629
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: add unit test
    pass


# Generated at 2022-06-17 01:59:59.193954
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.13.6'}


# Generated at 2022-06-17 02:00:05.627738
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # test with valid data
    name = 'OpenWrt'
    data = 'DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=18.06.4\nDISTRIB_REVISION=r7258-5eb055306f\nDISTRIB_CODENAME=dunfell\nDISTRIB_TARGET=ramips/mt7621\nDISTRIB_DESCRIPTION="OpenWrt 18.06.4 r7258-5eb055306f"'
    path = '/etc/openwrt_release'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_OpenWrt(name, data, path, collected_facts)

# Generated at 2022-06-17 02:00:12.888606
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_FreeBSD() == {'distribution_release': '12.1-RELEASE-p10', 'distribution_major_version': '12', 'distribution_version': '12.1'}


# Generated at 2022-06-17 02:00:15.529762
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    assert False


# Generated at 2022-06-17 02:00:17.211711
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 02:00:19.582582
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement test
    pass


# Generated at 2022-06-17 02:01:06.791808
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: implement unit test for method parse_distribution_file_Slackware of class DistributionFiles
    pass


# Generated at 2022-06-17 02:01:15.707630
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    assert freebsd_facts['distribution'] == 'FreeBSD'
    assert freebsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert freebsd_facts['distribution_version'] == platform.release().split('-')[0]


# Generated at 2022-06-17 02:01:18.477585
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:01:23.314072
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '1131'


# Generated at 2022-06-17 02:01:32.126640
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-17 02:01:44.903358
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles

# Generated at 2022-06-17 02:01:47.330712
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:01:56.030322
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    test_data = {
        'name': 'clearlinux',
        'data': 'NAME="Clear Linux"\nVERSION_ID=27000\nID=clear-linux-os\nVERSION_CODENAME=\nPRETTY_NAME="Clear Linux OS"\nANSI_COLOR="1;32"\nHOME_URL="https://clearlinux.org/"\nSUPPORT_URL="https://clearlinux.org/support"\nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues"',
        'path': '/etc/os-release',
        'collected_facts': {
            'distribution': 'NA',
            'distribution_version': 'NA',
            'distribution_release': 'NA',
            'distribution_major_version': 'NA'
        }
    }

# Generated at 2022-06-17 02:02:06.890748
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # Test with DragonFlyBSD 5.2.1-RELEASE-p10
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'v5.2.1-RELEASE-p10', ''))
    distribution = Distribution(module)
    dragonfly_facts = distribution.get_distribution_DragonFly()
    assert dragonfly_facts['distribution_major_version'] == '5'
    assert dragonfly_facts['distribution_version'] == '5.2.1'
    assert dragonfly_facts['distribution_release'] == 'RELEASE-p10'
    # Test with DragonFlyBSD 5.2.1-STABLE
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 02:02:14.375440
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    assert netbsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert netbsd_facts['distribution_version'] == platform.release()


# Generated at 2022-06-17 02:03:20.987728
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    dist_files = DistributionFiles()
    name = 'clearlinux'

# Generated at 2022-06-17 02:03:29.225809
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Test with empty data
    dist_file_facts = DistributionFiles().parse_distribution_file_Coreos('CoreOS', '', '/etc/os-release', {})
    assert dist_file_facts[0] == False
    assert dist_file_facts[1] == {}

    # Test with valid data
    data = '''
NAME=CoreOS
ID=coreos
VERSION=1298.7.0
VERSION_ID=1298.7.0
BUILD_ID=
PRETTY_NAME="CoreOS 1298.7.0"
ANSI_COLOR="38;5;75"
HOME_URL="https://coreos.com/"
BUG_REPORT_URL="https://issues.coreos.com"
COREOS_BOARD=amd64-usr
'''

# Generated at 2022-06-17 02:03:30.215479
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: write unit test
    return True



# Generated at 2022-06-17 02:03:39.763694
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # Test with Slackware
    name = 'Slackware'
    data = '''
Slackware 14.2
'''
    path = '/etc/slackware-version'
    collected_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA',
        'distribution_file_path': 'NA',
        'distribution_file_variety': 'NA',
        'distribution_file_parsed': False,
    }
    dist_file = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = dist_file.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed_dist_file is True

# Generated at 2022-06-17 02:03:41.661757
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: FIXME: write unit test
    pass

# Generated at 2022-06-17 02:03:51.548380
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)
    sunos_facts = distro.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20170705T181133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20170705T181133Z joyent_20170705T181133Z'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 02:03:53.671230
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # TODO: test for all cases
    pass


# Generated at 2022-06-17 02:03:56.404844
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:04:02.592899
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160630T180133Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20160630T180133Z joyent_20160629T221333Z'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 02:04:12.905885
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 02:04:58.001470
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.1'
    assert aix_facts['distribution_release'] == '1'


# Generated at 2022-06-17 02:05:07.216265
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(
            distribution_file_paths=dict(type='list', default=['/etc/os-release']),
        )
    )
    dist_files = DistributionFiles(module)
    collected_facts = {'distribution_file_paths': ['/etc/os-release'], 'distribution_file_facts': {'distribution_file_path': '/etc/os-release', 'distribution_file_variety': 'Coreos', 'distribution_file_parsed': True, 'distribution': 'Coreos', 'distribution_release': 'stable'}}

    # Test
    name = 'Coreos'

# Generated at 2022-06-17 02:05:09.978304
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_DragonFly() == {'distribution_release': '5.4-RELEASE'}


# Generated at 2022-06-17 02:05:18.664942
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    dist_files = DistributionFiles()
    name = 'OpenWrt'
    data = 'DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=18.06.1\nDISTRIB_REVISION=r7258-5eb055306f\nDISTRIB_CODENAME=reboot\nDISTRIB_TARGET=ramips/mt7621\nDISTRIB_DESCRIPTION="OpenWrt 18.06.1 r7258-5eb055306f"'
    path = '/etc/openwrt_release'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}

# Generated at 2022-06-17 02:05:24.733955
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    data = re.search(r'(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT|RC|PRERELEASE).*', freebsd_facts['distribution_release'])
    if data:
        assert freebsd_facts['distribution_major_version'] == data.group(1)
        assert freebsd_facts['distribution_version'] == '%s.%s' % (data.group(1), data.group(2))

# Generated at 2022-06-17 02:05:29.922143
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.2'
    assert aix_facts['distribution_release'] == '2'
