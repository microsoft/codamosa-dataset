

# Generated at 2022-06-17 01:56:24.557579
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:56:28.849795
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # Test with OpenWrt
    test_data = """
    DISTRIB_ID=OpenWrt
    DISTRIB_RELEASE=18.06.1
    DISTRIB_REVISION=r7258-5eb055306f
    DISTRIB_CODENAME=reboot
    DISTRIB_TARGET=ramips/mt7621
    DISTRIB_DESCRIPTION="OpenWrt 18.06.1 r7258-5eb055306f"
    DISTRIB_TAINTS=no-all
    """
    test_path = '/etc/openwrt_release'
    test_name = 'OpenWrt'
    test_collected_facts = {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}

# Generated at 2022-06-17 01:56:35.491625
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 01:56:46.805164
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    dragonfly_facts = distribution.get_distribution_DragonFly()
    assert dragonfly_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        assert dragonfly_facts['distribution_major_version'] == match.group(1)
        assert dragonfly_facts['distribution_version'] == '%s.%s.%s' % match.groups()[:3]


# Generated at 2022-06-17 01:56:51.606966
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 01:56:57.525783
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.13.6'


# Generated at 2022-06-17 01:57:01.332841
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 01:57:10.864631
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(None) == 'Linux'
    assert get_uname(None, '-a') == 'Linux localhost.localdomain 3.10.0-327.el7.x86_64 #1 SMP Thu Nov 19 22:10:57 UTC 2015 x86_64 x86_64 x86_64 GNU/Linux'
    assert get_uname(None, '-s') == 'Linux'
    assert get_uname(None, '-n') == 'localhost.localdomain'
    assert get_uname(None, '-r') == '3.10.0-327.el7.x86_64'
    assert get_uname(None, '-v') == '#1 SMP Thu Nov 19 22:10:57 UTC 2015'

# Generated at 2022-06-17 01:57:17.361947
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160401T222710Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20160401T222710Z joyent_20160401T222710Z'
    assert sunos_facts['distribution_major_version'] == '5'


# Generated at 2022-06-17 01:57:21.335051
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    facts = distribution.get_distribution_FreeBSD()
    assert facts['distribution_release'] == platform.release()
    assert facts['distribution'] == 'FreeBSD'
    assert facts['distribution_major_version'] == platform.release().split('.')[0]
    assert facts['distribution_version'] == platform.release().split('-')[0]


# Generated at 2022-06-17 01:58:03.351368
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: add unit tests
    pass


# Generated at 2022-06-17 01:58:06.964890
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.13.6'


# Generated at 2022-06-17 01:58:11.812546
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    dist_facts = dist.get_distribution_Darwin()
    assert dist_facts['distribution'] == 'MacOSX'
    assert dist_facts['distribution_major_version'] == '10'
    assert dist_facts['distribution_version'] == '10.15.7'


# Generated at 2022-06-17 01:58:13.175120
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(None) is not None


# Generated at 2022-06-17 01:58:18.431595
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 01:58:24.849462
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '11'
    assert sunos_facts['distribution_release'] == '11.4'
    assert sunos_facts['distribution_major_version'] == '11'



# Generated at 2022-06-17 01:58:34.375632
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    dist_file_facts = DistributionFiles().parse_distribution_file_Amazon('Amazon', 'Amazon Linux AMI release 2016.03', '/etc/system-release', {})
    assert dist_file_facts['distribution'] == 'Amazon'
    assert dist_file_facts['distribution_version'] == '2016.03'
    assert dist_file_facts['distribution_major_version'] == '2016'
    assert dist_file_facts['distribution_minor_version'] == '03'


# Generated at 2022-06-17 01:58:35.274294
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:58:45.342978
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert netbsd_facts['distribution_release'] == platform.release()
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        assert netbsd_facts['distribution_major_version'] == match.group(1)
        assert netbsd_facts['distribution_version'] == '%s.%s' % match.groups()[:2]

# Generated at 2022-06-17 01:58:55.324053
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_facts = DistributionFiles()
    name = 'Slackware'
    data = 'Slackware 14.1'
    path = '/etc/slackware-version'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}
    parsed_dist_file, parsed_dist_file_facts = dist_file_facts.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed_dist_file == True
    assert parsed_dist_file_facts == {'distribution': 'Slackware', 'distribution_version': '14.1'}


# Generated at 2022-06-17 01:59:31.573686
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:59:35.950427
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '0'


# Generated at 2022-06-17 01:59:48.609260
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles

# Generated at 2022-06-17 01:59:58.588133
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Test with valid data
    data = "GROUP=stable"
    name = "CoreOS"
    path = "/etc/os-release"
    collected_facts = {'distribution_release': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert dist_file_facts['distribution_release'] == 'stable'

    # Test with invalid data
    data = "GROUP=stable"
    name = "CoreOS"
    path = "/etc/os-release"
    collected_facts = {'distribution_release': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_Coreos(name, data, path, collected_facts)

# Generated at 2022-06-17 02:00:14.182267
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    test_data = '''
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=18.06.1
DISTRIB_REVISION=r7258-5eb055306f
DISTRIB_CODENAME=reboot
DISTRIB_TARGET=ramips/mt7621
DISTRIB_DESCRIPTION="OpenWrt 18.06.1 r7258-5eb055306f"
DISTRIB_TAINTS=no-all
'''
    test_path = '/etc/openwrt_release'
    test_name = 'OpenWrt'
    test_collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA'}

# Generated at 2022-06-17 02:00:17.900288
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    module = AnsibleModule(argument_spec={})
    dist_files = DistributionFiles(module)
    name = 'Flatcar'
    data = 'GROUP=stable'
    path = '/etc/flatcar/release'
    collected_facts = {'distribution_release': 'NA'}
    expected_result = {'distribution_release': 'stable'}
    result = dist_files.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result[1] == expected_result

# Generated at 2022-06-17 02:00:29.914465
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: fix this test
    # test_data = {'distribution': 'OpenWrt', 'distribution_version': '15.05', 'distribution_release': 'Chaos Calmer'}
    # test_data = {'distribution': 'OpenWrt', 'distribution_version': '15.05', 'distribution_release': 'Chaos Calmer'}
    test_data = {'distribution': 'OpenWrt', 'distribution_version': '15.05'}
    test_data_file = '/etc/openwrt_release'
    test_data_file_content = 'DISTRIB_RELEASE="15.05"\nDISTRIB_CODENAME="Chaos Calmer"\nDISTRIB_TARGET="ar71xx/generic"'

# Generated at 2022-06-17 02:00:40.606108
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Test with empty data
    data = ''
    name = 'NA'
    path = '/etc/os-release'
    collected_facts = {'distribution_version': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_NA(name, data, path, collected_facts)
    assert dist_file_facts[0] == True
    assert dist_file_facts[1] == {}

    # Test with valid data

# Generated at 2022-06-17 02:00:44.908100
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    assert hpux_facts['distribution_version'] == 'B.11.31'
    assert hpux_facts['distribution_release'] == '1234'


# Generated at 2022-06-17 02:00:48.985682
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:02:04.983189
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-17 02:02:14.566117
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_version'] == '20160308T180105Z'
    assert sunos_facts['distribution_release'] == 'SmartOS 20160308T180105Z joyent_20160308T180105Z'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 02:02:15.824561
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # TODO: FIXME: this is a stub
    pass


# Generated at 2022-06-17 02:02:23.313704
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_OpenBSD()
    assert distribution_facts['distribution_release'] == '6.6'
    assert distribution_facts['distribution_version'] == '6.6'


# Generated at 2022-06-17 02:02:24.878780
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:02:32.487899
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    freebsd_facts = distribution.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == platform.release()
    assert freebsd_facts['distribution'] == 'FreeBSD'
    assert freebsd_facts['distribution_major_version'] == platform.release().split('.')[0]
    assert freebsd_facts['distribution_version'] == platform.release().split('-')[0]


# Generated at 2022-06-17 02:02:40.010405
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_release'] == 'SmartOS 16.4.0'
    assert sunos_facts['distribution_version'] == '16.4.0'


# Generated at 2022-06-17 02:02:42.866902
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert openbsd_facts['distribution_version'] == platform.release()
    assert openbsd_facts['distribution_release'] == 'release'


# Generated at 2022-06-17 02:02:48.652049
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_DragonFly() == {'distribution_release': '5.8-RELEASE'}



# Generated at 2022-06-17 02:02:55.321150
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    # Test for Solaris 10
    with patch('ansible.module_utils.facts.system.get_file_content', return_value='Oracle Solaris 10 10/09 s10x_u8wos_08a X86'):
        with patch('ansible.module_utils.facts.system.get_uname', return_value='5.10'):
            sunos_facts = dist.get_distribution_SunOS()
            assert sunos_facts['distribution'] == 'Solaris'
            assert sunos_facts['distribution_version'] == '10'
            assert sunos_facts['distribution_release'] == 'Oracle Solaris 10 10/09 s10x_u8wos_08a X86'
            assert sunos_facts

# Generated at 2022-06-17 02:04:14.413878
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-17 02:04:15.747594
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:04:22.616744
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.15.4'}


# Generated at 2022-06-17 02:04:24.008394
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # TODO: implement
    pass


# Generated at 2022-06-17 02:04:29.585037
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Solaris'
    assert sunos_facts['distribution_version'] == '11.4'
    assert sunos_facts['distribution_release'] == '11.4'
    assert sunos_facts['distribution_major_version'] == '11'


# Generated at 2022-06-17 02:04:37.831983
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Setup
    dist_file_facts = DistributionFiles()
    dist_file_facts.module = MagicMock()
    dist_file_facts.module.get_bin_path.return_value = '/bin/ls'
    dist_file_facts.module.run_command.return_value = (0, 'CentOS Stream', '')
    dist_file_facts.module.params = {'gather_subset': ['all']}
    collected_facts = {'distribution_release': 'NA'}
    name = 'CentOS'
    data = 'CentOS Stream'
    path = '/etc/os-release'

    # Test
    parsed_dist_file, parsed_dist_file_facts = dist_file_facts.parse_distribution_file_CentOS(name, data, path, collected_facts)

    #

# Generated at 2022-06-17 02:04:39.750520
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # TODO: write unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
    pass


# Generated at 2022-06-17 02:04:45.137106
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    assert dist.get_distribution_DragonFly() == {'distribution_release': '5.8-RELEASE'}



# Generated at 2022-06-17 02:04:48.819140
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # TODO: FIXME: implement unit test
    pass


# Generated at 2022-06-17 02:04:58.630759
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Test for SLES
    data = '''
    NAME="SLES"
    VERSION="12-SP3"
    ID="sles"
    ID_LIKE="suse opensuse"
    VERSION_ID="12.3"
    PRETTY_NAME="SUSE Linux Enterprise Server 12 SP3"
    ANSI_COLOR="0;32"
    CPE_NAME="cpe:/o:suse:sles:12:sp3"
    BUG_REPORT_URL="https://bugs.opensuse.org"
    HOME_URL="https://www.suse.com/"
    '''
    collected_facts = {'distribution_version': '12.3'}