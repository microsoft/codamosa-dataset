

# Generated at 2022-06-20 19:12:39.878568
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distribution = DistributionFiles()
    path = distribution.run({})
    distribution_data = path['active']['distribution']
    distribution_file_facts = path['active']['distribution_file_facts']

    # Get name of distribution
    if distribution_file_facts:
        dist_name = distribution_data['distribution']
    else:
        dist_name = 'NA'

    # Get name of file
    if distribution_file_facts:
        for file_name, file_data in distribution_file_facts.items():
            distribution_file_path = file_data['distribution_file_path']
            if distribution_file_path == '/etc/os-release':
                file_name = 'os-release'

# Generated at 2022-06-20 19:12:45.413664
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    distribution = Distribution(module)
    hpux_facts = distribution.get_distribution_HPUX()
    expected_facts = {
        'distribution_release': 'B.11.31',
        'distribution_version': '11.31'}
    assert hpux_facts == expected_facts



# Generated at 2022-06-20 19:12:52.958954
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles

# Generated at 2022-06-20 19:12:58.383320
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    input = textwrap.dedent("""
        OpenBSD 7.0 (GENERIC) #11: Tue Dec 24 19:44:48 MST 2019
    """)

    distribution = Distribution(None)
    distribution_facts = distribution.get_distribution_OpenBSD()

    assert distribution_facts['distribution_version'] == '7.0'
    assert distribution_facts['distribution_release'] == 'GENERIC'


# Generated at 2022-06-20 19:13:06.266257
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    files = DistributionFiles()
    data = "DISTRIB_ID=\"MandrivaLinux\"\nDISTRIB_RELEASE=\"2007.1\"\nDISTRIB_CODENAME=\"Venus\"\nDISTRIB_DESCRIPTION=\"Mandriva Linux release 2007.1 (Venus) for x86_64\""
    name = "Mandriva"
    path = "/etc/lsb-release"
    collected_facts = {"distribution_version": "NA", "distribution_release": "NA"}
    expected = True
    expected_out = {"distribution_release": "Venus", "distribution": "Mandriva"}
    actual_out = files.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert actual_out[0] == expected

# Generated at 2022-06-20 19:13:14.351160
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    '''
    test ansible.module_utils.basic.distro.DistributionFactCollector.collect method
    '''
    if 'distribution' not in collected_facts:
        distribution = Distribution(module=module)
        distro_facts = distribution.get_distribution_facts()
        collected_facts.update(distro_facts)


# Generated at 2022-06-20 19:13:24.578272
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    distribution = Distribution(MockAnsibleModule(False))

    platform_release = platform.release()
    netbsd_facts = {'distribution_release': platform_release}
    rc, out, dummy = distribution.module.run_command("/sbin/sysctl -n kern.version")
    match = re.match(r'NetBSD\s(\d+)\.(\d+)\s\((GENERIC)\).*', out)
    if match:
        netbsd_facts['distribution_major_version'] = match.group(1)
        netbsd_facts['distribution_version'] = '%s.%s' % match.groups()[:2]
    else:
        netbsd_facts['distribution_major_version'] = platform_release.split('.')[0]
        netbsd

# Generated at 2022-06-20 19:13:32.947359
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    """Test method parse_distribution_file_Debian of class DistributionFiles
    """
    # Arrange
    distro = DistributionFiles()

    # Act
    name = 'Debian'
    data = """\
    NAME="Debian GNU/Linux"
    VERSION_ID="8"
    VERSION="8 (jessie)"
    ID=debian
    HOME_URL="http://www.debian.org/"
    SUPPORT_URL="http://www.debian.org/support/"
    BUG_REPORT_URL="https://bugs.debian.org/"
    """
    path = '/etc/os-release'
    dist_file_facts = {}
    dist_file_facts['distribution'] = 'Debian'
    dist_file_facts['distribution_version'] = '8'

# Generated at 2022-06-20 19:13:42.515426
# Unit test for method get_distribution_SunOS of class Distribution

# Generated at 2022-06-20 19:13:45.049057
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    current_distribution = get_distribution()
    if current_distribution not in ('Alpine', 'LinuxMint', 'Ubuntu'):
        pytest.fail("Distribution is expected to be Alpine or LinuxMint or Ubuntu")


# Generated at 2022-06-20 19:14:23.160712
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Test Case 1
    d = DistributionFiles()
    facts = {'distribution_release': 'NA'}
    file_name = 'coreos'
    file_data = 'GROUP=alpha'
    assert d.parse_distribution_file_Coreos(file_name, file_data, None, facts)

    # Test Case 2
    facts = {'distribution_release': 'NA'}
    file_name = 'coreos'
    file_data = ''
    assert not d.parse_distribution_file_Coreos(file_name, file_data, None, facts)

    # Test Case 2
    facts = {'distribution_release': 'NA'}
    file_name = 'CentOS'
    file_data = ''

# Generated at 2022-06-20 19:14:32.582332
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    d = DistributionFiles()
    # TODO: does not work without this
    # get_distribution()
    expected_keys = [
        'distribution', 'distribution_version',
        'distribution_release'
    ]
    path = '/etc/os-release'
    data = '''
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=15.05.1
DISTRIB_REVISION=r46767
DISTRIB_CODENAME=chaos_calmer
DISTRIB_TARGET=ar71xx/generic
DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"
DISTRIB_TAINTS=
'''
    name = 'OpenWrt'

# Generated at 2022-06-20 19:14:42.210386
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    """
    Test cases for parse_distribution_file_SUSE method
    """
    # ARRANGE
    df = DistributionFiles()
    name = 'SUSE'
    data = ''
    path = ''
    collected_facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}

    # ACT
    out = df.parse_distribution_file_SUSE(name, data, path, collected_facts)

    # ASSERT
    assert out[0] == False



# Generated at 2022-06-20 19:14:48.988639
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution = Distribution(None)
    assert distribution.get_distribution_AIX()['distribution_major_version'] == '7'
    assert distribution.get_distribution_AIX()['distribution_version'] == '7.1'
    assert distribution.get_distribution_AIX()['distribution_release'] == '1'


# Generated at 2022-06-20 19:14:56.325737
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    '''
    Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
    '''
    distribution_files = DistributionFiles()
    args = [None, "Mandriva Linux release 201008.0 (Official) for i586", None, None]
    result = {}
    result['distribution'] = 'Mandriva'
    result['distribution_version'] = '201008.0'
    result['distribution_release'] = 'Official'
    assert distribution_files.parse_distribution_file_Mandriva(*args) == (True, result)



# Generated at 2022-06-20 19:15:03.312591
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    """
    Test DistributionFiles.parse_distribution_file_Slackware
    """
    name = "Slackware"
    data = '''Slackware 14.0'''
    path = "/etc/slackware-version"
    collected_facts = {}
    d = DistributionFiles()
    result, slackware_facts = d.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert slackware_facts['distribution'] == 'Slackware'
    assert slackware_facts['distribution_version'] == '14.0'


# Generated at 2022-06-20 19:15:06.901014
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    distribution = Distribution(module)
    expected_result = {'distribution': 'Source Mage GNU/Linux'}
    assert expected_result == distribution.get_distribution_SMGL()

# Generated at 2022-06-20 19:15:10.870240
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    assert DistributionFactCollector.name == 'distribution'
    assert DistributionFactCollector._fact_ids == set(['distribution_version',
                                                       'distribution_release',
                                                       'distribution_major_version',
                                                       'os_family'])

# Generated at 2022-06-20 19:15:12.141062
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # TODO: test this file
    pass

# Generated at 2022-06-20 19:15:20.344660
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # case where output of oslevel is "7100-00-00-0000"
    module = MagicMock()
    module.run_command.return_value = (0, "7100-00-00-0000", "")
    aix_facts = Distribution(module).get_distribution_AIX()
    assert aix_facts["distribution_major_version"] == "7100"
    assert aix_facts["distribution_version"] == "7100-00"
    assert aix_facts["distribution_release"] == "00"

    # case where output of oslevel is "7100-03-01-1516"
    module.run_command.return_value = (0, "7100-03-01-1516", "")
    aix_facts = Distribution(module).get_distribution_AIX()


# Generated at 2022-06-20 19:15:48.065109
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    d = Distribution(None)

    assert d.get_distribution_SMGL() == {'distribution': 'Source Mage GNU/Linux'}


# Generated at 2022-06-20 19:15:59.358364
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-20 19:16:07.143625
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    dist = Distribution()

    # test with a NetBSD release
    kern_version = "NetBSD 6.1.5 (GENERIC) #0: Wed Feb  5 23:18:16 UTC 2014  builds@wb32:/home/builds/ab/netbsd-6-1-RELEASE/amd64/201402052014Z-obj/home/builds/ab/netbsd-6-1-RELEASE/src/sys/arch/amd64/compile/GENERIC amd64"
    result = dist.get_distribution_NetBSD()

    assert 'distribution' == 'NetBSD'
    assert 'distribution_version' == '6.1'
    assert 'distribution_major_version' == '6'
    assert 'distribution_release' == '6.1.5'

    # test with a Net

# Generated at 2022-06-20 19:16:19.742715
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # Init
    test_class = DistributionFiles()
    name = 'test_name'
    path = '/tmp/test.txt'
    collected_facts = {'distribution_release': 'NA'}

    # Run Debian test
    data = 'lsb_release(1)                         LSB Version:    :core-4.1-amd64:core-4.1-noarch\n' \
           'Distributor ID: Debian\n' \
           'Description:    Debian GNU/Linux 8.11 (jessie)\n' \
           'Release:        8.11\n' \
           'Codename:       jessie'
    bool_ret, ret = test_class.parse_distribution_file_Debian(name, data, path, collected_facts)
    assert bool_ret

# Generated at 2022-06-20 19:16:27.055274
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    d = DistributionFiles({}, 'Alpine', ['/etc/os-release'])
    data = '3.11.3'
    result = d.parse_distribution_file_Alpine('Alpine', data, '/etc/os-release', {})
    expected = (True, {'distribution': 'Alpine', 'distribution_version': '3.11.3'})

    assert (expected == result)


# Generated at 2022-06-20 19:16:28.362554
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    distributionfiles = DistributionFiles({})
    assert distributionfiles != None


# Generated at 2022-06-20 19:16:29.568899
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('-v') == 'Linux'

#
# Returns the output of 'grep PRETTY_NAME /etc/os-release'
#

# Generated at 2022-06-20 19:16:31.975109
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    facts = Distribution(None)
    distro_facts = facts.get_distribution_SMGL()
    assert distro_facts['distribution'] == 'Source Mage GNU/Linux'


# Generated at 2022-06-20 19:16:32.736271
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # NA.
    pass


# Generated at 2022-06-20 19:16:36.513318
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    d = DistributionFiles()
    data = "3.11.3"
    path = "/etc/alpine-release"
    name = "Alpine"
    collected_facts = {}
    d.parse_distribution_file_Alpine(name, data, path, collected_facts)



# Generated at 2022-06-20 19:17:26.586052
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    result = Distribution.get_distribution_FreeBSD(None)
    assert result == {}



# Generated at 2022-06-20 19:17:34.759506
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    def is_dict_contains(main_dict, check_dict):
        return all(item in main_dict.items() for item in check_dict.items())

    result = Distribution.get_distribution_FreeBSD(None)
    expected_result = {
        'distribution_release': platform.release(),
        'distribution': 'FreeBSD',
        'distribution_major_version': platform.release().split('.')[0],
        'distribution_version': '%s.%s' % (platform.release().split('.')[0], platform.release().split('.')[1])
    }

    assert is_dict_contains(result, expected_result), "Result doesn't contains all expected keys"

# Generated at 2022-06-20 19:17:39.666488
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    x = DistributionFactCollector()
    assert x.name == 'distribution'
    assert x._fact_ids == {'distribution_version',
                           'distribution_release',
                           'distribution_major_version',
                           'os_family'}
    assert x.dependencies == set()

# Generated at 2022-06-20 19:17:52.909840
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    """Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles"""

    def test_name(name, data, path, collected_facts):
        """
        Helper function to be able to test the arguments that are passed to
        parse_distribution_file_OpenWrt.

        It will return the arguments as a list.
        """
        return [name, data, path, collected_facts]

    def test_return(returnval, name, data, path, collected_facts):
        """
        Helper function to be able to test the return values of
        parse_distribution_file_OpenWrt.

        It will return the arguments as a list.
        """
        return returnval

    # Test the arguments.

# Generated at 2022-06-20 19:18:04.469114
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Test method parse_distribution_file_ClearLinux against sample data
    def test_data(test_file_data, expected_results):
        test_file_path = '/distribution_test_file'
        test_file_name = 'clearlinux'
        test_collected_facts = {
            'distribution_release': 'NA',
            'distribution_version': 'NA',
        }
        test_distribution_file = DistributionFiles(module=None)
        test_result = test_distribution_file.parse_distribution_file_ClearLinux(test_file_name, test_file_data, test_file_path, test_collected_facts)
        assert test_result[0] == expected_results[0]
        assert test_result[1] == expected_results[1]

    # Test successful ClearLinux

# Generated at 2022-06-20 19:18:07.201561
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    distribution_module = Distribution(module)
    facts = distribution_module.get_distribution_SMGL()

    exit_args = dict(
        changed=False,
        ansible_facts=facts
    )
    module.exit_json(**exit_args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 19:18:15.085375
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # create an instance of DistributionFiles
    df = DistributionFiles()
    assert df.parse_distribution_file_Coreos('Coreos', 'GROUP="alpha"', '/etc/os-release', '{}') == (True, {'distribution_release': 'alpha'})

    # create an instance of DistributionFiles
    df = DistributionFiles()
    assert df.parse_distribution_file_Coreos('Coreos', '', '/etc/os-release', '{}') == (False, {})

    # create an instance of DistributionFiles
    df = DistributionFiles()
    assert df.parse_distribution_file_Coreos('NotCoreos', 'Group="beta"', '/etc/os-release', '{}') == (False, {})


# Generated at 2022-06-20 19:18:26.426885
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    '''
    This is a test to validate the parsing of SUSE os-release file
    '''
    # SUSE with release data
    data = "NAME=\"SLES\"\nVERSION_ID=\"15\"\nPRETTY_NAME=\"SUSE Linux Enterprise Server 15\"\nID=\"sles\"\nANSI_COLOR=\"0;32\"\nCPE_NAME=\"cpe:/o:suse:sles:15\"\n"
    parsed_dist_file_facts = {'distribution': 'SLES', 'distribution_version': '15'}
    assert DistributionFiles().parse_distribution_file_SUSE('SUSE', data, '/etc/os-release', {"distribution_release": 'NA', "distribution_version": 'NA'}) == (True, parsed_dist_file_facts)

    # SUSE

# Generated at 2022-06-20 19:18:34.520366
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    distro = DistributionFiles()
    distro.parse_distribution_file_Coreos('coreos', 'GROUP=stable', '/etc/os-release', {})
    distro.parse_distribution_file_Coreos('coreos', 'GROUP=beta', '/etc/os-release', {})
    distro.parse_distribution_file_Coreos('notcoreos', 'GROUP=beta', '/etc/os-release', {})
    distro.parse_distribution_file_Coreos('notcoreos', '', '/etc/os-release', {})


# Generated at 2022-06-20 19:18:38.083504
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    fake_path = os.path.realpath(__file__)
    bad_path = os.path.join(os.path.dirname(fake_path), "fake_file")
    df = DistributionFiles(path_list=[fake_path, bad_path])
    assert len(df.paths) == 1
    assert df.paths[0] == fake_path
    assert len(df.facts) == 0


# Generated at 2022-06-20 19:20:58.304584
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    # Test instantiation of the class
    dist = Distribution(None)
    dist_name = dist.get_distribution_DragonFly()
    assert dist_name['distribution_release'] == "4.9-RELEASE"


# Generated at 2022-06-20 19:21:04.652155
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    m = Mock()
    distribution = Distribution(m)
    m.run_command.return_value = (0, '11.0-RELEASE', '')
    assert distribution.get_distribution_FreeBSD() == {
        'distribution_release': '11.0-RELEASE',
        'distribution_major_version': '11',
        'distribution_version': '11.0'
    }

# Generated at 2022-06-20 19:21:11.582540
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    get_distribution_Darwin = Distribution.get_distribution_Darwin
    darwin_facts = get_distribution_Darwin()
    assert darwin_facts == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.12.6'}


# Generated at 2022-06-20 19:21:20.168752
# Unit test for constructor of class Distribution
def test_Distribution():
    # distribution = Distribution()
    # pylint: disable=protected-access
    # print(distribution.is_bsd)
    # print(distribution.is_linux)
    # print(distribution.is_hpux)
    pass


# ==============================================================
# Distribution Files
# ==============================================================


# pylint: disable=too-few-public-methods

# Generated at 2022-06-20 19:21:25.958540
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = Mock()
    module.run_command.return_value = 0, "7.2.0.0", ""
    d = Distribution(module)
    aix_facts = d.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.2'
    assert aix_facts['distribution_release'] == '2'


# Generated at 2022-06-20 19:21:29.851703
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    dist = Distribution(module)
    assert dist.get_distribution_SMGL()['distribution'] == "Source Mage GNU/Linux"


# Generated at 2022-06-20 19:21:38.405777
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    def _gen_data(dist_name, ver_name):
        return '''TYPE="%s"
NAME="%s %s"
VERSION_ID="%s"
PRETTY_NAME="%s %s"
''' % ('ID', dist_name, ver_name, ver_name, dist_name, ver_name)

    def _comp_result(name, data, path, result):
        collected_facts = {}
        module = FakeModule(params=dict())
        distfile = DistributionFiles(module, collected_facts)
        return distfile.parse_distribution_file_NA(name, data, path, collected_facts)

    def _check_result(data, result):
        p, r = _comp_result('NA', data, '/etc/os-release', result)
        assert p is True
        assert r

# Generated at 2022-06-20 19:21:45.948786
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    result = {
        'distribution_version': 'B.11.31',
        'distribution_release': '1588'
    }

    testmodule = AnsibleModule(
        argument_spec={
        }
    )

    testmodule.run_command = MagicMock(return_value=(0, "Ignored output", ""))

    distribution = Distribution(testmodule)

    result = distribution.get_distribution_HPUX()

    testmodule.run_command.assert_called_once_with(r"/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'", use_unsafe_shell=True)