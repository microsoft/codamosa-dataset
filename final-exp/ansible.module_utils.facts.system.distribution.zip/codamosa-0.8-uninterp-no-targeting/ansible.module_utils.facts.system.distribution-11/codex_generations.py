

# Generated at 2022-06-20 19:12:43.148192
# Unit test for constructor of class Distribution
def test_Distribution():
    """
    Check if the default constructor of Distribution works
    """
    assert Distribution



# Generated at 2022-06-20 19:12:44.086467
# Unit test for constructor of class Distribution
def test_Distribution():
    assert Distribution('module')


# Generated at 2022-06-20 19:12:57.961549
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = get_module_mock("Distribution")
    module.run_command.return_value = (0, "NetBSD 7.3.0 (GENERIC) #0: Mon Apr  6 18:15:17 UTC 2020", "")
    distribution = Distribution(module)
    facts = distribution.get_distribution_NetBSD()
    assert facts == {'distribution_release': '7.3.0', 'distribution_version': '7.3', 'distribution_major_version': '7'}
    module.run_command.return_value = (0, "NetBSD 7.2.1 (GENERIC) #0: Mon Apr  6 18:15:17 UTC 2020", "")
    facts = distribution.get_distribution_NetBSD()

# Generated at 2022-06-20 19:13:00.311458
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    d = Distribution()
    assert d.get_distribution_SMGL() == {'distribution': 'Source Mage GNU/Linux'}



# Generated at 2022-06-20 19:13:03.607863
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = FakeAnsibleModule()
    distro = Distribution(module=module)
    assert distro.get_distribution_facts() == {'distribution': 'Linux',
                                               'distribution_major_version': '7',
                                               'distribution_release': 'Core',
                                               'distribution_version': '7',
                                               'os_family': 'RedHat'}

# Generated at 2022-06-20 19:13:09.508548
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.distribution import DistributionFiles
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.distribution import get_distribution
    import re
    import os
    import os.path

    distro_name = "Mandriva"

    test_path = "/etc/mandriva-release"

    test_data = """
        Linux-Libre release 1.0 (Cooker)
        kernel 2.6.32.9-server-2mnb on an i586
        """
    test_data = test_data.strip()
    # Example data:
    # DISTRIB_ID="Mandriva Linux"
    # DISTRIB_RELEASE="2011.0"
    #

# Generated at 2022-06-20 19:13:21.513166
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    data = 'DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=18.06\nDISTRIB_REVISION=r7258-5eb055306f\nDISTRIB_CODENAME=rebootstrap-18.06\nDISTRIB_TARGET=ramips/mt7620\nDISTRIB_DESCRIPTION="OpenWrt Rebootstrap 18.06 r7258-5eb055306f"'
    path = ""
    name = ""
    collected_facts = {}
    distribution_files = DistributionFiles()
    expected = {'distribution': 'OpenWrt', 'distribution_release': 'rebootstrap-18.06', 'distribution_version': '18.06'}

# Generated at 2022-06-20 19:13:30.286389
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles

# Generated at 2022-06-20 19:13:41.361427
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles

# Generated at 2022-06-20 19:13:51.120993
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    import ansible.module_utils.facts.system.distribution as mod_distro
    import mock

    # create a class instance of DistributionFactCollector
    distro = DistributionFactCollector()

    # mock a module object
    mock_module = mock.MagicMock()

    str_lists = [
        'Linux {0} {1} {2} GNU/Linux',
        '{0} {1} {2} GNU/Linux',
        '{0} {1} {2} GNU/{3}',
        'GNU/Linux {0} {1} {2}',
        'GNU/{0} {0} {1} {2}',
    ]
    distro_os_family_list = []
    expected_distro_os_family_list = []

# Generated at 2022-06-20 19:14:30.256888
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    run_command_ = Mock()
    run_command_.return_value = (0, 'test_data', '')
    get_file_content_ = Mock()
    get_file_content_.return_value = 'test_data'
    get_uname_ = Mock()
    get_uname_.return_value = 'test_data'
    _file_exists_ = Mock()
    _file_exists_.return_value = True
    Distribution_ = Distribution(module=None)
    Distribution_.run_command = run_command_
    Distribution_.get_file_content = get_file_content_
    Distribution_.get_uname = get_uname_
    Distribution_._file_exists = _file_exists_
    distribution_facts = Distribution_.get_distribution_facts()

# Generated at 2022-06-20 19:14:44.249413
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = AnsibleModule({}, {}, [], False, False)
    dist = DistributionFiles(module)
    path = ['data/distribution_files/raspbian.txt', '/etc/os-release']
    data = get_file_content(path[0])
    facts = {'distribution_release': 'NA', 'distribution_version': 'NA'}
    name = 'Debian'
    flag, result = dist.parse_distribution_file_Debian(name, data, path[0], facts)
    assert flag == True
    assert result['distribution'] == 'Debian'
    assert result['distribution_release'] == '8.0'
    assert result['distribution_version'] == 'NA'

    data = get_file_content(path[1])
    path = path[1]
    flag,

# Generated at 2022-06-20 19:14:53.212040
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    DIST = 'OpenWrt'
    dist_file_facts_openwrt = {'distribution': DIST,
                               'distribution_release': 'stable',
                               'distribution_version': '18.06.1',
                               'distribution_file_path': '/etc/openwrt_release',
                               'distribution_file_variety': DIST,
                               'distribution_file_parsed': True}

    with open('/etc/openwrt_release', 'r') as openwrt_release_file:
        data = openwrt_release_file.read()

    file_path = '/etc/openwrt_release'
    facts_test_openwrt = DistributionFiles()
    data_test_openwrt = data
    parsed_dist_file, parsed_dist_file

# Generated at 2022-06-20 19:14:56.091925
# Unit test for function get_uname
def test_get_uname():
    flags = ('-v')
    assert get_uname(flags) is not None



# Generated at 2022-06-20 19:15:00.676784
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    import unittest
    class MockDistribution(Distribution):
        def __init__(self, module=None):
            self.module = module
    dc = MockDistribution()
    result = dc.get_distribution_SMGL()
    assert result['distribution'] == 'Source Mage GNU/Linux'

# Generated at 2022-06-20 19:15:13.784465
# Unit test for method parse_distribution_file_NA of class DistributionFiles

# Generated at 2022-06-20 19:15:19.452331
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    test_distribution_facts = {
        'distribution': 'Linux',
        'distribution_major_version': '1',
        'distribution_release': '1',
        'distribution_version': '1',
        'os_family': 'Linux',
    }
    test_module = MockModule()

    test_class = DistributionFactCollector()
    test_class.module = test_module
    test_class.name = 'distribution'
    result = test_class.collect()
    assert result == test_distribution_facts



# Generated at 2022-06-20 19:15:30.544818
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles

# Generated at 2022-06-20 19:15:44.012892
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    test_module_name = 'ansible.module_utils.facts.system.distribution.DistributionFiles'
    test_module = import_module(test_module_name)

    name = 'Mandriva'
    file_content = '''
#Generated by parse-release
NAME="Mandriva Linux"
VERSION="2011"
ID="mandriva"
VERSION_CODENAME="TwoPenguins"
PRETTY_NAME="Mandriva Linux 2011"
CODENAME="TwoPenguins"
'''
    df = test_module.DistributionFiles()

    res = df.parse_distribution_file_Mandriva(name, file_content, '', {})

    assert res[0] == True
    assert 'Mandriva' in res[1]

# Generated at 2022-06-20 19:15:46.686380
# Unit test for constructor of class Distribution
def test_Distribution():
    assert Distribution({}).__class__.__name__ == 'Distribution'

# Generated at 2022-06-20 19:16:18.704319
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    try:
        dist = DistributionFiles()
    except Exception:
        assert False


# Generated at 2022-06-20 19:16:25.971163
# Unit test for constructor of class Distribution
def test_Distribution():
    # Create test module
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    # Create instance of Distribution
    # and check if the object has been created properly
    dist = Distribution(module=module)
    assert dist is not None
    # Create instance of DistributionFiles
    # and check if the object has been created properly
    dist_files = DistributionFiles(module=module)
    assert dist_files is not None
    assert dist_files.distribution_files is not None


# Generated at 2022-06-20 19:16:31.937353
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec={})
    distributionObj = Distribution(module)

    freebsd_facts = distributionObj.get_distribution_FreeBSD()

    ansible_facts = {
        "distribution": "FreeBSD",
        "distribution_release": platform.release(),
        "os_family": "freebsd",
    }

    assert isinstance(freebsd_facts, dict)
    assert freebsd_facts.keys() >= ansible_facts.keys()



# Generated at 2022-06-20 19:16:36.637723
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(argument_spec=dict())
    distribution = Distribution(module=module)
    freebsd_facts = distribution.get_distribution_FreeBSD()

    assert freebsd_facts['distribution_release']
    assert freebsd_facts['distribution_version']
    assert freebsd_facts['distribution_major_version']



# Generated at 2022-06-20 19:16:48.560512
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    test_case = "test_DistributionFiles_parse_distribution_file_Coreos"
    df_obj = DistributionFiles(None, 'coreos')
    name = 'coreos'
    path = 'path'
    collected_facts = {'distribution_version': 'NA'}
    test_map = {
        'test1': {
            'data': 'test GROUP="test"',
            'expected': True,
            'expected_facts': {
                'distribution_release': 'test'
            }
        },
        'test2': {
            'data': '',
            'expected': False,
            'expected_facts': {}
        }
    }

# Generated at 2022-06-20 19:17:02.018294
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    class FakeModule():
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "/usr/bin/sw_vers -productVersion":
                return (0, "10.11", "")
        # when checking if the platform is darwin, use the platform module to
        # find out.  This will make the unit test more robust.
        def __getattr__(self, name):
            return getattr(platform, name)
    distribution = Distribution(FakeModule())
    darwin_facts = distribution.get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_major_version'] == '10'
    assert darwin_facts['distribution_version'] == '10.11'

#

# Generated at 2022-06-20 19:17:10.961018
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    class Options:
        def __init__(self):
            self.use_unsafe_shell = True
    class Module:
        def __init__(self):
            self.options = Options()
        def run_command(self, args, data=None, use_unsafe_shell=True):  # pylint: disable=unused-argument
            if args == '/usr/bin/uname -r':
                return (0, '5.11', '')
            if args == '/usr/bin/uname -v':
                return (0, 'Joyent_2020.01.16T01:43:47Z', '')

# Generated at 2022-06-20 19:17:19.453121
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    """Test constructor for DistributionFiles class."""
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule(argument_spec={})
    distfiles = DistributionFiles(ansible_module)
    assert isinstance(distfiles, DistributionFiles)
    assert ansible_module is distfiles.module
    assert os.path.isdir(distfiles.dist_files_dir)
    assert distfiles.dist_files_list is not None
    assert len(distfiles.dist_files_list) >= 1
    assert isinstance(distfiles.dist_files_list_paths, list)
    assert len(distfiles.dist_files_list_paths) >= 1
    ansible_module.fail_json(msg='Test completed successfully!')



# Generated at 2022-06-20 19:17:28.878690
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    m_cmd = MagicMock()
    m_cmd.run_command.return_value = 0, 'NetBSD 8.99.17 (GENERIC) #0: Sat May  5 20:20:42 UTC 2018', ''
    m = Distribution(m_cmd)
    res = m.get_distribution_NetBSD()
    assert res['distribution_release'] == '8.99.17'
    assert res['distribution_major_version'] == '8'
    assert res['distribution_version'] == '8.99'

# Generated at 2022-06-20 19:17:38.472484
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    collector = DistributionFactCollector()
    assert collector, "Failed to create an instance of DistributionFactCollector"
    assert collector.name == 'distribution', "Failed to create an instance of DistributionFactCollector with name 'distribution'"
    assert collector.get_fact_ids() == {'distribution_version', 'distribution_release', 'distribution_major_version', 'os_family'}, "Failed to create an instance of DistributionFactCollector with expected _fact_ids"


# Generated at 2022-06-20 19:18:22.340306
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    distribution_files = DistributionFiles()
    results = distribution_files.process_dist_files()
    assert 'distribution' in results  # distribution should be set
    assert 'distribution_file_path' in results  # distribution_file_path should be set
    assert 'distribution_file_variety' in results  # distribution_file_variety should be set


# Generated at 2022-06-20 19:18:30.838309
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import DistributionFiles
    dfile = DistributionFiles({})
    dfile.parse_distribution_file_Coreos('name', '', 'file_path', '')
    dfile.parse_distribution_file_Coreos('name', 'GROUP=""', 'file_path', '')



# Generated at 2022-06-20 19:18:37.988708
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files = DistributionFiles({})
    distro = 'Amazon'
    data = 'NAME="Amazon Linux AMI"\nVERSION="2021.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2021.03"\nPRETTY_NAME="Amazon Linux AMI 2021.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2021.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\nAmazon Linux AMI release 2021.03\n'
    path = '/etc/os-release'

# Generated at 2022-06-20 19:18:38.982696
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist_files = DistributionFiles()
    assert isinstance(dist_files, DistributionFiles)



# Generated at 2022-06-20 19:18:50.655149
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    import pytest

    df = DistributionFiles('', '', '', '', [])
    assert (df.module is not None)
    assert (df.file_list is not None)
    assert (df.file_paths is not None)
    assert (df.path is not None)

    df = DistributionFiles('', '', '', '', ['a', 'b'])
    assert (len(df.file_paths) == 2)
    assert (len(df.file_list) == 2)

    df = DistributionFiles('', '', '', '', ['c', 'd', 'e', 'f'])
    assert (len(df.file_paths) == 4)
    assert (len(df.file_list) == 4)


# Generated at 2022-06-20 19:18:58.577712
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # GIVEN: The input distribution name and expected output
    distros = [
        ('NA', 'Ubuntu', '16.04.1 LTS'),
        ('NA', 'Fedora', '26 (Twenty Six)'),
        ('NA', 'Red Hat Enterprise Linux Server', '7.4 (Maipo)')
    ]

    for name, distro, version in distros:
        # WHEN: Creating a DistributionFiles object
        d = DistributionFiles({})

        # THEN: Expected output is given
        assert d.parse_distribution_file_NA(name, distro, version, None)[1] == {'distribution': distro, 'distribution_version': version}


# Generated at 2022-06-20 19:19:08.109990
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_facts = DistributionFiles({}).parse_distribution_file_Slackware(
        'Slackware',
        '''
Slackware 13.37.0
''',
        '/etc/slackware-version',
        {},
        )
    assert dist_file_facts['distribution'] == 'Slackware'
    assert dist_file_facts['distribution_version'] == '13.37.0'

    dist_file_facts = DistributionFiles({}).parse_distribution_file_Slackware(
        'Slackware',
        '''
Slackware 14.0
''',
        '/etc/slackware-version',
        {},
        )
    assert dist_file_facts['distribution'] == 'Slackware'
    assert dist_file_facts['distribution_version']

# Generated at 2022-06-20 19:19:15.145621
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    # This will return a module object
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    distribution = Distribution(module=module)
    facts = distribution.get_distribution_facts()
    if 'distribution_version' not in facts or 'distribution_release' not in facts or 'distribution_major_version' not in facts:
        module.fail_json(msg='missing required version or release info')

    assert DistributionFactCollector._fact_ids.issubset(set(facts.keys()))



# Generated at 2022-06-20 19:19:27.297943
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
  df = DistributionFiles()
  line = 'PRETTY_NAME="CentOS Linux 8 (Core)"'
  path = '/etc/os-release'
  name = 'CentOS'
  data = 'PRETTY_NAME="CentOS Linux Stream"'
  collected_facts = {'distribution_release': 'NA'}
  assert not df.parse_distribution_file_CentOS(name, data, path, collected_facts)
  collected_facts = {'distribution_release': 'NA'}
  assert df.parse_distribution_file_CentOS(name, line, path, collected_facts)



# Generated at 2022-06-20 19:19:38.532193
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec=dict())

    def run_command_safe(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        return 0, "HPUX11.31", "Dummy Error"

    module.run_command = run_command_safe

    distribution = Distribution(module)
    distribution_version = distribution.get_distribution_HPUX()

# Generated at 2022-06-20 19:20:32.174283
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # create a fake module:
    module = AnsibleModule(argument_spec={
        "content": {"required": False, "type": "str"}
    }, SuppressMissing='data')
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_NetBSD()
    assert distribution_facts['distribution_release'] == platform.release()
    assert distribution_facts['distribution_version'] == platform.release()
    assert distribution_facts['distribution_major_version'] == platform.release().split('.')[0]


# Generated at 2022-06-20 19:20:41.049133
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    '''
    Unit test for method collect of class DistributionFactCollector
    '''
    module = AnsibleModule()
    collector = DistributionFactCollector()
    facts = {
        'distribution': 'Debian',
        'distribution_version': '9.9',
        'distribution_release': 'stretch',
        'distribution_major_version': '9',
        'os_family': 'Debian'
    }
    assert collector.collect(module, facts) == facts

# Generated at 2022-06-20 19:20:43.297007
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    distribution = Distribution(None)
    distribution_facts = distribution.get_distribution_SMGL()
    assert distribution_facts['distribution'] == 'Source Mage GNU/Linux'



# Generated at 2022-06-20 19:20:49.981118
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """
    Test method get_distribution_SunOS of class Distribution
    """
    module = AnsibleModule(
        argument_spec=dict()
    )
    Distribution_instance = Distribution(module)
    result = Distribution_instance.get_distribution_SunOS()
    assert isinstance(result, dict)

# Generated at 2022-06-20 19:20:57.166261
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    file = DistributionFiles()

# Generated at 2022-06-20 19:20:59.618116
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    # Test instantiation of DistributionFactCollector
    DistributionFactCollector()



# Generated at 2022-06-20 19:21:05.797736
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distribution = Distribution(module)
    distribution.module.run_command = MagicMock(return_value = (0, 'stdoutval', 'stderrval'))
    distribution.get_distribution_HPUX()
    distribution.module.run_command.assert_called_with('/usr/sbin/swlist |egrep \'HPUX.*OE.*[AB].[0-9]+\.[0-9]+\'', use_unsafe_shell=True)



# Generated at 2022-06-20 19:21:13.021574
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    testfile = DistributionFilesTest()
    name = 'Alpine'
    data = '23.1.1'
    path = '/etc/os-release'
    collected_facts = { 'distribution': 'NA',
                        'distribution_version': 'NA'}
    testfile.parse_distribution_file_Alpine(name,data,path,collected_facts)

# Generated at 2022-06-20 19:21:25.199876
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():

        # mock_module = MagicMock()
        mock_module = MagicMock()
        mock_module.run_command = MagicMock(return_value = (0, 'OpenBSD 6.2-stable (GENERIC) #84: Wed Nov  1 20:50:32 MST 2017     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC', ''))
        d = Distribution(mock_module)
        ret = d.get_distribution_OpenBSD()
        assert ret == {'distribution_release': platform.release(), 'distribution_version': '6.2'}


if __name__ == '__main__':
    test_Distribution_get_distribution_OpenBSD()

# Generated at 2022-06-20 19:21:36.747172
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_facts = DistributionFiles()
    name = 'Slackware'
    data = 'Slackware'
    path = '/etc/slackware-version'
    collected_facts = {'distribution': 'Slackware',
                       'distribution_release': 'NA',
                       'distribution_version': 'NA'}
    parsed_dist_file_facts = dist_file_facts.parse_distribution_file(name, data, path, collected_facts)
    assert parsed_dist_file_facts['distribution_file_parsed']
    assert parsed_dist_file_facts['distribution_file_variety'] == 'Slackware'
    assert parsed_dist_file_facts['distribution'] == 'Slackware'
