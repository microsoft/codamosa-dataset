

# Generated at 2022-06-20 19:12:55.315785
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule()
    module.run_command = lambda x: ('', 'v4.6.2-RELEASE-p6', '')
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_DragonFly()
    assert distribution_facts['distribution_major_version'] == '4'
    assert distribution_facts['distribution_version'] == '4.6.2'
    assert distribution_facts['distribution_release'] == platform.release()


# Generated at 2022-06-20 19:13:02.271613
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)
    hpux_facts = dist.get_distribution_HPUX()
    assert len(hpux_facts) == 2
    assert hpux_facts.get('distribution_release', None) is not None
    assert hpux_facts.get('distribution_version', None) is not None



# Generated at 2022-06-20 19:13:08.494531
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Setup test data
    path = '/etc/lsb-release'
    data = """
# LSB_VERSION=core-9.20160110ubuntu0.2
DISTRIB_ID=CoreOS
DISTRIB_RELEASE=1235.4.0
DISTRIB_CODENAME=Redwing
DISTRIB_DESCRIPTION="CoreOS 1235.4.0"
NAME="CoreOS"
ID=coreos
""".strip()
    # Setup the mock module
    module = Mock()

    # Setup the class with the mock module
    dist = DistributionFiles(module)
    # Run the method with the test data
    result = dist.parse_distribution_file_Coreos('CoreOS', data, path, {})
    # Check the results

# Generated at 2022-06-20 19:13:18.453139
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = MagicMock()
    module.run_command.return_value = 0, 'v4.1.19-RELEASE', ''
    expected = {
        'distribution_release': '1-RELEASE',
        'distribution_major_version': '4',
        'distribution_version': '4.1.19'
    }

    test_obj = Distribution(module)
    result = test_obj.get_distribution_DragonFly()
    module.run_command.assert_called_once_with('/sbin/sysctl -n kern.version')

    assert result == expected

# Generated at 2022-06-20 19:13:28.156410
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    """
    Test DistributionFiles.parse_distribution_file_Slackware() method
    """
    test_obj = DistributionFiles()
    # Sample data for test
    test_obj.module = DummyAnsibleModule()
    test_obj.distribution_file_parsers = {'Slackware': test_obj.parse_distribution_file_Slackware}
    data = """Slackware 14.2 \r\n Slackware 14.1"""
    name = 'Slackware'
    path = '/etc/slackware-release'
    # Expected output for above test data
    exp_dist_file_facts = {'distribution': 'Slackware', 'distribution_version': '14.2'}
    # Result from call to DistributionFiles.parse_distribution_file_Slackware()
    result

# Generated at 2022-06-20 19:13:40.270649
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # data is a line from the /etc/release file
    data = 'OmniOS r151018 v5.11 omnios-869dabc'
    sunos_facts = {'distribution': 'OmniOS',
                   'distribution_release': 'OmniOS r151018 v5.11 omnios-869dabc'}
    with mock.patch('ansible.module_utils.facts.system.distribution.get_uname', return_value='OmniOS r151018 v5.11 omnios-869dabc'), \
        mock.patch('ansible.module_utils.facts.system.distribution.get_file_content', return_value=data):
        result = Distribution.get_distribution_SunOS(mock.Mock())
        assert result == sunos_facts



# Generated at 2022-06-20 19:13:47.511073
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    module = AnsibleModule(argument_spec={})
    if not _HAVE_DBUS:
        module.fail_json(msg='Could not load dbus module')

    name = 'clearlinux'

# Generated at 2022-06-20 19:14:01.132805
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    class A:
        def __init__(self):
            self.run_command = lambda x: ("0", "OpenWrt test", "")
    r = DistributionFiles(module=A())
    a = """DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=15.05-rc3
DISTRIB_REVISION=r49633
DISTRIB_CODENAME=chaos_calmer
DISTRIB_TARGET=brcm2708/bcm2708
DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05-rc3"
DISTRIB_TAINTS=""
"""
    b = "/etc/os-release"
    c = {}
    v = r.parse_distribution_file_OpenWrt("OpenWrt", a, b, c)
    assert type(v)

# Generated at 2022-06-20 19:14:08.937093
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=False),
            data=dict(type='str', required=False),
            collected_facts=dict(type='dict', required=False),
        ),
        supports_check_mode=False,
    )

    distribution = DistributionFiles(module)

    # test no data
    coreos_facts = {}
    result = distribution.parse_distribution_file_Coreos('NA', '', '/etc/os-release', coreos_facts)
    assert result == (False, {})

    # test success

# Generated at 2022-06-20 19:14:22.266435
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    """Test the parse_distribution_file_CentOS method of DistributionFiles."""

    # No CentOS Stream
    _name = 'CentOS'
    _data = 'CentOS Linux release 8.1.1911 (Core)'
    _path = '/etc/os-release'
    _collected_facts = {'distribution_release': 'NA'}
    _expected_ret = (False, {})
    _ret = DistributionFiles().parse_distribution_file_CentOS(_name, _data, _path, _collected_facts)
    assert _ret == _expected_ret, "ERROR: parse_distribution_file_CentOS returned: %s" % _ret

    # CentOS Stream
    _name = 'CentOS'
    _data = 'CentOS Linux release 8.0.1905 (Core)'

# Generated at 2022-06-20 19:15:05.840525
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    facts = {}
    distrib_file = DistributionFiles({'ansible_system': 'Linux', 'ansible_distribution': 'Clear Linux', 'ansible_distribution_version': '22770'})

# Generated at 2022-06-20 19:15:08.169135
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    mmodule = MockAnsibleModule()
    distribution = Distribution(mmodule)
    result = distribution.get_distribution_SMGL()
    assert 'Source Mage GNU/Linux' == result['distribution']

# Generated at 2022-06-20 19:15:14.434247
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    dist_files = DistributionFiles()
    # TODO: mock DistributionFiles.module, collect_facts.get_file_content()
    name = 'Alpine'
    path = 'some/path'
    collected_facts = {'distribution': 'Alpine'}
    data = 'foo'
    result = dist_files.parse_distribution_file_Alpine(name, data, path, collected_facts)
    assert result == (True, {'distribution': 'Alpine', 'distribution_version': 'foo'})


# Generated at 2022-06-20 19:15:28.154411
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    mock_module = MagicMock(module=False, name='mock_module')

# Generated at 2022-06-20 19:15:36.737408
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    fact_collector = DistributionFactCollector()
    assert fact_collector.name == 'distribution'

    assert 'distribution_version' in fact_collector._fact_ids
    assert 'distribution_release' in fact_collector._fact_ids
    assert 'distribution_major_version' in fact_collector._fact_ids
    assert 'os_family' in fact_collector._fact_ids

    assert hasattr(fact_collector, 'collect')
    # assert hasattr(fact_collector, '_get_virtual')



# Generated at 2022-06-20 19:15:46.950731
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    '''
    test case for DistributionFiles.parse_distribution_file_ClearLinux
    '''
    collected_facts = {'distribution': 'NA'}
    name = 'clearlinux'
    data = '''NAME="Clear Linux"
VERSION_ID=31040'''
    path = '/etc/os-release'
    distribution_files = DistributionFiles()
    parsed, clear_facts = distribution_files.parse_distribution_file_ClearLinux(name, data, path, collected_facts)
    assert parsed
    assert clear_facts['distribution'] == 'Clear Linux'
    assert clear_facts['distribution_major_version'] == '31040'
    assert clear_facts['distribution_version'] == '31040'



# Generated at 2022-06-20 19:15:58.363252
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    from ansible.module_utils.facts.system.distribution import get_distribution
    from ansible.module_utils.facts.system.distribution import get_file_content

    class ModuleMock(object):
        def get_bin_path(self, path):
            return path

        @staticmethod
        def run_command(cmd):
            return 0, '', ''

    # init the class
    d = DistributionFiles(ModuleMock())
    # SLES

# Generated at 2022-06-20 19:16:04.655324
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    def mock_module_run_command(command):
        return 0, "Test Distribution", ""

    module = MagicMock()
    module.run_command = mock_module_run_command
    distribution_fact_collector = DistributionFactCollector(module=module)
    result = distribution_fact_collector.collect()
    assert 'distribution' in result
    assert 'distribution_release' in result
    assert 'distribution_version' in result
    assert 'os_family' in result



# Generated at 2022-06-20 19:16:18.555764
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    # testing a proper alpine file
    dist_file_content = '3.8.1'
    dist = DistributionFiles()
    name = 'Alpine'
    path = '/etc/alpine-release'
    collected_facts = {'distribution': 'Alpine'}
    out_dict = {'distribution': 'Alpine', 'distribution_version': '3.8.1'}
    assert dist.parse_distribution_file_Alpine(name, dist_file_content, path, collected_facts) == (True, out_dict)
    #testing a wrong alpine file
    dist_file_content = 'Hello world'
    collected_facts = {'distribution': 'Ubuntu'}
    out_dict = {'distribution': 'Alpine', 'distribution_version': 'NA'}

# Generated at 2022-06-20 19:16:27.187376
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    file_parse = DistributionFiles()
    facts = {}
    parsed, mandriva_facts = file_parse.parse_distribution_file_Mandriva('Mandriva',
        'DISTRIB_ID="Mandriva"\nDISTRIB_RELEASE="2008"\nDISTRIB_CODENAME="Xtreme"\nDISTRIB_DESCRIPTION="Mandriva Linux Xtreme 2008"', '/etc/lsb-release', facts)
    assert parsed == True
    assert mandriva_facts['distribution'] == 'Mandriva'
    assert mandriva_facts['distribution_version'] == '2008'
    assert mandriva_facts['distribution_release'] == 'Xtreme'


# Generated at 2022-06-20 19:17:33.172838
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    with open('tests/unit/files/distribution_files/coreos', 'r') as myfile:
        data = myfile.read()
    path = '/etc/os-release'
    collected_facts = {'distribution_release': 'NA'}
    dist_files = DistributionFiles(module=None)
    name = 'Coreos'
    ret = dist_files.parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert ret[0] is True
    assert ret[1]['distribution_release'] == 'Beta'


# Generated at 2022-06-20 19:17:42.676028
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # test simple Debian

    data = ''
    path = '/etc/lsb-release'
    name = 'Debian'
    distro_file_obj = DistributionFiles()
    distro_file_obj.parse_distribution_file_Debian(name, data, path, {'distribution_release': 'NA'})
    distro_file_obj.parse_distribution_file_Debian(name, 'DISTRIB_CODENAME=jessie', '/etc/lsb-release', {'distribution_release': 'NA'})

    # test simple Ubuntu
    distro_file_obj.get_distribution_facts()

    # test simple Devuan

# Generated at 2022-06-20 19:17:54.806064
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    import pytest

    df = DistributionFiles()

    df_path = '/etc/redhat-release'
    df_name = 'CentOS Linux'
    df_data = 'CentOS Linux release 7.6.1810 (Core)'
    df_expect = {
        'distribution': 'CentOS',
        'distribution_file_path': '/etc/redhat-release',
        'distribution_file_parsed': True,
        'distribution_file_variety': 'CentOS Linux'
    }

    df_res = df.process_dist_files(df_name, df_data, df_path, {})
    assert df_expect == df_res

    df_path = '/etc/os-release'
    df_name = 'NA'

# Generated at 2022-06-20 19:18:01.413872
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)
    distribution_facts = distro.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '11'
    assert distribution_facts['distribution_version'] == '11.4.1'


# Generated at 2022-06-20 19:18:13.542477
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = MagicMock()
    dist = Distribution(module=module)
    expected_openbsd_facts = {'distribution_release': '6.3', 'distribution_version': '6.3'}

    module.run_command.return_value = (0, 'OpenBSD 6.3 (GENERIC) #1: Wed Apr 26 03:53:54 MDT 2017     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC', '')

    openbsd_facts = dist.get_distribution_OpenBSD()

    module.run_command.assert_called_once_with("/sbin/sysctl -n kern.version")
    assert openbsd_facts == expected_openbsd_facts

    # test when matching fails

    module

# Generated at 2022-06-20 19:18:25.654975
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    dist_files = DistributionFiles(module)
    collected_facts = {
        'distribution': 'Ubuntu',
        'distribution_version': '18.04',
        'distribution_major_version': '18',
        'distribution_release': 'bionic',
        'distribution_file_parsed': True,
        'distribution_file_variety': 'Ubuntu',
        'distribution_file_path': '/etc/lsb-release',
    }
    dist_file_path = '/etc/lsb-release'
    dist_file_name = 'Ubuntu'

# Generated at 2022-06-20 19:18:35.830724
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():

    df = DistributionFiles()
    assert_equals(df.parse_distribution_file_Amazon('Amazon', 'Amazon', '/etc/os-release', {'distribution_version': 'NA'} )[1]['distribution'], 'Amazon')
    assert_equals(df.parse_distribution_file_Amazon('Amazon', 'Amazon', '/etc/os-release', {'distribution_version': 'NA'} )[1]['distribution_version'], 'NA')

    assert_equals(df.parse_distribution_file_Amazon('Amazon', 'Amazon', '/etc/system-release-cpe', {'distribution_version': 'NA'} )[1]['distribution'], 'Amazon')

# Generated at 2022-06-20 19:18:47.812247
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    # Setting up arguments for the Unit test
    arguments = dict()
    arguments['module'] = MagicMock(spec_set=AnsibleModule)
    arguments['module'].run_command.return_value = ('', '', None)
    arguments['collected_facts'] = {}
    # Executing the Unit test
    fact_collector = DistributionFactCollector()
    fact_collector.collect(**arguments)


    # Checking if the Unit test executed properly
    assert arguments['module'].run_command.call_count == 1
    assert arguments['module'].run_command.call_args[1]['use_unsafe_shell'] == True
    # Checking if the Unit test executed properly
    assert arguments['module'].run_command.call_count == 1

# Generated at 2022-06-20 19:18:54.729684
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = FakeModule({'uname': 'Darwin mfenniak.local 15.6.0 Darwin Kernel Version 15.6.0: Mon Aug 29 20:21:34 PDT 2016; root:xnu-3248.60.11.2.1~1/RELEASE_X86_64 x86_64'}, [])
    distribution = Distribution(module)
    expected_results = {
        'distribution': 'MacOSX',
        'distribution_major_version': '15',
        'distribution_version': '10.11.6'
    }
    results = distribution.get_distribution_Darwin()
    assert results == expected_results



# Generated at 2022-06-20 19:19:07.334322
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    import sys
    import os

    if not os.path.exists('/etc/product'):
        os.system('touch /etc/product')
    file_data = """
    Title: OmniOS r151008
    Version: OmniOS r151008 v5.11
    Kernel: v5.11/ZFS@0.6.2.2-3
    """
    with open('/etc/product', 'w') as fd:
        fd.write(file_data)
    assert Distribution.get_distribution_SunOS(sys, {}) == {'distribution': 'OmniOS', 'distribution_release': 'OmniOS r151008', 'distribution_version': 'OmniOS r151008'}

# Generated at 2022-06-20 19:20:29.313166
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    df = DistributionFiles()
    # linux-2.6.32-smp-13.0.1
    # file name string
    name = "Slackware"
    data = 'Slackware 12.2.0'
    path = '/etc/slackware-version'
    collected_facts = {}
    parsed_dist = 'Slackware'
    parsed_v = '12.2.0'
    parsed, slackware_facts = df.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert parsed is True
    assert slackware_facts['distribution'] == parsed_dist
    assert slackware_facts['distribution_version'] == parsed_v

    # file name string
    name = "Slackware"

# Generated at 2022-06-20 19:20:32.033072
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    assert Distribution.get_distribution_OpenBSD(None) is not None

# Generated at 2022-06-20 19:20:43.798240
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distro_files_obj = DistributionFiles()
    name = 'Amazon'
    data = """NAME="Amazon Linux AMI"
VERSION="2018.03"
ID="amzn"
ID_LIKE="rhel fedora"
VERSION_ID="2018.03"
PRETTY_NAME="Amazon Linux AMI 2018.03"
ANSI_COLOR="0;33"
CPE_NAME="cpe:/o:amazon:linux:2018.03:ga"
HOME_URL="http://aws.amazon.com/amazon-linux-ami/"
"""
    path = '/etc/os-release'
    collected_facts = {'distribuiton_major_version': 'NA', 'distribution_version': 'NA', 'distribution': 'NA'}
    return_code, facts = distro_files_obj.parse_distribution_file

# Generated at 2022-06-20 19:20:50.420536
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    'Unit test for method collect of class DistributionFactCollector'
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils._text import to_bytes
    collected_facts={}

# Generated at 2022-06-20 19:20:57.278273
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles

# Generated at 2022-06-20 19:21:07.017732
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Test 1
    data = 'NAME="CentOS Stream"'
    name = 'CentOS'
    path = '/etc/os-release'

    # Test 1
    # Test a case if the distribution is CentOS Stream. It should return
    # True and a dictionary with distribution_release value set to Stream
    collected_facts = {'distribution_release': 'NA'}
    dist_files = DistributionFiles(module=MagicMock())
    result = dist_files.parse_distribution_file_CentOS(name, data, path, collected_facts)
    true_result = (True, {'distribution_release': 'Stream'})
    assert result == true_result
# end of test_DistributionFiles_parse_distribution_file_CentOS()



# Generated at 2022-06-20 19:21:13.454897
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # Default return value is False, dummy module is used for testing
    distribution = Distribution(None)
    # This method calls get_file_content, so we need to mock it
    get_file_content_orig = os.get_file_content

    # Mock output of /etc/release

# Generated at 2022-06-20 19:21:25.680533
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    df = DistributionFiles()
    # distribution_file_path: '/etc/os-release'
    # distribution_file_parsed: 'Amazon', 'LinuxMint'
    # distribution_file_variety: 'Amazon', 'LinuxMint'
    # distribution_file_data: 'Amazon Linux AMI release 2016.09\nNAME="Amazon Linux AMI 2016.09"\n'
    # distribution_file_data: 'NAME="Ubuntu"\nVERSION="14.04, Trusty Tahr"\nID=ubuntu\nID_LIKE=debian\n'
    # distribution_file_data: 'PRETTY_NAME="Raspbian GNU/Linux 9 (stretch)"\nNAME="Raspbian GNU/Linux"\nVERSION_ID="9"\nVERSION="9 (stretch)"\nID=raspbian\

# Generated at 2022-06-20 19:21:31.820507
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(
        argument_spec = dict(
        )
    )

    distribution = Distribution(module)
    distribution_info = distribution.get_distribution_Darwin()
    assert distribution_info['distribution'] == 'MacOSX'



# Generated at 2022-06-20 19:21:39.025849
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    # Given a module, a mocked os module, and a mocked content for os.uname -v and /etc/release
    module_mock = MagicMock()
    os_mock = MagicMock()
    def os_uname(options):
        if options == "":
            return "SunOS 5.11 oi_151a8 i86pc i386 i86pc"
        else:
            return "SunOS 5.11 oi_151a8 i86pc i386 i86pc"
    os_mock.uname = MagicMock(side_effect=os_uname)
    content_os_release = """
        SmartOS 20131205T221610Z
        opensolaris.org
        """
    content_etc_release = """
        OpenIndiana Development oi_151a8 October 2012
        """
   