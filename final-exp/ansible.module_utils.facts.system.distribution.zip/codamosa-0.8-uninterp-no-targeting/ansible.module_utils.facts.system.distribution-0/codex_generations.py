

# Generated at 2022-06-20 19:12:39.993560
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    '''
    Unit tests for methods of class Distribution
    '''
    class MockModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, command, use_unsafe_shell=False):
            return 0, '', ''

    def get_uname(module, flags=None):
        return ''

    def get_file_content(path):
        if path == '/etc/release':
            return "Source Mage GNU/Linux 0.9.7-pre1"

    facts = {}
    test_distro = Distribution(module=MockModule(facts))
    actual = test_distro.get_distribution_SMGL()

    # assert that we are getting the expected dictionary back,
    # and nothing more.

# Generated at 2022-06-20 19:12:49.096641
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    '''
    Test method parse_distribution_file_Amazon of class DistributionFiles
    '''
    temp_dir = tempfile.mkdtemp(prefix="ansible_unittesting_")
    os_release_file = temp_dir + '/etc/os-release'
    file_handle = open(os_release_file, 'w')

# Generated at 2022-06-20 19:12:49.633638
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    pass

# Generated at 2022-06-20 19:12:57.673216
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    # create instance of class DistributionFiles
    parsed_files_instance = DistributionFiles()
    # test case 1:
    # input data: name = Alpine, data = 3.11.6, path = /etc/alpine-release,
    # collected_facts = {}
    # expected result: True, {'distribution': 'Alpine', 'distribution_version': '3.11.6'}
    print("Unit test for method parse_distribution_file_Alpine of class DistributionFiles")
    name = 'Alpine'
    data = '3.11.6'
    path = '/etc/alpine-release'
    collected_facts = {}
    actual_output = parsed_files_instance.parse_distribution_file_Alpine(name, data, path, collected_facts)

# Generated at 2022-06-20 19:13:07.026859
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    distribution = Distribution(module=None)
    distro_facts = distribution.get_distribution_facts()
    if is_system_linux():
        assert distro_facts['distribution'] == 'Linux'
        if 'CentOS' in distro_facts['distribution']:
            assert distro_facts['distribution'] == 'CentOS'
            assert distro_facts['distribution_release'] == '7'
            assert distro_facts['distribution_version'] == '7'
        else:
            assert distro_facts['distribution'] == 'Debian'
            assert distro_facts['distribution_version'] == '9'
            assert distro_facts['distribution_release'] == 'stretch'

# Generated at 2022-06-20 19:13:19.779211
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    distfacts = Distribution(module)
    oslevel_return_str = 'B.11.31'
    swlist_return_str = 'HPUX.11.31.1909.B.11.31.1909             : OE Maintenance Bundle'
    with mock.patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.Distribution.module.run_command') as run_command:
        run_command.side_effect = [(0, oslevel_return_str, None), (0, swlist_return_str, None)]
        hpux_facts = distfacts.get_distribution_HPUX()
        assert hpux_facts['distribution_version'] == 'B.11.31'
        assert hpux_facts['distribution_release'] == '1909'


# Generated at 2022-06-20 19:13:25.602352
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():

    import ansible.module_utils.distro.distro_files

    df = DistributionFiles()
    assert isinstance(df, DistributionFiles)

    assert len(df.distro_file_parsers) == 35
    assert df.distro_file_parsers['Slackware']['parser_name'] == 'Slackware'  # verify a parser name matches a distribution name


# Generated at 2022-06-20 19:13:39.084181
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():

    # Data to be mocked by the mock
    data_to_mocked = dict(
        platform_release = '7.0',
        sysctl_out = 'NetBSD 7.0 (GENERIC) amd64',
    )

    # Mocked function
    def mocked_get_file_content(*args):
        data = data_to_mocked.get('get_file_content')
        if data is None:
            return None
        else:
            return data.get(*args)

    module_definition = imp.new_module('ansible_module')
    module_definition.module = imp.new_module('module')
    module_definition.module.run_command = MagicMock(name="module_run_command", return_value=data_to_mocked.get('run_command_out'))
    module_definition

# Generated at 2022-06-20 19:13:45.580069
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # Arrange
    module = AnsibleModule(argument_spec=dict())
    df = DistributionFiles(module)
    name='Centos'
    data = 'CentOS Stream'
    path = '/etc/os-release'
    collected_facts = dict()

    # Act
    result = df.parse_distribution_file_CentOS(name, data, path, collected_facts)

    # Assert
    assert result[0], 'Should return True if CentOS Stream found in distribution file'
    assert result[1] == {'distribution_release': 'Stream'}, f'Should return {{"distribution_release": "Stream"}} if CentOS Stream found in distribution file'


# Generated at 2022-06-20 19:13:51.201610
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    # TODO: create a method to create a mock module and pass that in, so we don't have to mock for each test
    mock_module = MagicMock()

    # test that passed in params are returned as is for non linux platforms
    mock_module.run_command.return_value = (0, "AIX\n", "")
    mock_module.run_command.side_effect = lambda _, **kwargs: (0, "/etc/release: IBM,7036-6C1", "") if kwargs.get('use_unsafe_shell') == True else (0, "AIX\n", "")
    distribution = Distribution(mock_module)
    result = distribution.get_distribution_facts()

# Generated at 2022-06-20 19:14:33.495510
# Unit test for method parse_distribution_file_NA of class DistributionFiles

# Generated at 2022-06-20 19:14:46.013608
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    # First test
    distname = "OpenWrt"
    datainput = """
    DISTRIB_ID=OpenWrt
    DISTRIB_RELEASE=18.06.6
    DISTRIB_REVISION=r0
    DISTRIB_CODENAME=dunfell
    DISTRIB_TARGET=mvebu/cortexa9
    DISTRIB_DESCRIPTION="OpenWrt 18.06.6 r0"
    DISTRIB_TAINTS=
    """
    pathname = "/etc/openwrt_release"
    collected_facts = {"distribution": "OpenWrt", "distribution_release": "NA", "distribution_version": "NA"}

# Generated at 2022-06-20 19:14:57.186600
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    from ansible.module_utils.facts.collector.system import DistributionFactCollector
    import ansible_collections.community.general.plugins.module_utils.facts.system.distribution as distribution
    import ansible_collections.community.general.plugins.module_utils.facts.system.distribution as distribution_files
    import platform
    import platform

    aix_facts = {}
    aix_facts['distribution_release'] = platform.release()
    rc, out, err = DistributionFactCollector.run_command("/usr/bin/oslevel")
    data = out.split('.')
    aix_facts['distribution_major_version'] = data[0]

# Generated at 2022-06-20 19:15:04.873425
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    fs = DistributionFiles()

# Generated at 2022-06-20 19:15:08.662693
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():

    # create an instance of Distribution
    dist = Distribution(None)

    # check when platform.system() gives linux
    system = "linux"

    # call the get_distribution_facts
    distribution_facts = dist.get_distribution_facts()

    # check if the key distribution has the value linux
    assert distribution_facts["distribution"] == system



# Generated at 2022-06-20 19:15:16.603417
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    collected_facts = {}
    module = MagicMock()
    os.path.exists = MagicMock()

    # Test Slackware
    dist_file_paths = ['/etc/slackware-version']
    dist_file_data = ['Slackware 14.2 ', 'Slackware 14.2.1', 'Slackware 15.0 Beta 1']

    i = 0
    for path in dist_file_paths:
        os.path.exists.return_value = True
        os.path.islink.return_value = False
        get_file_content = MagicMock(return_value=dist_file_data[i])
        i += 1

        distribution_files = DistributionFiles(module, collected_facts)
        distribution_files.get_file_content = get_file_content

        distribution_files

# Generated at 2022-06-20 19:15:18.879636
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    assert Distribution.get_distribution_AIX() == None


# Generated at 2022-06-20 19:15:30.342648
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    DUT = DistributionFiles()
    name = 'NA'
    data = '''NAME="CentOS Linux"
VERSION="7 (Core)"
ID="centos"
ID_LIKE="rhel fedora"
VERSION_ID="7"
PRETTY_NAME="CentOS Linux 7 (Core)"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:centos:centos:7"
HOME_URL="https://www.centos.org/"
BUG_REPORT_URL="https://bugs.centos.org/"

CENTOS_MANTISBT_PROJECT="CentOS-7"
CENTOS_MANTISBT_PROJECT_VERSION="7"
REDHAT_SUPPORT_PRODUCT="centos"
REDHAT_SUPPORT_PRODUCT_VERSION="7"
'''
   

# Generated at 2022-06-20 19:15:38.701728
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    module = AnsibleModule(argument_spec={})
    df = DistributionFiles(module)
    data = '''NAME="Mandriva Linux"
VERSION="2011.0"
ID="mandriva"
ID_LIKE="rpmforge mandrake fedora redhat"
VERSION_ID="2011.0"
PRETTY_NAME="Mandriva Linux 2011.0"
'''
    expected = dict(
        distribution='Mandriva',
        distribution_version='2011.0',
        distribution_release=None,
    )
    actual = df.parse_distribution_file_Mandriva('Mandriva', data, '/tmp/mandriva.txt', dict())[1]
    assert actual == expected


# Generated at 2022-06-20 19:15:43.258306
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_files = DistributionFiles(module=AnsibleModule(context=dict()))
    assert distribution_files.parse_distribution_file_ClearLinux("Clear Linux OS", "", "", dict())[1]['distribution'] == 'Clear Linux OS'

# Generated at 2022-06-20 19:17:05.625691
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distro_obj = Distribution(module=module)
    rc, out, err = module.run_command("uname -s")
    if out.lower().strip() == 'netbsd':
        rc, out, err = module.run_command("uname -r")
        netbsd_facts = distro_obj.get_distribution_NetBSD()
        assert netbsd_facts['distribution_release'] == out.strip()
        assert re.match(r'\d+', out.strip())
        netbsd_facts = distro_obj.get_distribution_NetBSD()
        assert netbsd_facts['distribution_version'] == out.strip()



# Generated at 2022-06-20 19:17:09.668583
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    module = AnsibleModule(argument_spec={})
    d = Distribution(module)
    smgl_facts = d.get_distribution_SMGL()
    assert smgl_facts['distribution'] == 'Source Mage GNU/Linux'


# Generated at 2022-06-20 19:17:11.831816
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    # FIXME: write unit test
    pass




# Generated at 2022-06-20 19:17:20.758405
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    dist_file = DistributionFiles({'path': '/etc/os-release'})
    dist_file_parsed = dist_file.parse_distribution_file_CentOS('CentOS', 'CentOS Stream', '/etc/os-release', {})
    assert dist_file_parsed[0]

    dist_file = DistributionFiles({'path': '/etc/os-release'})
    dist_file_parsed = dist_file.parse_distribution_file_CentOS('CentOS', 'CentOS Linux', '/etc/os-release', {})
    assert not dist_file_parsed[0]


if __name__ == "__main__":
    test_DistributionFiles_parse_distribution_file_CentOS()

# Generated at 2022-06-20 19:17:28.098892
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    module = AnsibleModule(argument_spec={})
    df = DistributionFiles(module)
    assert df is not None
    assert df.module is not None
    assert df.supported_files == ['/etc/os-release', '/etc/redhat-release', '/etc/system-release', '/etc/lsb-release', '/etc/SuSE-release']
    df.get_facts()



# Generated at 2022-06-20 19:17:41.187242
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    mock_platform = MagicMock(platform)
    mock_platform.system.return_value = 'Darwin'
    mock_platform.release.return_value = '16.7.0'
    mock_platform.version.return_value = 'Darwin Kernel Version 16.7.0: Fri Mar 30 15:29:21 PDT 2018; root:xnu-3789.70.16~1/RELEASE_X86_64'
    setattr(platform, 'system', mock_platform.system)
    setattr(platform, 'release', mock_platform.release)
    setattr(platform, 'version', mock_platform.version)
    dist = Distribution(module=module)

    # TODO: Fails: print

# Generated at 2022-06-20 19:17:45.653433
# Unit test for constructor of class Distribution
def test_Distribution():
    distribution = Distribution()
    assert 'system' in distribution
    assert 'version' in distribution
    assert 'major_version' in distribution
    assert 'release' in distribution


# Generated at 2022-06-20 19:17:55.988513
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    data = [
        'PRETTY_NAME="Amazon Linux AMI 2018.03"',
        'VERSION_ID="2018.03"',
        'VERSION_CODENAME="LinuxMint"',
        'ID="amzn"',
        'ID_LIKE="centos rhel fedora"',
        'NAME="Amazon Linux AMI"',
        'ANSI_COLOR="0;33"',
        'CPE_NAME="cpe:/o:amazon:linux:2018.03:ga"',
        'HOME_URL="http://aws.amazon.com/amazon-linux-ami/"',
        'Amazon Linux AMI release 2018.03'
    ]
    test = DistributionFiles(dict())


# Generated at 2022-06-20 19:18:06.561553
# Unit test for method parse_distribution_file_Debian of class DistributionFiles

# Generated at 2022-06-20 19:18:13.276240
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    from ansible.module_utils import basic

    module_mock = basic.AnsibleModule(argument_spec={})
    module_mock.get_bin_path = MagicMock(return_value=None)

    disfacts = DistributionFiles(module_mock)

    disfacts.parse_distribution_file_Slackware("Slackware", "Slackware 14.0.0.0", "/etc/slackware-release", {'os_family': 'Slackware'})



# Generated at 2022-06-20 19:19:14.556390
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    dist = Distribution(module=DummyModule())
    dist_facts = dist.get_distribution_OpenBSD()
    if 'distribution_version' in dist_facts.keys():
        if 'distribution_release' in dist_facts.keys():
            if 'distribution' in dist_facts.keys():
                assert True
            else:
                assert False
        else:
            assert False
    else:
        assert False


# Generated at 2022-06-20 19:19:20.008761
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    collection = DistributionFiles()
    file_data = '''NAME="clearlinux"
ID=clearlinux
VERSION_ID=31490
PRETTY_NAME="Clear Linux OS"'''
    result = collection.parse_distribution_file_ClearLinux('Clearlinux', file_data, '/etc/os-release', {})
    assert result[0] == True
    assert result[1]['distribution'] == "Clear Linux OS"
    assert result[1]['distribution_version'] == "31490"
    assert result[1]['distribution_major_version'] == "31490"
    assert result[1]['distribution_release'] == "clearlinux"



# Generated at 2022-06-20 19:19:30.894994
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    # Create an instance of DistributionFiles for tests
    dist_file_instance = DistributionFiles()
    # Assert that an object of type DistributionFiles is created
    assert isinstance(dist_file_instance, DistributionFiles)
    # Assert that dist_file_paths is a list type
    assert isinstance(dist_file_instance.dist_file_paths, list)
    # Assert that dist_file_paths is not empty
    assert dist_file_instance.dist_file_paths
    # Assert that file_mapping is a dictionary type
    assert isinstance(dist_file_instance.file_mapping, dict)
    # Assert that file_mapping is not empty
    assert dist_file_instance.file_mapping


# Unit tests for parse_distribution_file method of class DistributionFiles

# Generated at 2022-06-20 19:19:37.242457
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file = DistributionFiles()
    name = 'Slackware'
    data = '''Slackware x86_64 13.0 
PACKAGES=15071'''
    path = ''
    collected_facts = {}
    result, data = dist_file.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert result is True
    assert data == {'distribution': name}



# Generated at 2022-06-20 19:19:44.308211
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    distribution_files = DistributionFiles(MockModule)
    assert distribution_files.parse_distribution_file_Flatcar("Flatcar", "GROUP=lts", '', {}) == \
           (True, {'distribution_release': 'lts'})



# Generated at 2022-06-20 19:19:50.212372
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # test for name
    dist_file_name = 'NA'
    data = 'NAME="Fedora"\nVERSION="1"\nID=Fedora'
    path = 'path/to/file'
    # TODO: FIXME: check why this file is not in the class
    collected_facts = {'distribution_version': 'NA'}
    dist_file_facts = DistributionFiles().parse_distribution_file_NA(dist_file_name, data, path, collected_facts)
    distribution_expected = 'Fedora'
    distribution_version_expected = '1'

    assert dist_file_facts[1]['distribution'] == distribution_expected
    assert dist_file_facts[1]['distribution_version'] == distribution_version_expected

    # test for name
    dist_file_name = 'NA'

# Generated at 2022-06-20 19:19:59.499915
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():

    distro_file_facts = DistributionFiles().parse_distribution_file_Coreos('Coreos', 'GROUP=stable',
                                                                           '/etc/os-release', {'distribution_version': 'NA'})
    assert 'distribution_release' in distro_file_facts[1]

    distro_file_facts = DistributionFiles().parse_distribution_file_Coreos('Coreos', None,
                                                                           '/etc/os-release', {'distribution_version': 'NA'})
    assert not distro_file_facts[1]



# Generated at 2022-06-20 19:20:07.684569
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    module = AnsibleModule(argument_spec={})
    m = Distribution(module)
    assert m.get_distribution_SMGL() == {'distribution': 'Source Mage GNU/Linux'}, \
        'Distribution %s == "Source Mage GNU/Linux"' % m.get_distribution_SMGL()

# Generated at 2022-06-20 19:20:20.889144
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    """ Test collect function of class DistributionFactCollector with mock module """
    module = MagicMock()
    base_fact_collector = DistributionFactCollector()
    with patch("platform.system", return_value="Linux"):
        base_fact_collector.collect(module)
        module.run_command.assert_called_once()
    with patch("platform.system", return_value="Darwin"):
        base_fact_collector.collect(module)
        module.run_command.assert_called_once()
    with patch("platform.system", return_value="FreeBSD"):
        base_fact_collector.collect(module)
        module.run_command.assert_called_once()
    with patch("platform.system", return_value="OpenBSD"):
        base_fact_collector.collect(module)


# Generated at 2022-06-20 19:20:32.690059
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    platform_release = '6.4'
    expected_distribution_version = '6.4'
    expected_distribution_release = 'release'

    m = Mock()
    m.run_command.return_value = (0, 'OpenBSD 6.4 (GENERIC) #0: Tue Apr 11 10:30:10 MDT 2017', '')
    module = MagicMock()
    module.run_command.return_value = (0, 'OpenBSD 6.4 (GENERIC) #0: Tue Apr 11 10:30:10 MDT 2017', '')
    distribution = Distribution(module)
    distribution.module = m

    # Call the method
    actual = distribution.get_distribution_OpenBSD()

    # Check assertions
    assert(actual['distribution_version'] == expected_distribution_version)