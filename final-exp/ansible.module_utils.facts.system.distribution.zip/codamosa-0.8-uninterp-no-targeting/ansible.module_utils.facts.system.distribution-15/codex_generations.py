

# Generated at 2022-06-20 19:12:38.412136
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    def test(module):
        module.run_command.return_value  = 0, '10.14.3', ''
        fact = Distribution(module)
        fact_distribution_facts = fact.get_distribution_Darwin()
        expected_distribution_facts = {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.14.3'}
        assert fact_distribution_facts == expected_distribution_facts
        module.run_command.return_value  = 0, '10.13.1', ''
        fact_distribution_facts = fact.get_distribution_Darwin()

# Generated at 2022-06-20 19:12:45.266138
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    m = Module()
    x = Distribution(m)
    sunos_facts = x.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'Oracle Solaris'
    assert sunos_facts['distribution_release'] == 'Oracle Solaris 11.2 SPARC'
    assert sunos_facts['distribution_major_version'] == '11'
    assert sunos_facts['distribution_version'] == '11.2'



# Generated at 2022-06-20 19:12:58.104992
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    def get_uname_r_mock(module, flags=None):
        """
        mock function for platform.uname
        """
        uname = {'system': 'AIX',
                 'node': 'node1',
                 'release': '5.3.0.0',
                 'version': '1',
                 'machine': '0000001C4C00',
                 'processor': 'PowerPC_POWER4'
                 }
        return uname

    def get_file_content_mock(filename):
        """
        mock implementation of get_file_content() for testing
        """
        return ""

    module = AnsibleModule(argument_spec=dict())
    setattr(module, 'run_command', get_uname_r_mock)

# Generated at 2022-06-20 19:13:05.559081
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    lsb_release_data = '''
    DISTRIB_ID=MandrivaLinux
    DISTRIB_RELEASE=2010.0
    DISTRIB_CODENAME=Moonshine
    DISTRIB_DESCRIPTION="Mandriva Linux 2010.0 (Moonshine)"
    '''
    # TODO: verify that there is no need to comment out the line below
    # if 'Mandriva' in distribution_file_data:
    distribution_files = DistributionFiles()
    distribution_name = "MandrivaLinux"
    distribution_file_data = lsb_release_data
    distribution_file_path = "/etc/lsb-release"

# Generated at 2022-06-20 19:13:11.186681
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    facts = distribution.get_distribution_facts()
    assert facts['distribution'] == platform.system()



# Generated at 2022-06-20 19:13:20.793705
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not HAS_PLATFORM:
        module.fail_json(msg='platform is required for this module')

    distro = Distribution(module)
    netbsd_facts = distro.get_distribution_NetBSD()
    assert "distribution_version" in netbsd_facts
    assert "distribution_release" in netbsd_facts
    assert "distribution_major_version" in netbsd_facts
    assert "distribution" in netbsd_facts
    assert netbsd_facts["distribution"] == "NetBSD"



# Generated at 2022-06-20 19:13:24.687630
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    # TODO: you need to test for your facts
    # TODO: look at the pytest example in test/unit/ansible_collections/ansible/builtin/tests/unit/plugins/facts/test_distribution.py
    pass

# Generated at 2022-06-20 19:13:30.753770
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    test_module = MagicMock()
    distribution = Distribution(module=test_module)
    result = distribution.get_distribution_SMGL()
    assert result['distribution'] == 'Source Mage GNU/Linux'
    # todo: add more assertions here



# Generated at 2022-06-20 19:13:41.545023
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Set up test environment
    dist_file_reader = DistributionFiles()

    test_data = '''NAME=\"Clear Linux\"
VERSION_ID=\"24330\"
ID=clear-linux
VERSION=\"24330 (Intel Graphics Stack 2020Q2 10.2.2)\"
VERSION_CODENAME=\"\"
ID_LIKE=\"fedora\"
'''

    test_parsed_facts = {'distribution': 'Clear Linux', 'distribution_major_version': '24330', 'distribution_version': '24330', 'distribution_release': 'clear-linux'}

    # Perform test
    parsed_dist_file, parsed_dist_file_facts = dist_file_reader.parse_distribution_file_ClearLinux('clearlinux', test_data, '/etc/os-release', {})

    # Verify results
    assert parsed

# Generated at 2022-06-20 19:13:48.498995
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    dist_file_parser = DistributionFiles()
    test_name = 'Slackware'

# Generated at 2022-06-20 19:14:37.206739
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    # may need better test here

    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    facts = distribution.get_distribution_Darwin()
    assert facts == {u'distribution': u'MacOSX'}


# Generated at 2022-06-20 19:14:38.104873
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    pass

# Generated at 2022-06-20 19:14:49.162310
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    import pytest
    from ansible.module_utils.facts import Distribution
    from ansible.module_utils.facts.collector.distribution import DistributionFiles
    from ansible.module_utils.facts.collector.linux import LinuxDistribution
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, b"OpenBSD 5.6 (GENERIC) #3: Sun Apr 10 16:34:42 MDT 2011\tdavid@i386.openbsd.org:/usr/src/sys/arch/i386/compile/GENERIC\n", b""))
    dist = Distribution(module)
    dist.get_distribution_SMGL = Mock(return_value={"distribution": "Source Mage GNU/Linux"})

# Generated at 2022-06-20 19:14:51.147720
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    df = DistributionFiles()
    assert df is not None

# Unit tests for parsing distribution files.

# Generated at 2022-06-20 19:14:53.635062
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    """
    Unit test for Distribution.get_distribution_OpenBSD function
    """
    # TODO: write tests for this
    pass


# Generated at 2022-06-20 19:14:59.897740
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    # Instance of Distribution class
    d = Distribution()
    # insert path to file /usr/bin/oslevel
    d.module.run_command = MagicMock(return_value=(0, '/usr/bin/oslevel', ''))
    assert d.get_distribution_AIX() == {'distribution_major_version': '7',
                                                 'distribution_version': '7.1',
                                                 'distribution_release': '1'}


# Generated at 2022-06-20 19:15:11.643381
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    class FakeModule(object):
        def run_command(self, command):
            if command == '/usr/bin/sw_vers -productVersion':
                return 0, '10.10.2', ''
            return 0, '', ''

    dist = Distribution(FakeModule())
    result = dist.get_distribution_Darwin()
    assert result == {
        'distribution': 'MacOSX',
        'distribution_major_version': '10',
        'distribution_version': '10.10.2'
    }



# Generated at 2022-06-20 19:15:20.135636
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    df = DistributionFiles()
    ret, facts_dict = df.parse_distribution_file_Alpine('foo', '3.12.1', 'bar', {})
    assert ret == True
    assert(facts_dict['distribution'] == 'Alpine')
    assert(facts_dict['distribution_version'] == '3.12.1')


# Generated at 2022-06-20 19:15:23.546506
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    """
    create DistributionFiles object
    :return:
    """
    distro_files = DistributionFiles()
    if distro_files:
        return True
    else:
        return False


# Generated at 2022-06-20 19:15:33.614360
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    dist_files = DistributionFiles({})
    test_data = {
        '/etc/os-release': "CentOS Stream",
        '/etc/lsb-release': "",
    }
    collected_facts = {'distribution': 'NA'}
    parsed_dist_files = dist_files.process_dist_files(test_data, collected_facts)
    assert parsed_dist_files['parsed_dist_files'] == [
        {'distribution_file_path': '/etc/os-release', 'distribution_file_name': 'os-release', 'distribution_file_variety': 'os-release', 'distribution_file_parsed': True},
    ]
    assert parsed_dist_files['distribution'] == 'CentOS Stream'

# Generated at 2022-06-20 19:16:17.356576
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distribution_files = DistributionFiles(None)
    data = "DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=15.05.1\nDISTRIB_REVISION=r46767\nDISTRIB_CODENAME=chaos_calmer\nDISTRIB_TARGET=brcm2708/bcm2708\nDISTRIB_DESCRIPTION=\"OpenWrt Chaos Calmer 15.05.1\"\nDISTRIB_TAINTS=no-all\n"
    expected_output = {'distribution_release': 'chaos_calmer', 'distribution': 'OpenWrt', 'distribution_version': '15.05.1'}

# Generated at 2022-06-20 19:16:27.224689
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():

    # Arrange
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    dist_files = DistributionFiles(module)
    dist_files._collect_dist_file_facts = MagicMock()
    # dist_files.distro_facts = MagicMock()
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA', 'distribution_release': 'NA',
                       'ansible_facts': {'ansible_distribution': 'NA', 'ansible_distribution_version': 'NA'}}

    # Act
    dist_files.process_dist_files(collected_facts)

    # Assert
    assert dist_files._collect_dist_file_facts.call_count == 1
    # assert dist_files.distro_facts.call_count ==

# Generated at 2022-06-20 19:16:30.115159
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    assert distribution.Distribution(None).get_distribution_FreeBSD() == {
        'distribution_release': '11.3-RELEASE',
        'distribution': 'FreeBSD'
    }

# Generated at 2022-06-20 19:16:33.151790
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    """Tests for method get_distribution_facts of class Distribution"""
    # TODO: create appropriate Mock objects and unit test this method



# Generated at 2022-06-20 19:16:37.944436
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    distribution = Distribution(module)
    expected = {
        "distribution_version": "6.4",
        "distribution_release": "amd64"
    }
    assert distribution.get_distribution_OpenBSD()==expected



# Generated at 2022-06-20 19:16:49.000544
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    input_data = "DISTRIB_ID=OpenWrt\n\
DISTRIB_RELEASE=\"15.05\"\n\
DISTRIB_REVISION=\"r63046\"\n\
DISTRIB_CODENAME=\"chaos_calmer\"\n\
DISTRIB_TARGET=\"ar71xx/generic\"\n\
DISTRIB_DESCRIPTION=\"OpenWrt Chaos Calmer 15.05\"\n\
DISTRIB_TAINTS=\"no-all\""
    expected_output = {"distribution_release": "chaos_calmer",
                       "distribution_version": "15.05",
                       "distribution": "OpenWrt"}
    distfiles = DistributionFiles()

# Generated at 2022-06-20 19:16:59.695081
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    th = DistributionFiles()
    name = 'Alpine'
    path = 'path/to/file'
    data = '3.10.0'
    collected_facts = {'distribution': 'NA', 'distribution_version': 'NA'}
    success, facts = th.parse_distribution_file_Alpine(name, data, path, collected_facts)
    assert success
    assert facts['distribution'] == 'Alpine'
    assert facts['distribution_version'] == '3.10.0'



# Generated at 2022-06-20 19:17:04.364799
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    distribution_files_obj = DistributionFiles()
    if not isinstance(distribution_files_obj, DistributionFiles):
        raise AssertionError("unable to instantiate DistributionFiles()")



# Generated at 2022-06-20 19:17:15.997352
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    class distribution_object:
        def __init__(self):
            self.run_command_return_value = 0
        def run_command(self, cmd, *args, **kwargs):
            if re.search(r'kern\.version', cmd):
                return (self.run_command_return_value, "NetBSD 5.14 (GENERIC)\n", "")
    d = Distribution(distribution_object())

    if d.get_distribution_NetBSD() != {
        'distribution_version': '5.14',
        'distribution_release': 'GENERIC',
        'distribution_major_version': '5'
    }:
        raise Exception()
    distribution_object.run_command_return_value = 1

# Generated at 2022-06-20 19:17:22.053518
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors

    # Create collector
    distro_collector = DistributionFactCollector()

    # Create module instance (add full path to module script)
    module = MockModule("/tmp/does_not_matter")

    # Initialize context
    results = dict(changed=False, ansible_facts=dict())
    context = dict(module=module,
                   task_vars=dict(ansible_facts=dict()),
                   args=dict(),
                   set_facts=dict(),
                   results=results,
                   msg=dict())

    # Initialize facts collector
    facts_collector = FactsCollector(collectors=default_collectors)

    # Skip collection
    distro_collector._skip_collect

# Generated at 2022-06-20 19:17:48.185112
# Unit test for constructor of class Distribution
def test_Distribution():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_Distribution()

# Generated at 2022-06-20 19:17:56.872455
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # Prepare fixture
    module = AnsibleModuleMock()
    distrib = Distribution(module)

# Generated at 2022-06-20 19:18:07.043889
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    ansible_module = AnsibleModule(argument_spec={})
    distribution_files = DistributionFiles()
    parsed_data, mandriva_facts = distribution_files.parse_distribution_file_Mandriva(
        'Mandriva',
        'DISTRIB_ID=MandrivaLinux\n' \
        'DISTRIB_RELEASE=2010.2\n' \
        'DISTRIB_CODENAME=Henry_Farman\n' \
        'DISTRIB_DESCRIPTION="Mandriva Linux 2010.2"\n',
        '/etc/lsb-release',
        {
            'distribution': 'NA',
            'distribution_release': 'NA',
            'distribution_version': 'NA',
        }
    )
    assert parsed_data is True
    assert mandriva_facts

# Generated at 2022-06-20 19:18:11.479838
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_version': '10.14.6', 'distribution_major_version': '10'}

# Generated at 2022-06-20 19:18:25.153069
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    test_instance = DistributionFiles()

# Generated at 2022-06-20 19:18:34.269459
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    # Initialization
    dummy_module = None
    dist = Distribution(dummy_module)

    # make facts alike openbsd
    setattr(sys.modules['platform'], 'system', lambda: 'OpenBSD')
    setattr(sys.modules['platform'], 'release', lambda: '5.6')

    # run tested code
    actual = dist.get_distribution_OpenBSD()

    # check results
    expected = {
        'distribution_version': '5.6',
        'distribution_release': 'RELEASE',
    }
    assert actual == expected



# Generated at 2022-06-20 19:18:36.103840
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    '''
    Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-20 19:18:47.897600
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('uname -v') == '#1 SMP Tue Aug 18 15:51:48 UTC 2015'
    assert get_uname('uname -m') == 'x86_64'
    assert get_uname('uname -r') == '3.13.0-24-generic'
    assert get_uname('uname -s') == 'Linux'
    assert get_uname('uname') == 'Linux'
    assert get_uname('uname -o') == 'GNU/Linux'
    assert get_uname('uname -n') == 'vagrant-ubuntu-trusty-64'
    assert get_uname('uname -v') == '#1 SMP Tue Aug 18 15:51:48 UTC 2015'

# Generated at 2022-06-20 19:18:52.836611
# Unit test for function get_uname
def test_get_uname():
    from ansible.module_utils.facts.utils import ModuleContext
    from ansible.module_utils.facts.utils import ModuleProxy
    with ModuleContext(
            dict(os.environ),
            dict(),
            dict(),
            dict(),
            dict(),
            dict(),
        ) as module:
        assert get_uname(ModuleProxy(module, "command")) == "Linux\n"



# Generated at 2022-06-20 19:19:00.098464
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    # arrange
    freebsd_facts = {}
    freebsd_facts['distribution_release'] = platform.release()
    # act
    distribution = Distribution(module=ModuleStub())
    data = re.search(r'(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT|RC|PRERELEASE).*', freebsd_facts['distribution_release'])
    if data:
        freebsd_facts['distribution_major_version'] = data.group(1)
        freebsd_facts['distribution_version'] = '%s.%s' % (data.group(1), data.group(2))
    actual_output = distribution.get_distribution_FreeBSD()
    # assert
    assert actual_output == freebsd_facts

# Generated at 2022-06-20 19:20:08.793162
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    d = DistributionFiles()
    name = "clearlinux"
    data = 'NAME="Clear Linux"\nID=clearlinux\nID_LIKE=fedora \nVERSION_ID=30190 \nHOME_URL="https://www.clearlinux.org/" \nSUPPORT_URL="https://clearlinux.org/support" \nBUG_REPORT_URL="https://github.com/clearlinux/distribution/issues" \nPRIVACY_POLICY_URL="https://clearlinux.org/privacy-policy"'
    path = "/etc/os-release"
    collected_facts = {'distribution_release': 'NA',
                       'distribution': 'NA',
                       'distribution_version': 'NA'}
    result = d.parse_distribution_file_ClearLinux(name, data, path, collected_facts)

# Generated at 2022-06-20 19:20:14.552675
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    distribution_facts = Distribution(module=None).get_distribution_SMGL()
    assert distribution_facts['distribution'] == 'Source Mage GNU/Linux'

# This is a test unit of the get_distribution_AIX

# Generated at 2022-06-20 19:20:23.573690
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    _module = types.ModuleType('module')
    _module.run_command = MagicMock()
    _module.run_command.return_value = (0, 'ProductVersion:\t10.14.1\nBuildVersion:\t18B75\n', None)

    distribution_darwin = Distribution(_module)
    distribution_facts = distribution_darwin.get_distribution_Darwin()
    assert distribution_facts['distribution'] == 'MacOSX'
    assert distribution_facts['distribution_major_version'] == '10'
    assert distribution_facts['distribution_version'] == '10.14.1'


# Generated at 2022-06-20 19:20:31.077934
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    f = Distribution(module=None)
    f.module.run_command = lambda x: (0, 'ProductName: Mac OS X\nProductVersion: 10.11.6\nBuildVersion: 15G1004\n', '')
    assert f.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_version': '10.11.6', 'distribution_major_version': '10'}


# Generated at 2022-06-20 19:20:32.747740
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    pass

# Generated at 2022-06-20 19:20:44.156767
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    distribution_files = DistributionFilesModule()
    content = "NAME=\"Amazon Linux AMI\"\n" \
              "VERSION=\"2017.03\"\n" \
              "ID=\"amzn\"\n" \
              "ID_LIKE=\"rhel fedora\"\n" \
              "VERSION_ID=\"2017.03\"\n" \
              "PRETTY_NAME=\"Amazon Linux AMI 2017.03\"\n" \
              "ANSI_COLOR=\"0;33\"\n" \
              "CPE_NAME=\"cpe:/o:amazon:linux:2017.03:ga\"\n" \
              "HOME_URL=\"http://aws.amazon.com/amazon-linux-ami/\"\n" \
              "Amazon Linux AMI release 2017.03\n"
    name = 'Amazon'

# Generated at 2022-06-20 19:20:51.360535
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    assert DistributionFiles().parse_distribution_file_Amazon('name', 'Amazon', 'path', 'collected_facts') == (True, {'distribution': 'Amazon'})
    assert DistributionFiles().parse_distribution_file_Amazon('name', 'AmazonLinux', 'path', 'collected_facts') == (False, {})



# Generated at 2022-06-20 19:21:05.244606
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    d = DistributionFiles("fake_module", "c", "d")
    raw = "DISTRIB_ID=OpenWrt\nDISTRIB_RELEASE=18.06.4\nDISTRIB_REVISION=r7767-cddd7b4c77\nDISTRIB_CODENAME=reboot\nDISTRIB_TARGET=sunxi/cortexa7\nDISTRIB_DESCRIPTION=\"OpenWrt 18.06.4 r7767-cddd7b4c77\"\nDISTRIB_TAINTS=\"\"\n"
    name = "OpenWrt"
    path = "/etc/os-release"
    facts = {"distribution": "NA", "distribution_version": "NA", "distribution_release": "NA"}
    parse, facts = d.parse_distribution

# Generated at 2022-06-20 19:21:13.059615
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_obj = DistributionFiles(None)
    test_data = "Slackware 14.1"
    test_result = test_obj.parse_distribution_file_Slackware("Slackware",test_data,"/etc/lsb-release",{})
    assert test_result == (True, {'distribution': 'Slackware', 'distribution_version': '14.1'})

# Generated at 2022-06-20 19:21:15.665405
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_facts = Distribution(None).get_distribution_facts()
    print(json.dumps(distribution_facts, indent=4))

if __name__ == '__main__':
    test_Distribution_get_distribution_facts()