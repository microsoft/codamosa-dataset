

# Generated at 2022-06-20 19:12:16.975552
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles

# Generated at 2022-06-20 19:12:24.458513
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    def parse_distribution_file_CentOS(name, data, path, collected_facts):
        centos_facts = {}

        if 'CentOS Stream' in data:
            centos_facts['distribution_release'] = 'Stream'
            return True, centos_facts

        return False, centos_facts


# Generated at 2022-06-20 19:12:34.685553
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    """
    Function to test Distribution.get_distribution_Darwin()
    """
    # setup the test environment
    test_env = DistributionFactsTestEnv()
    test_env.create_dir('/usr/bin', 777)
    test_env.create_file('/usr/bin/sw_vers', '', 777)
    test_env.create_file('/System/Library/CoreServices/SystemVersion.plist', '', 777)
    test_env.create_file('/System/Library/CoreServices/SystemVersion.bundle/Contents/Resources/English.lproj/SystemVersion.strings', '', 777)
    test_env.create_file('/System/Library/CoreServices/SystemVersion.bundle/Contents/Resources/English.lproj/pre.strings', '', 777)

# Generated at 2022-06-20 19:12:37.947912
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = MockModule(
        run_command=Mock(
            side_effect=[
                (0, "", "")
            ]
        ),
    )
    distribution = Distribution(module)
    assert distribution.get_distribution_HPUX() == {}


# Generated at 2022-06-20 19:12:47.766553
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    module = AnsibleModule()
    distro_file = DistributionFiles(module)

    # Test parse_distribution_file_Alpine when Alpine is in the data.
    # should return True, alpine_facts
    # where alpine_facts = {'distribution': 'Alpine', 'distribution_version': 'alpine_data'}
    data = "alpine_data"
    result = distro_file.parse_distribution_file_Alpine("Alpine", data, None, None)
    assert result[0] is True
    assert result[1] == {'distribution': 'Alpine', 'distribution_version': 'alpine_data'}

    # Test parse_distribution_file_Alpine when Alpine is not in the data.
    # should return False, alpine_facts
    # where alpine_facts =

# Generated at 2022-06-20 19:13:00.004713
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    class AnsModule:
        def __init__(self, out, *args, **kwargs):
            self.out = out

        def run_command(self, *args, **kwargs):
            return (0, self.out, '')


# Generated at 2022-06-20 19:13:08.617080
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    """Unit test for method get_distribution_OpenBSD of class Distribution
    """
    import platform
    import pytest
    from ansible.module_utils.facts.collector import Distribution
    if platform.system() != 'OpenBSD':
        pytest.skip('Run test_Distribution_get_distribution_OpenBSD manually on an OpenBSD host')
    distribution = Distribution(None)
    distribution_facts = distribution.get_distribution_OpenBSD()
    for key in ('distribution', 'distribution_version',
                'distribution_release', 'distribution_major_version'):
        assert key in distribution_facts, '%s not in distribution_facts' % key
        assert distribution_facts[key] is not None, '%s is empty' % key

# Generated at 2022-06-20 19:13:12.433174
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """ Make sure that other functions of Distribution work"""
    #print "Executing '%s'" % test_Distribution_get_distribution_SunOS.__name__
    _test_module = AnsibleModule(argument_spec={})
    _test_module.params = {}
    _test_distribution = Distribution(_test_module)
    # All we get out of this is the first line of solaris so we can't check for more than we're not seeing an exception
    _test_sunos_facts = _test_distribution.get_distribution_SunOS()
    assert _test_sunos_facts is not None
    #print "test_Distribution_get_distribution_SunOS finished"


# Generated at 2022-06-20 19:13:17.058690
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    dist_files = DistributionFiles()

# Generated at 2022-06-20 19:13:22.676231
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Set up data
    distro = "Clear Linux"
    data = "NAME=\"Clear Linux OS\"\\nVERSION_ID=31370\\nID=clear-linux-os"
    path = "/usr/lib/os-release"
    collected_facts = {'distribution':'Clear Linux', 'distribution_version':'NA', 'distribution_major_version':'31370', 'distribution_release':'NA'}

    expected_facts = {
        'distribution': 'Clear Linux OS',
        'distribution_major_version': '31370',
        'distribution_version': '31370',
        'distribution_release': 'clear-linux-os'
    }

    # Call the actual method
    module = DistributionFiles()

# Generated at 2022-06-20 19:14:01.740650
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    f = DistributionFiles()
    # data from: https://centos.pkgs.org/8/centos-stream-x86_64/centos-release-8-1.1911.0.4.el8.x86_64.rpm.html
    data = 'CentOS Stream 8 (Core)'
    path = ""
    collected_facts = {
        "distribution": "NA",
        "distribution_release": "NA",
        "distribution_version": "NA",
        "distribution_major_version": "NA"
    }
    name = "CentOS"
    (ret, out) = f.parse_distribution_file_CentOS(name, data, path, collected_facts)
    assert ret == True
    assert out == {'distribution_release': 'Stream'}


# Generated at 2022-06-20 19:14:03.164656
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist_files = DistributionFiles()
    assert isinstance(dist_files, DistributionFiles)



# Generated at 2022-06-20 19:14:05.644184
# Unit test for constructor of class Distribution
def test_Distribution():
    mod = AnsibleModule({})
    result = Distribution(mod).get_distribution_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-20 19:14:12.001739
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # Test data with no release file
    _release_data_1 = "NetBSD 7.99.14 (GENERIC)  amd64"
    # Test data with no release file
    _release_data_2 = "NetBSD 7.0.2 (GENERIC)  amd64"
    # Test data with no release file
    _release_data_3 = "NetBSD 5.1 (GENERIC)\n#0: Wed Oct 27 14:09:53 UTC 2010\nbuilds@b8.netbsd.org:/home/builds/ab/netbsd-5-1-RELEASE/i386/201010270900Z-obj/home/builds/ab/netbsd-5-1-RELEASE/src/sys/arch/i386/compile/GENERIC"
    # Test data with no release file

# Generated at 2022-06-20 19:14:19.234862
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    df = DistributionFiles()
    df.module = get_module_mock()
    data = "GROUP=2445.5.0"
    ansible_facts = dict(os_family='Linux')
    names = ['Flatcar', 'NA', 'Flatcar 1']

    for name in names:
        name_facts = df.parse_distribution_file_Flatcar(name, data, '/run/flatcar/release', ansible_facts)[1]
        assert name_facts['distribution_release'] == '2445.5.0'



# Generated at 2022-06-20 19:14:23.440740
# Unit test for function get_uname
def test_get_uname():
    from ansible.module_utils._text import to_bytes
    import platform
    module = type("FakeModule", (object,), {"run_command":
                  lambda *args, **kwargs: (0, "", "")})()
    uname = get_uname(module)
    assert uname == platform.system()



# Generated at 2022-06-20 19:14:32.678388
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # create mock module
    module = AnsibleModule(argument_spec={})

    df = DistributionFiles()

    # SUSE, read from /etc/os-release
    os_release_data_sles = '''
NAME="SLES"
VERSION="12-SP2"
VERSION_ID="12.2"
PRETTY_NAME="SUSE Linux Enterprise Server 12 SP2"
ID="sles"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:suse:sles:12:sp2"
'''

# Generated at 2022-06-20 19:14:35.458882
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    assert Distribution(module=None).get_distribution_OpenBSD() == {'distribution_version': '8.5', 'distribution_release': 'penny-dreadful'}



# Generated at 2022-06-20 19:14:44.860041
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    instance = DistributionFiles(dict())

    # Test "Alpine" distribution files
    for name in ('Alpine', 'alpine'):
        for path in ('/etc/alpine-release', '/etc/arch'):
            data = '3.12.0'
            parsed_dist_file, parsed_dist_file_facts = instance.parse_distribution_file_Alpine(name, data, path, {'distribution': 'NA'})
            assert parsed_dist_file is True
            assert parsed_dist_file_facts == {'distribution': 'Alpine', 'distribution_version': data}



# Generated at 2022-06-20 19:14:53.630957
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    """ Test method parse_distribution_file_NA of class DistributionFiles """
    # distro_parse_fact_paths = ['/etc/os-release', '/usr/lib/os-release', '/etc/os-release.d/*']
    distro_parse_fact_paths = ['/etc/os-release']

    collected_facts = {'distribution_version': 'NA'}
    for path in distro_parse_fact_paths:
        dist_file_facts = {'distribution_file_path': path, 'distribution_file_data': '', 'distribution_file_variety': 'NA'}
        df = DistributionFiles(module=None, collected_facts=collected_facts, dist_file_facts=dist_file_facts)

# Generated at 2022-06-20 19:15:58.626557
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # pylint: disable=import-error,unused-variable
    from ansible.module_utils.facts.sys_info import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    from ansible_collections.ansible.internal.plugins.modules.system import distribution as module
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.system import distribution
    import os
    import platform
    import tempfile
    import textwrap
    import unittest

    os.environ['PATH'] = '/sbin:/bin'
    # fake values
    platform.system.return_value = "NetBSD"
    platform.release.return_value = "8.0_RC1"

# Generated at 2022-06-20 19:16:06.862168
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    test_facts = {
        'distribution': 'NA',
        'distribution_version': 'NA',
        'distribution_release': 'NA',
    }
    dist_files = [
        ('/etc/os-release', 'some text'),
        ('/etc/os-release', 'some text'),
        ('/etc/os-release', 'some text'),
        ('/etc/os-release', 'some text'),
    ]
    dist_files_results = {
        '/etc/os-release': {
            'exists': True,
            'isreg': True,
            'isdir': False,
            'islnk': False,
            'content': 'some text',
        },
    }
    d_files = DistributionFiles(test_facts, dist_files, dist_files_results)
    d

# Generated at 2022-06-20 19:16:19.604588
# Unit test for constructor of class Distribution
def test_Distribution():
    module = Mock()
    assert Distribution(module).get_distribution_AIX() == {}
    assert Distribution(module).get_distribution_Darwin() == {'distribution': 'MacOSX'}
    assert Distribution(module).get_distribution_FreeBSD() == {'distribution_release': '12.0-RELEASE-p4'}
    assert Distribution(module).get_distribution_OpenBSD() == {'distribution_release': 'release', 'distribution_version': '6.6'}
    assert Distribution(module).get_distribution_DragonFly() == {'distribution_release': '5.4.1-RELEASE', 'distribution_version': '5.4.1'}

# Generated at 2022-06-20 19:16:25.433813
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    obj = DistributionFiles()
    data = 'NAME="Amazon Linux AMI"\nVERSION="2017.09"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2017.09"\nPRETTY_NAME="Amazon Linux AMI 2017.09"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2017.09:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n'
    name = 'Amazon'
    path = '/etc/system-release'
    collected_facts = {'distribution': 'NA', 'distribution_release': 'NA', 'distribution_version': 'NA'}

# Generated at 2022-06-20 19:16:33.868827
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    """
    Tests for method collect of class DistributionFactCollector
    """
    fact_collector_obj = DistributionFactCollector()
    assert fact_collector_obj.name == 'distribution'

    facts_dict = {}

    # Test for Darwin(MacOSX)
    os.environ['ANSIBLE_CONFIG'] = 'test/units/modules/test_malformed_json.cfg'
    fact_collector_obj.collect(module=None, collected_facts=facts_dict)

    # Test for Aix
    os.environ['ANSIBLE_CONFIG'] = 'test/units/modules/test_malformed_json.cfg'
    fact_collector_obj.collect(module=None, collected_facts=facts_dict)

    # Test for HPUX
    os.environ['ANSIBLE_CONFIG']

# Generated at 2022-06-20 19:16:39.990256
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    # os.uname = ('Darwin', 'hostname', '10.9.0', 'Darwin Kernel Version 10.9.0: Wed May 21 16:17:16 PDT 2014; root:xnu-2422.100.13~1/RELEASE_X86_64', 'x86_64')
    mock_module = MagicMock(run_command=Mock(return_value=(0, '/sbin/sysctl -n kern.version', None)))
    mock_module.run_command.return_value = (0, 'NetBSD 6.1.5 (GENERIC) #0: Fri Jul 11 04:49:58 UTC 2014', None)
    distribution_netbsd = Distribution(mock_module)

# Generated at 2022-06-20 19:16:49.747762
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = Mock()
    dist = Distribution(module)
    print("Testing method get_distribution_facts():")
    print("\tTesting platform.system() = 'AIX'")
    module.run_command.return_value = (0, "7.1", "")
    output = dist.get_distribution_facts()
    assert output['distribution'] == 'AIX'
    assert output['distribution_major_version'] == '7'
    assert output['distribution_version'] == '7.1'
    print("\tTesting platform.system() = 'HP-UX'")
    module.run_command.return_value = (0, "B.11.31.1510.5", "")
    output = dist.get_distribution_facts()

# Generated at 2022-06-20 19:16:51.585927
# Unit test for constructor of class Distribution
def test_Distribution():
    assert Distribution(module=None).__class__.__name__ == 'Distribution'


# Generated at 2022-06-20 19:17:01.359491
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    """
    Test the method parse_distribution_file_Amazon() of class DistributionFiles
    """
    df = DistributionFiles()
    file_contents = (
        "NAME=\"Amazon Linux\"\n"
        "VERSION=\"2\"\n"
    )
    path = 'some_path'

    expected_result = {
        'distribution': 'Amazon',
        'distribution_version': '2',
    }
    result = df.parse_distribution_file_Amazon("Amazon", file_contents, path, {})
    assert result == (True, expected_result)



# Generated at 2022-06-20 19:17:09.123552
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(
        argument_spec={},
    )
    rc, out, err = module.run_command(
        '/sbin/sysctl -n kern.version',
        check_rc=True
    )
    dfly_facts = Distribution(module).get_distribution_DragonFly()
    assert dfly_facts['distribution_release'] in out
    assert dfly_facts['distribution_version'] == '4.10.0'
    assert dfly_facts['distribution_major_version'] == '4'



# Generated at 2022-06-20 19:18:13.795675
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    dist = Distribution(module)

    def get_uname(*args, **kwargs):
        return 'SmartOS michael-global-2 20141016T191900Z x86_64 i86pc'

    def get_file_content(file):
        return 'SmartOS joyent_20141016T191900Z'

    dist.get_uname = get_uname
    dist.get_file_content = get_file_content

    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts['distribution'] == 'SmartOS'
    assert sunos_facts['distribution_release'] == 'SmartOS joyent_20141016T191900Z'

# Generated at 2022-06-20 19:18:25.719347
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    dist_file = DistributionFiles()
    data = "NAME=Debian\nVERSION_ID=9\nVERSION=9 (stretch)\nVERSION_CODENAME=stretch\nID=debian\nID_LIKE=debian\nPRETTY_NAME=\"Debian GNU/Linux 9 (stretch)\"\nHOME_URL=\"https://www.debian.org/\"\nSUPPORT_URL=\"https://www.debian.org/support\"\nBUG_REPORT_URL=\"https://bugs.debian.org/\"\n"
    name = "Debian"
    path = "/etc/os-release"

# Generated at 2022-06-20 19:18:34.247217
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    """
    Unit test for Distribution.get_distribution_OpenBSD

    :return:
    """
    fake_module = _get_fake_ansible_module({})
    distribution = Distribution(fake_module)
    openbsd_facts = distribution.get_distribution_OpenBSD()
    assert isinstance(openbsd_facts, dict)
    assert 'distribution_version' in openbsd_facts
    assert 'distribution_release' in openbsd_facts
    assert openbsd_facts['distribution_release'] in ('snapshot', 'release')



# Generated at 2022-06-20 19:18:37.965510
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    os = Distribution(module)
    assert os.get_distribution_AIX()['distribution_major_version'] == '7'
    assert os.get_distribution_AIX()['distribution_version'] == os.get_distribution_AIX()['distribution_major_version']
    assert os.get_distribution_AIX()['distribution_release'] is None


# Generated at 2022-06-20 19:18:49.521275
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Try to parse a good /etc/os-release file.
    # Should return a mapping of distribution and version.
    name = 'NA'
    path = '/etc/os-release'
    data = '''NAME="Fedora"
        VERSION="26 (Twenty Six)"
        ID=fedora
        VERSION_ID=26
        '''
    collected_facts = {}
    collected_facts['distribution'] = 'NA'
    collected_facts['distribution_version'] = 'NA'
    return_value = parse_distribution_file_NA(name, data, path, collected_facts)
    assert return_value[0] is True
    assert return_value[1]['distribution'] == 'Fedora'
    assert return_value[1]['distribution_version'] == '26 (Twenty Six)'
    # Try

# Generated at 2022-06-20 19:18:54.474498
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    module = FakeModule()
    obj = Distribution(module)
    data = obj.get_distribution_HPUX()
    assert data == {'distribution_version': 'B.11.31', 'distribution_release': '0'}



# Generated at 2022-06-20 19:19:07.277171
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    '''
    Unit test for method parse_distribution_file_Coreos of class DistributionFiles
    '''

    df = DistributionFiles()

    # Happy path
    name = "CoreOS"
    data = "GROUP=stable"
    path = "/usr/share/coreos/lsb-release"
    collected_facts = {}
    expected_distro = {'distribution_release': 'stable'}
    parsed, distro = df.parse_distribution_file_Coreos(name, data, path, collected_facts)
    assert distro == expected_distro

    # No data
    name = "CoreOS"
    data = ""
    collected_facts = {}
    path = "/usr/share/coreos/lsb-release"
    expected_parsed = False
    expected_distro = {}
    parsed,

# Generated at 2022-06-20 19:19:16.027031
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
     mymodule = FakeModule(
         dict(
             run_command=Mock(return_value=(0, 'HPUX_OE_11i_v3_HPUX_11.31_IA-32_64_BIT_ML_2.00 abc123', '')))
     )
     dist = Distribution(mymodule)
     facts = dist.get_distribution_HPUX()
     assert facts['distribution_version'] == '11.31'
     assert facts['distribution_release'] == 'abc123'

# Generated at 2022-06-20 19:19:18.947887
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    x = DistributionFactCollector()
    assert x.name == 'distribution'

# Generated at 2022-06-20 19:19:23.837780
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    assert DistributionFactCollector.name == 'distribution'
    new_distribution_fact_collector = DistributionFactCollector()
    assert new_distribution_fact_collector.name == 'distribution'

# Generated at 2022-06-20 19:20:24.875061
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    dist_files = DistributionFiles()
    fake_facts = {'distribution': 'NA', 'distribution_version': 'NA'}

    # test empty data
    (result, dist_facts) = dist_files.parse_distribution_file_Coreos('CoreOS', '', '/etc/os-release', fake_facts)
    assert result and dist_facts['distribution_release'] == 'NA'

    # test valid data

# Generated at 2022-06-20 19:20:34.521697
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    dist = Distribution({"var": "var"})
    facts = dist.get_distribution_NetBSD()
    assert facts['distribution_release'] in ["8.99.9", "5.99.60", "6.99.30", "7.99.22"]
    assert facts['distribution_major_version'] in ["8", "5", "6", "7"]
    assert facts['distribution_version'] in ["8.99.9", "5.99.60", "6.99.30", "7.99.22"]
    # assert facts['distribution_release'] == "8.99.9"
    # assert facts['distribution_major_version'] == "8"
    # assert facts['distribution_version'] == "8.99.9"


if __name__ == '__main__':
    test

# Generated at 2022-06-20 19:20:38.582758
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    system = Distribution(None)
    smgl = system.get_distribution_SMGL()
    assert smgl['distribution'] == 'Source Mage GNU/Linux'



# Generated at 2022-06-20 19:20:41.196100
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    dist = Distribution()
    facts = dist.get_distribution_SMGL()
    assert facts['distribution'] == 'Source Mage GNU/Linux'



# Generated at 2022-06-20 19:20:41.825549
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    pass

# Generated at 2022-06-20 19:20:51.729369
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    instance = Distribution(module=None)
    try:
        from mocker import Mocker
    except ImportError:
        mocker = None
    else:
        mocker = Mocker()
    netbsd_facts = {'distribution_major_version': '5', 'distribution_release': '5.1', 'distribution_version': '5.1'}
    with mocker:
        mocker.replay()
        assert instance.get_distribution_NetBSD() == netbsd_facts


# Generated at 2022-06-20 19:21:05.432495
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.run_command_rc =rc
            self.run_command_out = out
            self.run_command_err = err

        def run_command(self, command, use_unsafe_shell=False):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    # tests to verify the output of method 'get_distribution_AIX'

    # oslevel command returns '7.2'
    testmodule = TestModule(0, '7.2', '')
    distribution_obj = Distribution(testmodule)
    distribution_facts = distribution_obj.get_distribution_AIX()
    assert isinstance(distribution_facts, dict)

# Generated at 2022-06-20 19:21:09.084923
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec=dict())
    dist_module = Distribution(module)
    dragonfly_facts = dist_module.get_distribution_DragonFly()

    assert 'distribution_major_version' in dragonfly_facts
    assert 'distribution_version' in dragonfly_facts
    assert 'distribution_release' in dragonfly_facts



# Generated at 2022-06-20 19:21:17.359473
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    dist = DistributionFiles()
    assert dist.parse_distribution_file_NA('NA', 'NAME="VMware vCloud Suite", VERSION="5.5"', '', {}) == (True, {'distribution': 'VMware vCloud Suite', 'distribution_version': '5.5'})
    assert dist.parse_distribution_file_NA('NA', 'NAME="CentOS Linux", VERSION="7 (Core)", ID="centos", ID_LIKE="rhel fedora"', '', {}) == (True, {'distribution': 'CentOS Linux', 'distribution_version': '7 (Core)'})

# Generated at 2022-06-20 19:21:21.173874
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    distro = Distribution("")
    assert {'distribution': 'Source Mage GNU/Linux'} == distro.get_distribution_SMGL()
