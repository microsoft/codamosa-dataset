

# Generated at 2022-06-20 19:12:28.725552
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    """Unit test for method parse_distribution_file_Mandriva of class DistributionFiles"""
    name = 'Mandriva'
    data = '''NAME="Mandriva"
VERSION="2010.1 (Official) - Spring"
ID=mandriva
'''
    path = './test/my_test_dist_file_Mandriva'
    collected_facts = {'distribution': 'NA',
        'distribution_release': 'NA',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA'
    }
    my_distribution_file_class = DistributionFiles()

# Generated at 2022-06-20 19:12:39.388566
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    # Test 1
    uname_v_data = "Oracle Solaris 11.4 X86\n  Copyright (c) 1983, 2018, Oracle and/or its affiliates.\n                    All rights reserved.\n   Assembled 23 September 2018"
    platform_r_data = "11.4"
    platform_sys_data = "SunOS"
    platform_data = "Oracle Solaris 11.4"
    get_file_content_data = """Oracle Solaris 11.4 X86
Copyright (c) 1983, 2018, Oracle and/or its affiliates.
                        All rights reserved.
      Assembled 23 September 2018"""

# Generated at 2022-06-20 19:12:48.653050
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    dist = Distribution(module=MagicMock())
    linux = 'Linux'
    solaris = 'SunOS'
    smartos = 'SmartOS'
    omnios = 'OmniOS'
    illumos = 'Illumos'
    openindiana = 'OpenIndiana'
    nexenta = 'Nexenta'
    nexentaos = 'NexentaOS_'
    uname_v = MagicMock(return_value='foo')
    uname_r = MagicMock(return_value='')
    file_exists = MagicMock(return_value=True)
    file_content = MagicMock(return_value='release OpenIndiana Hipster-19.05 (text mode)')

# Generated at 2022-06-20 19:13:00.469179
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    """
    unittest for method get_distribution_HPUX of class Distribution
    """
    from ansible.module_utils.facts.distribution import Distribution

    dist_obj = Distribution(module="")

    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, "", "")

    dist_obj.module = module_mock

    rc, out, err = dist_obj.module.run_command(r"/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'", use_unsafe_shell=True)

    out = "HPUX_OE B.11.11.1411.1411 B.11.23"

# Generated at 2022-06-20 19:13:02.153103
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    distribution_facts = Distribution(module=None)
    assert distribution_facts.get_distribution_SMGL()['distribution'] == 'Source Mage GNU/Linux'



# Generated at 2022-06-20 19:13:14.902252
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(ArgumentSpec())
    module.run_command = Mock(return_value=(0, "v5.1.1-RELEASE-p0", ""))
    module.get_bin_path = Mock(return_value="/sbin/sysctl")

    d = Distribution(module)
    # test regular release
    facts = d.get_distribution_DragonFly()
    assert facts['distribution_major_version'] == "5"
    assert facts['distribution_version'] == "5.1.1"
    assert facts['distribution_release'] == "RELEASE-p0"

    # test we don't overwrite facts already present
    module.run_command = Mock(return_value=(0, "v5.1-RELEASE-p0", ""))
    facts = d.get_distribution_DragonFly

# Generated at 2022-06-20 19:13:20.989646
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    collected_facts = {
        'distribution': 'Amazon',
        'distribution_file_path': '/etc/os-release',
        'distribution_file_variety': 'RedHat',
        'distribution_major_version': '2017',
        'distribution_minor_version': '12',
        'distribution_release': 'NA',
        'distribution_version': '2017.12',
        'distribution_file_parsed': True
    }

    dist_file = DistributionFiles()
    lsb_release = """
DISTRIB_ID=Amazon
DISTRIB_RELEASE=2017.12
DISTRIB_CODENAME=NA
DISTRIB_DESCRIPTION="Amazon 2017.12"
"""
    name, path = 'Amazon', '/etc/lsb-release'
    parsed_dist,

# Generated at 2022-06-20 19:13:25.375462
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    fact_collector = DistributionFactCollector()
    assert fact_collector.name == 'distribution'
    assert fact_collector._fact_ids == set(['distribution_version',
                                            'distribution_release',
                                            'distribution_major_version',
                                            'os_family'])

# Generated at 2022-06-20 19:13:38.921925
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = get_module(**dict())

    # This is a bit of hack, but seems necessary.  The python docs
    # suggest otherwise, but platform.release() returns things like
    # '10.1-RELEASE' for FreeBSD and '10.1-RELEASE-p8' for OpenBSD on
    # my systems.  The p8 looks like a patch number, but for the sake
    # of unittest.TestCase.assertEqual(), I want it to compare
    # equal.
    orig_release = platform.release
    platform.release = lambda: '10.1-RELEASE'

    # In principle, this could fail, but it would have to be on a
    # system where platform.system() returned 'FreeBSD' but where
    # platform.release() did not match the regexp in
    # Distribution.get_distribution_

# Generated at 2022-06-20 19:13:46.489171
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    rh_test = Distribution(module=None)
    rh_test.module.run_command = fakes.factory_fake_command(
        'Red Hat Enterprise Linux Server release 7.4 (Maipo)'
    )
    rh_test.get_distribution_Linux = fakes.factory_fake_Linux()
    distribution = rh_test.get_distribution_facts()
    assert distribution['distribution'] == 'RedHat'
    assert distribution['distribution_major_version'] == '7'
    assert distribution['distribution_version'] == '7.4'
    assert distribution['distribution_release'] == 'Maipo'
    assert distribution['os_family'] == 'RedHat'

    ubuntu_test = Distribution(module=None)
    ubuntu_test.module.run_command = fakes.factory_fake

# Generated at 2022-06-20 19:14:20.202938
# Unit test for function get_uname
def test_get_uname():
    # uname exists
    rc, out, err = module.run_command(['uname', '-v'])
    if rc == 0:
        assert out != None
    # uname doesn't exist
    rc, out, err = module.run_command(['not_a_uname', '-v'])
    if rc == 0:
        assert out != None
    # uname exists
    rc, out, err = module.run_command(['uname', '-v'])
    if rc == 0:
        assert out != None
    # uname doesn't exist
    rc, out, err = module.run_command(['not_a_uname', '-v'])
    if rc == 0:
        assert out != None


# Generated at 2022-06-20 19:14:27.863333
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    # create test object
    dist_file_fact_obj = DistributionFiles()

    # set test variables
    data = "GROUP=devel\n"
    path = "/usr/share/defaults/release"
    name = "flatcar"
    collected_facts = {'distribution_release': 'NA'}
    expected_result = (True, {'distribution_release': 'devel'})
    # perform test
    result = dist_file_fact_obj.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result == expected_result



# Generated at 2022-06-20 19:14:33.671784
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = FakeModule()
    distribution = Distribution(module)
    sunos_facts = distribution.get_distribution_SunOS()
    print(f"sunos_facts = {sunos_facts}")
    assert sunos_facts == {'distribution_release': 'Solaris 10 11/06 s10s_u4wos_12b SPARC',
                           'distribution': 'Solaris',
                           'distribution_version': '10',
                           'distribution_major_version': '10'}

# Generated at 2022-06-20 19:14:46.099737
# Unit test for method get_distribution_SunOS of class Distribution

# Generated at 2022-06-20 19:14:53.683357
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # Test if Slackware is successfully parsed from a distribution file
    df = DistributionFiles()
    dist_file_facts = {'distribution_file_path': '/etc/slackware-version',
                       'distribution_file_variety': 'Slackware',
                       'distribution_file_data': 'Slackware release 14.1 (Helium)',
                       'distribution_file_parsed': 'True'}
    collected_facts = {}

    result = df.parse_distribution_file_Slackware('Slackware', 'Slackware release 14.1 (Helium)', '/etc/slackware-version', collected_facts)

    assert result == (True, dist_file_facts)


# Generated at 2022-06-20 19:14:59.207548
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_obj = Distribution(module=test_module)
    test_obj.module.run_command = Mock()
    test_obj.module.run_command.return_value = (0, 'FreeBSD 10.2-RELEASE-p10', '')
    assert test_obj.get_distribution_FreeBSD() == {'distribution_release': '10.2-RELEASE-p10', 'distribution_major_version': '10', 'distribution_version': '10.2'}
    test_obj.module.run_command.return_value = (0, 'FreeBSD 10.3-RELEASE-p3', '')

# Generated at 2022-06-20 19:15:07.268434
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distribution_file_facts = DistributionFiles()
    test_ansible_module = AnsibleModuleMock()
    test_args = (
        'Slackware',
        '''
# Tue Jul 17 10:43:52 UTC 2018
SLACKWARE=14.1
SLACKWARE_PATCHLEVEL=0
SLACKWARE_VERSION=14.1
SLACKWARE_VERSION_STRING="Slackware version 14.1.0"
SLACKWARE_VERSION_CODENAME="Gnomey Gambit"
''',
        '/etc/slackware-version',
        None)
    result = distribution_file_facts._parse_distribution_file_Slackware(*test_args)
    assert result[0] == True

# Generated at 2022-06-20 19:15:15.714424
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(default='NA', required=False),
            data=dict(default='', required=False),
            path=dict(default='', required=False),
            facts=dict(default={}, required=False),
        ),
    )

    distro_files = DistributionFiles(module)

    # no data provided, return false
    module.params['name'] = 'Coreos'
    module.params['data'] = ''
    module.params['path'] = '/usr/share/clear-linux-os/live-helpers/configuration.ini'
    coreos_facts = distro_files.parse_distribution_file_Coreos(**module.params)
    assert not coreos_files_facts[0]

# Generated at 2022-06-20 19:15:20.760264
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    import sys
    sys.path.append('.')
    from .. import AnsibleModule

    inputs = {}
    module = AnsibleModule(argument_spec=inputs)

    fact_collector = DistributionFactCollector(module=module)
    result = fact_collector.collect(module=module, collected_facts={})
    expected = {'distribution': 'SMGL', }
    assert result == expected



# Generated at 2022-06-20 19:15:31.002540
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    d = DistributionFiles()
    mock_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    setattr(d, 'module', mock_module)


# Generated at 2022-06-20 19:16:05.409895
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    distro_files = DistributionFiles()

# Generated at 2022-06-20 19:16:18.940219
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    from ansible.module_utils.facts import DistributionFiles

    # Okay Linux Mint, I really wanted to get your facts through lsb_release
    # but you wont install lsb_release. I will have to resort to other means
    # I will just mess with your release file because I can't mess with the
    # python module LSB for this test.
    distr_file = DistributionFiles()

    def fake_glob(pattern):
        return [
            "/etc/fake-lsb-release",
            "/etc/os-release"
        ]

    distr_file.module.glob.glob = fake_glob


# Generated at 2022-06-20 19:16:27.735475
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    test_name = "test_DistributionFiles_parse_distribution_file_NA"
    test_data = "NAME=Foo\nVERSION=1.2.3"
    test_file_path = "test_file"
    dist_file_facts = {}
    dist_file_facts['distribution'] = 'NA'
    dist_file_facts['distribution_version'] = 'NA'
    expected_result = {'distribution' : 'Foo', 'distribution_version' : '1.2.3'}
    dist_obj = DistributionFiles(test_name)
    actual_result = dist_obj.parse_distribution_file_NA(test_name, test_data, test_file_path, dist_file_facts)[1]
    assert expected_result == actual_result


# Generated at 2022-06-20 19:16:31.489393
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    fact_collector = DistributionFactCollector()
    assert fact_collector.name == 'distribution'
    assert fact_collector._fact_ids == {'distribution_version',
                                        'distribution_release',
                                        'distribution_major_version',
                                        'os_family'}



# Generated at 2022-06-20 19:16:39.275074
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = MagicMock()
    module.run_command.return_value = 0,'OpenBSD 5.8-current (GENERIC) #1: Tue Feb 10 10:42:12 MST 2015     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC','None'
    distribution = Distribution(module)

# Generated at 2022-06-20 19:16:49.295712
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    from ansible.module_utils.facts import DistributionFiles
    from ansible.module_utils.facts import DistributionFile
    from ansible.module_utils.facts import Facts
    existing_facts = {
        'distribution_version': 'NA',
        'distribution_release': 'NA',
        'distribution_major_version': 'NA',
        'distribution': 'NA',
        'distribution_file_variety': 'NA',
    }
    expected_facts = {
        'distribution_major_version': 'NA',
        'distribution_release': 'jessie',
        'distribution_version': '8.11',
        'distribution': 'Debian',
        'distribution_file_variety': 'Debian',
    }
    distribution_files = DistributionFiles()
    distribution_files.distribution

# Generated at 2022-06-20 19:16:50.903661
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    # TODO: test
    assert False

# Generated at 2022-06-20 19:16:56.257300
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    test_distribution_facts = {}
    test_d = Distribution(module=None)
    test_distribution_facts['distribution_release'] = '10.3-STABLE'
    test_distribution_facts['distribution'] = 'FreeBSD'

    test_d_facts = test_d.get_distribution_FreeBSD()

    assert test_d_facts['distribution_major_version'] == '10'
    assert test_d_facts['distribution_version'] == '10.3'
    assert test_d_facts['distribution'] == 'FreeBSD'


# Generated at 2022-06-20 19:17:06.882270
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # setup
    test_parse_distribution_file_Debian = DistributionFilesClass()
    # test
    result1 = test_parse_distribution_file_Debian.parse_distribution_file_Debian(
                'Debian', 'Debian', '/etc/issue', {
                    'distribution_release':'NA',
                }
            )
    # verify
    assert result1 == (True, {
                'distribution': 'Debian',
                'distribution_release': 'NA'
            })

    result2 = None

# Generated at 2022-06-20 19:17:16.903228
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    netbsd_facts = distribution.get_distribution_NetBSD()
    assert re.match(r'\d+\.\d+', netbsd_facts['distribution_major_version'])
    assert re.match(r'\d+\.\d+', netbsd_facts['distribution_version'])
    assert netbsd_facts['distribution_release'] is not None


# Generated at 2022-06-20 19:17:51.308276
# Unit test for function get_uname
def test_get_uname():
    if platform.system() == 'FreeBSD':
        assert get_uname(['-a']) == platform.uname()[-1]
    else:
        assert get_uname(['-s']) == platform.uname()[0]
        assert get_uname(['-n']) == platform.uname()[1]
        assert get_uname(['-r']) == platform.uname()[2]
        assert get_uname(['-v']) == platform.uname()[3]
        assert get_uname(['-m']) == platform.uname()[4]
        assert get_uname(['-p']) == platform.uname()[5]
        assert get_uname(['-i']) == platform.uname()[6]
        assert get_uname

# Generated at 2022-06-20 19:18:04.107335
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    data = 'ID=coreos\nNAME=CoreOS\nVERSION=2028.3.0\nVERSION_ID=2028.3.0\nBUILD_ID=\nPRETTY_NAME="CoreOS 2028.3.0"\nANSI_COLOR="38;5;75"\nHOME_URL="https://coreos.com/"\nBUG_REPORT_URL="https://issues.coreos.com"\nCOREOS_BOARD=amd64-usr\nCOREOS_BRANCH_ID=stable\nCOREOS_BUILD_ID=\nCOREOS_PRETTY_NAME="CoreOS 2028.3.0 (Stable)"\nGROUP=stable\n'

# Generated at 2022-06-20 19:18:14.457742
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    platform_release_1 = 'Oracle Solaris 11.4 X86'
    platform_release_2 = 'Oracle Solaris 11.3 SPARC'
    platform_release_3 = 'Oracle Solaris 11.1 SPARC'
    platform_release_4 = 'Illumos'
    platform_release_5 = 'SunOS'
    platform_release_6 = 'Oracle Solaris 10 1/13 s10x_u11wos_17b X86'
    platform_release_7 = 'Oracle Solaris 10 1/13 s10s_u11wos_24a X86'
    platform_release_8 = 'Oracle Solaris 10 1/13 s10s_u11wos_24a X86'
    platform_release_9 = 'SmartOS 20.4.0 20170912T131414Z i86pc'
    platform

# Generated at 2022-06-20 19:18:23.312675
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    class DummyModule(object):
        def get_bin_path(self, name):
            return '/bin/%s' % name

        def run_command(self, cmd):
            return 0, 'GROUP=stable', ''

    dist_files = DistributionFiles()
    dist_files.module = DummyModule()
    ret, facts = dist_files.parse_distribution_file_Coreos('CoreOS', '', '', {})
    assert facts['distribution_release'] == 'stable'



# Generated at 2022-06-20 19:18:34.966510
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    class MockModule:
        def __init__(self, params):
            self.params = param

        def get_bin_path(self, path):
            return None

        def run_command(self, command):
            return 0, "", ""

    class MockFacts:
        def __init__(self, facts):
            self._facts = facts

        def get(self, key, default=None):
            return self._facts.get(key, default)

    for distribution in ("Debian", "Raspbian"):
        dist_file_facts = DistributionFiles(MockModule({}), MockFacts({})).parse_distribution_file_Debian(distribution, "Debian", "/etc/debian_version", {})
        assert dist_file_facts['distribution'] == "Debian"


# Generated at 2022-06-20 19:18:42.972910
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distribution_files = DistributionFiles()
    name = 'CentOS Stream'
    data = ''
    path = ''
    collected_facts = ''
    centos_facts = distribution_files.parse_distribution_file_CentOS(name, data, path, collected_facts)
    assert centos_facts[1]['distribution_release'] == 'Stream'
    return True



# Generated at 2022-06-20 19:18:56.051033
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    dist_file_name = 'Alpine'
    dist_file_data = 'v3.9'
    dist_file_path = '/etc/alpine-release'
    collected_facts = {
        'distribution_file_name': 'Alpine',
        'distribution_file_data': 'v3.9',
        'distribution_file_path': '/etc/alpine-release',
        'distribution_file_variety': 'Alpine',
        'distribution_version': 'NA',
        'distribution_major_version': 'NA',
        'distribution_release': 'NA',
        'distribution': 'NA',
        'distribution_file_parsed': False
    }
    dist_file = DistributionFiles()
    parsed_dist_file, parsed_dist_file_facts = dist_file

# Generated at 2022-06-20 19:19:04.676861
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    dist = Distribution(None)
    # Patching get_file_content() to return a content from a file
    with patch(
        'ansible_collections.ansible.netcommon.plugins.module_utils.network.common.platform.get_file_content',
        return_value="Content"
        ):
        result = dist.get_distribution_SMGL()
    assert result['distribution'] == 'Source Mage GNU/Linux'



# Generated at 2022-06-20 19:19:17.673509
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = get_module_mock({'run_command': run_command_mock})
    dist = Distribution(module)


# Generated at 2022-06-20 19:19:30.121682
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    di = DistributionFiles()
    collected = {'distribution': 'redhat',
                'distribution_major_version': "7",
                'distribution_release': 'core',
                'distribution_version': '10.0.1013'}
    na1_data = """
        NAME=openSUSE
        VERSION_CODENAME=Leap
        VERSION_ID=42.3
    """
    na2_data = """
        NAME=stupid_distro
        VERSION_CODENAME="Leap"
    """
    na3_data = """
        VERSION_CODENAME="Leap"
    """
    na4_data = """
        VERSION_CODENAME=Leap
        VERSION_ID=42.3
    """

# Generated at 2022-06-20 19:20:14.764673
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)


# Generated at 2022-06-20 19:20:26.000854
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    """
    test get_distribution_facts method of class Distribution
    """
    test_module = FakeAnsibleModule()
    test_module.get_bin_path.return_value = '/bin/sh'
    test_module.run_command.return_value = (0, 'Linux', '')
    test_module.params = {'ansible_facts': {'os_family': 'Linux'}}
    test_distribution = Distribution(test_module)
    test_distribution_facts = test_distribution.get_distribution_facts()
    assert type(test_distribution_facts) is dict
    assert 'os_family' in test_distribution_facts
    assert 'distribution' in test_distribution_facts



# Generated at 2022-06-20 19:20:31.002465
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
   data_from_system = {'distribution': 'OpenBSD', 'distribution_release': '6.4', 'distribution_version': '6.4'}
   distribution = Distribution(FakeModule())
   result = distribution.get_distribution_OpenBSD()
   assert data_from_system == result


# Generated at 2022-06-20 19:20:36.895731
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    fc = DistributionFactCollector()
    assert fc.name == 'distribution'
    assert fc._fact_ids == set(['distribution_version', 'distribution_release', 'distribution_major_version', 'os_family'])

# Generated at 2022-06-20 19:20:46.402093
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    from ansible.module_utils.facts.linux.distribution import DistributionFiles

    expected_facts = {'distribution_file_parsed': True, 'distribution_file_path': '/etc/os-release',
                      'distribution_file_variety': 'Debian', 'distribution': 'Ubuntu',
                      'distribution_release': 'xenial', 'distribution_version': '16.04'}
    dist = DistributionFiles()
    parsed_facts = dist.process_dist_files({}, ['/etc/os-release'])
    assert parsed_facts == expected_facts


# Generated at 2022-06-20 19:20:55.958022
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    test_module = GetDistribution(dict())
    test_Distribution = Distribution(test_module)
    test_facts = dict()
    test_facts['distribution'] = 'SunOS'
    data = "SmartOS 20141111T003300Z"
    test_Distribution._get_file_content = MagicMock(return_value=data)
    test_Distribution._file_exists = MagicMock(return_value=True)
    test_Distribution._get_uname = MagicMock(return_value='v1')
    expected_facts = {'distribution': 'SmartOS', 'distribution_release': 'SmartOS 20141111T003300Z', 'distribution_version': 'v1'}
    obtained_facts = Distribution.get_distribution_SunOS(test_Distribution)
    assert obtained_facts

# Generated at 2022-06-20 19:21:07.018774
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    distribution = Distribution(module)

    # test function with release - current
    setattr(platform, 'release', MagicMock(name='release', return_value='6.0_BETA'))
    setattr(subprocess, 'Popen', MagicMock(name='Popen'))
    mock_get_command_stdout = MagicMock(name='get_command_stdout', return_value='OpenBSD 6.0 (GENERIC) #64: Fri Mar 24 12:21:52 MDT 2017\ndoug@tova.gw.com:/usr/src/sys/arch/amd64/compile/GENERIC\n')
    setattr(module.params, 'get_command_stdout', mock_get_command_stdout)

# Generated at 2022-06-20 19:21:12.690211
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec={})
    distribution = Distribution(module)
    assert distribution.get_distribution_AIX() == {'distribution_major_version': '7', 'distribution_version': '7.1'}


# Generated at 2022-06-20 19:21:24.988215
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    module = AnsibleModule(argument_spec={})
    name = "SLES"
    data = "ID=SLES VERSION_ID=11.4 PATCHLEVEL=22"
    path = "/etc/os-release"
    collected_facts = {'distribution_version': '11.4'}

    dist_file = DistributionFiles()

    parsed_dist_file, parsed_dist_file_facts = dist_file.parse_distribution_file_SUSE(name, data, path, collected_facts)
    assert parsed_dist_file
    assert parsed_dist_file_facts == {'distribution': 'SLES',
                                     'distribution_release': '22',
                                     'distribution_version': '11.4.22'}

# Generated at 2022-06-20 19:21:36.904053
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    # The data to parse is stored in a file
    t_data = open('tests/unittests/resources/parse_distribution_file/slackware').read()
    t_data = t_data.splitlines()
    dist_file = DistributionFiles({}, {}, {}, {}, {})

    # Empty path variable
    t_path = ''
    t_name = 'Slackware'
    t_collected_facts = {'distribution': 'NA'}
    t_parsed_dist_file, t_parsed_dist_file_facts = dist_file.parse_distribution_file_Slackware(t_name, t_data, t_path, t_collected_facts)
    # The parsed data should be equal to the data stored in the file tests/unittests/resources/parse_distribution