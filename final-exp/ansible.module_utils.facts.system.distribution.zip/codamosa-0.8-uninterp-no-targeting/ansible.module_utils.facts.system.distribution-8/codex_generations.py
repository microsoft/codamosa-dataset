

# Generated at 2022-06-20 19:12:43.368522
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    module = MagicMock(run_command=Mock(return_value=(0, '', '')))
    distribution = Distribution(module=module)
    distribution.get_distribution_facts = Mock(return_value={'distribution_major_version': '1',
                                                             'distribution_release': '1.1',
                                                             'distribution_version': '1.1',
                                                             'distribution': 'MacOSX'})
    distro_collector = DistributionFactCollector(module=module, collect_subset=['all'])

# Generated at 2022-06-20 19:12:47.619365
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    d = DistributionFiles(module)
    name = 'Amazon'
    path = '/etc/system-release-cpe'
    data = 'cpe:/o:amazon:linux:2017.03:ga'
    collected_facts = {}

    assert d.parse_distribution_file_Amazon(name, data, path, collected_facts) == (True, {'distribution': 'Amazon'})

# Generated at 2022-06-20 19:12:49.555513
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist_files = DistributionFiles(module_importer=MockModuleUtilsImporter())
    assert isinstance(dist_files, DistributionFiles)



# Generated at 2022-06-20 19:12:54.075861
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('module') == 'module'
    assert get_uname('module','flags') == 'module'



# Generated at 2022-06-20 19:13:03.033153
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    """ test parse_distribution_file method of DistributionFiles
    """
    # create instance of class DistributionFiles
    distribution_files = DistributionFiles()
    # create fake system facts
    collected_facts = {}
    # create fake object for system data
    class Data:
        name = 'NA'
        data = 'NAME=Qubes\nVERSION=4.0'
        path = '/etc/os-release'
    # call method parse_distribution_file with created objects
    distribution_file_found, distribution_file_facts = distribution_files.parse_distribution_file(Data, collected_facts)
    assert distribution_file_found == True
    assert distribution_file_facts['distribution'] == 'Qubes'
    assert distribution_file_facts['distribution_version'] == '4.0'



# Generated at 2022-06-20 19:13:09.077238
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist_file_paths = ['/etc/redhat-release', '/etc/os-release']
    dist_file_names = ['RedHat', 'NA']
    dist_file_facts = {}
    dist_file_facts['distribution_file_path'] = '/etc/redhat-release'
    dist_file_facts['distribution_file_variety'] = 'RedHat'
    dist_file_facts['distribution_file_parsed'] = True

    dist_files_obj = DistributionFiles(dist_file_paths, dist_file_names, dist_file_facts)
    assert dist_files_obj.dist_file_paths == dist_file_paths
    assert dist_files_obj.dist_file_names == dist_file_names

# Generated at 2022-06-20 19:13:14.584023
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    distro_facts = DistributionFactCollector()

    print(distro_facts.name)
    print(distro_facts._fact_ids)

if __name__ == '__main__':
    test_DistributionFactCollector()

# Generated at 2022-06-20 19:13:16.615300
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    from distutils import distribution

    print(distribution.get_distribution_DragonFly())

# Generated at 2022-06-20 19:13:22.213581
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    test_module = AnsibleModule(argument_spec={})  # noqa
    darwin_facts = Distribution(test_module).get_distribution_Darwin()
    assert darwin_facts['distribution'] == 'MacOSX'
    assert darwin_facts['distribution_version'] == '10.15'
    assert darwin_facts['distribution_major_version'] == '10'



# Generated at 2022-06-20 19:13:25.990620
# Unit test for constructor of class Distribution
def test_Distribution():
    # TODO: consider moving to the test module
    module = AnsibleModule(argument_spec={})
    expected = {'distribution': 'Linux'}
    dist = Distribution(module=module)
    assert dist.get_distribution_facts() == expected


# Generated at 2022-06-20 19:13:55.629000
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    """
    Method parse_distribution_file_Mandriva
    """
    # TODO: remove
    assert 1 != 2


# Generated at 2022-06-20 19:13:57.909802
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    facts = {}
    assert DistributionFiles().parse_distribution_file_Alpine('Alpine', '3.12.0',
                                                              '/etc/os-release', facts) == (True,
                                                                                           {'distribution': 'Alpine',
                                                                                            'distribution_version': '3.12.0'})
    return True



# Generated at 2022-06-20 19:14:07.503105
# Unit test for function get_uname
def test_get_uname():
    from ansible.module_utils.common.process import get_bin_path
    module = None
    rc = 0
    out = ''
    err = ''
    if get_bin_path('uname', required=False):
        rc = 0
        out = 'Linux'
        err = ''
    else:
        rc = 1
        err = 'FAIL'
    assert get_uname(module, flags='-s') == out


# Generated at 2022-06-20 19:14:13.438069
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    # unknown macosx version
    monkeypatch_uname_result('Darwin Unknown')
    darwin_facts = Distribution(module).get_distribution_Darwin()
    assert darwin_facts['distribution_major_version'] == 'Unknown'
    assert darwin_facts['distribution_version'] == 'Unknown'

    # macosx 10.14 version
    monkeypatch_uname_result('Darwin 18.2.0')
    darwin_facts = Distribution(module).get_distribution_Darwin()
    assert darwin_facts['distribution_major_version'] == '18'
    assert darwin_facts['distribution_version'] == '18.2.0'

   

# Generated at 2022-06-20 19:14:21.175761
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():

    from ansible.module_utils.facts import Distribution

    class Module:

        def run_command(self, cmd):
            return 0, "10.13.2", ""

    module = Module()

    state = Distribution(module)

    assert state.get_distribution_Darwin() == {'distribution': 'MacOSX', 'distribution_major_version': '10', 'distribution_version': '10.13.2'}



# Generated at 2022-06-20 19:14:26.885298
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    fact_collector = DistributionFactCollector(module)
    result = fact_collector.collect()
    # user_facts
    assert 'distribution_version' in result
    assert 'distribution_release' in result
    assert 'distribution_major_version' in result
    assert 'os_family' in result

# Generated at 2022-06-20 19:14:35.898749
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_module = AnsibleModule(argument_spec={})
    test_distribution_files_class = DistributionFiles(test_module)
    distro = 'Slackware'
    data = "Slackware 14.0"
    path = "/etc/slackware-version"
    collected_facts = {'distribution_file_path': path,
                       'distribution_file_variety': distro,
                       'distribution_file_parsed': False,
                       'distribution_file_facts': {}}
    expected_out = True, {'distribution': 'Slackware', 'distribution_version': '14.0'}
    actual_out = test_distribution_files_class.parse_distribution_file_Slackware(distro, data, path, collected_facts)
    assert expected_out == actual

# Generated at 2022-06-20 19:14:37.064042
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    fc = DistributionFactCollector()
    # raise Exception(fc.collect())
    assert fc.collect()

# Generated at 2022-06-20 19:14:41.812579
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    def result():
        return 8.2
    platform.release = result
    distribution = Distribution(
        module=None
    )
    assert distribution.get_distribution_FreeBSD() == {
        'distribution_release': '8.2'
    }



# Generated at 2022-06-20 19:14:48.522813
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    distribution = DistributionFactCollector()
    assert distribution.name == 'distribution'
    assert set(distribution._fact_ids) == {'os_family', 'distribution_release', 'distribution_version', 'distribution_major_version'}
    assert DistributionFactCollector.__doc__ == 'Collects distribution-related facts'



# Generated at 2022-06-20 19:15:33.099497
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    
    # TODO: add test
    assert False, 'TODO: add test'


# Generated at 2022-06-20 19:15:41.548303
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str'),
            name=dict(type='str'),
            path=dict(type='str'),
            collected_facts=dict(type='dict'),
        ),
        supports_check_mode=True,
    )
    module.exit_json(changed=False)



# Generated at 2022-06-20 19:15:46.188674
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    import ansible.module_utils.facts.system.distribution as distribution_mgr

    # Arrange
    dist_mgr = distribution_mgr.Distribution(None)

    # Act
    result = dist_mgr.get_distribution_FreeBSD()

    # Assert
    assert result == {
      'distribution_release': '11.2-RELEASE-p1'
    }


# Generated at 2022-06-20 19:15:57.056969
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    m = DistributionFiles()

# Generated at 2022-06-20 19:16:02.726146
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    os_release_facts = Distribution({}).get_distribution_NetBSD()
    assert os_release_facts['distribution_major_version'] == '7'
    assert os_release_facts['distribution_version'] == '7.2'
    assert os_release_facts['distribution_release'] == '7.2_STABLE'


# Generated at 2022-06-20 19:16:17.397350
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)


# Generated at 2022-06-20 19:16:26.184556
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_DistributionFiles = DistributionFiles()
    test_collected_facts = dict()
    test_data = "Slackware 15.0"
    test_path = "/etc/slackware-release"
    test_name = "Slackware"

    test_parsed_dist_file, test_parsed_dist_file_facts = test_DistributionFiles.parse_distribution_file_Slackware(test_name, test_data, test_path, test_collected_facts)
    assert test_parsed_dist_file is True
    assert test_parsed_dist_file_facts == {'distribution': 'Slackware', 'distribution_version': '15.0'}


# Generated at 2022-06-20 19:16:27.641939
# Unit test for function get_uname
def test_get_uname():
    assert get_uname(['-v']) == '-v'



# Generated at 2022-06-20 19:16:35.976198
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    path = './test/data/distribution_files/os-release-NA_in'
    test_name = 'NA'
    with open(path) as f:
        data = f.read()
    collected_facts = {'distribution_version': 'NA',
                       'distribution_release': 'NA',
                       'distribution': 'NA'}
    new_data = DistributionFiles().parse_distribution_file_NA(test_name, data, path, collected_facts)
    with open('./test/data/distribution_files/os-release-NA_out') as exp_f:
        expected = exp_f.read()
    assert new_data[1]['distribution'] == json.loads(expected)['distribution']

# Generated at 2022-06-20 19:16:48.223028
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = Mock()

# Generated at 2022-06-20 19:17:21.284986
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    df = DistributionFiles()
    # below are all key:values that are expected to be returned from the OS Facts

# Generated at 2022-06-20 19:17:32.127825
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    df = DistributionFiles()
    name = 'Clear Linux'

# Generated at 2022-06-20 19:17:42.298953
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    module = AnsibleModule(argument_spec={})
    distfiles = DistributionFiles()
    distfiles.module = module
    distfiles.lsb_release_file = None
    distfiles.os_release_file = None
    distfiles.etc_redhat_release = None
    distfiles.etc_issue = None
    distfiles.etc_lsb_release = None

    name = 'CentOS Stream'
    path = '/etc/os-release'

# Generated at 2022-06-20 19:17:50.214002
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    test_module = FakeModule()
    test_distribution = Distribution(module=test_module)
    test_distribution.get_distribution_NetBSD()
    assert test_module.run_command.call_count == 1
    assert test_module.run_command.call_args[0][0] == '/sbin/sysctl -n kern.version'

# Generated at 2022-06-20 19:17:53.191201
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('test') == 'test'



# Generated at 2022-06-20 19:18:02.942332
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    module = AnsibleModule(
        argument_spec=dict(
            distribution_files=dict(type='list'),
            distribution_file_facts=dict(type='dict'),
        )
    )
    distribution_files = DistributionFiles(module)
    dist_file_facts = distribution_files.process_dist_files(
        ['dist_file1', 'dist_file2'],
        {'distribution_file1': {'distribution': 'CentOS'}, 'distribution_file2': {'distribution': 'CentOS'}}
    )
    assert dist_file_facts['distribution'] == 'CentOS', 'distribution file facts were not processed correctly'

# Generated at 2022-06-20 19:18:14.040668
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module_mock = Mock()
    module_mock.run_command.return_value = 0, "NetBSD 4.0.1_PATCH (GENERIC) #0: Fri Feb 27 14:05:28 UTC 2009    builds@wb34:/home/builds/ab/netbsd-4-0-1-RELEASE/i386/200902242029Z-obj/home/builds/ab/netbsd-4-0-1-RELEASE/src/sys/arch/i386/compile/GENERIC", ""
    test_class = Distribution(module_mock)
    expected = {'distribution_release': 'NetBSD', 'distribution_major_version': '4', 'distribution_version': '4.0.1_PATCH'}
    actual = test_class.get_distribution_Net

# Generated at 2022-06-20 19:18:25.853282
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    """ Unit test for method parse_distribution_file_Coreos of class DistributionFiles """
    dist_files_object = DistributionFiles(module=None)

    # output of lsb_release -a on Ubuntu
    data = 'COREOS_RELEASE_GROUP=stable\n'
    coreos_facts = {'distribution': 'CoreOS', 'distribution_major_version': '1234.5.10', 'distribution_version': '1234.5.10'}
    coreos_dist_file_path = '/etc/lsb-release'

    parsed_coreos_distribution_file, parsed_coreos_facts = dist_files_object.parse_distribution_file_Coreos('CoreOS', data, coreos_dist_file_path, coreos_facts)


# Generated at 2022-06-20 19:18:35.905468
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    distrofiles = DistributionFiles()
    collected_facts = {'distribution': 'CentOS', 'distribution_version': '7', 'distribution_major_version': '7'}
    path = '/etc/os-release'
    data = 'NAME="CentOS Stream"'
    expected_facts = {'distribution_release': 'Stream'}
    assert distrofiles.parse_distribution_file_CentOS('CentOS', data, path, collected_facts)[1] == expected_facts

    data = 'NAME="CentOS GNU/Linux"'
    assert distrofiles.parse_distribution_file_CentOS('CentOS', data, path, collected_facts)[1] == {}
    assert distrofiles.parse_distribution_file_CentOS('CentOS', data, 'not os-release', collected_facts)[1] == {}



# Generated at 2022-06-20 19:18:42.609090
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    dist_file_facts = DistributionFiles()
    name = 'Flatcar Container Linux'
    data = 'GROUP=beta'
    path = '/etc/flatcar-release'
    collected_facts = {'distribution': name, 'distribution_release': 'NA'}

    flatcar_facts = dist_file_facts.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert flatcar_facts[0]
    assert flatcar_facts[1] == {'distribution_release': 'beta'}

    data = 'GROUP='
    flatcar_facts = dist_file_facts.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert flatcar_facts[0]
    assert flatcar_facts[1] == {}


# Generated at 2022-06-20 19:19:41.490139
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    from ansible.module_utils.facts import DistributionFiles
    df = DistributionFiles(None)
    # Testing SUSE SLES
    name = "NA"
    data = ""
    path = "/etc/SuSE-release"
    facts = {'distribution_release': 'NA', 'distribution_version': '12.4'}
    # data = "SUSE Linux Enterprise Server 12 (x86_64)
    # VERSION = 12
    # PATCHLEVEL = 4
    # # This file is deprecated and will be removed in a future service pack or release.
    # # Please check /etc/os-release for details about this release.
    # "

# Generated at 2022-06-20 19:19:44.160471
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    assert DistributionFactCollector.name == 'distribution'
    assert DistributionFactCollector._fact_ids == {'distribution_version',
                                                   'distribution_release',
                                                   'distribution_major_version',
                                                   'os_family'}

# Generated at 2022-06-20 19:19:51.821285
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    dist_files = DistributionFiles()
    files = [os.path.join(os.path.dirname(__file__), os.pardir, 'test/ansible_facts/test_distro_files/', f) for f in os.listdir(os.path.join(os.path.dirname(__file__), os.pardir, 'test/ansible_facts/test_distro_files/'))]
    files_abs = []
    for f in files:
        files_abs.append(os.path.abspath(f))
    files = files_abs
    is_file_variety = []

    for file in files:
        is_file_variety.append(dist_files.is_file_variety_distribution_file(file))
    dist_files.files = files
    dist_

# Generated at 2022-06-20 19:20:00.889112
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    # mock module argument
    module = MagicMock(name='module')
    module.run_command = MagicMock(name='run_command')
    module.run_command.return_value = (0, "", "")

    # mock collected_facts argument
    collected_facts = MagicMock(name='collected_facts')

    # call the tested method
    dist_fact_collector = DistributionFactCollector()
    facts_dict = dist_fact_collector.collect(module=module, collected_facts=collected_facts)

    # make assertions
    assert isinstance(facts_dict, dict)
    assert 'distribution_release' in facts_dict.keys()
    assert 'distribution_version' in facts_dict.keys()
    assert 'distribution_major_version' in facts_dict.keys()

# Generated at 2022-06-20 19:20:12.899329
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # pylint: disable=protected-access
    distribution_files = DistributionFiles()
    distribution_files._cache_distro_facts = {'ansible_distribution': 'NA'}
    data = 'NAME="Amazon Linux AMI" VERSION="2016.09" ID="amzn" ID_LIKE="rhel fedora" VERSION_ID="2016.09" PRETTY_NAME="Amazon Linux AMI 2016.09" ANSI_COLOR="0;33" CPE_NAME="cpe:/o:amazon:linux:2016.09:ga" HOME_URL="http://aws.amazon.com/amazon-linux-ami/"'
    name = 'Amazon'
    path = '/etc/os-release'
    correct_parsed_dist_file, correct_parsed_dist_file_facts = distribution_files.parse_dist

# Generated at 2022-06-20 19:20:20.016127
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    distribution = Distribution(None)
    assert 'AIX' == distribution.get_distribution_AIX()['distribution']
    assert '10' == distribution.get_distribution_AIX()['distribution_major_version']
    assert '10.4' == distribution.get_distribution_AIX()['distribution_version']
    assert '4' == distribution.get_distribution_AIX()['distribution_release']


# Generated at 2022-06-20 19:20:21.568593
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    pass


# Generated at 2022-06-20 19:20:32.957214
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    """
    Unit test for class Distribution, method get_distribution_facts

    :return: False if successful, True if unsuccessful
    """

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, use_unsafe_shell=False, environ_update=None, umask=None, encoding=None):
            self.run_command_calls.append(command)
            return self.run_command_results.pop(0)

    realized_facts = {}
    realized_facts['distribution'] = 'Linux'

# Generated at 2022-06-20 19:20:40.185818
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = AnsibleModule(
    )
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_NetBSD()
    assert distribution_facts['distribution_release'] == '9.99.49'
    assert distribution_facts['distribution_major_version'] == '9'
    assert distribution_facts['distribution_version'] == '9.99'

# Generated at 2022-06-20 19:20:54.004694
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    df = DistributionFiles()

    # Test case 1
    # normal case
    facts = {}