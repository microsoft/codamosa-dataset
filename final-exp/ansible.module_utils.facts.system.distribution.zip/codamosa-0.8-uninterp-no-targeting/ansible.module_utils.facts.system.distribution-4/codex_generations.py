

# Generated at 2022-06-20 19:12:21.220946
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    test_module = ansible_module_mock()
    fact_collector = DistributionFactCollector(module=test_module)
    result = fact_collector.collect()
    assert result['os_family'] != ''
    assert result['distribution_version'] != ''
    assert result['distribution_release'] != ''
    assert result['distribution_major_version'] != ''

# Generated at 2022-06-20 19:12:26.108823
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():

    class MyModule(object):
        def __init__(self, **kwargs):
            self.distro = kwargs.get('distro')

        def get_distribution(self):
            return self.distro

        def run_command(self, cmd):
            if cmd.startswith("/usr/bin/sw_vers -productVersion"):
                return 0, "MacOSX 10.12.6", None
            if cmd.startswith("/usr/bin/lsb_release -s -r"):
                return 0, "18.04", None
            if cmd.startswith("/usr/bin/lsb_release -s -i"):
                return 0, "Ubuntu", None
            if cmd.startswith("/usr/bin/lsb_release -s -d"):
                return 0

# Generated at 2022-06-20 19:12:27.146718
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    assert DistributionFactCollector.name == 'distribution'
    assert 'distribution_version' in DistributionFactCollector._fact_ids


# Generated at 2022-06-20 19:12:37.364788
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    dist_file_paths = [
        '/usr/lib/os-release',
        '/etc/os-release'
    ]

# Generated at 2022-06-20 19:12:47.235874
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    df = DistributionFiles()
    # This test reads the file etc/mandriva-release and runs check on it
    # The file may not exist on the system, or is not the first one found
    # the unit test will fail until it finds the file.
    for path in df.distribution_files:
        if 'mandriva-release' in path:
            if os.path.exists(path):
                with open(path) as f:
                    data = f.read()
                break
            else:
                data = ''
    collected_facts = {}
    name = 'Mandriva'
    success, facts = df.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert success and isinstance(facts, dict)
    assert facts['distribution'] == 'Mandriva'
   

# Generated at 2022-06-20 19:12:54.551559
# Unit test for method process_dist_files of class DistributionFiles
def test_DistributionFiles_process_dist_files():
    # Unit tests for method process_dist_files of class DistributionFiles
    # Linters - test that the "collect_distribution_files" function collects only files that are listed
    module_name = 'ansible.plugins.processor.collect_distribution_files'
    d = DistributionFiles(module=None)
    module_obj = importlib.import_module(module_name)
    d.distribution_files_path = module_obj.distribution_files_path
    facts = {}
    test_distros = {'debian': {}, 'centos': {}}
    for name in d.get_distribution_files_names():
        parsed_dist_file, parsed_dist_file_facts = d.process_dist_files(name, facts)
        if parsed_dist_file:
            test_distros[name] = parsed_dist

# Generated at 2022-06-20 19:13:00.888442
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    module = AnsibleModule(argument_spec=dict())
    distribution = Distribution(module)
    aix_facts = distribution.get_distribution_AIX()
    assert aix_facts['distribution_major_version'] == '7'
    assert aix_facts['distribution_version'] == '7.2'


# Generated at 2022-06-20 19:13:08.298070
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.distribution import DistributionFiles
    import io

    lsb_file_data = io.StringIO("""
DISTRIB_ID="OpenWrt"
DISTRIB_RELEASE="Marvell Kirkwood"
DISTRIB_REVISION="r35667"
DISTRIB_CODENAME="kirkwood"
DISTRIB_TARGET="nsa330"
DISTRIB_DESCRIPTION="OpenWrt Marvell Kirkwood r35667"
DISTRIB_TAINTS="no-all busybox"
""")

# Generated at 2022-06-20 19:13:16.659370
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
  d = Distribution(Mock(stdout=os.linesep.join(
    ["HPUX-oe-09.01.000.00000.sparc-64", "HPUX-oe-09.01.000.00000.sparc-32"])))
  assert d.get_distribution_HPUX() == {'distribution_version': 'B.09.01', 'distribution_release': '00000'}
 

# Generated at 2022-06-20 19:13:23.063381
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    collector = DistributionFactCollector()
    assert collector.name == 'distribution'
    assert collector._fact_ids == {'distribution_version',
                                   'distribution_release',
                                   'distribution_major_version',
                                   'os_family'}

# Generated at 2022-06-20 19:14:10.278108
# Unit test for method get_distribution_NetBSD of class Distribution
def test_Distribution_get_distribution_NetBSD():
    module = MagicMock()
    distribution = Distribution(module)

    uname_version = "NetBSD 7.99.35 (GENERIC) #0: Mon Sep  9 19:34:58 UTC 2019   mkrepro@mkrepro.NetBSD.org:/usr/src/sys/arch/amd64/compile/GENERIC amd64"
    module.run_command.return_value = ['', uname_version, '']

    fact_distribution = distribution.get_distribution_NetBSD()

    expected_result = {
        'distribution_release': '7.99.35',
        'distribution_major_version': '7',
        'distribution_version': '7.99'
    }

    assert fact_distribution == expected_result


# Generated at 2022-06-20 19:14:13.122703
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    class mock_module:
        def run_command(cmd, use_unsafe_shell=False):
            out = "6.2.9.0"
            return 1, out, ""
    myDistribution = Distribution(module=mock_module)
    myAIXFacts = myDistribution.get_distribution_AIX()
    assert myAIXFacts['distribution_version'] == "6.2"
    assert myAIXFacts['distribution_release'] == "9.0"



# Generated at 2022-06-20 19:14:23.446912
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles

# Generated at 2022-06-20 19:14:25.326129
# Unit test for function get_uname
def test_get_uname():
    uname = get_uname(module)
    assert uname is not None



# Generated at 2022-06-20 19:14:34.045800
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    def fake_path_exists(path):
        if path == "/etc/os-release":
            return True
        return False
    def fake_get_file_content(path):
        if path == "/etc/os-release":
            return "OpenWrt"
    fake_module = FakeModule(
        params={},
        ansible_facts={},
    )
    fake_module.exists_file_name = fake_path_exists
    fake_module.get_file_content = fake_get_file_content
    dist_files = DistributionFiles(fake_module, {})
    facts = dist_files.parse_distribution_file_OpenWrt("OpenWrt",  "/etc/os-release", {})
    assert facts['distribution'] == "OpenWrt"

    # Test that non-OpenWrt

# Generated at 2022-06-20 19:14:46.271829
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    """
    Unit test for method get_distribution_SunOS of class Distribution.
    For Solaris 10 and 11.
    """
    from ansible.module_utils.facts.distribution.sunos import Distribution

    import sys
    import tempfile

    class MockModule(object):
        pass

    module = MockModule()

    # monkeypatching os.path.isfile to return True
    # thus simulates the file exists
    def mock_file_exists(path):
        return True

    def mock_system(shell, cmd):
        return 0, 'ok', 'ok'

    def mock_uname(shell, flags):
        return "5.11"

    def mock_get_file_content(path):
        """
            Mocks the reading of the file
            and returns the content of the file
        """
        solar

# Generated at 2022-06-20 19:14:57.339636
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_CentOS():
    # TODO: test CentOS Stream
    if sys.version_info.major == 2:
        from ansible.module_utils.facts import DistributionFiles
    elif sys.version_info.major == 3:
        from ansible.module_utils.facts.system.distribution import DistributionFiles

    distributionFacts = DistributionFiles()

    # Test Cent OS Stream flag
    # stream_test = 'CentOS Stream'
    # centos_stream_facts = {}
    # centos_stream_facts = distribution_file_facts['distribution']['CentOS'].parse_distribution_file(stream_test, stream_test, "/etc/os-release", centos_stream_facts)

    # assert centos_stream_facts['distribution_release'] == 'Stream'

    # Test Cent OS flag

# Generated at 2022-06-20 19:15:06.458516
# Unit test for method parse_distribution_file_CentOS of class DistributionFiles

# Generated at 2022-06-20 19:15:12.650072
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distrib_f = DistributionFiles()
    data = '''
    NAME=Fedora
    VERSION="31 (Workstation Edition)"
    ID=fedora
    VERSION_ID=31
    '''

    expected = {
        'distribution': 'Fedora',
        'distribution_version': '31'
    }
    res = distrib_f.parse_distribution_file_NA('NA', data, '', {})
    assert res[1] == expected



# Generated at 2022-06-20 19:15:14.897250
# Unit test for function get_uname
def test_get_uname():
    module = AnsibleModule()
    assert get_uname(module) != None


# Generated at 2022-06-20 19:15:46.222525
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    d = DistributionFiles(None, None)
    data = 'alpine'
    name = 'alpine'
    path = 'path'
    collected_facts = {}
    assert d.parse_distribution_file_Alpine(name, data, path, collected_facts) == (True, {'distribution': 'Alpine', 'distribution_version': 'alpine'})


# Generated at 2022-06-20 19:15:57.540545
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    class ModuleStub(object):

        def __init__(self):
            self.run_command_called_with = []

        def run_command(self, cmd, use_unsafe_shell):
            self.run_command_called_with.append((cmd, use_unsafe_shell))

            if cmd == "/sbin/sysctl -n kern.version":
                return (0, 'OpenBSD 5.8 (GENERIC) #0: Wed Feb 10 18:01:38 UTC 2016     deraadt@i386.openbsd.org:/usr/src/sys/arch/i386/compile/GENERIC', '')
            else:
                return (0, '', '')

    module = ModuleStub()

    distribution = Distribution(module)
    facts = distribution.get_distribution_OpenBSD()



# Generated at 2022-06-20 19:16:06.220075
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    module = MagicMock()
    mock_data = MagicMock()
    module.run_command.return_value = (0, '', '')
    mock_data.splitlines.return_value = ["OpenIndiana Hipster"]
    mock_data.split.return_value = "OpenIndiana Hipster".split(" ")
    mock_data.strip.return_value = "OpenIndiana Hipster"
    module.get_file_content.return_value = mock_data
    dist = Distribution(module)
    sunos_facts = dist.get_distribution_SunOS()
    assert sunos_facts == {'distribution': 'OpenIndiana', 'distribution_release': 'OpenIndiana Hipster',
                           'distribution_version': 'Hipster'}


if __name__ == '__main__':
    module = Ansible

# Generated at 2022-06-20 19:16:08.704911
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    assert DistributionFiles(None)


# Generated at 2022-06-20 19:16:17.153829
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    dist = Distribution()
    print(dist.get_distribution_SunOS())
############################################################################
    # Sample output
    # {'distribution': 'SmartOS', 'distribution_release': 'SmartOS 14.4.0',
    # 'distribution_version': '20190208T182617Z'}

    # {'distribution': 'OpenIndiana', 'distribution_release': 'OpenIndiana Hipster 2019.04',
    # 'distribution_version': '5.11'}
############################################################################

# Generated at 2022-06-20 19:16:23.678103
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    module = AnsibleModule(argument_spec={'test_data': {'required': False, 'type': 'dict'}})
    dist_file_facts = DistributionFiles(module).parse_distribution_file_OpenWrt(name="OpenWrt", data='DISTRIB_ID=OpenWrt', path='/etc/os-release', collected_facts={})
    assert dist_file_facts['distribution'] == 'OpenWrt' and dist_file_facts['distribution_release'] == 'DISTRIB_CODENAME="ramips_24kec"\n' and dist_file_facts['distribution_version'] == 'DISTRIB_RELEASE="18.06.3"\n'

# Generated at 2022-06-20 19:16:33.190750
# Unit test for method parse_distribution_file_Amazon of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Amazon():
    # test without /etc/os-release
    file_data = 'Amazon Linux AMI release 2013.09'
    result, data = DistributionFiles().parse_distribution_file_Amazon('Amazon', file_data, '/etc/issue', {})
    assert (result is True) and ('distribution_version' in data) and (data['distribution_version'] == '2013.09')
    # test with /etc/os-release

# Generated at 2022-06-20 19:16:45.918312
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    module = AnsibleModule(
        argument_spec=dict(
            distribution_files=dict(type='list', required=False, default=[]),
        ),
    )

    obj = DistributionFiles(module)

    assert obj.parse_distribution_file_Coreos(name='CoreOS',
                                              data='\n'.join([
                                                  '',
                                                  'GROUP=stable',
                                              ]),
                                              path='/usr/share/coreos/release',
                                              collected_facts={}) == \
        (True, {'distribution_release': 'stable'})

# Generated at 2022-06-20 19:16:47.274501
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('Linux')



# Generated at 2022-06-20 19:17:01.703414
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    """
    Test parse_distribution_file_Alpine of DistributionFiles.

    """

    def run(self, name, data, path, collected_facts):
        return True, {'distribution': 'Alpine'}

    # first patch method
    DistributionFiles.parse_distribution_file_Alpine = run
    df_facts = DistributionFiles({})
    df_facts.files.append(('/etc/alpine-release', 'Alpine 3.4.6'))
    df_facts.get_distribution_file_facts()
    assert df_facts.facts['distribution'] == 'Alpine'
    # second patch method
    def run(self, name, data, path, collected_facts):
        return True, {'distribution': 'Alpine'}

# Generated at 2022-06-20 19:18:12.633480
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    import test_classes.module_utils.distribution_files as test_df
    df = test_df.DistributionFiles()

    #run a test of name, data, path, collected_facts = 'CoreOS', data, '/etc/os-release', collected_facts
    dfds = df.parse_distribution_file_Coreos('CoreOS', '/etc/os-release', collected_facts)
    assert dfds['distribution_release'] is 'NA'



# Generated at 2022-06-20 19:18:25.483910
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_ClearLinux():
    # Arrange
    facts = {}
    df = DistributionFiles(facts)
    name = 'clearlinux'
    data = '''NAME="Clear Linux"
            VERSION="32720"
            ID=clear-linux-os
            VERSION_ID=32720
            PRETTY_NAME="Clear Linux OS 32720"'''
    path = '/usr/lib/os-release'

# Generated at 2022-06-20 19:18:31.510863
# Unit test for constructor of class Distribution
def test_Distribution():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, "", "")

    distribution = Distribution(module=module_mock)

    # Check if the class was instantiated properly.
    assert distribution is not None

# Generated at 2022-06-20 19:18:45.861929
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    # Create an instance of DistributionFiles
    dist_files = DistributionFiles()
    # Create a sample collected_facts
    collected_facts = {'distribution_release': 'NA', 'distribution_version': '13.2'}
    # Create the expected output
    expected_out = (True, {'distribution': 'SLES', 'distribution_release': '2'})
    # Get sample data
    data = get_file_content('%s/data/distribution_files/parse_distribution_file_SUSE' % os.path.dirname(__file__))
    # Call parse_distribution_file_SUSE and assert the output is as expected
    assert expected_out == dist_files.parse_distribution_file_SUSE('SUSE', data, '/etc/os-release', collected_facts)

# Unit test

# Generated at 2022-06-20 19:18:55.153647
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(argument_spec={})
    test_dist = Distribution(module)
    dist_facts = test_dist.get_distribution_facts()

    assert dist_facts['distribution'] == system()

    if system() == 'AIX':
        rc, out, err = module.run_command("/usr/bin/oslevel -s")
        assert dist_facts['distribution_version'] == out.strip()

    elif system() == 'Darwin':
        rc, out, err = module.run_command("/usr/bin/sw_vers -productVersion")
        assert dist_facts['distribution_version'] == out.strip()


# Generated at 2022-06-20 19:19:07.358312
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    test_file_data = """
NAME="openSUSE Leap"
VERSION = "42.3"
VERSION_ID="42.3"
PRETTY_NAME="openSUSE Leap 42.3"
ID=opensuse
ID_LIKE="suse opensuse"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:leap:42.3"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://www.opensuse.org/"
    """

# Generated at 2022-06-20 19:19:18.353201
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    collected_facts = {}
    collected_facts['distribution_file_path'] = '/etc/os-release'
    collected_facts['distribution_file_variety'] = 'OpenWrt'
    collected_facts['distribution_file_parsed'] = True
    collected_facts['distribution_file_data'] = """NAME="OpenWrt"
ID=openwrt
VERSION="18.06.4"
ID_LIKE=lede
PRETTY_NAME="OpenWrt 18.06.4"
VERSION_ID=18.06.4
HOME_URL=https://www.openwrt.org/
SUPPORT_URL=https://forum.openwrt.org/
BUG_REPORT_URL="https://bugs.openwrt.org/"
"""
    collected_facts['distribution'] = 'NA'


# Generated at 2022-06-20 19:19:29.744715
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distfile = DistributionFiles({})
    # test with a dummy path and name
    assert distfile.parse_distribution_file_NA(
        name='NA', data="NAME=Fedora\nID=fedora\nVERSION=30 (Workstation Edition)", path='dummy', collected_facts={}) == ({'distribution': 'Fedora', 'distribution_version': '30 (Workstation Edition)'}, True)
    assert distfile.parse_distribution_file_NA(
        name='NA', data="NAME=Fedora\nID=fedora\nVERSION=MYVERSION", path='dummy', collected_facts={}) == ({'distribution': 'Fedora', 'distribution_version': 'MYVERSION'}, True)



# Generated at 2022-06-20 19:19:34.413118
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    # create an instance of DistributionFactCollector and
    # invoke method collect against it
    ch = DistributionFactCollector()
    result = ch.collect()
    print(result)
    # assert that method collect returns a dict
    assert isinstance(result, dict)

    # assert that there exists a key 'os_family' in the dict
    assert 'os_family' in result



# Generated at 2022-06-20 19:19:38.724270
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    """
    Test the constructor of class DistributionFactCollector
    """
    from ansible.module_utils.facts import ModuleFacts
    module = ModuleFacts(platform='Linux', version='2.6.9')

    distribution = Distribution(module=module)

    distro_fact_collector = DistributionFactCollector(
        module=module,
        collected_facts={})

    distro_facts = distribution.get_distribution_facts()



# Generated at 2022-06-20 19:20:54.509820
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    facter_ins = DistributionFiles()
    name = 'Slackware'
    data = 'Slackware 12.2'
    path = '/etc/slackware-version'
    slackware_facts = {'distribution_version': '12.2'}
    collected_facts = {}
    success, returned_facts = facter_ins.parse_distribution_file_Slackware(name, data, path, collected_facts)
    assert success == True, "method parse_distribution_file_Slackware() of class DistributionFiles failed to correctly parse Slackware file"
    assert returned_facts == slackware_facts, "method parse_distribution_file_Slackware() of class DistributionFiles returned incorrect facts"


# Generated at 2022-06-20 19:21:02.890019
# Unit test for method get_distribution_AIX of class Distribution
def test_Distribution_get_distribution_AIX():
    class module_mock:
        def __init__(self):
            pass
        def run_command(self, param1, **kwargs):
            return 0, "8.0", "err"
    module = module_mock()
    distribution = Distribution(module)
    distribution_facts = distribution.get_distribution_AIX()
    assert 'distribution_release' in distribution_facts


# Generated at 2022-06-20 19:21:09.181212
# Unit test for constructor of class DistributionFactCollector
def test_DistributionFactCollector():
    df = DistributionFactCollector
    assert df.name == 'distribution'
    assert df._fact_ids == {'os_family', 'distribution_major_version', 'distribution_version', 'distribution_release'}



# Generated at 2022-06-20 19:21:22.707524
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
  # arrange
  distribution = Distribution(module=None)
  # test Solaris
  data = 'Solaris 10 10/09 s10s_u9wos_14a SPARC'
  distribution_facts = distribution.get_distribution_SunOS()
  distribution_facts_solaris = distribution_facts['distribution']
  distribution_version_solaris = distribution_facts['distribution_version']
  distribution_release_solaris = distribution_facts['distribution_release']
  distribution_major_version_solaris = distribution_facts['distribution_major_version']
  # test OmniOS
  data = 'Oracle OmniOS Community Edition r151026'
  distribution_facts = distribution.get_distribution_SunOS()
  distribution_facts_omnios = distribution_facts['distribution']
  distribution_version_om

# Generated at 2022-06-20 19:21:29.233999
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    '''
    Unit test for method get_distribution_SunOS of class Distribution
    '''
    def test_object():
        import sys
        test_object = Distribution
        if sys.version_info[:2] == (2, 6):
            import __builtin__ as builtins
        else:
            import builtins

        class AnsibleModuleFake:
            def __init__(self):
                self.params = {}

            def fail_json(self, *args, **kwargs):
                pass

            def exit_json(self, *args, **kwargs):
                pass
        # class AnsibleModule: end

        class FunctionModuleMock:
            def __init__(self, client):
                self.client = client


# Generated at 2022-06-20 19:21:36.230485
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    m = module_args = {}
    m.update({'run_command.side_effect': [
        (0, 'Source Mage GNU/Linux', ''),
        (0, '0.98-2', ''),
    ]})
    with mock.patch.multiple(Distribution, module=m):
        dist = Distribution(module=m)
        assert dist.get_distribution_SMGL() == {'distribution': 'Source Mage GNU/Linux'}


# Generated at 2022-06-20 19:21:42.656979
# Unit test for method parse_distribution_file_SUSE of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_SUSE():
    distribution_files = DistributionFiles()
    data = get_file_content("/etc/os-release")
    test_distribution_facts = distribution_files.parse_distribution_file_SUSE('SUSE Enterprise', data, '/etc/os-release', {})[1]
    assert test_distribution_facts['distribution'] == 'SLES'

# Generated at 2022-06-20 19:21:48.758717
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    df_obj = DistributionFiles()
    df_obj.module = FakeAnsibleModule()
    from collections import namedtuple
    CollectedFacts = namedtuple('CollectedFacts', 'distribution_version distribution_release')
    collected_facts = CollectedFacts(distribution_version='NA', distribution_release='NA')
    dist_file_data = ""
    path = ""
    name = "Slackware"
    ans, slackware_facts = df_obj.parse_distribution_file_Slackware(name, dist_file_data, path, collected_facts)
    assert ans is False
    assert slackware_facts == {}

    dist_file_data = "Slackware 14.2"