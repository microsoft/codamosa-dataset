

# Generated at 2022-06-20 19:12:54.201582
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    name = "Mandriva Linux"
    data = "NAME=\"Mandriva Linux\"\nVERSION=\"2010 Spring\"\nID=mandriva\nVERSION_ID=\"2010.1\""
    path = "/etc/os-release"
    collected_facts = {}
    file_parser = DistributionFiles(module=None)
    parsed_dist_file, parsed_dist_file_facts = file_parser.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    assert parsed_dist_file == True
    assert parsed_dist_file_facts == {'distribution': 'Mandriva', 'distribution_version': '2010.1', 'distribution_release': 'mandriva'}



# Generated at 2022-06-20 19:13:02.427703
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    test_module = AnsibleModule(argument_spec=dict())
    test_distribution = Distribution(test_module)
    # Test FreeBSD 11.3-RELEASE
    dist_facts1 = test_distribution.get_distribution_FreeBSD()
    assert dist_facts1['distribution_major_version'] == '11'
    assert dist_facts1['distribution_version'] == '11.3'
    assert dist_facts1['distribution_release'] == '11.3-RELEASE'
    # Test FreeBSD 8.0-RELEASE
    dist_facts2 = test_distribution.get_distribution_FreeBSD()
    assert dist_facts2['distribution_major_version'] == '8'
    assert dist_facts2['distribution_version'] == '8.0'

# Generated at 2022-06-20 19:13:08.599925
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Set up mock module
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Set up class
    x = DistributionFiles(module)

    # parse_distribution_file_NA()
    name = 'NA'

# Generated at 2022-06-20 19:13:12.132906
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    distribution = Distribution(module=None)
    assert 'distribution' in distribution.get_distribution_Darwin().keys()



# Generated at 2022-06-20 19:13:23.063486
# Unit test for method parse_distribution_file_Mandriva of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Mandriva():
    print("TESTING: DistributionFiles_parse_distribution_file_Mandriva")
    dist_file_facts = {}
    name = "Mandriva"
    collected_facts = {}
    collected_facts['distribution_version'] = 'NA'
    data, path = load_fixture_data('distribution_Mandriva')
    dist_files = DistributionFiles(None)
    success, facts = dist_files.parse_distribution_file_Mandriva(name, data, path, collected_facts)
    dist_file_facts.update(facts)
    assert success
    assert 'Mandriva' == dist_file_facts['distribution']
    assert '2010.2' == dist_file_facts['distribution_version']
    assert 'hydrogen' == dist_file_facts['distribution_release']
    return

# Generated at 2022-06-20 19:13:32.069890
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)

    dfly_facts = {}
    dfly_facts['distribution_release'] = 'v5.5.0-RELEASE'
    rc, out, dummy = module.run_command("/sbin/sysctl -n kern.version")
    match = re.search(r'v(\d+)\.(\d+)\.(\d+)-(RELEASE|STABLE|CURRENT).*', out)
    if match:
        dfly_facts['distribution_major_version'] = match.group(1)
        dfly_facts['distribution_version'] = '%s.%s.%s' % match.groups()[:3]

    distro_facts = distro.get_distribution_DragonFly()

    assert dist

# Generated at 2022-06-20 19:13:37.222855
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distfile = DistributionFiles()
    distfile_parse_NA = distfile.parse_distribution_file_NA('NA', 'version = "7" \n name=CentOS', '', {})
    assert distfile_parse_NA == (True, {'distribution': 'CentOS'})



# Generated at 2022-06-20 19:13:39.516938
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # test stuff here
    dist_files = DistributionFiles()
    dist_files.parse_distribution_file_NA('NA', '', '')

# Generated at 2022-06-20 19:13:46.932513
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    test = DistributionFiles()
    collected_facts = {
        'distribution': 'RedHat'
    }

# Generated at 2022-06-20 19:14:01.021825
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    platform_release = '5.5-RELEASE'
    kern_version = 'OpenBSD 5.5-RELEASE (GENERIC.MP) #4: Wed Nov  7 14:00:31 MST 2012     root@rp43650.b12-1.bsd.example.com:/usr/src/sys/arch/sparc64/compile/GENERIC.MP sparc64'
    output = {
        'distribution_release' : platform_release,
        'distribution_version': '5.5'
    }
    module = MagicMock()
    module.run_command.return_value = (0, kern_version.splitlines()[0], '')
    distribution = Distribution(module)
    assert distribution.get_distribution_OpenBSD() == output



# Generated at 2022-06-20 19:14:33.840573
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    distribution_files = DistributionFiles(dict())
    assert distribution_files
    assert distribution_files.facts == {}



# Generated at 2022-06-20 19:14:44.361493
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distfiles = DistributionFiles()
    name, content = 'Slackware', 'Slackware 1.0'
    path, collected_facts = "~/.whatever", {}
    parsed, dist_facts = distfiles.parse_distribution_file_Slackware(name, content, path, collected_facts)
    assert parsed == True, "Failed to parse Slackware distribution file"
    assert dist_facts['distribution'] == name, "Failed to set distribution fact for Slackware distribution file"
    assert dist_facts['distribution_version'] == '1.0', "Failed to set distribution version fact for Slackware distribution file"



# Generated at 2022-06-20 19:14:50.454373
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():

    class Module:
        def __init__(self):
            self.platform_version = '11.1-RELEASE'

        def run_command(self, command, check_rc=True, use_unsafe_shell=None):
            return (0, "", "")

    dist = Distribution(module=Module())

    facts = dist.get_distribution_FreeBSD()
    assert facts['distribution_release'] == '11.1-RELEASE'

    return True

# Generated at 2022-06-20 19:14:55.137608
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = MockModule()
    module.run_command = MagicMock(return_value=(0, "/sbin/sysctl -n kern.version", ""))

    distribution_dragonfly = Distribution(module)
    assert distribution_dragonfly.get_distribution_DragonFly() == {'distribution_release': 'platform.release()'}



# Generated at 2022-06-20 19:15:03.981679
# Unit test for method collect of class DistributionFactCollector
def test_DistributionFactCollector_collect():
    testmodule_distribution = DistributionFactCollector()

    facts_dict = {
        'distribution_version': '3.13.0-39-generic',
        'distribution': 'Ubuntu',
        'distribution_release': '14.04',
        'distribution_major_version': '14',
        'os_family': 'Debian'}

    mocked_module = Mock()
    mocked_module.run_command.return_value = (0, '3.13.0-39-generic', '')
    mocked_module.get_file_content.return_value = 'Ubuntu 14.04.4 LTS'

    distribution = Distribution(mocked_module)

    distro_facts = distribution.get_distribution_facts()
    assert distro_facts == facts_dict



# Generated at 2022-06-20 19:15:13.152786
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    test_module = mock.MagicMock()

    # FreeBSD 12.0-RELEASE-p7
    test_module.run_command.return_value = (0, "FreeBSD 12.0-RELEASE-p7 GENERIC", '')
    dist = Distribution(test_module)
    freebsd_facts = dist.get_distribution_FreeBSD()
    assert freebsd_facts['distribution_release'] == '12.0-RELEASE-p7'
    assert freebsd_facts['distribution_major_version'] == '12'
    assert freebsd_facts['distribution_version'] == '12.0'

    # FreeBSD 12.0-STABLE
    test_module.run_command.return_value = (0, "FreeBSD 12.0-STABLE GENERIC", '')

# Generated at 2022-06-20 19:15:17.923369
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    module = AnsibleModule(argument_spec={})
    distro = Distribution(module)
    facts = distro.get_distribution_facts()

    assert facts['distribution'] == 'Linux'

# Generated at 2022-06-20 19:15:29.879606
# Unit test for method parse_distribution_file_Coreos of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Coreos():
    # Skip coreos test if coreos is not installed
    # FIXME: add test to check os.path.exists('/usr/share/coreos/release')
    if not os.path.exists('/usr/bin/lsb_release'):
        return True

    distro_files = DistributionFiles({})
    test_collectd_facts = {'distribution': 'Coreos', 'distribution_version': 'NA', 'distribution_release': 'NA', 'distribution_major_version': 'NA'}

    test_path = '/usr/share/coreos/release'
    # return from parse_distribution_file_Coreos should be tuple (distribution, distribution_version, distribution_release)
    with open(test_path) as coreos_release_file:
        coreos_release = coreos_release_file

# Generated at 2022-06-20 19:15:39.131619
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    facts = DistributionFiles(module).get_distribution_facts()
    # Ubuntu

# Generated at 2022-06-20 19:15:46.639093
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    test_DistributionFiles = DistributionFiles({})
    data = '''
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=15.05
DISTRIB_REVISION=r47067
DISTRIB_CODENAME=chaos_calmer
DISTRIB_TARGET=ar71xx/generic
DISTRIB_DESCRIPTION="OpenWrt Chaos Calmer 15.05.1"
DISTRIB_TAINTS=no-all
'''
    path = '/etc/openwrt_release'
    name = 'OpenWrt'
    collected_facts = {
    }

    result = test_DistributionFiles.parse_distribution_file_OpenWrt(name, data, path, collected_facts)


# Generated at 2022-06-20 19:16:24.357027
# Unit test for constructor of class Distribution
def test_Distribution():
    module = AnsibleModule(argument_spec={})

    dist = Distribution(module=module)

    distribution_facts = dist.get_distribution_facts()

    os_family = distribution_facts['os_family'] or ''
    distribution = distribution_facts['distribution'] or ''
    distribution_version = distribution_facts['distribution_version'] or ''
    distribution_release = distribution_facts['distribution_release'] or ''

    if os_family == 'RedHat' and distribution != 'RedHat':
        module.fail_json(msg="Invalid os_family")

    if distribution not in Distribution.OS_FAMILY_MAP or distribution == 'NA':
        module.fail_json(msg="Invalid distribution")

    if platform.dist()[0].lower() == 'fedora':
        if distribution != 'Fedora':
            module.fail_

# Generated at 2022-06-20 19:16:37.302408
# Unit test for method get_distribution_HPUX of class Distribution
def test_Distribution_get_distribution_HPUX():
    from ansible.module_utils.facts.distribution import Distribution
    d = Distribution(None)
    rc, out, err = d.module.run_command("/usr/sbin/swlist |egrep 'HPUX.*OE.*[AB].[0-9]+\.[0-9]+'", use_unsafe_shell=True)
    data = re.search(r'HPUX.*OE.*([AB].[0-9]+\.[0-9]+)\.([0-9]+).*', out)
    if data:
        hpux_facts = {'distribution_version': data.groups()[0],
                      'distribution_release': data.groups()[1]}
    assert hpux_facts == {'distribution_version': 'B.11.31', 'distribution_release': '123456'}



# Generated at 2022-06-20 19:16:48.811483
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    distribution_file_facts = {}
    distribution_file_facts['distribution_version'] = 'NA'

# Generated at 2022-06-20 19:17:02.152591
# Unit test for method get_distribution_SunOS of class Distribution
def test_Distribution_get_distribution_SunOS():
    import platform
    from mock import Mock

    module = Mock()
    module.run_command = lambda cmd, **kwargs: (0, platform.uname()[3], None)
    module.get_file_content = lambda filename: b'OpenIndiana Development oi_151a X86\n' \
                                               b'Copyright 2010 Oracle Corporation.  All rights reserved.\n\n' \
                                               b'OpenIndiana Development oi_151a X86 (x86)\n\n' \
                                               b'OpenIndiana Development oi_151a X86\n' \
                                               b'Copyright 2010 Oracle Corporation.  All rights reserved.\n\n'


    distribution = Distribution(module)
    result = distribution.get_distribution_SunOS()

# Generated at 2022-06-20 19:17:11.006355
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    from ansible.module_utils.facts import DistributionFiles
    from ansible.module_utils.facts import Distribution
    # test Debian
    module_mock = Mock()
    dist = Distribution(module_mock)
    dist.get_distribution = Mock(return_value='Debian')
    dist.get_distribution_release = Mock(return_value='9')
    dist.get_distribution_version = Mock(return_value='123')
    files = DistributionFiles(module_mock)
    name = 'Debian'

# Generated at 2022-06-20 19:17:18.709277
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    dist_file_facts = DistributionFiles().parse_distribution_file_Alpine('Alpine', '3.6.0', '/NOTUSED', {})
    assert dist_file_facts['distribution_file_parsed'] is True
    assert dist_file_facts['distribution_file_path'] is '/NOTUSED'
    assert dist_file_facts['distribution'] == 'Alpine'
    assert dist_file_facts['distribution_version'] == '3.6.0'


# Generated at 2022-06-20 19:17:29.634119
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    distro_file = DistributionFiles()
    path = '/etc/os-release'
    path_data = 'Slackware 14.2+\n'
    name = 'Slackware'
    collected_facts = {}
    parsed_dist_file_facts = {}
    parsed_dist_file_facts['distribution'] = 'Slackware'
    parsed_dist_file_facts['distribution_version'] = '14.2'
    assert distro_file.parse_distribution_file_Slackware(name, path_data, path, collected_facts) == \
        (True, parsed_dist_file_facts)



# Generated at 2022-06-20 19:17:32.143694
# Unit test for constructor of class Distribution
def test_Distribution():
    distro = Distribution()
    assert distro is not None


# Generated at 2022-06-20 19:17:39.674775
# Unit test for method get_distribution_facts of class Distribution
def test_Distribution_get_distribution_facts():
    distribution_facts_test = Distribution(module=None)
    distro_facts = distribution_facts_test.get_distribution_facts()
    distro_facts_keys = distribution_facts_test.OS_FAMILY_MAP.keys()
    distro_facts_keys.append('altlinux')
    if distro_facts.get('distribution'):
        assert distro_facts.get('distribution').lower() in distro_facts_keys
    if distro_facts.get('os_family'):
        assert distro_facts.get('os_family').lower() in distro_facts_keys



# Generated at 2022-06-20 19:17:47.916800
# Unit test for method parse_distribution_file_Flatcar of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Flatcar():
    df = DistributionFiles({})
    name = 'CoreOS'
    data = 'GROUP=stable'
    path = 'test/path'
    collected_facts = {}
    result = df.parse_distribution_file_Flatcar(name, data, path, collected_facts)
    assert result[1]['distribution_release'] == 'stable'



# Generated at 2022-06-20 19:18:20.740357
# Unit test for method get_distribution_SMGL of class Distribution
def test_Distribution_get_distribution_SMGL():
    input = Distribution(module = ModuleStub())
    output = input.get_distribution_SMGL()

    expected = {'distribution': 'Source Mage GNU/Linux'}
    assert output == expected


# Generated at 2022-06-20 19:18:30.218559
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    distribution_files = DistributionFiles()

    # Test 1
    # Should return true, true and all the required info
    name = "Alpine"
    data = "3.7.0"
    path = "/etc/alpine-release"
    collected_facts = {"distribution": "NA", "distribution_version": "NA"}

    parsed_dist_file, parsed_dist_file_facts = distribution_files.parse_distribution_file_Alpine(name, data, path, collected_facts)

    if parsed_dist_file is True and parsed_dist_file_facts == {
        'distribution': name,
        'distribution_version': data
    }:
        print("Test 1 PASSED")
    else:
        print("Test 1 FAILED")

    # Test 2
    # Should return true, false and no info

# Generated at 2022-06-20 19:18:33.187879
# Unit test for method get_distribution_Darwin of class Distribution
def test_Distribution_get_distribution_Darwin():
    module = AnsibleModule(argument_spec={})
    # set up test
    # Collect facts
    distribution = Distribution(module)
    distribution.get_distribution_Darwin()



# Generated at 2022-06-20 19:18:46.683620
# Unit test for method parse_distribution_file_Slackware of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Slackware():
    test_facts = {
        'distribution': 'NA',
        'distribution_release': 'NA',
        'lsb': {
            'distcodename': 'NA',
            'distdescription': 'NA',
            'distid': 'NA',
            'distrelease': 'NA',
            'distrib_id': 'NA',
            'majdistrelease': 'NA'
        }
    }
    # Test parsing Slackware 14.2
    test_path = 'tests/unittests/files/etc_slackware-version_14.2'
    test_name = 'Slackware'
    test_data = get_file_content(test_path)
    df = DistributionFiles(None)

# Generated at 2022-06-20 19:18:49.743573
# Unit test for constructor of class Distribution
def test_Distribution():
    m = ModuleStub()

    d = Distribution(m)
    assert isinstance(d, Distribution)



# Generated at 2022-06-20 19:18:52.762364
# Unit test for function get_uname
def test_get_uname():
    assert get_uname('uname', '-v') == 'uname -v'



# Generated at 2022-06-20 19:19:00.065911
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    distro = DistributionFiles({})
    data = """
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=18.06
DISTRIB_REVISION=r7258-5eb055306f
DISTRIB_TARGET=ramips/mt7621
DISTRIB_ARCHITECTURE=mipsel_24kc
DISTRIB_DESCRIPTION="OpenWrt "
DISTRIB_TAINTS=
"""
    name = "OpenWrt"
    path = ""
    # FIXME: there is no collected_facts in this case, which is weird
    collected_facts = {}
    parsed, facts = distro.parse_distribution_file_OpenWrt(name, data, path, collected_facts)
    assert parsed is True

# Generated at 2022-06-20 19:19:09.341678
# Unit test for method get_distribution_FreeBSD of class Distribution
def test_Distribution_get_distribution_FreeBSD():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    distribution = Distribution(module)
    distribution.module.run_command = MagicMock(return_value=[0, 'OpenBSD 6.7-current (GENERIC.MP) #47: Fri Nov 16 14:49:23 MST 2018\ndavid@amd64-builder.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC.MP', ''])
    assert distribution.get_distribution_OpenBSD()['distribution_release'] == 'current'
    module.fail_json = MagicMock(return_value=None)
    distribution.module.run_command = MagicMock(return_value=[1, '', 'error'])

# Generated at 2022-06-20 19:19:17.710623
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # init
    df = DistributionFiles()
    name = 'NA'

# Generated at 2022-06-20 19:19:22.862302
# Unit test for method parse_distribution_file_ClearLinux of class DistributionFiles

# Generated at 2022-06-20 19:19:56.529100
# Unit test for constructor of class DistributionFiles
def test_DistributionFiles():
    dist_files = DistributionFiles()
    # FIXME: write some sort of meaningful test for this one
    dist_files.__init__()


# Generated at 2022-06-20 19:19:59.419018
# Unit test for method get_distribution_DragonFly of class Distribution
def test_Distribution_get_distribution_DragonFly():
    module = MagicMock()
    dist = Distribution(module)
    dist.get_distribution_DragonFly()
    module.run_command.assert_called_once_with('/sbin/sysctl -n kern.version')



# Generated at 2022-06-20 19:20:12.417064
# Unit test for method get_distribution_OpenBSD of class Distribution
def test_Distribution_get_distribution_OpenBSD():
    module = MockModule()
    dist_class = Distribution(module)
    # test match
    module.run_command.return_value = (0, "OpenBSD 5.5-current (GENERIC.MP) #15: Tue Mar  5 16:47:30 MST 2013     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC.MP", "")
    openbsd_facts = dist_class.get_distribution_OpenBSD()
    assert 'distribution_version' in openbsd_facts
    assert openbsd_facts['distribution_version'] == '5.5'
    assert 'distribution_release' in openbsd_facts
    assert openbsd_facts['distribution_release'] == 'current'
    # test no match
   

# Generated at 2022-06-20 19:20:22.452514
# Unit test for method parse_distribution_file_Debian of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Debian():
    # random data for test environment
    # TODO: test with more complete data and/or a loop
    collected_facts = {'distribution_release': 'NA'}
    # debian tests

# Generated at 2022-06-20 19:20:33.666499
# Unit test for method parse_distribution_file_OpenWrt of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_OpenWrt():
    _module = AnsibleModuleMock()
    _name = 'OpenWrt'
    _data = '''
DISTRIB_ID=OpenWrt
DISTRIB_RELEASE=12.09-rc1
DISTRIB_REVISION=r28422
DISTRIB_CODENAME=attitude_adjustment
DISTRIB_TARGET=ar71xx/generic
DISTRIB_DESCRIPTION="OpenWrt Attitude Adjustment 12.09-rc1"
DISTRIB_TAINTS=""
'''

    collected_facts = {}

    d = DistributionFiles(_module, collected_facts)
    r, parsed_facts = d.parse_distribution_file_OpenWrt(_name, _data, '', collected_facts)

    assert r is True
    assert isinstance(parsed_facts, dict)

# Generated at 2022-06-20 19:20:44.583549
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    # set up a DistributionFiles() object
    dist_file = DistributionFiles()

    # get test data
    test_data = get_distfile_data('Alpine')

    # test data
    name = 'Alpine'
    path = test_data['path']
    collected_facts = {}
    test_data['files'][path] = test_data['files'][path].encode()
    out = test_data['files'][path]
    test_data['files'] = {path: out}

    # run test
    out, facts = dist_file.parse_distribution_file_Alpine(name, out, path, collected_facts)
    assert out == True
    assert facts == {"distribution": "Alpine", "distribution_version": "3.5"}
    # run test
    out, facts = dist_

# Generated at 2022-06-20 19:20:47.533570
# Unit test for function get_uname
def test_get_uname():
    out = get_uname('', '-v')
    assert isinstance(out, str)



# Generated at 2022-06-20 19:20:56.371221
# Unit test for method parse_distribution_file_NA of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_NA():
    # Test with empty data
    name = 'NA'
    data = ""
    path = ""
    collected_facts = {"distribution_version": "NA"}
    distro_files = DistributionFiles()
    distro_files._parse_distribution_file_general = MagicMock()
    distro_files.parse_distribution_file_NA(name, data, path, collected_facts)
    distro_files._parse_distribution_file_general.assert_not_called()

    # Test with wrong data
    name = 'NA'
    data = "NAME=wrong_NAME"
    path = ""
    collected_facts = {"distribution_version": "NA"}
    distro_files = DistributionFiles()
    distro_files._parse_distribution_file_general = MagicMock()
    distro_files.parse

# Generated at 2022-06-20 19:21:07.137346
# Unit test for method get_distribution_NetBSD of class Distribution

# Generated at 2022-06-20 19:21:16.806506
# Unit test for method parse_distribution_file_Alpine of class DistributionFiles
def test_DistributionFiles_parse_distribution_file_Alpine():
    dist_file = DistributionFiles()
    # Test with correct data
    name = 'Alpine'
    path = '/etc/alpine-release'
    data = '3.5.2'
    collected_facts = {'distribution_file_path': path, 'distribution_file_variety': name}
    flag, res_facts = dist_file.parse_distribution_file_Alpine(name, data, path, collected_facts)
    assert flag == True, 'There was an error parsing distribution file %s' % name
    assert 'distribution' in res_facts.keys()
    assert 'distribution_version' in res_facts.keys(), 'There are missing mandatory keys in dictionary'
    assert res_facts['distribution'] == 'Alpine', 'Dictionary contains wrong values'
    assert res_facts['distribution_version']