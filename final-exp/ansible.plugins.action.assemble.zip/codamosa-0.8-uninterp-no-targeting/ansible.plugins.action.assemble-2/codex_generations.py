

# Generated at 2022-06-21 01:45:25.508977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # case 1:
    module = ActionModule({}, {}, {}, {}, {})
    module._play_context = PlayContext()
    module._connection = Connection(PlayContext())
    module._task = Play()
    module._task._ds = {}
    module._task._ds['vars'] = {}
    module._task._ds['vars']['ansible_connection'] = 'local'
    module._task._ds['vars']['ansible_python_interpreter'] = '/usr/bin/python'
    module._task._ds['vars']['ansible_shell_type'] = 'bash'
    module._task._ds['vars']['ansible_shell_executable'] = '/bin/sh'

# Generated at 2022-06-21 01:45:29.882921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is to eliminate the pytest warning, no test code goes here
    pass


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 01:45:32.147785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run\n")
    # Declare a test ActionModule instance
    testActionModule = ActionModule()
    # Test ActionModule.run method
    testActionModule.run()

# Generated at 2022-06-21 01:45:33.759393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail
    from ansible.module_utils import basic
    from ansible.module_utils.common.removed import removed_module

    assert False

# Generated at 2022-06-21 01:45:42.876634
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_args = dict(
        src='/fixtures/test.txt',
        dest='/test.txt',
        remote_src=True,
        regexp=None,
        delimiter=", ",
        ignore_hidden=False,
        decrypt=True,
    )
    module_action = ActionModule(
        argument_spec=dict(
            src=dict(required=True),
            dest=dict(required=True),
            remote_src=dict(type='bool'),
            regexp=dict(),
            delimiter=dict(),
            ignore_hidden=dict(type='bool'),
            decrypt=dict(type='bool', default=True),
        ),
        **test_args
    )
    assert module_action is not None
    assert module_action.name == 'assemble'
    assert module_action.module_

# Generated at 2022-06-21 01:45:52.685354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # type, name, value
    opts = [
        ('string', 'name', 'foo'),
        ('string', 'src', 'mock_src'),
        ('string', 'dest', 'mock_dest'),
        ('boolean', 'remote_src', True),
        ('boolean', 'decrypt', True),
    ]

    args = {
        'name': 'foo',
        'src': 'mock_src',
        'dest': 'mock_dest',
        'remote_src': True,
        'decrypt': True,
    }

    task = mock_task(opts, args)
    tmp = ''
    task_vars = None
    task_vars = {'ansible_connection': 'mock'}

# Generated at 2022-06-21 01:46:00.838131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule. """
    # Test input data
    test_data = {
        'src': 'src',
        'dest': 'dest',
        'delimiter': 'delimiter',
        'remote_src': 'yes',
        'regexp': 'regexp',
        'follow': False,
        'ignore_hidden': False,
        'decrypt': True
    }
    # Create an instance of class ActionModule.
    my_test_obj = ActionModule()
    # This is what we are testing.
    my_test_obj.run(tmp=None, task_vars=None)


# Generated at 2022-06-21 01:46:11.110248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import getpass
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.text_utils import get_binary_data
    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.assemble import ActionModule
    from ansible.plugins.action.copy import ActionModule as ActionModuleCopy
    from ansible.plugins.action.file import ActionModule as ActionModuleFile
    from ansible.utils.hashing import checksum_s

    # Mock out os.path.isfile() to return true because we filter out directories
   

# Generated at 2022-06-21 01:46:11.630344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:46:18.611432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Check if the method run can generate the same result as given by the reference"""
    #mock the class variables
    ActionModule.REQUIRED_ADDITIONAL_ARGS = ['dest', 'src']
    ActionModule.REQUIRED_CONFIG_ARGS = ['transfer_files', 'value']
    action_module = ActionModule()
    action_module._task_vars = {}
    action_module._task_vars = {"src": "src", "dest": "dest", "delimiter": "delimiter", "regexp": "regexp", "remote_src": "remote_src", "follow": False, "ignore_hidden": False, "decrypt": True, "action": "assemble"}
    action_module.get_bin_path = lambda: ""
    action_module.run()
    assert True

# Generated at 2022-06-21 01:46:32.254063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.__doc__
    assert am.run.__doc__

# Generated at 2022-06-21 01:46:37.358109
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create instance of class ActionModule without any required arguments
    action_module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    task_vars = dict()
    tmp = None
    action_module.run(tmp, task_vars)

# Generated at 2022-06-21 01:46:38.888431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 01:46:50.310380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    module_name = "ansible.modules."


# Generated at 2022-06-21 01:47:02.481411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play_context
    import ansible.utils.connection
    import ansible.plugins.action
    import ansible.module_utils.actions.assemble
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils._text
    import ansible.errors
    import ansible.utils.hashing
    import os
    import shutil
    import tempfile
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.six import b

    # Monkey patch Display class to make it usable for other methods.
    Display.verbosity = 2
    Display.display(u'msg', color=u'blue')
    Display.debug(u'msg')

# Generated at 2022-06-21 01:47:02.976572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:47:04.277669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None  # to check that ansible.plugins.action.assemble is imported correctly

# Generated at 2022-06-21 01:47:06.180483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 01:47:08.529914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action

# Generated at 2022-06-21 01:47:14.650037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config = dict(
        DEFAULT_ROLES_PATH=['roles', 'roles_path'],
    )
    fixture_loader = FixtureLoader(config=config)
    src_path = 'fixtures/files/assemble'
    config = dict(
        ACTION_DEFAULT_PARAM_FILE='fixtures/params.ini',
        ACTION_DEFAULT_PARAMS=dict(),
    )
    fixture_action = ActionModule(
        task=dict(args=dict(src=src_path, dest='/etc/test', remote_src=False)),
        play_context=PlayContext(config=config),
        connection=Connection(config=config),
        loader=fixture_loader)
    result = fixture_action.run(task_vars={})
    assert "ansible_facts" in result

# Generated at 2022-06-21 01:47:45.010974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=no-member
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection import DummyConnection
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    from ansible.module_utils._text import to_bytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    module_args = dict()
    module_args['remote_src'] = 'yes'
    module_args['path'] = '/tmp/foo'

    inventory = InventoryManager( [], [])
    inventory.hosts['localhost'] = Host('localhost')
   

# Generated at 2022-06-21 01:47:53.430831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    task = Task()

    am = ActionModule(task, play_context, variable_manager, loader)
    
    assert isinstance(am, ActionModule)
    assert am.TRANSFERS_FILES == True
    assert am._supports_check_mode == False
    assert isinstance(am._connection, AnsibleAction)
    assert isinstance

# Generated at 2022-06-21 01:48:00.860447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    ansible.plugins.action.assemble run() Unit Test
    '''

    # Source directory
    src = '/tmp/test_src'
    os.mkdir(src)
    os.mkdir(os.path.join(src, '.hidden'))
    with open(os.path.join(src, 'frag1.txt'), 'w') as fh:
        fh.write('frag1')
    with open(os.path.join(src, 'frag2.txt'), 'w') as fh:
        fh.write('frag2')
    with open(os.path.join(src, '.hidden', 'frag3.txt'), 'w') as fh:
        fh.write('frag3')

    # Expected result

# Generated at 2022-06-21 01:48:04.432516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    original_ActionModule = ActionModule
    ActionModule.__module__ = 'ansible.plugins.action'
    action_module_object = ActionModule()

# Generated at 2022-06-21 01:48:05.223123
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: implement tests for method run of class ActionModule
    assert False

# Generated at 2022-06-21 01:48:12.314474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check when no params
    obj = ActionModule(None)
    assert obj._supports_check_mode == False

    # Check with params
    mock_task = {'args': {}}
    obj = ActionModule(mock_task)
    assert obj._supports_check_mode == False

# Generated at 2022-06-21 01:48:13.213318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()

# Generated at 2022-06-21 01:48:22.999172
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest
    import unittest.mock as mock
    from ansible.errors import AnsibleError

    mock_task_vars = {'foo': 'bar'}

    mock_src = '/src/dir'
    mock_dest = '/dest/file'
    mock_remote_src = 'no'
    mock_decrypt = True
    mock_regexp = None
    mock_follow = False

    mock_tmp_path = '/mock_tmp'
    mock_path = '/mock_dir/mock_file'

    class ModuleArgs(object):
        def __init__(self, **kwargs):
            for (k,v) in kwargs.items():
                setattr(self, k, v)



# Generated at 2022-06-21 01:48:30.717322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test fixture: a fake module that we can use as a mock
    # for testing the 'run' method of our ActionModule.
    class FakeModule:
        # Attribute 'args' is required for the mock.
        args = {}
        # Attribute 'args' is required for the mock.
        _task = FakeModule()

    # Create a test fixture: a task with a fake module
    fake_task = FakeModule()
    fake_task.args = {}
    # Create a test fixture: an action module with a fake task
    fake_action = ActionModule(fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Note: 'run' should throw an exception (error) if parameter 'src' is not provided.

# Generated at 2022-06-21 01:48:40.266631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.compat.syslog
    ansible.compat.syslog.openlog = lambda facility, option, pid: None
    import ansible.plugins.action
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Create a mock for the ansible.plugins.action.ActionBase object
    actionbase_mock = mock.create_autospec(ansible.plugins.action.ActionBase)
    actionbase_mock._supports_check_mode = False
    actionbase_mock._supports_async = False
    actionbase_mock.task_vars = dict()
    actionbase_mock._remove_tmp_path = lambda self, tmp: None
    # The following method is used to "sanitize" the host specified in the action


# Generated at 2022-06-21 01:49:26.246640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:49:27.467984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:49:39.807734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test that the method run with a fake test_connection_class.fake_connection_class giving the expected result.
    class fake_connection_class():
        def __init__(self):
            pass
        def run(self):
            pass
    class fake_task():
        def __init__(self):
            pass
        def run(self):
            pass
    class ActionModuleTest(ActionModule):
        @classmethod
        def _execute_module(cls, module_name=None, module_args=None, task_vars=dict(), tmp=None):
            return {}
        @classmethod
        def _execute_remote_stat(cls, module_name=None, module_args=None, task_vars=dict(), tmp=None):
            return {}

# Generated at 2022-06-21 01:49:44.753608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    # test_actionmodule_run_simple
    # Test if the run method of ActionModule class successfully returns the result of a module execution when everything
    # is fine.
    #
    # Test if the run method of ActionModule class successfully executes an assembly task in check mode.
    #
    # Test if the run method of ActionModule class successfully executes a task in check mode when regexp argument is used
    #
    # Test if the run method of ActionModule class successfully executes a task in check mode when regexp argument is used
    #
    # Test if the run method of ActionModule class successfully executes a task in append mode.
    #
    # Test if the run method of ActionModule class successfully executes a task in append mode when regexp argument is used
    #
    '''

# Generated at 2022-06-21 01:49:53.264015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(action_plugin_config={}, task_config=dict(file='file', path='path'), task_vars_config=dict(vars='vars'))
    assert am._task.action == 'file'
    assert am._task.args == {}
    assert am._task.delegate_to is None
    assert am._task.delegate_facts is True
    assert am._task.delegate_to is None
    assert am._task.loop is None
    assert am._task.loop_args is None
    assert am._task.loop_control is None
    assert am._task.name == 'path'
    assert am._task.notify is None
    assert am._task.when is None
    assert am._task.environment == {}
    assert am._task.environment_append == {}
    assert am._task

# Generated at 2022-06-21 01:50:01.826128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None)
    try:
        result = action_module.run(None, None)
    except AnsibleError as e:
        result = e
    assert type(result) is AnsibleActionFail
    assert result.result['msg'] == 'src and dest are required'

    task_args = {'src': 'files', 'dest': 'test/test'}
    try:
        result = action_module.run(None, task_args)
    except AnsibleError as e:
        result = e
    assert type(result) is AnsibleActionFail
    assert result.result['msg'] == 'Source (files) is not a directory'

    task_args = {'src': 'files', 'dest': 'test/test'}

# Generated at 2022-06-21 01:50:02.697914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:50:05.645064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    action = action_loader.get('assemble', {})
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 01:50:08.382481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ function to test constructor or class ActionModule """
    module = ActionModule()
    assert len(module.TRANSFERS_FILES) > 0
    assert len(module.no_log_values) > 0


# Generated at 2022-06-21 01:50:10.174408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.assemble
    am = ansible.plugins.action.assemble.ActionModule(None, dict(), True, None, None)

# Generated at 2022-06-21 01:52:14.772002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock settings
    test_task = dict(
        action=dict(
            module='assemble',
            args=dict(
                src='./test_data',
                dest='/tmp/test_assemble.out',
                regexp='\w+.txt',
            )
        )
    )
    test_task_vars = dict()
    test_tmp = None

    # Create Mock object
    actionModule = ActionModule()

    # Inject mocks
    actionModule._task = test_task
    actionModule._connection = None
    actionModule._loader = None
    actionModule._templar = None
    actionModule._shared_loader_obj = None

    # Do test
    result = actionModule.run(test_tmp, test_task_vars)

    # Check if the result is correct

# Generated at 2022-06-21 01:52:16.071208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-21 01:52:16.521276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actions = ActionModule()

# Generated at 2022-06-21 01:52:27.684535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    mock_attrs = ('_connection', '_task', '_loader', '_templar', '_shared_loader_obj',)
    with pytest.raises(AnsibleActionFail):
        instance = ActionModule()
        for attr in mock_attrs:
            setattr(instance, attr, 'test')
        instance.run(tmp='/tmp/', task_vars='task_vars')

    mock_attrs = ('_connection', '_task', '_loader', '_templar', '_shared_loader_obj',)
    with pytest.raises(AnsibleActionFail):
        instance = ActionModule()
        for attr in mock_attrs:
            setattr(instance, attr, 'test')

# Generated at 2022-06-21 01:52:33.403939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase
    mod = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert isinstance(mod, ActionBase)

# Generated at 2022-06-21 01:52:43.235425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mocks for 'ansible.plugins.action.ActionBase' class
    class ActionBase_mock(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return {'actionbase_run': 'dummy'}

        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None):
            return {'actionbase__execute_module': 'dummy'}

        def _execute_remote_stat(self, path, all_vars=None, follow=None):
            return {'checksum': 'dummy'}

        def _get_diff_data(self, dest, path, task_vars=None):
            return 'dummy'


# Generated at 2022-06-21 01:52:55.718912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()
    host = Host(name=u'test host')
    group = Group(name=u'test group')

# Generated at 2022-06-21 01:52:59.381162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None,
                        loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:53:00.798542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print(module)

# Generated at 2022-06-21 01:53:07.204570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    action_module = ActionModule(None, None)
    action_module._task = MagicMock()
    action_module._play_context = MagicMock()
    action_module._execute_remote_stat = MagicMock()
    action_module._execute_remote_stat.return_value = {'checksum': 'ABCD1234'}
    action_module._connection = MagicMock()
    action_module._connection._shell = MagicMock()
    action_module._connection._shell.tmpdir = MagicMock()
    action_module._remove_tmp_path = MagicMock()
    action_module._transfer_file = MagicMock()
    action_module._get_diff_data = MagicMock()
    action_module._fixup_perms2 = MagicMock()
    action_module._remote