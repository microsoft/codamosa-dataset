

# Generated at 2022-06-21 01:45:20.702774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create test object.
    # Initialization will be tested in action/__init__
    action_module = ActionModule(avd_task=None, avd_connection=None, avd_play_context=None, avd_loader=None, avd_templar=None, avd_shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 01:45:29.993256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule.py: Unit test for constructor of class ActionModule. '''
    from ansible.runner.connection_plugins.local import Connection
    from ansible.runner.task_plugins.action import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    # Create a basic task
    task = Task()
    task.action = 'assemble'
    task.args = dict(src='/tmp/', dest='/tmp/dest')
    # Create a connection
    connection = Connection()
    # Create a variable_manager
    variables = VariableManager()
    inventory = InventoryManager()
    # Create an ActionModule

# Generated at 2022-06-21 01:45:37.204702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import mock
    except:
        import unittest.mock as mock
    action_module = ActionModule(mock.MagicMock(), mock.MagicMock(), mock.MagicMock())
    action_module.TRANSFERS_FILES = True
    # Set args
    args = {
        'dest': 'test_dest',
        'regexp': None,
        'delimiter': None,
        'remote_src': 'yes',
        'ignore_hidden': False,
        'decrypt': True
    }
    action_module._task.args = args
    # Set src and dest path
    test_dir = 'test'
    src_dir = test_dir + '/_tmp'
    dest_path = test_dir + '/_tmp/test_dest'
    # Make dir
   

# Generated at 2022-06-21 01:45:41.083086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=1, connection=1, play_context=1, loader=1, templar=1, shared_loader_obj=1)
    assert mod is not None

# Generated at 2022-06-21 01:45:51.457753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    ### Unit test for constructor of class ActionModule ###
    """
    print("\n---Unit test for constructor of class ActionModule---")
    tf = tempfile.NamedTemporaryFile()
    tmp_path = tf.name
    tf.close()

    loader = DictDataLoader({
        "defaults/main.yml": "",
        "tasks/main.yml": ("""
            - assemble:
                src: "path/to/dir"
                dest: "/path/to/dest"
                remote_src: "no"
                regexp: "regexp"
                delimiter: "delimiter"
                ignore_hidden: "no"
                decrypt: "yes"
            """),
    })

# Generated at 2022-06-21 01:45:56.692289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(tmp='test_tmp')
    assert a.TRANSFERS_FILES == True
    assert a._supports_check_mode == False

    # test the private function _assemble_from_fragments()
    tmpfd, temp_path = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    assert temp_path
    assert os.path.isfile(temp_path)
    os.remove(temp_path)

    # test the public function run()
    b = ActionModule(tmp='test_tmp')
    results = b.run(task_vars=None)
    assert results['failed'] == True

# Generated at 2022-06-21 01:45:59.284695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    # actionmodule = ActionModule()
    pass

# Generated at 2022-06-21 01:46:08.411882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.utils.hashing import checksum_s

    tmpdir = tempfile.mkdtemp()
    src = tempfile.mkdtemp(dir=tmpdir)
    dest = tempfile.mkdtemp(dir=tmpdir)

    for i in ['a', 'b', 'c']:
        with open(os.path.join(src, 'frag_%s' % i), 'w') as f:
            f.write('test_%s' % i)

    action = ActionModule(
        task=dict(
            args={'src': src, 'dest': dest, 'regexp': '^frag_[b]'}
        )
    )
    res = action.run()
    assert checksum_s(os.path.join(src, 'frag_b'))

# Generated at 2022-06-21 01:46:16.840327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:46:23.741704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make the testing class
    class MyClass(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return dict(changed=True)

    # testing
    myobj = MyClass()
    assert myobj.run() == dict(changed=True)



# Generated at 2022-06-21 01:46:41.646037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('', {}, {}, False, True, '', [], [], [], [], {})
    src = 'src'
    dest = 'dest'
    delimiter = 'delimiter'
    remote_src = False
    regexp = 'regexp'
    result = module.run(tmp=None, task_vars=None)
    args = {'actions': 'actions', '_ansible_check_mode': True, '_ansible_diff': True, '_ansible_no_log': False, '_ansible_verbosity': 4, '_ansible_version': 'version', '_ansible_version_info': 'version_info'}

# Generated at 2022-06-21 01:46:46.745539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.TRANSFERS_FILES is True

# Generated at 2022-06-21 01:46:49.109084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 01:47:01.904147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    task = Task()
    task._role = None
    task.args = {
        'src': 'file',
        'dest': '/path/to/dest',
        'regexp': '^fragment_.*',
        'delimiter': '\n',
        'ignore_hidden': False,
        'decrypt': False,
    }
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    test_action = ActionModule(task, variable_manager, loader=None, templar=None, shared_loader_obj=None)
    assert test_action._task == task


# Generated at 2022-06-21 01:47:04.580655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''test for non-legacy path'''
    tmp = None
    task_vars = None
    am = ActionModule(tmp, task_vars)
    assert am.run() == {'failed': True, 'msg': 'src and dest are required'}

# Generated at 2022-06-21 01:47:05.438951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:47:06.254980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:47:12.666666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class Options(object):
        connection = 'smart'
        module_path = '/path/to/ansible/mod'
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        private_key_file = '/path/to/ssh_key'

    # mock class object

# Generated at 2022-06-21 01:47:18.816020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, dict(src=None, dest=None, delimiter=None, remote_src='yes', regexp=None, follow=False, ignore_hidden=False), False, False)
    assert action is not None, "action is none"
    assert action._supports_check_mode is False, "action._supports_check_mode should be false"


# Generated at 2022-06-21 01:47:29.888987
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test when ActionModule is constructed
    action_module = ActionModule(None, None, None)
    assert action_module != None

    # Test when ActionModule is constructed with task action
    action_module = ActionModule(None, {'action': 'set_fact'}, None)
    assert action_module != None

    # Test when ActionModule is constructed with task args
    action_module = ActionModule(None, None, {'test': 'test_value'})
    assert action_module != None

    # Test when ActionModule is constructed with task action and args
    action_module = ActionModule(None, {'action': 'set_fact'}, {'test': 'test_value'})
    assert action_module != None

# Generated at 2022-06-21 01:47:56.933809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    host = 'localhost'
    loader = DataLoader()
    host = InventoryManager(loader=loader, sources='localhost,').get_host(host)
    task = Task()
    task_vars = dict(foo='bar')
    play_context = PlayContext()
    task_result = TaskResult(host, task, task_vars, play_context)
    task_result._result = dict(foo='bar')
    variable_manager = VariableManager()
    variable_manager._fact

# Generated at 2022-06-21 01:47:58.830723
# Unit test for constructor of class ActionModule
def test_ActionModule():
   am = ActionModule(dict())
   print(am)


# Generated at 2022-06-21 01:48:09.178235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an ActionModule object
    actMod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # create a set of valid input
    src = 'path/to/dir'
    dest = 'path/to/file'
    delimiter = '//'
    remote_src = 'yes'
    regexp = 'regexp'
    follow = 'yes'
    ignore_hidden = 'no'
    decrypt = 'yes'
    tmp = None
    task_vars = None

    # run the run() method using the valid input
    result = actMod.run(tmp, task_vars)

    # assert the expected result
    assert result is not None

# Generated at 2022-06-21 01:48:20.227626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._supports_check_mode = False

    class args:
        src = None
        dest = None
        delimiter = None
        remote_src = 'yes'
        regexp = None
        follow = False
    mod._task.args = args()
    mod._task.args.src = None
    mod._task.args.dest = None
    mod._execute_module = lambda m, t=None: {}
    mod._find_needle = lambda p, n: None
    mod._remote_expand_user = lambda n: 'dest'
    mod._execute_remote_stat = lambda d, t=None, f=False: {}
    mod._transfer_file = lambda p1, p2: 'src'
    mod._fixup_perms2 = lambda p: None
    mod._remove

# Generated at 2022-06-21 01:48:29.982989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.utils.path import unfrackpath
    from ansible.errors import AnsibleAction
    from ansible.plugins.action import ActionModule
    from ansible.utils.hashing import checksum_s
    host = 'localhost'
    tmp_path = os.path.expanduser(os.path.join('~', '.ansible', 'tmp'))
    # Create a test directory, containing a file and a sub-directory containing another file
    test_dir, test_file_name_1, test_file_name_2 = 'dir1', 'file1', 'file2'
    test_dir_path = unfrackpath(tmp_path + '/' + test_dir, follow=False)

# Generated at 2022-06-21 01:48:39.996502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    # Arrange
    args = dict(src='src', dest='dest', delimiter='delimiter', regexp='regexp', follow='follow', ignore_hidden='ignore_hidden', decrypt='decrypt')
    path = 'test-path'
    task_vars = 'test-task-vars'
    temp_module_class = 'temp-module-class'
    temp_loaded_class = 'temp-loaded-class'
    temp_plugin_class = 'temp-plugin-class'
    temp_action_class = 'temp-action-class'
    # Act

# Generated at 2022-06-21 01:48:47.823597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct class instance without parameters
    my_action_module = ActionModule()
    # check attribute "supports_check_mode"
    assert my_action_module._supports_check_mode == False
    # check attribute "supports_async"
    assert my_action_module._supports_async == False
    # check attribute "supports_subset_of_hosts"
    assert my_action_module._supports_subset_of_hosts == True
    # check attribute "deprecated_action_names"
    assert my_action_module._deprecated_action_names == None

# Generated at 2022-06-21 01:48:51.398525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no param
    obj = ActionModule( task = None )
    assert obj is not None

# vim: set et ts=4 sw=4

# Generated at 2022-06-21 01:48:53.299235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# vim: filetype=python

# Generated at 2022-06-21 01:49:00.441297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible.errors
    import ansible.plugins.action
    import ansible.utils.hashing
    import ansible.utils.unicode
    import os
    import shutil
    import tempfile

    class ActionModule_run_TmpClass1(ansible.plugins.action.ActionBase):
        def run(self, tmp=None, task_vars=None):
            pass

    class ActionModule_run_TmpClass2(ansible.plugins.action.ActionBase):
        def __init__(self):
            self._supports_check_mode = False

    class ActionModule_run_TmpClass3(ActionModule_run_TmpClass2):
        def run(self, tmp=None, task_vars=None):
            self._supports_check_mode = True


# Generated at 2022-06-21 01:49:40.792647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 01:49:51.431704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create and initialize mocks
    mock_self = MockActionModule()
    mock_self._execute_module = Mock(return_value=dict())
    mock_self._execute_remote_stat = Mock(return_value=dict(checksum='badf00d'))
    mock_self._fixup_perms2 = Mock(return_value=True)
    mock_self._get_diff_data = Mock(return_value=MockDiff())
    mock_self._loader = Mock(get_real_file=Mock(return_value=None))
    mock_self._remote_expand_user = Mock(return_value='none')
    mock_self._remove_tmp_path = Mock(return_value=True)
    mock_self._transfer_file = Mock(return_value='/tmp/src')
    mock_self

# Generated at 2022-06-21 01:49:52.130701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-21 01:49:54.082071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a
    assert bool(a)

# Generated at 2022-06-21 01:49:55.526214
# Unit test for constructor of class ActionModule
def test_ActionModule():
   x = ActionModule()
   return True

# Generated at 2022-06-21 01:50:00.513615
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up
    task_vars = dict()
    tmp = 'tmp'
    src = '/tmp/src'
    dest = 'src'
    follow = False
    remote_src = 'yes'
    regexp = None
    delimiter = None
    ignore_hidden = False
    decrypt = True

    my_action_module = ActionModule(
        task=dict(args=dict(dest=dest)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    my_action_module.connection = DummyConnect()

    # run

# Generated at 2022-06-21 01:50:05.441044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    task = Task()
    play_context = PlayContext()
    action_module = ActionModule(task, play_context)

# Generated at 2022-06-21 01:50:06.165497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 01:50:14.852458
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock for class ActionBase
    class ActionBaseMock(object):
        # Mock of method _execute_module of class ActionBase
        def _execute_module(self, *args, **kwargs):
            return {'invocation':{'module_name': 'ansible.legacy.copy'}}

        # Mock of method _execute_module of class ActionBase
        def _transfer_file(self, *args, **kwargs):
            return {'invocation':{'module_name': 'ansible.legacy.copy'}}

        # Mock of method run of class ActionBase
        def run(self, tmp, task_vars):
            return {'invocation':{'module_name': 'ansible.legacy.copy'}}

    # Create a mock for class ActionModule

# Generated at 2022-06-21 01:50:16.763683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    assert len(ActionModule.__bases__) == 1

# Generated at 2022-06-21 01:52:17.271376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert C.DEFAULT_LOCAL_TMP
    assert os.path.isdir(C.DEFAULT_LOCAL_TMP)
    assert os.access(C.DEFAULT_LOCAL_TMP, os.W_OK)
    assert os.access(C.DEFAULT_LOCAL_TMP, os.R_OK)
    assert os.access(C.DEFAULT_LOCAL_TMP, os.X_OK)
    assert C.DEFAULT_REMOTE_TMP
    assert os.path.isdir(C.DEFAULT_REMOTE_TMP)
    assert os.access(C.DEFAULT_REMOTE_TMP, os.W_OK)
    assert os.access(C.DEFAULT_REMOTE_TMP, os.R_OK)

# Generated at 2022-06-21 01:52:26.692042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule(
        task=dict(action=dict(module_name="test.internal")),
        connection=dict(host="localhost"),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert test_action.task == {"action": {"module_name": "test.internal"}}
    assert test_action.connection == {"host": "localhost"}
    assert test_action.play_context == {}
    assert test_action.loader == {}
    assert test_action.templar == {}
    assert test_action.shared_loader_obj == {}

# Generated at 2022-06-21 01:52:28.273162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t=ActionModule()


# Generated at 2022-06-21 01:52:31.588124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Invalid action module
    # Should throw an exception
    try:
        ActionModule()
    except Exception as e:
        pass


# Generated at 2022-06-21 01:52:34.053645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # TODO: test case for ActionModule.run()
    pass

# Generated at 2022-06-21 01:52:43.645754
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:52:44.897536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:52:56.317132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.plugins import module_finder

    loader = DataLoader()
    module_finder.add_directory(C.DEFAULT_MODULE_PATH)

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)

    host = Host(name='127.0.0.1', port=22)

# Generated at 2022-06-21 01:52:57.681807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    raise RuntimeError("Not implemented")



# Generated at 2022-06-21 01:52:58.760739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_run()

if __name__ == '__main__':
    import doctest
    doctest.testmod()