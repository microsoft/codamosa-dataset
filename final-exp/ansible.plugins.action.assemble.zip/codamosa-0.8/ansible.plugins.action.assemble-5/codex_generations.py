

# Generated at 2022-06-11 11:10:48.206140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 11:10:50.376686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module != None

# Generated at 2022-06-11 11:10:51.409659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Covered by other tests
    pass

# Generated at 2022-06-11 11:10:55.318509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            args=dict(
                src='foo',
                dest='/tmp/bar'
            )
        )
    )
    assert am
    assert am._task.args['src'] == 'foo'
    assert am._task.args['dest'] == '/tmp/bar'

# Generated at 2022-06-11 11:11:07.021006
# Unit test for constructor of class ActionModule
def test_ActionModule():

    tmp = tempfile.mkdtemp(dir=C.DEFAULT_LOCAL_TMP)
    os.chdir(tmp)

    # TODO: need to create a mock task, and a mock inventory
    #       and then run the module..
    # TODO: there are more unit tests in modules/action/__init__.py
    #       .. but they seem to be broken right now..
    #       need to go in, and fix that..
    # TODO: there are more unit tests in ansible.legacy.copy ..
    #       we can copy those tests for the assemble module as well.
    #       .. but that won't be an easy thing to do..

    a = ActionModule()

    # TODO: how to run the action Base class .. without any remote things
    # a.run()

# Generated at 2022-06-11 11:11:10.684625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import collections

    assert hasattr(ActionModule, 'run')

    # Test if the constructor was called
    ModuleRunner = collections.namedtuple('ModuleRunner', ('action', 'run'))
    ActionModule.run(ModuleRunner, None)

# Generated at 2022-06-11 11:11:14.906648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Tests for action plugin
    """

    # Importing the module
    from ansible.plugins.action import ActionModule
    # Create an instance of the class
    am = ActionModule(
        task=dict(action=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    am.run()



# Generated at 2022-06-11 11:11:19.182131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
        final_loader_obj=None
    )

# Generated at 2022-06-11 11:11:27.735954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {
      'ANSIBLE_MODULE_ARGS': {
        'dest': 'test/path/to/file',
        'src': 'test/path/to/src',
        'remote_src': 'true'
      },
      'ANSIBLE_KEEP_REMOTE_FILES': '0',
      'ANSIBLE_REMOTE_TEMP': '/var/tmp',
      'TEST_DIR': 'test/1',
      'TEST_FILE': 'test/file'
    }
    a = ActionModule(d)
    assert a.action

# Generated at 2022-06-11 11:11:30.138499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)._assemble_from_fragments('/home/', '', None, True) == None

# Generated at 2022-06-11 11:11:47.550257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Constructor of class ActionModule should not result in exception."""
    # pylint: disable=redefined-outer-name
    try:
        ActionModule(task=dict(action=dict(module_name='assemble'), args=dict(src='')))
    except:
        error_message = "Construction of class ActionModule raised exception"
        assert False, error_message

# Generated at 2022-06-11 11:11:53.820392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(
        src = '/home/jkroon/test_src',
        dest = '/home/jkroon/test_dest',
        delimiter = ';',
        remote_src = True,
        regexp = 'test_*.txt',
        follow = False,
        ignore_hidden = True,
        decrypt = False
    )

    ob = ActionModule({'task' : "test"}, task_args)
    ob.run()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 11:12:00.300559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Create an instance of this class, passing in needed and unused parameters
    #
    act_mod = ActionModule({}, {}, {}, {})
    args = { 'src': '/tmp/src', 'dest': '/tmp/dest' }
    task_vars = {}
    #
    # Call the run method and check the results
    #
    results = act_mod.run(None, task_vars)
    assert 'failed' in results

# Generated at 2022-06-11 11:12:02.169348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    name = 'action_module_new'
    action = ActionModule(name)
    assert(action.name() == name)

# Generated at 2022-06-11 11:12:13.400195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    import shutil
    from tempfile import mkdtemp

    def setup_test_dir(test_dir, num_files, delimiter):
        for i in range(num_files):
            test_file = os.path.join(test_dir, "test_file" + str(i))
            with open(test_file, 'w') as f:
                f.write('this is test file {}'.format(i))
                if delimiter:
                    f.write(delimiter)

    def test_run_basic(mocker):
        test_dir = mkdtemp()
        setup_test_dir(test_dir, 5, None)
        dest = '/foo/bar'


# Generated at 2022-06-11 11:12:14.086172
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action = ActionModule()

# Generated at 2022-06-11 11:12:15.497294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Unit test for constructor of class ActionModule
    assert True

# Generated at 2022-06-11 11:12:24.934619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.copy import ActionModule as copy_ActionModule

    module_args = dict(
        src='/tmp/test_data/assemble/src',
        dest='/tmp/test_data/assemble/dest/foo',
        remote_src=False,
        regexp='(foo|bar)',
        delimiter='THIS',
    )
    a = copy_ActionModule(task=dict(args=module_args), connection=None, play_context={}, loader=None, templar=None, shared_loader_obj=None)

    # arrange
    def execute_remote_stat(*args, **kwargs):
        class Object(object):
            pass
        obj = Object()
        obj

# Generated at 2022-06-11 11:12:25.533247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:12:26.826680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None,None, None)
    assert a is not None

# Generated at 2022-06-11 11:12:59.163615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object for the AnsibleOptions class
    from ansible.utils.vars import AnsibleOptions
    options = AnsibleOptions('config_file')

    # Create a mock object for the AnsibleModule class
    from ansible.modules.copy import AnsibleModule
    module = AnsibleModule.__new__(AnsibleModule)
    module.params = {'foo': 'bar'}
    module.connection = None
    module.check_mode = False

    # Create a mock object for the AnsibleAction class
    from ansible.plugins.action import ActionBase
    action = ActionBase.__new__(ActionBase)
    action._supports_check_mode = False
    action.connection = None
    action.task = None
    action.play_context = None
    action.loader = None
    action._shared_loader

# Generated at 2022-06-11 11:13:00.414358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return {'msg': 'Test is not yet implemented'}

# Generated at 2022-06-11 11:13:10.637718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.utils.vars
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible import constants as C

    class Playbook(object):

        def __init__(self):
            self._entries = {}
            self._basedir = '.'

        def get_basedir(self):
            return self._basedir

        def set_basedir(self, basedir):
            self._basedir = basedir

        def set_variable_manager(self, variable_manager):
            self._variable_manager = variable_manager

        def get_variable_manager(self):
            return self._variable_manager


# Generated at 2022-06-11 11:13:21.285151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader, module_loader

    module_loader.add_directory('./test/support/action_test')
    connection_loader.add_directory('./test/support/action_test')

    mock_task = mock.Mock()
    mock_task.action = 'action_test.action_test'
    mock_task._role = None

# Generated at 2022-06-11 11:13:21.878211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:13:26.137348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    a = ActionModule(dict(one = 1), [], 'test', Task(), VariableManager(), '/tmp', False)
    assert a._supports_check_mode is True

# Generated at 2022-06-11 11:13:27.598685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule('test_queue')
    assert a._queue == 'test_queue'

# Generated at 2022-06-11 11:13:36.982533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config_path = "./test_data/assemble.yaml"
    remote_user = "vagrant"
    remote_port = 2222
    src = config_path
    dest = "./test_data/assemble.txt"
    delimiter = None
    remote_src = "yes"
    regexp = None
    follow = False
    ignore_hidden = False
    decrypt = True
    args = {'src': src, 'dest': dest, 'delimiter': delimiter, 'remote_src': remote_src, 'regexp': regexp,
            'follow': follow, 'ignore_hidden': ignore_hidden, 'decrypt': decrypt}

# Generated at 2022-06-11 11:13:46.988607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = dict()
    a['src'] = 'test'
    a['dest'] = 'test'
    a['delimiter'] = 'test'
    a['regexp'] = 'test'
    a['remote_src'] = 'test'
    a['ignore_hidden'] = 'test'
    a['encrypt'] = 'test'
    a['decrypt'] = 'test'
    a['follow'] = 'test'

    task = dict()
    task['args'] = a
    task['action'] = ['test']

    action = ActionModule(task, dict(), dict())
    assert isinstance(action.run(dict()), dict)


# Generated at 2022-06-11 11:13:56.412001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    playbook_context = PlayContext()
    playbook_context._log_vars = False
    mock_executor = TaskExecutor(playbook_context=playbook_context)
    mock_executor._result = TaskResult(host=None, task=None, return_data=dict(invocation=dict(module_args=dict()),
                                                                              _ansible_no_log=False,
                                                                              _ansible_verbose_always=False))
    mock_executor._tqm = object

# Generated at 2022-06-11 11:14:40.016587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _ = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)


# Generated at 2022-06-11 11:14:43.603565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    task = Task()
    action = ActionModule(task, dict(src=1, dest=2, regexp=3))
    assert action.regexp == 3


# Generated at 2022-06-11 11:14:47.130289
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert issubclass(ActionModule, ActionBase)

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action.TRANSFERS_FILES is True

    assert action._supports_check_mode is False

# Generated at 2022-06-11 11:14:48.021103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is ActionBase

# Generated at 2022-06-11 11:14:58.496813
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:15:00.712001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__
    assert 'action' == ActionModule.__module__



# Generated at 2022-06-11 11:15:10.744200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        args = dict(
            src = 'src',
            dest = 'dest',
            delimiter = 'delimiter',
            remote_src = 'remote_src',
            regexp = 'regexp',
            follow = True,
            ignore_hidden = True
        )
    )
    action = ActionModule(task=task)

    assert action._task.args.get('src', None) is not None
    assert action._task.args.get('dest', None) is not None
    assert action._task.args.get('delimiter', None) is not None
    assert action._task.args.get('remote_src', 'yes') is not None
    assert action._task.args.get('regexp', None) is not None

# Generated at 2022-06-11 11:15:16.581364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.plugins.action import ActionModule

    # Init an ActionModule instance
    am = ActionModule(None)

    # Test
    test_dict = dict(
        src=os.getcwd() + '/tests/fixtures/test_assemble',
        dest=os.getcwd() + '/tests/fixtures/test_assemble_temp_file')
    am.run(task_vars={}, tmp=None)

# Generated at 2022-06-11 11:15:26.710057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule(
        task=dict(
            args=dict(
                src='test src',
                dest='test dest',
                delimiter='test delimiter',
                remote_src='test remote_src',
                regexp='test regexp',
                follow='test follow',
                ignore_hidden='test ignore_hidden',
                decrypt='test decrypt'
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    # _assemble_from_fragments
    # Called on line 106

# Generated at 2022-06-11 11:15:31.511378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create the object
    am = ActionModule()

    # call the method
    result = am.run(tmp=None, task_vars=None)

    # check if the result is valid
    assert result == {'skipped': True, 'skipped_reason': 'Skipping because remote_src is not yes'}



# Generated at 2022-06-11 11:16:58.742792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:17:03.423133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up parameters for call to run of class ActionModule
    tmp = None
    task_vars = dict()
    # Run method of class ActionModule and get result
    result = ActionModule.run(tmp, task_vars)
    # Check result of call run of class ActionModule
    assert(result == None)

# Generated at 2022-06-11 11:17:04.474592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 11:17:10.911514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = 'test_loader'
    connection = 'test_connection'
    play_context = 'test_play_context'
    new_stdin = 'test_stdin'

    test = ActionModule(loader=loader, connection=connection, play_context=play_context, new_stdin=new_stdin)
    assert test._loader == 'test_loader'
    assert test._connection == 'test_connection'
    assert test._play_context == 'test_play_context'
    assert test._new_stdin == 'test_stdin'
    assert test._supports_async is True
    assert test._supports_check_mode is False

# Generated at 2022-06-11 11:17:13.237310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(action_base.Task('name', {}, dict()), dict())
    assert am is not None


# Generated at 2022-06-11 11:17:14.484120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-11 11:17:26.767135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection={"host": "test_host", "port": 22, "user": "ansible", "ssh_executable": "/usr/bin/ssh", "scp_executable": "/usr/bin/scp", "scp_extra_args": "-o StrictHostKeyChecking=no"},
    module_executor={"_verbosity": 0, "no_log": False}
    connection_loader={"_connection_info": connection, "_task_uuid": None}
    loader={"_basedir": ".", "_password_files": [], "_FILES_CACHE": {}, "_TASKS_CACHE": {}, "_variable_manager": None, "_connection_loader": connection_loader}

# Generated at 2022-06-11 11:17:34.331287
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Need to call constructor of parent class (ActionBase)
  # to set ansible.utils.plugin_docs.version and ansible.utils.plugin_docs.documentation
  ansible.plugins.action.ActionBase()
  # Construct the object and test return value
  action_module=ActionModule(task=ansible.parsing.dataloader.DataLoader(),connection=ansible.plugins.connection.ConnectionBase(),play_context=ansible.playbook.play_context.PlayContext(),loader=ansible.parsing.dataloader.DataLoader(),templar=ansible.template.AnsibleTemplar(),shared_loader_obj=ansible.loader.AnsibleLoader())
  assert type(action_module) == ansible.plugins.action.ActionModule


# Generated at 2022-06-11 11:17:45.029007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup an ActionModule object and AnsibleAction object to test run.
    action_mod = ActionModule()
    # Assert 'src' and 'dest' are required
    task_vars = {"remote_src":"yes"}
    try:
        action_mod.run(tmp="temp", task_vars=task_vars)
    except Exception as e:
        assert e.message == "src and dest are required"

    # Assert warn message if src is not directory.
    task_vars = {"src":"test_ActionModule_run.py", "dest": "test_ActionModule_run.py", "remote_src":"yes"}

# Generated at 2022-06-11 11:17:46.098335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
