

# Generated at 2022-06-11 11:10:59.016249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

    class RealModule:
        def __init__(self):
            self.args = {}
        def fail_json(self, *args, **kwargs):
            raise AnsibleActionFail(args[0])
    mod._execute_module = lambda *args, **kwargs: {}
    mod._task = RealModule()
    mod._task.args = { 'src': 'src_test', 'dest': 'dest_test', 'regexp': 'test_regexp', 'delimiter': 'test_delimiter', 'ignore_hidden': 'test_ignore_hidden', 'remote_src': 'test_remote_src' }
    mod._find_needle = lambda *args, **kwargs: 'find_needle_test'

# Generated at 2022-06-11 11:11:00.859638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:11:10.124378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    playbook = Playbook.load(loader=DataLoader(), variable_manager=VariableManager(), templar=Templar())
    task = playbook.get_task(name='test_task', block=None)
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action, ActionBase), "action must be instance of ActionBase"

# Generated at 2022-06-11 11:11:18.887554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import os.path

    class AnsibleLegacyAssemble_ModuleTestCase(unittest.TestCase):
        module = ""
        path = "/tmp"

        @classmethod
        def setUpClass(cls):
            cls.module = module = AnsibleLegacyAssemble_Module()
            cls.path = path = os.path.join(path, "test")
            os.mkdir(path)
            os.mkdir(os.path.join(path, "files"))

            file = open(os.path.join(path, "files", "1"), "w")
            file.write("contents")
            file.close()

            file = open(os.path.join(path, "files", ".hidden"), "w")
            file.write("contents")
            file.close

# Generated at 2022-06-11 11:11:20.613558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module
    assert action_module.TRANSFERS_FILES

# Generated at 2022-06-11 11:11:32.370386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit tests for method run of class ActionModule '''

    # Run test for class ActionModule with given input (src='src', dest='dest')
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.copy import ActionModule
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import codecs
    import os
    import re
    import tempfile

    # Create object of class PlayContext and set its attributes
    play_context = PlayContext()
    play_context.check_mode = True
    play_context.network_os = 'network_os'
    play_context.remote_addr

# Generated at 2022-06-11 11:11:33.472843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    print(am)

# Generated at 2022-06-11 11:11:36.243460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We need to create an instance of our class
    # For that, we need to create this class with a list of methods
    action = ActionModule()
    assert action

# Generated at 2022-06-11 11:11:36.879420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:11:43.543462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action1 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(action1.TRANSFERS_FILES)

    action2 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(action2.TRANSFERS_FILES)


# Generated at 2022-06-11 11:11:55.675336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 11:11:56.602499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for class ActionModule"""
    assert True

# Generated at 2022-06-11 11:12:00.550794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    tmp = None
    task = None
    play_context = None
    connection = None
    loader = None
    test_obj = ActionModule(task, play_context, connection, tmp, loader)
    assert test_obj is not None

# Generated at 2022-06-11 11:12:05.968716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test_name', 'test_action_plugin_path', 'test_task', 'test_task_vars')
    assert am._task_name == 'test_name'
    assert am._action_plugin_path == 'test_action_plugin_path'
    assert am._task == 'test_task'
    assert am._task_vars == 'test_task_vars'

# Generated at 2022-06-11 11:12:11.643332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Check ActionModule.run method.

    Returns:
        True: Assertion successful
        False: Assertion failed
    """
    run_successful = True
    am = ActionModule()
    # AssertionError: if assertion failed
    try:
        am.run()
    except AssertionError:
        run_successful = False
    return run_successful

# Generated at 2022-06-11 11:12:21.756747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    context = dict()
    loader = DataLoader()
    context['loader'] = loader

    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory'])
    context['inventory'] = inv_manager

    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    context['variable_manager'] = variable_manager


# Generated at 2022-06-11 11:12:23.356482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert C.DEFAULT_LOCAL_TMP == tempfile.gettempdir()  # Assert that the assignment is correct

# Generated at 2022-06-11 11:12:24.786913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None, None, None, None)

# Generated at 2022-06-11 11:12:25.401330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:12:36.075343
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize a dummy object of class ActionModule
    obj = ActionModule()

    # Initialize attribute tmp of class ActionModule
    tmp = None
    # Assign value to attribute tmp of class ActionModule
    obj._tmp = tmp

    # Initialize attribute task_vars of class ActionModule
    task_vars = None
    # Assign value to attribute task_vars of class ActionModule
    obj._task_vars = task_vars

    # Initialize a dummy dictionary to be populated with dummy values
    result = {}
    # Invoke method run of class ActionModule
    obj.run(result)

    # Check whether the instance attribute _supports_check_mode of class ActionModule has been set to False
    assert obj._supports_check_mode is False

    # Check whether the value of the attribute tmp of class ActionModule has been set to

# Generated at 2022-06-11 11:13:00.207392
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action=ActionModule()
    action._connection=MockConnection()
    action._task.args={}
    action.run(tmp=None,task_vars=None)



# Generated at 2022-06-11 11:13:08.718974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test ActionModule")
    action_module = ActionModule(
        task=dict(args=dict(
            src="src", dest="dest", remote_src=True, regexp=None,
            delimiter=None, follow=False, ignore_hidden=False, decrypt=True
        )), connection=None, play_context=None, loader=None, templar=None,
        shared_loader_obj=None
    )
    action_module.run(tmp=None, task_vars=None)
    # print(action_module)

if __name__ == "__main__":
    # test_ActionModule()
    pass

# Generated at 2022-06-11 11:13:10.637157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test some empty values to ensure the class initializes
    action = ActionModule(None)
    assert not action.TRANSFERS_FILES

# Generated at 2022-06-11 11:13:13.158904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    modobj = ActionModule(task=dict(args=None), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert modobj

# Generated at 2022-06-11 11:13:13.738241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:13:15.992279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule =  ActionModule("test_task")

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 11:13:22.049334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    p = PlayContext()
    m = TaskQueueManager(p)

    a = ActionModule(m)

    assert a.action_name() == 'include'

    assert isinstance(a, ActionBase)

    assert a.TRANSFERS_FILES

# Generated at 2022-06-11 11:13:28.025117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    args = {'src': 'source', 'dest': 'dest'}
    actionmodule = ActionModule(None, args, context, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule.src == 'source'
    assert actionmodule.dest == 'dest'


# Generated at 2022-06-11 11:13:31.114518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None, None)
    assert actionModule.TRANSFERS_FILES == True
    assert actionModule._supports_check_mode == False


# Generated at 2022-06-11 11:13:32.178155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is ActionBase)

# Generated at 2022-06-11 11:14:15.761813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({}, {})._task.action == 'assemble'
    assert ActionModule({}, {})._connection is not None

# Generated at 2022-06-11 11:14:24.829893
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:14:26.084773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    n = ActionModule()
    assert n

# Generated at 2022-06-11 11:14:26.706681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:14:36.709420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    templar = Templar(loader=None, variables=VariableManager())
    task_vars = {}

    # Mock PlayContext
    context = PlayContext()
    context._templar = templar
    context._hostvars = task_vars
    context._host = None
    context._play_context.no_log = 1
    context._diff = False
    action_module = ActionModule(context, templar, task_vars, None)
    action_module._display = object()
    action_module._remove_tmp_path = object()
   

# Generated at 2022-06-11 11:14:37.333628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:14:40.406589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    ansible.module_utils.basic._ANSIBLE_ARGS = None
    am = ActionModule()
    assert am is not None



# Generated at 2022-06-11 11:14:45.045623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock = MagicMock()
    with patch.object(ActionModule, '_exec_module') as mock_module:
        mock_module.return_value = mock
        action_module = ActionModule()
        action_module.run(args={'src': 'src', 'dest': 'dest'})
        assert mock.run.called


# Generated at 2022-06-11 11:14:50.937761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    from units.mock.loader import DictDataLoader

    from units.modules.utils import set_module_args
    from units.mock.path import mock_unfrackpath_noop

    import pytest
    import os

    def _make_mock_block(module):
        return Block(
            role=Role(),
            task_include=TaskInclude(static=dict(block=['OK']))
        )


# Generated at 2022-06-11 11:14:52.029876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 11:16:16.025589
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:16:25.222227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-11 11:16:34.316336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    #from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    #from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.constants import LOAD_CALLBACK_PLUGINS

# Generated at 2022-06-11 11:16:43.884680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Used in integration test code
    """
    # test run method
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool

    class FakeModule(object):
        def __init__(self, diff=None, result=dict()):
            self.diff = diff
            self.result = result

    class FakeRunner(object):
        def __init__(self, diff=None, result=dict()):
            self.connection = FakeModule(diff=diff, result=result)
            self.basedir = ''

            # make the shell usable
            self

# Generated at 2022-06-11 11:16:44.776363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None, None, None)

# Generated at 2022-06-11 11:16:53.923894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    dest = '/home/user/.ssh/config'
    src = '/home/user/fragments'
    delimiter = '#'
    regexp = '^config$'
    follow = False
    ignore_hidden = False
    decrypt = True

    action_module._task.args = {
        'dest': dest,
        'src': src,
        'delimiter': delimiter,
        'regexp': regexp,
        'ignore_hidden': ignore_hidden,
        'decrypt': decrypt,
        'follow': follow
    }

    task_vars = {}

# Generated at 2022-06-11 11:17:00.634077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    task = dict(args=dict(src='src', dest='dest', delimiter='delimiter', remote_src=boolean(True), regexp='regexp', follow=boolean(False), ignore_hidden=boolean(False), decrypt=boolean(True)))
    am = ActionModule(task, dict())
    assert am.TRANSFERS_FILES == True

# Generated at 2022-06-11 11:17:09.406570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock classes to be used by AnsibleAction
    class MockActionBase(ActionBase):
        def _execute_module(self, module_name, module_args, task_vars, wrap_async=None):
            return dict(module_name=module_name, module_args=module_args, task_vars=task_vars, wrap_async=wrap_async)
        def _execute_module_with_result(self, module_name, module_args, task_vars, wrap_async=None):
            return dict(module_name=module_name, module_args=module_args, task_vars=task_vars, wrap_async=wrap_async)
        def _fixup_perms2(self, _):
            pass

# Generated at 2022-06-11 11:17:21.482987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_constants = type("test_constants", (object,), dict(DEFAULT_LOCAL_TMP="/tmp"))
    test_t = type("test_t", (object,), dict(args=dict(src="src", dest="dest"),
                                            _task=type("test_task", (object,), dict(args=dict(src="src", dest="dest")))()))
    test_loader = type("test_loader", (object,), dict(get_real_file=lambda self, filename, decrypt=False: filename))
    test_tmppath = type("test_tmppath", (object,), dict(name="/tmp/tmp_path"))
    test_tmpfd = type("test_tmpfd", (object,), dict(write=lambda self, data: None, close=lambda self: None))

    test_

# Generated at 2022-06-11 11:17:22.135825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:20:38.377559
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    # Test with missing src
    try:
        result = module.run(task_vars={'test': {'test1': 'test2'}})
        assert False
    except AnsibleAction as e:
        assert e.result['msg'] == 'src and dest are required'

    # Test with missing dest
    try:
        result = module.run(task_vars={'test': {'test1': 'test2'}}, tmp={'src': 'test'})
        assert False
    except AnsibleAction as e:
        assert e.result['msg'] == 'src and dest are required'

    # Test with _execute_module returning false