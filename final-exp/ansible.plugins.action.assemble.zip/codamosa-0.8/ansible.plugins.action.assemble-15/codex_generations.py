

# Generated at 2022-06-11 11:10:48.688560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.TRANSFERS_FILES == True
    assert a.__doc__ != None
    assert hasattr(a, '_assemble_from_fragments')

# Generated at 2022-06-11 11:10:54.957811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._supports_check_mode = False

# Generated at 2022-06-11 11:11:01.176754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    tmp = None
    action_args = dict(dest='/var/log/file.log', remote_src=False, src='/home/test/test_dir')
    # Test action module constructor
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am

# Generated at 2022-06-11 11:11:12.185078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.assemble as assemble
    import ansible.module_utils.ansible_release as ansible_release
    import sys

    # Monkey patch to avoid the real call to "ansible_release"
    old_rel = ansible_release.__ansible_version__
    ansible_release.__ansible_version__ = "2.6.0"
    old_sys = sys.version_info
    sys.version_info = (2, 7)

    # Mock the (real) ActionBase class: it is not loaded at this point
    class _source_class: pass
    _source_class.supports_check_mode = False


# Generated at 2022-06-11 11:11:22.068595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import sys
    import shutil
    import os

    module_name='ansible.legacy.assemble'
    test_case_dir = os.path.join(os.path.dirname(__file__), 'test_cases')
    test_case_dir = os.path.join(test_case_dir, 'action_plugin')
    test_case_dir = os.path.join(test_case_dir, 'ActionModule')
    test_case_dir = os.path.join

# Generated at 2022-06-11 11:11:24.625058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict())
    assert(module._supports_check_mode)


# Generated at 2022-06-11 11:11:35.876476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = dict(
        action_plugin='assemble.yml',
        action_plugin_args=dict(
            src='files',
            dest='/tmp/test',
            regexp='[^/]*$',
            delimiter="",
            remote_src='yes',
        ),
        action_wrapper=dict(
            _ansible_module_name='ansible.legacy.assemble',
        ),
        module_vars=dict(
            dest='/tmp/test',
            src='files',
            regexp='[^/]*$',
        ),
    )
    task = dict(
        module_vars=dict(
            dest='/tmp/test',
            src='files',
            regexp='[^/]*$',
        ),
    )

# Generated at 2022-06-11 11:11:38.849204
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    # Unit tests for class variables
    assert module.TRANSFERS_FILES == True

    # Unit tests for run() method
    assert module.run(1,'') == None

# Generated at 2022-06-11 11:11:50.370187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from mock import Mock
    from ansible.runner.action_plugins.assemble import ActionModule
    from ansible import errors

    # Given: mock parameters
    _task = Mock()
    _task.args = {
        'src' : None,
        'dest' : None,
        'delimiter' : None,
        'remote_src' : 'yes',
        'regexp' : None,
        'follow' : False,
        'ignore_hidden' : False,
        'decrypt' : True
    }
    _task._role = None
    _task.action = 'assemble'
    _task.role = None
    _task.async_val = 0
    _task.loop = None
    _task.notify = None

# Generated at 2022-06-11 11:11:52.291695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(
        task=dict(action=dict(module_name='whatever', module_args='whatever'))
    )
    assert isinstance(test_action_module, ActionModule)

# Generated at 2022-06-11 11:12:14.283681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize class variables
    task = {
        'args': {
            'src': '/some/where',
            'dest': '/some/where/else',
            'delimiter': '',
            'remote_src': 'yes',
            'regexp': '',
            'follow': False,
            'ignore_hidden': False
        }
    }
    play_context = {}
    connection = {}
    loader = {}
    temp_path = {}
    shared_loader_obj = {}

    # Initialize a new instance of the class
    am = ActionModule(task, play_context, connection, loader, temp_path, shared_loader_obj)

    # Assert _assemble_from_fragments raises an error if a src is None
    args = (None, None)

# Generated at 2022-06-11 11:12:23.780681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task.args['src'] = '/tmp/src'
    action._task.args['dest'] = '/tmp/dest'
    action._task.args['debug'] = False
    action._task.args['remote_src'] = False
    action._task.args['regexp'] = None
    action._task.args['delimiter'] = None
    action._task.args['ignore_hidden'] = False
    action._task.args['decrypt'] = False

    result = action.run(task_vars=dict())
    assert result['failed'] == True
    assert result['msg'].startswith("src and dest are required")
    assert result['rc'] == 5

    # create a fake source directory in tmp
    os.makedirs('/tmp/src')
    fd, test

# Generated at 2022-06-11 11:12:33.825207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit tests for action module copy

    This module is for testing the action module
    Copy. This code is a copy of the code in the
    ansible/action/copy.py module with
    modifications to allow testing of parts of
    this code in a unit test environment without
    the Ansible framework present.
    '''


# Generated at 2022-06-11 11:12:44.818245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create temp file as target directory
    temp_dir = tempfile.mkdtemp()

    module = ActionModule()

    # Stub _assemble_from_fragments to return temp dir
    def _assemble_from_fragments(src_path, delimiter=None, compiled_regexp=None, ignore_hidden=False, decrypt=True):
        return temp_dir

    module._assemble_from_fragments = _assemble_from_fragments

    # Stub _remote_expand_user to return the same string
    def _remote_expand_user(dest):
        return dest

    module._remote_expand_user = _remote_expand_user

    # Stub _execute_remote_stat to return a dict

# Generated at 2022-06-11 11:12:50.959164
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Dummy class for using super
    class DummyActionModule(ActionModule):
        def __init__(self):
            self.runner = None

    import unittest
    import sys

    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = open(os.devnull, 'wt')
    sys.stderr = open(os.devnull, 'wt')

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.action_module = DummyActionModule()
            self.action_module._task = {}
            self.action_module._task['args'] = {}

        def test_run_with_no_src(self):
            self.action_module._task['args']['dest'] = 'dest'


# Generated at 2022-06-11 11:13:02.006923
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:13:11.718803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import ansible.plugins.action.assemble as assemble_action

    temp_directory = tempfile.mkdtemp()

# Generated at 2022-06-11 11:13:22.627186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for the method ActionModule.run of the class ActionModule.
    '''

    # AnsibleModule object
    am = AnsibleModule()

    # ActionBase object
    am.args = {'dest': '/data',
               'remote_src': 'no',
               'decrypt': 'yes',
               'src': '/data/ansible'}
    am.task_vars = {'inventory_hostname': 'hostX',
                    'hostvars': {'hostX': {'ansible_distribution': 'CentOS'}}}
    am.task_vars['test_run'] = True
    ab = ActionBase()
    ab.module = am
    ab.task_vars = am.task_vars

    # Create ActionModule object with ActionBase object
    ac = ActionModule(ab)



# Generated at 2022-06-11 11:13:23.450346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 11:13:28.023934
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    module._connection = MockConnection()
    module._task = MockTask()

    module._task.args = dict(src="/some/path", dest="/some/other/path", remote_src=False)
    module._loader = MockLoader()

    module.run(None, None)


# Generated at 2022-06-11 11:13:40.508061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:13:42.444534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action is not None

test_ActionModule()

# Generated at 2022-06-11 11:13:43.090609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:13:54.345529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import combine_vars

    action = ActionModule('test', [], [], [], [])
    host_vars = {'test_host': {'ansible_check_mode': False}}
    task_vars = {'test_var': None, 'ansible_check_mode': False}
    self_vars = {'action': action, 'play_context': action._play_context}
    all_vars = {'hostvars': host_vars, 'self': self_vars, 'vars': task_vars}

    task_vars = combine_vars(all_vars)
    action.run(None, task_vars)
    # No source supplied

# Generated at 2022-06-11 11:14:00.195979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = "ansible.legacy.copy"
    module_args = "src=/tmp/test/sample dest=/tmp/test/dest"
    task_vars = ""
    create_directory = "False"
    follow = "False"
    checksum_algorithm = "sha1"

    # Create object
    obj = ActionModule(module_name, module_args, task_vars, create_directory, follow, checksum_algorithm)
    # call run()
    obj.run()

# Generated at 2022-06-11 11:14:10.444426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global module
    module = None

# Generated at 2022-06-11 11:14:11.651186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert not module._supports_check_mode

# Generated at 2022-06-11 11:14:21.580557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._execute_module = lambda self, module_name: {'rc': 0, 'stdout': ''}
    ActionModule._transfer_file = lambda self, path, remote_path: remote_path
    tf = tempfile.NamedTemporaryFile()
    path = tf.name
    os.remove(path)
    os.mkdir(path)
    open(os.path.join(path, '1.txt'), 'a').close()
    open(os.path.join(path, '2.txt'), 'a').close()
    open(os.path.join(path, '3.txt'), 'a').close()
    test_action_module = ActionModule()
    test_action_module._remove_tmp_path = lambda self, tmp: None
    test_action_module._connection = lambda self: None
    test

# Generated at 2022-06-11 11:14:26.468213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp = tempfile.mkdtemp()
    temp1 = tempfile.mkdtemp(dir=temp)
    temp2 = tempfile.mkdtemp(dir=temp)
    path = os.path.join(temp1, 'foo.txt')
    with open(path, 'w') as f:
        f.write("Hello world")
    path1 = os.path.join(temp2, 'bar.txt')
    with open(path1, 'w') as f:
        f.write("Test data")
    mod = ActionModule(None, None, None, '/var/tmp/ansible', False, False, None, None)
    assert mod._assemble_from_fragments(temp1, ignore_hidden=False) is not None

# Generated at 2022-06-11 11:14:27.440928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-11 11:14:48.978605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None, templar=None)
    try:
        result = module.run(tmp=None, task_vars=None)
    except AnsibleActionFail as e:
        assert e.result == {'failed': True, 'msg': 'src and dest are required'}
    except _AnsibleActionDone as e:
        assert e.result == {'ansible.legacy.assemble': {'skip_reason': 'Conditional result was False', 'skipped': True}}

# Generated at 2022-06-11 11:14:50.388807
# Unit test for constructor of class ActionModule
def test_ActionModule():

    fake_module_class = MockActionModule()

    fake_module_class.run()

# Generated at 2022-06-11 11:14:52.693278
# Unit test for constructor of class ActionModule
def test_ActionModule():
  test_obj = ActionModule(None, None, None, None, None)
  test_obj.run()


# Generated at 2022-06-11 11:15:03.278528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_task = dict(args=dict(src=None, dest=None, delimiter=None, remote_src='', regexp=None, follow=False,
                               ignore_hidden=False, decrypt=True))


# Generated at 2022-06-11 11:15:13.100956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    print("test_ActionModule_run")

    #######################################################################
    # SETUP FIXTURES
    #######################################################################
    class Mock_Task(object):
        '''
        Mock class for ansible.parsing.yaml.objects.Task
        '''
        def __init__(self):
            self.args = {}

    class Mock_Plugin(object):
        '''
        Mock class for ansible.plugins.action.ActionBase,
        not needed for unit tests
        '''
        pass

    class Mock_ActionModule(ActionModule, Mock_Plugin):
        '''
        Mock class for ansible.plugins.action.ActionModule,
        not needed for unit tests
        '''
        pass


# Generated at 2022-06-11 11:15:23.160384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    sys_module = sys.modules[__name__]  # get this modules module object
    # create an instance of ActionModule with the needed parameters
    # kwargs is dict with the arguments for the class constructor
    kwargs = dict(task=dict(args=dict(src='src_dir', dest='dest_dir', remote_src=True)),
                  connection=dict(tmp='/tmp', shell=dict(tmpdir='')))
    obj = sys_module.ActionModule(**kwargs)
    # mock the method execute_module of the class ActionModule
    with patch.object(ActionModule, '_execute_module', return_value=dict(rc=3, msg='error')):
        # assert the return value of method run is whatever the mocked _execute_module returns
        assert obj.run() == dict(rc=3, msg='error')

# Generated at 2022-06-11 11:15:24.270050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule.supports_check_mode

# Generated at 2022-06-11 11:15:24.876685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:15:35.266802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Loading ansible.legacy.file & ansible.legacy.assemble modules for unit testing
    import ansible.legacy.file
    import ansible.legacy.assemble

    action = ActionModule()

    # Loading required arguments for run method of ActionModule
    action.set_args(remote_src='no', src='home/travis/source', dest='/home/travis/dest')

    # Loading task_vars
    task_vars = { "ansible_user": "travis" }

    # Loading result file
    result = { "results": "passed" }

    # Test a successful run
    assert action.run(task_vars=task_vars) == result

    # Testing a failed run
    action.set_args(remote_src='no', src='home/travis/source')



# Generated at 2022-06-11 11:15:41.966284
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module_name = 'ansible.legacy.copy'
    src = 'src'
    dest = 'dest'
    regexp = 'regexp'

    t = ActionModule()

    # check only setters of variables class
    t.set_task('test_task')
    t.set_loader('test_loader')
    t.set_play_context('test_play_context')
    t.set_shared_loader_obj('test_shared_loader_obj')

    # call run method for testing purposes
    t.run(None, {'src' : src, 'dest' : dest, 'regexp' : regexp})

# Generated at 2022-06-11 11:16:16.350339
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:16:18.353667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    action = ActionModule()
    assert action.run() == 'test'

# Generated at 2022-06-11 11:16:27.730819
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:16:29.051843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None)
    assert x is not None


# Generated at 2022-06-11 11:16:29.635985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:16:38.916046
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Testing exception case for src is None or dest is None
    results = {'failed': True, 'msg': "src and dest are required"}
    result = a.run(tmp=None, task_vars=None)
    assert result == results

    # Testing with exception case where remote_src is not a directory
    a.src = None
    a.dest = None
    a.regexp = None
    a.delimiter = None
    a.remote_src = 'yes'
    a.ignore_hidden = False
    module_results = {'failed': True, 'msg': "Source (None) is not a directory"}

# Generated at 2022-06-11 11:16:48.421349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance with test ActionBase
    class ActionModuleTest(ActionBase):
        def __init__(self,  *args, **kwargs):
            my_dir = os.path.dirname(os.path.abspath(__file__))
            action_base_dir = os.path.abspath(os.path.join(my_dir, '..'))
            for path in [my_dir, action_base_dir]:
                if path not in sys.path:
                    sys.path.append(path)

            # base class constructor
            super(ActionModuleTest, self).__init__(*args, **kwargs)
            # don't try to load any plugins or modules

# Generated at 2022-06-11 11:16:58.434051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context

    # Setup


# Generated at 2022-06-11 11:17:08.211623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # test input
    module = {u'args': {u'regexp': u'.*', u'delimiter': u'', u'dest': u'test_dest',
                        u'remote_src': u'yes', u'src': u'test_src', u'ignore_hidden': False,
                        u'encrypt': True},
               u'name': u'assemble', u'_ansible_parsed': True, u'action': u'assemble'}
    task_vars = {}

    # tests
    # test when src is missing
    result = {}
    tmp = None
    ansible_module = ActionModule(task=module, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:17:20.025364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockTask(object):
        def __init__(self, args=dict()):
            self.args = args

    ansible_vars = dict(
        inventory=InventoryManager(loader=DataLoader(), sources=[]),
        variable_manager=VariableManager(loader=DataLoader())
    )
    context._init_global_context(**ansible_vars)

    connection = MockConnection()


# Generated at 2022-06-11 11:18:17.133352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    # read sample inventory for testing
    loader = DataLoader()
    inv_file = '../../../../examples/ansible_inventory.yaml'
    inventory = InventoryManager(loader, inv_file)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    
    # create a temporary directory for storing the test files
    import tempfile
    tmpdir = tempfile.mkdtemp()
    
    # define the test source and destination paths

# Generated at 2022-06-11 11:18:17.676695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:18:18.814565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We do not need to test any thing as this module never called directly.
    assert True

# Generated at 2022-06-11 11:18:21.901836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test variables
    tmp = '/tmp'
    task_vars = dict()
    action_module = ActionModule(None, None)

    result = action_module.run(tmp, task_vars)
    # Empty result
    assert result == {}, 'Expected {}'


# Generated at 2022-06-11 11:18:22.525707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:18:30.528942
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case try catch
    try:
        # Create instance of class ActionModule
        ActionModule('remote_src', 'src', 'dest')

    # Try catch exception
    except Exception as exp:
        print('Exception:', exp)
        # Continue

    # Test case try catch
    try:
        # Create instance of class ActionModule
        ActionModule('remote_src', 'src', 'dest', 'delimiter')

    # Try catch exception
    except Exception as exp:
        print('Exception:', exp)
        # Continue

    # Test case try catch
    try:
        # Create instance of class ActionModule
        ActionModule('remote_src', 'src', 'dest', 'delimiter', regexp='abc')

    # Try catch exception
    except Exception as exp:
        print('Exception:', exp)
        # Continue

   

# Generated at 2022-06-11 11:18:32.238313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModuleObj = ActionModule()
    assert (actionModuleObj.run(tmp=None, task_vars=None))

# Generated at 2022-06-11 11:18:40.124331
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct an instance of the class being tested
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    action_module._remove_tmp_path = lambda x: None

    # Mock methods used in the method being tested
    action_module._execute_module = MagicMock(
        side_effect=[
            {
                'changed': True,
                'checksum': '123',
                'msg': 'file modified'
            },
            {
                'changed': False,
                'checksum': '123',
                'msg': 'file not modified'
            }
        ]
    )
    action_module._assemble_from_fragments = MagicM

# Generated at 2022-06-11 11:18:42.460259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a module that will always fail
    test_module = ActionModule('failing_module', 'fake action plugin')
    assert not test_module.run()['failed']

# Generated at 2022-06-11 11:18:51.546564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.assemble
    import ansible.utils.module_docs
    import ansible.utils.template
    import ansible.vars
    import collections
    import json

    # Test input values
    test_input_task = collections.namedtuple('task', ('args'))
    test_input_args = {
        'arg1': '/var/a',
        'arg2': '/var/b',
        'arg3': 'c',
        'arg4': 'yes',
        'arg5': 'no',
    }

    test_input_task_vars = {
        'test': 'test'
    }

    # Expected result