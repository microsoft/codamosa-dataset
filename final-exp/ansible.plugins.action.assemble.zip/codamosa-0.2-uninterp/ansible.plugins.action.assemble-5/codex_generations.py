

# Generated at 2022-06-17 08:28:00.268233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:28:00.792894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:02.820841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:28:03.715809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 08:28:12.773571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:28:21.899345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:28:26.986335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.hashing import checksum_s

    class ActionModule_run_ActionModule(ActionModule):
        def _execute_module(self, module_name, module_args, task_vars=None):
            return dict(changed=True, msg='_execute_module')

        def _execute_remote_stat(self, path, all_vars=None, follow=False):
            return dict(checksum='abc123')

        def _fixup_perms2(self, file_args):
            pass

       

# Generated at 2022-06-17 08:28:37.796851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader)

    # Create a mock task variables
    task_vars = dict()

    # Create a mock source directory
    src = './test/files'

    # Create a mock destination directory
    dest = './test/dest'

    # Create a mock delimiter
    delimiter = '\n'

    # Create a mock regexp
    regexp = 'test'

    # Create a mock follow
    follow = False

    # Create a mock ignore_hidden

# Generated at 2022-06-17 08:28:41.894549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader)
    # Create a mock task vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock src
    src = None
    # Create a mock dest
    dest = None
    # Create a mock delimiter
    delimiter = None
    # Create a mock remote_src
    remote_src = 'yes'
    # Create a mock regexp
    regexp = None
    # Create a mock follow
    follow = False


# Generated at 2022-06-17 08:28:42.474728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:54.134879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:28:56.856008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:58.569077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:28:59.359324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:10.371058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    module = ActionModule()
    module._task = MockTask()
    module._task.args = {'dest': 'test'}
    module._execute_module = MockExecuteModule()
    module._execute_module.return_value = {'failed': True, 'msg': 'src and dest are required'}
    result = module.run()
    assert result['failed']
    assert result['msg'] == 'src and dest are required'

    # Test with no dest
    module = ActionModule()
    module._task = MockTask()
    module._task.args = {'src': 'test'}
    module._execute_module = MockExecuteModule()
    module._execute_module.return_value = {'failed': True, 'msg': 'src and dest are required'}
    result = module.run()

# Generated at 2022-06-17 08:29:13.370674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:15.719967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.TRANSFERS_FILES == True
    assert am._supports_check_mode == False


# Generated at 2022-06-17 08:29:30.061768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}
    task_vars = {}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create

# Generated at 2022-06-17 08:29:31.739300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:41.330967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock task vars
    task_vars = dict()

    # Create a mock src and dest
    src = 'src'
    dest = 'dest'

    # Create a mock regexp
    regexp = 'regexp'

    # Create a mock delimiter
    delimiter = 'delimiter'

    # Create a mock remote_src
    remote_src = 'yes'

    # Create a mock follow
    follow = False

    # Create a mock ignore_hidden
    ignore_hidden = False

    # Create a mock decrypt
    decrypt = True

    # Call the run method of the

# Generated at 2022-06-17 08:30:02.100812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:30:04.615476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:30:05.835475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:30:07.257341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:30:11.484888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:30:15.053055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:30:18.710630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:30:20.895142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 08:30:33.915319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid parameters
    action_module = ActionModule()
    action_module._task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}
    action_module._execute_module = lambda module_name, task_vars: {'result': 'result'}
    action_module._execute_remote_stat = lambda dest, all_vars, follow: {'checksum': 'checksum'}
    action_module._remote_expand_user = lambda dest: dest
    action_module._find_needle = lambda files, src: src
    action_module._assemble_from_fragments = lambda src_path, delimiter, compiled_regexp, ignore_hidden, decrypt: 'path'

# Generated at 2022-06-17 08:30:35.680013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 08:31:27.085836
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:31:30.474908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 08:31:30.991288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:37.686673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module.TRANSFERS_FILES == True
    assert action_module._supports_check_mode == False
    assert action_module._supports_async == False
    assert action_module._supports_become == False
    assert action_module._supports_diff == True
    assert action_module._supports_subset == False
    assert action_module._supports_check_mode == False
    assert action_module._supports_async == False
    assert action_module._supports_become == False
    assert action_module._supports_diff == True


# Generated at 2022-06-17 08:31:39.301778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:49.957707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = type('task', (object,), {})()
    task.args = {'src': 'src', 'dest': 'dest'}
    # Create a mock play context object
    play_context = type('play_context', (object,), {})()
    play_context.diff = False
    # Create a mock connection object
    connection = type('connection', (object,), {})()
    connection._shell = type('shell', (object,), {})()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.join_path = lambda x, y: x + '/' + y
    connection._shell.join_path.__name__ = 'join_path'
    connection._shell.join_path.__module__ = 'ansible.plugins.action.assemble'
   

# Generated at 2022-06-17 08:31:57.302693
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:31:58.105933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:08.440335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, action_plugin)

    # Test the run method
    action_module.run()



# Generated at 2022-06-17 08:32:19.883923
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:33:39.732945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:33:50.495675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid src and dest
    action_module = ActionModule()
    action_module._task = {'args': {'src': 'test/', 'dest': 'test/'}}
    action_module._connection = {'_shell': {'tmpdir': 'test/'}}
    action_module._loader = {'get_real_file': lambda x, y: x}
    action_module._execute_remote_stat = lambda x, y, z: {'checksum': 'test'}
    action_module._execute_module = lambda x, y: {'test': 'test'}
    action_module._remove_tmp_path = lambda x: None
    action_module._transfer_file = lambda x, y: x
    action_module._fixup_perms2 = lambda x: None
    action_module._find

# Generated at 2022-06-17 08:33:51.884455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:33:52.530140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:02.535187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionModule()
    # Create a mock action plugin
    action_plugin.action_plugin = action_plugin
    # Create a mock action plugin
    action_plugin.action_plugin.action_plugin = action_plugin
    # Create a mock action plugin
    action_plugin.action_plugin.action_plugin.action_plugin = action_plugin
    # Create a mock action plugin
    action_plugin.action_plugin.action_plugin.action_plugin.action_plugin = action_plugin
    # Create a mock action plugin

# Generated at 2022-06-17 08:34:04.631287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:34:06.664163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:08.510569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:09.428365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:34:10.227254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:37:00.454724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:37:01.725647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:37:03.451535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == True

# Generated at 2022-06-17 08:37:16.997881
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:37:18.135024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:37:19.106233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:37:31.991552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=dict(args=dict(src='src', dest='dest', remote_src='yes', regexp='regexp', delimiter='delimiter', ignore_hidden='ignore_hidden', decrypt='decrypt')))
    assert action_module._task.args['src'] == 'src'
    assert action_module._task.args['dest'] == 'dest'
    assert action_module._task.args['remote_src'] == 'yes'
    assert action_module._task.args['regexp'] == 'regexp'
    assert action_module._task.args['delimiter'] == 'delimiter'
    assert action_module._task.args['ignore_hidden'] == 'ignore_hidden'

# Generated at 2022-06-17 08:37:44.257157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': '/home/user/ansible/test/files', 'dest': '/home/user/ansible/test/dest', 'regexp': '^test_file_[0-9]$', 'delimiter': '\n---\n', 'ignore_hidden': False, 'decrypt': True}
    task.action = 'assemble'
    task.action_args = {'dest': '/home/user/ansible/test/dest', 'src': '/home/user/ansible/test/files', 'regexp': '^test_file_[0-9]$', 'delimiter': '\n---\n', 'ignore_hidden': False, 'decrypt': True}
    task.action_args.update(task.args)