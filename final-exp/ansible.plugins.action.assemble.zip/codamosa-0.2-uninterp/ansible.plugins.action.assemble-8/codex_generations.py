

# Generated at 2022-06-17 08:27:58.780805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:27:59.346631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:00.171022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 08:28:01.280802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid parameters
    # TODO: Add test for valid parameters
    pass

# Generated at 2022-06-17 08:28:06.939476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:28:09.105024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:28:10.131797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 08:28:13.083665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:28:14.034783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 08:28:15.328828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:28:33.456661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                src='src',
                dest='dest',
                delimiter='delimiter',
                remote_src='remote_src',
                regexp='regexp',
                follow='follow',
                ignore_hidden='ignore_hidden',
                decrypt='decrypt'
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module._task.args.get('src') == 'src'
    assert action_module._task.args.get('dest') == 'dest'
    assert action_module._task.args.get('delimiter') == 'delimiter'
    assert action_module._task

# Generated at 2022-06-17 08:28:35.987139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 08:28:41.876807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am.TRANSFERS_FILES == True
    assert am._supports_check_mode == False

    # Test with arguments
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.TRANSFERS_FILES == True
    assert am._supports_check_mode == False

# Generated at 2022-06-17 08:28:46.135887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock options
    options = MockOptions()
    # Create a mock inventory
    inventory = MockInventory()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock shell
    shell = MockShell()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock task_

# Generated at 2022-06-17 08:28:47.028807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:28:51.756812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:28:57.331491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:28:59.180275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:29:00.363824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:01.053333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:29:23.585378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:29:32.327048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    action_module._connection = MockConnection()
    action_module._loader = MockLoader()
    action_module._templar = MockTemplar()
    action_module._shared_loader_obj = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()
    action_module._play_context = play_context

   

# Generated at 2022-06-17 08:29:39.005579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin.run(task, connection, play_context, loader)

    # Check if the run method was called
    assert action_plugin.run_called



# Generated at 2022-06-17 08:29:44.923295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock task_vars
    task_vars = {}

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar=None, shared_loader_obj=None)

    # Test the run method
    result = action_module.run(tmp=None, task_vars=task_vars)

    # Assert that the result is a dictionary
    assert isinstance(result, dict)



# Generated at 2022-06-17 08:29:46.443222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:29:47.065465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:50.650743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:51.290739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:30:03.287110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:30:04.263469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 08:30:45.414045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:30:58.711209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    action_module._connection = MockConnection()
    action_module._loader = MockLoader()
    action_module._templar = MockTemplar()
    action_module._shared_loader_obj = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()
    action_module._play_context = play_context

   

# Generated at 2022-06-17 08:31:00.367917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:31:12.316371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(
        task=dict(
            args=dict(
                src='/path/to/src',
                dest='/path/to/dest',
                delimiter='delimiter',
                remote_src='yes',
                regexp='regexp',
                follow=False,
                ignore_hidden=False,
                decrypt=True,
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    assert action_module is not None

    # Test with invalid arguments

# Generated at 2022-06-17 08:31:13.500038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:31:14.066527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:14.620102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:18.871560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:31:20.027409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:22.920557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:41.580504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:42.579901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:32:51.010844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of class AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of class _AnsibleActionDone
    _ansible_action_done = _AnsibleActionDone()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class ActionBase
    action_base = ActionBase()

    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of class AnsibleAction
    ansible_

# Generated at 2022-06-17 08:33:01.341853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock action module
    am = ActionModule(None, None)

    # create a mock task
    task = MockTask()

    # create a mock connection
    conn = MockConnection()

    # create a mock play context
    play_context = MockPlayContext()

    # create a mock loader
    loader = MockLoader()

    # create a mock templar
    templar = MockTemplar()

    # create a mock action base
    action_base = MockActionBase()

    # create a mock task_vars
    task_vars = MockTaskVars()

    # set the action module's task, connection, play context, loader, templar, and action base
    am._task = task
    am._connection = conn
    am._play_context = play_context
    am._loader = loader
    am._tem

# Generated at 2022-06-17 08:33:02.441478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:33:15.952958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionModule()
    # Create a mock action plugin
    action_plugin2 = MockActionModule2()
    # Create a mock action plugin
    action_plugin3 = MockActionModule3()
    # Create a mock action plugin
    action_plugin4 = MockActionModule4()
    # Create a mock action plugin
    action_plugin5 = MockActionModule5()
    # Create a mock action plugin
    action_plugin6 = MockActionModule6()
    # Create a mock action plugin
    action_plugin7 = MockActionModule7()
   

# Generated at 2022-06-17 08:33:17.064959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:33:18.022929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:33:29.959079
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:33:31.654576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:36:09.440675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    action_module._connection = MockConnection()
    action_module._loader = MockLoader()
    action_module._templar = MockTemplar()
    action_module._shared_loader_obj = MockSharedLoaderObj()
    action_module._connection._shell = MockShell()

    # Create a mock task_vars

# Generated at 2022-06-17 08:36:18.454077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = {
        'args': {
            'src': 'src',
            'dest': 'dest',
            'delimiter': 'delimiter',
            'remote_src': 'remote_src',
            'regexp': 'regexp',
            'follow': 'follow',
            'ignore_hidden': 'ignore_hidden',
            'decrypt': 'decrypt'
        }
    }

    # Create a fake loader
    loader = {
        'get_real_file': lambda x, y: x
    }

    # Create a fake play context
    play_context = {
        'diff': 'diff'
    }

    # Create a fake connection

# Generated at 2022-06-17 08:36:21.593087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:36:31.645447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader)

    # Create a mock task vars
    task_vars = {}

    # Test the run method
    result = action_plugin.run(task_vars=task_vars)

    # Check the result

# Generated at 2022-06-17 08:36:41.739582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.assemble
    import ansible.plugins.action.copy
    import ansible.plugins.action.file
    import ansible.plugins.loader
    import ansible.plugins.action.template
    import ansible.plugins.action.unarchive
    import ansible.plugins.action.synchronize
    import ansible.plugins.action.script
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.debug
    import ansible.plugins.action.setup
    import ansible.plugins.action.ping
    import ansible.plugins.action.wait_for
    import ansible.plugins.action.include
    import ansible.plugins.action.include_role
    import ansible.plugins.action.include_tasks
    import ans

# Generated at 2022-06-17 08:36:43.460690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:36:46.895916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 08:36:49.825150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None


# Generated at 2022-06-17 08:36:55.080031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 08:36:57.308970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule()
    assert module._supports_check_mode == False
