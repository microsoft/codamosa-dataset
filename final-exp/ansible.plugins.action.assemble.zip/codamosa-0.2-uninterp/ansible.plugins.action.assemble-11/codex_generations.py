

# Generated at 2022-06-17 08:28:02.218997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:12.507872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    task_vars = dict()
    task_vars['ansible_ssh_user'] = 'test'
    task_vars['ansible_ssh_pass'] = 'test'
    task_vars['ansible_ssh_host'] = 'test'
    task_vars['ansible_ssh_port'] = 'test'
    task_vars['ansible_connection'] = 'test'
    task_vars['ansible_python_interpreter'] = 'test'
    task_vars['ansible_shell_type'] = 'test'
    task_vars['ansible_shell_executable'] = 'test'
    task_vars['ansible_shell_executable'] = 'test'
    task_vars['ansible_shell_executable'] = 'test'


# Generated at 2022-06-17 08:28:12.953916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:13.899232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:28:16.210403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == True

# Generated at 2022-06-17 08:28:19.155460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:28:20.007798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:31.684146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='assemble', module_args=dict(src='src', dest='dest'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module._task.action['module_name'] == 'assemble'
    assert action_module._task.action['module_args'] == dict(src='src', dest='dest')
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

# Generated at 2022-06-17 08:28:34.665614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:28:43.952312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader)

    # Create a mock task vars
    task_vars = dict()

    # Call method run of class ActionModule
    result = action_plugin.run(task_vars=task_vars)

    # Check result
    assert result == {'failed': False, 'changed': False}



# Generated at 2022-06-17 08:29:08.639979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionModule()
    # Create a mock action plugin
    action_plugin._task = task
    action_plugin._connection = connection
    action_plugin._loader = loader
    action_plugin._play_context = play_context
    # Create a mock task vars
    task_vars = dict()
    # Create a mock result
    result = dict()
    # Create a mock action fail
    action_fail = Mock

# Generated at 2022-06-17 08:29:12.872545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:29:21.293744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader)

    # Create a mock task_vars
    task_vars = {}

    # Create a mock tmp
    tmp = 'tmp'

    # Create a mock result

# Generated at 2022-06-17 08:29:23.642860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 08:29:24.156525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:29:24.654915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:29:25.732137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 08:29:26.503624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:29:34.439105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    module = ActionModule()
    module._task = MockTask()
    module._task.args = {'dest': 'dest'}
    module._execute_module = MockExecuteModule()
    module._execute_module.return_value = {'failed': False}
    module._remove_tmp_path = MockRemoveTmpPath()
    module._remove_tmp_path.return_value = None
    module._remote_expand_user = MockRemoteExpandUser()
    module._remote_expand_user.return_value = 'dest'
    module._execute_remote_stat = MockExecuteRemoteStat()
    module._execute_remote_stat.return_value = {'checksum': 'checksum'}
    module._get_diff_data = MockGetDiffData()
    module._get_diff_data

# Generated at 2022-06-17 08:29:44.419536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:30:18.517329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:30:19.871486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 08:30:30.904676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    task_vars = dict()
    tmp = None
    module = ActionModule(task=dict(args=dict(dest='/tmp/test')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'src and dest are required'

    # Test with no dest
    task_vars = dict()
    tmp = None
    module = ActionModule(task=dict(args=dict(src='/tmp/test')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp, task_vars)
   

# Generated at 2022-06-17 08:30:41.442922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(
            src='src',
            dest='dest',
            delimiter='delimiter',
            remote_src='remote_src',
            regexp='regexp',
            follow='follow',
            ignore_hidden='ignore_hidden',
            decrypt='decrypt'
        )),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module._task.args['src'] == 'src'
    assert action_module._task.args['dest'] == 'dest'
    assert action_module._task.args['delimiter'] == 'delimiter'

# Generated at 2022-06-17 08:30:47.910761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'remote_src', 'regexp': 'regexp', 'delimiter': 'delimiter', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin.run(task_vars=None, tmp=None)

# Generated at 2022-06-17 08:30:48.737357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:30:52.830725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:30:55.988211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:30:59.710920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 08:31:11.980702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    task_vars = dict()
    tmp = None
    module = ActionModule(task=dict(args=dict(dest='/tmp/test')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp, task_vars)
    assert result['failed'] is True
    assert result['msg'] == 'src and dest are required'

    # Test with no dest
    task_vars = dict()
    tmp = None
    module = ActionModule(task=dict(args=dict(src='/tmp/test')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp, task_vars)
   

# Generated at 2022-06-17 08:31:53.899204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:06.147323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(
        task=dict(action=dict(module_name='test', module_args=dict(src='test', dest='test'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module.TRANSFERS_FILES == True
    assert action_module._supports_check_mode == False

    # Test with invalid arguments

# Generated at 2022-06-17 08:32:17.508892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    module = ActionModule(None, dict(src='src', dest='dest', remote_src='yes', regexp='regexp', delimiter='delimiter', ignore_hidden='ignore_hidden', decrypt='decrypt'))
    assert module is not None

    # Test with missing src
    try:
        module = ActionModule(None, dict(dest='dest', remote_src='yes', regexp='regexp', delimiter='delimiter', ignore_hidden='ignore_hidden', decrypt='decrypt'))
        assert False
    except AnsibleActionFail:
        pass

    # Test with missing dest

# Generated at 2022-06-17 08:32:19.841238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:32:30.051025
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:32:41.196392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(src='src', dest='dest')

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin._task = task
    action_plugin._connection = connection
    action_plugin._play_context = play_context
    action_plugin._loader = loader
    action_plugin._templar = templar

    # Create a mock action plugin
    action_plugin.run()

    # Assert that the mock connection

# Generated at 2022-06-17 08:32:41.849035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:42.479672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:43.119839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:43.805627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:08.469069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:11.401818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:34:11.935757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-17 08:34:21.981411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am.TRANSFERS_FILES == True
    assert am._supports_check_mode == False
    assert am._supports_async == False
    assert am._supports_become == False
    assert am._supports_diff == False
    assert am._supports_subset == False
    assert am._supports_check_mode == False
    assert am._supports_async == False
    assert am._supports_become == False
    assert am._supports_diff == False
    assert am._supports_subset == False
    assert am._supports_check_mode == False
    assert am._supports_async == False
    assert am._supports_become == False
    assert am._supports_diff == False
    assert am

# Generated at 2022-06-17 08:34:33.793204
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:34:35.215585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:46.722841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module action
    mock_action = ActionModule()
    # Create a mock object for the module connection
    mock_connection = Connection()
    # Create a mock object for the module play_context
    mock_play_context = PlayContext()
    # Create a mock object for the module loader
    mock_loader = DataLoader()
    # Create a mock object for the module templar
    mock_templar = Templar()
    # Create a mock object for the module task
    mock_task = Task()
    # Create a mock object for the module task_vars
    mock_task_vars = dict()

    # Set the attributes of the mock object for the module action
    mock_action._task = mock_task
    mock_action._connection = mock_connection
    mock_action._play_context = mock_play_

# Generated at 2022-06-17 08:34:57.209785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection
    connection = Connection()
    # Create a mock task
    task = Task()
    # Create a mock action module
    action_module = ActionModule(task, connection)
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock src
    src = None
    # Create a mock dest
    dest = None
    # Create a mock delimiter
    delimiter = None
    # Create a mock remote_src
    remote_src = 'yes'
    # Create a mock regexp
    regexp = None
    # Create a mock follow
    follow = False
    # Create a mock ignore_hidden
    ignore_hidden = False
    # Create a mock decrypt
    decrypt = True

    # Test the run method
    action_module

# Generated at 2022-06-17 08:35:03.623059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_

# Generated at 2022-06-17 08:35:16.849310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action
    action = MockAction()

    # Create a mock shell
    shell = MockShell()

    # Create a mock remote_user
    remote_user = MockRemoteUser()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock action_plugin
    action_plugin = MockActionPlugin()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock action_base
    action_