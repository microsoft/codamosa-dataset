

# Generated at 2022-06-17 08:28:00.232457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:09.949313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    task_vars = dict()
    task_vars['ansible_check_mode'] = False
    task_vars['ansible_diff_mode'] = False
    task_vars['ansible_verbosity'] = 0
    task_vars['ansible_version'] = '2.9.0'
    task_vars['ansible_version_full'] = '2.9.0'
    task_vars['ansible_version_major'] = '2'
    task_vars['ansible_version_minor'] = '9'
    task_vars['ansible_version_revision'] = '0'
    task_vars['ansible_version_string'] = '2.9.0'

# Generated at 2022-06-17 08:28:11.325980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:28:12.382326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-17 08:28:21.630727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:28:22.009257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:28:27.099059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src
    module = ActionModule(dict(src=None, dest='/tmp/dest'))
    result = module.run(task_vars=dict())
    assert result['failed']

    # Test with no dest
    module = ActionModule(dict(src='/tmp/src', dest=None))
    result = module.run(task_vars=dict())
    assert result['failed']

    # Test with src not a directory
    module = ActionModule(dict(src='/tmp/src', dest='/tmp/dest'))
    result = module.run(task_vars=dict())
    assert result['failed']

    # Test with src a directory
    module = ActionModule(dict(src='/tmp', dest='/tmp/dest'))
    result = module.run(task_vars=dict())


# Generated at 2022-06-17 08:28:28.684271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 08:28:32.631262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Check if the instance created is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-17 08:28:43.320959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader)

    # Create a mock task_vars
    task_vars = {}

    # Run the method
    result = action_module.run(task_vars=task_vars)

    # Check the result
    assert result['changed'] == True
    assert result['msg'] == 'src changed'


# Generated at 2022-06-17 08:29:08.642006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._supports_check_mode == False
    assert action_module._supports_async == False
    assert action_module._supports_async_timeout == False
    assert action_module._supports_async_poll_delay == False
    assert action_module._supports_async_poll_interval == False
    assert action_module._supports_async_timeout_secs == False
    assert action_module._supports_become == False
    assert action_module._supports_become_method == False
    assert action_module._supports_become

# Generated at 2022-06-17 08:29:15.562396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()

    # Create a mock action module
    mock_action_module = ActionModule(mock_task, mock_connection, mock_play_context, mock_loader, mock_action_plugin)

    # Create a mock task vars
    mock_task_vars = dict()

    # Create a mock tmp
    mock_tmp = None

    # Create a mock src
    mock_src = None

    # Create a mock dest
    mock_dest = None

    # Create a mock

# Generated at 2022-06-17 08:29:17.423408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:29:30.777734
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:29:40.741014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(src='src', dest='dest', delimiter='delimiter', remote_src='remote_src', regexp='regexp', follow='follow', ignore_hidden='ignore_hidden', decrypt='decrypt')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module._task.args['src'] == 'src'
    assert action_module._task.args['dest'] == 'dest'
    assert action_module._task.args['delimiter'] == 'delimiter'
    assert action_module._task.args['remote_src'] == 'remote_src'

# Generated at 2022-06-17 08:29:46.080191
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:29:53.359903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes', 'regexp': 'regexp', 'delimiter': 'delimiter', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock shell
    shell = MockShell()

   

# Generated at 2022-06-17 08:30:04.915911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task

    # Create a mock connection
    connection = MockConnection()
    action_module._connection = connection

    # Create a mock loader
    loader = MockLoader()
    action_module._loader = loader

    # Create a mock play context
    play_context = MockPlayContext()
    action_module._play_context = play_context

    # Create a mock task v

# Generated at 2022-06-17 08:30:12.672462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='assemble', module_args=dict(src='src', dest='dest'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-17 08:30:23.119181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of AnsibleActionDone
    ansible_action_done = _AnsibleActionDone()

    # Create an instance of AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleAction

# Generated at 2022-06-17 08:30:58.169528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action base
    action_base = ActionBase(task, connection, play_context, loader, templar, action_plugin)

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, action_plugin)

    # Create a mock task vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

   

# Generated at 2022-06-17 08:31:10.300225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}

    # Create a mock connection
    connection = MockConnection()
    connection._shell = MockShell()
    connection._shell.tmpdir = 'tmpdir'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()
    play_context.diff = False

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader)

    # Test the run method
    result = action_plugin.run(task_vars=None)
    assert result['changed'] == False
    assert result['msg'] == 'src and dest are required'

    # Test the run

# Generated at 2022-06-17 08:31:10.872787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:11.987237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:31:15.191503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 08:31:27.085848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': 'yes'}

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock play context object
    play_context = MockPlayContext()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock action plugin object
    action_plugin = MockActionModule()

    # Create a mock action plugin object
    action_plugin._task = task
    action_plugin._connection = connection
    action_plugin._play_context = play_context
    action_plugin._loader = loader

    # Test the run method
    action_plugin.run(tmp=None, task_vars=None)

    # Test the run method with an exception

# Generated at 2022-06-17 08:31:34.852726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin.run(task, connection, play_context, loader)

    # Check if the method run of class ActionModule was called
    assert action_plugin.run_called == True


# Generated at 2022-06-17 08:31:38.045571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:31:39.692084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:31:50.234883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module is not None
    assert action_module._supports_check_mode is False
    assert action_module._supports_async is False
    assert action_module._supports_become is False
    assert action_module._supports_diff is False
    assert action_module._supports_subset is False
    assert action_module._supports_static is False
    assert action_module._supports_test is False
    assert action_module._supports_wait_for_connection is False
    assert action_module._supports_parallel is False
    assert action_module._supports_delegate_to is False
    assert action_module._supports_no_log is False
    assert action_module._supports_check_mode is False
   

# Generated at 2022-06-17 08:32:35.851839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with invalid parameters
    try:
        ActionModule(None, None, None, None, None)
        assert False
    except:
        assert True

    # Test with valid parameters
    try:
        ActionModule('test', 'test', 'test', 'test', 'test')
        assert True
    except:
        assert False

# Generated at 2022-06-17 08:32:47.015304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {'args': {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}})()
    # Create a mock connection
    mock_connection = type('MockConnection', (object,), {'_shell': type('MockShell', (object,), {'tmpdir': 'tmpdir', 'join_path': lambda self, a, b: os.path.join(a, b)})()})()
    # Create a mock play context

# Generated at 2022-06-17 08:32:50.708339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:32:52.174811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:32:52.959862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:32:53.980075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:32:56.366870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None)
    assert action_module is not None


# Generated at 2022-06-17 08:32:58.914590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:33:04.048500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(src='/tmp/src', dest='/tmp/dest')

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a new instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, action_plugin)

    # Test the run method
    action_module.run()

# Generated at 2022-06-17 08:33:04.666818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:34:36.155402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(src='src', dest='dest', delimiter='delimiter', remote_src='remote_src', regexp='regexp', follow='follow', ignore_hidden='ignore_hidden', decrypt='decrypt')

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock action plugin
    action_plugin = MockActionModule()

    # Create a mock action plugin
    action_plugin.connection = connection
    action_plugin.task = task
    action_plugin._play_context = play_context
    action_plugin._loader = loader

    # Test the run method
    action_plugin.run()

# Generated at 2022-06-17 08:34:39.963263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(None, None, None, None)
    assert action_module.TRANSFERS_FILES == True


# Generated at 2022-06-17 08:34:41.274224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:34:44.455484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 08:34:56.660483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock action module
    action_module = ActionModule()

    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task_vars
    task_vars = dict()

    # Set the action module's attributes
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context
    action_module._loader = loader
    action_module._templar = templar

    # Set the task's attributes

# Generated at 2022-06-17 08:34:57.268609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:35:03.645346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'delimiter': 'delimiter', 'remote_src': 'remote_src', 'regexp': 'regexp', 'follow': 'follow', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock task_vars
    task_vars = {}

    # Create a mock tmp
    tmp = None

    # Create a mock AnsibleActionFail
    AnsibleActionFail = Mock

# Generated at 2022-06-17 08:35:05.215895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:35:06.480517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:35:18.355627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am.TRANSFERS_FILES == True
    assert am._supports_check_mode == False
    assert am._task.args == {}
    assert am._task.action == 'assemble'
    assert am._task.action_plugin_name == 'assemble'
    assert am._task.action_plugin_type == 'action'
    assert am._task.action_plugin_load_name == 'assemble'
    assert am._task.action_plugin_load_type == 'action'
    assert am._task.action_plugin_class_name == 'ActionModule'
    assert am._task.action_plugin_class_type == 'action'
    assert am._task.action_plugin_class_load_name == 'ActionModule'
    assert am._task.action