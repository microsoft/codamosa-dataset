

# Generated at 2022-06-25 06:26:42.716918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '6^5|5"j*Y?(yL>|f$'
    set_0 = {str_0, str_0}

    dict_0 = dict()
    dict_0 = {'tmp': None, 'task_vars': dict_0}
    str_1 = '4Pf4G@:J/'
    float_0 = -919.03
    str_2 = 'XX[wH*i1'
    str_3 = 'LNu6^jU6'
    str_4 = '$|uY/F{5'
    float_1 = -80.9904
    str_5 = '`f?J&8aw'
    str_6 = ')'
    str_7 = 'S!_XtO+T'
    str_8

# Generated at 2022-06-25 06:26:45.464474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(action_args_0, action_invocation_0, action_options_0, action_plugin_dir_0, action_tmp_0, action_var_setup_0)
    action_module_0.run()

# Generated at 2022-06-25 06:26:54.772471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'D[v;8W\x0c9<Ip\\\rqtg'
    str_1 = 'wya'
    str_2 = '%[k]\x14'
    str_3 = 'R'
    str_4 = ']0\x0fg4x>#'
    str_5 = '\x1a\x1c\x11fn'
    str_6 = 'k/`5hQ(d|\x7f\x0c'
    str_7 = 'f'
    dict_0 = dict()
    dict_1 = dict()
    dict_1[str_6] = str_7
    dict_1[str_5] = str_2
    dict_1[str_4] = str_1

# Generated at 2022-06-25 06:27:04.915302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:27:15.672608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'vI|\x1d|_\x7f\x1fv!\x19\x1d\x19g'
    set_0 = {str_0, 'w\x1a\x1f\x01\x06\x13\x07\x0e\x1av\x03w\t.\x0e\x1e\x17\x1b\x1b\x1d\x19\x03r\r\r'}
    set_1 = {'#s\x15\x1d+\x08\x0e\x11\x0b\x1a\x1d\x1f\x1c\x0b\x03'}

# Generated at 2022-06-25 06:27:21.460217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'yj\x0c]{/v|Cr[,v>3qz'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 06:27:29.851309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    str_0 = 'X\x074\x1bk}y\x0c\x06]'
    str_1 = 'z!b\x17o%\x0cc\x14'
    str_2 = 'W\x1e\x17\x18\x08\x19\x04'
    str_3 = '\x0b\x03\x17\x06\x05\x1d'
    str_4 = '\x0b\x03\x17\x06\x05\x1d'
    str_5 = '\x0b\x03\x17\x06\x05\x1d'

# Generated at 2022-06-25 06:27:35.892313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'L:yT<w-0|M\x7f!>\x1d\x10t'
    set_0 = {str_0}
    str_1 = 'uV\x5f^9uV\x5f^'
    float_0 = 1.40129846E-45
    str_2 = 'mZ9'
    action_module_0 = ActionModule(str_2, set_0, set_0, str_1, float_0, str_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()

    test_ActionModule_run()

# Generated at 2022-06-25 06:27:41.821501
# Unit test for constructor of class ActionModule
def test_ActionModule():

    str_0 = 'ar\x0b~\r{+9:|\x0c\x0b'
    set_0 = {str_0, str_0}
    float_0 = -70.0
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)

    str_1 = 'Kj\x04=R5+\x12\x13\x10\x12\x1f'
    set_1 = {str_1, str_1}
    float_1 = -70.0
    action_module_0 = ActionModule(str_1, set_1, set_1, str_1, float_1, str_1)


# Generated at 2022-06-25 06:27:47.739356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`;{nRi8n|\x7fsa3q'
    str_1 = 'Z'
    dict_0 = {str_1:{'C9|\x7f\x0bYp~\x012x1u\x7fG\x0b'}}
    str_2 = '\\m'
    str_3 = 'Z'
    dict_1 = {str_3:{'P>y)d\x7f\x7fY0\x7f\x7f\x7fR\x7f\x7fS|>\x0b\\\x7f'}}
    str_4 = 'c\x7fs@/;\x7f0'
    float_0 = -0.565

# Generated at 2022-06-25 06:28:01.099425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:28:05.798795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except Exception as e_pytest_0:
        print ('Unhandled exception: ', e_pytest_0)


# Generated at 2022-06-25 06:28:13.557349
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    file_path = '/testfile'
    remote_file_path = '/testfile'
    remote_user = 'testuser'
    remote_group = 'testgroup'

# Generated at 2022-06-25 06:28:15.548792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    try:
        action_module_1.run()
    except NotImplementedError:
        pass

# Generated at 2022-06-25 06:28:20.677177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = False
    dest = False
    if src:
        # test case
        dest = dest
    else:
        raise Exception('src is required')


# Generated at 2022-06-25 06:28:21.568879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:28:29.223360
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:28:39.773060
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
    action_module = ActionModule()

# Generated at 2022-06-25 06:28:40.457074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:28:43.051001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("")
    print("Testing ActionModule.run()")

    print("")
    print("Test #1 (case 0)")
    action_module_0 = ActionModule()
    action_module_0.run()


# Execute the actions on the test cases

# Generated at 2022-06-25 06:29:13.530313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._supports_check_mode = False

    # Test template for variable tmp
    tmp = None
    tmp_expected_result = None
    assert tmp == tmp_expected_result
    # Test template for variable task_vars
    task_vars = None
    task_vars_expected_result = None
    assert task_vars == task_vars_expected_result

    action_module_0_run_expected_result = None
    action_module_0_run_result = action_module_0.run(tmp, task_vars)

    assert action_module_0_run_result == action_module_0_run_expected_result



# Generated at 2022-06-25 06:29:15.442658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    args = {}
    result = {}
    task_vars = {}

    result = action_module_0.run(args, task_vars)
    assert result is not None


# Generated at 2022-06-25 06:29:16.450017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 06:29:17.636799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:29:18.343513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:29:18.975941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()



# Generated at 2022-06-25 06:29:21.287207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, type(ActionModule))

# Generated at 2022-06-25 06:29:23.686139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:29:29.769229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    from collections import Mapping
    from ansible.errors import AnsibleError
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    if not PY3:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')

# Generated at 2022-06-25 06:29:35.545473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 is None


# Generated at 2022-06-25 06:30:01.027887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None
    assert action_module.TRANSFERS_FILES is not None


# Generated at 2022-06-25 06:30:01.556311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:30:09.188812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    # assert properties
    #assert action_module.BYPASS_HOST_LOOP == False
    assert action_module.NO_TARGET_SYSLOG == False
    assert action_module.BYPASS_PARSER == False
    #assert action_module.CONNECTION_PLUGIN_PATH == None
    assert action_module.NAME == 'assemble'
    #assert action_module.NEEDS_TMPPATH == True
    assert action_module.POLL_INTERVAL == 0
    assert action_module.SKIP_LOCKFILE == False
    assert action_module.TRANSFERS_FILES == True

# Generated at 2022-06-25 06:30:11.019361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module_1 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()
    print('Test completed')

# Generated at 2022-06-25 06:30:15.640232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# All tests pass
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:30:25.480040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # creating a temp dir and file
    with tempfile.TemporaryDirectory() as path:
        with tempfile.NamedTemporaryFile() as tmp_file:
            # Creating a task object and initialize its args
            task_args = {
                'src': path,
                'delimiter': '\n',
                'ignore_hidden': 'yes',
                'regexp': tmp_file.name.split('/')[-1],
                'dest': '/tmp/destination_directory',
                'remote_src': 'yes'
            }
            task_vars = {}
            task_loader = None
            play_context = None
            action_module_1 = ActionModule(task_args, task_vars, task_loader, play_context)
            # Assuming run() of module throws exception when os.path.isdir(

# Generated at 2022-06-25 06:30:28.844442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:29.807282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 06:30:34.643742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert hasattr(action_module_0, '_supports_check_mode')


# Generated at 2022-06-25 06:30:35.609035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule().run() is not None


# Generated at 2022-06-25 06:31:03.957280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test run')
    src = '/'
    remote_src = 'no'
    dest = '/'
    delimiter = None
    regexp = None
    follow = False
    ignore_hidden = False
    decrypt = True
    action_module_0 = ActionModule(src, remote_src, dest, delimiter, regexp, follow, ignore_hidden, decrypt)
    action_module_0.run()

# Generated at 2022-06-25 06:31:08.477132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make the following call for each unit test for ActionModule
    # action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    str_0 = 'yj\x0c]{/v|Cr[,]v>{3qz'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)

# Generated at 2022-06-25 06:31:14.198059
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:31:18.746321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str, set, set, str, float, str)
    tmp = None
    task_vars = None
    assert action_module_0.run(tmp, task_vars) == (True and False)


# Generated at 2022-06-25 06:31:24.024457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3;Li@{<J5^9(F0D\x7f2]z~'
    set_0 = {str_0, str_0}
    float_0 = 659.659
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 06:31:28.536729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ggE\\iC\tp@$Q9XqU4*M0\ttA'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    task_vars_0 = {str_0: set_0}
    action_module_0.run(task_vars=task_vars_0)


# Generated at 2022-06-25 06:31:37.283126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_1 = '<~\x7f\x1a?n\x15' # wrong length
    # str_1 = 'q3p\x05G\x1a,\x13\x07<\x0c' # wrong length
    set_1 = {str_1, str_1, str_1[:5]}
    bool_1 = False
    str_2 = '\x0e\x03i'
    float_1 = -1223.3796
    action_module_1 = ActionModule(str_2, set_1, set_1, bool_1, float_1, str_1)

# Generated at 2022-06-25 06:31:39.002801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _tmp = None
    task_vars = None
    action_module_0 = ActionModule(_tmp, task_vars)


# Generated at 2022-06-25 06:31:45.541760
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:31:55.416597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Task arguments StoreVariable(src='cmd',_raw_params='src',_task=task,_connection='connection',_play_context='play_context',_loader='loader',_templar='templar',_shared_loader_obj='shared_loader_obj')
    str_0 = 'cmd'
    # Task arguments StoreVariable(dest='register',_raw_params='dest',_task=task,_connection='connection',_play_context='play_context',_loader='loader',_templar='templar',_shared_loader_obj='shared_loader_obj')
    str_1 = 'register'
    # Task arguments StoreVariable(remote_src='no',_raw_params='remote_src',_task=task,_connection='connection',_play_context='play_context',_loader='loader',_templar='

# Generated at 2022-06-25 06:32:50.199088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'yj\x0c]{/v|Cr[,]v>{3qz' == "yj\x0c]{/v|Cr[,]v>{3qz"
    assert 'yj\x0c]{/v|Cr[,]v>{3qz' == "yj\x0c]{/v|Cr[,]v>{3qz"
    assert -486.165 == -486.165

# Generated at 2022-06-25 06:32:57.052540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'yj\x0c]{/v|Cr[,]v>{3qz'
    set_1 = {str_1, str_1}
    float_1 = -486.165
    action_module_1 = ActionModule(str_1, set_1, set_1, str_1, float_1, str_1)
    action_module_1.run()

if (__name__ == '__main__'):
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:33:04.625786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'yj\x0c]{/v|Cr[,]v>{3qz'
    set_1 = {str_1, str_1}
    float_1 = -486.165
    action_module_1 = ActionModule(str_1, set_1, set_1, str_1, float_1, str_1)
    assert action_module_1._supports_check_mode == False
    assert action_module_1._connection == str_1
    assert action_module_1._shell == set_1
    assert action_module_1._display == set_1
    assert action_module_1._loader == str_1
    assert action_module_1._play_context == float_1
    assert action_module_1._task == str_1


# Generated at 2022-06-25 06:33:12.811511
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:33:16.343445
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Check if method run exists
    action_module_0 = ActionModule('test_module', 'test_set', 'test_set', 'test_str', 0.0, 'test_str')
    hasattr(action_module_0, 'run')

    # Check if method run is callable
    callable(action_module_0.run())

# Generated at 2022-06-25 06:33:19.182934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    action_module_run_0 = action_module_0.run()


# Generated at 2022-06-25 06:33:21.461276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(ActionsError):
        pass
        #self.assertRaisesRegexp(ActionsError, '', self.action_module_0.run)

# Generated at 2022-06-25 06:33:23.482052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:33:31.048575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a\x02!k\x1d'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    action_module_0._supports_check_mode = False
    float_0 = -486.165
    float_1 = -486.165
    float_2 = -486.165
    float_3 = -486.165
    float_4 = -486.165
    float_5 = -486.165
    float_6 = -486.165
    float_7 = -486.165
    float_8 = -486.165
    float_9 = -486.165

# Generated at 2022-06-25 06:33:34.241796
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # setup necessary mocks
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:35:07.047399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0b)9*m5l8~^1f7\x0c0\x7f1rg\x06'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    var_0 = action_module_0.run()
    print(var_0)

if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 06:35:12.975893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'yj\x0c]{/v|Cr[,]v>{3qz'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:35:21.130026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'm7m@56\x02q3?&'
    set_0 = {str_0, str_0}
    float_0 = -486.165
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)

    # verification of instance variables

    assert type(action_module_0.name) is str

    assert type(action_module_0.connection) is Connection

    assert type(action_module_0.persistent_connection) is str

    assert type(action_module_0.only_if) is str

    assert type(action_module_0.until) is float

    assert type(action_module_0.async_val) is int

    
	


ACTION_REGISTRY = {}
ACTION

# Generated at 2022-06-25 06:35:28.470776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'G\t]4LK#\x05\x1aYz\x15'
    str_1 = 'f\x1d\x1f\x0bV9\x01\x04\x08'
    int_0 = -39514091
    str_2 = ''
    str_3 = '?\x1a\x1a_\\\x12\x03\x05'
    dict_0 = {
        '@' : int_0,
        'T' : str_0
    }
    set_0 = {str_1, str_2, str_3}
    float_0 = -2.723
    action_module_0 = ActionModule(str_0, set_0, set_0, str_0, float_0, str_0)

# Generated at 2022-06-25 06:35:30.215529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(test_case_0(), (ActionModule,))
    pass

# Generated at 2022-06-25 06:35:33.152585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('jr1\x04Rd{', {'o', '[;~g(`t.'}, {'I', '3', 'g\x0b'})
    assert isinstance(action_module_0, ActionModule) == True

# Generated at 2022-06-25 06:35:39.508033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0b/\x09<,\tP'
    set_0 = {str_0, '\x0b/\x09<,\tP'}
    set_1 = set_0
    str_1 = '\x0b/\x09<,\tP'
    float_0 = 0.929
    str_2 = '\x0b/\x09<,\tP'
    action_module_0 = ActionModule(str_0, set_0, set_1, str_1, float_0, str_2)
    var_0 = action_run()


# Generated at 2022-06-25 06:35:46.805958
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:35:47.837478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:35:50.561234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule), "TypeError: %r is not an instance of %r" % (action_module_0, ActionModule)
