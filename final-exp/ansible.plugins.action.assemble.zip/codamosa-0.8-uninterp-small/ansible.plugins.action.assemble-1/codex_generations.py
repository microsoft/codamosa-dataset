

# Generated at 2022-06-25 06:26:41.126882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 17
    str_0 = 'y1'
    float_0 = 511.903733
    list_0 = [str_0, int_0]
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_0, int_0)
    tmp = None
    task_vars = None
    (actual_result, result) = action_module_0.run(tmp, task_vars)
    assert result == actual_result
    print('PASSED: ' + str(result))


# Generated at 2022-06-25 06:26:45.674112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 17
    str_0 = 'hj8'
    float_0 = 840.632788
    list_0 = [int_0, str_0]
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_0, int_0)
    tmp = 'm1'
    task_vars = {}
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:26:46.914921
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    print(action_module_0)


# Generated at 2022-06-25 06:26:53.423576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    str_0 = 'y1'
    float_0 = 511.903733
    list_0 = [str_0, int_0]
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_0, int_0)
    action_module_0.run()

test_ActionModule_run()

# Generated at 2022-06-25 06:27:03.412084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    str_0 = 'y1'
    float_0 = 511.903733
    list_0 = [str_0, int_0]
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_0, int_0)
    assert abs((action_module_0.name) - (int_0)) <= 1e-06
    assert abs((action_module_0._play_context) - (float_0)) <= 1e-06
    assert abs((action_module_0._task) - (list_0)) <= 1e-06
    assert abs((action_module_0._connection) - (str_0)) <= 1e-06


# Generated at 2022-06-25 06:27:07.884937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    str_0 = 'y1'
    float_0 = 511.903733
    list_0 = [str_0, int_0]
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_0, int_0)
    action_module_0._task.args = {'src': '9qs0njbkyr', 'dest': 'ocrmdsyb6w'}

    # Call method run
    action_module_0.run()

# Generated at 2022-06-25 06:27:16.820784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r=f]b$rfT|3qE='
    int_0 = -3092
    list_0 = ['n|vw2', '\',l', '8X']
    str_1 = '#U6I'
    int_1 = -15
    float_0 = 933.9
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_1, int_1)

    # Test case for non-default src
    tmp_1 = None
    task_vars_1 = {'src': ''}
    action_module_0.run(tmp_1, task_vars_1)

    # Test case for non-default dest
    tmp_2 = None

# Generated at 2022-06-25 06:27:20.804250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Variables to test constructor of class ActionModule
    int_0 = 15
    str_0 = 'y1'
    float_0 = 511.903733

    list_0 = [str_0, int_0]
    test_case_0()


# Generated at 2022-06-25 06:27:29.474426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with invalid parameters
    try:
        action_module_1 = ActionModule(1,1,1,1,1,1,1)
    except Exception as e:
        assert "TypeError" in str(e)

    # Test with valid parameters
    action_module_2 = ActionModule(1,'_ansible_tmp',1.1,[1,1],1,1)
    # test for properties
    assert action_module_2._uses_shell == True
    assert action_module_2._supports_check_mode == False
    assert action_module_2._uses_delegate_to == False
    assert action_module_2._uses_become == False

    # test for methods

# Generated at 2022-06-25 06:27:33.048063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    str_0 = 'y1'
    float_0 = 511.903733
    list_0 = [str_0, int_0]
    action_module_0 = ActionModule(int_0, str_0, float_0, list_0, str_0, int_0)



# Generated at 2022-06-25 06:27:46.826272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    try:
        action_module_1.run()
    except Exception as err:
        print(err)



# Generated at 2022-06-25 06:27:47.594097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:27:52.651633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Test 1
    print('Test 1')

    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)

    # Test 2
    print('Test 2')

    task_vars = {'var_name': 'value'}
    result = action_module.run(tmp, task_vars)

    # Test 3
    print('Test 3')

    tmp = 'tmp_value'
    task_vars = {'var_name': 'value'}
    result = action_module.run(tmp, task_vars)

# Task variables unit test

# Generated at 2022-06-25 06:27:56.587082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = print(action_module_0)


# Generated at 2022-06-25 06:27:57.897386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = print(action_module_0)


# Generated at 2022-06-25 06:28:01.250704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if case 0 is working
    test_case_0()
    return None

# Generated at 2022-06-25 06:28:02.670219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = print(action_module_0)


# Generated at 2022-06-25 06:28:08.121604
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Run ActionModule.__init__()
    action_module_0 = ActionModule()

    # Check if attribute _supports_check_mode has the
    # type 'bool'
    assert(isinstance(action_module_0._supports_check_mode, bool))

    # Check if attribute _supports_check_mode is set to
    # the value 'False'
    assert(action_module_0._supports_check_mode == False)



# Generated at 2022-06-25 06:28:12.201219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 is None
    assert var_0 == None
    var_1 = action_module_0.run(tmp=None)
    assert var_1 is None
    assert var_1 == None
    var_2 = action_module_0.run(task_vars=None)
    assert var_2 is None
    assert var_2 == None


# Generated at 2022-06-25 06:28:14.499108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert type(action_module_1) == ActionModule
    # assert action_module_1.run() == True

#Unit test for run method

# Generated at 2022-06-25 06:28:29.419260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    case_0 = test_case_0()


# ______________________________________________________________________________

# Generated at 2022-06-25 06:28:38.952020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(module_name='setup', module_args='{}', inject=None)
    action.connection = Connection(module_name='setup', module_args='{}', inject=None)
    tmp = None
    task_vars = dict()
    expected_result_0 = dict()

    result_0 = action.run(tmp, task_vars)
    if result_0 != expected_result_0:
        error_message = f'ActionModule.run() returned {result_0}, expected {expected_result_0}.'
        error_message += f'\n{result_0}'
        raise AssertionError(error_message)


# Generated at 2022-06-25 06:28:41.686088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_0 = ActionModule(var_0)

    test_case_0()

# Generated at 2022-06-25 06:28:47.696432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None


# Generated at 2022-06-25 06:28:58.542732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Scripts input
test_case_0.ans_input = {
    'src': '',
    'dest': '',
    'delimiter': '',
    'remote_src': '',
    'regexp': '',
    'follow': '',
    'ignore_hidden': '',
    'decrypt': '',
}


# Generated at 2022-06-25 06:29:00.752448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    # test case 0

    try:
        raise AnsibleActionFail(u"Source (None) is not a directory")
    except AnsibleActionFail as e:
        print(e)
        assert True

# Generated at 2022-06-25 06:29:04.704038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No code to test.
    return


# Generated at 2022-06-25 06:29:07.760028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_0 = ActionModule()
    var_0.run()


# Generated at 2022-06-25 06:29:16.767904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None

    test_case_0()
    ansible_collector_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    test_case_0()
    test_case_0()

    assert_equal(ansible_collector_0.run(var_0, var_1), var_8)
    assert_equal(ansible_collector_0.run(var_0, var_1), var_9)

# Unit test

# Generated at 2022-06-25 06:29:22.112269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = None

    var_0 = ActionModule()
    var_2 = var_0.run()

    assert(var_2 == None)


# Generated at 2022-06-25 06:29:44.413224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -51.765092
    set_0 = {float_0, float_0, float_0}
    int_0 = -71038
    bool_0 = True
    bytes_0 = b'\x12\x11\xc4\xdd\x02#\xb5\xf1\x0e\xf73\xfb\xac\x9e\x17\x08\xe7\xf2\x8e\x1cu\x81\x15\xdb\xc9p\xfa\x9bF\x08\xa8\x97\x10\xbb'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]

# Generated at 2022-06-25 06:29:45.047913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 06:29:51.415825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 324.821
    set_0 = {float_0}
    list_0 = [set_0, set_0]
    int_0 = -89
    tuple_0 = (list_0, list_0)
    str_0 = '\x13\x17\x0c\x07\x1f\x1c\x1b\x0b\x02'
    float_1 = -3368.89
    set_1 = {str_0}
    int_1 = 0
    bool_0 = False
    action_module_0 = ActionModule(int_0, bool_0, int_1, list_0, int_0, str_0)

# Generated at 2022-06-25 06:29:59.419139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_module_0.run(set_0)
    tuple_0 = ()

# Generated at 2022-06-25 06:30:07.079793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {False, False, False}
    int_0 = -3710
    bool_0 = True
    bytes_0 = b'\xd2\xc0\xdb\x95\x90\x01;\x01\x99\xa9\xa5\x0b\xd5\x15\xaa\xf4\x17'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'x'
    str_1 = '%s %s not found in:\n%s\n'
    float_0 = 2177.02
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    dict_0 = {}
    tuple_0 = ()

# Generated at 2022-06-25 06:30:14.941392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = action_run(dict_0)
    action_module_0 = ActionModule(var_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    assert action_module_0.module_name == 'ansible.legacy.file'
    dict_1 = {'\x06\x08\x9e': '\x04\x18\xc4', '\t\x12': '\x08\v\x07\x8e\x0c\x14\xf2', '\x03\x0c\x14': '\x05\x09\x0c\x1b\xe3\xdb\x8d\x15'}

# Generated at 2022-06-25 06:30:24.623129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_run(set_0)
    tuple_0 = ()
    float_1 = -2377.

# Generated at 2022-06-25 06:30:34.110220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3426
    bool_0 = False
    int_1 = -3675
    list_0 = [int_0, bool_0, int_1]
    int_2 = -3797
    str_0 = 'H\x85x\xae\x94\x02\xde^\xfe\xbb\xadF\x8b\x80\x1a'
    action_module_0 = ActionModule(int_0, bool_0, int_2, list_0, int_1, str_0)
    bool_1 = True
    set_0 = {bool_1, bool_1, bool_1}
    action_module_0.run(set_0)
    tuple_0 = (21, bool_1, action_module_0)

# Generated at 2022-06-25 06:30:39.893088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_run(set_0)
    tuple_0 = ()
    float_1 = -2377.

# Generated at 2022-06-25 06:30:49.888692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {-3610.864347, -3610.864347, -3610.864347}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)


# Generated at 2022-06-25 06:31:20.157094
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert len(ActionModule.__actions__) == 3
  assert 'setup' in ActionModule.__actions__
  assert 'delegate_to' in ActionModule.__actions__
  assert ActionModule.__actions__['delegate_to']['args'] is True
  assert len(ActionModule.__actions__['delegate_to']['default']) == 3
  assert 'remote_user' in ActionModule.__actions__['delegate_to']['default']
  assert 'no_log' in ActionModule.__actions__['delegate_to']['default']
  assert 'transport' in ActionModule.__actions__['delegate_to']['default']
  assert ActionModule.__actions__['delegate_to']['default']['remote_user'] == 'root'
  assert ActionModule.__actions__

# Generated at 2022-06-25 06:31:27.695865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3358.5768
    set_0 = {float_0, float_0, float_0}
    int_0 = -1520
    bool_0 = False
    bytes_0 = b'\xcf\'\x12\x14\x0b\x0b\x04\t\x12\xeb\xcb\xbc\xcbK\xcb[\xac\xb2\xd1'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]

# Generated at 2022-06-25 06:31:30.508241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -2377.1229
    dict_0 = {}
    set_0 = {float_1, float_1, float_1}
    int_0 = 3212
    action_module_0 = ActionModule(int_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    var_0 = action_run(set_0)


# Generated at 2022-06-25 06:31:40.069342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    action_run(set_0)
    tuple_0 = ()
    float_1 = -2377.1229
   

# Generated at 2022-06-25 06:31:44.335036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)

    var_0 = test_0(set_0)
    tuple_0 = ()
    float_1 = -2377.

# Generated at 2022-06-25 06:31:51.685239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1264
    bool_0 = False
    int_1 = -2720
    list_0 = [int_0, bool_0]
    int_2 = -3300
    str_0 = '7<d\xcd\x8f\xc0\x83\x9f\x92\x8a\x8c\x7f\x99,\x8e\xc0\x9d\x9e'
    action_module_0 = ActionModule(int_0, bool_0, int_1, list_0, int_2, str_0)
    float_0 = -2425.96
    set_0 = {float_0, float_0}
    action_module_0.run(set_0)


# Generated at 2022-06-25 06:31:52.839909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:31:58.741618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments = {'dest': 'v]}_w^uV7pm\x03\x19',
                 'src': 'KMn\n\x1f\x1a\x1fQ'}
    action = ActionModule(id=1, action=2, args=arguments,
                          condensed=3, task=4, task_vars=5,
                          loader=6, templar=7, shared_loader_obj=8)
    action.task_vars = {'vars': {'x': 'X'}}

    # Test the default value of the 'remote_src' argument
    assert action.run()['msg'].startswith(
            'Using module file')

# Generated at 2022-06-25 06:32:02.826229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = object()
    bool_0 = object()
    int_1 = object()
    list_0 = object()
    int_2 = object()
    str_0 = object()
    action_module_0 = ActionModule(int_0, bool_0, int_1, list_0, int_2, str_0)
    set_0 = {int_2, int_1, int_0}
    action_module_0.run(set_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:32:12.592958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1881.54
    dict_0 = {}
    action_module_0 = ActionModule(float_0, dict_0)
    var_0 = action_run(dict_0)
    list_0 = [var_0]
    var_1 = action_run(list_0)
    dict_1 = {}
    action_module_1 = ActionModule(list_0, dict_1)
    tuple_0 = ()
    action_module_2 = ActionModule(list_0, dict_1, tuple_0)
    var_2 = action_run(tuple_0)
    str_0 = '~,%s,%s,%s,%s,%s,%s'
    list_1 = [var_2]
    dict_0['src'] = list_1
    action_

# Generated at 2022-06-25 06:32:59.898227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    func, __ = test_case_0()
    try:
        func(__)
    except ValueError:
        __.good('Good')
    except TypeError:
        __.bad('Bad')
    finally:
        __.done()


# Generated at 2022-06-25 06:33:08.608748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_module_0.run(set_0)
    tuple_0 = ()

# Generated at 2022-06-25 06:33:16.695743
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:33:26.436593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_3 = -8.18
    int_1 = -9710
    bool_1 = True
    bytes_2 = b'\x04\xa6\xcf\xd4\x03\xf3\xa4o'
    list_1 = [float_3, int_1, bool_1, bytes_2]
    int_2 = -219
    str_2 = 'k5%c\x8dRU\x08g'
    action_module_3 = ActionModule(int_2, bool_1, int_2, list_1, int_2, str_2)
    action_module_3.run(task_vars=action_module_3.task_vars)
    float_4 = -11.742
    int_3 = -3890
    bool_2 = False
   

# Generated at 2022-06-25 06:33:36.780769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    tuple_0 = ()
    float_1 = -2377.1229
    dict_0 = {}
    action_module

# Generated at 2022-06-25 06:33:45.554953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2726.3619
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_run(set_0)
    tuple_0 = ()
    float_1 = -2377.

# Generated at 2022-06-25 06:33:50.536301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.9379054569562467
    tuple_0 = (float_0,)
    action_module_0 = ActionModule(tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:33:59.046499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=unused-variable
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_run(set_0)
    tuple_

# Generated at 2022-06-25 06:33:59.820672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 06:34:06.435725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_2 = -2377.1229
    set_1 = {float_2, float_2, float_2}
    int_1 = 3212
    bool_1 = False
    bytes_2 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_1 = [int_1, bool_1, bytes_2, bytes_2]
    str_2 = 'zg]U\n'
    action_module_3 = ActionModule(int_1, bool_1, int_1, list_1, int_1, str_2)
    var_2 = action_run(set_1)
    tuple_1 = ()
    float_3 = -2377.

# Generated at 2022-06-25 06:35:35.642898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0, 0, 0, None, 0, None)
    var_0 = action_run(action_module_0)


# Generated at 2022-06-25 06:35:43.217341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    tuple_0 = ()
    float_1 = -2377.1229
    dict_0 = {}
    action_module

# Generated at 2022-06-25 06:35:50.650251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_3 = ActionModule(float_0)
    except TypeError as e:
        print(e)
    try:
        action_module_4 = ActionModule(float_0, str_1)
    except TypeError as e:
        print(e)
    try:
        action_module_5 = ActionModule(float_0, str_1, action_module_1)
    except TypeError as e:
        print(e)
    try:
        action_module_6 = ActionModule(float_0, str_1, action_module_1, int_1)
    except TypeError as e:
        print(e)

# Generated at 2022-06-25 06:35:52.318188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:35:57.104255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 31.6477
    str_0 = '\\'
    int_0 = -162
    set_0 = {float_0, float_0, float_0}
    action_module_0 = ActionModule(int_0, str_0, int_0, set_0, int_0, str_0)
    action_module_0.run(set_0)


# Generated at 2022-06-25 06:36:03.538902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 0.247808
    set_0 = {float_1, float_1, float_1}
    int_0 = 6282
    bool_0 = False
    bytes_0 = b'\xd4\xf4\x1b\x85\xa7\x86\xa1\\$\xbb\x1f\xba\x8d\x85\xd2F\xe2\xa6'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_1 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)


# Generated at 2022-06-25 06:36:11.822398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3610.864347
    set_0 = {float_0, float_0, float_0}
    int_0 = 3212
    bool_0 = False
    bytes_0 = b'\xc7\\\xb1\xb0\x0bo\x0f$r\xcb\xcc\xd9K\x88;S\x9c\xaf'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = 'zg]U\n'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_run(set_0)
    tuple_0 = ()
    float_1 = -2377.

# Generated at 2022-06-25 06:36:19.089064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2549.939
    set_0 = {float_0, float_0, float_0}
    int_0 = 3598
    bool_0 = True
    bytes_0 = b'#\xee\x1c\xc1\x82\xec\xa6\x87\xb8\xac\x89\x81\x87\x84\xc6\xd1\xcc\x9b'
    list_0 = [int_0, bool_0, bytes_0, bytes_0]
    str_0 = '0Y+\x0e'
    action_module_0 = ActionModule(int_0, bool_0, int_0, list_0, int_0, str_0)
    var_0 = action_run(set_0)
    tuple_