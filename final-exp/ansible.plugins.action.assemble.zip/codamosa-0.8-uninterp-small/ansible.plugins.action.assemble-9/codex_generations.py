

# Generated at 2022-06-25 06:26:38.320764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:26:40.403012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check if the constructor of class ActionModule is working correctly
    test_case_0()
    # No exception was thrown
    assert True

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:26:44.271189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    float_0 = 0.001
    action_module_0 = ActionModule(bool_0, list_0, dict_0, float_0, dict_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:26:50.626719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    float_0 = 0.001
    action_module_0 = ActionModule(bool_0, list_0, dict_0, float_0, dict_0, float_0)


# Generated at 2022-06-25 06:26:51.379674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:26:58.408804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    float_0 = 0.001
    action_module_0 = ActionModule(bool_0, list_0, dict_0, float_0, dict_0, float_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:27:05.325856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    float_0 = 0.001
    action_module_0 = ActionModule(bool_0, list_0, dict_0, float_0, dict_0, float_0)
    action_module_0.run(bool_0, list_0)

if __name__ == '__main__':
    #test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:27:13.538712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test: run")
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    float_0 = 0.001
    action_module_0 = ActionModule(bool_0, list_0, dict_0, float_0, dict_0, float_0)
    action_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 06:27:20.041754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    float_0 = 0.001
    action_module_0 = ActionModule(bool_0, list_0, dict_0, float_0, dict_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:27:27.309860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(False, [], {}, 0.0, {}, 0.0)
    assert False == action_module_0._supports_check_mode
    assert [] == action_module_0._task.args
    assert {} == action_module_0._task.action
    assert 0.0 == action_module_0._task.loop
    assert {} == action_module_0._task.loop_args
    assert 0.0 == action_module_0._task.loop_control
    action_module_0.run()
    action_module_0._remove_tmp_path()


# Generated at 2022-06-25 06:27:41.161492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(test_case_0(), ActionModule)


# Generated at 2022-06-25 06:27:45.270094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:46.594525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:27:52.514126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)


if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:27:59.034938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, True, True)
    action_module_0.set_loader(None)
    action_module_0.set_connection(None)
    action_module_0.set_play_context(None)

    # Test cases
    task_vars = {}
    tmp = None
    result = action_module_0.run(tmp, task_vars)
    assert result is not None
    assert 'warning' in result

# Generated at 2022-06-25 06:28:00.682518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-25 06:28:05.766942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    tmp = None
    task_vars = None
    ret = action_module_0.run(tmp, task_vars)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:14.488751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest_0 = "mURoD/gGCkJ|82/fY/H>\x0bJ%`]#N5}[H^d]z&\"Mg@\x0f*kYtVP_58t"
    regexp_0 = None
    src_0 = "Bb{#\rhiZJv*Gn!uCn=xVxqWyXvhE7m:`"
    delimiter_0 = None
    remote_src_0 = "yes"
    task_vars_0 = {}
    follow_0 = False
    ignore_hidden_0 = False
    decrypt_0 = True
    tmp_0 = None
    action_module_0 = ActionModule(follow_0, ignore_hidden_0, decrypt_0, tmp_0, False, True)

# Generated at 2022-06-25 06:28:19.600222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    action_module_1 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    dict_0 = {
        'changed': False,
        'failed': False,
        'rc': 0,
        'warnings': [],
    }
    assert(action_module_0.run({}, False) == dict_0)

if __name__ == "__main__":
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:28:22.463416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    dest = 'Destination'
    action_module = ActionModule(False, task_vars, dest, False)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 06:28:36.601277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule()
    b = ActionModule()
    result = b.run()
    assert(result == {})
    print (result)


# Generated at 2022-06-25 06:28:43.630725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock object
    class MockConnection(object):
        def _shell(self):
            pass

        def _remote_expand_user(self, dest):
            return dest

        def _execute_remote_stat(self, dest, all_vars=None, follow=None):
            return {'checksum': 'abcd'}

        def tmpdir(self):
            return ''

    class MockTask(object):
        def __init__(self):
            self.args = {'src': '', 'dest': '/etc/passwd'}

    class MockPlayContext(object):
        def __init__(self):
            self.diff = False

    task = MockTask()
    connection = MockConnection()
    play_context = MockPlayContext()

# Generated at 2022-06-25 06:28:48.951599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    arg_2 = {'mtime_regex': 'mtime_regex', 'mtime_format': 'mtime_format', 'acl': 'acl', 'delimiter': 'delimiter', 'dest': 'dest', 'attributes': 'attributes', 'selinux_permissive': 'selinux_permissive', 'mime_type': 'mime_type', 'remote_src': 'remote_src', 'owner': 'owner', 'regexp': 'regexp', 'follow': 'follow', 'src': 'src', 'ignore_hidden': 'ignore_hidden', 'decrypt': 'decrypt', 'group': 'group', 'mode': 'mode', 'state': 'state'}
    bool_2 = True
    bool_1 = False

# Generated at 2022-06-25 06:28:51.962392
# Unit test for constructor of class ActionModule
def test_ActionModule():

    new_instance = ActionModule()
    assert new_instance is not None
    assert isinstance(new_instance, ActionModule)



# Generated at 2022-06-25 06:28:55.041557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass # FIXME


# Generated at 2022-06-25 06:28:57.322440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test case is not yet implemented.
    assert False == True


# Generated at 2022-06-25 06:28:58.605655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    object_0 = ActionModule()
    assert object_0 != None


# Generated at 2022-06-25 06:29:01.156704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule.TRANSFERS_FILES==True)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:29:05.796686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print(err)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:29:08.371852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor: ActionModule(self, task, connection, play_context, loader, templar, shared_loader_obj)
    pass



# Generated at 2022-06-25 06:29:26.547519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


test_case_0()

# Generated at 2022-06-25 06:29:33.529274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    # Check method _assemble_from_fragments exists
    action_module_0._assemble_from_fragments()
    # Check method run exists
    action_module_0.run()

# Generated at 2022-06-25 06:29:44.360469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x17\x1dH$+'
    str_1 = 'e\x1b-xO]'
    str_2 = '='
    list_0 = [str_1, str_2]
    bytes_0 = b'\x12\x14\x04\x01\x1c\x03\x1e\x1f'
    str_3 = 'G&\x14'
    str_4 = '\x01\n\x1bI\x13\x14s'
    str_5 = '\x05\x1a\x1fh\x0b'
    str_6 = '\x1c\x1e\x02\x14\x03\x14\x10\x0f\x1c\x1b'
   

# Generated at 2022-06-25 06:29:48.102213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'x\rCv0Z_b*'
    str_2 = '+O\\T\x0bVC\n,c{V]NP'
    str_3 = 'AO\n&nH'
    list_0 = [str_3, str_1]
    bytes_1 = b''
    action_module_0 = ActionModule(str_1, str_2, str_1, str_3, list_0, bytes_1)


# Generated at 2022-06-25 06:29:58.474420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'V\x0b#\x1d'
    str_1 = 'c%\x18'
    str_2 = 'bY\r,'
    list_0 = ['\x0e', '\x1d', '\x0e', '\x0e', '\x1d']
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    str_3 = 'x\rCv0Z_b*'
    str_4 = '+O\\T\x0bVC\n,c{V]NP'
    str_5 = 'AO\n&nH'
    list_1 = [str_5, str_3]
    bytes_1

# Generated at 2022-06-25 06:30:05.924499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
# end of class ActionModule

# Generated at 2022-06-25 06:30:14.026762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test run...')
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    var_0 = action_module_0.run()
    assert(1 == len(var_0))
    assert(var_0['failed'] == False)
    print('Test done...')

# Generated at 2022-06-25 06:30:19.821088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    var_0 = action_module_0.test_case_0()
    return var_0

test_ActionModule()

# Generated at 2022-06-25 06:30:25.579858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


# Generated at 2022-06-25 06:30:30.688804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    var_0 = action_run()

dict_1 = {}
str_0 = 'x\rCv0Z_b*'
str_1 = '+O\\T\x0bVC\n,c{V]NP'
str_2 = 'AO\n&nH'
list_0 = [str_2, str_0]
bytes_0 = b''
action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
if (__name__ == '__main__'):
    test_case_0()

# Generated at 2022-06-25 06:31:01.100528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'x\rCv0Z_b*'
    str_3 = '{Nt3'
    list_0 = [str_0]

# Generated at 2022-06-25 06:31:09.223534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S&\\[\x0cIa6'
    str_1 = ';`U6'
    str_2 = '1[2>!C|\x7f]Pnq'
    list_0 = [str_1, str_1]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_2, str_2, list_0, bytes_0)
    # The 'dest_stat' variable is not referenced anywhere in the method body,
    # so setting it to anything will not affect the method output.
    var_0 = action_run(str_2)
    var_1 = action_run(str_1)
    var_2 = action_run(str_2)

# Generated at 2022-06-25 06:31:14.117973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "v`|W`0$"
    str_1 = "|^#)/}I"
    str_2 = "L\x17z\x19.6U[\x0b"
    str_3 = "Q2)O\x0eCqT"
    list_0 = [str_1, str_1, str_1]
    bytes_0 = b"\x07"
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, list_0, bytes_0)
    action_module_0.run()
    print("Test Done")


# Generated at 2022-06-25 06:31:18.529522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 06:31:26.770343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


# Generated at 2022-06-25 06:31:35.443009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'I'
    str_1 = '0\x0c\x1f'
    str_2 = 'D9S\x07(*\x19L2d\x1c'
    str_3 = '\x17p\x06g9j\x19\\\n'
    list_0 = [str_2, str_1]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, list_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:31:46.116454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '\n'
    str_2 = 'r'
    str_3 = 'A'
    str_4 = 'A'
    str_5 = '\n'
    str_6 = 'O\x1c'
    str_7 = '\x1d'
    list_1 = [str_6, str_2, str_6]
    bytes_1 = b'\x0e'
    action_module_1 = ActionModule(str_1, str_2, str_3, str_4, list_1, bytes_1)
    action_module_1.run()
    str_8 = '['
    str_9 = '4'
    str_10 = 'W*'
    str_11 = '~L'

# Generated at 2022-06-25 06:31:46.581535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-25 06:31:49.863799
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test fixture
    # Create a class instance with valid arguments
    action_module_0 = ActionModule('file', 'action', 'ansible.builtin.copy', 'ansible.builtin.wait_for', 'ansible.builtin.pause', 'M\xffm\x10\x10\x14\xad\x14\x1d')

# Generated at 2022-06-25 06:31:51.569270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(False, False, False, False, False, False)
    assert action_module_0.__init__(False, False, False, False, False, False)


# Generated at 2022-06-25 06:32:43.287512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    # Assume that the constructor for ActionModule has been called and assign the parameters
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
# Check if the action_module_0 is of type ActionModule
    if isinstance(action_module_0, ActionModule):
        var_0 = action_run()


# Generated at 2022-06-25 06:32:49.375095
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'x\rCv0Z_b*'
  str_1 = '+O\\T\x0bVC\n,c{V]NP'
  str_2 = 'AO\n&nH'
  list_0 = [str_2, str_0]
  bytes_0 = b''
  action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


# Generated at 2022-06-25 06:32:56.509266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


# Generated at 2022-06-25 06:32:57.735128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run() == True

exec(test_ActionModule_run())

# Generated at 2022-06-25 06:33:04.139794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1d'
    str_1 = 'W\x1c\x11!Y\x14'
    str_2 = '\x1cG\x02\x1d'
    list_0 = [str_0, str_1, str_2]
    bytes_0 = b'\x1c'
    action_module_0 = ActionModule(str_0, str_1, str_2, str_2, list_0, bytes_0)
    var_0 = action_module_0._loader.get_real_file
    assert var_0 == action_module_run(var_0, str_1)


# Generated at 2022-06-25 06:33:08.549674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    assert ActionModule(str_0, str_0, str_2, str_1, list_0, bytes_0)

# Generated at 2022-06-25 06:33:16.664483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Kw-\x0e'
    str_1 = '\x0c\x0b6\x1c\x1b,n\x0f'
    str_2 = 'M\x0c8'
    list_0 = [str_0, str_1]
    bytes_0 = b'\x1b\x1f'
    action_module_0 = ActionModule(str_0, str_2, str_2, str_1, list_0, bytes_0)
    str_3 = 'R\x1b\x18\x0e\x09'
    task_vars_0 = dict(list_0, **{str_3: str_1})
    action_module_0.run(None, task_vars_0)


# Generated at 2022-06-25 06:33:26.436864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Declare variables
    str_0 = 'path'
    str_1 = 'x\rCv0Z_b*'
    str_2 = '+O\\T\x0bVC\n,c{V]NP'
    str_3 = 'ZkpN'
    str_4 = 'AO\n&nH'
    list_0 = [str_4, str_1]
    bytes_0 = b''

    # Call constructor
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, list_0, bytes_0)

    # Generate a Variable object
    var_0 = Variable('ZkpN')

    # Check that action_module_0 is not None

# Generated at 2022-06-25 06:33:34.988659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


# Generated at 2022-06-25 06:33:39.688077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 06:35:15.259674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'O'
    str_1 = 't'
    str_2 = '%'
    str_3 = '*'
    list_0 = [str_3, str_3]
    bytes_0 = b''
    action_module_0 = ActionModule(str_1, str_2, str_1, str_2, list_0, bytes_0)
    # assert action_module_0.run(None, None) is None
    print("test done")
test_ActionModule_run()

if __name__ == '__main__':
    print("test begin")
    test_case_0()

# Generated at 2022-06-25 06:35:20.767560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:35:28.225553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'x\rCv0Z_b*'
    var_1 = '+O\\T\x0bVC\n,c{V]NP'
    var_2 = 'AO\n&nH'
    var_3 = [var_2, var_0]
    var_4 = b''
    var_5 = ActionModule(var_0, var_1, var_0, var_2, var_3, var_4)
    var_6 = None
    var_7 = None
    var_8 = var_5._ActionModule_run(var_6, var_7)
    # var_8 == {'msg': 'src and dest are required', 'failed': True, 'rc': 1}
    var_9 = 'x\rCv0Z_b*'
    var

# Generated at 2022-06-25 06:35:29.840435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True is True


# Generated at 2022-06-25 06:35:37.721864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'k\x7f\x1d\x7f\x14F\x7f\x04\x7f\x0c'
    str_1 = '\\K\x7f\x1c\x7f\t\x7f\x0e\x7f\x04\x7f\x1d'
    str_2 = '\x04\x7f\x16\x7f\x11\x7f\x17'
    str_3 = '\x16\x7f\x12\x7f\n\x7f\r\x7f\x1c'
    list_0 = [str_1]

# Generated at 2022-06-25 06:35:42.542390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)


# Generated at 2022-06-25 06:35:46.948362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)



# Generated at 2022-06-25 06:35:55.665381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing method run of class ActionModule')
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, bytes_0)
    var_0 = action_run()
    assert int(var_0) == -1, 'AssertionError: {} != -1'.format(var_0)

if __name__ == '__main__':
    test_case_0()

    test_ActionModule_run()

# Generated at 2022-06-25 06:36:02.701258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'x\rCv0Z_b*'
    str_1 = '+O\\T\x0bVC\n,c{V]NP'
    str_2 = 'AO\n&nH'
    list_0 = [str_2, str_0]
    action_module_0 = ActionModule(str_0, str_1, str_0, str_2, list_0, list_0)
    assert not hasattr(action_module_0, 'list_0')
    assert not hasattr(action_module_0, 'list_1')
    list_0 = [str_2, str_0]
    action_module_1 = ActionModule()
    assert not hasattr(action_module_1, 'bool_0')

# Generated at 2022-06-25 06:36:03.157111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass