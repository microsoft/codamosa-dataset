

# Generated at 2022-06-25 06:26:40.466222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -500.87
    list_0 = [float_0]
    complex_0 = None
    action_module_0 = ActionModule(list_0, float_0, list_0, float_0, list_0, complex_0)
    assert(action_module_0.run(8, 5) == {'changed': False, 'msg': 'Unable to find src in expected paths', 'rc': 2})


# Generated at 2022-06-25 06:26:44.024758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [complex_0]
    float_0 = -621.70818
    dict_0 = dict()
    action_module_0 = ActionModule(list_0, float_0, list_0, complex_0, list_0, complex_0)
    path_0 = action_module_0.run(float_0, dict_0)
    print(path_0)


# Generated at 2022-06-25 06:26:53.828219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = dict()
    dict_0['regexp'] = '^$'
    dict_0['decrypt'] = True
    dict_0['src'] = '../../../../../../../../..'
    dict_0['ignore_hidden'] = True
    dict_0['follow'] = False
    dict_0['remote_src'] = True
    dict_0['delimiter'] = 're.compile('')'
    dict_0['dest'] = 'tmp/'
    float_0 = -621.70818
    list_0 = [float_0]
    action_module_0 = ActionModule(list_0, float_0, list_0, float_0, list_0, complex_0)

# Generated at 2022-06-25 06:26:56.486099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:01.828872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -274.6515
    list_0 = [float_0]
    complex_0 = None
    action_module_0 = ActionModule(list_0, float_0, list_0, float_0, list_0, complex_0)
    action_module_0.run()


# Generated at 2022-06-25 06:27:02.803156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set the class attributes
    test_case_0()


# Generated at 2022-06-25 06:27:04.235457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:27:15.188356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'b,'
    float_0 = -485.8658097
    arg_0 = 'C'
    tup_0 = (arg_0,)
    tup_1 = (arg_0,)
    bit_1 = False
    str_1 = None
    complex_0 = None
    str_2 = None
    action_module_0 = ActionModule(tup_0, float_0, tup_1, bit_1, str_1, complex_0)
    action_module_0.set_loader(str_0)
    action_module_0.set_play_context(str_2)
    arg_1 = {}
    ret_0 = action_module_0.run(tmp=None, task_vars=arg_1)
    print(ret_0)

# Generated at 2022-06-25 06:27:16.072566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:27:19.700721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    function_call_0 = ActionModule.run(int_0, int_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:27:34.873758
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule(None, None)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()

# Generated at 2022-06-25 06:27:36.070678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    assert (action_module_0.run() == None)



# Generated at 2022-06-25 06:27:37.076133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_0 = C.DEFAULT_LOCAL_TMP
    var_0 = dict()


# Generated at 2022-06-25 06:27:41.124073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(ActionBase())


# Generated at 2022-06-25 06:27:48.900963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None


# Generated at 2022-06-25 06:27:50.133820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # default value of ok is set to True
    assert test_ActionModule.ok is True


# Generated at 2022-06-25 06:27:52.274461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # get test classes
    test_cases = [test_case_0()]
    # test solve
    for test_case in test_cases:
        test_case.run()
# end of file

# Generated at 2022-06-25 06:27:58.332185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_7 = None
    var_8 = None
    try:
        var_7 = test_case_0()
    except Exception as e:
        var_8 = e
    finally:
        var_7 is not var_8

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:28:02.790129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=var_0, connection=var_0, play_context=var_0, loader=var_0, templar=var_0, shared_loader_obj=var_0)

# Unit test class ActionModule

# Generated at 2022-06-25 06:28:05.513712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ast_instance_0 = ActionModule(None, None)
    assert ast_instance_0.run(None, None) is None

# Generated at 2022-06-25 06:28:25.328037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {
        'src': 'src_0',
        'dest': 'dest_0',
        'delimiter': 'delimiter_0',
        'remote_src': 'remote_src_0',
        'regexp': 'regexp_0',
        'follow': 'follow_0',
        'ignore_hidden': 'ignore_hidden_0',
        'decrypt': 'decrypt_0'
    }
    tmp = 'tmp_0'
    task_vars = 'task_vars_0'
    action_module = ActionModule(params, tmp, task_vars)
    result = action_module.run()
    assert result is None


# Generated at 2022-06-25 06:28:31.996725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(argv=[], action_id=-1, arguments=b'\x80 \xc6\x98\x13Q', args=['isatty', 'isatty'], loader_cache={}, check_mode=False)
    assert isinstance(action_module_0, object)


# Generated at 2022-06-25 06:28:41.908683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    var_0 = action_module_0.run(list_0)
    var_1 = action_module_0._assemble_from_fragments(str_0)
    var_2 = action_module_

# Generated at 2022-06-25 06:28:50.744798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert action_module_0._task.module_name == 'assemble', '_task.module_name != \'assemble\''


# Generated at 2022-06-25 06:28:58.668517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str_0 = 'isatty'
    # list_0 = [str_0, str_0]
    # float_0 = -334.1
    # int_0 = 10
    # list_1 = [float_0, int_0, int_0, float_0]
    # int_1 = -819
    # bytes_0 = b'\x80 \xc6\x98\x13Q'
    # set_0 = set()
    # bool_0 = False
    # action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert False # TODO: implement your test here


# Generated at 2022-06-25 06:29:04.276318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_a = 'isatty'
    list_b = [var_a, var_a]
    float_c = -334.1
    int_d = 10
    list_e = [float_c, int_d, int_d, float_c]
    int_f = -819
    bytes_g = b'\x80 \xc6\x98\x13Q'
    set_h = set()
    bool_i = False
    action_module_j = ActionModule(list_e, int_f, bytes_g, list_e, set_h, bool_i)
    action_module_j.run(list_b)


# Generated at 2022-06-25 06:29:12.474486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = list()
    int_0 = 10
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    list_1 = list()
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_0, int_0, bytes_0, list_1, set_0, bool_0)
    var_0 = action_module_0.run(list_1)
    assert var_0 == dict()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:29:17.377207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'write'
    int_0 = 10
    str_1 = '\x17\x12\x89\xcc\xa0\x03|\xff>\x1f\x19\xa3\x85\xc2\x06\x04#\x19\x8c\n2\x01\xe4\xfc\xb8H\xcf\x16'
    set_0 = set()
    bool_0 = True
    action_module_0 = ActionModule(str_0, int_0, str_1, set_0, bool_0)


# Generated at 2022-06-25 06:29:22.897769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    return

    # Unit test for method run()

# Generated at 2022-06-25 06:29:31.667310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    # Invoke constructor of class ActionModule
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert action_module_0 is not None
    # Invoke method 'run' of class ActionModule
    action_module_0.run(list_0)

# Unit test

# Generated at 2022-06-25 06:30:03.856381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    if not isinstance(action_module_0, Base):
        raise AssertionError()
    if not isinstance(action_module_0, ActionBase):
        raise AssertionError()


# Generated at 2022-06-25 06:30:11.669173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)

# Generated at 2022-06-25 06:30:20.218984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    print(action_module_0)


# Generated at 2022-06-25 06:30:21.544353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for case 0
    test_case_0()
    
# Test for running all actions

# Generated at 2022-06-25 06:30:23.447782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        print('You got an error. Good!')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:30:29.414708
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:30:38.417011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    action_module_0.run(list_0)

# Generated at 2022-06-25 06:30:48.009672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -939.8
    list_0 = [float_0, float_0, float_0, float_0]
    float_1 = -80.1
    int_0 = 10
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    list_1 = [float_1, int_0, int_1, float_1]
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_0, int_1, bytes_0, list_1, set_0, bool_0)
    action_module_0._assemble_from_fragments()


# Generated at 2022-06-25 06:30:56.332575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    str_1 = 'isatty'
    list_2 = [str_1, str_1]
    float_1 = -334.1
    int_2 = 10

# Generated at 2022-06-25 06:31:04.386933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)


# Generated at 2022-06-25 06:31:55.343327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -46
    str_0 = '\x00Dh\xc9\xe8\xdc\xce\xec\xde\xd8\xce\xec\xd0'
    str_1 = '\x00\xb0\x96\xaei\xd3\xdd\xfa\xe9\xaa\xc3\\'
    list_0 = [-46]
    str_2 = '\x00"Z\xd2\xa9I\xe0\xdc\xce\xec\xde\xd8\xce\xec\xd0'
    tuple_0 = (-46, -46, -46)
    list_1 = [str_0, str_1, str_2]
    bool_0 = True

# Generated at 2022-06-25 06:32:03.636298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 0
    bytes_0 = b'\x01F\x92\x03\x11\x8e\x9c\x1b\x9e'
    list_1 = [int_0, int_0, int_0, int_0]
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_0, int_0, bytes_0, list_1, set_0, bool_0)
    list_2 = []
    dict_0 = {}
    list_3 = [list_2, dict_0]
    var_0 = action_module_0.run(list_3)
    assert var_0 == dict_0



# Generated at 2022-06-25 06:32:13.517233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    int_2 = 10

# Generated at 2022-06-25 06:32:19.853889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    str_1 = '\x03\x01'
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-25 06:32:29.497761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        str_0 = 'isatty'
        list_0 = [str_0, str_0]
        float_0 = -334.1
        int_0 = 10
        list_1 = [float_0, int_0, int_0, float_0]
        int_1 = -819
        bytes_0 = b'\x80 \xc6\x98\x13Q'
        set_0 = set()
        bool_0 = False
        action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
        var_0 = action_module_0.run(list_0)

    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 06:32:35.104014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    var_0 = action_module_0.run(None, None)


# Generated at 2022-06-25 06:32:41.987268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    action_module_0._assemble_from_fragments()

# Generated at 2022-06-25 06:32:49.207985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert action_module_0.task_include is list_1
    assert action_module_0.task_vars is list_1
    assert action_module_0.loader is set_0
    assert action_module

# Generated at 2022-06-25 06:33:00.155453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'P\\'
    list_0 = [str_0]
    dict_0 = dict()
    bytes_0 = b'\x03\x0c\x1b\x18\x1c\nSC\x1c\x1b'
    set_0 = {bytes_0}
    dict_1 = dict()
    action_module_0.ActionBase__execute_module(dict_1, list_0, dict_0, set_0)
    int_0 = 0
    str_1 = '6\x14'
    dict_2 = dict()
    dict_2['dest'] = str_1
    dict_3 = dict()
    dict_3['dest'] = int_0
    dict_4 = dict()
    dict_4

# Generated at 2022-06-25 06:33:02.686298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    # TODO: construct object with mandatory attributes with example values
    # TODO: assert the class of the object returned by run
    return

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:34:33.347066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert action_module_0._task == list_1
    assert action_module_0._connection == int_1
    assert action_module_0._play_context == bytes_0
    assert action_module_0._

# Generated at 2022-06-25 06:34:42.066028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cwd = os.getcwd()
    ansible_path = os.path.abspath(os.path.join(cwd, '..'))
    data_path = os.path.join(ansible_path, 'test/sanity/data')
    args = dict(src=data_path, dest='/tmp/dest')
    
    dest = '/tmp/dest'
    task_vars = dict()
    remote_src = 'yes'
    regexp = None
    follow = False
    ignore_hidden = False
    decrypt = False
    delimiter = None
    delimit_me = False
    add_newline = False
    dest_path = '/tmp/dest/testfile'

    # This is a mock for os.path.isdir

# Generated at 2022-06-25 06:34:48.889134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_0 = [True]
    action_module_0 = ActionModule(args_0)
    assert isinstance(action_module_0, ActionModule)

    args_1 = [False]
    action_module_1 = ActionModule(args_1)
    assert isinstance(action_module_1, ActionModule)

    args_2 = [False, False]
    action_module_2 = ActionModule(args_2)
    assert isinstance(action_module_2, ActionModule)

    args_3 = [True, True, True]
    action_module_3 = ActionModule(args_3)
    assert isinstance(action_module_3, ActionModule)

    args_4 = [False, True, False]
    action_module_4 = ActionModule(args_4)

# Generated at 2022-06-25 06:34:56.904193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'jnuL0.B\xf5'
    list_0 = [str_0, str_0, str_0]
    float_0 = 479.5
    list_1 = [float_0, float_0, float_0]
    int_0 = -619
    bytes_0 = b'\xfc\x8b\xa9\xdc\xf0'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_0, bytes_0, list_1, set_0, bool_0)
    bool_1 = bool()
    var_1 = action_run(list_0, bool_1)
    var_2 = action_module_0.run(list_0, list_1)

#

# Generated at 2022-06-25 06:35:03.317844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    var_0 = action_run(list_0)
    assert not var_0 is False


# Generated at 2022-06-25 06:35:08.402178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert(isinstance(action_module_0, ActionModule))
    

# Generated at 2022-06-25 06:35:17.999723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'xf86-input-synaptics'
    int_0 = -60
    bool_0 = False
    bytes_0 = b'\x13'
    set_0 = set(['yno@fgy', 'yno@fgy', 'yno@fgy', 'yno@fgy', 'yno@fgy'])
    int_1 = -439
    list_0 = [str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0]
    float_0 = -66.0
    list_1 = [bytes_0, bytes_0, bytes_0, int_1]

# Generated at 2022-06-25 06:35:25.160115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    assert (action_module_0._task.args == list_0)


# Generated at 2022-06-25 06:35:33.688293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    action_module_0.run(list_0)


# Generated at 2022-06-25 06:35:40.321355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'isatty'
    list_0 = [str_0, str_0]
    float_0 = -334.1
    int_0 = 10
    list_1 = [float_0, int_0, int_0, float_0]
    int_1 = -819
    bytes_0 = b'\x80 \xc6\x98\x13Q'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(list_1, int_1, bytes_0, list_1, set_0, bool_0)
    action_module_0.run(list_0)