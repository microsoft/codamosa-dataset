

# Generated at 2022-06-25 06:26:37.509831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:26:44.336902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1c\xee\xca-\xc7KP\x88'
    int_0 = 923
    list_0 = [bytes_0, int_0, bytes_0, int_0]
    set_0 = set()
    str_0 = 'iYYd<+pK/q\x0bdWeQ}m'
    action_module_0 = ActionModule(bytes_0, int_0, list_0, set_0, bytes_0, str_0)
    bytes_1 = b'\xb3\x1f\xac\x8f\xf4\xa9\x1e\x82'
    int_1 = 984
    list_1 = [int_0, bytes_0, int_1, bytes_1, bytes_1]
   

# Generated at 2022-06-25 06:26:47.305483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 06:26:51.098372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test for constructor of class ActionModule')
    list_0 = [0, 1, 2]
    set_0 = {0, 1, 2}
    str_0 = 'cljhB'
    action_module_0 = ActionModule(list_0, 0, list_0, set_0, list_0, str_0)
    print(action_module_0)


# Generated at 2022-06-25 06:27:00.857130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1c\xee\xca-\xc7KP\x88'
    int_0 = 923
    list_0 = [bytes_0, int_0, bytes_0, int_0]
    set_0 = set()
    str_0 = 'iYYd<+pK/q\x0bdWeQ}m'
    action_module_0 = ActionModule(bytes_0, int_0, list_0, set_0, bytes_0, str_0)
    result = action_module_0.run(None)
    print(result)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:27:04.640210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1c\xee\xca-\xc7KP\x88'
    int_0 = 923
    list_0 = [bytes_0, int_0, bytes_0, int_0]
    set_0 = set()
    str_0 = 'iYYd<+pK/q\x0bdWeQ}m'
    ansible.ActionModule_0 = ansible.ActionModule(bytes_0, int_0, list_0, set_0, bytes_0, str_0)
    ansible.ActionModule_0.run()


# Generated at 2022-06-25 06:27:15.527172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "Kw{z"
    action_module_1 = ActionModule()
    bytes_0 = b'\x1c\xee\xca-\xc7KP\x88'
    str_1 = ""
    list_0 = [str_1, str_1, bytes_0, str_1, str_0, str_1, bytes_0, str_0, bytes_0, str_1, bytes_0, bytes_0, bytes_0, str_0, bytes_0, str_1, str_1, str_1, bytes_0, bytes_0, bytes_0, str_1, str_1, str_1, str_1, str_0, bytes_0, str_0, str_1, str_1, bytes_0, bytes_0]
    set_0 = set

# Generated at 2022-06-25 06:27:16.379104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:27:24.457233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up paramlocal variables
    bytes_0 = b'\x1c\xee\xca-\xc7KP\x88'
    int_0 = 923
    list_0 = [bytes_0, int_0, bytes_0, int_0]
    set_0 = set()
    str_0 = 'iYYd<+pK/q\x0bdWeQ}m'
    action_module_0 = ActionModule(bytes_0, int_0, list_0, set_0, bytes_0, str_0)

    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:27:25.513218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test constructor')

    # Set up expected input values
    tmp = None
    task_vars = None

    test_case_0()


# Generated at 2022-06-25 06:27:37.266520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0 != None)
    assert(action_module_0._supports_check_mode == False)


# Generated at 2022-06-25 06:27:41.164031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:27:45.271225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)

# Generated at 2022-06-25 06:27:50.436715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    try:
        action_module_2.run()
        action_module_3.run(tmp=None, task_vars=None)
    except AnsibleActionFail:
        pass
    assert action_module_0.run(tmp=None, task_vars=None) is None
    assert action_module_1.run(tmp=None, task_vars=None) is None

# Generated at 2022-06-25 06:27:57.054135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    path_0 = tempfile.mkdtemp()
    bytes_0 = b'\x1c\xee\xca-\xc7KP\x88'
    bytes_1 = b'\x9b?\x11\xbd\x98}'
    bytes_2 = b'\xc2\xbd\xdf\xc9\xcc'
    bytes_3 = b'\xe0\xba\x0b\xa7\x91\xa9'
    ansible_errors_AnsibleError_0 = AnsibleError(0)
    ansible_errors_AnsibleAction_0 = AnsibleAction(0, 0)
    ansible_errors__AnsibleActionDone_0 = _AnsibleActionDone(0)
    ansible_errors

# Generated at 2022-06-25 06:28:01.897957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_case_0()
    print('ActionModule.run')
    # Not yet implemented
    print('Not yet implemented')
    print('[DRY]')

# Generated at 2022-06-25 06:28:06.032246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:13.772522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:28:14.993439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None


# Generated at 2022-06-25 06:28:26.197350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test variables
    # NOTE: These values are calculated from the methods named above
    action_module_0 = ActionModule()

    result_0 = action_module_0.run(None, none_0)
    assert result_0

    # assert that the result is a dict
    assert isinstance(result_0, dict)

    # assert that the result contains the expected keys
    assert "md5sum" in result_0
    assert "changed" in result_0
    assert "dest" in result_0
    assert "checksum" in result_0
    assert "gid" in result_0
    assert "group" in result_0
    assert "mode" in result_0
    assert "owner" in result_0
    assert "secontext" in result_0
    assert "size" in result_0

# Generated at 2022-06-25 06:28:39.053223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:28:40.267817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run(None, {})


# Generated at 2022-06-25 06:28:41.455432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert(action_module_0.run is not None)


# Generated at 2022-06-25 06:28:47.696457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # [TODO] Add your test cases
    #result = action_module_1.run(tmp = None,task_vars = None)


# Generated at 2022-06-25 06:28:52.118812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:56.253890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # 'ActionModule' object has no attribute '_task'
    action_module_0 = ActionModule(0, 0)



# Generated at 2022-06-25 06:29:00.191168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ActionModule(task)
    action_module_0 = ActionModule()
    # ActionModule(task=task)
    action_module_1 = ActionModule()

    # TODO: test exception


# Generated at 2022-06-25 06:29:10.632239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task.args = dict()
    action_module_0._task.args['src'] = src
    action_module_0._task.args['dest'] = dest
    dest = Undefined
    action_module_0._task.args['delimiter'] = delimiter
    action_module_0._task.args['remote_src'] = remote_src
    action_module_0._task.args['regexp'] = regexp
    action_module_0._task.args['follow'] = follow
    action_module_0._task.args['ignore_hidden'] = ignore_hidden
    action_module_0._task.args['decrypt'] = decrypt
    action_module_0._task.args['src'] = src

# Generated at 2022-06-25 06:29:17.496861
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:29:24.044579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct object.
    action_module_0 = ActionModule()

    # Constructor test
    assert_equals(isinstance(action_module_0, ActionModule), True)

    # Method run existence test
    assert_equals(hasattr(action_module_0, 'run'), True)


# Generated at 2022-06-25 06:29:47.634733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert type(action_module_0.run()).__name__ == 'dict'


# Generated at 2022-06-25 06:29:53.238940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (action_module_0.__doc__ == ActionModule.__doc__)
    assert (action_module_0.run.__doc__ == ActionModule.run.__doc__)
    assert (action_module_0.TRANSFERS_FILES == True)


# Generated at 2022-06-25 06:30:03.886226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()

    with open('resource/action_module_test.json', 'r') as f:
        action_module_test_data = json.load(f)
        test_data_0 = action_module_test_data['test_data_0']
        test_data_1 = action_module_test_data['test_data_1']
        test_data_2 = action_module_test_data['test_data_2']

    assert action_module_0.run(**test_data_0) == {}
    assert action_module_1.run(**test_data_1) == {}
    assert action_module_2.run(**test_data_2) == {}

# Generated at 2022-06-25 06:30:10.463746
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Use if necessary
    # Build action_module_0
    action_module_0_changes = {'action_module_0':'action_module_0'}
    action_module_0_section = {'action_module_0':'action_module_0'}
    action_module_0 = ActionModule(action_module_0_section, action_module_0_changes)

    # Unit test for function run
    # Use if necessary
    # Build action_module_0
    action_module_0_changes = {'action_module_0':'action_module_0'}
    action_module_0_section = {'action_module_0':'action_module_0'}
    action_module_0 = ActionModule(action_module_0_section, action_module_0_changes)

    # Test

# Generated at 2022-06-25 06:30:16.768100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This will fail because there are no arguments in the run method
    # Create a new test case to add arguments
    action_module_run = ActionModule()
    assert_raises(AnsibleAction, action_module_run.run(), None, None)
    print('test_ActionModule_run passed')


# Generated at 2022-06-25 06:30:21.917205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()

if __name__ == '__main__':
    try:
        test_case_0()
    except SystemExit as e:
        print('FAILED')
        raise e
    else:
        print('PASSED')

# Generated at 2022-06-25 06:30:27.509083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    kwargs = {}
    kwargs['tmp'] = None
    kwargs['task_vars'] = dict()
    kwargs['task_vars']['ansible_check_mode'] = False
    kwargs['task_vars']['ansible_verbosity'] = 3
    kwargs['task_vars']['ansible_depth'] = 0
    kwargs['task_vars']['ansible_host'] = None
    kwargs['task_vars']['ansible_hostvars'] = dict()
    kwargs['task_vars']['ansible_playbook'] = None
    kwargs['task_vars']['ansible_play_hosts'] = None

# Generated at 2022-06-25 06:30:29.019711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:29.800406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert True == True


# Generated at 2022-06-25 06:30:39.234163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, mode='w+', delete=False)

    # Write data to temporary file
    data = 'Hello World'
    tmp_file.write(data)
    tmp_file.close()

    # Create a temporary directory
    tmp_dir_2 = tempfile.mkdtemp()

    # Create a tmp_file_2
    tmp_file_2 = tempfile.NamedTemporaryFile(dir=tmp_dir_2, mode='w+', delete=False)

    # Write data to tmp_file_2
    data_2 = 'Hello World'
    tmp_

# Generated at 2022-06-25 06:31:01.362806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule started')
    assert ActionModule is not None


# Generated at 2022-06-25 06:31:09.348131
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:31:11.159351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        action_module = ActionModule( )


# Generated at 2022-06-25 06:31:15.441900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = 'I1Z=bL0\tAa*\nb'
    str_3 = 'E;%\x0b>l(|\n'
    # Execute method run of class ActionModule with arguments: str_2, str_3
    action_run(str_2, str_3)


# Generated at 2022-06-25 06:31:18.426462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 == None, 'Return value of action_module_0.run() is not equal to None'

# Generated at 2022-06-25 06:31:27.236850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ActionModule()

# Generated at 2022-06-25 06:31:36.851597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '15X6'
    dict_0 = {str_0: str_0}
    str_1 = '*Bs7m@'
    str_2 = '8W4`y'
    bool_0 = True
    tuple_0 = ()
    obj_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    str_3 = 'p\ny_5E\x00'
    dict_1 = {str_0: str_0}
    obj_1 = ActionModule(str_0, dict_1, str_1, str_2, bool_0, tuple_0)
    str_4 = 'U"sx\\'
    tuple_1 = ()

# Generated at 2022-06-25 06:31:39.403237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:31:41.344435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # task_vars = {}
    # assert(action_module_0.run(tmp=None, task_vars=task_vars) == {})
    pass


# Generated at 2022-06-25 06:31:48.093072
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    dict_0 = {}
    action_module_0 = ActionModule('apJ#[j*Z6u', dict_0, '6u>*V-L3^', '6u>*V-L3^', True)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:32:39.797873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'U6\\\\\x0cS\\]\\\\\\F\x04'
    dict_0 = {}
    dict_1 = {str_0: str_0}
    str_1 = 'L-\x0boX_\x19a'
    str_2 = 'c%\x1a61/C'
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_1, str_1, str_2, bool_0, tuple_0)
    assert action_module_0._task == dict_1
    assert action_module_0._connection == str_2
    assert action_module_0._play_context == str_1
    assert action_module_0._loader == str_0
    assert action_module_0._

# Generated at 2022-06-25 06:32:48.691958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_0 = 'u6/Oj6(m'
    dict_0 = {ansible_0: ansible_0}
    str_0 = 'Kj.DZ\rkR^`'
    str_1 = 'y.-@'
    bool_0 = True
    tuple_0 = (bool_0, )
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_1, bool_0, tuple_0)
    result_0 = action_module_0.run(ansible_0, dict_0)


# Generated at 2022-06-25 06:32:57.305360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '52E\n=(SF\x0cgsua[&\nW&j'
    dict_0 = {str_0: str_0}
    str_1 = '/!3j=%3I1amX'
    str_2 = 'Bh!\x0bw('
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    # Some code here

# This is a unit test for method of class ActionModule._assemble_from_fragments

# Generated at 2022-06-25 06:33:03.763027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '@}3IK\n^lx*Bn6#1\x0b"\x0b\\n\\'
    dict_0 = {str_0: str_0}
    str_1 = ':!\x0c\x0b"\x0b\\i1#Wn&8\x0b"'
    str_2 = 'W\x0c- '
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)

test_case_0()

# Generated at 2022-06-25 06:33:12.564422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_3 = '4"6gh!|*D'
    dict_1 = {str_3: str_3}
    str_4 = '>Yc%u?7V'
    str_5 = '}g*#l9B'
    bool_1 = False
    tuple_1 = ()
    action_module_1 = ActionModule(str_3, dict_1, str_4, str_5, bool_1, tuple_1)
    str_6 = 'rZm-XHYx'
    dict_2 = {str_6: str_6}
    str_7 = '#HErkQ@'
    str_8 = 'lf"%<Kj'
    bool_2 = False
    tuple_2 = ()

# Generated at 2022-06-25 06:33:17.857752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '52E\n=(SF\x0cgsua[&\nW&j'
    dict_0 = {str_0: str_0}
    str_1 = '/!3j=%3I1amX'
    str_2 = 'Bh!\x0bw('
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    action_module_0.run()
    return

# Generated at 2022-06-25 06:33:26.672618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	str_1 = '52E\n=(SF\x0cgsua[&\nW&j'
	dict_0 = {str_1: str_1}
	str_2 = '/!3j=%3I1amX'
	str_3 = 'Bh!\x0bw('
	bool_0 = True
	tuple_0 = ()
	action_module_0 = ActionModule(str_1, dict_0, str_2, str_3, bool_0, tuple_0)
	tmp_0 = None
	task_vars_0 = None
	action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:33:35.365895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o\x14p\\\x06Uz\r'
    dict_0 = {str_0: str_0}
    str_1 = '_w\x0bS\x02UT'
    str_2 = '_w\x0bS\x02UT'
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    action_run()


# Generated at 2022-06-25 06:33:43.301828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '52E\n=(SF\x0cgsua[&\nW&j'
    dict_0 = {str_0: str_0}
    str_1 = '/!3j=%3I1amX'
    str_2 = 'Bh!\x0bw('
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)

# Generated at 2022-06-25 06:33:46.877878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '_8s&'
    dict_0 = {str_0: str_0}
    str_1 = 'TbB7(\x17'
    str_2 = '/*[g'
    bool_0 = True
    tuple_0 = ()
    #Test for __init__
    test_case_0()

# Generated at 2022-06-25 06:35:18.654521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '52E\n=(SF\x0cgsua[&\nW&j'
    dict_0 = {str_0: str_0}
    str_1 = '/!3j=%3I1amX'
    str_2 = 'Bh!\x0bw('
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    assert '52E\n=(SF\x0cgsua[&\nW&j' == action_module_0._task.args.get('src')
    assert {str_0: str_0} == action_module_0.LOADER


# Generated at 2022-06-25 06:35:25.504024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '52E\n=(SF\x0cgsua[&\nW&j'
    dict_0 = {str_0: str_0}
    str_1 = '/!3j=%3I1amX'
    str_2 = 'Bh!\x0bw('
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    list_0 = []
    dict_1 = {str_0: list_0}
    str_3 = var_0.run(str_0, dict_1)


# Generated at 2022-06-25 06:35:32.637061
# Unit test for method run of class ActionModule
def test_ActionModule_run():

	# get the basic objects we'll need for constructing our class and
	# test its output
	loader = DictDataLoader({})
	sut = ActionModule(loader=loader, task=dict())

	# we're done, return the results
	return (sut, [
		dict(
			actual={
				'stdout': None,
			},
			expect={
				'stdout': u'Hello World',
			},
		),
	])

# Generated at 2022-06-25 06:35:40.426423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.copy import ActionModule

# Generated at 2022-06-25 06:35:41.245469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:35:42.008103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()


# Generated at 2022-06-25 06:35:47.444173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '52E\n=(SF\x0cgsua[&\nW&j'
    dict_0 = {str_0: str_0}
    str_1 = '/!3j=%3I1amX'
    str_2 = 'Bh!\x0bw('
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:35:52.433061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'X'
    dict_0 = {str_0: str_0}
    str_1 = 'u'
    str_2 = 'Y'
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, dict_0, str_1, str_2, bool_0, tuple_0)
    var_0 = action_module_0.run(action_run(), action_run())

# Generated at 2022-06-25 06:35:53.594589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    test_ActionModule_run_0(tmp, task_vars)

# Generated at 2022-06-25 06:35:56.466729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run 'test_case_0'")
    test_case_0()
    print("Testing run 'test_case_0' completed ")