

# Generated at 2022-06-25 06:26:39.531181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "'Rt\x0c[@#KMau\t"
    set_0 = {str_0}
    list_0 = []
    int_0 = -324
    action_module_0 = ActionModule(str_0, set_0, str_0, list_0, list_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 06:26:45.586112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = u'profundities'
    set_0 = {str_0}
    str_1 = u'deviousnesses'
    list_0 = []
    list_1 = []
    int_0 = 839
    action_module_0 = ActionModule(str_0, set_0, str_1, list_0, list_1, int_0)

    # Testing method run of class ActionModule
    action_module_0.run()


# Generated at 2022-06-25 06:26:54.829902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'YJ\x1a\x17\x0b\x14J$\x10G\x1eU6\x0b\\^]\x18\x1f\x1d)]\x0c\x1f\x00'
    str_2 = 'B\x0e`\x0f\x1b'
    set_1 = {str_2}

# Generated at 2022-06-25 06:27:01.272668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('U4K6.s<6~', set(['\n', 'S{y-@', 'T', '>|', 'hi', 'l:)l\x0c', '[;c(', '&']), '!\rX', list([]), [], 1)
    assert action_module_0._supports_check_mode == False


# Generated at 2022-06-25 06:27:03.380748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in ActionModule test:")
        print(e)
    else:
        print("ActionModule test completed")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:14.599868
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = "5\x0c\x02\x1f\x19\x0eZ\x1b\x12\x19\x15\x14\x03\x0f\x13\x1b\x0b\x0f\x12\x02\x1e\x1d\x0b\x12\x02"

# Generated at 2022-06-25 06:27:24.678164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ""
    set_0 = {str_0}
    str_1 = "7i\x16\x08\x1d"
    list_0 = []
    list_1 = []
    int_0 = 0
    action_module_0 = ActionModule(str_0, set_0, str_0, list_0, list_1, int_0)
    path_0 = tempfile.mkdtemp()
    dict_0 = dict()
    dict_0["path"] = os.path.dirname(path_0)
    dict_0["src"] = os.path.basename(path_0)
    dict_0["dest"] = "/tmp/dest"
    dict_0["regexp"] = "\\.txt$"
    dict_0["remote_src"] = "no"

# Generated at 2022-06-25 06:27:32.647560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'U|ZD0\x03'
    str_2 = "c'i\t\x1c"
    str_3 = 'f\x1f!;\x03\x12'
    str_4 = 'r'
    list_0 = [str_3, str_1]
    set_0 = {str_4}
    action_module_0 = ActionModule(str_2, set_0, str_4, list_0, list_0, -88)
    str_5 = "\x1c\x1eL3h"
    str_6 = "1"
    str_7 = '\x1f\r\r\r\r'
    str_8 = '\x1c\x1eL3h'

# Generated at 2022-06-25 06:27:38.935042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "f\x13\x12\x1e\x19\b\x1f\x1b\x1b\x1d\x0e\x19\x1a\x19\x14\x01\x1c"
    set_0 = {}
    str_1 = "\x1a\x17"
    list_0 = []
    list_1 = []
    int_0 = -28
    action_module_0 = ActionModule(str_0, set_0, str_1, list_0, list_1, int_0)
    action_module_0._AnsibleActionDone()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:27:42.675249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('Rt\x0c[@#KMau\t', {'Rt\x0c[@#KMau\t'}, 'Rt\x0c[@#KMau\t', [], [], -324)


# Generated at 2022-06-25 06:28:00.542064
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # --- setup
    # temp file for assemble
    temp_path = tempfile.mkstemp()
    os.close(temp_path[0])

    # assemble a file from a directory of fragments
    def _assemble_from_fragments(src_path, delimiter=None, **kwargs):
        tmp = open(to_text(temp_path[1]), 'wb')
        tmp.write(str_0)
        tmp.close()
        return temp_path[1]

    # task setup
    task = dict(name = 'ActionModule test', args = dict(src = 'src', dest = 'dest', delimiter = 'delimiter', remote_src = 'remote_src'))
    am = ActionModule(task, connection=None, play_context=dict())
    am._loader = FakeLoader(searchpath=[])

# Generated at 2022-06-25 06:28:03.758385
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module_1 = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-25 06:28:05.613308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-25 06:28:09.117298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    aModule = ActionModule(connection=None, runner_connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    aModule.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 06:28:16.196122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 'src', 'dest', 'delimiter', 'remote_src', 'regexp', 'follow', 'ignore_hidden', 'decrypt'
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    args = {
        'src': AnsibleUnicode(str_0),
        'dest': AnsibleUnicode(str_1),
        'delimiter': AnsibleUnsafeText(str_2),
        'remote_src': True,
        'regexp': AnsibleUnicode(str_3),
        'follow': False,
        'ignore_hidden': True,
        'decrypt': True,
        }
    # Return a new instance of the class
    obj = ActionModule()
    #obj

# Generated at 2022-06-25 06:28:26.275929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = '\x1e\x1e\x02\x1c\x05\x06\x0b\x1b\x05\x05\x0b\x1a\x0c\x0e\x0e\x1d\x1a\x0c\x06\x05\x06\x0c\x1b\x1a\x13\x15\x1e'

# Generated at 2022-06-25 06:28:35.216486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    task = dict()

    task = dict()
    task['action'] = dict()
    task['action']['module_name'] = 'assemble'
    task['action']['module_args'] = dict()
    task['action']['module_args']['src'] = '/path/to/src/dir'
    task['action']['module_args']['dest'] = '/path/to/dest/file'

    tmp = None

    action_module = ActionModule(task, tmp)
    action_module.run(tmp, task_vars)


if __name__ == "__main__":
    # Test to implement
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:37.807815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import PY3
    # test_case_0
    try:
        test_case_0()
        assert False
    except RuntimeError:
        pass


# Generated at 2022-06-25 06:28:39.792534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_ActionModule = ActionModule()
    tmp = None
    task_vars = None
    obj_ActionModule.run(tmp, task_vars)

test_case_0()

# Generated at 2022-06-25 06:28:40.775284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 06:29:01.595981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=Task(V2_2()), connection=Connection(V2_2()), play_context=PlayContext(V2_2()), loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(action_module._task, Task)
    assert isinstance(action_module._connection, Connection)
    assert isinstance(action_module._loader, DataLoader)
    assert isinstance(action_module._templar, Templar)
    assert isinstance(action_module._shared_loader_obj, SharedPluginLoaderObj)
    assert isinstance(action_module._play_context, PlayContext)
    assert isinstance(action_module._supports_check_mode, bool)


# Generated at 2022-06-25 06:29:10.744739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = u'c:\windows\system32\inetsrv\appcmd.exe set config -section:system.webServer/serverRuntime "-appHostConfig:\"C:\\Windows\\system32\\inetsrv\\config\\applicationHost.config\" -commitpath:\"MACHINE/WEBROOT/APPHOST\""'

# Generated at 2022-06-25 06:29:12.170971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._supports_check_mode == False


# Generated at 2022-06-25 06:29:18.285956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test the no-op constructor for ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module.task == None
    assert action_module.connection == None
    assert action_module.play_context == None
    assert action_module.loader == None
    assert action_module.templar == None
    assert action_module._supports_check_mode == False
    assert action_module._supports_async == False
    assert action_module._supports_async_timeout == False
    assert action_module._shared_loader_obj == None


# Generated at 2022-06-25 06:29:20.789281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a1 = ActionModule()
    a1.run()


# Generated at 2022-06-25 06:29:28.819993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import PY2
    import sys
    import ansible.plugins.loader as loader
    import ansible.plugins.action as action
    import ansible.utils as utils
    import ansible.module_utils.parsing.convert_bool as convert_bool

    loader.add_directory(utils.path_dwim('lib/ansible/plugins/action'))
    module_source = loader.find_plugin(str_0)

    module_name = 'ansible.plugins.action.' + str_0

    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        from ansible.utils.boolean import boolean
    else:
        from ansible.utils.boolean import boolean

    boolean = convert_bool.boolean


# Generated at 2022-06-25 06:29:33.999054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for _ in range(0):
        _ = test_case_0()


# Tested using:
# $ shasum -a 256 test_file_1
# $ shasum -a 256 test_file_2
# $ shasum -a 256 test_file_3
# $ shasum -a 256 test_file_4
# $ shasum -a 256 test_file_5
# $ shasum -a 256 test_file_6
# $ shasum -a 256 test_file_7
# $ shasum -a 256 test_file_8
# $ shasum -a 256 test_file_9
# $ shasum -a 256 test_file_10

# Generated at 2022-06-25 06:29:37.527808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b = ActionModule()
    print(b.run())


# Generated at 2022-06-25 06:29:43.535301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = '.'
    dest = '.'

    # should match pattern 'RegexpError'
    assert re.match(r'RegexpError', str_0)

    # should match pattern 'IOError'
    assert re.match(r'IOError', str_0)

    # should match pattern 'AnsibleAction'
    assert re.match(r'AnsibleAction', str_0)

    # should match pattern 'AnsibleActionFail'
    assert re.match(r'AnsibleActionFail', str_0)

# Generated at 2022-06-25 06:29:49.465403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._assemble_from_fragments == None
    # assert obj._check_mode == None
    # assert obj._cleanup_remote_tmp == None
    # assert obj._close_remote_tmp == None
    # assert obj._remove_tmp_path == None
    # assert obj._delete_remote_file == None
    # assert obj._execute_module == None
    # assert obj._execute_remote_stat == None
    # assert obj._execute_status == None
    # assert obj._fixup_perms2 == None
    # assert obj._load_name_to_path_info == None
    # assert obj._make_tmp_path == None
    # assert obj._remote_expand_user == None
    # assert obj._remote_checksum == None
    # assert obj._remote_md

# Generated at 2022-06-25 06:30:06.509966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('In test_ActionModule')
    task_vars = ['Z\x1b\x12\x19\x15\x14\x03\x0f\x13\x1b\x0b\x0f\x12\x02\x1e\x1d\x0b\x12\x02']
    obj_ActionModule = ActionModule(task_vars)
    # print(obj_ActionModule)


# Generated at 2022-06-25 06:30:07.783444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# unit tests

# Generated at 2022-06-25 06:30:14.823825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_2 = None
    task_vars_3 = None
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    a._supports_check_mode = False
    a._task = None
    a._connection = None
    a._play_context = None
    a._loader = None
    a._templar = None
    a._shared_loader_obj = None
    tmp_2 = None
    task_vars_3 = None
    try:
        test_case_0()
    finally:
        tmp_2 = None
        task_vars_3 = None

# Generated at 2022-06-25 06:30:20.844670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    run_call = MagicMock()
    assemble_from_fragments = MagicMock()

    action = ActionModule(run_call, assemble_from_fragments)
    action.run_call = run_call
    action.assemble_from_fragments = assemble_from_fragments


# Generated at 2022-06-25 06:30:28.435594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.network.fortios.fortios import fortios_firewall_multicast_address_custom
    from ansible.module_utils.network.fortios.fortios import fortios_firewall_multicast_address_default
    from ansible.module_utils.network.fortios.fortios import fortios_firewall_object_group_network
    from ansible.module_utils.network.fortios.fortios import fortios_firewall_object_group_network_network_object
    from ansible.module_utils.network.fortios.fortios import fortios_firewall_object_group_network_network_object_host
    from ansible.module_utils.network.fortios.fortios import fortios_firewall_object_group_network_network_object_range

# Generated at 2022-06-25 06:30:38.442988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = Host()
    connection = Connection('ssh')
    task = Task()
    task.args = dict(dest='/root/.vimrc', src='files', delimiter='# BEGIN ANSIBLE MANAGED BLOCK', remote_src='no', regexp='^vimrc_.*')
    play_context = PlayContext()

    obj = ActionModule(task, connection, play_context, host, '/path/to')

    assert obj.pkg_mgr is None
    assert obj.changed is False
    assert obj.skipped is False
    assert obj.failed is False
    assert obj.parsed is False
    assert obj.action_show_custom_stats == {}
    assert obj.action_metadata is None
    assert obj.action_plugins is None
    assert obj.handler_plugins is None

# Generated at 2022-06-25 06:30:49.352738
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:30:57.465054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dest = 'x\x0c\x00\x19\x00\x17\x00\x14\x00\x1a\x00\x17\x00\x19\x00\x18\x00\x1f\x00\x15\x00\x1f\x00\x0b\x00\x1f\x00\x10\x00\x19\x00\x1e'
    x = ActionModule(task_vars = 'Z')
    assert type(x) == ActionModule


# Generated at 2022-06-25 06:31:03.359811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture_0 = ActionModule(task=None)
    expected_0 = ''
    actual_0 = fixture_0.run(tmp=None, task_vars=None)

    # Compare with expected_0
    assert actual_0 == expected_0

# Unit tests for run()

# Generated at 2022-06-25 06:31:09.509465
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    text = "This is a test"
    src = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_file')
    dest = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_file_1')

    with open(src, 'w') as f:
        f.write(text)

    acm = ActionModule(task=dict(args=dict(src=src, dest=dest)),
                      connection=None,
                      play_context=None,
                      loader=None,
                      templar=None,
                      shared_loader_obj=None)
    res = acm.run()

    with open(dest) as f:
        result = f.read()

    if result == text:
        print("test_ActionModule_run: PASS")

# Generated at 2022-06-25 06:31:29.697977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {}
    tuple_0 = ()
    bytes_0 = b'7\x00\x00\x00\xd26\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xab\x01\x00\x00\x00'

# Generated at 2022-06-25 06:31:39.105262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    action_module_0.run(None, None)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:31:45.848455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    
    assert str_0 == 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    assert bool_0 == True
    assert int_0 == 21
    assert bytes_0 == b'oB\xaf\xf6\xf1'
    assert isinstance

# Generated at 2022-06-25 06:31:51.835935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    with patch('ansible.parsing.dataloader.DataLoader.get_file_contents') as mock_get_file_contents:
        with patch('ansible.plugins.action.ActionBase._execute_module') as mock__execute_module:
            with patch('ansible.plugins.action.ActionBase._execute_task') as mock__execute_task:
                with patch('ansible.plugins.action.ActionBase._fixup_perms2') as mock__fixup_perms2:
                    with patch('ansible.plugins.action.ActionBase._get_diff_data') as mock__get_diff_data:
                    #Invoke method
                        action_module_0 = ActionModule()
                        var_0 = action_module_0.run(var_0, var_0)
                        assert true

# Generated at 2022-06-25 06:31:57.918646
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create instance of class ActionModule and pass true, {}, (), 'oB¯øñ', 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main', 21 as params
    action_module_0 = ActionModule(True, {}, (), 'oB¯øñ', 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main', 21)

    # check the object action_module_0 is an instance of class ActionModule
    if(isinstance(action_module_0, ActionModule)):
        print('Object is an instance of class ActionModule')
    else:
        print('Object is not an instance of class ActionModule')

    # check the number of parameters

# Generated at 2022-06-25 06:31:58.646440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:32:03.869212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    action_module_run_1 = ActionModule()
    action_module_run_2 = ActionModule()
    action_module_run_3 = ActionModule()
    action_module_run_4 = ActionModule()
    action_module_run_5 = ActionModule()
    action_module_run_6 = ActionModule()
    action_module_run_7 = ActionModule()
    action_module_run_8 = ActionModule()
    action_module_run_9 = ActionModule()
    action_module_run_10 = ActionModule()
    action_module_run_11 = ActionModule()
    action_module_run_12 = ActionModule()
    action_module_run_13 = ActionModule()
    action_module_run_14 = ActionModule()
    action_module

# Generated at 2022-06-25 06:32:13.628405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    bool_1 = True
    dict_1 = {bool_1: bool_1, bool_1: bool_1}
    tuple_1 = ()
    bytes_1 = b'oB\xaf\xf6\xf1'

# Generated at 2022-06-25 06:32:19.898058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_1 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    action_module_2 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    assert action_module_1 == action_module_2
    assert action_module_1 != action_module_2


# Generated at 2022-06-25 06:32:28.327974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    assert (len(action_module_0._task.action) == 21)


# Generated at 2022-06-25 06:32:59.502320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'\xd6\x9c\xa5\xfa5\x1e\x05\x8a'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21

# Generated at 2022-06-25 06:33:04.668174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # method run with two parameters
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    action_module_0._supports_check_mode = False
    int_0 = 21
    dict_0 = {int_0: int_0}
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    var_0 = action_run(str_0, dict_0)
    assert_equal(var_0, b'\x00\x1e\x00')


# Generated at 2022-06-25 06:33:09.664131
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Code to test constructor
    var_0 = True
    dict_0 = {}
    tuple_0 = ()
    bytes_0 = b''
    str_0 = ''
    int_0 = 0

    # ActionModule.run
    var_0 = run(dict_0, tuple_0)

    # ActionModule._assemble_from_fragments
    var_0 = assemble_from_fragments(dict_0, dict_0, dict_0, dict_0)


# Generated at 2022-06-25 06:33:15.556437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)


# Generated at 2022-06-25 06:33:18.461669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:33:28.248017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule()
    dir_0 = tempfile.mkdtemp('dir_0')
    str_0 = 'dir_1'
    str_1 = 'asmble_frag_dir'
    str_2 = 'asmble_frag_foo_dir'
    dir_2 = os.path.join(dir_0, str_2)
    list_0 = ('asmble_frag_baz.yml', 'asmble_frag_foo.yml', 'asmble_frag_bar.yml')
    str_3 = 'asmble_frag_foo.yml'
    list_1 = ('asmble_frag_bar.yml', 'asmble_frag_baz.yml')
    str_4 = 'asmble_frag_baz.yml'

# Generated at 2022-06-25 06:33:37.579173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    assert action_module_0.get_action_result() is True
    dict_1 = {bool_0: bool_0, bool_0: bool_0}
    assert action_module_0.get_action_result() is True
    from ansible.task_vars import TaskVars
   

# Generated at 2022-06-25 06:33:41.278935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        # return False
    else:
        # return True
        pass


# Generated at 2022-06-25 06:33:48.062380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if True:
        dict_0 = {'\xac\xa8\x95\x97\xb5%\x0b\xa6\x95\xc3\xb0\xb6\xce\xbdc\xaf\xa9\x95\xb9\xfa\xf0a\xc1\xef': True, False: False}
        tuple_0 = ()
        bytes_0 = b'oB\xaf\xf6\xf1'
        str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
        int_0 = 21
        action_module_0 = ActionModule(True, dict_0, tuple_0, bytes_0, str_0, int_0)
        action_module_0.run()
        assert True

# Generated at 2022-06-25 06:33:53.495966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)


# Generated at 2022-06-25 06:34:43.586043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test action_module.py - test_ActionModule')
    # assert ...


# Generated at 2022-06-25 06:34:50.080869
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Setup arguments
    self = None
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None

    # Call the constructor
    action_module_0 = ActionModule(self, task, connection, play_context, loader, templar)

    # Retrieve values
    self_value = action_module_0.self
    task_value = action_module_0.task
    connection_value = action_module_0.connection
    play_context_value = action_module_0.play_context
    loader_value = action_module_0.loader
    templar_value = action_module_0.templar

    # Compare values
    assert self_value == self
    assert task_value == task
    assert connection_value == connection
    assert play_context_

# Generated at 2022-06-25 06:34:50.544832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-25 06:34:58.585909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    bool_0 = True
    tuple_0 = ()

# Generated at 2022-06-25 06:34:59.286390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass


# Generated at 2022-06-25 06:35:05.021405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = (1, 'int', 'd')
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    action_module_0.run(action_module_0)

test_ActionModule_run()

# Generated at 2022-06-25 06:35:13.166609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:35:19.458012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'dQ\xf8\xec\x1d'
    str_0 = '8W_'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    test_case_0(action_module_0)
    test_case_1(action_module_0)

# Generated at 2022-06-25 06:35:27.059923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = (bool_0, bool_0)
    bytes_0 = b'\x80\x96w\xac\x94\xf9\xca'
    str_0 = '\x8a\x95\xc0\xfd\x08\xfd\x9f\xec\x1a\xe0\xbb\x14\xea\x81\xcd\xa2\xa9\x0e'
    int_0 = 31
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    str_1 = 't\x90\xf2'
    str_

# Generated at 2022-06-25 06:35:36.306314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    tuple_0 = ()
    bytes_0 = b'oB\xaf\xf6\xf1'
    str_0 = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main'
    int_0 = 21
    action_module_0 = ActionModule(bool_0, dict_0, tuple_0, bytes_0, str_0, int_0)
    var_0 = action_module_0.run()
    var_1 = action_module_0.run()
    dict_1 = {'a': 'var_0', 'b': 'var_1'}
    var_0.update(dict_1)
    assert var_0 == var_