

# Generated at 2022-06-25 06:26:42.890570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = "Given a concrete collection pointer, return a cached path.\n\n        If it's not yet on disk, this method downloads the artifact first.\n        "
    bool_0 = False
    str_1 = 'v%n#$ny'
    str_2 = 'bak'
    str_3 = 'jk9X'
    action_module_0 = ActionModule(set_0, str_0, str_0, bool_0, str_1, str_2)
    dict_0 = {}
    dict_1 = {'tmp': str_3}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_3['dest'] = str

# Generated at 2022-06-25 06:26:43.817198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 06:26:54.657173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_dict = {
        "src": 'TQ9qs8',
        "dest": 'Y3HJD3',
        "delimiter": '%H46^R',
        "remote_src": 'zPvY5H',
        "regexp": 'oLcZ@H',
        "follow": True,
        "ignore_hidden": True
    }


# Generated at 2022-06-25 06:27:04.802057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = "Given a concrete collection pointer, return a cached path.\n\n        If it's not yet on disk, this method downloads the artifact first.\n        "
    module_name_0 = 't'
    bool_0 = False
    str_1 = 'v%n#$ny'
    os_0 = os
    os_path_0 = os.path
    ansible_action_0 = AnsibleAction
    _ansible_action_done_0 = _AnsibleActionDone
    ansible_action_fail_0 = AnsibleActionFail
    ansible_error_0 = AnsibleError
    to_native_0 = to_native
    to_text_0 = to_text
    ansible_plugins_action_0 = ActionBase

# Generated at 2022-06-25 06:27:12.472797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = "Given a concrete collection pointer, return a cached path.\n\n        If it's not yet on disk, this method downloads the artifact first.\n        "
    bool_0 = False
    str_1 = 'v%n#$ny'
    action_module_1 = ActionModule(set_0, str_0, str_0, bool_0, str_1, str_1)
    #TODO - add tests for method ActionModule.run


# Generated at 2022-06-25 06:27:17.836702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = "Given a concrete collection pointer, return a cached path.\n\n        If it's not yet on disk, this method downloads the artifact first.\n        "
    bool_0 = False
    str_1 = 'v%n#$ny'
    assert callable(ActionModule)
    action_module_0 = ActionModule(set_0, str_0, str_0, bool_0, str_1, str_1)
    assert isinstance(action_module_0, __builtin__.object)
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 06:27:27.662688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = "Given a concrete collection pointer, return a cached path.\n\n        If it's not yet on disk, this method downloads the artifact first.\n        "
    bool_0 = False
    str_1 = 't=PQt'
    str_2 = '4:*Bd'
    action_module_0 = ActionModule(set_0, str_0, str_0, bool_0, str_1, str_2)
    e = AnsibleError('z')
    task_vars = dict()
    with pytest.raises(AnsibleActionFail):
        action_module_0.run('', task_vars)
    str_3 = 'G=^Np'
    str_4 = 'KBI'
    dict_0 = dict()


# Generated at 2022-06-25 06:27:28.452819
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert test_case_0() == None


# Generated at 2022-06-25 06:27:29.266584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:35.379297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = "Given a concrete collection pointer, return a cached path.\n\n        If it's not yet on disk, this method downloads the artifact first.\n        "
    bool_0 = False
    str_1 = 'v%n#$ny'
    action_module_0 = ActionModule(set_0, str_0, str_0, bool_0, str_1, str_1)
    dict_0 = dict()
    dict_1 = dict()
    action_module_0.run(dict_0, dict_1)
    # assert False # Dummy method that does not compare arguments or return anything



# Generated at 2022-06-25 06:27:51.669119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0.0, 0, '', 0.0, {}, '')
    action_module_0.run()


# Generated at 2022-06-25 06:27:59.010244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # TODO: setup test values for all properties
    # TODO: setup test values for all args
    # TODO: setup test values for all task_vars

    # TODO: replace all calls to random things with test values
    # TODO: replace all asserts with appropriate verify
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:28:06.261857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dest = 'C:\\Users\\ywAQF\\AppData\\Local\\Temp\\_ansible_tmp_files/ansible_tmp_1574255737.43-128192424660112'
    action_module_0 = ActionModule(0, 0, 0, 0, {}, '')
    assert True == action_module_0._Supports_check_mode
    assert None == action_module_0._remote_tmp
    assert dest == action_module_0._connection
    return action_module_0


# Generated at 2022-06-25 06:28:13.493234
# Unit test for constructor of class ActionModule
def test_ActionModule():

    error_string = '[ERROR]: %s'

    # Create an action module with a task, a connection, and a play context
    dummy_task = DummyTask()
    dummy_connection = DummyConnection()
    dummy_play_context = DummyPlayContext()
    action_module = ActionModule(dummy_task, dummy_connection, dummy_play_context, error_string)

    # Create an action module with a task, a connection, and a play context
    dummy_task = DummyTask()
    dummy_connection = DummyConnection()
    dummy_play_context = DummyPlayContext()
    action_module = ActionModule(dummy_task, dummy_connection, dummy_play_context, error_string)


# Base class for unit test

# Generated at 2022-06-25 06:28:14.465913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    test_case_0()

# Generated at 2022-06-25 06:28:16.827259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(None, None, None, None, None, None)
    var_1 = None
    var_2 = None
    var_3 = var_0.run(var_1, var_2)
    assert var_3 is None

# Generated at 2022-06-25 06:28:22.834115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -836
    float_0 = 0.767508978947
    dict_0 = {}
    tuple_0 = (1, 2, 3)
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, dict_0, dict_0, str_0)
    action_module_0.run()

# Generated at 2022-06-25 06:28:28.061580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = action_module_0.run(None, None)


# Generated at 2022-06-25 06:28:38.337800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -348
    var_0 = 1.715306017
    tuple_0 = (78, 63, 30)
    float_0 = 175.88918
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(int_0, var_0, tuple_0, float_0, dict_0, str_0)
    str_1 = 'c'
    dict_1 = dict()
    dict_2 = dict()
    dict_1['copy'] = dict_2
    dict_3 = dict()
    dict_2['module'] = dict_3
    dict_2 = dict()
    dict_3['basic'] = dict_2
    dict_4 = dict()
    dict_2['dest'] = dict_4
    dict

# Generated at 2022-06-25 06:28:43.400619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    return

# Generated at 2022-06-25 06:29:05.258919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:29:06.902163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:29:12.473760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 66.4714507429308
    int_0 = -882
    tuple_0 = (b'\x8d',)
    float_1 = 98.9102402429308
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    action_module_0.run('tmp', task_vars = {})
#

# Generated at 2022-06-25 06:29:18.975576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    assert action_module_0._filter_loader_0 == float_0
    assert action_module_0._ds_0 == int_0
    assert action_module_0._async_timeout_0 == tuple_0
    assert action_module_0._task_vars_0 == float_0
    assert action_module_0._task_0 == dict_0
    assert action_module_0._task_name_0

# Generated at 2022-06-25 06:29:20.910766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(action_module_0) == ActionModule
    assert action_module_0._task_vars == {}
    assert action_module_0._supports_check_mode == False
    assert action_module_0._supports_async == False


# Generated at 2022-06-25 06:29:25.428466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        var_0 = action_module_0.run()
    except Exception as e:
        print("Uncaught exception in run()")
    else:
        print("Executing run()")
    finally:
        print("Finally block")


# Generated at 2022-06-25 06:29:31.690896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:29:35.104793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:29:36.805686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test start!')
    test_case_0()
    print('Test end!')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:29:39.824201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(var_0, var_1, var_2)
    assert isinstance(action_module_0.run(var_0), dict)


# Generated at 2022-06-25 06:30:26.825090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    assert action_module_0._supports_check_mode == False
    action_module_0._supports_check_mode = False


# Generated at 2022-06-25 06:30:31.934088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    assert (isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 06:30:36.742284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)


# Generated at 2022-06-25 06:30:39.625572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    bytes_0 = b'\x07'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    float_0 = 10.0
    str_0 = '**'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:30:46.324585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    

# Generated at 2022-06-25 06:30:55.201411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = '\n[ERROR]: %s'
    action_module_0.run(str_0)
    str_0 = '\n[ERROR]: %s'
    action_module_0.run(str_0)
    str_0 = '\n[ERROR]: %s'
    action_module_0.run(str_0)
    str_0 = '\n[ERROR]: %s'
    action_module_0.run(str_0)
    str_0 = '\n[ERROR]: %s'
    action_module_0.run(str_0)
    str_0 = '\n[ERROR]: %s'
    action_module_0.run(str_0)


# Generated at 2022-06-25 06:31:00.002278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = action_run(dict_0)

    assert var_0 is not None


# Generated at 2022-06-25 06:31:08.625773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -65.45357
    int_0 = -943

# Generated at 2022-06-25 06:31:10.655398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_0 = ActionModule()
    obj_0 = class_0.run()
    assert obj_0


# Generated at 2022-06-25 06:31:16.809779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    test_case_0()

# Method run of class ActionModule calls method run of class ActionBase

# Generated at 2022-06-25 06:32:46.587148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    float_1 = action_module_0.run()
    float_2 = action_module_0.run()
    float_3 = action_module_0.run()
    float_4 = action_module_0.run()
    float_5 = action_module_0.run()
    float_6 = action_module_0.run()
    float_7 = action_module_0.run()
    float_

# Generated at 2022-06-25 06:32:51.043352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = [action_module_0.run() for x in range(5)]


# Generated at 2022-06-25 06:32:57.283306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 257.694
    int_0 = 437
    bytes_0 = b'\xa8'
    tuple_0 = (bytes(0),)
    dict_0 = {}
    str_0 = '\rKEY = %(key)s\nVALUE_FROM = %(value_from)s\n'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    tmp_0 = None
    task_vars_0 = dict()
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    tmp_0 = None
    task_vars_0 = dict()

# Generated at 2022-06-25 06:33:01.283405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = test_case_0()
    task_vars_0 = tmp_0
    action_module_1 = ActionModule(ActionModule, ActionModule, ActionModule, ActionModule, ActionModule, ActionModule)
    action_module_1.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:33:04.289453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:33:12.488932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -436.947127715
    int_0 = -143
    bytes_0 = b'\x01\xa0\x80\xc5\x9d\x1a\x1e\xf2\xf5\x96\x18\xb6\x0e3\x1a\xbc\\'
    tuple_0 = (bytes_0,)
    dict_0 = {}

# Generated at 2022-06-25 06:33:18.249141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 486.9753
    int_0 = -338
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    tmp_0 = None
    task_vars_0 = {}
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    print(var_0)


# Generated at 2022-06-25 06:33:24.853686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    var_0 = action_module_0.run('tmp')

# Generated at 2022-06-25 06:33:32.031560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.84
    int_0 = -43
    bytes_0 = b'\x0f\x15\x1b\x1d\x1f\xc9'
    tuple_0 = (b'\xa0', b'\x96', b'\xc3', b'\x7f\xa6\x15')
    str_0 = 'This is a string'
    list_0 = ['\x1f', '\x11']
    dict_0 = {'a': -33, 'b': b'\xb0', 'c': -43}
    action_module_0 = ActionModule(float_0, int_0, tuple_0, 'This string', dict_0, str_0)
    action_module_0.set_play_context(play_context_0)
   

# Generated at 2022-06-25 06:33:38.732803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 175.88918
    int_0 = -348
    bytes_0 = b'\xd4'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '\n[ERROR]: %s'
    action_module_0 = ActionModule(float_0, int_0, tuple_0, float_0, dict_0, str_0)
    float_1 = action_module_0.float_0
    str_1 = action_module_0.str_0
    int_1 = action_module_0.int_0
    dict_1 = action_module_0.dict_0
    float_2 = action_module_0.float_1
    tuple_1 = action_module_0.tuple_0
    assert float_0 == float_1
