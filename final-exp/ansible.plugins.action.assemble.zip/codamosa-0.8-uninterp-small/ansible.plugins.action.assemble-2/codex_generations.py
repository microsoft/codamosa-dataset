

# Generated at 2022-06-25 06:26:36.668941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\n\nTesting run in module test_case_0')
    test_case_0()


# Generated at 2022-06-25 06:26:46.528557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -713
    str_0 = 'c%p!9&]{g?d'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, str_0, int_0, int_0]
    float_0 = -1215.0
    action_module_0 = ActionModule(int_0, float_0, bool_0, list_0, float_0, str_0)
    tmp = 'tmp'
    task_vars = [float_0, int_0, int_0, str_0, str_0, int_0, int_0, str_0, str_0, str_0, int_0]
    result = action_module_0.run(tmp, task_vars)

    assert result.get("failed", False)

# Generated at 2022-06-25 06:26:55.323554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    float_0 = -1468.0
    bool_0 = False
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    list_0 = [int_0, str_0, str_0, bool_0]
    str_1 = '\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007'
    str_2 = ':-'
    dict_0 = {str_0: str_2, str_1: int_0, str_2: str_0}
    action_module_0 = ActionModule(int_0, float_0, bool_0, list_0, float_0, str_0)
    actio

# Generated at 2022-06-25 06:26:57.605869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()
    print("Test completed successfully!")

# Generated at 2022-06-25 06:27:02.985947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -51
    str_0 = 'v.N9'
    bool_0 = True
    list_0 = [str_0, int_0, str_0, str_0, int_0]
    float_0 = 1030.0
    action_module_0 = ActionModule(int_0, float_0, bool_0, list_0, float_0, str_0)
    run_0 = action_module_0.run()


# Generated at 2022-06-25 06:27:14.526466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    dict_0 = {}
    bool_1 = True
    action_module_0 = ActionModule(int_0, float_0, bool_0, list_0, float_0, str_0)
    action_module_0._execute_module(str_0, dict_0)
    action_module_0._execute_remote_stat(str_0, True, bool_1)
    action_module_0._transfer_file(str_0, str_0)
    action_module_0.run(dict_0)

# Generated at 2022-06-25 06:27:17.523821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:27.347759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1421
    str_0 = '$T6.P'
    bool_0 = False
    list_0 = [int_0, str_0, str_0]
    float_0 = 1386.0
    action_module_0 = ActionModule(int_0, float_0, bool_0, list_0, float_0, str_0)
    int_0 = -3507
    str_0 = '8'
    bool_0 = False
    list_0 = [int_0, str_0]
    float_0 = -58.0
    tmp_0 = None
    task_vars_0 = dict(list_0=list_0, float_0=float_0, str_0=str_0, int_0=int_0)
    result = action_module

# Generated at 2022-06-25 06:27:28.155507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:32.917339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = 'src'
    dest = 'dest'
    action_module_0 = ActionModule()
    action_module_0.set_task({'args': {"src": src, "dest": dest}})
    tmp = 'tmp'
    task_vars = {'list_0': [0, 1, 2, 3]}
    test_result = action_module_0.run(tmp, task_vars)
    print(test_result)


# Generated at 2022-06-25 06:27:45.450627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:27:48.241338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_3 = ActionModule()
    test_case_0()


if __name__ == '__main__':
    print('Testing started')
    print('Testing method run of class ActionModule')
    test_ActionModule_run()
    print('Testing completed')

# Generated at 2022-06-25 06:27:51.544654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_ActionModule_instance = ActionModule()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:27:57.053368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Initializing a task with an empty task_vars")
    test_task_vars = {}
    am_1 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print("Testing run method of class ActionModule")
    am_1.run(tmp=None, task_vars=test_task_vars)
    print("Method run of class ActionModule tested")
    res = am_1.run(tmp=None, task_vars=test_task_vars)
    print(res)
    print("\n-----\n")


# Generated at 2022-06-25 06:27:59.482942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n\nTesting constructor of class ActionModule'
    var_0 = print(str_0)
    actionmodule = ActionModule()
    var_1 = print('\n')
    var_2 = print(actionmodule)


# Generated at 2022-06-25 06:28:03.502015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Imp class to test private method _assemble_from_fragments in class ActionModule
    class Imp:
        def __init__(self):
            pass
        def __enter__(self):
            pass
        def __exit__(self, exc_type, exc_value, traceback):
            pass
    imp = Imp()
    imp._assemble_from_fragments = (lambda *args, **kwargs: test_case_0())
    imp.run = ActionModule.run
    imp.run('test_path', {'test_dict': ['one', 'two', 'three']})


# Generated at 2022-06-25 06:28:07.985992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run in class ActionModule')
    test_case_0()

if __name__ == '__main__':
    print('Testing ansible.plugins.action.assemble.ActionModule')
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:14.872182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()
    assert var_0 == None, 'Test for method run of class ActionModule'
# -*- -*- -*- End included fragment: class/action_module.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: lib/ansible/module_utils/urls.py -*- -*- -*-


# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible.module_utils.six.moves.urllib.parse import urlsplit
from ansible.module_utils.six.moves.urllib.parse import urlunsplit

# Generated at 2022-06-25 06:28:15.824676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 06:28:24.355158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = 'src'
    dest = 'dest'
    delimiter = 'delimiter'
    remote_src = 'remote_src'
    regexp = 'regexp'
    follow = 'follow'
    ignore_hidden = 'ignore_hidden'
    decrypt = 'decrypt'
    tmp = 'tmp'
    task_vars = 'task_vars'
    # Call run of class ActionModule with parameters
    res = ActionModule.run(src, dest, delimiter, remote_src, regexp, follow, ignore_hidden, decrypt, tmp, task_vars)

# Generated at 2022-06-25 06:28:35.952285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:28:43.253108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.set_task({})
    action_module.set_loader({})
    action_module.set_play_context({})
    action_module._remove_tmp_path(action_module._connection._shell.tmpdir)
    action_module._remote_expand_user(action_module._task.args.get('dest', None))
    action_module._get_diff_data(action_module._remote_expand_user(action_module._task.args.get('dest', None)), 'path', task_vars=None)

# Generated at 2022-06-25 06:28:45.652152
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # constructor test without any mandatory parameters
    action_module_1 = ActionModule()

    # constructor test with arguments
    action_module_2 = ActionModule(connection=None,
                                   play_context=None,
                                   loader=None,
                                   templar=None,
                                   shared_loader_obj=None)



# Generated at 2022-06-25 06:28:51.644278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    try:
        assert action_module_0
    except AssertionError as e:
        raise(AssertionError(to_text(e) + ' on line {}'.format(sys._getframe().f_lineno)))

# Generated at 2022-06-25 06:29:01.846910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    setattr(action_module_0, '_execute_module', lambda *args, **kwargs: {'failed': False})
    setattr(action_module_0, '_remote_expand_user', lambda *args, **kwargs: '~/%s' % args[0])
    setattr(action_module_0, '_execute_remote_stat', lambda *args, **kwargs: {'checksum': 'cbc147aa7bcc6f5d6f5426d14c9ca9fb'})
    setattr(action_module_0, '_get_diff_data', lambda *args, **kwargs: {'failed': True})

# Generated at 2022-06-25 06:29:08.176976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # /home/pwntester/workspace/ansible-devel/test/units/module_utils/basic.py:283: in run
    # [0]     def run(self, tmp=None, task_vars=None):
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result_0 is not None


# Generated at 2022-06-25 06:29:10.392240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp_1 = None
    task_vars_1 = None
    action_module_1.run(tmp_1, task_vars_1)


# Generated at 2022-06-25 06:29:12.474382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import pdb; pdb.set_trace()
    action_module_0 = ActionModule()
    action_module_0.run()



# Generated at 2022-06-25 06:29:13.501943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # _supports_check_mode
    assert ActionModule()._supports_check_mode == False


# Generated at 2022-06-25 06:29:15.749725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = test_case_0()
    try:
        assert result
    except AssertionError as e:
        print(e)
        raise

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:29:41.654312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == None
    return None

# Generated at 2022-06-25 06:29:42.541475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    action_module_run.run()

# Generated at 2022-06-25 06:29:46.558434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:29:53.828756
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test data
    tmp = None
    task_vars = {}

    action_module = ActionModule()

    # Prerequisites - nothing to test
    action_module._execute_module = lambda module_name, module_args, task_vars: {}

    # Test execution
    result = action_module.run(tmp, task_vars)

    # Verify inputs
    assert(action_module._execute_module.call_count == 2)




# Generated at 2022-06-25 06:29:55.965772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    pass

# Generated at 2022-06-25 06:29:57.476181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp='tmp', task_vars='task_vars')


# Generated at 2022-06-25 06:30:04.586337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._connection = {}
    action_module_1._shell = {}
    action_module_1._shell.join_path = lambda a, b: a + b
    action_module_1._shell.tmpdir = ''
    action_module_1._shell.join_path(action_module_1._shell.tmpdir, 'src')

if __name__ == '__main__':
    import pytest

    pytest.main(["-v", "-s", "test_action_module.py"])

# Generated at 2022-06-25 06:30:10.867068
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Using mock patch to replace the module
    # ansible.module_utils.basic.AnsibleModule with an object that
    # simulates it.
    @mock.patch('ansible.module_utils.basic.AnsibleModule')
    def test_run_0(MockAnsibleModule):

        # Preparing test environment by creating mock objects.
        module_params = dict(src='foo.bar', dest='foo.bar',
                             delimiter='foo.bar', regexp='foo.bar',
                             follow='foo.bar', ignore_hidden='foo.bar',
                             decrypt='foo.bar')

        mock_module = MockAnsibleModule.return_value
        mock_module.params = module_params

        action_module_0 = ActionModule()

        # Calling methods on mock objects that simulate the module ans

# Generated at 2022-06-25 06:30:13.401241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:30:22.919533
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
    action_module_0 = ActionModule() 
    tmp = '/root/anaconda3/envs/ansible_test/lib/python3.7/site-packages/ansible/modules/files' 

# Generated at 2022-06-25 06:30:52.521909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    print('Testing constructor of class ActionModule')
    print('Expected value:')

# Generated at 2022-06-25 06:30:57.995821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)


# Generated at 2022-06-25 06:31:01.070440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    
    action_module_0 = ActionModule(0, 0, 0.0, 0, 0.0, 0)
    dict_0 = dict()
    action_module_0.run(0, dict_0)

# Generated at 2022-06-25 06:31:09.198042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    assert(action_module_0.__was_executed__ == False)
    assert(action_module_0.__was_executed_once__ == False)
    assert(action_module_0._supports_check_mode == False)

# Generated at 2022-06-25 06:31:13.747235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    # test_case_0()
    print(action_module_0)



# Generated at 2022-06-25 06:31:21.109082
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test properties of class ActionModule
    assert not hasattr(ActionModule, "supports_check_mode"), \
        "`ActionModule` class does not have attribute `supports_check_mode`"
    assert hasattr(ActionModule, "run"), \
        "`ActionModule` class does not have method `run`"
        # Test number of arguments of method run of class ActionModule
    try:
        action_module = ActionModule()
        action_module.run()
    except TypeError:
        assert False, \
            "Method `run` of `ActionModule` class takes exactly %d arguments (1 given)" % action_module.run.__code__.co_argcount

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('Tests passed!')

# Generated at 2022-06-25 06:31:27.629782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:31:35.285466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    test_case_0()

# Generated at 2022-06-25 06:31:40.661561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    test_case_0()

# Generated at 2022-06-25 06:31:51.277974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    int_1 = -469
    str_2 = 'qrh/Zfh\n}S#:c^#em'
    bool_1 = False
    list_1 = [int_0, str_0, str_0, bool_0]
    float_1 = -1468.0


# Generated at 2022-06-25 06:32:40.393488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    str_2 = '|v5@5+'
    bool_1 = True
    str_3 = '_\x1b&U]?6\x1d'
    float_1 = -2758.0
    int_1 = -65

# Generated at 2022-06-25 06:32:49.885847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#9`B%]^d|@'
    str_1 = '&|wV7G^Yz}'
    bool_0 = False
    list_0 = [str_0, bool_0, bool_0, bool_0]
    float_0 = -977.0
    str_2 = '~%pG+t[0bR'
    int_0 = 148
    action_module_0 = ActionModule(int_0, str_1, bool_0, list_0, float_0, str_2)
    action_module_0.run()

if __name__ == '__main__':
    res = test_ActionModule_run()
    print(res)

# Generated at 2022-06-25 06:33:00.197298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    assert action_module_0.action_module_0 == int_0, "action_module_0 property of class ActionModule is not set correctly"
    assert action_module_0.action_module_1 == str_0, "action_module_1 property of class ActionModule is not set correctly"
    assert action

# Generated at 2022-06-25 06:33:08.239475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)



# Generated at 2022-06-25 06:33:15.384260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    assert action_module_0._connection is None
    assert action_module_0.test_compile_regexp_0 is not None


# Generated at 2022-06-25 06:33:17.127716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test execution with test_case_0
    test_case_0()


# Generated at 2022-06-25 06:33:19.621690
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)

    print(action_module_0.run())



# Generated at 2022-06-25 06:33:20.140448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:33:27.172470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    action_run()

# Generated at 2022-06-25 06:33:34.382774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0, 'Fx7Cp', True, [31.48341805, 'zf.A', 'Dj=M2s&y\x0bqvk', False], -35.81732409, 't&Ffnv(S%c_8')
    action_module_0.run()


# Generated at 2022-06-25 06:34:57.759030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    var_0 = action_run()


# Generated at 2022-06-25 06:34:59.940249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import time

    start_time = time.time()
    test_case_0()
    print("--- %s seconds ---" % str(time.time() - start_time))

# Generated at 2022-06-25 06:35:05.021973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    var_0 = []
    var_1 = action_run(var_0)


# Generated at 2022-06-25 06:35:13.127923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = -468
  str_0 = "pm"
  bool_0 = False
  list_0 = [int_0, str_0, str_0, bool_0]
  float_0 = -46.0
  str_1 = "6\n)N"
  var_0 = TaskModule(int_0, str_0, bool_0, list_0, float_0, str_1)
  str_2 = "n"
  dict_0 = dict()
  var_1 = var_0.run(str_2, dict_0)
  return var_1


# Generated at 2022-06-25 06:35:19.128541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)


# Generated at 2022-06-25 06:35:26.014822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -999
    str_0 = 'A_NzsxC&~\n@YFW/<6T'
    bool_0 = False
    list_0 = [float_0, list_0, int_0, str_0]
    float_0 = -303.0
    str_1 = '_gZ,i2QXkC(Iot[:=0i'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    action_module_0.run()


if __name__ == "__main__":
    module_type_store(explore_types(), locals(), globals())

# Generated at 2022-06-25 06:35:29.881178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    return action_module_0


# Generated at 2022-06-25 06:35:33.436509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0b{h$<~'
    action_module_0 = ActionModule(str_0)
    module_name = 'ansible.legacy.file'
    module_args = dict() # <class 'dict'>
    var_0 = action_module_0.run(module_name, module_args)


# Generated at 2022-06-25 06:35:39.471384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -469
    str_0 = 'qrh/Zfh\n}S#:c^#em'
    bool_0 = False
    list_0 = [int_0, str_0, str_0, bool_0]
    float_0 = -1468.0
    str_1 = 'C_5WHy0O*Ys'
    action_module_0 = ActionModule(int_0, str_0, bool_0, list_0, float_0, str_1)
    var_0 = action_run()

# Test suite for class ActionModule

# Generated at 2022-06-25 06:35:40.286226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True
