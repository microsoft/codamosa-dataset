

# Generated at 2022-06-25 06:26:40.118606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = None
    set_0 = {action_module_1}
    bool_0 = True
    int_0 = 2539
    action_module_2 = ActionModule(int_0, action_module_1, set_0, bool_0, action_module_1, int_0)


# Generated at 2022-06-25 06:26:44.911750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = None
    set_0 = {action_module_1}
    bool_0 = True
    int_0 = 6891
    action_module_2 = ActionModule(int_0, action_module_1, set_0, bool_0, action_module_1, int_0)
    return 0


# Generated at 2022-06-25 06:26:49.596946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = None
    set_0 = set()
    bool_0 = True
    int_0 = 5585
    action_module_1 = ActionModule(int_0, action_module_0, set_0, bool_0, action_module_0, int_0)


# Generated at 2022-06-25 06:26:50.387726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:26:53.178626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_4 = 'tmp'
    task_vars_4 = {}
    action_module_4 = ActionModule(2539, None, {}, True, None, 2539)

    # Call method run
    result = action_module_4.run(tmp_4, task_vars_4)


# Generated at 2022-06-25 06:26:58.918688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = None
    set_1 = {action_module_2}
    bool_1 = True
    int_1 = 5372
    action_module_3 = ActionModule(int_1, action_module_2, set_1, bool_1, action_module_2, int_1)


# Generated at 2022-06-25 06:27:03.151830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = None
    set_1 = {action_module_2}
    bool_1 = True
    int_1 = 2539
    action_module_3 = ActionModule(int_1, action_module_2, set_1, bool_1, action_module_2, int_1)
    action_module_3.run()

# Generated at 2022-06-25 06:27:09.895335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    set_0 = {action_module_0}
    bool_0 = True
    int_0 = 2539
    action_module_1 = ActionModule(int_0, action_module_0, set_0, bool_0, action_module_0, int_0)
    action_module_2 = None
    action_module_3 = action_module_1.run(action_module_2, action_module_2)


# Generated at 2022-06-25 06:27:17.836821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    set_0 = {action_module_0}
    bool_0 = True
    int_0 = 2539
    action_module_1 = ActionModule(int_0, action_module_0, set_0, bool_0, action_module_0, int_0)
    task_vars_0 = None
    tmp_0 = None
    dict_0 = dict()
    dict_0['checksum'] = '7e46e2414bbe7c83773f87f9c3b3ceea'
    dict_0['path'] = 'test_path_1'
    dict_0['state'] = 'file'
    dict_0['dest'] = 'test_dest_1'
    dict_0['gid'] = '5042'

# Generated at 2022-06-25 06:27:19.553103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 06:27:37.584253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 18400
    bool_0 = True
    int_1 = 900
    bool_1 = True
    bool_2 = True
    int_2 = 400
    action_module_0 = ActionModule(int_0, bool_0, int_1, bool_1, bool_2, int_2)
    assert action_module_0.task._parent is None
    assert action_module_0._supports_check_mode is False
    assert action_module_0._supports_async is False
    assert action_module_0.task_vars == {}
    assert action_module_0.play_context.check_mode is False
    assert action_module_0.play_context.no_log is False
    assert action_module_0.play_context.become is False
    assert action_module_

# Generated at 2022-06-25 06:27:42.374275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 0
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)

    test_case_0()


# Generated at 2022-06-25 06:27:47.531037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 6400
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    bool_1 = action_module_0.run('tmp')

# Generated at 2022-06-25 06:27:53.275550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_1 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_2 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_3 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_4 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_5 = ActionModule

# Generated at 2022-06-25 06:27:56.646055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:57.403132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if True:
        test_case_0()

# Generated at 2022-06-25 06:28:02.564031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Parameters to run()
    tmp = None
    task_vars = None

    # Returns the value of attribute result
    result_0 = action_module_0.run(tmp, task_vars)
    return result_0


# Generated at 2022-06-25 06:28:07.661144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    file_name = "/tmp/test-action-module.txt"
    with open(file_name, "a") as test_file:
        test_file.write("testing ActionModule")
    test_case_0()

# Generated at 2022-06-25 06:28:09.715276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)


# Generated at 2022-06-25 06:28:14.010028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:28:31.256169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert_equals(1,1)
    except AssertionError as ae:
        print("Assertion error caught: {}".format(ae.__str__()))
# End of unit test for method run of class ActionModule

# Generated at 2022-06-25 06:28:36.800551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:28:39.957230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    var_0 = action_run()
    assert func_0()


# Generated at 2022-06-25 06:28:41.510784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'remote_tmp' in ActionModule().__dict__


# Generated at 2022-06-25 06:28:45.829057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 06:28:52.118167
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bool_0 = True if random.randint(1,100)%2 == 0 else False
  int_0 = random.randint(-100,100)
  action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)

# Generated at 2022-06-25 06:29:00.005174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(None, None, None, None, None, None)
    action_module_1.set_loader(ActionModule.set_loader)
    action_module_1.set_play_context(ActionModule.set_play_context)
    action_module_1.get_option=ActionModule.get_option
    action_module_1.run(action_module_1, test_case_0)

# Generated at 2022-06-25 06:29:05.427395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except (e):
        raise AssertionError(e)


# Generated at 2022-06-25 06:29:09.113101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 06:29:12.797864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare objects and variables
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)

    # Call run method of action_module_0
    result = action_module_0.run(var_0, var_1)
    assert result == var_2

# Generated at 2022-06-25 06:29:43.893075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module_0 = ActionModule()
    # Setup
    tmp_0 = u'tmp'
    task_vars_0 = {'ansible_check_mode': True, 'ansible_diff_mode': True}
    action_module_0._task.args = {'remote_src': False, 'regexp': False, 'src': u'src', 'ignore_hidden': False, 'dest': u'dest', 'delimiter': u'delimiter'}
    src_0 = u'src'
    dest_0 = u'dest'
    regexp_0 = False
    _re_0 = False
    encrypt_0 = True
    path_0 = u'path'

# Generated at 2022-06-25 06:29:45.740523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Example:
    # action_run()

    # Positive test cases
    test_case_0()

    # Negative test cases
    # Example:
    # assertEqual(action_run(), "expected result")



# Generated at 2022-06-25 06:29:51.966262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 06:29:59.815009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_0.run()
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0._supports_check_mode == False

# Generated at 2022-06-25 06:30:04.419905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, False, False, False, False, False)
    action_module.run("", True)

# Generated at 2022-06-25 06:30:07.350145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # See issue #20801
    action_module_0 = ActionModule(int(), bool(), int(), bool(), bool(), int())
    var_0 = action_module_0.run(int(), dict())
    if (var_0 is not None):
        raise Exception('Failed: var_0 is not None')

# Generated at 2022-06-25 06:30:10.597018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    return True


# Generated at 2022-06-25 06:30:16.632586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    var_0 = action_run()
    assert True


# Generated at 2022-06-25 06:30:22.855934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    # assert action_module_0._supports_check_mode == (False.)
    # assert type(action_module_0._supports_check_mode) == type(bool_0)


# Generated at 2022-06-25 06:30:25.293635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    var_0 = action_run()
    return var_0


# Generated at 2022-06-25 06:31:09.055981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:31:10.744322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:31:13.912651
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert  isinstance(ActionModule.run(1), dict)

# test_case_0()
# test_ActionModule_run()

# Generated at 2022-06-25 06:31:18.526679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 06:31:24.977068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    constructor of class ActionModule
    """
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)


# Generated at 2022-06-25 06:31:32.060338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 564795
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)



# Generated at 2022-06-25 06:31:36.311183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    test_case_0()

# Generated at 2022-06-25 06:31:40.764051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    destination_1 = action_module_0.run()


# Generated at 2022-06-25 06:31:44.018805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 06:31:50.781159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 9108
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    assert action_module_0 is not None
    assert action_module_0._connection is not None
    assert action_module_0._supports_check_mode is not None
    assert action_module_0._supports_async is not None
    assert action_module_0._task is not None
    # IMPORTANT: Don't delete the assert statements from this unit test. Module coverage doesn't function without them.


# Generated at 2022-06-25 06:33:26.825308
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:33:29.864365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_1 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)


# Generated at 2022-06-25 06:33:31.320630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    if (actionModule == None):
        raise Exception("Failed to create ActionModule object")


# Generated at 2022-06-25 06:33:35.569954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 06:33:45.473741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = {
      'ignore_hidden': False,
      'dest': 'string',
      'regexp': 'string',
      'src': 'string',
      'delimiter': 'string',
      'remote_src': True
    }
    action_module = ActionModule(mock_task, True, 1234, True, True, 1234)

    # Run the action
    result = action_module.run()

    # Check the result
    assert(result['failed'] == False)
    assert(result['changed'] == True)
    assert(result['rc'] == 0)
    assert(type(result['invocation']['module_args']) == dict)

# Generated at 2022-06-25 06:33:52.683077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6900
    bool_0 = True
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    dict_0 = dict()
    dict_0 = action_module_0.run(dict_0)
    assert dict_0.get('ansible_facts') == None
    assert dict_0.get('ansible_inventories') == None
    assert dict_0.get('results_file') == None

# Generated at 2022-06-25 06:33:58.683407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)
    assert_equal(action_module_0.TRANSFERS_FILES, True)
    assert_equal(action_module_0._module_name, 'ansible.legacy.assemble')
    assert_equal(action_module_0._supports_check_mode(), True)
    assert_equal(action_module_0._supports_async(), True)
    assert_equal(action_module_0.run(tmp=None, task_vars=None), var_0)


# Generated at 2022-06-25 06:34:00.906246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 6900
    action_module_0 = ActionModule(int_0, bool_0, int_0, bool_0, bool_0, int_0)

# Generated at 2022-06-25 06:34:04.462942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:34:06.064919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict({})
    dest = dict({})
    action_module_0 = ActionModule()
    action_module_0.run(task_vars,dest)