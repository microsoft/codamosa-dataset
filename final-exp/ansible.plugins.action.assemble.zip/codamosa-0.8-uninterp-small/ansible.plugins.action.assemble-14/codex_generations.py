

# Generated at 2022-06-25 06:26:42.889669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -9098.6426583
    bool_0 = False
    str_0 = '1Ft}'
    bytes_0 = b'\x90\x85\xc3\x98D\x0c\xfb\xd6\xdb\xa0\x7f\x1e\xc7\xb6\xd4\x8e\x11/}'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)

# Generated at 2022-06-25 06:26:51.733045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    assert isinstance(action_module_0.run(), dict)


# Generated at 2022-06-25 06:27:02.396775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    dict_1 = {}
    float_1 = -1991.0
    bool_1 = False
    str_1 = 'S@hL-K'
    bytes_1 = b"\xf3'e"

# Generated at 2022-06-25 06:27:14.372802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    # call with tmp = None and task_vars = None
    action_module_1 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    test_case_0()
    test_case_0()
    test_

# Generated at 2022-06-25 06:27:21.944540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    action_module_0._assemble_from_fragments('XI', '`', re.compile('[a-z]'), True, True)
    action_module_0.run()


# Generated at 2022-06-25 06:27:30.185872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)

    # Test with AssertionError
    with pytest.raises(AssertionError):
        action_module_0.run()

    # Test with AnsibleActionFail
    with pytest.raises(AnsibleActionFail):
        action_module_0.run()

# Generated at 2022-06-25 06:27:37.200821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    # Check if the object is instance of its parent
    assert isinstance(action_module_0, ActionBase)
    assert isinstance(action_module_0, object)
    # Test __init__ method
    assert action_module_0._supports_check_mode == False
    assert action

# Generated at 2022-06-25 06:27:46.671086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    result = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0).run()
    assert result['changed'] == True
    assert result['meta']['checksum'] == '7da6c8d895ee915c38f3a94baf1d80d59e7c1f9b'

# Generated at 2022-06-25 06:27:47.931609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Error with assertation: ", err)

# Generated at 2022-06-25 06:27:56.477766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(dict_0, dict_0, float_0, bool_0, str_0, bytes_0)
    dict_0 = {}
    dict_1 = {}
    dict_0 = {}
    dict_1 = {}
    dict_0 = {}
    dict_1 = {}
    dict_0 = {}
    dict_1 = {}
    dict_0 = {}
    dict_1 = {}

# Generated at 2022-06-25 06:28:15.229896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -199.751
    bool_0 = True
    str_0 = 'pZ~g[*a|J2?_%R1OPu&@(O\x0fQ\x0f\t'
    bytes_0 = b'W\xb8C\xec\x0f\xc4\xa1\xe0\x19\x98\x1co\x9b\x05\xd7\xc0\x97\xa1\xac\xf4\xfd\xcc'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    str_1 = action_module_0._loader

# Generated at 2022-06-25 06:28:24.287351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:28:30.804004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:31.635058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:28:39.612210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 06:28:45.610303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    action_module_0._supports_check_mode = float_0
    action_module_0._play_context = bool_0
    float_1 = -1991.0
    dict_0 = dict(float_1)

# Generated at 2022-06-25 06:28:55.132906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    if __package__ is None:
        import sys
        from os import path
        sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
        from ansible.module_utils.basic import AnsibleModule, missing_required_lib
        from ansible.module_utils._text import to_bytes, to_text

        from ansible.module_utils.six.moves.urllib.error import HTTPError
        from ansible.module_utils.six.moves.urllib.error import URLError

    # unit test for copy
    test_ActionModule()

# Generated at 2022-06-25 06:29:01.292092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 06:29:10.094819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)

    try:
        action_module_0.run()
    except Exception:
        assert False


# Generated at 2022-06-25 06:29:15.197089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'FsWR~1HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)


# Generated at 2022-06-25 06:29:57.034617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1976.98
    bool_0 = False
    str_0 = 'WR~HnQ-C\\:'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bool_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:29:57.950062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:30:06.034662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -881.78
    bool_0 = False
    str_0 = '\x9d'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 06:30:09.386779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = u'B@G|B?PtO#Fb\\Z'
    task_vars_0 = {}
    float_0 = -1976.98
    bool_0 = False
    str_0 = 'WR~HnQ-C\\:'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bool_0)
    action_module_0.run(u'B@G|B?PtO#Fb\\Z', task_vars_0)

# Generated at 2022-06-25 06:30:18.202796
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Set up test values
    tmp = None
    task_vars = dict()

    # set up object
    str_0 = 'GH~KIkE;M$'
    float_0 = -566.12
    bool_0 = False
    str_1 = 'b-L|HJDdt!'
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_1, str_1, bool_0)

    # Run method
    result = action_module_0.run(tmp, task_vars)

    assert result == dict()

# Generated at 2022-06-25 06:30:25.828420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1976.98
    bool_0 = False
    str_0 = 'WR~HnQ-C\\:'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bool_0)

    dummy_0 = DummyModuleLoader()
    assert callable(getattr(dummy_0, '_load_from_file', None))
    assert isinstance(action_module_0._loader, DummyModuleLoader)
    action_module_0._loader = dummy_0

    str_1 = 'Z:ze=l'
    assert isinstance(action_module_0._task, AnsibleTask)
    action_module_0._task = None
    assert isinstance(action_module_0._task, AnsibleTask)


# Generated at 2022-06-25 06:30:29.232853
# Unit test for constructor of class ActionModule
def test_ActionModule():

    str_0 = 'C'
    str_1 = 't'
    float_0 = -5.69199
    bool_0 = True
    str_2 = 'c'
    bool_1 = False

    action_module_0 = ActionModule(str_2, str_0, float_0, bool_1, str_1, bool_0) # ***
    action_module_0.run() # ***


# Generated at 2022-06-25 06:30:38.361431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1954.11
    bool_0 = True
    str_0 = '_i>``,[F4'
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bool_0)
    action_module_1 = ActionModule(str_0, float_0, float_0, bool_0, float_0, bool_1)
    action_module_1.result = dict()
    action_module_1.run(float_0, float_0)
    assert action_module_1.result['_ansible_no_log'] == True


# Generated at 2022-06-25 06:30:42.260898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1976.98
    bool_0 = False
    str_0 = 'WR~HnQ-C\\:'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bool_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 06:30:43.822482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0()
    pass

# Generated at 2022-06-25 06:31:28.637580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:31:37.341693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'r'
    float_0 = -1768.0
    bool_0 = False
    str_1 = '`'

# Generated at 2022-06-25 06:31:41.067565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule('ansible.legacy.assemble', _loader=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except Exception as err:
        print('test ActionModule(): An error occurred: {0}'.format(err))
        assert False


# Generated at 2022-06-25 06:31:47.511291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)

    # The function run of class ActionModule has a bug, l. 49, when the variable 'res' is not defined.
    var_0 = action_module_0.run()
    assert var_0 is None

# Line 49 in action_plugins/copy.py
# This test method verifies that the bug is fixed, when

# Generated at 2022-06-25 06:31:51.983807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_1 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 06:31:58.049920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3.2
    bool_0 = True
    str_0 = 'C@\x9d\x0c\x0cp'
    bytes_0 = b'6\x97\xe7\xc5\xca\xe5\xb2\xa4\xdc\x05\x1d\x80\xfe`\xe3'
    str_1 = 'cR\xcc'
    # Call constructor of class ActionModule
    # Note: We call the constructor even if we don't use the object afterwards
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    action_module_1 = ActionModule(str_1, str_0, float_0, bool_0, str_1, bytes_0)


# Generated at 2022-06-25 06:32:02.656616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_2 = -1076.0
    bool_1 = True
    str_2 = 'r#'
    bytes_1 = b'!\x99\xe8\x1f\xfa\xed\xeb\x8d\xab\x7f\x12$\xf8h\xc6\x9f\x97\xe0\x91'
    action_module_2 = ActionModule(str_2, str_2, float_2, bool_1, str_2, bytes_1)
    assert(type(action_module_2) == ActionModule)
    assert(action_module_2.method == str_2)
    assert(action_module_2.module == str_2)
    assert(action_module_2.timeout == float_2)

# Generated at 2022-06-25 06:32:11.227541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1991.0
    bool_0 = True
    str_0 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    var_0 = action_module_0.test_case_0()
    assert var_0 == True

# Generated at 2022-06-25 06:32:17.430087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.0
    bool_0 = False
    str_0 = 'ntjd^`s'
    bytes_0 = b'\xad\xda\x1e\x0e\x15\xee\xf8\x9a\xa6\x92\x1f\x00\x0b\xaa\xdc=\xc6S\xe5\x9a\x12\xd4'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    print(action_module_0.get_task_vars())


# Generated at 2022-06-25 06:32:24.363420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.0
    bool_0 = True
    str_0 = '1L\x81\x0b\x98'
    bytes_0 = b'\x0f\x9e\xf4\xa4\x8b\x06\x1f\x00\xad\xfc\xbdX\xf2\x9c\xcf'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:33:56.014951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    res_1 = action_module_0.run()
    # Test the expected result of action_module_0.run()
    assert res_1 == None


# Generated at 2022-06-25 06:34:04.734447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1991.0
    str_0 = 'WR~HnQC\\:'
    bool_0 = True
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    assert action_module_0._task_vars == {}
    assert action_module_0._supports_check_mode is False
    assert action_module_0.action == str_0
    assert action_module_0._loader == str_0
    assert action_module_0._connection == float_0

# Generated at 2022-06-25 06:34:09.653450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 6725.0
    bool_0 = True
    str_0 = "5!_"
    bytes_0 = b'\xb5\x13\xd5\x1f\x1d\xab\x8d\xf5\xef\xbd\xbe'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)

# Generated at 2022-06-25 06:34:13.032110
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: create test case
    assert True == True

# Generated at 2022-06-25 06:34:17.931999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2809.0
    bool_0 = False

# Generated at 2022-06-25 06:34:26.213566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1991.0
    str_0 = 'WR~HnQC\\:'
    bool_0 = True
    str_1 = 'WR~HnQC\\:'
    bytes_0 = b'=P`\xe6\x97\x0cg\xe9\xa0\x1d\x91+\x86\xa6\xf7\xb0\xfe\xb2i'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_1, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:34:33.636899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1997.0
    bool_0 = True
    str_0 = '\\WW?6\x0e\x17\x1a?'
    bytes_0 = b'\x1b\xe9l\x9f\x8b\x0b\xeb/\xd1I\xf1\x93\xbc\xb7\x9d\xcd\xbb'
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    str_1 = '@\x1d|\x1bg\x04\xf3m'
    bool_1 = True

# Generated at 2022-06-25 06:34:41.519276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1853.0
    bool_0 = True
    str_0 = 'd`\x85*\x01\x9e\x8e'
    bytes_0 = b"\xbf\xa4'\xe4\x96U\x10\x1e\xbc\xe2\x16\x00\xcc\xe8\x0c\xb3\x01\x83\x8a\x02\x17\x01\x0cW\x8c'"
    action_module_0 = ActionModule(str_0, str_0, float_0, bool_0, str_0, bytes_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:34:48.163692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = None
    action_module_1 = ActionModule(tmp, task_vars)
    assert len(action_module_1._supports_check_mode) == len(action_module_0._supports_check_mode)
    assert len(action_module_1.runner) == len(action_module_0.runner)
    assert len(action_module_1._task) == len(action_module_0._task)
    assert len(action_module_1.module_vars) == len(action_module_0.module_vars)


# Generated at 2022-06-25 06:34:56.839344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if str == bytes:
        string_type = basestring
    else:
        string_type = str

    t_ActionModule = ActionModule(
        task='test_task',
        connection='test_connection',
        play_context=123,
        loader='test_loader',
        templar='test_templar',
        shared_loader_obj='test_shared_loader_obj'
    )

    assert isinstance(t_ActionModule.task, AnsibleTask)
    assert isinstance(t_ActionModule.connection, Connection)
    assert t_ActionModule.play_context == 123
    assert isinstance(t_ActionModule.loader, DataLoader)
    assert isinstance(t_ActionModule.templar, Templar)