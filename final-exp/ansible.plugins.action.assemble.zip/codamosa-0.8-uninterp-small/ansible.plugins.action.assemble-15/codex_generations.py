

# Generated at 2022-06-25 06:26:42.833619
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:26:51.687318
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_0 = 445.05872
    set_0 = {str_0, float_0, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, set_0, float_0)

    action_module_0.run()


# Generated at 2022-06-25 06:27:02.332823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = 'src'
    dest = 'dest'
    delimiter = 'delimiter'
    remote_src = 'remote_src'
    regexp = 'regexp'
    follow = True
    ignore_hidden = True
    decrypt = False
    test_args = {'src': src, 'dest': dest, 'delimiter': delimiter, 'remote_src': remote_src, 'regexp': regexp, 'follow': follow, 'ignore_hidden': ignore_hidden, 'decrypt': decrypt}
    test_obj = ActionModule(None, None, None, None, None, None)
    test_obj.tmp = 'tmp'
    test_obj.task_vars = 'task_vars'

# Generated at 2022-06-25 06:27:09.306281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    # Init method is already tested in test_case_0
    # Test all parameters
    play_context_0 = {}
    connection_0 = {}
    in_data_0 = {}
    action_plugin_0 = {}
    play_context_1 = {}
    connection_1 = {}
    in_data_1 = {}
    action_plugin_1 = {}
    test_case_0()

# Generated at 2022-06-25 06:27:16.053000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_0 = 445.05872
    set_0 = {str_0, float_0, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, set_0, float_0)

# Generated at 2022-06-25 06:27:23.694808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_0 = 445.05872
    set_0 = {str_0, float_0, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, set_0, float_0)


# Generated at 2022-06-25 06:27:31.924861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xa2\x1d#\x8c\xef"\xd1\xc2\x1f\x8eU6\x81'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    set_0 = {bytes_0, float_0, str_0, str_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, set_0, float_0)
    assert(action_module_0.tmp == bytes_0)
    assert(action_module_0.task_vars == str_0)
    assert(action_module_0._task == float_0)

# Generated at 2022-06-25 06:27:33.205842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:27:39.445322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_1 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_1 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_1 = {str_1, float_1, str_1, bytes_1}
    action_module_1 = ActionModule(bytes_1, str_1, float_1, float_1, set_1, float_1)
    assert action_module_1 is not None
    assert type(action_module_1) == ActionModule
    assert getattr(action_module_1, '_connection') == bytes_1
    assert getattr(action_module_1, '_task') == str_1
   

# Generated at 2022-06-25 06:27:41.020120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:54.896886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'RS\xcd\x9b\x07\x98\xf7\xd2\xad\xc0\xdfU'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)
    assert action_module_0._supports_check_mode == False


# Generated at 2022-06-25 06:28:00.627327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'RS\xcd\x9b\x07\x98\xf7\xd2\xad\xc0\xdfU'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)
    assert action_module_0._task.module_args == {'become': True, 'become_user': 'root', 'become_method': 'sudo'}
    assert len(action_module_0._task.args) == 0


# Generated at 2022-06-25 06:28:08.650840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xde\x8c\x96\xe1\x01\xfe\x8e\x9d\xacG\x13\x8bw'
    str_0 = 'gr\x10\x8c\xe9\x92\xc5\xaf\n\xccb\x87\x80\x10'
    float_0 = 6722.026
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)
    str_1 = 'w\xeb\xec\xbc\x10\x8a\xe2\x88\xf7F\xc8\x06\x93'
    dict_0 = dict()
    dict_1 = dict()
    dict_

# Generated at 2022-06-25 06:28:15.101598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\x20\xd3\x9c\x9d\x13\x1e\x8e\xcd\xd0P\xc5\xba\x8f\xf0\x1b\xd4\xab\xea\x8a\x9e\xbe\xa9'
    str_0 = ')C\x1f\xfa\x0c\x0c\xb3\xd8\x0c\xafO\x0c\xf8\xdf\x94\x95\xbd\xfc\xb9\x1b\xa6'
    float_0 = 849.1709

# Generated at 2022-06-25 06:28:26.196743
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:28:32.922544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'RS\xcd\x9b\x07\x98\xf7\xd2\xad\xc0\xdfU'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)

# Unit test to test run method of class ActionModule

# Generated at 2022-06-25 06:28:39.740756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'RS\xcd\x9b\x07\x98\xf7\xd2\xad\xc0\xdfU'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:28:45.302817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x12!\x8b\xfe\x05[\x17\x14\xaa\x9c\xe7\x19'
    str_0 = '\x99\xce\xb9\x18\xef\x0b\xc6\x1bZ\x94\x02P\x07\x0b\x97><HG\xdd\x0b\xa7\xdf\x1aQ\x1b\xab\x9a\xe8@'
    float_0 = 220.4651
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)


# Generated at 2022-06-25 06:28:52.777831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'RS\xcd\x9b\x07\x98\xf7\xd2\xad\xc0\xdfU'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, float_0, float_0)



# Generated at 2022-06-25 06:29:01.538393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1d\xa7\xd3\xbe\xf9\x9c\xdb\x12\xba)\xfd\xc1\x7f\xaf\xaf7\x9d'
    str_0 = '^,TfT}d"\'G\x1a'
    float_0 = 422.7101
    float_1 = 422.7101
    float_2 = 422.7101
    float_3 = 422.7101
    float_4 = 422.7101
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_1, float_2, float_3, float_4)
    action_module_1 = test_case_0()

# Generated at 2022-06-25 06:29:18.971582
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Assigning argument 'args_0' a value of '{}'
    # Assigning argument 'task_vars_0' a value of '{}'
    args_0 = {}
    task_vars_0 = {}

    # Obtaining an instance of the builtin type 'dict' (line 716)
    dict_0 = get_builtin_python_type_instance(stypy.reporting.localization.Localization(__file__, 716, 8), 'dict')
    # Adding type elements to the builtin type 'dict' instance (line 716)
    # Adding element type (key, value) (line 716)

# Generated at 2022-06-25 06:29:24.110735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule_0 = ActionModule({
        '_task': ActionModule._task,
        '_connection': ActionModule._connection,
        '_play_context': ActionModule._play_context,
        '_loader': ActionModule._loader,
        '_templar': ActionModule._templar,
        '_shared_loader_obj': ActionModule._shared_loader_obj},
        ansible_action_plugins=ActionModule.ansible_action_plugins,
        ansible_module_utils=ActionModule.ansible_module_utils,
        class_name=ActionModule.class_name,
        timeout=ActionModule.timeout,
        verbosity=ActionModule.verbosity
    )
    assert str(type(ActionModule_0)) == "<class 'ansible.plugins.action.assemble.ActionModule'>"


# Generated at 2022-06-25 06:29:26.293979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.TRANSFERS_FILES == True
    assert mod._supports_check_mode == False


# Generated at 2022-06-25 06:29:34.281858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_obj = ActionModule()
    assert 'tmp' not in module_obj.run()
    assert 'task_vars' not in module_obj.run()
    assert 'tmp' not in module_obj.run(tmp=bytes_0)
    assert 'task_vars' not in module_obj.run(tmp=bytes_0)
    assert 'tmp' not in module_obj.run(tmp=str_0)
    assert 'task_vars' not in module_obj.run(tmp=str_0)
    assert 'tmp' not in module_obj.run(tmp=float_0)
    assert 'task_vars' not in module_obj.run(tmp=float_0)
    assert 'tmp' not in module_obj.run(task_vars=bytes_0)

# Generated at 2022-06-25 06:29:41.706123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule_0 = ActionModule()
    type(actionmodule_0)._supports_check_mode = bool_9 = True
    actionmodule_0.run()

    assert bool_9 == True, "expected bool_9 to be True, got %s" % bool_9

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:29:48.311363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionbase_obj = ActionBase()
    actionmodule_obj = ActionModule()
    actionbase_obj._connection = MockConnection()
    actionbase_obj._task = MockTask()
    actionmodule_obj._task = MockTask()
    actionmodule_obj._task.args = {'src': 'src_0', 'dest': 'dest_0', 'delimiter': 'delimiter_0', 'remote_src': 'remote_src_0', 'regexp': 'regexp_0', 'follow': 'follow_0', 'ignore_hidden': 'ignore_hidden_0', 'decrypt': 'decrypt_0'}
    actionmodule_obj._loader = MockLoader()
    actionmodule_obj._execute_module = MockExecuteModule()
    actionmodule_obj._execute_remote_stat = MockExecuteRemoteStat()
   

# Generated at 2022-06-25 06:29:58.472485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nTesting class: ActionModule")
    action_module = ActionModule([], {})
    # test_case_ActionModule_transfers_files
    assert action_module.TRANSFERS_FILES == True, "Unit test for ActionModule.transfers_files() failed"
    # test_case_ActionModule_run
    try:
        assert action_module.run() == {}, "Unit test for ActionModule.run() failed"
    except Exception as e:
        print("Unit test for ActionModule.run() failed")
        #print(e)
    # test_case_ActionModule_supports_check_mode
    assert action_module.supports_check_mode() == False, "Unit test for ActionModule.supports_check_mode() failed"
    print("Unit test for ActionModule completed")
# Unit

# Generated at 2022-06-25 06:30:01.095568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:30:04.704123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2025
    float_0 = 657.2068
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:06.220300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:30:22.855676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except Exception as exception:
        print("Exception in the constructor of ActionModule")
        print(exception)
        return
    else:
        if action_module is None:
            print("Exception in the constructor of ActionModule")
            return
        else:
            print("Constructor of ActionModule is working as expected")


# Generated at 2022-06-25 06:30:23.627799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
 
    action = ActionModule()
    action.run()


# Generated at 2022-06-25 06:30:27.117752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(action_module_0.__dict__) == 4
    assert action_module_0._supports_async == False
    assert action_module_0._supports_check_mode == False
    assert action_module_0._supports_async == False
    assert action_module_0._supports_check_mode == False
    assert action_module_0._supports_check_mode == False
    assert action_module_0._supports_check_mode == False
    assert action_module_0._supports_check_mode == False

# Generated at 2022-06-25 06:30:28.297606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except NameError as e:
        assert False


# Generated at 2022-06-25 06:30:33.935809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Unit test for constructor of class ActionModule')
    print(' If the unit test is passed, TEST_CASE_0 will be passed')
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:34.972994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:35.958137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:37.612840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
#    try:
#        action_module_0.run()
#        print(action_module_0.run())
#    except:
#        print ("Error while executing the method ActionModule.run()")
#

# Generated at 2022-06-25 06:30:38.871715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None


# Generated at 2022-06-25 06:30:49.825650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args = { 'src' : 'mocked_string_src', 'dest' : 'mocked_string_dest', 'delimiter' : 'mocked_string_delimiter', }
    action_module._task.action = 'mocked_string_action'
    action_module._task.async_val = 'mocked_boolean_async'
    action_module._task.async_seconds = 'mocked_integer_async_seconds'
    action_module._task.async_poll_interval = 'mocked_integer_async_poll_interval'
    action_module._task.delegate_to = 'mocked_string_delegate_to'

# Generated at 2022-06-25 06:31:04.758163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0 != None
    # TODO: Add unit test code here



# Generated at 2022-06-25 06:31:06.147384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0).__name__ == 'ActionModule'


# Generated at 2022-06-25 06:31:07.062566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:31:11.830772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # generate fake test variables
    test_vars = {
        "test_var": "test value"
    }

    # test constructor
    action_module_test = ActionModule(task_vars=test_vars)

    # check that vars are set correctly
    assert action_module_test._task_vars == test_vars


# Generated at 2022-06-25 06:31:15.029365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of class
    action_module_0 = ActionModule()

    # Initializing test values
    tmp = None
    task_vars = None

    # calling run method
    action_module_0.run(tmp, task_vars)



# Generated at 2022-06-25 06:31:23.938407
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    task_vars = dict(
        ansible_connection='connection',
        ansible_ssh_common_args='a',
        ansible_ssh_extra_args='b',
        ansible_ssh_pass='c',
        ansible_ssh_private_key_file='d',
        ansible_ssh_user='e',
        ansible_sudo=True,
        ansible_sudo_exe='f',
        ansible_verbosity=4,
        vault_password_file='i',
    )

    # ansible.module_utils.remote_management.ssh._get_connection()

# Generated at 2022-06-25 06:31:25.902005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    print('[+] Test: Pass test_ActionModule')


# Generated at 2022-06-25 06:31:31.645474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:31:34.710463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:31:36.100992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 06:31:56.184772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -15.174
    bytes_0 = b'L\xb9!t\x85\xe4\x93\xad\xadT\xa4\xf4\x12\xe4\xf4'
    str_0 = '\x1cA\x1b\xe6\x14\xc3\xdb\xb6\xce\x05'
    float_1 = -14.47
    set_0 = {float_0, float_0, float_1, float_1}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_0, set_0, float_0)
    dict_0 = dict()
    dict_0[float_1] = float_1
    dict_0[float_0] = float_0
   

# Generated at 2022-06-25 06:32:04.135313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    int_0 = 2908
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)

# Generated at 2022-06-25 06:32:13.683096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    return action_module_0

# Initialize the test with given data

# Generated at 2022-06-25 06:32:19.938393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(dict_0, bytes_0, str_0, float_0, float_0, set_0, float_1)
    assert not action_module_0._supports_check_mode

# Generated at 2022-06-25 06:32:21.575121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule({}, {}, {}, {}, {}, {})



# Generated at 2022-06-25 06:32:30.323618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    var_0 = action_module_0.run(dict_0)


# Generated at 2022-06-25 06:32:39.382687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    var_0 = action_run(dict_0)



# Generated at 2022-06-25 06:32:48.973496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(1416.0, '\nqc(nn^X(J!vU\\E{', 445.05872, 1416.0, {'\nqc(nn^X(J!vU\\E{', 1416.0, b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E', 1416.0, '\nqc(nn^X(J!vU\\E{', b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'}, 1416.0)


# Generated at 2022-06-25 06:33:00.155399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 6158.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytearray_0 = bytearray(b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E')
    str_0 = '\nqc(nn^X(J!vU\\E{'
    set_0 = {str_0, str_0, bytearray_0}
    action_module_0 = ActionModule(bytearray_0, str_0, bytearray_0, bytearray_0, set_0, bytearray_0)

# Generated at 2022-06-25 06:33:05.530075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This unit test tests the constructor of class ActionModule

    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)

# Generated at 2022-06-25 06:33:38.670302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule(b'\x8f\xe9\x19\x13\xf1\xc8\x93\xd2\x01\x19\xdc',
                                       '\xf08\x1d\xdd\xd5?\xb5\x12\xf5\x1b',
                                       471.893,
                                       0.073724494095,
                                       set(),
                                       0.5)
        dict_0 = dict()
        dict_0.update({'src': 'src', 'dest': 'dest'})

        action_module_0.run(dict_0, dict_0)

        assert False
    except AnsibleActionFail:
        assert True

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 06:33:45.289044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_2 = 3590.566
    set_1 = {float_2, float_2}
    bytes_1 = b'6\xed\xe4\x13\xf8\xaf\x1a\xde\xb7\x19\xc9'
    str_1 = '^W\x8dv\x85Ql\x1f\xf7\x9f\xad\x10\x15\x1b'
    # Test with a null value
    float_3 = 2491.926
    action_module_1 = ActionModule(float_3, str_1, set_1, bytes_1, bytes_1, set_1)
    var_1 = action_run(None)


# Generated at 2022-06-25 06:33:53.754112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 598.0
    str_0 = '\nqc(nn^X(J!vU\\E{'
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    float_1 = 1184.4
    set_0 = {str_0, bytes_0, float_0, float_0, float_1}
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, set_0, float_1)
    action_module_0.run(tmp=float_0)


# Generated at 2022-06-25 06:33:55.168095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    # Get an object of class ActionModule
    action_module_0 = ActionModule(dict_0)
    assert action_module_0 != None



# Generated at 2022-06-25 06:34:02.232253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    assert action_module_0

# Generated at 2022-06-25 06:34:12.415590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case where src is None
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    task_vars = {}
    tmp = None

# Generated at 2022-06-25 06:34:17.553756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)

# Generated at 2022-06-25 06:34:25.795681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_0 = 445.05872
    set_0 = {str_0, float_0, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_0, float_0, set_0, float_0)
    action_module_0.run(dict_0)

# Generated at 2022-06-25 06:34:26.954475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Tests for __init__(self, connection, play_context, loader, templar, shared_loader_obj):
    pass


# Generated at 2022-06-25 06:34:33.511518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    action_module_0.run(dict_0)


# Generated at 2022-06-25 06:35:28.041720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.459942
    dict_0 = {float_0: float_0, float_0: float_0}
    string_0 = 'nmz@!\x0c'
    float_1 = 793.0
    set_0 = {string_0, float_1, string_0, string_0}
    action_module_0 = ActionModule(string_0, string_0, float_1, float_1, set_0, float_1)
    var_0 = action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 06:35:30.175818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Needs to be implemented
    pass


# Generated at 2022-06-25 06:35:31.341026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:35:32.428311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:35:40.249074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 7.88
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\xd1\xe8\xc2\x94\xb3\xbb\x88\x9e\xab\x8d\xd6\xc2\xa7\xe2\x8e\xb6'
    str_0 = '\\"\x11\xc6\x10$\xec\x90\x9d\xed\xb6\xbf\xe1\xfb\x03'
    float_1 = 1772.906
    set_0 = {str_0, float_1, str_0, bytes_0}

# Generated at 2022-06-25 06:35:47.390884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)

# Generated at 2022-06-25 06:35:55.664973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(dict_0, bytes_0, float_1, float_1, set_0, float_1)


# Generated at 2022-06-25 06:36:02.404855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)
    var_0 = action_run(dict_0)

# Generated at 2022-06-25 06:36:07.601008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1416.0
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    bytes_0 = b'\x1a\xe9\xb0\xe4N \xe4\xb8\x04V\xdf\xe4E'
    str_0 = '\nqc(nn^X(J!vU\\E{'
    float_1 = 445.05872
    float_2 = 445.05872
    set_0 = {str_0, float_1, str_0, bytes_0}
    dict_1 = action_run(dict_0)
    action_module_0 = ActionModule(bytes_0, str_0, float_1, float_1, set_0, float_1)


# Generated at 2022-06-25 06:36:16.798115
# Unit test for constructor of class ActionModule