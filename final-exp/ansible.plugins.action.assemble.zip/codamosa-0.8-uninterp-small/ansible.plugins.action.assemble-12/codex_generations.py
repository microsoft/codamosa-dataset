

# Generated at 2022-06-25 06:26:36.359916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:26:44.759270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = True
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)

    # Call action_module_0.run with arguments.
    result = action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:26:52.759052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup args
    def __init__(self, connection, runner, tmp, task_vars, private_vars):
        pass

    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = True
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    dict_0 = {}
    tmp = dict_0
    task_vars = dict_0
    result = action_module_0.run(tmp, task_vars)
    bool_1 = bool()
    assert result == bool_1


# Generated at 2022-06-25 06:26:53.852788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:01.891241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = True
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    task_vars = dict()
    tmp = None
    result = action_module_0.run(tmp, task_vars)
    assert result == dict()


# Generated at 2022-06-25 06:27:02.631668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:27:08.728402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = True
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    ####! ensure constructor has correct number of arguments


# Generated at 2022-06-25 06:27:14.884382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = True
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)


# Generated at 2022-06-25 06:27:25.034328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path = "/Users/foo/temp"
    if not os.path.exists(path):
        os.makedirs(path)
    tmp = tempfile.NamedTemporaryFile(dir=path, delete=False)
    remote_src = "yes"
    delimiter = None
    regexp = None
    follow = False
    str_0 = "src"
    src = str_0
    bool_0 = True
    src_path = os.path.abspath(src)
    ignore_hidden = False
    regexp = None
    int_0 = 1273
    compiled_regexp = re.compile(regexp)
    str_1 = "dest"
    dest = str_1
    dict_0 = dict()
    result = dict_0
    del tmp  # tmp no longer has any

# Generated at 2022-06-25 06:27:30.925733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "15#Xr'gBq3"
    tuple_0 = None
    bool_0 = True
    int_0 = 6453
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    dict_0 = dict(str_0 = str_0)
    dict_1 = dict()
    test_case_0(dict_0, dict_1)


if __name__ == '__main__':
    #test_ActionModule_run()
    print("This is good")

# Generated at 2022-06-25 06:27:51.554279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = 2124
  bool_0 = False
  str_0 = "\tw$qh?'nW"
  str_1 = "\tw$qh?'nW"
  str_2 = "\tw$qh?'nW"
  bool_1 = True
  int_1 = 2293
  str_3 = "\tw$qh?'nW"
  actionmodule_0 = ActionModule(bool_0, str_0, str_1, bool_0, int_0, str_2)
  str_4 = ""
  actionmodule_0.run(str_4, bool_1)
  str_5 = "\tw$qh?'nW"
  str_6 = "\tw$qh?'nW"
  actionmodule_0.run(str_5, str_6)

# Unit test

# Generated at 2022-06-25 06:28:00.408525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " .h'_?{Uv"
    bool_0 = True
    int_0 = 27179
    action_module_0 = ActionModule(bool_0, str_0, str_0, bool_0, int_0, str_0)
    print(action_module_0._connection)
    print(action_module_0._display)
    print(action_module_0._loader)
    print(action_module_0._no_log)
    print(action_module_0._play_context)
    print(action_module_0._shared_loader_obj)
    print(action_module_0._templar)
    print(action_module_0._task)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:28:02.490849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Testcase 0: ERROR")
        print("Exception: " + str(err))

# Generated at 2022-06-25 06:28:08.735785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '0\x14l*\x1eR\x1dw\x1f\x17=3\x0c\x1a}c\x0e\x02'
    action_module_0 = ActionModule(bool_0, str_0)


# Generated at 2022-06-25 06:28:15.165894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare objects and variables
    str_0 = "\tw$qh?'nW"
    str_1 = "C(j0"
    str_2 = "Cj0"
    str_3 = "$L1!(9jF"
    str_4 = "o0_\x7f"
    str_5 = "$L1!(9jF"
    str_6 = "mK8a"
    str_7 = "$L1!(9jF"
    str_8 = "mK8a"
    str_9 = "mK8a"
    str_10 = "mK8a"
    str_11 = "(|9jKM"
    str_12 = "$L1!(9jF"
    str_13 = "mK8a"

# Generated at 2022-06-25 06:28:21.616294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "ylf@Dd gJYEw"
    bool_0 = False
    int_0 = 1471
    action_module_0 = ActionModule(bool_0, str_0, str_0, bool_0, int_0, str_0)

# Generated at 2022-06-25 06:28:27.918034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "|;*Ao|}"
    bool_0 = False
    int_0 = 1586
    action_module_0 = ActionModule(bool_0, str_0, str_0, bool_0, int_0, str_0)
    if isinstance(action_module_0, ActionModule):
        print("\033[32m" + "##### Test Case: "+ __file__ + " ######" + "\033[0m")
        test_case_0()
    else:
        print("\033[31m" + "##### Test Case: "+ __file__ + " ######" + "\033[0m")

# Generated at 2022-06-25 06:28:31.695542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'nW"
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, str_0, bool_0, int_0, str_0)


# Generated at 2022-06-25 06:28:38.337271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        str_0 = "\tw$qh?'nW"
        bool_0 = False
        int_0 = 2293
        action_module_0 = ActionModule(bool_0, str_0, str_0, bool_0, int_0, str_0)
    except Exception as e:
        print(e)


# Unit tests for class ActionModule

# Generated at 2022-06-25 06:28:42.558530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "rMdD|ZC?m"
    bool_0 = False
    int_0 = 1795
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(bool_0, str_0, str_0, bool_0, int_0, str_0)
    res_0 = action_module_0.run(tmp_0, task_vars_0)
    assert res_0.get_failed() == False

# Generated at 2022-06-25 06:29:02.811425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test a stub
    assert False

# Generated at 2022-06-25 06:29:11.260810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True

# Generated at 2022-06-25 06:29:14.774692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = '!9\x0b\t\x1c\x1b\x0c%\x1b\x05\x07\x1cO'
    action_module_0 = ActionModule(bool_0, str_0)
    module_result = action_module_0.run_()



# Generated at 2022-06-25 06:29:18.495120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None
    bool_0 = True
    str_0 = '^]`\x0b\x11\x1e\x1f\x1e\t\x11Sw\x06\x0b'
    action_module_0 = ActionModule(bool_0, str_0)
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:29:19.838505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'n%&\x1e'
    action_module_0 = ActionModule(bool_0, str_0)


# Generated at 2022-06-25 06:29:23.977798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, '0\x14l*\x1eR\x1dw\x1f\x17=3\x0c\x1a}c\x0e\x02')
    action_module_0.run(None, None)

# Generated at 2022-06-25 06:29:25.428425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # happy path
    test_case_0()



# Generated at 2022-06-25 06:29:29.084852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:29:29.999484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:29:33.727986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:30:04.552847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_obj = ActionModule()

    src = self._task.args.get('src', None)
    dest = self._task.args.get('dest', None)
    delimiter = self._task.args.get('delimiter', None)
    remote_src = self._task.args.get('remote_src', 'yes')
    regexp = self._task.args.get('regexp', None)
    follow = self._task.args.get('follow', False)
    ignore_hidden = self._task.args.get('ignore_hidden', False)
    decrypt = self._task.args.pop('decrypt', True)


# Generated at 2022-06-25 06:30:10.849126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create object
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    # check the type of the object
    assert isinstance(action_module_0, ActionModule)
    # check the value of the object
    assert action_module_0.task.action == "\tw$qh?'Db"
    assert action_module_0.task.args == {}
    assert action_module_0.task.delegate_to == ""
    assert action_module_0.task.environment == {}
    assert action_module_0.task.ignore_errors == False

# Generated at 2022-06-25 06:30:17.626026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:30:24.401713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return action_module_0

str_0 = "\tw$qh?'Db"
tuple_0 = None
bool_0 = False
int_0 = 2293
action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
action_module_0 = test_ActionModule()
var_0 = action_module_0.run()
var_1 = action_module_0.test_case_0()
var_2 = action_module_0._assemble_from_fragments()

# Generated at 2022-06-25 06:30:32.194033
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test case 1: bool_0 = bool(True, bool(True, bool(True)))
    str_1 = "70"
    tuple_1 = None
    bool_1 = boolean(True, boolean(True, boolean(True)))
    int_1 = 6236
    action_module_1 = ActionModule(bool_1, str_1, tuple_1, bool_1, int_1, str_1)
    test_case_1 = var_0

    # Unit test case for test case 1
    assert test_case_1


# Generated at 2022-06-25 06:30:34.690065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:30:38.070595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    tuple_0 = None
    action_module_0.run(tuple_0, tuple_0)


# Generated at 2022-06-25 06:30:39.695446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    isinstance(ActionModule, object)
    assert_equals(ActionModule.__init__, object.__init__)

# Generated at 2022-06-25 06:30:47.157166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = "\tw$qh?'Db"
    tuple_3 = None
    bool_3 = False
    int_3 = 2293
    action_module_1 = ActionModule(bool_3, str_3, tuple_3, bool_3, int_3, str_3)
    task_vars_0 = {}
    bool_1 = None
    var_0 = action_module_1.run(bool_1, task_vars_0)


# Generated at 2022-06-25 06:30:51.517709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:31:37.815219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    assert action_module_0._task == str_0



# Generated at 2022-06-25 06:31:42.424115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'BZW'
    tuple_0 = None
    bool_1 = False
    int_0 = 922
    str_1 = 'I?mGJx@'
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_1, int_0, str_1)
    var_0 = action_module_0.run()
    del action_module_0
    test_case_0()

# Generated at 2022-06-25 06:31:48.909807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "w\"'e:@=8KG<"
    tuple_0 = None
    bool_0 = False
    int_0 = 1128
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    var_0 = action_module_0.run()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:31:51.694129
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Replace the following line with your code
  assert True

# Generated at 2022-06-25 06:31:52.387680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 06:31:53.568765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(True, '', None, True, 0, '')


# Generated at 2022-06-25 06:32:02.540692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "="
    dict_0 = dict()
    dict_0["dest"] = "AkNr"
    dict_0["path"] = "UQZ6_"
    dict_0["src"] = "A2<"
    dict_0["remote_src"] = "q"
    dict_0["regexp"] = "x"
    dict_0["delimiter"] = ">#_]"
    dict_0["ignore_hidden"] = "."
    dict_0["decrypt"] = "|:1"
    dict_0["dest"] = "AkNr"
    dict_0["path"] = "UQZ6_"
    dict_0["src"] = "A2<"
    dict_0["remote_src"] = "q"
    dict_0["regexp"]

# Generated at 2022-06-25 06:32:12.573072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  arg_1 = None
  arg_2 = None
  action_module_0 = ActionModule(None, None, None, None, None, None)
  var_1 = action_module_0.run(arg_1, arg_2)

  # check call to action_run()
  string_0 = ","
  tuple_0 = None
  bool_1 = False
  int_1 = -18404
  var_2 = action_run(string_0, tuple_0, bool_1, int_1)
  var_3 = None
  var_4 = None
  var_5 = None
  var_6 = None
  var_7 = None
  var_8 = None
  var_9 = None
  var_1 = action_module_0.run(var_7, var_8)

#

# Generated at 2022-06-25 06:32:20.701467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    assert action_module_0._supports_check_mode == False
    assert action_module_0._task_vars == tuple_0
    assert action_module_0._tmp_path == str_0
    assert action_module_0._display == str_0
    assert action_module_0._connection == bool_0
    assert action_module_0._task == int_0
    assert action_module_0._loader == bool_0
    assert action_module_0.TRANSFERS_FILES == True

# Unit test

# Generated at 2022-06-25 06:32:26.701295
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Instantiate an object of ActionModule class
    action_module_0 = ActionModule(False, "eVhnxTbu", None, False, 2293, "eVhnxTbu")

    # Call method run() of class ActionModule
    var_0 = action_run()


# Generated at 2022-06-25 06:33:56.656340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:34:04.781252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    assert action_module_0.task is None
    assert action_module_0.connection is None
    assert action_module_0.play_context is None
    assert action_module_0.loader is None
    assert action_module_0.shared_loader_obj is None
    assert action_module_0.strategy is None
    assert action_module_0.noop_task is False
    assert action_module_0.noop_on_check is False
    assert action_module_0.always_run is False
    assert action

# Generated at 2022-06-25 06:34:13.224607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = "\tw$qh?'Db"
    tuple_2 = None
    bool_2 = False
    int_2 = 2293
    action_module_2 = ActionModule(bool_2, str_2, tuple_2, bool_2, int_2, str_2)
    assert isinstance(action_module_2, ActionModule) == True
    assert action_module_2._supports_check_mode == False
    assert action_module_2.action_executed == False
    assert action_module_2.is_local == False
    assert action_module_2.is_playbook == False
    assert action_module_2.noop_on_checkin == False
    assert action_module_2.noop_on_checkout == False
    assert action_module_2.noop_on_check

# Generated at 2022-06-25 06:34:20.987166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "pN!t<wN"
    tuple_0 = None
    bool_0 = True
    int_0 = 1311
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    task_vars_0 = None
    var_0 = action_module_0.run(None, task_vars_0)
    assert var_0 == "Failed" 


# Generated at 2022-06-25 06:34:27.645069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = "\t0o/:A="
    tuple_0 = None
    bool_1 = False
    int_0 = 2237
    str_1 = "n7nqE"
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_1, int_0, str_1)
    bool_2 = True
    assert bool_2 == bool_0
    assert str_0 == str_1
    assert tuple_0 == tuple_0
    assert bool_1 == bool_1
    assert int_0 == int_0


# Generated at 2022-06-25 06:34:29.193378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 06:34:29.912354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    pass

# Generated at 2022-06-25 06:34:38.064158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest_0 = "/S"
    args = {'regexp': '=', 'dest': dest_0, 'src': "/%"}
    # Instantiate action module
    action_module_0 = ActionModule(False, '', (), False, 2, '')
    action_module_0.set_task_and_variable_manager(None, None)
    # Call the method
    try:
        action_module_0.run(None, None)
    except AnsibleAction as e:
        assert e.result['rc'] == 1
    # Check that file has not been copied
    assert action_module_0.remote_file_exists(dest_0) is False


# Generated at 2022-06-25 06:34:42.741455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    assert var_0 is not None
    assert var_0 is None

# Generated at 2022-06-25 06:34:46.128942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Write tests for constructor of class ActionModule
    str_0 = "\tw$qh?'Db"
    tuple_0 = None
    bool_0 = False
    int_0 = 2293
    action_module_0 = ActionModule(bool_0, str_0, tuple_0, bool_0, int_0, str_0)
    