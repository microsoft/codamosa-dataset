

# Generated at 2022-06-25 06:26:42.836932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest_stat = {"checksum": "fake_checksum"}
    remote_expand_user = "fake_remote_expand_user"
    execute_remote_stat = "fake_execute_remote_stat"
    task_vars = {}
    assemble_from_fragments = "fake_assemble_from_fragments"
    task_vars = {}
    execute_module = "fake_execute_module"
    task_vars = {}
    int_0 = 264
    str_0 = "|)'g/:&)Yen$fl bW"
    float_0 = -324.751
    list_0 = [str_0]
    action_module_0 = None

# Generated at 2022-06-25 06:26:43.756666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:26:54.658143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 543
    str_0 = "!a_!Za*h"
    float_0 = -847.731
    int_1 = 338
    list_0 = [str_0]
    action_module_0 = None
    action_module_0 = ActionModule(int_0, str_0, float_0, int_1, list_0, action_module_0)
    int_2 = 897
    str_1 = "7L?=O:rq3m`"
    float_1 = 628.299
    list_1 = [int_1]
    action_module_1 = ActionModule(int_2, str_1, float_1, int_2, list_1, action_module_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:26:56.508687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:27:06.138933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 263
    str_0 = "]*GX`C%Q+rq@&}~"
    float_0 = -664.886
    list_0 = [str_0]
    action_module_0 = None
    dest = "Gx}h4$L3~O<2Cg9X"
    src = "vY[*gwc}"
    module_name = "Vv.t,QyV7~9NgW;"
    task_vars = ActionModule(int_0, str_0, float_0, int_0, list_0, action_module_0)
    remote_src = "DxM,i4'3q*3:G"

# Generated at 2022-06-25 06:27:08.475132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:16.945246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_1_arguments_0 = {'src': None, 'dest': None, 'decrypt': True}
    test_1_arguments_1 = {'src': None, 'dest': None, 'decrypt': True}
    test_1_return_0 = {}
    test_1_return_1 = {}
    test_1_run_0 = test_case_0()
    test_1_run_0.run(**test_1_arguments_0)
    test_1_run_1 = test_case_0()
    test_1_run_1.run(**test_1_arguments_1)
    assert test_1_return_0 == test_1_run_0
    assert test_1_return_1 == test_1_run_1

# Generated at 2022-06-25 06:27:24.457230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6
    str_0 = "I=.-lL`"
    float_0 = -902.266
    int_1 = 456
    list_0 = [int_1]
    action_module_0 = None
    action_module_1 = ActionModule(int_0, str_0, float_0, int_0, list_0, action_module_0)
    int_0 += 5
    # assert action_module_1.transfers_files == True
    # assert action_module_1.is_playbook == False


# Generated at 2022-06-25 06:27:26.059988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(0, 'str_0', 0.0, 0, [], None)


# Generated at 2022-06-25 06:27:26.835092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:46.696233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Step 1
    # Method 'run'
    # Class 'ActionModule'

    # Step 1.1
    # ActionModule.run - setup
    int_0 = 0
    str_0 = '/usr/local/sbin'
    action_module_0 = ActionModule(int_0, str_0, int_0, int_0, int_0, int_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    # dict_1.update(dict_0)
    dict_1.update

# Generated at 2022-06-25 06:27:47.192153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:27:51.469199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Unit test to test the method assemble_from_fragments in class ActionModule

# Generated at 2022-06-25 06:27:52.921480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Run the unit test
    test_ActionModule()

# Generated at 2022-06-25 06:27:56.616609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:59.882793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = 'usr'
    str_1 = '/usr/local/sbin'
    action_module_0 = ActionModule(int_0, str_0, int_0, int_0, int_0, int_0)

    # Check if method run is defined
    assert 'run' in dir(action_module_0)

# Generated at 2022-06-25 06:28:03.758644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = '/usr/local/sbin'
    action_module_0 = ActionModule(int_0, str_0, int_0, int_0, int_0, int_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:28:07.430898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a temp file and return it
    fd, path = tempfile.mkstemp()
    # close the temp file
    os.close(fd)
    int_0 = 0
    str_0 = '../include'
    action_module_0 = ActionModule(int_0, str_0, int_0, int_0, int_0, int_0)
    # result should be an Exception
    result = action_module_0.run()
    assert type(result) == dict


# Generated at 2022-06-25 06:28:08.218271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:28:09.456963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:28:24.183638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-25 06:28:26.156902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None, 'test_ActionModule failed!'


# Generated at 2022-06-25 06:28:29.981549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None, 'ActionModule() is not instantiated'


# Generated at 2022-06-25 06:28:31.602786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run()

test_cases = [
    test_case_0
]

# Execute each test case
for test_case in test_cases:
    test_case()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 06:28:35.055698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-25 06:28:37.989063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)


# Generated at 2022-06-25 06:28:43.117180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    action_module_1 = ActionModule()
    action_module_1._task = Mock()

    del action_module_1._task.args['src']

    action_module_2 = ActionModule()
    action_module_2._task = Mock()

    del action_module_2._task.args['dest']

    action_module_3 = ActionModule()
    action_module_3._task = Mock()
    action_module_3._task.args['remote_src'] = 'no'
    action_module_3._task.args['src'] = 'test_src_0'
    action_module_3._task.args['dest'] = 'test_dest_0'
    action_module_3.run()

    action_module_3._task.args['remote_src']

# Generated at 2022-06-25 06:28:47.930692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Make a new object in memory
    action_module_1 = ActionModule()
    #Check if the object is instance of ActionModule
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 06:28:58.568349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  p = os.path.abspath(os.path.dirname(__file__))
  src_dir = os.path.join(p, '../../../examples/assemble/group_vars')
  dest_dir = os.path.join(p, '../../../examples/assemble/')
  with open(os.path.join(dest_dir, 'complete_smtp_config'), 'r') as content_file:
    expected = content_file.read()
  action_module = ActionModule()
  tmp = None

# Generated at 2022-06-25 06:29:00.387758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:29:29.602975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 06:29:33.855807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:29:40.234549
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    # Test case with option args
    args = {'dest': u'/tmp/assemble.txt', 'src': u'files', 'remote_src': 'no'}
    action_module.run(tmp=None, task_vars=None, args=args)


# Generated at 2022-06-25 06:29:41.683105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0.ActionModule() == 'ActionModule')


# Generated at 2022-06-25 06:29:43.018471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# vim: expandtab:tabstop=4:shiftwidth=4

#pylint: disable=protected-access

# Generated at 2022-06-25 06:29:49.312851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Set arguments
    tmp_1 = None
    task_vars_2 = {"key3": "value3", "key2": "value2", "key1": "value1"}
    action_module_0.set_task_vars(task_vars_2)
    # Call method run of class ActionModule with arguments
    action_module_0.run(tmp_1)
    # Asserts
    assert action_module_0._supports_check_mode == False


if __name__ == '__main__':
    # test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:29:54.614885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.ActionBase.DEFAULT_TMP_PATH = 'something'
    dest = '/etc/ansible/test/test/test.cfg'
    src = '/etc/ansible/test/test/test.cfg'
    regexp = '/etc/ansible/test/test.cfg'
    ignore_hidden = False
    remote_src = True
    tempfile.mkdtemp.return_value = 'something'
    action_module.ActionBase.transfer_file.return_value = 'something'
    action_module.ActionBase._execute_module.return_value = None
    action_module.ActionBase._remove_tmp_path.return_value = None
    action_module.ActionBase._fixup_perms2.return_value = None
    action_module.ActionModule._

# Generated at 2022-06-25 06:29:57.111425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0
    assert action_module_0._supports_check_mode == False


# Generated at 2022-06-25 06:30:06.385949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.setenv('ANSIBLE_MODULE_ARGS',
                           {'ignore_hidden': False, 'dest': 'string_example', 'remote_src': True, 'src': 'string_example'})
    action_module_0.STANDBY_SKIP_DATA = 'dict_example'
    action_module_0.setenv('ANSIBLE_ASYNC_DIR', 'string_example')
    task_vars_0 = dict()
    result_1 = action_module_0.run(tmp='string_example', task_vars=task_vars_0)
    try:
        for key in result_1:
            print(key)
    except Exception as e:
        print(e.message)

# Generated at 2022-06-25 06:30:08.198594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:30:36.071536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32
    str_0 = '-tKVN3_\x0b'
    list_0 = [int_0, int_0, str_0]
    float_0 = 448.6
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:30:41.059707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32
    str_0 = '-tKVN3_\x0b'
    list_0 = [int_0, int_0, str_0]
    float_0 = 448.6
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 06:30:47.664365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = 32
  str_0 = '-tKVN3_\x0b'
  list_0 = [int_0, int_0, str_0]
  float_0 = 448.6
  action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
  var_0 = action_run()

# Generated at 2022-06-25 06:30:52.261664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3
    str_0 = '16n2n1a.9\x7f(MZ'
    list_0 = [int_0, int_0, str_0]
    float_0 = 32.8
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:30:53.811287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 06:30:55.336366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('arg5', '-', list(), '-', 'arg9', 0.452827)

# Generated at 2022-06-25 06:30:56.050264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 0 == ActionModule()

# Generated at 2022-06-25 06:30:57.811162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:31:05.112961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 193
    str_0 = '-tKVN3_\x0b'
    list_0 = [int_0, int_0, str_0]
    float_0 = 448.6
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    action_module_0._supports_check_mode = False

    tmp = None
    task_vars = dict()
    result = action_module_0.run(tmp, task_vars)
    assert result == dict()


# Generated at 2022-06-25 06:31:08.848561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res_0 = None
    action_module_0 = ActionModule()
    tmp_0 = {'first': '1', 'second': '2'}
    task_vars_0 = [tmp_0, 'third']
    var_0 = action_run(task_vars_0, tmp_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('Test completed')

# Generated at 2022-06-25 06:31:59.420551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 06:32:00.229166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 06:32:07.359293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0.__init__(int_0, str_0, list_0, str_0, int_0, float_0) == None) # constructor of ActionModule

# Generated at 2022-06-25 06:32:07.849723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert false

# Generated at 2022-06-25 06:32:12.465473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 174
    str_0 = '@'
    list_0 = [0.8, 68, int_0]
    str_1 = 'Bn'
    int_1 = 1
    float_0 = 0.5414
    action_module_0 = ActionModule(int_0, str_0, list_0, str_1, int_1, float_0)


if __name__ == '__main__':
    #test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:32:18.190928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32
    str_0 = '-tKVN3_\x0b'
    list_0 = [int_0, int_0, str_0]
    float_0 = 448.6
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 06:32:24.414886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 17
    str_0 = ']'
    list_0 = [int_0, int_0, str_0]
    float_0 = 941.2
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    assert(action_module_0)
    assert(not action_module_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()
    print("[+] test cases completed")

# Generated at 2022-06-25 06:32:28.921614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 38
    str_0 = "Kx=('\x7f\x5c\x7f\x5c\x7f\x5c\x7f\x5c\x7f\x5c\x7f\x5c\x7f\x5c\x7f"
    list_0 = [int_0, int_0, str_0]
    str_1 = ')T9\r@qo_GsJ\x15\'\x7f\\p\x1c'
    int_1 = 0
    float_0 = 5.67
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    action_module_0.run()
    assert action_module_0

# Generated at 2022-06-25 06:32:33.914560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32
    str_0 = '-tKVN3_\x0b'
    list_0 = [int_0, int_0, str_0]
    float_0 = 448.6
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    var_0 = action_module_run()


# Generated at 2022-06-25 06:32:38.377583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 54977
    str_0 = '@$kp\n'
    list_0 = [str_0]
    float_0 = 983.0
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:34:18.706462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:34:26.540767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 70797
    str_0 = 'U9\x1ds\x1f:y\x13'
    list_0 = [int_0, int_0, str_0]
    str_1 = 'J[\x03@'
    int_1 = 881
    float_0 = 390.9
    action_module_0 = ActionModule(int_0, str_1, list_0, str_0, int_1, float_0)
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0._supports_check_mode == False


# Generated at 2022-06-25 06:34:31.014403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = 32
    var_2 = '-tKVN3_\x0b'
    var_3 = [var_0, var_1, var_2]
    var_4 = 448.6
    action_module_1 = ActionModule(var_0, var_2, var_3, var_2, var_0, var_4)


# Generated at 2022-06-25 06:34:33.049023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.assemble
    ansible.plugins.action.assemble.ActionModule()


# Generated at 2022-06-25 06:34:37.618894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = '7C'
    list_0 = []
    float_0 = 10.1
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    action_module_0.run(int_0, int_0)


# Generated at 2022-06-25 06:34:39.045866
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test cases to get different types of results
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:34:43.652508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 32
    str_0 = '-tKVN3_\x0b'
    list_0 = [int_0, int_0, str_0]
    float_0 = 448.6
    action_module_0 = ActionModule(int_0, str_0, list_0, str_0, int_0, float_0)
    assert(action_module_0._supports_check_mode == False)


# Generated at 2022-06-25 06:34:47.667120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = 'test case 0'
    list_0 = [0, 1, 2]
    str_1 = 'test case 1'
    int_1 = 10
    float_0 = 10.1
    action_module_0 = ActionModule(int_0, str_0, list_0, str_1, int_1, float_0)

# Generated at 2022-06-25 06:34:49.479155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TODO
    assert True


# Generated at 2022-06-25 06:34:50.629697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
