

# Generated at 2022-06-25 06:26:37.700536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:26:44.540169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -4497.98
    bool_0 = True
    set_0 = {float_0, bool_0, bool_0}
    int_0 = 131072
    bytes_0 = b'\xbb\x80\xb7\xfe\x95'
    action_module_0 = ActionModule(float_0, set_0, float_0, int_0, bytes_0, int_0)
    action_module_0._dump_options = 0x9b
    action_module_0._play_context = 0x8d
    action_module_0._remote_user = 'U9f\xdcY\xf3F'
    action_module_0._task = 'l\x10\x0c\x8a\x1e'

# Generated at 2022-06-25 06:26:48.785861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(float_0, set_0, float_0, int_0, bytes_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 06:26:52.701368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 868.39
    str_0 = 'q'
    int_0 = 0
    bytes_0 = b'\x17\x10\x9d\x8c\x81\x06'
    str_1 = 'u'
    action_module_0 = ActionModule(float_0, set([str_0]), str_1, int_0, bytes_0, int_0)


# Generated at 2022-06-25 06:26:54.586722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:27:02.190410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -4497.98
    bool_0 = True
    set_0 = {float_0, bool_0, bool_0}
    int_0 = 131072
    bytes_0 = b'\xbb\x80\xb7\xfe\x95'
    action_module_0 = ActionModule(float_0, set_0, float_0, int_0, bytes_0, int_0)
    action_module_0.run(set_0, set_0)

# Generated at 2022-06-25 06:27:03.677966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(0.0, set(), 0.0, 0, b'', 0)


# Generated at 2022-06-25 06:27:09.811265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -4497.98
    bool_0 = True
    set_0 = {float_0, bool_0, bool_0}
    int_0 = 131072
    bytes_0 = b'\xbb\x80\xb7\xfe\x95'
    action_module_0 = ActionModule(float_0, set_0, float_0, int_0, bytes_0, int_0)



# Generated at 2022-06-25 06:27:14.954288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 131072
    float_0 = -4497.98
    str_0 = '\xbb\x80\xb7\xfe\x95'
    set_0 = {int_0, bool_0, bool_0}
    test_case_0()


# Generated at 2022-06-25 06:27:19.932388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 4.18251973418
    int_0 = 2048
    str_0 = u'3\x9c\x0b\x89'
    action_module_0 = ActionModule(float_0, int_0, str_0)

    # Act
    result = action_module_0.run(int_0, int_0)

    # Assert
    assert result == int_0

# Generated at 2022-06-25 06:27:32.721231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.0
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, float_0, float_0, float_0, bytes_0, float_0)


# Generated at 2022-06-25 06:27:36.009919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, float_0, float_0, float_0, bytes_0, float_0)
    tmp = {}
    task_vars = {}
    result = action_module_0.run(tmp, task_vars)
    assert result == {}


# Generated at 2022-06-25 06:27:41.897290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test code for instance method action_module.run
    float_8 = 0.0
    bytes_8 = b'<module>ansible.legacy.assemble</module>\n<args>src=/home/vagrant/ansible/test/integration/foo/bar/baz delimiter=\'\'</args>'
    action_module_8 = ActionModule(float_8, float_8, float_8, float_8, bytes_8, float_8)
    string_19 = 'remote_src'
    dictionary_20 = {string_19: True}
    action_module_8.set_task(dictionary_20)
    float_9 = 0.0
    bytes_9 = b''

# Generated at 2022-06-25 06:27:43.585141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This needs to be tested for an real ActionModule
    # We currently only have a Mock to test
    # TODO: Test for valid regexp/ignore_hidden combos
    return None


# Generated at 2022-06-25 06:27:44.222808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:46.654905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = 'test'
    action_module_0 = ActionModule(x, x, x, x, x, x)


# Generated at 2022-06-25 06:27:49.752463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, float_0, float_0, float_0, bytes_0, float_0)
    dict_0 = dict()
    result = action_module_0.run(dict_0)

# Generated at 2022-06-25 06:27:51.554320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.0
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, float_0, float_0, float_0, bytes_0, float_0)

# Generated at 2022-06-25 06:27:57.501774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, float_0, float_0, float_0, bytes_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 06:28:08.345487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    float_1 = 1.0
    bytes_0 = b''

# Generated at 2022-06-25 06:28:24.496046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    return var_0


# Generated at 2022-06-25 06:28:26.696149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(var_0)
    # Test for instance attributes
    assert obj.TRANSFERS_FILES == True


# Generated at 2022-06-25 06:28:36.562520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    Task = type('Task', (object,), {'args': {'ignore_hidden': False, 'dest': None, 'delimiter': None, 'decrypt': True, 'regexp': None, 'src': None, 'remote_src': 'yes'}, '_task': {'args': {'ignore_hidden': False, 'dest': None, 'delimiter': None, 'decrypt': True, 'regexp': None, 'src': None, 'remote_src': 'yes'}, 'action': 'assemble'}})
    var_2 = type('', (object,), {'connection': None})
    var_3 = type('Connection', (object,), {'_shell': None})

# Generated at 2022-06-25 06:28:37.732718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # unit test for ActionModule.run
    test_case_0()

# Generated at 2022-06-25 06:28:41.080332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:28:43.604135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.assemble import ActionModule
    from ansible.plugins.action.assemble import test_case_0

    a = ActionModule()
    a._task = test_case_0()

    test_case_0(a)


# Generated at 2022-06-25 06:28:45.153186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global var_0
    var_0 = ActionModule(var_0)
    assert isinstance(var_0, ActionModule)
    assert isinstance(var_0, ActionBase)


# Generated at 2022-06-25 06:28:52.041022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run of ActionModule")
    var_0 = None
    ActionModule.run(var_0)
    return True

if __name__ == '__main__':
    print("Testing ActionModule")
    if test_ActionModule_run() != True:
        raise Exception("Testing of ActionModule failed")
    else:
        print("ActionModule Class implementation test passed")

# Generated at 2022-06-25 06:28:58.459827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run test with argument "test_case_0"
    test_ActionModule_0 = ActionModule(test_case_0)
    # Run test with argument "test_case_1"
    test_ActionModule_1 = ActionModule(test_case_1)


# Generated at 2022-06-25 06:29:04.870520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 06:29:20.618266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    obj = ActionModule(var_0)


# Generated at 2022-06-25 06:29:24.637766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Setup the context
        set_up()

        # Call the function
        test_case_0()

    # Cleanup the context
    finally:
        tear_down()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:29:27.277761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_instance = ActionModule()
    var_tmp = None
    var_task_vars = None
    var_return = var_instance.run(var_tmp, var_task_vars)
    assert var_return == {}

# Generated at 2022-06-25 06:29:31.270706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = None

    obj_0 = ActionModule(arg_0, arg_1, arg_2, arg_3)
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:29:31.859188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 06:29:33.401118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    main_test_obj = ActionModule()
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:29:42.092422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    const_0 = None
    const_1 = None
    var_0 = ActionModule()
    var_1 = {}
    var_2 = {}
    var_0.run(var_1, var_2)


# Generated at 2022-06-25 06:29:47.783062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert isinstance(instance, ActionModule)
    # ActionBase._supports_check_mode
    assert instance._supports_check_mode == False
    # ActionBase._supports_async
    assert instance._supports_async == False


# Generated at 2022-06-25 06:29:50.793571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case0 = ActionModule()



# Generated at 2022-06-25 06:29:52.375302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:30:19.734168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    dest = None
    tmp = None
    var_2 = None
    delimiter = None
    regexp = None
    src = None
    var_3 = None
    remote_src = None
    follow = False
    ignore_hidden = False
    decrypt = True
    task_vars = dict()
    tmp = None
    var_1 = None
    var_0 = ActionModule(var_0, task_vars = task_vars)
    var_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:30:23.568315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_var_0 = None
    task_var_0 = None
    result_var_0 = None

    # Test instantiation of class ActionModule
    try:
        action_var_0 = ActionModule(action_var_0, task_var_0, result_var_0)
    except NameError as err:
        print(err)
        print('Error instantiating ActionModule')
    return action_var_0


# Generated at 2022-06-25 06:30:25.230881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #var_0 = None
    var_1 = {}
    x = ActionModule(var_0, var_1)
    assert type(x) == ActionModule


# Generated at 2022-06-25 06:30:31.164608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(argument_spec=dict())
    module.params['src'] = var_0
    module.params['dest'] = '.'
    task = AnsibleTask(Actions=ActionModule.run)
    result = task.run(module)
    print(result)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:30:39.279468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    try:
        var_6 = None
        if (var_0.run(tmp=var_1, task_vars=var_2)):
            var_6 += 1
    except AnsibleAction as exc_0:
        var_5 = exc_0
        var_6 += 1
    except _AnsibleActionDone as exc_1:
        var_4 = exc_1
        var_6 += 1
    except Exception as exc_2:
        var_3 = exc_2
        var_6 += 1

# Generated at 2022-06-25 06:30:41.332494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = Mock()
    obj_0 = ActionModule(arg_0)
    assert isinstance(obj_0, ActionModule)


# Generated at 2022-06-25 06:30:47.839348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    tmp = None
    task_vars = None
    var_2 = None
    action_module = ActionModule(var_1, task_vars=var_2)
    var_1 = action_module.run(tmp=tmp, task_vars=task_vars)
    assert var_1 == "", "Returned value not as expected."

# Generated at 2022-06-25 06:30:49.680789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test cases for constructor of class ActionModule
    var_0 = ActionModule()


# Generated at 2022-06-25 06:30:52.143251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()

# Generated at 2022-06-25 06:30:59.689291
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mocking class Task to avoid errors
    class Task:

        def __init__(self):
            self.args = dict()
            self.args['src'] = '../tests/fixtures/copy/assemble/sample_dir'
            self.args['dest'] = '/tmp/sample_dir'
            self.args['regexp'] = None
            self.args['delimiter'] = None
            self.args['remote_src'] = False
            self.args['follow'] = False
            self.args['ignore_hidden'] = False
            self.args['decrypt'] = True

    # Mocking class PlayContext to avoid errors
    class PlayContext:
        def __init__(self):
            self.diff = False

    # Mocking class Connection to avoid errors

# Generated at 2022-06-25 06:31:29.710740
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # initialising a ActionModule with a module
    # This will initialise all the class variables
    action_module = ActionModule()

    # testing the function assemble_from_fragments
    # This function is used to assemble a file from a
    # directory of fragments
    src_path = "/tmp/test"
    delimiter = "test"
    compiled_regexp = re.compile("test")
    ignore_hidden = False
    decrypt = False
    action_module.assemble_from_fragments(src_path, delimiter, compiled_regexp, ignore_hidden, decrypt)

    # testing the function run
    # This function is used to run the module
    tmp = None
    task_vars = ["test"]
    action_module.run(tmp, task_vars)

    file_path = ""
   

# Generated at 2022-06-25 06:31:31.328518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:31:34.364058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)
    assert isinstance(ActionModule.run, object)

# Generated at 2022-06-25 06:31:41.935049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    var_0 = action_run()

    # TEST
    # Class constructor.
    # Assert: The function action_run() is defined for the ActionBase class.

# Generated at 2022-06-25 06:31:50.067784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:31:51.901752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run()
    print(var_0)


# Generated at 2022-06-25 06:31:57.997900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = 'src/A'
    delimiter = b'\x9e'
    src = 'src/B'
    regexp = 'src/C'
    follow = 'src/D'
    ignore_hidden = 'src/E'
    decrypt = True
    var_0 = test_case_0()
    var_1 = new_module_args(dest, delimiter, src, regexp, follow, ignore_hidden, decrypt)
    var_2 = new_module_args(task_vars)
    var_3 = action_module_0.run(var_1, var_2)
    var_4 = action_module_0.run(var_0, var_2)
    var_5 = action_module_0.run(var_1, var_1)
    var_6 = action_module_

# Generated at 2022-06-25 06:32:01.104843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:32:08.513459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)


# Generated at 2022-06-25 06:32:13.752416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 06:33:05.145444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bytes_0 = b'\x90'
  bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
  bytes_2 = b'8\xbc'
  str_0 = '#levOc|'
  float_0 = 1759.1
  tuple_0 = (str_0, float_0)
  list_0 = []
  action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
  action_module_1 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)

# Generated at 2022-06-25 06:33:12.519630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)


# Generated at 2022-06-25 06:33:18.057744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0)
    assert action_module_0._supports_check_mode == False


# Generated at 2022-06-25 06:33:19.226369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert method_run(action_module_0) == var_0

# Generated at 2022-06-25 06:33:27.059424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:33:32.365265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    bytes_1 = b'\x0f\xa3T\xc6\x8b\xbf_1\x9c\x82\x8c\x82^\xac'
    bytes_2 = b'\x00'
    str_0 = '#'

# Generated at 2022-06-25 06:33:38.416758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setting up mock objects.
    param_0 = b'\x90'
    param_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    param_2 = b'8\xbc'
    param_3 = ('#levOc|',1759.1)
    param_4 = '#levOc|'
    param_5 = []
    action_module_0 = ActionModule(param_0, param_1, param_2, param_3, param_4, param_5)

if __name__ == '__main__':
    # Initialize mock objects
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes

# Generated at 2022-06-25 06:33:45.093513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create test object
    bytes_0 = b'\xeb\x00\x1a\x12\x9au#\x91'
    bytes_1 = b'\xbf\x06\x0f\x8e\x98\xd6\x15\x0e\xc1\x80\x1b\x15\xf8\xad\x94\xdc\x99\x1b\x0b\xafk\xdd\xda\x16'
    bytes_2 = b'l\xb7'
    with tempfile.NamedTemporaryFile() as file_0:
        str_0 = file_0.name
        float_0 = 642.9847058387871
        tuple_0 = (str_0, float_0)
        list_0 = []


# Generated at 2022-06-25 06:33:51.166790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments = ['ansible.legacy.file', 'ansible.legacy.copy']
    module_0 = arguments[0]
    module_1 = arguments[1]
    result = action._execute_module(module_0)
    result = action._execute_module(module_1)
    assert result in result

# Generated at 2022-06-25 06:33:54.928471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:35:30.251580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 100
    str_0 = 'k'
    str_1 = 'hi'
    tuple_0 = (str_1, float_0)
    float_0 = float("nan")
    float_1 = float("inf")
    float_2 = float("inf")
    float_3 = float("nan")
    float_4 = float("-inf")
    float_5 = float("nan")
    float_6 = float("inf")
    float_7 = float("-inf")
    float_8 = float("-inf")
    byte_0 = b'\x88'
    byte_1 = b'\x90'
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'


# Generated at 2022-06-25 06:35:31.711578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #assert action_module_0.run() == 'ActionModule.run'
    assert 1 == 1

# Generated at 2022-06-25 06:35:38.325312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    tuple_1 = (None, None)
    action_module_0.run(tuple_1)


# Generated at 2022-06-25 06:35:44.243304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:35:51.533815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    #assert path_0 == path_1
    #assert path_1 == path_2
    #assert path_2 == path_3
    #assert path_3 == path_4


# Generated at 2022-06-25 06:36:00.111476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Case 0
    bytes_0 = b'\x90'
    bytes_1 = b'\x88J0\x1f\xaa\xd0\xf6\x16'
    bytes_2 = b'8\xbc'
    str_0 = '#levOc|'
    float_0 = 1759.1
    tuple_0 = (str_0, float_0)
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, tuple_0, str_0, list_0)
    assert action_module_0._supports_check_mode == 0
    assert action_module_0._display.verbosity == 0
    assert action_module_0._options.become == 0
    assert action_module_0._options.become

# Generated at 2022-06-25 06:36:06.062376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path = 'src/'
    regexp = '\w+'
    delimiter = '\t'
    ignore_hidden = False
    remote_src = False
    follow = True
    encrypt = True
    module_name = 'ansible.legacy.assemble'
    module_args = 'dest'
    dest = 'ansible'
    path_checksum = 'checksum'
    diff = {}
    # tempfile dir
    tmp_dir = 'tmp_dir'
    remote_path = 'remote_path'
    fixup_perms = False
    remote_expand_user = 'remote_expand_user'
    execute_remote_stat = 'execute_remote_stat'
    execute_module = 'execute_module'
    diff_data = 'diff_data'

# Generated at 2022-06-25 06:36:06.522497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:36:08.297033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == False, "Test Failed. Unit test for constructor is not implemented."

# Generated at 2022-06-25 06:36:15.551868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    file_path = '/path/to/file.txt'
    data_type = os.path.basename(file_path)
    task_name = 'test'
    data_type = 'test'
    action_module_0 = ActionModule(task_name, file_path, data_type)
    assert action_module_0.file_path == file_path
    assert action_module_0.data_type == data_type
    assert action_module_0.task_name == task_name
    assert action_module_0.result == dict()
    assert action_module_0.tmp == str()
