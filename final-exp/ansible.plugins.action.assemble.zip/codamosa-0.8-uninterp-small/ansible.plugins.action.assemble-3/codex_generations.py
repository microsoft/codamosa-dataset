

# Generated at 2022-06-25 06:26:36.359581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:26:46.279511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = None
    int_0 = 1548
    float_0 = -1885.598
    action_module_1 = ActionModule(action_module_0, int_0, action_module_0, action_module_0, float_0, action_module_0)
    assert action_module_1.result is None
    assert action_module_1.action_shell is None
    assert action_module_1.action is None
    assert action_module_1.task_vars is None
    assert action_module_1.play_context is None
    assert action_module_1.shared_loader_obj is None
    assert action_module_1.cleanup_remote_tmp is False
    assert action_module_1.remote_files is None
    assert action_module_1.args is None

# Generated at 2022-06-25 06:26:55.347396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = None
    int_1 = -1823
    float_1 = -1749.861
    action_module_3 = ActionModule(action_module_2, int_1, action_module_2, action_module_2, float_1, action_module_2)
    action_module_3._AnsibleActionFail(action_module_2)
    action_module_3._AnsibleAction(action_module_2)
    action_module_3._AnsibleActionFail(action_module_2)
    action_module_3._AnsibleActionFail(action_module_2)
    action_module_3._AnsibleAction(action_module_2)

# Generated at 2022-06-25 06:27:03.773614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -744.8
    int_0 = -1497
    action_module_0 = None
    action_module_1 = ActionModule(action_module_0, int_0, action_module_0, action_module_0, float_0, action_module_0)
    action_module_1.run()


if __name__ == '__main__':
    import os
    import unittest

    os.chdir("/home/travis/build/ansible/ansible-modules-extras/test/units/modules/files")
    # print("Running unit tests for file modules/files/assemble.py")
    unittest.main()

# Generated at 2022-06-25 06:27:14.849516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src_0 = None
    dest_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(src_0, dest_0, task_vars_0)
    try:
        action_module_0.run(dest_0, task_vars_0)
    except AnsibleAction as e:
        pass
    except AnsibleActionFail as e:
        pass
    except AnsibleActionDone as e:
        pass
    except AnsibleError as e:
        pass
    except AnsibleAction as e:
        pass
    except AnsibleActionFail as e:
        pass
    except AnsibleActionDone as e:
        pass
    except AnsibleError as e:
        pass
    except AnsibleAction as e:
        pass
    except AnsibleActionFail as e:
        pass

# Generated at 2022-06-25 06:27:15.786700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:27:17.521904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 06:27:23.607865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    int_0 = 1
    float_0 = 1e-06
    action_module_1 = ActionModule(action_module_0, int_0, action_module_0, action_module_0, float_0, action_module_0)
    # Method run of class ActionModule is not implemented
    with pytest.raises(NotImplementedError):
        action_module_1.run()

# Generated at 2022-06-25 06:27:25.272824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:27:26.792631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    test_case_0()
    print("Success")


# Generated at 2022-06-25 06:27:46.196382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -119
    float_0 = -119.0
    action_module_0 = ActionModule(int_0, int_0, int_0, int_0, float_0, int_0)
    # method_return_0 = action_module_0.run('\tVpk', {'Gk*]': 'f+\t'})
    # assert method_return_0.items() <= {'g6N8': object, 'F<\t': object, 'W`]8': object}.items()
    # assert method_return_0.items() >= {'g6N8': object, 'F<\t': object, 'W`]8': object}.items()


# Generated at 2022-06-25 06:27:51.079377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run_0()
    test_ActionModule_run_1()


# Generated at 2022-06-25 06:27:51.831924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:27:57.367982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1239
    float_0 = -274.459
    action_module_0 = ActionModule(int_0, int_0, int_0, int_0, float_0, int_0)


# Generated at 2022-06-25 06:28:08.260633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert False
    except:
        ActionBase_0 = ActionBase(-817, float(-10.84), float(-2306.39), int(-974), float(752.2), float(-1788.822))
        float_1 = float(-3044.921)
        float_2 = float(-2435.764)
        int_1 = -3060
        int_2 = -792
        float_3 = float(-2524.381)
        float_4 = float(31)
        float_5 = float(94.4)
        float_6 = float(1335.615)
        int_3 = -3042
        int_4 = -1795
        int_5 = -1270
        int_6 = -620
        float_7 = float(1148.895)


# Generated at 2022-06-25 06:28:09.782036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Parameterized tests
    tmp = 2
    task_vars = 2


    test_case_0()


# Generated at 2022-06-25 06:28:14.086987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1661
    float_0 = -717.988
    action_module_0 = ActionModule(int_0, int_0, int_0, int_0, float_0, int_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:28:15.580551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:28:24.322231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars_0 = {}
    tmp_1 = None
    args_0 = {
        'src': 'src',
        'regexp': 'regexp',
        'dest': 'dest',
        'decrypt': True,
        'remote_src': 'remote_src',
        'delimiter': 'delimiter',
        'ignore_hidden': True,
        'follow': True,
    }
    result = {}
    ansible_action_0 = ActionModule(task_vars_0, tmp_1, args_0, result)


# Generated at 2022-06-25 06:28:28.110163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        float_0 = float('inf')
        test_case_0()
    except ValueError as e:
        assert str(e) == 'infinity or a value too large to convert to float'
        assert float_0 == float('inf')
    except Exception as e:
        assert False, str(e)


# Generated at 2022-06-25 06:28:50.996733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tmp = None
    task_vars = {}
    test_ActionModule = ActionModule(None, None, tmp, task_vars, None, None)
    
    # Stub: _exit_json
    def _exit_json(self, **kwargs):
        raise _AnsibleActionDone()

    test_ActionModule._exit_json = _exit_json

    # Stub: _fail_json
    def _fail_json(self, *args, **kwargs):
        raise AnsibleActionFail('')

    test_ActionModule._fail_json = _fail_json

    # Setup: src
    test_ActionModule._task.args = {'src': 'dir_0'}

    # Setup: dest
    test_ActionModule._task.args = {'dest': 'dir_1'}

    #

# Generated at 2022-06-25 06:28:52.194813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True


# Generated at 2022-06-25 06:28:55.239474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define input types
    tmp = None
    task_vars = None

    # Create an object of the class ActionModule
    obj_ActMod = ActionModule(tmp, task_vars)

    # Call method run of the class with the above specified inputs
    obj_ActMod.run(tmp, task_vars)



# Generated at 2022-06-25 06:28:58.570997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    inst_0 = ActionModule('mock_context')
    try:
        test_case_0()
    except:
        pass


test_ActionModule()

# Generated at 2022-06-25 06:29:01.115148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object for ActionModule
    obj_ActionModule = ActionModule()

    # test actionmodule.run
    # test error case of actionmodule.run
    #pass


# Generated at 2022-06-25 06:29:10.486118
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:29:11.556610
# Unit test for constructor of class ActionModule
def test_ActionModule():
	var_0 = ActionModule('var_0', 'var_1')

# Generated at 2022-06-25 06:29:15.780992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0.0'
    var_0 = float(str_0)
    str_1 = 'inf'
    var_1 = float(str_1)
    str_2 = '0.0'
    var_2 = float(str_2)
    str_3 = 'inf'
    var_3 = float(str_3)
    str_4 = '0.0'
    var_4 = float(str_4)


# Generated at 2022-06-25 06:29:17.748353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule()
    # TODO: review testcases for __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):


# Generated at 2022-06-25 06:29:18.389764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:29:43.127392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 10
    str_0 = 'i'
    float_1 = 100.0
    bytes_0 = b'\x02\xef\xbf\xbf\x0e\x00'
    bytes_1 = b'\x02$\x00'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    print(action_module_0)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 06:29:48.609636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.0
    str_0 = '0'
    float_1 = 100.0
    bytes_0 = b'a'
    bytes_1 = b'b'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    var_0 = action_module_0.run(float_0)


# Generated at 2022-06-25 06:29:56.556905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.0
    str_0 = 'Rn'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    var_0 = action_run(float_0)

# Generated at 2022-06-25 06:30:01.887386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    str_0 = 'test'
    float_1 = 100.0
    bytes_0 = b'\xa1m\x89\x82\x15*\x8b\x19\x82\xd6\x97\x8c\x98'
    bytes_1 = b'\x15*\x8b\x19\x82\xd6\x97\x8c\x98\x82\xd6\x97'
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    assert action_module_0._task.name is str_0
    assert isinstance(action_module_0._task.args, dict) is True
    assert action

# Generated at 2022-06-25 06:30:11.449032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_2 = 3.0
    str_1 = 'x'
    float_3 = 101.0
    bytes_2 = b'0\x95W\xae\xf5\x9a\x8e\x80MyP\x0f\x1ey'
    bytes_3 = b'\x1c'
    bool_1 = True
    action_module_1 = ActionModule(str_1, float_3, float_3, bytes_2, bytes_3, bool_1)
    float_4 = 2.0
    str_2 = 's'
    float_5 = 100.0

# Generated at 2022-06-25 06:30:16.469942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(float, float)
    result_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:30:25.730460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    assert(len(action_module_0.__dict__.keys()) == 3)
    assert(action_module_0._task == str_0)
    assert(action_module_0._connection == float_1)
    assert(action_module_0._play_context == float_1)


# Generated at 2022-06-25 06:30:34.150639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'N7\xe4\x87\xad\xf5\x9b\x15\x82\xed\xa3\x1a\x86\xb5\xce\x172\x9d\xc2\x8b\xb5\xe6\x15y'
    bytes_0 = b'\xbe\xa9\x03\x8a'
    bytes_1 = b'\xac\x8a\xdc\xa5\x9d\x85\xbc\xc3\xb2\x1d\x8e\x07\x98\x0b\x9d\xc8\xc4\xe0\x7b\x96\xb8\xfa\xfc'
    float_0 = 2.8
    bool_0 = True
   

# Generated at 2022-06-25 06:30:34.984886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert_exception(test_case_0, AnsibleActionFail)

# Generated at 2022-06-25 06:30:38.903233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:31:17.256918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 06:31:26.344368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    assert action_module_0._task is not None
    assert action_module_0._supports_async is None
    assert action_module_0._shared_loader_obj is None
    assert action_module_0._display is not None
    assert action_module_0._connection is not None
    assert action_module_0._play_context

# Generated at 2022-06-25 06:31:36.805363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path = ['./test_ActionModule_run_mocks.json']
    with open(path[0], 'w') as file_0:
        dict_0 = dict()
        dict_0 = {'stdout': 'Copy done.', 'stderr': '', 'changed': True}
        file_0.write(json.dumps(dict_0))
    float_0 = 100.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = True

# Generated at 2022-06-25 06:31:39.392024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global float_0
    global str_0
    global float_1
    global bytes_0
    global bytes_1
    global bool_0
    global action_module_0
    global var_0
    test_case_0()


# Generated at 2022-06-25 06:31:40.207920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:31:46.754103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    print(action_module_0._task.args)
    print(action_module_0._task.args)
    #assert action_module_0._task.args == {}
    #assert action_module_0._task.args == {}
    print('Done')
    return True


# Generated at 2022-06-25 06:31:51.327018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 06:31:52.751704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    int_0 = 5
    var_1 = var_0.run(int_0)


# Generated at 2022-06-25 06:31:57.002517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    var_0 = action_run(float_0)

# Generated at 2022-06-25 06:32:02.489939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)


# Generated at 2022-06-25 06:33:09.537730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception raised in invoking constructor of class ActionModule")
        print("Exception raised: " + str(e))

# Generated at 2022-06-25 06:33:15.238046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)


# Generated at 2022-06-25 06:33:25.104586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3.0
    str_0 = 'y'
    float_1 = 100.0
    bytes_0 = b'P[\x8e\x04\xcf\xdc\xcbf\x1b\xbc\x1d\xc9\xb9\xdd\xd6\x00\xa3\x02\x8f\x00\xe1\x0f@'
    bytes_1 = b'\x0c\x1b\x8b\xb1\xf7\xd1\x9c\x00\xe0\x93\xfc'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)


# Generated at 2022-06-25 06:33:32.173148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 5.0
    str_0 = 't'
    float_1 = 100.0
    bytes_0 = b'\xaa\xcfy\x1e\x14\x9eGz\x0e\xbb\x8d\xea\xfc\xc5'
    bytes_1 = b'\xb5\x83\xeb\x87\xe6\x00\x14%\x86\xbbC\x13\x9b\xcc'
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    var_0 = action_run(float_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:33:36.682483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    action_module_0.run(float_0)


# Generated at 2022-06-25 06:33:43.404807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 2.0
    str_1 = 'p'
    float_2 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    action_module_1 = ActionModule(str_1, float_2, float_2, bytes_0, bytes_1)
    assert action_module_1 is not None


# Generated at 2022-06-25 06:33:48.465635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.0
    str_0 = '5'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    var_0 = action_module_0.run(float_0)



# Generated at 2022-06-25 06:33:55.842298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.0
    str_0 = 'p'
    float_1 = 100.0
    bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
    bytes_1 = b''
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_1, float_1, bytes_0, bytes_1, bool_0)
    var_0 = action_run(float_0)
    if not var_0:
        raise Exception('Failed test')

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('Test completed')

# Generated at 2022-06-25 06:34:04.745739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	float_0 = 2.0
	str_0 = 'p'
	float_1 = 100.0
	bytes_0 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
	bytes_1 = b''
	bool_0 = False
	action_module_0 = ActionModule(str_0, float_0, float_1, bytes_0, bytes_1, bool_0)
	var_0 = 2.0
	var_1 = 100.0
	bytes_2 = b'B\x07v4\xe3\x8b&\xffNu\x10\xc3\x0e(\xb6'
	bytes_3 = b''
	bool_1 = False
	action_module_1 = ActionModule

# Generated at 2022-06-25 06:34:06.971638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test run method')
    out = StringIO()
    with redirect_stdout(out):
        test_case_0()
    output = out.getvalue().strip()
    assert output == 'Test run method'
    print('Done')


# Generated at 2022-06-25 06:36:23.559377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'o.R'
    float_0 = 100.0
    float_1 = 2.0
    bytes_0 = b'\x0f\xf4\x06\x94Eu\x0b\x9a\xc0\xac\xf7\x16\xcf\x8f'
    bytes_1 = b'\x0f\xee\x03\x11\x97\x1b\x1b\xcc\xa9\x96\x9d\x89'
    bool_0 = False
    action_module_0 = ActionModule(str_0, float_0, float_1, bytes_0, bytes_1, bool_0)
