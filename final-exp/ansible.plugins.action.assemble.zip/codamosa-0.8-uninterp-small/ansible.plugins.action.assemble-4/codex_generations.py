

# Generated at 2022-06-25 06:26:43.695665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '8/\x0c/;\x00H\x0c8\x0c\r&\x0c\x0c&\x0c\x0c&\x0c\x0c'
    float_0 = -1677.08737
    dict_0 = {str_0: float_0, float_0: str_0}
    list_0 = [float_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    str_1 = '`^\x0bP\x0c\x0c'
    str_2 = 'pE]@\x0c\x0c'
    float_1 = -1179

# Generated at 2022-06-25 06:26:54.621818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    func_1 = mock()
    func_0 = mock_register(action_module_0._execute_module, func_1)
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    bool_0 = action_module_0.run(str_0, dict_0)
    try:
        assert_equal(bool_0, True)
    finally:
        func

# Generated at 2022-06-25 06:26:58.091466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule
    assert action_module_0.__init__() == None

# Generated at 2022-06-25 06:27:02.070065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = None
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(src, tmp, task_vars)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:27:02.773805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-25 06:27:12.628781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)

    try:
        var_0 = action_module_0.run()
    except Exception:
        var_0 = None
    assert var_0 is None



# Generated at 2022-06-25 06:27:15.641827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

# Generated at 2022-06-25 06:27:23.953293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_module_0.run(tmp=float_0, task_vars=dict_0)


# Generated at 2022-06-25 06:27:32.064343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '<5'
    float_0 = -0.5612
    dict_0 = {float_0: str_0, str_0: float_0, str_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)

# Generated at 2022-06-25 06:27:37.164980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ')o&PkpNx\x0b?g\x0b"1'
    float_0 = 0.30109
    dict_0 = {str_0: 0.0, str_0: str_0, str_0: dict_0}
    list_0 = [dict_0, dict_0, dict_0, str_0, str_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 06:27:51.500090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'G}8%4]f'
    float_0 = -2116.8229
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)


# Generated at 2022-06-25 06:27:58.050767
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:28:08.403354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'XtM\x0bm|\x19\\\x0b)N\x0b!Nx\x0b>N\x0b%|\x0b?_\x0b+]\x0b#\x1a\x16\x0b\x1f\x0b4J\x0b)j\x0b.x'
    float_0 = 0.40830
    dict_0 = {str_0: float_0, float_0: str_0, str_0: str_0}
    list_0 = [float_0, str_0, str_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)


# Generated at 2022-06-25 06:28:14.820745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    assert isinstance(action_module_0._supports_check_mode, bool)
    assert action_module_0._supports_check_mode == False
    assert isinstance(action_module_0._supports_async, bool)
    assert action_module_0._supports_async == False

# Generated at 2022-06-25 06:28:20.667734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = '~\x00t\x0b\x0bE\x0b\x02\x08\x0b\x0b\x0b'
    float_1 = 1.72647e-05
    float_2 = -4794.744
    float_3 = -259.7767

# Generated at 2022-06-25 06:28:31.137258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'P\x0b|\x1c\x0c\x1f\x19!\x07&F9\x0c'
    float_0 = -0.4189355055272126
    dict_0 = {str_0: float_0, float_0: str_0}
    list_0 = [float_0, dict_0, dict_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0.action == str_0
    assert action_module_0.args == dict_0
    assert action_module_0.container == list_0
    assert action_module_0

# Generated at 2022-06-25 06:28:37.041292
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create a the class object and check if its instance
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_ActionModule()

# Generated at 2022-06-25 06:28:45.753740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'm8'
    float_1 = 9732.7437
    dict_1 = {'m7': str_1}
    list_1 = [float_1]
    action_module_1 = ActionModule(str_1, float_1, dict_1, list_1, float_1, str_1)
    action_run(str_1)
    str_2 = '5e'
    float_2 = 0.06748
    dict_2 = {'5d': str_2}
    list_2 = [float_2]
    action_module_2 = ActionModule(str_2, float_2, dict_2, list_2, float_2, str_2)
    action_run(str_2)
    return


# Generated at 2022-06-25 06:28:48.225931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except TypeError as e:
        assert type(e) == TypeError
    except Exception as e:
        assert type(e) == NameError


# Generated at 2022-06-25 06:28:57.044531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'R$>\x1b7;\xe1\x1b]'
    float_0 = 1974.0313
    dict_0 = {str_0: float_0, float_0: float_0, float_0: float_0}
    list_0 = [float_0, str_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    action_module_0.run()
    action_module_0.run(str_0)
    action_module_0.run(str_0, dict_0)


# Generated at 2022-06-25 06:29:23.703834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Prepare data for testing
    a_load_0 = 'Dormitory'
    b_load_0 = -983.038
    c_load_0 = {'gumdrop': 'sapient', 'gumdrop': 'archaic', 'sapient': 'gumdrop'}
    d_load_0 = [{'gumdrop': 'sapient', 'gumdrop': 'archaic', 'sapient': 'gumdrop'}, -983.038, -983.038]
    e_load_0 = -983.038
    f_load_0 = {a_load_0: b_load_0, a_load_0: b_load_0, b_load_0: a_load_0}

# Generated at 2022-06-25 06:29:29.228151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1b,i\x1djK\x7f\x16f\x7f.\x1b)7\x1b\x06k\x1dkP'
    float_0 = -3.9073284994966327e-7
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 06:29:37.093452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = ']G4\x0b=xPy\x0b%P$wlx'
    float_1 = -1959.2305
    dict_1 = {str_1: float_1, str_1: float_1, float_1: str_1}
    list_1 = [dict_1, float_1, float_1]
    action_module_1 = ActionModule(str_1, float_1, dict_1, list_1, float_1, dict_1)
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 06:29:41.228222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a_module = ActionModule(a, b, c, d, e, f)
    assert a_module.run() == a
    pass

# Generated at 2022-06-25 06:29:47.090751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_module_0._assemble_from_fragments(dict_0)
    assert var_0 == str_0
    assert not var_0 is None
    assert isinstance(var_0, str)
    assert var_0 == str_0
    assert not var_0 is None
   

# Generated at 2022-06-25 06:29:51.286384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        res = run()
    except:
        raise Exception('test_ActionModule_run failed!')

# Generated at 2022-06-25 06:29:56.585129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # source of the assembly directory
    src = "/some/path/on/filesystem/"
    dest = "/some/other/path"
    tmp = "/tmp/path"
    task_vars = None
    action_module_0 = ActionModule(src, dest, tmp, task_vars)
    action_module_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:30:00.478311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'sR$\x0b\x19\x06\x03'
    float_0 = -1933.3
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [float_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    print(action_module_0)


# Generated at 2022-06-25 06:30:01.549849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, type)

# Generated at 2022-06-25 06:30:08.147578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9.$n-L'
    float_0 = 1697.498
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 06:30:57.274010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Om\x0bq4\x0b=9\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)


# Generated at 2022-06-25 06:31:04.667013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)

main()

# Generated at 2022-06-25 06:31:05.352685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:31:12.640419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = ']G4\x0b=xPy\x0b%P$wlx'
    float_1 = -1959.2305
    dict_1 = {str_1: float_1, str_1: float_1, float_1: str_1}
    list_1 = [dict_1, float_1, float_1]
    action_module_1 = ActionModule(str_1, float_1, dict_1, list_1, float_1, dict_1)


# Generated at 2022-06-25 06:31:20.348201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = [1, 2, 3, 4]
    param_1 = [1, 2, 3, 4]
    # prepare the parameters
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    # run the test
    result = action_module_0.run(param_0, param_1)
    assert result == 'something'

# Generated at 2022-06-25 06:31:26.709701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'action.yml'
    float_1 = -852.891
    dict_1 = {str_1: float_1, str_1: str_1, float_1: float_1}
    list_1 = [str_1, float_1]
    action_module_0 = ActionModule(str_1, float_1, dict_1, list_1, float_1, dict_1)
    var_1 = action_run(str_1)

# Generated at 2022-06-25 06:31:36.835122
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_test_0 = ActionModule()
    assert(isinstance(action_module_test_0, ActionModule))

    action_module_test_1 = ActionModule(1)
    assert(isinstance(action_module_test_1, ActionModule))

    action_module_test_2 = ActionModule(1, 2)
    assert(isinstance(action_module_test_2, ActionModule))

    action_module_test_3 = ActionModule(1, 2, 3)
    assert(isinstance(action_module_test_3, ActionModule))

    action_module_test_4 = ActionModule(1, 2, 3, 4)
    assert(isinstance(action_module_test_4, ActionModule))

    action_module_test_5 = ActionModule(1, 2, 3, 4, 5)
   

# Generated at 2022-06-25 06:31:46.218126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\t\0\t"\x0b\x12\x07\x19\t'
    float_0 = 1.98
    dict_0 = {'+C\x1b\x1dQ': '\t\0\t"\x0b\x12\x07\x19\t', '&\x1e\x1f\x19\x0f': str_0, 'N\x00\x07\x0c\x0c': float_0}
    list_0 = [str_0, dict_0, '\t\0\t"\x0b\x12\x07\x19\t']
    action_module_0 = ActionModule(str_0, dict_0, dict_0, list_0, list_0, dict_0)

# Generated at 2022-06-25 06:31:52.205009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    str_0 = 'w{\\\x0b'
    action_module_0.action_plugin_loader = action_plugin_loader_0 = ActionLoader(str_0, float_0, dict_0, list_0, float_0, dict_0)
    action_module_0.action_base = action

# Generated at 2022-06-25 06:32:00.342703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor of class ActionModule
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    str_1 = '=Zf6<0q3}N\x19\x1d9%c\x0e'
    str_2 = '  \n]G4\x0b=xPy\x0b%P$wlx\n  \n'
    float_0 = -1959.2305
    list_0 = []
    list_1 = []
    dict_0 = {}
    dict_1 = {}
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)

# Generated at 2022-06-25 06:33:28.212116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 06:33:34.644208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Mh%t\x0b+\x0bJ\x0by\x0b'
    float_0 = 461.08088
    dict_0 = {float_0: str_0, str_0: 'VPD\x0b\x0byB-\x0bD'}
    list_0 = [dict_0, dict_0, dict_0]
    action_module_0 = ActionModule(dict_0, list_0, dict_0, str_0, str_0, dict_0)
    action_module_1 = ActionModule(float_0, dict_0, dict_0, 'N\x0b\x0b\x0b\x0b\x0b\x0b\x0b', '', dict_0)

# Generated at 2022-06-25 06:33:45.430820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n***** TESTING: run of class ActionModule\n")
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    float_0 = -1959.2305
    var_0 = False
    str_1 = ']G4\x0b=xPy\x0b%P$wlx'
    float_1 = -1959.2305
    dict

# Generated at 2022-06-25 06:33:55.019794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1$G\x0b8\x15\x06\x1c\x13?Jt\x1a\x1d\x0f0\x07\x1b\x0f'
    float_0 = 87.129629
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    var_0 = action_module_0.run(float_0, dict_0)
    assert var_0 == None

if __name__ == "__main__":
	test_case_

# Generated at 2022-06-25 06:34:00.411344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    assert action_module_0.TRANSFERS_FILES is True


# Generated at 2022-06-25 06:34:03.337115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float()
    dict_0 = dict()
    str_0 = str()
    action_module_0 = ActionModule(str_0, float_0, dict_0, list(), float_0, dict_0)
    action_module_0.run()



# Generated at 2022-06-25 06:34:08.984386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule("\x06\x12\x05\x00\x11\x15", -0.0012601262297356041, {'Eo\x15\x06\x01S\x0e': 0.000549952994742431}, [0.0, '9\t\x1d\rCC5\x1a\x05\x0e', -588.73592], -1940.4948788982546, {'\x06\x12\x05\x00\x11\x15': 'Eo\x15\x06\x01S\x0e'})
    str_0 = 'A'
    float_0 = -9.2839

# Generated at 2022-06-25 06:34:13.482629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0._supports_check_mode is False


# Generated at 2022-06-25 06:34:22.334261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']G4\x0b=xPy\x0b%P$wlx'
    float_0 = -1959.2305
    dict_0 = {str_0: float_0, str_0: float_0, float_0: str_0}
    list_0 = [dict_0, float_0, float_0]
    action_module_0 = ActionModule(str_0, float_0, dict_0, list_0, float_0, dict_0)
    str_1 = 'Q4\n\x0cG\x19w-h\x1f\x1c%'
    float_1 = -839.9829

# Generated at 2022-06-25 06:34:27.965766
# Unit test for method run of class ActionModule