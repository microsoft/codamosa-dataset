

# Generated at 2022-06-22 14:58:30.737465
# Unit test for function debug
def test_debug():
    message = 'message'

    def assert_called(called):
        assert called

    called = False

    def get_message():
        nonlocal called
        called = True
        return message

    # Check if assertions are disabled
    original = sys.gettrace()
    sys.settrace(None)
    debug(get_message)
    sys.settrace(original)
    assert not called

    # Check if function is called when assertions are enabled
    current_debug = settings.debug
    settings.debug = True
    debug(get_message)
    settings.debug = current_debug
    assert called

# Generated at 2022-06-22 14:58:32.672199
# Unit test for function eager
def test_eager():
  from test.test_generator import TestGenerator
  assert TestGenerator().call_eager([1,2,3]) == [1,2,3], "eager function is not working"

# Generated at 2022-06-22 14:58:40.828839
# Unit test for function get_source
def test_get_source():
    """
    Unit test for function get_source.
    """
    def test_fn():
        """'\
        test_fn is a test function to test the get_source function.
        """
        print(123)

    def get_source_test_fn():
        """
        This is a test for get_source function.
        """
        return get_source(test_fn)

    test_source = get_source(get_source_test_fn)
    assert test_source == "def test_fn():\n    " + "'\\\n        test_fn is a test function to test the get_source function.\n        '\n    print(123)\n"
    print("Test for get_source function passed!")

# Generated at 2022-06-22 14:58:44.421944
# Unit test for function eager
def test_eager():
    @eager
    def func() -> Iterable[int]:
        yield 1
        yield 2
        yield 3
        yield 4
    assert func() == [1, 2, 3, 4]

# Generated at 2022-06-22 14:58:55.003573
# Unit test for function get_source

# Generated at 2022-06-22 14:58:57.495902
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass\n'

# Generated at 2022-06-22 14:58:59.212228
# Unit test for function eager
def test_eager():
    from itertools import count
    assert eager(count)() == list(count(0))

# Generated at 2022-06-22 14:59:04.407036
# Unit test for function debug
def test_debug():
    test_debug_get_message = []  # type: List[str]
    def get_message():
        test_debug_get_message.append('secret')
        return 'secret'
    debug(get_message)
    assert len(test_debug_get_message) == 0

    settings.debug = True
    debug(get_message)
    assert len(test_debug_get_message) == 1



# Generated at 2022-06-22 14:59:08.881516
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stdout

    buffer = StringIO()

    with redirect_stdout(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == ''

    buffer = StringIO()
    settings.debug = True

    with redirect_stdout(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == '\x1b[90mtest\x1b[39m\n'

    settings.debug = False

# Generated at 2022-06-22 14:59:12.563987
# Unit test for function get_source
def test_get_source():
    def test():
        print("Test")
        print("Test2")
    assert get_source(test) == "print(\"Test\")\nprint(\"Test2\")"



# Generated at 2022-06-22 14:59:17.237258
# Unit test for function eager
def test_eager():
    @eager
    def fn():
        yield 1
        yield 2
        yield 3

    assert fn() == [1, 2, 3]

# Generated at 2022-06-22 14:59:19.342111
# Unit test for function eager
def test_eager():

    @eager
    def lazy_ones() -> Iterable[int]:
        yield 1
        yield 1

    assert lazy_ones() == [1, 1]

# Generated at 2022-06-22 14:59:22.557266
# Unit test for function get_source
def test_get_source():
    def function():
        return 2 + 2

    assert get_source(function) == 'return 2 + 2'

# Generated at 2022-06-22 14:59:23.686237
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-22 14:59:25.553833
# Unit test for function eager
def test_eager():
    assert eager(lambda: iter([1, 2, 3]))() == [1, 2, 3]

# Generated at 2022-06-22 14:59:26.534692
# Unit test for function debug
def test_debug():
    assert debug('test debug') is None



# Generated at 2022-06-22 14:59:34.082236
# Unit test for function get_source
def test_get_source():
    def some_function():
        """This is some function."""
        a = 0
        b = None
        if b is None:
            b = a
        return b

# Generated at 2022-06-22 14:59:36.736446
# Unit test for function get_source
def test_get_source():
    def foo(x):
        a = x
        b = a
        return b


# Generated at 2022-06-22 14:59:46.841576
# Unit test for function get_source
def test_get_source():
    from .base import BaseGenerator


    class TestGenerator(BaseGenerator):

        def render(self, fn: Callable[..., Any], name: str) -> str:
            """ Returns a function as a string. """
            return 'def {}():\n{}'.format(
                name, '    ' + get_source(fn).strip().replace('\n', '\n    ')
            )

    test_generator = TestGenerator()
    result = test_generator.test_fn()
    assert result == """def test_fn():
    @test_generator.generate("test_fn")
    def _py_backwards_test_fn_0():
        ...
    return 0"""



# Generated at 2022-06-22 14:59:51.085219
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(5):
            yield i

    bar = eager(foo)

    assert isinstance(bar(), list)
    assert bar() == [0,1,2,3,4]

# Generated at 2022-06-22 15:00:04.044081
# Unit test for function debug
def test_debug():
    debug_message = None

    def get_message():
        return 'Debug message'

    def reset():
        nonlocal debug_message
        debug_message = None

    def open():
        nonlocal debug_message
        debug_message = sys.stderr

    def print(message, file=None, end=None):
        nonlocal debug_message
        assert file is sys.stderr
        assert end is '\n'
        debug_message = message

    sys.modules['sys'] = sys = type('', (), {
        'stderr': sys.stderr,
        'debug': False
    })
    sys.modules['backwards.conf.settings'] = settings = type('', (), {
        'debug': False
    })

# Generated at 2022-06-22 15:00:06.578614
# Unit test for function get_source
def test_get_source():
    called = False

    def test():
        called = True

    assert get_source(test) == 'called = True\n'

# Generated at 2022-06-22 15:00:08.736625
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for i in range(5):
            yield i
    assert gen() == list(range(5))

# Generated at 2022-06-22 15:00:11.348249
# Unit test for function get_source
def test_get_source():
    def test_func():
        return 'test'

    assert get_source(test_func) == 'return "test"'



# Generated at 2022-06-22 15:00:13.240285
# Unit test for function get_source
def test_get_source():
    assert get_source(warn) == (
        """print(messages.warn(message), file=sys.stderr)""")

# Generated at 2022-06-22 15:00:17.689557
# Unit test for function debug
def test_debug():
    #pylint: disable=import-outside-toplevel
    from ..conf import settings
    old, settings.debug = settings.debug, True
    try:
        debug(lambda: 'debug')
    finally:
        settings.debug = old


# Generated at 2022-06-22 15:00:20.212445
# Unit test for function get_source
def test_get_source():
    def source(): pass
    def source2(): pass
    assert get_source(source) == 'def source(): pass'
    assert get_source(source2) == 'def source2(): pass'

# Generated at 2022-06-22 15:00:22.503255
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-22 15:00:26.348824
# Unit test for function get_source
def test_get_source():
    def get_source_test():
        def some_function():
            pass

        return get_source(some_function)

    assert get_source_test() == 'def some_function():\n    pass\n'

# Generated at 2022-06-22 15:00:30.706880
# Unit test for function eager
def test_eager():
    from random import randint
    from time import sleep

    @eager
    def test():
        for _ in range(3):
            yield randint(1, 3)
            sleep(0.1)

    result = test()
    assert isinstance(result, list)
    assert len(result) == 3
    assert result == sorted(result)

# Generated at 2022-06-22 15:00:41.331271
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == 'def get_source(fn: Callable[..., Any]) -> str:\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)'

# Generated at 2022-06-22 15:00:42.903902
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'kitty')
    debug(lambda: 'doggy')
    debug(lambda: 'rabbit')
    settings.debug = False
    debug(lambda: 'mouse')

# Generated at 2022-06-22 15:00:44.845175
# Unit test for function eager
def test_eager():
    def f():
        for i in range(3):
            yield i
    assert(eager(f)() == [0, 1, 2])

# Generated at 2022-06-22 15:00:56.840911
# Unit test for function debug
def test_debug():
    from .utils import get_stdout
    from .mock import Mock, patch

    counter = 0
    def fn():
        nonlocal counter
        counter = 1

    mock = Mock(return_value='Hello, World!')

    with patch('py_backwards.utils.settings.debug', True), \
            patch('py_backwards.utils.print', mock), \
            get_stdout():
        debug(fn)
    assert mock.called
    assert mock.call_args[0][0] == 'Hello, World!'
    assert counter == 1

    with patch('py_backwards.utils.settings.debug', False), \
            patch('py_backwards.utils.print', mock), \
            get_stdout():
        debug(fn)
    assert not mock.called
    assert counter == 2

# Generated at 2022-06-22 15:01:02.272209
# Unit test for function get_source
def test_get_source():
    def a():
        """abc"""
        return 3

    # TODO
    #assert get_source(a) == 'return 3'

    def b():
        def c():
            r = 2
            return r

        return c()

    #assert get_source(b) == '\n'.join(['return c()', 'def c():', '    r = 2', '    return r'])

# Generated at 2022-06-22 15:01:09.283604
# Unit test for function get_source
def test_get_source():
    def deco(fn: Callable) -> Callable:
        @wraps(fn)
        def wrapped(*args, **kwargs):
            return fn(*args, **kwargs)

        wrapped.__doc__ = get_source(fn)
        return wrapped

    @deco
    def foo():
        pass

    @deco
    def bar():
        pass

    assert get_source(foo) == get_source(bar)



# Generated at 2022-06-22 15:01:20.200813
# Unit test for function debug
def test_debug():
    assert get_source(debug) == """
        def debug(get_message):
            if settings.debug:
                print(messages.debug(get_message()), file=sys.stderr)
    """
    with mock.patch('sys.stderr.write') as mocked_write, \
         mock.patch('backwards.settings.debug', True):
        message = 'some'
        debug(lambda: message)
        assert mocked_write.call_args[0][0] == '\x1b[90msome\x1b[0m\n'
    with mock.patch('sys.stderr.write'), \
         mock.patch('backwards.settings.debug', False):
        message = 'some'
        debug(lambda: message)
        assert not mocked_write.called


# Generated at 2022-06-22 15:01:21.820245
# Unit test for function get_source

# Generated at 2022-06-22 15:01:23.416762
# Unit test for function debug
def test_debug():
    assert debug('test_debug') == None

# Generated at 2022-06-22 15:01:28.059160
# Unit test for function debug
def test_debug():
    sys.stderr = StringIO()
    try:
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == '\npy_backwards: debug - test\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:01:40.612523
# Unit test for function eager
def test_eager():
    
    import random
    
    @eager
    def fib(n):
        x, y = 1, 0
        for _ in range(n):
            x, y = x+y, x
            yield x
    
    
    # This is a lazy function
    def fib2(n):
        x, y = 1, 0
        for _ in range(n):
            x, y = x+y, x
            yield x
    
    l1 = fib(10)
    l2 = fib2(10)
    assert l1 == list(l2)
    
    l1 = fib(random.randint(1, 20))
    l2 = fib2(random.randint(1, 20))
    assert l1 == list(l2)



# Generated at 2022-06-22 15:01:43.029075
# Unit test for function get_source
def test_get_source():
    def test_fn():
        local_variable = 1

    assert get_source(test_fn) == 'local_variable = 1'



# Generated at 2022-06-22 15:01:49.160416
# Unit test for function debug
def test_debug():
    global settings
    warnings = []
    settings = SimpleNamespace(debug=True)

    def warn(message):
        warnings.append(message)

    global print
    print = warn
    global sys
    sys = SimpleNamespace(stderr=warn)

    debug(lambda: 'My message')
    assert warnings == ['\x1b[33mMy message\x1b[0m']
    warnings = []
    settings.debug = False
    debug(lambda: 'My message')
    assert warnings == []



# Generated at 2022-06-22 15:01:50.756579
# Unit test for function get_source
def test_get_source():
    def test():
        """
            Returns 0
        """
        return 0
    assert get_source(test) == 'def test():\n    """\n        Returns 0\n    """\n    return 0'

# Generated at 2022-06-22 15:01:53.425555
# Unit test for function get_source
def test_get_source():
    def akshat():
        akshat1 = "Akshat"
        print("Hello {}".format(akshat1))
    return get_source(akshat)

# Generated at 2022-06-22 15:01:54.933825
# Unit test for function get_source
def test_get_source():
    from ..tests.test_helpers import get_source as test_get_source

    # when 0
    assert get_source(test_get_source) == test_get_source.__doc__

# Generated at 2022-06-22 15:01:57.773862
# Unit test for function debug
def test_debug():
    messages._debug_indent_level = 0
    debug(lambda: 'message')
    messages._debug_indent_level = 0
    settings.debug = False
    debug(lambda: 'message')
    settings.debug = True
    print('debug test passed')

# Generated at 2022-06-22 15:01:59.621833
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'

    debug(get_message)

# Generated at 2022-06-22 15:02:02.656402
# Unit test for function get_source
def test_get_source():
    def get_source1():
        return 'This is a test'

    assert get_source(get_source1) == "return 'This is a test'"



# Generated at 2022-06-22 15:02:07.385494
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == ['    pass'][0]

    def g():
        pass

    def h():
        pass

    assert get_source(g) == ['    pass'][0]
    assert get_source(h) == ['    pass'][0]

# Generated at 2022-06-22 15:02:26.470297
# Unit test for function debug
def test_debug():
    def mock_stderr():
        return [str(x) for x in sys.stderr.getvalue().splitlines()]

    message = 'This is a test'
    with patch('sys.stderr', new_callable=StringIO) as mock_stdout:
        debug(lambda: message)
        assert message in mock_stderr()
        assert any('DEBUG:' in x for x in mock_stderr())

    with patch('sys.stderr', new_callable=StringIO) as mock_stdout:
        settings.debug = False
        debug(lambda: message)
        assert mock_stderr() == []

# Generated at 2022-06-22 15:02:29.242525
# Unit test for function get_source
def test_get_source():
    def sample_function():
        a = 1
        b = 2
        return a + b
    assert get_source(sample_function) == 'a = 1\nb = 2\nreturn a + b'

# Generated at 2022-06-22 15:02:41.306687
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase

    output = StringIO()
    sys.stderr = output

    class Dummy(TestCase):
        def test_simple(self):
            settings.debug = True
            try:
                debug(lambda: 'dummy')
                self.assertEqual(output.getvalue(), '>>> dummy\n')
            finally:
                sys.stderr = sys.__stderr__

        def test_not_debugging(self):
            settings.debug = False
            try:
                debug(lambda: 'dummy')
                self.assertEqual(output.getvalue(), '')
            finally:
                sys.stderr = sys.__stderr__

    Dummy('test_simple').test_simple()

# Generated at 2022-06-22 15:02:49.551747
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def bar():
        if True:
            pass

    assert get_source(bar) == 'if True:\n    pass'

    def baz():
        if True:
            pass

    assert get_source(baz) == 'if True:\n    pass'

    def faz(a: int, b: str) -> str:
        return a + b

    assert get_source(faz) == 'return a + b'


# End

# Generated at 2022-06-22 15:02:51.066271
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
    assert eager(f)() == [1, 2]

# Generated at 2022-06-22 15:02:53.544198
# Unit test for function eager
def test_eager():

    @eager
    def f() -> Iterable[int]:
        yield 1
        yield 2

    assert f() == [1, 2]

# Generated at 2022-06-22 15:02:55.736517
# Unit test for function eager
def test_eager():
    def gen():
        yield 1
        yield 2
        yield 3

    assert eager(gen)() == [1, 2, 3]

# Generated at 2022-06-22 15:02:57.347451
# Unit test for function get_source
def test_get_source():
    def foo():
        return True

    assert get_source(foo) == 'return True'

# Generated at 2022-06-22 15:02:58.366606
# Unit test for function debug
def test_debug():
    msg = 'I am message'
    def get_message():
        return msg

    debug(get_message)
    assert settings.debug == True

# Generated at 2022-06-22 15:03:08.631283
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            sys.stdout = self._stdout
    with Capturing() as output:
        settings.debug = True
        debug(lambda: 'debug message')
    assert output == ['DEBUG: debug message']
    with Capturing() as output:
        settings.debug = False
        debug(lambda: 'debug message')
    assert output == []

# Generated at 2022-06-22 15:03:35.947331
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'
    def g(a):
        pass
    assert get_source(g) == 'def g(a):\n    pass'
    
test_get_source()

# Generated at 2022-06-22 15:03:38.692706
# Unit test for function get_source
def test_get_source():
    def foo():
        """Bar"""
        x = 1
        return x

    assert get_source(foo) == 'x = 1\nreturn x'



# Generated at 2022-06-22 15:03:40.070708
# Unit test for function get_source

# Generated at 2022-06-22 15:03:48.639736
# Unit test for function debug
def test_debug():
    class DummyFile:
        def __init__(self) -> None:
            self.content = ''  # type: str

        def write(self, string: str) -> None:
            self.content += string

    def dummy_debug_function(message: str) -> None:
        pass

    sys.stderr = DummyFile()
    debug(lambda: 'test')
    assert sys.stderr.content == ''

    settings.debug = True
    debug(lambda: 'test')
    assert sys.stderr.content == 'test\n'
    sys.stderr.content = ''

    settings.debug = False
    debug(lambda: 'test')
    assert sys.stderr.content == ''

    settings.debug = dummy_debug_function
    debug(lambda: 'test')

# Generated at 2022-06-22 15:03:49.572397
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-22 15:03:52.260213
# Unit test for function debug
def test_debug():
    test_var = None
    def test_fn():
        return test_var
    def test_function():
        debug(lambda: test_fn())
    test_var = 'test'
    test_function()

# Generated at 2022-06-22 15:04:01.933348
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from io import StringIO
    from ..conf import settings

    @contextmanager
    def capture_stderr() -> StringIO:
        stderr_file = StringIO()
        std_err = sys.stderr
        try:
            sys.stderr = stderr_file
            yield stderr_file
        finally:
            sys.stderr = std_err


    with capture_stderr() as stderr_file:
        settings.debug = False
        debug(lambda: 'Some message')
        assert stderr_file.getvalue() == ''

        settings.debug = True
        debug(lambda: 'Some message')
        assert stderr_file.getvalue() == 'Some message\n'

test_debug()

# Generated at 2022-06-22 15:04:04.053911
# Unit test for function eager
def test_eager():
    @eager
    def test(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert test(42) == [i for i in range(42)]

# Generated at 2022-06-22 15:04:07.131800
# Unit test for function debug
def test_debug():
    from .mocks import MockStream

    stream = MockStream()
    settings.debug = True
    sys.stderr = stream
    debug(lambda: 'test')
    assert stream.text == messages.debug('test')
    settings.debug = False
    debug(lambda: 'test')
    assert stream.text == messages.debug('test')
    sys.stderr = sys.__stderr__



# Generated at 2022-06-22 15:04:09.208186
# Unit test for function get_source
def test_get_source():

    def dummy_function():
        pass

    def dummy_function2():
        """Multiline
        definition"""
        pass

    assert get_source(dummy_function) == 'def dummy_function():'
    assert get_source(dummy_function) == get_source(dummy_function2)

# Generated at 2022-06-22 15:04:44.256424
# Unit test for function eager
def test_eager():
    from random import randint
    from ..executor.patch import get_data_from_patch

    @eager
    def random_numbers() -> Iterable[int]:
        for _ in range(10):
            yield randint(0, 100)

    @eager
    def random_numbers_range(start: int, end: int) -> Iterable[int]:
        for _ in range(10):
            yield randint(start, end)

    assert random_numbers() == get_data_from_patch(random_numbers)
    assert random_numbers_range(2, 4) == get_data_from_patch(random_numbers_range, 2, 4)



# Generated at 2022-06-22 15:04:48.478676
# Unit test for function get_source
def test_get_source():
    def function1():
        return 1

    def function2():
        a = 1
        b = 2
        return a + b

    def function3():
        return function1() + function2() * 2

    assert get_source(function1) == "return 1"
    assert get_source(function2) == "a = 1\n    b = 2\n    return a + b"
    assert get_source(function3) == "return function1() + function2() * 2"

# Generated at 2022-06-22 15:04:54.877520
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'message')
    sys.stderr.read() == '{}message\n'.format(messages.DEBUG_PREFIX)
    settings.debug = False
    debug(lambda: 'message')
    sys.stderr.read() == ''
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

# Generated at 2022-06-22 15:04:58.805741
# Unit test for function get_source
def test_get_source():
    def fn(a, b, c=0, d=None):
        print('Hello')
    assert get_source(fn) == 'def fn(a, b, c=0, d=None):\n    print(\'Hello\')'

# Generated at 2022-06-22 15:04:59.942418
# Unit test for function get_source

# Generated at 2022-06-22 15:05:04.120813
# Unit test for function get_source
def test_get_source():
    def target():
        """
            This is some function.
        """
        # Some block.
        a = 2 + 2
        return a

    def target2():
        a = 2 + 2
        b = 2 + 2
        return b

    assert target.__source__ == 'return a'
    assert target2.__source__ == 'return b'

# Generated at 2022-06-22 15:05:08.594201
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: '123')
    assert True

    settings.debug = True
    try:
        debug(lambda: '123')
    except SystemExit:
        assert False
    else:
        assert True
    finally:
        sys.stderr.close()
        settings.debug = False

# Generated at 2022-06-22 15:05:12.596793
# Unit test for function debug
def test_debug():
    from io import StringIO
    from ..conf import set_debug
    set_debug(True)
    out = StringIO()
    with redirect_stdout(out):
        debug(lambda: "Message")
        assert out.getvalue() == ":bug: Message\n"



# Generated at 2022-06-22 15:05:14.500509
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test message')



# Generated at 2022-06-22 15:05:17.275458
# Unit test for function eager
def test_eager():
    # pylint: disable=E1120
    
    def f():
        for i in [1, 2, 3]:
            yield i
    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-22 15:06:19.506821
# Unit test for function debug
def test_debug():
    class Spy:
        def __init__(self) -> None:
            self.messages = []

        def write(self, text: str) -> None:
            self.messages.append(text)

    settings.debug = True
    sys.stderr = Spy()

    debug(lambda: '{}')
    assert 'lambda' in sys.stderr.messages[-1]

    settings.debug = False
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:06:29.554190
# Unit test for function debug
def test_debug():
    from collections import namedtuple
    from unittest import TestCase
    from io import StringIO
    from unittest.mock import patch
    from py_backwards.debug import debug

    class DebugTest(TestCase):
        @patch.object(sys, 'stderr', new_callable=StringIO)
        @patch.object(settings, 'debug', False)
        def test_debug_with_debug_disabled_should_not_log_message(self, mock_stderr, mock_settings):
            debug(lambda x: 'x')
            self.assertFalse(mock_stderr.getvalue())


# Generated at 2022-06-22 15:06:32.445027
# Unit test for function get_source
def test_get_source():
    def function_to_test():
        return 1

    test_string = 'def function_to_test():\n    return 1'
    assert test_string == get_source(function_to_test)



# Generated at 2022-06-22 15:06:33.806124
# Unit test for function get_source
def test_get_source():
    import re
    def f():
        if True:
            pass
    if re.match(
            r'if True:\n *pass',
            get_source(f),
            flags=re.S,
    ):
        print('get_source works')


test_get_source()

# Generated at 2022-06-22 15:06:36.885798
# Unit test for function get_source
def test_get_source():
    @settings(debug=False)
    def test():
        pass
    assert get_source(test) == 'def test():\n    pass'

    @settings(debug=True)
    def test(a, b, c):
        return a + b + c
    assert get_source(test) == 'def test(a, b, c):\n    return a + b + c'

# Generated at 2022-06-22 15:06:38.178923
# Unit test for function get_source
def test_get_source():
    from my_module.my_package.my_file import my_function

# Generated at 2022-06-22 15:06:39.152537
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)

# Generated at 2022-06-22 15:06:42.283824
# Unit test for function eager
def test_eager():
    @eager
    def f(lst):
        for item in lst:
            yield item

    assert f([1, 2, 3]) == [1, 2, 3]


__all__ = ['eager', 'VariablesGenerator', 'get_source', 'warn', 'debug']

# Generated at 2022-06-22 15:06:46.637250
# Unit test for function debug
def test_debug():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stderr = captured_output

    debug(lambda: 'test')
    output = captured_output.getvalue()
    assert re.match(r'^\[py-backwards\] test\n$', output)

    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:06:47.551293
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'message')
    assert True



# Generated at 2022-06-22 15:07:54.097909
# Unit test for function get_source
def test_get_source():
    def foo(): pass
    import inspect
    assert get_source(foo) == inspect.getsource(foo)
    assert get_source(test_get_source) == inspect.getsource(test_get_source)[1:]

# Generated at 2022-06-22 15:07:56.375429
# Unit test for function eager
def test_eager():
    @eager
    def return_generator():
        yield 1
        yield 2
        yield 3

    assert return_generator() == [1, 2, 3]

# Generated at 2022-06-22 15:08:03.014019
# Unit test for function debug
def test_debug():
    def mocked_print(message: str) -> None:
        print('Mocked: ' + message)
    original_print = print
    print = mocked_print
    with mock.patch.object(
            sys, 'stderr', new_callable=io.StringIO) as mocked_stderr:
        warnings.warn("test")
        mocked_stderr.seek(0)
        assert mocked_stderr.read() == ''
        settings.debug = True
        warnings.warn("test")
        mocked_stderr.seek(0)
        assert mocked_stderr.read() == messages.debug("test") + "\n"
    print = original_print

# Generated at 2022-06-22 15:08:05.198989
# Unit test for function eager
def test_eager():
    @eager
    def add(a, b):
        yield a + b
        yield a + b + 1
    assert add(1, 2) == [3, 4]

# Generated at 2022-06-22 15:08:09.296064
# Unit test for function get_source
def test_get_source():
    def some_function(*args, **kwargs):
        pass

    text = """
    def some_function(*args, **kwargs):
        pass
    """

    assert text == get_source(some_function)

# Generated at 2022-06-22 15:08:15.364735
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from ..conf import set_settings, Settings

    set_settings(Settings(debug=True, verbose='debug'))

    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'Test debug')
        assert(mock_stderr.write.call_args[0][0] == '\x1b[35m   Debug: Test debug\n\x1b[0m')

# Generated at 2022-06-22 15:08:20.014583
# Unit test for function eager
def test_eager():
    print("Testing function eager")
    import random as r
    def function(x):
        for i in range(x):
            yield r.random()

    result = eager(function)
    a = result(5)
    assert(len(a) == 5)
    for i in range(5):
        assert(type(a[i]) == float)
    assert(a[0] != a[1] != a[2] != a[3] != a[4])
    print("Passed!")

# Generated at 2022-06-22 15:08:25.617198
# Unit test for function get_source
def test_get_source():
    def sample_func():
        pass

    assert get_source(sample_func) == 'def sample_func():\n    pass'

    def sample_func():
        for i in range(10):
            pass

    sample_func = get_source(sample_func)
    assert sample_func == 'def sample_func():\n    for i in range(10):\n        pass'