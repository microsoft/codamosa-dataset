

# Generated at 2022-06-22 14:58:37.561726
# Unit test for function get_source
def test_get_source():
    # Function with arguments
    def my_function(a, b):
        '''Function with arguments
        and multiline docstring.
        '''
        pass

    source = """def my_function(a, b):
    '''Function with arguments
    and multiline docstring.
    '''
    pass"""

    assert get_source(my_function) == source



# Generated at 2022-06-22 14:58:40.469789
# Unit test for function debug
def test_debug():
    settings.debug = True
    message = 'This is a test message.'

    try:
        debug(lambda: message)
        assert sys.stderr.getvalue().strip() == message
    finally:
        settings.debug = False

# Generated at 2022-06-22 14:58:43.669293
# Unit test for function debug
def test_debug():
    debug(lambda: '123')
    settings.debug = False
    debug(lambda: '123')





# Generated at 2022-06-22 14:58:48.781563
# Unit test for function get_source
def test_get_source():
    @lru_cache(maxsize=1000)
    @variant
    def fib(n: int) -> int:
        if n == 0:
            return 1
        return n * fib(n - 1)  # noqa

    assert get_source(fib) == 'if n == 0:\n    return 1\nreturn n * fib(n - 1)'  # noqa: E501

# Generated at 2022-06-22 14:58:52.127004
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        print(a)
        print(b)
        return 0

    assert get_source(foo) == 'print(a)\nprint(b)\nreturn 0'

# Generated at 2022-06-22 14:58:58.083139
# Unit test for function debug
def test_debug():
    from .mocks import MockPrinter
    printer = MockPrinter()
    old_stdout = sys.stdout
    old_debug = settings.debug
    sys.stdout = printer
    try:
        settings.debug = True
        debug(lambda: 'hello')
        assert printer.last == 'hello\n'
        printer.last = None
        settings.debug = False
        debug(lambda: 'world')
        assert printer.last is None
    finally:
        sys.stdout = old_stdout
        settings.debug = old_debug

# Generated at 2022-06-22 14:59:00.466661
# Unit test for function eager
def test_eager():
    @eager
    def function():
        return range(5)

    assert function() == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 14:59:05.756425
# Unit test for function debug
def test_debug():
    # pylint: disable=unused-variable
    from unittest.mock import MagicMock

    sys.stderr = MagicMock()
    settings.debug = True

    debug(lambda: 'some debug message')
    sys.stderr.write.assert_called_once_with(messages.debug('some debug message') + '\n')

    settings.debug = False
    # pylint: enable=unused-variable



# Generated at 2022-06-22 14:59:10.534242
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'foo')
    assert sys.stderr.getvalue() == ''

    settings.debug = True
    debug(lambda: 'bar')
    assert sys.stderr.getvalue() == messages.debug('bar') + '\n'

# Generated at 2022-06-22 14:59:15.851680
# Unit test for function get_source
def test_get_source():
    # assert it works on self-defined functions
    def foo():
        pass

    assert get_source(foo) == "def foo():\n    pass"
    # assert it works on functions defined by pytest
    def foo():
        assert 1 == 1

    assert get_source(foo) == "def foo():\n    assert 1 == 1"

# Generated at 2022-06-22 14:59:23.100774
# Unit test for function debug
def test_debug():
    def generate_message():
        return "hello"
    expected = messages.debug(generate_message())
    with patch('sys.stderr', new=StringIO()) as fake_err:
        ret = debug(generate_message)
        assert ret is None
        assert fake_err.getvalue() == expected



# Generated at 2022-06-22 14:59:26.584273
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'pass'

    def fn():
        a = 1

    assert get_source(fn) == 'a = 1'
    assert get_source(lambda: None) == 'pass'

# Generated at 2022-06-22 14:59:28.342370
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'bar'

    assert get_source(foo) == 'return \'bar\''

# Generated at 2022-06-22 14:59:33.326993
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        lines = []
        def save_line(msg):
            lines.append(msg)
        def get_message():
            return 'message'
        sys.stderr.write = save_line
        debug(get_message)
        assert len(lines) == 1
        assert lines[0] == 'message\n'
    finally:
        settings.debug = False

# Generated at 2022-06-22 14:59:34.771548
# Unit test for function get_source
def test_get_source():
    def test_function():
        return 1

    assert get_source(test_function) == 'return 1'

# Generated at 2022-06-22 14:59:37.476131
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            pass

    assert get_source(f) == 'def g():\n    pass'

# Generated at 2022-06-22 14:59:43.144368
# Unit test for function eager
def test_eager():
    def fn_eager(i: int) -> Iterable[int]:
        for i in range(i):
            yield i
    
    def fn_eager_1(i: int) -> Iterable[int]:
        for i in range(i):
            yield i
    
    assert fn_eager(2) == eager(fn_eager_1)(2)


# Generated at 2022-06-22 14:59:45.075983
# Unit test for function eager
def test_eager():
    assert eager(range)(1, 2) == [1]
    assert eager(range)(1, 3) == [1, 2]

# Generated at 2022-06-22 14:59:46.051400
# Unit test for function get_source

# Generated at 2022-06-22 14:59:49.150802
# Unit test for function get_source
def test_get_source():
    code = get_source(lambda a, b, c: a + b + c)
    assert code == 'a + b + c', code

# Generated at 2022-06-22 14:59:55.867238
# Unit test for function get_source
def test_get_source():
    @get_source
    def test_fn(a,b):
        if a==b:
            return a+b
        return a*b
    assert test_fn == """def test_fn(a,b):
    if a==b:
        return a+b
    return a*b"""

# Generated at 2022-06-22 15:00:01.642620
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def wrapper():
        def foo():
            pass

    def foo(a, b):
        pass

    def foo2(a, b=None):
        pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(wrapper) == 'def foo():\n    pass'
    assert get_source(foo) == 'def foo(a, b):\n    pass'
    assert get_source(foo2) == 'def foo2(a, b=None):\n    pass'

# Generated at 2022-06-22 15:00:02.681847
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello, Debug!')

# Generated at 2022-06-22 15:00:13.431894
# Unit test for function get_source
def test_get_source():
    import unittest

    class TestGetSource(unittest.TestCase):

        def test_get_source(self):
            def fn():
                pass

            self.assertEqual(get_source(fn), 'def fn():\n    pass')

        def test_get_source_with_comments(self):
            def fn():
                '''
                Function docstring
                '''
                pass

            self.assertEqual(get_source(fn), 'def fn():\n    pass')

        def test_get_source_with_multiple_lines(self):
            def fn():
                a = 1
                b = 2

            self.assertEqual(get_source(fn), 'def fn():\n    a = 1\n    b = 2')

    unittest.main()



# Generated at 2022-06-22 15:00:17.910439
# Unit test for function debug
def test_debug():
    # Test debug message
    debug_message = 'debug message'

    # Test with debug mode enabled
    settings.debug = True
    debug(lambda: debug_message)

    # Test with debug mode disabled
    settings.debug = False
    debug(lambda: debug_message)

# Generated at 2022-06-22 15:00:21.341794
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        if a:
            b += 1
        return b

    source = get_source(fn)

    assert source == """
if a:
    b += 1
return b
""".strip()

# Generated at 2022-06-22 15:00:30.579181
# Unit test for function debug
def test_debug():
    with patch('py_backwards.utils.settings.debug', True), \
            patch('sys.stderr.write') as write:
        debug(lambda: 'message')
        assert_equals(write.call_count, 1)
        assert_equals(write.call_args_list[0][0][0], '\x1b[36mmessage\x1b[0m\n')

    with patch('py_backwards.utils.settings.debug', False), \
            patch('sys.stderr.write') as write:
        debug(lambda: 'message')
        assert_equals(write.call_count, 0)

# Generated at 2022-06-22 15:00:32.054204
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:00:36.815218
# Unit test for function get_source
def test_get_source():
    """Unit test for function get_source."""
    def foo():
        """Function for testing"""
        print(10)
    assert get_source(foo) == "print(10)"

# Generated at 2022-06-22 15:00:39.589033
# Unit test for function debug
def test_debug():
    with settings(debug=False):
        debug(lambda: 'xyz')
    with settings(debug=True):
        debug(lambda: 'xyz')



# Generated at 2022-06-22 15:00:43.963567
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> Iterable[int]:
        yield 1
        yield 2
    assert gen() == [1, 2]



# Generated at 2022-06-22 15:00:46.476169
# Unit test for function eager
def test_eager():
    @eager
    def get_numbers(n: int) -> Iterable[int]:
        for i in range(n):
            yield i
    assert get_numbers(3) == [0, 1, 2]



# Generated at 2022-06-22 15:00:51.318350
# Unit test for function get_source
def test_get_source():
    def fn():
        """Does nothing specific."""
        return 0


# Generated at 2022-06-22 15:00:54.301220
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(foo)(1) == [1, 2, 3]

# Generated at 2022-06-22 15:01:04.066133
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)

# Generated at 2022-06-22 15:01:11.396389
# Unit test for function debug
def test_debug():
    messages.debug = 'DEBUGGING'
    settings.debug = True
    debug_message = 'Hello Debug'

    try:
        sys.stderr = StringIO()
        debug(lambda: debug_message)
        assert sys.stderr.getvalue() == DEBUGGING + ' ' + debug_message + '\n'
    finally:
        sys.stderr = sys.__stderr__
        messages.debug = 'DEBUG'
        settings.debug = False

# Generated at 2022-06-22 15:01:15.473569
# Unit test for function get_source
def test_get_source():
    """Unit test for function get_source."""

    def f():
        # line 1
        # line 2
        # line 3
        pass

    assert get_source(f) == '# line 1\n# line 2\n# line 3\npass'

# Generated at 2022-06-22 15:01:19.313972
# Unit test for function debug
def test_debug():
    s = []
    def get_message():
        s.append("test")
        return ""
    debug(get_message)
    assert len(s) == 1

if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-22 15:01:23.361545
# Unit test for function get_source
def test_get_source():
    def ekta(a, b):
        # ittak
        return a+b

    assert get_source(ekta) == 'def ekta(a, b):'

# Generated at 2022-06-22 15:01:27.261808
# Unit test for function get_source
def test_get_source():
    def func():
        for arg in ['a', 'b', 'c']:
            yield arg

    assert get_source(func) == dedent('''
        for arg in ['a', 'b', 'c']:
            yield arg
    ''')

# Generated at 2022-06-22 15:01:31.793209
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'
    debug(get_message)


# Generated at 2022-06-22 15:01:33.676163
# Unit test for function eager
def test_eager():
    import pytest

    @eager
    def foo():
        yield 1
        yield 2

    assert foo() == [1, 2]


# Generated at 2022-06-22 15:01:35.512060
# Unit test for function eager
def test_eager():
    def fn():
        yield 0

    assert eager(fn)() == [0]



# Generated at 2022-06-22 15:01:42.002116
# Unit test for function debug
def test_debug():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    old_debug = settings.debug
    settings.debug = True
    with captured_output() as (output, error):
        debug(lambda: 'This is debug message')
    settings.debug = False

# Generated at 2022-06-22 15:01:44.466573
# Unit test for function get_source
def test_get_source():
    def function(a, b):
        c = a + b
        return c
    with open(__file__) as f:
        assert get_source(function) in f.read()

# Generated at 2022-06-22 15:01:54.263306
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        """
        some function
        """
        pass

    def baz():
        if 1 == 1:
            print('1')

    expected_source = [
        'def foo():',
        '    pass',
        ''
    ]
    assert get_source(foo) == '\n'.join(expected_source)

    expected_source = [
        'def bar():',
        '    """',
        '    some function',
        '    """',
        '    pass',
        ''
    ]
    assert get_source(bar) == '\n'.join(expected_source)

    expected_source = [
        'def baz():',
        '    if 1 == 1:',
        '        print(\'1\')',
        ''
    ]
   

# Generated at 2022-06-22 15:01:58.727619
# Unit test for function get_source
def test_get_source():
    def tst1(x, y):
        return x + y

    def tst2():
        """
        This is test for testing
        """

    def tst3():
        # Comment
        pass

    assert get_source(tst1) == 'return x + y'
    assert get_source(tst2) == '"""\n        This is test for testing\n        """'
    assert get_source(tst3) == 'pass'



# Generated at 2022-06-22 15:02:04.611718
# Unit test for function get_source
def test_get_source():
    def src(a):
        if a == 5:
            return True
        else:
            return False

    src_ = '''def src(a):
    if a == 5:
        return True
    else:
        return False'''

    assert get_source(src) == src_


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:02:06.040821
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:02:08.923513
# Unit test for function eager
def test_eager():
    @eager
    def iterator() -> Iterable[int]:
        for i in range(3):
            yield i

    assert iterator() == [0, 1, 2]

# Generated at 2022-06-22 15:02:15.886849
# Unit test for function debug
def test_debug():
    with settings(debug=True):
        debug(lambda: 'foo')



# Generated at 2022-06-22 15:02:20.090000
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'should not be printed')
    settings.debug = True
    debug(lambda: 'should be printed')
    settings.debug = False


# Generated at 2022-06-22 15:02:23.824937
# Unit test for function eager
def test_eager():
    with pytest.raises(RuntimeError):
        list(eager(lambda: 1 / 0)())
    assert eager(lambda: range(10))() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:02:26.000497
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-22 15:02:27.466387
# Unit test for function get_source
def test_get_source():
    def foo(): pass
    assert get_source(foo).strip() == 'def foo(): pass'



# Generated at 2022-06-22 15:02:28.906344
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'



# Generated at 2022-06-22 15:02:30.734132
# Unit test for function get_source
def test_get_source():
    assert 'test = 1' == get_source(
        lambda x: x +
        1  # noqa
    )

# Generated at 2022-06-22 15:02:32.893089
# Unit test for function debug
def test_debug():
    messages.debug = lambda msg: messages.green('[DEBUG] {}'.format(msg))
    settings.debug = True
    debug(lambda: 'foo')

# Generated at 2022-06-22 15:02:36.697545
# Unit test for function get_source
def test_get_source():
    def function():
        statement = 'a = 42'
    assert get_source(function).strip() == 'statement = 42'

# Generated at 2022-06-22 15:02:41.068603
# Unit test for function debug
def test_debug():
    settings.debug = True
    messages.debug = lambda msg: msg
    messages.warn = lambda msg: msg
    try:
        debug(lambda: 'warn')
        debug(lambda: 'debug')
        assert False
    except AssertionError:
        pass
    settings.debug = False



# Generated at 2022-06-22 15:02:55.475337
# Unit test for function get_source
def test_get_source():
    """Should return source code of the function."""

    def f():
        """Docstring."""
        return 42

    assert get_source(f) == 'def f():\n    """Docstring."""\n    return 42'

# Generated at 2022-06-22 15:02:58.061447
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-22 15:03:04.985349
# Unit test for function debug
def test_debug():
    settings.set_debug(True)
    debug(lambda: "test")
    with mock.patch('sys.stderr') as mock_stdout:
        debug(lambda: "test")

    mock_stdout.write.assert_called_with("\x1B[1m\x1B[34m[pybackwards]\x1B[0m \x1B[1mtest\x1B[0m\n")
    settings.set_debug(False)

# Generated at 2022-06-22 15:03:12.375065
# Unit test for function get_source
def test_get_source():
    def _test_source(fn, source):
        assert get_source(fn) == source

    def fn():
        pass

    _test_source(fn, 'def fn():\n    pass')

    def fn():
        a = 1
        b = 2

    _test_source(fn, 'def fn():\n    a = 1\n    b = 2')

    def fn():
        a = 1
        b = 2

    _test_source(fn, 'def fn():\n    a = 1\n    b = 2')

# Generated at 2022-06-22 15:03:16.216780
# Unit test for function get_source
def test_get_source():
    def foo():
        print('hello')
    expected = '        print(\'hello\')'
    assert get_source(foo) == expected


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:03:19.130233
# Unit test for function get_source
def test_get_source():
    def foo(bar):
        return bar

    print(get_source(foo))


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:03:21.767321
# Unit test for function get_source
def test_get_source():
    def test(a, b, c=3, *args, d=4, **kwargs):
        """Test function."""
        # Some code here
        pass


# Generated at 2022-06-22 15:03:27.553540
# Unit test for function debug
def test_debug():
    if 'debug' not in sys.modules:
        return None
    debug_module = sys.modules['debug']
    sys.modules['debug'] = lambda x: None
    try:
        settings.debug = True
        messages.debug = lambda x: x
        debug(lambda: 'message')
        settings.debug = False
        debug(lambda: 'supposed to be not printed')
    finally:
        sys.modules['debug'] = debug_module


# Generated at 2022-06-22 15:03:30.269685
# Unit test for function get_source
def test_get_source():
    """Test if function get_source gives correct result."""
    source = """
    def test():
        pass
    """
    assert get_source(test_get_source) == source

# Generated at 2022-06-22 15:03:31.976483
# Unit test for function debug
def test_debug():
    def get_message():
        return 'foo'

    debug(get_message)



# Generated at 2022-06-22 15:04:04.936130
# Unit test for function get_source
def test_get_source():
    def normal_func():
        pass

    def normal_func_with_args(x, y):
        pass

    def normal_func_with_args_and_default_value(x, y=0):
        pass

    def normal_func_with_multiline_docstring(x, y='\n'):
        """Complex multi-

        line
        docstring
        """
        pass

    def normal_func_with_one_line_docstring(x, y='\n'):
        """Simple one line docstring."""
        pass

    def normal_func_with_args_and_default_value_and_many_lines(x,
                                                               y='\n\n',
                                                               z=3):
        """Complex multi-

        line
        docstring
        """
       

# Generated at 2022-06-22 15:04:05.985811
# Unit test for function debug
def test_debug():
    def get_message():
        return "This is a test!"
    debug(get_message)

# Generated at 2022-06-22 15:04:07.501594
# Unit test for function eager
def test_eager():
    @eager
    def f() -> Iterable[int]:
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-22 15:04:11.261233
# Unit test for function debug
def test_debug():
    messages.debug = 'PyBackwards {}'
    with patch('sys.stderr') as stderr:
        debug(lambda: 3)
    stderr.write.assert_called_once_with('PyBackwards 3\n')



# Generated at 2022-06-22 15:04:18.464679
# Unit test for function debug
def test_debug():
    class MockStream:
        def __init__(self):
            self.content = ''
            self.file_object = self

        def __enter__(self):
            return self.file_object

        def __exit__(self, type, value, tb):
            pass

        def write(self, data):
            self.content += data

    settings.debug = True
    stream = MockStream()
    sys.stderr = stream
    debug(lambda: 'Hello!')
    assert 'Hello!' in stream.content

# Generated at 2022-06-22 15:04:20.595480
# Unit test for function get_source
def test_get_source():
    def fn(x: int, y: str = 'hello') -> bool:
        return True

    assert get_source(fn) == 'return True'

# Generated at 2022-06-22 15:04:23.019719
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == \
        'assert get_source(test_get_source) == \\'

# Generated at 2022-06-22 15:04:26.435959
# Unit test for function debug
def test_debug():
    import io
    import sys

    # Setup
    sys.stderr = io.StringIO()
    settings.debug = True

    debug(lambda: 'test message')
    result = sys.stderr.getvalue()

    # Teardown
    del sys.stderr
    settings.debug = False

    assert messages.debug('test message') == result

# Generated at 2022-06-22 15:04:27.989899
# Unit test for function debug
def test_debug():
    if settings.debug:
        assert(debug(lambda: 'test') is None)
    else:
        assert(debug(lambda: 'test') is None)


# Generated at 2022-06-22 15:04:30.137599
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
        pass
    source_code = get_source(foo)
    source_code_expected = '\n'.join([
        'def bar():',
        '    pass',
        'pass'
    ])
    assert source_code == source_code_expected

# Generated at 2022-06-22 15:04:57.534459
# Unit test for function debug
def test_debug():
    L = []
    settings.debug = True
    try:
        def get_message():
            L.append(3)
            return 'foo bar'
        debug(get_message)
        assert L == [3]
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:04:59.761139
# Unit test for function eager
def test_eager():
    def f():
        yield 1
    g = eager(f)
    print(g())

# test_eager()

# Generated at 2022-06-22 15:05:01.898426
# Unit test for function eager
def test_eager():
    def foo():
        yield 'foo'
        yield 'bar'

    assert eager(foo)() == ['foo', 'bar']



# Generated at 2022-06-22 15:05:04.201873
# Unit test for function eager
def test_eager():
    def iter():
        yield from [1, 2, 3]

    assert eager(iter)() == [1, 2, 3]
    assert list(iter()) == [1, 2, 3]

# Generated at 2022-06-22 15:05:09.310238
# Unit test for function debug
def test_debug():
    _message = None

    def get_message():
        return _message

    debug(get_message)
    assert _message is None, 'Should not set message when debug is False'

    settings.debug = True
    debug(get_message)
    assert _message == messages.debug(''), (
        'Should set message to the value returned by get_message when debug is True')

# Generated at 2022-06-22 15:05:12.728615
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == """def test_get_source():
    assert get_source(test_get_source) == get_source.__doc__"""


test_get_source()

# Generated at 2022-06-22 15:05:23.375737
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager
    from ..conf import settings
    from ._test_utils import capture_stdout, assert_stdout

    @contextmanager
    def temp_setting(name: str, value: Any):
        old_value = getattr(settings, name)
        setattr(settings, name, value)
        try:
            yield
        finally:
            setattr(settings, name, old_value)

    @capture_stdout
    def test_debug_enabled(stdout):
        with temp_setting('debug', True):
            debug(lambda: 'foobar')
        assert_stdout(stdout, 'DEBUG: foobar\n')

    @capture_stdout
    def test_debug_disabled(stdout):
        with temp_setting('debug', False):
            debug

# Generated at 2022-06-22 15:05:25.249090
# Unit test for function get_source
def test_get_source():
    def function(a, b):
        c = a + b
        return c

    assert get_source(function) == textwrap.dedent(
        """\
    def function(a, b):
        c = a + b
        return c""")

# Generated at 2022-06-22 15:05:28.313172
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == dedent('''
    def fn():
        pass
    ''')



# Generated at 2022-06-22 15:05:33.567136
# Unit test for function get_source
def test_get_source():
    """Tests get_source().

    To run unit tests for this module:

    $ python -m py_backwards.utils.tests
    """
    def f():
        def inner():
            pass
        pass

    assert get_source(f) == '\n'.join([
        'def inner():',
        '    pass',
        'pass',
    ])

# Generated at 2022-06-22 15:06:39.466169
# Unit test for function get_source
def test_get_source():
    def my_function(a, b, c=1, d=2, e=3, f=4, g=5):
        pass

    func_source = get_source(my_function)
    assert func_source == """def my_function(a, b, c=1, d=2, e=3, f=4, g=5):
    pass""", func_source



# Generated at 2022-06-22 15:06:45.617006
# Unit test for function debug
def test_debug():
    from . import debug, settings

    result = []

    def get_message() -> str:
        return 'message'

    def run():
        settings.debug = True
        debug(get_message)
        settings.debug = False
        debug(get_message)

    try:
        sys.stderr = result
        run()
    finally:
        sys.stderr = sys.__stderr__

    assert len(result) == 1
    assert result[0] == 'DEBUG: message\n'

# Generated at 2022-06-22 15:06:46.778323
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        pass
    assert get_source(foo) == '    pass'

# Generated at 2022-06-22 15:06:47.891144
# Unit test for function get_source
def test_get_source():
    def test() -> str:
        return 'return value'

    assert get_source(test) == 'return "return value"'

# Generated at 2022-06-22 15:06:55.869956
# Unit test for function debug
def test_debug():
    message = 'hello'
    with patch('sys.stderr') as stderr:
        settings.debug = True
        debug(lambda: message)
        assert stderr.write.mock_calls == [call(messages.debug(message) + '\n')]
        assert stderr.flush.mock_calls == [call()]
        assert message == 'hello'

    with patch('sys.stderr') as stderr:
        settings.debug = False
        debug(lambda: message)
        assert stderr.write.mock_calls == []
        assert message == 'hello'

# Generated at 2022-06-22 15:06:59.373037
# Unit test for function debug
def test_debug():
    message = 'hello world'
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        warn(message)
    assert stderr.getvalue().strip() == message

# Generated at 2022-06-22 15:07:03.351619
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar(x):
        """Example function."""
        pass

    assert (get_source(bar) ==
            'def bar(x):\n    """Example function."""\n    pass')

# Generated at 2022-06-22 15:07:05.575519
# Unit test for function debug
def test_debug():
    sys.stderr = sys.stdout

    def debug1():
        debug(lambda: 'some message')

    debug1()
    settings.debug = True
    debug1()
    settings.debug = False
    debug1()



# Generated at 2022-06-22 15:07:07.139966
# Unit test for function eager
def test_eager():
    import operator
    assert eager(map(operator.add, [1, 2, 3], [4, 5]))([]) == [5, 7]

# Generated at 2022-06-22 15:07:08.787468
# Unit test for function get_source
def test_get_source():
    def _test():
        def _test():
            pass

        assert get_source(_test) == 'def _test():\n    pass'

    _test()