

# Generated at 2022-06-22 14:58:31.861086
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'bar'

    assert get_source(foo) == 'def foo():\n    return \'bar\''

# Generated at 2022-06-22 14:58:34.029373
# Unit test for function debug
def test_debug():
    def mocked_print(message: str) -> None:
        assert message == messages.debug("Hello")

    sys.stderr.write = mocked_print
    debug(lambda: "Hello")


# Generated at 2022-06-22 14:58:39.764600
# Unit test for function get_source
def test_get_source():
    def test_fn_1():
        pass

    def test_fn_2():
        print('Example')

    def test_fn_3():
        """Example"""
        return

    assert get_source(test_fn_1) == 'pass'
    assert get_source(test_fn_2) == 'print(\'Example\')'
    assert get_source(test_fn_3) == '"""Example"""\nreturn'

# Generated at 2022-06-22 14:58:49.997479
# Unit test for function debug
def test_debug():
    import io
    import sys

    class Messages:
        debug = 'my debug message'

    class Settings:
        debug = True

    messages.debug = Messages.debug
    settings.debug = Settings.debug
    stream = io.StringIO()
    sys.stderr = stream
    debug(lambda: 'my debug message')
    assert stream.getvalue() == messages.debug_prefix + 'my debug message\n'
    settings.debug = False
    debug(lambda: 'my debug message')
    assert stream.getvalue() == messages.debug_prefix + 'my debug message\n'

# Generated at 2022-06-22 14:58:54.285566
# Unit test for function get_source
def test_get_source():
    def test_fn() -> None:
        pass

    assert get_source(test_fn) == 'def test_fn() -> None:\n    pass'

    def test_fn_2():
        pass

    assert get_source(test_fn_2) == 'def test_fn_2():\n    pass'

# Generated at 2022-06-22 14:58:56.508127
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-22 14:59:03.841891
# Unit test for function get_source
def test_get_source():
    def decorator(func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    def test_function(x, y):
        return x * y

    assert get_source(test_function) == 'test_function(x, y):\n    return x * y\n'
    assert get_source(decorator(test_function)) == 'def wrapper(*args, **kwargs):\n    return func(*args, **kwargs)\n'

# Generated at 2022-06-22 14:59:04.738558
# Unit test for function get_source
def test_get_source():
    def get_two():
        return 2

    assert get_source(get_two) == 'return 2\n'

# Generated at 2022-06-22 14:59:06.467007
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo')
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    assert True



# Generated at 2022-06-22 14:59:11.460264
# Unit test for function get_source
def test_get_source():
    def inner(first_arg: Any, *args: Any, **kwargs: Any) -> Any:
        pass
    assert get_source(inner) == 'def inner(first_arg: Any, *args: Any, **kwargs: Any) -> Any:\n    pass'



# Generated at 2022-06-22 14:59:17.001909
# Unit test for function debug
def test_debug():
    if settings.debug:
        assert_equal(debug(lambda: 'heheh'), None)
    else:
        assert_equal(debug(lambda: 'heheh'), None)

# Generated at 2022-06-22 14:59:18.870151
# Unit test for function debug
def test_debug():
    # pylint: disable=unused-variable
    @backwards
    def fn(a=1):
        debug(lambda: a)
    # pylint: enable=unused-variable

# Generated at 2022-06-22 14:59:20.728107
# Unit test for function get_source
def test_get_source():
    def a():
        pass
    assert get_source(a) == 'def a():\n    pass\n'

# Generated at 2022-06-22 14:59:23.552688
# Unit test for function get_source
def test_get_source():
    def test(x):
        pass
    assert get_source(test) == 'def test(x):\n    pass\n'

# Generated at 2022-06-22 14:59:26.199717
# Unit test for function get_source
def test_get_source():
    def f(a: int) -> None:
        pass

    assert get_source(f) == 'def f(a: int) -> None:\n    pass'

# Generated at 2022-06-22 14:59:32.827823
# Unit test for function debug
def test_debug():
    import io
    import sys

    out = io.StringIO()
    sys.stderr = out

    def get_message():
        return 'message'

    debug(get_message)

    sys.stderr = sys.__stderr__
    assert out.getvalue() != 'message'

    out = io.StringIO()
    sys.stderr = out

    settings.debug = True
    debug(get_message)

    sys.stderr = sys.__stderr__
    assert out.getvalue() == 'message'

# Generated at 2022-06-22 14:59:36.217456
# Unit test for function debug
def test_debug():
    for debug_setting in [False, True]:
        settings.debug = debug_setting
        messages.debug = lambda m: 'smth'
        debug(lambda: '')
        messages.debug = lambda m: 'something'
        debug(lambda: '')

# Generated at 2022-06-22 14:59:40.008857
# Unit test for function get_source
def test_get_source():
    def foo():
        # Some comment
        pass

    assert get_source(foo) == 'def foo():\n    # Some comment\n    pass'

# Generated at 2022-06-22 14:59:41.821853
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-22 14:59:42.880446
# Unit test for function debug
def test_debug():
    debug(lambda: 'some debug')

# Generated at 2022-06-22 14:59:51.798223
# Unit test for function get_source
def test_get_source():
    """Tests function get_source."""
    def foo():
        """Docstring of foo."""
        pass

    assert get_source(foo) == '"""Docstring of foo."""\npass'



# Generated at 2022-06-22 14:59:54.361149
# Unit test for function eager
def test_eager():
    @eager
    def generate():
        yield 1
        yield 2
        yield 3

    assert generate() == [1, 2, 3]



# Generated at 2022-06-22 14:59:56.200171
# Unit test for function get_source
def test_get_source():
    def test(a):
        pass
    assert get_source(test) == 'def test(a):\n    pass'

# Generated at 2022-06-22 14:59:58.016165
# Unit test for function get_source
def test_get_source():
    def f():
        a = 5
        return a

    assert get_source(f) == 'a = 5\nreturn a'

# Generated at 2022-06-22 15:00:03.315910
# Unit test for function debug
def test_debug():
    print("test_debug")

    class Testing():
        def __init__(self):
            self.x = 0

    test = Testing()

    def message():
        test.x += 1
        return str(test.x)

    debug(message)
    assert test.x == 0, "should not execute the message yet"
    settings.debug = True
    debug(message)
    assert test.x == 1, "should execute the message once"
    debug(message)
    assert test.x == 2, "should execute the message twice"

    del message
    del test
    del Testing

# Generated at 2022-06-22 15:00:06.815043
# Unit test for function get_source
def test_get_source():
    def foo(): pass

    assert get_source(foo) == 'def foo(): pass'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:00:08.977634
# Unit test for function eager
def test_eager():
    @eager
    def foo() -> Iterable[int]:
        yield 1
        yield 2

    assert foo() == [1, 2]

# Generated at 2022-06-22 15:00:11.907490
# Unit test for function get_source
def test_get_source():
    def fn(a):
        pass
    expected = 'def fn(a):\n    pass'
    actual = get_source(fn)
    assert actual == expected

# Generated at 2022-06-22 15:00:14.743503
# Unit test for function debug
def test_debug():
    settings.debug = True
    a = 1
    b = 2
    debug(lambda: f'{a} + {b} = {a + b}')
    # Output
    #   \033[36mDEBUG:  1 + 2 = 3\033[0m



# Generated at 2022-06-22 15:00:24.687127
# Unit test for function debug
def test_debug():
    import unittest
    from . import conf

    class TestDebug(unittest.TestCase):
        def setUp(self):
            conf.settings.debug = True

        def test_debug(self):
            from io import StringIO
            debug_message = StringIO()
            with redirect_stderr(debug_message):
                debug(lambda :'debug message')
            debug_message = debug_message.getvalue()
            self.assertTrue('DEBUG' in debug_message)
            self.assertTrue('debug message' in debug_message)

    unittest.main(module='tests.test_tools', exit=False)



# Generated at 2022-06-22 15:00:39.298601
# Unit test for function eager
def test_eager():
    iterable = [1, 2, 3]
    def res_iterable() -> Iterable[int]:
        return iterable

    assert(eager(res_iterable)() == [1, 2, 3])
    assert(eager(res_iterable)() == [1, 2, 3])


# Generated at 2022-06-22 15:00:46.306661
# Unit test for function debug
def test_debug():
    class MockStderr:
        def __init__(self):
            self.args = []

        def write(self, *args, **kwargs):
            self.args.append((args, kwargs))

        def assert_called_once_with(self, message):
            assert self.args == [(('PyBackwards: ' + message + '\n',), {})]

    stderr = MockStderr()
    settings.debug = True
    sys.stderr = stderr

    debug(lambda: 'hello')

    stderr.assert_called_once_with('hello')

# Generated at 2022-06-22 15:00:52.319259
# Unit test for function get_source
def test_get_source():
    class C:
        @classmethod
        def function(cls):
            """Some docstring."""
            pass

    assert get_source(C.function) == (
        'def function(cls):\n'
        '    """Some docstring."""\n'
        '    pass'
    )

# Generated at 2022-06-22 15:00:55.664832
# Unit test for function eager
def test_eager():
    def lazy_range(limit: int) -> Iterable[int]:
        for i in range(limit):
            yield i

    assert eager(lazy_range)(3) == [0, 1, 2]


# Generated at 2022-06-22 15:00:56.959319
# Unit test for function get_source
def test_get_source():
    def foo():
        return 10

    assert get_source(foo) == 'return 10'

# Generated at 2022-06-22 15:00:59.565943
# Unit test for function get_source
def test_get_source():
    def foo():
        """
        This is not a comment...
        """
        # but this is
        return 42


# Generated at 2022-06-22 15:01:00.964083
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False

# Generated at 2022-06-22 15:01:03.457494
# Unit test for function get_source
def test_get_source():
    def test():
        return 1

    assert get_source(test) == 'return 1'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:01:09.056516
# Unit test for function debug
def test_debug():
    import io
    sys.stderr = io.StringIO()
    settings.debug = True
    debug(lambda: 'hello')
    assert sys.stderr.getvalue() == messages.debug('hello') + '\n'
    settings.debug = False
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:01:15.711718
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        debug(lambda: 'No!')
        assert not stderr.writelines.called
    with patch.dict('py_backwards.utils.settings.__dict__', {'debug': True}):
        with patch('sys.stderr') as stderr:
            debug(lambda: 'Something went wrong...')
            assert stderr.writelines.called



# Generated at 2022-06-22 15:01:34.771718
# Unit test for function debug
def test_debug():
    message = 'Hello'
    debug(lambda: message)
    debug(lambda: message)

# Generated at 2022-06-22 15:01:39.311948
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    def test_get_message():
        return 'foo'

    with patch('backwards.code.messages.debug') as mock_messages_debug:
        debug(test_get_message)

        mock_messages_debug.assert_called_once_with(test_get_message())

# Generated at 2022-06-22 15:01:41.394736
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    debug(lambda: 'foo')

# Generated at 2022-06-22 15:01:44.208126
# Unit test for function get_source
def test_get_source():
    def test():
        return 1

    assert get_source(test) == 'return 1'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:01:48.554549
# Unit test for function get_source
def test_get_source():
    import re

    def test():
        """Some docstring"""
        var = 'hello'
        return var

    assert re.sub(r'(\s)', '', get_source(test)) == """def test():
    \"\"\"Some docstring\"\"\"
    var = 'hello'
    return var"""



# Generated at 2022-06-22 15:01:51.411009
# Unit test for function debug
def test_debug():
    class C:
        def __init__(self):
            self.message = 'The message!'

    c = C()
    debug(c.__repr__)

# Generated at 2022-06-22 15:01:54.729553
# Unit test for function get_source
def test_get_source():
    import re
    import inspect
    N = 100
    def foo(var):
        return var
    if not re.match(r'^.*\n' * N, "".join(inspect.getsourcelines(foo)[0])):
        raise ValueError("get_source does not work")

# Generated at 2022-06-22 15:01:57.262853
# Unit test for function get_source
def test_get_source():
    """This function is used in unit tests to test function get_source."""
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-22 15:02:03.506593
# Unit test for function debug
def test_debug():
    number_of_calls = 0

    def get_message():
        nonlocal number_of_calls
        number_of_calls += 1
        return 'message'

    debug(get_message)
    assert number_of_calls == 1

    settings.debug = False
    debug(get_message)
    assert number_of_calls == 1



# Generated at 2022-06-22 15:02:05.382292
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 15:02:48.311794
# Unit test for function get_source
def test_get_source():
    def function1(a, b):
        return a + b
    assert get_source(function1) == "return a + b"

    def function2(a):
        return a

    assert get_source(function2) == "return a"



# Generated at 2022-06-22 15:02:51.496419
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    stripped_source = source.lstrip()
    assert source == stripped_source
    assert stripped_source.startswith('def test_get_source():')



# Generated at 2022-06-22 15:02:53.326911
# Unit test for function get_source
def test_get_source():
    def func():
        return 2

    assert get_source(func) == 'return 2'

# Generated at 2022-06-22 15:02:56.095366
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'before')
    settings.debug = False
    debug(lambda: 'after')
    # Cleanup
    settings.debug = False

# Generated at 2022-06-22 15:03:02.662045
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .. import conf
    conf.settings.debug = True
    try:
        out = StringIO()
        sys.stderr = out
        debug(lambda: 'warning')
        assert out.getvalue() == '\033[101m\033[97mwarning\033[0m\n'
    finally:
        sys.stderr = sys.__stderr__
        conf.settings.debug = False



# Generated at 2022-06-22 15:03:04.528016
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == "def fn():\n    pass"

# Generated at 2022-06-22 15:03:06.449369
# Unit test for function get_source
def test_get_source():
    def source_code_function():
        return 1
    assert get_source(source_code_function) == 'return 1'

# Generated at 2022-06-22 15:03:17.954126
# Unit test for function debug
def test_debug():
    class MockStdErr:
        def __init__(self):
            self.output = []

        def write(self, string):
            self.output.append(string)

    std_err = sys.stderr
    mock_stderr = MockStdErr()
    sys.stderr = mock_stderr
    try:
        settings.debug = True
        debug(lambda: "development")
        assert mock_stderr.output[0] == '\x1b[34m\n    DEVELOPMENT:\x1b[0m development\n'
        mock_stderr.output = []
        settings.debug = False
        debug(lambda: "development")
        assert mock_stderr.output == []
    finally:
        sys.stderr = std_err

# Generated at 2022-06-22 15:03:25.017338
# Unit test for function debug
def test_debug():
    assert not hasattr(sys.stderr, 'old_write')

    debug(lambda: 'hello')
    assert not hasattr(sys.stderr, 'old_write')

    settings.debug = True

    try:
        debug(lambda: 'hello')
        assert hasattr(sys.stderr, 'old_write')
        assert sys.stderr.old_write.read() == messages.debug('hello') + '\n'
    finally:
        settings.debug = False
        assert not hasattr(sys.stderr, 'old_write')

# Generated at 2022-06-22 15:03:28.070090
# Unit test for function get_source
def test_get_source():
    """
    >>> def foo():
    ...     print('bar')
    >>> get_source(foo)
    'def foo():\\n    print(\'bar\')'
    """

# Generated at 2022-06-22 15:05:12.862612
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'bar')
    except AttributeError:
        sys.stderr = sys.__stderr__
        settings.debug = False
        return True
    else:
        sys.stderr = sys.__stderr__
        settings.debug = False
        return False

# Generated at 2022-06-22 15:05:15.702702
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        return a + b
    assert get_source(foo) == 'return a + b'



# Generated at 2022-06-22 15:05:17.757655
# Unit test for function eager
def test_eager():
    @eager
    def get_generator():
        yield 1
    assert get_generator() == [1]



# Generated at 2022-06-22 15:05:24.157666
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        """
        This is a docstring
        """
        pass

    def baz():
        return 1

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    """\n    This is a docstring\n    """\n    pass'
    assert get_source(baz) == 'def baz():\n    return 1'


# Generated at 2022-06-22 15:05:25.200847
# Unit test for function get_source

# Generated at 2022-06-22 15:05:28.872309
# Unit test for function debug
def test_debug():
    # When not in debug mode nothing should happen
    settings.debug = False
    debug(lambda: "Something")

    # When in debug mode something should happen
    settings.debug = True
    debug(lambda: "Something")



# Generated at 2022-06-22 15:05:30.860612
# Unit test for function eager
def test_eager():
    def get_generator():
        return (i for i in list(range(0, 4)))

    assert eager(get_generator)() == [0, 1, 2, 3]

# Generated at 2022-06-22 15:05:34.583069
# Unit test for function debug
def test_debug():
    if settings.debug:
        settings.debug = False
        assert not debug(lambda: 'only visible in debug mode')
        settings.debug = True
        assert debug(lambda: 'should be visible')

# Generated at 2022-06-22 15:05:39.546351
# Unit test for function get_source
def test_get_source():
    def foo():
        bar()

    def bar():
        pass

    expected = 'bar()'
    actual = get_source(foo)
    assert expected == actual

    expected = 'pass'
    actual = get_source(bar)
    assert expected == actual

# Generated at 2022-06-22 15:05:40.220498
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "simple message")
    settings.debug = False
