

# Generated at 2022-06-22 14:58:33.606849
# Unit test for function debug
def test_debug():
    assert debug(None, None, settings.debug) == None

# Generated at 2022-06-22 14:58:34.069568
# Unit test for function get_source

# Generated at 2022-06-22 14:58:37.343935
# Unit test for function get_source
def test_get_source():
    a = 1
    b = 2
    def foo():
        return a + b
    foo.__name__ = "foo"
    assert get_source(foo) == "return a + b"

# Generated at 2022-06-22 14:58:38.461242
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')

# Generated at 2022-06-22 14:58:39.840783
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'

# Generated at 2022-06-22 14:58:45.097028
# Unit test for function eager
def test_eager():
    def fn(a: int, b: int) -> Iterable[str]:
        for i in range(a, b):
            yield str(i)

    assert eager(fn)(1, 3) == ['1', '2']



# Generated at 2022-06-22 14:58:51.030641
# Unit test for function debug
def test_debug():
    import contextlib
    from io import StringIO
    from .conf import set_debug

    captured = None
    with set_debug(debug=True):
        with contextlib.redirect_stderr(StringIO()) as destination:
            debug(lambda: 'test')
            captured = destination.getvalue().rstrip()
    assert captured == messages.debug('test')
test_debug()



# Generated at 2022-06-22 14:58:53.767220
# Unit test for function eager
def test_eager():
    @eager
    def get_range(number):
        yield from range(number)

    assert get_range(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 14:58:54.852531
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        def getter():
            return 'getter'

        debug(getter)
    finally:
        settings.debug = False



# Generated at 2022-06-22 14:58:58.299821
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i
    assert gen(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-22 14:59:09.303573
# Unit test for function debug
def test_debug():
    import io
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self) -> None:
            self.buffer = io.StringIO()
            sys.stderr = self.buffer

        def tearDown(self) -> None:
            sys.stderr = sys.__stderr__

        def test_print(self) -> None:
            try:
                settings.debug = True
                debug(lambda: 'foo')
                self.assertRegex(self.buffer.getvalue(), r'\[DEBUG\].*foo.*')
            finally:
                settings.debug = False



# Generated at 2022-06-22 14:59:10.883326
# Unit test for function eager
def test_eager():
    assert eager(range)(4) == [0, 1, 2, 3]

# Generated at 2022-06-22 14:59:15.421662
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass

    assert get_source(some_function) == 'def some_function():\n    pass'
    assert get_source(get_source) == 'return \'\\n\'.join(line[padding:] for line in source_lines)'

# Generated at 2022-06-22 14:59:18.251403
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    def expected_function_source():
        pass

    assert get_source(test_function) == get_source(expected_function_source)

# Generated at 2022-06-22 14:59:24.576025
# Unit test for function get_source

# Generated at 2022-06-22 14:59:26.392053
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2

    assert eager(f)() == [1, 2]

# Generated at 2022-06-22 14:59:28.533926
# Unit test for function get_source
def test_get_source():
    def f():
        """Hooray for function literals."""
        pass

    print("%s" % get_source(f))

# Generated at 2022-06-22 14:59:35.028651
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == """def test_get_source():
    assert get_source(test_get_source) == \"\"\"def test_get_source():
    assert get_source(test_get_source) == \\\"\\\"\\\"def test_get_source():
    assert get_source(test_get_source) == \\\\\\\"\\\\\\\"\\\\\\\"def test_get_source():
    assert get_source(test_get_source) == \\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\"\"\"
"""

# Generated at 2022-06-22 14:59:42.575627
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar(a, b, *args, c: int = 0, d: str = 'abc', **kwargs):
        pass

    assert get_source(bar) == 'def bar(a, b, *args, c: int = 0, d: str = \'abc\', **kwargs):\n    pass'


# Unit tests for function generate

# Generated at 2022-06-22 14:59:43.948331
# Unit test for function get_source
def test_get_source():
    def func():
        return 42

    assert get_source(func) == 'return 42'

# Generated at 2022-06-22 14:59:58.661344
# Unit test for function debug
def test_debug():
    """Check that debug messages are hidden if settings.debug is False."""

    class FakeStdErr:
        def __init__(self):
            self.written_message = ""

        def write(self, message):
            self.written_message = message

    std_err = sys.stderr
    sys.stderr = FakeStdErr()
    try:
        # Turn on debugging
        settings.debug = True
        debug(lambda: "xxx")
        assert sys.stderr.written_message == messages.debug("xxx"), "debug should write with debug message"

        # Hide debugging
        settings.debug = False
        debug(lambda: "xxx")
        assert sys.stderr.written_message == "", "debug should not write with debug message"
    finally:
        sys.stderr = std_err

# Generated at 2022-06-22 15:00:02.342477
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '"""Unit test for function get_source"""\n' + \
                                          'assert get_source(test_get_source) == \'\'\'"""Unit test for function get_source"""\\n\' + \\\n' + \
                                          '    \'    """Unit test for function get_source"""\'\n'

# Generated at 2022-06-22 15:00:06.579024
# Unit test for function get_source
def test_get_source():
    def func():
        '''
        Hi
        Bye
        '''
        pass


    assert get_source(func) == '''
'''

# Generated at 2022-06-22 15:00:08.732807
# Unit test for function get_source
def test_get_source():
    # No need to test this function more deeply, because it is partly tested by unittest of function module
    assert get_source(get_source)



# Generated at 2022-06-22 15:00:14.187592
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.stderr', new=StringIO()) as fake_err, \
         patch('py_backwards.utils.settings.debug', new=True):
        debug(lambda: "my debug message")
        assert fake_err.getvalue() == "\x1b[1;30mmy debug message\x1b[0m\n"



# Generated at 2022-06-22 15:00:17.477188
# Unit test for function get_source
def test_get_source():
    def source():
        """
        This function is used only for tests.
        """
        return True


# Generated at 2022-06-22 15:00:18.907786
# Unit test for function debug
def test_debug():
    for i in range(10):
        debug(lambda: i)



# Generated at 2022-06-22 15:00:21.168415
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
    assert foo() == [1, 2]


# Generated at 2022-06-22 15:00:27.230839
# Unit test for function eager
def test_eager():
    x = 0

    @eager
    def f(i: int) -> Iterable[int]:
        nonlocal x
        x += 1
        return range(i)


    assert f(3) == [0, 1, 2]
    assert x == 1

    assert f(3) == [0, 1, 2]
    assert x == 2



# Generated at 2022-06-22 15:00:29.414679
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Unit test')
    settings.debug = False

# Generated at 2022-06-22 15:00:36.510315
# Unit test for function eager
def test_eager():
    fn = eager(range)
    assert type(fn(1)) == list

# Generated at 2022-06-22 15:00:38.474796
# Unit test for function get_source
def test_get_source():
    def myfnc(): return 'something good'

    assert get_source(myfnc) == 'return "something good"'

# Generated at 2022-06-22 15:00:40.641501
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello World')
    settings.debug = False
    debug(lambda: 'Hello World')

# Generated at 2022-06-22 15:00:43.024587
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-22 15:00:44.636777
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in [1,2,3]))() == [1,2,3]

# Generated at 2022-06-22 15:00:48.036553
# Unit test for function get_source
def test_get_source():
    @wraps(get_source)
    def test_function() -> None:
        pass

    assert get_source(test_function) == "def test_function():\n    pass\n"

# Generated at 2022-06-22 15:00:54.348406
# Unit test for function get_source
def test_get_source():
    def test_source_1(a):
        return a + 1

    def test_source_2():
        a = 10
        return a + 1

    assert get_source(test_source_1) == 'return a + 1'
    assert get_source(test_source_2) == 'a = 10\nreturn a + 1'

# Generated at 2022-06-22 15:00:55.949833
# Unit test for function get_source
def test_get_source():
    def source_test():
        return 'test'

    assert get_source(source_test) == 'return \'test\''

# Generated at 2022-06-22 15:01:00.874536
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    out = StringIO()
    sys.stderr = out

    settings.debug = False
    debug(lambda: 'a')
    assert out.getvalue() == ''

    settings.debug = True
    debug(lambda: 'b')
    settings.debug = False
    assert out.getvalue().strip() == messages.debug('b')

# Generated at 2022-06-22 15:01:03.035775
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    def g():
        pass

    assert get_source(f) == get_source(g)

# Generated at 2022-06-22 15:01:14.935597
# Unit test for function eager
def test_eager():
    def f():
        yield '123'

    def test():
        assert eager(f)() == list(f())

    test()

# Generated at 2022-06-22 15:01:20.162176
# Unit test for function get_source
def test_get_source():
    def example(arg1: str, arg2: str) -> str:
        """Test function.

        Args:
            arg1: first argument
            arg2: second argument

        Returns:
            Concatenation of `arg1` and `arg2`
        """
        return arg1 + arg2


# Generated at 2022-06-22 15:01:22.105515
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1

    assert get_source(test) == 'a = 1'

# Generated at 2022-06-22 15:01:33.350739
# Unit test for function get_source
def test_get_source():
    def monkey():
        """My docstring"""
        return

    def monkey_with_args(*args, **kwargs):
        """My docstring"""
        return

    def monkey_with_kwargs(**kwargs):
        """My docstring"""
        return

    def monkey_with_kwonly(*args, kwonly=None):
        """My docstring"""
        return

    def monkey_with_kwonly2(kwonly=None):
        """My docstring"""
        return

    def monkey_with_kwonly3(kwonly=None, *args, **kwargs):
        """My docstring"""
        return

    def monkey_with_kwonly4(kwonly=None, *args):
        """My docstring"""
        return


# Generated at 2022-06-22 15:01:35.194024
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-22 15:01:36.453376
# Unit test for function eager
def test_eager():
    def test_function():
        yield 2
        return 4
    assert eager(test_function)() == [2]


# Generated at 2022-06-22 15:01:44.953201
# Unit test for function debug
def test_debug():
    try:
        import unittest.mock as mock
        
        with mock.patch.object(sys.stderr, 'write') as mocked_write:
            debug(lambda: "hello")

            # Checks if the function tries to write 
            # with console colors to the stderr
            mocked_write.assert_called_once_with(
                messages.debug("hello") + "\n"
            )
    # If the patching process failed, it means that 
    # the `mock` library hasn't been installed yet
    except ImportError:
        pass

# Generated at 2022-06-22 15:01:50.047093
# Unit test for function eager
def test_eager():
    @eager
    def fibonacci_gen(max: int) -> Iterable[int]:
        a, b = 0, 1
        while a < max:
            yield a
            a, b = b, a + b
    
    assert fibonacci_gen(4) == [0, 1, 1, 2, 3]
    @eager
    def no_input_gen_fib() -> Iterable[int]:
        a, b = 0, 1
        while a < 10:
            yield a
            a, b = b, a + b
    assert no_input_gen_fib() == [0, 1, 1, 2, 3, 5, 8]

# Generated at 2022-06-22 15:01:52.829295
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
        pass
    
    result = get_source(fn)
    expected = 'def fn():\n    pass\n    pass'

    assert result == expected

# Generated at 2022-06-22 15:01:58.423324
# Unit test for function debug
def test_debug():
    class Test(object):
        def __init__(self):
            self.messages = []
        def __call__(self, message):
            self.messages.append(message)

    t = Test()
    print_ = print
    print = t
    try:
        for debug_settings in [True, False]:
            t.messages = []
            settings.debug = debug_settings
            debug(lambda: 'message')
            assert t.messages == (['message'] if debug_settings else [])
    finally:
        print = print_
test_debug()

# Generated at 2022-06-22 15:02:09.979208
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]
    assert eager(lambda xs: xs)(l) == l
    assert eager(lambda: l)() == l

# Generated at 2022-06-22 15:02:11.768389
# Unit test for function debug
def test_debug():
    from .system import reset_settings
    from .system import get_stdout_from_call
    reset_settings()

    try:
        settings.debug = False
        get_stdout_from_call(debug, lambda: 'foo')
        settings.debug = True
        assert get_stdout_from_call(debug, lambda: 'foo') == 'foo'
    finally:
        reset_settings()

# Generated at 2022-06-22 15:02:13.894083
# Unit test for function eager
def test_eager():
    # Unit tests for function eager
    assert eager(lambda: (i + 1 for i in range(3)))() == [1, 2, 3]

# Generated at 2022-06-22 15:02:20.003701
# Unit test for function eager
def test_eager():
    @eager
    def get_list():
        for item in range(10):
            yield item


    assert isinstance(get_list(), list)
    assert get_list() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:02:23.099002
# Unit test for function eager
def test_eager():
    @eager
    def genRange(n: int) -> Iterable[int]:
        while n >= 0:
            yield n
            n -= 1

    assert genRange(3) == [3, 2, 1, 0]

# Generated at 2022-06-22 15:02:26.882405
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'pass'

    def fn():
        def inner_fn():
            pass

    assert get_source(fn) == '\tdef inner_fn():\n\t\tpass'



# Generated at 2022-06-22 15:02:29.886374
# Unit test for function get_source
def test_get_source():
    from inspect import getsource
    from py_backwards.utils import get_source

    def foo_func(arg1, arg2):
        pass
    assert get_source(foo_func) == getsource(foo_func)



# Generated at 2022-06-22 15:02:32.337125
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1

    def bar():
        return 2

    assert get_source(foo) == 'return 1'
    assert get_source(bar) == 'return 2'

# Generated at 2022-06-22 15:02:39.183480
# Unit test for function debug
def test_debug():
    def dummy_get_message():
        return 'hello!'

    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(dummy_get_message)
    assert 'hello!' in fake_stderr.getvalue()

# Generated at 2022-06-22 15:02:43.358299
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from io import StringIO
    tmp_stderr = sys.stderr
    sys.stderr = StringIO()
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    debug(lambda: 'foo')
    sys.stderr = tmp_stderr

# Generated at 2022-06-22 15:03:07.523599
# Unit test for function get_source
def test_get_source():
    def foo() -> str:
        return 'bar'

    assert get_source(foo) == 'return \'bar\''



# Generated at 2022-06-22 15:03:10.767443
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    def func2():
        def func3():
            pass

    assert get_source(func) == 'pass'
    assert get_source(func2) == 'def func3():\n    pass'

# Generated at 2022-06-22 15:03:13.288167
# Unit test for function debug
def test_debug():
    def test_get_message(prefix: str) -> str:
        return prefix + 'test message'
    debug(lambda: test_get_message('prefix:'))

# Generated at 2022-06-22 15:03:19.759293
# Unit test for function get_source
def test_get_source():
    def test_function():
        """
        This is a test for function get_source.
        The functon should return source
        code of the function.
        """
    assert get_source(test_function) == """def test_function():
    """

# Generated at 2022-06-22 15:03:20.947998
# Unit test for function get_source
def test_get_source():
    def func():
        pass

# Generated at 2022-06-22 15:03:23.015000
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-22 15:03:26.455071
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            return 2
        return 1

    assert get_source(foo) == 'def bar():\n' +\
        '    return 2\n' +\
        'return 1'


# Generated at 2022-06-22 15:03:28.447369
# Unit test for function get_source
def test_get_source():
    def example():
        pass

    assert 'example():\n    pass' == get_source(example)

# Generated at 2022-06-22 15:03:30.066790
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

# Generated at 2022-06-22 15:03:37.306302
# Unit test for function debug
def test_debug():
    import io
    import sys
    from unittest.mock import patch

    from ..conf import settings

    settings.debug = True

    assert debug(lambda: 'message') is None
    assert sys.stderr.write.call_count == 0

    stderr = io.StringIO()
    with patch.object(sys, 'stderr', stderr):
        assert debug(lambda: 'message') is None
        assert stderr.getvalue() == '\x1b[2mmessage\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-22 15:04:31.486509
# Unit test for function get_source
def test_get_source():
    def f():
        a = 1  # noqa
    # noqa because of code formatter
    assert get_source(f) == '\ndef f():\n    a = 1\n'

# Generated at 2022-06-22 15:04:34.255959
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-22 15:04:39.186641
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        if a == b:
            return 0
        else:
            return 1

    assert get_source(foo) == 'if a == b:\n'\
                              '    return 0\n'\
                              'else:\n'\
                              '    return 1'

# Generated at 2022-06-22 15:04:41.196386
# Unit test for function eager
def test_eager():
    @eager
    def g():
        yield 1
        yield 2

    assert g() == [1, 2]

# Generated at 2022-06-22 15:04:46.327420
# Unit test for function debug
def test_debug():
    message = 'message'
    with patch.object(settings, 'debug', True):
        with patch.object(messages, 'debug') as debug_message:
            debug(lambda: message)
            debug_message.assert_called_once_with(message)

    with patch.object(settings, 'debug', False):
        with patch.object(messages, 'debug') as debug_message:
            debug(lambda: message)
            debug_message.assert_not_called()



# Generated at 2022-06-22 15:04:48.340314
# Unit test for function get_source
def test_get_source():
    def f(a):
        ...
    source = get_source(f)
    assert source == "def f(a):\n    ...\n"

# Generated at 2022-06-22 15:04:51.062600
# Unit test for function eager
def test_eager():
    def func():
        yield 1
        yield 2
    assert eager(func)() == [1, 2]


# Generated at 2022-06-22 15:04:54.124790
# Unit test for function get_source
def test_get_source():
    def test():
        """Returns 1."""
        a = 1
        return a

    assert get_source(test) == '"""Returns 1."""\na = 1\nreturn a'

# Generated at 2022-06-22 15:05:02.915495
# Unit test for function debug
def test_debug():
    debug_messages = []
    def test_get_message():
        debug_messages.append("Something")
        return "Some message"

    # Should not print anything
    debug(test_get_message)
    assert not debug_messages
    assert not sys.stderr.getvalue()

    # Should print message
    settings.debug = True
    debug(test_get_message)
    assert debug_messages[0] == "Something"
    assert sys.stderr.getvalue() == messages.debug("Some message") + "\n"

    # Reset
    sys.stderr = sys.__stderr__ # type: ignore
    settings.debug = False



# Generated at 2022-06-22 15:05:05.849985
# Unit test for function eager
def test_eager():
    from itertools import count

    def gen() -> Iterable[int]:
        for i in count():
            yield i

    assert eager(gen)() == []
    assert eager(gen)() == []



# Generated at 2022-06-22 15:07:10.521280
# Unit test for function debug
def test_debug():
    settings.debug = False
    assert debug(lambda: 'x') is None
    settings.debug = True
    assert debug.__doc__ is None
    assert debug.__annotations__ == {}
    assert debug.__wrapped__ is None
    assert debug.__name__ == 'debug'
    assert debug.__qualname__ == 'test_debug.<locals>.debug'

# Generated at 2022-06-22 15:07:14.151132
# Unit test for function get_source
def test_get_source():
    def func():
        """
        Multiline
        docstring
        """
        pass

    source = ('"""\n'
              '        Multiline\n'
              '        docstring\n'
              '        """\n'
              '        pass')

    assert get_source(func) == source

# Generated at 2022-06-22 15:07:18.188518
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()
    settings.debug = True
    debug(lambda: '1')
    assert sys.stderr.getvalue() == '1\n'
    settings.debug = False
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:07:24.052819
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'hello')
    assert sys.stderr.getvalue() == '\x1b[33m[debug] hello\x1b[0m\n'
    sys.stderr.truncate(0)
    settings.debug = False
    debug(lambda: 'hello')
    assert sys.stderr.getvalue() == ''


# Generated at 2022-06-22 15:07:26.913278
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-22 15:07:28.730647
# Unit test for function get_source
def test_get_source():
    def dummy():
        pass

    assert get_source(dummy) == "def dummy():\n    pass"

# Generated at 2022-06-22 15:07:38.632630
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    buf = StringIO()

    def capture(stream):
        return stream.getvalue().strip()

    with settings.use(angular=True, debug=True):
        saved = sys.stderr
        sys.stderr = buf
        try:
            debug(lambda: 'Hello world!')
            assert capture(buf) == 'py-backwards debug: Hello world!'
        finally:
            sys.stderr = saved

    with settings.use(angular=True, debug=False):
        saved = sys.stderr
        sys.stderr = buf
        try:
            debug(lambda: 'Hello world!')
            assert capture(buf) == ''
        finally:
            sys.stderr = saved

# Generated at 2022-06-22 15:07:40.398442
# Unit test for function eager
def test_eager():
    @eager
    def testing(x):
        for i in range(x):
            yield i

    assert testing(3) == [0, 1, 2]


# Generated at 2022-06-22 15:07:43.897753
# Unit test for function eager
def test_eager():
    def inc(list):
        return [i+1 for i in list]

    print(inc)
    print(eager(inc))

# Generated at 2022-06-22 15:07:49.546150
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'message1')
    assert sys.stderr.getvalue() == ''
    settings.debug = True
    sys.stderr = StringIO()
    debug(lambda: 'message2')
    assert sys.stderr.getvalue() == messages.debug('message2') + '\n'

