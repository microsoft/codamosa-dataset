

# Generated at 2022-06-22 14:58:37.561685
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2

    assert eager(foo)() == [1, 2]

# Generated at 2022-06-22 14:58:44.531122
# Unit test for function get_source
def test_get_source():
    from tempfile import NamedTemporaryFile
    from os import remove, close
    from .conf import settings
    from .. import messages
    from . import VariablesGenerator

    def fn():
        a = 1
        b = 2
        return a + b

    try:
        settings.debug = True
        file = NamedTemporaryFile()
        with open(file.name, 'w') as f:
            f.write(get_source(fn))
        file.flush()
        name = VariablesGenerator.generate('a')
        with open(file.name) as f:
            assert f.read() == """\
a = 1
b = 2
return a + b
""".format(name)
    finally:
        close(file.fileno())
        remove(file.name)
        del settings.debug


#

# Generated at 2022-06-22 14:58:46.713948
# Unit test for function debug
def test_debug():
    if settings.debug:
        print(messages.debug('test_debug() finished'), file=sys.stderr)



# Generated at 2022-06-22 14:58:56.234667
# Unit test for function debug
def test_debug():
    import io
    import sys
    import contextlib

    def call_debug():
        debug(lambda: 'Success')

    with contextlib.redirect_stderr(io.StringIO()) as stderr:
        with contextlib.redirect_stdout(io.StringIO()) as stdout:
            call_debug()
            assert stderr.getvalue() == ''

    settings.debug = True
    with contextlib.redirect_stderr(io.StringIO()) as stderr:
        with contextlib.redirect_stdout(io.StringIO()) as stdout:
            call_debug()
            assert stderr.getvalue() == '\x1b[34mDEBUG: Success\x1b[0m\n'



# Generated at 2022-06-22 14:58:58.958600
# Unit test for function get_source
def test_get_source():
    def fn():
        return 1

    assert get_source(fn) == 'return 1'



# Generated at 2022-06-22 14:59:02.083472
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i
    assert gen.__name__ == 'gen'
    assert gen(3) == [0, 1, 2]

# Generated at 2022-06-22 14:59:03.145213
# Unit test for function get_source
def test_get_source():
    def some_function():
        a = 1
        b = 2

    assert get_source(some_function) == 'a = 1\nb = 2'

# Generated at 2022-06-22 14:59:07.590995
# Unit test for function debug
def test_debug():
    # This ensures that debug won't print anything unless debug=True
    with patch('py_backwards.utils._internal.settings', debug=False):
        with patch('py_backwards.utils._internal.print'):
            debug(lambda: '200')
            assert print.call_args_list == []

    with patch('py_backwards.utils._internal.settings', debug=True):
        # This should print a warning
        with patch('py_backwards.utils._internal.print') as mocked_print:
            debug(lambda: '100')

        # Test if something was printed and it's a warning
        assert mocked_print.call_args_list
        message = mocked_print.call_args_list[0][0][0]
        assert message.startswith('\x1b[37m')
        assert message.endsw

# Generated at 2022-06-22 14:59:10.067296
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass
    assert get_source(some_function) == 'def some_function():\n    pass'

# Generated at 2022-06-22 14:59:15.470998
# Unit test for function get_source
def test_get_source():
    @wraps(get_source)
    def foo() -> str:
        return "frob"

    @wraps(get_source)
    def bar() -> str:
        return "baz"

    assert get_source(foo) == "    return 'frob'"
    assert get_source(bar) == "    return 'baz'"

# Generated at 2022-06-22 14:59:20.195191
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        """Function for test."""
        return a + b

    assert get_source(func) == 'def func(a, b):\n    """Function for test."""\n    return a + b'

# Generated at 2022-06-22 14:59:22.128754
# Unit test for function debug
def test_debug():
    debug(lambda: "test")

# Generated at 2022-06-22 14:59:26.533711
# Unit test for function debug
def test_debug():
    class GetMessage:
        def __init__(self) -> None:
            self.message = 'foo'

        def __call__(self):
            return self.message
    gm = GetMessage() # type: ignore
    debug(gm)
    assert gm.message == 'foo'


# Generated at 2022-06-22 14:59:34.695273
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    expected_source = 'def f():\n' \
                      '    pass'
    assert get_source(f) == expected_source

    def g(a: bool,  # noqa: F821
          b: str,  # noqa: F821
          c: int) -> None:  # noqa: F821, F723
        pass  # noqa: F821, F841
    expected_source = 'def g(a: bool,\n' \
                      '    b: str,\n' \
                      '    c: int) -> None:\n' \
                      '    pass'
    assert get_source(g) == expected_source

# Generated at 2022-06-22 14:59:37.429774
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'



# Generated at 2022-06-22 14:59:41.173262
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Output')
        assert False, 'Exception was not raised'
    except RuntimeError:
        pass
    assert True, 'All is ok'

# Generated at 2022-06-22 14:59:43.494946
# Unit test for function get_source
def test_get_source():
    def my_function():
        pass

    assert get_source(my_function) == 'def my_function():\n    pass\n'

# Generated at 2022-06-22 14:59:45.654999
# Unit test for function get_source
def test_get_source():
    def fn(x: int) -> int:
        """Adds 10 to x."""
        return x + 10

    assert get_source(fn) == 'return x + 10'

# Generated at 2022-06-22 14:59:46.422590
# Unit test for function eager
def test_eager():
    print(eager(range))

# Generated at 2022-06-22 14:59:53.968764
# Unit test for function debug
def test_debug():
    """Test for debug function."""
    import pytest
    from unittest.mock import Mock
    from io import StringIO
    import sys

    debug_message = 'Debug message'
    get_message = Mock(return_value=debug_message)

    with pytest.raises(SystemExit):
        with StringIO() as fake_stderr:
            sys.stderr = fake_stderr
            debug(get_message)



# Generated at 2022-06-22 15:00:00.996687
# Unit test for function debug
def test_debug():
    from unittest.mock import patch, call

    with patch('sys.stderr') as mock_stderr:
        with settings(debug=True):
            debug(lambda: 'test')
            assert mock_stderr.mock_calls == [call.write('\x1b[34mDEBUG: test\x1b[0m\n')]
        with settings(debug=False):
            debug(lambda: 'test')
            assert mock_stderr.mock_calls == []

# Generated at 2022-06-22 15:00:02.583312
# Unit test for function get_source
def test_get_source():
    def test_function():
        return 1

    assert get_source(test_function) == '    return 1'



# Generated at 2022-06-22 15:00:05.419881
# Unit test for function get_source
def test_get_source():
    def add(x, y):
        return x + y

    source = get_source(add)

    assert source == 'return x + y'

# Generated at 2022-06-22 15:00:09.221317
# Unit test for function get_source
def test_get_source():
    def foo():
        """Docstring
        """
        def bar():
            return 1
        return bar()

    assert get_source(foo) == 'def bar():\n' \
                              '    return 1\n' \
                              'return bar()'

# Generated at 2022-06-22 15:00:11.692733
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-22 15:00:15.450436
# Unit test for function debug
def test_debug():
    from . import helpers
    from . import messages

    test_output = []

    def debug(msg: str) -> None:
        test_output.append(msg)

    messages.debug = debug
    helpers.debug(lambda: 'Just a simple test')

    assert test_output[0].startswith(
        '\x1b[33mJust a simple test\x1b[0m')  # Color should be yellow

# Generated at 2022-06-22 15:00:24.886858
# Unit test for function debug
def test_debug():
    # Test for normal case
    stdout_org = sys.stdout
    sys.stdout = StringIO()
    debug(lambda: 'Debug message')
    assert sys.stdout.getvalue() == messages.debug('Debug message')
    sys.stdout = stdout_org

    # Test for debug=False
    settings.debug = False
    stdout_org = sys.stdout
    sys.stdout = StringIO()
    debug(lambda: 'Debug message')
    assert sys.stdout.getvalue() == ''
    sys.stdout = stdout_org
    settings.debug = True



# Generated at 2022-06-22 15:00:27.941265
# Unit test for function eager
def test_eager():
    # test function has to be defined in global scope
    from . import variables

    @eager
    def non_eager(x: int) -> Iterable[int]:
        yield x

    @eager
    def eager(x: int) -> Iterable[int]:
        yield x

    assert non_eager(1) == [1]
    assert eager(1) == [1]



# Generated at 2022-06-22 15:00:29.576957
# Unit test for function get_source
def test_get_source():
    def func():
        return 1
    assert get_source(func) == 'return 1'

# Generated at 2022-06-22 15:00:36.240102
# Unit test for function debug
def test_debug():
    import unittest.mock
    with unittest.mock.patch.object(settings, 'debug', True) as mocked:
        with unittest.mock.patch('sys.stderr') as mocked_stderr:
            debug(lambda: 'Test debug message')
            assert mocked_stderr.write.called



# Generated at 2022-06-22 15:00:41.725014
# Unit test for function get_source
def test_get_source():
    def fn_source():
        """
        Bla bla
        """

    assert get_source(fn_source) == 'def fn_source():\n    """\n    Bla bla\n    """\n'  # noqa: E501

# Generated at 2022-06-22 15:00:47.163115
# Unit test for function debug
def test_debug():
    messages.debug = lambda message: 'debug {}'.format(message)
    messages.warn = lambda message: 'warn {}'.format(message)

    stdout_ = sys.stdout
    sys.stdout = StringIO()

    try:
        sys.stderr = StringIO()
        debug(lambda: 'message')
        assert sys.stderr.getvalue() == 'debug message\n'

        settings.debug = False
        debug(lambda: 'message')
        assert sys.stderr.getvalue() == 'debug message\n'
    finally:
        sys.stdout = stdout_

# Generated at 2022-06-22 15:00:59.194735
# Unit test for function get_source
def test_get_source():
    # Test for function with one line
    def single_line():
        pass
    assert get_source(single_line) == 'pass'

    # Test for function with two indented lines
    def two_lines():
        print(1)
        print(2)
    assert get_source(two_lines) == 'print(1)\nprint(2)'

    # Test for function with two dedented lines
    def two_dedented_lines(a):
        def inner_function(a):
            return a
        return inner_function(a) + 1
    assert get_source(two_dedented_lines) == 'def inner_function(a):\n\treturn a\nreturn inner_function(a) + 1'

    # Test for function with two mixed lines

# Generated at 2022-06-22 15:01:01.061251
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        return 2

    assert f() == [1]



# Generated at 2022-06-22 15:01:05.018049
# Unit test for function eager
def test_eager():
    from collections import Counter

    @eager
    def numbers(start: int, stop: int) -> Iterable[int]:
        for number in range(start, stop):
            yield number

    assert numbers(0, 4) == [0, 1, 2, 3]



# Generated at 2022-06-22 15:01:09.895412
# Unit test for function debug
def test_debug():
    # Arrange
    class Test:
        called = False

        def __call__(self):
            self.called = True
            return 'test message'

    # Act
    test = Test()
    debug(test)
    # Assert
    assert test.called

# Generated at 2022-06-22 15:01:11.220074
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'

# Generated at 2022-06-22 15:01:15.664659
# Unit test for function eager
def test_eager():
    @eager
    def _test(xs):
        for x in xs:
            yield x

    # Empty list
    assert _test([]) == []

    # Non-empty list
    assert _test(list(range(10))) == list(range(10))

# Generated at 2022-06-22 15:01:20.460584
# Unit test for function get_source
def test_get_source():
    def f():
        """
        The function f.
        """
        return 0

    assert get_source(f) == (
        "def f():\n"
        "    \"\"\"\n"
        "    The function f.\n"
        "    \"\"\"\n"
        "    return 0"
    )

# Generated at 2022-06-22 15:01:27.919180
# Unit test for function debug
def test_debug():
    # Mocking sys.stderr to capture the output
    real_stderr = sys.stderr
    sys.stderr = io.StringIO()

    settings.debug = True
    message = lambda: 'debug message'
    debug(message)
    assert(sys.stderr.getvalue() == messages.debug(message()) + '\n')

    settings.debug = False
    sys.stderr = real_stderr

# Generated at 2022-06-22 15:01:33.017872
# Unit test for function get_source
def test_get_source():
    def foo():
        # comment
        print("Hello, world!")

    def bar():
        '''
        docstring
        '''
        print("Hello, world!")

    assert get_source(foo) == 'def foo():\n    print("Hello, world!")\n'
    assert get_source(bar) == 'def bar():\n    print("Hello, world!")\n'

# Generated at 2022-06-22 15:01:36.436547
# Unit test for function eager
def test_eager():
    try:
        from unittest.mock import Mock
        _ = Mock()
        assert True
    except ImportError:
        from mock import Mock
        _ = Mock()
    @eager
    def func():
        yield 1

    assert func() == [1]



# Generated at 2022-06-22 15:01:41.033248
# Unit test for function debug
def test_debug():
    settings.debug = True
    calls: List[str] = []
    debug(lambda: calls.append('foo'))
    assert len(calls) == 1
    assert calls[0] == 'foo'
    settings.debug = False



# Generated at 2022-06-22 15:01:42.286891
# Unit test for function debug
def test_debug():
    messages.debug('test')

# Generated at 2022-06-22 15:01:46.313056
# Unit test for function get_source
def test_get_source():
    def function_1(a):
        pass
    def function_2(a, b=5):
        pass
    result_1 = get_source(function_1)
    result_2 = get_source(function_2)
    assert result_1 == 'pass'
    assert result_2 == 'pass'

# Generated at 2022-06-22 15:01:47.976952
# Unit test for function get_source
def test_get_source():
    source = get_source(get_source)
    assert 'source = get_source(get_source)' in source
    assert 'return \'\\n\'.join(line[padding:] for line in source_lines)' in source

# Generated at 2022-06-22 15:01:51.021272
# Unit test for function get_source
def test_get_source():
    def f():
        if True:
            return 1 + 2 + 3

    test = """ if True:
            return 1 + 2 + 3
    """

    assert get_source(f) == test

# Generated at 2022-06-22 15:01:54.533331
# Unit test for function get_source
def test_get_source():
    def my_func():
        pass
    assert get_source(my_func) == 'pass'

    def test_func(param1, param2=True, *args, **kwargs):
        pass
    assert get_source(test_func) == 'pass'

# Generated at 2022-06-22 15:01:56.535913
# Unit test for function eager
def test_eager():
    @eager
    def _():
        yield 1
        yield 2

    assert _() == [1, 2]



# Generated at 2022-06-22 15:01:59.961376
# Unit test for function eager
def test_eager():
    @eager
    def func() -> Iterable[int]:
        yield from [1, 2, 3]

    assert func() == [1, 2, 3]

# Generated at 2022-06-22 15:02:04.525686
# Unit test for function get_source
def test_get_source():
    def func():
        x = 1
    assert get_source(func) == 'x = 1'


# Generated at 2022-06-22 15:02:07.606976
# Unit test for function eager
def test_eager():
    # Test eager
    @eager
    def f(x):
        yield x
        yield x + 1

    assert f(1) == [1, 2]

# Generated at 2022-06-22 15:02:15.065064
# Unit test for function get_source
def test_get_source():
    def nested_functions():
        def foo():
            pass

        def bar():
            pass

    def foo():
        pass

    def bar():
        pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == get_source(bar) == 'def bar():\n    pass'
    assert get_source(nested_functions) == textwrap.dedent("""
        def nested_functions():
            def foo():
                pass

            def bar():
                pass
    """)[1:]

# Generated at 2022-06-22 15:02:18.372872
# Unit test for function get_source
def test_get_source():
    def foo() -> None:
        pass
    assert get_source(foo) == 'pass'



# Generated at 2022-06-22 15:02:22.004267
# Unit test for function debug
def test_debug():
    import pytest
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def get_stderr() -> Iterable[StringIO]:
        try:
            original_stderr = sys.stderr
            sys.stderr = StringIO()
            yield sys.stderr
        finally:
            sys.stderr = original_stderr

    def test_output():
        with get_stderr() as stderr:
            debug(lambda: 'value')
            assert stderr.getvalue() != ''
            stderr.truncate(0)
            debug(lambda: 'value')
            assert stderr.getvalue() == ''
            settings.debug = True

# Generated at 2022-06-22 15:02:29.813734
# Unit test for function get_source
def test_get_source():
    import re
    import ast
    import astor

    def test_function(a: int, b: int) -> int:
        return a + b

    def test_generator(a: int, b: int) -> int:
        yield a + b

    def test_class():
        class TestClass:
            def test_method(self, a: int, b: int) -> int:
                return a + b

    def test_lambda(a: int, b: int) -> int:
        return lambda x: a + b + x

    def test_function_with_indent(a: int, b: int) -> int:
        if True:
            return a + b

    def test_function_with_string(a: int, b: int) -> int:
        return a + b + 'abc'


# Generated at 2022-06-22 15:02:41.999835
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def stderr_io():
        old_stderr = sys.stderr
        stderr = StringIO()
        sys.stderr = stderr
        try:
            yield stderr
        finally:
            sys.stderr = old_stderr

    def test_debug_turned_off():
        with stderr_io() as stderr:
            settings.debug = False
            debug(lambda: 'foo')
            assert not stderr.getvalue()

    def test_debug_turned_on():
        with stderr_io() as stderr:
            settings.debug = True

            def get_message():
                return 'foo'

            debug(get_message)
            assert stderr

# Generated at 2022-06-22 15:02:44.563841
# Unit test for function debug
def test_debug():
    debug(lambda: "moar testing")
    settings.debug = True
    debug(lambda: "moar testing")

test_debug()

# Generated at 2022-06-22 15:02:46.305562
# Unit test for function get_source
def test_get_source():
    # TODO: assert source code is retrieved properly
    # TODO: check source code is trimmed properly
    pass



# Generated at 2022-06-22 15:02:52.654015
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: u'Hello Debug')
    assert sys.stderr.getvalue() == '''\
Debug: \033[1mHello Debug\033[0m

'''
    sys.stderr.truncate(0)
    settings.debug = False
    debug(lambda: u'Hello Debug')
    assert sys.stderr.getvalue() == ''


# Generated at 2022-06-22 15:03:05.027097
# Unit test for function debug
def test_debug():
    original_debug = settings.debug
    settings.debug = True
    result = StringIO()
    try:
        sys.stderr, original_stderr = result, sys.stderr
        debug('Some message')
        assert result.getvalue() == '\033[0;2m\033[0;33;1mSome message\033[0m\n'
    finally:
        sys.stderr = original_stderr
        settings.debug = original_debug


# Generated at 2022-06-22 15:03:09.577047
# Unit test for function get_source
def test_get_source():
    def test_func():
        def inner_test_func():
            1 // 0
        inner_test_func()

    assert get_source(test_func) == '\n'.join([
        'def inner_test_func():',
        '    1 // 0',
        'inner_test_func()',
    ])

# Generated at 2022-06-22 15:03:13.027816
# Unit test for function eager
def test_eager():
    def my_generator(x: int) -> Iterable[int]:
        for i in range(x):
            yield i

    assert eager(my_generator)(3) == [0, 1, 2]



# Generated at 2022-06-22 15:03:16.075902
# Unit test for function eager
def test_eager():
    def test(iterable):
        yield from iterable

    assert eager(test)(range(10)) == list(range(10))

# Generated at 2022-06-22 15:03:22.150794
# Unit test for function get_source
def test_get_source():
    def foo():
        a = 1
        b = a + 1
        if b > 1:
            return True
        else:
            return False

    def bar():
        def baz():
            pass

    assert get_source(foo) == """\
a = 1
b = a + 1
if b > 1:
    return True
else:
    return False"""


# Generated at 2022-06-22 15:03:26.643752
# Unit test for function eager
def test_eager():
    @eager
    def my_range(*args, **kwargs):
        return range(*args, **kwargs)

    def my_range_generator(*args, **kwargs):
        return range(*args, **kwargs)

    assert(my_range(1, 10) == list(my_range_generator(1, 10)))

# Generated at 2022-06-22 15:03:28.615701
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 15:03:38.770695
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from .asserts import install_stdlib_hook

    class TestIO(StringIO):
        def __init__(self, *args, **kwargs):
            self.reset()
            super().__init__(*args, **kwargs)

        def reset(self):
            self.getvalue()
            self.truncate(0)
            self.seek(0)

    def test_debug_stdout():
        install_stdlib_hook()

        testio = TestIO()
        testio.name = '<stdout>'
        with patch('sys.stdout', testio):
            debug(lambda: 'Some debug message')
            assert testio.getvalue() == ''

    def test_debug_stderr():
        install_stdlib

# Generated at 2022-06-22 15:03:41.152853
# Unit test for function get_source
def test_get_source():
    def my_fn():
        return 1

    assert get_source(my_fn) == 'return 1'



# Generated at 2022-06-22 15:03:46.433517
# Unit test for function get_source
def test_get_source():
    def foo():
        return bar()

    def bar():
        return foo()

    foo_src = get_source(foo)
    bar_src = get_source(bar)
    assert foo_src == 'def foo():\n' + ' ' * 4 + 'return bar()', foo_src
    assert bar_src == 'def bar():\n' + ' ' * 4 + 'return foo()', bar_src

# Generated at 2022-06-22 15:03:54.122935
# Unit test for function get_source
def test_get_source():
    code = """
    def test(x):
        return x + 1
    """
    assert get_source(test) == code

# Generated at 2022-06-22 15:03:56.415219
# Unit test for function get_source
def test_get_source():
    def foo(x, y):
        return x + y

    assert get_source(foo) == 'return x + y'


# Generated at 2022-06-22 15:04:02.294038
# Unit test for function debug
def test_debug():
    settings.debug = True
    message_log = []

    def get_message():
        mes = str(len(message_log))
        message_log.append(mes)
        return mes

    debug(get_message)
    assert message_log == ['0']
    settings.debug = False
    debug(get_message)
    assert message_log == ['0']
    settings.debug = True
    debug(get_message)
    assert message_log == ['0', '1']
    settings.debug = False

# Generated at 2022-06-22 15:04:05.683412
# Unit test for function get_source

# Generated at 2022-06-22 15:04:07.497549
# Unit test for function get_source
def test_get_source():
    source = get_source(
        lambda x, y: x + y
    )
    assert source == 'return x + y'



# Generated at 2022-06-22 15:04:09.359254
# Unit test for function eager
def test_eager():
    def gen():
        print("1")
        yield 1
        print("2")
        yield 2
        print("3")
        yield 3

    e = eager(gen)
    assert e() == [1, 2, 3]
    assert gen.__name__ == 'gen'

# Generated at 2022-06-22 15:04:13.706141
# Unit test for function eager
def test_eager():
    from pytest import raises
    assert eager(lambda: (1, 2, 3))() == [1, 2, 3]
    assert eager(lambda: [1, 2, 3])() == [1, 2, 3]

    def test_generator() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(test_generator)() == [1, 2, 3]

    x = 1

    def test_side_effect():
        nonlocal x
        x += 1
        return x

    assert eager(test_side_effect)() == [2, 3]
    assert x == 3

    def test_exception():
        raise RuntimeError('Error')

    with raises(RuntimeError) as ex:
        eager(test_exception)()
    assert str(ex.value) == 'Error'

# Generated at 2022-06-22 15:04:17.270928
# Unit test for function debug
def test_debug():
    messages.debug = 'foo bar {0}'
    assert debug(lambda: 'baz') is None
    assert debug(lambda: 'bar') is None
    print('-', sys.stderr)

# Generated at 2022-06-22 15:04:18.696246
# Unit test for function get_source
def test_get_source():
    def test():
        return 5

    assert 'return 5' in get_source(test)

# Generated at 2022-06-22 15:04:19.982886
# Unit test for function get_source
def test_get_source():
    def function():
        return 1
    assert get_source(function) == 'return 1'

# Generated at 2022-06-22 15:04:36.468280
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'hello'

    assert get_source(foo).strip() == "return 'hello'"

# Generated at 2022-06-22 15:04:41.527668
# Unit test for function debug
def test_debug():
    def messsage(): return 'TEST'
    # Call and check that the function returns None and prints to stderr if settings.debug is set to True
    assert debug(messsage) is None
    settings.debug = False
    # Call and check that the function returns None and prints to stderr if settings.debug is set to False
    assert debug(messsage) is None



# Generated at 2022-06-22 15:04:42.884511
# Unit test for function get_source
def test_get_source():
    def f(a, b=1):
        return a + b
    assert get_source(f) == 'return a + b'

# Generated at 2022-06-22 15:04:45.704178
# Unit test for function eager
def test_eager():
    def test_function():
        yield 1
        yield 2
        yield 3

    assert eager(test_function)() == [1, 2, 3]
    assert eager(eager(test_function))() == [1, 2, 3]

# Generated at 2022-06-22 15:04:53.119591
# Unit test for function debug
def test_debug():
    from io import StringIO
    from sys import stderr
    from ..conf import settings
    from .. import messages
    settings.debug = True
    buffer = StringIO()
    message = object()
    with redirect_stream(stderr, buffer):
        debug(lambda: message)
    output = buffer.getvalue()
    assert output == messages.debug(message) + '\n'
    settings.debug = False
    with redirect_stream(stderr, buffer):
        debug(lambda: message)
    assert buffer.getvalue() == ''



# Generated at 2022-06-22 15:04:55.362084
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    # source of function "f" is indented by 4 characters
    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-22 15:04:58.931908
# Unit test for function get_source
def test_get_source():
    source = "def reversed_string(text):\n        return text[::-1]"
    def reversed_string(text):
        return text[::-1]
    assert get_source(reversed_string) == source

# Generated at 2022-06-22 15:05:01.643676
# Unit test for function get_source
def test_get_source():
    a = 1
    b = 2
    def foo(a, b):
        return a + b

    assert get_source(foo) == 'return a + b'



# Generated at 2022-06-22 15:05:06.370377
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == \
        'def test_get_source():\n' \
        '    assert get_source(test_get_source) == \\\n' \
        '        \'def test_get_source():\\n\' \\\n' \
        '        \'    assert get_source(test_get_source) == \\\'\''

# Generated at 2022-06-22 15:05:09.028968
# Unit test for function get_source
def test_get_source():
    def func():
        return 5

    trimmed_line = get_source(func).split('\n')[0]
    assert trimmed_line == 'def func():'



# Generated at 2022-06-22 15:05:37.930967
# Unit test for function get_source
def test_get_source():
    from .. import main

    def f():
        pass

    assert main.get_source(f) == 'pass'



# Generated at 2022-06-22 15:05:41.256325
# Unit test for function eager
def test_eager():
    @eager
    def test(x):
        yield from range(x)
    assert test(3) == [0, 1, 2]

# Generated at 2022-06-22 15:05:43.075424
# Unit test for function eager
def test_eager():
    @eager
    def test_eager() -> Iterable[int]:
        yield 1
        yield 2
        yield 3
    assert test_eager() == [1, 2, 3]

# Generated at 2022-06-22 15:05:48.717177
# Unit test for function get_source
def test_get_source():
    code = '''
        def f(x):
            return x
    '''
    @py_backwards.annotations(x=int)
    def g(x):
        return x
    assert get_source(g) == code[1:]

# Generated at 2022-06-22 15:05:50.588935
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    # tests for function foo
    assert get_source(foo) == 'def foo():'

# Generated at 2022-06-22 15:05:53.250932
# Unit test for function get_source
def test_get_source():
    def f():
        return 42

    assert get_source(f) == 'return 42'

    def g():
        def h():
            pass

        return 42

    assert get_source(g) == 'def h():\n    pass\n\nreturn 42'

# Generated at 2022-06-22 15:05:59.441061
# Unit test for function get_source
def test_get_source():
    def a():
        pass
    assert get_source(a) == "def a():\n    pass\n"

    def b():
        if True:
            a = 2

    assert get_source(b) == "def b():\n    if True:\n" \
                            "        a = 2\n"

# Generated at 2022-06-22 15:06:01.706201
# Unit test for function eager
def test_eager():
    @eager
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]



# Generated at 2022-06-22 15:06:08.888910
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == dedent('''
        def test_function():
            pass
    ''').strip()

    def test_function():
        def inner_function():
            pass
        return inner_function

    assert get_source(test_function) == dedent('''
        def test_function():
            def inner_function():
                pass
            return inner_function
    ''').strip()



# Generated at 2022-06-22 15:06:11.437576
# Unit test for function debug
def test_debug():
    my_var = 'foo'
    debug(lambda: 'my_var=%s' % my_var)
    settings.debug = True
    debug(lambda: 'my_var=%s' % my_var)

test_debug()



# Generated at 2022-06-22 15:07:20.560645
# Unit test for function get_source
def test_get_source():
    def f(arg1, arg2):
        pass

    assert get_source(f) == 'def f(arg1, arg2):\n    pass'

# Generated at 2022-06-22 15:07:21.815788
# Unit test for function debug
def test_debug():
    debug(lambda: 'DEBUG') == None

# Generated at 2022-06-22 15:07:24.306575
# Unit test for function debug
def test_debug():
    m = []
    debug(lambda: m.append(1))
    assert not m
    settings.debug = True
    debug(lambda: m.append(1))
    assert m == [1]



# Generated at 2022-06-22 15:07:26.912444
# Unit test for function eager
def test_eager():
    def generate():
        yield 1
        yield 2
        yield 3

    assert eager(generate)() == [1, 2, 3]

# Generated at 2022-06-22 15:07:29.624960
# Unit test for function eager
def test_eager():
    @eager
    def test(number):
        while True:
            yield number
            number += 1

    assert test(42) == [42]

# Unit tests for functions generates and get_source

# Generated at 2022-06-22 15:07:37.936155
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch
    from .. import conf

    with patch('sys.stderr', new=StringIO()) as error_stream:
        conf.settings.debug = True
        debug(lambda: 'Hello world!')
        assert error_stream.getvalue() == messages.debug('Hello world!') + '\n'

    with patch('sys.stderr', new=StringIO()) as error_stream:
        conf.settings.debug = False
        debug(lambda: 'Hello world!')
        assert error_stream.getvalue() == ''



# Generated at 2022-06-22 15:07:39.535424
# Unit test for function get_source
def test_get_source():
    # test function
    def foo():
        print('hello world')
        return 1

    # test output

# Generated at 2022-06-22 15:07:43.843624
# Unit test for function get_source
def test_get_source():
    def give_five(): # noqa
        return 5

    assert get_source(give_five) == 'def give_five():\n    return 5'



# Generated at 2022-06-22 15:07:46.980391
# Unit test for function eager
def test_eager():
    def lazy():
        for i in range(5):
            yield i

    def eager():
        return list(lazy())

    assert eager() == eager(lazy)



# Generated at 2022-06-22 15:07:49.416600
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'hello')
    finally:
        settings.debug = False