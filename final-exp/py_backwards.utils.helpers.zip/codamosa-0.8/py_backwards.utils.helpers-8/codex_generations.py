

# Generated at 2022-06-22 14:58:33.751621
# Unit test for function debug
def test_debug():
    from py_backwards.utils import StringIO

    def get_message():
        return 'Hello {}'.format(settings.debug)

    messages.debug = lambda s: 'DEBUG: ' + s
    string_io = StringIO()

    with string_io.bind_to(sys.stderr):
        debug(get_message)
    assert string_io.getvalue() == ''

    settings.debug = True
    with string_io.bind_to(sys.stderr):
        debug(get_message)
    assert string_io.getvalue() == 'DEBUG: Hello True\n'

    settings.debug = False

# Generated at 2022-06-22 14:58:36.099194
# Unit test for function eager
def test_eager():
    def _sum(*args):
        for arg in args:
            yield arg

    assert eager(_sum)(1, 2) == [1, 2]

# Generated at 2022-06-22 14:58:37.227462
# Unit test for function get_source

# Generated at 2022-06-22 14:58:38.984596
# Unit test for function eager
def test_eager():
    assert eager(lambda: x for x in range(5))() == [0, 1, 2, 3, 4]



# Generated at 2022-06-22 14:58:41.165404
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for i in range(10):
            yield i

    assert gen() == list(range(10))



# Generated at 2022-06-22 14:58:42.877541
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert "def fn():\n    pass" == get_source(fn)


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 14:58:45.137154
# Unit test for function get_source
def test_get_source():
    def foo(a, b):  # noqa
        return 3 * a + b

    assert get_source(foo) == 'return 3 * a + b'

# Generated at 2022-06-22 14:58:49.895480
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def bar():
        x = 2
        y = 3
        z = x + y
        return z

    assert get_source(bar) == 'x = 2\ny = 3\nz = x + y\nreturn z'

# Generated at 2022-06-22 14:58:51.357620
# Unit test for function eager
def test_eager():
    assert eager(list)(range(1, 4)) == [1, 2, 3]

# Generated at 2022-06-22 14:58:54.374160
# Unit test for function debug
def test_debug():
    with mock.patch('sys.stderr', new=six.StringIO()) as mock_stderr:
        debug(lambda: 'message')
        assert 'message' in mock_stderr.getvalue()

# Generated at 2022-06-22 14:59:00.931466
# Unit test for function debug
def test_debug():
    # If debug is set to True, it should print
    settings.debug = True
    debug(lambda: "It passed")
    # And if settings.debug is set to False, it should not print
    settings.debug = False
    debug(lambda: "It did not pass")

# Generated at 2022-06-22 14:59:04.894706
# Unit test for function debug
def test_debug():
    class StreamLogger:

        def __init__(self) -> None:
            self._stream = []

        def read(self) -> str:
            return ''.join(self._stream)

        def write(self, x: str) -> None:
            self._stream += x

    with patch('sys.stderr', StreamLogger()):
        with patch('py_backwards.settings.debug', True):
            debug(lambda: 'helloooo')
            assert sys.stderr.read() == messages.debug('helloooo')

        with patch('py_backwards.settings.debug', False):
            debug(lambda: 'helloooo')
            assert sys.stderr.read() == ''

# Generated at 2022-06-22 14:59:08.895621
# Unit test for function get_source
def test_get_source():
    def func1():
        for x in range(5):
            print(x)

    expected_source = """for x in range(5):
    print(x)"""

    assert get_source(func1) == expected_source



# Generated at 2022-06-22 14:59:14.455069
# Unit test for function debug
def test_debug():
    messages.debug = lambda s: s

    old_settings_debug = settings.debug
    settings.debug = True

    debug(lambda: 'debug')
    settings.debug = False
    debug(lambda: 'debug')
    settings.debug = True
    debug(lambda: 'debug')

    settings.debug = old_settings_debug

# Generated at 2022-06-22 14:59:15.803301
# Unit test for function eager
def test_eager():
    assert eager(lambda: [1, 2, 3])() == [1, 2, 3]

# Generated at 2022-06-22 14:59:23.326588
# Unit test for function debug
def test_debug():
    lines = []
    with patch.object(sys.stderr, 'write') as mock_stderr_write:
        mock_stderr_write.side_effect = lambda *args: lines.append(args[0])
        settings.set_debug(True)
        debug(lambda: '5 + 2 = {}'.format(5 + 2))
        debug(lambda: '2 + 5 = {}'.format(2 + 5))
        settings.set_debug(False)
        debug(lambda: '5 - 2 = {}'.format(5 - 2))
    assert lines == [
        messages.debug('5 + 2 = 7').rstrip() + '\n',
        messages.debug('2 + 5 = 7').rstrip() + '\n',
    ]

# Generated at 2022-06-22 14:59:27.212158
# Unit test for function get_source
def test_get_source():
    def foo():
        if True:
            return 1

    def bar():
        if True:
            return 1

    print(
        foo, bar,
        get_source(foo), get_source(bar),
        sep='\n',
    )



# Generated at 2022-06-22 14:59:30.884061
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'

    def g():
        def f():
            pass

    assert get_source(g) == 'def f():\n    pass'



# Generated at 2022-06-22 14:59:33.530536
# Unit test for function debug
def test_debug():
    global settings

    # Case 1
    settings.debug = False
    assert debug(lambda: '') is None

    # Case 2
    settings.debug = True
    assert debug(lambda: 'test') is None

# Generated at 2022-06-22 14:59:39.527031
# Unit test for function get_source
def test_get_source():
    def fn():
        a = 1

    expected = "a = 1\n"
    assert get_source(fn) == expected

    def fn2():
        a = 1
        b = 2
        c = 3
        d = 4

    expected = ("a = 1\n"
                "b = 2\n"
                "c = 3\n"
                "d = 4\n")
    assert get_source(fn2) == expected

    def fn3():
        a = 1
        b = 2
        c = 3
        d = 4

    expected = ("a = 1\n"
                "b = 2\n"
                "c = 3\n"
                "d = 4\n")
    assert get_source(fn3) == expected

    def fn4():
        a = 1

        b = 2

# Generated at 2022-06-22 14:59:44.685366
# Unit test for function debug
def test_debug():
    from ..test_utils import MockStdErr
    settings.debug = True
    with MockStdErr() as mock:
        debug(lambda: 'message')
        assert mock.value == messages.debug('message') + '\n'

# Generated at 2022-06-22 14:59:50.930680
# Unit test for function debug
def test_debug():
    class DummyStream:
        def __init__(self) -> None:
            self.last_message = None

        def write(self, msg: str) -> None:
            self.last_message = msg

    stream = DummyStream()
    stdout_backup = sys.stderr
    sys.stderr = stream
    try:
        # Execute the positive test case
        settings.debug = True
        debug(lambda: 'test debug')
        assert stream.last_message == (
            'py_backwards: DEBUG: test debug\n'
        )
        stream.last_message = None

        # Execute the negative test case
        settings.debug = False
        debug(lambda: 'test debug')
        assert stream.last_message is None
    finally:
        sys.stderr = stdout_back

# Generated at 2022-06-22 14:59:55.084851
# Unit test for function get_source
def test_get_source():
    def fn():
        """Docstring"""
        def wrapped():
            pass

    assert get_source(fn) == inspect.cleandoc("""
        """
                                               """Docstring
        """
                                               """def wrapped():
            pass
        """)

# Generated at 2022-06-22 14:59:58.528426
# Unit test for function get_source
def test_get_source():

    def foo():
        """
            This is docstring
        """
        pass

    source = get_source(foo)
    assert source == 'def foo():\n    """\n        This is docstring\n    """\n    pass'

# Generated at 2022-06-22 15:00:02.598914
# Unit test for function get_source
def test_get_source():
    def foo_bar():
        pass

    def foo_bar_with_many_spaces():
        pass

    assert get_source(foo_bar) == 'pass'
    assert get_source(foo_bar_with_many_spaces) == 'pass'

# Generated at 2022-06-22 15:00:08.228332
# Unit test for function debug
def test_debug():
    if not settings.debug:
        return
    _buffer = StringIO()
    _old_stderr = sys.stderr
    sys.stderr = _buffer
    try:
        debug(lambda: 'test')
        assert 'test' in _buffer.getvalue()
    finally:
        sys.stderr = _old_stderr



# Generated at 2022-06-22 15:00:10.178770
# Unit test for function eager
def test_eager():
    import pytest
    from random import randint
    @eager
    def range_of(number: int) -> Iterable[int]:
        for i in range(number):
            yield i
    assert range_of(5) == [0, 1, 2, 3, 4]
    with pytest.raises(TypeError):
        range_of()

# Generated at 2022-06-22 15:00:15.497217
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()
    debug(lambda: 'foo')
    assert sys.stderr.getvalue() == ''

    settings.debug = True
    debug(lambda: 'foo')
    assert sys.stderr.getvalue().strip() == '[DEBUG]: foo'

# Generated at 2022-06-22 15:00:22.956275
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == """def test_get_source():
    assert get_source(test_get_source) == \"\"\"def test_get_source():
    assert get_source(test_get_source) == \\\"\\\"\\\"def test_get_source():
    assert get_source(test_get_source) == '''def test_get_source():
    assert get_source(test_get_source) == \\'\\'\\'\"\"\"
"""

# Generated at 2022-06-22 15:00:26.350432
# Unit test for function get_source
def test_get_source():
    def fn(arg: int) -> int:
        return arg + 2

    assert get_source(fn) == '    return arg + 2'



# Generated at 2022-06-22 15:00:30.194524
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 15:00:35.564915
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    source = get_source(function)
    assert source == 'def function():'

    def function():
        pass
    source = get_source(function)
    assert source == 'def function():'

# Generated at 2022-06-22 15:00:37.757980
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-22 15:00:43.664105
# Unit test for function debug
def test_debug():
    import unittest

    class TestDebug(unittest.TestCase):

        def test_debug_invokes_get_message(self):
            call_count = 0

            def get_message() -> str:
                nonlocal call_count
                call_count += 1
                return 'message'

            debug(get_message)

            self.assertEqual(call_count, 1)

    unittest.main()

# Generated at 2022-06-22 15:00:45.249822
# Unit test for function debug
def test_debug():
    from .. import conf
    conf.settings.debug = True
    debug(lambda: 'Hello!')



# Generated at 2022-06-22 15:00:47.661835
# Unit test for function eager
def test_eager():
    def get_list():
        yield 1
        yield 2
        yield 3

    assert eager(get_list)() == [1, 2, 3]

# Generated at 2022-06-22 15:00:52.596111
# Unit test for function eager
def test_eager():
    def get_numbers():
        yield 1
        yield 2

    numbers_list = eager(get_numbers)()

    assert type(numbers_list) is list
    assert len(numbers_list) == 2



# Generated at 2022-06-22 15:00:53.351448
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'



# Generated at 2022-06-22 15:00:55.610542
# Unit test for function eager
def test_eager():
    assert eager(lambda: i for i in range(10))() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:00:57.864441
# Unit test for function get_source
def test_get_source():
    def test():
        x = 1
        return x

    assert get_source(test) == 'x = 1\nreturn x'

# Generated at 2022-06-22 15:01:01.861847
# Unit test for function get_source
def test_get_source():
    def fn():
        a = 1
        b = 2

    assert get_source(fn) == 'a = 1\nb = 2'

# Generated at 2022-06-22 15:01:03.623812
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 15:01:07.667611
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    lines = get_source(foo).split('\n')
    assert lines[0] == ''
    assert lines[1] == 'def foo():'

# Generated at 2022-06-22 15:01:14.688407
# Unit test for function debug
def test_debug():
    import io
    import sys

    out = io.StringIO()
    sys.stderr = out
    
    settings.debug = False
    debug(lambda: 'This is a debug message')
    assert out.getvalue() == ''
    settings.debug = True
    debug(lambda: 'This is a debug message')
    assert out.getvalue() == messages.debug('This is a debug message') + '\n'
    
    sys.stderr = sys.__stderr__
    out.close()

# Generated at 2022-06-22 15:01:18.968251
# Unit test for function get_source
def test_get_source():
    def f():
        """
        docstring
        """
        pass

    expected_source = """
    def f():
        \"\"\"
        docstring
        \"\"\"
        pass

    """
    assert get_source(f).strip() == expected_source.strip()

# Generated at 2022-06-22 15:01:21.515673
# Unit test for function eager
def test_eager():
    @eager
    def generator_function():
        yield 1
        yield 2

    assert generator_function() == [1, 2]



# Generated at 2022-06-22 15:01:25.150432
# Unit test for function eager
def test_eager():
    from inspect import getsource

    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3


# Generated at 2022-06-22 15:01:28.876373
# Unit test for function get_source
def test_get_source():
    def func():
        def _():
            return 'aaa'
        return _()

    assert get_source(func) == 'def _():\n    return \'aaa\'\nreturn _()'

# Generated at 2022-06-22 15:01:31.833069
# Unit test for function get_source
def test_get_source():
    def get_source_test_func():
        def test():
            pass
        return get_source(test)

    assert get_source_test_func() == 'def test():\n    pass'

# Generated at 2022-06-22 15:01:32.991021
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    debug(lambda: 'foo')

# Generated at 2022-06-22 15:01:38.562973
# Unit test for function debug
def test_debug():
    lines: List[str] = []
    settings.debug = True
    print = lambda *args: lines.append(repr(args))
    debug(lambda: 'hello')
    settings.debug = False
    debug(lambda: 'world')

    assert len(lines) == 1
    assert lines[0] == "('hello',)"



# Generated at 2022-06-22 15:01:42.497301
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'
    assert get_source(bar) == 'def bar():\n    pass\n'

# Generated at 2022-06-22 15:01:46.764316
# Unit test for function get_source
def test_get_source():
    def test_function(x: str = 'test') -> int:
        """Simple function for testing."""
        return x


# Generated at 2022-06-22 15:01:56.341333
# Unit test for function debug
def test_debug():
    def assert_out(expected: str) -> None:
        captured_stderr = sys.stderr.getvalue()
        if not captured_stderr.startswith(expected):
            raise AssertionError('Expected: {!r}, got {!r}'.format(expected, captured_stderr))

    class StdOutCapturing:
        @staticmethod
        def start() -> None:
            sys.stderr = StringIO()

        @staticmethod
        def stop() -> None:
            sys.stderr = sys.__stderr__

    StdOutCapturing.start()
    debug(lambda: 'message')
    assert_out('DEBUG: message\n')
    StdOutCapturing.stop()
    debug(lambda: 'message')



# Generated at 2022-06-22 15:01:59.676305
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    expected_source = 'def test_function():\n    pass'
    assert get_source(test_function) == expected_source

# Generated at 2022-06-22 15:02:06.082061
# Unit test for function debug
def test_debug():
    orig_debug = settings.debug
    settings.debug = True
    try:
        import io
        from contextlib import redirect_stderr
        stderr = io.StringIO()
        with redirect_stderr(stderr):
            debug(lambda: 42)
        assert stderr.getvalue().startswith('\x1b[1;30mDEBUG: ')
    finally:
        settings.debug = orig_debug



# Generated at 2022-06-22 15:02:12.251969
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .. import messages
    from . import debug

    settings.debug = True

    def test_function():
        with StringIO() as stream:
            sys.stderr = stream
            debug(lambda: 'Hello!')
            sys.stderr = sys.__stderr__
            return stream.getvalue()

    assert test_function().startswith(messages.debug(''))


# Generated at 2022-06-22 15:02:13.611071
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'pass'

# Generated at 2022-06-22 15:02:14.760702
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test_message')
    finally:
        settings.debug = False
    assert True

# Generated at 2022-06-22 15:02:17.655744
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 15:02:24.963396
# Unit test for function get_source
def test_get_source():
    def fn(x, y):
        a = 1
        b = 2
        return [a, b]

    assert get_source(fn) == '''a = 1
    b = 2
    return [a, b]'''

# Generated at 2022-06-22 15:02:28.903931
# Unit test for function get_source
def test_get_source():
    from typing import Optional
    from ..backwards import backwards
    from .typing import *

    @backwards
    def do_return(x: Optional[int]) -> Optional[int]:
        return x

    assert get_source(do_return) == dedent(
        '''
        def do_return(x: Optional[int]) -> Optional[int]:
            return x
        '''
    )



# Generated at 2022-06-22 15:02:32.337161
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        x = 1
        y = x + b

        for i in range(x + y + a):
            pass

        return x + y + a, x + y + b, x + y


# Generated at 2022-06-22 15:02:36.421017
# Unit test for function get_source
def test_get_source():
    def f(*args, **kwargs):
        return True
    assert get_source(f) == 'return True', 'get_source returns wrong source code'

# Generated at 2022-06-22 15:02:39.018898
# Unit test for function get_source
def test_get_source():
    def func():
        """Docstring"""
        pass
    eq_(get_source(func), "def func():\n    pass")

# Generated at 2022-06-22 15:02:42.912036
# Unit test for function debug
def test_debug():
    import io
    import sys
    out = io.StringIO()
    sys.stdout = out
    try:
        print(123)
    except Exception:
        pass
    sys.stdout = sys.__stdout__
    assert out.getvalue() == "123\n"

# Generated at 2022-06-22 15:02:49.688006
# Unit test for function get_source
def test_get_source():
    def fun():
        pass
    def fun_with_padding():
        pass
    fun_with_padding.__name__ = 'fun_with_padding'
    test_fun_with_padding = 'def fun_with_padding():\n        pass'
    assert get_source(fun) == 'def fun():\n    pass'
    assert get_source(fun_with_padding) == test_fun_with_padding

# Generated at 2022-06-22 15:02:59.094646
# Unit test for function get_source
def test_get_source():
    from backwards.helpers import get_source, VariablesGenerator

    def get_source_test():
        """\
        function get_source(fn: Callable[..., Any]) -> str:
            # Returns the source code of the function.

            source_lines = getsource(fn).split('\n')
            padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
            return '\\n'.join(line[padding:] for line in source_lines)
        """
        return VariablesGenerator.generate('temp_var')

    assert get_source(get_source_test) == get_source(get_source)


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:03:01.068983
# Unit test for function eager
def test_eager():
    l = [1,2]
    assert eager(iter)(l) == [1,2]

# Generated at 2022-06-22 15:03:04.131210
# Unit test for function eager
def test_eager():
    @eager
    def range_():
        yield 1
        yield 2
        yield 3

    assert range_() == [1, 2, 3]

# Generated at 2022-06-22 15:03:18.668452
# Unit test for function eager
def test_eager():
    from types import GeneratorType
    def f():
        yield 1
        yield 2
        yield 3

    assert isinstance(f(), GeneratorType)
    assert isinstance(eager(f), type(lambda: []))



# Generated at 2022-06-22 15:03:28.866155
# Unit test for function debug
def test_debug():
    import sys
    import unittest
    import unittest.mock

    sys.modules['py_backwards.conf.settings'] = unittest.mock.Mock(debug=True)
    sys.modules['py_backwards.messages'] = unittest.mock.Mock(debug=lambda x: 'message')
    sys.modules['sys'] = unittest.mock.Mock(stderr=unittest.mock.Mock())
    from py_backwards.utils.misc import debug

    with unittest.mock.patch('sys.stderr.write') as write:
        debug(lambda: 'this is message')
        write.assert_called_once_with('message\n')

    sys.modules['py_backwards.conf.settings'] = unittest.mock

# Generated at 2022-06-22 15:03:31.030616
# Unit test for function get_source
def test_get_source():
    def f(a, b):
        return a + b

    assert get_source(f) == "return a + b"



# Generated at 2022-06-22 15:03:33.414193
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-22 15:03:36.088704
# Unit test for function eager
def test_eager():
    @eager
    def test_generator():
        for i in range(5):
            yield i

    assert list(test_generator()) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:03:40.313866
# Unit test for function get_source
def test_get_source():
    def foo():
        x = 42
        return x

    def bar():
        def baz(x):
            return x + 1
        return baz

    assert get_source(foo) == 'x = 42\nreturn x'

# Generated at 2022-06-22 15:03:46.549584
# Unit test for function debug
def test_debug():
    from . import mock
    from .mock import patch

    with patch.object(settings, 'debug', True):
        with mock.patch('builtins.print') as mocked_print:
            debug(lambda: 'message')
            mocked_print.assert_called_with(
                messages.debug('message'),
                file=mock.ANY
            )

    with patch.object(settings, 'debug', False):
        with mock.patch('builtins.print') as mocked_print:
            debug(lambda: 'message')
            print.assert_not_called()

# Generated at 2022-06-22 15:03:48.210266
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == \
        'assert get_source(test_get_source) == \\'

# Generated at 2022-06-22 15:03:50.084341
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1
    assert get_source(foo) == 'return 1'



# Generated at 2022-06-22 15:03:51.846748
# Unit test for function get_source
def test_get_source():
    def test_func(a):
        return a

    assert get_source(test_func) == 'return a'

# Generated at 2022-06-22 15:04:22.981122
# Unit test for function eager
def test_eager():
    def fibonacci():
        prev, curr = 0, 1
        while True:
            yield curr
            prev, curr = curr, curr + prev
    lst = eager(fibonacci)()
    assert len(lst) == 30
    assert lst[-1] == 832040
    assert lst[-2] == 514229

# Generated at 2022-06-22 15:04:24.199738
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-22 15:04:24.971235
# Unit test for function debug
def test_debug():
    debug(lambda: 'debug')


# Generated at 2022-06-22 15:04:27.601622
# Unit test for function get_source
def test_get_source():
    def fn(a: int, *args: int, c: int=0) -> int:
        pass

    assert get_source(fn) == dedent(
        """
        def fn(a: int, *args: int, c: int=0) -> int:
            pass
        """
    )

# Generated at 2022-06-22 15:04:33.748724
# Unit test for function eager
def test_eager():
    class MyIterable:
        def __init__(self):
            self._items = [1, 2, 3]

        def __len__(self):
            return len(self._items)

        def __iter__(self):
            return iter(self._items)

    @eager
    def get_iterable() -> Iterable[int]:
        return MyIterable()

    assert get_iterable() == [1, 2, 3]

# Generated at 2022-06-22 15:04:37.909853
# Unit test for function eager
def test_eager():
    def foo(bar):
        yield bar
        yield 1
        yield 2

    assert foo('bar') == [bar, 1, 2]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:04:45.702825
# Unit test for function debug
def test_debug():
    import re
    from py_backwards.utils.pytest_utils import assert_outcomes

    @assert_outcomes
    def test_debug_with_debug_enabled(capsys):
        settings.debug = True
        debug(lambda: 'test debug')
        captured = capsys.readouterr()

        assert re.search(r'^\[py_backwards\].*?test debug$', captured.err)

    @assert_outcomes
    def test_debug_with_debug_disabled(capsys):
        settings.debug = False
        debug(lambda: 'test debug')
        captured = capsys.readouterr()

        assert captured.err == ''

# Generated at 2022-06-22 15:04:47.957333
# Unit test for function eager
def test_eager():
    import types
    @eager
    def gen() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert isinstance(gen, types.FunctionType)
    assert gen() == [1, 2, 3]

# Generated at 2022-06-22 15:04:49.605445
# Unit test for function debug
def test_debug():
    debug(lambda: 'value')

# Generated at 2022-06-22 15:04:54.042723
# Unit test for function debug
def test_debug():
    def debug_message():
        return 'This is it'

    def not_debug_message():
        return 'Again'

    debug_result = debug(debug_message)
    not_debug_result = debug(not_debug_message)

    assert debug_result is None
    assert not_debug_result is None

# Generated at 2022-06-22 15:05:47.936998
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 15:05:50.732579
# Unit test for function eager
def test_eager():
    def f(a, b):
        yield a
        yield b

    @eager
    def g(a, b):
        yield a
        yield b

    assert g(1, 2) == [1, 2]

# Generated at 2022-06-22 15:05:55.427539
# Unit test for function debug
def test_debug():
    lines = []
    old_stdout = sys.stdout
    sys.stdout = out = open(os.devnull, 'w')

    def print_message(message: str) -> None:
        lines.append(message)

    try:
        print_message = messages.debug
        settings.debug = False
        debug(lambda: 'debug mode off, test')
        assert len(lines) == 0
        settings.debug = True
        debug(lambda: 'debug mode on')
        assert len(lines) == 1

        # Check message format
        assert lines[0] == messages.debug('debug mode on')
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-22 15:05:58.069260
# Unit test for function eager
def test_eager():
    @eager
    def function():
        yield 1
        yield 2
        yield 3

    assert function() == [1, 2, 3]


# Generated at 2022-06-22 15:06:02.633342
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

    def fn_with_docstring():
        """Docstring"""
        pass

    assert get_source(fn_with_docstring) == 'def fn_with_docstring():\n    """Docstring"""\n    pass'



# Generated at 2022-06-22 15:06:13.520933
# Unit test for function debug
def test_debug():
    messages.enable_color = False
    settings.debug = True

    output = []

    def print_to_buffer(*args):
        output.extend(args)

    sys.stderr.write = print_to_buffer

    debug(lambda: 'test')

    assert output == ['[PyBackwards] ', 'debug: ', 'test']
    assert sys.stderr.write == print_to_buffer

    output = []
    settings.debug = False
    debug(lambda: 'test')
    assert output == []

    settings.debug = True
    messages.enable_color = True
    settings.debug = True
    output = []
    debug(lambda: 'test')

# Generated at 2022-06-22 15:06:16.316496
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]

    @eager
    def example():
        return l

    assert example() == l
    l.append(4)
    assert example() == l



# Generated at 2022-06-22 15:06:18.417173
# Unit test for function get_source
def test_get_source():
    def function() -> int:
        variable = 1
        return variable
    assert get_source(function) == 'variable = 1\nreturn variable'



# Generated at 2022-06-22 15:06:21.502362
# Unit test for function eager
def test_eager():
    def test_func(*a, **kw):
        for i in range(3):
            yield i
    assert eager(test_func)() == [0, 1, 2]

# Generated at 2022-06-22 15:06:22.869476
# Unit test for function eager
def test_eager():
    def range_2(n):
        i = 0
        while i <= n:
            yield i
 

# Generated at 2022-06-22 15:07:34.780254
# Unit test for function debug
def test_debug():
    assert not settings.debug
    debug_message = 'Message'
    debug_call = mock.MagicMock()

    def _get_message() -> str:
        debug_call()
        return debug_message

    debug(_get_message)
    assert not debug_call.called

    with settings.debug_context():
        debug(_get_message)
        assert debug_call.called_once_with()



# Generated at 2022-06-22 15:07:36.649071
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo bar')

# Generated at 2022-06-22 15:07:38.937198
# Unit test for function debug
def test_debug():
    messages.reset()
    settings.debug = False
    debug(lambda: 'foo')
    assert not messages.debug
    settings.debug = True
    debug(lambda: 'foo')
    assert messages.debug == 'foo'

# Generated at 2022-06-22 15:07:40.426065
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == 'def get_source(fn):\n    return getsource(fn).split("\\n")[1:-1]'

# Generated at 2022-06-22 15:07:52.315471
# Unit test for function get_source
def test_get_source():
    # Simple function
    def test_function():
        """Testing function"""
        return 1 + 2

    assert get_source(test_function) == '"""Testing function"""\nreturn 1 + 2'

    # Empty function
    def test_empty_function():
        pass

    assert get_source(test_empty_function) == ''

    # Function with parameters
    def test_function_with_parameters(parameter: int) -> str:
        pass

    assert get_source(
        test_function_with_parameters) == 'def test_function_with_parameters(parameter: int) -> str:\n    pass'

    # Lambda function
    test_lambda = lambda x: x

    assert get_source(test_lambda) == 'lambda x: x'

# Generated at 2022-06-22 15:08:01.114371
# Unit test for function eager
def test_eager():
    # test no change
    @eager
    def f():
        yield 1
        yield 2

    assert f() == [1, 2]

    # test no change, with args
    @eager
    def f(args):
        yield args
        yield args

    assert f(1) == [1, 1]

    # test no change, with kwargs
    @eager
    def f(kwargs=None):
        yield kwargs
        yield kwargs

    assert f(kwargs=1) == [1, 1]

    # test no change, with *args and **kwargs
    @eager
    def f(*args, **kwargs):
        yield args
        yield kwargs

    assert f(1, 2, 3) == [(1, 2, 3), {}]

# Generated at 2022-06-22 15:08:05.235767
# Unit test for function debug
def test_debug():
    msg = ['DO NOT SHOW THIS MESSAGE']

    @debug
    def test():
        msg[0] = 'OK'
        return msg[0]

    test()
    assert msg[0] == 'DO NOT SHOW THIS MESSAGE'

    settings.debug = True
    test()
    settings.debug = False

    assert msg[0] == 'OK'



# Generated at 2022-06-22 15:08:13.588895
# Unit test for function debug
def test_debug():
    import mock
    import pytest
    from .. import settings

    def get_message():
        return 'hello'

    debug_mock = mock.MagicMock()

    with mock.patch('builtins.print', debug_mock):
        settings.debug = False
        debug(get_message)
        assert not debug_mock.called, 'Debug mode should be ignored'

        settings.debug = True
        debug(get_message)
        assert debug_mock.called, 'Debug mode should be enabled'



# Generated at 2022-06-22 15:08:18.085418
# Unit test for function debug
def test_debug():
    normal_print = print
    buffer = ''
    try:
        print = lambda msg, file=None: buffer.__iadd__(str(msg))
        debug(lambda: 'message')
        assert buffer == ''
        settings.debug = True
        debug(lambda: 'message')
        assert buffer == messages.debug('message') + '\n'
    finally:
        settings.debug = False
        print = normal_print



# Generated at 2022-06-22 15:08:27.631000
# Unit test for function get_source
def test_get_source():
    def foo():
        # nested function has to be ignored
        def bar(): pass
    assert get_source(foo) == 'def foo():\n    # nested function has to be ignored'


# Additional indentation of source code
INDENTATION = 4

# Set of variable names, that are explicitly ignored by the middleware
EXPLICIT_IGNORE_VARIABLES = frozenset({'__annotations__', '__name__'})

# Set of variable names, that are implicitly ignored by the middleware
IMPLICIT_IGNORE_VARIABLES = frozenset({'__module__', '__defaults__', '__code__', '__globals__', '__dict__',
                                       '__closure__', '__kwdefaults__', '__qualname__'})