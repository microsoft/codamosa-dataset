

# Generated at 2022-06-22 14:58:33.858848
# Unit test for function get_source
def test_get_source():
    def add(val):
        return val + 1

    assert get_source(add) == 'return val + 1'



# Generated at 2022-06-22 14:58:38.839053
# Unit test for function debug
def test_debug():
    settings.debug = True

    debug(lambda: 'test')
    output = sys.stderr.getvalue().strip()
    assert output == 'py_backwards_debug: test'

    settings.debug = False

    debug(lambda: 'test')
    output = sys.stderr.getvalue().strip()
    assert output == ''

    settings.debug = True

test_debug.__test__ = False

# Generated at 2022-06-22 14:58:42.363679
# Unit test for function get_source
def test_get_source():
    def f():
        print(1)

    def g():
        print(2)

    str1 = get_source(f)
    str2 = '''print(1)'''
    str3 = get_source(g)
    str4 = '''print(2)'''
    assert str1 == str2
    assert str3 == str4

# Generated at 2022-06-22 14:58:49.895826
# Unit test for function get_source
def test_get_source():
    def foo(a):
        return a

    def bar(a):
        def baz(c):
            return c
        return (a, baz)

    def qux(a):
        """
        Some docstring
        """

    assert get_source(foo) == 'return a'
    assert get_source(bar) == 'def baz(c):\n    return c\nreturn (a, baz)'
    assert get_source(qux) == '"""\nSome docstring\n"""'

# Generated at 2022-06-22 14:58:55.853106
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'assert get_source(test_get_source) == \'assert get_source(test_get_source) == \\\'assert get_source(test_get_source) == \\\\\\\'assert get_source(test_get_source) == \\\\\\\\\\\\\\\'assert get_source(test_get_source) == \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'assert get_source(test_get_source) == \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'\'\''

# Generated at 2022-06-22 14:58:59.014339
# Unit test for function eager
def test_eager():
    @eager
    def x():
        yield 1
        yield 2
        yield 3
    assert x() == [1,2,3]


# Generated at 2022-06-22 14:59:01.746403
# Unit test for function get_source
def test_get_source():
    def test():
        '''
        test_get_source
        '''
        pass

    assert get_source(test) == 'test'

# Generated at 2022-06-22 14:59:03.757021
# Unit test for function eager
def test_eager():
    x = eager(lambda x: range(x))
    assert x(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 14:59:06.733422
# Unit test for function get_source
def test_get_source():
    def foo():
        a = 1
        return a

    assert get_source(foo) == 'a = 1\nreturn a\n'
    foo.x = 1
    assert get_source(foo) == 'a = 1\nreturn a\n'

# Generated at 2022-06-22 14:59:14.597744
# Unit test for function debug
def test_debug():
    from .ctx import get_context
    from .utils import set_debug

    ctx = get_context()
    old_debug = ctx.settings.debug
    try:
        ctx.settings.debug = True

        msgs = []
        def get_debug_message():
            msgs.append('test')
            return 'test'

        debug(get_debug_message)
        assert msgs == ['test']
    finally:
        ctx.settings.debug = old_debug

# Generated at 2022-06-22 14:59:19.673665
# Unit test for function debug
def test_debug():
    """Unit test for function debug."""
    try:
        settings.debug = True
        debug(lambda: 'print this')
        settings.debug = False
        debug(lambda: 'don\'t print this')
    finally:
        settings.debug = False

# Generated at 2022-06-22 14:59:24.179629
# Unit test for function eager
def test_eager():
    from ..test import TestCase, compare

    class Test(TestCase):
        def test(self):
            @eager
            def gen():
                yield 1
                yield 2

            compare(gen(), [1, 2])

# Generated at 2022-06-22 14:59:26.391936
# Unit test for function get_source
def test_get_source():
    def foo():
        """function definition"""
        a = 1
        b = 2
        return a + b

# Generated at 2022-06-22 14:59:29.681937
# Unit test for function debug
def test_debug():
    settings.debug = True
    message = 'test'

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        debug(lambda: message)
        assert message == stderr.getvalue().strip()



# Generated at 2022-06-22 14:59:31.050234
# Unit test for function get_source
def test_get_source():
    def fn(): pass
    assert get_source(fn) == 'def fn(): pass'

# Generated at 2022-06-22 14:59:33.370401
# Unit test for function get_source
def test_get_source():
    def test_func():
        #        print(1)
        return 1
    assert get_source(test_func).strip() == 'return 1'



# Generated at 2022-06-22 14:59:35.674706
# Unit test for function get_source
def test_get_source():
    def test():
        print()

    source = get_source(test)
    assert source == 'def test():\n    print()'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 14:59:40.004099
# Unit test for function get_source

# Generated at 2022-06-22 14:59:42.752722
# Unit test for function eager
def test_eager():
  def foo(a, b):
    yield a
    yield b
  
  bar = eager(foo)
  assert bar("5", "10") == ["5", "10"]

# Generated at 2022-06-22 14:59:44.432259
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'
    debug(get_message)


# Generated at 2022-06-22 14:59:49.295142
# Unit test for function eager
def test_eager():
    assert eager.__name__ == 'wrapped'
    assert eager.__doc__ == 'Returns list of function\'s iterable result.'

# Generated at 2022-06-22 14:59:54.938093
# Unit test for function get_source
def test_get_source():
    assert 'a = 1' == get_source(lambda: 1)

# Generated at 2022-06-22 14:59:57.630231
# Unit test for function debug
def test_debug():
    warn('Pytest warning. Will be ignored.')
    debug(lambda: 'Debug message')
    with pytest.raises(AssertionError):
        assert False, 'Pytest error message. Will be ignored.'
    assert True



# Generated at 2022-06-22 15:00:03.945353
# Unit test for function debug
def test_debug():
    result = []
    def get_debug_message():
        result.append(1)
        return 'Debug message'

    debug(get_debug_message)
    assert result == [1]

    settings.debug = True
    import sys
    old_stderr = sys.stderr
    try:
        def stderr_mock(message):
            result.append(message)

        sys.stderr = stderr_mock
        debug(get_debug_message)

        assert result == [1, '\033[1;34m[debug]\033[0;39m Debug message\n']
    finally:
        sys.stderr = old_stderr
        settings.debug = False

# Generated at 2022-06-22 15:00:06.468390
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass\n'



# Generated at 2022-06-22 15:00:13.120499
# Unit test for function eager
def test_eager():
    def f1(a):
        return [x for x in range(a)]
    def f2(a):
        yield from range(a)
    assert f1(5) == [0, 1, 2, 3, 4]
    assert f2(5) == [0, 1, 2, 3, 4]
    assert eager(f1)(5) == [0, 1, 2, 3, 4]
    assert eager(f2)(5) == [0, 1, 2, 3, 4]


# Generated at 2022-06-22 15:00:14.977874
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 15:00:19.713030
# Unit test for function get_source
def test_get_source():
    def test_fn():
        return 'abc'

    def test2_fn():
        def inner_fn():
            return 'abc'
        return inner_fn
    assert get_source(test_fn) == 'return \'abc\''
    assert get_source(test2_fn) == 'return inner_fn'

# Generated at 2022-06-22 15:00:23.298202
# Unit test for function debug
def test_debug():
    global SETTINGS
    SETTINGS = settings.settings({'debug': True})
    debug(lambda: "HI")
    SETTINGS = settings.settings({'debug': False})
    debug(lambda: "HI")

# Generated at 2022-06-22 15:00:25.309005
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == '    pass'

# Generated at 2022-06-22 15:00:35.829983
# Unit test for function debug
def test_debug():
    messages.debug_message = ''

    def test_messages():
        messages.debug_message = 'hello'

    def test_get_message():
        return messages.debug_message

    debug(test_messages)
    assert messages.debug_message == 'hello'

    debug(test_get_message)
    assert messages.debug_message == 'hello'

# Generated at 2022-06-22 15:00:41.549404
# Unit test for function get_source
def test_get_source():
    def test():
        """
        This is docstring

        :return: None
        """
        a = 1
        return a

    assert get_source(test).split('\n') == [
        '"""',
        'This is docstring',
        '',
        ':return: None',
        '"""',
        'a = 1',
        'return a'
    ]

# Generated at 2022-06-22 15:00:44.218941
# Unit test for function eager
def test_eager():
    def test_fn() -> Iterable[int]:
        for i in range(5):
            yield i

    assert eager(test_fn)() == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:00:45.695623
# Unit test for function debug
def test_debug():
    def test_code():
        debug(lambda: 'test')
    return test_code



# Generated at 2022-06-22 15:00:49.538033
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert list(test_fn()) == [1, 2, 3]

# Generated at 2022-06-22 15:00:54.253840
# Unit test for function get_source
def test_get_source():
    def test_func():
        return 1

    def test_func_with_docstring():
        """Test docstring"""
        return 1
    assert get_source(test_func) == 'return 1'
    assert get_source(test_func_with_docstring) == 'return 1'

# Generated at 2022-06-22 15:00:59.712974
# Unit test for function get_source
def test_get_source():
    def a():
        return 1

    assert get_source(a) == 'return 1'

    def b(x):
        return x + 1

    assert get_source(b) == 'return x + 1'

    def c(x):
        def a():
            return 1

        return x + 1

    assert get_source(c) == '    def a():\n        return 1\n\n    return x + 1'

# Generated at 2022-06-22 15:01:02.705942
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello, world!')

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-22 15:01:06.911262
# Unit test for function get_source
def test_get_source():
    def f(a, b):
        def g():
            pass

    expected = '\n'.join(get_source(f).split('\n')[1:])
    assert expected == 'def g():\n    pass\n'

# Generated at 2022-06-22 15:01:09.555738
# Unit test for function get_source
def test_get_source():
    def test_function():
        return 1

    assert get_source(test_function) == 'return 1'



# Generated at 2022-06-22 15:01:19.271452
# Unit test for function get_source
def test_get_source():
    def func(x):
        return x

    assert get_source(func) == 'return x'

# Generated at 2022-06-22 15:01:24.632029
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        if 3 == 4:
            return 3
        else:
            return 2
    assert get_source(bar) == 'def bar():\n    if 3 == 4:\n        return 3\n    else:\n        return 2'

# Generated at 2022-06-22 15:01:26.876673
# Unit test for function get_source
def test_get_source():
    def func():
        return '1'

    assert get_source(func) == 'return "1"'

# Generated at 2022-06-22 15:01:36.550677
# Unit test for function debug
def test_debug():
    from pytest import raises
    from io import StringIO
    output = StringIO()
    strings = []
    for i in range(10):
        strings.append('Hello world' + str(i))
    for i in range(10):
        with raises(StopIteration):
            next(debug(lambda: strings[i]))
            next(debug(
                lambda: strings[i],
                output=output
            ))
    for i in range(10):
        assert output.getvalue() == ''
    try:
        settings.debug = True
        for i in range(10):
            next(debug(
                lambda: strings[i],
                output=output
            ))
        for i in range(10):
            assert output.getvalue() == messages.debug(strings[i])
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:01:42.722840
# Unit test for function debug
def test_debug():
    def test_function():
        return 'Hello'
    output = list(capture(debug, lambda: test_function()))
    assert output == []
    settings.debug = True
    output = list(capture(debug, lambda: test_function()))
    assert output == ['Hello']
    settings.debug = False


# Generated at 2022-06-22 15:01:44.663071
# Unit test for function get_source
def test_get_source():
    def foo(baz: int) -> int:
        return baz + 1

    assert get_source(foo) == 'return baz + 1'

# Generated at 2022-06-22 15:01:51.087627
# Unit test for function debug
def test_debug():
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = open('/dev/null', 'w')
    settings.debug = True
    debug(lambda: 'ok')
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    settings.debug = False
    passed = False
    try:
        debug(lambda: 'ok')
    except:
        passed = True
    assert passed, "test_debug() failed"

# Generated at 2022-06-22 15:01:57.706093
# Unit test for function get_source
def test_get_source():
    def foo():
        return "foo"

    def bar():
        def inner():
            return inner

        return inner

    def baz():
        def inner():
            return inner()

        return inner

    assert get_source(foo) == 'return "foo"'
    assert get_source(bar) == '    def inner():\n        return inner\n    \n    return inner'
    assert get_source(baz) == '    def inner():\n        return inner()\n    \n    return inner'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:01:59.552388
# Unit test for function eager
def test_eager():
    assert eager(range)(3) == [0, 1, 2]

# Generated at 2022-06-22 15:02:10.796047
# Unit test for function debug
def test_debug():
    print('>>>', 'test_debug', '<<<')
    import sys
    import io
    import pytest

    @debug
    def func():
        return 'test'
    out, err = sys.stdout, sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    settings.debug = True
    func()
    stdout = sys.stdout.getvalue().strip()
    stderr = sys.stderr.getvalue().strip()
    assert stdout == ''
    assert stderr == '[DEBUG] test'

    func()
    stdout = sys.stdout.getvalue().strip()
    stderr = sys.stderr.getvalue().strip()
    assert stdout == ''

# Generated at 2022-06-22 15:02:34.052146
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
        yield 2
        yield 3

    assert generator() == [1,2,3]

# Generated at 2022-06-22 15:02:37.347599
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]
    f = lambda x: iter(x)
    assert eager(f)(l) == l

# Generated at 2022-06-22 15:02:48.565538
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from py_backwards.conf import settings as mocked_settings
    from py_backwards.utils import messages as mocked_messages
    from unittest import TestCase

    class DebugTestCase(TestCase):
        def test_debug_enabled(self):
            mocked_settings.debug = True
            with patch.object(sys.stderr, 'write') as mocked_write:
                debug(lambda: 'test message')

            mocked_write.assert_called_with(mocked_messages.debug('test message') + '\n')
            mocked_settings.debug = False

        def test_debug_disabled(self):
            mocked_settings.debug = False
            with patch.object(sys.stderr, 'write') as mocked_write:
                debug(lambda: 'test message')

# Generated at 2022-06-22 15:02:50.751851
# Unit test for function get_source
def test_get_source():
    def get_source_test():
        pass

    assert get_source(get_source_test) == 'pass'



# Generated at 2022-06-22 15:02:56.093071
# Unit test for function debug
def test_debug():
    debug_log = ""

    def get_message():
        nonlocal debug_log
        debug_log = "debug"
        return ''

    from ..conf import settings
    settings.debug = True
    debug(get_message)
    assert debug_log == "debug"
    settings.debug = False
    debug(get_message)
    assert debug_log == "debug"

# Generated at 2022-06-22 15:03:03.656032
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from . import test_conf

    def get_message() -> str:
        return 'raw'

    debug(get_message)
    settings.debug = False
    debug(get_message)
    settings.debug = True
    with patch('sys.stderr') as stderr:
        debug(get_message)
        assert stderr.write.call_args[0][0] == messages.debug(get_message())
    settings.debug = test_conf.DEBUG

# Generated at 2022-06-22 15:03:14.291458
# Unit test for function get_source

# Generated at 2022-06-22 15:03:16.713218
# Unit test for function debug
def test_debug():
    for settings.debug in (True, False):
        debug(lambda: 'test')

# Generated at 2022-06-22 15:03:17.286584
# Unit test for function debug
def test_debug():
    pass

# Generated at 2022-06-22 15:03:21.027299
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert 'def test_function():\n    pass' == get_source(test_function)
    assert 'def test_function():\n    pass' == get_source(test_function)

# Generated at 2022-06-22 15:04:19.154476
# Unit test for function debug
def test_debug():
    output = sys.stdout
    try:
        import io
        sys.stdout = io.StringIO()
        settings.debug = True
        # should print to stdout
        debug(lambda: 'success')
        assert sys.stdout.getvalue().endswith(messages.debug('success') + '\n')
        sys.stdout = io.StringIO()
        settings.debug = False
        # should not print to stdout
        debug(lambda: 'success')
        assert sys.stdout.getvalue() == ''
    finally:
        sys.stdout = output



# Generated at 2022-06-22 15:04:20.422278
# Unit test for function eager
def test_eager():
    def get_generator() -> Iterable[int]:
        for i in range(3):
            yield i

    assert get_generator() == [0, 1, 2]

# Generated at 2022-06-22 15:04:23.749097
# Unit test for function eager
def test_eager():
    @eager
    def range_function(*args):
        return range(*args)
    result = range_function(10)
    assert result == list(range(10))
    assert isinstance(result, list)



# Generated at 2022-06-22 15:04:29.613151
# Unit test for function debug
def test_debug():
    get_message_call_counter = 0
    def get_message():
        nonlocal get_message_call_counter
        get_message_call_counter += 1
        return 'message source'

    from io import StringIO
    buffer = StringIO()
    old_stderr = sys.stderr
    sys.stderr = buffer

    settings.debug = False
    debug(get_message)
    assert get_message_call_counter == 0
    assert buffer.getvalue() == ''

    settings.debug = True
    debug(get_message)
    assert get_message_call_counter == 1
    assert buffer.getvalue().rstrip() == messages.debug('message source')

    sys.stderr = old_stderr
    buffer.close()

# Generated at 2022-06-22 15:04:32.116980
# Unit test for function eager
def test_eager():
    def foo(a):
        for i in range(2):
            yield i
    assert foo(1) is not None
    assert eager(foo)(1) == [0, 1]

# Generated at 2022-06-22 15:04:35.672340
# Unit test for function get_source
def test_get_source():
    def _test():
        if True:
            pass
    assert get_source(_test) == 'if True:\n    pass'

# Generated at 2022-06-22 15:04:39.104449
# Unit test for function eager
def test_eager():
    from itertools import chain

    @eager
    def chain_three(*args):
        return chain(*args)

    assert chain_three('a', 'bc', 'def') == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-22 15:04:41.484850
# Unit test for function get_source
def test_get_source():  # pragma: no cover
    def f():
        """f"""
        pass
    assert get_source(f) == '        pass'

# Generated at 2022-06-22 15:04:44.452410
# Unit test for function eager
def test_eager():
    @eager
    def generate():
        for i in range(5):
            yield i
    assert generate() == [i for i in range(5)]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:04:46.492905
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == ''

    def g():
        return 1

    assert get_source(g) == 'return 1'

# Generated at 2022-06-22 15:06:41.177611
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        if a == 0:
            return b
        return 1
    assert get_source(fn) == ('def fn(a, b):\n'
                              '    if a == 0:\n'
                              '        return b\n'
                              '    return 1')



# Generated at 2022-06-22 15:06:42.435349
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            baz()
    assert get_source(foo) == '    def bar():\n' \
        '        baz()'



# Generated at 2022-06-22 15:06:43.887164
# Unit test for function debug
def test_debug():
    message = 'Example message'

# Generated at 2022-06-22 15:06:45.153865
# Unit test for function get_source
def test_get_source():
    def test_func():
        return 'Test function'
    assert get_source(test_func) == 'def test_func():\n    return \'Test function\''



# Generated at 2022-06-22 15:06:46.577094
# Unit test for function eager
def test_eager():
    @eager
    def a():
        yield 1
        yield 2
        return

    assert(a() == [1, 2])

# Generated at 2022-06-22 15:06:54.327096
# Unit test for function eager
def test_eager():
    from py_backwards.core import testutils
    with testutils.assert_raises(ValueError) as error:
        @eager
        def fn(x: int) -> int:
            """This function has wrong type signature"""
            return range(x)

        fn(10)
    assert str(error) == 'Iterable is expected, int is not'

    @eager
    def fn(x: int) -> Iterable[int]:
        """This function should return list"""
        return range(x)

    assert fn(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert fn.__name__ == 'fn'

# Generated at 2022-06-22 15:06:57.897447
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'


# _assert is used as a placeholder in inverse assserts.
_assert = object()

# Generated at 2022-06-22 15:07:00.340067
# Unit test for function get_source
def test_get_source():
    """
    This should match the source code of this function
    """
    def test_fn():
        pass
    assert get_source(test_fn) == get_source.__doc__

# Generated at 2022-06-22 15:07:02.425200
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    assert get_source(function) == 'def function():\n    pass'

# Generated at 2022-06-22 15:07:06.286166
# Unit test for function debug
def test_debug():
    counter = 0

    def get_message():
        nonlocal counter
        counter += 1
        return "Raised {} times".format(counter)

    settings.debug = True
    debug(get_message)
    debug(get_message)
    assert counter == 2

    counter = 0
    settings.debug = False
    debug(get_message)
    debug(get_message)
    assert counter == 0

