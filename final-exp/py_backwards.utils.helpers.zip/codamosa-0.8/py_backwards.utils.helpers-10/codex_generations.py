

# Generated at 2022-06-22 14:58:17.385520
# Unit test for function get_source
def test_get_source():
    def foo(bar):
        print(bar)

    assert get_source(foo) == 'def foo(bar):\n    print(bar)'

# Generated at 2022-06-22 14:58:19.371217
# Unit test for function eager
def test_eager():
    def slow_generator(max_value):
        for i in range(max_value):
            yield i
    fast_generator = eager(slow_generator)
    assert fast_generator(3) == [0, 1, 2]

# Generated at 2022-06-22 14:58:22.013737
# Unit test for function eager
def test_eager():
    assert eager(list)(range(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 14:58:31.081708
# Unit test for function debug
def test_debug():
    debug_messages = []
    def _debug(*text):
        debug_messages.append(' '.join([str(message) for message in text]))

    def fake_settings():
        return Fake_settings()

    class Mock_debug:
        class __class__:
            def __init__(self, _debug):
                self._debug = _debug

            def debug(self, *text):
                self._debug(*text)

    mock_debug = Mock_debug(_debug)
    with patch.dict('sys.modules', zmq=mock_debug, py_backwards=fake_settings):
        debug(lambda: f'Debbuging thing {42}')
    assert debug_messages == ["32m[DEBUG] \x1b[0mDebbuging thing 42"]



# Generated at 2022-06-22 14:58:31.937452
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source)

# Generated at 2022-06-22 14:58:35.969288
# Unit test for function get_source
def test_get_source():
    def test_fn(a, b):
        """Test function"""
        return 2 * a + 2 * b
    assert get_source(test_fn) == \
        'def test_fn(a, b):\n' \
        '    """Test function"""\n' \
        '    return 2 * a + 2 * b'

# Generated at 2022-06-22 14:58:38.126551
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    source = get_source(fn)
    assert source == "def fn():\n    pass"

# Generated at 2022-06-22 14:58:39.846452
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    source = get_source(fn).strip()
    assert source == ('def fn():'
                      '\n    pass')

# Generated at 2022-06-22 14:58:48.518425
# Unit test for function debug
def test_debug():
    import io
    import sys
    from ..conf import settings

    settings.debug = True

    debug_message = "test"

    stderr = sys.stderr

    try:
        out = io.StringIO()
        sys.stderr = out
        debug(lambda: debug_message)
        output = out.getvalue().strip()
    finally:
        sys.stderr = stderr

    assert output == debug_message
    assert len(output) == len(debug_message)

# Generated at 2022-06-22 14:58:55.292734
# Unit test for function debug
def test_debug():
    messages.debug = lambda text: text + 'the end'
    buffer = io.StringIO()
    sys.stderr = buffer
    settings.debug = True

    # Unit test for function debug
    print("Unit test begins")
    debug(lambda: 'Unit test')
    assert buffer.getvalue() == 'Unit testthe end\n'

    settings.debug = False
    debug(lambda: 'Unit test')
    assert buffer.getvalue() == 'Unit testthe end\n'

    print("Unit test ends")

# Generated at 2022-06-22 14:59:07.786170
# Unit test for function debug
def test_debug():
    def f():
        debug(lambda: 'test')

    assert debug.__name__ == 'debug'
    assert f.__name__ == 'f'
    assert debug.__qualname__ == 'py_backwards.utils.debug'
    assert f.__qualname__ == 'test_debug.<locals>.f'
    assert debug.__module__ == f.__module__ == __name__
    assert debug.__doc__ == f.__doc__ == None
    assert debug.__annotations__ == f.__annotations__ == {}
    assert debug.__defaults__ == f.__defaults__ == None
    assert debug.__code__.co_filename == f.__code__.co_filename == __file__
    assert debug.__code__.co_name == 'debug'
    assert f.__code__.co

# Generated at 2022-06-22 14:59:09.874778
# Unit test for function get_source
def test_get_source():
    def fn() -> None:
        pass

    assert get_source(fn) == getsource(fn)

# Generated at 2022-06-22 14:59:12.032656
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2

    assert test() == [1, 2]

# Generated at 2022-06-22 14:59:14.278995
# Unit test for function get_source
def test_get_source():
    def lala():
        pass
    assert get_source(lala) == 'def lala():\n    pass'

# Generated at 2022-06-22 14:59:15.281764
# Unit test for function get_source
def test_get_source():
    def fn():
        pass


# Generated at 2022-06-22 14:59:18.852860
# Unit test for function debug
def test_debug():
    def get_message():
        return "Debugging"
    TestCallable.from_callables(
        debug, (get_message,)
    ).assert_output(
        "", "", ("Debugging\n",)
    )


# Generated at 2022-06-22 14:59:24.230343
# Unit test for function get_source
def test_get_source():
    def func():
        """This docstring is not part of source code."""
        def nested():
            """Nested function is also ignored."""
        return nested()

    assert get_source(func) == 'def nested():\n    """Nested function is also ignored."""'

# Generated at 2022-06-22 14:59:26.824394
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
    l = eager(f)()
    assert l == [1, 2]
    assert l == [1, 2]

# Generated at 2022-06-22 14:59:30.187099
# Unit test for function get_source
def test_get_source():
    @wraps(get_source)
    def get_source(fn):
        return fn
    assert get_source(get_source) == get_source
    assert get_source(test_get_source) == get_source



# Generated at 2022-06-22 14:59:32.237681
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "Hello world")
    # settings.debug is set back to False in test_runner.py


# Generated at 2022-06-22 14:59:36.993594
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'ok')
    settings.debug = False



# Generated at 2022-06-22 14:59:40.824768
# Unit test for function debug
def test_debug():
    old_debug = settings.debug
    settings.debug = True
    try:
        assert not debug(lambda: 'test message')
    finally:
        settings.debug = old_debug



# Generated at 2022-06-22 14:59:45.767080
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
        return bar

    def baz():
        def foo():
            def bar():
                pass
            return bar
        return foo

    assert get_source(foo) == 'def bar():\n    pass\n'
    assert get_source(baz) == 'def foo():\n    def bar():\n        pass\n    return bar\n'

# Generated at 2022-06-22 14:59:48.754539
# Unit test for function get_source
def test_get_source():
    def get_square(n):
        return n * n
    assert get_source(get_square) == "return n * n"

# Generated at 2022-06-22 14:59:51.249095
# Unit test for function get_source
def test_get_source():
    def test(a: int, b: int = 1) -> int:
        return a


# Generated at 2022-06-22 14:59:53.823937
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        return a + b

    assert get_source(test_function) == 'return a + b'

# Generated at 2022-06-22 14:59:55.733641
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 14:59:57.402921
# Unit test for function get_source
def test_get_source():
    def f(x, y):
        return x + y

    assert get_source(f) == "return x + y"

# Generated at 2022-06-22 14:59:59.112471
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        return a + b

    assert get_source(func) == 'return a + b'


# Generated at 2022-06-22 15:00:00.188124
# Unit test for function get_source
def test_get_source():
    assert "    return 10 + 20" in get_source(lambda: 10 + 20)

# Generated at 2022-06-22 15:00:06.624723
# Unit test for function get_source
def test_get_source():
    def example():
        x = 1

    assert get_source(example).strip() == 'x = 1'

# Generated at 2022-06-22 15:00:09.168991
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == "assert get_source(test_get_source) == '''assert get_source(test_get_source) == ..."

# Generated at 2022-06-22 15:00:15.345116
# Unit test for function debug
def test_debug():
    debug_string = "This is a debug string"
    settings.debug = False
    with patch('sys.stderr', new_callable=StringIO) as fake_stderr:
        debug(lambda: debug_string)
        assert fake_stderr.getvalue() == ""
    settings.debug = True
    with patch('sys.stderr', new_callable=StringIO) as fake_stderr:
        debug(lambda: debug_string)
        assert fake_stderr.getvalue() == messages.debug(debug_string) + "\n"



# Generated at 2022-06-22 15:00:18.102767
# Unit test for function get_source
def test_get_source():

    def func():
        a = 1
        return a

    assert get_source(func) == "a = 1\nreturn a"



# Generated at 2022-06-22 15:00:21.168597
# Unit test for function debug
def test_debug():
    with settings.using(debug=True):
        i = 0
        debug(lambda: 'before {}'.format(i))
        i = 1
        debug(lambda: 'after {}'.format(i))

# Generated at 2022-06-22 15:00:22.910186
# Unit test for function get_source
def test_get_source():
    def fun(): pass
    assert get_source(fun) == 'pass'

# Generated at 2022-06-22 15:00:26.348826
# Unit test for function eager
def test_eager():
    from typing import List

    @eager
    def lazy() -> Iterable[int]:
        for i in range(10):
            yield i

    assert isinstance(lazy(), List)

# Generated at 2022-06-22 15:00:32.249224
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        def baz():
            pass

    def baz(a):
        pass

    def quux():
        """To be or not to be."""

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'
    assert get_source(baz) == 'def baz(a):\n    pass'
    assert get_source(quux) == 'def quux():\n    """To be or not to be."""'

# Generated at 2022-06-22 15:00:42.175786
# Unit test for function debug
def test_debug():
    debug_messages = []

    def get_message():
        debug_messages.append('Message')
        return 'Message'

    debug(get_message)
    assert debug_messages == ['Message']
    debug(get_message)
    assert debug_messages == ['Message', 'Message']
    settings.debug = False
    debug(get_message)
    assert debug_messages == ['Message', 'Message']
    settings.debug = True
    debug(get_message)
    assert debug_messages == ['Message', 'Message', 'Message']



# Generated at 2022-06-22 15:00:43.454342
# Unit test for function get_source
def test_get_source():
    def foo():
        return 8
    assert get_source(foo) == 'return 8'

# Generated at 2022-06-22 15:01:03.251007
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import mock
    from .. import conf
    from . import messages

    class FakeModule:
        class Settings:
            debug = False

        def __getattr__(self, item):
            return self.Settings()

    conf.conf = FakeModule()
    stderr = mock.patch('sys.stderr', new_callable=StringIO)

    with stderr as mocked:
        debug(lambda: 'some message')
        assert mocked.getvalue() == ''

    conf.conf = FakeModule()
    conf.conf.Settings.debug = True

    with stderr as mocked:
        debug(lambda: 'some message')
        assert mocked.getvalue() == messages.debug('some message') + '\n'

    conf.conf = FakeModule()
    conf.conf.Settings

# Generated at 2022-06-22 15:01:06.268636
# Unit test for function debug
def test_debug():
    settings.debug = False
    try:
        assert debug(lambda: 'debug') is None
    finally:
        settings.debug = True



# Generated at 2022-06-22 15:01:10.833852
# Unit test for function eager
def test_eager():
    def fn_returning_generator(a, b):
        for i in range(a, b):
            yield i

    assert eager(fn_returning_generator)(0, 3) == [0, 1, 2]
    assert isinstance(fn_returning_generator(0, 3), iter)

# Generated at 2022-06-22 15:01:21.356734
# Unit test for function get_source

# Generated at 2022-06-22 15:01:27.066821
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch('sys.stderr') as mock_stderr:
        with settings(debug=True):
            debug(lambda: 'Some debug message')
            mock_stderr.write.assert_called_once_with(
                messages.debug('Some debug message') + '\n')



# Generated at 2022-06-22 15:01:31.833969
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        stdout = sys.stderr = io.StringIO()
        debug(lambda: 'Some message')
        assert stdout.getvalue() == messages.debug('Some message')
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False


# Generated at 2022-06-22 15:01:33.518504
# Unit test for function eager
def test_eager():
    from ..conf import settings

    settings.debug = True
    counter = 0
    settings.debug = False
    li = [1, 2, 3]
    res = eager(li)
    settings.debug = True
    assert res == []

# Generated at 2022-06-22 15:01:37.756546
# Unit test for function debug
def test_debug():
    class Test:
        def __init__(self) -> None:
            self.value = 0

        def increment(self) -> None:
            self.value += 1

    test = Test()

    def get_message() -> str:
        return 'Adding 1 to {}'.format(test.value)

    test.increment()
    debug(get_message)



# Generated at 2022-06-22 15:01:40.210651
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function).strip() == 'pass'

# Generated at 2022-06-22 15:01:43.623548
# Unit test for function eager
def test_eager():
    @eager
    def generator(lst):
        for item in lst:
            yield item

    x = generator(range(5))
    assert isinstance(x, list)
    assert x == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:01:57.093825
# Unit test for function debug
def test_debug():
    assert not settings.debug

    call_count = {'count': 0}

    def get_message():
        call_count['count'] += 1
        return 'some message'

    debug(get_message)

    assert call_count['count'] == 0

    settings.debug = True

    debug(get_message)

    assert call_count['count'] == 1

# Generated at 2022-06-22 15:02:02.467592
# Unit test for function eager
def test_eager():
    from py_backwards.transformers.tests.test_transformers import SampleCallsRecorder
    recorder = SampleCallsRecorder(3)
    result = eager(recorder.fn)()
    recorder.check_calls()
    assert result == [1, 2, 3]


# Generated at 2022-06-22 15:02:04.481534
# Unit test for function get_source
def test_get_source():
    def foo(a):
       return a

    assert get_source(foo) == 'return a'

# Generated at 2022-06-22 15:02:07.932699
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert list(foo()) == [1, 2, 3]
    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-22 15:02:10.381754
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'unseen')
    settings.debug = True
    debug(lambda: 'seen')
    settings.debug = False



# Generated at 2022-06-22 15:02:22.355575
# Unit test for function get_source
def test_get_source():
    source_fn_kwargs_error = '''
    def get_source_with_kwargs_error(self):
        def f(a: int, b: int, c: int, d: int, e: int, f: int, g: int, h: int, i: int, j: int, k: int, l: int,
              m: int, n: int, o: int, p: int, q: int, r: int, s: int, t: int, u: int, v: int, w: int, x: int,
              y: int, z: int = 1, *, **kwargs):
            if True:  # pragma: no cover
                return a
        return f
    '''

# Generated at 2022-06-22 15:02:24.262993
# Unit test for function get_source
def test_get_source():
    def test(a, b):
        return a
    assert get_source(test) == 'return a'

# Generated at 2022-06-22 15:02:26.088819
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == '    pass'



# Generated at 2022-06-22 15:02:31.405914
# Unit test for function get_source
def test_get_source():
    def example_func():
        foo = 1 + 2
        return str(foo)

    # when we call this function, a line
    #
    #     source_lines = getsource(fn).split('\n')
    #
    # is executed. Subsequently, the first line gets added some padding,
    # which depends on the tree structure of the source file.
    # This is problematic, because it means that we cannot hardcode the result
    # of calling get_source in the unit test
    # - we would need to hardcode the tree structure of the file,
    # which is not desirable.
    #
    # Instead, we will assert that there is only one line with padding,
    # and remove only the padding from that line.
    # This way, the unit test can remain relatively insensitive to
    # changes in the codebase.

# Generated at 2022-06-22 15:02:34.897461
# Unit test for function debug
def test_debug():
    def test_function():
        debug(lambda: "This is a unit test for the debug function")
    test_function()
test_debug()

# Generated at 2022-06-22 15:02:48.605637
# Unit test for function get_source
def test_get_source():
    def function():
        def nested_function():
            return 2 + 2

        return nested_function()

    assert get_source(function) == """def nested_function():
    return 2 + 2

return nested_function()"""

# Generated at 2022-06-22 15:02:54.934975
# Unit test for function debug
def test_debug():
    messages.debug = lambda get_message: '_DEBUG_' + get_message()

    def test_function():
        return None

    settings.debug = True
    assert debug(lambda: get_source(test_function)) is None
    assert not debug(lambda: sys.stderr.getvalue())

    settings.debug = False
    assert debug(lambda: get_source(test_function)) is None
    assert not debug(lambda: sys.stderr.getvalue())



# Generated at 2022-06-22 15:03:02.384766
# Unit test for function debug
def test_debug():
    import pytest
    import io
    from unittest.mock import patch
    from ..conf import settings
    with patch('sys.stderr', new=io.StringIO()) as mock_stderr:
        settings.debug = True
        debug(lambda: 'Hello')
        assert mock_stderr.getvalue().strip() == messages.debug('Hello')
        settings.debug = False
        debug(lambda: 'Hello')
        assert mock_stderr.getvalue().strip() == messages.debug('Hello')

# Generated at 2022-06-22 15:03:03.547802
# Unit test for function eager
def test_eager():
    def test(x: int) -> Iterable[int]:
        for i in range(x):
            yield i

    assert eager(test)(10) == list(test(10))
    assert eager(test)(0) == list(test(0))

# Generated at 2022-06-22 15:03:05.520885
# Unit test for function eager
def test_eager():
    lst = [1]

    @eager
    def a():
        for i in lst:
            yield i
    assert a() == [1]

# Generated at 2022-06-22 15:03:08.293974
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1
        return a

    assert get_source(test) == "a = 1\nreturn a"

# Generated at 2022-06-22 15:03:14.844674
# Unit test for function get_source
def test_get_source():
    def test():
        return 1

    assert get_source(test) == 'return 1'

    def test2(a):
        if a == 2:
            return 1

    assert get_source(test2) == 'if a == 2:\n    return 1'

    def test3():
        try:
            return 1
        except Exception:
            return 0

    assert get_source(test3) == ('try:\n    return 1\n'
                                 'except Exception:\n    return 0')

# Generated at 2022-06-22 15:03:18.670304
# Unit test for function eager
def test_eager():
    from ..conf import settings
    settings.debug = True
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-22 15:03:21.805896
# Unit test for function get_source
def test_get_source():
    def test():
        """This is a test."""
        pass

# Generated at 2022-06-22 15:03:22.991588
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

# Generated at 2022-06-22 15:03:49.879048
# Unit test for function get_source
def test_get_source():
    def fn():
        """This is function documentation.

        Some longer documentation.

        """
        import os
        import sys

        x = 1


# Generated at 2022-06-22 15:03:51.333368
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        return a + b


# Generated at 2022-06-22 15:03:53.633594
# Unit test for function get_source
def test_get_source():
    def py_backwards_func():
        pass

    def source():
        pass

    assert get_source(source) == get_source(py_backwards_func)

# Generated at 2022-06-22 15:03:56.045256
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Some message')
    settings.debug = False
    debug(lambda: 'Some message')

# Generated at 2022-06-22 15:04:02.585787
# Unit test for function debug
def test_debug():
    class MockStream:
        def __init__(self):
            self.content = ''

        def write(self, content):
            self.content += content

    with open(os.devnull, 'w') as sys.stderr:
        message = 'message'
        debug(lambda: message)
        assert '' == sys.stderr.content

        settings.debug = True
        mock_stream = MockStream()
        sys.stderr = mock_stream
        debug(lambda: message)
        assert messages.debug(message) == sys.stderr.content

# Generated at 2022-06-22 15:04:05.316966
# Unit test for function eager
def test_eager():
    import pytest

    @eager
    def xrange(n):
        i = 0
        while i < n:
            yield i
            i += 1

    assert xrange(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-22 15:04:07.969952
# Unit test for function get_source
def test_get_source():
    def foo():
        """Docstring."""
        bar = 1

    assert get_source(foo) == '"""Docstring."""\nbar = 1'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:04:10.655301
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    debug(lambda: 'magick')
    def magic():
        debug(lambda: 'test')
    magic()



# Generated at 2022-06-22 15:04:14.279855
# Unit test for function get_source
def test_get_source():
    print(get_source(test_get_source))

    assert get_source(test_get_source) == '''
print(get_source(test_get_source))

assert get_source(test_get_source) == '''

# Generated at 2022-06-22 15:04:17.514126
# Unit test for function get_source
def test_get_source():
    @get_source
    def foo():
        # Comment
        a = 1
        b = 2

    foo
    assert foo == '''# Comment
a = 1
b = 2'''

# Generated at 2022-06-22 15:04:45.781261
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    pattern = re.compile(r'^def foo\(\)')
    assert pattern.match(get_source(foo)) != None



# Generated at 2022-06-22 15:04:47.792286
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
    assert foo() is foo()
    assert eager(foo)() == [1, 2]
    assert eager(foo)() == [1, 2]


# Generated at 2022-06-22 15:04:50.860094
# Unit test for function get_source
def test_get_source():
    def get_source_test():\
        print("unit test")
    assert get_source(get_source_test) == "print(\"unit test\")"

# Generated at 2022-06-22 15:04:54.669638
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Hello %s' % 'World'

    settings.debug = False
    # Should not raise
    debug(get_message)

    settings.debug = True
    # Should not raise
    debug(get_message)

# Generated at 2022-06-22 15:04:57.485125
# Unit test for function get_source
def test_get_source():
    def test():
        debug(lambda: 'a')
        print(1)

    assert get_source(test) == 'debug(lambda: \'a\')\nprint(1)\n'

# Generated at 2022-06-22 15:04:59.492176
# Unit test for function debug
def test_debug():
    @debug
    def get_message():
        return 'message'
    get_message()



# Generated at 2022-06-22 15:05:03.449815
# Unit test for function eager
def test_eager():
    def my_generator():
        yield 1
        yield 2
        yield 3

    my_list = eager(my_generator)()

    assert isinstance(my_list, list)
    assert my_list == [1, 2, 3]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:05:04.369083
# Unit test for function debug
def test_debug():
    debug(lambda: 'test message')

# Generated at 2022-06-22 15:05:06.322350
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-22 15:05:09.310781
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        for i in range(5):
            yield i

    assert test_fn() == [0, 1, 2, 3, 4]



# Generated at 2022-06-22 15:06:16.658245
# Unit test for function debug
def test_debug():
    msg = 'test message'

    class PrintWrapper:
        """Wrapper for sys.stderr.write() for debug message testing."""
        def __init__(self) -> None:
            self.captured = None

        def __call__(self, value: str) -> None:
            self.captured = value

    old_print = sys.stderr.write

    for debug_mode in [True, False]:
        wrapper = PrintWrapper()
        sys.stderr.write = wrapper
        settings.debug = debug_mode
        debug(lambda: msg)
        sys.stderr.write = old_print
        if debug_mode:
            assert wrapper.captured.strip() == msg
        else:
            assert wrapper.captured is None



# Generated at 2022-06-22 15:06:17.754787
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'

# Generated at 2022-06-22 15:06:18.776439
# Unit test for function get_source
def test_get_source():
    def f():
        pass

# Generated at 2022-06-22 15:06:22.295898
# Unit test for function get_source
def test_get_source():
    def a():
        return 1

    assert get_source(a) == 'return 1'
    print('Success!')


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:06:26.560760
# Unit test for function eager
def test_eager():
    @eager
    def call_eager():
        yield 'foo'
    assert(call_eager()==['foo'])
    def call_eager2():
        yield 'foo'
    assert(call_eager2()!=['foo'])

test_eager()
        

# Generated at 2022-06-22 15:06:32.290517
# Unit test for function debug
def test_debug():
    from unittest import mock
    from .conf import settings

    with mock.patch('sys.stderr') as stderr:
        settings.debug = True
        debug(lambda: 'foobar')
        assert stderr.write.call_args[0][0] == 'Warn: foobar\n'

    with mock.patch('sys.stderr') as stderr:
        settings.debug = False
        debug(lambda: 'foobar')
        assert stderr.write.call_args is None



# Generated at 2022-06-22 15:06:33.563482
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-22 15:06:36.033651
# Unit test for function get_source
def test_get_source():
    def test(): pass
    assert get_source(test) == 'pass'

    def test2():
        a = 1
        b = 2
        c = 3

    assert get_source(test2) == 'a = 1\nb = 2\nc = 3'

# Generated at 2022-06-22 15:06:44.955541
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'def test_get_source():\n' \
                                         '    assert get_source(test_get_source) == \\\n' \
                                         '        \'def test_get_source():\\n\' \\\n' \
                                         '        \'    assert get_source(test_get_source) == \\\' \\ \\\n' \
                                         '        \'        \\\'def test_get_source():\\\\n\\\' \\\\\\ \\\' \\ \\\n' \
                                         '        \'        \\\'        \\\'def test_get_source():\\\\n\\\\\'' \
                                         ' \\\\\\\\ \\\' \\ \\\n' \
                                         '        \'        \\\'                \\\'def test_get_source():' \
                                        

# Generated at 2022-06-22 15:06:46.133348
# Unit test for function get_source
def test_get_source():
    def function(x):
        return 1

    assert get_source(function) == 'return 1'

# Generated at 2022-06-22 15:07:53.002529
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-22 15:07:55.415076
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        for i in range(5):
            yield i

    assert foo() == eager(foo)()

# Generated at 2022-06-22 15:07:57.902746
# Unit test for function debug
def test_debug():
    # pylint: disable=unused-variable
    @debug
    def get_message():
        return 'test message'
    assert get_message.__name__ == 'get_message'



# Generated at 2022-06-22 15:08:03.430192
# Unit test for function get_source
def test_get_source():
    test_src_code = '''
        def foo():
            pass

        def bar():
            pass
        '''

    def foo():
        pass

    def bar():
        pass

    file_like_object = StringIO(test_src_code)
    sys.stdin = file_like_object
    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    pass'
    file_like_object.close()
    sys.stdin = sys.__stdin__

# Generated at 2022-06-22 15:08:05.831240
# Unit test for function eager
def test_eager():
    func = eager(range)
    result = func(10)
    assert isinstance(result, list)
    assert len(result) == 10
    assert result == list(range(10))

# Generated at 2022-06-22 15:08:12.515257
# Unit test for function get_source
def test_get_source():
    def fn():
        def nested_fn():
            return 'value'

        assert nested_fn() == 'value'

    assert get_source(fn) == '\n'.join([
        'def nested_fn():',
        '    return \'value\'',
        '',
        'assert nested_fn() == \'value\''])


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:08:17.127986
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from contextlib import contextmanager
    from io import StringIO
    with settings(debug=True):
        with debug_io() as io:
            debug(lambda: 'hi')

        assert 'hi' in io.getvalue()

    with settings(debug=False):
        with debug_io() as io:
            debug(lambda: 'hi')

        assert 'hi' not in io.getvalue()

