

# Generated at 2022-06-22 14:58:52.416270
# Unit test for function eager
def test_eager():
    def f(*args, **kwargs):
        for a in args: yield a
        for k, v in kwargs.items(): yield k
        for v in kwargs.values(): yield v

    fn = eager(f)
    assert fn(1, 2, 3, a=4, b=5) == [1, 2, 3, 'a', 'b', 4, 5]

# Generated at 2022-06-22 14:58:57.656627
# Unit test for function debug
def test_debug():
    class Test:
        _msg = 'foo'
        _counter = 0

        def get_msg(self) -> str:
            self._counter += 1
            return self._msg

        def assert_called(self) -> bool:
            return self._counter == 1

    test = Test()
    debug(test.get_msg)
    assert test.assert_called()

    settings.debug = True
    debug(test.get_msg)
    assert test.assert_called()



# Generated at 2022-06-22 14:59:08.168351
# Unit test for function debug
def test_debug():
    import sys

    class FakeStdErr:
        def __init__(self):
            self.calls = []

        def write(self, message: str) -> None:
            self.calls.append(message)

    fake_stderr = FakeStdErr()
    captured_stderr = sys.stderr
    sys.stderr = fake_stderr
    fake_debug_message = 'message'
    debug(lambda: fake_debug_message)

# Generated at 2022-06-22 14:59:11.358811
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Hi')
        assert 'Hi' == messages.debug('Hi')
    finally:
        settings.debug = False



# Generated at 2022-06-22 14:59:16.804453
# Unit test for function get_source
def test_get_source():
    def function1():
        '''
        This is the important
        doc string.
        '''

        def function2():
            pass

    assert """def function1():
    '''
    This is the important
    doc string.
    '''

    def function2():
        pass
""" == get_source(function1)

# Generated at 2022-06-22 14:59:20.584564
# Unit test for function get_source
def test_get_source():
    def f(a, b, c=1, *args, **kwargs):
        pass
    source_code = """
        def f(a, b, c=1, *args, **kwargs):
    pass
""".lstrip()
    assert get_source(f) == source_code

# Generated at 2022-06-22 14:59:23.106063
# Unit test for function get_source
def test_get_source():
    def foo(x):
        return 5

    assert get_source(foo) == 'return 5'

# Generated at 2022-06-22 14:59:24.581113
# Unit test for function eager
def test_eager():
    @eager
    def bar():
        yield 1
    assert bar() == [1]

# Generated at 2022-06-22 14:59:31.050415
# Unit test for function debug
def test_debug():
    debug_message = "This is a debug message.\nIt shouldn't be shown"

    def get_message():
        return debug_message

    import sys
    original_stderr = sys.stderr
    sys.stderr = open('/tmp/py_backwards_unittest', 'w')

    try:
        debug(get_message)
        assert sys.stderr.closed
    finally:
        sys.stderr.close()
        sys.stderr = original_stderr

# Generated at 2022-06-22 14:59:32.983768
# Unit test for function eager
def test_eager():
    from typing import Iterable, List

    fn = lambda: iter([1, 2, 3])
    assert callable(fn())

    wrapped = eager(fn)
    assert isinstance(wrapped(), List)

# Generated at 2022-06-22 14:59:38.721240
# Unit test for function get_source
def test_get_source():
    def f():
        print('a')
        # comment
        print('b')
    source = get_source(f)
    assert source == """print('a')
    # comment
    print('b')"""



# Generated at 2022-06-22 14:59:40.824203
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'



# Generated at 2022-06-22 14:59:43.015687
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]



# Generated at 2022-06-22 14:59:46.230470
# Unit test for function get_source
def test_get_source():
    def get_source_1():
        def test_function():
            pass

        return get_source(test_function)

    assert get_source_1() == 'def test_function():\n    pass'

    def test_function_2():
        return 1

    assert get_source(test_function_2) == 'return 1'



# Generated at 2022-06-22 14:59:51.601767
# Unit test for function get_source
def test_get_source():
    def f(a, b, c='c_value'):
        return a + b + c
    assert get_source(f) == ('def f(a, b, c=\'c_value\'):\n'
                             '    return a + b + c')



# Generated at 2022-06-22 14:59:53.778183
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(3):
            return i
    assert eager(foo)() == [foo()]

# Generated at 2022-06-22 14:59:56.369665
# Unit test for function get_source
def test_get_source():
    source = get_source(get_source)
    assert source.startswith('def get_source(fn: Callable[..., Any]) -> str:')



# Generated at 2022-06-22 14:59:57.819168
# Unit test for function get_source
def test_get_source():
    def foo():
        print('Hello')

    assert get_source(foo) == "print('Hello')"



# Generated at 2022-06-22 14:59:59.816267
# Unit test for function debug
def test_debug():
    settings.debug = False

    def get_message():
        return 'It works'

    debug(get_message)

    settings.debug = True
    debug(get_message)



# Generated at 2022-06-22 15:00:03.532591
# Unit test for function debug
def test_debug():
    called = False
    def get_message():
        nonlocal called
        called = True
        return 'test'
    called = False
    debug(get_message)
    assert called



# Generated at 2022-06-22 15:00:08.878118
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f).strip() == 'pass'

    def g():
        if True:
            pass

    assert get_source(g).strip() == 'if True:\n    pass'


# Generated at 2022-06-22 15:00:13.467927
# Unit test for function get_source
def test_get_source():  # type: ignore
    from py_backwards.core import get_source
    from inspect import getsource
    from typing import Callable
    from .decorators import var_store
    def test():  # type: ignore
        var_store.in_decorated_function = False
    assert get_source(test) == getsource(test)

# Generated at 2022-06-22 15:00:15.395015
# Unit test for function get_source
def test_get_source():
    def fn() -> int:
        return 1 + 2

    assert get_source(fn) == 'return 1 + 2'

# Generated at 2022-06-22 15:00:18.580391
# Unit test for function get_source
def test_get_source():
    def test_fn(a, b):
        x = 1
        y = 2
        if x:
            return sum(a, b)


# Generated at 2022-06-22 15:00:21.267853
# Unit test for function get_source
def test_get_source():
    @does_nothing
    def function_source():
        pass

    assert get_source(function_source) == "def function_source():\n\tpass"

# Generated at 2022-06-22 15:00:23.010665
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

# Generated at 2022-06-22 15:00:25.981629
# Unit test for function get_source
def test_get_source():
    source = get_source(get_source)
    assert 'def get_source(fn: Callable[..., Any]) -> str:' in source

# Generated at 2022-06-22 15:00:30.193850
# Unit test for function get_source
def test_get_source():
    def source_function():
        """This is docstring
        of source function.
        """
        print('  This is first line')
        print(' And this is second line')

    expression = '\s*def source_function'
    assert re.match(expression, get_source(source_function))

# Generated at 2022-06-22 15:00:31.956305
# Unit test for function eager
def test_eager():
    import pytest
    assert eager(lambda: range(3))() == [0, 1, 2]


# Generated at 2022-06-22 15:00:36.770073
# Unit test for function eager
def test_eager():
    def gen(n):
        for i in range(n):
            yield i

    x = eager(gen)(3)
    assert x == [0, 1, 2]

# Generated at 2022-06-22 15:00:45.664593
# Unit test for function get_source
def test_get_source():
    def add(a: int, b: int) -> int:
        """Returns a + b."""
        return a + b


    def mul(a: float, b: float) -> float:
        """Returns a * b."""
        return a * b

    assert get_source(add) == 'return a + b'
    assert get_source(mul) == 'return a * b'

# Generated at 2022-06-22 15:00:49.070418
# Unit test for function eager
def test_eager():
    def fn():
        for i in range(3):
            yield i
    assert eager(fn)() == [0, 1, 2]



# Generated at 2022-06-22 15:00:51.888672
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    assert get_source(function) == 'def function():\n    pass'



# Generated at 2022-06-22 15:00:54.109480
# Unit test for function get_source
def test_get_source():
    def test(a, b):
        return a + b


# Generated at 2022-06-22 15:00:58.469346
# Unit test for function get_source
def test_get_source():
    def x():
        pass

    assert get_source(x) == 'def x():\n    pass'
    assert get_source(test_get_source) == 'def test_get_source():\n    def x():\n        pass\n\n    assert get_source(x) == \'def x():\\n    pass\''

# Generated at 2022-06-22 15:01:01.013028
# Unit test for function get_source
def test_get_source():
    def foo():
        "baz"
        pass

    assert get_source(foo) == 'def foo():\n    "baz"\n    pass'



# Generated at 2022-06-22 15:01:07.668761
# Unit test for function eager
def test_eager():
    class A:
        @eager
        def empty(self):
            return ()

        @eager
        def non_empty(self):
            return (1, 2, 3)

    assert isinstance(A().empty(), list)
    assert isinstance(A().non_empty(), list)
    assert A().empty() == []
    assert A().non_empty() == [1, 2, 3]


# Generated at 2022-06-22 15:01:18.454071
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from ..testing.unittest_backend import unittest_backend as unittest

    class _TestHideStderr(object):
        def __enter__(self) -> None:
            self.stderr = sys.stderr
            sys.stderr = self.test_stderr = io.StringIO()

        def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
            sys.stderr = self.stderr

    class TestDebug(unittest.TestCase):
        def setUp(self) -> None:
            self.stderr = sys.stderr
            sys.stderr = self.test_stderr = io.StringIO()

# Generated at 2022-06-22 15:01:19.968010
# Unit test for function get_source
def test_get_source():
    def func():
        pass


# Generated at 2022-06-22 15:01:28.836059
# Unit test for function debug
def test_debug():
    import unittest.mock as mock

    with mock.patch('sys.stderr') as stderr:
        debug(lambda: 'debug message')
        assert stderr.write.called
        (_, (output,), _), = stderr.write.call_args_list
        assert 'debug message' in output

    with mock.patch.object(settings, 'debug', False):
        with mock.patch('sys.stderr') as stderr:
            debug(lambda: 'debug message')
            assert not stderr.write.called



# Generated at 2022-06-22 15:01:40.172712
# Unit test for function debug
def test_debug():
    standard_output = sys.stdout
    sys.stdout = sys.stderr
    from io import StringIO

    # check that nothing is printed when settings.debug is set to False
    settings.debug = False
    debug(lambda: 'just an example')
    # check that something is printed when settings.debug is set to True
    settings.debug = True
    old_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        debug(lambda: 'just an example')
    finally:
        sys.stdout = old_stdout
    assert 'just an example' in out.getvalue()


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-22 15:01:42.038878
# Unit test for function debug
def test_debug():
    message = "test_debug called"
    debug(lambda: message)
    assert settings.debug



# Generated at 2022-06-22 15:01:45.761887
# Unit test for function get_source
def test_get_source():

    import inspect
    import pkg_resources

    def foo(a, b=5):
        return a + b

    assert get_source(foo) == inspect.getsource(foo)

    assert get_source(pkg_resources) == inspect.getsource(pkg_resources)



# Generated at 2022-06-22 15:01:47.335148
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-22 15:01:51.659055
# Unit test for function get_source
def test_get_source():
    def source_method():
        """
        This is method I'm testing.
        """
        pass

    expected_source = """
        This is method I'm testing.
        """
    debug(lambda: get_source(source_method))
    assert get_source(source_method) == expected_source



# Generated at 2022-06-22 15:01:54.652075
# Unit test for function get_source
def test_get_source():
    def function():
        var = 1
        print(var)

    assert get_source(function) == "var = 1\nprint(var)\n"


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:01:57.193248
# Unit test for function get_source
def test_get_source():
    def f1():
        def f():
            a = 1
            b = 2
        return f
    assert get_source(f1) == """def f():
    a = 1
    b = 2
""".strip()

# Generated at 2022-06-22 15:02:06.429746
# Unit test for function debug
def test_debug():
    import pytest
    from ..conf import settings

    settings.debug = True

    messages_made_in_debug=[]
    def make_message():
        messages_made_in_debug.append('message')
        return 'made message'

    debug(make_message)
    assert 'made message' in str(sys.stderr)
    assert 'message' in messages_made_in_debug

    with pytest.raises(AssertionError):
        debug(make_message)
        assert 'made message' in str(sys.stderr)
        assert 'message' in messages_made_in_debug



# Generated at 2022-06-22 15:02:08.025491
# Unit test for function get_source
def test_get_source():
    def fun():
        pass

    assert get_source(fun) == 'def fun():'

# Generated at 2022-06-22 15:02:10.021844
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function)[0] == 'd'



# Generated at 2022-06-22 15:02:29.413674
# Unit test for function debug
def test_debug():
    def _assert_debug_is_enabled():
        debug(lambda: 'Hello, world!')

    def _assert_debug_is_disabled():
        with mock.patch.object(sys.stderr, 'write') as mock_write:
            debug(lambda: 'Hello, world!')
            mock_write.assert_not_called()

    # Test that it is enabled
    with mock.patch.object(settings, 'debug', True):
        with mock.patch.object(messages, 'debug') as mock_debug:
            _assert_debug_is_enabled()
            mock_debug.assert_called_once_with('Hello, world!')

    # Test that it is disabled
    with mock.patch.object(settings, 'debug', False):
        _assert_debug_is_disabled()



# Generated at 2022-06-22 15:02:37.021768
# Unit test for function debug
def test_debug():
    from . import utils
    from .. import settings
    __import__('pytest').utils.suppress_warnings()

    settings.debug = False
    debug(lambda: 'foo')
    debug(lambda: utils.get_identifier_from_name('foo'))

    settings.debug = True
    debug(lambda: 'foo')
    debug(lambda: utils.get_identifier_from_name('foo'))

# Generated at 2022-06-22 15:02:41.345670
# Unit test for function eager
def test_eager():
    @eager
    def nums(start: int, end: int) -> Iterable[int]:
        for i in range(start, end):
            yield i

    assert nums(0, 10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:02:43.283556
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    def g():
        pass

    assert get_source(f) == get_source(g)



# Generated at 2022-06-22 15:02:50.107351
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass\n'

    def foo():
        """Docstring."""
        pass

    assert get_source(foo) == 'pass\n'

    def foo():
        """Docstring.

        All lines should be stripped from white spaces.
        """
        pass

    assert get_source(foo) == 'pass\n'



# Generated at 2022-06-22 15:02:52.992311
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            print(1)

        return bar

    source = get_source(foo())
    assert source == 'def bar():\n    print(1)'



# Generated at 2022-06-22 15:02:55.294194
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    source = get_source(f)
    assert source.startswith("def f():")


# Generated at 2022-06-22 15:02:57.502710
# Unit test for function eager
def test_eager():
    @eager
    def generate():
        yield 1
        yield 2

    assert generate() == [1, 2]

# Generated at 2022-06-22 15:03:03.610835
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .conf import override_settings

    buffer = StringIO()
    try:
        with override_settings(debug=True):
            debug(lambda: 'The debug message')
            debug_output = buffer.getvalue()
    finally:
        sys.stderr = sys.__stderr__
    assert 'The debug message' in debug_output
    assert 'DEBUG' in debug_output

# Generated at 2022-06-22 15:03:05.234880
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-22 15:03:32.057260
# Unit test for function get_source
def test_get_source():
    def my_function(a, b, c):
        pass
    assert get_source(my_function) == 'def my_function(a, b, c):\n    pass'



# Generated at 2022-06-22 15:03:35.146931
# Unit test for function get_source
def test_get_source():
    import re

    def function():
        pass

    # get_source is indented by one space
    assert re.search(r'^def function\(\)', get_source(function)) is not None



# Generated at 2022-06-22 15:03:36.088651
# Unit test for function debug
def test_debug():
    warn("Unit tests are disabled.")

# Generated at 2022-06-22 15:03:43.153275
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test message'

    import io
    import sys
    sys.stderr = StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == ''

    settings.debug = True
    sys.stderr = StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == '\x1b[90m\n#DEBUG: test message\n\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-22 15:03:49.317402
# Unit test for function debug
def test_debug():
    messages.debug = lambda msg: msg
    settings.debug = True
    warn_msg = ''
    try:
        debug(lambda: '1')
        debug(lambda: '2')
        warn_msg = 'debug should print debug messages if debug=True'
    except Exception:
        warn_msg = 'debug should not throw an error'

    settings.debug = False
    try:
        debug(lambda: '1')
        debug(lambda: '2')
    except Exception:
        warn_msg = 'debug should throw an error if debug=False'

    if warn_msg:
        warn(warn_msg)

# Generated at 2022-06-22 15:03:51.721417
# Unit test for function eager
def test_eager():
    @eager
    def test():
        for i in range(5):
            yield i

    assert test() == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:03:54.545987
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        return
    assert test() == [1]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:03:57.344243
# Unit test for function eager
def test_eager():
    @eager
    def get_list() -> Iterable[int]:
        yield 1
        yield 2

    assert get_list() == [1, 2]



# Generated at 2022-06-22 15:04:00.624731
# Unit test for function eager
def test_eager():
    @eager
    def test_eager_fn(n):
        i = 0
        while i < n:
            yield i
            i += 1

    assert list(test_eager_fn(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-22 15:04:01.743493
# Unit test for function get_source
def test_get_source():
    def fn():
        return 4

    print(get_source(fn))
    assert get_source(fn) == 'return 4'



# Generated at 2022-06-22 15:04:54.956067
# Unit test for function get_source
def test_get_source():
    def decorated():
        def func():
            pass
        return func
    assert get_source(decorated()) == 'def func():\n    pass'

# Generated at 2022-06-22 15:04:57.804202
# Unit test for function get_source
def test_get_source():
    def test():
        return 0
    assert get_source(test) == 'def test():\n    return 0'


# Unit tests for functions warn and debug

# Generated at 2022-06-22 15:05:01.600019
# Unit test for function eager
def test_eager():
    def return_iterable():
        for i in range(3):
            yield i

    def return_list():
        return [1, 2, 3]

    assert eager(return_iterable)() == return_list()


# Generated at 2022-06-22 15:05:04.551819
# Unit test for function get_source
def test_get_source():
    def a():
        """Docstring for a."""
        return 1

    assert get_source(a) == (
        '"""Docstring for a."""\n'
        'return 1'
    )


# Generated at 2022-06-22 15:05:09.276488
# Unit test for function get_source
def test_get_source():
    def func1():
        def internal_func(a, b, c):
            return a + b + c
        
        def internal_func2(a, b, c, d=4):
            return a + b + c + d
        
        return internal_func, internal_func2
    

# Generated at 2022-06-22 15:05:11.485525
# Unit test for function eager
def test_eager():
    if eager(lambda: (1, 2, 3))() != [1, 2, 3]:
        raise AssertionError()

# Generated at 2022-06-22 15:05:22.394472
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == '    pass'
    def fn():
        x = 1
    assert get_source(fn) == '    x = 1'
    def fn():
        x
        y
    assert get_source(fn) == '    x\n    y'
    @decorator
    def fn():
        x
        y
    assert get_source(fn) == '    x\n    y'
    def fn():
        x = 1
    assert get_source(fn) == '    x = 1'
    def fn(x = 1):
        pass
    assert get_source(fn) == '    pass'
    def fn(x = 1):
        x
        y
    assert get_source(fn) == '    x\n    y'



# Generated at 2022-06-22 15:05:24.505715
# Unit test for function get_source
def test_get_source():
    def foo(a, b, c='c'):
        def nested(foo, bar=None):
            return foo

        return nested(b)


# Generated at 2022-06-22 15:05:26.638716
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-22 15:05:28.910870
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'debug message')
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:07:37.842751
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch
    from .test_main import settings_context

    with settings_context(debug=False):
        assert not settings.debug

        with patch('sys.stderr', new_callable=StringIO) as stderr:
            debug(lambda: 'Message')
            assert stderr.getvalue() == ''

    with settings_context(debug=True):
        assert settings.debug

        with patch('sys.stderr', new_callable=StringIO) as stderr:
            debug(lambda: 'Message')
            assert stderr.getvalue() == messages.debug('Message\n')

# Generated at 2022-06-22 15:07:41.505816
# Unit test for function debug
def test_debug():
    import sys
    temp_stdout = sys.stderr
    sys.stderr = stdout = StringIO()
    debug(lambda: "foo")
    debug(lambda: "bar")
    assert stdout.getvalue() == "\033[33mDEBUG: foo\033[0m\n\033[33mDEBUG: bar\033[0m\n"
    sys.stderr = temp_stdout



# Generated at 2022-06-22 15:07:51.426125
# Unit test for function eager
def test_eager():
    """Unit test for function eager.

    This function is used to unit test function eager from file utils.py
    with the following scenario:
    1. Generates an iterator that yields numbers from 0 to 9
    2. Passes it to eager
    3. Asserts that the returned list is the same as the expected one
    """
    from .iterators import from_number
    from .assertions import assert_equals

    def iterator():
        yield from from_number(0, 10)

    assert_equals(eager(iterator)(), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

# Generated at 2022-06-22 15:07:55.628639
# Unit test for function debug
def test_debug():
    if not settings.debug:
        return
    debug_message = 'debug-message'
    mock_debug_print = Mock()
    with patch('py_backwards.messaging.debug', mock_debug_print):
        debug(lambda: debug_message)
        mock_debug_print.assert_called_once_with(debug_message)



# Generated at 2022-06-22 15:07:57.797246
# Unit test for function get_source
def test_get_source():
    def f(): pass

    source_code = get_source(f)
    source_code_expected = 'def f(): pass'

    assert source_code == source_code_expected

# Generated at 2022-06-22 15:08:00.627381
# Unit test for function get_source
def test_get_source():
    def test():
        """
        Some kind of docstring
        """
        pass

    assert get_source(test) == '''def test():
        \"\"\"
        Some kind of docstring
        \"\"\"
        pass'''

# Generated at 2022-06-22 15:08:02.003903
# Unit test for function get_source
def test_get_source():  # type: ignore
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-22 15:08:03.207223
# Unit test for function eager
def test_eager():
    def gen():
        yield 1
    assert eager(gen)() == [1]

# Generated at 2022-06-22 15:08:08.320553
# Unit test for function get_source
def test_get_source():
    def f1(x: int) -> int:
        y = 1
        return x + y
    assert get_source(f1) == textwrap.dedent('''
    def f1(x: int) -> int:
        y = 1
        return x + y
    ''').strip()

# Generated at 2022-06-22 15:08:12.721338
# Unit test for function get_source
def test_get_source():
    def function(hello: str, world: str) -> int:
        this_is_just_a_test = 1
        return this_is_just_a_test

    source = get_source(function)
    assert source.strip() == (
        'return this_is_just_a_test'
    ).strip()