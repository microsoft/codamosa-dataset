

# Generated at 2022-06-22 14:58:36.557154
# Unit test for function eager
def test_eager():
    def fibgen(n):
        a, b = 1, 1
        while a < n:
            yield a
            a, b = b, a+b
    assert eager(fibgen)(5) == [1, 1, 2, 3]

# Generated at 2022-06-22 14:58:39.024780
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: 'DEBUG ' + x

    debug(lambda: 'hello')  # Should not print
    settings.debug = True
    debug(lambda: 'hello')  # Should print



# Generated at 2022-06-22 14:58:40.098643
# Unit test for function debug
def test_debug():
    debug(lambda: 'Ouch!')



# Generated at 2022-06-22 14:58:44.761021
# Unit test for function get_source
def test_get_source():
    def foo(x):
        a = x
        print(a)
    msg = get_source(foo)
    assert msg == 'def foo(x):\n    a = x\n    print(a)'

# Generated at 2022-06-22 14:58:46.975952
# Unit test for function eager
def test_eager():
    def generator_func():
        yield 1
        yield 2

    assert eager(generator_func)() == [1, 2]



# Generated at 2022-06-22 14:58:57.030814
# Unit test for function debug
def test_debug():
    from ..types import DebugMessage
    from .apply_global import apply_global
    from .. import messages
    from .get_variables import get_variables

    # Store original settings
    original_debug = settings.debug

    # Mock messages.debug
    debug_message: List[DebugMessage] = []

    def _mock_debug(message: DebugMessage) -> None:
        debug_message.append(message)

    messages.debug = _mock_debug

    # Mock get_variables
    get_variables_message: List[str] = []

    def _mock_get_variables() -> str:
        get_variables_message.append('test')
        return 'test'

    get_variables.__code__ = _mock_get_variables.__code__

    # Test
    settings.debug

# Generated at 2022-06-22 14:59:07.740739
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    source_lines = source.split('\n')
    assert source_lines[0] == 'def test_get_source():'
    assert source_lines[1] == '    source = get_source(test_get_source)'
    assert source_lines[2] == '    source_lines = source.split(\'\\n\')'
    assert source_lines[3] == '    assert source_lines[0] == \'def test_get_source():\''
    assert source_lines[4] == '    assert source_lines[1] == \'    source = get_source(test_get_source)\''
    assert source_lines[5] == '    assert source_lines[2] == \'    source_lines = source.split(\\\'\\\\n\\\')\''

# Generated at 2022-06-22 14:59:16.473941
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stdout
    from ..conf import settings

    settings.debug = True
    captured_output = StringIO()
    with redirect_stdout(captured_output):
        debug(lambda: "test_message")
    assert captured_output.getvalue() == messages.debug("test_message") + '\n'

    settings.debug = False
    captured_output = StringIO()
    with redirect_stdout(captured_output):
        debug(lambda: "test_message")
    assert captured_output.getvalue() == ''



# Generated at 2022-06-22 14:59:19.000444
# Unit test for function eager
def test_eager():
    @eager
    def fn():
        yield 1
        yield 2
        yield 3
    assert fn() == [1, 2, 3]



# Generated at 2022-06-22 14:59:22.209803
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'pass'



# Generated at 2022-06-22 14:59:28.776251
# Unit test for function debug
def test_debug():
    called = False

    def get_message():
        nonlocal called
        called = True
        return "debug message"

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(get_message)

    mock_stderr.seek(0)
    assert called == True, 'The debug function should call get_message function'
    assert mock_stderr.read() == '', 'If debug is disabled, the function should return nothing'

    called = False
    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(get_message)

    mock_stderr.seek(0)
    settings.debug = False
    assert called == True, 'The debug function should call get_message function'
    assert mock

# Generated at 2022-06-22 14:59:34.656472
# Unit test for function debug
def test_debug():
    import io
    import sys
    buffer_out = io.StringIO()
    buffer_err = io.StringIO()
    settings.debug = True
    sys.stdout = buffer_out
    sys.stderr = buffer_err

    def get_message_test():
        x = 3
        return str(x)

    debug(get_message_test)
    assert sys.stderr.getvalue() == 'Warning: Debug: 3\n'
    settings.debug = False



# Generated at 2022-06-22 14:59:39.665226
# Unit test for function eager
def test_eager():
    @eager
    def gen(length: int, step: int = 1) -> Generator[int, None, None]:
        i = 0
        while i < length:
            yield i
            i += step

    assert gen(4, 2) == [0, 2]



# Generated at 2022-06-22 14:59:41.865636
# Unit test for function get_source
def test_get_source():
    def func():
        print('Hello')

    assert(get_source(func).strip() == "print('Hello')")



# Generated at 2022-06-22 14:59:42.610237
# Unit test for function eager
def test_eager():
    @eager
    def test(a):
        yield a
    assert test(1) == [1]

# Generated at 2022-06-22 14:59:45.424115
# Unit test for function get_source
def test_get_source():
    def func_sample(a, b):
        """Docstring."""
        c = 12

        def nested_func():
            print(c)

    assert get_source(func_sample) == '''def func_sample(a, b):
    """Docstring."""
    c = 12

    def nested_func():
        print(c)
'''

# Generated at 2022-06-22 14:59:47.798820
# Unit test for function get_source
def test_get_source():
    def foo():
        bar('a', 'b')

    def bar(x, y):
        pass

    assert get_source(foo) == 'bar(\'a\', \'b\')'
    assert get_source(bar) == 'pass'

# Generated at 2022-06-22 14:59:52.994882
# Unit test for function eager
def test_eager():
    def fn(a: int) -> List[int]:
        yield a
        yield a + 1
        yield a + 2
    assert eager(fn)(0) == [0, 1, 2]

import unittest


# Generated at 2022-06-22 14:59:54.776223
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    assert True



# Generated at 2022-06-22 15:00:06.105380
# Unit test for function get_source
def test_get_source():
    def foo():
        """
        hello
        """
        print('world')

    assert(get_source(foo) == dedent(
        """
        """
        """
        hello
        """
        """
        print('world')
        """.strip()
    ))
    assert(get_source(foo) == dedent(
        """
        """
        """
        hello

        """
        """
        print('world')
        """.strip()
    ))
    assert(get_source(foo) == dedent(
        """
        """
        """
        hello
        """
        """

        print('world')
        """.strip()
    ))

# Generated at 2022-06-22 15:00:12.755914
# Unit test for function debug
def test_debug():
    class Test:
        def __init__(self, value: Any) -> None:
            self.value = value

        def __repr__(self) -> str:
            return '{!r}'.format(self.value)

    test = Test('test')
    debug(lambda: 'should print', test)



# Generated at 2022-06-22 15:00:19.885954
# Unit test for function eager
def test_eager():
    def fn():
        for a in range(4):
            for b in range(4):
                yield (a, b)

    assert eager(fn)() == [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2), (1, 3), (2, 0), (2, 1), (2, 2), (2, 3), (3, 0), (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-22 15:00:24.885385
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    @wraps(foo)
    def wrapped_foo():
        pass

    assert get_source(wrapped_foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 15:00:27.108003
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == '\n    pass', 'get_source returns invalid source code'

# Generated at 2022-06-22 15:00:29.931906
# Unit test for function get_source
def test_get_source():
    def decorated():
        def fn():
            pass
        return fn
    assert get_source(decorated()) == 'def fn():\n    pass\n'

# Generated at 2022-06-22 15:00:38.068200
# Unit test for function get_source

# Generated at 2022-06-22 15:00:40.283987
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    source = get_source(test_function)

    assert source == 'def test_function():\n    pass\n'

# Generated at 2022-06-22 15:00:43.454466
# Unit test for function debug
def test_debug():
    settings.debug = True
    messages.debug = lambda x: x

    try:
        debug(lambda: 'message')
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-22 15:00:45.050719
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-22 15:00:47.210711
# Unit test for function get_source
def test_get_source():
    def hello():
        print('Hello!')
    assert get_source(hello) == 'def hello():\n    print(\'Hello!\')'

# Generated at 2022-06-22 15:00:58.770008
# Unit test for function eager
def test_eager():
    class FakeIterable:
        def __init__(self, num_elements):
            self.i = 0
            self.num_elements = num_elements
        
        def __iter__(self):
            return self

        def __next__(self):
            if self.i == self.num_elements:
                raise StopIteration
            self.i += 1
            return self.i
        
    @eager
    def fn(n, k):
        return FakeIterable(n)

    assert fn(10, 3) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    

# Generated at 2022-06-22 15:01:00.807110
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    except SystemExit as e:
        pass
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:01:03.622081
# Unit test for function eager
def test_eager():
    a = [x for x in range(3)]
    assert(a == eager(list)(a))
    assert(a == eager(list)(a))
    assert(a == eager(list)(a))

# Generated at 2022-06-22 15:01:06.268929
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in range(5)))(), [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:01:09.763840
# Unit test for function get_source
def test_get_source():
    def foo(x: int, y: int) -> int:
        x = x + 1
        y = y + 2
        return x + y

# Generated at 2022-06-22 15:01:11.793234
# Unit test for function eager
def test_eager():
    def f():
        for i in range(3):
            yield i

    assert eager(f)() == [0, 1, 2]

# Generated at 2022-06-22 15:01:13.930893
# Unit test for function get_source
def test_get_source():
    def func_example(): pass
    assert get_source(func_example) == "def func_example(): pass"

# Generated at 2022-06-22 15:01:16.086716
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'
    debug(get_message)



# Generated at 2022-06-22 15:01:23.617168
# Unit test for function debug
def test_debug():
    import io
    output = io.StringIO()
    saved_debug = settings.debug
    saved_stderr = sys.stderr
    try:
        settings.debug = True
        sys.stderr = output
        debug(lambda: 'lorem ipsum')
        assert 'lorem ipsum' in output.getvalue()
        output.seek(0)
        output.truncate()

        settings.debug = False
        sys.stderr = output
        debug(lambda: 'lorem ipsum')
        assert 'lorem ipsum' not in output.getvalue()
    finally:
        sys.stderr = saved_stderr
        settings.debug = saved_debug
# end unit test

# Generated at 2022-06-22 15:01:25.102537
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(10))() == list(range(10))

# Generated at 2022-06-22 15:01:31.833487
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'
    for _ in range(2):
        debug(get_message)

# Generated at 2022-06-22 15:01:36.846106
# Unit test for function debug
def test_debug():
    from mock import MagicMock, patch

    debug = MagicMock()
    patch(settings, 'debug', True, debug)

    debug_message = 'abc'
    debug(lambda: debug_message)

    debug.assert_called_once_with(messages.debug(debug_message))

    patch(settings, 'debug', False, debug)

    debug(lambda: debug_message)

    debug.assert_called_once()



# Generated at 2022-06-22 15:01:39.278442
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'message')

    assert f.getvalue() == 'message\n'

# Generated at 2022-06-22 15:01:41.352280
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-22 15:01:43.832242
# Unit test for function get_source
def test_get_source():

    def test_function():
        print('123')

    assert get_source(test_function) == "print('123')"



# Generated at 2022-06-22 15:01:47.376447
# Unit test for function eager
def test_eager():
    class TestClass:
        def some_func(self):
            yield 1
            yield 2
            yield 3

    test = TestClass()

    eager_func = eager(test.some_func)
    assert eager_func == list(test.some_func())



# Generated at 2022-06-22 15:01:56.885498
# Unit test for function debug
def test_debug():
    import sys

    class FakeStdout(object):
        def __init__(self) -> None:
            self.data = []  # type: List[str]

        def write(self, s: str) -> None:
            self.data.append(s)

    try:
        old_stdout = sys.stderr
        fake_stdout = FakeStdout()
        sys.stderr = fake_stdout
        settings.debug = True
        debug(lambda: "hello")
        assert len(fake_stdout.data) == 1
        assert fake_stdout.data[0].startswith("py_backwards_warning:")
        assert "[debug] hello" in fake_stdout.data[0]
    finally:
        sys.stderr = old_stdout

# Generated at 2022-06-22 15:02:00.194927
# Unit test for function eager
def test_eager():
    from .utils import eager

    @eager
    def fn():
        for i in range(3):
            yield i

    assert fn() == [0, 1, 2]

# Generated at 2022-06-22 15:02:03.125943
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'debug message')
    except:
        raise
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:02:05.715395
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        c = a + b
        return c
    assert get_source(foo) == 'c = a + b\nreturn c'



# Generated at 2022-06-22 15:02:20.448348
# Unit test for function get_source
def test_get_source():
    def my_function(a, b):
        return a + b

    expected = '''return a + b'''
    actual = get_source(my_function)
    assert expected == actual



# Generated at 2022-06-22 15:02:29.242269
# Unit test for function debug
def test_debug():
    import unittest
    import sys
    import settings

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self._stdout = sys.stdout
            sys.stdout = self._mock_stdout = StringIO()

        def tearDown(self):
            sys.stdout = self._stdout

        def test_debug_if_debug_is_enabled(self):
            settings.debug = True

            debug(lambda: 'Debug message')

            self.assertIn('Debug message', self._mock_stdout.getvalue())

        def test_debug_if_debug_is_disabled(self):
            settings.debug = False

            debug(lambda: 'Debug message')

            self.assertNotIn('Debug message', self._mock_stdout.getvalue())


# Generated at 2022-06-22 15:02:35.604576
# Unit test for function eager
def test_eager():
    src = 'def eager(fn):\n'
    src += '  @wraps(fn)\n'
    src += '  def wrapped(*args, **kwargs):\n'
    src += '    return list(fn(*args, **kwargs))\n'
    src += '  return wrapped'
    assert getsource(eager) == src



# Generated at 2022-06-22 15:02:46.645236
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == (
        "assert get_source(test_get_source) == ('\\n'\n"
        "        '    assert get_source(test_get_source) == ('\\n'\n"
        "        \"        '    assert get_source(test_get_source) == ('\\\\n'\"\n"
        '        "        \"        '    # Unit test for function get_source'\"\n"
        '        \'        "        \'"\')"\'"\'"\'"\'"\')"\'"\'"\'"\'"\'"\')"\'"\'"\'"\'"\'\'\')'
    )

# Generated at 2022-06-22 15:02:49.597879
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 3
        yield 5

    assert test() == [1, 3, 5]

# Generated at 2022-06-22 15:02:53.018187
# Unit test for function get_source
def test_get_source():
    def function_1():
        return 2 + 3

    def function_2():
        return 2 + 3

    assert get_source(function_1) == 'return 2 + 3'
    assert get_source(function_2) == 'return 2 + 3'

# Generated at 2022-06-22 15:02:55.637382
# Unit test for function get_source
def test_get_source():
    from .test_correctness import test_get_source as test_fn

    assert get_source(test_fn) == test_fn._py_backwards_source



# Generated at 2022-06-22 15:02:59.405985
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: 'Debug ' + x
    settings.debug = True
    debug(lambda: 'message')
    assert sys.stderr.getvalue() == 'Debug message\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-22 15:03:04.008335
# Unit test for function get_source
def test_get_source():
    def some_function(a: int, b: int) -> int:
        return a + b
    assert get_source(some_function) == 'def some_function(a: int, b: int) -> int:\n    return a + b\n'

# Generated at 2022-06-22 15:03:07.856537
# Unit test for function get_source
def test_get_source():
    """Unit test for function get_source."""
    @warm
    def fn():
        """Does nothing."""
        pass

    source = get_source(fn)
    assert source.startswith('fn_py_backwards'), source

# Generated at 2022-06-22 15:03:32.514983
# Unit test for function get_source
def test_get_source():
    def test():
        return 1
    assert get_source(test) == 'return 1'



# Generated at 2022-06-22 15:03:34.160525
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-22 15:03:38.651626
# Unit test for function debug
def test_debug():
    called = []
    def get_message():
        called.append(1)
        return "test message"
    debug(get_message)
    assert called == []

    settings.debug = True
    debug(get_message)
    assert called == [1]
    settings.debug = False
    debug(get_message)
    assert called == [1]

# Generated at 2022-06-22 15:03:47.889028
# Unit test for function debug
def test_debug():
    from . import settings
    from . import messages
    from contextlib import contextmanager

    @contextmanager
    def debug_settings(debug: bool) -> None:
        old_debug = settings.debug
        settings.debug = debug
        yield
        settings.debug = old_debug

    def test_debug_on() -> None:
        with debug_settings(True):
            call_count = 0

            def get_message() -> str:
                nonlocal call_count
                call_count += 1
                return 'result'

            debug(get_message)
            assert call_count == 1
            assert sys.stderr.getvalue().strip() == messages.debug('result')

    def test_debug_off() -> None:
        with debug_settings(False):
            call_count = 0


# Generated at 2022-06-22 15:03:49.204758
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'pass'

# Generated at 2022-06-22 15:03:53.401436
# Unit test for function get_source
def test_get_source():
    def test1():
        pass

    def generate():
        for i in range(10):
            yield i

    assert get_source(test1) == "def test1():\n    pass"
    assert get_source(generate) == "def generate():\n    for i in range(10):\n        yield i"


# Generated at 2022-06-22 15:03:55.763607
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-22 15:04:02.622875
# Unit test for function debug
def test_debug():
    import io

    class Logger:
        def __init__(self):
            self.messages = []

        def debug(self, message: str) -> None:
            self.messages.append(message)

    logger = Logger()

    # Need to change settings to test - unfortunately we need to mock it
    original_debug = settings.debug
    settings.debug = True

    message = 'any message'
    debug(lambda: message)

    # Restore settings
    settings.debug = original_debug

    # Assert message was written to the output stream
    assert logger.messages == [message]

# Generated at 2022-06-22 15:04:05.624205
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    assert 'def test_get_source():' in source.split('\n')[0]



# Generated at 2022-06-22 15:04:07.690768
# Unit test for function get_source
def test_get_source():
    def function_with_comments():
        pass

    assert get_source(function_with_comments) == 'def function_with_comments():\n    pass\n'

# Generated at 2022-06-22 15:04:54.791884
# Unit test for function get_source

# Generated at 2022-06-22 15:05:02.615190
# Unit test for function eager
def test_eager():
    from random import randint
    from time import sleep
    from multiprocessing import Pool

    def get_numbers() -> Iterable[int]:
        for i in range(1000):
            sleep(0.005)
            yield randint(0, 1000)

    pool = Pool()

    @eager
    def get_results(data: Iterable[int]) -> Iterable[int]:
        return pool.map(lambda x: x ** 2, data)

    results = get_results(get_numbers())
    assert isinstance(results, list)
    assert len(results) == 1000

# Generated at 2022-06-22 15:05:04.201469
# Unit test for function get_source
def test_get_source():
    def f():
        return 42  # noqa

    assert get_source(f) == 'return 42'

# Generated at 2022-06-22 15:05:08.673541
# Unit test for function get_source
def test_get_source():
    def _function():
        x = 'test'
        y = 'abc'
        return x + y
    assert get_source(_function) == 'x = \'test\'\n        y = \'abc\'\n        return x + y'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:05:10.122642
# Unit test for function eager
def test_eager():
    assert eager(lambda: [1, 2, 3])() == [1, 2, 3]

# Generated at 2022-06-22 15:05:14.019429
# Unit test for function get_source
def test_get_source():
    def add(x: int, y: int) -> int:
        return x + y

    assert get_source(add) == 'def add(x, y):\n    return x + y'



# Generated at 2022-06-22 15:05:20.304415
# Unit test for function get_source
def test_get_source():
    # pylint: disable=no-self-argument,unused-variable,pointless-statement
    def get_source_test_function(a: int, *, b: int) -> int:
        def inner():
            return a + b
        return inner()

    assert get_source(get_source_test_function) == 'def inner():\n' \
                                                  '    return a + b\n' \
                                                  'return inner()\n'



# Generated at 2022-06-22 15:05:29.054901
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from contextlib import contextmanager

    @contextmanager
    def mocked_settings(debug: bool) -> Iterable[None]:
        with patch('py_backwards.utils.settings.debug', debug):
            yield

    with mocked_settings(True):
        test_message = 'test message'
        debug(lambda: test_message)
        assert sys.stderr.getvalue().endswith(test_message + '\n')

    with mocked_settings(False):
        sys.stderr.truncate(0)
        debug(lambda: 'test message')
        assert not sys.stderr.getvalue().endswith('test message\n')

# Generated at 2022-06-22 15:05:33.605970
# Unit test for function eager
def test_eager():
    @eager
    def add_one(x):
        for i in range(x):
            yield i + 1

    x = add_one(3)
    assert len(x) == 3
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3



# Generated at 2022-06-22 15:05:35.997913
# Unit test for function get_source
def test_get_source():
    # noinspection PyPep8Naming
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-22 15:07:48.134323
# Unit test for function eager
def test_eager():
    @eager
    def fib():
        a, b, n = 0, 1, 1
        while n < 5:
            yield a
            a, b = b, a + b
            n += 1

    assert fib() == [0, 1, 1, 2, 3]



# Generated at 2022-06-22 15:07:50.943445
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            pass
        return g
    assert get_source(f) == 'def g():\n    pass\nreturn g'



# Generated at 2022-06-22 15:07:52.758328
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Test')
    settings.debug = False
    debug(lambda: 'Test')

# Generated at 2022-06-22 15:07:56.698794
# Unit test for function get_source
def test_get_source():
    """
    Checks that function get_source returns source code of the function without
    padding.
    """
    def test(b: bool) -> str:
        if b:
            return 'True'
        else:
            return 'False'


# Generated at 2022-06-22 15:08:03.488927
# Unit test for function debug
def test_debug():
    # Fake object to simulate settings module
    settings = type('settings', (object,), {'debug': False})

    def get_message():
        return 'Hello world'

    # Print function to test function debug
    print_func = lambda msg: msg

    # Catch all calls to print_func
    with mock.patch('sys.stderr', new_callable=mock.Mock) as print_mock:
        debug(get_message)
        print_mock.assert_not_called()

        settings.debug = True
        debug(get_message)
        print_mock.assert_called_once_with('\x1b[33mHello world\x1b[0m\n')



# Generated at 2022-06-22 15:08:09.257891
# Unit test for function debug
def test_debug():
    debug(lambda: 'message')
    with patch('sys.stderr', new=StringIO()) as fake_stderr, \
         patch('py_backwards.core.utils.settings') as fake_settings:  # type: ignore
        fake_settings.debug = False
        debug(lambda: 'message')
    assert fake_stderr.getvalue() == ''



# Generated at 2022-06-22 15:08:11.097555
# Unit test for function get_source
def test_get_source():
    def test():
        print(1)

    assert get_source(test) == 'print(1)'



# Generated at 2022-06-22 15:08:19.399729
# Unit test for function eager
def test_eager():
    from pytest import raises
    from _pytest.warnings import catch_warnings
    from .messages import README_WARNING

    @eager
    def test():
        yield 1
        yield 2

    assert test() == [1, 2]

    with raises(TypeError) as e:
        test(1)
    assert str(e.value) == 'test() takes 0 positional arguments but 1 was given'

    with raises(TypeError) as e:
        test(1, 2)
    assert str(e.value) == 'test() takes 0 positional arguments but 2 were given'

    with raises(TypeError) as e:
        test(foo=1, bar=2)
    assert str(e.value) == "test() got an unexpected keyword argument 'foo'"

    def test2():
        pass


# Generated at 2022-06-22 15:08:25.577710
# Unit test for function get_source
def test_get_source():
    def my_source_function():
        """Docstring"""


    def my_source_function_with_padding():
        """Docstring"""


    expected_result = """    \"""Docstring\""""""
    result = get_source(my_source_function)
    assert result == expected_result
    result = get_source(my_source_function_with_padding)
    assert result == expected_result

# Generated at 2022-06-22 15:08:27.819147
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]