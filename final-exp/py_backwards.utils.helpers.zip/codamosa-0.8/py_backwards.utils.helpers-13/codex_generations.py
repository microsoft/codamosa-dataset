

# Generated at 2022-06-22 14:58:19.011438
# Unit test for function get_source
def test_get_source():
    def fn(a, b, c, d):
        if a:
            b = 3
            d = 2
        return b if c else d

    assert get_source(fn) == """
if a:
    b = 3
    d = 2
return b if c else d
""".strip()

# Generated at 2022-06-22 14:58:25.605179
# Unit test for function debug
def test_debug():
    import io
    import sys

    print_stdout = sys.stdout

    try:
        sys.stdout = io.StringIO()
        settings.debug = True
        debug(lambda: 'message')
        assert sys.stdout.getvalue() == messages.debug('message') + '\n'
    finally:
        sys.stdout = print_stdout

# Generated at 2022-06-22 14:58:27.746960
# Unit test for function debug
def test_debug():
    from ..conf import set_debug
    set_debug(True)
    debug(lambda: 'test')
    set_debug(False)

# Generated at 2022-06-22 14:58:33.824764
# Unit test for function debug
def test_debug():
    from unittest import mock
    from ..conf import settings

    settings.debug = True

    with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
        debug(lambda: 'test')
        mock_stderr.write.assert_called_once_with(messages.debug('test') + '\n')

    with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
        settings.debug = False
        debug(lambda: 'test')
        assert not mock_stderr.write.called

# Generated at 2022-06-22 14:58:39.651724
# Unit test for function debug
def test_debug():
    # pylint: disable=W0613
    warnings = []
    old_settings_debug = settings.debug
    settings.debug = True
    old_print = builtins.print
    builtins.print = lambda *args, **kwargs: warnings.append(args[0])
    debug(lambda: 'Debug message')
    assert warnings.pop() == messages.debug('Debug message')
    builtins.print = old_print
    settings.debug = old_settings_debug
    return True

# Generated at 2022-06-22 14:58:44.422714
# Unit test for function get_source
def test_get_source():
    def function_name():
        return 'function'
    # This is a "string" for the test
    assert get_source(function_name) == 'return "function"'

# Generated at 2022-06-22 14:58:46.627844
# Unit test for function debug
def test_debug():
    def test_method():
        # type: () -> None
        debug(lambda: 'test_message')
    test_method()



# Generated at 2022-06-22 14:58:54.200130
# Unit test for function eager
def test_eager():
    from inspect import getfullargspec

    @eager
    def fn_lazy(x: int) -> List[T]:
        yield from range(x)

    fn_eager = eager(fn_lazy)

    assert fn_lazy(10) == fn_eager(10)
    assert fn_lazy(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    assert getfullargspec(fn_lazy) == getfullargspec(fn_eager)



# Generated at 2022-06-22 14:58:57.496079
# Unit test for function eager
def test_eager():
    def func(i: int) -> Iterable[int]:
        yield i

    assert eager(func)(42) == [42]

# Generated at 2022-06-22 14:59:00.372442
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield from (1, 2, 3)
        yield 4

    assert(test() == [1, 2, 3, 4])

# Generated at 2022-06-22 14:59:09.045991
# Unit test for function get_source
def test_get_source():
    assert get_source(VariablesGenerator.generate) == '@classmethod\n' \
                                                     'def generate(cls, variable: str) -> str:\n' \
                                                     '    """Generates unique name for variable."""\n' \
                                                     '    try:\n' \
                                                     '        return \'_py_backwards_{}_{}\'.format(variable, cls._counter)\n' \
                                                     '    finally:\n' \
                                                     '        cls._counter += 1'



# Generated at 2022-06-22 14:59:11.029378
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-22 14:59:16.608227
# Unit test for function debug
def test_debug():
    assert not settings.debug
    _debugged = []
    def _debug(*args, **kwargs):
        _debugged.append((args, kwargs))
    debug(_debug)
    assert not _debugged
    settings.debug = True
    try:
        debug(_debug)
    finally:
        settings.debug = False
    assert _debugged

# Generated at 2022-06-22 14:59:19.175390
# Unit test for function get_source
def test_get_source():
    def foo():
        src = '    pass\n    pass'
        return src

    assert get_source(foo) == 'pass\npass'



# Generated at 2022-06-22 14:59:23.299360
# Unit test for function get_source
def test_get_source():
    def check():
        """Docstring"""
        print('check')
        pass
    assert get_source(check).strip() == 'print(\'check\')'



# Generated at 2022-06-22 14:59:32.828255
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from io import StringIO
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.output = StringIO()
            sys.stderr = self.output
            settings.debug = True
            self.msg = "Lorem ipsum dolor sit amet"

        def tearDown(self):
            sys.stderr = sys.__stderr__
            settings.debug = False

        def test_debug(self):
            debug(lambda : self.msg)
            self.assertEqual("{} {}".format("\033[1;30m", self.msg),
                             self.output.getvalue().strip("\n"))

    unittest.main()

# Generated at 2022-06-22 14:59:34.215380
# Unit test for function get_source
def test_get_source():
    def test_function():
        """This is a documentation"""
        return 1


# Generated at 2022-06-22 14:59:38.212493
# Unit test for function eager
def test_eager():
    def test_generator():
        for i in range(3):
            yield i

    assert eager(test_generator)() == [0, 1, 2]



# Generated at 2022-06-22 14:59:44.767009
# Unit test for function get_source
def test_get_source():
    def test_fn(a, b):
        """This is just a test function to test get_source function.
        
        It doesn't do anything useful, but it's still cool.
        """
        pass


# Generated at 2022-06-22 14:59:45.923803
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'pass'

# Generated at 2022-06-22 14:59:54.551179
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    def run(debug_flag: bool, message: str) -> None:
        sys.stderr = StringIO()
        settings.debug = debug_flag
        debug(lambda: message)
        assert sys.stderr.getvalue() == messages.debug(message) + "\n"

    run(True, "message")
    run(False, "message")

# Generated at 2022-06-22 14:59:58.179069
# Unit test for function eager
def test_eager():
    def test(n: int) -> Iterable[int]:
        while n > 0:
            yield n
            n -= 1

    assert eager(test)(10) == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

# Generated at 2022-06-22 15:00:01.321609
# Unit test for function get_source
def test_get_source():
    def function_example(argument1, argument2):
        """Function example."""
        return argument1 + argument2
    assert get_source(function_example) == 'def {}(argument1, argument2):\n    """Function example."""\n    return argument1 + argument2'.format(function_example.__name__)

# Generated at 2022-06-22 15:00:05.663100
# Unit test for function debug
def test_debug():
    message = 'test'
    with patch('py_backwards.utils.settings.debug', True):
        debug(lambda: message)
    with patch('py_backwards.utils.settings.debug', False):
        debug(lambda: message)



# Generated at 2022-06-22 15:00:07.479981
# Unit test for function get_source
def test_get_source():
    assert get_source(print).startswith('def print')

# Generated at 2022-06-22 15:00:14.441765
# Unit test for function debug
def test_debug():
    debug_messages = []
    original_debug = settings.debug
    settings.debug = True

    def record_debug(*args: Any, **kwargs: Any) -> None:
        debug_messages.append((args, kwargs))

    messages.debug = record_debug
    try:
        debug(lambda: 'Hello')
        debug(lambda: 'World')
        assert debug_messages == [(('Hello',), {}), (('World',), {})]
    finally:
        messages.debug = debug
        settings.debug = original_debug

test_debug()

# Generated at 2022-06-22 15:00:18.051173
# Unit test for function debug
def test_debug():
    # Execute
    settings.debug = True
    def get_message():
        return "debug message"
    debug(get_message)

    # Check
    assert settings.debug == False



# Generated at 2022-06-22 15:00:19.799515
# Unit test for function eager
def test_eager():
    @eager
    def _():
        yield 1
        yield 2

    assert _() == [1, 2]

# Generated at 2022-06-22 15:00:26.855347
# Unit test for function eager
def test_eager():
    class Foo:
        def __init__(self, value: int) -> None:
            self.value = value

    foo1 = Foo(1)
    foo2 = Foo(2)
    foo3 = Foo(3)

    @eager
    def foo() -> Iterable[Foo]:
        yield foo1
        yield foo2
        yield foo3

    assert foo() == [foo1, foo2, foo3]



# Generated at 2022-06-22 15:00:31.291861
# Unit test for function eager
def test_eager():
    from .test_tools import test

    @eager
    def lazy_list() -> Iterable[int]:
        yield 1
        yield 2
    test.is_instance(lazy_list, list)
    test.equal(lazy_list(), [1, 2])
    test.equal(lazy_list(), [1, 2])


# Unit tests for function get_source

# Generated at 2022-06-22 15:00:45.397854
# Unit test for function debug
def test_debug():
    import io
    import sys
    import contextlib

    captured_output = io.StringIO()

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (outputs, errors):
        debug(lambda: 'hello')
        assert outputs.getvalue().strip() == messages.debug('hello'), 'debug message is not printed to stdout'


# Generated at 2022-06-22 15:00:57.049148
# Unit test for function debug
def test_debug():
    logs = []
    def print_to_log(line):
        logs.append(line)

    stdout_old = sys.stderr
    sys.stderr = lambda: print_to_log
    try:
        debug(lambda: 'message')
        debug(lambda: 'message 2')
        assert logs == ['  \x1b[0;34;40mDEBUG  \x1b[0m message', '  \x1b[0;34;40mDEBUG  \x1b[0m message 2']
    finally:
        sys.stderr = stdout_old

    with settings.override(debug=False):
        assert len(logs) == 2
        debug(lambda: 'message 3')
        assert len(logs) == 2

# Generated at 2022-06-22 15:01:00.498634
# Unit test for function get_source
def test_get_source():
    def f(x): return x

    assert get_source(f) == 'return x'

    def f():
        return 1

    assert get_source(f) == 'return 1'

# Unit tests for function debug



# Generated at 2022-06-22 15:01:04.208689
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        def baz():
            pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

# Generated at 2022-06-22 15:01:07.827612
# Unit test for function eager
def test_eager():
    @eager
    def fn(n):
        return range(n)

    assert fn(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:01:12.927023
# Unit test for function debug
def test_debug():
    """Tests for function debug."""

    mock = MagicMock()
    with patch('py_backwards.utils.settings.debug', True):
        debug(mock)
    mock.assert_called()
    mock.reset_mock()

    with patch('py_backwards.utils.settings.debug', False):
        debug(mock)
    mock.assert_not_called()



# Generated at 2022-06-22 15:01:15.424135
# Unit test for function debug
def test_debug():
    settings.debug = True
    assert 'TRACE' in debug(lambda: 'TRACE')



# Generated at 2022-06-22 15:01:19.272068
# Unit test for function get_source
def test_get_source():
    def test_func(arg1, arg2):
        return arg1 + arg2

    assert get_source(test_func) == ('def test_func(arg1, arg2):\n'
                                     '    return arg1 + arg2\n')

# Generated at 2022-06-22 15:01:21.123546
# Unit test for function debug
def test_debug():
    with settings.debug_mode(True):
        debug(lambda: 'TEST')

# Non-unit test

# Generated at 2022-06-22 15:01:22.617617
# Unit test for function get_source
def test_get_source():
    def function_to_test():
        pass

# Generated at 2022-06-22 15:01:28.932838
# Unit test for function get_source
def test_get_source():
    def test_function(): # noqa
        return 0
    assert get_source(test_function) == 'return 0'

# Generated at 2022-06-22 15:01:31.554283
# Unit test for function get_source
def test_get_source():
    def foo():
        if False:
            pass

    source = '''if False:
        pass'''
    assert get_source(foo) == source



# Generated at 2022-06-22 15:01:35.033310
# Unit test for function debug
def test_debug():
    from .test_functions import test_debug as f
    assert f() == 'abc'
    assert f.__annotations__ == {}
    assert getsource(f) == dedent('''\
        def test_debug():
            return 'abc'
        ''')

# Generated at 2022-06-22 15:01:37.065796
# Unit test for function get_source
def test_get_source():
    def add(x, y):
        return x + y * y
    assert get_source(add) == 'def add(x, y):\n    return x + y * y\n'

# Generated at 2022-06-22 15:01:41.061557
# Unit test for function debug
def test_debug():
    # pylint: disable=unused-argument

    import subprocess

    def get_message():
        return 'Hello world!'

    # Debug is disabled by default
    subprocess.check_output(['python3', __file__])
    # Debug is enabled
    subprocess.check_output(['python3', __file__, '-D'])


if __name__ == '__main__':
    settings.debug = '-D' in sys.argv
    test_debug()

# Generated at 2022-06-22 15:01:45.519922
# Unit test for function eager
def test_eager():
    """Check that function eager actually works."""
    from itertools import count

    def _gen():
        for i in count():
            yield i

    @eager
    def gen():
        for i in count():
            yield i

    assert list(_gen()) == gen()
    assert _gen() == gen()

# Generated at 2022-06-22 15:01:47.099470
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass

    assert get_source(test_func) == 'pass'



# Generated at 2022-06-22 15:01:48.786565
# Unit test for function get_source
def test_get_source():
    def test():
        print(2)

    assert get_source(test) == 'print(2)'

# Generated at 2022-06-22 15:01:50.600418
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-22 15:01:52.424436
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    assert 'def test_get_source' in source

# Generated at 2022-06-22 15:02:07.099927
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass

        return bar()

    code = get_source(foo)
    assert code == """\
    def bar():
        pass

    return bar()"""
    assert getsource(foo) == '    def foo():\n        {}\n'.format(code)



# Generated at 2022-06-22 15:02:09.457823
# Unit test for function eager
def test_eager():
    @eager
    def numbers() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert numbers() == [1, 2, 3]



# Generated at 2022-06-22 15:02:10.702368
# Unit test for function debug
def test_debug():
    debug(lambda: 'Test message')



# Generated at 2022-06-22 15:02:12.782866
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-22 15:02:18.212216
# Unit test for function get_source
def test_get_source():
    def f1(a):
        def g(b):
            pass
    assert get_source(f1) == "def g(b):\n    pass"

    def f2(a):
        pass
    assert get_source(f2) == "pass"

# Generated at 2022-06-22 15:02:18.729536
# Unit test for function get_source
def test_get_source():
    def f():
        pass



# Generated at 2022-06-22 15:02:21.993248
# Unit test for function get_source
def test_get_source():
    def test_function():
        # pylint: disable=unused-variable
        first_line = 1
        second_line = 2
        third_line = 3
        # pylint: enable=unused-variable

    expected = 'first_line = 1\n' \
               'second_line = 2\n' \
               'third_line = 3'

    source = get_source(test_function)

    assert source == expected

# Generated at 2022-06-22 15:02:27.397065
# Unit test for function debug
def test_debug():
    settings.debug = True
    lines = []

    def get_message():
        return 'My debug message'

    def store(message):
        lines.append(message)

    old_debug = sys.stderr.write

    sys.stderr.write = store
    debug(get_message)
    sys.stderr.write = old_debug
    assert lines == [messages.debug(get_message()) + '\n']



# Generated at 2022-06-22 15:02:29.810123
# Unit test for function get_source
def test_get_source():
    def foo() -> int:
        return 42

    assert get_source(foo).split('\n')[1:] == \
        'def foo() -> int:'.split('\n')


# Generated at 2022-06-22 15:02:32.650456
# Unit test for function eager
def test_eager():
    @eager
    def tester(a: int, b: int) -> Iterable[int]:
        yield a + b
    assert tester(0, 0) == [0]

# Generated at 2022-06-22 15:02:57.979631
# Unit test for function get_source
def test_get_source():
    def function():
        one = 1
        two = 2

        def nested_function():
            return one + two
        return nested_function

    assert get_source(function) == '    one = 1\n    two = 2\n\n    def nested_function():\n        return one + two\n    return nested_function\n'

# Generated at 2022-06-22 15:02:59.444406
# Unit test for function get_source
def test_get_source():
    def fn(*args, **kwargs):
        pass

    assert get_source(fn) == 'pass'



# Generated at 2022-06-22 15:03:09.408724
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .. import conf

    class Settings:
        debug = False

    test_conf = Settings()
    backup = conf.settings
    conf.settings = test_conf
    backup_stderr = sys.stderr
    sys.stderr = StringIO()
    debug(lambda: 'test')
    assert '' == sys.stderr.getvalue()
    test_conf.debug = True
    debug(lambda: 'test')
    assert 'test\n' == sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = backup_stderr
    conf.settings = backup

# Generated at 2022-06-22 15:03:11.449562
# Unit test for function get_source
def test_get_source():
    def fn():
        """Test function."""
        print('Hello world')
    print(get_source(fn))

# Generated at 2022-06-22 15:03:15.928456
# Unit test for function eager
def test_eager():
    def fib():
        x, y = 0, 1
        while True:
            yield x
            x, y = y, x + y

    assert eager(fib)() == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

# Generated at 2022-06-22 15:03:19.922877
# Unit test for function debug
def test_debug():
    messages._debug = 1
    try:
        debug(lambda : "hello")
    except TypeError:
        pass
    messages._debug = 0
    try:
        debug(lambda : "foo")
    except TypeError:
        pass

# Generated at 2022-06-22 15:03:21.919268
# Unit test for function get_source
def test_get_source():
    def foo():
        print('Hello')
    assert get_source(foo) == 'print(\'Hello\')'


# Generated at 2022-06-22 15:03:28.490004
# Unit test for function get_source
def test_get_source():
    import inspect
    def get_source(fn: Callable[..., Any]) -> str:
        """Returns source code of the function."""
        source_lines = inspect.getsource(fn).split('\n')
        padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
        return '\n'.join(line[padding:] for line in source_lines)

    # We need to test function in order to test function which tests function
    print(get_source(get_source))

# Generated at 2022-06-22 15:03:33.374900
# Unit test for function get_source
def test_get_source():
    # noinspection PyShadowingBuiltins
    def input(str):
        """"""
    assert get_source(input) == """def input(str):
    """"""
    """"""
    """
    get_source(test_get_source)

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 15:03:41.069621
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import mock

    stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        debug(lambda: 'test')
        output = sys.stderr.getvalue()
        assert output == ''

        with mock.patch('backwards.core.settings.debug', True):
            debug(lambda: 'test')
            output = sys.stderr.getvalue()
            assert output == messages.debug('test') + '\n'

    finally:
        sys.stderr = stderr


# Generated at 2022-06-22 15:04:40.131449
# Unit test for function debug
def test_debug():
    debug_messages = []
    settings.debug = True
    debug(lambda: 'test_debug1')
    debug(lambda: 'test_debug2')
    settings.debug = False
    assert sys.stderr.getvalue() == '\x1b[94;2mtest_debug1\x1b[0m\n\x1b[94;2mtest_debug2\x1b[0m\n'

# Generated at 2022-06-22 15:04:43.940959
# Unit test for function eager
def test_eager():
    def f(*args: Any, **kwargs: Any) -> str:
        return iter(['a', 'b', 'b'])

    assert eager(f)(1, 2, 3, one=1, two='2') == ['a', 'b', 'b']

# Generated at 2022-06-22 15:04:46.636264
# Unit test for function get_source
def test_get_source():
    import os

    def test():
        """Source."""
        # 2 space indents
        for line in os.listdir('.'):
            print(line)

    assert get_source(test) == get_source.__doc__.strip()

# Generated at 2022-06-22 15:04:48.479190
# Unit test for function eager
def test_eager():
    @eager
    def do_nothing(x: int) -> Iterable[int]:
        yield x

    assert do_nothing(1) == [1]

# Generated at 2022-06-22 15:04:50.946522
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-22 15:04:53.079081
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:04:57.580644
# Unit test for function get_source
def test_get_source():
    def fn():
        def fn1():
            return 1  # lgtm [py/unreachable-statement]


    assert (
        get_source(fn) == '\n'
        'def fn1():\n'
        '    return 1  # lgtm [py/unreachable-statement]\n'
    )

# Generated at 2022-06-22 15:04:59.227261
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'pass'

# Generated at 2022-06-22 15:05:02.653585
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        return 3

    assert eager(test)() == [1, 2]


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 15:05:06.322608
# Unit test for function debug
def test_debug():
    debug_message = 'debug message'
    debug_msg = ''
    def get_debug_message():
        nonlocal debug_msg
        debug_msg = debug_message
        return debug_message
    debug(get_debug_message)
    assert debug_msg == debug_message

# Generated at 2022-06-22 15:07:05.488914
# Unit test for function get_source
def test_get_source():
    def fn(a):
        return a

    assert get_source(fn) == 'return a'



# Generated at 2022-06-22 15:07:07.076762
# Unit test for function eager
def test_eager():
    @eager
    def it():
        yield 1
        yield 2
    assert it() == [1, 2]


# Generated at 2022-06-22 15:07:09.208149
# Unit test for function get_source
def test_get_source():
    def foo(x, y):
        return x + y
    assert get_source(foo) == 'return x + y'


python_version = sys.version_info
is_py_37 = python_version >= (3, 7)

# Generated at 2022-06-22 15:07:11.866806
# Unit test for function get_source
def test_get_source():
    def get_return():
        """Get return 2"""
        return 2
    return_source = '    return 2'
    assert get_source(get_return) == 'def get_return():\n' + return_source

# Generated at 2022-06-22 15:07:13.909809
# Unit test for function get_source
def test_get_source():
    def f():
        a = 1
        b = 2

    assert get_source(f) == 'a = 1\nb = 2'

# Generated at 2022-06-22 15:07:20.478308
# Unit test for function get_source
def test_get_source():
    # TODO: it's not the best thing to use global variable, but this is only for test
    global_variable = 3
    def test():
        local_variable = 4
        # comment1
        print(global_variable, local_variable)
    # comment2

    assert get_source(test) == 'def test():\n    local_variable = 4\n    # comment1\n    print(global_variable, local_variable)'
    del test, global_variable

# Generated at 2022-06-22 15:07:25.027106
# Unit test for function debug
def test_debug():
    from unittest.mock import call, patch

    @patch('stderr', new_callable=lambda: [])
    def test(stderr):
        settings.debug = True
        debug(lambda: 'a')
        debug(lambda: 'b')
        debug(lambda: 'c')
        assert stderr == ['a', 'b', 'c']

    test()



# Generated at 2022-06-22 15:07:28.479782
# Unit test for function get_source
def test_get_source():
    def function():
        a = 1
        if a:
            return a
        else:
            return a+3
    assert get_source(function) == 'a = 1\nif a:\n    return a\nelse:\n    return a+3'

# Generated at 2022-06-22 15:07:31.046263
# Unit test for function eager
def test_eager():
    eager_list = eager(lambda x: range(x))(4)
    eager_list[0] = eager_list[0] + 10
    assert eager_list == [10, 1, 2, 3]

# Generated at 2022-06-22 15:07:34.146480
# Unit test for function eager
def test_eager():
    @eager
    def list_range():
        for i in range(5):
            yield i
    assert list_range() == [0, 1, 2, 3, 4]