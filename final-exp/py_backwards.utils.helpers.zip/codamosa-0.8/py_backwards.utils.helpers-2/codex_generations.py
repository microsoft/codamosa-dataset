

# Generated at 2022-06-22 14:58:40.965999
# Unit test for function debug
def test_debug():
    debug_msg = "Debug message"
    captured_output = io.StringIO()  # Create StringIO object
    sys.stdout = captured_output  # and redirect
    debug(lambda: debug_msg)  # debug output to this object
    sys.stdout = sys.__stdout__  # Reset redirect.
    captured_output.seek(0)
    output = captured_output.read()
    assert debug_msg in output

# Generated at 2022-06-22 14:58:42.967348
# Unit test for function eager
def test_eager():
    def some_function():
        yield 1
        yield 2
        yield 3
    assert list(some_function()) == [1, 2, 3]
    assert eager(some_function)() == [1, 2, 3]

# Generated at 2022-06-22 14:58:46.843397
# Unit test for function get_source
def test_get_source():
    @decorator
    def get_source_test(fn, *a, **kw):
        assert get_source(fn) == ('def fn():\n'
                                  '    pass\n')

    @get_source_test
    def fn():
        pass

# Generated at 2022-06-22 14:58:54.057554
# Unit test for function get_source
def test_get_source():
    def no_args():
        pass

    def one_line(arg):
        return arg

    def multi_line(arg1, arg2):
        return arg1, arg2

    assert get_source(no_args) == 'def no_args():'
    assert get_source(one_line) == 'def one_line(arg):'
    assert get_source(multi_line) == ('def multi_line(arg1, arg2):'
                                      '\n    return arg1, arg2')

# Generated at 2022-06-22 14:58:55.936893
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "test")
    settings.debug = False

# Generated at 2022-06-22 14:59:03.422135
# Unit test for function eager
def test_eager():
    @eager
    def fib(n):
        a, b = 0, 1
        while n > 0:
            yield a
            a, b, n = a + b, a, n - 1

    assert fib(0) == []
    assert fib(1) == [0]
    assert fib(2) == [0, 1]
    assert fib(3) == [0, 1, 1]


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 14:59:08.749450
# Unit test for function debug
def test_debug():
    with patch('sys.stderr', StringIO()) as _stderr:
        debug(lambda: 'message')
        assert _stderr.getvalue() == ''

        settings.debug = True
        debug(lambda: 'message')
        assert _stderr.getvalue() == messages.debug('message') + '\n'

    settings.debug = False

# Generated at 2022-06-22 14:59:14.696085
# Unit test for function eager
def test_eager():
    import itertools
    import time

    @eager
    def generator(n: int) -> Iterable[int]:
        for i in range(n):
            time.sleep(0.1)
            yield i ** 2

    assert generator(10) == list(itertools.starmap(lambda x: x ** 2, enumerate(range(10))))



# Generated at 2022-06-22 14:59:17.966452
# Unit test for function get_source
def test_get_source():
    def f_1():
        a = 1
        b = 1
        return a, b

    assert get_source(f_1) == 'a = 1\nb = 1\nreturn a, b'

# Generated at 2022-06-22 14:59:18.899984
# Unit test for function eager

# Generated at 2022-06-22 14:59:23.552707
# Unit test for function get_source
def test_get_source():
    def func(arg: int) -> str:
        return arg

    assert get_source(func) == 'return arg'

# Generated at 2022-06-22 14:59:28.195735
# Unit test for function debug
def test_debug():
    settings.debug = True

    try:
        debug(lambda: 'debug')
    except AssertionError:
        pass
    else:
        raise AssertionError

    settings.debug = False

    try:
        debug(lambda: 'debug')
    except AssertionError:
        raise AssertionError
    else:
        pass

# Generated at 2022-06-22 14:59:31.096348
# Unit test for function get_source
def test_get_source():
    def func():
        a = 1
        b = 2
        return a + b

    assert get_source(func) == 'a = 1\nb = 2\nreturn a + b\n'

# Generated at 2022-06-22 14:59:35.816120
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    source = get_source(f)
    assert source == '    pass'

    def g():
        x = 1
        if x == 1:
            print('asd')

    source = get_source(g)
    assert source == '    x = 1\n    if x == 1:\n        print(\'asd\')'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 14:59:45.434534
# Unit test for function debug
def test_debug():
    import sys, mock

    @debug
    def foo():
        return 'hello world'

    with mock.patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        with mock.patch('py_backwards.utils.settings.debug', True):
            foo()
            assert mock_stderr.getvalue() == '\x1b[34mDEBUG: hello world\x1b[0m\n'

    with mock.patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        with mock.patch('py_backwards.utils.settings.debug', False):
            foo()
            assert mock_stderr.getvalue() == ''

# Generated at 2022-06-22 14:59:57.180262
# Unit test for function debug
def test_debug():
    import unittest
    import unittest.mock
    import sys

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            sys.stdout = unittest.mock.MagicMock()
            self.stdout.reset_mock()
            self.stderr = sys.stderr
            sys.stderr = unittest.mock.MagicMock()
            self.stderr.reset_mock()

        def tearDown(self):
            sys.stdout = self.stdout
            sys.stderr = self.stderr

        def test_debug(self):
            my_message = 'my message'
            debug(lambda: my_message)
            sys.stderr.write.assert_called

# Generated at 2022-06-22 14:59:59.182153
# Unit test for function get_source
def test_get_source():
    def foo(x):
        return x

    assert get_source(foo) == 'return x'



# Generated at 2022-06-22 15:00:00.550577
# Unit test for function get_source
def test_get_source():
    def function_to_test():
        pass

    assert get_source(function_to_test) == ''

# Generated at 2022-06-22 15:00:03.188418
# Unit test for function eager
def test_eager():
    result = eager(range)(5)
    assert result == [0, 1, 2, 3, 4], result

# Generated at 2022-06-22 15:00:13.759006
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar(a):
        pass
    assert get_source(bar) == 'def bar(a):\n    pass'

    def foo_bar(a,
                b,
                c,
                d):
        pass
    assert get_source(foo_bar) == 'def foo_bar(a,\n            b,\n            c,\n            d):\n    pass'

    def baz():
        def quux():
            pass
    assert get_source(baz) == (
        'def baz():\n'
        '    def quux():\n'
        '        pass'
    )



# Generated at 2022-06-22 15:00:19.531496
# Unit test for function eager
def test_eager():
    @eager
    def fn(x):
        yield x
    assert fn(1) == [1]

# Generated at 2022-06-22 15:00:21.428889
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'foo'
    assert get_source(foo) == "return 'foo'"



# Generated at 2022-06-22 15:00:30.045223
# Unit test for function get_source
def test_get_source():
    def do_something():
        # This is documentation.
        return 42
    assert get_source(do_something) == dedent('''
        # This is documentation.
        return 42
    ''')
    def do_something_else():
        # This is documentation.
        for i in range(10):
            print(i)
        return 42
    assert get_source(do_something_else) == dedent('''
        # This is documentation.
        for i in range(10):
            print(i)
        return 42
    ''')

# Generated at 2022-06-22 15:00:31.475093
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(4))() == [0, 1, 2, 3]

# Generated at 2022-06-22 15:00:36.667544
# Unit test for function get_source
def test_get_source():
    def f(x: int) -> int:
        pass
    assert get_source(f).strip() == """def f(x: int) -> int:"""
    assert get_source(f).starts

# Generated at 2022-06-22 15:00:42.861008
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        import mock
        x = 1
        debug(lambda: 'x is %s' % x)  # noqa
        with mock.patch('sys.stderr') as stderr:
            debug(lambda: 'x is %s' % x)
            assert 'x is 1' in stderr.write.call_args[0][0]
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:00:44.465736
# Unit test for function get_source
def test_get_source():
    # TODO: run pytest
    assert get_source(get_source)
    gs = get_source



# Generated at 2022-06-22 15:00:49.939735
# Unit test for function debug
def test_debug():
    print(messages.info('Running test for function debug...'))
    settings.debug = True
    debug(lambda: 'test_debug')
    settings.debug = False
    debug(lambda: 'test_debug')
    print(messages.success('Test passed.'))
test_debug()

# Generated at 2022-06-22 15:00:51.986918
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
    assert eager(test_fn)() == [1, 2]

# Generated at 2022-06-22 15:00:56.715681
# Unit test for function get_source
def test_get_source():
    def source_func(a, b, c):
        def sub_func(a, b):
            return a + b
        return (a + b) * c + sub_func(a, b)
    assert get_source(source_func) == '    return (a + b) * c + sub_func(a, b)'

# Generated at 2022-06-22 15:01:13.482038
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'assert get_source(test_get_source) == \'assert get_source(test_get_source) == \\\'assert get_source(test_get_source) == \\\\\\\\\\\\\\\'assert get_source(test_get_source) == \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\'assert get_source(test_get_source) == "assert get_source(test_get_source) == \\\'assert get_source(test_get_source) == \\\'\''
# End of unit test

# Generated at 2022-06-22 15:01:17.528649
# Unit test for function get_source
def test_get_source():
    def test_function(a, b, c=3, *args, kw1='kw1', **kwargs):
        x = a + b + c
        return x


# Generated at 2022-06-22 15:01:19.859458
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'



# Generated at 2022-06-22 15:01:22.144935
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    expected = 'def foo():\n    pass\n'
    assert get_source(foo) == expected

# Generated at 2022-06-22 15:01:30.683103
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '    assert get_source(test_get_source) == \'    assert get_source(test_get_source) == \\\'    assert get_source(test_get_source) == \\\'    assert get_source(test_get_source) == \\\'    assert get_source(test_get_source) == \\\'    assert get_source(test_get_source) == \\\'    assert get_source(test_get_source) == \\\'\''

test_get_source()

# Generated at 2022-06-22 15:01:37.899062
# Unit test for function get_source
def test_get_source():
    def test1(): pass
    lines = ['def test1(): pass', '']
    assert get_source(test1) == '\n'.join(lines)

    def test2():
        "Some docstring"
    lines = ['def test2():', '    "Some docstring"', '']
    assert get_source(test2) == '\n'.join(lines)

    def test3():
        '''Multi
        line
        docstring
        '''
    lines = ['def test3():', '    """Multi', '    line', '    docstring', '    """', '']
    assert get_source(test3) == '\n'.join(lines)

# Generated at 2022-06-22 15:01:44.744492
# Unit test for function debug
def test_debug():
    from py_backwards.debug import debug, capture_stdout
    from ..conf import settings

    settings.debug = True
    with capture_stdout() as out:
        debug(lambda: "message")
    assert out.getvalue().strip() == messages.debug("message")

    out.seek(0)
    out.truncate(0)
    settings.debug = False
    debug(lambda: "message")
    assert out.getvalue().strip() == ""



# Generated at 2022-06-22 15:01:46.675514
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        a = 1
        b = 2
        return a + b
    assert get_source(fn) == '    a = 1\n    b = 2\n    return a + b'

# Generated at 2022-06-22 15:01:55.309348
# Unit test for function debug
def test_debug():
    class MockStderr:
        def __init__(self) -> None:
            self.lines = []

        def write(self, line: str) -> None:
            self.lines.append(line)

    stderr = MockStderr()  # type: MockStderr
    old_stderr = sys.stderr.buffer

    try:
        sys.stderr.buffer = stderr
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.lines == ['\033[1;4mDEBUG\033[m: test\n']
    finally:
        sys.stderr.buffer = old_stderr
        settings.debug = False

# Generated at 2022-06-22 15:01:56.744988
# Unit test for function get_source
def test_get_source():
    def func():
        return 1
    assert get_source(func) == '\n        return 1\n    '

# Generated at 2022-06-22 15:02:18.624273
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass'



# Generated at 2022-06-22 15:02:21.633875
# Unit test for function debug
def test_debug():
    settings.set_debug(False)
    debug(lambda: 1)
    settings.set_debug(True)
    debug(lambda: 2)
    settings.set_debug(False)



# Generated at 2022-06-22 15:02:24.633324
# Unit test for function get_source
def test_get_source():
    def foo(): pass
    assert get_source(foo) == 'def foo(): pass'

    def bar():
        pass
    assert get_source(bar) == 'def bar():\n    pass'

# Generated at 2022-06-22 15:02:28.744415
# Unit test for function debug
def test_debug():
    _side_effect = []
    _original_debug = settings.debug

    def get_message():
        _side_effect.append(None)
        return "test_debug"

    try:
        settings.debug = True
        debug(get_message)
        debug(get_message)

        assert _side_effect == [None] * 2
    finally:
        settings.debug = _original_debug

# Generated at 2022-06-22 15:02:40.750180
# Unit test for function get_source
def test_get_source():
    import unittest
    import re

    def fn(a: int, b: int) -> int:
        """Docstring

        More Docstring!
        """
        return a + b

    class Test(unittest.TestCase):
        def test_get_source(self):
            source = get_source(fn)
            self.assertTrue(re.match(r'^def fn\(a: int, b: int\) -> int:', source))
            self.assertTrue(re.match(r'^    """Docstring$', source))
            self.assertTrue(re.match(r'^    More Docstring!$', source))
            self.assertTrue(re.match(r'^    """$', source))
            self.assertTrue(re.match(r'^    return a \+ b$', source))

# Generated at 2022-06-22 15:02:43.024931
# Unit test for function get_source
def test_get_source():
    def func():
        """Docstring."""
        if True:
            return True
        else:
            return False


# Generated at 2022-06-22 15:02:46.683503
# Unit test for function get_source
def test_get_source():
    """Function get_source() works as expected."""

    def fun():
        """
        def fun():
            pass
        """

    assert get_source(fun).strip() == 'def fun():\n    pass'

# Generated at 2022-06-22 15:02:50.308805
# Unit test for function debug
def test_debug():
    assert get_source(debug) == '''
    if settings.debug:
        print(messages.debug(get_message()), file=sys.stderr)
    '''


# Generated at 2022-06-22 15:03:00.520937
# Unit test for function debug
def test_debug():
    # pylint: disable=unused-argument,redefined-outer-name
    def assert_message(debug_message):
        import io
        with io.StringIO() as f:
            sys.stderr = f
            messages.debug_prefix = "WRONG_VALUE"
            settings.debug = False
            debug(lambda: debug_message)
            assert f.getvalue() == ""
            settings.debug = True
            debug(lambda: debug_message)
            assert f.getvalue() == "WRONG_VALUE " + debug_message + "\n"
            messages.debug_prefix = "DEBUG"
            f.truncate(0)
            f.seek(0)
            debug(lambda: debug_message)
            assert f.getvalue() == "DEBUG " + debug_message + "\n"


# Generated at 2022-06-22 15:03:03.562331
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 15:03:34.084900
# Unit test for function debug
def test_debug():
    from .repl import repl_input
    import io
    import sys
    from . import messages

    debug_message = "debug message"
    sys.stderr = io.StringIO()
    debug(lambda: debug_message)
    output = sys.stderr.getvalue()
    assert output == "\r" + messages.debug(debug_message) + "\n"
    # Restore real sys.stdin
    sys.stdin = sys.__stdin__

# Generated at 2022-06-22 15:03:41.759776
# Unit test for function debug
def test_debug():
    with patch('sys.stderr') as stderr:
        print = stderr.write

        messages.debug = lambda message: message
        settings.debug = True
        debug(lambda: 'message')
        assert stderr.write.call_count == 1
        assert stderr.write.call_args_list[0][0][0] == '\x1b[34mmessage\x1b[0m\n'

        settings.debug = False
        debug(lambda: 'other_message')
        assert stderr.write.call_count == 1



# Generated at 2022-06-22 15:03:43.573920
# Unit test for function eager
def test_eager():
    def lazy():
        yield 2
        yield 2
    assert eager(lazy)() == [2, 2]

# Generated at 2022-06-22 15:03:46.241638
# Unit test for function debug
def test_debug():
    assert not settings.debug
    debug(lambda: 'test message')
    settings.debug = True
    try:
        debug(lambda: 'test message')
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:03:48.210773
# Unit test for function eager
def test_eager():
    f = lambda: (i for i in range(3))
    g = eager(f)

    assert g() == [0, 1, 2]



# Generated at 2022-06-22 15:03:49.447440
# Unit test for function debug
def test_debug():
    global settings
    settings = type('', (), {'debug': True})
    debug(lambda: 'test')

# Generated at 2022-06-22 15:03:55.436757
# Unit test for function debug
def test_debug():
    d = []
    def get_message():
        return 'value'
    old = settings.debug
    settings.debug = True
    debug(get_message)
    assert sys.stderr.getvalue() == messages.debug('value') + '\n'
    with settings.override(debug=False):
        debug(get_message)
        assert sys.stderr.getvalue() == messages.debug('value') + '\n'
    settings.debug = old



# Generated at 2022-06-22 15:03:57.802422
# Unit test for function get_source
def test_get_source():
    def _test_function():
        return 2
    source = get_source(_test_function)
    assert source == 'return 2'

# Generated at 2022-06-22 15:03:59.818589
# Unit test for function debug
def test_debug():
    messages.DEBUG_PREFIX = ''
    messages.DEBUG_SUFFIX = ''

    def get_message():
        return 'message'

    debug(get_message)



# Generated at 2022-06-22 15:04:01.927115
# Unit test for function get_source
def test_get_source():
    def func():
        """
        func
        """
        a = 1

    assert get_source(func) == 'a = 1'

# Generated at 2022-06-22 15:04:54.165413
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test).strip() == 'def test():'

# Generated at 2022-06-22 15:04:58.019952
# Unit test for function get_source
def test_get_source():
    def _test(a, b):
        """This function is for testing function get_source."""
        pass
    assert get_source(_test) == 'def _test(a, b):\n    """This function is for testing function get_source."""\n    pass'

# Generated at 2022-06-22 15:05:03.531535
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == 'def get_source(fn: Callable[..., Any]) -> str:"""Returns source code of the function."""source_lines = getsource(fn).split("\\n")padding = len(re.findall(r"^(\\s*)", source_lines[0])[0])return "\\n".join(line[padding:] for line in source_lines)'

# Generated at 2022-06-22 15:05:07.262008
# Unit test for function eager
def test_eager():
    @eager
    def a():
        return map(str, range(10))

    assert (a() == ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'])

# Generated at 2022-06-22 15:05:12.389440
# Unit test for function debug
def test_debug():
    class Context:
        message = ''
    ctx = Context()
    def set_message(message):
        ctx.message = message
    def get_message():
        return ctx.message
    debug(set_message)
    assert get_message() == ''
    settings.debug = True
    debug(set_message)
    assert get_message() == ''

test_debug()

# Generated at 2022-06-22 15:05:23.136756
# Unit test for function get_source

# Generated at 2022-06-22 15:05:24.583709
# Unit test for function debug
def test_debug():
    got = []
    debug(lambda: got.append(1) and 'TEST')
    assert got == [1]



# Generated at 2022-06-22 15:05:26.641528
# Unit test for function eager
def test_eager():
    from random import shuffle
    from time import sleep

    def f(n: int) -> Iterable[int]:
        for i in range(n):
            sleep(0.5)
            yield i
    lst = eager(f)(3)
    assert lst == [0, 1, 2]
    shuffle(lst)
    assert lst == [0, 1, 2]



# Generated at 2022-06-22 15:05:37.240553
# Unit test for function debug
def test_debug():
    class Inner:
        def get_message(self):
            return 'message'
    class Outer:
        class Inner:
            pass
    outer = Outer()
    outer.Inner.get_message = Inner().get_message
    class MockPrint:
        def __init__(self):
            self.printed_lines = []
        def __call__(self, line: str):
            self.printed_lines.append(line)
    mock_print = MockPrint()
    sys.stdout = mock_print
    debug(outer.Inner().get_message)
    assert len(mock_print.printed_lines) == 1
    line = mock_print.printed_lines[0]
    # message must be in the line
    assert 'message' in line
    # message must be in the debug color
    assert messages.DEBUG_

# Generated at 2022-06-22 15:05:43.926756
# Unit test for function eager
def test_eager():
    from itertools import count
    from time import sleep

    def generator() -> Iterable[int]:
        for i in count():
            print(i)
            sleep(1)
            yield i

    def print_first_three_eager(f: Callable[..., Iterable[int]]) -> None:
        for i in f()[:3]:
            print(i)

    def print_first_three_lazy(f: Callable[..., Iterable[int]]) -> None:
        g = f()
        for i in g[:3]:
            print(i)

# Generated at 2022-06-22 15:07:57.046048
# Unit test for function debug
def test_debug():
    sample_messages = [messages.debug('sampel_message_{}'.format(i))
                       for i in range(3)]
    fake_stdout = []  # type: List[str]
    with patch('sys.stderr', fake_stdout):
        settings.debug = False
        for message in sample_messages:
            debug(lambda: message)
        assert len(fake_stdout) == 0

        settings.debug = True
        for message in sample_messages:
            debug(lambda: message)
        assert fake_stdout == sample_messages



# Generated at 2022-06-22 15:07:58.767193
# Unit test for function get_source
def test_get_source():
    def source():
        pass
    assert get_source(source) == 'def source():\n    pass\n'

# Generated at 2022-06-22 15:08:00.617140
# Unit test for function debug
def test_debug():
    if settings.debug:
        raise Exception('settings.debug should not be True')
    debug(lambda: 'test message')  # Should not raise Exception



# Generated at 2022-06-22 15:08:03.044486
# Unit test for function debug
def test_debug():
    global calls
    calls = 0

    @debug
    def fn():
        global calls
        calls += 1
        return 'foo'

    fn()
    assert calls == 1


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-22 15:08:08.478785
# Unit test for function debug
def test_debug():
    output = StringIO()
    sys.stderr = output
    settings.debug = True
    debug(lambda: 'debug message')
    assert output.getvalue() == '\x1b[33mdebug message\n\x1b[0m'
    output.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:08:09.971839
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
    assert eager(f)() == [1,2]

# Generated at 2022-06-22 15:08:13.708051
# Unit test for function eager
def test_eager():
    @eager
    def get_numbers() -> Iterable[int]:
        return range(10)

    assert get_numbers() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:08:16.735155
# Unit test for function eager
def test_eager():
    import random

    def random_numbers(n: int) -> Iterable[int]:
        for _ in range(n):
            yield random.randint(1, 100)

    numbers = eager(random_numbers)(10)
    assert len(numbers) == 10

# Generated at 2022-06-22 15:08:21.323319
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from .. import settings

    settings.debug = False

    with patch('sys.stderr.write') as write_mock:
        debug(lambda: 'msg')
        assert not write_mock.called

    settings.debug = True

    with patch('sys.stderr.write') as write_mock:
        debug(lambda: 'msg')
        assert write_mock.called
        assert write_mock.call_args[0][0].endswith('msg')



# Generated at 2022-06-22 15:08:23.204765
# Unit test for function get_source
def test_get_source():
    def hello():
        return "Hello"
    assert get_source(hello) == 'return "Hello"'