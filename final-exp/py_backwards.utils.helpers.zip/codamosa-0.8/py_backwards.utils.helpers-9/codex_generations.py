

# Generated at 2022-06-22 14:58:36.470705
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'



# Generated at 2022-06-22 14:58:38.236421
# Unit test for function get_source
def test_get_source():
    def _get_source():
        return _get_source

    assert get_source(_get_source) == 'return _get_source'

# Generated at 2022-06-22 14:58:40.209968
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1

    expected_source = 'a = 1'
    assert get_source(test) == expected_source

# Generated at 2022-06-22 14:58:45.096687
# Unit test for function eager
def test_eager():
    test_list = [1, 2, 3, 4, 5]
    def test_function(lst):
        for i in lst:
            yield i
    assert eager(test_function)(test_list) == test_list


# Generated at 2022-06-22 14:58:51.031348
# Unit test for function get_source
def test_get_source():
    def foo():
        if True:
            print("if")
        else:
            print("else")
    assert foo.__code__.co_filename.endswith("utils.py")
    for path in get_source(foo).split('\n'):
        assert not any(x.startswith("    ") for x in path.split("if")[1:])

# Generated at 2022-06-22 14:58:52.619459
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'pass'



# Generated at 2022-06-22 14:58:56.312106
# Unit test for function eager
def test_eager():
    def get_lazy_generator() -> Iterable[int]:
        for i in range(10):
            yield i
    assert eager(get_lazy_generator)(20) == [20]
    assert eager(get_lazy_generator)() == list(range(10))



# Generated at 2022-06-22 14:58:59.446880
# Unit test for function get_source
def test_get_source():
    source = get_source(get_source)
    assert(isinstance(source, str))
    assert("import re\n" in source)

# Generated at 2022-06-22 14:59:04.005787
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)'

# Generated at 2022-06-22 14:59:15.519573
# Unit test for function get_source
def test_get_source():
    def fn(x=1, y=2):
        """Some function."""
        def inner_function(a, b):
            pass

        return (
            (
                'Multiple',
                'lines'
            )
        )


# Generated at 2022-06-22 14:59:24.429920
# Unit test for function debug
def test_debug():
    from pytest import capsys
    settings.debug = True
    debug(lambda: 'foo')

    out, err = capsys.readouterr()
    assert err == '\x1b[33mPyBackwards Debug: foo\x1b[0m\n'

    settings.debug = False
    debug(lambda: 'foo')

    out, err = capsys.readouterr()
    assert err == ''



# Generated at 2022-06-22 14:59:26.250496
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 14:59:30.747082
# Unit test for function debug
def test_debug():
    settings.DEBUG = True
    messages.DEBUG = 'DEBUG'
    output = StringIO()
    sys.stderr = output
    debug(lambda: 'debug message')
    assert output.getvalue() == 'DEBUG debug message\n'
    output.close()
    settings.DEBUG = False
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 14:59:32.408702
# Unit test for function get_source
def test_get_source():
    def f(a):
        return a + 3

    src = get_source(f)


# Generated at 2022-06-22 14:59:35.138336
# Unit test for function get_source
def test_get_source():
    def fn():
        def inner():
            pass
    assert get_source(fn) == 'def fn():\n    def inner():\n        pass'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-22 14:59:38.212361
# Unit test for function get_source
def test_get_source():
    def fn():
        return True

    expected = 'return True'
    assert get_source(fn).strip() == expected



# Generated at 2022-06-22 14:59:45.744379
# Unit test for function debug
def test_debug():
    import pytest
    def not_called() -> str:
        pytest.fail("function not called")

    with pytest.raises(Exception):
        debug(not_called)

    from io import StringIO
    with StringIO() as output:
        value = "some variable"
        debug(lambda: value)
        output.seek(0)
        assert output.read() == ''

        settings.debug = True
        debug(lambda: value)

        output.seek(0)
        assert output.read().endswith("{}\n".format(value))



# Generated at 2022-06-22 14:59:48.754191
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == "def f():\n    pass"



# Generated at 2022-06-22 14:59:51.249268
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 14:59:53.824344
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Test')
    settings.debug = False
    debug(lambda: 'Test')

# Generated at 2022-06-22 15:00:02.028280
# Unit test for function get_source
def test_get_source():
    # pylint: disable=no-self-use
    class Test:
        """Class for test."""
        def method(self) -> None:
            # pylint: disable=unused-variable
            a = self
    assert get_source(Test.method) == 'def method(self) -> None:\n' \
                                     '    # pylint: disable=unused-variable\n' \
                                     '    a = self'

# Generated at 2022-06-22 15:00:06.519750
# Unit test for function get_source
def test_get_source():
    def a():
        return 2

    assert get_source(a) == 'return 2'

    def b():
        print('1')
        return 3

    assert get_source(b) == 'print(\'1\')\nreturn 3'

# Generated at 2022-06-22 15:00:09.661059
# Unit test for function eager
def test_eager():
    def get_gen() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    wrapper = eager(get_gen)

    assert wrapper() == [1, 2, 3]



# Generated at 2022-06-22 15:00:12.426953
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    expected = """
    def test_function():
        pass
    """.strip()

    assert get_source(test_function) == expected

# Generated at 2022-06-22 15:00:14.307778
# Unit test for function get_source
def test_get_source():
    def foo():
        return "Hello"
    assert get_source(foo) == 'return "Hello"'

# Generated at 2022-06-22 15:00:15.936106
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'pass'

# Generated at 2022-06-22 15:00:18.623944
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n', "function get_source doesn't work"

# Generated at 2022-06-22 15:00:20.641392
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n' \
                               '    pass\n'

# Generated at 2022-06-22 15:00:24.928913
# Unit test for function debug
def test_debug():
    messages.debug = lambda m: m
    settings.debug = True
    assert debug(lambda: 'test') == None
    settings.debug = False
    assert debug(lambda: 'test') == None

# Generated at 2022-06-22 15:00:27.252307
# Unit test for function get_source
def test_get_source():
    def function():
        def nested():
            def nested_again():
                return 7
        return nested_again

    assert get_source(function) == 'def nested():\n       ' \
                                   '  def nested_again():\n       ' \
                                   '      return 7\n'

# Generated at 2022-06-22 15:00:39.347941
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '''
    def test_get_source():
        assert get_source(test_get_source) == '''

# Generated at 2022-06-22 15:00:41.504131
# Unit test for function eager
def test_eager():
    def foo():
        return [2, 3, 5]

    assert eager(foo)() == foo()

# Generated at 2022-06-22 15:00:44.552389
# Unit test for function eager
def test_eager():
    @eager
    def test_function(arg1, arg2):
        yield arg1
        yield arg2
    
    assert test_function([1, 2], [3, 4]) == [[1, 2], [3, 4]]



# Generated at 2022-06-22 15:00:48.036631
# Unit test for function debug
def test_debug():
    if not settings.debug:
        settings.debug = True
        debug(lambda: '2')
        settings.debug = False

test_debug()

if __name__ == '__main__':
    pass

# Generated at 2022-06-22 15:00:52.816518
# Unit test for function eager
def test_eager():
    intervals = [0.1, 0.2, 0.3, 0.4, 0.5]

    @eager
    def time_based_interval():
        for interval in intervals:
            yield interval

    assert time_based_interval() == intervals

# Generated at 2022-06-22 15:00:57.656557
# Unit test for function get_source
def test_get_source():
    def f(a):
        def g(b):
            return a + b
        return g(1) + 2
    assert f(1) == 5
    src = '''def f(a):
    def g(b):
        return a + b
    return g(1) + 2
'''
    assert get_source(f) == src

# Generated at 2022-06-22 15:00:59.665011
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
    assert get_source(foo) == '\n    def bar():\n        pass'

# Generated at 2022-06-22 15:01:02.677554
# Unit test for function debug
def test_debug():
    import pytest

    def debug_test():
        debug(lambda: "hi")

    with pytest.raises(AssertionError):
        debug_test()



# Generated at 2022-06-22 15:01:05.590594
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    foo_source = 'def foo():\n    pass\n'
    assert get_source(foo) == foo_source



# Generated at 2022-06-22 15:01:12.013308
# Unit test for function eager
def test_eager():
    class LazyList(list):
        def __init__(self, value):
            self._value = value

        def __getitem__(self, index):
            return self._value

    class FakeIterator:
        def __iter__(self):
            return self

        def __next__(self):
            raise StopIteration
    assert eager(LazyList)(0) == [0]
    assert eager(FakeIterator)(0) == []

# Generated at 2022-06-22 15:01:33.635695
# Unit test for function eager
def test_eager():
    def test_func():
        yield 1
        yield 2

    assert eager(test_func)() == [1, 2]

# Generated at 2022-06-22 15:01:35.473117
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-22 15:01:36.882294
# Unit test for function eager
def test_eager():
    assert eager(list)('string') == ['s', 't', 'r', 'i', 'n', 'g']

# Generated at 2022-06-22 15:01:39.053581
# Unit test for function debug
def test_debug():
    def get_message(): return 'Message'
    sys.stderr = StringIO()
    debug(get_message)
    assert sys.stderr.getvalue().strip() == '>>> Message'


# Generated at 2022-06-22 15:01:40.527529
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    print(get_source(function))

# Generated at 2022-06-22 15:01:43.286967
# Unit test for function debug
def test_debug():
    settings.debug = True

    msg = '\n'.join(['Hello', 'World!'])
    debug(lambda: msg)

    settings.debug = False
    debug(lambda: msg)

# Generated at 2022-06-22 15:01:44.496582
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    print(get_source(fn))


# Generated at 2022-06-22 15:01:54.301955
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)

# Generated at 2022-06-22 15:01:56.602409
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i

    assert gen(10) == list(range(10))


# Generated at 2022-06-22 15:02:08.535052
# Unit test for function get_source

# Generated at 2022-06-22 15:02:59.405916
# Unit test for function get_source
def test_get_source():
    import inspect
    from .transformer import transformer

    def foo(x):
        """This is a docstring in foo."""

        def bar(y):
            """This is a docstring in bar."""
            return x + y

        return bar(x)

    def test_get_source(fn, expected_source):
        assert get_source(fn) == expected_source

    test_get_source(foo, """def bar(y):
    """ + '"""' + """This is a docstring in bar.
    return x + y""")
    test_get_source(foo, """def bar(y):
    """ + '"""' + """This is a docstring in bar.
    return x + y""")
    # test_get_source(foo, """def bar(y):
    # """ + '"""' + """

# Generated at 2022-06-22 15:03:01.760929
# Unit test for function eager
def test_eager():
    def g():
        yield 1
        yield 2
    assert eager(g)() == [1, 2]

# Generated at 2022-06-22 15:03:07.078803
# Unit test for function debug
def test_debug():
    import io

    with io.StringIO() as stderr:
        sys.stderr = stderr

        try:
            debug(lambda: 'Hello')
            assert stderr.getvalue() == messages.debug('Hello') + '\n'
        finally:
            sys.stderr = sys.__stderr__



# Generated at 2022-06-22 15:03:09.326276
# Unit test for function get_source
def test_get_source():
    def fn():
        print('Test')
    assert get_source(fn) == 'print(\'Test\')'

# Generated at 2022-06-22 15:03:20.748130
# Unit test for function get_source
def test_get_source():
    import inspect
    source = '''def test_get_source():
    import inspect
    source = 'abc'
    source_lines = source.split('\\n')
    padding = len(re.findall(r'^(\\s*)', source_lines[0])[0])
    return '\\n'.join(line[padding:] for line in source_lines)'''
    def test_get_source():
        import inspect
        source = 'abc'
        source_lines = source.split('\n')
        padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
        return '\n'.join(line[padding:] for line in source_lines)
    def test_get_source():
        import inspect
        source = 'abc'
        source_lines = source.split

# Generated at 2022-06-22 15:03:26.689248
# Unit test for function debug
def test_debug():
    with unittest.mock.patch('py_backwards.base.settings') as settings_mock:
        settings_mock.debug = True
        with unittest.mock.patch('sys.stderr') as stderr_mock:
            debug(lambda: 'test')
            assert stderr_mock.write.call_args_list == [unittest.mock.call(messages.debug('test') + '\n')]



# Generated at 2022-06-22 15:03:29.777856
# Unit test for function eager
def test_eager():
    def iterator():
        yield from range(10)

    assert eager(iterator)() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:03:31.819078
# Unit test for function eager
def test_eager():
    @eager
    def x():
        for i in range(1, 4):
            yield i

    assert x() == [1, 2, 3]

# Generated at 2022-06-22 15:03:33.807408
# Unit test for function debug
def test_debug():
    msg = 'haha'
    debug(lambda: msg)
    assert msg == 'haha'

# Generated at 2022-06-22 15:03:36.126886
# Unit test for function get_source
def test_get_source():
    def f():
        """Function f"""
        pass
    assert get_source(f) == 'def f():\n    """Function f"""\n    pass'



# Generated at 2022-06-22 15:04:32.889777
# Unit test for function debug
def test_debug():
    print('test_debug', end=': ')
    settings.debug = True

    def check():
        message = 'debug message'

        def get_message():
            return message

        debug(get_message)

    check()
    settings.debug = False
    print('OK')



# Generated at 2022-06-22 15:04:37.199040
# Unit test for function get_source
def test_get_source():
    def _test_get_source():
        def test():
            """Test function."""
            pass
        pass  # fake line

    assert get_source(_test_get_source).strip() == 'pass  # fake line'

# Generated at 2022-06-22 15:04:39.695490
# Unit test for function debug
def test_debug():
    debug(lambda: 'message')
    settings.debug = True
    try:
        assert debug(lambda: 'message') == None
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:04:42.788710
# Unit test for function debug
def test_debug():
    from .test_helpers import patch_input

    settings.debug = True

    with patch_input('bar', 'hello', 'world'):
        debug(lambda: input())
        debug(lambda: input())

# Generated at 2022-06-22 15:04:44.410963
# Unit test for function get_source
def test_get_source():
    def example():
        pass
    assert get_source(example) == 'pass'

# Generated at 2022-06-22 15:04:46.742792
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1
    assert get_source(test) == 'a = 1'
    assert get_source(get_source) == get_source.__code__.co_code

# Generated at 2022-06-22 15:04:57.712964
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase
    from contextlib import contextmanager

    class Test(TestCase):
        def setUp(self):
            settings.debug = True
            self.debug_output = StringIO()
            self.debug_output.name = '<debug_output>'

        @contextmanager
        def captured_output(self, stream=sys.stdout):
            old_stdout = stream
            try:
                stream.close()
                stream = self.debug_output
                sys.stdout = stream
                yield stream
            finally:
                stream.close()
                sys.stdout = old_stdout

        def test_debug(self):
            with self.captured_output():
                debug(lambda: 'spam')

# Generated at 2022-06-22 15:04:59.947104
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == '    pass'


# Generated at 2022-06-22 15:05:02.410457
# Unit test for function eager
def test_eager():
    def doubler(n: int) -> Iterable[int]:
        yield n
        yield n

    assert len(eager(doubler)(2)) == 2

# Generated at 2022-06-22 15:05:12.390621
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    import unittest

    class TestDebug(unittest.TestCase):

        def test_prints_debug_message_if_debug_mode(self):
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                settings.debug = True
                debug(lambda: 'debug')
            self.assertIn('debug', buf.getvalue())

        def test_doesnt_print_debug_message_if_not_debug_mode(self):
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                settings.debug = False
                debug(lambda: 'debug')
            self.assertNotIn('debug', buf.getvalue())

    unittest.main()

# Generated at 2022-06-22 15:07:17.514251
# Unit test for function get_source
def test_get_source():
    def my_function():
        pass

    assert get_source(my_function) == "def my_function():\n    pass"

# Generated at 2022-06-22 15:07:22.083590
# Unit test for function eager
def test_eager():
    def some_function():
        yield 1
        yield 2
        yield 3
        yield 4
        yield 5

    assert eager(some_function)() == [1, 2, 3, 4, 5]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:07:26.841734
# Unit test for function get_source
def test_get_source():
    def func_to_test():
        a = 1
        b = 2
        return a + b

    def func_to_test_with_white_space():
        a = 1
        b = 2
        c = 3
        return a + b + c

    assert get_source(func_to_test) == 'a = 1\nb = 2\nreturn a + b'
    assert get_source(func_to_test_with_white_space) == (
        'a = 1\nb = 2\nc = 3\nreturn a + b + c'
    )

# Generated at 2022-06-22 15:07:33.694336
# Unit test for function debug
def test_debug():
    test_output = []
    '''
    def print(message, **kwargs):
        test_output.append(message)

    def get_message():
        return '[test]'
    sys.stderr = print

    settings.debug = True
    debug(get_message)
    assert test_output[0] == '[py_backwards] [DEBUG] [test]'
    test_output.clear()

    settings.debug = False
    debug(get_message)
    assert test_output == []
    '''

# Generated at 2022-06-22 15:07:38.322260
# Unit test for function eager
def test_eager():
    # pylint: disable=import-outside-toplevel
    from . import _eager

    @eager
    def some_fn() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    # pylint: disable=protected-access
    assert _eager.some_fn() == [1, 2, 3]

# Generated at 2022-06-22 15:07:40.137986
# Unit test for function get_source
def test_get_source():
    def target():
        """Comments
        more comments
        more lines
        """
        a = 1
        b = 2
        return a + b


# Generated at 2022-06-22 15:07:44.105403
# Unit test for function get_source
def test_get_source():
    def test_fn(x: int) -> None:
        return x  # nosec

    assert get_source(test_fn) == 'return x  # nosec'



# Generated at 2022-06-22 15:07:47.551287
# Unit test for function get_source
def test_get_source():
    def function(a, b, c):
        return a, b, c

    assert get_source(function) == textwrap.dedent(function.__doc__)



# Generated at 2022-06-22 15:07:49.822945
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-22 15:07:51.986321
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
    assert get_source(foo) == '\n    def bar():\n        pass'