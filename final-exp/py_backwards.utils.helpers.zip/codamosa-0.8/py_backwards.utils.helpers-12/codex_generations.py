

# Generated at 2022-06-22 14:58:40.965922
# Unit test for function debug
def test_debug():
    messages.debug = lambda message: 'DEBUG: ' + message

    class FakeStream:
        def __init__(self) -> None:
            self.content = []

        def write(self, message: str) -> None:
            self.content.append(message)

    def run(debug: bool) -> str:
        old_stderr = sys.stderr
        sys.stderr = FakeStream()
        settings.debug = debug
        debug(lambda: 'test')
        sys.stderr = old_stderr
        return '\n'.join(sys.stderr.content)

    assert run(True) == 'DEBUG: test'
    assert run(False) == ''

# Generated at 2022-06-22 14:58:51.181057
# Unit test for function debug
def test_debug():
    from types import FunctionType
    from io import StringIO
    from contextlib import redirect_stdout
    from ..conf import settings

    assert callable(debug)
    assert all(arg in getfullargspec(debug) for arg in ('get_message',))
    assert debug.__annotations__['get_message'] is Callable[[], str]
    assert 'return None' in debug.__doc__

    # Test debug
    def example():
        output = StringIO()
        with redirect_stdout(output):
            debug(lambda: 'foo')
            debug(lambda: 'bar')
        assert output.getvalue() == 'foo\nbar\n'

    # Test no debug
    settings.debug = False
    example()

# Generated at 2022-06-22 14:58:51.799786
# Unit test for function eager
def test_eager():
    pass

# Generated at 2022-06-22 14:59:03.558504
# Unit test for function debug
def test_debug():
    from io import StringIO

    from .. import messages

    import sys
    import backwards

    with StringIO() as buf, unittest.mock.patch.object(sys, 'stderr', new=buf):
        backwards.debug(lambda: 'foo msg')
        assert not buf.getvalue()
        with unittest.mock.patch.object(backwards.settings, 'debug', True):
            backwards.debug(lambda: 'foo msg')
            assert messages.debug('foo msg') in buf.getvalue()
            backwards.debug(lambda: 'bar msg')
            assert messages.debug('bar msg') in buf.getvalue()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    import unittest
    unittest.main(exit=False)

# Generated at 2022-06-22 14:59:05.004676
# Unit test for function get_source
def test_get_source():
    def foo():  # noqa
        return 's'

    source = get_source(foo)
    assert source == "return 's'"

# Generated at 2022-06-22 14:59:06.466349
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == 'def fn():\n    pass\n'

# Generated at 2022-06-22 14:59:11.460155
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stderr
    debug(lambda: 'test')
    with redirect_stderr(io.StringIO()) as f:
        debug(lambda: 'test')
    assert 'test' not in f.getvalue()



# Generated at 2022-06-22 14:59:13.809370
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-22 14:59:15.233644
# Unit test for function get_source
def test_get_source():
    def f(): pass
    assert get_source(f) == 'pass'

# Generated at 2022-06-22 14:59:21.347658
# Unit test for function eager
def test_eager():
    def iterator_factory(is_active: bool, value: T) -> Iterable[T]:
        while is_active:
            yield value
    iterable = iterator_factory(True, 0)
    assert isinstance(iterable, Iterable)
    assert not isinstance(iterable, list)
    eager_list = eager(iterator_factory)(False, 'value')
    assert isinstance(eager_list, list)
    assert not isinstance(eager_list, Iterable)



# Generated at 2022-06-22 14:59:25.351059
# Unit test for function eager
def test_eager():
    def fn():
        yield 1
        yield 2
        yield 3

    assert eager(fn)() == [1, 2, 3]



# Generated at 2022-06-22 14:59:29.447560
# Unit test for function debug
def test_debug():
    def get_message() -> str:
        return 'some message'

    assert not sys.stderr.getvalue()
    debug(get_message)
    assert not sys.stderr.getvalue()

    settings.debug = True
    debug(get_message)
    assert sys.stderr.getvalue()

# Generated at 2022-06-22 14:59:30.909177
# Unit test for function debug
def test_debug():
    # unittest.TestCase.assertFalse will be deprecated soon, so we can't use it here
    assert not 'message' in debug.__code__.co_names



# Generated at 2022-06-22 14:59:32.790788
# Unit test for function get_source
def test_get_source():
    function_definition = """if True:
        def foo():
            bar()
            baz()
        """

    assert get_source(foo) == """def foo():
    bar()
    baz()
"""

# Generated at 2022-06-22 14:59:43.745292
# Unit test for function debug
def test_debug():
    messages.debug = lambda message: message

    class MockSys:
        stderr = None
        @classmethod
        def reset(cls):
            cls.stderr = None

        def __getattr__(self, attr):
            if attr == 'stderr':
                if self.stderr is None:
                    self.stderr = StringIO()
                    return self.stderr
                else:
                    raise AttributeError
            else:
                raise AttributeError

    sys = MockSys()
    settings.debug = True
    print(debug(lambda: 'mes'))
    assert sys.stderr.getvalue() == 'mes\n'

    sys.reset()
    settings.debug = False
    print(debug(lambda: 'mes'))
    assert sys.stderr.getvalue

# Generated at 2022-06-22 14:59:49.152021
# Unit test for function debug
def test_debug():
    class Test:
        def __init__(self):
            self.called = False

        def action(self):
            self.called = True

    t = Test()
    debug(t.action)
    assert not t.called

    try:
        settings.debug = True
        debug(t.action)
    finally:
        settings.debug = False
    assert t.called



# Generated at 2022-06-22 14:59:50.838299
# Unit test for function eager
def test_eager():
    assert eager(range)(1, 2) == [1]

# Generated at 2022-06-22 14:59:54.207905
# Unit test for function eager
def test_eager():
    @eager
    def a1():
        for x in range(10):
            yield x
    assert a1() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:00:05.518856
# Unit test for function debug
def test_debug():
    from io import StringIO
    output = StringIO()
    try:
        old_stderr, sys.stderr = sys.stderr, output
        old_debug = settings.debug
        settings.debug = True
        debug(lambda: 'This is debug message')
        assert output.getvalue() == ''
    finally:
        sys.stderr = old_stderr
        settings.debug = old_debug

    output = StringIO()
    try:
        old_stderr, sys.stderr = sys.stderr, output
        settings.debug = False
        debug(lambda: 'This is debug message')
        assert output.getvalue() == ''
    finally:
        sys.stderr = old_stderr
        settings.debug = True

    output = StringIO()

# Generated at 2022-06-22 15:00:09.457193
# Unit test for function get_source
def test_get_source():
    def fn(a, b, c=1, d=2):
        return a + b + c + d
    assert get_source(fn).split('\n') == ['def fn(a, b, c=1, d=2):', '    return a + b + c + d']

# Generated at 2022-06-22 15:00:14.218564
# Unit test for function debug
def test_debug():
    message = 'Hello World!'
    debug(lambda: message)



# Generated at 2022-06-22 15:00:18.386792
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        i = 0
        while True:
            i += 1
            yield i
    assert foo() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-22 15:00:19.339837
# Unit test for function get_source
def test_get_source():
    get_source(test_get_source)

# Generated at 2022-06-22 15:00:22.723771
# Unit test for function eager
def test_eager():
    def fun(a):
        for i in range(a):
            yield i
    print(eager(fun)(1))

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-22 15:00:30.157053
# Unit test for function debug
def test_debug():
    import sys
    import contextlib
    import io

    @contextlib.contextmanager
    def capture_stderr():
        old = sys.stderr
        stderr = io.StringIO()
        sys.stderr = stderr
        yield stderr
        sys.stderr = old

    settings.debug = True
    with capture_stderr() as stderr:
        debug(lambda: 1 + 2)
    assert '3' in stderr.getvalue()



# Generated at 2022-06-22 15:00:35.437750
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        try:
            debug(lambda: 'test message')
        except AssertionError:
            assert False, 'Assertion should not be raised'
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:00:42.000453
# Unit test for function debug
def test_debug():
    logged_message: str = ""

    def get_message():
        nonlocal logged_message
        return logged_message

    def test_case():
        debug(get_message)

    old_debug = settings.debug
    settings.debug = True
    logged_message = "logged_message"
    try:
        test_case()

        assert(logged_message == "")
    finally:
        settings.debug = old_debug



# Generated at 2022-06-22 15:00:43.644877
# Unit test for function get_source
def test_get_source():
    def test_case(a, b):
        pass

    assert get_source(test_case) == 'def test_case(a, b):\n    pass\n'



# Generated at 2022-06-22 15:00:45.758028
# Unit test for function get_source
def test_get_source():
    def foo(x):
        return x

    source = get_source(foo)

    assert source == 'def foo(x):\n    return x'



# Generated at 2022-06-22 15:00:50.983977
# Unit test for function eager
def test_eager():
    import random
    def rand(times):
        for _ in range(times):
            yield random.random()
    assert len(list(rand(100))) == 100

    assert len(eager.wrapped(rand)(100)) == 100

# Generated at 2022-06-22 15:01:03.757233
# Unit test for function get_source
def test_get_source():
    from inspect import getsource

    def test_func():
        def inner():
            pass

        return inner

    expected_source = 'def inner():\n    pass\n\n'
    source = get_source(test_func())
    assert source == expected_source
    # Because get_source() is removing first 4 whitespaces
    assert getsource(test_func) == expected_source + '    '

# Generated at 2022-06-22 15:01:12.538416
# Unit test for function eager
def test_eager():
    def dummy_eager_generator(n):
        print("Generating values")
        for i in range(n):
            yield i

    print("Generating first list")
    l1 = eager(dummy_eager_generator)(4)
    print("Generating second list")
    l2 = eager(dummy_eager_generator)(4)
    print("Done generating lists")
    print("First list:")
    print(l1)
    print("Second list:")
    print(l2)

if __name__ == "__main__":
    test_eager()

# Generated at 2022-06-22 15:01:16.267122
# Unit test for function debug
def test_debug():
    msg = ''
    def get_message():
        return msg

    try:
        settings.debug = True
        debug(get_message)
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:01:20.277032
# Unit test for function debug
def test_debug():
    messages.reset()
    settings.debug = True

    def get_message():
        return 'message'

    debug(get_message)
    assert settings.debug

    messages.reset()
    settings.debug = False

    debug(get_message)
    assert not settings.debug

# Generated at 2022-06-22 15:01:25.286648
# Unit test for function debug
def test_debug():
    def get_debug_msg():
        return 'debug message'
    # Case: Debug is disabled.
    settings.debug = False
    assert debug(get_debug_msg) is None

    # Case: Debug is enabled
    settings.debug = True
    assert debug(get_debug_msg) is None

# Generated at 2022-06-22 15:01:35.708685
# Unit test for function debug
def test_debug():
    import io
    import unittest

    class DebugTest(unittest.TestCase):
        def test_debug_msg_is_printed(self):
            settings.debug = True
            messages.debug = 'debug message'
            capture = io.StringIO()
            try:
                debug(lambda: messages.debug)
            except Exception as e:
                self.fail('debug() raised %s' % e)
            sys.stderr = capture
            sys.stdout = capture
            self.assertEqual(sys.stderr.getvalue(), messages.debug + '\n')
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__
        def test_debug_msg_is_not_printed(self):
            settings.debug = False

# Generated at 2022-06-22 15:01:38.250655
# Unit test for function get_source
def test_get_source():
    def foo():
        """test"""
        pass


# Generated at 2022-06-22 15:01:42.122764
# Unit test for function eager
def test_eager():
    @eager
    def fn(n: int) -> Iterable[int]:
        for i in range(n):
            yield i
    assert fn(3) == [0, 1, 2]

# Generated at 2022-06-22 15:01:45.519415
# Unit test for function eager
def test_eager():
    @eager
    def fn() -> Iterable[int]:
        for i in range(10):
            yield i**2
    assert fn() == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# Generated at 2022-06-22 15:01:47.977042
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'assert get_source(test_get_source) == \\\n    \'assert get_source(test_get_source) == {}\\\'\''.format(repr(get_source(test_get_source)))  # noqa

# Generated at 2022-06-22 15:02:08.683156
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'message')
    settings.debug = False

# Generated at 2022-06-22 15:02:16.700160
# Unit test for function debug
def test_debug():
    import random
    import tempfile
    from contextlib import redirect_stderr
    from ..conf import settings

    with tempfile.TemporaryFile() as f:
        with redirect_stderr(f) as err:
            settings.debug = True
            value = random.randint(1, 100)
            message = 'Value is {}'.format(value)
            debug(lambda: message)
        f.seek(0)
        actual = f.read().decode()
        assert actual == messages.debug(message) + '\n'
        err.close()



# Generated at 2022-06-22 15:02:22.729659
# Unit test for function debug
def test_debug():
    import pytest
    from . import messages

    @debug
    def f():
        return 'Hello, World!'

    with pytest.raises(SystemExit):
        # debug is not print to stdout by default
        f()

    settings.debug = True
    f() == f'{messages.BLUE}[DEBUG]{messages.END} Hello, World!\n'

# Generated at 2022-06-22 15:02:25.845573
# Unit test for function get_source
def test_get_source():
    def foo():
        x = 1
        y = 2
        return x + y

    assert get_source(foo) == 'x = 1\ny = 2\nreturn x + y\n'

# Generated at 2022-06-22 15:02:27.852043
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]



# Generated at 2022-06-22 15:02:29.601516
# Unit test for function get_source
def test_get_source():
    def function():
        return 'result'

    assert get_source(function) == '    return \'result\'\n'


# Generated at 2022-06-22 15:02:36.766429
# Unit test for function get_source
def test_get_source():
    def some_func(arg: int):
        print(arg)

    def some_func_decorated(arg: int):
        print(arg)

    some_func_decorated = backward_compatible(some_func_decorated)
    source1 = get_source(some_func)
    source2 = get_source(some_func_decorated)
    assert source1 == source2

# Generated at 2022-06-22 15:02:38.858997
# Unit test for function eager
def test_eager():
    @eager
    def test() -> Iterable[int]:
        yield 1

    assert test() == [1]

# Generated at 2022-06-22 15:02:40.987470
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-22 15:02:45.180518
# Unit test for function get_source
def test_get_source():
    def func():
        a = 3
        return a

    assert get_source(func).strip('\n').split('\n') == [
        'def func():',
        '    a = 3',
        '    return a',
    ]


# Generated at 2022-06-22 15:03:38.693715
# Unit test for function debug
def test_debug():
    message = 'Simple string'

    class MemoryStdErr:
        def __init__(self):
            self.text = ''
        def write(self, text):
            self.text += text

    out = MemoryStdErr()
    settings.debug = False
    sys.stderr = out
    debug(lambda: message)
    assert out.text == ''

    out = MemoryStdErr()
    settings.debug = True
    sys.stderr = out
    debug(lambda: message)
    assert out.text == '{}\n'.format(messages.debug(message))

# Generated at 2022-06-22 15:03:40.786371
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-22 15:03:43.574563
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        return a + b

    print(get_source(foo))

    def foo(a, b):
        return a +       b

    print(get_source(foo))

# Generated at 2022-06-22 15:03:45.933271
# Unit test for function get_source
def test_get_source():
    """Test get_source function."""
    def foo():  # noqa
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 15:03:48.461551
# Unit test for function eager
def test_eager():
    test_list = [1, 5, 3]
    
    @eager
    def sort_test_list():
        return sorted(test_list)

    assert sort_test_list() == test_list


# Generated at 2022-06-22 15:03:49.571739
# Unit test for function debug
def test_debug():
    debug(lambda: 'Test')

# Generated at 2022-06-22 15:03:59.259798
# Unit test for function debug
def test_debug():
    def side_effect_message():
        return "void function"

    def assert_func(expected_message):
        assert_side_effect.message = None

        def side_effect():
            assert_side_effect.message = expected_message

        assert_side_effect.side_effect = side_effect

    def assert_side_effect():
        assert_side_effect.side_effect()

    assert_func.reset_mock = lambda: None
    assert_side_effect.reset_mock = lambda: None

    def side_effect_message():
        return "string message"

    assert_func(side_effect_message())
    debug(side_effect_message)
    assert assert_side_effect.message == side_effect_message()


# Generated at 2022-06-22 15:04:01.369834
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(3):
            yield i
    assert eager(foo)() == [0, 1, 2]

# Generated at 2022-06-22 15:04:06.348676
# Unit test for function debug
def test_debug():
    import unittest
    import contextlib
    @contextlib.contextmanager
    def debug_set(setting):
        old_setting = settings.debug
        settings.debug = setting
        yield
        settings.debug = old_setting
    class Test(unittest.TestCase):
        def test__debug_not_debug(self):
            with debug_set(False):
                self.assertFalse('debug' in debug.__name__)
        def test__debug_debug(self):
            with debug_set(True):
                self.assertTrue('debug' in debug.__name__)
    unittest.main()

# Generated at 2022-06-22 15:04:07.593091
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'a')



# Generated at 2022-06-22 15:05:50.550297
# Unit test for function debug
def test_debug():
    with settings.override(debug=True):
        debug(lambda: 'foo')

    with settings.override(debug=False):
        debug(lambda: 'bar')

# Generated at 2022-06-22 15:05:53.457568
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == (
        "assert get_source(test_get_source) == (\n"
        "    'assert get_source(test_get_source) == ('\n"
        "    '    \')\')'\n"
        '    )'
    )

# Generated at 2022-06-22 15:05:57.420010
# Unit test for function get_source
def test_get_source():
    def fn(x: int) -> int:
        return x

    assert get_source(fn) == (
        'def fn(x: int) -> int:\n'
        '    return x\n'
    )

# Generated at 2022-06-22 15:06:00.453522
# Unit test for function get_source
def test_get_source():
    def a():
        print(1)

    result = get_source(a)
    expected = "print(1)"

    assert result == expected

# Generated at 2022-06-22 15:06:00.900803
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo')

# Generated at 2022-06-22 15:06:02.108488
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'

# Generated at 2022-06-22 15:06:05.231689
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

    def g():
      pass

    assert get_source(g) == 'pass'

# Generated at 2022-06-22 15:06:10.613085
# Unit test for function eager
def test_eager():
    l = [1, 2, 3, 4]

    @eager
    def fn1() -> Iterable[int]:
        for i in range(10):
            yield i

    @eager
    def fn2() -> List[int]:
        return l

    assert fn1() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert fn2() == l

# Generated at 2022-06-22 15:06:18.648743
# Unit test for function eager
def test_eager():
    from py_backwards.wrappers import Wrapper

    class TestWrapper(Wrapper[T]):
        @staticmethod
        def apply_before(
            fn: Callable[..., Iterable[T]],
        ) -> Callable[..., Iterable[T]]:
            @wraps(fn)
            def wrapped(*args: Any, **kwargs: Any) -> Iterable[T]:
                return list(fn(*args, **kwargs))

            return wrapped

    def get_iterator():
        for i in range(2):
            yield i

    assert list(get_iterator()) == [0, 1]
    assert TestWrapper.apply_before(get_iterator)() == [0, 1]

# Generated at 2022-06-22 15:06:21.391175
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    source = get_source(fn)
    assert source == "def fn():\n    pass"