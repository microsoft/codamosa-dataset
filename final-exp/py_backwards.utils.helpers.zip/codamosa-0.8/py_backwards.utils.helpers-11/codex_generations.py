

# Generated at 2022-06-22 14:58:34.858694
# Unit test for function debug
def test_debug():
    assert settings.debug is False
    debug(lambda: 'test')
    settings.debug = True
    debug(lambda: 'test')

# Generated at 2022-06-22 14:58:40.366317
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    def fn2(a, b):
        pass

    def fn3(a, b):
        pass
    return get_source(fn) == 'def fn():\n    pass' and \
        get_source(fn2) == 'def fn2(a, b):\n    pass' and \
        get_source(fn3) == 'def fn3(a, b):\n    pass'

# Generated at 2022-06-22 14:58:52.413719
# Unit test for function debug
def test_debug():
    class MockStderr(object):
        def __init__(self):
            self.messages = []

        def write(self, message):
            self.messages.append(message)

    messages_list = []

    def get_message():
        message = "example"
        messages_list.append(message)
        return message

    old_stderr = sys.stderr
    sys.stderr = MockStderr()

    # disables debug
    settings.debug = False
    debug(get_message)
    assert messages_list == []

    # enables debug
    settings.debug = True
    debug(get_message)
    assert messages_list == [get_message.__name__, get_message.__name__]

    sys.stderr = old_stderr



# Generated at 2022-06-22 14:58:58.951632
# Unit test for function debug
def test_debug():
    class GetMessage:
        def __init__(self):
            self.messages = []

        def __call__(self) -> str:
            self.messages.append('foo')
            return 'bar'

    get_message = GetMessage()
    debug(get_message)
    assert not get_message.messages

    settings.debug = True
    debug(get_message)
    assert get_message.messages == ['foo']
    assert get_message.messages.clear() is None

    settings.debug = False
    debug(get_message)
    assert not get_message.messages



# Generated at 2022-06-22 14:59:03.509986
# Unit test for function eager
def test_eager():
    ls = []
    @eager
    def gen():
        ls.append(1)
        ls.append(2)
        ls.append(3)
        yield 1
        yield 2
        yield 3
    assert ls == []
    assert gen() == [1, 2, 3]
    assert ls == [1, 2, 3]

# Generated at 2022-06-22 14:59:04.712650
# Unit test for function get_source

# Generated at 2022-06-22 14:59:07.638588
# Unit test for function eager
def test_eager():
    @eager
    def numbers() -> Iterable[int]:
        i = 0
        while True:
            yield i
            i += 1

    assert numbers() == list(range(10))

# Generated at 2022-06-22 14:59:11.030274
# Unit test for function eager
def test_eager():
    import random
    @eager
    def test():
        for i in range(10):
            yield i
            if random.random() < 0.1:
                break
    assert all(test())

# Generated at 2022-06-22 14:59:12.233478
# Unit test for function debug
def test_debug():
    print(getsource(debug))

# Generated at 2022-06-22 14:59:14.877766
# Unit test for function get_source
def test_get_source():
    def test():
        """Test function."""
        pass

    assert get_source(test) == 'TEST FUNCTION.'

# Generated at 2022-06-22 14:59:18.644824
# Unit test for function get_source
def test_get_source():
    def test():
        print(3)

    assert get_source(test) == 'print(3)'


# Generated at 2022-06-22 14:59:19.914287
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'hello')
    settings.debug = False

# Generated at 2022-06-22 14:59:25.151010
# Unit test for function eager
def test_eager():
    @eager
    def yield_one_to_ten():
        for i in range(1,11):
            yield i

    assert yield_one_to_ten() == [1,2,3,4,5,6,7,8,9,10]

# Generated at 2022-06-22 14:59:31.519686
# Unit test for function debug
def test_debug():
    messages.debug = lambda msg: msg

    def get_message():
        return 'a'

    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new=StringIO()) as stderr:
        settings.debug = True
        debug(get_message)
        assert stderr.getvalue() == 'a'

        settings.debug = False
        debug(get_message)
        assert stderr.getvalue() == 'a'

# Generated at 2022-06-22 14:59:35.315706
# Unit test for function debug
def test_debug():
    messages.set_colorful(False)
    settings.debug = True

    with patch('sys.stderr', new_callable=StringIO) as f:
        debug(lambda: 'abc {}'.format(123))
        assert f.getvalue() == '[debug] abc 123\n'

    settings.debug = False



# Generated at 2022-06-22 14:59:37.952239
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'hello world')
    settings.debug = False
    debug(lambda: 'hello world')

# Generated at 2022-06-22 14:59:40.824169
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():\n    pass\n'


# Generated at 2022-06-22 14:59:48.377011
# Unit test for function get_source
def test_get_source():
    def fn():
        return 'hello'

    def fn_a():
        def fn_b():
            def fn_c():
                def fn_d():
                    def fn_e():
                        def fn_f():
                            return 1 + 1
                        return fn_f()
                    return fn_e()
                return fn_d()
            return fn_c()
        return fn_b()

    def fn_a_a():
        def fn_b_b():
            pass

        return fn_b_b()

    assert get_source(fn) == 'return \'hello\''
    assert get_source(fn_a) == 'return 1 + 1'
    assert get_source(fn_a_a) == 'pass'



# Generated at 2022-06-22 14:59:53.778013
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == ('def test_get_source():\n'
                                           '    assert get_source(test_get_source) == ({!r}\n'
                                           '                                           .format(get_source(test_get_source)))\n')

# Generated at 2022-06-22 14:59:58.902811
# Unit test for function debug
def test_debug():
    import sys

    def check():
        assert sys.stderr.getvalue().strip() == "DEBUG: py - test message"
    sys.stderr = io.StringIO()
    debug(lambda: 'test message')
    check()
    settings.debug = True
    sys.stderr = io.StringIO()
    debug(lambda: 'test message')
    check()

# Generated at 2022-06-22 15:00:03.218681
# Unit test for function get_source
def test_get_source():
    def foo(x):
        return x + 5
    assert get_source(foo) == 'return x + 5'

# Generated at 2022-06-22 15:00:05.901000
# Unit test for function get_source
def test_get_source(): 
    def foo(a, b):
        return a, b
    def foo2(a):
        return a

# Generated at 2022-06-22 15:00:07.707536
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    debug(lambda: 'test message')



# Generated at 2022-06-22 15:00:08.910173
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        c, d = b, a
        return c, d


# Generated at 2022-06-22 15:00:11.863355
# Unit test for function eager
def test_eager():
    def square(n: int) -> Iterable[int]:
        for x in range(n):
            yield x ** 2

    assert [0, 1, 4] == eager(square)(3)

# Generated at 2022-06-22 15:00:19.292190
# Unit test for function debug
def test_debug():
    messages.debug = lambda message: message
    settings.debug = True
    import io
    import contextlib
    with contextlib.redirect_stderr(io.StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == 'test\n'
    settings.debug = False
    with contextlib.redirect_stderr(io.StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == ''
# end Unit test

# Generated at 2022-06-22 15:00:22.678094
# Unit test for function get_source
def test_get_source():
    """
    The get_source(fn) function should return the source code of the function
    fn.
    """
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-22 15:00:30.921421
# Unit test for function debug
def test_debug():
    debug_output = ""
    def test_function():
        debug(lambda: "test")
        nonlocal debug_output
        debug_output = sys.stderr.getvalue()
    with patch("sys.stderr", new_callable=StringIO) as sys_stderr:
        test_function()
        assert debug_output == ""
        settings.debug = True
        test_function()
        assert debug_output == "\x1b[36mDEBUG: test\x1b[0m\n"
        settings.debug = False
        test_function()
        assert debug_output == ""

# Generated at 2022-06-22 15:00:43.707275
# Unit test for function debug
def test_debug():
    from contextlib import redirect_stderr, contextmanager
    import io
    import sys

    @contextmanager
    def capture_stdout(self):
        # Save stdout settings
        original_stdout = sys.stdout
        # Create StringIO object
        captured_stdout = io.StringIO()
        # Redirect stdout to StringIO object
        sys.stdout = captured_stdout
        try:
            # Yield control
            yield captured_stdout
        finally:
            # Restore stdout settings
            sys.stdout = original_stdout

        @contextmanager
        def capture_stdout():
            original_stdout = sys.stdout
            captured_stdout = io.StringIO()
            sys.stdout = captured_stdout
            try:
                yield captured_stdout
            finally:
                sys

# Generated at 2022-06-22 15:00:46.742073
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'assert get_source(test_get_source) == \'assert get_source(test_get_source) == \\\'assert get_source(test_get_source) == \\\\\\\'assert get_source(test_get_source) == \\\\\\\\\\\\\\\'\''

# Generated at 2022-06-22 15:00:53.725070
# Unit test for function debug
def test_debug():
    debug_messages_received = []

    def should_be_executed():
        debug_messages_received.append('It works!')

    def should_not_be_executed():
        debug_messages_received.append('This should not be called')

    

# Generated at 2022-06-22 15:00:55.394943
# Unit test for function eager
def test_eager():
    """Tests function eager."""
    assert eager(range)(10) == list(range(10))


# Generated at 2022-06-22 15:00:59.009560
# Unit test for function debug
def test_debug():
    message = 'The test message.'
    settings.debug = True
    saved_print = builtins.print
    builtins.print = lambda *args, **kwargs: None
    try:
        debug(lambda: message)
    finally:
        builtins.print = saved_print



# Generated at 2022-06-22 15:01:01.198583
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'message')
    settings.debug = True
    debug(lambda: 'message')



# Generated at 2022-06-22 15:01:03.622978
# Unit test for function eager
def test_eager():
    @eager
    def get_eagerly():
        for i in range(10000):
            yield i

    for i in get_eagerly():
        assert i == i

# Generated at 2022-06-22 15:01:06.268969
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
    assert eager(foo)() == [1, 2]

# Generated at 2022-06-22 15:01:10.833441
# Unit test for function get_source
def test_get_source():
    def test_function():
        """Test function"""
        return 1

    def test_function2():
        """
        Test function
        """
        return 2

    assert get_source(test_function) == 'return 1'
    assert get_source(test_function2) == 'return 2'

# Generated at 2022-06-22 15:01:13.625414
# Unit test for function get_source
def test_get_source():
    def test1(a, b, c=3, d=4):
        return 5

    assert get_source(test1).startswith('    return 5')

# Generated at 2022-06-22 15:01:16.587520
# Unit test for function debug
def test_debug():
    settings.debug = True

    def get_message():
        return 'Some message'

    debug(get_message)

    # Clearing
    settings.debug = False

# Generated at 2022-06-22 15:01:18.969511
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'pass'

# Generated at 2022-06-22 15:01:27.066989
# Unit test for function debug
def test_debug():
    if settings.debug:
        s = ""
        with capture_output_to_string() as captured:
            debug(lambda: "b")
            s = captured.__str__()
        assert s == "debug: b\n"



# Generated at 2022-06-22 15:01:29.367770
# Unit test for function eager
def test_eager():
    assert eager(lambda: [x for x in range(10)])(), [0,1,2,3,4,5,6,7,8,9]

# Generated at 2022-06-22 15:01:31.658645
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(1, 10):
            yield i
    assert eager(foo)() == list(range(1, 10))

# Generated at 2022-06-22 15:01:37.000967
# Unit test for function debug
def test_debug():
    import pytest

    from io import StringIO

    stderr = sys.stderr
    message_log = StringIO()
    sys.stderr = message_log

    debug(lambda: 'foobar')

    sys.stderr = stderr
    assert not message_log.getvalue()

    settings.debug = True
    debug(lambda: 'foobar')
    settings.debug = False

    assert message_log.getvalue() == 'Debug: foobar\n'

# Generated at 2022-06-22 15:01:41.190814
# Unit test for function eager
def test_eager():
    from typing import Iterable
    # Mock up a function
    def mock_function() -> Iterable[bool]:
        yield True
        yield False
        yield True

    # Use eager to wrap it
    wrapped = eager(mock_function)

    # Check that it returns a list
    assert type(wrapped()) == list

    # Check that the contents are correct
    contents = wrapped()
    assert contents[0] is True
    assert contents[1] is False
    assert contents[2] is True


# Generated at 2022-06-22 15:01:44.332053
# Unit test for function get_source
def test_get_source():
    def test_function():
        return 'some_value'

    expected_source_code = """def test_function():
    return 'some_value'"""

    assert expected_source_code == get_source(test_function)

# Generated at 2022-06-22 15:01:46.891210
# Unit test for function get_source
def test_get_source():
    expected = "if True:\n    print('test')"
    actual = get_source(lambda: 'test')

    assert actual == expected, "get_source"

# Generated at 2022-06-22 15:01:48.542467
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
    assert foo() == [1, 2]

# Generated at 2022-06-22 15:01:50.727269
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    source = get_source(foo)
    assert source == 'def foo():\n    pass'

# Generated at 2022-06-22 15:01:54.027914
# Unit test for function get_source
def test_get_source():
    def x():
        """Docstring"""
        print('jk')
        return None
    assert get_source(x) == 'def x():\n    """Docstring"""\n    print(\'jk\')\n    return None'

# Generated at 2022-06-22 15:02:04.883736
# Unit test for function get_source
def test_get_source():
    def foo():
        foo = """bar"""
        return foo

    assert get_source(foo) == 'foo = """bar"""\n        return foo'

# Generated at 2022-06-22 15:02:07.870273
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Hello World')
    except Exception as e:
        raise Exception('debug function is broken')



# Generated at 2022-06-22 15:02:09.039868
# Unit test for function eager
def test_eager():
    def f(n):
        for i in range(n):
            yield i
    assert eager(f)(10) == list(range(10))

# Generated at 2022-06-22 15:02:11.413522
# Unit test for function eager
def test_eager():
    def gen() -> Iterable[int]:
        yield 1
        yield 2

    assert eager(gen)() == [1, 2]

# Generated at 2022-06-22 15:02:14.512600
# Unit test for function eager
def test_eager():
    def get_list() -> Iterable[int]:
        for x in range(3):
            yield x

    assert eager(get_list)() == [0, 1, 2]



# Generated at 2022-06-22 15:02:16.329163
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    assert source.startswith('def test_get_source():')

# Generated at 2022-06-22 15:02:22.314663
# Unit test for function debug
def test_debug():
    from contextlib import redirect_stderr
    from io import StringIO
    stream = StringIO()
    with redirect_stderr(stream):
        debug(lambda: 'Test' if settings.debug else 'x')
        assert stream.getvalue() == '\x1b[2mTest\x1b[0m\n'



# Generated at 2022-06-22 15:02:28.164197
# Unit test for function debug
def test_debug():
    debug_messages = []
    def get_debug_message():
        debug_messages.append(True)
        return 'this is debug message'

    debug(get_debug_message)
    debug(get_debug_message)
    assert len(debug_messages) == 2
    settings.debug = False
    debug(get_debug_message)
    assert len(debug_messages) == 2
    settings.debug = True
    debug(get_debug_message)
    assert len(debug_messages) == 3

# Generated at 2022-06-22 15:02:40.135454
# Unit test for function get_source
def test_get_source():
    def f():
        return 1

    def g():
        return 2

    assert get_source(f) == 'return 1'
    assert get_source(g) == 'return 2'
    assert get_source(test_get_source) == (
        'return get_source(f) == \'return 1\'\n'
        '    assert get_source(g) == \'return 2\'\n'
        '    assert get_source(test_get_source) == (\n'
        '        \'return get_source(f) == \\\'return 1\\\'\'\n'
        '        \'    assert get_source(g) == \\\'return 2\\\'\'\n'
        '        \'    assert get_source(test_get_source) == (\')\n'
    )

# Generated at 2022-06-22 15:02:42.151132
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    source = get_source(foo)

    assert source == 'def foo():', source



# Generated at 2022-06-22 15:03:08.413097
# Unit test for function debug
def test_debug():
    import os
    import tempfile
    with tempfile.TemporaryFile() as f:
        try:
            settings.debug = True
            debug(lambda: 'debug')
            sys.stderr.flush()
            f.seek(0)
            result = f.read().decode('utf-8')
            assert 'debug' in result
        finally:
            settings.debug = False

# Generated at 2022-06-22 15:03:19.881546
# Unit test for function debug
def test_debug():
    assert debug.__name__ == 'debug'
    assert debug.__doc__ == None

    class FakeStderr:
        content = ''

        def write(self, value):
            self.content += value

        def flush(self):
            pass

    fake_stderr = FakeStderr()
    original_stderr = sys.stderr
    sys.stderr = fake_stderr

# Generated at 2022-06-22 15:03:22.798237
# Unit test for function eager
def test_eager():
    @eager
    def gen(x: int) -> Iterable[int]:
        for i in range(x):
            yield i

    assert gen(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:03:29.118416
# Unit test for function debug
def test_debug():
    from . import messages
    from .conf import settings
    from .core import warn
    from .core import debug

    def get_message():
        return 'lol'

    settings.debug = False
    _debug = debug(get_message)
    # Tries to run _debug, which should be ignored because of False settings.debug
    _debug()
    settings.debug = True
    # Tries to run _debug, which should print message to stderr
    _debug()



# Generated at 2022-06-22 15:03:38.159399
# Unit test for function eager
def test_eager():
    from pytest import raises

    @eager
    def square(x: int) -> Iterable[int]:
        yield x ** 2

    assert square(3) == [9]
    assert square(3) == [9]

    @eager
    def take(n: int, seq: Iterable[int]) -> Iterable[int]:
        for i, x in enumerate(seq):
            if i >= n:
                break
            yield x

    assert take(2, range(10)) == [0, 1, 2]
    assert take(2, range(10)) == [0, 1, 2]

    def raise_generator():
        yield

    with raises(RuntimeError):
        square(raise_generator())

# Generated at 2022-06-22 15:03:40.192319
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield from range(10)
    assert gen() == list(range(10))

# Generated at 2022-06-22 15:03:44.852393
# Unit test for function get_source
def test_get_source():
    from . import functions
    def test_fn():
        pass
    assert get_source(test_fn) == '    def test_fn():\n        pass'
    assert get_source(functions.unsupported_function) == '    @wraps(fn)\n    def unsupported_function(*args, **kwargs):\n        raise UnsupportedFunctionWarning(fn)'

# Generated at 2022-06-22 15:03:49.801545
# Unit test for function debug
def test_debug():
    """Unit test for debug function."""
    def assert_warning_equal(expected_warning, get_message):
        """Asserts that function debug, with given get_message function,
        prints expected warning."""
        debug_output = StringIO()

        class Args:
            debug = True

        settings.debug = Args.debug

        with redirect_stderr(debug_output):
            debug(get_message)

        assert debug_output.getvalue() == messages.debug(
            expected_warning
        ) + '\n'

    assert_warning_equal('hello world', lambda: 'hello world')
    assert_warning_equal('hello\nworld', lambda: 'hello\nworld')

# Generated at 2022-06-22 15:03:53.361873
# Unit test for function debug
def test_debug():
    from ..settings import debug
    from .testutils import capture
    settings.debug = True
    with capture() as stdout:  # type: ignore
        debug(lambda: 'test')
    assert 'test' in stdout.getvalue()
    settings.debug = debug

# Generated at 2022-06-22 15:04:01.091913
# Unit test for function debug
def test_debug():
    """Check if function debug works properly."""
    global debug_message

    debug_message = None

    def get_debug_message() -> str:
        return debug_message

    # If debug is enabled, debug_message should be set to "Testing debug..."
    settings.debug = True
    debug_message = "Testing debug..."
    debug(get_debug_message)
    assert debug_message == "Testing debug..."

    # If debug is disabled, debug_message should be None
    settings.debug = False
    debug_message = "Testing debug..."
    debug(get_debug_message)
    assert debug_message is None



# Generated at 2022-06-22 15:04:53.447352
# Unit test for function get_source
def test_get_source():
    def echo(name: str) -> str:
        return name

    assert get_source(echo) == 'return name'

# Generated at 2022-06-22 15:04:56.311213
# Unit test for function debug
def test_debug():
    # GIVEN
    msg = 'This is a debug message'

    # WHEN
    debug(lambda: msg)

    # THEN
    print('') # TODO: How to assert that the message was printed?


# Generated at 2022-06-22 15:05:05.478533
# Unit test for function get_source

# Generated at 2022-06-22 15:05:15.890396
# Unit test for function debug
def test_debug():
    """Unit test for function debug.

    The test is executed only when `debug` is set to `True` in `py_backwards.conf.settings`.
    """
    setting = settings.debug
    try:
        settings.debug = True
        messages_printed = []

        def mock_print(message: str, file: Any = None, flush: bool = False) -> None:
            messages_printed.append(message)

        def get_message():
            return 'test'
        sys.stderr.print = mock_print
        debug(get_message)
        assert len(messages_printed) == 1
        assert messages_printed[0] == messages.debug(get_message())
    finally:
        settings.debug = setting

# Generated at 2022-06-22 15:05:25.240952
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from io import StringIO
    from .conf import settings

    @contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        stderr = StringIO()
        try:
            sys.stderr = stderr
            yield stderr
        finally:
            sys.stderr = old_stderr

    with capture_stderr() as stderr:
        debug(lambda: 'message')
        assert stderr.getvalue() == ''
        settings.debug = True
        debug(lambda: 'message')
        assert stderr.getvalue() == '\x1b[2;30;43mDEBUG:\x1b[0;0m message\n\n'

# Generated at 2022-06-22 15:05:29.868380
# Unit test for function eager
def test_eager():
    # Function without yield statement
    def without_yield_statement():
        return 1

    assert eager(without_yield_statement)() == [1]

    # Function with yield statement
    def with_yield_statement():
        yield 1
        yield 2

    assert eager(with_yield_statement)() == [1, 2]



# Generated at 2022-06-22 15:05:35.499502
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        output = []
        def append(value):
            output.append(value)
        debug(lambda: 'foo' + 'bar')
        sys.stderr.write = append
        debug(lambda: 'hello')
        assert output[0] == messages.debug('hellobar')
    finally:
        settings.debug = False


# Generated at 2022-06-22 15:05:43.286405
# Unit test for function debug
def test_debug():
    def get_message() -> str:
        return 'test message'

    with mock.patch('sys.stderr.write') as mock_sys_stderr_write:
        warnings.warn = mock.Mock()
        settings.debug = False
        debug(get_message)
        assert mock_sys_stderr_write.call_count == 0

        settings.debug = True
        debug(get_message)
        mock_sys_stderr_write.assert_called_once_with('[py_backwards debug] test message\n')

# Generated at 2022-06-22 15:05:50.125420
# Unit test for function eager
def test_eager():
    @eager
    def f(a: int) -> Iterable[int]:
        yield a

    @eager
    def g(a: int) -> Iterable[int]:
        yield from range(a)

    assert f(1) == [1]
    assert g(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:05:52.073491
# Unit test for function get_source
def test_get_source():
    try:
        x = 1
        def f():
            return x
        assert get_source(f) == '    return x'
    finally:
        del f



# Generated at 2022-06-22 15:08:02.403802
# Unit test for function debug
def test_debug():
    import io
    import sys
    import warnings

    with warnings.catch_warnings():
        sys.stderr = io.StringIO()
        settings.debug = False

        debug(lambda: 'should not be printed')
        assert sys.stderr.read() == ''

        settings.debug = True
        debug(lambda: 'should be printed')
        assert sys.stderr.read() == messages.debug('should be printed') + '\n'

# Generated at 2022-06-22 15:08:04.689395
# Unit test for function eager
def test_eager():
    # This function returns generator
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() is not foo()
    assert list(foo()) == eager(foo)()

# Generated at 2022-06-22 15:08:08.075113
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'


# Unit tests for function warn

# Generated at 2022-06-22 15:08:12.519462
# Unit test for function debug
def test_debug():
    from .tests import test_settings
    test_settings.debug = True
    debug_logs = list()

    def log_message() -> str:
        debug_logs.append('debug message')
        return 'debug message'

    debug(log_message)
    assert debug_logs == ['debug message']

# Generated at 2022-06-22 15:08:14.629695
# Unit test for function get_source
def test_get_source():
    from .._helpers import get_source
    def f():
        return 1
    assert get_source(f).endswith('\n    return 1\n')


# Generated at 2022-06-22 15:08:17.614590
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    pass'

# Generated at 2022-06-22 15:08:18.947118
# Unit test for function get_source
def test_get_source():
    from . import _test_cases
    assert get_source(_test_cases.function) == _test_cases.function_source

# Generated at 2022-06-22 15:08:21.268823
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        msg = 'hello'
        print(msg)
        debug(lambda: msg)
        msg = 'world'
        print(msg)
        debug(lambda: msg)
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:08:23.483125
# Unit test for function eager
def test_eager():
    def f():
        yield "hello"
        yield "world"

    assert eager(f)() == ['hello', 'world']

# Generated at 2022-06-22 15:08:25.615831
# Unit test for function eager
def test_eager():
    def test(x, y):
        yield x * y

    assert eager(test)(1, 2) == [2]