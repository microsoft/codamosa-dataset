

# Generated at 2022-06-22 14:58:48.408425
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    assert source.endswith('        source = get_source(test_get_source)\n        assert source.endswith(\'        source = get_source(test_get_source)\')')

# Generated at 2022-06-22 14:58:52.628493
# Unit test for function get_source
def test_get_source():
    arg = 5
    def foo(a):
        b = arg
        return a + b
    assert get_source(foo) == 'def foo(a):\n' \
                              '    b = arg\n' \
                              '    return a + b\n'

# Generated at 2022-06-22 14:58:55.723591
# Unit test for function eager
def test_eager():
    @eager
    def f(arg):
        yield arg
    assert f(1) == [1]


# Generated at 2022-06-22 14:59:02.182184
# Unit test for function eager
def test_eager():
    from random import randint
    from typing import List, Iterable

    def gen() -> Iterable[int]:
        for i in range(3):
            yield randint(0, 100)

    def run(a: str, b: str) -> List[int]:
        return gen()

    assert run('a', 'b') == eager(run)('a', 'b')
test_eager()

# Generated at 2022-06-22 14:59:08.264846
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as err, redirect_stderr(err):
        debug(lambda: 'Test')
        assert not err.getvalue()

    with StringIO() as err, redirect_stderr(err):
        settings.debug = True
        debug(lambda: 'Test')
        assert err.getvalue() == 'DEBUG (backwards): Test\n'
        settings.debug = False

# Generated at 2022-06-22 14:59:10.436087
# Unit test for function eager
def test_eager():
    func = lambda x: range(x)
    assert func(5) == eager(func)(5)



# Generated at 2022-06-22 14:59:14.183665
# Unit test for function get_source
def test_get_source():
    def foo(x: int) -> int:
        return x + 1
    assert get_source(foo) == 'def foo(x: int) -> int:\n    return x + 1'


# Generated at 2022-06-22 14:59:16.709596
# Unit test for function get_source
def test_get_source():
    def foo():
        if True:
            pass
    assert get_source(foo) == "def foo():\n    if True:\n        pass\n"

# Generated at 2022-06-22 14:59:18.852860
# Unit test for function get_source
def test_get_source():
    from .assertions import assert_source

    def foo():  # noqa
        pass

    assert_source(foo, 'def foo():')

# Generated at 2022-06-22 14:59:22.474664
# Unit test for function debug
def test_debug():
    debug(lambda: "foo")
    settings.debug = True
    debug(lambda: "foo")
    settings.debug = False



# Generated at 2022-06-22 14:59:26.053241
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2

    assert foo() == [1, 2]

# Generated at 2022-06-22 14:59:27.819505
# Unit test for function get_source
def test_get_source():
    def x(x):
        return x

    assert get_source(x) == 'return x'

# Generated at 2022-06-22 14:59:36.172292
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stderr
    stderr_buffer = io.StringIO()
    with redirect_stderr(stderr_buffer):
        settings.debug = True
        debug(lambda: 'Some debug message.')
        debug(lambda: 'Another debug message.')
        settings.debug = False
        debug(lambda: 'This message should be hidden.')
    output = stderr_buffer.getvalue()
    debug_messages = re.findall(r'^.*DEBUG.*$', output, re.MULTILINE)
    assert len(debug_messages) == 2
    assert debug_messages[0] == messages.debug('Some debug message.')
    assert debug_messages[1] == messages.debug('Another debug message.')

# Generated at 2022-06-22 14:59:40.464761
# Unit test for function eager
def test_eager():
    def f(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert eager(f)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-22 14:59:43.496425
# Unit test for function get_source
def test_get_source():
    """
    This function is a unit test for get_source function.
    """
    def func():
        pass

    source_code = inspect.getsource(func)
    assert source_code == get_source(func)

# Generated at 2022-06-22 14:59:44.741910
# Unit test for function debug
def test_debug():
    """Tests debug function"""
    debug(lambda: "Test debug")



# Generated at 2022-06-22 14:59:47.768177
# Unit test for function get_source
def test_get_source():
    def my_function(a, b=1):
        c = a + b
        d = c * b
        return d
    assert get_source(my_function) == """def my_function(a, b=1):
    c = a + b
    d = c * b
    return d"""

# Generated at 2022-06-22 14:59:55.688202
# Unit test for function get_source
def test_get_source():
    def f1(a, b, c):
        pass

    def f2(a, b, c):
        if a:
            a = b
        return a
    assert get_source(f1) == 'def f1(a, b, c):\n    pass'
    assert get_source(f2) == 'def f2(a, b, c):\n    if a:\n        a = b\n    return a'


# Generated at 2022-06-22 14:59:57.324260
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-22 15:00:08.734665
# Unit test for function debug
def test_debug():
    from unittest import TestCase, mock
    from unittest.mock import patch
    import sys

    class DebugTest(TestCase):
        @patch('sys.stderr', new_callable=lambda: sys.stderr)
        @patch('backwards.utils.debug')
        def test_with_debug_off(self, mock_debug, mock_stderr):
            settings.debug = False
            debug(lambda: 'value')
            mock_debug.assert_called_once_with(lambda: 'value')
            mock_stderr.write.assert_not_called()


# Generated at 2022-06-22 15:00:14.981036
# Unit test for function eager
def test_eager():
    from itertools import count

    @eager
    def foo() -> Iterable[int]:
        yield from count(1)

    assert list(foo()) == [1, 2, 3, 4, 5]

    assert not settings.debug

    # It should work with 0 args and kwargs
    @eager
    def bar() -> Iterable[int]:
        yield 1
        yield 2

    assert bar() == [1, 2]

# Generated at 2022-06-22 15:00:26.897049
# Unit test for function debug
def test_debug():
    import os
    import unittest
    import subprocess
    import shutil
    import tempfile

    TEMP_FILE = tempfile.mktemp()

    def ut_debug():
        debug("message")
        debug("other message")
        debug("more messages")

    class TestDebug(unittest.TestCase):
        def setUp(self):
            with open(TEMP_FILE, "w") as file:
                settings._debug = True
                ut_debug()
                settings._debug = False
                ut_debug()
                settings._debug = True
                ut_debug()

        def test_output(self):
            lines = subprocess.check_output(["cat", TEMP_FILE]).decode("utf-8").split("\n")
            self.assertEqual(len(lines), 8)

# Generated at 2022-06-22 15:00:30.860487
# Unit test for function get_source
def test_get_source():
    def test():
        x = 1
        print(x)

    def test_1():
        x = 1

        def inner():
            pass

    assert get_source(test) == 'x = 1\nprint(x)\n'
    assert get_source(test_1) == 'x = 1\n\n'

# Generated at 2022-06-22 15:00:36.560562
# Unit test for function debug
def test_debug():
    assert settings.debug is False
    messages.debug = '%s'
    assert debug(lambda: "Hello, this is just a test") is None
    settings.debug = True
    assert debug(lambda: "Hello, this is just a test") is None

# Generated at 2022-06-22 15:00:39.745612
# Unit test for function debug
def test_debug():
    sys.stderr = sys.stdout
    settings.debug = True
    debug(lambda: 'test message')
    settings.debug = False
    debug(lambda: 'test message')
    assert True

# Generated at 2022-06-22 15:00:47.762121
# Unit test for function debug
def test_debug():
    import contextlib
    from io import StringIO
    from unittest.mock import Mock, patch
    from ..conf import settings

    @contextlib.contextmanager
    def capture_stderr() -> Iterable[StringIO]:
        """Captures text written to stderr."""
        old_stderr = sys.stderr
        stderr = StringIO()
        sys.stderr = stderr
        try:
            yield stderr
        finally:
            sys.stderr = old_stderr

    with capture_stderr() as stderr:
        debug(lambda: 'debug' * 10)
    assert stderr.getvalue() == ''

    with patch.object(settings, 'debug', True):
        with capture_stderr() as stderr:
            mocked_get

# Generated at 2022-06-22 15:00:52.595128
# Unit test for function get_source
def test_get_source():
    def function(a: int, b: str) -> bool:
        x = a + len(b)
        return True

    assert get_source(function) == '''
x = a + len(b)
return True
'''



# Generated at 2022-06-22 15:00:54.173932
# Unit test for function debug
def test_debug():
    def foo():
        print('foo')
    def bar():
        print('bar')

    with settings.debug_context(True):
        debug(foo)
        debug(bar)
        with settings.debug_context(False):
            debug(foo)
            debug(bar)
        debug(foo)
        debug(bar)



# Generated at 2022-06-22 15:00:56.171278
# Unit test for function eager
def test_eager():
    @eager
    def x():
        yield 1
        yield 2
    assert x() == [1, 2]


# Generated at 2022-06-22 15:00:59.004739
# Unit test for function eager
def test_eager():
    import collections
    def foo():
        for i in range(3):
            yield i
    generator_func = foo
    wrapper_func = eager(generator_func)
    assert isinstance(wrapper_func, collections.abc.Callable)
    assert wrapper_func() == [0, 1, 2]



# Generated at 2022-06-22 15:01:09.137155
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    try:
        old_stderr, sys.stderr = sys.stderr, StringIO.StringIO()
        import src.conf
        src.conf.settings.debug = True
        debug(lambda: 'Apekatten')
        assert 'DEBUG: Apekatten' in sys.stderr.getvalue()
        sys.stderr = old_stderr
    finally:
        sys.stderr = old_stderr
        src.conf.settings.debug = False



# Generated at 2022-06-22 15:01:11.170750
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello')

if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-22 15:01:12.878497
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(5))() == [0, 1, 2, 3, 4]

# Generated at 2022-06-22 15:01:15.757973
# Unit test for function get_source
def test_get_source():
    @nop
    def f():
        return
    assert get_source(f) == """    return
""".lstrip()

# Generated at 2022-06-22 15:01:20.200783
# Unit test for function eager
def test_eager():
    def foo():
        yield from range(10)

    assert eager(foo)() == list(range(10))

    @eager
    def bar(a: int) -> Iterable[int]:
        for x in range(a):
            yield x

    assert bar(10) == list(range(10))

# Generated at 2022-06-22 15:01:24.827401
# Unit test for function eager
def test_eager():
    @eager
    def empty_generator():
        return ()

    @eager
    def non_empty_generator():
        yield 1
        yield 2

    assert empty_generator() == []
    assert non_empty_generator() == [1, 2]



# Generated at 2022-06-22 15:01:27.066750
# Unit test for function get_source
def test_get_source():
    def my_function():
        pass
    assert get_source(my_function).strip() == 'def my_function():'

# Generated at 2022-06-22 15:01:29.056274
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-22 15:01:31.016021
# Unit test for function eager
def test_eager():

    @eager
    def main():
        yield 1
        yield 2

    assert main() == [1, 2]

# Generated at 2022-06-22 15:01:33.228852
# Unit test for function debug
def test_debug():
    class SimpleGetMessage:
        def __call__(self):
            return 'some message'

    get_message = SimpleGetMessage()
    debug(get_message)



# Generated at 2022-06-22 15:01:36.079011
# Unit test for function debug
def test_debug():
    @debug
    def get_message():
        return 'Message'

    get_message()

# Generated at 2022-06-22 15:01:38.318689
# Unit test for function debug
def test_debug():
    message = 'Debug message'
    sys.stderr = io.StringIO()
    debug(lambda: message)
    assert sys.stderr.getvalue() == message + '\n'

# Generated at 2022-06-22 15:01:42.981171
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            return 4 + 5

        return g()

    source_f = get_source(f)
    assert source_f == dedent(
        """
    def g():
        return 4 + 5

    return g()
    """
    )

# Generated at 2022-06-22 15:01:51.660572
# Unit test for function debug
def test_debug():  # type: ignore
    debug_messages = []

    def get_message() -> str:
        return 'Msg'

    def get_debug_message(msg: str) -> None:
        debug_messages.append(msg)

    print_debug_message_func_mock = 'py_backwards.utils.messages.debug'
    with mock.patch(print_debug_message_func_mock, side_effect=get_debug_message):
        debug(get_message)
        assert not debug_messages, 'Message was printed even though debug=False'

        settings.debug = True
        debug(get_message)
        assert debug_messages, 'Message was not printed even though debug=True'

# Generated at 2022-06-22 15:01:54.653417
# Unit test for function debug
def test_debug():
    settings.debug = True

# Generated at 2022-06-22 15:01:59.496227
# Unit test for function debug
def test_debug():
    pref = 'test_debug()'
    message = 'test'
    settings.debug = True
    try:
        assert debug.__name__ == 'debug'
        assert debug.__code__.co_argcount == 1
        assert debug.__globals__ == globals()
        debug(lambda: message)
        assert sys.stderr.getvalue() == messages.debug(message) + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False
        print('Passed ' + pref)



# Generated at 2022-06-22 15:02:03.932948
# Unit test for function debug
def test_debug():
    """Tests function debug"""

    # When setting is set to false, nothing gets printed
    settings.debug = False
    debug(lambda: "debug message")

    # When setting is set to true, message is printed
    settings.debug = True
    debug(lambda: "debug message")

# Generated at 2022-06-22 15:02:07.005751
# Unit test for function eager
def test_eager():
    # Tests for eager function
    assert eager(range)(5) == [0, 1, 2, 3, 4]
    assert eager(range)(2) == [0, 1]

# Generated at 2022-06-22 15:02:10.117770
# Unit test for function debug
def test_debug():
    from .conf import settings
    with settings(debug=True):
        debug(lambda: 'Hello')
        debug(lambda: 'world')
        with settings(debug=False):
            debug(lambda: 'not printed')



# Generated at 2022-06-22 15:02:15.605418
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys, pytest
    from ..conf import settings
    settings.debug = True
    captured = StringIO()
    sys.stderr = captured
    debug(lambda: 'abc')
    assert captured.getvalue() == messages.debug('abc') + '\n'
    settings.debug = False
    captured.close()



# Generated at 2022-06-22 15:02:27.758908
# Unit test for function debug
def test_debug():
    global captured_message

    def get_message_1():
        return 'captured_message'

    def get_message_2():
        return 'not captured_message'

    captured_message = None

    def capture(message):
        global captured_message
        captured_message = message

    backup_print = print
    print = capture
    settings.debug = True
    try:
        debug(get_message_1)
        assert(captured_message == messages.debug(get_message_1()))
        captured_message = None

        debug(get_message_2)
        assert(captured_message == None)

        # reset settings
        captured_message = None
        settings.debug = False
        debug(get_message_1)
        assert(captured_message == None)
    finally:
        print = backup_

# Generated at 2022-06-22 15:02:29.242540
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2

    assert eager(f)() == [1, 2]

# Generated at 2022-06-22 15:02:31.676741
# Unit test for function get_source
def test_get_source():
    def some_function(x):
        print('Hello')

    assert get_source(some_function) == 'def some_function(x):\n    print(\'Hello\')'

# Generated at 2022-06-22 15:02:36.491760
# Unit test for function eager
def test_eager():
    def count_to_3() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    # Should be list not generator.
    assert list == type(eager(count_to_3))



# Generated at 2022-06-22 15:02:38.665105
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1

    assert foo() == [1]



# Generated at 2022-06-22 15:02:46.726242
# Unit test for function debug
def test_debug():
    def t(message):  # type: (str) -> None
        print(messages.debug(message), file=sys.stderr)
    settings.debug = False
    debug(lambda: 'abc')
    try:
        old_debug = sys.stderr
        try:
            from io import StringIO
            s = StringIO()
            sys.stderr = s
            settings.debug = True
            debug(lambda: 'abc')
            assert s.getvalue() == t('abc')
        finally:
            sys.stderr = old_debug
    finally:
        settings.debug = False

# Generated at 2022-06-22 15:02:56.777889
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .. import settings as _settings
    from .tests import assert_equals

    settings.debug = True
    out = StringIO()

    with redirect_stdout(out):
        debug(lambda: 'hello world')
    assert_equals(out.getvalue(), 'DEBUG: hello world\n')

    out.seek(0)
    with redirect_stdout(out):
        debug(lambda: 'hello world')
    assert_equals(out.getvalue(), '')

    settings.debug = False
    out.seek(0)
    with redirect_stdout(out):
        debug(lambda: 'hello world')
    assert_equals(out.getvalue(), '')
    _settings.debug = settings.debug

# Generated at 2022-06-22 15:02:58.019529
# Unit test for function debug
def test_debug():
    debug(lambda: "This is a message")

# Generated at 2022-06-22 15:03:02.867007
# Unit test for function get_source
def test_get_source():
    @add_one
    def test():
        """Docstring, should be ignored"""
        return 2

    def add_one(fn):
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs) + 1
        return wrapper


# Generated at 2022-06-22 15:03:04.374468
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'pass'

# Generated at 2022-06-22 15:03:17.609099
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import mock
    from contextlib import redirect_stderr

    output = StringIO()
    with mock.patch.object(sys, 'stderr', new=output):
        with redirect_stderr(sys.stderr):
            debug(lambda: 'foo bar!')
            assert output.getvalue() == '\x1b[34m[debug]\x1b[0m foo bar!\n'
    output = StringIO()
    debug(lambda: 'bar foo!')
    with mock.patch.object(sys, 'stderr', new=output):
        with redirect_stderr(sys.stderr):
            debug(lambda: 'foo bar!')
            assert output.getvalue() == ''



# Generated at 2022-06-22 15:03:24.047263
# Unit test for function get_source
def test_get_source():
    def test_function(a, b, c=10, *args, d=20, **kwargs):
        """This is a test function"""
        pass

    source_lines = [
        'def test_function(a, b, c=10, *args, d=20, **kwargs):',
        '    """This is a test function"""',
        '    pass'
    ]
    assert get_source(test_function) == '\n'.join(source_lines)



# Generated at 2022-06-22 15:03:25.749299
# Unit test for function get_source

# Generated at 2022-06-22 15:03:28.445717
# Unit test for function get_source
def test_get_source():
    def function():
        """This function is a test."""
        x = 1
        y = 2
    assert get_source(function) == 'x = 1\ny = 2'

# Generated at 2022-06-22 15:03:30.386645
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test message')
    settings.debug = False
    assert True

# Generated at 2022-06-22 15:03:32.880413
# Unit test for function get_source
def test_get_source():
    def myfunction():
        pass

    assert get_source(myfunction) == 'def myfunction():\n    pass\n'

# Generated at 2022-06-22 15:03:39.473688
# Unit test for function debug
def test_debug():
    debug_message = 'Test debug message'
    with patch('sys.stderr') as fake_stderr:
        debug(lambda: debug_message)
        fake_stderr.write.assert_called_with(messages.debug(debug_message))
        fake_stderr.write.reset_mock()

    settings.debug = False
    with patch('sys.stderr') as fake_stderr:
        debug(lambda: debug_message)
        assert not fake_stderr.write.called

# Generated at 2022-06-22 15:03:42.472236
# Unit test for function get_source
def test_get_source():
    def f(a, b, c):
        return a + b + c

    expected = '\n'.join(
        ['return a + b + c',
         '',
         '',
         ''])
    assert get_source(f) == expected

# Generated at 2022-06-22 15:03:44.812224
# Unit test for function debug
def test_debug():

    debug(lambda: "message")  # we can't use lambda in decorator so we use
                              # function as argument for debug function.



# Generated at 2022-06-22 15:03:51.197482
# Unit test for function get_source
def test_get_source():
    def f1(A, B):
        return A + B

    assert get_source(f1) == 'return A + B'

    def f2(A, B):
        if A > B:
            return A - B
        else:
            return A + B

    assert get_source(f2) == '''\
if A > B:
    return A - B
else:
    return A + B'''

    def f3(A, B):
        return (
            A
            + B)

    assert get_source(f3) == 'return A + B'

    def f4(A, B):
        return (((((A + B))))
                )

    assert get_source(f4) == 'return A + B'


# Generated at 2022-06-22 15:03:58.471100
# Unit test for function eager
def test_eager():
    from typing import List
    from random import randint
    LENGTH = randint(10, 100)
    L = [randint(0, 100) for _ in range(LENGTH)]
    @eager
    def generate_list() -> List[int]:
        return L
    assert generate_list() == L

# Generated at 2022-06-22 15:04:00.700850
# Unit test for function get_source
def test_get_source():
    def test_fn():
        def inner_fn():
            return 1

        return inner_fn()


    assert get_source(test_fn) == 'return inner_fn()'

# Generated at 2022-06-22 15:04:02.548783
# Unit test for function get_source
def test_get_source():
    def f():
        pass  # pragma: no cover

    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-22 15:04:08.353420
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase

    from ..conf import settings

    class TestDebug(TestCase):
        def setUp(self):
            self.stdout = sys.stderr = sys.stderr = StringIO()

        def tearDown(self):
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__

        def test(self):
            settings.debug = True
            debug(lambda: 'Debug message')
            self.assertEqual(sys.stderr.getvalue(), 'DEBUG: Debug message')
            settings.debug = False
            debug(lambda: 'Debug message')
            self.assertEqual(sys.stderr.getvalue(), 'DEBUG: Debug message')

    TestDebug().test()

# Generated at 2022-06-22 15:04:11.078657
# Unit test for function get_source
def test_get_source():
    def fun():
        pass

    source = get_source(fun)
    assert source == 'def fun():\n    pass'

# Generated at 2022-06-22 15:04:14.039911
# Unit test for function eager
def test_eager():
    @eager
    def test():
        for i in range(10):
            yield i
    assert test() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 15:04:16.271265
# Unit test for function get_source
def test_get_source():
    def test_function():
        return True

    assert get_source(test_function) == 'return True'

# Generated at 2022-06-22 15:04:17.982900
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    assert settings.debug



# Generated at 2022-06-22 15:04:19.772941
# Unit test for function get_source
def test_get_source():
    def test_function():
        return x

    assert get_source(test_function) == "return x"

# Generated at 2022-06-22 15:04:21.885508
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False



# Generated at 2022-06-22 15:04:32.690072
# Unit test for function get_source
def test_get_source():
    def f():
        """Test

        Args:
            arg: arg
        """
        pass
    assert(get_source(f) == "def f():\n    \"\"\"Test\n\n    Args:\n        arg: arg\n    \"\"\"\n    pass")

# Generated at 2022-06-22 15:04:38.283264
# Unit test for function eager
def test_eager():
    a = 1
    b = 2

    @eager
    def testing():
        nonlocal a, b
        for i in range(5):
            a += 1
            b *= 2
            yield (a, b)

    testing_list = list(testing())

    assert testing() == testing_list



# Generated at 2022-06-22 15:04:47.127849
# Unit test for function get_source
def test_get_source():
    # function with body indented
    def a():
        x = 1 + 4

    # function without body indented
    def b():
        x = 1 + 4

    # function with multiline body
    def c():
        if a() < 1:
            x = 1 + 4
        else:
            x = a() * 4

    # function with multiline body
    def d():
        if a() < 1:\
            x = 1 + 4
        else:\
            x = a() * 4

    assert get_source(a) == 'x = 1 + 4'
    assert get_source(b) == 'x = 1 + 4'
    assert get_source(c) == 'if a() < 1:\n    x = 1 + 4\nelse:\n    x = a() * 4'

# Generated at 2022-06-22 15:04:58.234756
# Unit test for function debug
def test_debug():
    import io
    import sys
    import pytest

    @pytest.fixture
    def debug_output_stream():
        class DebugOutputStream(io.StringIO):
            def getvalue(self):
                value = super().getvalue()
                self.truncate(0)
                self.seek(0)
                return value

        return DebugOutputStream()

    def test_debug_message(capsys, monkeypatch, debug_output_stream):
        def get_messages():
            yield 'foo'
            yield 'bar'
            yield 'baz'

        monkeypatch.setattr(settings, 'debug', True)
        monkeypatch.setattr(sys, 'stderr', debug_output_stream)
        debug(get_messages)

# Generated at 2022-06-22 15:05:02.653680
# Unit test for function eager
def test_eager():
    l1 = [1]
    l2 = [2, 3]
    l3 = [4, 5, 6]

    def generator() -> Iterable[int]:
        yield from l1
        yield from l2
        yield from l3
    assert eager(generator)() == list(generator())



# Generated at 2022-06-22 15:05:10.404344
# Unit test for function debug
def test_debug():
    import io
    import sys

    _stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()

        # no debug information output
        debug(lambda: 'debug message')
        assert sys.stderr.getvalue() == ''

        # debug information output
        settings.debug = True
        debug(lambda: 'debug message')
        assert sys.stderr.getvalue() == '\x1b[2mdebug message\x1b[0m\n'
    finally:
        sys.stderr = _stderr



# Generated at 2022-06-22 15:05:16.973640
# Unit test for function debug
def test_debug():
    sys.stderr = StringIO()
    settings.debug = True
    debug(lambda: "debug")
    assert sys.stderr.getvalue() == "py-backwards debugging: debug\n"
    settings.debug = False
    debug(lambda: "debug")
    assert sys.stderr.getvalue() == "py-backwards debugging: debug\n"
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:05:19.460435
# Unit test for function debug
def test_debug():
    from fakeredirs import enable_fake_redirs, disable_fake_redirs

    enable_fake_redirs()


# Generated at 2022-06-22 15:05:22.730270
# Unit test for function eager
def test_eager():
    def add_one(x: int) -> int:
        yield x + 1

    assert eager(add_one)(1, 2, 3) == [2, 3, 4]



# Generated at 2022-06-22 15:05:24.094543
# Unit test for function get_source
def test_get_source():
    def dummy_func():
        pass
    assert get_source(dummy_func) == get_source.__doc__

# Generated at 2022-06-22 15:05:42.349079
# Unit test for function eager
def test_eager():
    def return_generator(n):
        for i in range(n):
            yield i

    assert(eager(return_generator)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])



# Generated at 2022-06-22 15:05:49.859213
# Unit test for function debug
def test_debug():
    class TestSettings:
        debug = True

    settings.load(TestSettings)
    recorder = []

    def get_message():
        recorder.append(True)
        return 'test'

    debug(get_message)
    assert recorder == [True]

    recorder = []
    settings.load(None)
    debug(get_message)
    assert recorder == []


# Generated at 2022-06-22 15:05:54.587953
# Unit test for function get_source
def test_get_source():
    from textwrap import dedent

    def test():
        if True:
            return 1

    def test2():
        if True:
            return 2

    def test3():
        if True:
            return 3

    assert get_source(test) == dedent('''\
    if True:
        return 1''')
    assert get_source(test2) == dedent('''\
    if True:
        return 2''')
    assert get_source(test3) == dedent('''\
    if True:
        return 3''')



# Generated at 2022-06-22 15:06:01.846003
# Unit test for function debug
def test_debug():
    import sys
    from py_backwards.conf import set_debug, unset_debug
    from py_backwards.utils import debug

    set_debug()
    sys.stderr = FakeStderr()
    debug(lambda: 'test')
    assert 'test' in str(sys.stderr)
    unset_debug()
    sys.stderr = FakeStderr()
    debug(lambda: 'test')
    assert 'test' not in str(sys.stderr)



# Generated at 2022-06-22 15:06:05.674574
# Unit test for function get_source
def test_get_source():
    def test(v: int) -> int:
        """Function documentation."""
        print('a')
        return v

    code = inspect.getsource(test)

    assert get_source(test) == code



# Generated at 2022-06-22 15:06:10.781617
# Unit test for function debug
def test_debug():
    result = []

    def get_message():
        result.append(1)
        return 'x'

    old_debug = settings.debug
    try:
        settings.debug = True
        debug(get_message)
        assert result
    finally:
        settings.debug = old_debug

    result = []
    debug(get_message)
    assert not result

# Generated at 2022-06-22 15:06:15.607711
# Unit test for function get_source
def test_get_source():
    def test_function(a, b=2, *args, c=3, **kwargs):
        return a + b + c

    get_source(test_function)

    def test_function(a, b=2, *args, c=3, **kwargs):
        return a + b + c

    assert get_source(test_function)

# Generated at 2022-06-22 15:06:19.229774
# Unit test for function debug
def test_debug():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stderr = captured_output

    def get_message():
        return 'test'

    debug(get_message)
    assert (captured_output.getvalue() == '[PY-BACKWARDS] test\n') == settings.debug

    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 15:06:22.772255
# Unit test for function get_source
def test_get_source():
    def foo():
        x = 1
        if x:
            y = False
        return y
    assert get_source(foo) == 'x = 1\nif x:\n    y = False\nreturn y\n'

# Generated at 2022-06-22 15:06:25.910585
# Unit test for function get_source
def test_get_source():
    def f_expected():
        return None

    def f_actual():
        return

    assert get_source(f_expected) == get_source(f_actual)

# Generated at 2022-06-22 15:07:02.461021
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    expected = "def fn():\n    pass\n"
    assert get_source(fn) == expected

# Generated at 2022-06-22 15:07:03.921512
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
    assert eager(f)() == [1, 2]

# Generated at 2022-06-22 15:07:07.995952
# Unit test for function eager
def test_eager():
    # Given
    def fn(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    # When
    lazy = fn(10)
    eager_lazy = eager(lazy)
    eager_fn = eager(fn)

    # Then
    assert isinstance(lazy, Iterable)
    assert isinstance(eager_lazy, List)
    assert isinstance(eager_fn, Callable)


# Generated at 2022-06-22 15:07:12.825049
# Unit test for function eager
def test_eager():

    @eager
    def generate_list() -> Iterable[int]:
        yield 1
        yield 2

    @eager
    def generate_set() -> Iterable[int]:
        yield 1
        yield 2

    assert generate_list() == [1, 2]
    assert generate_list.__name__ == 'generate_list'
    assert generate_set() == [1, 2]
    assert generate_set.__name__ == 'generate_set'

# Generated at 2022-06-22 15:07:22.915937
# Unit test for function get_source
def test_get_source():
    def test():
        """This is a test function."""
        var = 0
        print("Hello")
        var += 1
        return var

    def test2():
        """This is a test function."""
        var = 0
        print("Hello")
        var += 1
        return var

    def test3():
        """This is a test function."""
        var = 0
        print("Hello")
        var += 1
        return var

    source_lines_1 = get_source(test).split('\n')
    source_lines_2 = get_source(test2).split('\n')
    source_lines_3 = get_source(test3).split('\n')
    # Test if the returned code is the same
    assert source_lines_1 == source_lines_2

# Generated at 2022-06-22 15:07:24.570398
# Unit test for function get_source
def test_get_source():
    def foo():
        """print your name"""
        return 'ALEX'


# Generated at 2022-06-22 15:07:30.356464
# Unit test for function get_source
def test_get_source():
    class FooBar:
        @classmethod
        def foo(cls):
            pass

    class Bar:
        @staticmethod
        def foo():
            pass

    def foo():
        pass

    def bar():
        pass

        # comment

    def baz():
        pass
        # comment

    def qux():
        pass



# Generated at 2022-06-22 15:07:32.467927
# Unit test for function eager
def test_eager():
    assert eager(list)([1,2,3]) == [1,2,3]

# Generated at 2022-06-22 15:07:34.065756
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():\n    pass'

# Generated at 2022-06-22 15:07:36.191929
# Unit test for function get_source
def test_get_source():
    expected = '    if 1:\n        return 3\n'



# Generated at 2022-06-22 15:08:33.820308
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    pass'

# Generated at 2022-06-22 15:08:37.108219
# Unit test for function get_source
def test_get_source():
    def func(arg1, arg2):
        return arg1 + arg2

    assert get_source(func) == 'return arg1 + arg2'

# Generated at 2022-06-22 15:08:45.003767
# Unit test for function debug
def test_debug():
    sys.modules['_py_backwards'].conf.settings.debug = True
    sys.stderr.seek(0)
    debug(lambda: 'Foo')
    assert sys.stderr.read() == '\x1b[94mDEBUG: Foo\x1b[0m\n'
    sys.modules['_py_backwards'].conf.settings.debug = False
    sys.stderr.seek(0)
    debug(lambda: 'Foo')
    assert sys.stderr.read() == ''
del test_debug