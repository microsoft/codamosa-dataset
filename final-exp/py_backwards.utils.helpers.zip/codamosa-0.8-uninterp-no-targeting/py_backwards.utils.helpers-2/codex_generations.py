

# Generated at 2022-06-21 18:30:58.454209
# Unit test for function debug
def test_debug():
    debug_message = 'Debug message'
    try:
        settings.debug = True
        debug(lambda: debug_message)
    finally:
        settings.debug = False



# Generated at 2022-06-21 18:31:03.299976
# Unit test for function debug
def test_debug():
    """If debug is False, debug(lambda: 'message') should not print anything."""
    saved_debug = settings.debug
    settings.debug = False

    try:
        debug(lambda: 'message')
    except UnboundLocalError:
        pass
    else:
        raise ValueError("When debugging is disabled, debug(lambda: 'message') shouldn't print anything")

    settings.debug = saved_debug



# Generated at 2022-06-21 18:31:09.904928
# Unit test for function debug
def test_debug():
    import sys
    import io

    # Redirect stdout
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()

    debug(lambda: 'debug message')
    assert sys.stdout.getvalue() == ''

    settings.debug = True
    debug(lambda: 'debug message')
    assert sys.stdout.getvalue() == messages.debug('debug message') + '\n'

    # Restore stdout
    sys.stdout = old_stdout

# Generated at 2022-06-21 18:31:12.332791
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'debug')
        debug(lambda: 'debug 2')
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:31:17.506877
# Unit test for function eager
def test_eager():
    def filter_odd_numbers(numbers):
        for number in numbers:
            if number % 2 != 0:
                yield number

    assert eager(filter_odd_numbers)(range(10)) == [1, 3, 5, 7, 9]

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-21 18:31:22.314660
# Unit test for function debug
def test_debug():
    result = []
    def example():
        result.append('Hello world')
    debug(example)
    assert result == []
    settings.debug = True
    try:
        debug(example)
        assert result == ['Hello world']
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:31:23.780078
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'function debug')

# Generated at 2022-06-21 18:31:31.557750
# Unit test for function debug
def test_debug():
    import sys
    import io

    class FakeStream:
        def __init__(self):
            self.written_strings = []

        def write(self, string: str):
            self.written_strings.append(string)

    settings.debug = True
    stdout = sys.stderr
    fake_stream = FakeStream()
    try:
        sys.stderr = fake_stream
        debug(lambda: 'test string')
    finally:
        sys.stderr = stdout

    assert 'test string' in fake_stream.written_strings[0]

# Generated at 2022-06-21 18:31:36.854072
# Unit test for function get_source
def test_get_source():
    def func(x: int, y: int) -> int:
        return x + y

    # FIXME: Fix this test. It uses internal source code formatting of
    # inspect.getsource
    assert get_source(func) == 'def func(x: int, y: int) -> int:\n    return x + y'


# Unit tests for function warn

# Generated at 2022-06-21 18:31:40.237747
# Unit test for function debug
def test_debug():
    with mock.patch('backwards.__main__.settings', debug=True):
        assert debug(lambda: 'hey')
    with mock.patch('backwards.__main__.settings', debug=False):
        assert debug(lambda: 'hey') is None

# Generated at 2022-06-21 18:31:47.876704
# Unit test for function warn
def test_warn():
    from io import StringIO
    stdout = sys.stderr
    sys.stderr = StringIO()
    try:
        warn("example warning")
        assert sys.stderr.getvalue() == '\033[93m\033[1m\n' \
                                        'PyBackwards\n' \
                                        'warning:\n' \
                                        'example warning\033[0m\n'
    finally:
        sys.stderr = stdout


# Generated at 2022-06-21 18:31:50.363392
# Unit test for function get_source
def test_get_source():
    def f():
        """Function for testing get_source.
        Does nothing.
        """
        pass
    assert get_source(f) == 'def f():\n    """Function for testing get_source.\n    Does nothing.\n    """\n    pass'

# Generated at 2022-06-21 18:31:52.392999
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-21 18:32:04.619790
# Unit test for function eager
def test_eager():
    from hypothesis import given
    from hypothesis.strategies import lists

    @eager
    def my_function() -> Iterable[int]:
        return [1, 2, 3]

    assert my_function() == [1, 2, 3]

    @eager
    def my_function(a: int, b: int) -> Iterable[int]:
        return [a, b]

    assert my_function(1, 2) == [1, 2]

    @given(lists(elements=lists(elements=int)))
    def test_eager(lst: List[List[int]]) -> None:
        assert sum(lst, []) == list(sum(lst, []))

    test_eager()


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-21 18:32:09.413618
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as stderr:
        warn('some string')
        assert stderr.getvalue().strip() == '\x1b[38;2;255;255;0mwarn\x1b[0m: some string'


# Generated at 2022-06-21 18:32:14.115388
# Unit test for function get_source
def test_get_source():
    def f1():
        pass

    def f2():
        print('  a')
        print('  b')

    expected1 = 'def f1():\n    pass'
    expected2 = '    print(\'  a\')\n    print(\'  b\')'
    assert get_source(f1) == exp

# Generated at 2022-06-21 18:32:16.383235
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first = VariablesGenerator.generate('variable')
    assert first == '_py_backwards_variable_0'
    second = VariablesGenerator.generate('variable')
    assert second == '_py_backwards_variable_1'

# Generated at 2022-06-21 18:32:18.623918
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    # Important part: test if get_source removes indentation from
    # source code.
    assert get_source(fn) == 'def fn():\n    pass\n'

# Generated at 2022-06-21 18:32:22.996711
# Unit test for function get_source
def test_get_source():
    def fn_that_can_be_backwarded_for_testing():
        pass

    assert get_source(fn_that_can_be_backwarded_for_testing) == 'def fn_that_can_be_backwarded_for_testing():\n    pass\n'



# Generated at 2022-06-21 18:32:33.722789
# Unit test for function eager
def test_eager():
    class IterClass:
        def __init__(self, elems: List[int]) -> None:
            self._elems = elems
            self._current = 0

        def __next__(self) -> int:
            if self._current == len(self._elems):
                raise StopIteration
            elem = self._elems[self._current]
            self._current += 1
            return elem

    @eager
    def return_list(nums: List[int]) -> Iterable[int]:
        for num in nums:
            yield num * 2

    res = return_list(IterClass([1, 2, 3, 4]))
    assert len(res) == 4
    assert res[0] == 2
    assert res[3] == 8



# Generated at 2022-06-21 18:32:37.448583
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == 'def fn():\n    pass'



# Generated at 2022-06-21 18:32:39.863854
# Unit test for function warn
def test_warn():
    with settings.use(debug=False):
        warn('Warn')
        assert capture_output(warn, 'Warn') == '[WARNING] Warn\n'


# Generated at 2022-06-21 18:32:43.193664
# Unit test for function eager
def test_eager():
    def test_eager(a):
        for i in range(10):
            a = i
            yield a
    assert eager(test_eager)(1) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-21 18:32:46.939092
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():'

    def bar():
        """Docstring."""
        pass
    assert get_source(bar) == 'def bar():'



# Generated at 2022-06-21 18:32:52.630539
# Unit test for function warn
def test_warn():
    output = StringIO()
    _old_stderr = sys.stderr
    sys.stderr = output
    message = 'test_warn'
    warn(message)
    sys.stderr = _old_stderr
    assert (output.getvalue() == '\n[WARN] {}'.format(message))



# Generated at 2022-06-21 18:32:56.887412
# Unit test for function warn
def test_warn():
    output = io.StringIO()
    with contextlib.redirect_stderr(output):
        warn('message')

    assert re.match(r'\x1b\[33m\[!\]\x1b\[0m message', output.getvalue()) is not None



# Generated at 2022-06-21 18:33:07.995119
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Message'

    class MockStdErr:
        def __init__(self, messages: List[str]) -> None:
            self.messages = messages

        def write(self, message: str) -> None:
            if message:
                self.messages.append(message)

    messages = []
    with patch.object(sys, 'stderr', MockStdErr(messages)) as stderr:
        with patch.object(settings, 'debug') as debug:
            debug.__get__ = Mock(return_value=False)
            debug(get_message)
            assert stderr.messages == []

            debug.__get__ = Mock(return_value=True)
            debug(get_message)

# Generated at 2022-06-21 18:33:10.408905
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        for _ in range(2):
            yield "Hi"
    assert foo() == ["Hi", "Hi"]


# Generated at 2022-06-21 18:33:13.129600
# Unit test for function get_source
def test_get_source():
    def get_source_test(arg1: str, arg2: str) -> str:
        return 'Hello ' + arg1 + arg2


# Generated at 2022-06-21 18:33:14.579748
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in range(10)))() == list(range(10))



# Generated at 2022-06-21 18:33:20.771617
# Unit test for function eager
def test_eager():
    @eager
    def foo(count: int) -> Iterable[int]:
        for _ in range(count):
            yield 5

    assert foo(5) == [5, 5, 5, 5, 5]

# Generated at 2022-06-21 18:33:25.651218
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-21 18:33:28.481244
# Unit test for function warn
def test_warn():
    import sys, io
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    message = "Test warn"
    warn(message)

    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == messages.warn(message) + '\n'

# Generated at 2022-06-21 18:33:33.732688
# Unit test for function debug
def test_debug():
    calls = []

    def get_message():
        calls.append(0)
        return 'message'

    debug(get_message)
    assert calls == []

    settings.debug = True
    debug(get_message)
    debug(get_message)
    assert calls == [0, 0]

# Generated at 2022-06-21 18:33:39.541040
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'
    assert VariablesGenerator.generate('ygdf') == '_py_backwards_ygdf_3'

# Generated at 2022-06-21 18:33:41.853843
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert(VariablesGenerator.generate('x') == '_py_backwards_x_0')

# Generated at 2022-06-21 18:33:46.790375
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate("a")
    b = VariablesGenerator.generate("a")
    c = VariablesGenerator.generate("a")
    assert a != b
    assert a != c
    assert b != c

if __name__ == "__main__":
    test_VariablesGenerator()

# Generated at 2022-06-21 18:33:53.545368
# Unit test for function get_source
def test_get_source():
    assert (get_source(get_source) == '@wraps(fn)\ndef wrapped(*args: Any, **kwargs: Any) -> None:\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)\n')



# Generated at 2022-06-21 18:33:57.577551
# Unit test for function eager
def test_eager():
    @eager
    def range_to(x: int) -> Iterable[int]:
        return range(x)

    r1 = range_to(10)
    assert isinstance(r1, list)
    assert r1 == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:33:59.409875
# Unit test for function eager
def test_eager():
    l = [1,2,3]
    assert eager(l) == l

# Generated at 2022-06-21 18:34:09.097914
# Unit test for function warn
def test_warn():
    # Input
    from io import StringIO
    stream = StringIO()
    sys.stderr = stream
    warn("test")
    # Output
    stream.seek(0)
    assert stream.read() == "WARNING: test\n"

# Generated at 2022-06-21 18:34:13.728327
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """
    >>> a = VariablesGenerator.generate('a')
    >>> b = VariablesGenerator.generate('b')
    >>> a != b
    True
    >>> a = VariablesGenerator.generate('a')
    >>> a == '_py_backwards_a_1'
    True
    """
    pass



# Generated at 2022-06-21 18:34:19.054955
# Unit test for function warn
def test_warn():
    import io
    import sys
    from unittest import TestCase, mock

    class TestWarn(TestCase):
        def test_warn(self):
            with io.StringIO() as stream, mock.patch('sys.stderr', stream):
                message = "Something went wrong"
                warn(message)
                self.assertEqual(stream.getvalue(), messages.warn(message))

    __test__ = {'test_warn': TestWarn}

# Generated at 2022-06-21 18:34:22.065087
# Unit test for function eager
def test_eager():
    def eager_fn() -> Iterable[int]:
        for i in range(100):
            yield i

    assert eager(eager_fn)() == list(range(100))



# Generated at 2022-06-21 18:34:27.947589
# Unit test for function debug
def test_debug():
    debug_message = "Hello, debug!"
    captured_output = StringIO()
    sys.stderr = captured_output
    settings.debug = True
    debug(lambda: debug_message)
    assert captured_output.getvalue() == messages.debug(debug_message)
    settings.debug = False
    debug(lambda: debug_message)
    assert captured_output.getvalue() == messages.debug(debug_message)



# Generated at 2022-06-21 18:34:28.808701
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-21 18:34:31.105401
# Unit test for function warn
def test_warn():
    import io
    stdout = sys.stderr
    try:
        sys.stderr = io.StringIO()
        warn('Message')
        assert sys.stderr.getvalue() == 'Message\n'
    finally:
        sys.stderr.close()
        sys.stderr = stdout

# Generated at 2022-06-21 18:34:43.085043
# Unit test for function warn
def test_warn():
    import sys
    import re
    import contextlib
    import io

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn("test message")
        print("test message", file=sys.stderr)

# Generated at 2022-06-21 18:34:45.846475
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            pass
    assert get_source(f) == 'def g():\n    pass'

# Generated at 2022-06-21 18:34:52.177118
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class _VariablesGenerator(VariablesGenerator):
        pass

    _VariablesGenerator._counter = 0
    assert _VariablesGenerator.generate('X') == '_py_backwards_X_0'
    assert _VariablesGenerator.generate('X') == '_py_backwards_X_1'
    assert _VariablesGenerator.generate('Y') == '_py_backwards_Y_2'


# Generated at 2022-06-21 18:35:04.967022
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
        yield 4
        yield 5
    assert gen() == [1,2,3,4,5]


# Generated at 2022-06-21 18:35:12.233029
# Unit test for function eager
def test_eager():
    a = [1, 2, 3]
    b = []

    @eager
    def test(x: List[int]) -> Iterable[int]:
        for _ in range(3):
            _ = x.pop()
            yield _
        b.append(5)

    assert test(a) == [3, 2, 1]
    assert b == [5]
    assert a == []


# Unit tests for function get_source

# Generated at 2022-06-21 18:35:13.657352
# Unit test for function get_source
def test_get_source():
    def foo():
        return True

    assert get_source(foo) == 'return True'

# Generated at 2022-06-21 18:35:16.071980
# Unit test for function debug
def test_debug():
    if settings.test_mode:
        def get_message():
            return "This is a test"
        debug(get_message)

# Generated at 2022-06-21 18:35:20.174592
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    f = StringIO()
    with redirect_stderr(f):
        warn("hello")
    assert f.getvalue() == "\x1b[93mwarn: hello\x1b[0m\n"


# Generated at 2022-06-21 18:35:25.810064
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    VariableGenerator = VariablesGenerator()
    assert VariableGenerator.generate("a") == '_py_backwards_a_0'
    assert VariableGenerator.generate("a") == '_py_backwards_a_1'
    assert VariableGenerator.generate("b") == '_py_backwards_b_2'
    assert VariableGenerator.generate("b") == '_py_backwards_b_3'

# Generated at 2022-06-21 18:35:31.348314
# Unit test for function warn
def test_warn():
    import io

    buffer = io.StringIO()
    sys.stderr = buffer

    warn('Warn message')

    sys.stderr = sys.__stderr__
    assert buffer.getvalue() == messages.warn('Warn message') + '\n'



# Generated at 2022-06-21 18:35:38.129676
# Unit test for function warn
def test_warn():
    from .. import messages
    from unittest.mock import patch
    print_patcher = patch('sys.stdout.write')
    messages_patcher = patch('py_backwards.conf.messages.warn')
    with print_patcher as mock_print, messages_patcher as mock_messages:
        mock_messages.return_value = 'fake_message'
        warn('fake_message')
        mock_messages.assert_called_once_with('fake_message')
        mock_print.assert_called_once_with('fake_message\n')

# Generated at 2022-06-21 18:35:41.301722
# Unit test for function eager
def test_eager():
    from itertools import count

    @eager
    def gen(n: int) -> Iterable[int]:
        for i in count(start=n):
            yield i

    assert gen(0) == [0, 1, 2]

# Generated at 2022-06-21 18:35:50.560634
# Unit test for function eager
def test_eager():
    import unittest.mock as mock

    # Test with no arguments
    @eager
    def f():
        yield 1

    assert f() == [1]

    # Test with one argument
    @eager
    def g(x):
        yield x + 1
        yield x + 2

    assert g(10) == [11, 12]

    # Test with multiple arguments
    @eager
    def h(x, y):
        yield x + y

    assert h(1, 2) == [3]

    # Test with keyword arguments
    @eager
    def i(x, y, z):
        yield x + y
        yield z

    assert i(1, 2, z=3) == [3, 3]

# Generated at 2022-06-21 18:36:11.757059
# Unit test for function warn
def test_warn():
    warn("test")

# Generated at 2022-06-21 18:36:19.534282
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # pylint: disable=global-statement
    global VariablesGenerator
    VariablesGenerator._counter = 0
    assert(VariablesGenerator.generate('a') == '_py_backwards_a_0')
    assert(VariablesGenerator.generate('b') == '_py_backwards_b_1')
    assert(VariablesGenerator.generate('a') == '_py_backwards_a_2')
    assert(VariablesGenerator.generate('b') == '_py_backwards_b_3')
    assert(VariablesGenerator.generate('b') == '_py_backwards_b_4')
    assert(VariablesGenerator.generate('a') == '_py_backwards_a_5')

# Generated at 2022-06-21 18:36:24.907149
# Unit test for function get_source
def test_get_source():
    def foo():
        x = '  def bar():\n        pass\n'
        return x

    def bar():
        pass

    assert get_source(foo) == 'def bar():\n    pass'
    assert get_source(bar) == 'def bar():\n    pass'


# Generated at 2022-06-21 18:36:29.591639
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    instance = VariablesGenerator()
    assert re.match(r'_py_backwards_\w+_\d+', instance.generate('MyVariable'))
    assert re.match(r'_py_backwards_\w+_\d+', instance.generate('MyVariable'))

# Generated at 2022-06-21 18:36:35.816955
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x_') == '_py_backwards_x__1'
    assert VariablesGenerator.generate('_x') == '_py_backwards__x_2'
    assert VariablesGenerator.generate('_x_') == '_py_backwards__x__3'
    assert VariablesGenerator.generate('_x_x') == '_py_backwards__x_x_4'

# Generated at 2022-06-21 18:36:43.085767
# Unit test for function warn
def test_warn():
    # In order to test `warn` we need to mock print
    import unittest.mock

    def assert_warn(expected_message: str) -> Callable[[str], None]:
        """Asserts that print was called with expected message."""
        def assert_called_wth(message: str) -> None:
            assert message == expected_message

        return assert_called_wth

    with unittest.mock.patch('backwards.utils.print', assert_warn(
            '{} {}'.format(messages.warning_prefix, 'message'))):
        warn('message')

# Generated at 2022-06-21 18:36:47.162457
# Unit test for function eager
def test_eager():
    """Unit test for eager function."""
    @eager
    def generator_fn(i: int) -> Iterable[int]:
        """Generator function."""
        for x in range(i):
            yield i

    assert generator_fn(10) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-21 18:36:49.006560
# Unit test for function eager
def test_eager():
    def f() -> Iterator[int]:
        for i in range(5):
            yield i

    assert eager(f)() == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:36:53.174694
# Unit test for function warn
def test_warn():
    from io import StringIO
    f = StringIO()
    sys.stderr = f
    warn('message')
    sys.stderr = sys.__stderr__

    assert f.getvalue().strip() == messages.warn('message')

# Generated at 2022-06-21 18:36:58.640045
# Unit test for function warn
def test_warn():
    import sys, io
    print(sys.stderr)
    sys.stderr = io.StringIO()
    warn("test")
    sys.stderr.seek(0)
    assert (sys.stderr.read() == "---\npybackwards: warn: test\n---\n")


# Generated at 2022-06-21 18:37:57.025049
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("some_name") == '_py_backwards_some_name_0'
    assert VariablesGenerator.generate("some_name") == '_py_backwards_some_name_1'
    assert VariablesGenerator.generate("some_name") == '_py_backwards_some_name_2'



# Generated at 2022-06-21 18:37:59.099105
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert list(gen()) == [1, 2, 3]

# Generated at 2022-06-21 18:38:09.526613
# Unit test for function warn
def test_warn():
    import contextlib
    import io
    with contextlib.redirect_stdout(io.StringIO()):
        warn("Hello World!")

# Generated at 2022-06-21 18:38:13.212740
# Unit test for function warn
def test_warn():
    from unittest import mock

    with mock.patch('sys.stderr', new_callable=StringIO) as stderr:
        warn('testing')
        assert stderr.getvalue() == messages.warn('testing') + '\n'



# Generated at 2022-06-21 18:38:19.650094
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first_variable = VariablesGenerator.generate("input")
    assert first_variable == '_py_backwards_input_0'
    second_variable = VariablesGenerator.generate("input")
    assert second_variable == '_py_backwards_input_1'
    assert VariablesGenerator._counter == 2


# Generated at 2022-06-21 18:38:21.805765
# Unit test for function eager
def test_eager():
    def fn(arg):
        for i in range(arg):
            yield i
    assert eager(fn)(3) == [0, 1, 2]

# Generated at 2022-06-21 18:38:26.173967
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        import sys
        from io import StringIO
        from contextlib import contextmanager

        @contextmanager
        def capture_output():
            old_out = sys.stdout
            try:
                out = StringIO()
                sys.stdout = out
                yield out
            finally:
                sys.stdout = old_out

        with capture_output() as out:
            debug(lambda: 'foo')
        assert out.getvalue().strip() == messages.debug('foo')
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:38:29.760574
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'


# Generated at 2022-06-21 18:38:32.448566
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for name in ['a', 'aa', 'aaaa', 'aaaaaaaaaaaaaaaaa']:
        new_name = VariablesGenerator.generate(name)
        assert new_name != name


# Generated at 2022-06-21 18:38:44.186546
# Unit test for function warn
def test_warn():
    from .. import messages
    from .. import settings
    from pytest import raises
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout():
        sio = StringIO()
        old_stdout = sys.stdout
        sys.stdout = sio
        try:
            yield sio
        finally:
            sys.stdout = old_stdout

    messages.warn = lambda x: x
    settings.debug = False
    settings.warnings = True

    with capture_stdout() as stdout:
        warn('Spam')
        assert stdout.getvalue() == 'Spam\n'

    settings.debug = True
    assert warn('Spam') is None

    settings.warnings = False
    assert warn('Spam') is None

# Generated at 2022-06-21 18:40:42.519926
# Unit test for function warn
def test_warn():
    import pytest
    from .stubs import stub_print

    msg = 'msg'

    with stub_print() as stub:
        warn(msg)

    assert stub.print.call_count == 1
    assert stub.print.call_args[0][0] == messages.warn(msg)

# Generated at 2022-06-21 18:40:48.952620
# Unit test for function debug
def test_debug():
    _messages = []
    _orig_print = messages.print
    messages.print = lambda m: _messages.append(m)

    from . import conf
    conf.debug = True
    debug(lambda: 'test')
    print(messages.debug)
    assert _messages == [messages.debug('test')]

    conf.debug = False
    debug(lambda: 'test')
    assert _messages == [messages.debug('test')]

    messages.print = _orig_print

# Generated at 2022-06-21 18:40:50.136633
# Unit test for function get_source
def test_get_source():
    def test():
        print('test')

    source_code = '''def test():
    print('test')'''
    assert source_code == get_source(test)

# Generated at 2022-06-21 18:40:52.329976
# Unit test for function get_source
def test_get_source():
    def f(x, y):
        return x + y
    assert get_source(f) == 'return x + y'

# Generated at 2022-06-21 18:40:54.494257
# Unit test for function warn
def test_warn():
    try:
        warn('warn')
        print('success')
    except:
        print('fail')


if __name__ == "__main__":
    test_warn()