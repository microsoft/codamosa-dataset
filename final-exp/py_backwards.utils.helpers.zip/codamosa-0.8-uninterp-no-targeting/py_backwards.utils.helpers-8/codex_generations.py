

# Generated at 2022-06-21 18:30:45.995281
# Unit test for function warn
def test_warn():
    def get_keyboard_interrupt_error_message() -> str:
        try:
            raise KeyboardInterrupt()
        except KeyboardInterrupt:
            return str(sys.exc_info()[1])

    error_message = get_keyboard_interrupt_error_message()
    sys.stdout = io.StringIO()
    warn('message')
    output = sys.stdout.getvalue()
    sys.stdout = sys.__stdout__
    assert output == '{}: message\n'.format(error_message)


# Generated at 2022-06-21 18:30:48.473584
# Unit test for function get_source
def test_get_source():
    def f():
        return 1

    assert get_source(f) == 'return 1'



# Generated at 2022-06-21 18:30:49.440913
# Unit test for function warn
def test_warn():
    warn('I am a test message')



# Generated at 2022-06-21 18:30:54.942835
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("b") == '_py_backwards_b_1'



# Generated at 2022-06-21 18:30:57.963329
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-21 18:30:58.936978
# Unit test for function warn
def test_warn():
    warn('test message')


# Generated at 2022-06-21 18:31:01.818766
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'

    def test2():
        if True:
            pass

    assert get_source(test2) == 'if True:\n    pass'

# Generated at 2022-06-21 18:31:07.427733
# Unit test for function warn
def test_warn():
    from io import StringIO
    try:
        sys.stderr = StringIO()
        warn("This should be written to stderr.")
        assert '\x1b[33m' in sys.stderr.getvalue()
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:31:09.759152
# Unit test for function debug
def test_debug():
    def get_message():
        return "Hello"
    debug(get_message)
    settings.debug = True
    debug(get_message)



# Generated at 2022-06-21 18:31:11.396305
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == "_py_backwards_a_0"

# Generated at 2022-06-21 18:31:18.582850
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("xx") == "_py_backwards_xx_0"
    assert VariablesGenerator.generate("xx") == "_py_backwards_xx_1"
    assert VariablesGenerator.generate("xx") == "_py_backwards_xx_2"


# Generated at 2022-06-21 18:31:22.414780
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(10))() == list(range(10))

    @eager
    def f():
        for i in range(10):
            yield i
    assert f() == list(range(10))

# Generated at 2022-06-21 18:31:23.875823
# Unit test for function get_source

# Generated at 2022-06-21 18:31:25.708292
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == "pass"

# Generated at 2022-06-21 18:31:28.829185
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'

# Generated at 2022-06-21 18:31:35.762347
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        import io
        import sys
        stream = io.StringIO()
        sys.stderr = stream
        debug(lambda: 'debug message')
        assert 'debug message' in stream.getvalue()
        settings.debug = False
        stream.truncate(0)
        debug(lambda: 'debug message')
        assert stream.tell() == 0
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:31:37.369109
# Unit test for function warn
def test_warn():
    __tracebackhide__ = True
    try:
        raise Exception('message')
    except:
        warn('message')

# Generated at 2022-06-21 18:31:43.568012
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        captured_output = io.StringIO()
        sys.stderr = captured_output
        debug(lambda: 'A debug message')
        assert captured_output.getvalue() == '\n'.join((messages.color('DEBUG', 'red'), 'A debug message', '\n'))
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-21 18:31:48.749519
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    var = gen.generate('num')
    assert var == '_py_backwards_num_0'

    gen1 = VariablesGenerator()
    var1 = gen1.generate('num')
    assert var1 == '_py_backwards_num_1'

# Generated at 2022-06-21 18:31:51.393005
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'


# Generated at 2022-06-21 18:32:04.316976
# Unit test for function debug
def test_debug():
    from io import StringIO

    import sys
    import backwards
    import backwards.conf.settings as _settings
    from backwards.utils import debug

    old_stdout = sys.stderr
    new_stdout = sys.stderr = StringIO()
    try:
        _settings.debug = True
        debug(lambda: 'Test')
        assert new_stdout.getvalue().strip() == 'DEBUG: Test'
        new_stdout.seek(0)
        new_stdout.truncate()

        _settings.debug = False
        debug(lambda: 'Test')
        assert new_stdout.getvalue().strip() == ''
    finally:
        sys.stderr = old_stdout



# Generated at 2022-06-21 18:32:07.515132
# Unit test for function warn
def test_warn():
    with tempfile.TemporaryFile() as tmp:
        sys.stderr = tmp
        warn('test')
        tmp.seek(0)
        result = tmp.read().decode()
        tmp.close()
        assert result == messages.warn('test') + '\n'


# Generated at 2022-06-21 18:32:10.974164
# Unit test for function get_source
def test_get_source():
    def source_code():
        # 1.
        def fn():
            return 1

        # 2.
            return 2


# Generated at 2022-06-21 18:32:13.317586
# Unit test for function get_source
def test_get_source():
    def add(a: int, b: int) -> int:
        return a + b
    assert get_source(add) == 'return a + b'



# Generated at 2022-06-21 18:32:15.259213
# Unit test for function get_source
def test_get_source():
    def func(): pass
    assert get_source(get_source) == 'def func(): pass'


# Generated at 2022-06-21 18:32:18.418720
# Unit test for function debug
def test_debug():
    from .capture import Capture
    from .patcher import patch, replace

    def get_message():
        return 'test'

    with Capture() as capture:
        with patch(replace=replace, debug=True):
            debug(get_message)

    assert capture.output == 'debug: test\n'



# Generated at 2022-06-21 18:32:20.613667
# Unit test for function eager
def test_eager():
    @eager
    def gen_numbers(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    result = gen_numbers(10)
    assert result == list(range(10))

# Generated at 2022-06-21 18:32:24.645745
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    import sys

    out = StringIO()
    sys.stderr = out

    warn('some message')

    assert out.getvalue().strip() == 'some message'

# Generated at 2022-06-21 18:32:33.364181
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import contextmanager, redirect_stderr

    @contextmanager
    def captured_output() -> Any:
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn('test')
    assert 'test' in err.getvalue()



# Generated at 2022-06-21 18:32:38.194515
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('x') == '_py_backwards_x_0'
    assert gen.generate('y') == '_py_backwards_y_1'
    assert gen.generate('x') == '_py_backwards_x_2'



# Generated at 2022-06-21 18:32:42.851721
# Unit test for function debug
def test_debug():
    import os

    old_debug = settings.debug
    settings.debug = True
    debug(lambda: os.getpid())
    settings.debug = old_debug



# Generated at 2022-06-21 18:32:45.917383
# Unit test for function warn
def test_warn():
    try:
        sys.stderr = open('test_output.txt', 'w')
        warn('Warning!')
        sys.stderr.close()
        sys.stderr = sys.__stderr__
        assert open('test_output.txt').read() == messages.warn('Warning!')
    except Exception as e:
        print(e)


# Generated at 2022-06-21 18:32:51.139840
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        warn('message')
        assert stderr.write.call_args[0][0] == '\033[33mmessage\033[0m\n'



# Generated at 2022-06-21 18:32:52.803965
# Unit test for function debug
def test_debug():
    message = 'message'
    debug(lambda: message) == message



# Generated at 2022-06-21 18:32:56.732244
# Unit test for function debug
def test_debug():
    _message = None

    def get_message() -> str:
        nonlocal _message
        _message = "Test message"
        return _message

    settings.debug = True
    debug(get_message)
    settings.debug = False

    assert _message == None

# Generated at 2022-06-21 18:32:59.701711
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        z = 1
        return a + b

    assert get_source(test_function) == '''\
z = 1
return a + b'''

# Generated at 2022-06-21 18:33:05.622866
# Unit test for function warn
def test_warn():
    try:
        out, err = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = StringIO(), StringIO()
        warn('test')
        assert sys.stderr.getvalue() == messages.warn('test') + '\n'
    finally:
        sys.stdout, sys.stderr = out, err



# Generated at 2022-06-21 18:33:07.788195
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    expected_source = """def foo():
    pass"""

    assert get_source(foo) == expected_source

# Generated at 2022-06-21 18:33:14.920880
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    first_var = VariablesGenerator.generate('v')
    assert first_var == '_py_backwards_v_0'
    assert VariablesGenerator._counter == 1
    second_var = VariablesGenerator.generate('v')
    assert second_var == '_py_backwards_v_1'
    third_var = VariablesGenerator.generate('x_')
    assert third_var == '_py_backwards_x__2'
    assert VariablesGenerator._counter == 3
    assert first_var != second_var != third_var


# Generated at 2022-06-21 18:33:24.747039
# Unit test for function debug
def test_debug():
    import io
    import sys

    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    messages.debug = lambda msg: 'DEBUG: {}'.format(str(msg))
    settings.debug = True

    try:
        debug(lambda: 'This is a debug message.')
        assert sys.stderr.getvalue() == 'DEBUG: This is a debug message.\n'
    finally:
        settings.debug = False
        sys.stderr = old_stderr

    from .. import messages
    from ..conf import settings



# Generated at 2022-06-21 18:33:38.626746
# Unit test for function warn
def test_warn():
    import sys
    def test_warn(stderr, message):
        warn(message)
        assert stderr.getvalue().strip() == messages.warn(message)
    #String value
    with conditional_captured_output('stderr') as stderr:
        test_warn(stderr, "warning")
    #Integer value
    with conditional_captured_output('stderr') as stderr:
        test_warn(stderr, 1)
    #Random string value
    with conditional_captured_output('stderr') as stderr:
        test_warn(stderr, "pokemon")


# Generated at 2022-06-21 18:33:45.969123
# Unit test for function warn
def test_warn():
    saved_stderr = sys.stderr
    try:
        from io import StringIO
        out = StringIO()
        sys.stderr = out
        warn('Hello world!')
        assert out.getvalue().startswith('\x1b[33m')
        assert out.getvalue().endswith('\x1b[0m\n')
        assert 'Hello world!' in out.getvalue()
    finally:
        sys.stderr = saved_stderr

# Generated at 2022-06-21 18:33:47.888884
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "This is ignored")
    assert not settings.debug



# Generated at 2022-06-21 18:33:52.934499
# Unit test for function warn
def test_warn():
    import sys
    f = sys.stderr
    sys.stderr = open('temp', 'w')
    warn("test warn")
    sys.stderr.close()
    sys.stderr = f
    assert issubclass(str(open('temp').read()), str(messages.warn("test warn")))


# Generated at 2022-06-21 18:33:55.301441
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        print("test")
        yield

    test_function()



# Generated at 2022-06-21 18:33:56.358893
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo')

# Generated at 2022-06-21 18:34:01.975970
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO
    buffer = StringIO()
    try:
        orig = sys.stderr
        sys.stderr = buffer
        warn('hello')
        sys.stderr = buffer
        assert buffer.getvalue() == 'Warning: hello\n'
    finally:
        sys.stderr = orig
        buffer.close()

# Generated at 2022-06-21 18:34:06.465306
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    try:
        counter = VariablesGenerator._counter
        assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
        assert VariablesGenerator.generate('y') == '_py_backwards_y_1'
        assert VariablesGenerator._counter == 2 + counter
    finally:
        VariablesGenerator._counter = counter

# Generated at 2022-06-21 18:34:09.050114
# Unit test for function eager
def test_eager():
    def foo(x: int) -> Iterable[int]:
        yield x
        yield x
    assert eager(foo)(3) == [3, 3]

# Generated at 2022-06-21 18:34:11.695060
# Unit test for function get_source
def test_get_source():  # pragma: no cover
    def test(a, b):
        c = a + b
        d = a - b
        return c, d


    print(get_source(test))

# Generated at 2022-06-21 18:34:25.949312
# Unit test for function debug
def test_debug():
    settings.debug = True

    try:
        # Function should show debug message
        debug(lambda: 'message')
        print('debug message shown')

        # Function shouldn't show debug message
        settings.debug = False
        debug(lambda: 'message')
        raise Exception('debug message not shown')
    except Exception:
        settings.debug = False
        raise

# Generated at 2022-06-21 18:34:29.689458
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert(VariablesGenerator._counter == 0)
    assert(VariablesGenerator.generate('arg') == '_py_backwards_arg_0')
    assert(VariablesGenerator.generate('arg') == '_py_backwards_arg_1')
    assert(VariablesGenerator._counter == 2)

# Generated at 2022-06-21 18:34:32.664936
# Unit test for function debug
def test_debug():
    debug_messages = []  # type: List[str]

    def func():
        debug_messages.append('message')

    func()
    assert not debug_messages

    settings.debug = True
    func()
    assert debug_messages == ['message']

# Generated at 2022-06-21 18:34:34.385739
# Unit test for function get_source
def test_get_source():
    def code():  # pylint: disable=unused-variable,missing-docstring
        return 1
    assert get_source(code) == 'return 1'

# Generated at 2022-06-21 18:34:37.164272
# Unit test for function warn
def test_warn():
    def dummy_print(*args, **kwargs):
        pass
    sys.stderr.write = dummy_print
    warn("Test warn: email:abc@abc.abc")



# Generated at 2022-06-21 18:34:45.024323
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('param') for i in range(10)]
    assert variables == ['_py_backwards_param_0', '_py_backwards_param_1', '_py_backwards_param_2',
                         '_py_backwards_param_3', '_py_backwards_param_4', '_py_backwards_param_5',
                         '_py_backwards_param_6', '_py_backwards_param_7', '_py_backwards_param_8',
                         '_py_backwards_param_9']

# Generated at 2022-06-21 18:34:49.123931
# Unit test for function eager
def test_eager():
    @eager
    def check_eager(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert [0, 1] == check_eager(2)


# Generated at 2022-06-21 18:34:52.710305
# Unit test for function debug
def test_debug():
    print('test_debug')
    print = lambda s: sys.stdout.write(s+'\n')

    def foo():
        debug(lambda: 'test')

    settings.debug = True
    foo()
    settings.debug = False
    foo()



# Generated at 2022-06-21 18:34:57.279615
# Unit test for function warn
def test_warn():
    import io
    from contextlib import redirect_stderr
    from unittest import mock

    with mock.patch('sys.stderr', new=io.StringIO()) as mock_stderr:  # type: ignore
        with redirect_stderr(mock_stderr):
            warn('warning')
            assert mock_stderr.getvalue() == '\n\x1b[93mwarning\x1b[0m\n'

# Generated at 2022-06-21 18:34:57.874771
# Unit test for function warn
def test_warn():
    warn("warning message")

# Generated at 2022-06-21 18:35:19.093754
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello')



# Generated at 2022-06-21 18:35:24.648486
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'
    assert get_source(test_get_source) == 'def test_get_source():\n    def foo():\n        pass\n\n    assert get_source(foo) == \'def foo():\\n    pass\\n\'\n'



# Generated at 2022-06-21 18:35:35.678398
# Unit test for function debug
def test_debug():
    import os
    import tempfile

    def get_message():
        return 'Hello, world!'

    _stdout = sys.stderr
    try:
        fd, path = tempfile.mkstemp()
        sys.stderr = os.fdopen(fd, 'w')
        debug(get_message)
        sys.stderr.close()
        with open(path) as fp:
            assert fp.read() == ''
        settings.debug = True
        debug(get_message)
        sys.stderr.close()
        with open(path) as fp:
            assert fp.read() == '{} {}\n'.format(messages.DEBUG, get_message())
    finally:
        settings.debug = False
        sys.stderr = _stdout



# Generated at 2022-06-21 18:35:37.004671
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello %s', 'World')



# Generated at 2022-06-21 18:35:39.963418
# Unit test for function get_source
def test_get_source():
    """ get_source() should return source code of the given function """
    def foo():
        return "foo"

    assert get_source(foo) == "return \"foo\""



# Generated at 2022-06-21 18:35:44.552235
# Unit test for function warn
def test_warn():
    out = StringIO()
    with redirect_stderr(out):
        warn('Test do not ignore')
    assert out.getvalue() == '\x1b[33mWarning:\x1b[0m Test do not ignore\n'



# Generated at 2022-06-21 18:35:47.895140
# Unit test for function debug
def test_debug():
    class TestException(Exception):
        pass

    def test_function():
        raise TestException('some message')

    try:
        with settings(debug=True):
            debug(lambda: 'some test message')
    except TestException:
        pass



# Generated at 2022-06-21 18:35:52.124123
# Unit test for function get_source
def test_get_source():
    def f():
        """Test function for get_source"""
        pass
    assert get_source(f) == 'def f():\n    """Test function for get_source"""\n    pass'

# Generated at 2022-06-21 18:36:02.788397
# Unit test for function debug
def test_debug():
    from .session import Session
    from io import StringIO
    from mpi4py import MPI
    session = Session()
    session.start()
    session.comm.Barrier()
    if session.rank == 0:
        captured_output = StringIO()
        sys.stderr = captured_output
        debug(lambda: 'Test message')
        # Reset to normal
        sys.stderr = sys.__stderr__
        assert captured_output.getvalue() == ''.join([f'\x1b[1;33m{MPI.COMM_WORLD.rank:03d}\x1b[0m \x1b[1;35mTest message\x1b[0m\n'])
    session.stop()

# Generated at 2022-06-21 18:36:08.108921
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate("test1"))
    print(VariablesGenerator.generate("test2"))
    print(VariablesGenerator.generate("test3"))
    print(VariablesGenerator.generate("test4"))


if __name__ == "__main__":
    test_VariablesGenerator()

# Generated at 2022-06-21 18:37:08.098055
# Unit test for function get_source
def test_get_source():
    def test_function():
        """Test function docstring.

        First line of the docstring.
        """
        pass

    expected_source = (
        'def test_function():\n'
        "    \"\"\"Test function docstring.\n\n"
        "    First line of the docstring.\n"
        "    \"\"\"\n"
        '    pass\n'
    )
    assert get_source(test_function) == expected_source


if __name__ == '__main__':
    def debug_test():
        # print 1
        # print 2
        # print 3
        pass


# Generated at 2022-06-21 18:37:19.055301
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch('sys.stderr.write') as write:
        settings.debug = True
        try:
            debug(lambda: 'message')
        finally:
            settings.debug = False
        write.assert_called_with('\033[0;33;40mDEBUG: message\033[0m\n')

        with patch('py_backwards.messages.debug') as mock_messages_debug:
            mock_messages_debug.return_value = 'colored message'

            settings.debug = True
            try:
                debug(lambda: 'message')
            finally:
                settings.debug = False

            mock_messages_debug.assert_called_with('message')
            write.assert_called_with('colored message\n')

        settings.debug = False
       

# Generated at 2022-06-21 18:37:20.211893
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '    assert get_source(test_get_source) == ...'

# Generated at 2022-06-21 18:37:27.486082
# Unit test for function get_source
def test_get_source():
    def test(a, b, c=None): pass

    def gen(a, b, c=None):
        yield a
        yield 1

    assert get_source(test).strip() == 'def test(a, b, c=None): pass'
    assert get_source(gen).strip() == 'def gen(a, b, c=None):\n\tyield a\n\tyield 1'

# Generated at 2022-06-21 18:37:29.615748
# Unit test for function get_source
def test_get_source():
    def add(a, b):
        return a + b

    assert get_source(add) == 'return a + b'



# Generated at 2022-06-21 18:37:31.438001
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-21 18:37:33.352257
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for i in range(10):
            yield i
    assert gen() == list(range(10))

# Generated at 2022-06-21 18:37:37.093085
# Unit test for function warn
def test_warn():
    from io import StringIO
    out = StringIO()
    with redirect_stderr(out):
        warn('some warning')
    stderr = out.getvalue()
    assert stderr.startswith('\x1b[33m')
    assert stderr.endswith('some warning\x1b[0m\n')


# Generated at 2022-06-21 18:37:39.750281
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate('foo')
    v2 = VariablesGenerator.generate('bar')
    assert v1 != v2

# Generated at 2022-06-21 18:37:43.921986
# Unit test for function get_source
def test_get_source():
    def dummy_function(a, b):
        """Docstring
        """
        local_variable = 1
        local_function(a, b, c=1)
        return

    def local_function(a, b, c=1):
        return


# Generated at 2022-06-21 18:39:41.272710
# Unit test for function warn
def test_warn():
    with captured_output() as (out, err):
        warn('This is a warning message')
    output = err.getvalue().strip()
    assert output == messages.warning_prefix() + 'This is a warning message'

# python -m pytest py/backwards/utils.py -s -v

# Generated at 2022-06-21 18:39:44.457687
# Unit test for function get_source
def test_get_source():
    def test():
        if True:
            pass
    assert get_source(test) == 'if True:\n    pass'



# Generated at 2022-06-21 18:39:45.874514
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import random
    variables = [VariablesGenerator.generate('x') for _ in range(random.randrange(1, 10))]
    assert len(variables) == len(set(variables))

# Generated at 2022-06-21 18:39:47.907351
# Unit test for function get_source
def test_get_source():
    def fn():
        a = 1
        return a

    assert get_source(fn) == 'a = 1\nreturn a\n'

# Generated at 2022-06-21 18:39:51.923948
# Unit test for function warn
def test_warn():
    message = 'Test warn'
    capturedOutput = StringIO()
    sys.stderr = capturedOutput
    warn(message)
    assert capturedOutput.getvalue() == messages.warn(message) + '\n'


# Generated at 2022-06-21 18:39:54.990248
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test_count = 1000
    test_list = []
    for _ in range(test_count):
        test_list.append(VariablesGenerator.generate('test'))
    assert len(test_list) == len(set(test_list))

# Generated at 2022-06-21 18:39:57.127530
# Unit test for function warn
def test_warn():
    try:
        print('before message')
        warn('message')
        raise Exception('This should not happen')
    except SystemExit:
        print('after message')



# Generated at 2022-06-21 18:40:05.698338
# Unit test for function debug
def test_debug():
    debug_settings = settings.debug

    msgs = []
    def new_debug(get_message: Callable[[], str]) -> None:
        msgs.append(get_message())

    settings.debug = True
    globals()['debug'] = new_debug
    debug(lambda: 'foo')
    assert msgs == ['foo']

    settings.debug = False
    globals()['debug'] = new_debug
    msgs = []
    debug(lambda: 'bar')
    assert msgs == []

    settings.debug = debug_settings

# Generated at 2022-06-21 18:40:07.348309
# Unit test for function get_source
def test_get_source():
    def function(a, b, c):
        return a + b + c
    assert get_source(function).rstrip() == 'return a + b + c'

# Generated at 2022-06-21 18:40:09.453881
# Unit test for function debug
def test_debug():
    def test_debug_wrapper():
        debug(lambda: 'test debug')

    test_debug_wrapper()