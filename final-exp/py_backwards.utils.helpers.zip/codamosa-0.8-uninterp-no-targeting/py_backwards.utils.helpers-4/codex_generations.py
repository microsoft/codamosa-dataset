

# Generated at 2022-06-21 18:30:43.355119
# Unit test for function get_source
def test_get_source():
    """Tests if get_source returns correct source code of a function."""
    def fn(a, b, c=1, d=5):
        return a + b + c + d

    assert get_source(fn) == (
        'def fn(a, b, c=1, d=5):\n'
        '    return a + b + c + d\n'
        '\n'
    )

# Generated at 2022-06-21 18:30:44.396789
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello world!')
    assert True



# Generated at 2022-06-21 18:30:46.713565
# Unit test for function warn
def test_warn():
    from contextlib import redirect_stderr
    from io import StringIO

    with redirect_stderr(StringIO()) as err:
        warn('message')
    assert err.getvalue() == '\n{}Warning: {}\n'.format(
        messages.point, 'message')



# Generated at 2022-06-21 18:30:51.193053
# Unit test for function get_source
def test_get_source():
    func_test = lambda: 1

# Generated at 2022-06-21 18:30:52.839158
# Unit test for function debug
def test_debug():
    pass

# Generated at 2022-06-21 18:31:00.680653
# Unit test for function debug
def test_debug():
    from unittest.mock import patch, call
    from sys import stderr
    with patch('sys.stderr', new_callable=lambda: stderr):
        debug(lambda: 'msg')
        with settings(debug=True):
            assert stderr.write.call_count == 0
            debug(lambda: 'msg')
        assert stderr.write.call_args_list == [
            call(messages.debug('msg')),
            call(messages.debug('msg')),
        ]

# Generated at 2022-06-21 18:31:04.706401
# Unit test for function eager
def test_eager():
    def gen(a: int, b: int) -> Iterable[int]:
        for i in range(a):
            yield i
        for j in range(b):
            yield j

    assert gen(2, 3) == range(2)
    assert type(gen(2, 3)) is range
    assert eager(gen)(2, 3) == [0, 1, 0, 1, 2]
    assert type(eager(gen)(2, 3)) is list

# Generated at 2022-06-21 18:31:07.526990
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    b = VariablesGenerator()
    assert a.generate("one") != b.generate("one")


# Generated at 2022-06-21 18:31:09.856107
# Unit test for function warn
def test_warn():
    err = sys.stderr
    sys.stderr = sys.stdout
    warn('test')
    sys.stderr = err

# Generated at 2022-06-21 18:31:15.041585
# Unit test for function warn
def test_warn():
    import sys
    import io
    test_warn_message = 'Test warn message for testing purposes'
    fake_stderr = io.StringIO()
    original_stderr = sys.stderr
    sys.stderr = fake_stderr
    try:
        warn(test_warn_message)
    finally:
        sys.stderr = original_stderr
    assert fake_stderr.getvalue().rstrip() == messages.warn(test_warn_message)

# Generated at 2022-06-21 18:31:28.466431
# Unit test for function get_source
def test_get_source():
    from .. import utils
    from ..conf import settings
    from . import warn
    import sys

    settings.debug = True

    @utils.debug
    def add(a: int, b: int) -> int:
        return a + b

    @warn
    def test_get_source_is_correct():
        assert get_source(add) == '@utils.debug\ndef add(a, b):\n    return a + b'

    @warn
    def test_get_source_is_indented():
        def bar(a: int, b: int) -> int:
            return a + b
        assert get_source(bar) == 'return a + b'

    test_get_source_is_correct()
    test_get_source_is_indented()


# Generated at 2022-06-21 18:31:31.696334
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'


# Generated at 2022-06-21 18:31:32.858222
# Unit test for function warn
def test_warn():
    warn('test warn')


# Generated at 2022-06-21 18:31:38.547358
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables_list = []
    for i in range(1, 10):
        var_name = VariablesGenerator.generate('quark')
        assert 'quark' in var_name
        variables_list.append(var_name)
        print(var_name)
    assert 'quark' not in var_name
    assert len(variables_list) == 9
# test_VariablesGenerator()

# Generated at 2022-06-21 18:31:41.922221
# Unit test for function warn
def test_warn():
    counter = 0
    def func():
        import sys
        def my_stderr(x):
            global counter
            counter += int(x)

        sys.stderr.write = my_stderr
        warn('123')

    func()
    assert counter == 123


# Generated at 2022-06-21 18:31:43.567888
# Unit test for function eager
def test_eager():
    assert eager(range)(0, 3) == [0, 1, 2]

# Generated at 2022-06-21 18:31:48.167551
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'



# Generated at 2022-06-21 18:31:51.805720
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('var') for _ in range(10)]
    assert len(variables) == 10
    assert len(set(variables)) == 10



# Generated at 2022-06-21 18:31:53.117183
# Unit test for function debug
def test_debug():
    assert messages.debug('test') == 'Debug: test'

# Generated at 2022-06-21 18:31:59.113622
# Unit test for function warn
def test_warn():
    from io import StringIO
    from sys import stderr

    old_stderr = stderr
    try:
        stderr = StringIO()
        warn('hello')
        assert 'hello' in stderr.getvalue()
    finally:
        stderr.close()
        stderr = old_stderr



# Generated at 2022-06-21 18:32:03.072440
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'It works')
    finally:
        settings.debug = False


# Generated at 2022-06-21 18:32:06.753524
# Unit test for function debug
def test_debug():
    settings.debug = True
    print('Running test_debug...')
    try:
        debug(lambda: 'message')
        debug(lambda: 'message 2')
    finally:
        settings.debug = False
    # If it reached here it means no exception was raised
    print('success!')

# Generated at 2022-06-21 18:32:11.989515
# Unit test for function get_source
def test_get_source():
    def fn(a, b = 1, *args, c=3, **kwargs):
        print(a, b, c, args, kwargs)
    assert get_source(fn) == dedent('''
        def fn(a, b = 1, *args, c=3, **kwargs):
            print(a, b, c, args, kwargs)
    ''').strip('\n')

# Generated at 2022-06-21 18:32:15.975174
# Unit test for function eager
def test_eager():
    def read_file(path: str) -> Iterable[str]:
        with open(path, mode='r') as f:
            for line in f:
                yield line.strip()
    assert eager(read_file)('eager.py') == list(read_file('eager.py'))


# Generated at 2022-06-21 18:32:17.668684
# Unit test for function eager
def test_eager():
    def fn(a, b):
        yield a
        yield b
    assert fn(1, 2) == [1, 2]


# Generated at 2022-06-21 18:32:20.850412
# Unit test for function debug
def test_debug():
    test_debug_message = "test_debug message"
    def assert_printed(out, err):
        assert test_debug_message in err
    settings.debug = True
    with settings(input_stream=None, output_stream=None, err_stream=assert_printed):
        debug(lambda: test_debug_message)
    settings.debug = False


# Generated at 2022-06-21 18:32:24.897885
# Unit test for function warn
def test_warn():
    with open(os.devnull, 'w') as null:
        stdout = sys.stdout
        sys.stdout = null
        warn('test')
        sys.stdout = stdout


# Generated at 2022-06-21 18:32:30.532344
# Unit test for function get_source
def test_get_source():
    def inner():
        def foo():
            """
            A function that does nothing.

            >>> print(foo.__doc__)
            A function that does nothing.

            """

    assert get_source(inner) == 'def foo():\n    """\n    A function that does nothing.\n\n    >>> print(foo.__doc__)\n    A function that does nothing.\n\n    """\n'

# Generated at 2022-06-21 18:32:33.812711
# Unit test for function eager
def test_eager():
    function_test = lambda: range(10)
    expected_output = [0,1,2,3,4,5,6,7,8,9]
    test_instance = eager(function_test)
    assert test_instance() == expected_output

# Generated at 2022-06-21 18:32:39.397739
# Unit test for function warn
def test_warn():
    import io
    import sys

    try:
        sys.stderr = io.StringIO()
        warn('This is test message')
        stderr = sys.stderr.getvalue()
        sys.stderr.close()
        assert stderr == messages.warn('This is test message') + '\n'
    except AssertionError:
        print(stderr)
        raise

# Generated at 2022-06-21 18:32:46.631931
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('_a') == '_py_backwards__a_0'
    assert VariablesGenerator.generate('_a') == '_py_backwards__a_1'
    assert VariablesGenerator.generate('_b') == '_py_backwards__b_2'
    assert VariablesGenerator.generate('_b') == '_py_backwards__b_3'
    assert VariablesGenerator.generate('_a') == '_py_backwards__a_4'
    assert VariablesGenerator.generate('_b') == '_py_backwards__b_5'


# Generated at 2022-06-21 18:32:47.262797
# Unit test for function debug
def test_debug():
    msg = 'test'
    debug(lambda: msg)



# Generated at 2022-06-21 18:32:50.781940
# Unit test for function eager
def test_eager():
    def noop(*args): pass

    @eager
    def fn(*args):
        for i in range(3):
            yield i

    noop(*fn()) == [0, 1, 2]

# Generated at 2022-06-21 18:32:56.570272
# Unit test for function warn
def test_warn():
    from ..conf import settings
    from io import StringIO
    import sys
    temp_out = StringIO()
    temp_err = StringIO()
    sys.stdout = temp_out
    sys.stderr = temp_err
    warn("Hello")
    assert temp_err.getvalue().split()[-1] == "Hello"
    assert temp_out.getvalue() == ""


# Generated at 2022-06-21 18:33:00.114677
# Unit test for function warn
def test_warn():
    with captured_output() as (out, err):
        warn("Warn Message")
        out_err_msg = err.getvalue().strip()
    assert out_err_msg == messages.warn("Warn Message")



# Generated at 2022-06-21 18:33:05.009825
# Unit test for function debug
def test_debug():
    def test():
        debug_msg = []
        def get_message():
            debug_msg.append('foo')
            return 'bar'

        debug(get_message)
        return debug_msg

    assert len(test()) == 1
    settings.debug = False
    assert len(test()) == 0

# Generated at 2022-06-21 18:33:07.216241
# Unit test for function eager
def test_eager():
    def double(a: int) -> Iterable[int]:
        yield a * 2

    assert eager(double)(3) == [6]

# Generated at 2022-06-21 18:33:13.854787
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .conf import settings
    from . import messages

    # We need to change settings to debug mode to test debug function
    settings.debug = True

    # Open StringIO to catch all prints
    with StringIO() as stream:
        sys.stderr = stream
        debug(lambda: 'test')
        sys.stderr = sys.__stderr__

    assert stream.getvalue() == messages.debug('test') + '\n'

    # We need to turn off settings to debug mode to not break the code
    settings.debug = False



# Generated at 2022-06-21 18:33:15.563222
# Unit test for function eager
def test_eager():
    assert eager(lambda: [1, 2, 3])() == [1, 2, 3]

# Generated at 2022-06-21 18:33:18.081717
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'



# Generated at 2022-06-21 18:33:25.693402
# Unit test for function get_source
def test_get_source():
    def foo():
        """Function to test get_source"""
        x = 1
        y = 2
        return x + y

    assert get_source(foo) == """\
x = 1
y = 2
return x + y"""

# Generated at 2022-06-21 18:33:27.558729
# Unit test for function eager
def test_eager():
    @eager
    def f(l):
        for el in l:
            yield el
    l = [1, 2, 3]
    assert f(l) == l

# Generated at 2022-06-21 18:33:29.132331
# Unit test for function eager
def test_eager():
    @eager
    def foo() -> Iterable[int]:
        for i in range(10):
            yield i

    assert foo() == list(range(10))

# Generated at 2022-06-21 18:33:36.389073
# Unit test for function eager
def test_eager():
    # GIVEN
    test_data = [1, 10, 5, -1, 30, 15]

    # WHEN
    @eager
    def f(data):
        for i in data:
            if (i > 0):
                if (i % 10 == 0):
                    yield i
                else:
                    yield i * 2

    # THEN
    assert f(test_data) == [2, 10, 10, 20, 30, 30]

# Generated at 2022-06-21 18:33:37.227901
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'



# Generated at 2022-06-21 18:33:44.074571
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('test') == '_py_backwards_test_0'
    assert gen.generate('test') == '_py_backwards_test_1'
    assert gen.generate('test') == '_py_backwards_test_2'
    assert gen.generate('test2') == '_py_backwards_test2_3'
    assert gen.generate('test2') == '_py_backwards_test2_4'

# Generated at 2022-06-21 18:33:50.625649
# Unit test for function debug
def test_debug():
    debug_message = 'debug message'

    def get_debug_message() -> str:
        return debug_message

    mock_stderr = StringIO()
    with patch('sys.stderr', mock_stderr):
        settings.debug = True
        debug(get_debug_message)
        assert mock_stderr.getvalue() == messages.debug(debug_message)

    settings.debug = False

# Generated at 2022-06-21 18:33:55.254885
# Unit test for function get_source
def test_get_source():
    def example():
        """Test docstring"""
        a = 1
        b = 2
        c = a + b

    assert get_source(example) == '\n'.join([
        '"""Test docstring"""',
        'a = 1',
        'b = 2',
        'c = a + b',
        '',
    ])

# Generated at 2022-06-21 18:33:58.473559
# Unit test for function eager
def test_eager():
    @eager
    def add(x: int, y: int) -> Iterable[int]:
        yield x
        yield y

    assert add(1, 2) == [1, 2]



# Generated at 2022-06-21 18:34:01.505049
# Unit test for function get_source
def test_get_source():
    def test_function():
        return 'Hello, world!'
    source = get_source(test_function)
    assert(source == 'return \'Hello, world!\'')

# Generated at 2022-06-21 18:34:09.794409
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'



# Generated at 2022-06-21 18:34:12.315296
# Unit test for function get_source
def test_get_source():
    def f(): pass
    source = get_source(f)
    assert '\n' not in source
    assert source.strip() == 'def f(): pass'



# Generated at 2022-06-21 18:34:13.812118
# Unit test for function debug
def test_debug():
    called = False

    @debug
    def get_message():
        nonlocal called
        called = True
        return 'test'

    settings.debug = True
    get_message()
    assert called == True

    settings.debug = False
    get_message()
    assert called == True

# Generated at 2022-06-21 18:34:16.533787
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    b = VariablesGenerator.generate('b')
    c = VariablesGenerator.generate('c')
    assert (a=='_py_backwards_a_0')
    assert (b=='_py_backwards_b_1')
    assert (c=='_py_backwards_c_2')


# Generated at 2022-06-21 18:34:18.307391
# Unit test for function debug
def test_debug():
    assert not sys.stderr.getvalue()
    debug(lambda: 'test')
    assert not sys.stderr.getvalue()

    settings.debug = True
    debug(lambda: 'test')
    assert sys.stderr.getvalue()

    settings.debug = False

# Generated at 2022-06-21 18:34:19.915094
# Unit test for function eager
def test_eager():
    assert eager(lambda: iter([1, 2, 3]))() == [1, 2, 3]



# Generated at 2022-06-21 18:34:21.916646
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit):
        warn("Warn")

# Generated at 2022-06-21 18:34:24.452098
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n' '    pass'



# Generated at 2022-06-21 18:34:28.026959
# Unit test for function get_source
def test_get_source():
    def dummy():
        """
        dummy function
        """
        pass

    assert get_source(dummy) == 'def dummy():\n    """\n    dummy function\n    """\n    pass'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:34:30.157930
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    if getsource(test_function).strip() != get_source(test_function).strip():
        raise Exception('get_source() does not work')

# Generated at 2022-06-21 18:34:46.922959
# Unit test for function debug
def test_debug():
    messages.debug = 'DEBUG: {}'
    settings.debug = True

    messages_list = []

    def get_message():
        msg = "Called 'get_message()'"
        messages_list.append(msg)
        return msg

    debug(get_message)
    assert messages_list == ["Called 'get_message()'"]

    settings.debug = False
    debug(get_message)
    assert messages_list == ["Called 'get_message()'"]

    settings.debug = True
    debug(get_message)
    assert messages_list == ["Called 'get_message()'", "Called 'get_message()'"]
    assert messages_list[-1] == "Called 'get_message()'"

    settings.debug = False
    messages.debug = 'DEBUG: {}'
    messages_

# Generated at 2022-06-21 18:34:51.739278
# Unit test for function debug
def test_debug():
    with tempfile.TemporaryDirectory() as tmpdirname:
        messages.tmpdirname = tmpdirname
        debug(lambda: 'test debug')
        with open(os.path.join(tmpdirname, 'backwards.log')) as f:
            assert f.read() == 'test debug\n', "Function debug"

test_debug()

# Generated at 2022-06-21 18:34:54.283067
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('A') == '_py_backwards_A_0'
    assert VariablesGenerator.generate('B') == '_py_backwards_B_1'



# Generated at 2022-06-21 18:34:59.187438
# Unit test for function eager
def test_eager():
    from itertools import count
    from operator import ge

    def is_prime(n: int) -> bool:
        return n >= 2 and all(ge(n, m) for m in range(2, n))

    @eager
    def primes(n: int) -> Iterable[int]:
        for i in count(2):
            if is_prime(i):
                yield i
            if i > n:
                break

    assert primes(5) == [2, 3, 5]

# Generated at 2022-06-21 18:35:02.902564
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit) as e:
        warn('system exit')
    assert e.type == SystemExit
    assert e.value.code == 1


# Generated at 2022-06-21 18:35:06.324586
# Unit test for function debug
def test_debug():
    debug_msg = 'test'

    def test():
        debug(lambda: debug_msg)
    with settings(debug=True):
        test()
        capture = capture_output()
        assert capture == messages.debug(debug_msg + '\n')

    with settings(debug=False):
        test()
        capture = capture_output()
        assert capture == ''



# Generated at 2022-06-21 18:35:09.897488
# Unit test for function eager
def test_eager():
    def test_fn() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]


# Generated at 2022-06-21 18:35:13.140311
# Unit test for function eager
def test_eager():
    lst = list(range(10))

    @eager
    def generator() -> Iterable[int]:
        for name in lst:
            yield name

    assert lst == generator()
    assert lst == generator()

# Generated at 2022-06-21 18:35:23.529405
# Unit test for function eager
def test_eager():
    from random import choices
    from string import printable
    from itertools import takewhile
    from string import ascii_lowercase
    from string import ascii_uppercase
    from string import digits

    def random_string(length: int) -> str:
        return ''.join(choices(printable, k=length))

    @eager
    def random_strings_of_length(length: int) -> Iterable[str]:
        yield from takewhile(
            lambda s: len(s) == length,
            (random_string(length) for _ in iter(int, 1)),
        )

    assert random_strings_of_length(10) == [random_string(10)]
    assert random_strings_of_length(10) == [random_string(10)]


# Generated at 2022-06-21 18:35:24.607036
# Unit test for function debug
def test_debug():
    debug(lambda: 'testing')



# Generated at 2022-06-21 18:35:51.990614
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch('builtins.print') as mocked_print:
        with patch('backwards.conf.settings.debug') as mocked_debug:
            mocked_debug.__eq__ = lambda a, b: b
            mocked_debug.__ne__ = lambda a, b: not b

            mocked_debug.__bool__ = lambda: False
            debug(lambda: 'message')
            mocked_print.assert_not_called()

            mocked_debug.__bool__ = lambda: True
            debug(lambda: 'message')
            mocked_print.assert_called_once()
            assert mocked_print.call_args[0][0] == 'DEBUG: message'

# Generated at 2022-06-21 18:35:57.632739
# Unit test for function debug
def test_debug():
    debug_message = 'Debug message'
    with patch('sys.stderr') as stderr:
        debug(lambda: debug_message)
        assert stderr.write.call_count == 1
        stderr.write.assert_called_once_with(messages.debug(debug_message) + '\n')



# Generated at 2022-06-21 18:35:58.610650
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello')



# Generated at 2022-06-21 18:35:59.568019
# Unit test for function warn
def test_warn():
    assert warn == messages.warn

# Generated at 2022-06-21 18:36:01.143239
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: x
    settings.debug = False
    debug(lambda: 'A')
    settings.debug = True
    debug(lambda: 'B')


# Generated at 2022-06-21 18:36:06.502795
# Unit test for function eager
def test_eager():
    # Given
    @eager
    def gen(start):
        for i in range(start):
            yield i
    
    # When
    rv = gen(5)

    # Then
    assert type(rv) == list
    assert len(rv) == 5


# Generated at 2022-06-21 18:36:07.938742
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == "def function():"

# Generated at 2022-06-21 18:36:13.375354
# Unit test for function debug
def test_debug():
    debug_message = 'Debug message'

    def get_debug_message():
        return debug_message

    with patch('sys.stderr.write') as write_mock:
        debug(get_debug_message)

        assert write_mock.called
        assert debug_message in write_mock.call_args.args[0]
        assert 'DEBUG' in write_mock.call_args.args[0]



# Generated at 2022-06-21 18:36:15.635186
# Unit test for function debug
def test_debug():
    test_settings = settings
    test_settings.debug = True
    def get_message():
        return "test"
    debug(get_message)


# Generated at 2022-06-21 18:36:18.455894
# Unit test for function eager
def test_eager():
    def do_something(arg1, arg2):
        yield arg1 * arg2
        yield arg1 * (arg2 + 1)
        yield arg1 * (arg2 + 2)

    assert eager(do_something)(2, 3) == [6, 8, 10]

# Generated at 2022-06-21 18:36:47.047615
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('variable') == '_py_backwards_variable_0'
    assert generator.generate('variable') == '_py_backwards_variable_1'
    assert generator.generate('variable') == '_py_backwards_variable_2'

# Generated at 2022-06-21 18:36:49.892613
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    source_lines = getsource(function).split('\n')
    padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
    assert(get_source(function) == '\n'.join(line[padding:] for line in source_lines))

# Generated at 2022-06-21 18:36:55.592791
# Unit test for function get_source
def test_get_source():
    def test_function():
        """
        This is a test function
        """
        x = 3
        y = 4

    # Test the indentation is removed from the result
    assert get_source(test_function) == 'def test_function():\n    """\n    This is a test function\n    """\n    x = 3\n    y = 4\n'

# Generated at 2022-06-21 18:36:58.705795
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'

# Generated at 2022-06-21 18:37:02.495788
# Unit test for function eager
def test_eager():
    @eager
    def test(n):
        while n >= 0:
            yield n
            n -= 1

    assert test(10) == list(range(10, -1, -1))

# Generated at 2022-06-21 18:37:08.545863
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    from py_backwards.conf import settings

    settings.debug = False

    # stderr is hidden by default
    with patch('sys.stderr', new=sys.stdout):
        with patch('sys.stdout') as mock:
            warn('foo')
            mock.write.assert_called_once_with(messages.warn('foo\n'))


# Generated at 2022-06-21 18:37:11.807117
# Unit test for function eager
def test_eager():
    @eager
    def a() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert isinstance(a(), list)
    assert a() == [1, 2, 3]

# Generated at 2022-06-21 18:37:16.359002
# Unit test for function eager
def test_eager():
    def slow_fn() -> Iterable[int]:
        for i in range(4):
            time.sleep(0.1)
            yield i
    assert eager(slow_fn)() == [0, 1, 2, 3]

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-21 18:37:19.894788
# Unit test for function get_source
def test_get_source():
    import pytest

    def test_function_on_multiple_lines():
        def test_fn():
            var = 1 + 2
            return var


# Generated at 2022-06-21 18:37:24.707970
# Unit test for function warn
def test_warn():
    stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        warn("hello world")
        assert sys.stderr.getvalue().strip() == "[py_backwards] WARN - hello world"
    finally:
        sys.stderr = stderr


# Generated at 2022-06-21 18:38:23.656354
# Unit test for function debug
def test_debug():
    import unittest

    class test_debug(unittest.TestCase):
        def setUp(self):
            self.message = 'test '

        def test_log(self):
            with self.assertLogs() as log:
                debug(lambda: self.message)
            self.assertEqual(log.output, ['DEBUG:py_backwards:test '])

    unittest.main()



# Generated at 2022-06-21 18:38:25.904401
# Unit test for function get_source
def test_get_source():
    def foo():
        """Docstring"""
        pass


# Generated at 2022-06-21 18:38:33.965763
# Unit test for function eager
def test_eager():
    from ..backwards import backwards
    from .test_collector import Collector

    def test_function(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    @backwards
    def test(n: int) -> List[int]:
        return list(test_function(n))

    collector = Collector()
    with collector.collect():
        test(10)

    function_call = collector.data['test_function'][0]
    assert function_call.arguments == (10, )
    assert function_call.result == list(range(10))

# Generated at 2022-06-21 18:38:36.103163
# Unit test for function eager
def test_eager():
    def gen():
        yield 1
        yield 2
        yield 3

    assert eager(gen)() == [1, 2, 3]

# Generated at 2022-06-21 18:38:42.352591
# Unit test for function get_source
def test_get_source():
    """Unit test for function get_source."""
    def test_function(a: float, b: float) -> float:
        """Simple test function."""
        return a + b

    assert get_source(test_function) == ['def test_function(a: float, b: float) -> float:',
                                         '    """Simple test function."""',
                                         '    return a + b']

# Generated at 2022-06-21 18:38:44.260437
# Unit test for function debug
def test_debug():
    debug(lambda: "Random number: " + str(random.randint(1, 10)))


# Generated at 2022-06-21 18:38:53.996292
# Unit test for function debug
def test_debug():
    import re
    from subprocess import Popen, PIPE, STDOUT

    from .settings import Settings

    def run():
        # We have to use a separate process because in case of debugging
        # current process dies.
        return Popen(sys.argv, stdout=PIPE, stderr=STDOUT).communicate()[0].decode()

    def test_debugging(settings: Settings, expected: bool) -> None:
        settings.debug = False
        out = run()
        assert not re.search(r'\x1b\[1;30mDEBUG:', out)

        settings.debug = True
        out = run()
        assert re.search(r'\x1b\[1;30mDEBUG:', out) == expected

    test_debugging(settings, expected=True)
    test_debug

# Generated at 2022-06-21 18:38:56.736699
# Unit test for function get_source
def test_get_source():
    def f(x):
        return x

    assert get_source(f) == 'return x'

# Generated at 2022-06-21 18:38:59.298577
# Unit test for function get_source
def test_get_source():
    test_function = '''def test_function():
    x = 2 + 3
    y = 2 * 3'''

    get_source_test_function = '''def get_source_test_function():
    x = 2 + 3
    y = 2 * 3'''

    assert get_source(test_function) == get_source_test_function

# Generated at 2022-06-21 18:39:00.811291
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'

