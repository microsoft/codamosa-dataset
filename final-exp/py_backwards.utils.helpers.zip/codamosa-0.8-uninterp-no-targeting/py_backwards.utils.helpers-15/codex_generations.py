

# Generated at 2022-06-21 18:31:00.877103
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-21 18:31:03.850586
# Unit test for function warn
def test_warn():
    class Out:
        MSG = None

        def write(self, msg):
            self.MSG = msg

    warn("Hello World")
    assert sys.stderr.getvalue() == "### py_backwards warning: Hello World\n"


# Generated at 2022-06-21 18:31:09.997959
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == list(range(10))
    assert eager(range)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert eager(range)(1, 11) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert eager(range)(1, 11, 2) == [1, 3, 5, 7, 9]
    return True

# Generated at 2022-06-21 18:31:15.128615
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Hello'

    class PseudoStderr:
        def write(self, message):
            assert message == '\x1b[4m\x1b[93mHello\x1b[0m\n'

    with patch.object(sys, 'stderr', PseudoStderr()):
        with patch.object(settings, 'debug', True):
            debug(get_message)
        with patch.object(settings, 'debug', False):
            debug(get_message)

# Generated at 2022-06-21 18:31:16.225027
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo') # silence linter

# Generated at 2022-06-21 18:31:25.945672
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest
    from .variablesgenerator import VariablesGenerator

    prefix = '_py_backwards_'
    cases = [('a' + str(case), case) for case in range(5)]

    for case, num in cases:
        var = VariablesGenerator.generate(case)

        assert var.startswith(prefix)
        assert var.endswith(case + '_' + str(num))
        assert var[len(prefix):].count('_') == 2

        if num != 4:
            assert var != VariablesGenerator.generate(case)
        else:
            assert var == VariablesGenerator.generate(case)

# Generated at 2022-06-21 18:31:29.360592
# Unit test for function warn
def test_warn():
    f = open('/dev/null', 'w')
    sys.stderr = f
    warn('Testing warning message')
    sys.stderr = sys.__stderr__
    f.close()

# Generated at 2022-06-21 18:31:30.721760
# Unit test for function debug
def test_debug():
    debug_message = "Test debug message"
    debug(lambda: debug_message)

# Generated at 2022-06-21 18:31:36.809139
# Unit test for function warn
def test_warn():
    from pytest import raises
    from . import pipes
    from . import output

    with raises(SystemExit) as excinfo:
        warn('Hello world')

    assert excinfo.value.code == 1
    assert pipes.read_output() == output.display(
        '\n'.join([
            'py: warn:',
            'py: warn: Hello world',
            'py: warn:',
            ''
        ])
    )



# Generated at 2022-06-21 18:31:44.432903
# Unit test for function debug
def test_debug():
    import warnings

    def warn_called(_message: str, category: Any, stacklevel: int) -> None:
        assert category == UserWarning
        assert stacklevel == 2
        assert _message == messages.debug(get_message())

    with warnings.catch_warnings(record=True) as warning_list:
        warnings.simplefilter('always')
        settings.debug = False
        debug(lambda: 'test')

        assert len(warning_list) == 0

        settings.debug = True
        debug(lambda: 'test')

        assert len(warning_list) == 1
        warn_called(*warning_list[0].args)

# Generated at 2022-06-21 18:31:49.122928
# Unit test for function eager
def test_eager():
    seq = [1, 2, 3]
    # Create function to be tested
    @eager
    def genfunc(seq):
        for i in seq:
            yield i
    # Call function and assert that the generator was converted to a list
    assert isinstance(genfunc(seq), list)

# Generated at 2022-06-21 18:31:51.609515
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == inspect.getsource(func)

# Generated at 2022-06-21 18:31:54.410397
# Unit test for function eager
def test_eager():
    def fn():
        yield 2
        yield 2
        yield 2
    assert eager(fn)() == [2,2,2]

# Generated at 2022-06-21 18:32:05.501273
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg1 = VariablesGenerator()
    assert vg1.generate("aa") == "_py_backwards_aa_0"
    assert vg1.generate("bb") == "_py_backwards_bb_1"
    assert vg1.generate("aa") == "_py_backwards_aa_2"

    vg2 = VariablesGenerator()
    assert vg2.generate("aa") == "_py_backwards_aa_0"
    assert vg2.generate("bb") == "_py_backwards_bb_1"
    assert vg2.generate("aa") == "_py_backwards_aa_2"

    assert vg1.generate("aa") == "_py_backwards_aa_3"

# Generated at 2022-06-21 18:32:07.523319
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for i in range(3):
            yield i

    assert gen() == [0, 1, 2]

# Generated at 2022-06-21 18:32:12.427447
# Unit test for function warn
def test_warn():
    import re
    import sys
    import io

    # Capture stdout
    test_io = io.StringIO()
    sys.stdout = test_io

    warn('test warn message')
    assert re.search(r'warn : test warn message', test_io.getvalue()) is not None

    # Restore stdout
    sys.stdout = sys.__stdout__

# Generated at 2022-06-21 18:32:15.127638
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    name = VariablesGenerator.generate('name')
    name2 = VariablesGenerator.generate('name')
    assert name != name2


# Generated at 2022-06-21 18:32:20.589750
# Unit test for function debug
def test_debug():
    # you can't mock the print function.
    old_print = print

    lines: List[str] = []

    def catcher(*args, **kwargs):
        # take the first argument and push it to our lines array
        lines.append(args[0])

    print = catcher

    debug(lambda: "hello")
    assert len(lines) == 0

    settings.debug = True
    debug(lambda: "hello")
    assert len(lines) == 1
    assert lines[0] == messages.debug("hello")

    settings.debug = False
    print = old_print



# Generated at 2022-06-21 18:32:22.994924
# Unit test for function eager
def test_eager():
    assert eager(lambda x: range(x))(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-21 18:32:24.849588
# Unit test for function warn
def test_warn():
    assert warn("test") == None


# Generated at 2022-06-21 18:32:27.811672
# Unit test for function warn
def test_warn():
    warn('test')
    assert True



# Generated at 2022-06-21 18:32:37.904250
# Unit test for function eager
def test_eager():
    import random
    import unittest
    from ..testing import UnitTest

    class Test(UnitTest):
        def test_eager(self):
            @eager
            def gen_range(start: int = 0, step: int = 1) -> Iterable[int]:
                assert (step != 0)
                while True:
                    yield start
                    start += step

            length = random.randint(5, 10)

            rng = gen_range()
            self.assertEqual(len(rng), length)

            rng = gen_range(step=2)
            self.assertEqual(len(rng), length)

            rng = gen_range(start=-1)
            self.assertEqual(len(rng), length)

    Test.run_tests()

# Generated at 2022-06-21 18:32:42.475787
# Unit test for function eager
def test_eager():
    from ..api import setup

    @eager
    def func(a: int) -> Iterable[int]:
        for i in range(a):
            yield i

    @setup
    def setup_fn():
        return func(3)

    assert setup_fn() == [0, 1, 2]

# Generated at 2022-06-21 18:32:45.148019
# Unit test for function get_source
def test_get_source():
    def fn():
        def nested_function():
            pass
        return nested_function

    assert (
        get_source(fn()) == 'def nested_function():\n'
        '    pass\n'
        'return nested_function\n'
    )


# Generated at 2022-06-21 18:32:48.563272
# Unit test for function get_source
def test_get_source():
    def test_function(any):pass
    source = get_source(test_function)
    assert source == 'def test_function(any):pass'

# Generated at 2022-06-21 18:32:58.352156
# Unit test for function eager
def test_eager():
    from .. import backwards
    from .gen import gen_test_data
    from .py import py_backwards
    from .func import make_func_source
    from .containers import make_container_source
    from .gen import make_gen_source
    from .decorator import make_decorated_source
    from .ifaces import make_ifaces_source

    # Get spec.
    spec = backwards.spec(eager)
    # Get source.
    source = make_func_source(spec, intro='from py_backwards import eager')
    # Compile.
    code = compile(source, '<string>', 'exec')
    # Initialize namespace.

# Generated at 2022-06-21 18:33:01.458932
# Unit test for function eager
def test_eager():
    def test() -> List[int]:
        for i in range(10):
            yield i
    assert eager(test)() == list(range(10))

# Generated at 2022-06-21 18:33:08.716314
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('f') == '_py_backwards_f_0'
    assert VariablesGenerator.generate('f') == '_py_backwards_f_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'
    assert VariablesGenerator.generate('f') == '_py_backwards_f_3'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_4'

# Generated at 2022-06-21 18:33:11.256635
# Unit test for function get_source
def test_get_source():
    def func():
        def inner_func():
            pass
        pass
    assert get_source(func) == 'def inner_func():\n    pass\npass'



# Generated at 2022-06-21 18:33:16.489165
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    settings.debug = True
    with patch('sys.stderr.write') as mock_write:
        debug(lambda: 'Hello')
        assert mock_write.called
        mock_write.assert_called_once()
        mock_write.assert_called_with(messages.debug('Hello') + '\n')

    settings.debug = False
    with patch('sys.stderr.write') as mock_write:
        debug(lambda: 'Hello')
        assert not mock_write.called

# Generated at 2022-06-21 18:33:28.093962
# Unit test for function warn
def test_warn():
    from . import messages
    import sys
    from io import StringIO

    class FakeStdErr:
        def __init__(self):
            self.content = []

        def write(self, s):
            self.content.append(s)

        def __str__(self):
            return ''.join(self.content)

    stderr = sys.stderr
    sys.stderr = fake_stderr = FakeStdErr()
    try:
        warn('anything')
    finally:
        sys.stderr = stderr
    assert str(fake_stderr) ==  messages.warn('anything') + '\n'


# Generated at 2022-06-21 18:33:31.503964
# Unit test for function warn
def test_warn():
    mock_stderr = StringIO()
    sys.stderr = mock_stderr
    warn("a")
    sys.stderr = sys.__stderr__
    assert 'a' in mock_stderr.getvalue()

# Generated at 2022-06-21 18:33:37.176023
# Unit test for function debug
def test_debug():
    is_called = False

    def get_message():
        nonlocal is_called
        is_called = True
        return "debug message"

    debug(get_message)
    assert not is_called

    settings.debug = True
    debug(get_message)
    assert is_called

test_debug()

# Generated at 2022-06-21 18:33:38.973657
# Unit test for function eager
def test_eager():
    @eager
    def func():
        yield 1
        yield 2

    assert func() == [1, 2]

# Generated at 2022-06-21 18:33:44.255575
# Unit test for function eager
def test_eager():
    a = [1, 2, 3, 4, 5]
    b = [6, 7, 8, 9, 10]

    def test_function():
        for i in a:
            yield i
        for i in b:
            yield i

    assert eager(test_function)() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-21 18:33:47.889081
# Unit test for function warn
def test_warn():
    try:
        # disabling stdout for testing only
        sys.stdout = open('/dev/null', 'w')
        warn('test message')
        assert True
    except:
        assert False

# Generated at 2022-06-21 18:33:58.088337
# Unit test for function eager
def test_eager():
    from collections import Iterator
    from ..conf import settings
    from contextlib import contextmanager

    @contextmanager
    def no_warnings():
        with settings(warn=False):
            yield

    def test_gen(x: int) -> Iterator[int]:
        yield x

    def test_list(x: int) -> List[int]:
        return [x]

    def test_tuple(x: int) -> Tuple[int]:
        return (x,)

    def test_set(x: int) -> Set[int]:
        return {x}

    def test_dict(x: int) -> Dict[int, int]:
        return {x: x}

    @eager
    def test_gen_wrapped(x: int) -> Iterator[int]:
        yield x


# Generated at 2022-06-21 18:34:00.573554
# Unit test for function get_source
def test_get_source():
    def inner():
        def __():
            '''Docstring.'''
            pass


# Generated at 2022-06-21 18:34:03.422501
# Unit test for function get_source
def test_get_source():
    def fn():
        """Test."""
        pass
    assert get_source(fn) == 'def fn():\n    """Test."""\n    pass'

# Generated at 2022-06-21 18:34:09.891262
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vs_gen = VariablesGenerator()
    assert vs_gen.generate('name') == '_py_backwards_name_0'
    assert vs_gen.generate('name') == '_py_backwards_name_1'
    assert vs_gen.generate('name') == '_py_backwards_name_2'

# Generated at 2022-06-21 18:34:15.497227
# Unit test for function eager
def test_eager():
    def gen() -> Iterable[int]:
        for i in range(10):
            yield i

    assert eager(gen)() == list(range(10))

# Generated at 2022-06-21 18:34:21.353504
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_3'


# Generated at 2022-06-21 18:34:23.740126
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first = VariablesGenerator.generate('x')
    second = VariablesGenerator.generate('x')
    assert first != second


# Generated at 2022-06-21 18:34:27.903916
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest.mock import patch

    msg = 'test warning'

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        warn(msg)
    assert 'test warning' in fake_stderr.getvalue()


# Generated at 2022-06-21 18:34:30.652610
# Unit test for function debug
def test_debug():
    settings.debug = True
    # Same as settings.debug = True
    debug(lambda: 'Test debug')
    settings.debug = False
    settings.debug = False
    debug(lambda: 'Test debug')

test_debug()

# Generated at 2022-06-21 18:34:33.550978
# Unit test for function warn
def test_warn():
    def assert_equal(actual, expected):
        if actual != expected:
            raise AssertionError("{} != {}".format(actual, expected))

    assert_equal(settings.debug, False)
    assert_equal(settings.warnings, True)


# Generated at 2022-06-21 18:34:36.309147
# Unit test for function eager
def test_eager():
    class GeneratorMock:
        def __iter__(self):
            i = 0
            while i < 5:
                yield i
                i += 1

    def function_returning_generator():
        return GeneratorMock()

    assert eager(function_returning_generator)(1, 2, 3) == [0, 1, 2, 3, 4]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-21 18:34:41.956551
# Unit test for function debug
def test_debug():
    import sys
    import io

    temp_stream = io.StringIO()
    sys.stderr = temp_stream

    class FakeSettings:
        debug = True

    debug(lambda: "foobar")

    assert temp_stream.getvalue().startswith("\x1b[1;30mDEBUG:")

    temp_stream.close()

# Generated at 2022-06-21 18:34:48.500730
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate('number'))

    # Test for name collision
    class A:
        a = VariablesGenerator.generate('number')

    class B:
        b = VariablesGenerator.generate('number')

    assert id(A.a) != id(B.b)

    return 'ok'


# Generated at 2022-06-21 18:34:49.539384
# Unit test for function warn
def test_warn():
    warn('WARNING')



# Generated at 2022-06-21 18:35:03.485538
# Unit test for function warn
def test_warn():
    messages.set_colors(False)
    warn('Dummy')
    # TODO: check if the string is red
    # TODO: check against the message content

# Generated at 2022-06-21 18:35:04.770941
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
    assert foo() == [1, 2]

# Generated at 2022-06-21 18:35:09.101790
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'

# Generated at 2022-06-21 18:35:13.190596
# Unit test for function warn
def test_warn():
    _warn, sys.stderr = sys.stderr, StringIO()
    warn('test')
    assert sys.stderr.getvalue() == messages.warn('test') + '\n'
    sys.stderr = _warn


# Generated at 2022-06-21 18:35:16.383373
# Unit test for function eager
def test_eager():
    @eager
    def result(x):
        yield x
        yield x + 1
        yield x + 2

    result(1) == [1, 2, 3]

test_eager()

# Generated at 2022-06-21 18:35:18.586088
# Unit test for function get_source
def test_get_source():
    def foo(a, b, c):
        print(a + b + c)

    assert get_source(foo) == 'print(a + b + c)'


test_get_source()

# Generated at 2022-06-21 18:35:21.917338
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    var1 = vg.generate('a')
    var2 = vg.generate('a')
    assert var1 != var2

# Generated at 2022-06-21 18:35:26.064736
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'



# Generated at 2022-06-21 18:35:29.248724
# Unit test for function eager
def test_eager():
    assert eager(range(10))(0, 4) == [0, 1, 2, 3]

# Generated at 2022-06-21 18:35:32.983790
# Unit test for function get_source
def test_get_source():
    def foo():
        return 42

    def bar(x):
        return x

    assert get_source(foo) == 'return 42'
    assert get_source(bar) == 'return x'
    assert 'foo = bar' not in get_source(bar)

# Generated at 2022-06-21 18:36:00.576109
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate('v1')
    v2 = VariablesGenerator.generate('v2')
    v3 = VariablesGenerator.generate('v3')
    assert v1 != v2 and v2 != v3 and v1 != v3
    assert v1.startswith('_py_') and v2.startswith('_py_') and v3.startswith('_py_')

# Generated at 2022-06-21 18:36:04.155490
# Unit test for function warn
def test_warn():
    # get
    message = 'hi'
    assert messages.warn(message) == "\033[93mhi\033[0m"

    # not get
    message = ''
    assert messages.warn(message) == ''



# Generated at 2022-06-21 18:36:11.599396
# Unit test for function eager
def test_eager():
    def lst(N: int = 100) -> Iterable[int]:
        for i in range(N):
            yield i

    if __debug__:
        assert lst is not eager(lst)  # type: ignore

    lst2 = eager(lst)
    assert lst2(5) == [0, 1, 2, 3, 4]
    assert lst2.__name__ == 'lst'
    assert lst2.__doc__ == lst.__doc__



# Generated at 2022-06-21 18:36:12.102266
# Unit test for function warn
def test_warn():
    assert True

# Generated at 2022-06-21 18:36:15.217829
# Unit test for function debug
def test_debug():
    debug_data = []

    def get_data():
        debug_data.append(2)
        return 'test_debug'

    settings.debug = True
    debug(get_data)

    assert debug_data == [2]



# Generated at 2022-06-21 18:36:17.801412
# Unit test for function get_source
def test_get_source():
    def foo():
        """Docstring

        a = 3

        b = 4
        """
        pass

    assert get_source(foo) == '"""Docstring\n\n    a = 3\n\n    b = 4\n    """'

# Generated at 2022-06-21 18:36:20.705232
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """Tests the VariablesGenerator."""
    instance = VariablesGenerator()
    assert instance.generate('a') == '_py_backwards_a_0'
    assert instance.generate('a') == '_py_backwards_a_1'
    assert instance.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-21 18:36:23.163919
# Unit test for function eager
def test_eager():
    test_list = [1, 2, 3, 4, 5]
    expected_output = [1, 2, 3, 4, 5]

    @eager
    def return_list_generator():
        for i in test_list:
            yield i

    output = return_list_generator()

    assert output == expected_output, (output, expected_output)


# Generated at 2022-06-21 18:36:26.505692
# Unit test for function get_source
def test_get_source():
    def f():
        """Just a function."""
        while True:
            pass

    assert get_source(f) == 'while True:\n    pass'



# Generated at 2022-06-21 18:36:29.502622
# Unit test for function eager
def test_eager():
    def dummy_function(n):
        for i in range(n):
            yield i

    assert eager(dummy_function)(10) == list(range(10))

# Generated at 2022-06-21 18:37:32.334932
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from unittest import TestCase

    test_cases = [
        (
            {'arg': 'BEST'},
            ['_py_backwards_BEST_0', '_py_backwards_BEST_1', '_py_backwards_BEST_2']
        ),
    ]

    class Tester(TestCase):
        def test_VariablesGenerator(self):
            for case, expected in test_cases:
                actual = []
                while len(actual) < len(expected):
                    actual.append(VariablesGenerator.generate(**case))
                self.assertEqual(actual, expected)

    Tester().test_VariablesGenerator()

# Generated at 2022-06-21 18:37:34.518013
# Unit test for function eager
def test_eager():
    def some_func():
        i = 0
        while i < 100:
            yield i
            i += 1

    assert eager(some_func)() == list(some_func())

# Generated at 2022-06-21 18:37:36.782833
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new_callable=io.StringIO) as stderr:
        warn('WARNING')
        assert stderr.getvalue() == 'WARNING\n'



# Generated at 2022-06-21 18:37:39.944331
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]



# Generated at 2022-06-21 18:37:44.457621
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == "_py_backwards_a_0"
    assert VariablesGenerator.generate("a") == "_py_backwards_a_1"
    assert VariablesGenerator.generate("a") == "_py_backwards_a_2"

# Generated at 2022-06-21 18:37:55.917236
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert  gen.generate('x') == '_py_backwards_x_0'
    assert  gen.generate('y') == '_py_backwards_y_1'
    assert  gen.generate('x') == '_py_backwards_x_2'
    assert  gen.generate('x') == '_py_backwards_x_3'
    assert  gen.generate('y') == '_py_backwards_y_4'
    assert  gen.generate('z') == '_py_backwards_z_5'
    assert  gen.generate('x') == '_py_backwards_x_6'
    assert  gen.generate('y') == '_py_backwards_y_7'

# Generated at 2022-06-21 18:37:57.509205
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]


# Generated at 2022-06-21 18:38:01.160153
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    import sys
    message = 'hello'
    with patch.object(sys, 'stderr') as mocked:
        with patch.object(messages, 'warn') as mocked_warn:
            mocked_warn.return_value = message
            warn(message)
            mocked_warn.assert_called_once_with(message)
            mocked.write.assert_called_once_with(message)



# Generated at 2022-06-21 18:38:04.516148
# Unit test for function eager
def test_eager():
    @eager
    def get_iterable():
        for i in range(5):
            yield [i]
    assert get_iterable() == ([[i] for i in range(5)],)

# Generated at 2022-06-21 18:38:08.158366
# Unit test for function eager
def test_eager():
    def gen() -> Iterable[int]:
        for i in range(10):
            yield i

    assert eager(gen)() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:40:09.659780
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("value2") == '_py_backwards_value2_0'
    assert VariablesGenerator.generate("value3") == '_py_backwards_value3_1'
    assert VariablesGenerator.generate("value3") == '_py_backwards_value3_2'

# Generated at 2022-06-21 18:40:10.945199
# Unit test for function get_source
def test_get_source():
    def add(a, b):
        return a + b

    assert get_source(add) == 'return a + b'

# Generated at 2022-06-21 18:40:20.516652
# Unit test for function debug
def test_debug():
    messages.reset_log()
    count = [0]
    def get_message():
        count[0] += 1
        return f'count={count[0]}'

    debug(get_message)
    messages.reset_log()
    settings.debug = True
    assert messages.get_log() == []

    debug(get_message)
    assert messages.get_log() == [messages.debug(get_message())]
    assert count[0] == 2

    settings.debug = False
    messages.reset_log()
    debug(get_message)
    assert count[0] == 3
    assert messages.get_log() == []

    settings.debug = True
    messages.reset_log()
    count[0] = 0

# Generated at 2022-06-21 18:40:24.993554
# Unit test for function warn
def test_warn():
    from .test import Patch
    with Patch('sys.stderr.write') as write:
        warn('Message to warn about')
        assert write.call_args.args[0] == '\x1b[33mWarning! Message to warn about\x1b[0m\n'

# Generated at 2022-06-21 18:40:26.956463
# Unit test for function eager
def test_eager():
    @eager
    def produce_numbers():
        yield 1
        yield 2
        yield 3
    assert produce_numbers() == [1, 2, 3]



# Generated at 2022-06-21 18:40:28.042919
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    print(get_source(func))

# Generated at 2022-06-21 18:40:38.024804
# Unit test for function debug
def test_debug():
    assertion = []

    def get_message():
        return 'This is debug message'

    class CustomStdOut(object):
        def __init__(self):
            pass

        def write(self, message):
            assertion.append(message)
            pass

        def flush(self):
            pass

    captured_std_out = sys.stderr
    sys.stderr = CustomStdOut()
    settings.debug = False
    debug(get_message)
    assert not assertion
    settings.debug = True
    debug(get_message)
    assert assertion[0] == '\x1b[90m' + get_message() + '\x1b[0m\n'
    sys.stderr = captured_std_out

# Generated at 2022-06-21 18:40:38.859725
# Unit test for function debug
def test_debug():
    debug(lambda: 'Debug message')

# Generated at 2022-06-21 18:40:41.845489
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'



# Generated at 2022-06-21 18:40:48.700916
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_0'
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_1'
    assert VariablesGenerator.generate('def') == '_py_backwards_def_2'
    assert VariablesGenerator.generate('def') == '_py_backwards_def_3'
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_4'
