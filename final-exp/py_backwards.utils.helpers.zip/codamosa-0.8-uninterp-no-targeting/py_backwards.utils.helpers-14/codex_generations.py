

# Generated at 2022-06-21 18:30:40.803401
# Unit test for function debug
def test_debug():
    def get_message():
        return 'some message'

    settings.debug = False
    with settings.resetting():
        debug(get_message)

    settings.debug = True
    debug(get_message)

# Generated at 2022-06-21 18:30:48.457799
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


    settings.debug = False
    with captured_output() as (out, err):
        warn('\x1b[33mWarning: message\x1b[0m')
    assert err.getvalue().strip() == 'Warning: message'

    settings.debug = True

# Generated at 2022-06-21 18:30:49.928981
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'

# Generated at 2022-06-21 18:30:53.763555
# Unit test for function eager
def test_eager():
    def f(n):
        for i in range(n):
            yield i

    assert eager(f)(3) == [0, 1, 2]

# Generated at 2022-06-21 18:30:59.612084
# Unit test for function debug
def test_debug():
    import io
    import sys
    buf = io.StringIO()
    sys.stderr = buf
    settings.debug = True
    debug(lambda: 'Jablko')
    assert buf.getvalue() == 'Backwards python: DEBUG: Jablko\n'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:31:04.017371
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('a') == '_py_backwards_a_0'
    assert gen.generate('a') == '_py_backwards_a_1'
    assert gen.generate('b') == '_py_backwards_b_2'
    assert gen.generate('a') == '_py_backwards_a_3'

# Generated at 2022-06-21 18:31:06.878576
# Unit test for function eager
def test_eager():
    def function(x):
        for i in range(5):
            yield i
    assert eager(function)(0) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:31:11.138238
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    _class = VariablesGenerator()
    assert _class.generate('var') == '_py_backwards_var_0'
    assert _class.generate('var2') == '_py_backwards_var2_1'
    assert '_py_backwards' in VariablesGenerator._counter



# Generated at 2022-06-21 18:31:14.712741
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
  assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
  assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
  assert VariablesGenerator.generate('x') == '_py_backwards_x_2'


# Unit tests for function get_source

# Generated at 2022-06-21 18:31:15.403529
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-21 18:31:21.342254
# Unit test for function eager
def test_eager():
    a = 0
    @eager
    def test():
        nonlocal a
        while a < 4:
            yield a
            a += 1
    assert test() == [0, 1, 2, 3]


# Generated at 2022-06-21 18:31:26.036512
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'


# Generated at 2022-06-21 18:31:29.949389
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('variable') for _ in range(10)]
    assert len(set(variables)) == len(variables)
    assert len(set(['_py_backwards_variable'])) == 1

# Generated at 2022-06-21 18:31:36.454462
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("my_var") == "_py_backwards_my_var_0"
    assert VariablesGenerator.generate("my_var") == "_py_backwards_my_var_1"
    assert VariablesGenerator.generate("my_var") == "_py_backwards_my_var_2"
    assert VariablesGenerator.generate("my_var") == "_py_backwards_my_var_3"

# Generated at 2022-06-21 18:31:38.685934
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        return a + b

    assert get_source(func) == '    return a + b'



# Generated at 2022-06-21 18:31:43.101816
# Unit test for function warn
def test_warn():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    msg = 'test message'
    warn(msg)
    assert sys.stderr.getvalue() == '{} {}\n'.format(messages.WARN, msg)

# Generated at 2022-06-21 18:31:48.595086
# Unit test for function get_source
def test_get_source():
    source = get_source(get_source)
    expected = """    source_lines = getsource(fn).split('\\n')
    padding = len(re.findall(r'^(\\s*)', source_lines[0])[0])
    return '\\n'.join(line[padding:] for line in source_lines)"""
    assert source == expected



# Generated at 2022-06-21 18:31:53.065854
# Unit test for function warn
def test_warn():
    import io
    sys.stderr = io.StringIO()
    warn('test warn')
    assert 'warning' in sys.stderr.getvalue()
    assert 'test warn' in sys.stderr.getvalue()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:31:57.094694
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Checking if generated variable is unique
    assert (VariablesGenerator.generate('_py_backwards_') != \
        VariablesGenerator.generate('_py_backwards_'))

# Generated at 2022-06-21 18:31:59.313215
# Unit test for function get_source
def test_get_source():
    def fn1(x):
        return x + x

    assert get_source(fn1) == 'return x + x'

# Generated at 2022-06-21 18:32:03.912069
# Unit test for function eager
def test_eager():
    @eager
    def second_third(n):
        yield n + 1
        yield n + 2

    assert second_third(1) == [2, 3]

# Generated at 2022-06-21 18:32:06.297740
# Unit test for function get_source
def test_get_source():
    def function():
        def nested():
            pass
    assert get_source(function) == dedent("""
    def nested():
        pass
    """)[1:]



# Generated at 2022-06-21 18:32:09.227681
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('_a') == '_py_backwards__a_0'
    assert VariablesGenerator.generate('_a') == '_py_backwards__a_1'

# Generated at 2022-06-21 18:32:10.974351
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
    assert eager(f)() == [1, 2]

# Generated at 2022-06-21 18:32:12.295187
# Unit test for function warn
def test_warn():
    warn('This is a warning')('Error', 'about variable')

# Generated at 2022-06-21 18:32:20.371699
# Unit test for function warn
def test_warn():
    import io
    import sys
    import unittest
    from ..conf import settings
    from .. import messages

    # Save stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    class Test(unittest.TestCase):
        def test(self) -> None:
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()
            settings.color = False
            messages.warn = lambda message: 'warn: ' + message
            warn('test')
            self.assertEqual(sys.stderr.getvalue(), 'warn: test\n')

    Test().test()

    # Restore stdout and stderr
    sys.stdout = old_stdout
    sys.stderr = old_stderr

# Generated at 2022-06-21 18:32:27.593301
# Unit test for function debug
def test_debug():
    warns = []
    with settings(debug=True):
        debug_ = debug
    with settings(debug=False):
        def debug(get_message):
            warns.append(get_message())
            return debug_
        debug('hello world')
        assert len(warns) == 1
        assert warns[0] == 'hello world'
        debug('hi')
        assert len(warns) == 2
        assert warns[1] == 'hi'

# Generated at 2022-06-21 18:32:33.510952
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate("x") == '_py_backwards_x_0'
    assert generator.generate("y") == '_py_backwards_y_1'
    assert generator.generate("z") == '_py_backwards_z_2'
    assert generator.generate("y") == '_py_backwards_y_3'

test_VariablesGenerator()

# Generated at 2022-06-21 18:32:42.307607
# Unit test for function eager
def test_eager():
    from random import randint

    assert [1, 2, 3] == eager(lambda: (i for i in range(4)))()
    assert [] == eager(lambda: (i for i in []))()

    assert eager(lambda: randint(0, 1))() == list(range(1))
    assert eager(lambda: randint(0, 10))() == list(range(11))

    def randint_generator(max_value: int) -> Iterable[int]:
        while True:
            yield randint(0, max_value)

    assert eager(lambda: randint_generator(10))() == list(range(11))

# Generated at 2022-06-21 18:32:44.285952
# Unit test for function warn
def test_warn():
    class MockFile:
        def write(self, x):
            pass

    sys.stderr = MockFile()
    warn("warn")



# Generated at 2022-06-21 18:32:49.460777
# Unit test for function get_source
def test_get_source():
    def test_fn():
        pass
    assert get_source(test_fn) == 'def test_fn():\n    pass'



# Generated at 2022-06-21 18:32:57.516467
# Unit test for function debug
def test_debug():
    import io
    stream = io.StringIO()
    sys.stderr = stream
    try:
        debug(lambda: 'foo')
        debug(lambda: 'bar')
        assert stream.getvalue() == ''
    finally:
        sys.stderr = sys.__stderr__
    settings.debug = True
    try:
        debug(lambda: 'foo')
        debug(lambda: 'bar')
        assert stream.getvalue() == 'foo\nbar\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False


# Generated at 2022-06-21 18:32:58.961677
# Unit test for function get_source
def test_get_source():
    func = lambda x: x ** 2
    result = get_sourc

# Generated at 2022-06-21 18:33:02.660186
# Unit test for function eager
def test_eager():
    def sum_list(max_value):
        for x in range(max_value):
            yield x
    assert eager(sum_list)(4) == [0, 1, 2, 3]


# Generated at 2022-06-21 18:33:06.581249
# Unit test for function get_source
def test_get_source():
    """
    Some function providing this docstring.
    """
    return 'test'

assert get_source(test_get_source).strip() == '"""\nSome function providing this docstring.\n"""\nreturn \'test\''

# Generated at 2022-06-21 18:33:07.927790
# Unit test for function warn
def test_warn():
    mess = "Hello World"
    messages.warn(mess)
    assert True

# Generated at 2022-06-21 18:33:11.211633
# Unit test for function eager
def test_eager():
    @eager
    def gen_list(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen_list(10) == list(range(10))



# Generated at 2022-06-21 18:33:15.770831
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_3'



# Generated at 2022-06-21 18:33:27.802747
# Unit test for function warn
def test_warn():
    import pytest
    from ..conf import settings
    from .. import messages
    import sys

    settings.debug = True
    monkeypatch = pytest.importorskip('pytest_mock')

    with monkeypatch.context() as m:
        m.setattr(sys, "stderr", m.MagicMock())
        warn('test')
        sys.stderr.write.assert_called_once()
        assert sys.stderr.write.call_args[0][0] == messages.warn('test') + '\n'

        sys.stderr.write.reset_mock()
        warn('test')
        sys.stderr.write.assert_called_once()
        assert sys.stderr.write.call_args[0][0] == messages.warn('test') + '\n'

# Generated at 2022-06-21 18:33:28.754755
# Unit test for function warn
def test_warn():
    assert warn('') is None

# Generated at 2022-06-21 18:33:36.341248
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator
    assert vg.generate('variable') == '_py_backwards_variable_0'
    assert vg.generate('variable') == '_py_backwards_variable_1'
    assert vg.generate('variable') == '_py_backwards_variable_2'

# Generated at 2022-06-21 18:33:38.724629
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug')
    settings.debug = False
    debug(lambda: 'debug')

# Generated at 2022-06-21 18:33:39.676697
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-21 18:33:47.074828
# Unit test for function debug
def test_debug():
    from ..conf import settings as reset_settings
    from .. import messages as reset_messages
    try:
        settings.debug = True
        messages.debug = 'D'
        debug(lambda: '1')
        assert False
    except AssertionError:
        pass
    settings.debug = False
    debug(lambda: '2')
    assert False

# Generated at 2022-06-21 18:33:49.400637
# Unit test for function warn
def test_warn():
    warn('hello world')

if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-21 18:33:52.553618
# Unit test for function eager
def test_eager():
    @eager
    def get_list() -> Iterable[int]:
        return [1, 2, 3]

    assert get_list() == [1, 2, 3]



# Generated at 2022-06-21 18:33:56.670028
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'

# Generated at 2022-06-21 18:34:00.203927
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'

# Generated at 2022-06-21 18:34:01.784295
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate("a") == "_py_backwards_a_0"
    assert vg.generate("a") == "_py_backwards_a_1"
    assert vg.generate("b") == "_py_backwards_b_2"


# Generated at 2022-06-21 18:34:06.040337
# Unit test for function get_source
def test_get_source():
    def foo():
        bar = 1
        return bar

    class Foo:
        def bar(self):
            pass

    assert get_source(foo) == 'bar = 1\nreturn bar'
    assert get_source(Foo.bar) == 'pass'
    assert get_source(lambda x: x) == 'return x'



# Generated at 2022-06-21 18:34:15.455277
# Unit test for function eager
def test_eager():
    # type: () -> None
    def add(a: int, b: int) -> int:
        return a + b

    def get_numbers(*nums: int) -> Iterable[int]:
        for num in nums:
            yield num

    assert eager(get_numbers)(1, 2, 3) == [1, 2, 3]
    assert eager(map)(add, [1, 2], [3, 4]) == [4, 6]

# Generated at 2022-06-21 18:34:20.887406
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('a') == '_py_backwards_a_0'
    assert vg.generate('b') == '_py_backwards_b_1'
    assert vg.generate('c') == '_py_backwards_c_2'


if __name__ == '__main__':
    test_VariablesGenerator()

# Generated at 2022-06-21 18:34:25.051584
# Unit test for function warn
def test_warn():
    sys.argv[1] = "tests/warn.py"
    expected = "Function `test` was not backported!"
    warn(expected)
    with open('tests/warn.py') as f:
        assert f.read() == expected + '\n'

# Generated at 2022-06-21 18:34:28.539571
# Unit test for function warn
def test_warn():
    captured = io.StringIO()
    sys.stderr = captured
    warn('1 > 2')
    captured.seek(0)
    assert captured.read() == 'WARNING: 1 > 2\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:34:32.157087
# Unit test for function warn
def test_warn():
    called = [0]

    def _mock_print(*args, **kwargs):
        called[0] += 1
        return

    sys.stderr.write = _mock_print
    sys.stderr.flush = _mock_print
    warn('test')
    assert called[0] == 2



# Generated at 2022-06-21 18:34:34.569535
# Unit test for function get_source
def test_get_source():
    @wraps(get_source)
    def func_get_source():
        return None
    print(get_source(func_get_source))

# Generated at 2022-06-21 18:34:36.437700
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass\n'

# Generated at 2022-06-21 18:34:40.542710
# Unit test for function warn
def test_warn():
    with pytest.warns(None) as record:
        warn('test_warn')
    assert len(record) == 1
    assert 'test_warn' in str(record[0].message)



# Generated at 2022-06-21 18:34:43.933073
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    names = [VariablesGenerator.generate('foo') for _ in range(10)]
    # check that every name is different
    assert len(names) == len(set(names))
    assert 'foo_bar' not in names

# Generated at 2022-06-21 18:34:45.940527
# Unit test for function get_source
def test_get_source():
    def test_fn():
        pass
    assert get_source(test_fn) == 'pass'

# Generated at 2022-06-21 18:34:56.940581
# Unit test for function eager
def test_eager():
    def all_even(x, y):
        for i in range(x, y):
            if i % 2 == 0:
                yield i

    all_even_eager = eager(all_even)

    assert all_even_eager(0, 10) == [0, 2, 4, 6, 8]

    def all_even_yield_from(x, y):
        yield from even(x, y)

    all_even_yield_from_eager = eager(all_even_yield_from)

    assert all_even_yield_from_eager(0, 11) == [0, 2, 4, 6, 8, 10]



# Generated at 2022-06-21 18:34:59.675373
# Unit test for function eager
def test_eager():
    def slow(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    a = eager(slow)(5)
    assert a == [0, 1, 2, 3, 4]
    assert type(a) == list



# Generated at 2022-06-21 18:35:03.768129
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == '_py_backwards_x_0'
    assert VariablesGenerator.generate("x") == '_py_backwards_x_1'



# Generated at 2022-06-21 18:35:11.524790
# Unit test for function warn
def test_warn():    # TODO use Python 3.4 mock.patch.dict instead of monkey-patching
    import sys
    import io
    old_stderr = sys.stderr
    sys.stderr = StringIO = io.StringIO()
    settings.debug = False
    warn('This is a warning')
    assert StringIO.getvalue() == '\n\033[31mWarning:\033[0m This is a warning\n'
    sys.stderr = old_stderr

# Generated at 2022-06-21 18:35:16.365183
# Unit test for function warn
def test_warn():
    with open('./test.txt', 'w') as f:
        sys.stderr = f
        warn('message')
        sys.stderr = sys.__stderr__

    with open('./test.txt', 'r') as f:
        assert f.read() == messages.warn('message') + '\n'

# Generated at 2022-06-21 18:35:18.173309
# Unit test for function warn
def test_warn():
    # should print a bold yellow message with the text
    #  "Hello World"
    warn("Hello World")



# Generated at 2022-06-21 18:35:21.397701
# Unit test for function get_source
def test_get_source():
    """Function get_source should return correct source code.
    """
    def foo():
        pass
    assert get_source(foo) == "def foo():\n    pass"

# Generated at 2022-06-21 18:35:25.957771
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Testcase: Generate 5 variables and make sure that they are unique.
    assert len(set(VariablesGenerator.generate('') for _ in range(5))) == 5
    # Testcase: Generate 5 variables with prefix abc and make sure that they are unique.
    assert len(set(VariablesGenerator.generate('abc') for _ in range(5))) == 5

# Generated at 2022-06-21 18:35:27.911106
# Unit test for function warn
def test_warn():
    warn('This is a test for warn function')



# Generated at 2022-06-21 18:35:31.729537
# Unit test for function eager
def test_eager():
    iterable = {
        '1': 'hello',
        '2': 'world'
    }
    iterable_eager = eager(list)(iterable.values())
    assert iterable == iterable_eager

# Generated at 2022-06-21 18:35:41.788006
# Unit test for function warn
def test_warn():
    warn("test")

# Generated at 2022-06-21 18:35:44.601874
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function)

# Generated at 2022-06-21 18:35:47.254087
# Unit test for function eager
def test_eager():
    @eager
    def test(x):
        for i in range(x):
            yield i
    assert test(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:35:59.770815
# Unit test for function debug
def test_debug():
    def get_message():
        return 'message'

    with mock.patch('sys.stderr', new=io.StringIO()) as patched_stderr:
        settings.debug = True
        debug(get_message)
        result = patched_stderr.getvalue()
        assert result.startswith('\033[')
        result = result[result.index('py-backwards') + len('py-backwards'):]
        assert result.startswith(' ')
        result = result[1:]
        assert result.startswith('message')
        result = result[len('message'):]
        assert result.endswith('\033[0m')
    with mock.patch('sys.stderr', new=io.StringIO()) as patched_stderr:
        settings.debug = False
        debug

# Generated at 2022-06-21 18:36:03.580970
# Unit test for function debug
def test_debug():
    global settings
    try:
        settings = settings.copy()
        settings['debug'] = False
        result = []

        def get_message():
            result.append(1)
            return 'pass'

        debug(get_message)
        assert not result

        settings['debug'] = True
        debug(get_message)
        assert result == [1]
    finally:
        settings = settings.copy()



# Generated at 2022-06-21 18:36:07.212536
# Unit test for function get_source
def test_get_source():
    def test_fn(a, b):
        c = a + b
        return c

    assert get_source(test_fn) == 'c = a + b\nreturn c'

# Generated at 2022-06-21 18:36:12.175318
# Unit test for function debug
def test_debug():
    captured = []
    settings.debug = True

    def capture_output(msg: str) -> None:
        captured.append(msg)

    old_print = print

    try:
        print = capture_output
        debug(lambda: 'Hello, world!')
        assert captured[0] == messages.debug('Hello, world!')
    finally:
        settings.debug = False
        print = old_print

# Generated at 2022-06-21 18:36:15.295911
# Unit test for function get_source
def test_get_source():
    def foo():
        '''This is a test function'''
        return 1

# Generated at 2022-06-21 18:36:18.177620
# Unit test for function warn
def test_warn():
    # make sure message is printed to stderr
    assert sys.stderr != sys.stdout
    # make sure message contains link to the docs
    assert 'http://py-backwards.readthedocs.io/en/latest' in warn('message')

# Generated at 2022-06-21 18:36:19.467631
# Unit test for function eager
def test_eager():
    l = [1,2,3]
    assert l == eager(lambda x: x)(l)


# Generated at 2022-06-21 18:36:48.433523
# Unit test for function eager
def test_eager():
    from ..test_helpers import Asserter
    asserter = Asserter('utils.eager')
    asserter.assert_callable_returns([], eager(lambda: range(3)))
    asserter.assert_callable_returns([1, 2, 3], eager(range))
    asserter.summary()

# Generated at 2022-06-21 18:36:53.363335
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # GIVEN
    vg = VariablesGenerator()
    # WHEN
    vg.generate("x")
    res = vg.generate("x")
    # THEN
    assert res == "_py_backwards_x_0"


# Generated at 2022-06-21 18:36:56.326668
# Unit test for function get_source
def test_get_source():
    def test_function():
        # Test content
        pass

    assert get_source(test_function) == '# Test content\n    pass'

# Generated at 2022-06-21 18:37:02.994714
# Unit test for function eager
def test_eager():
    @eager
    def eager_func(bar):
        return iter(range(bar))

    @eager
    def eager_func_empty():
        return iter(range(0))

    assert eager_func(2) == [0, 1]
    assert isinstance(eager_func(0), list)
    assert eager_func(3) == [0, 1, 2]
    assert eager_func_empty() == []

test_eager()

# Generated at 2022-06-21 18:37:07.931758
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("_counter") == "_py_backwards__counter_0"
    assert VariablesGenerator.generate("_counter") == "_py_backwards__counter_1"
    assert VariablesGenerator.generate("_counter") == "_py_backwards__counter_2"


# Generated at 2022-06-21 18:37:09.392254
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-21 18:37:13.259920
# Unit test for function warn
def test_warn():
    f = open('test.txt', 'a+')
    warn('test')
    f.seek(0)
    assert f.readlines() == ['test\n']
    f.close()



# Generated at 2022-06-21 18:37:14.364067
# Unit test for function warn
def test_warn():
    warn('test message')



# Generated at 2022-06-21 18:37:19.459448
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("var_name") == '_py_backwards_var_name_0'
    assert VariablesGenerator.generate("var_name") == '_py_backwards_var_name_1'
    assert VariablesGenerator.generate("var_name") == '_py_backwards_var_name_2'


# Generated at 2022-06-21 18:37:24.330079
# Unit test for function debug
def test_debug():
    """Test that debug messages are not formatted when debug is disabled."""
    from .. import conf
    from .context_managers import settings as cm_settings
    with cm_settings(debug=False):
        debug(lambda: 'test')
    with cm_settings(debug=True):
        conf.debug = True
        assert debug(lambda: 'test') is None

# Generated at 2022-06-21 18:38:22.475779
# Unit test for function warn
def test_warn():
    import io
    import sys
    f = io.StringIO()
    sys.stderr = f
    warn("hello")
    assert f.getvalue() == messages.warn("hello") + "\n"
    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:38:28.350768
# Unit test for function debug
def test_debug():
    if not settings.debug:
        return
    import os, sys
    try:
        old = sys.stderr
        sys.stderr = open(os.devnull, 'w')
        settings.debug = True
        debug(lambda: "This should be printed")
        settings.debug = False
        debug(lambda: "This should not be printed")
    finally:
        sys.stderr.close()
        sys.stderr = old

# Generated at 2022-06-21 18:38:30.477456
# Unit test for function get_source
def test_get_source():
    def source_test():
        pass

    assert get_source(source_test) == 'def source_test():\n    pass\n'

# Generated at 2022-06-21 18:38:34.710567
# Unit test for function debug
def test_debug():
    message = 'I am debug message'
    captured_output = io.StringIO()
    sys.stderr = captured_output
    with patch.object(settings, 'debug', True):
        debug(lambda: message)
    assert captured_output.getvalue() == messages.debug(message) + '\n'



# Generated at 2022-06-21 18:38:39.380223
# Unit test for function warn
def test_warn():
    from ..io import capture_io
    from ..conf import settings
    settings.debug = False

    with capture_io() as (out, _):
        warn('test')
        assert out.getvalue() == messages.warn('test') + '\n'


# Generated at 2022-06-21 18:38:42.856624
# Unit test for function debug
def test_debug():
    settings.debug = True
    called = [False]
    def get_message() -> str:
        called[0] = True
        return 'Hello!'
    debug(get_message)
    assert called
    settings.debug = False

# Generated at 2022-06-21 18:38:44.654016
# Unit test for function eager
def test_eager():
    l = [1, 2, 3, 4, 5]
    assert eager(iter)(l) == l

# Generated at 2022-06-21 18:38:47.745087
# Unit test for function debug
def test_debug():
    """If settings.debug is False, debug should not print anything."""
    settings.debug = False
    debug(lambda: 'some message')  # should not print anything
    settings.debug = True

# Generated at 2022-06-21 18:38:52.902254
# Unit test for function warn
def test_warn():
    settings.warn = True
    assert settings.warn
    msg = 'This is a warning'
    try:
        old_std_err = sys.stderr
        sys.stderr = StringIO()
        warn(msg)
        output = sys.stderr.getvalue().strip()
    finally:
        sys.stderr = old_std_err
    assert output == ('\n' + messages.warn(msg))



# Generated at 2022-06-21 18:38:58.491270
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    counter = 0
    @eager
    def check_variable(variable: str) -> Iterable[str]:
        """Checks that name of variable is unique."""
        nonlocal counter
        name = VariablesGenerator.generate(variable)
        assert name not in globals(), '{} is not unique'.format(name)
        globals()[name] = True
        counter += 1
        return name

    variables = ('a', 'B', '_c')
    for variable in variables:
        list(check_variable(variable))
    assert counter == 3 * len(variables)


if __name__ == '__main__':
    test_VariablesGenerator()