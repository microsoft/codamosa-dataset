

# Generated at 2022-06-21 18:30:26.738669
# Unit test for function debug
def test_debug():
    import io
    import sys

    from . import test_settings

    out = io.StringIO()
    sys.stderr = out
    test_settings.debug = True
    debug(lambda: 'hello')
    assert out.getvalue() == messages.debug('hello') + '\n'

    out = io.StringIO()
    sys.stderr = out
    test_settings.debug = False
    debug(lambda: 'hello')
    assert out.getvalue() == ''

# Generated at 2022-06-21 18:30:28.180554
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "testeroni")
    settings.debug = False
    debug(lambda: "testeroni")



# Generated at 2022-06-21 18:30:30.410654
# Unit test for function get_source
def test_get_source():
    def my_function(x, y, z=1):
        if x < y:
            print(y)
        else:
            print(x)
        return x + y + z


# Generated at 2022-06-21 18:30:35.961674
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('a') == '_py_backwards_a_0'
    assert vg.generate('b') == '_py_backwards_b_1'
    assert vg.generate('a') == '_py_backwards_a_2'

test_VariablesGenerator()

# Generated at 2022-06-21 18:30:36.977711
# Unit test for function get_source
def test_get_source():
    get_source(test_get_source)

# Generated at 2022-06-21 18:30:40.198040
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'

# Generated at 2022-06-21 18:30:44.254631
# Unit test for function debug
def test_debug():
    debug_message = []  # type: List[str]

    def test_function():
        debug(lambda: 'debugged')

    class TestClass:
        def test_method(self):
            debug(lambda: 'debugged')

    with settings(debug=True):
        test_function()

        TestClass().test_method()

    assert debug_message == ['debugged', 'debugged']



# Generated at 2022-06-21 18:30:49.996697
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO
    stderr = sys.stderr
    def mock_stderr():
        sys.stderr = StringIO()
        yield
        sys.stderr = stderr
    with mock_stderr():
        warn("message")
    assert sys.stderr.getvalue() == "\x1b[93mWarning:\x1b[0m message\n"


# Generated at 2022-06-21 18:31:02.706092
# Unit test for function debug
def test_debug():
    debug_stream = ""
    debug_output = ""

    def get_message():
        global debug_stream
        for line in debug_stream.split('\n'):
            debug_output += "DEBUG: {}\n".format(line)

    def get_source():
        global debug_stream
        return debug_stream

    def set_source(source):
        global debug_stream
        debug_stream = source

    def test_debug_enabled():
        global debug_output
        debug_output = ""
        set_source("debug_stream")
        settings.debug = True
        debug(get_message)
        assert debug_output == "\x1b[32mDEBUG: debug_stream\n\x1b[0m"

    def test_debug_disabled():
        global debug_output
        debug_output = ""
       

# Generated at 2022-06-21 18:31:05.584173
# Unit test for function eager
def test_eager():
    @eager
    def function():
        yield 'hello'
        yield 'world'

    assert function() == ['hello', 'world']

# Generated at 2022-06-21 18:31:12.212040
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source).split('\n') == [
        'return getsource(fn).split(\'\\n\')',
        'padding = len(re.findall(r\'^(\s*)\', source_lines[0])[0])',
        'return \'\\n\'.join(line[padding:] for line in source_lines)'
    ]

# Generated at 2022-06-21 18:31:15.650463
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'

# Generated at 2022-06-21 18:31:18.488634
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]



# Generated at 2022-06-21 18:31:28.914741
# Unit test for function get_source
def test_get_source():
    def dummy():
        def nested_dummy():
            pass

    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    from dummy_app.dummy_app import dummy_app


    # os.system('python -m pytest tests')
    assert get_source(dummy) == '\n'.join([
        'def nested_dummy():',
        '    pass'
    ])
    assert get_source(dummy_app) == '\n'.join([
        'from py_backwards.conf import settings',
        'settings.debug = True'
    ])


# Generated at 2022-06-21 18:31:30.577510
# Unit test for function eager
def test_eager():
    assert eager(iter)(range(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:31:33.648440
# Unit test for function eager
def test_eager():
    @eager
    def _generate_ones() -> Iterable[int]:
        for _ in range(10):
            yield 1

    assert _generate_ones() == [1] * 10


# Generated at 2022-06-21 18:31:39.287513
# Unit test for function debug
def test_debug():
    import io
    import sys

    buff = io.StringIO()
    sys.stderr = buff
    settings.debug = True
    debug(lambda: 'foobar')
    assert buff.getvalue() == '🐛 foobar\n'

    settings.debug = False
    debug(lambda: 'foobar')
    assert buff.getvalue() == '🐛 foobar\n'



# Generated at 2022-06-21 18:31:46.345429
# Unit test for function warn
def test_warn():
    import textwrap
    import re
    text = '''\
    def some_function(a, b, c=3, *args, d=5, **kwargs):
        pass
    '''
    with patch('sys.stdout', new=StringIO()) as fake_out:
        warn(text)
    assert(fake_out.getvalue() == textwrap.dedent('''\
        \033[93m            def some_function(a, b, c=3, *args, d=5, **kwargs):
         (WARNING)         pass
        '''))



# Generated at 2022-06-21 18:31:50.565793
# Unit test for function get_source
def test_get_source():
    def foo():
        """A function with a docstring."""
        print('This is a function.')
    assert get_source(foo) == """def foo():
    print('This is a function.')"""

# Generated at 2022-06-21 18:31:52.030191
# Unit test for function eager
def test_eager():
    arr = [1, 2, 3]
    assert eager(iter)(arr) == arr

# Generated at 2022-06-21 18:32:00.140449
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()
    message = 'foobar'
    debug(lambda: message)
    sys.stderr.seek(0)
    assert messages.debug(message) in sys.stderr.read()



# Generated at 2022-06-21 18:32:03.401842
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0

    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator._counter == 1

    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator._counter == 2


# Generated at 2022-06-21 18:32:05.620182
# Unit test for function get_source

# Generated at 2022-06-21 18:32:09.630831
# Unit test for function warn
def test_warn():
    import io
    buffer = io.StringIO()
    sys.stderr = buffer
    try:
        warn('some message')
        assert buffer.getvalue() == 'pybackwards: some message\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:32:11.344112
# Unit test for function eager
def test_eager():
    @eager
    def to_list(value):
        yield value
    assert to_list('value') == ['value']

# Generated at 2022-06-21 18:32:15.754288
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    counter = 0
    debug(lambda : 'Hello, world')
    settings.debug = False
    try:
        debug(lambda : counter)
    except Exception as e:
        print(e)
        assert False, "Error occured"
    debug(lambda : counter)



# Generated at 2022-06-21 18:32:19.911961
# Unit test for function warn
def test_warn():
    import io
    import warnings
    import contextlib

    output = io.StringIO()
    with contextlib.redirect_stderr(output):
        with warnings.catch_warnings(record=True) as w:
            warn('test warn')
            assert len(w) == 1
            assert str(w[-1].message) == 'test warn'
    assert 'test warn' in output.getvalue()


# Generated at 2022-06-21 18:32:21.196947
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    print(get_source(func))

# Generated at 2022-06-21 18:32:23.271933
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')

# Generated at 2022-06-21 18:32:27.822780
# Unit test for function warn
def test_warn():
    capture = io.StringIO()
    with contextlib.redirect_stderr(capture):
        warn('hello')
    assert capture.getvalue().strip() == '\x1b[31mPyBackwards Warning: hello\x1b[0m'

# Generated at 2022-06-21 18:32:43.725504
# Unit test for function eager
def test_eager():
    # test function to which we later apply eager
    def test_call_fn(x: int) -> Iterable[int]:
        for i in range(x):
            yield i

    # wrapper to ensure that eager returns a list object
    def check_eager_fn(x: int) -> List[int]:
        return eager(test_call_fn)(x)

    assert check_eager_fn(0) == []
    assert check_eager_fn(1) == [0]
    assert check_eager_fn(2) == [0, 1]
    assert check_eager_fn(3) == [0, 1, 2]


# Generated at 2022-06-21 18:32:46.888365
# Unit test for function debug
def test_debug():
    _debug_message = []
    debug(lambda: "This is a test")
    assert len(_debug_message) == 1, "Debug message should be printed."



# Generated at 2022-06-21 18:32:52.639794
# Unit test for function warn
def test_warn():
    import sys
    sys.stderr = open('test_warn_err', 'w')
    warn('blah blah')
    with open('test_warn_err') as f:
        assert(f.read() == messages.warn('blah blah') + '\n')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:32:58.742164
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase, mock

    try:
        out = StringIO()
        sys.stderr = out
        settings.debug = True
        debug(messages.debug('Dummy message'))
        expected = '\x1b[33m\u21A9 \x1b[37mDummy message\n'
        self = TestCase()
        self.assertEqual(out.getvalue(), expected)
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-21 18:33:02.853455
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('test') == '_py_backwards_test_0'
    assert vg.generate('test') == '_py_backwards_test_1'



# Generated at 2022-06-21 18:33:07.263361
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    V = VariablesGenerator()
    v1 = V.generate('limit')
    assert v1 == '_py_backwards_limit_0'
    v2 = V.generate('limit')
    assert v2 == '_py_backwards_limit_1'


# Generated at 2022-06-21 18:33:15.924199
# Unit test for function debug
def test_debug():
    output = []
    class Output(list):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def append(self, item):
            super().append(item)

        def __setattr__(self, key, value):
            if key == 'debug':
                setattr(settings, key, value)

        def __getattr__(self, key):
            if key == 'debug':
                return getattr(settings, key)

    def get_message():
        return 'some message'

    def test():
        settings.debug = True
        debug(get_message)


    settings = Output()
    test()
    assert output == ['some message']


# detect_collisions_between_generators
# -----------------------------------

# Arguments
# ---------

# Generated at 2022-06-21 18:33:19.066354
# Unit test for function eager
def test_eager():
    def seq(n):
        for i in range(n):
            yield i
    assert eager(seq)(3) == [0, 1, 2]

# Generated at 2022-06-21 18:33:29.149921
# Unit test for function get_source
def test_get_source():
    def assert_source(function, expected):
        actual = get_source(function)
        assert actual == expected, \
            '{}\n!=\n{}'.format(actual, expected)

    def empty():
        pass

    assert_source(empty, 'pass')

    def one_line(foo):
        if foo:
            pass
        else:
            pass

    assert_source(one_line, 'if foo:\n    pass\nelse:\n    pass')

    def multi_line(bar):
        if bar:
            pass
        else:
            pass

    assert_source(multi_line, '''if bar:
    pass
else:
    pass''')

    def blank_lines(baz):
        if baz:
            pass
        else:
            pass

# Generated at 2022-06-21 18:33:34.585663
# Unit test for function debug
def test_debug():
    from ..conf import Settings as _Settings
    from ... import _Context

    class Settings(_Settings):
        debug = True

    _Context(settings=Settings())

    def gm():
        return 'abcdefg'

    debug(gm)
    # Output:
    #     [(DEBUG) abcdefg]



# Generated at 2022-06-21 18:33:50.673546
# Unit test for function debug
def test_debug():
    debug(lambda: "Something happened")

# Generated at 2022-06-21 18:33:52.836079
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass

    assert get_source(foo) == 'def bar():\n    pass'

# Generated at 2022-06-21 18:33:55.158129
# Unit test for function get_source
def test_get_source():
    # TODO: Remove this function
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-21 18:34:00.744051
# Unit test for function warn
def test_warn():
    import io
    import warnings
    with warnings.catch_warnings(record=True) as ws:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        warn("some message")
        # Verify some things
        assert len(ws) == 1
        assert str(ws[-1].message) == "some message"

# Generated at 2022-06-21 18:34:05.002830
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    source = 'def func():\n    pass\n'
    assert get_source(func) == source
    # Test with tabs instead of spaces
    def func():
        pass
    source = 'def func():\n\tpass\n'
    assert get_source(func) == source

# Generated at 2022-06-21 18:34:09.240545
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'

# Generated at 2022-06-21 18:34:11.551094
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert all(gen.generate('a') != gen.generate('b') for _ in range(1000))

# Generated at 2022-06-21 18:34:15.577374
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert "test" in stderr.getvalue()

# Generated at 2022-06-21 18:34:17.507709
# Unit test for function warn
def test_warn():
    message = "test message"
    warn(message)
    assert messages.warn(message) in sys.stderr.getvalue()


# Generated at 2022-06-21 18:34:21.305335
# Unit test for function eager
def test_eager():
    @eager
    def fn(*args: str) -> Iterable[str]:
        for arg in args:
            yield arg

    assert fn('a', 'b', 'c') == ['a', 'b', 'c']


# Generated at 2022-06-21 18:35:04.309588
# Unit test for function get_source
def test_get_source():
    def add(x, y):
        return x + y

    assert get_source(add) == '    return x + y\n'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:35:09.744087
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-21 18:35:17.304394
# Unit test for function warn
def test_warn():
    error_message = 'Error message'
    with patch('sys.stderr.write', return_value=None) as stderr_write:
        warn(error_message)
        stderr_write.assert_called_once_with(
            messages.warn(error_message) + '\n')

    # Test warn is called twice
    with patch('sys.stderr.write', return_value=None) as stderr_write:
        for _ in range(2):
            warn(error_message)
        assert stderr_write.call_count == 2

# Generated at 2022-06-21 18:35:21.876965
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch('py_backwards.utils.settings') as settings_mock:
        settings_mock.debug = True
        debug(lambda: 'debug_message')
        settings_mock.debug = False
        debug(lambda: 'debug_message')

# Generated at 2022-06-21 18:35:24.816468
# Unit test for function debug
def test_debug():
    assert settings.debug

    # Create message of debug
    def create_msg():
        return "hello"

    debug(create_msg)
    settings.debug = False
    debug(create_msg)



# Generated at 2022-06-21 18:35:29.723720
# Unit test for function debug
def test_debug():
    with settings(debug=True):
        debug(lambda: 'message')

    with settings(debug=False):
        debug(lambda: 'message')


__all__ = ['eager', 'VariablesGenerator', 'get_source', 'warn', 'debug',
           'test_debug']

# Generated at 2022-06-21 18:35:33.025272
# Unit test for function eager
def test_eager():
    @eager
    def concat(*args: Any) -> Iterable[str]:
        for arg in args:
            yield str(arg)
    assert concat(1, 2, 3) == ['1', '2', '3']



# Generated at 2022-06-21 18:35:37.005472
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'



# Generated at 2022-06-21 18:35:40.700249
# Unit test for function get_source
def test_get_source():
    def foo(x):
        return x.bar(5)

    assert get_source(foo) == '    return x.bar(5)'


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-21 18:35:44.554657
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    if get_source(foo).strip() != 'raise Exception()':
        raise Exception('failed to get source')



# Generated at 2022-06-21 18:37:19.378905
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') != VariablesGenerator.generate('test')

# Generated at 2022-06-21 18:37:27.022299
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    VG = VariablesGenerator()
    VG._counter = 0
    assert VG.generate('a') == '_py_backwards_a_0'
    assert VG.generate('a') == '_py_backwards_a_1'
    assert VG.generate('b') == '_py_backwards_b_2'
    assert VG.generate('c') == '_py_backwards_c_3'
    assert VG.generate('a') == '_py_backwards_a_4'

# Generated at 2022-06-21 18:37:28.454693
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(100000))() == list(range(100000))

# Generated at 2022-06-21 18:37:30.715283
# Unit test for function eager
def test_eager():
    import pytest
    @eager
    def gen():
        yield 1
        yield 2
    assert gen() == [1, 2]

# Generated at 2022-06-21 18:37:34.663192
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate("name") == '_py_backwards_name_0'
    assert vg.generate("name") == '_py_backwards_name_1'
    assert vg.generate("name") == '_py_backwards_name_2'


# Generated at 2022-06-21 18:37:37.742334
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'


# Generated at 2022-06-21 18:37:39.381492
# Unit test for function get_source
def test_get_source():
    def a():
        pass

    assert get_source(a) == 'pass'

# Generated at 2022-06-21 18:37:43.921011
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("_a") == "_py_backwards__a_0"
    assert VariablesGenerator.generate("_b") == "_py_backwards__b_1"
    assert VariablesGenerator.generate("_c") == "_py_backwards__c_2"

# Generated at 2022-06-21 18:37:46.782795
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """Unit test for constructor of class VariablesGenerator"""
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'

# Generated at 2022-06-21 18:37:58.196968
# Unit test for function debug
def test_debug():
    import io
    import sys

    buffer = io.StringIO()
    sys.stderr = buffer

    messages.debug = lambda m: 'debug: {}'.format(m)
    settings.debug = True
    debug(lambda: 'Testing debug message')
    assert buffer.getvalue() == 'debug: Testing debug message\n'

    messages.debug = lambda m: 'debug: {}'.format(m)
    settings.debug = False
    debug(lambda: 'Testing debug message')
    assert buffer.getvalue() == 'debug: Testing debug message\n'

    messages.debug = lambda m: 'debug: {}'.format(m)
    settings.debug = True
    debug(lambda: 'Testing debug message 2')
    assert buffer.getvalue() == 'debug: Testing debug message\ndebug: Testing debug message 2\n'

   