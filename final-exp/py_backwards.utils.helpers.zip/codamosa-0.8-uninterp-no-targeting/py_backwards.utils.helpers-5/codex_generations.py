

# Generated at 2022-06-21 18:30:35.863243
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        warn('foo')
        assert 'foo' in fake_stderr.getvalue()

# Generated at 2022-06-21 18:30:36.906180
# Unit test for function get_source

# Generated at 2022-06-21 18:30:45.409935
# Unit test for function get_source

# Generated at 2022-06-21 18:30:54.193323
# Unit test for function debug
def test_debug():
    class TestCase:
        message = 'Message'

        def __enter__(self):
            self.setting = settings.debug
            settings.debug = True

        def __exit__(self, exc_type, exc_val, exc_tb):
            settings.debug = self.setting

    with TestCase() as test_case:
        def get_message() -> str:
            return test_case.message

        captured_output = StringIO()
        sys.stderr = captured_output
        debug(get_message)
        assert captured_output.getvalue() == messages.debug(test_case.message)
        captured_output.close()

        captured_output = StringIO()
        sys.stderr = captured_output
        debug(get_message)
        assert captured_output.getvalue() == ''
        captured_output

# Generated at 2022-06-21 18:31:01.629430
# Unit test for function warn
def test_warn():
    # 1. Call function
    # 2. Check that it prints a message
    # 3. Check that it prints a warning message

    def test_():
        warn('a message')

    try:
        test_output = StringIO()
        with redirect_stdout(test_output):
            test_()
        output = test_output.getvalue()
    finally:
        test_output.close()
    assert 'a message' in output and messages.warn('a message') in output



# Generated at 2022-06-21 18:31:08.786003
# Unit test for function warn
def test_warn():
    messages.warn = lambda x: 'warn: {}'.format(x)
    messages.debug = lambda x: 'debug: {}'.format(x)
    with open('/dev/null', 'w'):
        warn('test')
        debug(lambda: 'test')
    settings.debug = True
    with open('/dev/null', 'w') as dev_null:
        warn('test')
        debug(lambda: 'test')

# Generated at 2022-06-21 18:31:11.904659
# Unit test for function debug
def test_debug():
    messages.debug = lambda message: '!!!DEBUG!!!: {}'.format(message)
    settings.debug = True
    debug(lambda: 'Hello world!')
    settings.debug = False
    debug(lambda: 'Hello again!')



# Generated at 2022-06-21 18:31:13.721453
# Unit test for function get_source
def test_get_source():
    def foo():
        a = 1
    expected_result = 'a = 1'
    assert get_source(foo) == expected_result


# Generated at 2022-06-21 18:31:16.905322
# Unit test for function debug
def test_debug():
    debug_output = ''

    def get_msg():
        return 'Yay'

    class FakeStderr:
        def write(self, message):
            nonlocal debug_output
            debug_output = message

    sys.stderr = FakeStderr()
    settings.debug = True
    debug(get_msg)

    assert debug_output == messages.debug(get_msg())


# Generated at 2022-06-21 18:31:21.757556
# Unit test for function get_source
def test_get_source():
    def function_to_be_tested():
        pass

    def function_to_return_source():
        return get_source(function_to_be_tested)

    assert function_to_return_source() == 'def function_to_be_tested():\n    pass'

# Generated at 2022-06-21 18:31:28.123127
# Unit test for function warn
def test_warn():
    # Empty sys.stderr file
    sys.stderr = open(os.devnull, 'w')
    # Redirect stdout to stderr (to see output from warn())
    sys.stdout = sys.stderr
    # Call warn()
    warn("test warning")


# Generated at 2022-06-21 18:31:35.805443
# Unit test for function get_source
def test_get_source():
    def foo():
        a = 1

    assert get_source(foo) == 'a = 1'
    assert get_source(get_source) == 'source_lines = getsource(fn).split(\'\\n\')\n' \
                                     'padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n' \
                                     'return \'\\n\'.join(line[padding:] for line in source_lines)'
    assert '\n' not in get_source(test_get_source)

# Generated at 2022-06-21 18:31:37.391330
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        return (i for i in range(5))
    assert foo() == list(range(5))

# Generated at 2022-06-21 18:31:39.334326
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a')=='_py_backwards_a_0'

# Generated at 2022-06-21 18:31:41.734658
# Unit test for function debug
def test_debug():
    settings.debug = True

    try:
        message = 'Hello World'
        debug(lambda: message)
        assert True
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:31:45.096408
# Unit test for function debug
def test_debug():
    capturer = io.StringIO()
    with contextlib.redirect_stderr(capturer):
        debug(lambda: 'Hello')

    assert capturer.getvalue() ==  messages.debug('Hello') + '\n'



# Generated at 2022-06-21 18:31:47.447877
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i
    assert gen(3) == [0, 1, 2]


import pytest

# Generated at 2022-06-21 18:31:47.913092
# Unit test for function warn
def test_warn():
    pass



# Generated at 2022-06-21 18:31:51.585453
# Unit test for function warn
def test_warn():
    try:
        old_stderr = sys.stderr
        stderr = sys.stderr = StringIO()
        try:
            warn('oops')
            assert stderr.getvalue() == messages.warn('oops') + '\n'
        finally:
            sys.stderr = old_stderr
    except:
        raise
        # print('test_warn: failed')


# Generated at 2022-06-21 18:31:54.411177
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    v.generate('abc')
    v.generate('abc')
    v.generate('abc')

# Generated at 2022-06-21 18:32:05.881464
# Unit test for function debug
def test_debug():
    debug_message = 'debug message'
    assert not settings.debug

    def test_get_message():
        return debug_message

    debug(test_get_message)
    assert debug_message not in sys.stderr.getvalue()

    class StdErrMock:
        def __init__(self):
            self.buffer = ''
        def write(self, text):
            self.buffer += text

    sys.stderr = StdErrMock()
    settings.debug = True

    debug(test_get_message)
    assert debug_message in sys.stderr.buffer
    sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:32:09.132082
# Unit test for function warn
def test_warn():
    stdout = sys.stdout
    sys.stdout = sys.stderr  # todo: change file to /dev/null
    try:
        warn('test message')
    finally:
        sys.stdout = stdout

# Generated at 2022-06-21 18:32:14.548386
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('test') == '_py_backwards_test_0'
    assert vg.generate('test') == '_py_backwards_test_1'
    assert vg.generate('test') == '_py_backwards_test_2'
    assert vg.generate('test') == '_py_backwards_test_3'

# Generated at 2022-06-21 18:32:16.894500
# Unit test for function get_source
def test_get_source():
    def test_function():
        with open(__file__):
            pass
    source = get_source(test_function)
    assert source == 'with open(__file__):\n' \
                     '    pass'



# Generated at 2022-06-21 18:32:19.520636
# Unit test for function eager
def test_eager():
    @eager
    def f():
        for i in [1,2,3]:
            yield i
    assert f() == [1,2,3]

# Generated at 2022-06-21 18:32:20.511310
# Unit test for function warn
def test_warn():
    assert warn('') is None

# Generated at 2022-06-21 18:32:21.909125
# Unit test for function warn
def test_warn():
    warn('Test warn')


# Unit teest for function debug

# Generated at 2022-06-21 18:32:33.220816
# Unit test for function eager

# Generated at 2022-06-21 18:32:37.997674
# Unit test for function get_source
def test_get_source():
    def simple_function():
        def simple_inner_function():
            print("hello")
            print("world")
        simple_inner_function()
    source = get_source(simple_function)
    source_reference = """def simple_inner_function():
    print("hello")
    print("world")"""
    assert source_reference == source

# Generated at 2022-06-21 18:32:40.698270
# Unit test for function eager
def test_eager():
    @eager
    def some(a):
        for i in a:
            yield i
    assert some([1,2]) == [1,2]

# Generated at 2022-06-21 18:32:50.826704
# Unit test for function warn
def test_warn():
    from io import StringIO
    from sys import stdout
    from sys import stderr
    sys.stderr = StringIO()
    sys.stdout = stderr
    warn('Test message')
    assert sys.stderr.getvalue() == '\x1b[33m[PYBACKWARDS] Test message\x1b[0m\n'


# Generated at 2022-06-21 18:32:52.159326
# Unit test for function warn
def test_warn():
    warn("This is a test")

# Generated at 2022-06-21 18:32:54.199164
# Unit test for function get_source
def test_get_source():
    def source_to_test():
        return 1

    source = get_source(source_to_test)
    assert source == 'return 1'


# Generated at 2022-06-21 18:33:00.562535
# Unit test for function eager
def test_eager():
    import operator
    @eager
    def gen_fibonacci(n):
        a, b = 0, 1
        for _ in range(n):
            yield a
            a, b = b, a + b

    assert gen_fibonacci(5) == [0, 1, 1, 2, 3]

    @eager
    def gen_fibonacci2():
        a, b = 0, 1
        while True:
            yield a
            a, b = b, a + b


# Generated at 2022-06-21 18:33:03.750115
# Unit test for function get_source
def test_get_source():
    def test_fn():
        print('test')
        return 1
    test_source = [
        'def test_fn():',
        '    print(\'test\')',
        '    return 1'
    ]
    assert get_source(test_fn) == '\n'.join(test_source)


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:33:05.770955
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello')
    debug(lambda: 'World')


# Generated at 2022-06-21 18:33:08.030706
# Unit test for function get_source
def test_get_source():
    def foo():
        bar()

    def bar():
        pass

    assert get_source(foo) == 'bar()'



# Generated at 2022-06-21 18:33:10.794101
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    print(vg.generate('hello'))
    print(vg.generate('hello'))
    print(vg.generate('hello'))


# Generated at 2022-06-21 18:33:14.734227
# Unit test for function warn
def test_warn():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    out = StringIO()

    warn('simple warn')
    print('simple warn', file=out)
    assert out.getvalue() == '\x1b[31m⚠ simple warn\x1b[0m\n'



# Generated at 2022-06-21 18:33:15.771690
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == function.__doc__

# Generated at 2022-06-21 18:33:28.461826
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_gen = VariablesGenerator()
    assert var_gen.generate('test') == '_py_backwards_test_0'
    assert var_gen.generate('test') == '_py_backwards_test_1'
    assert var_gen.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-21 18:33:30.183825
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-21 18:33:31.698731
# Unit test for function warn
def test_warn():
    capturer = Capturer()
    capturer.start()
    warn('Warning test')
    response = capturer.stop()
    print(response)
    assert 'Warning test' in response

test_warn()

# Generated at 2022-06-21 18:33:34.731958
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'message 1')
    settings.debug = True
    debug(lambda: 'message 2')



# Generated at 2022-06-21 18:33:38.047541
# Unit test for function debug
def test_debug():
    result = []
    settings.debug = True
    debug(lambda: 'A')
    settings.debug = False
    debug(lambda: 'B')

    assert result == ['A']



# Generated at 2022-06-21 18:33:41.853618
# Unit test for function warn
def test_warn():
    message = 'Test Message'
    try:
        sys.stderr.close()
    except:
        pass
    warn(message)
    assert sys.stderr.getvalue().strip() == messages.warn(message)

# Generated at 2022-06-21 18:33:46.789238
# Unit test for function warn
def test_warn():
    import io
    import sys
    buf = io.StringIO()
    sys.stderr = buf
    warn('test')
    body = buf.getvalue()
    sys.stderr = sys.__stderr__
    assert body.startswith('WARNING: ') and body.endswith(': test\n')



# Generated at 2022-06-21 18:33:50.870759
# Unit test for function debug
def test_debug():
    result = []
    message = 'This is a test message.'

    def get_message():
        return message

    debug(lambda: result.append(get_message()))
    assert result == [get_message()]



# Generated at 2022-06-21 18:33:57.666970
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            sys.stdout = self._stdout

    with Capturing() as capture:
        warn('Warning')
        assert len(capture) == 1
        assert re.match(r'\x1b\[[0-9;]+mWARNING: Warning\x1b\[0m', capture[0])


# Generated at 2022-06-21 18:34:07.337698
# Unit test for function eager
def test_eager():
    from .. import utils
    from inspect import getsource
    from functools import wraps
    from typing import Any, Callable, Iterable

    @eager
    def eager_fn() -> Iterable[int]:
        yield 1
        yield 2

    utils.assert_eq(eager_fn(), [1, 2])
    utils.assert_eq(getsource(eager_fn), 'def eager_fn():\n    pass')

    @eager
    def eager_fn2() -> Iterable[int]:
        """Meaningless docstring."""
        yield 1
        yield 2

    utils.assert_eq(eager_fn2(), [1, 2])

# Generated at 2022-06-21 18:34:34.176866
# Unit test for function debug
def test_debug():
    debug_messages = []  # type: List[str]

    assert settings.debug is False
    debug(lambda: 'debug')
    assert debug_messages == []

    settings.debug = True
    debug(lambda: 'debug')
    assert debug_messages == ['debug']
    settings.debug = False

    def do_debug():
        debug(lambda: 'debug')
        debug(lambda: 'debug')
        debug(lambda: 'debug')

    assert settings.debug is False
    do_debug()
    assert debug_messages == []

    settings.debug = True
    do_debug()
    assert debug_messages == ['debug', 'debug', 'debug']
    settings.debug = False

# Generated at 2022-06-21 18:34:35.099948
# Unit test for function warn
def test_warn():
    warn("This is just a test")


# Generated at 2022-06-21 18:34:39.331555
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'



# Generated at 2022-06-21 18:34:43.534851
# Unit test for function eager
def test_eager():
    from collections import Counter
    fn = lambda x: Counter(x)
    assert eager(fn)('backwards') == [Counter({'a': 2, 'b': 1, 'c': 1, 'd': 1, 'e': 1, 'k': 1, 'r': 1, 's': 1, 'w': 1})]

# Generated at 2022-06-21 18:34:48.500900
# Unit test for function debug
def test_debug():
    import io
    def test():
        with io.StringIO() as stream:
            sys.stderr = stream
            debug(lambda: 'something')
            return stream.getvalue()
    assert test() == '\n\033[32mD>\033[0m something\n'

# Generated at 2022-06-21 18:34:52.221783
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
	a = VariablesGenerator()
	b = VariablesGenerator()
	c = VariablesGenerator()
	print(a._counter)
	assert a._counter == 3
	assert b._counter == 3
	assert c._counter == 3

test_VariablesGenerator()

# Generated at 2022-06-21 18:34:54.750510
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'



# Generated at 2022-06-21 18:34:57.279471
# Unit test for function warn
def test_warn():
    @warn('message')
    def fn(n: int) -> int:
        return n * n

    assert fn(2) == 4, messages.fn_result_error(fn, 4, fn(2))



# Generated at 2022-06-21 18:34:59.489834
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'



# Generated at 2022-06-21 18:35:00.642398
# Unit test for function eager
def test_eager():
    data = [1, 2, 3]
    assert eager(lambda x: x)(data) == data

# Generated at 2022-06-21 18:35:48.771182
# Unit test for function debug
def test_debug():
    import pytest
    get_message = lambda: 'Hello!'
    assert get_message() == 'Hello!'
    try:
        actual_output = StringIO()
        settings.set_debug(True)
        with patch('sys.stderr', actual_output):
            debug(get_message)
    finally:
        settings.set_debug(False)
    assert actual_output.getvalue().strip().endswith('Hello!')



# Generated at 2022-06-21 18:35:58.883457
# Unit test for function debug
def test_debug():
    import unittest
    import sys
    import io
    try:
        settings.debug = True
        sys.stderr = io.StringIO()

        debug(lambda: 'This is test message')
        assert sys.stderr.getvalue() == messages.debug('This is test message') + '\n'

        settings.debug = False
        sys.stderr = io.StringIO()

        debug(lambda: 'This is test message')
        assert sys.stderr.getvalue() == ''
    finally:
        settings.debug = False
        sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:36:01.951841
# Unit test for function warn
def test_warn():
    from .helpers import CapturingOutput

    expected_message = "some message"
    with CapturingOutput(stderr=True) as capturer:
        warn(expected_message)
    assert capturer.stderr == "{}\n".format(messages.warn(expected_message))

# Generated at 2022-06-21 18:36:05.085735
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    capturedOutput = StringIO()
    sys.stderr = capturedOutput
    warn('test')
    sys.stderr = sys.__stderr__
    assert 'warn' in capturedOutput.getvalue()


# Generated at 2022-06-21 18:36:07.069813
# Unit test for function warn
def test_warn():
    assert (warn('test') == None)


# Generated at 2022-06-21 18:36:11.717209
# Unit test for function get_source
def test_get_source():
    def test_fn():
        return 3

    # For unknown reason on Python 3.7 we don't get expected source code. It's indented more than it seems to be.
    expected_source_lines = [
        'def test_fn():',
        '    return 3',
    ]
    assert get_source(test_fn).split('\n') == expected_source_lines

# Generated at 2022-06-21 18:36:15.448564
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    buf = StringIO()
    sys.stderr = buf
    msg = "Warning message"
    warn(msg)
    sys.stderr = sys.__stderr__
    assert buf.getvalue().strip() == msg


# Generated at 2022-06-21 18:36:18.006270
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test_v1 = VariablesGenerator()
    test_v2 = VariablesGenerator()

    if (test_v1 is not test_v2):
        pass
    else:
        raise AssertionError()
    return

# Generated at 2022-06-21 18:36:21.609524
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'

# Generated at 2022-06-21 18:36:23.744005
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1

    eager(test_fn)() == [1]

# Generated at 2022-06-21 18:38:10.753044
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest.mock import patch

    custom_message = 'custom_message'
    expected_output = messages.warn(custom_message) + '\n'
    stderr = 'py_backwards.utils.warn'

    with patch(stderr, new=StringIO()) as mocked_stderr:
        warn(custom_message)
        assert mocked_stderr.getvalue() == expected_output

# Generated at 2022-06-21 18:38:19.319685
# Unit test for function debug
def test_debug():
    class TraceMessage(Exception):
        def __init__(self, message: str) -> None:
            super().__init__(message)

    try:
        from contextlib import redirect_stderr
        from io import StringIO
        from testfixtures import LogCapture

        settings.debug = True

        with redirect_stderr(StringIO()) as output:
            with LogCapture() as log_capture:
                debug(lambda: raise_(TraceMessage('message')))

            output.seek(0)
            stderr = output.read()
            log_capture.check(('root', 'WARNING', 'Debug traceback:'), ('root', 'WARNING', 'message'))
            assert stderr == ''

        settings.debug = False
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:38:20.998665
# Unit test for function get_source
def test_get_source():
    def foo():
        return 42

    assert get_source(foo) == 'return 42'



# Generated at 2022-06-21 18:38:22.708378
# Unit test for function eager
def test_eager():
    g = (n for n in range(3))
    assert eager(g)() == [0, 1, 2]

# Generated at 2022-06-21 18:38:25.038814
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2

    assert foo() == [1, 2]

# Generated at 2022-06-21 18:38:28.823377
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('%s') == '_py_backwards_%s_0'
    assert VariablesGenerator.generate('%s') == '_py_backwards_%s_1'
    assert VariablesGenerator.generate('%s') == '_py_backwards_%s_2'

# Generated at 2022-06-21 18:38:32.412555
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'

# Generated at 2022-06-21 18:38:44.181624
# Unit test for function debug
def test_debug():
    global settings, messages
    import pytest
    from io import StringIO
    from pprint import pformat
    from ..conf import Settings, Messages
    from . import run

    test_settings = Settings(debug=True)
    test_messages = Messages()

    def set_vars():
        globals().update(
            settings=test_settings,
            messages=test_messages,
        )

    def unset_vars():
        del settings
        del messages

    class StderrPrinter:

        def __enter__(self):
            self.stderr = sys.stderr
            self.printed = StringIO()
            sys.stderr = self.printed

        def __exit__(self, exception_type, exception_value, traceback):
            sys.stderr = self.stderr

       

# Generated at 2022-06-21 18:38:47.260919
# Unit test for function eager
def test_eager():
    def f(x):
        for i in range(x):
            yield i

    assert eager(f)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:38:49.956363
# Unit test for function get_source
def test_get_source():
    def func(): pass
    assert get_source(func) == 'def func(): pass'