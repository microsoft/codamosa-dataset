

# Generated at 2022-06-21 18:30:58.161820
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == list(range(10))

# Generated at 2022-06-21 18:30:59.127553
# Unit test for function get_source
def test_get_source():
    def func():
        def bar():
            pass

    assert 'def bar():' in get_source(func)

# Generated at 2022-06-21 18:31:03.491700
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == \
        "    source_lines = getsource(fn).split('\\n')\n" + \
        "    padding = len(re.findall(r'^(\\s*)', source_lines[0])[0])\n" + \
        "    return '\\n'.join(line[padding:] for line in source_lines)"

# Generated at 2022-06-21 18:31:08.890884
# Unit test for function eager
def test_eager():
    def foo(numbers: Iterable[int]) -> Iterable[int]:
        for num in numbers:
            if num > 5:
                yield num

    assert foo([1, 2, 3, 4, 5, 6, 7]) == [6, 7]
    assert foo(eager([1, 2, 3, 4, 5, 6, 7])) == [6, 7]

# Generated at 2022-06-21 18:31:13.033385
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'



# Generated at 2022-06-21 18:31:15.537299
# Unit test for function get_source
def test_get_source():
    def test_func():
        """
        Function test_func.
        """
        return None
    assert get_source(test_func) == \
        'def test_func():\n    """\n    Function test_func.\n    """\n    return None\n'

# Generated at 2022-06-21 18:31:17.454779
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> Iterable[int]:
        yield 1

    assert gen() == [1]

# Generated at 2022-06-21 18:31:23.136179
# Unit test for function get_source
def test_get_source():
    def func1():
        pass
    assert get_source(func1) == 'def func1():\n    pass'

    def func2():
        x = 'x'
        y = 'y'
    assert get_source(func2) == 'def func2():\n    x = \'x\'\n    y = \'y\''

# Generated at 2022-06-21 18:31:26.117708
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'



# Generated at 2022-06-21 18:31:31.934670
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'
    assert VariablesGenerator.generate('z') == '_py_backwards_z_3'

# Generated at 2022-06-21 18:31:43.053927
# Unit test for function get_source
def test_get_source():
    def fn1(x):
        return x + 1

    assert get_source(fn1) == 'return x + 1'

    def fn2(x, y=1):
        with open('file.txt') as f:
            data = f.read()
            for line in data.split('\n'):
                if 'py_backwards' in line:
                    return line
                else:
                    pass

    assert get_source(fn2) == '\n    with open(\'file.txt\') as f:\n        data = f.read()\n        for line in data.split(\'\\n\'):\n            if \'py_backwards\' in line:\n                return line\n            else:\n                pass'

# Generated at 2022-06-21 18:31:45.990646
# Unit test for function warn
def test_warn():
    _ = messages.warn
    assert _('Hello') == '\033[0;33mWarning: \033[0mHello'
    assert _('No color', colored=False) == 'Warning: No color'



# Generated at 2022-06-21 18:31:47.110634
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]

# Generated at 2022-06-21 18:31:51.608801
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var, var_gen = VariablesGenerator(), VariablesGenerator()
    first_var = var.generate('first_var')
    second_var = var_gen.generate('second_var')
    assert first_var == '_py_backwards_first_var_0'
    assert second_var == '_py_backwards_second_var_1'
    assert first_var != second_var


if __name__ == '__main__':
    test_VariablesGenerator()
    print('tests passed')

# Generated at 2022-06-21 18:31:57.247020
# Unit test for function warn
def test_warn():
    from io import StringIO
    try:
        old_stderr = sys.stderr
        out = StringIO()
        sys.stderr = out
        warn("Test")
        assert "Test" in out.getvalue()
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-21 18:32:01.153536
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('b')

# Generated at 2022-06-21 18:32:04.180591
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'

# Generated at 2022-06-21 18:32:08.011379
# Unit test for function warn
def test_warn():
    import io
    import contextlib

    with contextlib.redirect_stderr(io.StringIO()) as stderr:
        warn('hello world')
        content = stderr.getvalue()
    assert content == messages.warn('hello world') + '\n'


# Generated at 2022-06-21 18:32:10.718709
# Unit test for function get_source
def test_get_source():
    def some_function():
        return 1

    assert 'return 1' == get_source(some_function).split('\n')[1].strip()

# Generated at 2022-06-21 18:32:11.660683
# Unit test for function warn
def test_warn():
    pass


# Generated at 2022-06-21 18:32:17.119864
# Unit test for function debug
def test_debug():
    def non_debug_message():
        debug(get_message)
        return 1
    def get_message():
        return 'test'

    def debug_message():
        debug(get_message)
        return 1

    assert non_debug_message() == 1
    assert debug_message() == 1

# Generated at 2022-06-21 18:32:21.327212
# Unit test for function eager
def test_eager():
    def test_func(list_):
        for item in list_:
            yield item
    list_test = [1, 2, 3, 4]
    list_result = eager(test_func)(list_test)
    assert list_test == list_result



# Generated at 2022-06-21 18:32:25.824506
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    code_lines = get_source(foo).split('\n')
    assert code_lines == ['def foo():', '    pass']


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:32:32.916793
# Unit test for function debug
def test_debug():
    settings.debug = True
    count = 1
    def get_message():
        nonlocal count
        count += 1
        return 'debug message #' + str(count)

    # Test when debug mode is on
    assert count == 1
    debug(get_message)
    assert count == 2
    debug(lambda: 'debug message #' + str(count))
    assert count == 3

    # Test when debug mode is off
    settings.debug = False
    assert count == 3
    debug(get_message)
    assert count == 3

# Generated at 2022-06-21 18:32:34.510394
# Unit test for function debug
def test_debug():
    settings.debug = True
    messages.debug = lambda msg: msg
    assert 'foo' in debug(lambda: 'foo')

# Generated at 2022-06-21 18:32:41.835610
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar(baz: int) -> str:
        return baz

    def qux(foo, bar):
        """Qux"""
        pass

    assert get_source(foo) == 'def foo():\npass'
    assert get_source(bar) == 'def bar(baz: int) -> str:\n    return baz'
    assert get_source(qux) == 'def qux(foo, bar):\n    """Qux"""\n    pass'

# Generated at 2022-06-21 18:32:43.375695
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():\n    pass\n'

# Generated at 2022-06-21 18:32:46.517627
# Unit test for function debug
def test_debug():
    # function get_message never called
    debug(lambda: 'DEBUG')
    # debug mode is set
    settings.debug = True
    # function get_message called
    debug(lambda: 'DEBUG')

# Generated at 2022-06-21 18:32:52.582628
# Unit test for function get_source
def test_get_source():
    def decorated():
        def foo():
            return 1 + 1
        foo()
    if decorated.__doc__ is not None:
        decorated.__doc__ += '\n'
    assert get_source(decorated) == decorated.__doc__ + '    def foo():\n        return 1 + 1\n    foo()'

# Generated at 2022-06-21 18:32:55.265860
# Unit test for function get_source
def test_get_source():
    @wraps(test_get_source)
    def foo():
        return "bar"

    assert get_source(foo) == "    return \"bar\""



# Generated at 2022-06-21 18:33:01.898750
# Unit test for function get_source
def test_get_source():
    def function():
        return 1

    assert get_source(function) == 'return 1'



# Generated at 2022-06-21 18:33:04.106659
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass

    assert get_source(some_function) == 'def some_function():\n    pass'

# Generated at 2022-06-21 18:33:05.724897
# Unit test for function debug
def test_debug():
    assert settings.debug
    messages.debug('hello')



# Generated at 2022-06-21 18:33:14.845091
# Unit test for function warn
def test_warn():
    import sys
    from contextlib import contextmanager, redirect_stdout, redirect_stderr
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn("This is a warning message.")
    output = err.getvalue().strip()


# Generated at 2022-06-21 18:33:17.797646
# Unit test for function warn
def test_warn():
    import sys
    import io
    sys.stderr = io.StringIO()
    debug('test')
    stderr_value = sys.stderr.getvalue()
    assert stderr_value.startswith("\033[93mDEBUG\033[0m")
    sys.stderr = sys.__stderr__
    print(stderr_value)

# Generated at 2022-06-21 18:33:18.520678
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-21 18:33:19.684188
# Unit test for function debug
def test_debug():
    assert debug(lambda: '') is None



# Generated at 2022-06-21 18:33:23.248652
# Unit test for function warn
def test_warn():
    warn('test')
    try:
        assert 'test' in sys.stderr.getvalue()
    finally:
        sys.stderr.close()


# Generated at 2022-06-21 18:33:25.400689
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == r'''
assert get_source(test_get_source) == r'''



# Generated at 2022-06-21 18:33:29.593178
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .conf import settings

    def get_message():
        return '%s' % 'something'

    try:
        settings.debug = True
        with StringIO() as stream:
            sys.stderr = stream
            debug(get_message)
            assert stream.getvalue().startswith('\x1b[35m')
            assert 'something' in stream.getvalue()
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:33:38.144114
# Unit test for function warn
def test_warn():
    output = io.StringIO() if sys.version_info >= (3, 0) else io.BytesIO()
    with contextlib.redirect_stderr(output):
        warn('Warning detected')
    output = output.getvalue()
    assert output == messages.warn('Warning detected')


# Generated at 2022-06-21 18:33:41.582240
# Unit test for function debug
def test_debug():
    def test_func():
        settings.debug = True
        debug(lambda: 'message')
        settings.debug = False
        debug(lambda: 'message')

    test_func()



# Generated at 2022-06-21 18:33:43.143503
# Unit test for function get_source
def test_get_source():
    def test_fn():
        # We want to indent lines of the function
        # to test how function get_source works.
        pass

    assert get_source(test_fn) == 'def test_fn():\n    pass'

# Generated at 2022-06-21 18:33:44.074668
# Unit test for function warn
def test_warn():
    warn('hello')



# Generated at 2022-06-21 18:33:46.692321
# Unit test for function get_source
def test_get_source():
    def my_function():
        return '42'

    source = get_source(my_function)
    assert source == 'return \'42\''

# Generated at 2022-06-21 18:33:51.951831
# Unit test for function warn
def test_warn():
    import sys
    import io

    def test_function():
        # Set up a mock stream
        sys.stderr = io.StringIO()

        # Call the function
        warn('test message')

        # Get the output
        output = sys.stderr.getvalue()
        assert output == 'test message\n'

    test_function()

# Generated at 2022-06-21 18:33:57.767280
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    assert get_source(function) == "def function():\n    pass"

    def function(a, b):
        pass
    assert get_source(function) == "def function(a, b):\n    pass"

    def function(  a, b):
        x = 0
        y = 1
    assert get_source(function) == """def function(  a, b):
    x = 0
    y = 1"""

# Generated at 2022-06-21 18:33:58.817850
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello')

# Generated at 2022-06-21 18:34:02.225537
# Unit test for function warn
def test_warn():
    warnings = []

    def patch(message):
        warnings.append(message)

    sys.stderr.write = patch
    warn("test")
    assert warnings == ["test"]



# Generated at 2022-06-21 18:34:04.847842
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug_text = '123'
    debug(lambda: debug_text)
    settings.debug = False
    debug(lambda: debug_text)

# Generated at 2022-06-21 18:34:19.358292
# Unit test for function warn
def test_warn():
    import tempfile
    from io import TextIOWrapper
    from typing import Any, TypeVar
    T = TypeVar('T')
    with tempfile.TemporaryFile() as temp:
        warn('test')
        temp.seek(0)
        assert temp.read().decode() == '\x1b[90mtest\x1b[0m\n'
    assert warn.__wrapped__ == print  # pylint: disable=no-member



# Generated at 2022-06-21 18:34:21.204788
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello, world!')

# Generated at 2022-06-21 18:34:27.465993
# Unit test for function get_source
def test_get_source():
    indent = lambda s: '\n'.join(' ' * 4 + l for l in s.split('\n'))
    def fn():
        pass
    assert get_source(fn) == 'pass'
    def fn():
        x = 1
        y = 2
        z = 3
        return x, y, z
    assert get_source(fn) == indent('''
        x = 1
        y = 2
        z = 3
        return x, y, z''')

# Generated at 2022-06-21 18:34:30.041937
# Unit test for function eager
def test_eager():
    from .test_functions import generator

    g = [generator()]
    eager_generator = eager(generator)
    assert eager_generator() == g
    assert eager_generator() is not g

# Generated at 2022-06-21 18:34:33.307595
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '@wraps(fn)\ndef wrapped(*args: Any, **kwargs: Any) -> List[T]:\n    return list(fn(*args, **kwargs))'


# Generated at 2022-06-21 18:34:35.218010
# Unit test for function get_source
def test_get_source():
    def func(a):
        print(a)

    assert get_source(func) == "print(a)"



# Generated at 2022-06-21 18:34:36.924501
# Unit test for function get_source
def test_get_source():
    import ast

# Generated at 2022-06-21 18:34:44.570803
# Unit test for function debug
def test_debug():
    import pytest

    class FakeStream(object):
        def __init__(self):
            self.last_message = None

        def write(self, message):
            self.last_message = message

    sys.stderr = FakeStream()
    debug(lambda: "test message")
    assert sys.stderr.last_message == "WARNING: DeprecationWarning: test message"

    warn("test message")
    assert sys.stderr.last_message == "WARNING: DeprecationWarning: test message"


test_debug()

# Generated at 2022-06-21 18:34:48.640776
# Unit test for function warn
def test_warn():
    import io
    import contextlib
    f = io.StringIO()
    with contextlib.redirect_stderr(f):
        warn("test error message")
    assert f.getvalue() == "test error message\n"

# Generated at 2022-06-21 18:34:53.582838
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    g = VariablesGenerator()
    assert g.generate('abc') == '_py_backwards_abc_0'
    assert g.generate('def') == '_py_backwards_def_1'
    assert g.generate('def') == '_py_backwards_def_2'
    assert g.generate('abc') == '_py_backwards_abc_3'

# Generated at 2022-06-21 18:35:18.234291
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    name1 = VariablesGenerator.generate('a')
    assert name1 == '_py_backwards_a_0'
    name2 = VariablesGenerator.generate('b')
    assert name2 == '_py_backwards_b_1'
    assert name1 != name2


# Generated at 2022-06-21 18:35:27.546425
# Unit test for function debug
def test_debug():
    import io
    import sys

    buffer = io.StringIO()

    class Stderr(dict):  # type: ignore
        def __getitem__(self, key):
            if key == 'stderr':
                return buffer
            else:
                return super(Stderr, self).__getitem__(key)


# Generated at 2022-06-21 18:35:34.470379
# Unit test for function debug
def test_debug():
    def assert_print(expected, *args, **kwargs):
        with patch('sys.stderr') as mock_stderr:
            debug(*args, **kwargs)
            mock_stderr.write.assert_called_once_with(expected)
    assert_print(b'[DEBUG] msg\n', lambda: 'msg')
    with patch('py_backwards.conf.settings.debug', False):
        assert_print(b'', lambda: 'msg')



# Generated at 2022-06-21 18:35:38.402252
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('c') == '_py_backwards_c_2'


# Generated at 2022-06-21 18:35:45.044888
# Unit test for function get_source
def test_get_source():
    def func():
        a = 0
        return a + 1
    assert get_source(func) == 'a = 0\nreturn a + 1'
    assert get_source(test_get_source) == 'def test_get_source():\n    def func():\n        a = 0\n        return a + 1\n    assert get_source(func) == \'a = 0\\nreturn a + 1\''

# Generated at 2022-06-21 18:35:47.602531
# Unit test for function eager
def test_eager():
    def evil() -> Iterator[str]:
        count = 0
        while True:
            count += 1
            yield count
    assert eager(evil)() == []

# Generated at 2022-06-21 18:35:56.193954
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings
    settings.debug = True

    message = 'This is a test'
    out = StringIO()
    sys.stderr = out
    debug(lambda: message)

    out.seek(0)
    assert out.read() == '{} {}'.format(settings.debug_prefix, message) + '\n'

    # Reset sys.stderr
    sys.stderr = sys.__stderr__
    settings.debug = False

# Generated at 2022-06-21 18:35:58.338825
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from .test_structures import variables_generator
    assert variables_generator._counter == 1


# Generated at 2022-06-21 18:36:02.534751
# Unit test for function warn
def test_warn():
    import sys
    sys.stderr = open('stderr.txt', 'wt', encoding='utf-8')
    warn('test warn')
    sys.stderr.close()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:36:04.968808
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    g1 = VariablesGenerator()
    g2 = VariablesGenerator()
    assert g1 != g2
    
    

# Generated at 2022-06-21 18:36:55.966032
# Unit test for function debug
def test_debug():
    msg = 'hi'

    def get_message():
        return msg

    debug(get_message)



# Generated at 2022-06-21 18:37:07.365590
# Unit test for function debug
def test_debug():
    if 'pytest' not in sys.modules:
        return

    def test_get_message():
        return 'test'

    class StdoutMocker:

        def __init__(self):
            self.content = []

        def write(self, content):
            self.content.append(content)

        def flush(self):
            pass

        def __exit__(self, exc_type, exc_val, exc_tb):
            sys.stdout = sys.__stdout__

    with StdoutMocker() as mocker:
        deactivate = settings.debug
        settings.debug = True
        sys.stdout = mocker
        debug(test_get_message)
        settings.debug = deactivate

# Generated at 2022-06-21 18:37:08.294697
# Unit test for function warn
def test_warn():
    warn("Warning")


# Generated at 2022-06-21 18:37:19.258090
# Unit test for function get_source

# Generated at 2022-06-21 18:37:23.549277
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate("x") == '_py_backwards_x_0'
    assert vg.generate("x") == '_py_backwards_x_1'
    assert vg.generate("x") == '_py_backwards_x_2'

# Generated at 2022-06-21 18:37:26.958330
# Unit test for function get_source
def test_get_source():
    def foo(x: int) -> int:
        return x + 2
    assert get_source(foo) == dedent('''
        return x + 2
    ''')

# Generated at 2022-06-21 18:37:29.196705
# Unit test for function warn
def test_warn():
    import contextlib

    with contextlib.redirect_stdout(sys.stderr):
        warn('warning message')
        assert True

# Generated at 2022-06-21 18:37:34.465801
# Unit test for function get_source
def test_get_source():
    def test():
        """
        Test function to test the get_source function
        """
        print('py-backwards test')

    source = get_source(test)
    source_lines = source.split('\n')
    expected_lines = ['def test():', '    """', '    Test function to test the get_source function', '    """',
                      '    print(\'py-backwards test\')']
    assert source_lines == expected_lines

# Generated at 2022-06-21 18:37:36.982356
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate("a") == '_py_backwards_a_0'
    assert vg.generate("b") == '_py_backwards_b_1'

# Generated at 2022-06-21 18:37:47.376316
# Unit test for function debug
def test_debug():
    def get_message_triple_quote():
        """Returns message with triple quotes"""
        return '''
        something
        '''
    def get_message_no_triple_quote():
        return '''something'''
    class C:
        def get_message_triple_quote(self):
            """Returns message with triple quotes"""
            return '''
            something
            '''
        def get_message_no_triple_quote(self):
            return '''something'''
    c = C()

    # noinspection PyUnusedLocal
    debug_triple_quote_inside = debug(get_message_triple_quote)
    # noinspection PyUnusedLocal
    debug_no_triple_quote_inside = debug(get_message_no_triple_quote)
    # noinspection Py

# Generated at 2022-06-21 18:39:45.184702
# Unit test for function eager
def test_eager():
    @eager
    def gen_nums():
        yield 1
        yield 2
        yield 3

    assert gen_nums() == [1, 2, 3]



# Generated at 2022-06-21 18:39:47.257236
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(3):
            yield i

    assert [0, 1, 2] == eager(foo)()



# Generated at 2022-06-21 18:39:48.479322
# Unit test for function warn
def test_warn():
    def fn():
        warn("Test message")
    fn()



# Generated at 2022-06-21 18:39:49.890070
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert set(VariablesGenerator.generate('var') for _ in range(60)) == \
        {'_py_backwards_var_' + str(i) for i in range(60)}


# Generated at 2022-06-21 18:39:53.374020
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn("Hello World")
    assert("Warning: Hello World" in sys.stderr.getvalue())
    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:39:57.571740
# Unit test for function get_source
def test_get_source():
    def foo(one: int, two: int) -> int:
        return one + two
    assert get_source(foo) == ['def foo(one: int, two: int) -> int:',
                               '    return one + two']
    assert get_source(foo) != ['def foo(one: int, two: int) -> int:',
                               '    return one + two', 'something']

# Generated at 2022-06-21 18:40:03.242299
# Unit test for function debug
def test_debug():
    from .util import silent
    assert silent(debug)(lambda: 'test') == ''
    settings.debug = True
    assert silent(debug)(lambda: 'test') == '[DEBUG] test\n'
    settings.debug = False
    assert silent(debug)(lambda: 'test') == ''



# Generated at 2022-06-21 18:40:04.922728
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    VG = VariablesGenerator
    assert VG._counter == 0
    VG.generate('a')
    assert VG._counter == 1
    VG.generate('a')
    assert VG._counter == 2
    VG._counter = 0

# Generated at 2022-06-21 18:40:06.859792
# Unit test for function get_source
def test_get_source():
    def my_func():
        print(1 + 2)
    assert get_source(my_func) == 'print(1 + 2)'



# Generated at 2022-06-21 18:40:11.216703
# Unit test for function warn
def test_warn():
    def fn():
        return (lambda x: x * x)(10)

    debug(lambda: "Debug message")
    assert 'x * x' in get_source(fn)
    assert '_py_backwards' in VariablesGenerator.generate('val')
    assert VariablesGenerator.generate('val') != VariablesGenerator.generate('val')