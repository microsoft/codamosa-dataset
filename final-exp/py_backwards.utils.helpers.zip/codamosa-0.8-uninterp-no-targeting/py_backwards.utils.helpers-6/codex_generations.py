

# Generated at 2022-06-21 18:30:59.359911
# Unit test for function eager
def test_eager():
    def foo():
        return map(lambda x: x ** 2, range(3))
    assert list(foo()) == eager(foo)()

# Generated at 2022-06-21 18:31:03.116838
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    sys.stderr = StringIO()
    warn('some important message')
    assert sys.stderr.getvalue().strip() == 'some important message'


if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-21 18:31:03.851624
# Unit test for function warn
def test_warn():
    warn("A message")

# Generated at 2022-06-21 18:31:06.262753
# Unit test for function eager
def test_eager():
    @eager
    def test(*args):
        return sum(args)

    assert test(1, 2, 3) == [6]

# Generated at 2022-06-21 18:31:12.211980
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator._counter == 1
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator._counter == 2
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'
    assert VariablesGenerator._counter == 3

# Generated at 2022-06-21 18:31:15.649106
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-21 18:31:23.780667
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    result = [VariablesGenerator.generate("variable") for _ in range(9)]
    assert result == ["_py_backwards_variable_0", "_py_backwards_variable_1",
                      "_py_backwards_variable_2", "_py_backwards_variable_3",
                      "_py_backwards_variable_4", "_py_backwards_variable_5",
                      "_py_backwards_variable_6", "_py_backwards_variable_7",
                      "_py_backwards_variable_8"]



# Generated at 2022-06-21 18:31:24.746231
# Unit test for function get_source
def test_get_source():
    def test():
        x = 10

    assert get_source(test) == 'x = 10'

# Generated at 2022-06-21 18:31:27.180556
# Unit test for function get_source
def test_get_source():
    def test_func():
        """returns `2`"""
        return 2

    assert get_source(test_func) == 'return 2'

# Generated at 2022-06-21 18:31:30.385374
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("test") == "_py_backwards_test_0"
    assert VariablesGenerator.generate("test") == "_py_backwards_test_1"

# Generated at 2022-06-21 18:31:36.195767
# Unit test for function debug
def test_debug():
    debug_history = []
    def get_message():
        dg = 'debug message'
        debug_history.append(dg)
        return dg
    debug(get_message)
    assert debug_history == ['debug message']

# Generated at 2022-06-21 18:31:44.521110
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from contextlib import contextmanager
    @contextmanager
    def test_mode():
        sys.stderr, old_stderr = StringIO(), sys.stderr
        try:
            yield
        finally:
            sys.stderr = old_stderr
    with test_mode():
        debug(lambda: 'Hello')
        assert sys.stderr.getvalue() == ''
    with test_mode():
        settings.debug = True
        debug(lambda: 'Hello')
        settings.debug = False
        assert sys.stderr.getvalue().endswith('Hello\n')


# Generated at 2022-06-21 18:31:46.316816
# Unit test for function get_source
def test_get_source():
    assert get_source(lambda x: x) == 'x'



# Generated at 2022-06-21 18:31:49.057561
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            return 42
        return bar()

    assert get_source(foo) == 'return bar()'

# Generated at 2022-06-21 18:31:53.274816
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-21 18:32:05.352700
# Unit test for function warn
def test_warn():
    from io import StringIO
    output = StringIO()

# Generated at 2022-06-21 18:32:07.346945
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
        yield 2
        yield 3

    assert [1, 2, 3] == generator()

# Generated at 2022-06-21 18:32:12.250331
# Unit test for function debug
def test_debug():
    debug_message = "Debug test"
    # Expect the debug message to be printed with log level DEBUG
    assert debug(lambda: debug_message) == "[DEBUG] Debug test"
    # Expect no debug message even if debug is set to True
    settings.debug = True
    assert debug(lambda: debug_message) is None
    # Reset the debug value
    settings.debug = False


# Generated at 2022-06-21 18:32:16.217341
# Unit test for function get_source
def test_get_source():
    class Class:
        def __init__(self) -> None:
            self.field = 1

        def function(self, arg1, arg2):
            pass

    expected = 'def function(self, arg1, arg2):\n    pass'
    assert get_source(Class().function) == expected

# Generated at 2022-06-21 18:32:22.945088
# Unit test for function debug
def test_debug():
    from .test_utils import capture_stderr
    from .. import conf
    conf.debug = True

    with capture_stderr() as stderr:
        debug(lambda: 'foobar')
    assert 'DEBUG' in stderr.getvalue()
    assert 'foobar' in stderr.getvalue()

    conf.debug = False

    with capture_stderr() as stderr:
        debug(lambda: 'foobar')
    assert not stderr.getvalue()

# Generated at 2022-06-21 18:32:27.455707
# Unit test for function get_source
def test_get_source():
    def function():
        if 1:
            pass
    assert get_source(function) == 'if 1:\n    pass'


# Generated at 2022-06-21 18:32:31.741321
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """Tests VariablesGenerator."""
    assert(VariablesGenerator.generate("a") == '_py_backwards_a_0')
    assert(VariablesGenerator.generate("a") == '_py_backwards_a_1')

# test_get_source

# Generated at 2022-06-21 18:32:35.094378
# Unit test for function debug
def test_debug():
    called = False
    def get_message():
        nonlocal called
        called = True
        return "test"
    debug(get_message)
    assert not called
    settings.debug = True
    debug(get_message)
    assert called

# Generated at 2022-06-21 18:32:38.782895
# Unit test for function warn
def test_warn():
    with patch("sys.stderr", new=StringIO()) as stderr_fixture:
        warn("some message")
    assert stderr_fixture.getvalue() == "warn: some message\n"


# Generated at 2022-06-21 18:32:44.857936
# Unit test for function debug
def test_debug():
    sys_stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        debug(lambda: 'debug message')

        assert sys.stderr.getvalue() == '\n'
        settings.debug = True
        debug(lambda: 'debug message')
        assert sys.stderr.getvalue() == '\n{}\n'.format(messages.debug('debug message'))
    finally:
        sys.stderr = sys_stderr

# Generated at 2022-06-21 18:32:48.663094
# Unit test for function eager
def test_eager():
    assert eager(lambda x: x)(10) == 10
    assert eager(lambda x: [i for i in range(x)])(10) == [i for i in range(10)]

# Generated at 2022-06-21 18:32:51.038662
# Unit test for function debug
def test_debug():
    result = []

    def get_message():
        result.append('abc')
        return 'something'

    debug(get_message)
    assert not result

# Generated at 2022-06-21 18:32:54.821802
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('_m')=='_py_backwards__m_0'
    assert VariablesGenerator.generate('_m')=='_py_backwards__m_1'

# Generated at 2022-06-21 18:32:57.546792
# Unit test for function get_source
def test_get_source():
    """Tests for function get_source."""
    def foo(x: int) -> int:
        return x + 1

    assert get_source(foo) == "\n    return x + 1"

# Generated at 2022-06-21 18:33:08.624869
# Unit test for function debug
def test_debug():
    def _test_debug(debug):
        def _assert_message(message):
            assert message == 'Hello, debug!'

        debug(_assert_message)

    from contextlib import contextmanager
    from io import StringIO
    from unittest import TestCase
    from .conf import settings

    class TestDebug(TestCase):
        @contextmanager
        def _temp_stdout(self):
            save_stdout = sys.stdout
            s = StringIO()
            sys.stdout = s
            yield
            self.assertEqual(sys.stdout, s)
            sys.stdout = save_stdout

        @contextmanager
        def _temp_settings(self, **kwargs):
            save_settings = settings
            settings = type('Settings', (object,), kwargs)
            yield
            settings = save_

# Generated at 2022-06-21 18:33:13.844727
# Unit test for function warn
def test_warn():
    import io
    import sys
    from . import messages

    stream = io.StringIO()
    sys.stderr = stream
    warn('message')

    assert stream.getvalue() == messages.warn('message') + '\n'



# Generated at 2022-06-21 18:33:15.258418
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert len(set(VariablesGenerator.generate('variable_name') for _ in range(10))) == 10

# Generated at 2022-06-21 18:33:18.134179
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-21 18:33:23.102782
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: x
    settings.debug = True
    print(debug(lambda: 'Hello {name}!'.format(name='world')))
    settings.debug = False
    print(debug(lambda: 'Hello {name}!'.format(name='world')))

# Generated at 2022-06-21 18:33:29.675257
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn('foo')
    assert err.getvalue().strip() == 'Warning: foo'



# Generated at 2022-06-21 18:33:30.901334
# Unit test for function debug
def test_debug():
    test_str = 'test_str'
    def get_message():
        return test_str
    debug(get_message)


# Generated at 2022-06-21 18:33:34.204974
# Unit test for function eager
def test_eager():
    assert eager(lambda: (x for x in range(5)))(
    ) == [0, 1, 2, 3, 4]



# Generated at 2022-06-21 18:33:35.804879
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False

# Generated at 2022-06-21 18:33:39.720797
# Unit test for function warn
def test_warn():
    global test_warn_is_called
    test_warn_is_called = False
    def test():
        global test_warn_is_called
        test_warn_is_called = True
        warn('Warning')
    test()
    assert test_warn_is_called



# Generated at 2022-06-21 18:33:40.232361
# Unit test for function warn
def test_warn():
    assert warn('test warning') == None

# Generated at 2022-06-21 18:33:47.350163
# Unit test for function get_source
def test_get_source():
    def foo():
        return 2

    def bar():
        return 3

    assert get_source(foo) == 'return 2'
    assert get_source(bar) == 'return 3'

# Generated at 2022-06-21 18:33:50.724282
# Unit test for function eager
def test_eager():
    def function() -> Iterable[int]:
        for i in range(10):
            yield i

    assert eager(fn=function)() == list(range(10))

# Generated at 2022-06-21 18:33:56.796178
# Unit test for function get_source

# Generated at 2022-06-21 18:33:58.477743
# Unit test for function get_source
def test_get_source():
    def foo():
        return 4

    assert get_source(foo) == "return 4"

# Generated at 2022-06-21 18:34:00.203710
# Unit test for function eager
def test_eager():
    l = [1,2,3]
    assert eager(lambda: l)() == l

# Generated at 2022-06-21 18:34:05.821232
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'


# Generated at 2022-06-21 18:34:11.358489
# Unit test for function get_source
def test_get_source():
    def function(a, b, c):
        pass
    assert get_source(function) == 'def function(a, b, c):\n    pass'

    def function(a, b, c):
        return None
    assert get_source(function) == 'def function(a, b, c):\n    return None'



# Generated at 2022-06-21 18:34:15.702352
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'


# Generated at 2022-06-21 18:34:17.276656
# Unit test for function get_source
def test_get_source():
    def fn():
        x = 1

    assert get_source(fn) == '\n    x = 1'

# Generated at 2022-06-21 18:34:19.440908
# Unit test for function get_source
def test_get_source():
    def f():
        a = 1
        b = 2

    assert get_source(f) == 'a = 1\nb = 2'

# Generated at 2022-06-21 18:34:34.732546
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    from contextlib import redirect_stderr

    def test():
        string = StringIO()
        with redirect_stderr(string):
            debug(lambda: 'Debugging')

        assert string.getvalue() == ''

        string = StringIO()
        with redirect_stderr(string):
            debug(lambda: 'Debugging')

        assert string.getvalue() == 'py_backwards: DEBUG: Debugging\n'

        with pytest.raises(TypeError):
            debug('Not a function!')

# Generated at 2022-06-21 18:34:40.499841
# Unit test for function warn
def test_warn():
    from py_backwards.conf import settings
    from io import StringIO
    import sys
    import warnings

    buffer = StringIO()
    settings.color = False
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        warn("test")
        assert buffer.getvalue() == "test\n"



# Generated at 2022-06-21 18:34:45.059985
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    old_stderr = sys.stderr
    sys.stderr = buffer = StringIO()

    try:
        debug(lambda: "This is a test message")
        assert buffer.getvalue() == messages.debug("This is a test message") + '\n'

    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-21 18:34:48.731007
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'



# Generated at 2022-06-21 18:34:55.559103
# Unit test for function debug
def test_debug():
    import sys
    import io

    @debug
    def test():
        return 'hello from test function'

    sys.stderr = stderr = io.StringIO()
    debug(lambda: 'hello from test function')()
    assert stderr.getvalue() == ''

    settings.debug = True

    debug(lambda: 'hello from test function')()
    assert stderr.getvalue() == 'hello from test function\n'

    try:
        test()
        assert False
    except TypeError:
        pass

    assert 'hello from test function\n' in stderr.getvalue()

# Generated at 2022-06-21 18:35:01.766728
# Unit test for function debug
def test_debug():
    messages.debug = lambda message: messages.frmt('DEBUG', message)
    settings.debug = True

    messages_list = []

    def mocked_print(*args, file=sys.stderr, **kwargs):
        messages_list.append(args)

    sys.stderr = MagicMock(wraps=StringIO())
    sys.stderr.write = mocked_print

    message = 'test'

    debug(lambda: message)

    assert len(messages_list) == 0

    settings.debug = False

    debug(lambda: message)

    assert len(messages_list) == 1
    assert messages_list[0][0] == messages.debug(message)
    sys.stderr.close()

# Generated at 2022-06-21 18:35:03.926528
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    b = VariablesGenerator.generate('a')
    assert a != b

# Generated at 2022-06-21 18:35:08.266995
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() is not foo()
    assert foo() == foo()

    assert eager(foo)() is not eager(foo)()
    assert eager(foo)() == eager(foo)()

# Generated at 2022-06-21 18:35:09.376272
# Unit test for function warn
def test_warn():
    warn('hello')


# Generated at 2022-06-21 18:35:11.339754
# Unit test for function debug
def test_debug():
    def generate_message():
        return "test"

    debug(generate_message)

# Generated at 2022-06-21 18:35:34.635776
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3
    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-21 18:35:41.184715
# Unit test for function eager
def test_eager():
    from ..utils import IntList

    @eager
    def add(xs: Iterable[int], ys: Iterable[int]) -> Iterable[int]:
        if isinstance(xs, IntList):
            print('xs is IntList')
        else:
            print('xs is not IntList')
        yield from (x + y for x, y in zip(xs, ys))

    xs = IntList([1, 2, 3])
    ys = [4, 5, 6]

    assert type(add(xs, ys)) is list

    if sys.version_info < (3, 0):
        assert not isinstance(add(xs, ys), IntList)
    else:
        assert isinstance(add(xs, ys), IntList)

# Generated at 2022-06-21 18:35:45.515554
# Unit test for function warn
def test_warn():
    test_warn.message = ''

    def get_message():
        test_warn.message = 'test'
        return test_warn.message

    warn(get_message())
    assert test_warn.message is not None

# Generated at 2022-06-21 18:35:49.729291
# Unit test for function debug
def test_debug():
    assert sys.stderr.write.call_args_list == []
    debug(lambda: 'hello')
    assert sys.stderr.write.call_args_list == []
    settings.debug = True
    debug(lambda: 'hello')
    assert sys.stderr.write.call_args_list == [call('[DEBUG] hello\n')]



# Generated at 2022-06-21 18:35:53.596583
# Unit test for function warn
def test_warn():
    import sys, io
    sys.stderr = io.StringIO()
    sys.stderr.truncate(0)
    warn('test_warn')
    assert 'test_warn' in sys.stderr.getvalue()



# Generated at 2022-06-21 18:35:56.676835
# Unit test for function debug
def test_debug():
    settings.debug = True
    def get_message():
        return "The message"
    debug(get_message)


# Generated at 2022-06-21 18:35:58.428598
# Unit test for function warn
def test_warn():
    messages.warn_messages = lambda : ''
    warn('test')
    #warn('test')


# Generated at 2022-06-21 18:36:08.070963
# Unit test for function get_source
def test_get_source():
    def sample(x: str):
        return x  # hello

    def sample1(x: str):
        return x  # hello

    def sample2(x: str):
        y = x
        return y  # hello

    def sample3(x: str):
        y = x

        return y  # hello

    assert get_source(sample) == 'return x  # hello'
    assert get_source(sample1) == 'return x  # hello'
    assert get_source(sample2) == 'y = x\nreturn y  # hello'
    assert get_source(sample3) == 'y = x\n\nreturn y  # hello'

# Generated at 2022-06-21 18:36:14.945817
# Unit test for function warn
def test_warn():
    class MockFile(object):
        def __init__(self):
            self.written = None

        def write(self, what):
            self.written = what

    mock_file = MockFile()
    mocked = 'py' in sys.modules
    if mocked:
        old_stderr = sys.stderr
    try:
        sys.stderr = mock_file
        warn("test")

        assert "test" == mock_file.written.strip()
    finally:
        if mocked:
            sys.stderr = old_stderr

# Generated at 2022-06-21 18:36:17.015143
# Unit test for function get_source
def test_get_source():
    test_var = 'test_variable'
    def test_function(var):
        return var

    assert get_source(test_function) == 'return var\n'

# Generated at 2022-06-21 18:37:08.625884
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-21 18:37:10.743208
# Unit test for function debug
def test_debug():
    def _debug(text):
        debug(lambda: text)
    _debug('hello')



# Generated at 2022-06-21 18:37:14.247205
# Unit test for function warn
def test_warn():
    with settings(capture_output=True):
        warn('I am warning you!')
    assert settings.output == messages.warn('I am warning you!') + '\n'



# Generated at 2022-06-21 18:37:15.881469
# Unit test for function get_source
def test_get_source():
    def foo(bar):
        return bar

    assert get_source(foo) == 'return bar'



# Generated at 2022-06-21 18:37:16.891684
# Unit test for function eager
def test_eager():
    assert eager(range)(1, 2) == [1]

# Generated at 2022-06-21 18:37:20.641661
# Unit test for function warn
def test_warn():
    warn("Testing warn function")
    user_input = input("Did you see a warning message just now? (yes/no)")
    if user_input == "yes":
        print("Test for warn function passed.")
    else:
        print("Test for warn function did not pass.")

# Generated at 2022-06-21 18:37:24.425853
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        return a + b

    assert get_source(fn) == (
        'def fn(a, b):\n'
        '    return a + b'
    )

# Generated at 2022-06-21 18:37:29.972634
# Unit test for function debug
def test_debug():
    out = io.StringIO()
    settings.debug = True

    @debug
    def get_msg():
        return 'Hello debug!'

    with replace_std_stream(out=out):
        get_msg()

    settings.debug = False
    assert out.getvalue() == messages.debug('Hello debug!') + '\n'



# Generated at 2022-06-21 18:37:36.230656
# Unit test for function get_source
def test_get_source():
    def foo():
        bar(1)

        def qux():
            pass

    source_lines_of_foo = []
    source_lines_of_foo.append('def foo():')
    source_lines_of_foo.append('    bar(1)')
    source_lines_of_foo.append('')
    source_lines_of_foo.append('    def qux():')
    source_lines_of_foo.append('        pass')
    assert get_source(foo) == '\n'.join(source_lines_of_foo)

# Generated at 2022-06-21 18:37:39.564540
# Unit test for function get_source
def test_get_source():
    def test(a, b):
        return a + b
    assert get_source(test) == "def test(a, b):\n    return a + b"


# Generated at 2022-06-21 18:39:35.846839
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'



# Generated at 2022-06-21 18:39:38.847754
# Unit test for function get_source
def test_get_source():
    def foo(A, b=0, *args, c='a', **kwargs):
        pass

    wanted = """def foo(A, b=0, *args, c='a', **kwargs):
    pass"""
    assert wanted == get_source(foo)



# Generated at 2022-06-21 18:39:43.069633
# Unit test for function warn
def test_warn():
    # Test if 'warn' function really prints to stderr
    import io
    import sys

    # Captures stderr
    stderr = io.StringIO()
    sys.stderr = stderr
    message = "Test string"
    warn(message)
    # Checks if we really captured message
    assert message in stderr.getvalue()
    # And if message is prepended with "PyBackwards warning!"
    assert stderr.getvalue().startswith("PyBackwards warning!")
    # Returns stderr to its original state
    sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:39:48.192095
# Unit test for function get_source
def test_get_source():
    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            print(fn(*args, **kwargs))
        return wrapper

    @decorator
    def test():
        return 'look at me!'

    assert get_source(test) == 'return "look at me!"'

# Generated at 2022-06-21 18:39:50.853098
# Unit test for function get_source
def test_get_source():
    def f(): pass
    assert get_source(f) == 'def f(): pass'
    val = 1
    assert get_source(val) == '1'



# Generated at 2022-06-21 18:39:53.695027
# Unit test for function get_source
def test_get_source():
    source = """def func(value):
    print(value)
    return value + 1"""
    assert get_source(func) == source

# Generated at 2022-06-21 18:39:54.551102
# Unit test for function warn
def test_warn():
    pass



# Generated at 2022-06-21 18:39:57.997054
# Unit test for function warn
def test_warn():
    import sys
    from io import StringIO
    out = StringIO()
    sys.stderr = out
    warn('test')
    sys.stderr = sys.__stderr__
    assert out.getvalue() == '\x1b[31mWarning: test\x1b[0m\n'


# Generated at 2022-06-21 18:40:07.957546
# Unit test for function debug
def test_debug():
    import unittest
    import re

    class TestDebug(unittest.TestCase):
        def test_debug_off(self):
            settings.debug = False
            x = []

            def log():
                x.append('logged')

            debug(log)

            self.assertEqual(len(x), 0)

        def test_debug_on(self):
            settings.debug = True
            x = []

            def log():
                x.append('logged')
                return 'info'

            debug(log)
            self.assertEqual(len(x), 1)
            self.assertRegex(x[0], re.compile(r'^\[DEBUG\] info$'))

    unittest.main()



# Generated at 2022-06-21 18:40:09.625339
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    '''
    # FIXME
    assert get_source(f) == 'def f():\n    pass'''

