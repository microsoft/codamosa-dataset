

# Generated at 2022-06-21 18:30:59.126191
# Unit test for function debug
def test_debug():
    try:
        settings.debug = True
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:31:05.702028
# Unit test for function debug
def test_debug():
    old = settings.debug

# Generated at 2022-06-21 18:31:08.454544
# Unit test for function get_source
def test_get_source():
    def dummy_function():
        # Some really useful code
        pass

    assert get_source(dummy_function) == '# Some really useful code\npass'

# Generated at 2022-06-21 18:31:14.169766
# Unit test for function warn
def test_warn():
    class MessageIO:
        def __init__(self):
            self._message = ''

        def getvalue(self):
            return self._message

        def write(self, message):
            self._message = self._message + message

    message_io = MessageIO()
    sys.stderr = message_io

    warn('test warn')
    assert message_io.getvalue() == messages.warn('test warn')

    sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:31:19.842858
# Unit test for function get_source
def test_get_source():
    """Test for source code retrieval."""

    def val() -> str:
        """Decorated function."""
        return 'val'

    def wrapped() -> str:
        """Another function."""
        return 'wrapped'

    assert get_source(val) == 'return "val"'
    assert get_source(wrapped) == 'return "wrapped"'

# Generated at 2022-06-21 18:31:22.214347
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test')=="_py_backwards_test_0"

# Generated at 2022-06-21 18:31:30.091956
# Unit test for function warn
def test_warn():
    import io
    import sys
    import unittest

    class TestWarn(unittest.TestCase):
        def setUp(self) -> None:
            self.stdout_ = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self) -> None:
            sys.stderr = self.stdout_

        def test_warn(self) -> None:
            warn('test')
            self.assertEqual(sys.stderr.getvalue(), 'test\n')

    unittest.main()

# Generated at 2022-06-21 18:31:32.809832
# Unit test for function eager
def test_eager():
    def test(value):
        yield 1
        yield 2
        yield value

    result = eager(test)(7)
    assert result == [1,2,7]

# Generated at 2022-06-21 18:31:38.006186
# Unit test for function debug
def test_debug():
    import io
    from .test_utils import patched_stderr

    with patched_stderr(io.StringIO()) as s:
        debug(lambda: 'Hello, world!')
        assert (
            s.getvalue() ==
            messages.debug({'message': 'Hello, world!'}).format(
                debug=settings.debug
            ) + '\n'
        )

# Generated at 2022-06-21 18:31:39.810960
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-21 18:31:43.285319
# Unit test for function eager
def test_eager():
    def a():
        yield 1

    assert eager(a)() == [1]

# Generated at 2022-06-21 18:31:46.804593
# Unit test for function warn
def test_warn():
    try:
        stderr = sys.stderr
        sys.stderr = StringIO()
        warn('test warning')
        assert sys.stderr.getvalue() == messages.warn('test warning') + '\n'
    finally:
        sys.stderr = stderr


# Generated at 2022-06-21 18:31:52.899822
# Unit test for function eager
def test_eager():
    from collections import Iterable

    # Test that the function works correctly
    @eager
    def zero_to_n(n: int) -> Iterable[int]:
        for i in range(n):
            yield 0

    assert zero_to_n(5) == [0, 0, 0, 0, 0]

    # Test that the function is decorated.
    from functools import partial
    from functools import WRAPPER_ASSIGNMENTS

    @eager
    def func():
        yield 1

    func.attr = 2

    wrapped = list(eager(func))[0]

    assert wrapped.attr == 2
    assert wrapped.__name__ == 'func'
    assert wrapped.__doc__ == func.__doc__


# Generated at 2022-06-21 18:31:56.517899
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    x = gen()
    assert x == [1, 2, 3]

# Generated at 2022-06-21 18:32:00.138872
# Unit test for function debug
def test_debug():
    settings.debug = True
    template = 'Internal error: {}.'
    try:
        raise Exception('Unknown')
    except Exception as e:
        debug(lambda: template.format(str(e)))



# Generated at 2022-06-21 18:32:03.359617
# Unit test for function eager
def test_eager():
    @eager
    def get_eager() -> Iterable[int]:
        for i in range(10):
            yield i

    assert get_eager() == list(range(10))


# Generated at 2022-06-21 18:32:04.945901
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "message")



# Generated at 2022-06-21 18:32:07.259013
# Unit test for function eager
def test_eager():

    @eager
    def foo(x):
        for i in range(x):
            yield i

    assert foo(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:32:10.673902
# Unit test for function warn
def test_warn():
    stdout = StringIO()
    with patch('sys.stderr', stdout):
        warn('foo')
    assert stdout.getvalue() == '\x1b[93m\u26a0\x1b[0m foo\n'

# Generated at 2022-06-21 18:32:11.616603
# Unit test for function warn
def test_warn():
    pass


# Generated at 2022-06-21 18:32:16.450746
# Unit test for function debug
def test_debug():
    from unittest import mock
    with mock.patch('sys.stderr'):
        settings.debug = True
        debug(lambda: 'hi')
        settings.debug = False
        debug(lambda: 'hi')
        settings.debug = True

# Should be False
settings.debug = False

if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-21 18:32:18.718265
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('test') for _ in range(10)]
    assert len(variables) == len(set(variables))

# Generated at 2022-06-21 18:32:24.081883
# Unit test for function debug
def test_debug():
    settings.debug = True
    from .. import messages
    from unittest import mock
    with mock.patch.object(messages, 'debug'), mock.patch('sys.stderr.write') as mock_write:
        debug(lambda: 'test')
        mock_write.assert_called_once_with(messages.debug('test'))

# Generated at 2022-06-21 18:32:31.640089
# Unit test for function debug
def test_debug():
    from . import mocks

    with mocks.MockStdStreams() as (out, err):
        debug(lambda: 'Hello, world!')
        assert err.getvalue() == '\x1b[34mDEBUG: Hello, world!\x1b[0m\n'
        assert out.getvalue() == ''

    with mocks.MockStdStreams() as (out, err):
        settings.debug = False
        debug(lambda: 'Hello, world!')
        assert err.getvalue() == ''
        assert out.getvalue() == ''

# Generated at 2022-06-21 18:32:35.008186
# Unit test for function eager
def test_eager():
    @eager
    def gen_squares(n: int) -> Iterable[int]:
        for i in range(n):
            yield i ** 2

    assert gen_squares(5) == [0, 1, 4, 9, 16]



# Generated at 2022-06-21 18:32:42.317124
# Unit test for function eager
def test_eager():
    def test_eager_function(a: int, b: int) -> Iterator[Tuple[int, int, int]]:
        for x in range(a):
            for y in range(b):
                yield x, y, x * y

    if eager(test_eager_function)(5, 6) != [(x, y, x * y)
                                            for x in range(5)
                                            for y in range(6)]:
        raise AssertionError()



# Generated at 2022-06-21 18:32:43.418108
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]

# Generated at 2022-06-21 18:32:45.189094
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') != VariablesGenerator.generate('y')



# Generated at 2022-06-21 18:32:47.475332
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit):
        warn('test')



# Generated at 2022-06-21 18:32:53.073402
# Unit test for function warn
def test_warn():
    sys.stderr = open('/tmp/warn.txt', 'w')
    warn('my_message')
    f = open('/tmp/warn.txt')
    assert f.read().strip() == messages.warn('my_message')
    f.close()
    sys.stderr = sys.__stderr__
    os.remove('/tmp/warn.txt')

# Generated at 2022-06-21 18:33:08.030709
# Unit test for function get_source
def test_get_source():
    def f():
        return 'a'

    def g(a=3):
        return 'b'

    def h():
        return '''
            a
            b
            c
        '''

    def i():
        '''
        a
        b
        c
        '''
        return 'a'

    assert get_source(f) == 'return \'a\''
    assert get_source(g) == 'return \'b\''

# Generated at 2022-06-21 18:33:09.725486
# Unit test for function eager
def test_eager():
    @eager
    def dummy():
        yield 1
        yield 2
        yield 3
    assert dummy() == [1, 2, 3]

# Generated at 2022-06-21 18:33:12.532081
# Unit test for function warn
def test_warn():
    # python tests/utils.py
    print("test_warn")
    if settings.debug:
        message="hello world"
        warn(message)
        print("warn message: "+message)



# Generated at 2022-06-21 18:33:14.921139
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('test')
    sys.stderr.seek(0)
    assert sys.stderr.read() == messages.warn('test') + '\n'



# Generated at 2022-06-21 18:33:18.292264
# Unit test for function warn
def test_warn():
    import sys
    import mock
    import io
    from ._util import warn

    test_message = 'test message'
    # Capture stderr output
    with mock.patch('sys.stderr', new_callable=io.StringIO) as mock_stderr:
        warn(test_message)
        if mock_stderr.getvalue().strip() != messages.warn(test_message):
            raise AssertionError

# Generated at 2022-06-21 18:33:28.878952
# Unit test for function get_source
def test_get_source():
    import contextlib

    def f():
        pass

    source = get_source(f)
    assert source == '    def f():\n        pass\n'

    def function_with_args(a, b, c=42, *args, **kwargs):
        pass

    source = get_source(function_with_args)
    assert source == (
        '    def function_with_args(a, b, c=42, *args, **kwargs):\n'
        '        pass\n'
    )

    # Fool proof
    def g(x: int) -> str:
        with contextlib.closing(x):
            return 'boo'

    source = get_source(g)

# Generated at 2022-06-21 18:33:30.231563
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == settings.get_source_example

# Generated at 2022-06-21 18:33:36.292616
# Unit test for function get_source
def test_get_source():
    def get_source(fn):
        def f():
            return None
        print(getsource(f))

    def get_source(fn):
        def f():
            return None

        print(getsource(f))

    def get_source(fn):
        print(getsource(fn))

    # get_source(fn)

# Generated at 2022-06-21 18:33:40.694370
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as fake_stderr:
        with patch('backwards.conf.settings.debug', True):
            debug(lambda: 'Print this message')
            fake_stderr.write.assert_called_once()

# Generated at 2022-06-21 18:33:41.206230
# Unit test for function warn
def test_warn():
    # TODO: write unit test
    pass



# Generated at 2022-06-21 18:33:52.581388
# Unit test for function warn
def test_warn():
    sys.stderr = io.StringIO()
    warn('test')
    assert 'test' == sys.stderr.getvalue().strip()

# Generated at 2022-06-21 18:33:54.544155
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-21 18:33:57.231622
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("a") == '_py_backwards_a_1'


# Generated at 2022-06-21 18:34:00.685702
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-21 18:34:05.857585
# Unit test for function debug
def test_debug():
    original_value = settings.debug
    try:
        settings.debug = True
        called = False
        def get_message():
            nonlocal called
            called = True
            return 'test'
        debug(get_message)
        assert called

        called = False
        settings.debug = False
        debug(get_message)
        assert not called
    finally:
        settings.debug = original_value



# Generated at 2022-06-21 18:34:12.579779
# Unit test for function warn
def test_warn():
    import sys
    from io import StringIO
    # Redirect stdout to string
    captured_stdout = StringIO()
    sys.stdout = captured_stdout
    warn("test")
    captured_stdout.seek(0)
    output = captured_stdout.read()[:-1]
    assert output == messages.warn("test")
    # Reset stdout to normal state
    sys.stdout = sys.__stdout__


# Generated at 2022-06-21 18:34:16.363289
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest.mock import patch
    
    with patch("sys.stderr", StringIO()) as mock_stderr:
        warn("warn_test")
        assert("warn_test" in mock_stderr.getvalue())
    

# Generated at 2022-06-21 18:34:17.220128
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == '    pass'

# Generated at 2022-06-21 18:34:19.399909
# Unit test for function warn
def test_warn():
    assert '¯\_(ツ)_/¯' in messages.warn('¯\_(ツ)_/¯')



# Generated at 2022-06-21 18:34:23.031165
# Unit test for function eager
def test_eager():
    @eager
    def generate_numbers():
        for i in range(3):
            yield i

    assert generate_numbers() == [0, 1, 2]


# Unit tests for function generate

# Generated at 2022-06-21 18:34:45.248214
# Unit test for function warn
def test_warn():
    import sys
    import io
    output = io.StringIO()
    sys.stderr = output
    warn('yo')
    result = output.getvalue()
    expected = messages.warn('yo')
    assert result.strip() == expected

# Generated at 2022-06-21 18:34:47.508824
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-21 18:34:54.471381
# Unit test for function warn
def test_warn():
    import sys
    import io
    from contextlib import redirect_stderr

    expected = 'WARNING: There is a bug in py-backwards. Please report it at: https://github.com/jacebrowning/py-backwards/issues/new\n'

    with redirect_stderr(io.StringIO()) as stderr:
        warn('There is a bug in py-backwards. Please report it at: https://github.com/jacebrowning/py-backwards/issues/new')
        actual = stderr.getvalue()
    assert expected == actual



# Generated at 2022-06-21 18:34:56.172283
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0', 'Error in VariablesGenerator class'

# Generated at 2022-06-21 18:35:02.540138
# Unit test for function debug
def test_debug():
    assert settings.debug is False

    class DummyStderr:
        def __init__(self):
            self.out = []

        def write(self, message: str) -> None:
            self.out.append(message)

    dummy = DummyStderr()
    sys.stderr = dummy
    assert len(dummy.out) == 0 and debug('dummy') is None and len(dummy.out) == 0
    sys.stderr = sys.__stderr__

    settings.debug = True
    dummy = DummyStderr()
    sys.stderr = dummy
    assert len(dummy.out) == 0 and debug('dummy') is None and len(dummy.out) == 1
    assert dummy.out[0] == messages.debug('dummy')
    sys.stder

# Generated at 2022-06-21 18:35:08.447369
# Unit test for function warn
def test_warn():
    warn('Something went wrong')
    import StringIO
    sio = StringIO.StringIO()
    stderr = sys.stderr
    sys.stderr = sio
    warn('Testing')
    sys.stderr = stderr
    x = sio.getvalue()
    assert x == '\x1b[33m'+'Something went wrong'+'\x1b[0m\n'

# Generated at 2022-06-21 18:35:12.994659
# Unit test for function eager
def test_eager():
    from unittest.mock import Mock
    mock_generator = Mock(return_value=range(5))
    eager_generator = eager(mock_generator)

    assert eager_generator() == [0, 1, 2, 3, 4]
    mock_generator.assert_called_once()

# Generated at 2022-06-21 18:35:17.150247
# Unit test for function eager
def test_eager():
    def foo() -> List[int]:
        return [1, 2, 3]

    def bar() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]
    assert eager(bar)() == [1, 2, 3]

# Generated at 2022-06-21 18:35:21.745550
# Unit test for function get_source
def test_get_source():
    def foo():
        print('hello')

    def bar():
        def baz():
            print('world')

    assert get_source(foo) == 'print(\'hello\')'
    assert get_source(bar) == '    def baz():\n        print(\'world\')'

# Generated at 2022-06-21 18:35:25.919363
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_0'
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_1'
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_2'

# Generated at 2022-06-21 18:36:11.492284
# Unit test for function eager
def test_eager():
    def range_fn(a: int, b: int) -> range:
        return range(a, b)

    assert eager(range_fn)(1, 10) == list(range_fn(1, 10))

# Generated at 2022-06-21 18:36:15.525684
# Unit test for function get_source
def test_get_source():
    def function():
        """This is a function document.
        a
        b
        """
        print('somethings')
    assert get_source(function) == """def function():
    \"\"\"This is a function document.
    a
    b
    \"\"\"
    print('somethings')
    """

# Generated at 2022-06-21 18:36:21.785543
# Unit test for function debug
def test_debug():
    class MockOut:
        def __init__(self) -> None:
            self.lines = []
            self.delay = 0
            self.current_line = ''

        def write(self, line: str) -> None:
            i = line.find('\n')
            if i != -1:
                line = line[:i]
                self.current_line += line
                self.lines.append(self.current_line)
                self.current_line = ''
            else:
                self.current_line += line
                self.delay = True

    mock_out = MockOut()

# Generated at 2022-06-21 18:36:25.396570
# Unit test for function eager
def test_eager():
    from typing import Sequence

    @eager
    def foo() -> Sequence[int]:
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-21 18:36:27.157856
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'foo')
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:36:34.703530
# Unit test for function warn
def test_warn():
    global message
    message = ''

    def replace_print(*args):
        global message
        message = args[0]

    sys.stderr.write = replace_print
    sys.stderr.writelines = replace_print

    warn('msg_test')
    assert message == 'py_backwards warning: msg_test'
    warn('msg_test')
    assert message == 'py_backwards warning: msg_test'
    warn('msg_test2')
    assert message == 'py_backwards warning: msg_test2'


# Generated at 2022-06-21 18:36:39.432537
# Unit test for function warn
def test_warn():
    import io
    import sys
    out = io.StringIO()
    sys.stderr = out
    warn('warning_message')
    out.seek(0)
    sys.stderr = sys.__stderr__
    assert out.readlines()[0] == 'warning_message\n'



# Generated at 2022-06-21 18:36:48.094179
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'def test_get_source():\n    assert get_source(test_get_source) == """def test_get_source():\\n    assert get_source(test_get_source) == "def test_get_source():\\\\n    assert get_source(test_get_source) == \\\\\\"def test_get_source():\\\\\\\\n    assert get_source(test_get_source) == \\\\\\\\\\\\\\"def test_get_source():\\\\\\\\\\\\n    assert get_source(test_get_source) == \\\\\\\\\\\\\\"def test_get_source():\\\\\\\\\\\\\\\\n    assert get_source(test_get_source) == \\\\\\\\\\\\\\\\\\\\\\"def test_get_source():\\\\\\\\\\\\\\\\\\\\n    assert get_source(test_get_source) == \\\\\\\\\\\\\\\\\\\\\\"""""'

# Generated at 2022-06-21 18:36:50.055737
# Unit test for function eager
def test_eager():
    @eager
    def function():
        yield 'a'
        yield 'b'
        yield 'c'
        return 'd'

    assert function() == ['a', 'b', 'c']

# Generated at 2022-06-21 18:36:52.966670
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'

    def f():
        pass


    assert get_source(f) == 'pass'

# Generated at 2022-06-21 18:38:43.342054
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    b = VariablesGenerator.generate('a')
    c = VariablesGenerator.generate('b')
    assert a != b != c



# Generated at 2022-06-21 18:38:45.614292
# Unit test for function debug
def test_debug():
    settings.debug = True
    x = 0

    @debug
    def test():
        return 'foobar'

    assert x == 0
    test()
    assert x == 0

# Generated at 2022-06-21 18:38:47.885018
# Unit test for function get_source
def test_get_source():
    def dummy():
        pass
    assert get_source(dummy) == 'def dummy():\n    pass'



# Generated at 2022-06-21 18:38:49.143909
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Test message')

# Generated at 2022-06-21 18:38:53.923965
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
        return bar()

    assert get_source(foo) == textwrap.dedent("""\
        def bar():
            pass
        return bar()""")


"""
This part is a modified version of the snippet by Peter Norvig. All credit to him.

http://norvig.com/python-iaq.html
"""

import inspect
import sys


# Generated at 2022-06-21 18:39:03.353382
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_3'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_4'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_5'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_6'

# Generated at 2022-06-21 18:39:06.240123
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit):
        warn("something is wrong")



# Generated at 2022-06-21 18:39:08.767272
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(10))() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:39:12.512185
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'


# Generated at 2022-06-21 18:39:16.102699
# Unit test for function warn
def test_warn():
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    warn('warned')
    assert capturedOutput.getvalue() == messages.warn('warned') + '\n'
