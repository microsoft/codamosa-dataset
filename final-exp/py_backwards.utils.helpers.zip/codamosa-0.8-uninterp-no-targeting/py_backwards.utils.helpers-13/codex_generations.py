

# Generated at 2022-06-21 18:30:36.444085
# Unit test for function eager
def test_eager():
    class Test:
        _counter = 0
        @staticmethod
        @eager
        def get_values(num: int) -> Iterable[int]:
            for i in range(num):
                yield i

    instance = Test()
    assert instance.get_values(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:30:42.083374
# Unit test for function warn
def test_warn():
    import io
    import sys

    old_stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        warn('Hello world!')
        assert sys.stderr.getvalue() == '\n\x1b[33mWarning: Hello world!\n\x1b[0m'
    finally:
        sys.stderr = old_stderr



# Generated at 2022-06-21 18:30:49.809055
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    print("1. {}\n2. {}\n3. {}\n".format(vg.generate("var"), vg.generate("var"), vg.generate("var2")))
    f = lambda : print("1. {}\n2. {}\n3. {}".format(vg.generate("var"), vg.generate("var"), vg.generate("var2")))
    f()
    print("\n")
    print("1. {}\n2. {}\n3. {}".format(vg.generate("var"), vg.generate("var"), vg.generate("var2")))


# Generated at 2022-06-21 18:31:02.706530
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class VariablesGeneratorTest:
        _counter = 0

        @classmethod
        def generate(cls, variable: str) -> str:
            """Generates unique name for variable."""
            try:
                return '_py_backwards_{}_{}'.format(variable, cls._counter)
            finally:
                cls._counter += 1

    def test_VariablesGenerator_class_works_correctly_with_multiply_calls():
        assert VariablesGeneratorTest.generate('i') == '_py_backwards_i_0'
        assert VariablesGeneratorTest.generate('i') == '_py_backwards_i_1'
        assert VariablesGeneratorTest.generate('i') == '_py_backwards_i_2'
        assert VariablesGeneratorTest.generate

# Generated at 2022-06-21 18:31:05.980970
# Unit test for function debug
def test_debug():
    message = "dummy string"
    print(message)
    assert debug(lambda:message) == print(messages.debug(message), file=sys.stderr)

# Generated at 2022-06-21 18:31:09.715556
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """Testing constructor of VariablesGenerator"""
    a = VariablesGenerator()
    b = VariablesGenerator()
    c = VariablesGenerator()
    assert a.generate('a') == '_py_backwards_a_0'
    assert b.generate('b') == '_py_backwards_b_1'
    assert c.generate('c') == '_py_backwards_c_2'

# Generated at 2022-06-21 18:31:13.614561
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    try:
        assert VariablesGenerator._counter == 0
        assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
        assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    finally:
        VariablesGenerator._counter = 0



# Generated at 2022-06-21 18:31:18.688200
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test_fn = VariablesGenerator.generate
    assert test_fn('abc') == '_py_backwards_abc_0'
    assert test_fn('abc') == '_py_backwards_abc_1'
    assert test_fn('abc') == '_py_backwards_abc_2'



# Generated at 2022-06-21 18:31:21.793641
# Unit test for function eager
def test_eager():
    def x():
        yield 'a'
        yield 'b'

    assert eager(x)() == ['a', 'b']

# Generated at 2022-06-21 18:31:27.477696
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n' \
                              '    pass'

    def bar():
        def foo():
            pass

    assert get_source(bar) == 'def bar():\n' \
                              '    def foo():\n' \
                              '        pass'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:31:37.157958
# Unit test for function eager
def test_eager():
    from ..utils.inspect import get_args_count
    from ..utils.types import ANY
    from ..utils.functional import identity

    @eager
    def foo():
        """docstring"""
        pass

    assert foo(0) == []
    assert identity(foo)() == []
    assert get_args_count(foo) == (ANY, None)
    assert foo.__doc__ == 'docstring'
    assert 'test_eager' in foo.__name__
    assert 'eager' in foo.__name__

# Generated at 2022-06-21 18:31:39.847129
# Unit test for function warn
def test_warn():
    assert messages.warn('test') == '\033[93m\033[1mWARNING\033[0m: test\033[0m'



# Generated at 2022-06-21 18:31:42.788572
# Unit test for function debug
def test_debug():
    settings.debug = True
    message = 'test'
    debug(lambda: message)
    assert message in sys.stderr.getvalue()
    sys.stderr.truncate(0)



# Generated at 2022-06-21 18:31:45.443789
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    result = test()
    assert result == [1, 2, 3]
    assert isinstance(result, list)

# Generated at 2022-06-21 18:31:46.647845
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():'

# Generated at 2022-06-21 18:31:50.868981
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'

# Generated at 2022-06-21 18:31:52.854694
# Unit test for function warn
def test_warn():
    import io
    buffer = io.StringIO()
    sys.stderr = buffer

    warn('hello, world')
    assert buffer.getvalue() == '\x1b[33mwarning: hello, world\x1b[0m\n'



# Generated at 2022-06-21 18:31:56.924245
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'

# Generated at 2022-06-21 18:31:58.091319
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo')



# Generated at 2022-06-21 18:32:00.659459
# Unit test for function get_source
def test_get_source():
    def a():
        if True:
            return 1
    assert 'return 1' in get_source(a)

# Generated at 2022-06-21 18:32:12.828252
# Unit test for function eager
def test_eager():
    # - Use eager to make this function eager (lambda x: x)
    # - Make sure it returns a list
    # - Make sure it doesn't lose information
    # - Make sure it works with different kinds of iterable
    from random import random
    from itertools import count

    @eager
    def do_eager(n: int) -> Iterable[float]:
        for i in range(n):
            yield random()
            yield random()
            yield random()

    assert isinstance(do_eager(1000), list)
    assert len(do_eager(1000)) == 3000
    assert do_eager(0) == []
    assert do_eager((x for x in range(10))) == list(range(10))


# Generated at 2022-06-21 18:32:15.789365
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("var") == '_py_backwards_var_0'
    assert VariablesGenerator.generate("var") == '_py_backwards_var_1'



# Generated at 2022-06-21 18:32:18.064453
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("b") == '_py_backwards_b_1'



# Generated at 2022-06-21 18:32:27.817951
# Unit test for function warn
def test_warn():
    import sys
    import io

    class Stream:
        def __init__(self):
            self.is_writed = False
            self.value = ''
        def write(self, value):
            self.value += value
            self.is_writed = True
    # normal case
    stream = Stream()
    sys.stdout = io.StringIO()
    sys.stderr = stream
    warn('This is check normal case')
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    assert(stream.is_writed)
    assert('This is check normal case' in stream.value)

# Generated at 2022-06-21 18:32:30.010527
# Unit test for function debug
def test_debug():
    settings.debug = True

    expected_message = 'This is debug message'
    output = io.StringIO()
    with contextlib.redirect_stderr(output):
        debug(lambda: expected_message)
    output_message = output.getvalue().strip()

    assert output_message == '\n[DEBUG] {}'.format(expected_message)

    settings.debug = False

# Generated at 2022-06-21 18:32:31.968068
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n' + \
        '    pass'



# Generated at 2022-06-21 18:32:33.810086
# Unit test for function get_source
def test_get_source():
    def source():
        pass

    assert get_source(source) == 'pass'



# Generated at 2022-06-21 18:32:42.265621
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print()
    print('test_VariablesGenerator')
    print(' VariablesGenerator.generate() =', VariablesGenerator.generate('var'), 'should be _py_backwards_var_0')
    print(' VariablesGenerator.generate() =', VariablesGenerator.generate('var'), 'should be _py_backwards_var_1')
    print(' VariablesGenerator.generate() =', VariablesGenerator.generate('var'), 'should be _py_backwards_var_2')
    print()

if __name__ == '__main__':
    test_VariablesGenerator()

# Generated at 2022-06-21 18:32:43.725647
# Unit test for function get_source
def test_get_source():
    def foo(s): pass
    assert get_source(foo) == 'def foo(s): pass'



# Generated at 2022-06-21 18:32:46.016523
# Unit test for function get_source
def test_get_source():
    def test():
        print('print message')

    assert get_source(test) == 'def test():\n    print(\'print message\')'

# Generated at 2022-06-21 18:32:53.419882
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable1') == '_py_backwards_variable1_0'
    assert VariablesGenerator.generate('variable2') == '_py_backwards_variable2_1'
    assert VariablesGenerator.generate('variable3') == '_py_backwards_variable3_2'

# Generated at 2022-06-21 18:32:57.189201
# Unit test for function eager
def test_eager():
    def test_function() -> Iterable[int]:
        for i in range(10):
            yield(i)
    assert eager(test_function)() == [0,1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-21 18:33:05.524154
# Unit test for function debug
def test_debug():
    with open('debug_log.txt', 'w') as f:
        # noinspection PyTypeChecker
        sys.stderr = f
        try:
            __name__  # to suppress warning about unused import
            debug(lambda: 'foo')
            settings.debug = True
            debug(lambda: 'bar')
        finally:
            sys.stderr = sys.__stderr__
    with open('debug_log.txt', 'r') as f:
        # noinspection PyTypeChecker
        assert f.read() == 'bar\n'

# Generated at 2022-06-21 18:33:08.444418
# Unit test for function eager
def test_eager():
    lst = [1, 2, 3]
    lst2 = eager(lambda x: x)(lst)
    assert lst == lst2 == [1, 2, 3]



# Generated at 2022-06-21 18:33:11.719419
# Unit test for function debug
def test_debug():
    messages.debug = 'DEBUG MESSAGE'
    settings.debug = False
    debug(lambda: 'some_debug_message')
    settings.debug = True
    debug(lambda: 'some_debug_message')
test_debug()



# Generated at 2022-06-21 18:33:14.154293
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('z') == '_py_backwards_z_1'

# Generated at 2022-06-21 18:33:19.731817
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as mock_stderr:
        with patch('backwards.utils.settings', {'debug': True}):
            debug(lambda: 'Hello world')
        assert mock_stderr.write.call_args[0][0].strip() == 'Hello world'



# Generated at 2022-06-21 18:33:20.578637
# Unit test for function warn
def test_warn():
    warn('test warn')

# Generated at 2022-06-21 18:33:25.775205
# Unit test for function eager
def test_eager():
    @eager
    def get_things() -> Iterable[str]:
        i = 0
        while i < 5:
            yield 'thing{}'.format(i)
            i += 1

    assert get_things() == ['thing0', 'thing1', 'thing2', 'thing3', 'thing4']



# Generated at 2022-06-21 18:33:27.374296
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-21 18:33:34.727395
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator
    assert gen._counter == 0

    gen.generate('foo')
    assert gen._counter == 1

    gen.generate('foo')
    assert gen._counter == 2

    gen.generate('bar')
    assert gen._counter == 3

# Generated at 2022-06-21 18:33:37.654163
# Unit test for function eager
def test_eager():
    @eager
    def r() -> Iterable[int]:
        for x in range(4):
            yield x

    assert r() == [0, 1, 2, 3]

# Generated at 2022-06-21 18:33:45.368061
# Unit test for function debug
def test_debug():
    import pytest
    from ..conf import settings
    settings.debug = True

    message = 'message'

    def my_func():
        debug(lambda: message)

    with pytest.raises(SystemExit):
        my_func()

    settings.debug = False

    with pytest.raises(SystemExit) as system_exit:
        my_func()

    assert system_exit.type == SystemExit

    try:
        my_func()
    except SystemExit:
        pytest.fail('Should not raise SystemExit')



# Generated at 2022-06-21 18:33:48.452136
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1

    def bar():  # pragma: no branch
        pass

    assert get_source(foo) == 'return 1'
    assert get_source(bar) == 'pass'

# Generated at 2022-06-21 18:33:49.362722
# Unit test for function warn
def test_warn():
    pass



# Generated at 2022-06-21 18:33:54.259469
# Unit test for function warn
def test_warn():
    result = StringIO()
    sys.stderr = result
    try:
        warn('Hello')
        result = result.getvalue()
        assert result == '\x1b[33mHello\x1b[0m'
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:33:56.956755
# Unit test for function eager
def test_eager():
    @eager
    def get_range(end: int) -> Iterable[int]:
        for i in range(end):
            yield i

    assert get_range(3) == [0, 1, 2]

# Generated at 2022-06-21 18:34:01.293017
# Unit test for function get_source
def test_get_source():
    def func():
        x = 1
        # comment
        return x
    assert get_source(func) == (
        'def func():\n'
        '    x = 1\n'
        '    # comment\n'
        '    return x\n'
    )

# Generated at 2022-06-21 18:34:04.434031
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(100):
        if '_py_backwards_' in VariablesGenerator.generate('f'):
            assert True
        else:
            assert False


# Generated at 2022-06-21 18:34:15.867154
# Unit test for function debug
def test_debug():
    import sys

    def test_debug_write_to_stderr_when_debug_is_set():
        # Reset stderr first
        sys.stderr = sys.__stderr__
        should_be_written = 'test debug message'
        debug(lambda: should_be_written)
        assert should_be_written in sys.stderr.getvalue()

    def test_debug_dont_write_to_stderr_when_debug_is_not_set():
        # Reset stderr first
        sys.stderr = sys.__stderr__
        should_not_be_written = 'test debug message'
        previous_debug_setting = settings.debug
        settings.debug = False
        debug(lambda: should_not_be_written)
        assert should_not_be_

# Generated at 2022-06-21 18:34:27.733398
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class VGC:
        def __init__(self):
            self._counter = 0

        @classmethod
        def generate(cls, variable: str) -> str:
            """Generates unique name for variable."""
            try:
                return '_py_backwards_{}_{}'.format(variable, cls._counter)
            finally:
                cls._counter += 1

    vgc = VGC()
    assert vgc.generate('test') == '_py_backwards_test_0'
    assert vgc.generate('test') == '_py_backwards_test_1'
    assert vgc.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-21 18:34:31.145000
# Unit test for function get_source
def test_get_source():

    def test_fn():
        variable_i, variable_j = range(2)
        return variable_i + variable_j

    expected_source = '''variable_i, variable_j = range(2)
return variable_i + variable_j'''

    assert get_source(test_fn) == expected_source

# Generated at 2022-06-21 18:34:35.777947
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]
    assert eager(lambda a, b=2: range(a, b))(1) == [1]
    assert eager(lambda a, b=2: range(a, b))(1, 3) == [1, 2]

# Generated at 2022-06-21 18:34:45.124981
# Unit test for function debug
def test_debug():
    from io import StringIO

    class Stream:
        def __init__(self):
            self.stream = StringIO()

        def __enter__(self):
            return self.stream

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.stream.close()

    test_message = "test"

    def test():
        with Stream() as stream:
            sys.stderr = stream
            debug(lambda: test_message)
            sys.stderr.seek(0)
            assert sys.stderr.read() == messages.debug(test_message)
        print(test_message)

    test()

# Generated at 2022-06-21 18:34:55.194234
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variables') == '_py_backwards_variables_0'
    assert VariablesGenerator.generate('variables') == '_py_backwards_variables_1'
    assert VariablesGenerator.generate('variables') == '_py_backwards_variables_2'
    assert VariablesGenerator.generate('variables') == '_py_backwards_variables_3'
    assert VariablesGenerator.generate('variables') == '_py_backwards_variables_4'
    assert VariablesGenerator.generate('variables') == '_py_backwards_variables_5'
    # If you do not want to mock '__init__' of class to test generator,
    # you should go by this way:
    first_var = Vari

# Generated at 2022-06-21 18:35:01.937611
# Unit test for function warn
def test_warn():
    def test_wrap(fn):
        @wraps(fn)
        def wrapped(message):
            with tests.capture_stderr() as stderr:
                fn(message)
            assert stderr.getvalue() == messages.warn(message) + '\n'
        return wrapped

    @test_wrap
    def fn_1(message):
        warn(message)

    @test_wrap
    def fn_2(message):
        warn(message + 'a')
        warn(message + 'b')

    @test_wrap
    def fn_3(message):
        warn(message + 'a')
        warn(message + 'b')
        warn(message)

    fn_1('Message 1')
    fn_2('Message 2')
    fn_3('Message 3')

# Generated at 2022-06-21 18:35:04.961281
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variable = "i"
    for counter in range(0, 10):
        gen_variable = VariablesGenerator._generate(variable, counter)
        assert gen_variable == '_py_backwards_' + variable + '_' + str(counter)

# Generated at 2022-06-21 18:35:11.086623
# Unit test for function warn
def test_warn():
    import sys
    import re
    from contextlib import redirect_stderr

    with redirect_stderr(sys.stderr) as f:
        warn('test')

    f.seek(0)
    assert re.match(r'^\[warn\]\s*test\n$', f.read()) is not None



# Generated at 2022-06-21 18:35:12.949763
# Unit test for function debug
def test_debug():
    if settings.debug:
        debug(lambda: 'This is a debug message')

# Generated at 2022-06-21 18:35:21.444743
# Unit test for function debug
def test_debug():
    class CaptureSysStdErr(list):
        def __enter__(self):
            self._original_stderr = sys.stderr
            sys.stderr = self._stringio = StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio
            sys.stderr = self._original_stderr

    with CaptureSysStdErr() as stderr, CaptureSysStdOut() as stdout:
        debug(lambda: 'Some text')
        assert not stderr
        assert not stdout

# Generated at 2022-06-21 18:35:31.106867
# Unit test for function eager
def test_eager():
    class Foo:
        def bar(self, length):
            return range(length)

    foo = Foo()
    assert isinstance(foo.bar(2), range)
    assert isinstance(eager(foo.bar)(2), list)

# Generated at 2022-06-21 18:35:37.924000
# Unit test for function warn
def test_warn():
    actual_stdout = sys.stdout
    actual_stderr = sys.stderr
    warn_message = ''
    try:
        sys.stdout = sys.stderr = StringIO()
        warn('message')
        warn_message = sys.stderr.getvalue()
    finally:
        sys.stdout = actual_stdout
        sys.stderr = actual_stderr

    assert re.match(r'\x1b\[.+message\x1b\[0m', warn_message) is not None



# Generated at 2022-06-21 18:35:44.748015
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        message = 'some warning'
        warn(message)

        mock_stderr.seek(0)
        asserted = '{} {}'.format(settings.warning_prefix, message)
        actual = mock_stderr.readline()

    assert asserted == actual


if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-21 18:35:47.687960
# Unit test for function debug
def test_debug():
    # Should not output anything when debug is off
    settings.debug = False
    debug(lambda: 'message')

    # Should print the message when debug is on
    settings.debug = True
    debug(lambda: 'message')

# Generated at 2022-06-21 18:35:51.771947
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]



# Generated at 2022-06-21 18:36:00.424793
# Unit test for function debug
def test_debug():
    import os

    def get_a_message():
        return 'a message'
    settings_debug = settings.debug
    try:
        settings.debug = True
        out = os.dup(sys.stderr.fileno())
        sys.stderr.close()
        sys.stderr = open('/dev/null', 'w')
        debug(get_a_message)
    finally:
        sys.stderr.close()
        os.dup2(out, sys.stderr.fileno())
        os.close(out)
        settings.debug = settings_debug



# Generated at 2022-06-21 18:36:02.337875
# Unit test for function get_source
def test_get_source():

    def f():
        pass

    assert get_source(f) == 'pass'

# Generated at 2022-06-21 18:36:09.431254
# Unit test for function warn
def test_warn():
    warnings.simplefilter('always')
    assert warnings.catch_warnings(record=True)
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        warn('w')
        # Verify some things
        assert len(w) == 1
        assert 'w' in str(w[-1].message)
    warnings.simplefilter('default')

# Generated at 2022-06-21 18:36:11.328292
# Unit test for function debug
def test_debug():
    messages.DEBUG = True
    debug(lambda: 'Hello')
    messages.DEBUG = False
    debug(lambda: 'Hello')

# Generated at 2022-06-21 18:36:14.236738
# Unit test for function get_source
def test_get_source():
    def my_func(a, b, c):
        return a + b + c

    assert get_source(my_func) == 'return a + b + c'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:36:27.146815
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

# Generated at 2022-06-21 18:36:31.718187
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class MockVariablesGenerator(VariablesGenerator):
        _counter = 0

    assert MockVariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert MockVariablesGenerator.generate('foo') == '_py_backwards_foo_1'

# Generated at 2022-06-21 18:36:35.660694
# Unit test for function warn
def test_warn():
    from .mock import MockStdErr

    with MockStdErr() as mock_stderr:
        warn('It is a warning message!')

    assert mock_stderr.flush() == '\x1b[33mIt is a warning message!\x1b[0m\n'



# Generated at 2022-06-21 18:36:38.377516
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    assert v.generate('variable') == '_py_backwards_variable_0'
    assert v.generate('variable') == '_py_backwards_variable_1'

# Generated at 2022-06-21 18:36:44.385886
# Unit test for function warn
def test_warn():
    import sys

    from StringIO import StringIO

    mystdout = StringIO()
    sys.stderr = mystdout
    warn('this is test message')
    warn('this is another test message')
    sys.stderr = sys.__stderr__
    assert 'this is test message' in mystdout.getvalue()
    assert 'this is another test message' in mystdout.getvalue()
    assert 'warning' in mystdout.getvalue()

# Generated at 2022-06-21 18:36:47.290783
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from .test import expect
    vg = VariablesGenerator()
    expect(vg.generate('a')).to_equal('_py_backwards_a_0')
    expect(vg.generate('b')).to_equal('_py_backwards_b_1')

# Generated at 2022-06-21 18:36:52.504751
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class VariablesGeneratorTest:
        def __init__(self):
            self.count = 0

        @classmethod
        def generate(cls, variable: str) -> str:
            """Generates unique name for variable."""
            try:
                return '_py_backwards_{}_{}'.format(variable, cls.count)
            finally:
                cls.count += 1

    gen = VariablesGeneratorTest()
    assert gen.generate('test') == '_py_backwards_test_0'
    assert gen.generate('test') == '_py_backwards_test_1'
    assert gen.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-21 18:36:56.414401
# Unit test for function debug
def test_debug():
    with patch('sys.stderr'):
        debug(lambda: 'Hello, buddy!')
    sys.stderr.write.assert_called_once_with(messages.debug('Hello, buddy!') + '\n')

# Generated at 2022-06-21 18:37:04.850980
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO
    from ..conf import settings

    # Backup settings and set debug to False
    settings_backup = settings
    settings.debug = False

    # Set stderr
    stderr = StringIO()
    sys.stderr = stderr

    # Run test
    warn("hello world")

    # Assert test result
    assert "hello world" in stderr.getvalue()

    # Restore settings and stderr
    settings = settings_backup
    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:37:07.317736
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-21 18:37:35.261435
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'pass'

# Generated at 2022-06-21 18:37:42.021375
# Unit test for function warn
def test_warn():
    try:
        with warnings.catch_warnings(record=True) as w:
            warn('Hello!')
            assert len(w) == 1
            assert w[0].message.args[0] == 'Hello!'
    except AssertionError as e:
        print(e)
        print('test_warn() failed!')
        os.system("pause")


# Generated at 2022-06-21 18:37:44.808464
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('') == '_py_backwards__0'
    assert VariablesGenerator.generate('') == '_py_backwards__1'



# Generated at 2022-06-21 18:37:55.839189
# Unit test for function get_source
def test_get_source():
    def source_tester():
        if True:
            def foo():
                pass

            def bar():
                pass

            def baz():
                pass

    source = get_source(source_tester)
        # If a pass statement is not executed in the function, the
        # "unreachable code" error will be raised.
    assert re.match(
        r'    def foo\(\) -> None:\n^        pass\n\n^    def bar\(\) -> None:\n^        pass\n\n^    def baz\(\) -> None:\n^        pass$',
        source
    )
    assert source_tester.__doc__ == get_source.__doc__


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:37:56.687783
# Unit test for function warn
def test_warn():
    assert warn('message') == None

# Generated at 2022-06-21 18:38:01.238029
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_4'


# Generated at 2022-06-21 18:38:06.803400
# Unit test for function warn
def test_warn():
    out = StringIO()
    sys.stderr = out
    warn("WARNING: something went wrong")
    sys.stderr = sys.__stderr__
    output = out.getvalue()
    assert "\x1b[1;33m" in output
    assert "something went wrong" in output
    assert "\x1b[0m" in output



# Generated at 2022-06-21 18:38:12.301946
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_3'


# Generated at 2022-06-21 18:38:13.990487
# Unit test for function eager
def test_eager():
    @eager
    def fn() -> Iterable[int]:
        yield 1
        yield 2
    assert fn() == [1, 2]

# Generated at 2022-06-21 18:38:19.379703
# Unit test for function eager
def test_eager():
    import types
    import random

    def generator_function():
        for i in range(10):
            yield random.randint(0, 100)

    eager_function = eager(generator_function)
    assert isinstance(eager_function(), list)

# Generated at 2022-06-21 18:39:17.147696
# Unit test for function debug
def test_debug():
    debug(lambda: "test")

# Generated at 2022-06-21 18:39:18.593827
# Unit test for function warn
def test_warn():
    from io import StringIO
    from sys import stderr
    message = "test"
    buff = StringIO()
    stderr.write = buff.write
    warn(message)
    assert buff.getvalue() == message+"\n"

# Generated at 2022-06-21 18:39:25.471143
# Unit test for function get_source
def test_get_source():
    def test_1():
        return 1

    def test_2():
        class Test:
            def __init__(self):
                self.x = 1

    expected_lines_1 = (
        'def test_1():',
        '    return 1',
        '',
        '',
    )

    expected_lines_2 = (
        'def test_2():',
        '    class Test:',
        '        def __init__(self):',
        '            self.x = 1',
        '',
        '',
    )

    assert get_source(test_1).split('\n') == expected_lines_1
    assert get_source(test_2).split('\n') == expected_lines_2

# Generated at 2022-06-21 18:39:28.911523
# Unit test for function get_source
def test_get_source():
    def simple(a):
        def simple_inner(b):
            pass
        pass
    assert get_source(simple) == 'def simple_inner(b):\n    pass'

# Generated at 2022-06-21 18:39:30.093742
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate("_py_backwards_x_0") == '_py_backwards_x_0_0'


# Generated at 2022-06-21 18:39:35.438888
# Unit test for function debug
def test_debug():
    from .logger import redirect
    from . import captured

    with redirect() as stream:
        def message():
            return 'test'

        debug(message)
        assert captured(stream) == ''

        with settings.override(debug=True):
            debug(message)
            assert captured(stream) == messages.debug('test') + '\n'



# Generated at 2022-06-21 18:39:38.835831
# Unit test for function debug
def test_debug():
    assert not settings.debug
    messages.debug = lambda message: 'DBG: {}'.format(message)

    # No output, nothing should be printed
    debug(lambda: 'whatever')

    # Now we turn on debug
    settings.debug = True
    try:
        # Now we should see debug message
        debug(lambda: 'whatever')
    finally:
        # And turn off debug
        settings.debug = False

    # No output, nothing should be printed
    debug(lambda: 'whatever')


# Generated at 2022-06-21 18:39:40.477661
# Unit test for function eager
def test_eager():
    import pytest
    @eager
    def get_list() -> Iterable[T]:
        yield 1
        yield 2
        yield 3

    assert get_list() == [1, 2, 3]


# Generated at 2022-06-21 18:39:42.096077
# Unit test for function eager
def test_eager():
    @eager
    def gen_odd() -> Iterable[int]:
        n = 1
        while True:
            yield n
            n += 2

    assert gen_odd() == [1, 3, 5]

# Generated at 2022-06-21 18:39:43.939796
# Unit test for function debug
def test_debug():
    def test_get_message():
        return 'Some debug message'
    debug(test_get_message)