

# Generated at 2022-06-21 18:30:24.265000
# Unit test for function eager
def test_eager():
    def foo():
        yield 'bar'
        yield 'baz'
    foo = eager(foo)
    assert foo() == ['bar', 'baz']


# Generated at 2022-06-21 18:30:26.248280
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit) as exc_info:
        warn('message')
    assert exc_info.value.code == 1
    assert exc_info.value.name == 'Backwards'

# Generated at 2022-06-21 18:30:29.551135
# Unit test for function warn
def test_warn():
    _messages = [] # type: List[str]

    def _print(*args, **kwargs):
        _messages.append(*args, **kwargs)

    orig_print = print
    print = _print
    try:
        warn("abc")
        assert _messages == ["abc\n"]
    finally:
        print = orig_print


# Generated at 2022-06-21 18:30:34.165885
# Unit test for function warn
def test_warn():
    import io
    import sys

    # Buffer for error output
    buffer = io.StringIO()
    sys.stderr = buffer

    warn("test")
    sys.stderr = sys.__stderr__

    assert buffer.getvalue() == messages.warn("test") + "\n"

# Generated at 2022-06-21 18:30:35.738629
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    b = VariablesGenerator()
    assert a != b

# Generated at 2022-06-21 18:30:40.902335
# Unit test for function warn
def test_warn():
    from StringIO import StringIO

    old_stderr = sys.stderr
    sys.stderr = StringIO()
    warn('warn')
    assert sys.stderr.getvalue() == 'py_backwards: \x1b[91mwarn\x1b[0m\n'
    sys.stderr = old_stderr



# Generated at 2022-06-21 18:30:44.390241
# Unit test for function eager
def test_eager():
    from py_backwards import eager

    @eager
    def eager_test():
        for i in range(3):
            yield i

    list1 = eager_test()
    list2 = [0, 1, 2]

    assert list1 == list2
    
    

# Generated at 2022-06-21 18:30:45.725759
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(5))() == [0, 1, 2, 3, 4]


# Generated at 2022-06-21 18:30:51.715670
# Unit test for function get_source
def test_get_source():
    def test1(): pass
    assert get_source(test1) == 'def test1(): pass'

    def test2():
        pass
    assert get_source(test2) == 'def test2():\n    pass'

    def test3(arg1=None):
        pass
    assert get_source(test3) == 'def test3(arg1=None):\n    pass\n'



# Generated at 2022-06-21 18:30:55.340215
# Unit test for function eager
def test_eager():
    @eager
    def fn() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert fn() == [1, 2, 3]

# Generated at 2022-06-21 18:31:01.109666
# Unit test for function warn
def test_warn():
    warn('message')



# Generated at 2022-06-21 18:31:04.382566
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first_variable = VariablesGenerator.generate('test')
    second_variable = VariablesGenerator.generate('test')
    assert first_variable != second_variable
    assert first_variable.startswith('_py_backwards_test')
    assert second_variable.startswith('_py_backwards_test')



# Generated at 2022-06-21 18:31:09.336524
# Unit test for function warn
def test_warn():
    import StringIO
    import sys
    buffer = StringIO.StringIO()
    try:
        sys.stderr = buffer
        warn("Test")
        assert buffer.getvalue() == "\n" + messages.warn("Test") + "\n"
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:31:15.269563
# Unit test for function get_source
def test_get_source():
    assert(get_source(test_get_source) == 'def test_get_source():\n'
                                         '    assert(get_source(test_get_source) == \'def test_get_source():\\n\'\n'
                                         '                                                 \'                                         \'\n'
                                         '                                                 \'    assert(get_source(test_get_source) == \\\'def test_get_source():\\\\n\\\'\')')

# Generated at 2022-06-21 18:31:21.810295
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager

    with open('/dev/null', 'w') as null:
        with contextmanager(lambda: sys.modules['sys'].stderr) as stderr:
            sys.modules['sys'].stderr = null
            debug(lambda: 'test')
            sys.modules['sys'].stderr = stderr
            debug(lambda: 'test')

# Generated at 2022-06-21 18:31:24.912694
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == "_py_backwards_x_0"
    assert VariablesGenerator.generate("x") == "_py_backwards_x_1"

# Generated at 2022-06-21 18:31:31.097558
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate("foo") == '_py_backwards_foo_0'
    assert VariablesGenerator.generate("foo") == '_py_backwards_foo_1'
    assert VariablesGenerator.generate("foo") == '_py_backwards_foo_2'
    assert VariablesGenerator.generate("bar") == '_py_backwards_bar_3'

# Generated at 2022-06-21 18:31:32.604877
# Unit test for function warn
def test_warn():
    import pytest
    assert warn('message') == None



# Generated at 2022-06-21 18:31:38.178400
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            def h(x: str):
                pass
            pass
        pass
    assert get_source(f) == "def g():\n    def h(x: str):\n        pass\n    pass"
    assert get_source(g) == "def h(x: str):\n        pass"
    assert get_source(h) == "pass"

# Generated at 2022-06-21 18:31:39.942986
# Unit test for function warn
def test_warn():
    warn('test warn message')
    assert "test warn message" in sys.stderr.getvalue()

# Generated at 2022-06-21 18:31:46.881098
# Unit test for function get_source
def test_get_source():
    import random

    def foo(a, b):
        return a * b * random.randint(0, 100)

    assert get_source(foo) == 'return a * b * random.randint(0, 100)'

# Generated at 2022-06-21 18:31:51.871125
# Unit test for function get_source
def test_get_source():
    def do_something(x: int, y: float) -> None:
        pass

    source = '''def do_something(x: int, y: float) -> None:
    pass'''
    assert get_source(do_something) == source

# Generated at 2022-06-21 18:31:57.398390
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'

    def bar():
        # This is a comment
        pass  # This is also a comment

    expected_source = '# This is a comment\npass  # This is also a comment'
    assert get_source(bar) == expected_source

# Generated at 2022-06-21 18:31:58.804947
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator()


# Generated at 2022-06-21 18:32:02.641129
# Unit test for function debug
def test_debug():
    message = 'test'
    with mock.patch('sys.stderr.write') as mock_write:
        debug(lambda: message)
    assert mock_write.call_args[0][0] == messages.debug(message)

# Generated at 2022-06-21 18:32:06.434916
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from .VariablesGenerator import VariablesGenerator
    vg = VariablesGenerator()

    for i in range(10):
        assert vg.generate('z') == '_py_backwards_z_{}'.format(i)



# Generated at 2022-06-21 18:32:09.773674
# Unit test for function debug
def test_debug():
    global debug_flag
    debug_flag = False
    debug(lambda: debug_flag)
    assert not debug_flag
    settings.debug = True
    debug(lambda: debug_flag)
    assert debug_flag



# Generated at 2022-06-21 18:32:14.068031
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    last_var_name = VariablesGenerator.generate('x')
    for i in range(4):
        new_var_name = VariablesGenerator.generate('x')
        assert last_var_name != new_var_name
        last_var_name = new_var_name



# Generated at 2022-06-21 18:32:16.136181
# Unit test for function get_source
def test_get_source():
    def fn(x, y, z=None):
        return x + y + z

    assert get_source(fn) == "return x + y + z"



# Generated at 2022-06-21 18:32:19.465488
# Unit test for function warn
def test_warn():
    import io
    import sys
    
    backup = sys.stderr
    sys.stderr = io.StringIO()  # Block stderr

    warn('foo')

    content = sys.stderr.getvalue()
    sys.stderr = backup

    assert content == messages.warn('foo') + '\n'

# Generated at 2022-06-21 18:32:29.433799
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate('_py_')
    v2 = VariablesGenerator.generate('_py_')
    assert v1 != v2
    assert v1.startswith('_py_backwards_')
    assert v2.startswith('_py_backwards_')
    assert len(v1) - len(v2) > 0

# Generated at 2022-06-21 18:32:29.757200
# Unit test for function get_source

# Generated at 2022-06-21 18:32:30.736168
# Unit test for function get_source
def test_get_source():
    def test_fn():
        return 1

    assert get_source(test_fn) == 'return 1'



# Generated at 2022-06-21 18:32:35.181805
# Unit test for function warn
def test_warn():
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        warn('warned')
        assert sys.stderr.getvalue() == messages.warn('warned') + '\n'
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-21 18:32:41.741892
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == '''def get_source(fn: Callable[..., Any]) -> str:
    "Returns source code of the function."
    source_lines = getsource(fn).split('\\n')
    padding = len(re.findall(r'^(\\s*)', source_lines[0])[0])
    return '\\n'.join(line[padding:] for line in source_lines)
'''

# Generated at 2022-06-21 18:32:52.806177
# Unit test for function debug
def test_debug():
    debug_msg = []
    def get_message():
        debug_msg.append('get_message')
        return 'debug_msg'
    with mock.patch('sys.stderr') as fake_stderr:
        debug(get_message)
        assert [mock.call.write('DEBUG: debug_msg\n')] == fake_stderr.write.call_args_list
        assert debug_msg == []
    with mock.patch('sys.stderr') as fake_stderr:
        settings.debug = True
        debug(get_message)
        assert [mock.call.write('DEBUG: debug_msg\n')] == fake_stderr.write.call_args_list
        assert debug_msg == ['get_message']



# Generated at 2022-06-21 18:32:56.732207
# Unit test for function get_source
def test_get_source():
    def foo(x, y):
        z = x + y
        return z
    s=get_source(foo)
    print(s)
    assert s=='def foo(x, y):\n    z = x + y\n    return z'



# Generated at 2022-06-21 18:32:58.435657
# Unit test for function warn
def test_warn():
    assert get_messages(warn, 'message') == [messages.warn('message')]


# Generated at 2022-06-21 18:32:59.448397
# Unit test for function warn
def test_warn():
    assert warn('Hello world!') == None

# Generated at 2022-06-21 18:33:03.174243
# Unit test for function get_source
def test_get_source():
    # Example of function
    def my_func():
        def inner_func():
            pass
        pass

    # Source code of the example

# Generated at 2022-06-21 18:33:11.678995
# Unit test for function warn
def test_warn():
    ImportWarning = type('ImportWarning', (ImportWarning,), {})
    with warnings.catch_warnings(record=True) as issued_warnings:
        warn('test warning')

        assert len(issued_warnings) == 1
        assert isinstance(issued_warnings[0].message, ImportWarning)



# Generated at 2022-06-21 18:33:16.096302
# Unit test for function warn
def test_warn():
    _print = print
    _sys_stderr = sys.stderr

    try:
        output_msgs = []
        sys.stderr = output_msgs
        print = output_msgs.append
        warn('test')
        assert output_msgs == [messages.warn('test')]
    finally:
        print = _print
        sys.stderr = _sys_stderr
        pass

# Generated at 2022-06-21 18:33:25.357036
# Unit test for function debug
def test_debug():
    mock_print = unittest.mock.Mock()
    mock_settings = unittest.mock.Mock(debug=True)
    with unittest.mock.patch.dict('sys.modules', {
        'pdb_backwards.conf.settings': mock_settings,
    }):
        with unittest.mock.patch.object(sys, 'stderr', mock_print):
            debug(lambda: 'output')
            mock_print.assert_called_once_with(messages.debug('output'), end='')



# Generated at 2022-06-21 18:33:31.380255
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch('builtins.print'), patch('sys.stderr'):
        settings.debug = True
        debug(lambda: 'message 1')
        debug(lambda: 'message 2')
    assert print.call_count == 2
    assert sys.stderr == print.call_args_list[0][1]['file']
    assert sys.stderr == print.call_args_list[1][1]['file']
    assert print.call_args_list[0][0][0] == messages.debug('message 1')
    assert print.call_args_list[1][0][0] == messages.debug('message 2')
    with patch('builtins.print'), patch('sys.stderr'):
        settings.debug = False

# Generated at 2022-06-21 18:33:32.915763
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-21 18:33:35.805131
# Unit test for function warn
def test_warn():
    for warning in warnings.catch_warnings(record=True):
        warn('hello')
        assert warning.message.args[0].strip() == 'warning: hello'



# Generated at 2022-06-21 18:33:36.902431
# Unit test for function debug
def test_debug():
    debug(lambda: 'Debug message')


# Generated at 2022-06-21 18:33:48.035166
# Unit test for function debug
def test_debug():
    import sys
    import mock
    debug.__module__ = 'py_backwards'
    with mock.patch('py_backwards.messages.debug') as mock_messages_debug:
        with mock.patch('sys.stderr', new=mock.Mock()):
            debug(lambda: 'x' + 'y')
            mock_messages_debug.assert_called_once_with('xy')
            sys.stderr.write.assert_called_once_with(mock_messages_debug.return_value + '\n')
    with mock.patch('py_backwards.messages.debug') as mock_messages_debug:
        with mock.patch('sys.stderr', new=mock.Mock()):
            settings.debug = False

# Generated at 2022-06-21 18:33:53.882578
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('x') == '_py_backwards_x_0'
    assert generator.generate('x') == '_py_backwards_x_1'
    assert generator.generate('y') == '_py_backwards_y_2'
    assert generator.generate('x') == '_py_backwards_x_3'


# Generated at 2022-06-21 18:33:56.756406
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'



# Generated at 2022-06-21 18:34:05.194384
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-21 18:34:10.603188
# Unit test for function get_source
def test_get_source():
    source = \
        '    def dummy_function(foo, bar, baz):\n' \
        '        return foo + bar + baz\n'

    def dummy_function(foo, bar, baz):
        return foo + bar + baz

    assert get_source(dummy_function) == source

# Generated at 2022-06-21 18:34:12.821688
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(100):
        assert VariablesGenerator.generate('var') != VariablesGenerator.generate('var')

# Generated at 2022-06-21 18:34:18.928824
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('A') == '_py_backwards_A_0'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_1'
    assert VariablesGenerator.generate('B') == '_py_backwards_B_2'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_3'
    assert VariablesGenerator.generate('B') == '_py_backwards_B_4'

# Generated at 2022-06-21 18:34:19.824607
# Unit test for function warn
def test_warn():
    warn('Warning message')



# Generated at 2022-06-21 18:34:23.141531
# Unit test for function debug
def test_debug():
    with settings.replace(debug=False):
        debug(lambda: 'foo')

    with settings.replace(debug=True):
        debug(lambda: 'bar')



# Generated at 2022-06-21 18:34:26.160535
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'pass'

import unittest
import sys
from contextlib import contextmanager
from io import StringIO


# Generated at 2022-06-21 18:34:29.924456
# Unit test for function debug
def test_debug():
    messages.DEBUG = True
    output = StringIO()
    sys.stderr = output
    debug(lambda: 'Message')
    assert output.getvalue() == '\x1b[35m[DBG] Message\x1b[0m\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:34:33.725842
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate('x')
    assert(v1 == '_py_backwards_x_0')
    assert(VariablesGenerator._counter == 1)

    v2 = VariablesGenerator.generate('x')
    assert(v2 == '_py_backwards_x_1')
    assert(VariablesGenerator._counter == 2)

# Generated at 2022-06-21 18:34:40.174771
# Unit test for function eager
def test_eager():
    @eager
    def fibonacci(n: int) -> Iterable[int]:
        if n <= 2:
            yield 1
        else:
            a, b = 1, 1
            for _ in range(n - 2):
                a, b = b, a + b
                yield b

    assert fibonacci(10) == [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]

# Generated at 2022-06-21 18:34:51.783083
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate("counter")
    assert a == '_py_backwards_counter_0'


# Generated at 2022-06-21 18:34:54.648450
# Unit test for function eager
def test_eager():
    from itertools import count
    @eager
    def lazy_range_gen() -> Iterable[int]:
        for i in count(10):
            yield i

    assert lazy_range_gen() == [10, 11, 12, 13]

# Generated at 2022-06-21 18:34:56.864764
# Unit test for function debug
def test_debug():
    import pytest
    with pytest.raises(SystemExit) as e:
        debug(lambda: 'test')
    assert e.type == SystemExit
    assert e.value.code == 0



# Generated at 2022-06-21 18:35:02.426426
# Unit test for function eager
def test_eager():
    from pytest import raises
    from .messages import make_assert_message
    from .types import Func

    def func(a, b):
        c = a + b
        yield c
        yield c * 2
        yield c * 3

    def func2(a, b):
        c = a + b
        return c * 6

    assert eager(func)(1, 2) == [3, 6, 9]
    assert eager((lambda x: x * 2))(2) == [4]
    assert eager(func2)(1, 2) == 6

    with raises(AssertionError, match=make_assert_message(func)):
        eager(Func('+'))(1, 2)

# Generated at 2022-06-21 18:35:03.864435
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) ==\
        '    assert get_source(test_get_source) ==     '\
        'get_source(test_get_source)'



# Generated at 2022-06-21 18:35:04.621475
# Unit test for function warn

# Generated at 2022-06-21 18:35:09.744596
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    out = StringIO()
    sys.stderr = out
    warn('warn')
    sys.stderr = sys.__stderr__
    assert out.getvalue() == '<b>warn</b>'

# Generated at 2022-06-21 18:35:13.385271
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        warn('%s %s', 'foo', 'bar')
        assert 'foo bar' in mock_stderr.getvalue()



# Generated at 2022-06-21 18:35:17.495690
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as stderr_mock:
        debug(lambda: 'mock message')

        assert "mock message" in stderr_mock.getvalue()


# Generated at 2022-06-21 18:35:23.278553
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(10):
        assert VariablesGenerator.generate(str(i)) == "_py_backwards_"+str(i)+"_"+str(i)
    for i in range(3):
        assert VariablesGenerator.generate(str(i)) != "_py_backwards_"+str(i)+"_"+str(i+3)
    return True


# Generated at 2022-06-21 18:35:36.561967
# Unit test for function debug
def test_debug():
    settings.debug = True
    message = 'test'
    debug(lambda: message)



# Generated at 2022-06-21 18:35:37.454734
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-21 18:35:39.461038
# Unit test for function eager
def test_eager():
    def gen():
        yield 1
        yield 2
    assert eager(gen)() == [1, 2]

# Generated at 2022-06-21 18:35:44.748267
# Unit test for function get_source
def test_get_source():
    """
    Check that get_source returns the same source code in case of multiline
    function
    """
    # Returns
    def function():
        """
        Function docstring
        """
        return 1

    assert get_source(function) == '''
"""
Function docstring
"""
return 1
'''.strip()

# Generated at 2022-06-21 18:35:48.948781
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest
    vg = VariablesGenerator()

    assert(vg.generate("__t") == '_py_backwards__t_0')
    assert(vg.generate("__t") == '_py_backwards__t_1')
    assert(vg.generate("__t") == '_py_backwards__t_2')

# Generated at 2022-06-21 18:35:54.661191
# Unit test for function eager
def test_eager():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    def f(x, y):
        for i in range(len(x)):
            yield x[i] * y[i]
    print(eager(f)(a, b))

# Generated at 2022-06-21 18:36:04.969212
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys
    from contextlib import contextmanager

    # fmt: off
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    # fmt: on

    with captured_output() as (out, err):
        debug(lambda: 'test')

    output = err.getvalue().strip()
    assert output == 'test'

# Generated at 2022-06-21 18:36:07.697084
# Unit test for function get_source
def test_get_source():
    def source_code():
        pass
    assert get_source(source_code) == 'def source_code():\n    pass\n'

# Generated at 2022-06-21 18:36:11.675337
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-21 18:36:13.685200
# Unit test for function get_source
def test_get_source():
    def my_function(a, b):
        x = 0
        return a + b + x


# Generated at 2022-06-21 18:36:39.432297
# Unit test for function warn
def test_warn():
    pass
    #warn('test')



# Generated at 2022-06-21 18:36:44.558929
# Unit test for function get_source
def test_get_source():  
    from ..base import BackwardsTest
    from .backwards import backwards
    from .check import check
    @backwards
    class TestGetSource(BackwardsTest):
        @check
        def test():
            @backwards(test)
            def testtest():
                pass
            pass
    result = TestGetSource.test.testtest.source
    assert result.strip() == 'pass', result



# Generated at 2022-06-21 18:36:46.257384
# Unit test for function get_source
def test_get_source():
    def test():
        # Indentation is necessary for testing
        return 1

    assert get_source(test) == 'return 1'

# Generated at 2022-06-21 18:36:52.386874
# Unit test for function debug
def test_debug():
    class MiniStringIO(list):
        def __init__(self) -> None:
            super().__init__()

        @property
        def getvalue(self) -> str:
            return '\n'.join(self) + '\n'

    fake_stderr = MiniStringIO()

    def run(debug_level: bool, message_text: str) -> None:
        fake_stderr.clear()
        settings.debug = debug_level
        debug(lambda: message_text)

    run(False, 'test_message')
    assert fake_stderr.getvalue == ''

    run(True, 'test_message')

# Generated at 2022-06-21 18:36:53.527665
# Unit test for function get_source
def test_get_source():
    def f():
        def nested(): ...
    assert get_sourc

# Generated at 2022-06-21 18:36:56.797519
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        return (i for i in range(0, 10))

    assert foo() == eager(foo)()


# Generated at 2022-06-21 18:36:59.076657
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'test')
    settings.debug = True
    debug(lambda: 'test')

# Generated at 2022-06-21 18:37:07.363672
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """Ensure that VariablesGenerator should be unique."""
    assert VariablesGenerator()._counter == 0
    assert VariablesGenerator()._counter == 1
    assert VariablesGenerator()._counter == 2
    assert VariablesGenerator()._counter == 3
    assert VariablesGenerator()._counter == 4
    assert VariablesGenerator()._counter == 5
    assert VariablesGenerator()._counter == 6
    assert VariablesGenerator()._counter == 7
    assert VariablesGenerator()._counter == 8
    assert VariablesGenerator()._counter == 9

# Generated at 2022-06-21 18:37:10.495906
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'



# Generated at 2022-06-21 18:37:13.433808
# Unit test for function eager
def test_eager():
    def test_function():
        for i in range(5):
            yield i*i
    assert eager(test_function)() == [0, 1, 4, 9, 16]

# Generated at 2022-06-21 18:38:13.733095
# Unit test for function get_source
def test_get_source():
    def worx():
        pass

    assert get_source(worx) == 'pass'

    def worx():
        pass

    def worx():
        pass

    if True:
        def worx():
            pass
    assert get_source(worx) == 'pass'

    def worx(a, b):
        pass

    assert get_source(worx) == 'pass'

    def worx():
        pass

    assert get_source(worx) == 'pass'

# Generated at 2022-06-21 18:38:21.257386
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('c') == '_py_backwards_c_3'



# Generated at 2022-06-21 18:38:22.271130
# Unit test for function get_source

# Generated at 2022-06-21 18:38:25.902737
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-21 18:38:28.313865
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield
    assert gen() == [None]



# Generated at 2022-06-21 18:38:29.344707
# Unit test for function get_source

# Generated at 2022-06-21 18:38:33.098748
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    
    assert get_source(func) == 'pass'

    def func():
        '''
        This is a function.
        '''

    assert get_source(func) == '        \'\'\'\n        This is a function.\n        \'\'\'\n'

    def func():
        pass

    assert get_source(func) == 'pass'

# Generated at 2022-06-21 18:38:38.370166
# Unit test for function warn
def test_warn():
    import sys
    import io

    capturedOutput = io.StringIO()
    sys.stderr = capturedOutput
    warn('foobar')
    sys.stderr = sys.__stderr__
    assert capturedOutput.getvalue() == messages.warn('foobar') + '\n'

# Generated at 2022-06-21 18:38:41.760889
# Unit test for function warn
def test_warn():
    output = ''
    sys.stderr = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')
    warn('test')
    assert output == messages.warn('test')



# Generated at 2022-06-21 18:38:49.054932
# Unit test for function warn
def test_warn():
    # 1st use case
    messages.warn_color_on = False
    warn('message')
    assert 'message' in sys.stderr.getvalue().replace('\x1b[0m','')

    # 2nd use case
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

    messages.warn_color_on = True
    warn('message')
    assert '\x1b[91m' in sys.stderr.getvalue()

