

# Generated at 2022-06-21 18:31:03.396789
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("Mr_0") == '_py_backwards_Mr_0_0'
    assert VariablesGenerator.generate("Mr_0") == '_py_backwards_Mr_0_1'
    assert VariablesGenerator.generate("Mr_0") == '_py_backwards_Mr_0_2'

# Generated at 2022-06-21 18:31:11.138428
# Unit test for function get_source
def test_get_source():
    def test_func(arg1: int, arg2: str='foo', *args) -> str:
        if arg1 > 1:
            print(arg2)
            return 'baz'
        elif arg1 < 1:
            return 'bar'
        return 'foo'

    expected = textwrap.dedent('''
        if arg1 > 1:
            print(arg2)
            return 'baz'
        elif arg1 < 1:
            return 'bar'
        return 'foo'
    ''').strip()

    assert get_source(test_func) == expected

# Generated at 2022-06-21 18:31:11.999023
# Unit test for function warn
def test_warn():
    warn("test")

# Generated at 2022-06-21 18:31:18.214602
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('_var') == '_py_backwards__var_0'
    assert gen.generate('_var') == '_py_backwards__var_1'
    assert gen.generate('_var') == '_py_backwards__var_2'

if __name__ == '__main__':
    test_VariablesGenerator()

# Generated at 2022-06-21 18:31:21.241544
# Unit test for function get_source
def test_get_source():
    def foo():
        # hello world
        pass
    assert get_source(foo) == '# hello world\n        pass'

# Generated at 2022-06-21 18:31:25.160417
# Unit test for function debug
def test_debug():
    from .test_tool import mock

    with mock.patch('sys.stderr') as stderr:
        debug(lambda: 'some text')
    stderr.write.assert_called_once_with(messages.debug('some text').encode('utf-8'))

# Generated at 2022-06-21 18:31:36.093413
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # list_a is used to store all the generated variables
    list_a = []
    # list_b is used to store the input variables
    list_b = []
    list_c = []

# Generated at 2022-06-21 18:31:37.326396
# Unit test for function eager
def test_eager():
    assert eager(iter)(range(55)) == list(range(55))

# Generated at 2022-06-21 18:31:40.028489
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg1, vg2 = VariablesGenerator(), VariablesGenerator()
    assert vg1.generate('test') != vg2.generate('test')

# Generated at 2022-06-21 18:31:40.915612
# Unit test for function warn
def test_warn():
    warn('testing warn')
    assert True

# Generated at 2022-06-21 18:31:45.405787
# Unit test for function eager
def test_eager():
    wishes = eager(lambda: iter([1, 2, 3]))
    got = wishes()
    assert wishes == got



# Generated at 2022-06-21 18:31:49.852548
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn("Test")
    sys.stderr.seek(0)
    error_output_lines = sys.stderr.readlines()
    assert error_output_lines[0] == '\x1b[33m  \x1b[33mwarn\x1b[0m\x1b[33m:\x1b[0m Test\x1b[0m\n'


# Generated at 2022-06-21 18:31:50.974251
# Unit test for function get_source
def test_get_source():
    from inspect import getsource
    assert get_source(test_get_source) == getsource(test_get_source)

# Generated at 2022-06-21 18:31:52.029998
# Unit test for function warn
def test_warn():
    assert warn('hello') == None



# Generated at 2022-06-21 18:31:55.798619
# Unit test for function get_source
def test_get_source():
    source = "def foo():\n    pass"
    eval(source)
    foo_source = get_source(foo)
    assert source.strip() == foo_source.strip()

# Generated at 2022-06-21 18:32:04.226525
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from py_backwards.conf import settings
    settings.debug = True
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: "Hello World")
    mock_stderr.write.assert_called_once_with(messages.debug("Hello World") + '\n')
    settings.debug = False
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: "Hello World")
    assert not mock_stderr.write.called

# Generated at 2022-06-21 18:32:06.287881
# Unit test for function eager
def test_eager():
    @eager
    def test():
        return [1, 2, 3]
    assert list(test()) == [1, 2, 3]

# Generated at 2022-06-21 18:32:09.630550
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        for i in range(10):
            for j in range(i):
                yield i * j

    assert foo() == list(range(0, 10))[4:9]



# Generated at 2022-06-21 18:32:11.716070
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    assert eager(test)() == [1, 2, 3]

# Generated at 2022-06-21 18:32:15.411258
# Unit test for function eager
def test_eager():
    from typing import Iterable

    @eager
    def foo() -> Iterable[float]:
        for i in range(100):
            yield float(i)

    assert isinstance(foo(), list)
    assert all(isinstance(v, float) for v in foo())

# Generated at 2022-06-21 18:32:22.560261
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> None:
        yield '1'
        yield '2'

    assert gen() == ['1', '2']

# Generated at 2022-06-21 18:32:25.568851
# Unit test for function get_source
def test_get_source():
    def fn():
        return 1 + \
            2

    assert get_source(fn) == 'return 1 + \\\n        2'

# Generated at 2022-06-21 18:32:33.811101
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert [VariablesGenerator.generate('var') for i in range(10)] == ['_py_backwards_var_0', '_py_backwards_var_1',
                                                                      '_py_backwards_var_2', '_py_backwards_var_3',
                                                                      '_py_backwards_var_4', '_py_backwards_var_5',
                                                                      '_py_backwards_var_6', '_py_backwards_var_7',
                                                                      '_py_backwards_var_8', '_py_backwards_var_9']

# Generated at 2022-06-21 18:32:37.542040
# Unit test for function eager
def test_eager():
    @eager
    def generate_numbers(n: int) -> Iterable[int]:
        yield from range(n)

    assert generate_numbers(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:32:45.961703
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest

    generator1 = VariablesGenerator()
    generator2 = VariablesGenerator()

    assert generator1._counter == 0
    assert generator1._counter == 0

    assert generator1.generate('var') == '_py_backwards_var_0'
    assert generator1.generate('var') == '_py_backwards_var_1'
    assert generator2.generate('var') == '_py_backwards_var_2'

    assert generator1._counter == 2
    assert generator2._counter == 2

    assert generator2.generate('var') == '_py_backwards_var_3'
    assert generator2.generate('var') == '_py_backwards_var_4'
    assert generator1.generate('var') == '_py_backwards_var_5'



# Generated at 2022-06-21 18:32:57.334870
# Unit test for function debug
def test_debug():
    import unittest
    from . import test_utils
    from .test_utils import TestBase

    class TestDebug(TestBase):
        def test_debug_printing(self):
            with test_utils.captured_output() as (out, err):
                debug(lambda: 'Message')
                output = err.getvalue().strip()
                self.assertEqual(output, '\x1b[90mMessage\x1b[0m')

        def test_debug_not_printing(self):
            with test_utils.captured_output() as (out, err):
                settings.debug = False
                debug(lambda: 'Message')
                output = err.getvalue().strip()
                self.assertEqual(output, '')

    TestDebug.main()

# Generated at 2022-06-21 18:33:00.615779
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for expected_variable, i in zip([0, 1, 2, 3, 4, 5], range(6)):
        assert VariablesGenerator.generate('x') == '_py_backwards_x_0'

# Generated at 2022-06-21 18:33:04.663914
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('x') == '_py_backwards_x_0'
    assert vg.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-21 18:33:09.504700
# Unit test for function warn
def test_warn():
    import sys
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warn("message")
        assert len(w) == 1
        assert str(w[0].message) == "message"
        assert issubclass(w[0].category, UserWarning)
        assert w[0].filename == sys.stderr.name


# Generated at 2022-06-21 18:33:11.678464
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator._counter)
    print(VariablesGenerator.generate("test"), VariablesGenerator.generate("test"))

# Generated at 2022-06-21 18:33:24.645896
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    o = VariablesGenerator()
    assert o.generate('a') == '_py_backwards_a_0'
    assert o.generate('a') == '_py_backwards_a_1'
    assert o.generate('a') == '_py_backwards_a_2'
    assert o.generate('b') == '_py_backwards_b_3'
    assert o.generate('c') == '_py_backwards_c_4'

# Generated at 2022-06-21 18:33:25.222513
# Unit test for function warn
def test_warn():
    warn('dummy')

# Generated at 2022-06-21 18:33:27.528983
# Unit test for function get_source
def test_get_source():
    def foo():
        """
            This is a test function.
            It has few lines of code.
            As well as multi-line comment.
        """
        return 1


# Generated at 2022-06-21 18:33:28.879009
# Unit test for function warn
def test_warn():
    warn('message')
    warn('message')
    warn('message')


if __name__ == "__main__":
    test_warn()

# Generated at 2022-06-21 18:33:29.757454
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')



# Generated at 2022-06-21 18:33:32.507883
# Unit test for function eager
def test_eager():
    def fn():
        yield 1
        yield 2

    assert eager(fn)() == [1, 2]

# Generated at 2022-06-21 18:33:35.856746
# Unit test for function eager
def test_eager():
    @eager
    def generate(n: int) -> Iterable[int]:
        for i in range(n):
            yield 2 * i
    assert generate(3) == [0, 2, 4]

# Generated at 2022-06-21 18:33:37.853124
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
    assert test() == [1, 2]

# Generated at 2022-06-21 18:33:43.578901
# Unit test for function get_source
def test_get_source():
    """
    >>> def get_source2(fn):
    ...     return get_source(fn).replace('\n', '').replace(' ', '')
    ...
    >>> def function():
    ...     a = 1
    ...     b = 2
    ...     return a + b
    >>> assert get_source2(function) == 'a=1;b=2;returna+b'
    """

# Generated at 2022-06-21 18:33:49.401023
# Unit test for function warn
def test_warn():
    pass
    # from io import StringIO
    # from contextlib import redirect_stdout
    #
    # f = StringIO()
    # with redirect_stdout(f):
    #     warn('bug')
    #
    # assert f.getvalue() == '\x1b[33mWARNING: bug\x1b[0m\n'



# Generated at 2022-06-21 18:33:57.190117
# Unit test for function debug
def test_debug():
    # Clear settings
    old_debug_value = settings.debug
    settings.debug = True

    try:
        # Check that debug prints properly
        debug(lambda: 'ONE')
    finally:
        settings.debug = old_debug_value

# Generated at 2022-06-21 18:33:59.781730
# Unit test for function eager
def test_eager():
    @eager
    def test() -> Iterable[str]:
        yield "1"
        yield "2"
    assert test() is not None

# Generated at 2022-06-21 18:34:06.390203
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        def get_message():
            return 'test'
        debug(get_message)
    assert out.getvalue() == ''

    with contextlib.redirect_stderr(out):
        def get_message():
            return 'test'
        settings.debug = True
        debug(get_message)
        settings.debug = False

    assert out.getvalue().strip() == 'DEBUG: test'

# Generated at 2022-06-21 18:34:07.668416
# Unit test for function warn
def test_warn():
    warn("warn")



# Generated at 2022-06-21 18:34:10.479017
# Unit test for function warn
def test_warn():
    import sys
    warn("initial test message")
    sys.stderr.flush()
    assert sys.stderr.getvalue() == "uh-oh! initial test message\n"

# Generated at 2022-06-21 18:34:13.096978
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    for i in range(100):
        assert v.generate('a') == '_py_backwards_a_' + str(i)



# Generated at 2022-06-21 18:34:14.779513
# Unit test for function eager
def test_eager():
    assert eager(lambda x: (yield y) for y in range(x))(3) == [0, 1, 2]

# Generated at 2022-06-21 18:34:19.012906
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('test')
    warn('test test')
    sys.stderr = sys.__stderr__
    assert sys.stderr.getvalue() == messages.warn('test') + '\n' + messages.warn('test test') + '\n'


# Generated at 2022-06-21 18:34:21.206860
# Unit test for function eager
def test_eager():
    assert eager(x for x in range(4))() == [0, 1, 2, 3]

# Generated at 2022-06-21 18:34:23.595721
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    try:
        debug(lambda: 'Test message')
    finally:
        settings.debug = False

# Generated at 2022-06-21 18:34:35.818026
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate("a") == "_py_backwards_a_0"
    assert generator.generate("b") == "_py_backwards_b_1"


# Generated at 2022-06-21 18:34:40.457677
# Unit test for function eager
def test_eager():
    lst = []
    @eager
    def foo():
        lst.append(1)
        yield
        lst.append(2)
    foo()
    assert lst == [1,2]



# Generated at 2022-06-21 18:34:44.747380
# Unit test for function warn
def test_warn():
    from unittest import mock
    from . import messages

    with mock.patch('sys.stderr', new=StringIO()) as mock_stderr:
        warn('message')

        mock_stderr.seek(0)
        assert mock_stderr.read() == messages.warn('message') + '\n'



# Generated at 2022-06-21 18:34:48.899365
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 'x'
        yield 'y'
        yield 'z'

    assert type(foo()) == list
    assert foo() == ['x', 'y', 'z']



# Generated at 2022-06-21 18:34:51.824341
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'


# Generated at 2022-06-21 18:34:56.172630
# Unit test for function eager
def test_eager():
    def test_gen():
        for i in range(5):
            yield i
    a = eager(test_gen)
    assert a == [0, 1, 2, 3, 4]
    def test_gen2(b):
        for i in range(b):
            yield i
    a = eager(test_gen2)(5)
    assert a == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:35:04.757156
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class TestVariablesGenerator:
        def __init__(self, variable: str) -> None:
            self.variable = variable
            self.generator = VariablesGenerator()
        def generate(self):
            return self.generator.generate(self.variable)
    gen = TestVariablesGenerator('x')
    xs = [gen.generate() for i in range(5)]
    assert xs == ['_py_backwards_x_0', '_py_backwards_x_1', '_py_backwards_x_2', '_py_backwards_x_3', '_py_backwards_x_4']

# Generated at 2022-06-21 18:35:08.213700
# Unit test for function warn
def test_warn():
    # TODO: Figure out how to create file-like object and test it with text
    # interface
    pass



# Generated at 2022-06-21 18:35:15.503314
# Unit test for function debug
def test_debug():
    class MyClass:
        def __init__(self):
            self.my_attr = 1

        def func(self):
            debug(lambda: "my_attr = {}".format(self.my_attr))

    with captured_stderr() as output:
        MyClass().func()

    assert not output.getvalue().strip()
    settings.debug = True
    with captured_stderr() as output:
        MyClass().func()
    assert "my_attr = 1" in output.getvalue()
    settings.debug = False



# Generated at 2022-06-21 18:35:22.029609
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_generator = VariablesGenerator
    assert var_generator._counter == 0
    var_generator.generate('a')
    assert var_generator._counter == 1
    var_generator.generate('b')
    var_generator.generate('c')
    var_generator.generate('b')
    var_generator.generate('c')
    var_generator.generate('c')
    assert var_generator._counter == 6
    assert var_generator.generate('b') == '_py_backwards_b_4'
    assert var_generator.generate('c') == '_py_backwards_c_5'
    assert var_generator.generate('a') == '_py_backwards_a_0'



# Generated at 2022-06-21 18:35:47.559193
# Unit test for function get_source
def test_get_source():
    def foo():
        print('hello, world')

    foo_source = get_source(foo)
    assert foo_source in ['print("hello, world")\n', 'print(\'hello, world\')\n']



# Generated at 2022-06-21 18:35:53.213254
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print('***************** Unit test for constructor of class VariablesGenerator *****************')
    test = VariablesGenerator()
    print(test.generate('variable_1'))
    print(test.generate('variable_2'))
    print(test.generate('variable_3'))

# Generated at 2022-06-21 18:36:00.575989
# Unit test for function debug
def test_debug():
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'ABC')

    assert '' == f.getvalue()

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'ABC')

    assert '\x1b[36mDEBUG: ABC\x1b[0m' == f.getvalue().strip()
    settings.debug = False

# Generated at 2022-06-21 18:36:03.830615
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('a') == '_py_backwards_a_0'
    assert generator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-21 18:36:08.475610
# Unit test for function get_source
def test_get_source():
    def fun():
        """docstring"""
        if True:
            pass
        if True:
            pass

# Generated at 2022-06-21 18:36:10.330016
# Unit test for function debug
def test_debug():
    assert debug(lambda: "Hello World!") == None


# Generated at 2022-06-21 18:36:14.157990
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('foo') == '_py_backwards_foo_0'
    assert generator.generate('foo') == '_py_backwards_foo_1'
    assert generator.generate('foo') == '_py_backwards_foo_2'

# Generated at 2022-06-21 18:36:18.501452
# Unit test for function warn
def test_warn():
    try:
        out = StringIO()
        sys.stderr = out
        warn('Test')
        assert out.getvalue() == messages.warn('Test') + '\n'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-21 18:36:25.938436
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'


# Generated at 2022-06-21 18:36:30.580767
# Unit test for function get_source
def test_get_source():
    def foo(a, b=1, *args, c=4, **kwargs):
        return None

    assert get_source(foo) == dedent('''\
        def foo(a, b=1, *args, c=4, **kwargs):
            return None
    ''')

# Generated at 2022-06-21 18:37:28.729435
# Unit test for function warn
def test_warn():
    import io
    import sys
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    warn('message')
    assert 'warn' in sys.stderr.getvalue()
    assert 'message' in sys.stderr.getvalue()


# Generated at 2022-06-21 18:37:31.317481
# Unit test for function get_source
def test_get_source():
    assert get_source(warn) == 'def warn(message: str) -> None:\n    print(messages.warn(message), file=sys.stderr)'



# Generated at 2022-06-21 18:37:33.550601
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('test warn')
    assert sys.stderr.getvalue().strip() == messages.warn('test warn')



# Generated at 2022-06-21 18:37:35.669343
# Unit test for function eager
def test_eager():
    def f1():
        yield 1
        yield 2
        yield 3

    assert eager(f1)() == [1, 2, 3]


# Generated at 2022-06-21 18:37:37.607878
# Unit test for function eager
def test_eager():
    from .test_eager import test_eager
    test_eager()

# Generated at 2022-06-21 18:37:41.142912
# Unit test for function eager
def test_eager():
    from functools import reduce
    assert eager(lambda: [1, 2, 3])(reduce, lambda a, b: a + b) == 6


# Generated at 2022-06-21 18:37:43.508048
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]



# Generated at 2022-06-21 18:37:47.134577
# Unit test for function eager
def test_eager():
    @eager
    def foo(*args, **kwargs):
        return args + ['kwargs=', str(kwargs)]

    assert foo(1, 2, 3, name='Andrew', age=42) == [1, 2, 3, 'kwargs=', "{'age': 42, 'name': 'Andrew'}"]

# Generated at 2022-06-21 18:37:54.358652
# Unit test for function warn
def test_warn():
    from unittest import TestCase
    from unittest.mock import patch

    class TestWarn(TestCase):
        @patch('sys.stderr')
        def test_simple(self, mock_stderr):
            warn('Hello!')
            mock_stderr.write.assert_called_once_with('  \x1b[33mWarning:\x1b[0m Hello!\n')

# Generated at 2022-06-21 18:37:56.729079
# Unit test for function get_source
def test_get_source():
    def some_function(x):
        pass

    assert get_source(some_function) == 'def some_function(x):\n    pass'



# Generated at 2022-06-21 18:39:53.848444
# Unit test for function warn
def test_warn():
    # should print warning to stderr
    warn('test')


test_warn()

# Generated at 2022-06-21 18:39:55.586437
# Unit test for function get_source
def test_get_source():
    def get_a():
        return 1

    assert get_source(get_a) == 'return 1'


# Generated at 2022-06-21 18:39:58.037974
# Unit test for function warn
def test_warn():
    import io
    f = io.StringIO()
    with redirect_stderr(f):
        warn('hello')
    assert f.getvalue() == '\x1b[31mhello\x1b[0m\n'


# Generated at 2022-06-21 18:40:00.125099
# Unit test for function debug

# Generated at 2022-06-21 18:40:05.057049
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr

    f = StringIO()
    with redirect_stderr(f):
        warn('warn')

    assert f.getvalue() == messages.warn('warn') + '\n'



# Generated at 2022-06-21 18:40:09.524444
# Unit test for function eager
def test_eager():
    def list_of_generators():
        for i in range(2):
            for j in range(3):
                yield (i, j)
    assert eager(list_of_generators)() == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2)]
    

# Generated at 2022-06-21 18:40:11.091291
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('') != vg.generate('')


# Generated at 2022-06-21 18:40:12.045394
# Unit test for function eager
def test_eager():
    assert eager([0, 1, 2]) == [0, 1, 2]

# Generated at 2022-06-21 18:40:13.150861
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2

    assert foo() == [1, 2]

# Generated at 2022-06-21 18:40:14.710329
# Unit test for function eager
def test_eager():
    def generator():
        yield 'a'
        yield 'b'
        yield 'c'

    assert eager(generator)() == ['a', 'b', 'c']