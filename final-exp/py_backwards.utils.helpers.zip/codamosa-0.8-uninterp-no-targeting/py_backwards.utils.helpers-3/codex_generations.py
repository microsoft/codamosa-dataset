

# Generated at 2022-06-21 18:30:36.218101
# Unit test for function get_source

# Generated at 2022-06-21 18:30:40.608674
# Unit test for function debug
def test_debug():
    settings.debug = False
    message = 'some message'
    debug(lambda: message)  # pylint: disable=no-value-for-parameter
    settings.debug = True
    debug(lambda: message)  # pylint: disable=no-value-for-parameter



# Generated at 2022-06-21 18:30:43.822847
# Unit test for function eager
def test_eager():
    @eager
    def test() -> Iterable[int]:
        c = 0
        while True:
            yield c
            c += 1

    assert test(0, 1) == [0, 1]

# Generated at 2022-06-21 18:30:47.893966
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        message = 'Warning message.'
        warn(message)
        print(fake_stderr.getvalue())
        assert fake_stderr.getvalue() == messages.warn(message) + '\n'



# Generated at 2022-06-21 18:30:54.219861
# Unit test for function debug
def test_debug():
    class TestDebug:
        def __init__(self):
            self.messages = []

        def print(self, message, file=None):
            self.messages.append(message)

    test_debug = TestDebug()
    sys.stderr = test_debug
    settings.debug = True
    debug(lambda: 'abc')
    settings.debug = False
    debug(lambda: 'def')
    sys.stderr = sys.__stderr__
    assert test_debug.messages == ['\x1b[2mabc\x1b[0m']

# Generated at 2022-06-21 18:30:59.032269
# Unit test for function get_source
def test_get_source():
    def some_function():
        """Some docstring."""
        x = 1
    assert get_source(some_function) == '"""Some docstring."""\nx = 1'
    assert get_source(test_get_source) != ''



# Generated at 2022-06-21 18:31:00.391702
# Unit test for function get_source

# Generated at 2022-06-21 18:31:03.821252
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass\n'
    def bar():
        a = 1
        b = 2
    assert get_source(bar) == 'def bar():\n    a = 1\n    b = 2\n'

# Generated at 2022-06-21 18:31:09.614111
# Unit test for function get_source
def test_get_source():
    def foo():
        bar()

    assert get_source(foo) == 'bar()'
    assert get_source(foo).count('\n') == 0

    def bar():
        baz()
        if qux:
            foo()

    assert get_source(bar) == 'baz()\nif qux:\n    foo()'
    assert get_source(bar).count('\n') == 2

# Generated at 2022-06-21 18:31:14.893121
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from aiounittest import asyncio_run, futurized
    from .test_utils import TestCase

    class VariablesGeneratorTest(TestCase):
        async def test_generate(self):
            self.assertEqual(VariablesGenerator.generate("x"), "_py_backwards_x_0")
            self.assertEqual(VariablesGenerator.generate("y"), "_py_backwards_y_1")

    asyncio_run(futurized(VariablesGeneratorTest().run()))

# Generated at 2022-06-21 18:31:22.315366
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == "_py_backwards_x_0"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_1"
    assert VariablesGenerator.generate("y") != VariablesGenerator.generate("y")

# Generated at 2022-06-21 18:31:25.411782
# Unit test for function warn
def test_warn():
    messages.warn = (lambda msg: 'WARN: ' + msg)
    try:
        warn('warn message')
    except AssertionError:
        raise AssertionError()



# Generated at 2022-06-21 18:31:35.634182
# Unit test for function debug
def test_debug():
    from io import StringIO
    output = StringIO()
    backup_debug = sys.stderr
    sys.stderr = output
    settings.debug = True
    debug(lambda: "Debug message")
    # checking if it prints debug message in sys.stderr
    assert output.getvalue().strip() == "Debug message"
    sys.stderr = backup_debug
    # checking if it doesn't print debug message when settings.debug is False
    output = StringIO()
    backup_debug = sys.stderr
    sys.stderr = output
    settings.debug = False
    debug(lambda: "Debug message")
    assert output.getvalue().strip() == ""
    sys.stderr = backup_debug

# Generated at 2022-06-21 18:31:37.240831
# Unit test for function get_source
def test_get_source():
    def foo():
        pass # noqa

    assert get_source(foo) == 'pass'



# Generated at 2022-06-21 18:31:39.571329
# Unit test for function get_source
def test_get_source():
    def some_func():
        pass
    assert get_source(some_func) == "def some_func():\n    pass"



# Generated at 2022-06-21 18:31:44.680503
# Unit test for function debug
def test_debug():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stderr = captured_output

    debug(lambda: 'hello world')
    assert captured_output.getvalue() == ''
    settings.debug = True
    debug(lambda: 'hello world')
    assert captured_output.getvalue() == messages.debug('hello world') + '\n'
    settings.debug = Fa

# Generated at 2022-06-21 18:31:47.947708
# Unit test for function eager
def test_eager():
    import pytest
    @eager
    def test():
        yield 1
        yield 2
        yield 3
        yield 4
    assert test() == [1, 2, 3, 4]
    def test():
        yield 1
        yield 2
        yield 3
        yield 4

# Generated at 2022-06-21 18:31:51.037527
# Unit test for function eager
def test_eager():
    @eager
    def my_fn():
        yield 1
        yield 2

    assert my_fn() == [1, 2]



# Generated at 2022-06-21 18:31:56.516122
# Unit test for function eager
def test_eager():
    @eager
    def range_n_times(max: int) -> Iterable[int]:
        for n in range(max):
            yield n

    assert range_n_times(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:32:07.391329
# Unit test for function warn
def test_warn():
    import sys
    import io
    import warnings

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        # Try to capture stderr
        saved_stderr = sys.stderr
        try:
            out = io.StringIO()
            sys.stderr = out
            warn("some message")
            stderr = out.getvalue()
        finally:
            sys.stderr = saved_stderr

        assert len(w) == 1
        assert issubclass(w[-1].category, RuntimeWarning)
        assert "some message" in str(w[-1].message)
        assert "some message" in stderr
        assert "warn" in stderr

# Generated at 2022-06-21 18:32:11.296886
# Unit test for function get_source
def test_get_source():
    def fn():
        return 1

    assert get_source(fn) == 'return 1'



# Generated at 2022-06-21 18:32:18.100574
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from unittest import TestCase

    class TestDebug(TestCase):

        def test_debug_in_debug_mode_print(self):
            with patch('sys.stderr', new=open(os.devnull, 'w')):
                settings.debug = True
                debug(lambda: 'test_message')

        def test_debug_not_in_debug_mode_no_print(self):
            with patch('sys.stderr', new=open(os.devnull, 'w')):
                settings.debug = False
                debug(lambda: 'test_message')

# Generated at 2022-06-21 18:32:22.005660
# Unit test for function eager
def test_eager():
    def test_func(a: int) -> Iterable[int]:
        for i in range(a):
            yield i
    assert test_func(3) == [0, 1, 2]
    assert eager(test_func)(3) == [0, 1, 2]

# Generated at 2022-06-21 18:32:26.020645
# Unit test for function get_source
def test_get_source():
    def add(a: int, b: int) -> int:
        return a + b

    source_code = get_source(add)
    assert source_code == "return a + b"



# Generated at 2022-06-21 18:32:28.979968
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda:  "hello world")
    settings.debug = False
    debug(lambda:  "hello world")




# Generated at 2022-06-21 18:32:36.786735
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        from unittest.mock import patch
        with patch('sys.stderr') as mock_stderr:
            debug(lambda: 'hello')
            mock_stderr.write.assert_called_once_with('hello\n')

        settings.debug = False
        with patch('sys.stderr') as mock_stderr:
            mock_stderr.write.reset_mock()
            debug(lambda: 'goodbye')
            mock_stderr.write.assert_not_called()

    finally:
        settings.debug = False



# Generated at 2022-06-21 18:32:40.666540
# Unit test for function debug
def test_debug():
    msg = 'test'
    debug(lambda : msg)
    debug(lambda : msg)  # Should be printed only once

    # Fake debug param
    settings.debug = False
    debug(lambda : msg)
    settings.debug = True


# Generated at 2022-06-21 18:32:42.009084
# Unit test for function debug
def test_debug():
    def get_message():
        return "debug message"
    debug(get_message)

# Generated at 2022-06-21 18:32:48.114154
# Unit test for function get_source

# Generated at 2022-06-21 18:32:53.946788
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: 'Debug: ' + x
    settings.debug = True
    from io import StringIO
    with StringIO() as stream:
        old = sys.stderr
        sys.stderr = stream
        debug(lambda: 'debug?')
        sys.stderr = old
        assert 'Debug: debug?' in stream.getvalue()
    settings.debug = False



# Generated at 2022-06-21 18:32:57.511686
# Unit test for function eager
def test_eager():
    @eager
    def fn():
        yield 1
        yield 2
    assert fn() == [1, 2]

# Generated at 2022-06-21 18:32:58.961086
# Unit test for function warn
def test_warn():
    assert '' == str(warn("test_message"))


# Generated at 2022-06-21 18:33:08.397403
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator._counter == 1
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator._counter == 2
    assert VariablesGenerator.generate('c') == '_py_backwards_c_2'
    assert VariablesGenerator._counter == 3
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'
    assert VariablesGenerator._counter == 4


# Generated at 2022-06-21 18:33:14.844571
# Unit test for function warn
def test_warn():
    import io
    import sys

    msg = "hello"

    try:
        # remember old stdout
        old_stdout = sys.stdout
        # replace stdout with a buffer
        sys.stdout = buffer = io.StringIO()
        warn(msg)
        output = buffer.getvalue()
    finally:
        # restore old stdout
        sys.stdout = old_stdout

    # check if we got the expected output
    assert output == '\x1b[33mWARNING: ' + msg + '\x1b[0m\n'


# Generated at 2022-06-21 18:33:19.685276
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen1 = VariablesGenerator()
    gen2 = VariablesGenerator()
    assert gen1.generate("var") == "_py_backwards_var_0"
    assert gen2.generate("var") == "_py_backwards_var_1"


# Generated at 2022-06-21 18:33:21.296533
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1

    assert generator() == [1]

# Generated at 2022-06-21 18:33:27.802115
# Unit test for function warn
def test_warn():
    import io
    import unittest.mock
    import builtins
    import sys

    with unittest.mock.patch.object(builtins, 'print') as mock_print:
        sys.stderr = io.StringIO()
        warn('a')
        mock_print.assert_called_once()
        assert sys.stderr.read() == messages.warn('a') + '\n'



# Generated at 2022-06-21 18:33:31.597684
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        warn('message')
        mock_stderr.seek(0)
        assert mock_stderr.read() == messages.warn('message') + '\n'

# Generated at 2022-06-21 18:33:33.474692
# Unit test for function warn
def test_warn():
    warn('this is a warning')

# Generated at 2022-06-21 18:33:34.505231
# Unit test for function debug
def test_debug():
    debug(lambda: "TEST")

# Generated at 2022-06-21 18:33:41.536269
# Unit test for function get_source
def test_get_source():
    def some_function():
        if True:
            return True

    assert get_source(some_function) == ("if True:\n"
                                         "    return True")

# Generated at 2022-06-21 18:33:43.829287
# Unit test for function debug
def test_debug():
    debug_calls = 0
    # pylint: disable=unused-variable
    @debug
    def foo():
        nonlocal debug_calls
        debug_calls += 1
        return 'foo'
    # pylint: enable=unused-variable

    foo()
    assert debug_calls == 1
    settings.debug = False
    foo()
    assert debug_calls == 1



# Generated at 2022-06-21 18:33:50.723971
# Unit test for function warn
def test_warn():
    import tempfile

    with tempfile.TemporaryFile(mode='r+') as f:
        old_stderr = sys.stderr
        sys.stderr = f
        warn('Hello!')
        sys.stderr.flush()
        f.seek(0)
        assert f.read() == '\x1b[93mHello!\x1b[0m\n'
        sys.stderr = old_stderr

# Generated at 2022-06-21 18:33:51.402940
# Unit test for function warn
def test_warn():
    warn("hello")


# Generated at 2022-06-21 18:33:57.653269
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_4'

# Generated at 2022-06-21 18:33:59.469687
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == list(range(10))


# Generated at 2022-06-21 18:34:06.460296
# Unit test for function debug
def test_debug():
    class FakeStdErr:
        def __init__(self):
            self.messages = []

        def write(self, message: str) -> None:
            self.messages.append(message)

    settings.debug = True
    stderr = sys.stderr
    sys.stderr = FakeStdErr()
    try:
        debug(lambda: 'test message')
        assert sys.stderr.messages == [messages.debug('test message')]
    finally:
        sys.stderr = stderr
        settings.debug = False

# Generated at 2022-06-21 18:34:09.941933
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() is not eager(foo)()
    assert foo() != eager(foo)()
    assert list(foo()) == eager(foo)()

# Generated at 2022-06-21 18:34:12.079197
# Unit test for function eager
def test_eager():
    @eager
    def a():
        yield 1
        yield 2
    assert a() == [1, 2]


# Generated at 2022-06-21 18:34:16.687332
# Unit test for function warn
def test_warn():
    sys.stdout = sys.stderr = BytesIO()
    warn('This is bad!')
    assert sys.stderr.getvalue() == b'\x1b[93mWarning: This is bad!\x1b[0m\n'
    sys.stdout = sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:34:23.240817
# Unit test for function debug
def test_debug():
    settings._debug = True
    def test_message():
        return "test message"
    debug(test_message)

# Generated at 2022-06-21 18:34:26.965730
# Unit test for function warn
def test_warn():
    expected_output = messages.warn("test string")
    buf = io.StringIO()
    sys.stderr = buf
    warn("test string")
    sys.stderr = sys.__stderr__
    assert expected_output in buf.getvalue()


# Generated at 2022-06-21 18:34:28.382103
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "debug")

# Generated at 2022-06-21 18:34:34.308599
# Unit test for function warn
def test_warn():
    with patch('pybackwards.utils.print') as print_mock:
        with patch('sys.stderr') as stderr_mock:
            warn('some message')
            assert print_mock.call_args_list[0] == call('\x1b[33msome message\x1b[0m', file=stderr_mock)
            assert stderr_mock in print_mock.call_args[0]
            assert print_mock.call_args[1] == {'file': stderr_mock}


# Generated at 2022-06-21 18:34:36.536237
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        return a + b

    assert get_source(test_function) == 'return a + b'

# Generated at 2022-06-21 18:34:41.823596
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('a').split('_')[-1] == 0
    assert generator.generate('b').split('_')[-1] == 1
    assert generator.generate('c').split('_')[-1] == 2

# Generated at 2022-06-21 18:34:44.886313
# Unit test for function eager
def test_eager():
    lst = [1, 2, 3]
    lst.append(4)
    assert eager(lst) == [1, 2, 3, 4]


if __name__ == "__main__":
    test_eager()

# Generated at 2022-06-21 18:34:47.556527
# Unit test for function warn
def test_warn():
    settings.debug = False
    warn('Warning!')
    settings.debug = True
    warn('Warning!')


# Generated at 2022-06-21 18:34:49.540708
# Unit test for function debug
def test_debug():
    debug(lambda: 'test1')
    settings.debug = True
    debug(lambda: 'test2')

# Generated at 2022-06-21 18:34:53.048251
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stderr(buf):
        debug(lambda: "Constant message")
    debug(lambda: "Another constant message")
    assert buf.getvalue() == ""

# Generated at 2022-06-21 18:35:02.432586
# Unit test for function warn
def test_warn():
    with mock.patch('sys.stderr', new_callable=io.StringIO) as f:
        warn('Test error')
        assert f.getvalue() == '\033[93mWarning: Test error\033[0m\n'

# Generated at 2022-06-21 18:35:05.637219
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('X') == '_py_backwards_X_0', "VariablesGenerator did not return a unique name"
    assert VariablesGenerator.generate('Y') == '_py_backwards_Y_1', "VariablesGenerator did not return a unique name"



# Generated at 2022-06-21 18:35:09.637070
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-21 18:35:12.904374
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == '_py_backwards_x_0'
    assert VariablesGenerator.generate("y") == '_py_backwards_y_1'



# Generated at 2022-06-21 18:35:22.948212
# Unit test for function debug
def test_debug():
    # mock output of print
    class FakeStdout:
        def __init__(self):
            self.content = []

        def write(self, thing):
            self.content.append(thing)

    out = FakeStdout()
    # original value of sys.stdout
    old_stdout = sys.stdout
    # override sys.stdout
    sys.stdout = out

    settings.debug = True

    debug(lambda: 'debugging')
    assert any(['debugging' in line for line in out.content])

    settings.debug = False

    debug(lambda: 'debugging')
    assert not any(['debugging' in line for line in out.content])

    # restore sys.stdout
    sys.stdout = old_stdout

# Generated at 2022-06-21 18:35:27.625761
# Unit test for function warn
def test_warn():
    def get_stderr():
        return sys.stderr.getvalue()

    sys.stderr = StringIO()
    warn('hello')
    assert messages.warn(messages.Style.reset('hello')) in get_stderr()
    warn(messages.Style.red('hello_again'))
    assert messages.warn(messages.Style.reset('hello_again')) in get_stderr()

    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:35:30.712056
# Unit test for function eager
def test_eager():
    def iterator():
        yield 1
        yield 2
        yield 3

    assert eager(iterator)() == [1, 2, 3]

# Generated at 2022-06-21 18:35:32.841069
# Unit test for function get_source
def test_get_source():
    def test(x):
        return x
    assert get_source(test) == 'def test(x):\n    return x'

# Generated at 2022-06-21 18:35:34.554023
# Unit test for function eager
def test_eager():
    def f() -> Iterable[str]:
        yield "1"

    assert eager(f)() == ["1"]

# Generated at 2022-06-21 18:35:36.686481
# Unit test for function eager
def test_eager():
    def gen():
        yield from [0, 1, 2]

    assert eager(gen)() == [0, 1, 2]

# Generated at 2022-06-21 18:35:47.772531
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('a') == '_py_backwards_a_0'
    assert vg.generate('a') == '_py_backwards_a_1'
    assert vg.generate('a') == '_py_backwards_a_2'


# Generated at 2022-06-21 18:35:55.059542
# Unit test for function debug
def test_debug():
    import unittest

    class TestDebug(unittest.TestCase):
        def test_debug_disabled(self):
            settings.debug = False
            debug(lambda: 'test')

        def test_debug_enabled(self):
            settings.debug = True
            with self.assertRaises(SystemExit):
                debug(lambda: 'test')

    unittest.main()



# Generated at 2022-06-21 18:35:59.114070
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    g1 = VariablesGenerator.generate('a')
    assert g1 == '_py_backwards_a_0'
    g2 = VariablesGenerator.generate('b')
    assert g2 == '_py_backwards_b_1'

# Generated at 2022-06-21 18:36:01.735544
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'


# Generated at 2022-06-21 18:36:08.931021
# Unit test for function debug
def test_debug():
    import io
    import sys

    buf: io.StringIO = io.StringIO()
    backup: Any = sys.stderr
    sys.stderr = buf

# Generated at 2022-06-21 18:36:09.902633
# Unit test for function warn
def test_warn():
    def inner():
        return 1
    warn(inner)

# Generated at 2022-06-21 18:36:11.806659
# Unit test for function get_source
def test_get_source():
    source = '''
        def foo():
            pass
    '''
    assert get_source(test_get_source) == source

# Generated at 2022-06-21 18:36:13.798427
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for _ in range(100):
        assert VariablesGenerator.generate('test') == '_py_backwards_test_0'

# Generated at 2022-06-21 18:36:20.559167
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    try:
        settings.debug = True

        with redirect_stderr(sys.stderr):
            debug(lambda: 'debug message')

        assert 'debug message' in sys.stderr.getvalue()

        sys.stderr = io.StringIO()

        with redirect_stderr(sys.stderr):
            debug(lambda: 'second debug message')

        assert 'second debug message' in sys.stderr.getvalue()
    finally:
        sys.stderr = old_stderr
        settings.debug = False

# Generated at 2022-06-21 18:36:26.603339
# Unit test for function warn
def test_warn():
    from io import BytesIO
    f = BytesIO()
    old_stderr = sys.stderr
    sys.stderr = f
    warn("message")
    sys.stderr = old_stderr
    assert f.getvalue().decode('utf-8').strip() == "PyBackwards: message"
    f.close()


# Generated at 2022-06-21 18:36:36.358602
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for (num, _) in enumerate(range(30)):
        result = VariablesGenerator.generate('f')
        VariablesGenerator._counter += 1
        assert result == '_py_backwards_f_' + str(num)


# Generated at 2022-06-21 18:36:41.494194
# Unit test for function warn
def test_warn():
    # simple test, just to check all is ok
    message = 'test_warn_' + str(random.randint(0, 100))
    try:
        warn(message)
        assert message in sys.stderr.getvalue()
    except AssertionError:
        print('AssertionError: {} not in {}'.format(message, sys.stderr.getvalue()))



# Generated at 2022-06-21 18:36:43.916597
# Unit test for function get_source
def test_get_source():
    def f():
    # Comment
        pass
    assert get_source(f) == 'def f():\n# Comment\n    pass'


# Generated at 2022-06-21 18:36:50.610270
# Unit test for function debug
def test_debug():
    import io
    saved_stderr = sys.stderr
    try:
        out = io.StringIO()
        sys.stderr = out
        test_message = 'Test message'
        debug(lambda: test_message)
        debug(lambda: test_message)
        assert out.getvalue() == messages.debug(test_message)
    finally:
        sys.stderr = saved_stderr


# Generated at 2022-06-21 18:36:51.755571
# Unit test for function warn
def test_warn():
    warn('warn message')
    pass

# Generated at 2022-06-21 18:36:53.555710
# Unit test for function eager
def test_eager():
    @eager
    def my_gen():
        yield 1
        yield 2
        yield 3
    assert my_gen() == [1, 2, 3]

# Generated at 2022-06-21 18:36:56.498690
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    import os

    with patch('sys.stderr', os.devnull):
        warn('test')

# Generated at 2022-06-21 18:37:07.886794
# Unit test for function get_source

# Generated at 2022-06-21 18:37:11.069830
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'


# Generated at 2022-06-21 18:37:21.137930
# Unit test for function debug
def test_debug():
    import logging
    import sys
    import unittest

    class DebugTester(unittest.TestCase):
        def setUp(self):
            logger = logging.getLogger("py_backwards")
            self.log_capture_string = io.StringIO()
            self.handler = logging.StreamHandler(self.log_capture_string)
            self.handler.setLevel(logging.DEBUG)
            self.formatter = logging.Formatter("%(message)s")
            self.handler.setFormatter(self.formatter)
            logger.addHandler(self.handler)

        def tearDown(self):
            logger = logging.getLogger("py_backwards")
            logger.removeHandler(self.handler)
            self.handler.close()
            self.log_capture_string.close()

# Generated at 2022-06-21 18:37:30.278790
# Unit test for function get_source
def test_get_source():
    def add(a: int, b: int) -> int:
        return a + b

    assert get_source(add).strip() == 'return a + b'



# Generated at 2022-06-21 18:37:32.280026
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i ** 2 for i in range(5)))(), [0, 1, 4, 9, 16]



# Generated at 2022-06-21 18:37:34.148756
# Unit test for function get_source
def test_get_source():
    @wraps(get_source)
    def fn():
        pass

    assert get_source(fn) == 'pass\n'



# Generated at 2022-06-21 18:37:37.613846
# Unit test for function warn
def test_warn():
    import sys
    import re
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warn("Foo")
        if len(w) != 1:
            sys.exit(1)
        if not re.search("Foo", str(w[-1].message)):
            sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-21 18:37:43.001379
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        if a:
            return b
        else:
            return b * 2

    assert get_source(fn) == '''
if a:
    return b
else:
    return b * 2
'''


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-21 18:37:46.950404
# Unit test for function debug
def test_debug():
    from ..conf import configure

    configure(debug=True)
    debug_message = 'debug'
    debug(lambda: debug_message)
    assert debug_message not in sys.stderr.getvalue()

    configure(debug=False)
    debug(lambda: debug_message)
    assert debug_message not in sys.stderr.getvalue()

# Generated at 2022-06-21 18:37:50.957207
# Unit test for function eager
def test_eager():
    eag = eager(lambda a: (i for i in range(a)))
    a = eag(10)
    assert a == [0,1,2,3,4,5,6,7,8,9]

# Generated at 2022-06-21 18:37:55.834014
# Unit test for function get_source
def test_get_source():
    def function():
        for i in range(4):
            print('Source code:')
            print(get_source(function))

    assert get_source(function) == '''\
for i in range(4):
    print('Source code:')
    print(get_source(function))
'''

# Generated at 2022-06-21 18:37:58.640571
# Unit test for function debug
def test_debug():
    # GIVEN
    global settings
    settings = type('', (), {
        'debug': True,
    })

    # WHEN
    debug(lambda: 'test')

    # THEN
    sys.stderr.getvalue() == 'test'

# Generated at 2022-06-21 18:38:09.191766
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    from unittest import TestCase

    class WarnTestCase(TestCase):
        def setUp(self):
            self.captured_output = StringIO()
            sys.stderr = self.captured_output

        def tearDown(self):
            sys.stderr = sys.__stderr__

        def test_warn(self):
            warn('test')
            self.assertEquals(self.captured_output.getvalue(), '\x1b[1m\x1b[31mWarning: test\x1b[0m\n')

    class DebugTestCase(TestCase):
        def setUp(self):
            self.captured_output = StringIO()
            sys.stderr = self.captured_output

        def tearDown(self):
            sys

# Generated at 2022-06-21 18:38:26.617207
# Unit test for function eager
def test_eager():
    from .. import syntax_tree
    from . import modules

    tree = syntax_tree.get_tree(modules.__file__, eager)
    assert tree.eager.returns.name == 'list'



# Generated at 2022-06-21 18:38:28.456576
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
        yield 2
    assert list(generator()) == [1, 2]



# Generated at 2022-06-21 18:38:30.892479
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # All generated variables must be unique
    assert not bool(len(set(VariablesGenerator.generate('var') for i in range(100))) -
                    set(VariablesGenerator.generate('var') for i in range(100)))

# Generated at 2022-06-21 18:38:35.424277
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x1') == '_py_backwards_x1_0'
    assert VariablesGenerator.generate('x2') == '_py_backwards_x2_1'
    assert VariablesGenerator.generate('x1') == '_py_backwards_x1_2'
    assert VariablesGenerator.generate('x1') == '_py_backwards_x1_3'
    assert VariablesGenerator.generate('x2') == '_py_backwards_x2_4'
    assert VariablesGenerator.generate('x3') == '_py_backwards_x3_5'

# Generated at 2022-06-21 18:38:39.242411
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        warn("Message")
        assert fake_stderr.getvalue().startswith("Warning: ")

# Generated at 2022-06-21 18:38:44.342050
# Unit test for function warn
def test_warn():
    with mock.patch.object(sys.stderr, 'write') as mock_stderr_write:
        warn('warning message')
        assert mock_stderr_write.call_args_list == [
            mock.call('\x1b[1;33mWarning:\x1b[0m warning message\n'),
        ]



# Generated at 2022-06-21 18:38:54.068641
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Create new function to test different numbers of variables
    def test_function(a, b, c):
        return a, b, c

    # Check counter
    assert VariablesGenerator._counter == 0
    a = VariablesGenerator.generate(test_function.__code__.co_varnames[0])
    b = VariablesGenerator.generate(test_function.__code__.co_varnames[1])
    c = VariablesGenerator.generate(test_function.__code__.co_varnames[2])
    assert VariablesGenerator._counter == 3
    # Check generated names
    assert a == '_py_backwards_a_0'
    assert b == '_py_backwards_b_1'
    assert c == '_py_backwards_c_2'

# Generated at 2022-06-21 18:38:55.635740
# Unit test for function get_source
def test_get_source():
    def add(x: int, y: int) -> int:
        return x + y

    assert get_source(add) == 'return x + y'

# Generated at 2022-06-21 18:38:57.500000
# Unit test for function warn
def test_warn():
    sys.stderr = open('stderr.txt', 'a')
    settings.debug = True
    warn('You are going to run test_warn')
    sys.stderr.close()

# Generated at 2022-06-21 18:39:00.819058
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'A')
    assert True

    settings.debug = True
    debug(lambda: 'A')


# Generated at 2022-06-21 18:39:37.001228
# Unit test for function warn
def test_warn():
    try:
        stdout = sys.stdout
        stderr = sys.stderr
        sys.stdout = sys.stderr = io.StringIO()
        warn('test')
        assert sys.stderr.getvalue() == '\x1b[33mtest\x1b[0m\n'
    finally:
        sys.stdout = stdout
        sys.stderr = stderr



# Generated at 2022-06-21 18:39:47.907570
# Unit test for function debug

# Generated at 2022-06-21 18:39:49.829451
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'

# Generated at 2022-06-21 18:39:53.954019
# Unit test for function get_source
def test_get_source():
    def foo(a, b=2):
        '''
        This is a dummy function
        '''
        return a + b

    foo.__name__ = 'foo'
    source = get_source(foo)
    assert source == "    return a + b"

# Generated at 2022-06-21 18:39:58.382920
# Unit test for function get_source
def test_get_source():
    def first_func():
        pass

    def second_func():
        pass

    result = get_source(first_func)
    assert 'def first_func():' in result, 'Function name should be included'
    assert 'def second_func():' not in result, 'Function should be unique'
    assert '    pass' in result, 'Function body should be included'
    assert '\n\n' not in result, 'Function without body should be without empty line'



# Generated at 2022-06-21 18:40:04.123187
# Unit test for function warn
def test_warn():
    sys.stderr.write("test_warn: ")
    # Test warn output
    try:
        sys.stderr.write("test warn output")
        sys.stderr.flush()
        warn("test")
    finally:
        sys.stderr.write(" passed")
        sys.stderr.flush()


# Generated at 2022-06-21 18:40:05.400892
# Unit test for function get_source

# Generated at 2022-06-21 18:40:07.303479
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-21 18:40:10.283348
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator._counter == 0
    assert generator.generate('sys') == '_py_backwards_sys_0'
    assert generator._counter == 1



# Generated at 2022-06-21 18:40:13.179321
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
  def run():
    assert(VariablesGenerator.generate("a") == "_py_backwards_a_0")
    assert(VariablesGenerator.generate("b") == "_py_backwards_b_1")
    assert(VariablesGenerator.generate("a") == "_py_backwards_a_2")
  run()