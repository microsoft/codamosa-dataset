

# Generated at 2022-06-21 18:30:59.841444
# Unit test for function eager
def test_eager():
    import random
    from ..compat import range
    assert eager(lambda: range(random.randint(0, 100)))() == list(range(random.randint(0, 100)))
    assert eager(lambda: [])() == []

# Generated at 2022-06-21 18:31:05.919471
# Unit test for function debug
def test_debug():
    _stdout = sys.stderr

    def _set_stdout(stdout):
        sys.stderr = stdout


# Generated at 2022-06-21 18:31:10.635174
# Unit test for function get_source
def test_get_source():
    def function_to_test(arg1):
        arg2 = 5
        arg3 = arg1 + arg2
        return arg3
    source = get_source(function_to_test)
    assert source == 'arg2 = 5\n' + \
            'arg3 = arg1 + arg2\n' + \
            'return arg3\n'

# Generated at 2022-06-21 18:31:11.866146
# Unit test for function warn
def test_warn():
    sys.stderr = sys.stdout
    warn("something")

# Generated at 2022-06-21 18:31:14.238281
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate("a") == "_py_backwards_a_0"
    assert vg.generate("b") == "_py_backwards_b_1"

# Generated at 2022-06-21 18:31:17.401952
# Unit test for function eager
def test_eager():
    def generate() -> Iterable[int]:
        for i in range(3):
            yield i

    assert eager(generate)() == [0, 1, 2]

# Generated at 2022-06-21 18:31:22.618992
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    assert source == 'source = get_source(test_get_source)\nassert source == \'source = get_source(test_get_source)\\nassert source == \\\'\\\'\'\nassert source == \\\'\\\'\'\n'

# Generated at 2022-06-21 18:31:26.078712
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('test') == '_py_backwards_test_0'
    assert vg.generate('test2') == '_py_backwards_test2_1'



# Generated at 2022-06-21 18:31:27.804911
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
    assert foo() == [1]

# Generated at 2022-06-21 18:31:38.597600
# Unit test for function debug
def test_debug():
    recorded_messages = []

    def mock_print(*args: Any, **kwargs: Any) -> None:
        recorded_messages.append(args[0])

    @debug
    def random() -> str:
        return 'random'

    def test():
        random()
        random()

    with patch('sys.stderr', new_callable=StringIO):
        with patch('sys.stderr.write', side_effect=mock_print):
            test()

        assert len(recorded_messages) == 2
        assert recorded_messages[0].startswith('py_backwards_debug')
        assert recorded_messages[0].endswith('random')
        assert recorded_messages[1].startswith('py_backwards_debug')
        assert recorded_messages[0].endswith

# Generated at 2022-06-21 18:31:46.030950
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('qwerty') != vg.generate('qwerty')
    assert vg.generate('qwerty') != vg.generate('uiop')
    assert vg.generate('asdfg') == vg.generate('asdfg')
    assert vg.generate('asdfg') != vg.generate('zxcvb')

# Generated at 2022-06-21 18:31:48.291100
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    assert v.generate('x') == '_py_backwards_x_0'
    assert v.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-21 18:31:50.030414
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var = VariablesGenerator.generate('x')
    assert var == '_py_backwards_x_0'
    assert var != VariablesGenerator.generate('x')

# Generated at 2022-06-21 18:31:51.871268
# Unit test for function warn
def test_warn():
    from pytest import capsys

    warn('something')
    captured = capsys.readouterr()
    assert captured.err == messages.warn('something\n')


# Generated at 2022-06-21 18:31:54.136075
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():\n    pass'

# Generated at 2022-06-21 18:32:03.597752
# Unit test for function debug
def test_debug():
    d1 = []
    d2 = []

    @debug
    def g1() -> str:
        d1.append(1)
        return 'Debug message'

    @debug
    def g2() -> str:
        d2.append(1)
        return 'Debug message'

    @debug
    def g3() -> str:
        return 'Debug message'

    g1()
    g2()
    g3()

    assert d1 == [1]
    assert d2 == []
    assert len(g1.wrapped.__doc__.split('\n')) == 3



# Generated at 2022-06-21 18:32:06.818041
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v0 = VariablesGenerator.generate('foo')
    assert v0 == '_py_backwards_foo_0'
    v1 = VariablesGenerator.generate('foo')
    assert v1 == '_py_backwards_foo_1'

# Generated at 2022-06-21 18:32:09.822313
# Unit test for function debug
def test_debug():
    from io import StringIO
    output = StringIO()
    settings.debug = True
    print(messages.debug('foo'), file=output)
    assert output.getvalue() == 'foo\n'



# Generated at 2022-06-21 18:32:11.536248
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('class') != VariablesGenerator.generate('class')

# Generated at 2022-06-21 18:32:14.337215
# Unit test for function eager
def test_eager():
    from py_backwards.utils import eager

    @eager
    def get_value() -> Iterable[int]:
        yield 1

    assert get_value() == [1]

# Generated at 2022-06-21 18:32:19.208982
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('hello')
    assert sys.stderr.getvalue() == messages.warn('hello')


# Generated at 2022-06-21 18:32:20.570893
# Unit test for function debug
def test_debug():
    message = "Test"
    debug(lambda: message)
    assert True

# Generated at 2022-06-21 18:32:21.742708
# Unit test for function warn
def test_warn():
    assert warn('Hi!') == None


# Generated at 2022-06-21 18:32:28.934983
# Unit test for function debug
def test_debug():
    if not settings.debug:
        raise RuntimeError('This test is designed for working with debug mode.')
    tmp_file = sys.stderr
    try:
        from io import StringIO
        sio = StringIO()
        sys.stderr = sio
        debug(lambda: 'test')
        assert sio.getvalue() is not ''
    finally:
        sys.stderr = tmp_file



# Generated at 2022-06-21 18:32:38.983365
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_3'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_4'
    assert '_py_backwards_var_0' != '_py_backwards_var_3'
    assert '_py_backwards_var_1' != '_py_backwards_foo_2'

# Generated at 2022-06-21 18:32:42.727098
# Unit test for function warn
def test_warn():
    import sys
    import io
    captured_output = io.StringIO()
    sys.stdout = captured_output
    warn('Warning!')
    assert captured_output.getvalue() == '\033[91mWarning!\033[0m\n'

# Generated at 2022-06-21 18:32:45.914769
# Unit test for function warn
def test_warn():
    import io
    import sys

    sys.stderr = io.StringIO()

    warn("this is warning message")
    assert sys.stderr.getvalue() == messages.warn("this is warning message")



# Generated at 2022-06-21 18:32:57.581745
# Unit test for function eager
def test_eager():
    @eager
    def g(x: float, y: float):
        for _ in range(4):
            for _ in range(4):
                yield (x, y)
                y += 1
            x, y = y, x

# Generated at 2022-06-21 18:33:07.551331
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Some tests for generating variable names
    variable = VariablesGenerator.generate('foo')
    assert variable == '_py_backwards_foo_0'
    variable = VariablesGenerator.generate('bar')
    assert variable == '_py_backwards_bar_1'
    variable = VariablesGenerator.generate('baz')
    assert variable == '_py_backwards_baz_2'
    variable = VariablesGenerator.generate('qux')
    assert variable == '_py_backwards_qux_3'
    variable = VariablesGenerator.generate('quux')
    assert variable == '_py_backwards_quux_4'



# Generated at 2022-06-21 18:33:12.214186
# Unit test for function eager
def test_eager():
    # function with callable argument
    @eager
    def d(x: int) -> Iterable[int]:
        yield x

    # function with generator argument
    @eager
    def g(x: Iterable[int]) -> Iterable[int]:
        yield from x

    assert d(1) == [1]
    assert g(d(2)) == [2]

# Generated at 2022-06-21 18:33:14.932990
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-21 18:33:23.974513
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Message'

    with patch.object(settings, 'debug', True):
        with patch.object(sys.stderr, 'write') as f:
            debug(get_message)
            f.assert_called_once_with('debug: Message\n')

    with patch.object(settings, 'debug', False):
        with patch.object(sys.stderr, 'write') as f:
            debug(get_message)
            f.assert_not_called()


# Generated at 2022-06-21 18:33:27.729175
# Unit test for function warn
def test_warn():
    import io
    buf = io.StringIO()
    sys.stderr = buf
    warn("test1")
    sys.stderr = sys.__stderr__
    assert buf.getvalue() == "py_backwards: test1\n"


# Generated at 2022-06-21 18:33:28.299333
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
  assert True

# Generated at 2022-06-21 18:33:31.359499
# Unit test for function eager
def test_eager():
    def gen(i: int) -> Iterable[int]:
        yield from range(i)

    assert eager(gen)(5) == [0, 1, 2, 3, 4]
    assert eager(gen)(0) == []

# Generated at 2022-06-21 18:33:43.405494
# Unit test for function debug
def test_debug():
    # When settings.debug is True:
    settings.debug = True

    # Then function debug should print debug message to stderr
    with patch('builtins.print', side_effect=print) as print_mock:
        debug(lambda: 'debug message')

    # And function debug should have been called with debug message
    print_mock.assert_called_once_with(
        messages.debug('debug message'),
        file=sys.stderr
    )

    # When settings.debug is False:
    settings.debug = False

    # Then function debug should not print debug message to stderr
    with patch('builtins.print', side_effect=print) as print_mock:
        debug(lambda: 'debug message')

    # And function  debug should not have been called at all
    assert print_mock.call_

# Generated at 2022-06-21 18:33:46.404409
# Unit test for function eager
def test_eager():
    def list_gen():
        yield 1
        yield 2
        yield 3
        yield 4

    print(list_gen())
    print(eager(list_gen)())

# Generated at 2022-06-21 18:33:53.546791
# Unit test for function debug
def test_debug():
    """
    >>> import os
    >>> d = os.environ.get('PY_BACKWARDS_DEBUG', '')
    >>> os.environ['PY_BACKWARDS_DEBUG'] = '1'

    >>> def foo():
    ...     debug(lambda: "debug message")

    >>> foo()
    \x1b[30m\x1b[1mdebug message\x1b[0m

    >>> os.environ['PY_BACKWARDS_DEBUG'] = d

    """

# Generated at 2022-06-21 18:33:58.156555
# Unit test for function warn
def test_warn():
    import io
    import sys
    from contextlib import redirect_stderr
    from .messages import warn
    msg = 'test'
    f = io.StringIO()
    with redirect_stderr(f) as f:
        warn(msg)
        output = f.getvalue()
    assert output.startswith('\x1b[93m')
    assert msg in output

# Generated at 2022-06-21 18:34:01.972402
# Unit test for function get_source
def test_get_source():
    from inspect import getsource
    from .utils import get_source

    def foo(a, b, c):
        """Docstring."""
        return a  # foo comment

    assert get_source(foo) == getsource(foo)

# Generated at 2022-06-21 18:34:10.788119
# Unit test for function warn
def test_warn():
    old_stderr = sys.stderr
    stderr = sys.stderr = StringIO()
    try:
        warn('Hello')
        print('stderr:')
        print(stderr.getvalue())
        assert stderr.getvalue() == 'WARNING: Hello\n'
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-21 18:34:14.143416
# Unit test for function warn
def test_warn():
    import sys, io
    sys.stderr = io.StringIO()
    warn('some message')
    assert sys.stderr.getvalue() == messages.warn('some message') + '\n'


# Generated at 2022-06-21 18:34:17.461221
# Unit test for function warn
def test_warn():
    result = StringIO()
    sys.stderr = result
    try:
        warn('warn message')
        assert result.getvalue() == messages.warn('warn message') + '\n'
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:34:19.615794
# Unit test for function eager
def test_eager():
    def fn():
        for i in range(4):
            yield i

    assert eager(fn)() == [0, 1, 2, 3]

# Generated at 2022-06-21 18:34:22.437582
# Unit test for function debug
def test_debug():
    messages.debug = lambda msg: msg
    debug(lambda: 'foo: {}'.format('bar')) == 'foo: bar'

# Generated at 2022-06-21 18:34:29.274171
# Unit test for function warn
def test_warn():
    # TODO(yevgey): It is better to use mock to make sure that print
    #               was called. I don't know how to do it.
    #               Also, if print will be changed to logging then
    #               this test should be updated.
    from io import StringIO
    from contextlib import redirect_stdout
    f = StringIO()
    with redirect_stdout(f):
        warn('Test warn')
    assert f.getvalue() == messages.warn('Test warn') + '\n'



# Generated at 2022-06-21 18:34:32.845245
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("b") == '_py_backwards_b_1'
    assert VariablesGenerator.generate("a") == '_py_backwards_a_2'


# Generated at 2022-06-21 18:34:35.262961
# Unit test for function eager
def test_eager():
    class X:
        @classmethod
        @eager
        def reversed_yield(cls, x: int):
            for i in reversed(range(x)):
                yield i

    assert X.reversed_yield(10) == sorted(X.reversed_yield(10), reverse=True)

# Generated at 2022-06-21 18:34:44.425380
# Unit test for function debug
def test_debug():
    import os
    os.environ['PY_BACKWARDS_DEBUG'] = '1'

    def local():
        import sys
        import io
        from unittest.mock import patch

        captured_output = io.StringIO()  # Create StringIO object
        sys.stdout = captured_output

        debug(get_message=lambda: 'FOO')

        sys.stdout = sys.__stdout__  # Reset redirect.
        assert captured_output.getvalue() == '\033[1m\033[92m[PY_BACKWARDS]\033[0m FOO\n'

    local()



# Generated at 2022-06-21 18:34:48.946676
# Unit test for function eager
def test_eager():
    def a():
        for i in range(3):
            yield i
    b = eager(a)
    assert isinstance(b(), list)
    assert all(isinstance(i, int) for i in b())
    assert sum(b()) == 3

# Generated at 2022-06-21 18:34:57.708433
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'


# Generated at 2022-06-21 18:35:04.384340
# Unit test for function get_source
def test_get_source():
    def f():
        print(3)
        return 4

    def g():
        def h():
            print(5)
            return 6

        print(7)
        return 8


    assert get_source(f).split('\n') == ['print(3)', 'return 4']
    assert get_source(g).split('\n') == ['    def h():', '        print(5)',
                                         '        return 6', '', '    print(7)',
                                         '    return 8']

# Generated at 2022-06-21 18:35:07.362210
# Unit test for function warn
def test_warn():
    import warnings
    warnings.simplefilter("always")
    try:
        warn("test")
    except Exception:
        assert False


# Generated at 2022-06-21 18:35:14.242138
# Unit test for function warn
def test_warn():
    from types import SimpleNamespace
    import sys

    args = SimpleNamespace(debug=False, log='warn')
    with patch.object(sys, 'stderr', StringIO()) as stderr, \
        patch.object(settings, 'debug', args.debug), \
        patch.object(settings, 'log', args.log):
        warn('Test warn')
        assert stderr.getvalue().split('\n')[0] == messages.warn('Test warn')



# Generated at 2022-06-21 18:35:18.774668
# Unit test for function eager
def test_eager():
    tests = [
        dict(args=(1, 2), expected=[1, 2]),
        dict(args=(), expected=[]),
    ]

    for test in tests:
        args, expected = test['args'], test['expected']

# Generated at 2022-06-21 18:35:22.043090
# Unit test for function warn
def test_warn():
    from io import StringIO

    output = StringIO()
    sys.stderr = output
    warn('test')
    assert 'test' in output.getvalue()



# Generated at 2022-06-21 18:35:27.570478
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_4'


# Generated at 2022-06-21 18:35:32.151809
# Unit test for function get_source
def test_get_source():
    @wraps(get_source)
    def wrapper():
        pass

    assert get_source(wrapper) == '@wraps(get_source)\n' \
                                  'def wrapper():\n' \
                                  '    pass\n'



# Generated at 2022-06-21 18:35:36.274543
# Unit test for function eager
def test_eager():
    def test_iterable():
        import random
        values = [random.randint(1, 20) for i in range(5)]
        for v in values:
            yield v

    values = eager(test_iterable)()
    assert values == [1, 5, 9, 14, 18]



# Generated at 2022-06-21 18:35:38.313526
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(5):
        assert VariablesGenerator.generate("var_name") == f"_py_backwards_var_name_{i}"



# Generated at 2022-06-21 18:35:57.814553
# Unit test for function debug
def test_debug():
    message = 'hello'
    with patch('sys.stdout', new=StringIO()) as fake_out:
        debug(lambda: message)
        output = fake_out.getvalue()
    assert output == ''

    with patch('sys.stdout', new=StringIO()) as fake_out:
        settings.debug = True
        debug(lambda: message)
        output = fake_out.getvalue()
    assert output.rstrip() == '\x1b[36mdebug {}\x1b[0m'.format(message)



# Generated at 2022-06-21 18:36:00.243235
# Unit test for function eager
def test_eager():
    @eager
    def dummy_generator(n):
        for i in range(n):
            yield i
    assert dummy_generator(1) == [0]


# Generated at 2022-06-21 18:36:10.131428
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from . import messages
    from unittest import mock

    mocks = dict(stderr=mock.Mock())

    with mock.patch.dict(globals(), mocks), \
         mock.patch.dict(messages.globals(), mocks), \
         mock.patch.multiple(sys, stderr=mocks['stderr']):
        settings.debug = False
        assert not debug(lambda: None)

        settings.debug = True
        assert not debug(lambda: None)
        mocks['stderr'].write.assert_called_with(mocks['debug']('None'))



# Generated at 2022-06-21 18:36:15.256002
# Unit test for function warn
def test_warn():
    try:
        import sys
        from contextlib import redirect_stderr
        from io import StringIO

        f = StringIO()
        sys.stderr = f
        warn('test')
        expected = messages.warn('test')
        assert expected in f.getvalue()
    finally:
        sys.stderr = sys.__stderr__

if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-21 18:36:16.977221
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    seen = set()
    for _ in range(100):
        assert VariablesGenerator.generate('my_var') not in seen

# Generated at 2022-06-21 18:36:18.315305
# Unit test for function get_source
def test_get_source():
    def f():
        return 42
    g = f
    assert get_source(g) == 'return 42'

# Generated at 2022-06-21 18:36:21.031557
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_generator = VariablesGenerator()
    assert var_generator.generate('dog') == '_py_backwards_dog_0'
    assert var_generator.generate('cat') == '_py_backwards_cat_1'
    assert var_generator.generate('dog') == '_py_backwards_dog_2'

# Generated at 2022-06-21 18:36:23.899724
# Unit test for function get_source
def test_get_source():
    def test():
        """Docstring"""
        def nested():
            pass

    assert get_source(test) == 'def nested():\n' \
                               '    pass'

# Generated at 2022-06-21 18:36:26.269531
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2

    assert f() == [1, 2]

# Generated at 2022-06-21 18:36:28.775507
# Unit test for function debug
def test_debug():
    debug_message = 'Debug message 1'
    debug(lambda: debug_message)


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-21 18:36:44.973585
# Unit test for function debug
def test_debug():
    # TODO: check that we don't print anything,
    #       because settings.debug is False
    # TODO: check that we print something if settings.debug is True
    pass



# Generated at 2022-06-21 18:36:46.366194
# Unit test for function debug
def test_debug():
    settings.debug = True
    print(messages.debug('_test_debug'))
    settings.debug = False

# Generated at 2022-06-21 18:36:49.832993
# Unit test for function warn
def test_warn():
    sys.stderr = sys.__stderr__
    warnings.simplefilter('ignore', ResourceWarning)

    with warnings.catch_warnings(record=True) as logged:
        warn('test')
        assert len(logged) == 1

    with pytest.raises(Exception) as e:
        warn('test')
        assert len(e) == 1

# Generated at 2022-06-21 18:36:55.547034
# Unit test for function eager
def test_eager():
    def fib(n):
        if n < 0:
            raise Exception('Negative number')
        if n < 2:
            return n
        return fib(n-1) + fib(n-2)
    assert fib(5) == 5
    fib_list = eager(fib)
    assert fib_list(5) == [0, 1, 1, 2, 3]

# Generated at 2022-06-21 18:37:03.415564
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_4'


# Generated at 2022-06-21 18:37:10.557457
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from collections import Counter
    from random import randint

    def generate_random_variables():
        for _ in range(100):
            yield VariablesGenerator.generate(chr(65+randint(0, 25)) + chr(65+randint(0, 25)) + chr(65+randint(0, 25)))

    res = generate_random_variables()
    count = Counter(res)
    for i in res:
        assert count[i] == 1



# Generated at 2022-06-21 18:37:13.955437
# Unit test for function get_source
def test_get_source():
    from ..utils import get_source
    source = get_source(test_get_source)

    assert 'def test_get_source():' in source
    assert source.strip() == source

# Generated at 2022-06-21 18:37:18.723038
# Unit test for function debug
def test_debug():
    debug_called = 0
    def get_message():
        nonlocal debug_called
        debug_called += 1
        return 'OK'
    debug(get_message)
    assert debug_called == 0

    debug_called = 0
    settings.debug = True
    debug(get_message)
    assert debug_called == 1



# Generated at 2022-06-21 18:37:19.729816
# Unit test for function warn
def test_warn():
    assert messages.warn('Hello world!!!') == messages.WARN + ' Hello world!!!'

# Generated at 2022-06-21 18:37:25.923111
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate('a')
    v2 = VariablesGenerator.generate('b')
    v3 = VariablesGenerator.generate('b')
    assert v1 == '_py_backwards_a_0'
    assert v2 == '_py_backwards_b_1'
    assert v3 == '_py_backwards_b_2'


# Generated at 2022-06-21 18:37:58.196515
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # array for testing consistency of name generation
    test_array = []
    for i in range(0, 100):
        generated_var = VariablesGenerator.generate("test")
        if generated_var in test_array:
            print("warning: variable name not unique")
        else:
            test_array.append(generated_var)
    print("test passed: all generated variables are unique")



# Generated at 2022-06-21 18:38:00.533461
# Unit test for function debug
def test_debug():
    def f0() -> None:
        pass

    def f1() -> None:
        debug(lambda: 'I am debug message')

    f0()
    f1()

# Generated at 2022-06-21 18:38:11.448488
# Unit test for function warn
def test_warn():
    class TestStream:
        def __init__(self):
            self._messages = []

        def write(self, message: str):
            self._messages.append(message)

        def is_empty(self) -> bool:
            return not self._messages

        def get_message(self, index: int) -> str:
            return self._messages[index]

    stream = TestStream()

    sys.stderr = stream

    warn('test message 1')
    warn('test message 2')

    assert stream.get_message(0).startswith('WARNING: ')
    assert stream.get_message(1).startswith('WARNING: ')
    assert stream.get_message(0).endswith('test message 1')
    assert stream.get_message(1).endswith('test message 2')


# Generated at 2022-06-21 18:38:14.144968
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test = VariablesGenerator()
    assert test.generate('x') == '_py_backwards_x_0'
    assert test.generate('y') == '_py_backwards_y_1'



# Generated at 2022-06-21 18:38:23.146394
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def debug_settings():
        old_value = settings.debug
        settings.debug = True
        try:
            yield
        finally:
            settings.debug = old_value

    def func():
        pass

    source = get_source(func)

    message = 'test debug output'

    with debug_settings(), StringIO() as output:
        debug(lambda: message)
        assert output.getvalue() == messages.debug(message + '\n' + source)


# Generated at 2022-06-21 18:38:25.894211
# Unit test for function get_source
def test_get_source():
    def fn():
        def foo():
            print('hello world')

    assert get_source(fn) == 'def foo():\n    print(\'hello world\')'

# Generated at 2022-06-21 18:38:27.388534
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert 'def foo():' in get_source(foo)



# Generated at 2022-06-21 18:38:30.810405
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'TEST_DEBUG')
    except Exception:
        assert False, 'Should not raise an exception'
    finally:
        settings.debug = False



# Generated at 2022-06-21 18:38:35.094586
# Unit test for function warn
def test_warn():
    settings.debug = False
    with capture_stdout() as stdout, capture_stderr() as stderr:
        warn("my message")
    assert stdout.getvalue() == ''
    assert stderr.getvalue().strip() == messages.warn("my message")



# Generated at 2022-06-21 18:38:46.137488
# Unit test for function debug
def test_debug():
    code = """
    import py_backwards
    def test_function():
        pass
    def test_function_2():
        pass
    """
    from . import patch_bytecode_module
    from .tests.test_patch_bytecode_module import patch_bytecode_module_test
    from .tests.test_patch_bytecode_module import BytecodeMock


# Generated at 2022-06-21 18:39:56.750732
# Unit test for function debug
def test_debug():
    import io
    import unittest
    import unittest.mock as mock

    class DebugTest(unittest.TestCase):
        def test_debug_function(self):
            with mock.patch('sys.stderr', new_callable=io.StringIO) as fake_stderr:
                debug(lambda: 'Foo')
                self.assertEqual(fake_stderr.getvalue(), "")
            settings.debug = True
            with mock.patch('sys.stderr', new_callable=io.StringIO) as fake_stderr:
                debug(lambda: 'Bar')
                self.assertEqual(fake_stderr.getvalue(), '  \x1b[2mDEBUG: Bar\x1b[0m\n')
            settings.debug = False

    return Debug

# Generated at 2022-06-21 18:39:59.228002
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-21 18:40:01.316928
# Unit test for function get_source
def test_get_source():  # noqa
    def some_func():
        pass

    assert get_source(some_func) == 'pass'



# Generated at 2022-06-21 18:40:06.818327
# Unit test for function warn
def test_warn():
    import io
    import sys
    old_stderr = sys.stderr
    sys.stderr = captured = io.StringIO()
    try:
        warn("Hello, world!")
        assert "Hello, world!" in captured.getvalue()
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-21 18:40:09.824260
# Unit test for function eager
def test_eager():
    import random

    @eager
    def generator(n: int):
        for _ in range(n):
            yield random.random()

    assert len(generator(5)) == 5



# Generated at 2022-06-21 18:40:13.264214
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariantGenerator.generate('a') == '_py_backwards_a_0'
    assert VariantGenerator.generate('a') == '_py_backwards_a_1'
    assert VariantGenerator.generate('b') == '_py_backwards_b_2'
    assert VariantGenerator.generate('a') == '_py_backwards_a_3'


# Generated at 2022-06-21 18:40:14.534038
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
	v1 = VariablesGenerator.generate('test')
	v2 = VariablesGenerator.generate('test')
	assert v1 != v2

# Generated at 2022-06-21 18:40:17.075593
# Unit test for function debug
def test_debug():
    # Should not print anything
    debug(lambda : 'message')

    settings.debug = True

    assert 'message' in debug(lambda : 'message')

    settings.debug = False

# Generated at 2022-06-21 18:40:23.420589
# Unit test for function warn
def test_warn():
    stderr = sys.stderr
    buffer = []

    class StdOut:
        def write(self, message: str) -> None:
            buffer.append(message)

    try:
        sys.stderr = StdOut()
        warn('Test warn')
        assert buffer[0] == messages.warn('Test warn') + '\n'
    finally:
        sys.stderr = stderr

# Generated at 2022-06-21 18:40:25.845290
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

