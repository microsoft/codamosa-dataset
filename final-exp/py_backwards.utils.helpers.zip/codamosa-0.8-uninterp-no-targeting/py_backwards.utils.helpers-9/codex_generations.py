

# Generated at 2022-06-21 18:30:26.402925
# Unit test for function eager
def test_eager():
    def empty_eager_list():
        @eager
        def empty_list():
            return []
        return empty_list()
    assert not empty_eager_list()

    def non_empty_eager_list():
        @eager
        def non_empty_list():
            return [1]
        return non_empty_list()
    assert non_empty_eager_list() == [1]


# Generated at 2022-06-21 18:30:29.988238
# Unit test for function debug
def test_debug():
    import mock
    import sys
    from io import StringIO

    with mock.patch('py_backwards.utils.settings.debug', True):
        stream = StringIO()
        with mock.patch.object(sys, 'stderr', stream):
            debug(lambda: 'test')
        stream.seek(0)
        debug_message = stream.read().strip()

    assert debug_message == messages.debug('test')



# Generated at 2022-06-21 18:30:32.990580
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello')
    settings.debug = False
    debug(lambda: 'Hello')
    settings.debug = True



# Generated at 2022-06-21 18:30:35.070127
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in range(5)))(
    ) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 18:30:38.362834
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'msg')
        assert False
    except AssertionError:
        pass
    else:
        raise AssertionError('Should be never reached')



# Generated at 2022-06-21 18:30:44.216249
# Unit test for function eager
def test_eager():
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __eq__(self, other):
            if not isinstance(other, Point):
                return False
            return self.x == other.x and self.y == other.y

    @eager
    def _gen(a, b):
        for i in range(a, b):
            yield Point(i, i)

    assert _gen(2, 5) == [Point(2, 2), Point(3, 3), Point(4, 4)]

# Generated at 2022-06-21 18:30:47.385020
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('fred') == '_py_backwards_fred_0'
    assert VariablesGenerator.generate('fred') == '_py_backwards_fred_1'



# Generated at 2022-06-21 18:30:50.159228
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    count = 197
    variables = [VariablesGenerator.generate(str(i)) for i in range(count)]
    for i in range(count - 1):
        for j in range(i + 1,count):
            assert variables[i] != variables[j]
    return True

# Generated at 2022-06-21 18:30:56.433482
# Unit test for function debug
def test_debug():
    """Check that debug messages are printed when settings.debug is True."""
    print('\x1b[35m')
    message = 'test'
    settings.debug = True
    debug(lambda: message)
    settings.debug = False
    print('\x1b[0m')

# Generated at 2022-06-21 18:31:00.056447
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'



# Generated at 2022-06-21 18:31:04.847751
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Unit test for debug')
    settings.debug = False



# Generated at 2022-06-21 18:31:06.827678
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-21 18:31:09.562023
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'
    print(get_message())
    debug(get_message)
    assert get_message() == 'test'

# Generated at 2022-06-21 18:31:11.146296
# Unit test for function get_source
def test_get_source():
    def f(x):
        return x + 1

    print(get_source(f))



# Generated at 2022-06-21 18:31:12.452777
# Unit test for function get_source
def test_get_source():
    from .test_utils import func


# Generated at 2022-06-21 18:31:24.324741
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('w') == '_py_backwards_w_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_3'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_4'
    assert VariablesGenerator.generate('z') == '_py_backwards_z_5'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_6'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_7'

# Generated at 2022-06-21 18:31:31.696285
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert(VariablesGenerator.generate("a") == '_py_backwards_a_0')
    assert(VariablesGenerator.generate("a") == '_py_backwards_a_1')
    assert(VariablesGenerator.generate("b") == '_py_backwards_b_2')
    assert(VariablesGenerator.generate("a") == '_py_backwards_a_3')
    assert(VariablesGenerator.generate("b") == '_py_backwards_b_4')

# Generated at 2022-06-21 18:31:36.362726
# Unit test for function warn
def test_warn():
    output = []
    print_fn = lambda x, file=None: output.append(x)
    try:
        sys.stdout = sys.stderr = print_fn
        warn('Hello')
        assert output == [messages.warn('Hello')]
    finally:
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__


# Generated at 2022-06-21 18:31:38.965601
# Unit test for function warn
def test_warn():
    from pytest import capsys
    warn('test')
    out, err = capsys.readouterr()
    assert err == messages.warn('test') + '\n'

# Generated at 2022-06-21 18:31:43.002941
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_2'

# Generated at 2022-06-21 18:31:46.459319
# Unit test for function get_source
def test_get_source():
    def foo():
        return 42

    a = get_source(foo)

# Generated at 2022-06-21 18:31:49.567610
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    expected = 'def func():\n    pass'
    assert get_source(func) == expected



# Generated at 2022-06-21 18:31:51.870748
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Test message'
    debug(get_message)



# Generated at 2022-06-21 18:31:59.990806
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    output = io.StringIO()
    @contextlib.contextmanager
    def set_debug():
        settings.debug = True
        try:
            yield
        finally:
            settings.debug = False
    with set_debug():
        debug(lambda: 'This is debug message')
        assert output.getvalue() == messages.debug('This is debug message') + '\n'
    with set_debug():
        assert not settings.debug



# Generated at 2022-06-21 18:32:03.214235
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'


# Generated at 2022-06-21 18:32:05.468919
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-21 18:32:08.191108
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    counter = VariablesGenerator._counter
    for i in range(3):
        assert VariablesGenerator.generate('x') == '_py_backwards_x_{}'.format(counter + i)

# Generated at 2022-06-21 18:32:09.727366
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
    assert f() == [1]

# Generated at 2022-06-21 18:32:12.873180
# Unit test for function eager
def test_eager():
    from ..iterable import IntIterable
    @eager
    def gen():
        return IntIterable(10)
    assert gen() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 18:32:20.713855
# Unit test for function debug
def test_debug():
    import sys
    import io

    def capture_stdout(capture: io.StringIO, func: Callable[[], Any], *args: Any, **kwargs: Any) -> Any:
        old = sys.stdout
        sys.stdout = capture
        try:
            return func(*args, **kwargs)
        finally:
            sys.stdout = old
        # end try
    # end def

    from .conf import settings

    sys.modules['py_backwards.conf'].settings.debug = True
    message = "test"
    stdout = io.StringIO()
    assert capture_stdout(stdout, debug, lambda: message) is None
    assert stdout.getvalue() == "{}\n".format(messages.debug(message))


# Generated at 2022-06-21 18:32:27.454740
# Unit test for function eager
def test_eager():
    from types import GeneratorType

    @eager
    def generator() -> GeneratorType:
        yield 1
        yield 2

    assert generator() == [1, 2]

# Generated at 2022-06-21 18:32:31.747181
# Unit test for function debug
def test_debug():
    output = patch.object(sys, 'stderr', StringIO())
    try:
        with patch.object(settings, 'debug', True):
            debug(lambda: 'test')
        assert output.getvalue() == '[DEBUG]   test\n'
    finally:
        output.close()

# Generated at 2022-06-21 18:32:33.938725
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate("variable") == '_py_backwards_variable_0'


# Generated at 2022-06-21 18:32:39.523432
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'


if __name__ == '__main__':
    test_VariablesGenerator()

# Generated at 2022-06-21 18:32:45.091943
# Unit test for function eager
def test_eager():
    def gen(x: int) -> Iterable[int]:
        for i in range(x):
            yield i


    def another_gen(x: int) -> Iterable[int]:
        for i in range(x):
            if i % 2 == 0:
                yield i


    assert eager(gen)(7) == [0, 1, 2, 3, 4, 5, 6]
    assert eager(another_gen)(6) == [0, 2, 4]

# Generated at 2022-06-21 18:32:49.266374
# Unit test for function debug
def test_debug():
    func_called = 0

    def get_message():
        nonlocal func_called
        func_called += 1
        return 'some message'

    debug(get_message)

    assert func_called == 1

# Generated at 2022-06-21 18:32:54.199793
# Unit test for function eager
def test_eager():
    def function_with_generator():
        for i in range(3):
            yield i

    def function_with_list():
        return [0, 1, 2]

    assert eager(function_with_generator)() == [0, 1, 2]
    assert eager(function_with_list)() == [0, 1, 2]

# Generated at 2022-06-21 18:32:59.986958
# Unit test for function debug
def test_debug():
    import io

    class FakeStderr:
        def __init__(self) -> None:
            self.output = io.StringIO()

        def __getattr__(self, name: str) -> Any:
            return self.output.__getattribute__(name)

    stderr = sys.stderr
    try:
        fake_stderr = sys.stderr = FakeStderr()
        settings.debug = True
        debug(lambda: 'Debug message')
    finally:
        sys.stderr = stderr
        settings.debug = False
    assert fake_stderr.getvalue() == messages.debug('Debug message') + '\n'



# Generated at 2022-06-21 18:33:04.910572
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_0'
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_1'
    assert VariablesGenerator.generate('def') == '_py_backwards_def_2'

# Generated at 2022-06-21 18:33:05.924745
# Unit test for function warn
def test_warn():
    assert warn('Hello') is None

# Generated at 2022-06-21 18:33:24.937581
# Unit test for function eager
def test_eager():
    def fn(*args: Any, **kwargs: Any) -> Iterable[str]:
        for arg in args:
            yield 'Eager:' + str(arg)
        for k, v in kwargs.items():
            yield 'Eager:' + k + '=' + str(v)

    assert eager(fn)('arg1', 'arg2', k1='v1', k2='v2') == \
        ['Eager:arg1', 'Eager:arg2', 'Eager:k1=v1', 'Eager:k2=v2']



# Generated at 2022-06-21 18:33:27.942997
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def a():
            pass

        def b():
            pass
    assert get_source(bar) ==  'def a():\n    pass\n\n\ndef b():\n    pass'

# Generated at 2022-06-21 18:33:29.605185
# Unit test for function warn
def test_warn():
    with settings.patch(debug=True):
        warn("Some warning message")


# Generated at 2022-06-21 18:33:32.917249
# Unit test for function get_source
def test_get_source():
    def my_function():
        return 1
    source = get_source(my_function)
    assert source == 'return 1'



# Generated at 2022-06-21 18:33:37.271486
# Unit test for function warn
def test_warn():
    warn('Hello, world!')
    sys.stderr.seek(0)
    assert 'Hello, world!' in sys.stderr.read()
    sys.stderr.truncate(0)
    sys.stderr.seek(0)



# Generated at 2022-06-21 18:33:38.238190
# Unit test for function warn
def test_warn():
    warn('Hello World!')


# Generated at 2022-06-21 18:33:41.678028
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('_a') == '_py_backwards__a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'

# Generated at 2022-06-21 18:33:49.872091
# Unit test for function debug
def test_debug():
    def get_message():
        return 'message'

    for flag, expected in [
        (False, None),
        (True, 'message')
    ]:
        with patch('py_backwards.utils.settings.debug', new=flag):
            with patch('sys.stderr') as stderr:
                debug(get_message)
                if expected is not None:
                    stderr.write.assert_called_once_with(messages.debug(expected) + '\n')
                else:
                    stderr.write.assert_not_called()

# Generated at 2022-06-21 18:33:52.235453
# Unit test for function warn
def test_warn():
    with pytest.warns(None) as record:
        warn('Test message')
    assert 'Test message' in str(record.pop().message)

# Generated at 2022-06-21 18:33:59.638796
# Unit test for function get_source

# Generated at 2022-06-21 18:34:21.600397
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
    assert foo() == [1, 2]

# Generated at 2022-06-21 18:34:26.755538
# Unit test for function get_source
def test_get_source():
    def foo():
        '''Docstring.'''
        with open('/dev/null') as f:
            return 42

    source = get_source(foo)
    assert source == 'def foo():\n    """Docstring."""\n' \
                     r'    with open(' \
                     r"'/dev/null') as f:\n" \
                     '        return 42'

# Generated at 2022-06-21 18:34:29.458468
# Unit test for function eager
def test_eager():
    @eager
    def i_am_eager() -> Iterable[int]:
        yield 1
        yield 2

    assert i_am_eager() == [1, 2]



# Generated at 2022-06-21 18:34:33.307545
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import unittest
    class TestVariablesGenerator(unittest.TestCase):

        def test_generate(self):
            generator = VariablesGenerator()
            first = generator.generate('variable')
            second = generator.generate('variable')
            self.assertNotEqual(first, second)

    unittest.main(argv=[__file__])

# Generated at 2022-06-21 18:34:37.450469
# Unit test for function warn
def test_warn():
    import io
    import sys
    out = io.StringIO()
    sys.stderr = out
    warn("error1")
    assert out.getvalue() == "\x1b[31m\x1b[1merror1\x1b[0m\n"



# Generated at 2022-06-21 18:34:41.332811
# Unit test for function get_source
def test_get_source():
    import inspect
    def f():
        pass
    assert get_source(f) == inspect.getsource(f)
    def f():
        pass
    assert get_source(f) == inspect.getsource(f)

# Generated at 2022-06-21 18:34:46.623455
# Unit test for function eager
def test_eager():
    from collections import deque

    @eager
    def calculate():
        yield 2
        yield 3
        yield 5

    assert calculate() == [2, 3, 5]
    assert isinstance(calculate(), list)

    @eager
    def iterate_over_deque():
        queue = deque()
        queue.append(2)
        queue.append(3)
        queue.append(5)
        while queue:
            yield queue.popleft()

    assert iterate_over_deque() == [2, 3, 5]
    assert isinstance(iterate_over_deque(), list)

# Generated at 2022-06-21 18:34:50.926925
# Unit test for function warn
def test_warn():
    warnings = []

    def test_warning(message):
        warnings.append(message)

    sys.stderr.write = test_warning
    message = 'Test warn'

    warn(message)
    assert(warnings[0] == messages.warn(message))



# Generated at 2022-06-21 18:34:53.769301
# Unit test for function debug
def test_debug():
    msg_printed = [False]
    def test_debug_func():
        print("test_debug called")
        msg_printed[0] = True
    debug(test_debug_func)
    assert msg_printed[0]



# Generated at 2022-06-21 18:34:54.432087
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-21 18:35:36.965597
# Unit test for function warn
def test_warn():
    messages.warn = lambda text: text
    assert warn('test') == 'test', 'warn was not working properly'

# Generated at 2022-06-21 18:35:39.039169
# Unit test for function get_source
def test_get_source():
    def test_fn(*args, **kwargs):
        pass
    expected_source = 'test_fn(*args, **kwargs)'
    source = get_source(test_fn).strip()

    assert source == expected_source

# Generated at 2022-06-21 18:35:41.422171
# Unit test for function get_source
def test_get_source():
    def f():
        # first line
        # second line
        pass

    assert get_source(f) == '# first line\n# second line\npass'

# Generated at 2022-06-21 18:35:48.098525
# Unit test for function eager
def test_eager():
    l = [2]
    def one():
        i = iter([1])
        return i
    def two():
        return l
    assert one() is not one()
    assert two() is two()
    assert eager(one)() is not eager(one)()
    assert eager(two)() is eager(two)()
    assert eager(one)() == [1]
    assert eager(two)() == [2]

# Generated at 2022-06-21 18:35:51.050190
# Unit test for function get_source
def test_get_source():
    def hi():
        print('hi')

    assert get_source(hi) == 'print(\'hi\')'

# Generated at 2022-06-21 18:35:52.008380
# Unit test for function get_source
def test_get_source():
    def f():
        pass

# Generated at 2022-06-21 18:35:53.080340
# Unit test for function warn
def test_warn():
    warn('Hello world!')


# Generated at 2022-06-21 18:35:55.480258
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        pass
    assert get_source(fn) == """        pass"""

# Generated at 2022-06-21 18:35:59.153856
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var = VariablesGenerator()
    var.generate("arg")
    assert(var._counter == 1)
    var.generate("arg")
    assert(var._counter == 2)

test_VariablesGenerator()


# Generated at 2022-06-21 18:36:00.045379
# Unit test for function warn
def test_warn():
    warn('failure')



# Generated at 2022-06-21 18:36:50.796786
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = set()
    for i in range(100):
        var = VariablesGenerator.generate('test')
        assert var not in variables, "Variable {} is not unique.".format(var)
        variables.add(var)

# Generated at 2022-06-21 18:36:55.916569
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'


# Generated at 2022-06-21 18:36:59.222978
# Unit test for function warn
def test_warn():
    """Test for function warn."""
    stream = io.StringIO()
    with redirect_stdout(stream):
        warn('message')
    assert stream.getvalue().strip() == messages.warn('message')



# Generated at 2022-06-21 18:37:01.538337
# Unit test for function eager
def test_eager():
    @eager
    def lazy_function():
        yield 1
        yield 1
        yield '1'
        yield '1'

    result = lazy_function()
    assert result == [1, 1, '1', '1']

# Generated at 2022-06-21 18:37:07.181746
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        warn("A warning message")
        stderr.write.assert_called_with('\x1b[33m' + 'A warning message' + '\x1b[0m\n')
        assert stderr.write.call_count == 1


# Generated at 2022-06-21 18:37:10.696823
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('var1') == '_py_backwards_var1_0'
    assert generator.generate('var2') == '_py_backwards_var2_1'

# Generated at 2022-06-21 18:37:12.354866
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert(get_source(foo) == 'def foo():\n    pass')



# Generated at 2022-06-21 18:37:15.059204
# Unit test for function warn
def test_warn():
    def foo(message):
        return warn(message)

    assert 'Warning' in foo.__code__.co_names



# Generated at 2022-06-21 18:37:23.231194
# Unit test for function get_source
def test_get_source():
    def foo():
        """Silly docstring."""

        def bar():
            """Nested function."""
            return 1

        return bar()

    source_lines_foo = getsource(foo).split('\n')
    source_lines_bar = getsource(foo.__code__.co_consts[2]).split('\n')

    # All padding from function foo should be removed
    padding = len(re.findall(r'^(\s*)', source_lines_foo[0])[0])
    assert get_source(foo) == '\n'.join(line[padding:] for line in source_lines_foo)

    # The same padding should be applied to the nested function
    padding = len(re.findall(r'^(\s*)', source_lines_bar[0])[0])
    assert get_source

# Generated at 2022-06-21 18:37:28.454651
# Unit test for function get_source
def test_get_source():
    import functools
    @functools.wraps(get_source)
    def test_function(x, y):
        return x + y
    assert get_source(test_function) == ('def test_function(x, y):\n'
                                         '    return x + y')

# Generated at 2022-06-21 18:39:19.774544
# Unit test for function debug
def test_debug():
    debug(lambda: 'a')
    debug(lambda: 'b')
    debug(lambda: 'c')
    debug(lambda: 'd')

# Generated at 2022-06-21 18:39:21.100206
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

# Generated at 2022-06-21 18:39:26.085156
# Unit test for function debug
def test_debug():
    class StringIO(io.TextIOWrapper):
        def __init__(self):
            super().__init__(io.BytesIO())

        def getvalue(self) -> str:
            self.seek(0)
            return self.read()

    stream = StringIO()
    sys.stderr = stream
    try:
        debug(lambda: 'test debug message')
        assert stream.getvalue() == ''
        settings.debug = True
        debug(lambda: 'test debug message')
        assert stream.getvalue().startswith('[DEBUG] test debug message')
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-21 18:39:29.776642
# Unit test for function warn
def test_warn():
    import pytest
    capture_warnings = pytest.importorskip("pytest_capturelog")

    with capture_warnings(pytest.raises(AssertionError)):
        warn("Test Warn of py.backwards")

# Generated at 2022-06-21 18:39:32.105693
# Unit test for function warn
def test_warn():
    import io
    import sys

    out = io.StringIO()
    sys.stderr = out

# Generated at 2022-06-21 18:39:34.487857
# Unit test for function warn
def test_warn():
    import warnings
    warnings.simplefilter('ignore', DeprecationWarning)
    assert settings.debug == False
    warn("warning message")


# Generated at 2022-06-21 18:39:35.812208
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for _ in range(10):
        print(VariablesGenerator.generate('abc'))


# Generated at 2022-06-21 18:39:37.000718
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(5):
        print(VariablesGenerator.generate('x'))

# Generated at 2022-06-21 18:39:40.082427
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-21 18:39:48.107663
# Unit test for function eager
def test_eager():
    from ..conf import settings
    settings.debug = True
    @eager
    def range_10():
        debug(lambda: 'range_10')
        debug(lambda: 'range_10')
        return range(10)

    def test_function(func):
        func()
        assert len(func()) == 10
        assert func() != range(10)

    test_function(range_10)

    @eager
    def range_20():
        debug(lambda: 'range_20')
        return range(20)

    test_function(range_20)

