

# Generated at 2022-06-23 23:32:07.707175
# Unit test for function get_source
def test_get_source():
    def d():
        pass

    assert get_source(d).strip() == 'pass'

    def d(a, b, c=3, *args, d=4, **kwargs):
        pass

    assert get_source(d).strip() == 'pass'

    with settings.change(debug=True):
        debug(lambda: 'hello')

# Generated at 2022-06-23 23:32:12.947838
# Unit test for function warn
def test_warn():
    try:
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        warn("warning message")
        output = sys.stderr.getvalue().strip('\n')
    finally:
        sys.stderr = old_stderr
    assert output == messages.warn("warning message")


# Generated at 2022-06-23 23:32:18.861535
# Unit test for function warn
def test_warn():
    sys.stderr = sys.stdout = open('test_warn.txt', 'w')
    warn('TEST MESSAGE')
    sys.stderr = sys.stdout = open('test_warn.txt', 'r')
    with open('test_warn.txt', 'r') as f:
        assert f.read() == messages.warn('TEST MESSAGE') + '\n'
    os.remove('test_warn.txt')


# Generated at 2022-06-23 23:32:20.081990
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    print(get_source(foo))

# Generated at 2022-06-23 23:32:23.145727
# Unit test for function debug
def test_debug():
    my_message = "hello world"
    settings.debug = False
    assert settings.debug == False
    debug(lambda: my_message) == None
    settings.debug = True
    assert settings.debug == True
    debug(lambda: my_message) == None

# Generated at 2022-06-23 23:32:28.765056
# Unit test for function warn
def test_warn():
    with open('warnings.txt', 'w') as f:
        old_stderr = sys.stderr
        sys.stderr = f
        try:
            warn("test")
        finally:
            sys.stderr = old_stderr
    with open('warnings.txt', 'r') as f:
        assert f.read() == messages.warn("test") + '\n'

# Generated at 2022-06-23 23:32:30.642699
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == "pass"



# Generated at 2022-06-23 23:32:31.215014
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-23 23:32:34.050079
# Unit test for function eager
def test_eager():
    def test_fn(n):
        for i in range(n):
            yield i

    assert eager(test_fn)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:32:41.305371
# Unit test for function debug
def test_debug():
    class DummyFile:
        text = ''

        def write(self, text: str) -> None:
            self.text += text

    dummy_file = DummyFile()
    with tempfile.TemporaryDirectory() as directory:
        filename = '{}/file.py'.format(directory)
        with open(filename, 'w') as f:
            print('''
                from py_backwards.utilities import debug

            ''', file=f, end='')
        sys.path.append(directory)
        import file
        settings.debug = True
        sys.stderr = dummy_file
        file.debug(lambda: 'test_debug')
        assert dummy_file.text == '[D] test_debug'
        sys.path.remove(directory)



# Generated at 2022-06-23 23:32:45.506029
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'


# Generated at 2022-06-23 23:32:46.484375
# Unit test for function warn
def test_warn():
    assert callable(warn)



# Generated at 2022-06-23 23:32:50.440661
# Unit test for function warn
def test_warn():
    if __name__ == '__main__':
        from io import StringIO
        from sys import stderr

        orig_stderr = stderr
        try:
            stderr = StringIO()
            warn('hello')
            assert 'hello' in stderr.getvalue()
        finally:
            stderr = orig_stderr

# Generated at 2022-06-23 23:32:53.300648
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variable = 'var'
    assert '_py_backwards_var_0' == VariablesGenerator.generate(variable)
    assert '_py_backwards_var_1' == VariablesGenerator.generate(variable)

# Generated at 2022-06-23 23:32:56.812322
# Unit test for function get_source
def test_get_source():
    """
    This is unit test for function get_source.
    """
    def _inner(a, b):
        pass

    def outer(a, b):
        _inner(a, b)

    assert get_source(_inner) == 'pass'
    assert get_source(outer) == '    _inner(a, b)'

# Generated at 2022-06-23 23:32:59.655603
# Unit test for function get_source
def test_get_source():
    def function_to_be_tested(foo: int) -> int:
        return foo

    assert get_source(function_to_be_tested) == 'def function_to_be_tested(foo: int) -> int:\n    return foo'



# Generated at 2022-06-23 23:33:00.971292
# Unit test for function warn
def test_warn():
    assert warn(2) == "WARNING: 2\n"



# Generated at 2022-06-23 23:33:05.188709
# Unit test for function warn
def test_warn():
    warn_message = 'It is my message'
    with patch('backwards.utils.sys') as sys_mock:
        warn(warn_message)
        sys_mock.stderr.write.assert_called_once_with('\x1b[91m{0}\x1b[0m\n'.format(warn_message))



# Generated at 2022-06-23 23:33:06.604548
# Unit test for function get_source
def test_get_source():
    def sum(a, b):
        return a + b

    assert get_source(sum) == 'return a + b'

# Generated at 2022-06-23 23:33:08.559879
# Unit test for function warn
def test_warn():
    import io
    sys.stderr = io.StringIO()
    warn('Test')
    assert sys.stderr.getvalue() == '\033[93mTest\033[0m\n'

# Generated at 2022-06-23 23:33:13.012447
# Unit test for function warn
def test_warn():
    from io import StringIO
    real_stderr = sys.stderr
    sys.stderr = StringIO()
    warn('foo')
    error = sys.stderr.getvalue()
    sys.stderr = real_stderr
    assert messages.warn('foo') == error

# Generated at 2022-06-23 23:33:15.914916
# Unit test for function eager
def test_eager():
    """
    >>> t = eager(lambda: range(4))
    >>> t()
    [0, 1, 2, 3]
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:33:22.469275
# Unit test for function debug
def test_debug():
    debug_messages = []
    def print_debug(message):
        print(message, file=sys.stderr)
        debug_messages.append(message)

    original_print = builtins.print
    try:
        builtins.print = print_debug

        debug(lambda: 'Hello')
        assert not debug_messages
        settings.debug = True
        debug(lambda: 'Hello')
        assert debug_messages == ['Hello']
    finally:
        builtins.print = original_print



# Generated at 2022-06-23 23:33:24.012685
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == list(range(5))

# Generated at 2022-06-23 23:33:27.736739
# Unit test for function warn
def test_warn():
    import io
    from contextlib import redirect_stderr

    message = 'Hey'
    f = io.StringIO()
    with redirect_stderr(f):
        warn(message)
    assert f.getvalue().strip() == messages.warn(message)

# Generated at 2022-06-23 23:33:30.969390
# Unit test for function debug
def test_debug():
    out = []
    sys.stderr = [out]

    # Should not print anything with debug off
    debug(lambda: 'foo')
    assert not out

    settings.debug = True

    # Should print with debug on
    debug(lambda: 'foo')
    assert any('foo' in line for line in out)

# Generated at 2022-06-23 23:33:37.340619
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
	assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
	assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
	assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
	assert VariablesGenerator.generate('b') == '_py_backwards_b_3'
	assert VariablesGenerator.generate('c') == '_py_backwards_c_4'
	assert VariablesGenerator.generate('c') == '_py_backwards_c_5'


# Generated at 2022-06-23 23:33:38.262868
# Unit test for function debug
def test_debug():
    debug(lambda : 'test')

# Generated at 2022-06-23 23:33:42.734746
# Unit test for function warn
def test_warn():
    from io import StringIO
    from .test_utils import redirect_stderr

    with redirect_stderr(StringIO()) as stderr:
        warn('This is a test warning')
        assert stderr.getvalue() == '\x1b[1m\x1b[33mWarning:\x1b[0m This is a test warning\n'

# Generated at 2022-06-23 23:33:45.816991
# Unit test for function warn
def test_warn():
    def test_warn_to_stderr():
        stderr = io.StringIO()
        with redirect_stderr(stderr):
            warn('test')
        assert 'test' in stderr.getvalue()

    test_warn_to_stderr()



# Generated at 2022-06-23 23:33:49.104319
# Unit test for function eager
def test_eager():
    @eager
    def my_eager():
        yield 1
        yield 2
        yield 3
    assert my_eager() == [1, 2, 3]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:33:58.309918
# Unit test for function debug
def test_debug():
    from pytest import raises
    from io import StringIO
    from .conf import settings as _settings

    def dummy(*args: Any, **kwargs: Any) -> None:
        """Dummy callable."""

    monkeypatch = None
    try:
        import unit_test  # type: ignore
    except ImportError:
        pass
    else:
        if hasattr(unit_test, 'MonkeyPatch'):
            monkeypatch = unit_test.MonkeyPatch()

    if monkeypatch is not None:
        with monkeypatch.context():
            _settings.debug = True
            orig_stderr = sys.stderr
            sys.stderr = StringIO()
            try:
                debug(lambda: 'message')
                message = sys.stderr.getvalue()
            finally:
                sys.stderr

# Generated at 2022-06-23 23:33:59.826472
# Unit test for function warn
def test_warn():
    assert issubclass(warn, object)


# Generated at 2022-06-23 23:34:00.732337
# Unit test for function warn
def test_warn():
    warn("Test")



# Generated at 2022-06-23 23:34:02.476410
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first = VariablesGenerator.generate('foo')
    second = VariablesGenerator.generate('foo')

    assert first != second

# Generated at 2022-06-23 23:34:07.620990
# Unit test for function debug
def test_debug():
    from unittest import mock
    from py_backwards.conf import settings
    debug('foo')
    debug(lambda: 'bar')
    with mock.patch('py_backwards.utils.settings.debug', False):
        debug('baz')
        debug(lambda: 'qux')
        settings.debug = True
        debug('quux')
        debug(lambda: 'corge')
        settings.debug = False
        debug('grault')
        debug(lambda: 'garply')

# Generated at 2022-06-23 23:34:08.544608
# Unit test for function eager
def test_eager():
    def f():
        yield 1
    assert eager(f)() == [1]

# Generated at 2022-06-23 23:34:15.196658
# Unit test for function warn
def test_warn():
    import io
    import unittest

    class WarnTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.out = io.StringIO()
            self.err = io.StringIO()

            self.original_sys_stdout = sys.stdout
            self.original_sys_stderr = sys.stderr

            sys.stdout = self.out
            sys.stderr = self.err

        def tearDown(self) -> None:
            sys.stdout = self.original_sys_stdout
            sys.stderr = self.original_sys_stderr

        def test_warn(self):
            warn('Hello, friends!')
            self.assertEqual(self.out.getvalue(), '')

# Generated at 2022-06-23 23:34:17.416714
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_gen = VariablesGenerator()
    assert var_gen.generate('variable') == '_py_backwards_variable_0'
    assert var_gen.generate('variable') == '_py_backwards_variable_1'
    assert var_gen.generate('variable') == '_py_backwards_variable_2'

# Generated at 2022-06-23 23:34:19.401661
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'



# Generated at 2022-06-23 23:34:21.854129
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello debug!')

if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:34:22.900493
# Unit test for function warn
def test_warn():
    warn("Nigga")


# Generated at 2022-06-23 23:34:27.285490
# Unit test for function eager
def test_eager():
    def generator(n):
        for i in range(n):
            yield i
    generated_list = eager(generator)(10)
    assert isinstance(generated_list, list)
    assert generated_list == [i for i in range(10)]

# Generated at 2022-06-23 23:34:38.716861
# Unit test for function debug
def test_debug():
    import logging
    import unittest
    from unittest import mock
    from pytest import raises

    class TestDebug(unittest.TestCase):
        @mock.patch('stderr', new_callable=mock.Mock())
        @mock.patch('settings.debug', True)
        def test_debug_message_printed_if_settings_debug_is_true(self, stderr):
            debug(lambda: 'Hello World')
            stderr.assert_called_with(messages.debug('Hello World'), file=sys.stderr)


# Generated at 2022-06-23 23:34:39.892137
# Unit test for function eager
def test_eager():
    assert eager(range)(2, 3) == [2]



# Generated at 2022-06-23 23:34:43.197503
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('t') == '_py_backwards_t_0'
    assert VariablesGenerator.generate('t') == '_py_backwards_t_1'

# Generated at 2022-06-23 23:34:47.122671
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_gen = VariablesGenerator()
    a,b,c = var_gen.generate('x'), var_gen.generate('x'), var_gen.generate('x')
    assert a != b and b!= c and c != a, "Names are not unique"

# Generated at 2022-06-23 23:34:51.919882
# Unit test for function debug
def test_debug():
    class A:
        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    A.inc = debug(lambda: "A.value={}".format(A.inc.__self__.value))(A.inc)
    a = A()
    a.inc()
    a.inc()
    a.inc()

# Generated at 2022-06-23 23:34:55.313726
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    counter = VariablesGenerator._counter
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'
    assert VariablesGenerator._counter > counter


# Generated at 2022-06-23 23:34:58.798273
# Unit test for function eager
def test_eager():
    def foo(n: int) -> Iterable[int]:
        while n > 0:
            yield n
            n -= 1

    assert eager(foo)(5) == [5, 4, 3, 2, 1]

# Generated at 2022-06-23 23:35:04.783054
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'

    cls = VariablesGenerator
    cls._counter = 0
    assert cls.generate('a') == '_py_backwards_a_0'
    assert cls.generate('a') == '_py_backwards_a_1'


# Generated at 2022-06-23 23:35:07.027117
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for _ in range(20):
        a = VariablesGenerator.generate('name')
        assert a == '_py_backwards_name_0'

# Generated at 2022-06-23 23:35:09.218935
# Unit test for function warn
def test_warn():
    buf = StringIO()
    sys.stderr = buf
    msg = 'this is a test'
    warn(msg)
    assert msg in buf.getvalue()


# Generated at 2022-06-23 23:35:14.552796
# Unit test for function debug
def test_debug():
    from . import mocks
    from .utils import debug

    def get_message():
        return 'hello'

    with mocks.Stdout():
        debug(get_message)

    mocks.Stdout.assert_not_called()

    with mocks.Stdout():
        with settings.push(debug=True):
            debug(get_message)

    mocks.Stdout.assert_called_once_with('\r\x1b[2KPyBackwards: hello\n')

# Generated at 2022-06-23 23:35:22.213995
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from nose.tools import assert_equals

    stream = StringIO()
    variable = 'variable_debug'
    variable_value = 'cool variable'
    variable_counter = 42
    with redirect_stderr(stream):
        debug(lambda: '{} = {}'.format(variable, variable_value))
    assert_equals(stream.getvalue(), '{} = {}\n'.format(variable, variable_value))
    stream.close()



# Generated at 2022-06-23 23:35:25.190638
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vars = []
    for i in range(100):
        vars.append(VariablesGenerator.generate("var"))
    assert len(vars) == len(set(vars))

# Generated at 2022-06-23 23:35:28.448013
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    x = VariablesGenerator.generate('a')
    assert x == '_py_backwards_a_0'
    y = VariablesGenerator.generate('b')
    assert y == '_py_backwards_b_1'

# Generated at 2022-06-23 23:35:31.034086
# Unit test for function get_source
def test_get_source():
    def some_function():
        return 0

    def another_function():
        """Some docstring"""

        def one_more_function():
            """One more docstring"""
            return 1

        return one_more_function()

    assert get_source(some_function) == 'return 0'
    assert get_source(another_function) == '    """One more docstring"""\n    return 1'

# Generated at 2022-06-23 23:35:32.815187
# Unit test for function get_source
def test_get_source():
    def f1():  # 1
        pass  # 2

    assert get_source(f1) == 'def f1():\n    pass'

# Generated at 2022-06-23 23:35:36.493190
# Unit test for function warn
def test_warn():
    from io import StringIO
    captureOutput = StringIO()
    sys.stderr = captureOutput
    warn("Hello world")
    sys.stderr = sys.__stderr__
    assert captureOutput.getvalue() == messages.warn("Hello world") + '\n'



# Generated at 2022-06-23 23:35:39.230249
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in range(10)))(
        ) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-23 23:35:41.238964
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'


# Generated at 2022-06-23 23:35:42.602499
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:35:43.641791
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-23 23:35:47.100465
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'



# Generated at 2022-06-23 23:35:49.261122
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-23 23:35:51.454203
# Unit test for function get_source
def test_get_source():
    def fn():
        def inner():
            return 1
        return inner()

# Generated at 2022-06-23 23:35:58.604547
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class Var:
        def __init__(self):
            self.list_of_variable = []

        def add_variable(self, variable: str):
            self.list_of_variable.append(variable)

        def same_variable(self, variable: str) -> bool:
            return variable in self.list_of_variable

    var = Var()
    for i in range(10000):
        variable = VariablesGenerator.generate('my_variable')
        var.add_variable(variable)
        assert not var.same_variable(variable)
    assert not var.same_variable('_py_backwards_my_variable_11111')

# Generated at 2022-06-23 23:36:04.569705
# Unit test for function debug
def test_debug():
    from contextlib import redirect_stderr
    from io import StringIO

    message = 'test_message'
    with redirect_stderr(StringIO()) as stream:
        debug(lambda: message)
        assert stream.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stream:
        debug(lambda: message)
        assert stream.getvalue() == messages.debug(message) + '\n'
    settings.debug = False

# Generated at 2022-06-23 23:36:08.978178
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('c') == '_py_backwards_c_2'

# Generated at 2022-06-23 23:36:19.140093
# Unit test for function debug
def test_debug():
    import inspect
    import ast
    import io
    test = [0]

    def test_debug(message: str) -> bool:
        assert message == 'hello world'
        test[0] += 1
        return True

    with inspect.start_capturing() as stdout:
        with open(__file__, 'r') as module:
            tree = ast.parse(module.read())
            module.seek(0)
            lines_map = dict(enumerate(module.readlines(), 1))

        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and hasattr(node, 'func') and getattr(node.func, 'id', None) == 'debug':
                node.args[0].value.args[0].value = 'hello world'
                module_name = ast.Module

# Generated at 2022-06-23 23:36:28.925465
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn('Some warning')
        assert err.getvalue().strip() == '\x1b[93mWarning: Some warning\x1b[0m'


# Generated at 2022-06-23 23:36:34.963506
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'



# Generated at 2022-06-23 23:36:35.976425
# Unit test for function warn
def test_warn():
    assert not warn("warning")

# Generated at 2022-06-23 23:36:42.562974
# Unit test for function get_source
def test_get_source():
    def is_one(a, b):
        if a < b:
            if a < b or a > b:
                return True
        else:
            return False

    return_statement = 'return True'
    expected_source = \
        'def is_one(a, b):\n' \
        '    if a < b:\n' \
        '        if a < b or a > b:\n' \
        '            {}\n'.format(return_statement)

    assert expected_source == get_source(is_one)

# Generated at 2022-06-23 23:36:46.257140
# Unit test for function get_source
def test_get_source():
    """
        >>> def func():
        ...     print('Printed!')
        >>> get_source(func) == \"\"\"
        ... print('Printed!')
        ... \"\"\"
        True
    """
    pass

# Generated at 2022-06-23 23:36:49.612540
# Unit test for function eager
def test_eager():
    @eager
    def naturals(n: int=-1) -> Iterable[int]:
        while True:
            n += 1
            yield n

    assert naturals() == [0, 1, 2]



# Generated at 2022-06-23 23:36:50.552123
# Unit test for function warn
def test_warn():
    warn('Warning')
    assert True

# Generated at 2022-06-23 23:36:53.363342
# Unit test for function eager
def test_eager():
    assert eager([1, 2, 3])(lambda: range(10)) == [1, 2, 3]
    assert eager(None)(lambda: range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:36:54.950189
# Unit test for function get_source
def test_get_source():
    foo = 1

    def x():
        """Docstring."""
        return foo

    assert get_source(x) == '"""Docstring."""\n    return foo'



# Generated at 2022-06-23 23:36:57.201121
# Unit test for function get_source
def test_get_source():

    def sample_function():
        a = 1
        b = 2
        return a + b

    assert get_source(sample_function) == 'a = 1\nb = 2\nreturn a + b'

# Generated at 2022-06-23 23:36:59.577857
# Unit test for function get_source
def test_get_source():
    def f(x, y):
        return 2 * x + 3 * y

    assert get_source(f) == 'return 2 * x + 3 * y'

# Generated at 2022-06-23 23:37:02.175133
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert 'def fn():\n' in get_source(fn)

# Generated at 2022-06-23 23:37:08.777050
# Unit test for function warn
def test_warn():
    from textwrap import dedent
    from unittest.mock import Mock, call
    from py_backwards.utils.console import warn

    stderr = Mock()
    stderr.read.return_value = ''
    stderr.write.return_value = ''

    with patch('sys.stderr', new_callable=lambda: stderr):
        warn('test')
    stderr.write.assert_called_once_with(dedent('''\
        !!! test
        '''))



# Generated at 2022-06-23 23:37:12.467841
# Unit test for function warn
def test_warn():
    import sys

    sys.stderr = sys.stdout
    warn("bazinga")
    print("123")


module_name_pattern = re.compile(r'^[a-zA-Z_][0-9a-zA-Z_]*$')



# Generated at 2022-06-23 23:37:14.215622
# Unit test for function eager
def test_eager():
    def test():
        return (1, 2)

    assert eager(test)() == [1, 2]



# Generated at 2022-06-23 23:37:18.363460
# Unit test for function warn
def test_warn():
    class TestWarn:
        def __init__(self):
            self.test_stdout = None
        def get_stdout(self):
            return self.test_stdout
    test = TestWarn()
    saved_stdout = sys.stdout
    sys.stdout = test
    try:
        # Happy path
        warn('This is a test')
        assert test.get_stdout().strip() == messages.warn('This is a test')
    finally:
        sys.stdout = saved_stdout



# Generated at 2022-06-23 23:37:24.392499
# Unit test for function get_source
def test_get_source():
    def source_test_function():
        x = 1
        y = x*2
        z = y*3
        return z

    source = get_source(source_test_function)
    print(source)
    assert source == 'def py_backwards_source_test_function():\n    x = 1\n    y = x*2\n    z = y*3\n    return z'

# Generated at 2022-06-23 23:37:26.459932
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    x = VariablesGenerator.generate('test')
    y = VariablesGenerator.generate('test')
    assert x != y

# Generated at 2022-06-23 23:37:30.821392
# Unit test for function warn
def test_warn():
    from .. import messages
    from . import testutils
    from io import StringIO

    out = StringIO()
    testutils.redirect_stdout(out)
    message = 'This is a test'
    warn(message)
    out.seek(0)
    result = out.read()
    assert result == '{}\n'.format(messages.warn(message))



# Generated at 2022-06-23 23:37:31.606826
# Unit test for function warn
def test_warn():
    assert warn('message') == None

# Generated at 2022-06-23 23:37:34.296241
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    names = [VariablesGenerator.generate('temp_var')
             for _ in range(3)]
    assert names == ['_py_backwards_temp_var_0',
                     '_py_backwards_temp_var_1',
                     '_py_backwards_temp_var_2']

# Generated at 2022-06-23 23:37:37.665174
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('a') == '_py_backwards_a_0'
    assert generator.generate('a') == '_py_backwards_a_1'

# Generated at 2022-06-23 23:37:39.154326
# Unit test for function debug
def test_debug():
    get_message = lambda: 'Hello'
    debug(get_message)

# Generated at 2022-06-23 23:37:41.074947
# Unit test for function get_source
def test_get_source():
    def func():
        return 2
    res = get_source(func)
    assert res == 'return 2'

# Generated at 2022-06-23 23:37:43.138519
# Unit test for function eager
def test_eager():
    def f1() -> Iterable[int]:
        yield 1
        yield 2
    assert eager(f1)() == [1, 2]

# Generated at 2022-06-23 23:37:48.977838
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stdout
    from unittest import TestCase

    class Test(TestCase):
        def test_debug(self) -> None:
            output = io.StringIO()
            with redirect_stdout(output):
                settings.debug = True
                debug(lambda: 'message')
                settings.debug = False
                debug(lambda: 'message')
            self.assertEqual(output.getvalue(), '\x1b[34m[DEBUG] message\x1b[0m\n')

    Test().test_debug()

# Generated at 2022-06-23 23:37:51.732755
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen=VariablesGenerator()
    assert gen.generate('a')=='_py_backwards_a_0'
    assert gen.generate('a')=='_py_backwards_a_1'

# Generated at 2022-06-23 23:38:00.015351
# Unit test for function warn
def test_warn():
    """This function tests function warn."""
    import io
    import sys
    import unittest

    class WarningTestCase(unittest.TestCase):
        # Redirect stdout and stderr to capture warnings.
        def setUp(self):
            self.old_stderr = sys.stderr
            self.old_stdout = sys.stdout
            sys.stderr = self.stderr = io.StringIO()
            sys.stdout = self.stdout = io.StringIO()

        def tearDown(self):
            sys.stderr = self.old_stderr
            sys.stdout = self.old_stdout

        def test_warn(self):
            """Tests the warn function."""
            warn('warning message')

# Generated at 2022-06-23 23:38:05.128721
# Unit test for function warn
def test_warn():
    """
    Tests for warn function.
    """
    try:
        from io import StringIO
    except:
        from StringIO import StringIO
    import sys

    stream = StringIO()
    sys.stderr = stream
    warn('Warning!')
    assert stream.getvalue() == messages.warn('Warning!') + '\n'



# Generated at 2022-06-23 23:38:10.039147
# Unit test for function debug
def test_debug():
    """Setting debug to False should not print message"""
    import pytest
    class TestClass:
        @staticmethod
        def test():
            """test"""
            def get_message():
                """test"""
                return "test message"
            debug(get_message)
            return True
    TestClass.test()
    assert TestClass.test() == True
    def get_message():
        """test"""
        return "test message"
    from ..conf import settings
    settings.debug = True
    capture = pytest.raises(SystemExit)
    debug(get_message)

# Generated at 2022-06-23 23:38:12.146509
# Unit test for function get_source
def test_get_source():
    def f():
        print(x)

    assert get_source(f) == "print(x)\n"


# Generated at 2022-06-23 23:38:14.895579
# Unit test for function eager
def test_eager():
    @eager
    def fn():
        print('fn')
        yield 1
        yield 2
        yield 3
        print('fn end')

    assert fn() == [1, 2, 3]

# Generated at 2022-06-23 23:38:18.845529
# Unit test for function debug
def test_debug():
    if settings.debug:
        for i in range(settings.debug_verbosity):
            debug(lambda: i)
        for i in range(settings.debug_verbosity):
            print(messages.debug(str(i)), file=sys.stderr)



# Generated at 2022-06-23 23:38:21.609491
# Unit test for function eager
def test_eager():
    def generator():
        for i in range(3):
            yield str(i)

    assert eager(generator)() == ['0', '1', '2']

# Generated at 2022-06-23 23:38:24.485269
# Unit test for function warn
def test_warn():
    messages.warn = lambda m: 'warned: ' + m
    try:
        assert warn('foo') == 'warned: foo'
    finally:
        messages.warn = messages.warn



# Generated at 2022-06-23 23:38:25.108888
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-23 23:38:28.721467
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    x = VariablesGenerator.generate("var")
    y = VariablesGenerator.generate("var")
    assert(x != y)
    assert(x.startswith("_py_backwards"))
    assert(y.startswith("_py_backwards"))

# Generated at 2022-06-23 23:38:32.305730
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print("Generated variables:")
    list_of_vars = []
    for i in range(5):
        list_of_vars.append(VariablesGenerator.generate("cos"))
    print(list_of_vars)


test_VariablesGenerator()

# Generated at 2022-06-23 23:38:34.455087
# Unit test for function eager
def test_eager():
    def t():
        for i in range(5):
            yield i**2
    assert eager(t)() == [0, 1, 4, 9, 16]

# Generated at 2022-06-23 23:38:36.978535
# Unit test for function warn
def test_warn():
    sys.stderr = open('stderr', 'w')
    warn('This is warning')
    sys.stderr.close()
    assert 'This is warning' in open('stderr').read()
    os.unlink('stderr')

# Generated at 2022-06-23 23:38:38.106687
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1
    assert get_source(foo) == 'return 1'

# Generated at 2022-06-23 23:38:40.607000
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    simple_function = '''def foo():
    pass
'''

    assert get_source(foo) == simple_function

# Generated at 2022-06-23 23:38:43.573599
# Unit test for function eager
def test_eager():
    @eager
    def fun() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert fun() == [1, 2, 3]



# Generated at 2022-06-23 23:38:44.596945
# Unit test for function warn
def test_warn():
    warn('Hello!')



# Generated at 2022-06-23 23:38:47.387363
# Unit test for function eager
def test_eager():
    @eager
    def fn() -> Iterable[Any]:
        yield 1
        yield 2
        yield 3

    assert fn() == [1, 2, 3]

# Generated at 2022-06-23 23:38:50.325733
# Unit test for function warn
def test_warn():
    from io import StringIO
    s = StringIO()
    sys.stderr = s
    warn('Test message')
    assert s.getvalue() == '  Test message\n'



# Generated at 2022-06-23 23:38:54.247883
# Unit test for function debug
def test_debug():
    from io import StringIO
    from . import utils
    import sys

    ori_stdout = sys.stderr
    sys.stderr = mystdout = StringIO()
    utils.debug(lambda: 'Hello')
    assert 'Hello' in mystdout.getvalue()
    sys.stderr = ori_stdout

# Generated at 2022-06-23 23:38:55.314287
# Unit test for function warn
def test_warn():
    assert warn.__name__ == 'warn'



# Generated at 2022-06-23 23:38:55.821554
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-23 23:38:57.540710
# Unit test for function eager
def test_eager():
    @eager
    def get_numbers():
        for i in range(10):
            yield i

    assert get_numbers() == list(range(10))

# Generated at 2022-06-23 23:39:01.238235
# Unit test for function get_source
def test_get_source():
    def test(arg):
        a = 1
        b = 2
        c = 3
        return a + b + c

    assert get_source(test).strip() == '''
    a = 1
    b = 2
    c = 3
    return a + b + c
    '''.strip()

# Generated at 2022-06-23 23:39:02.179565
# Unit test for function get_source
def test_get_source():
    source = """
    def fn():
        pass"""
    assert get_source(fn) == source



# Generated at 2022-06-23 23:39:04.648169
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass
    assert get_source(test_func) == 'def test_func():\n    pass\n'

# Generated at 2022-06-23 23:39:06.575067
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'



# Generated at 2022-06-23 23:39:09.215544
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            return 165

    assert get_source(foo) == 'def bar():\n    return 165'

# Generated at 2022-06-23 23:39:12.966176
# Unit test for function eager
def test_eager():
    def get_range(to: int) -> Iterable[int]:
        for i in range(to):
            yield i

    assert eager(get_range)(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 23:39:17.348397
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-23 23:39:19.073551
# Unit test for function eager
def test_eager():
    # pylint: disable=unused-variable
    xs = range(4)
    assert eager(range)(4) == [0, 1, 2, 3]

# Generated at 2022-06-23 23:39:21.418800
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'


# Generated at 2022-06-23 23:39:26.274577
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    list_of_variables = []
    for i in range(10):
        var = VariablesGenerator.generate('test')
        list_of_variables.append(var)
    assert len(list(set(list_of_variables))) == len(list_of_variables), "Class variables are unique"



# Generated at 2022-06-23 23:39:36.714834
# Unit test for function debug
def test_debug():
    import tempfile

    with tempfile.TemporaryFile('w+') as output:
        # Save default value of sys.stderr.
        old_stderr = sys.stderr
        sys.stderr = output

        debug(lambda: 'Test message #1')
        sys.stderr.flush()
        output.seek(0)

        # Check debug message.
        assert output.read() == ''

        settings.debug = True
        debug(lambda: 'Test message #2')
        sys.stderr.flush()
        output.seek(0)

        # Check debug message.
        assert output.read().strip() == 'Test message #2\n'
        settings.debug = False

        sys.stderr = old_stderr



# Generated at 2022-06-23 23:39:40.502172
# Unit test for function debug
def test_debug():
    print('Function test_debug is running')
    def message():
        print('This is debug message')
        return 'This is debug message'
    debug(message)


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:39:41.892314
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        return (x for x in range(1))
    assert foo() == [0]

# Generated at 2022-06-23 23:39:48.268878
# Unit test for function debug
def test_debug():
    from .debug import debug
    from .settings import debug as settings_debug
    from .settings import debug_set

    settings_debug_tmp = settings_debug
    messages_debug = []

    def mock_debug(message: str) -> None:
        messages_debug.append(message)

    settings.debug_set('debug', True)
    settings.debug_set('debug_set', mock_debug)
    debug(lambda: 'test')
    assert settings.debug_get('debug')
    assert messages_debug[-1] == 'py_backwards.debug: test'

    settings.debug_set('debug', False)
    settings.debug_set('debug_set', mock_debug)
    debug(lambda: 'test')
    assert not settings.debug_get('debug')
    assert messages_debug[-1] == ''



# Generated at 2022-06-23 23:39:51.320549
# Unit test for function get_source
def test_get_source():
    def fn(a, b, c=[1, 2, 3]):
        return c


# Generated at 2022-06-23 23:39:56.093033
# Unit test for function debug
def test_debug():
    get_message = lambda: 'I am the debug message'
    old_debug = settings.debug
    settings.debug = True
    try:
        debug(get_message)
    except SystemExit:
        sys.exit(messages.fail_message('SystemExit should not happen'))
    finally:
        settings.debug = old_debug

# Generated at 2022-06-23 23:39:58.647510
# Unit test for function get_source
def test_get_source():
    def test_func(a, b):
        c = a + b
        return c

    assert get_source(test_func) == 'c = a + b\nreturn c\n'

# Generated at 2022-06-23 23:40:05.038732
# Unit test for function eager
def test_eager():
    class _DummyClass:

        def _dummy_method(self, data: List[int]) -> Iterable[int]:
            for i, v in enumerate(data):
                if i == 2:
                    yield v
                    data.pop()
                    break

    instance = _DummyClass()

    expected = [1, 2]
    actual = instance._dummy_method([1, 2, 3, 4])
    assert expected == actual

    eager_actual = eager(instance._dummy_method)([1, 2, 3, 4])
    assert expected == eager_actual

# Generated at 2022-06-23 23:40:07.277098
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():

    for i in range(100):
        assert VariablesGenerator.generate('variable') != VariablesGenerator.generate('variable')



# Generated at 2022-06-23 23:40:13.036663
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class A:
        pass
    assert not hasattr(A, '_py_backwards_a_1'), 'Variable already exists.'
    variables = VariablesGenerator()
    assert variables.generate('a') == '_py_backwards_a_1', 'Generate variables error.'
    assert hasattr(A, '_py_backwards_a_1'), 'Variable does not exist.'

# Generated at 2022-06-23 23:40:14.439243
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'message')
    settings.debug = False

# Generated at 2022-06-23 23:40:16.612837
# Unit test for function get_source
def test_get_source():
    def function(a: int, b: int) -> int:
        return a + b
    assert get_source(function) == 'return a + b'

# Generated at 2022-06-23 23:40:20.505719
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    b = VariablesGenerator.generate('b')
    c = VariablesGenerator.generate('c')
    d = VariablesGenerator.generate('d')
    assert a != b and a != c and a != d
    assert b != c and b != d and c != d

# Generated at 2022-06-23 23:40:22.204450
# Unit test for function get_source
def test_get_source():

    def function():
        pass

    assert get_source(function) == 'def function():\n    pass'

# Generated at 2022-06-23 23:40:28.510799
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        for message in ['Message', '', 'abc\nabc\nabc\nabc']:
            expected = messages.debug(message)
            actual = []

            def get_message() -> str:
                return message

            debug(get_message)
            assert expected == actual, 'Expected message: {}\nActual message: {}'.format(expected, actual)
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:40:35.337546
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('a') == '_py_backwards_a_0'
    assert generator.generate('a') == '_py_backwards_a_1'
    assert generator.generate('a') == '_py_backwards_a_2'
    assert generator.generate('b') == '_py_backwards_b_3'
    assert generator.generate('b') == '_py_backwards_b_4'
    assert generator.generate('a') == '_py_backwards_a_5'

# Generated at 2022-06-23 23:40:36.882247
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'



# Generated at 2022-06-23 23:40:39.466335
# Unit test for function eager
def test_eager():
    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    l = gen(5)
    assert isinstance(l, list)
    assert l == range(5)

# Generated at 2022-06-23 23:40:41.538675
# Unit test for function eager
def test_eager():
    assert eager(lambda: [1, 2, 3])() == [1, 2, 3]
    assert eager(lambda: [])(None) == []

# Generated at 2022-06-23 23:40:42.765218
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit):
        warn('test')



# Generated at 2022-06-23 23:40:49.578711
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from .context import settings
    old_stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        settings.debug = True
        debug(lambda: 'mesagge')
        assert sys.stderr.getvalue().strip() == '[DEBUG]: mesagge'
    finally:
        del settings.debug
        sys.stderr = old_stderr

# Generated at 2022-06-23 23:40:52.854609
# Unit test for function eager
def test_eager():
    @eager
    def f(n: int) -> Iterable[int]:
        for i in range(n):
            yield i**2

    assert f(3) == [0, 1, 4]

# Generated at 2022-06-23 23:40:59.038479
# Unit test for function get_source
def test_get_source():
    def foo(z):
        a = 5
        b = 6
        x = 1 + 2 + a + b + z
        return x

    expected = '\n'.join([
        'a = 5',
        'b = 6',
        'x = 1 + 2 + a + b + z',
        'return x',
    ])

    source = get_source(foo)

    print(expected)
    print(source)

    assert source == expected



# Generated at 2022-06-23 23:41:01.349316
# Unit test for function warn
def test_warn():
    def test_wrap():
        try:
            warn('test')
        except Exception:
            return False
        return True
    assert test_wrap()

# Generated at 2022-06-23 23:41:03.150792
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'



# Generated at 2022-06-23 23:41:05.633626
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == "def func():\n    pass\n"

# Generated at 2022-06-23 23:41:07.924755
# Unit test for function eager
def test_eager():
    @eager
    def yield_a():
        yield 'a'
        yield 'a'
    assert yield_a() == ['a', 'a']

# Generated at 2022-06-23 23:41:10.159035
# Unit test for function get_source
def test_get_source():
    def function(a, b, c=10):
        pass
    assert get_source(function) == 'def function(a, b, c=10):\n    pass'

# Generated at 2022-06-23 23:41:12.779701
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'


# Generated at 2022-06-23 23:41:15.772741
# Unit test for function debug
def test_debug():
    from ..conf import enable_debug, disable_debug
    enable_debug()
    debug(lambda: 'test')
    disable_debug()
    messages._is_debug_enabled = False
    debug(lambda: 'test')


# Generated at 2022-06-23 23:41:18.386058
# Unit test for function warn
def test_warn():
    handle = StringIO()
    sys.stderr = handle

    warn('test')

    sys.stderr = sys.__stderr__
    assert 'test' in handle.getvalue()



# Generated at 2022-06-23 23:41:19.616092
# Unit test for function warn
def test_warn():
    assert warn(message='Test warn') == None


# Generated at 2022-06-23 23:41:26.060340
# Unit test for function get_source
def test_get_source():
    # The following function has 5 lines of code
    # and 5 lines of whitespace
    def foo(i: int, j: int) -> int:
        if i < j:
            i += 1
            if i >= j:
                return i
            else:
                return i + 1
        else:
            return 1


    assert get_source(foo) == """def foo(i: int, j: int) -> int:
    if i < j:
        i += 1
        if i >= j:
            return i
        else:
            return i + 1
    else:
        return 1"""


__all__ = [warn, debug, eager, get_source, VariablesGenerator]

# Generated at 2022-06-23 23:41:29.181310
# Unit test for function get_source
def test_get_source():
    def test():
        """
            This is a test function, it
            returns the value of x.
        """
        x = 'x'
        return x

    assert get_source(test) == '    """\n        This is a test function, it\n        returns the value of x.\n    """\n    x = \'x\'\n    return x\n'

# Generated at 2022-06-23 23:41:32.368354
# Unit test for function get_source
def test_get_source():
    from inspect import cleandoc
    from pybackwards.utils import get_source
    def test_func(a, b=1, *args, **kwargs):
        return a > b or \
            'foo' in kwargs and \
            kwargs.get('foo') > 4

    assert get_source(test_func) == cleandoc('''
        return a > b or \
            'foo' in kwargs and \
            kwargs.get('foo') > 4''')



# Generated at 2022-06-23 23:41:37.842044
# Unit test for function debug
def test_debug():
    import sys
    from os import devnull
    import pytest

    def get_message():
        return 'foo'

    # We are creating temporary file to store debug messages.
    with open(devnull, 'w') as stderr:
        sys.stderr = stderr
        with pytest.raises(AssertionError):
            debug(get_message)

# Generated at 2022-06-23 23:41:42.217629
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variable = "ryba"
    variable_generator = VariablesGenerator()
    variable_new = variable_generator.generate(variable)
    assert variable_new == "_py_backwards_{}_{}".format(variable, 0)

# Generated at 2022-06-23 23:41:50.749436
# Unit test for function warn
def test_warn():
    # Arrange
    expected_message = 'message'
    stdout = sys.stdout
    stderr = sys.stderr
    try:
        sys.stdout = BytesIO()
        sys.stderr = BytesIO()
        # Act
        warn(expected_message)
        actual_message = get_result_from_output()
        # Assert
        assert 'message' in actual_message

    finally:
        sys.stdout = stdout
        sys.stderr = stderr



# Generated at 2022-06-23 23:41:55.748287
# Unit test for function debug
def test_debug():
    import click
    from . import messages
    from . import settings
    settings.debug = True
    debug(lambda: 'debug')
    assert click.get_text_stream('stderr').getvalue() == messages.debug('debug') + '\n'
    settings.debug = False
    debug(lambda: 'debug')
    assert click.get_text_stream('stderr').getvalue() == messages.debug('debug') + '\n'

# Generated at 2022-06-23 23:41:58.512222
# Unit test for function get_source
def test_get_source():

    def a(x, y=2):
        return x + y

    source = get_source(a)
    assert source == 'def a(x, y=2):\n    return x + y'

# Generated at 2022-06-23 23:42:01.179142
# Unit test for function warn
def test_warn():
    with open('./tmp.txt', 'w') as f_out:
        warn('FOO MESSAGE')
        sys.stderr = f_out
        assert ('FOO MESSAGE' in open('./tmp.txt', 'r').read())



# Generated at 2022-06-23 23:42:08.177308
# Unit test for function debug
def test_debug():
    import sys
    import io
    import pytest

    output = io.StringIO()
    real_std_err = sys.stderr
    try:
        settings.debug = True
        sys.stderr = output
        debug(lambda: 'message to debug')
        assert 'message to debug' in output.getvalue()

        settings.debug = False
        output.truncate(0)
        output.seek(0)
        debug(lambda: 'message to debug')
        assert '' == output.getvalue()
    finally:
        sys.stderr = real_std_err
        output.close()