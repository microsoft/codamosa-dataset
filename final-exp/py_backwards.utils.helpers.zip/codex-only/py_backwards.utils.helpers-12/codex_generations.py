

# Generated at 2022-06-23 23:32:07.843823
# Unit test for function debug
def test_debug():
    def test_function(input_value, output_value):
        if input_value == output_value:
            debug(lambda : 'The input value is the same as the output value')
        else:
            debug(lambda : 'The input value is not the same as the output value')

    settings.debug = True
    test_function(123, 123)
    test_function('a', 'b')
    settings.debug = False
    test_function(123, 123)
    test_function('a', 'b')



# Generated at 2022-06-23 23:32:18.335012
# Unit test for function debug
def test_debug():
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        class MockStderr:
            def __init__(self):
                self.messages = []

            def write(self, message):
                self.messages.append(message)

        def setUp(self):
            self.message = 'message'
            self.mock_stderr = self.MockStderr()

        def tearDown(self):
            sys.stderr = self.mock_stderr

        def test_debug_gets_output_when_enabled(self):
            settings.debug = True
            sys.stderr = self.mock_stderr
            debug(lambda: self.message)

# Generated at 2022-06-23 23:32:19.957673
# Unit test for function get_source
def test_get_source():
    def foo():
        print('qwe')
    assert 'print(\'qwe\')' in get_source(foo)

# Generated at 2022-06-23 23:32:23.416243
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("unique") == "_py_backwards_unique_0"
    assert VariablesGenerator.generate("unique") == "_py_backwards_unique_1"
    assert VariablesGenerator.generate("unique") == "_py_backwards_unique_2"

# Generated at 2022-06-23 23:32:31.124085
# Unit test for function get_source
def test_get_source():
    def example_function():
        var1 = 1
        var2 = var1
        var3 = var2
        var4 = var3
        var5 = var4
        var6 = var5

    assert (
        get_source(example_function) ==
        'var1 = 1\n'
        'var2 = var1\n'
        'var3 = var2\n'
        'var4 = var3\n'
        'var5 = var4\n'
        'var6 = var5\n'
    )


# Generated at 2022-06-23 23:32:35.217780
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'

# Generated at 2022-06-23 23:32:37.152490
# Unit test for function get_source
def test_get_source():
    def test(): pass
    assert get_source(test) == "def test(): pass"
    assert get_source(test).startswith('def')

# Generated at 2022-06-23 23:32:47.575104
# Unit test for function get_source

# Generated at 2022-06-23 23:32:52.549708
# Unit test for function debug
def test_debug():
    import io
    import contextlib

    with contextlib.redirect_stdout(io.StringIO()):
        settings.debug = True
        debug(lambda: 'message')
    assert 'message' in sys.stderr.getvalue()
    with contextlib.redirect_stdout(io.StringIO()):
        settings.debug = False
        debug(lambda: 'message')
    assert 'message' not in sys.stderr.getvalue()



# Generated at 2022-06-23 23:32:59.336475
# Unit test for function eager
def test_eager():
    import itertools
    import random
    import string

    def generate_chars() -> Iterable[str]:
        result = []
        for _ in range(3):
            result.append(''.join(random.choices(string.ascii_lowercase, k=3)))
        return result

    def generate_numbers() -> Iterable[int]:
        return itertools.count(start=0, step=5)

    generate_eagered_chars = eager(generate_chars)
    generate_eagered_numbers = eager(generate_numbers)
    print('Eager chars:', generate_eagered_chars())
    print('Eager numbers:', generate_eagered_numbers())

# Generated at 2022-06-23 23:33:02.014372
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('name') == '_py_backwards_name_0'
    assert VariablesGenerator.generate('name') == '_py_backwards_name_1'

# Generated at 2022-06-23 23:33:06.771052
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'assert get_source(test_get_source) == \'assert get_source(test_get_source) == """""assert get_source(test_get_source) == \'\'\'assert get_source(test_get_source) == ""\'\'\'assert get_source(test_get_source) == "\'\'\'\'"'



# Generated at 2022-06-23 23:33:16.949353
# Unit test for function debug
def test_debug():
    import sys
    import mock
    import py_backwards.utils.internal as utils

    test_data = [
        'message',
        'another message',
    ]

    for message in test_data:
        with mock.patch.object(utils.sys, 'stderr', new=sys.stdout):
            with mock.patch.object(utils.settings, 'debug', new=True):
                utils.debug(lambda: message)
                assert message in sys.stdout.getvalue().strip()

    with mock.patch.object(utils.sys, 'stderr', new=sys.stdout):
        with mock.patch.object(utils.settings, 'debug', new=False):
            utils.debug(lambda: test_data[0])
            assert test_data[0] not in sys.stdout.get

# Generated at 2022-06-23 23:33:23.327040
# Unit test for function debug
def test_debug():
    class DummyLogger():
        def __init__(self):
            self.log = []
        def __call__(self, msg):
            self.log.append(msg)
    logger = DummyLogger()
    saved_print = print
    try:
        print = logger
        settings.debug = True
        debug(lambda: 'debug')
    finally:
        print = saved_print
        settings.debug = False
    assert logger.log == ['[DEBUG] debug\n']

# Generated at 2022-06-23 23:33:24.307077
# Unit test for function warn
def test_warn():
    warn("message")


# Generated at 2022-06-23 23:33:28.330392
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('x') == '_py_backwards_x_0'
    assert generator.generate('y') == '_py_backwards_y_1'
    assert generator.generate('x') == '_py_backwards_x_2'

# Generated at 2022-06-23 23:33:33.899058
# Unit test for function debug
def test_debug():
    # pylint: disable=redefined-outer-name
    import io
    import sys
    from contextlib import contextmanager
    from io import StringIO
    from unittest import TestCase

    @contextmanager
    def captured_output() -> io.StringIO:
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class Test(TestCase):
        def test_true(self):
            settings.debug = True

# Generated at 2022-06-23 23:33:41.853444
# Unit test for function get_source
def test_get_source():
    import inspect
    def func(x):
        print(x)

    def func_with_padding(padding, x):
        for i in range(padding):
            if padding > 1:
                print(x)
            else:
                print(x)

    def func_with_multiline(x):
        print(x)
        print(x)

    assert get_source(func) == inspect.getsource(func)
    assert get_source(func_with_padding) == inspect.getsource(func_with_padding)
    assert get_source(func_with_multiline) == inspect.getsource(func_with_multiline)

# Generated at 2022-06-23 23:33:43.435474
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test message')
    settings.debug = False



# Generated at 2022-06-23 23:33:44.772839
# Unit test for function get_source
def test_get_source():
    def foo():
        return 0
    expected = "return 0"
    assert get_source(foo) == expected

# Generated at 2022-06-23 23:33:47.143013
# Unit test for function get_source
def test_get_source():
    def test(a, b=5, *, c='foo', d=None):
        pass

    assert get_source(test).startswith('def test')

# Generated at 2022-06-23 23:33:53.693072
# Unit test for function get_source
def test_get_source():
    assert (get_source(get_source) ==
            'def get_source(fn: Callable[..., Any]) -> str:\n'
            '    """Returns source code of the function."""\n'
            '    source_lines = getsource(fn).split(\'\\n\')\n'
            '    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n'
            '    return \'\\n\'.join(line[padding:] for line in source_lines)')

# Generated at 2022-06-23 23:33:59.346699
# Unit test for function warn
def test_warn():
    from ..conf import settings
    import io
    import sys
    stderr_real = sys.stderr
    try:
        sys.stderr = io.StringIO()  # redirect stderr output to in-memory buffer
        settings.debug = True
        warn('message')
        assert sys.stderr.getvalue().strip() == messages.warn('message')
    finally:
        sys.stderr = stderr_real  # restore the original stderr

# Generated at 2022-06-23 23:34:02.645769
# Unit test for function eager
def test_eager():
    @eager
    def lazy_sqr(x: int) -> Iterable[int]:
        if x > 10:
            yield x * x
        else:
            for i in range(x):
                yield i * i

    assert lazy_sqr(1) == [0]
    assert lazy_sqr(2) == [0, 1]
    assert lazy_sqr(3) == [0, 1, 4]
    assert lazy_sqr(11) == [121]

# Generated at 2022-06-23 23:34:04.031531
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    assert v.generate('variable') == '_py_backwards_variable_0'

# Generated at 2022-06-23 23:34:07.186534
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    gen_source = getsource(gen.generate)
    counter = VariablesGenerator._counter
    assert gen.generate('name') == '_py_backwards_name_0'
    assert counter + 1 == VariablesGenerator._counter
    assert gen_source == getsource(gen.generate)


# Generated at 2022-06-23 23:34:14.210489
# Unit test for function get_source
def test_get_source():
    assert get_source(foo) == 'def foo():\n    return 1'

# Generated at 2022-06-23 23:34:16.683253
# Unit test for function debug
def test_debug():
    settings.debug = True

    counter = 0

    def get_message():
        return str(counter)

    debug(get_message)

    assert counter == 0, counter

    counter += 1

    settings.debug = False

# Generated at 2022-06-23 23:34:24.299007
# Unit test for function warn
def test_warn():
    # Example: weird function which prints message to sys.stderr
    def weird(message: str) -> None:
        print(message, file=sys.stderr)
    # Patching weird method to check if message was printed
    with mock.patch('sys.stderr.write') as mock_write:
        warn('Expected message')
        mock_write.assert_called_once_with(messages.warn('Expected message'))
    # Checking if weird function wasn't called
    with mock.patch('sys.stderr.write') as mock_write:
        warn('Expected message')
        mock_write.assert_not_called()

# Generated at 2022-06-23 23:34:26.724610
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]

    @eager
    def f():
        for i in l:
            if i % 2 == 0:
                yield i

    assert f() == [2]


# Generated at 2022-06-23 23:34:30.400451
# Unit test for function eager
def test_eager():
    @eager
    def sum_generator():
        for i in range(10):
            yield i

    assert sum_generator() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:34:35.738584
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '    assert get_source(test_get_source) == ' \
                                         '\'\\n    assert get_source(test_get_source) == \\\'\' + \\\'{}\\\'\'.format(get_source(test_get_source))'



# Generated at 2022-06-23 23:34:37.754100
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-23 23:34:39.000193
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') != VariablesGenerator.generate('test')

# Generated at 2022-06-23 23:34:43.298022
# Unit test for function get_source
def test_get_source():
    def fn():
        for i in range(10):
            print(i)

    assert get_source(fn) == """\
for i in range(10):
    print(i)
""", "get_source(fn) == '\\nfor i in range(10):\\n    print(i)\\n'"

# Generated at 2022-06-23 23:34:45.882290
# Unit test for function eager
def test_eager():
    @eager
    def iter_():
        yield 'a'
        yield 'b'
        yield 'c'

    assert iter_() == ['a', 'b', 'c']

# Generated at 2022-06-23 23:34:49.856440
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    f = StringIO()
    with redirect_stderr(f):
        warn('Fake warning')
    assert f.getvalue() == messages.warn('Fake warning') + '\n'



# Generated at 2022-06-23 23:34:53.679670
# Unit test for function get_source
def test_get_source():
    def some_fn(a, b, c):
        return a + b + c

    assert get_source(some_fn) == 'return a + b + c'

    class SomeClass:
        def __getitem__(self, key):
            return self

        def __len__(self):
            return 0

    # Unit test for conflict between VariablesGenerator and some class attribute.
    assert get_source(SomeClass.__getitem__) == 'return self'



# Generated at 2022-06-23 23:34:56.616570
# Unit test for function eager
def test_eager():
    def test_gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert eager(test_gen)(3) == [0, 1, 2]


# Generated at 2022-06-23 23:34:57.821329
# Unit test for function eager
def test_eager():
    assert eager(range)(1, 4) == [1, 2, 3]



# Generated at 2022-06-23 23:35:04.307534
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():

    assert VariablesGenerator.generate("x") == "_py_backwards_x_0"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_1"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_2"
    assert VariablesGenerator.generate("x") == "_py_backwards_x_3"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_4"

# Generated at 2022-06-23 23:35:06.937646
# Unit test for function eager
def test_eager():
    from py_backwards.utils.typing_ import *  # pylint: disable=unused-wildcard-import
    @eager
    def x() -> Iterable[int]:
        yield 1
        yield 2
        yield 3
    assert x() == [1, 2, 3]

# Generated at 2022-06-23 23:35:09.142167
# Unit test for function get_source
def test_get_source():
    def foo(a: int, b: int) -> int:
        return a + b

    expected = """
        return a + b
    """
    assert expected == get_source(foo)

# Generated at 2022-06-23 23:35:11.450484
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('aaa') == '_py_backwards_aaa_0'
    assert VariablesGenerator.generate('aaa') == '_py_backwards_aaa_1'

# Generated at 2022-06-23 23:35:15.068331
# Unit test for function debug
def test_debug():
    # GIVEN
    settings.debug = True
    debug_messages = []
    def capture(get_message: Callable[[], str]) -> None:
        debug_messages.append(get_message())
    # WHEN
    debug(lambda: 'test message')
    # THEN
    assert debug_messages == ['test message']

# Generated at 2022-06-23 23:35:18.763704
# Unit test for function debug
def test_debug():
    settings_debug = settings.debug
    settings.debug = False
    debug(lambda: 'Test')
    settings.debug = True
    debug(lambda: 'Test')
    settings.debug = settings_debug

# Generated at 2022-06-23 23:35:21.455351
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> Iterable[int]:
        for i in range(3):
            yield i

    assert gen() == [0, 1, 2]

# Generated at 2022-06-23 23:35:23.245000
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') != VariablesGenerator.generate('var')


# Generated at 2022-06-23 23:35:27.419018
# Unit test for function get_source
def test_get_source():
    source_code = """def func(a, b):\r\n    print(a + b)"""
    def func(a, b):
        print(a + b)

    assert get_source(func) == source_code

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-23 23:35:29.212642
# Unit test for function eager
def test_eager():
    def foo():
        a = 1
        yield a
        a += 1
        yield a
        a += 1
        yield a

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-23 23:35:37.665141
# Unit test for function eager
def test_eager():
    new_list = []
    class TestClass:
        @staticmethod
        @eager
        def test_staticmethod():
            for i in range(6):
                new_list.append(i)
                yield i
        @classmethod
        @eager
        def test_classmethod():
            for i in range(6):
                new_list.append(i)
                yield i
        @eager
        def test_method(self):
            for i in range(6):
                new_list.append(i)
                yield i
    assert TestClass.test_staticmethod() == [i for i in range(6)]
    assert new_list == [i for i in range(6)]
    new_list = []
    tc = TestClass()

# Generated at 2022-06-23 23:35:39.859858
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-23 23:35:45.040491
# Unit test for function eager
def test_eager():
    @eager
    def test_generator(x: int, y: int) -> Iterable[int]:
        for i in range(x):
            for j in range(y):
                yield i, j

    assert test_generator(3, 4) == list(test_generator(3, 4))


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:35:50.164810
# Unit test for function warn
def test_warn():
    sys.stderr = open('warn_output.txt', 'w')
    warn('some message')
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    assert open('warn_output.txt', 'r').read() == 'PyBackwards: some message\n'


# Generated at 2022-06-23 23:35:52.728994
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass
    assert get_source(foo) == 'pass'
    assert get_source(bar) == 'pass'

# Generated at 2022-06-23 23:36:00.773199
# Unit test for function debug
def test_debug():
    # create function which returns the message to print
    def get_message():
        return "this is a test"

    # set debug to True
    settings.debug = True

    # call debug
    debug(get_message)

    # Check output
    assert sys.stderr.getvalue() == "    This is a test\n"

    # remove output of debug from stderr
    sys.stderr.truncate(0)

    # set debug to False
    settings.debug = False

    # call debug
    debug(get_message)

    # check that nothing is printed
    assert sys.stderr.getvalue() == ""

    # remove output of debug from stderr
    sys.stderr.truncate(0)

    # reset debug to default value
    settings.debug = settings.debug_default

# Generated at 2022-06-23 23:36:04.718841
# Unit test for function warn
def test_warn():
    msg = 'Hello!'
    out = StringIO()
    with patch('sys.stderr', out):
        warn(msg)
    assert out.getvalue() == messages.warn(msg) + '\n'


# Generated at 2022-06-23 23:36:07.968791
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(0))() == []
    assert eager(lambda: range(10))() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:36:10.047140
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Debug message')
    finally:
        settings.debug = False


# Generated at 2022-06-23 23:36:12.775497
# Unit test for function eager
def test_eager():
    @eager
    def a():
        for i in range(4):
            yield i

    result = a()
    assert result == [0, 1, 2, 3]

# Generated at 2022-06-23 23:36:16.264310
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'


# Test of get_source

# Generated at 2022-06-23 23:36:17.963297
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:36:23.821576
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert(VariablesGenerator.generate('abc') == '_py_backwards_abc_0')
    assert(VariablesGenerator.generate('abc') == '_py_backwards_abc_1')
    assert(VariablesGenerator.generate('abc') == '_py_backwards_abc_2')
    assert(VariablesGenerator.generate('def') == '_py_backwards_def_3')
    assert(VariablesGenerator.generate('def') == '_py_backwards_def_4')
    assert(VariablesGenerator.generate('abc') == '_py_backwards_abc_5')

# Generated at 2022-06-23 23:36:27.088496
# Unit test for function debug
def test_debug():
    settings.debug = True

    log = [None]

    def wrapped():
        log[0] = 'message'

    debug(wrapped)

    assert log[0] == 'message'

    settings.debug = False

# Generated at 2022-06-23 23:36:29.077502
# Unit test for function get_source
def test_get_source():
    def test():
        if True:
            a = 1

    assert get_source(test) == 'a = 1'


# Generated at 2022-06-23 23:36:36.568632
# Unit test for function warn
def test_warn():
    import io as StringIO
    output = StringIO.StringIO()
    save_stdout=sys.stdout
    sys.stdout = output
    warn('test')
    sys.stdout = save_stdout
    output.seek(0)
    print('Got this: "' + output.read() + '"')
    print('Expected: "'+messages.warn('test')+'"')
    assert(output.read() == messages.warn('test'))

# Generated at 2022-06-23 23:36:42.096361
# Unit test for function debug
def test_debug():
    # Reset debug value
    settings.debug = False
    debug(lambda: "debug message")

    settings.debug = True
    saved_stderr = sys.stderr
    sys.stderr = messages.StringIO()
    try:
        debug(lambda: "debug message")
        assert sys.stderr.getvalue() == '[DEBUG]    debug message\n'
    finally:
        sys.stderr = saved_stderr

# Generated at 2022-06-23 23:36:45.431998
# Unit test for function debug
def test_debug():
    debug(lambda: 'This is debug message')
    settings.debug = False
    try:
        debug(lambda: 'This is debug message')
    except Exception:
        pass
    finally:
        settings.debug = True

# Generated at 2022-06-23 23:36:49.702693
# Unit test for function get_source
def test_get_source():
    def fn():
        a = 1
        return a

    assert get_source(fn) == 'a = 1\nreturn a'

    def fn2():
        b = 2
        return b

    assert get_source(fn2) == 'b = 2\nreturn b'



# Generated at 2022-06-23 23:36:51.941599
# Unit test for function warn
def test_warn():
    import sys
    sys.modules['sys'].stderr = sys.__stdout__
    warn('inside test_warn')
    assert True



# Generated at 2022-06-23 23:36:57.587277
# Unit test for function debug
def test_debug():
    from unittest import mock
    with mock.patch.object(sys.stderr, 'write') as mock_write:
        settings.debug = True
        debug(lambda: 'message')
        assert mock_write.mock_calls == [mock.call('\033[1;32mDEBUG: message\033[0m\n')]
        settings.debug = False
        debug(lambda: 'message')
        assert mock_write.mock_calls == [mock.call('\033[1;32mDEBUG: message\033[0m\n')]



# Generated at 2022-06-23 23:37:07.656766
# Unit test for function warn
def test_warn():
    # We need to mock stdout
    # pylint: disable=import-outside-toplevel; We need to replace stdout
    import io
    from contextlib import redirect_stdout

    # Stringio from temporary file
    f = io.StringIO()

    # We save old stdout
    old_stdout = sys.stdout

    # We change stdout to our mock
    sys.stdout = f

    # We call warn function with some message
    warn('test')

    # We change stdout back
    sys.stdout = old_stdout

    # ---------Tests---------
    # Check if output from warn is what we expect
    assert '\033[93mWARN\033[0m: test' == f.getvalue().strip()

# Generated at 2022-06-23 23:37:09.628647
# Unit test for function get_source
def test_get_source():
    def source_test():
        return 1

    assert get_source(source_test) == 'return 1'



# Generated at 2022-06-23 23:37:12.309430
# Unit test for function eager
def test_eager():
    def generate_integers():
        yield 1
        yield 2
        yield 3
        yield 4
        yield 5

    generator = generate_integers()
    assert list(generator) == eager(generator)

# Generated at 2022-06-23 23:37:14.446187
# Unit test for function get_source
def test_get_source():
    def fn(a, b, c=3, d=4, *args: Any, **kwargs: Any) -> None:
        return a + b

    source = get_source(fn)

# Generated at 2022-06-23 23:37:18.718220
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('c') == '_py_backwards_c_2'



# Generated at 2022-06-23 23:37:25.058962
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: x
    settings.debug = True
    from unittest.mock import patch
    with patch('sys.stderr', new=open('/dev/null', 'w')):
        debug(lambda: 'my message')
    settings.debug = False
    with patch('sys.stderr', new=open('/dev/null', 'w')):
        debug(lambda: 'my message')



# Generated at 2022-06-23 23:37:28.866518
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        warn('test')
        assert fake_stderr.getvalue() == messages.warn('test') + '\n'


# Generated at 2022-06-23 23:37:30.985386
# Unit test for function eager
def test_eager():
    def f(i):
        for j in range(i):
            yield j

    assert eager(f)(2) == [0, 1]



# Generated at 2022-06-23 23:37:36.179323
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()

    debug(lambda: 'What is up')
    assert sys.stderr.getvalue() == 'DEBUG: What is up\n'

    debug(lambda: 'Nothing is up')
    assert sys.stderr.getvalue() == 'DEBUG: What is up\n' \
        'DEBUG: Nothing is up\n'



# Generated at 2022-06-23 23:37:38.766808
# Unit test for function debug
def test_debug():
    with patch('sys.stderr') as stderr:
        debug(lambda: 'debug message')
    assert stderr.write.called



# Generated at 2022-06-23 23:37:43.650965
# Unit test for function debug
def test_debug():
    get_message = lambda: 'some message'
    old_debug_setting = settings.debug
    # Case 1: debug is false
    settings.debug = False
    debug(get_message)
    # Case 2: debug is true
    settings.debug = True
    debug(get_message)
    # Restore the old setting
    settings.debug = old_debug_setting

# Generated at 2022-06-23 23:37:50.485435
# Unit test for function warn
def test_warn():
    # empty message
    with pytest.raises(ValueError):
        warn('')

    # message consists gaps only
    with pytest.raises(ValueError):
        warn('    ')

    # message is '\n'
    with pytest.raises(ValueError):
        warn('\n')

    # message is '\n\n\n'
    with pytest.raises(ValueError):
        warn('\n' * 3)

    # message is '\t'
    with pytest.raises(ValueError):
        warn('\t')

    # message is '\t\t\t'
    with pytest.raises(ValueError):
        warn('\t' * 3)

# Generated at 2022-06-23 23:37:55.047239
# Unit test for function eager
def test_eager():
    from random import randint

    @eager
    def random_number_generator(n: int) -> Iterable[int]:
        for i in range(n):
            yield randint(1, 100)

    assert isinstance(random_number_generator(10), list)


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:37:58.093131
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    original = VariablesGenerator._counter
    VariablesGenerator._counter = 0
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    VariablesGenerator._counter = original

# Generated at 2022-06-23 23:38:03.401950
# Unit test for function get_source
def test_get_source():
    import textwrap

    @eager
    def function():
        yield 1
        yield 2
        yield 3

    expected_source = textwrap.dedent('''
        @eager
        def function():
            yield 1
            yield 2
            yield 3
    ''').strip()

    assert get_source(function) == expected_source



# Generated at 2022-06-23 23:38:04.252908
# Unit test for function warn
def test_warn():
    warn('Hello, I am warning!')


# Unit testing for function debug

# Generated at 2022-06-23 23:38:07.452300
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch.object(sys.stderr, 'write') as mock_stderr:
        settings.debug = False
        debug(lambda: 'hello')
        assert mock_stderr.call_count == 0

        settings.debug = True
        debug(lambda: 'hello')
        assert mock_stderr.call_count == 1
        assert mock_stderr.call_args[0][0] == messages.debug('hello')

# Generated at 2022-06-23 23:38:11.590508
# Unit test for function debug
def test_debug():
    """Test if debug function print message.
    """
    message = 'test_debug'
    with patch('sys.stderr') as mock:
        debug(lambda: message)
        assert mock.write.call_args[1].__getitem__('sep').startswith(message)



# Generated at 2022-06-23 23:38:14.092012
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: "test_debug")
    settings.debug = True
    debug(lambda: "test_debug")


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:38:17.522754
# Unit test for function eager
def test_eager():
    def generator(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert eager(generator)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:38:24.970953
# Unit test for function debug
def test_debug():
    _real_debug = settings.debug
    settings.debug = True
    try:
        test_message = 'test'
        with mock.patch('sys.stderr', new=mock.Mock(spec=io.IOBase)) as mock_stderr:
            mock_stderr.write.side_effect = IOError
            debug(lambda: test_message)
        assert mock_stderr.write.call_args == mock.call(messages.debug(test_message))
    finally:
        settings.debug = _real_debug



# Generated at 2022-06-23 23:38:28.279122
# Unit test for function debug
def test_debug():
    import io

    with io.StringIO() as s:
        sys.stderr = s
        settings.debug = True
        debug(lambda: 'test')
        assert s.getvalue() == messages.debug('test') + '\n'



# Generated at 2022-06-23 23:38:31.235413
# Unit test for function warn
def test_warn():
    """
    >>> test_warn()
    \x1b[44m\x1b[35mWarning:\x1b[0m
        %s
    message
    """
    warn('message')

# Generated at 2022-06-23 23:38:33.622353
# Unit test for function debug
def test_debug():
    global settings
    settings = settings.copy()
    settings.debug = True

    messages.DEBUG_MESSAGE = '[$message]'

    debug(lambda: 'Hello, debug!')
    assert settings.debug



# Generated at 2022-06-23 23:38:38.403257
# Unit test for function debug
def test_debug():
    messages.debug = 'Test message: {}'
    messages_list: List[str] = []
    old_print = print
    try:
        print = messages_list.append
        settings.debug = True
        debug(lambda: 'test')
        assert messages_list == ['Test message: test']

        messages_list.clear()
        settings.debug = False
        debug(lambda: 'test')
        assert messages_list == []
    finally:
        settings.debug = False
        print = old_print

# Generated at 2022-06-23 23:38:42.083698
# Unit test for function get_source
def test_get_source():
    def foo():
        if True:
            raise Exception()

    source = '''def foo():
        if True:
            raise Exception()
'''

    assert get_source(foo).strip() == source.strip()

# Generated at 2022-06-23 23:38:43.573723
# Unit test for function warn
def test_warn():
    warn('This is a test')
    print('Test 1 ok')



# Generated at 2022-06-23 23:38:45.972178
# Unit test for function eager
def test_eager():
    @eager
    def get_iterator():
        yield 1
        yield 2
        yield 3

    assert get_iterator() == [1, 2, 3]

# Generated at 2022-06-23 23:38:46.657664
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-23 23:38:50.042951
# Unit test for function get_source
def test_get_source():
    def some_function():
        a = 1
        b = 2
        return a + b

    assert get_source(some_function) == 'a = 1\n' \
                                       'b = 2\n' \
                                       'return a + b'

# Generated at 2022-06-23 23:38:52.718147
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = stream = io.StringIO()
    debug(lambda: 'hello')
    assert stream.getvalue() == messages.debug('hello') + '\n'



# Generated at 2022-06-23 23:38:55.130313
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'

# Generated at 2022-06-23 23:38:56.406109
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():'



# Generated at 2022-06-23 23:39:01.783214
# Unit test for function warn
def test_warn():
    from ..mock import MockStream

    stdout, stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = MockStream(), MockStream()

    try:
        warn('sample')

        assert sys.stderr.content == messages.warn('sample') + '\n'
        assert sys.stdout.content == ''
    finally:
        sys.stdout, sys.stderr = stdout, stderr



# Generated at 2022-06-23 23:39:05.183874
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    def foo():
        print(VariablesGenerator.generate("c"))
        print(VariablesGenerator.generate("c"))
        print(VariablesGenerator.generate("c"))
    foo()

# Generated at 2022-06-23 23:39:09.995001
# Unit test for function debug
def test_debug():
    res = []

    def get_message():
        return 'test'

    debug(get_message)
    assert len(res) == 0

    settings.debug = True

    debug(get_message)
    assert len(res) == 1
    assert res[0] == messages.debug('test')



# Generated at 2022-06-23 23:39:15.148478
# Unit test for function debug
def test_debug():
    from .conf import settings
    settings.debug = True

    def logger():
        '''Logging function'''
        debug(lambda: 'Hello')

    try:
        logger()
    except ModuleNotFoundError:
        assert False, 'settings.debug is not working'
    else:
        assert True, 'settings.debug is working'



# Generated at 2022-06-23 23:39:19.254047
# Unit test for function warn
def test_warn():
    """Test that warning is raised."""
    message = 'Warning message'
    with mock.patch('sys.stderr') as stderr:
        warn(message)
        stderr.write.assert_called_once_with(messages.warn(message) + '\n')


# Generated at 2022-06-23 23:39:23.091919
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(100):
        v1 = VariablesGenerator.generate('foo')
        v2 = VariablesGenerator.generate('foo')
        assert v1 != v2
        assert v1.find('foo') >= 0
        assert v2.find('foo') >= 0


# Generated at 2022-06-23 23:39:26.654978
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()

    assert vg.generate("var") == '_py_backwards_var_0'
    assert vg.generate("var") == '_py_backwards_var_1'



# Generated at 2022-06-23 23:39:28.281077
# Unit test for function warn
def test_warn():
    assert warn.__name__ == 'warn'



# Generated at 2022-06-23 23:39:34.616132
# Unit test for function get_source
def test_get_source():
    def foo():
        for x in [1, 2, 3]:
            yield x

    def bar():
        """
        Lorem ipsum.
        """
        for x in [1, 2, 3]:
            yield x

    assert get_source(foo) == 'for x in [1, 2, 3]:\n    yield x'
    assert get_source(bar) == 'for x in [1, 2, 3]:\n    yield x'

# Generated at 2022-06-23 23:39:38.451234
# Unit test for function get_source
def test_get_source():
    def function():
        """Docstring"""
        some_str = 'str'
        return 42
    expected_source = '''some_str = 'str'
return 42'''
    assert get_source(function) == expected_source

# Generated at 2022-06-23 23:39:40.508336
# Unit test for function get_source
def test_get_source():
    def fn():
        return 1
    source = get_source(fn)
    assert '        return 1' in source



# Generated at 2022-06-23 23:39:43.493158
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    s = StringIO()
    with redirect_stderr(s):
        warn('Hello, world')
        assert s.getvalue() == '\x1b[1;33mHello, world\x1b[0m\n'

# Generated at 2022-06-23 23:39:45.661085
# Unit test for function get_source
def test_get_source():
    def fn(): pass
    assert get_source(fn) == 'def fn(): pass'


# Generated at 2022-06-23 23:39:46.593751
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

test_debug()

# Generated at 2022-06-23 23:39:52.055747
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Debug message'

    import io
    import sys
    old_stdout = sys.stderr
    sys.stderr = io.StringIO()
    try:
        debug(get_message)
        assert sys.stderr.getvalue() == 'Debug message\n'

    finally:
        sys.stderr = old_stdout

# Generated at 2022-06-23 23:39:53.047803
# Unit test for function warn
def test_warn():
    warn('Test warn')


# Generated at 2022-06-23 23:40:01.202778
# Unit test for function debug
def test_debug():
    messages.debug = lambda msg: 'debug: {}'.format(msg)
    settings.debug = False

    debug(lambda: 'no debug')
    assert not settings.debug
    assert sys.stderr.getvalue() == ''
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

    settings.debug = True
    debug(lambda: 'debug')
    assert settings.debug
    assert sys.stderr.getvalue() == 'debug: debug\n'
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

# Generated at 2022-06-23 23:40:06.261745
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_2'
    assert VariablesGenerator.generate('other_variable') == '_py_backwards_other_variable_3'



# Generated at 2022-06-23 23:40:08.672707
# Unit test for function eager
def test_eager():
    def test1():
        yield 1
        yield 2

    lst = eager(test1)()
    assert lst == [1, 2]



# Generated at 2022-06-23 23:40:12.269901
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'


# Generated at 2022-06-23 23:40:14.439037
# Unit test for function get_source
def test_get_source():
    def func(): return 0

    expected_source = """def func(): return 0"""

    assert get_source(func) == expected_source

# Generated at 2022-06-23 23:40:17.302647
# Unit test for function eager
def test_eager():
    @eager
    def range_10():
        return range(10)

    assert range_10() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:40:20.516167
# Unit test for function eager
def test_eager():
    test_var = []

    @eager
    def generate_evens() -> Iterable[int]:
        yield 2
        yield 4
        yield 6

    generate_evens().extend(test_var)
    assert test_var == [2, 4, 6]



# Generated at 2022-06-23 23:40:23.455110
# Unit test for function eager
def test_eager():
    def double(x: int) -> Iterable[int]:
        while x:
            yield x
            x *= 2

    assert eager(double)(1) == [1, 2, 4, 8]

# Generated at 2022-06-23 23:40:25.498221
# Unit test for function warn
def test_warn():
    message = 'Hello world!'
    warn(message)


if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-23 23:40:26.668432
# Unit test for function warn
def test_warn():
    warn('Hello World!')
#

# Generated at 2022-06-23 23:40:36.148151
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr, redirect_stdout

    sys.stderr, stderr = io.StringIO(), sys.stderr
    sys.stdout, stdout = io.StringIO(), sys.stdout
    settings.debug = True
    debug(lambda: 'debug message')
    assert sys.stderr.getvalue() == '\x1b[41m\x1b[30m\x1b[1mdebug message\x1b[0m\n'

    sys.stderr, sys.stdout = stderr, stdout
    settings.debug = False
    debug(lambda: 'debug message')
    assert sys.stderr.getvalue() == ''
    assert sys.stdout.getvalue() == ''



# Generated at 2022-06-23 23:40:42.773641
# Unit test for function debug
def test_debug():
    import io
    import sys

    messages_output = io.StringIO()
    debug_output = io.StringIO()

    old_stdout = sys.stdout
    old_console = sys.console_type
    try:
        sys.stdout = messages_output
        sys.console_type = 'spam'
        debug_output = io.StringIO()
        sys.stderr = debug_output
        settings.debug = True
        messages.debug = 'debug'
        debug('my debug')
        assert debug_output.getvalue() == messages.debug('my debug') + '\n'
        debug(lambda: 'my debug')
        assert debug_output.getvalue() == messages.debug('my debug') + '\n'
    finally:
        sys.stdout = old_stdout
        sys.console_

# Generated at 2022-06-23 23:40:46.924705
# Unit test for function warn
def test_warn():
    import io
    sys.stderr = buffer = io.StringIO()
    warn('test message')
    assert buffer.getvalue() == messages.warn('test message') + '\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:40:50.630372
# Unit test for function warn
def test_warn():
    from .fakeio import FakeIO

    with FakeIO() as fakeio:
        warn('my message')
        assert fakeio.get_stderr() == '\033[93mmy message\033[0m\n'



# Generated at 2022-06-23 23:40:54.178396
# Unit test for function eager
def test_eager():
    @eager
    def gen_numbers() -> Iterable[int]:
        for i in range(10):
            yield i
    assert(gen_numbers() == [i for i in range(10)])



# Generated at 2022-06-23 23:40:58.856990
# Unit test for function warn
def test_warn():
    messages.DEBUG = False
    sys.stderr = io.StringIO()
    warn('Test')
    result = sys.stderr.getvalue().strip()
    sys.stderr = sys.__stderr__
    assert result == '\x1b[33mWARNING: Test\x1b[0m'


# Generated at 2022-06-23 23:41:00.930819
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    expected = """def func():
    pass"""

    assert get_source(func) == expected

# Generated at 2022-06-23 23:41:05.390040
# Unit test for function debug
def test_debug():
    """
    >>> debug(lambda: 'foo')
    >>> debug(lambda: 'bar')
    >>> settings.debug = True
    >>> debug(lambda: 'baz')
    >>> settings.debug = False
    >>> debug(lambda: 'qux')
    """
    pass

# Generated at 2022-06-23 23:41:11.755520
# Unit test for function debug
def test_debug():
    original_debug_value = settings.debug
    settings.debug = True
    try:
        captured_output = StringIO()
        sys.stderr = captured_output
        def get_message():
            return 'Hello world!'
        debug(get_message)
        sys.stderr = sys.__stderr__
        assert captured_output.getvalue() == messages.debug('Hello world!') + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = original_debug_value

# Generated at 2022-06-23 23:41:16.732203
# Unit test for function warn
def test_warn():
    import sys
    from io import StringIO
    out = StringIO()
    sys.stderr = out
    warn("Warning: Interpreter not found!")
    sys.stderr = sys.__stderr__
    output = out.getvalue().strip()
    assert output == "Warning: Interpreter not found!", "Warn should print message in the console with red colour(use sys.stderr.write)."


# Generated at 2022-06-23 23:41:18.026821
# Unit test for function eager
def test_eager():
    @eager
    def generate():
        yield 1

    assert generate() == [1]

# Generated at 2022-06-23 23:41:21.919670
# Unit test for function get_source
def test_get_source():
    def not_important_function(a, b, c: int = 1, *args, **kwargs):
        return a + b + c

    assert get_source(get_source) == 'return getsource(fn).split(\'\\n\')'
    assert get_source(not_important_function) == 'return a + b + c'

# Generated at 2022-06-23 23:41:28.723358
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('A') == '_py_backwards_A_0'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_1'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_2'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_3'
    assert VariablesGenerator.generate('B') == '_py_backwards_B_4'
    assert VariablesGenerator.generate('C') == '_py_backwards_C_5'
    assert VariablesGenerator.generate('D') == '_py_backwards_D_6'
    assert VariablesGenerator.generate('E') == '_py_backwards_E_7'

# Generated at 2022-06-23 23:41:30.926744
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test = VariablesGenerator()
    assert test.generate("_py_backwards_foo_") == "_py_backwards_foo_0"
    assert test.generate("_py_backwards_foo_") == "_py_backwards_foo_1"

# Generated at 2022-06-23 23:41:34.148785
# Unit test for function get_source
def test_get_source():
    # Arrange
    def foo():
        pass

    expected = 'def foo():\n    pass\n'

    # Act & Assert
    assert get_source(foo) == expected



# Generated at 2022-06-23 23:41:37.322280
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'

# Generated at 2022-06-23 23:41:43.731240
# Unit test for function warn
def test_warn():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stderr = captured_output
    try:
        warn('This is a warning text')
        assert captured_output.getvalue() == 'Warning: This is a warning text\n'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:41:49.152956
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        stage = 0
        message = lambda: 'Message {}'.format(stage)
        debug(message)
        stage += 1
        debug(message)
        stage += 1
        settings.debug = False
        debug(message)
        stage += 1
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:41:53.824902
# Unit test for function warn
def test_warn():
    import sys
    sys.stderr = open('warning.txt', 'w')
    warn('it is a test')
    sys.stderr.close()
    sys.stderr = sys.__stderr__
if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-23 23:41:56.079004
# Unit test for function eager
def test_eager():
    @eager
    def f(i: int) -> Iterable[int]:
        for k in range(i):
            yield k

    assert f(10) == list(range(10))

# Generated at 2022-06-23 23:41:58.549784
# Unit test for function debug
def test_debug():
    debug_message = ""

    @debug
    def get_debug_message():
        return debug_message

    debug_message = "foo"
    get_debug_message()



# Generated at 2022-06-23 23:42:02.419001
# Unit test for function debug
def test_debug():
    def fn():
        debug(lambda: 'Foo bar')

    import sys
    import io
    c = io.StringIO()
    sys.stderr = c
    settings.debug = True
    fn()
    assert c.getvalue() == messages.debug('Foo bar\n')
    settings.debug = False
    fn()
    assert c.getvalue() == messages.debug('Foo bar\n')


# Generated at 2022-06-23 23:42:03.623470
# Unit test for function eager
def test_eager():
    assert eager(xrange)(2) == [0, 1]