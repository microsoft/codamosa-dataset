

# Generated at 2022-06-23 23:32:06.735874
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test_generator = VariablesGenerator()
    for i in range(10):
        if i == 0:
            assert test_generator.generate('x') == '_py_backwards_x_0'
        else:
            assert test_generator.generate('x') == '_py_backwards_x_' + str(i)
# Test get_source

# Generated at 2022-06-23 23:32:09.352963
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('foo') == '_py_backwards_foo_0'
    assert generator.generate('foo') == '_py_backwards_foo_1'
    assert generator.generate('bar') == '_py_backwards_bar_2'

# Generated at 2022-06-23 23:32:11.500642
# Unit test for function eager
def test_eager():
    def test(i):
        yield i

    assert eager(test)(1) == [1]

# Generated at 2022-06-23 23:32:15.944002
# Unit test for function eager
def test_eager():

    def with_list():
        return [1, 2, 3]

    def with_generator():
        yield 1
        yield 2
        yield 3
        yield 4

    assert eager(with_list)() == [1, 2, 3]
    assert eager(with_generator)() == [1, 2, 3, 4]

# Generated at 2022-06-23 23:32:18.901424
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('i') == '_py_backwards_i_0'
    assert VariablesGenerator.generate('i') == '_py_backwards_i_1'

# Generated at 2022-06-23 23:32:22.353813
# Unit test for function eager
def test_eager():
    def add_ten(l: List[int]) -> List[int]:
        return [x + 10 for x in l]

    def add_ten_and_return(l: List[int]) -> iter:
        return [x + 10 for x in l]

    assert add_ten == eager(add_ten_and_return)

# Generated at 2022-06-23 23:32:28.169743
# Unit test for function debug

# Generated at 2022-06-23 23:32:34.089851
# Unit test for function debug
def test_debug():
    try:
        # Test when debug is on
        flag = 'on'
        settings.debug = True
        debug(lambda: 'debug is {}'.format(flag))
        assert True
    except:
        assert False

    try:
        # Test when debug is off
        flag = 'off'
        settings.debug = False
        debug(lambda: 'debug is {}'.format(flag))
        assert True
    except:
        assert False

# Generated at 2022-06-23 23:32:36.564256
# Unit test for function debug
def test_debug():
    settings.debug = True
    test_string = 'test'
    def get_message():
        return test_string
    debug(get_message)
    settings.debug = False

# Generated at 2022-06-23 23:32:40.222812
# Unit test for function eager
def test_eager():
    def lazy_function():
        for i in range(2):
            yield i

    assert eager(lazy_function)() == [0, 1]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:32:42.142896
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 23:32:43.518994
# Unit test for function warn
def test_warn():
    warn('test') # it prints normally this string


# Generated at 2022-06-23 23:32:48.803351
# Unit test for function debug
def test_debug():
    import tempfile
    settings.debug = True
    try:
        f = tempfile.NamedTemporaryFile(delete=False, mode='w')
        name = f.name
        try:
            with f, open(name) as f:
                debug(lambda: 'x' * 3)
                assert f.readline().strip() == messages.debug('xxx')
        finally:
            import os
            os.remove(name)
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:32:49.622967
# Unit test for function warn
def test_warn():
    warn("this is a message")



# Generated at 2022-06-23 23:32:57.120936
# Unit test for function warn
def test_warn():
    from .core import replace_function
    from io import StringIO
    import sys

    original_stdout = sys.stderr

    try:
        out = sys.stderr = StringIO()

        warning_message = 'Testing warning message'

        @replace_function('warnings.warn')
        def dummy_warn(message, *args, **kwargs):
            warn(warning_message)

        warnings.warn('Some message', UserWarning)

        assert warning_message in out.getvalue()

        dummy_warn.undo()

        out = sys.stderr = StringIO()

        warnings.warn('Some message', UserWarning)

        assert warning_message not in out.getvalue()

    finally:
        sys.stderr = original_stdout

# Generated at 2022-06-23 23:32:58.081060
# Unit test for function warn
def test_warn():
    warn("Test message")


# Generated at 2022-06-23 23:32:58.768422
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')



# Generated at 2022-06-23 23:33:00.608839
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-23 23:33:01.609885
# Unit test for function get_source
def test_get_source():
    def hello(a: str) -> str:
        return a

    assert get_source(hello) == "return a"

# Generated at 2022-06-23 23:33:04.008003
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        pass

    # Source code contains indentation in the beginning of the lines
    assert get_source(func).startswith('def func')

# Generated at 2022-06-23 23:33:08.753528
# Unit test for function warn
def test_warn():
    from io import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        warn("message")
    finally:
        assert sys.stderr.getvalue() == messages.warn("message") + '\n'
        sys.stderr = stderr



# Generated at 2022-06-23 23:33:11.447102
# Unit test for function eager
def test_eager():
    import unittest

    class EagerTest(unittest.TestCase):
        def test_eager(self):
            def test_func():
                yield 1
                yield 2

            self.assertEqual([1, 2], eager(test_func)())

    test_case = EagerTest()
    test_case.test_eager()

# Generated at 2022-06-23 23:33:14.924565
# Unit test for function warn
def test_warn():
    import contextlib
    import io
    import sys
    with contextlib.redirect_stderr(io.StringIO()) as fake_err:
        warn('message')
    assert 'message' in fake_err.getvalue()
    assert '\n' in fake_err.getvalue()

# Generated at 2022-06-23 23:33:18.684739
# Unit test for function warn
def test_warn():
    sys.stderr = io.StringIO()
    warn("warn")
    assert sys.stderr.getvalue() == '\x1b[31mwarn\x1b[0m\n'


# Generated at 2022-06-23 23:33:22.469271
# Unit test for function warn
def test_warn():
    test_message = 'test message'
    with patch('sys.stderr.write') as write_mock:
        warn(test_message)

    write_mock.assert_called_with(messages.warn(test_message) + '\n')



# Generated at 2022-06-23 23:33:26.594474
# Unit test for function eager
def test_eager():
    import unittest

    class TestEager(unittest.TestCase):
        def test_eager(self):
            def f():
                yield 2
                yield 3
                yield 4

            assert eager(f)() == [2, 3, 4]

    unittest.main()

# Generated at 2022-06-23 23:33:34.081870
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    from ..conf import set_debug

    set_debug(True)
    message = 'Hello, world!'
    with StringIO() as fp:
        sys.stderr, old_stderr = fp, sys.stderr
        debug(lambda: message)
        sys.stderr = old_stderr
        assert fp.getvalue() == messages.debug(message) + '\n'

    with StringIO() as fp:
        sys.stderr, old_stderr = fp, sys.stderr
        set_debug(False)
        debug(lambda: message)
        sys.stderr = old_stderr
        assert fp.getvalue() == ''

# Generated at 2022-06-23 23:33:41.326602
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert [VariablesGenerator.generate(str(i)) for i in range(10)] == ['_py_backwards_0_0', '_py_backwards_1_1', '_py_backwards_2_2', '_py_backwards_3_3', '_py_backwards_4_4', '_py_backwards_5_5', '_py_backwards_6_6', '_py_backwards_7_7', '_py_backwards_8_8', '_py_backwards_9_9']


# Generated at 2022-06-23 23:33:43.906942
# Unit test for function get_source
def test_get_source():
    code = \
    """def f(a: int, b: int) -> int:
        if a > b:
            return a
        return b"""
    assert get_source(f) == code

# Generated at 2022-06-23 23:33:52.733293
# Unit test for function debug
def test_debug():
    class TestException(Exception):
        pass

    debug_message = 'Test debug message'

    try:
        with settings.override('debug', True):
            def stub_warn(message: str) -> None:
                raise TestException(message)

            original_warn = warnings._show_warning
            warnings._show_warning = stub_warn

            debug(lambda: debug_message)
    finally:
        warnings._show_warning = original_warn

    try:
        with settings.override('debug', False):
            def stub_warn(message: str) -> None:
                raise TestException(message)

            original_warn = warnings._show_warning
            warnings._show_warning = stub_warn

            debug(lambda: debug_message)
    finally:
        warnings._show_warning = original_warn

    assert True

# Generated at 2022-06-23 23:33:55.483953
# Unit test for function eager
def test_eager():
    seq = range(10)
    # `list` is a built-in function
    assert eager(list)(seq) == list(seq)
    assert eager(lambda x: x)(seq) == list(seq)

# Generated at 2022-06-23 23:33:57.072684
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
    assert gen() == [1, 2]

# Generated at 2022-06-23 23:33:58.782177
# Unit test for function get_source
def test_get_source():

    def foo(arg):
        return arg

    assert get_source(foo) == 'return arg'

# Generated at 2022-06-23 23:34:01.797674
# Unit test for function warn
def test_warn():
    from ..testing.capture import CaptureOutput

    with CaptureOutput() as captured:
        warn('Test warning')

    assert captured.text == '\033[0;33mTest warning\033[0m\n'



# Generated at 2022-06-23 23:34:08.179882
# Unit test for function debug
def test_debug():
    import unittest
    class DebugTest(unittest.TestCase):
        def test_debug(self) -> None:
            import sys
            import io
            with io.StringIO() as output:
                sys.stderr = output
                debug(lambda: 'Hello, world!')
                output.seek(0)
                self.assertEqual(output.read(), '')
                settings.debug = True
                debug(lambda: 'Hello, world!')
                output.seek(0)
                self.assertEqual(output.read(), 'py-backwards: DEBUG: Hello, world!\n')
                sys.stderr = sys.__stderr__
    unittest.main()

if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:34:13.938893
# Unit test for function debug
def test_debug():
    output = []

    def get_message():
        return "a"

    def _print(*args, **kwargs):
        output.append([args, kwargs])

    settings.debug = True
    sys.stderr.print = _print
    debug(get_message)
    assert output == [
        (("\033[91m\033[1m[a]: \033[0m\033[92ma\033[0m\n",), {})
    ], "output should be [[(, {}])]"

    settings.debug = False
    sys.stderr.write = _print
    debug(get_message)
  

# Generated at 2022-06-23 23:34:15.596159
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 0
        yield 1
        yield 2

    assert f() == [0, 1, 2]

# Generated at 2022-06-23 23:34:19.343134
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as mocked_stderr:
        warn("test")
        assert(mocked_stderr.getvalue() == '\033[93mwarn: test\033[0m\n')



# Generated at 2022-06-23 23:34:20.857408
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

# Generated at 2022-06-23 23:34:24.339576
# Unit test for function debug
def test_debug():
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'test debug')
        assert mock_stderr.write.called
        assert 'DEBUG: test debug\n' == mock_stderr.write.call_args[0][0]

# Generated at 2022-06-23 23:34:25.435468
# Unit test for function warn
def test_warn():
    warn('warning test2')

# Generated at 2022-06-23 23:34:27.171269
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test debug')

# Generated at 2022-06-23 23:34:30.824305
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass
    assert get_source(test_func) == 'def test_func():\n    pass'
    assert get_source(test_func) == test_func.__code__.co_source

# Generated at 2022-06-23 23:34:32.902115
# Unit test for function debug
def test_debug():
    messages.debug_message = '{}'
    settings.debug = False
    debug(lambda: 'Test message')
    settings.debug = True
    debug(lambda: 'Test message')
    assert True

# Generated at 2022-06-23 23:34:35.441198
# Unit test for function warn
def test_warn():
    messages.warn = lambda msg: 'warn: {}'.format(msg)
    warn('hello')



# Generated at 2022-06-23 23:34:37.794666
# Unit test for function warn
def test_warn():
    import sys
    stderr = sys.stderr
    sys.stderr = sys.stdout
    try:
        warn('test message')
    finally:
        sys.stderr = stderr



# Generated at 2022-06-23 23:34:39.388424
# Unit test for function eager
def test_eager():
    @eager
    def function():
        yield 1
        yield 2
        yield 3
    assert function() == [1, 2, 3]

# Generated at 2022-06-23 23:34:42.996179
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator();
    v2 = VariablesGenerator();
    assert v1.generate('variable') != v2.generate('variable')
    assert v1.generate('variable2') != v2.generate('variable2')

# Generated at 2022-06-23 23:34:47.322653
# Unit test for function debug
def test_debug():
    def message_gen():
        return 'I am a debug message'

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(message_gen=message_gen)

    assert 'I am a debug message' in mock_stderr.getvalue()

# Generated at 2022-06-23 23:34:51.056793
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class TestVariablesGenerator(VariablesGenerator):
        pass

    assert TestVariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert TestVariablesGenerator.generate('a') == '_py_backwards_a_1'

# Generated at 2022-06-23 23:34:52.618545
# Unit test for function eager
def test_eager():
    assert eager(lambda: iter([1, 2, 3]))() == [1, 2, 3]

# Generated at 2022-06-23 23:34:56.413534
# Unit test for function debug
def test_debug():
    import sys
    from .. import settings
    from . import debug

    settings.debug = True
    result = []

    def output(msg: str) -> None:
        result.append(msg)

    sys.stderr = sys.__stderr__ = output

    debug(lambda: 'message')

    assert result == [messages.debug('message')]

# Generated at 2022-06-23 23:35:00.908253
# Unit test for function warn
def test_warn():
    import sys
    import io
    message = 'Hello i am fake message'
    out = io.StringIO()
    sys.stderr = out
    warn(message)
    sys.stderr = sys.__stderr__
    assert out.getvalue() == messages.warn(message) + '\n'

# Generated at 2022-06-23 23:35:04.638716
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    source_lines = settings.source_template.format(
        source=get_source(foo)
    ).split('\n')
    assert source_lines[0] == ''
    assert source_lines[-1] == ''



# Generated at 2022-06-23 23:35:05.738076
# Unit test for function warn
def test_warn():
    assert warn is not None



# Generated at 2022-06-23 23:35:10.294430
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    def g():
        return f()

    def h(a, b, c, d, e=1, f=2, *, g=3, h=4, **kwargs):
        pass

    assert get_source(f) == 'pass'
    assert get_source(g) == 'return f()'
    assert get_source(h) == 'pass'

# Generated at 2022-06-23 23:35:12.968049
# Unit test for function warn
def test_warn():
    import io
    messages = io.StringIO()
    try:
        sys.stderr = messages
        warn('test')
        assert messages.getvalue() == messages.getvalue()
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:35:14.077808
# Unit test for function warn
def test_warn():
#     warn('This is a warning')
    pass


# Generated at 2022-06-23 23:35:19.120840
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'


# Generated at 2022-06-23 23:35:22.613847
# Unit test for function eager
def test_eager():
    @eager
    def return_range(x: int) -> Iterable[int]:
        yield from range(x)

    assert return_range(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:35:27.177133
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-23 23:35:28.159409
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1

    assert foo() == [1]

# Generated at 2022-06-23 23:35:30.690822
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('a') == '_py_backwards_a_0'
    assert gen.generate('a') == '_py_backwards_a_1'
    assert gen.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-23 23:35:34.883777
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class A:
        pass

    assert VariablesGenerator.generate('a') == "_py_backwards_a_0"
    assert VariablesGenerator.generate('a') == "_py_backwards_a_1"
    assert VariablesGenerator.generate('a') == "_py_backwards_a_2"



# Generated at 2022-06-23 23:35:40.067770
# Unit test for function warn
def test_warn():
    import io
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = False

    f = io.StringIO()
    with redirect_stderr(f):
        warn('warn message')

    f.seek(0)
    result = f.read()
    assert result == '\x1b[1m\x1b[33mwarn message\x1b[m\n'

# Generated at 2022-06-23 23:35:45.525298
# Unit test for function warn
def test_warn():
    from io import StringIO
    from sys import stderr
    from contextlib import redirect_stderr

    warn('test')

    with redirect_stderr(StringIO()) as sys.stderr:
        warn('test')

    with open(messages.WARN_FILE, 'r') as f:
        assert f.read() == 'test\n'

# Generated at 2022-06-23 23:35:49.440400
# Unit test for function debug
def test_debug():
    from .conf import settings
    settings.debug = False
    debug(lambda: 'foo')
    settings.debug = True
    assert debug(lambda: 'foo') is None
    assert debug(lambda: 'bar') is None
    settings.debug = False


# Generated at 2022-06-23 23:35:53.626923
# Unit test for function debug
def test_debug():
    global counter
    counter = 0
    def get_message():
        global counter
        counter += 1
        return "Test message {}".format(counter)
    debug(get_message)
    assert counter == 1
    settings.debug = True
    debug(get_message)
    assert counter == 2
    settings.debug = False

# Generated at 2022-06-23 23:35:56.186001
# Unit test for function eager
def test_eager():
    @eager
    def values():
        yield 1
        yield 2
        yield 3

    assert values() == [1, 2, 3]

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:35:58.854883
# Unit test for function get_source
def test_get_source():
    def fn(*args, **kwargs):
        print(args)
        print(kwargs)
    assert get_source(fn) == "print(args)\nprint(kwargs)", \
        "Function get_source does not work properly."


# Generated at 2022-06-23 23:36:00.852704
# Unit test for function get_source
def test_get_source():
    def test_fn(test_arg):
        pass

    assert get_source(test_fn) == 'def test_fn(test_arg):\n    pass'



# Generated at 2022-06-23 23:36:07.486567
# Unit test for function debug
def test_debug():
    settings.debug = True

    def run():
        settings.debug = False
        print("Debug output:")
        debug(lambda: "message")
        print("Expected output:")
        print("---\n{}---\n".format(messages.debug("message")))

    settings.debug = False
    print("disabled debug")
    run()
    settings.debug = True
    print("enabled debug")
    run()

# Generated at 2022-06-23 23:36:10.715527
# Unit test for function warn
def test_warn():
    orig_stderr = sys.stderr
    sys.stderr = StringIO()
    warn('test warn')
    assert 'test warn' in sys.stderr.getvalue()
    sys.stderr = orig_stderr

# Generated at 2022-06-23 23:36:16.359233
# Unit test for function debug
def test_debug():
    assert callable(debug)

    _ = []

    def get_message():
        _.append('1')
        return '2'

    with pytest.raises(AssertionError):
        debug('')

    debug(get_message)
    assert _ == []

    settings.debug = True

    debug(get_message)
    assert _ == ['1']

    settings.debug = False

# Generated at 2022-06-23 23:36:18.879781
# Unit test for function eager
def test_eager():
    @eager
    def get_generator():
        yield 1
        yield 2
        yield 3

    assert get_generator() == [1, 2, 3]



# Generated at 2022-06-23 23:36:21.625461
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)
    assert source.startswith('def test_get_source():')
    assert source.endswith('    assert source.startswith(\'def test_get_source():\')')

# Generated at 2022-06-23 23:36:27.682715
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == 'def test_get_source():\n    assert get_source(test_get_source) == \'def test_get_source():\\n    assert get_source(test_get_source) == \\\'def test_get_source():\\\\n    assert get_source(test_get_source) == \\\'def test_get_source():\\\\\\\'\''

# Generated at 2022-06-23 23:36:29.519200
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        pass
    assert get_source(fn) == 'def fn(a, b):\n    pass'

# Generated at 2022-06-23 23:36:37.042601
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    def my_func():
        debug(lambda: 'Hello')

    with patch('sys.stderr', StringIO()) as err:
        settings.debug = True
        my_func()
    assert 'Hello' in err.getvalue()

    with patch('sys.stderr', StringIO()) as err:
        settings.debug = False
        my_func()
    assert 'Hello' not in err.getvalue()


# Generated at 2022-06-23 23:36:41.567621
# Unit test for function eager
def test_eager():
    def get_list(*args):
        return range(*args)

    func = eager(get_list)

    assert isinstance(func(0, 3), list)
    assert len(func(0, 3)) == 3
    assert isinstance(func(1, 3), list)
    assert len(func(1, 3)) == 2

# Generated at 2022-06-23 23:36:42.878309
# Unit test for function warn
def test_warn():
    assert warn.__name__ == 'warn'
    warn('msg')

# Generated at 2022-06-23 23:36:51.243262
# Unit test for function debug
def test_debug():
    from .process import set_debug
    from io import StringIO
    from contextlib import redirect_stderr
    set_debug(True)
    fp = StringIO()
    with redirect_stderr(fp):
        debug(lambda: 'Hello, World!')
    assert fp.getvalue() == '\x1b[35m[DEBUG] Hello, World!\x1b[0m\n'
    set_debug(False)
    fp = StringIO()
    with redirect_stderr(fp):
        debug(lambda: 'Hello, World!')
    assert fp.getvalue() == ''



# Generated at 2022-06-23 23:36:54.786050
# Unit test for function warn
def test_warn():
    # GIVEN a message to display
    message = "I'm a message"

    # WHEN a warning is displayed
    with patch("builtins.print") as mocked_print:
        warn(message)

    # THEN the print statement has been called with the right message
    mocked_print.assert_called_once_with("\033[33m{}\033[0m".format(message), file=sys.stderr)


# Generated at 2022-06-23 23:36:56.966186
# Unit test for function eager
def test_eager():
    from collections import Iterable, Sequence
    @eager
    def foo() -> Iterable[Any]:
        yield 1
        yield 2
        yield 3
    assert isinstance(foo(), Sequence)

# Generated at 2022-06-23 23:36:58.990005
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')

# Generated at 2022-06-23 23:37:04.650496
# Unit test for function debug
def test_debug():
    import sys
    import tempfile
    settings.debug = True
    f = tempfile.TemporaryFile(mode='w+')
    save = sys.stderr
    sys.stderr = f
    debug(lambda: 'test_debug')
    sys.stderr = save
    f.seek(0)
    assert 'test_debug' in f.read()

# Generated at 2022-06-23 23:37:13.686383
# Unit test for function get_source
def test_get_source():

    @backwards(n=2, fill=0)
    def f(a, b, c=1, *args, **kwargs):
        pass

    def f2(a, b, c=1, *args, **kwargs):
        pass

    def f3(a, b, c=1, *args, **kwargs):
        pass

    assert get_source(f) == "def f(a, b, c=1, *args, **kwargs):\n    pass"
    assert get_source(f2) == "def f2(a, b, c=1, *args, **kwargs):\n    pass"
    assert get_source(f3) == "def f3(a, b, c=1, *args, **kwargs):\n    pass"



# Generated at 2022-06-23 23:37:14.517829
# Unit test for function warn
def test_warn():
    warn("test_warn")


# Generated at 2022-06-23 23:37:22.976243
# Unit test for function debug
def test_debug():
    from io import StringIO
    from ..conf import settings
    from contextlib import redirect_stderr

    def get_message_mock() -> str:
        return 'Mock debug message'

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = False
        debug(get_message_mock)
        assert stderr.getvalue() == ''
        settings.debug = True
        debug(get_message_mock)
        assert stderr.getvalue() == messages.debug(get_message_mock()) + '\n'


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:37:29.107722
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('0') == '_py_backwards_0_0'

    gen_1 = VariablesGenerator()
    gen_2 = VariablesGenerator()

    assert gen_1.generate('0') == gen_2.generate('0')
    assert gen_1.generate('1') == '_py_backwards_1_1'
    assert gen_2.generate('1') == '_py_backwards_1_1'



# Generated at 2022-06-23 23:37:30.652482
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'pass'



# Generated at 2022-06-23 23:37:33.236559
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
    assert test_function() == [1,2]


if __name__ == "__main__":
    test_eager()

# Generated at 2022-06-23 23:37:35.450749
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert(vg.generate("_a") == "_py_backwards__a_0")

# Generated at 2022-06-23 23:37:38.482163
# Unit test for function eager
def test_eager():
    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen(10) == list(range(10))

# Generated at 2022-06-23 23:37:41.215638
# Unit test for function warn
def test_warn():
    try:
        sys.stderr = sys.stdout
        warn("This is a warning")
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-23 23:37:42.211596
# Unit test for function warn
def test_warn():
    warn("test warn")


# Generated at 2022-06-23 23:37:44.195613
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test_debug')
    finally:
        settings.debug = False
test_debug()

# Generated at 2022-06-23 23:37:47.797231
# Unit test for function eager
def test_eager():
    # Empty iterable
    assert eager(lambda: iter([]))() == []

    # Iterable with one element
    assert eager(lambda: iter([1]))() == [1]

    # Iterable with multiple elements
    assert eager(lambda: iter([1, 2, 3]))() == [1, 2, 3]



# Generated at 2022-06-23 23:37:53.053351
# Unit test for function debug
def test_debug():
    mock_settings = Mock(spec_set=settings)
    mock_settings.debug = True
    with patch('py_backwards.utils.settings', mock_settings):
        message = 'foo'
        with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
            debug(lambda: message)
            assert message in mock_stderr.getvalue()
    mock_settings.debug = False
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        debug(lambda: message)
        assert message not in mock_stderr.getvalue()



# Generated at 2022-06-23 23:37:59.150921
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import itertools
    for v in ['x', 'dx', 'ddx', 'dddx']:
        for i in range(5):
            var_gen = VariablesGenerator()
            eq_(var_gen.generate(v), f"_py_backwards_{v}_{i}")
            assert next(reversed(itertools.takewhile(v.__ne__,
                                                     (var_gen.generate(v)
                                                      for _ in itertools.count())))) == f"_py_backwards_{v}_{i}"


# Generated at 2022-06-23 23:38:02.701714
# Unit test for function warn
def test_warn():
    capture = io.StringIO()
    sys.stderr = capture

    warn('test')

    sys.stderr = sys.__stderr__
    assert capture.getvalue() == messages.warn('test\n')



# Generated at 2022-06-23 23:38:06.032038
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    i = 0
    gen = VariablesGenerator()
    while i < 10:
        assert VariablesGenerator.generate("a") == "_py_backwards_a_{}".format(i)
        i += 1




# Generated at 2022-06-23 23:38:08.594607
# Unit test for function eager
def test_eager():
    @eager
    def test(a):
        for i in range(a):
            yield i
    assert test(2) == [0, 1]



# Generated at 2022-06-23 23:38:12.660687
# Unit test for function warn
def test_warn():
    import sys
    import io
    try:
        capturedOutput = io.StringIO()
        sys.stderr = capturedOutput
        nested_warn()
        assert "Nested warn" in capturedOutput.getvalue()
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:38:14.650514
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2

    assert eager(foo)() == [1, 2]

# Generated at 2022-06-23 23:38:19.321804
# Unit test for function debug
def test_debug():
    from .mock import Mock

    with Mock(settings, debug=True) as settings:
        debug(lambda: 'x')
        assert settings.write_stderr.called
    with Mock(settings, debug=False) as settings:
        debug(lambda: 'x')
        assert not settings.write_stderr.called



# Generated at 2022-06-23 23:38:23.619109
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-23 23:38:29.375899
# Unit test for function debug
def test_debug():
    def get_message():
        return "test message"

    stdout = io.StringIO()
    sys.stderr = stdout
    debug(get_message)
    assert stdout.getvalue() == ''

    settings.debug = True
    stdout = io.StringIO()
    sys.stderr = stdout
    debug(get_message)
    assert stdout.getvalue() != ''

    settings.debug = False

# Generated at 2022-06-23 23:38:29.955631
# Unit test for function debug
def test_debug():
    pass

# Generated at 2022-06-23 23:38:34.725323
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'
test_VariablesGenerator()

# Generated at 2022-06-23 23:38:37.699692
# Unit test for function warn
def test_warn():
    from io import StringIO

    stderr = sys.stderr
    sys.stderr = StringIO()

    try:
        warn('hello world')
        assert sys.stderr.getvalue() == 'backwards: hello world\n'
    finally:
        sys.stderr = stderr


# Generated at 2022-06-23 23:38:38.537350
# Unit test for function warn
def test_warn():
    assert warn == print  # TODO: implement

# Generated at 2022-06-23 23:38:40.759195
# Unit test for function get_source
def test_get_source():
    def foo():
        return 42

    assert get_source(foo) == 'return 42'



# Generated at 2022-06-23 23:38:43.723749
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    foo_eager = eager(foo)

    assert foo_eager() == [1, 2, 3]

# Generated at 2022-06-23 23:38:46.114980
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'debug message')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:38:48.072664
# Unit test for function get_source
def test_get_source():

    def foo():
        print('foo')

    def bar():
        print('bar')

    assert \
        """print('foo')""" == get_source(foo)

    assert \
        """print('bar')""" == get_source(bar)

# Generated at 2022-06-23 23:38:51.997973
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'

# Generated at 2022-06-23 23:38:53.999942
# Unit test for function get_source
def test_get_source():
    def get_source_function():
        """Example docstring."""
        return 1

    assert get_source(get_source_function) == '"""Example docstring."""\nreturn 1'

# Generated at 2022-06-23 23:38:56.474936
# Unit test for function warn
def test_warn():
    debug_messages = []
    def _warn(message):
        debug_messages.append(message)
        warn(message)
    _warn('abc')
    assert debug_messages[0] == 'Warning: abc'


# Generated at 2022-06-23 23:38:58.472309
# Unit test for function get_source
def test_get_source():
    def fn(): pass
    expected = 'def fn(): pass'
    assert get_source(fn) == expected
    assert get_source(fn) == expected  # Test caching



# Generated at 2022-06-23 23:39:02.780489
# Unit test for function warn
def test_warn():
    import contextlib
    from io import StringIO
    output = StringIO()
    with contextlib.redirect_stdout(output):
        warn("message")
    assert output.getvalue().strip() == '\033[1m\033[91mwarning\033[m\033[m: message'



# Generated at 2022-06-23 23:39:12.411575
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest import TestCase
    from ..messages import warn as warn_message

    class WarnTest(TestCase):
        @classmethod
        def setUpClass(cls):
            cls.stderr = sys.stderr
            sys.stderr = StringIO()

        @classmethod
        def tearDownClass(cls):
            sys.stderr = cls.stderr

        def test_should_print_warning_message(self):
            message = 'test'
            warn(message)
            self.assertEqual(warn_message(message) + '\n', sys.stderr.getvalue())

# Generated at 2022-06-23 23:39:21.234396
# Unit test for function eager
def test_eager():
    import time
    import random

    def sleep_n_seconds(n):
        time.sleep(n)
        return n

    numbers = [random.random() for _ in range(100)]

    shuffled_numbers = sorted(numbers, reverse=True)
    assert shuffled_numbers == sorted(shuffled_numbers, reverse=True)
    assert numbers != shuffled_numbers

    parallel_numbers = [sleep_n_seconds(x) for x in numbers]
    assert numbers == parallel_numbers
    assert numbers == eager(sleep_n_seconds)(*numbers)
    assert numbers != eager(sleep_n_seconds)(*shuffled_numbers)



# Generated at 2022-06-23 23:39:25.370557
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables_generator = VariablesGenerator()
    assert variables_generator.generate('test') == '_py_backwards_test_0'
    assert variables_generator.generate('test') == '_py_backwards_test_1'



# Generated at 2022-06-23 23:39:29.710927
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('b')
    assert VariablesGenerator.generate('b') != VariablesGenerator.generate('a')


# Generated at 2022-06-23 23:39:34.801800
# Unit test for function get_source
def test_get_source():
    def source_function(a, b):
        return a * b
    source_lines = ['\n',
                    'def source_function(a, b):\n',
                    '    return a * b\n',
                    '\n']
    assert (source_lines == get_source(source_function).split('\n'))

# Generated at 2022-06-23 23:39:39.015534
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('_py_backwards_') != VariablesGenerator.generate('_py_backwards_')
    assert VariablesGenerator.generate('_py_backwards_') == VariablesGenerator.generate('_py_backwards_')

# Generated at 2022-06-23 23:39:40.403292
# Unit test for function eager
def test_eager():
    @eager
    def test(n):
        for i in range(n):
            yield i

    assert test(10) == list(range(10))

# Generated at 2022-06-23 23:39:43.593092
# Unit test for function eager
def test_eager():
    import pytest
    import sys
    import os

    def test(x=0):
        return range(x)

    assert eager(test)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 23:39:51.764321
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    import pytest
    from ..config.settings import Settings
    from .messages import MESSAGES

    def get_test_warn_text(prefix: str) -> str:
        return MESSAGES[settings.language][prefix]

    output = StringIO()
    sys.stderr = output
    settings.debug = False
    warn("test warn message")
    captured = output.getvalue()
    assert captured == get_test_warn_text("warn") + "test warn message\n"
    output.close()



# Generated at 2022-06-23 23:39:56.534836
# Unit test for function warn
def test_warn():
    from unittest import mock
    with mock.patch('sys.stderr', new=mock.Mock(spec=sys.stderr)) as mock_stderr:
        warn('spam')
    mock_stderr.write.assert_called_once_with(messages.warn('spam') + '\n')



# Generated at 2022-06-23 23:40:00.827777
# Unit test for function warn
def test_warn():
    # Given
    message = 'test message'
    output = six.StringIO()

    # When
    with mock.patch('sys.stderr', output):
        warn(message)

    # Then
    assert output.getvalue().strip() == messages.warn(message)


# Generated at 2022-06-23 23:40:05.066163
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == ('    source_lines = getsource(fn).split(\'\\n\')\n'
                                      '    padding = len(re.findall(r\'^(\\s*)\', '
                                      'source_lines[0])[0])\n'
                                      '    return \'\\n\'.join(line[padding:] '
                                      'for line in source_lines)')

# Generated at 2022-06-23 23:40:07.910554
# Unit test for function eager
def test_eager():
    @eager
    def iterate():
        for i in range(10):
            yield i

    assert iterate() == list(range(10))



# Generated at 2022-06-23 23:40:13.138493
# Unit test for function warn
def test_warn():
    with patch.object(sys.stderr, 'write') as mock_stderr:
        warn('message')
        subprocess.check_output(['git', 'status'])
        print(mock_stderr)
        mock_stderr.assert_called_with(messages.warn('message'))


# Generated at 2022-06-23 23:40:16.059960
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'



# Generated at 2022-06-23 23:40:21.565109
# Unit test for function get_source
def test_get_source():
    def b():
        pass
    assert get_source(b) == 'pass'

    class C:
        def d():
            pass
    assert get_source(C.d) == 'def d():\n    pass'

    @wraps(b)
    def e():
        pass
    assert get_source(e) == '@wraps(b)\ndef e():\n    pass'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 23:40:25.452785
# Unit test for function warn
def test_warn():
    s = ''
    def inject_stdout(msg: str) -> None:
        nonlocal s
        s += msg
    sys.stderr.write = inject_stdout
    warn('test')
    assert s == messages.warn('test') + '\n'


# Generated at 2022-06-23 23:40:30.400486
# Unit test for function debug
def test_debug():
    assert not settings.debug
    test_debug.called = False
    def _(message):
        test_debug.called = True
    with patch('sys.stderr', _):
        debug(lambda: 'hi')
        assert not test_debug.called
        settings.debug = True
        debug(lambda: 'hi')
        assert test_debug.called
    settings.debug = False

# Generated at 2022-06-23 23:40:38.038837
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    def check(expected, actual):
        assert expected == actual, 'wrong result generated for {}'.format(expected)
    check('_py_backwards_a_0', VariablesGenerator.generate('a'))
    check('_py_backwards_a_1', VariablesGenerator.generate('a'))
    check('_py_backwards_b_2', VariablesGenerator.generate('b'))
    check('_py_backwards_a_3', VariablesGenerator.generate('a'))
    check('_py_backwards_b_4', VariablesGenerator.generate('b'))

# Unit Test for function get_source

# Generated at 2022-06-23 23:40:40.750236
# Unit test for function get_source
def test_get_source():
    def my_function():
        def another_function():
            pass

    expected = 'def another_function():\n' \
               '    pass'
    assert get_source(my_function) == expected

# Generated at 2022-06-23 23:40:42.682012
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first = VariablesGenerator.generate('myvar')
    second = VariablesGenerator.generate('myvar')
    assert first != second

# Generated at 2022-06-23 23:40:46.441634
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate("x")
    print(a)
    b = VariablesGenerator.generate("x")
    print(b)
    assert a != b


# Generated at 2022-06-23 23:40:49.658971
# Unit test for function warn
def test_warn():
    test_message = 'test'
    warn(test_message)
    assert sys.stderr.getvalue() == messages.warn(test_message) + '\n'



# Generated at 2022-06-23 23:40:52.519984
# Unit test for function warn
def test_warn():
    stub_stdout(lambda: warn('warning message'))
    assert len(stdout) == 1
    assert stdout[0] == messages.warn('warning message')



# Generated at 2022-06-23 23:40:56.052545
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('My msg')
    assert sys.stderr.getvalue() == messages.warn('My msg')
    sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:40:59.303721
# Unit test for function warn
def test_warn():
    with mock.patch('sys.stderr', new_callable=io.StringIO) as stderr:
        warn('Hello, world!')
        assert stderr.getvalue() == messages.warn('Hello, world!') + '\n'

# Generated at 2022-06-23 23:41:01.065723
# Unit test for function eager
def test_eager():
    f = eager(lambda: range(5))
    assert f() == list(range(5))

# Generated at 2022-06-23 23:41:05.913633
# Unit test for function debug
def test_debug():

    debug_message = 'This is a debug message'

    def get_message():
        return debug_message

    # without debug()
    debug(get_message)

    with settings.debug_enabled():
        # with debug()
        debug(get_message)
        assert get_message() == debug_message

# Generated at 2022-06-23 23:41:06.962407
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-23 23:41:08.619877
# Unit test for function get_source
def test_get_source():
    def foo(x):
        return x * 2

    assert get_source(foo) == 'return x * 2'

# Generated at 2022-06-23 23:41:09.506393
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-23 23:41:14.519638
# Unit test for function eager
def test_eager():
    def foo(n) -> List[int]:
        return list(range(int(n)))

    assert foo.__name__ == 'foo'
    assert foo.__doc__ == None
    assert foo(1) == [0]

    foobar = eager(foo)
    assert foobar.__name__ == 'foo'
    assert foobar.__doc__ == None
    assert foobar(1) == [0]


# Generated at 2022-06-23 23:41:18.861060
# Unit test for function warn
def test_warn():
    import sys
    import StringIO
    stdout = sys.stderr
    sys.stderr = StringIO.StringIO()
    warn('test_message')
    assert sys.stderr.getvalue() == '\033[33m[WARNING]\033[0m test_message\n'
    sys.stderr = stdout

# Generated at 2022-06-23 23:41:21.111144
# Unit test for function get_source
def test_get_source():
    def function(a, b, c):
        return a+b+c
    assert get_source(function) == 'return a+b+c'


# Generated at 2022-06-23 23:41:24.265140
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    def bar():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]
    assert list(bar()) == [1, 2, 3]



# Generated at 2022-06-23 23:41:29.189811
# Unit test for function get_source
def test_get_source():
    def func():
        """
        This function is sample
        """
        if True:
            return False
        else:
            return True
    assert get_source(func) == \
        'def func():\n' +\
        '    """\n' +\
        '    This function is sample\n' +\
        '    """\n' +\
        '    if True:\n' +\
        '        return False\n' +\
        '    else:\n' +\
        '        return True'



# Generated at 2022-06-23 23:41:31.640426
# Unit test for function debug
def test_debug():
    settings.debug = True

    message = 'Test debug message'
    captured = StringIO()
    sys.stderr = captured

    debug(lambda: message)
    sys.stderr = sys.__stderr__

    settings.debug = False

    assert captured.getvalue() == messages.debug(message) + '\n'



# Generated at 2022-06-23 23:41:36.661639
# Unit test for function get_source
def test_get_source():
    # the code is indented on purpose
    assert get_source(test_get_source) == (
        '@wraps(fn)\n'
        'def wrapped(*args: Any, **kwargs: Any) -> T:\n'
        '    return fn(*args, **kwargs)\n'
        '\n'
        'return wrapped'
    )

# Generated at 2022-06-23 23:41:45.839128
# Unit test for function eager
def test_eager():
    def fibonacci(n: int) -> Iterable[int]:
        a, b = 0, 1
        for _ in range(n):
            yield a
            a, b = b, a + b

    assert eager(fibonacci)(10) == fibonacci(10)

    @eager
    def even_numbers(n: int) -> Iterable[int]:
        for i in range(n):
            if i % 2 == 0:
                yield i

    assert even_numbers(10) == [0, 2, 4, 6, 8]



# Generated at 2022-06-23 23:41:49.340983
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'



# Generated at 2022-06-23 23:41:54.842156
# Unit test for function debug
def test_debug():
    with unittest.mock.patch.object(messages, 'debug') as mock_method:
        mock_method.return_value = 'test'
        for debug_enabled in True, False:
            settings.debug = debug_enabled
            debug(lambda: 'message')
            assert mock_method.call_count == (1 * debug_enabled)
            mock_method.reset_mock()

# Generated at 2022-06-23 23:41:55.741963
# Unit test for function warn
def test_warn():
    print("test_warn")
    warn("message")



# Generated at 2022-06-23 23:41:57.212989
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Testing constructor of class VariablesGenerator
    _c = VariablesGenerator()
    assert _c is not None

# Generated at 2022-06-23 23:42:01.421843
# Unit test for function get_source
def test_get_source():
    def test_func(a, b, c=4, d=5, e=6, f=7):
        return a + b + c + d

    source = get_source(test_func)

    assert source == 'def test_func(a, b, c=4, d=5, e=6, f=7):\n' \
                     '    return a + b + c + d\n'



# Generated at 2022-06-23 23:42:05.068705
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    x = VariablesGenerator.generate('a')
    y = VariablesGenerator.generate('a')
    z = VariablesGenerator.generate('b')
    assert(x != y)
    assert(x != z)

if __name__ == '__main__':
    test_VariablesGenerator()