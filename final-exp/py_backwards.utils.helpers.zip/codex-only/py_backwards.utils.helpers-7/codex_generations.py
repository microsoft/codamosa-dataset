

# Generated at 2022-06-23 23:31:57.746411
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'pass'

# Generated at 2022-06-23 23:32:01.286441
# Unit test for function warn
def test_warn():
    result = StringIO()
    sys.stderr = result
    warn('warn message')
    sys.stderr = sys.__stderr__
    result.seek(0)
    assert result.read() == ' ⚠  warn message\n'


# Generated at 2022-06-23 23:32:02.985277
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
    assert generator() == [1]

# Generated at 2022-06-23 23:32:04.746174
# Unit test for function get_source
def test_get_source():
    def index(x):
        return 0

    assert get_source(index) == 'def index(x):\n    return 0'

# Generated at 2022-06-23 23:32:07.740670
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-23 23:32:17.923148
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg0 = VariablesGenerator()
    vg1 = VariablesGenerator()
    vg2 = VariablesGenerator()
    assert vg0.generate('foo') != vg2.generate('foo')
    assert vg0.generate('foo') != vg1.generate('foo')
    assert vg1.generate('foo') != vg2.generate('foo')
    assert vg0.generate('bar') != vg1.generate('bar')
    assert vg0.generate('bar') != vg2.generate('bar')
    assert vg1.generate('bar') != vg2.generate('bar')
    assert vg0.generate('foo') != vg0.generate('bar')

# Generated at 2022-06-23 23:32:18.465402
# Unit test for function warn
def test_warn():
    warn("warn")

# Generated at 2022-06-23 23:32:19.419506
# Unit test for function warn
def test_warn():
    assert settings.enable_warnings is True

# Generated at 2022-06-23 23:32:21.892671
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') != '_py_backwards_a_0'


# Generated at 2022-06-23 23:32:26.192762
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == 'def get_source(fn: Callable[..., Any]) -> str:\n    """Returns source code of the function."""\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)'

# Generated at 2022-06-23 23:32:29.234692
# Unit test for function warn
def test_warn():
    from . import capture
    lines = list(capture.stdout(warn, 'Warning message'))
    assert lines[0] == messages.warn('Warning message') + '\n'

# Generated at 2022-06-23 23:32:36.090695
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .test_utils import patch_stdout, test_settings

    debug_message = 'debug'

    with patch_stdout() as stdout, test_settings(debug=True):
        debug(lambda: debug_message)
        assert stdout.getvalue() == messages.debug(debug_message) + '\n'

    with patch_stdout() as stdout, test_settings(debug=False):
        debug(lambda: debug_message)
        assert stdout.getvalue() == ''

# Generated at 2022-06-23 23:32:38.647267
# Unit test for function eager
def test_eager():

    @eager
    def get_one_two_three():
        yield 1
        yield 2
        yield 3

    print(get_one_two_three())


# Generated at 2022-06-23 23:32:41.868519
# Unit test for function eager
def test_eager():
    def f() -> Iterable[int]:
        for i in range(5):
            yield i
    assert eager(f)() == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 23:32:44.119081
# Unit test for function eager
def test_eager():
    def generator():
        yield 1
        yield 2
    assert eager(generator)() == [1, 2]


# Generated at 2022-06-23 23:32:45.867583
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2

    assert eager(test)() == [1, 2]

# Generated at 2022-06-23 23:32:52.360726
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        print_calls = []
        print_calls.append(lambda s: print(s, file=sys.stderr))
        print_calls.append(lambda s: print(s, file=sys.stdout))

        for print_call in print_calls:
            with patch('sys.stderr.write', print_call):
                debug(lambda: 'message')

            assert print_call.called_once_with(messages.debug('message'))
            print_call.reset_mock()
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:32:54.832867
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'


# Generated at 2022-06-23 23:32:57.791753
# Unit test for function eager
def test_eager():
    assert eager(list)(range(10)) == list(range(10))
    assert eager(x for x in range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:33:01.457944
# Unit test for function warn
def test_warn():
    from io import StringIO
    from sys import stderr
    buffer = StringIO()
    old_stderr, stderr = stderr, buffer
    try:
        warn("Hello world")
        assert buffer.getvalue().strip() == "Warning: Hello world."
    finally:
        stderr = old_stderr

# Generated at 2022-06-23 23:33:03.374515
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(3):
            yield i

    assert foo() == [0, 1, 2], "eager failed"

# Generated at 2022-06-23 23:33:04.910209
# Unit test for function warn
def test_warn():
    import sys
    warn('Test warning')
    assert 'Test warning' in sys.stderr.getvalue()


# Generated at 2022-06-23 23:33:11.196270
# Unit test for function eager
def test_eager():
    from pytest import raises
    from collections import Iterable

    @eager
    def fn():
        yield 1
        raise ValueError()

    assert fn() == [1]
    with raises(ValueError) as e:
        fn()
    assert isinstance(e.value, ValueError)

    @eager
    def fn():
        for num in range(5):
            yield num
    assert fn() == list(range(5))

# Generated at 2022-06-23 23:33:16.647114
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('') == '_py_backwards__0'
    assert VariablesGenerator._counter == 1
    assert VariablesGenerator.generate('') == '_py_backwards__1'
    assert VariablesGenerator._counter == 2
    assert VariablesGenerator.generate('') == '_py_backwards__2'
    assert VariablesGenerator._counter == 3

# Generated at 2022-06-23 23:33:20.336263
# Unit test for function warn
def test_warn():
    pass
    # with patch('sys.stderr', new_callable=StringIO) as stderr:
    #     warn('test')
    #     assert_equal(stderr.getvalue(), messages.warn('test') + '\n')



# Generated at 2022-06-23 23:33:22.238342
# Unit test for function get_source
def test_get_source():
    from tests import utils
    source = get_source(utils.simple_function)

# Generated at 2022-06-23 23:33:27.742143
# Unit test for function debug
def test_debug():
    class Message:
        def __init__(self):
            self.count = 0

        def __call__(self):
            self.count += 1
            return 'foo_{}'.format(self.count)

    get_message = Message()
    debug(get_message)
    assert get_message.count == 1

    settings.debug = False
    debug(get_message)
    assert get_message.count == 1

# Generated at 2022-06-23 23:33:32.663532
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys

    # Capturing stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    # Check the function warn
    warn('warn')

    # Restore stdout
    sys.stdout = old_stdout
    #mystdout.close() # Do nothing

    # Assertions
    assert mystdout.getvalue() == '\x1b[33m[WARNING] warn\n\x1b[0m'


# Generated at 2022-06-23 23:33:35.917326
# Unit test for function eager
def test_eager():
    import pytest

    @eager
    def foo() -> Iterable[int]:
        for i in range(1, 4):
            yield i
    assert foo() == [1, 2, 3]
    with pytest.raises(AssertionError):
        assert foo() == [1, 2, 4]

# Generated at 2022-06-23 23:33:41.654793
# Unit test for function warn
def test_warn():
    import sys
    temp_stderr = sys.stderr
    sys.stderr = open('warn_test.txt', 'w')
    try:
        warn("TEST_WARN")
    finally:
        sys.stderr = temp_stderr
    with open('warn_test.txt', 'r') as f:
        assert f.read() == messages.warn("TEST_WARN") + '\n'



# Generated at 2022-06-23 23:33:44.293247
# Unit test for function debug
def test_debug():
    from unittest import mock
    from pybackwards.conf import settings
    settings.debug = True
    se = mock.Mock()
    debug(se)
    assert se.called
    settings.debug = False



# Generated at 2022-06-23 23:33:45.346082
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:33:52.276056
# Unit test for function debug
def test_debug():
    import io

    stream = io.StringIO()
    sys_err = sys.stderr
    sys.stderr = stream

    settings.debug = True
    debug(lambda: 'Hello, World!')
    assert stream.getvalue() == 'Hello, World!\n'
    stream.seek(0)

    settings.debug = False
    debug(lambda: 'Hello, World!')
    assert stream.getvalue() == ''
    stream.seek(0)

    sys.stderr = sys_err
    settings.debug = False
    stream.close()

# Generated at 2022-06-23 23:33:55.006519
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator().generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator().generate('b') == '_py_backwards_b_1'


# Generated at 2022-06-23 23:34:03.780826
# Unit test for function debug
def test_debug():
    import re
    import sys
    import pytest
    from io import StringIO

    class Settings:
        debug = False

    def capture_print(get_message: Callable[[], str]) -> str:
        with StringIO() as stream:
            sys.stderr, previous_stderr = stream, sys.stderr
            try:
                debug(get_message)
                return stream.getvalue()
            finally:
                sys.stderr = previous_stderr

    def test_debug_does_not_print_anything_when_debug_is_off():
        assert not settings.debug
        assert not capture_print(lambda: 'Hello')

    def test_debug_prints_message_when_debug_is_on():
        settings.debug = True

# Generated at 2022-06-23 23:34:06.508868
# Unit test for function debug
def test_debug():
    logger = call_count_logger()
    setattr(settings, 'debug', True)
    debug(lambda: 'hello')
    assert logger.count == 1
    setattr(settings, 'debug', False)
    debug(lambda: 'hello')
    assert logger.count == 1



# Generated at 2022-06-23 23:34:09.195941
# Unit test for function eager
def test_eager():
    iterable = [1, 2, 3]
    iterator = iter(iterable)
    assert next(iterator) == 1

    @eager
    def foo():
        return iterator

    assert foo() == iterable

# Generated at 2022-06-23 23:34:12.716471
# Unit test for function get_source
def test_get_source():
    def my_function():
        pass

    assert get_source(my_function) == 'def my_function():\n    pass\n'

    def my_function():
        first_line = 'Hello'
        second_line = 'world'

    assert get_source(my_function) == 'first_line = \'Hello\'\nsecond_line = \'world\'\n'

# Generated at 2022-06-23 23:34:17.594173
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    from .context import settings
    import warnings

    save_debug_mode = settings.debug
    settings.debug = False
    fake_output = StringIO()
    with redirect_stderr(fake_output):
        warn('Hello, world!')
    assert fake_output.getvalue() == messages.warn('Hello, world!')
    fake_output = StringIO()
    with redirect_stderr(fake_output):
        with warnings.catch_warnings(record=True) as w:
            warns = []
            for message in w:
                warns.append(str(message.message))
            assert warns == ['Hello, world!']

# Generated at 2022-06-23 23:34:22.849998
# Unit test for function eager
def test_eager():
    # pylint: disable=C0111,C0103
    from py_backwards.utils.eager import eager
    import time

    @eager
    def gen() -> range:
        time.sleep(1)
        return range(5)

    start = time.time()
    assert gen() == [0, 1, 2, 3, 4]
    end = time.time()
    assert end - start < 1.2

# Generated at 2022-06-23 23:34:27.724178
# Unit test for function warn
def test_warn():
    from tempfile import TemporaryFile

    message = 'Test message'
    with TemporaryFile('w+') as f:
        warn(message)
        f.seek(0)
        assert f.readline().strip() == messages.warn(message)



# Generated at 2022-06-23 23:34:28.733037
# Unit test for function warn
def test_warn():
    """For test purposes only."""
    warn('\nSame warn here\n')

# Generated at 2022-06-23 23:34:30.010385
# Unit test for function get_source
def test_get_source():
    def test(a, b):
        return a + b

    assert get_source(test) == 'return a + b'

# Generated at 2022-06-23 23:34:31.190379
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(10))() == list(range(10))

# Generated at 2022-06-23 23:34:32.924234
# Unit test for function get_source
def test_get_source():
    def twice(x):
        return 2 * x

    assert get_source(twice) == 'return 2 * x'

# Generated at 2022-06-23 23:34:38.136854
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'

# Generated at 2022-06-23 23:34:42.483309
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables_generator = VariablesGenerator()
    assert variables_generator.generate('a') == '_py_backwards_a_0'
    assert variables_generator.generate('a') == '_py_backwards_a_1'
    assert variables_generator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-23 23:34:45.882142
# Unit test for function warn
def test_warn():
    with patch('sys.stderr') as stderr_mock:
        warn('test')
        stderr_mock.write.assert_called_with(messages.warn('test') + '\n')



# Generated at 2022-06-23 23:34:50.592854
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('some_var') == '_py_backwards_some_var_0'
    assert VariablesGenerator.generate('some_var') == '_py_backwards_some_var_1'
    assert VariablesGenerator.generate('some_var') == '_py_backwards_some_var_2'

# Generated at 2022-06-23 23:34:52.863451
# Unit test for function get_source
def test_get_source():
    def test_function():
        """docstring"""
        return 'return value'

    assert get_source(test_function) == 'return "return value"'


# Generated at 2022-06-23 23:34:57.670197
# Unit test for function eager
def test_eager():
    def fibs_generator(end: int) -> Iterable[int]:
        a, b = 1, 1
        while a < end:
            yield a
            a, b = b, a + b

    assert eager(fibs_generator)(end=10) == [1, 1, 2, 3, 5, 8]

# Generated at 2022-06-23 23:35:00.668620
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('') == '_py_backwards_0_0'
    assert VariablesGenerator.generate('') == '_py_backwards_0_1'


# Generated at 2022-06-23 23:35:02.369356
# Unit test for function get_source
def test_get_source():
    def fn(x: int) -> int:
        return x

    assert get_source(fn) == 'return x'

# Generated at 2022-06-23 23:35:05.289211
# Unit test for function get_source
def test_get_source():
    def source(a, b):
        if a == 0:
            return b[:8]
        print('a = %d' % a)

# Generated at 2022-06-23 23:35:07.153570
# Unit test for function get_source
def test_get_source():
    def foo():
        print('test')

    assert get_source(foo) == 'print(\'test\')'

# Generated at 2022-06-23 23:35:09.020170
# Unit test for function debug

# Generated at 2022-06-23 23:35:12.440641
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == "_py_backwards_x_0"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_1"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_2"



# Generated at 2022-06-23 23:35:16.472052
# Unit test for function eager
def test_eager():
    @eager
    def foo(start, stop):
        i = start
        while i < stop:
            yield i
            i += 1
    def bar():
        yield 1
        yield 2
    assert foo(1, 10) == list(range(1, 10))
    assert foo(bar()) == [1, 2]

# Generated at 2022-06-23 23:35:19.996478
# Unit test for function get_source
def test_get_source():
    def my_function():
        a = 1 + 2
        return a
    if get_source(my_function) != '    a = 1 + 2\n    return a':
        raise AssertionError('get_source works incorrectly!')

# Generated at 2022-06-23 23:35:25.811094
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_3'


# Generated at 2022-06-23 23:35:33.265283
# Unit test for function eager
def test_eager():
    # Arrange
    import random

    lst = list(range(random.randint(1, 100)))

    def natural_numbers() -> Iterable[int]:
        i = 0
        while True:
            yield i
            i += 1

    def natural_numbers_up_to(n: int) -> Iterable[int]:
        for i in natural_numbers():
            if i == n:
                break

            yield i

    # Act, then assert
    assert eager(lambda: lst)() == lst
    assert eager(natural_numbers)() == lst
    assert eager(natural_numbers_up_to)(len(lst)) == lst

# Generated at 2022-06-23 23:35:36.775790
# Unit test for function get_source
def test_get_source():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            def f():
                def g():
                    pass
            self.assertEqual(get_source(f).strip(), 'def g():\n    pass')

    unittest.main()


# Generated at 2022-06-23 23:35:41.763419
# Unit test for function warn
def test_warn():
    import io
    import sys

    buf = io.StringIO()
    try:
        sys.stderr = buf
        warn('test')
        assert buf.getvalue() == messages.warn('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:35:42.695718
# Unit test for function warn
def test_warn():
    warn('Warning!')


# Generated at 2022-06-23 23:35:48.244334
# Unit test for function debug
def test_debug():
    debug_messages = []
    def print_debug(message: str) -> None:
        debug_messages.append(message)

    settings.debug = False
    debug(lambda: 'should not print')
    assert not debug_messages

    settings.debug = True
    debug(lambda: 'should not print')
    assert debug_messages[0] == 'should not print'

# Generated at 2022-06-23 23:35:52.912307
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'


# Generated at 2022-06-23 23:35:54.380384
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(1, 10):
        assert VariablesGenerator.generate("a") == "_py_backwards_a_" + str(i)

# Generated at 2022-06-23 23:35:58.785742
# Unit test for function warn
def test_warn():
    """Test the warn function"""
    class Capture(list):
        """Captures the arguments passed to func."""
        def __call__(self, *args: Any) -> None:
            self.append(args)

    capture = Capture()
    sys.stderr.write = capture

    warn('message')

    assert capture[0][0].endswith('message\n')



# Generated at 2022-06-23 23:36:01.508929
# Unit test for function eager
def test_eager():
    @eager
    def test(n):
        for i in range(n):
            yield i

    assert test(0) == []
    assert test(1) == [0]
    assert test(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-23 23:36:07.485428
# Unit test for function debug
def test_debug():

    class SideEffect:

        def __init__(self):
            self.messages = []

        def __call__(self, message: str) -> None:
            self.messages.append(message)


    side_effect = SideEffect()
    settings.debug = True
    get_message = lambda: 'test'
    debug(get_message)
    assert side_effect.messages == ['[Debug] test']

# Generated at 2022-06-23 23:36:15.302027
# Unit test for function debug
def test_debug():

    debug_s = []

    def debug_printer(message):
        debug_s.append(message)

    with patch('py_backwards.utils.messages.debug') as patched:
        patched.side_effect = debug_printer
        debug(lambda: "hello")
        assert len(debug_s) == 0

    settings.debug = True

    def debug_func():
        debug(lambda: "hello")
        assert len(debug_s) == 1
        assert debug_s == ["[DEBUG] hello"]

    debug_func()

    settings.debug = False

    debug_func()

# Generated at 2022-06-23 23:36:19.305856
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('c') == '_py_backwards_c_2'

# Generated at 2022-06-23 23:36:26.936958
# Unit test for function debug
def test_debug():
    class Mock:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.write_arg = None

        def write(self, arg):
            self.write_arg = arg

    sys.stderr = Mock()
    debug(lambda: "DEBUG")
    assert sys.stderr.write_arg is None
    settings.debug = True
    debug(lambda: "DEBUG")
    assert sys.stderr.write_arg is not None

# Generated at 2022-06-23 23:36:27.976422
# Unit test for function warn
def test_warn():
    warn('Secret message')


# Generated at 2022-06-23 23:36:35.629280
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('c') == '_py_backwards_c_2'
    assert VariablesGenerator.generate('d') == '_py_backwards_d_3'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_4'


# Generated at 2022-06-23 23:36:39.476177
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate("a")
    assert(v1 == "_py_backwards_a_0")
    v2 = VariablesGenerator.generate("a")
    assert(v2 == "_py_backwards_a_1")

# Generated at 2022-06-23 23:36:43.212050
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class Test:
        def __init__(self, name):
            self.name = name

    g1 = VariablesGenerator()
    g2 = VariablesGenerator()
    g3 = VariablesGenerator()
    assert g1.generate('a') != g2.generate('a') != g3.generate('a')



# Generated at 2022-06-23 23:36:47.450984
# Unit test for function warn
def test_warn():
    from io import StringIO
    f = StringIO()
    sys.stderr = f
    warn('test')
    sys.stderr = sys.__stderr__
    assert f.getvalue() == messages.warn('test') + '\n'


# Generated at 2022-06-23 23:36:51.408313
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    global VariablesGenerator
    VariablesGenerator._counter = 0

    assert(VariablesGenerator.generate('foo') == '_py_backwards_foo_0')
    assert(VariablesGenerator.generate('foo') == '_py_backwards_foo_1')


# Generated at 2022-06-23 23:36:53.208021
# Unit test for function eager
def test_eager():
    @eager
    def foo() -> Iterable[int]:
        yield 1
        yield 2

    assert foo() == [1, 2]

# Generated at 2022-06-23 23:36:55.249537
# Unit test for function get_source
def test_get_source():
    # Given
    def foo():
        x = 1
        return x

    # Then
    assert get_source(foo) == 'x = 1\nreturn x'



# Generated at 2022-06-23 23:36:56.611748
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2

    assert eager(f)() == [1, 2]

# Generated at 2022-06-23 23:37:00.102056
# Unit test for function get_source
def test_get_source():
    def fn():
        for i in range(10):
            print(i)

    expected = '''
for i in range(10):
    print(i)
'''.strip()
    assert expected == get_source(fn)

# Generated at 2022-06-23 23:37:04.245244
# Unit test for function get_source
def test_get_source():
    def example():
        def inner_example():
            return 1
        return inner_example()

    assert get_source(example) == 'def inner_example():\n' \
        '    return 1\n' \
        'return inner_example()'

# Generated at 2022-06-23 23:37:05.204545
# Unit test for function debug
def test_debug():
    debug(lambda: 'Test debug message')



# Generated at 2022-06-23 23:37:10.973953
# Unit test for function warn
def test_warn():
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    import sys
    import warnings as py_warnings

    sys.stderr = StringIO()
    py_warnings.filterwarnings('error')
    try:
        warn('test_warn_message')
        assert sys.stderr.getvalue() == messages.warn('test_warn_message')
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:37:14.316602
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    import warnings

    old_stdout = sys.stdout
    sys.stdout = StringIO()
    warnings.simplefilter('ignore')
    warn("Test warn")
    warnings.simplefilter('default')
    sys.stdout = old_stdout

# Generated at 2022-06-23 23:37:16.381879
# Unit test for function get_source
def test_get_source():
    def function():
        def inner_function():
            pass
    assert get_source(function) == 'def inner_function():\n    pass'



# Generated at 2022-06-23 23:37:19.143418
# Unit test for function debug
def test_debug():
    from pybackwards.utils import debug
    debug_message = "Test debug"
    debug(lambda: debug_message)
    assert debug.__name__ == "debug"

# Generated at 2022-06-23 23:37:24.677700
# Unit test for function get_source
def test_get_source():
    """Unit test for function get_source."""
    def a():
        """Function a."""
        return 1
    def b():
        """Function b."""
        return 2
    assert get_source(a) == 'return 1'
    assert get_source(b) == 'return 2'
    assert get_source(test_get_source) is not None

# Generated at 2022-06-23 23:37:29.764601
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO
    from . import utils
    stderr = StringIO()
    with pytest.warns(UserWarning):
        with pytest.raises(SystemExit):
            with utils.replaced(sys.stderr, stderr):
                utils.warn(message="test_warn_message")
                assert stderr.getvalue() == "test_warn_message\n"


# Generated at 2022-06-23 23:37:32.401350
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2

    def bar():
        return 1, 2

    assert foo() == foo()
    assert eager(foo)() == eager(foo)()
    assert foo() != eager(foo)()
    assert eager(foo)() == bar()



# Generated at 2022-06-23 23:37:33.568560
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2

    assert f() == [1, 2]

# Generated at 2022-06-23 23:37:35.691999
# Unit test for function warn
def test_warn():
    from io import StringIO
    s = StringIO()
    sys.stderr = s
    warn("Test message")
    sys.stderr = sys.__stderr__
    assert(s.getvalue() == "py-backwards: Test message\n")

# Generated at 2022-06-23 23:37:40.403522
# Unit test for function warn
def test_warn():
    output = StringIO()
    sys.stderr = output
    message = 'Something went wrong'
    warn(message)
    output.seek(0)
    assert output.read() == messages.warn(message) + '\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:37:44.593451
# Unit test for function debug
def test_debug():
    assert settings.debug
    sys.stderr = sys.__stderr__ = open('/dev/null', 'w')
    debug(lambda: "debug")
    assert 'debug' in open('/dev/null', 'r').read()
    assert settings.debug
    sys.stderr = sys.__stderr__ = sys.stderr

# Generated at 2022-06-23 23:37:48.171610
# Unit test for function warn
def test_warn():
    import io
    import sys

    output_string = io.StringIO()
    sys.stderr = output_string
    string = 'Hello you'
    warn(string)
    assert output_string.getvalue() == '\033[93mWarning! {}\033[0m\n'.format(string)



# Generated at 2022-06-23 23:37:49.397362
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(10))() == list(range(10))


#Unit test for function get_source

# Generated at 2022-06-23 23:37:51.474159
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_2'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_3'

# Generated at 2022-06-23 23:37:54.101481
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    with patch('sys.stderr', new=None):
        warn('message')
        warn('other message')



# Generated at 2022-06-23 23:37:55.817076
# Unit test for function get_source
def test_get_source():
    def f():
        return x

    assert (get_source(f)) == '''
return x'''



# Generated at 2022-06-23 23:38:00.459813
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('a') == '_py_backwards_a_0'
    assert gen.generate('a') == '_py_backwards_a_1'
    assert gen.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:38:01.919505
# Unit test for function debug
def test_debug():
    def get_message():
        return "test"

    debug(get_message)

# Generated at 2022-06-23 23:38:04.934172
# Unit test for function warn
def test_warn():
    import sys, io
    f = io.StringIO()
    with redirect_stdout(f):
        warn("Test")
    assert f.getvalue() == messages.warn("Test") + '\n'

# Generated at 2022-06-23 23:38:10.631266
# Unit test for function debug
def test_debug():
    debug_messages = []

    def get_message():
        debug_messages.append('called')
        return 'called'

    from . import conf
    with conf.override_settings(debug=True):
        debug(get_message)
        assert debug_messages == ['called']

    with conf.override_settings(debug=False):
        debug(get_message)
        assert debug_messages == ['called']

# Generated at 2022-06-23 23:38:12.864859
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'



# Generated at 2022-06-23 23:38:14.276805
# Unit test for function eager
def test_eager():
    from .test_utils import test_eager
    return test_eager()

# Generated at 2022-06-23 23:38:24.530159
# Unit test for function get_source

# Generated at 2022-06-23 23:38:28.234998
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_gen = VariablesGenerator()
    global _counter
    _counter = 0
    assert var_gen.generate('a') == '_py_backwards_a_0'
    assert var_gen.generate('a') == '_py_backwards_a_1'

# Generated at 2022-06-23 23:38:36.363024
# Unit test for function warn
def test_warn():
    import re

    class CaptureOutput:
        def __init__(self, out=None, err=None):
            self.out = out
            self.err = err

        def __enter__(self):
            self.out_old, self.err_old = sys.stdout, sys.stderr
            sys.stdout, sys.stderr = self.out, self.err

        def __exit__(self, *args):
            sys.stdout, sys.stderr = self.out_old, self.err_old

    def test_warning_message():
        with CaptureOutput(out=open('tests/warn.txt', 'w'), err=open('tests/warn.txt', 'w')) as output:
            warn('test')

# Generated at 2022-06-23 23:38:41.982334
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'



# Generated at 2022-06-23 23:38:50.136933
# Unit test for function get_source
def test_get_source():
    def func(): pass
    def inner_func(): pass
    def func_with_inner_func():
        inner_func()
        inner_func()
    def func_with_nesting():
        def inner():
            pass
    assert get_source(func) == 'def func(): pass'
    assert get_source(func_with_inner_func) == \
        'def func_with_inner_func():\n    inner_func()\n    inner_func()'
    assert get_source(func_with_nesting) == 'def func_with_nesting():\n    pass'

# Generated at 2022-06-23 23:38:54.088798
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Creating two instances of the class
    generator1 = VariablesGenerator()
    generator2 = VariablesGenerator()
    # Generating two unique names for variables
    name1 = generator1.generate('name')
    name2 = generator2.generate('name')
    # Checking that names are unique
    assert name1 != name2


# Generated at 2022-06-23 23:39:01.273629
# Unit test for function get_source

# Generated at 2022-06-23 23:39:02.980407
# Unit test for function warn
def test_warn():
    print(messages.warn('message'))



# Generated at 2022-06-23 23:39:04.451366
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate('test_variable'))

# Generated at 2022-06-23 23:39:09.633796
# Unit test for function debug
def test_debug():
    get_debug_messages = []

    def get_message():
        get_debug_messages.append(None)
        return 'debug message'

    debug(get_message)
    assert get_debug_messages == [None]

    settings.debug = False
    debug(get_message)
    assert get_debug_messages == [None]

# Generated at 2022-06-23 23:39:14.794537
# Unit test for function debug
def test_debug():
    old_debug = settings.debug
    settings.debug = True
    try:
        messages.reset_debug_message_counter()
        debug(lambda: 'Example')
        assert messages.get_debug_message_counter() == 1
    finally:
        settings.debug = old_debug
        messages.reset_debug_message_counter()

# Generated at 2022-06-23 23:39:20.069536
# Unit test for function get_source
def test_get_source():
    def inside_test_source():
        return None
    test_source = get_source(test_get_source)
    test_source += get_source(inside_test_source)
    assert test_source == """def inside_test_source():
    return None
test_source = get_source(test_get_source)
test_source += get_source(inside_test_source)
assert test_source == """

# Generated at 2022-06-23 23:39:20.656457
# Unit test for function debug
def test_debug():
    pass

# Generated at 2022-06-23 23:39:22.475719
# Unit test for function eager
def test_eager():
    def fn(): yield 1; yield 2
    assert eager(fn)() == [1, 2]

# Generated at 2022-06-23 23:39:25.750371
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'


# Generated at 2022-06-23 23:39:33.363972
# Unit test for function warn
def test_warn():
    import textwrap
    import sys
    sys.stderr = open('test_stderr', 'w')
    warn(textwrap.dedent("""
        this is my waring message,
        you should see this message
    """))
    sys.stderr.close()
    with open('test_stderr') as f:
        stderr = f.read()
    assert stderr == '\x1b[93mthis is my waring message, you should see this message\n\x1b[0m'


# Generated at 2022-06-23 23:39:39.247877
# Unit test for function debug
def test_debug():
    from io import StringIO
    from ..conf import set_settings
    set_settings(debug=False)
    message = StringIO()
    sys.stderr = message
    debug(lambda: 'hello')
    assert message.getvalue() == ''
    set_settings(debug=True)
    debug(lambda: 'hello')
    assert message.getvalue().strip() == 'debug: hello'


# Generated at 2022-06-23 23:39:42.910621
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('var') != gen.generate('var')
    assert gen.generate('var1') != gen.generate('var2')
    assert gen.generate('var1') == gen.generate('var1')



# Generated at 2022-06-23 23:39:44.018734
# Unit test for function eager
def test_eager():
    assert eager(range)(1, 2) == [1]



# Generated at 2022-06-23 23:39:48.340261
# Unit test for function eager
def test_eager():
    from tempfile import TemporaryDirectory
    from .utils import execute

    with TemporaryDirectory() as tmp_dir:
        fn_path = '{}/fn.py'.format(tmp_dir)

# Generated at 2022-06-23 23:39:53.663839
# Unit test for function eager
def test_eager():
    from unittest import TestCase, main
    class TestEager(TestCase):
        def test_generator(self):
            @eager
            def generator():
                for x in range(10):
                    yield x ** 2
            self.assertEqual(generator(), [0, 1, 4, 9, 16, 25, 36, 49, 64, 81])
    main()

# Generated at 2022-06-23 23:39:59.285333
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Setup
    generator = VariablesGenerator()
    first = generator.generate("x")
    second = generator.generate("x")
    third = generator.generate("x")

    # Assertion
    assert first != second, "Variables should be different"
    assert second != third, "Variables should be different"
    assert first != third, "Variables should be different"



# Generated at 2022-06-23 23:40:00.553465
# Unit test for function warn
def test_warn():
    warn('warning')



# Generated at 2022-06-23 23:40:06.986739
# Unit test for function debug
def test_debug():
    # Pytest will capture stderr, so we need to restore it
    stderr = sys.stderr
    sys.stderr = open("test1.txt", 'w+')

    settings.debug = True
    debug(lambda: "debug message 1")

    settings.debug = False
    debug(lambda: "debug message 2")

    # Restore stderr
    sys.stderr.close()
    sys.stderr = stderr
    settings.debug = False
    # Pytest will capture stderr, so we need to restore it
    stderr = sys.stderr

    f = open("test1.txt", "r")
    contents = f.readlines()
    f.close()
    print(contents)
    assert contents[0].strip().endswith("debug message 1")


# Generated at 2022-06-23 23:40:13.667471
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'
    assert VariablesGenerator.generate('z') == '_py_backwards_z_2'
    assert VariablesGenerator.generate('x') != '_py_backwards_x_0'


# Generated at 2022-06-23 23:40:15.434725
# Unit test for function warn
def test_warn():
    messages.Messages.warn = 'This is a warning'
    warn('This is a warning')


# Generated at 2022-06-23 23:40:18.233479
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_0'
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_1'


# Generated at 2022-06-23 23:40:21.565294
# Unit test for function debug
def test_debug():
    """
    NOTE: this test relies on the side effect of printing to stdout.
    TODO: write a better test that actually checks that the right things are printed.
    """
    debug(lambda: 'This should be printed')
    settings.debug = False
    debug(lambda: 'This should be not printed')



# Generated at 2022-06-23 23:40:25.452436
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Test if two variables are generated
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('b')

    # Test if two variables generated the same way are different
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')

# Generated at 2022-06-23 23:40:27.839941
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(1, 11):
        assert VariablesGenerator().generate('') == '_py_backwards__{}'.format(i)

# Generated at 2022-06-23 23:40:36.486108
# Unit test for function debug
def test_debug():
    # Test if ``settings.debug`` is set to True.
    settings._debug_tmp = settings.debug
    settings.debug = True

    # Test user-defined message
    try:
        s = 'user-defined message'
        debug(lambda: s)
        assert True
    except AssertionError:
        assert False

    # Test if ``settings.debug`` is set to False.
    settings.debug = False
    try:
        s = 'user-defined message'
        debug(lambda: s)
        assert True
    except AssertionError:
        assert False

    # Restore ``settings.debug``
    settings.debug = settings._debug_tmp
    delattr(settings, '_debug_tmp')


# Generated at 2022-06-23 23:40:38.991170
# Unit test for function warn
def test_warn():
    result = []
    old = sys.stderr
    try:
        sys.stderr = result.append
        warn('my message')
    finally:
        sys.stderr = old
    assert result[0] == messages.warn('my message') + '\n'

# Generated at 2022-06-23 23:40:41.634247
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('x') for _ in range(10)]
    assert len(set(variables)) == len(variables)



# Generated at 2022-06-23 23:40:50.630630
# Unit test for function debug
def test_debug():
    import io
    import unittest

    class DebugTest(unittest.TestCase):
        def test_debug(self):
            result = io.StringIO()
            sys.stderr = result
            try:
                settings.debug = False
                debug(lambda: 'test message')

                settings.debug = True
                debug(lambda: 'test message 2')
            finally:
                sys.stderr = sys.__stderr__

            self.assertEqual(result.getvalue(), 'test message 2\n')

    unittest.main(module='tests.test_util', exit=False, verbosity=2)

# Generated at 2022-06-23 23:41:00.026267
# Unit test for function debug
def test_debug():
    from . import test_utils
    from . import messages

    test_message = 'Test message'

    settings.debug = True
    with test_utils.captured_output() as (_, stderr):
        debug(lambda: test_message)
    assert test_message in stderr.getvalue()
    assert messages.debug('Test message') in stderr.getvalue()

    settings.debug = False
    with test_utils.captured_output() as (stdout, stderr):
        debug(lambda: test_message)
    assert test_message not in stdout.getvalue()
    assert test_message not in stderr.getvalue()
    assert messages.debug('Test message') not in stderr.getvalue()



# Generated at 2022-06-23 23:41:04.856200
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'

# Generated at 2022-06-23 23:41:06.620426
# Unit test for function get_source
def test_get_source():
    test_function = lambda x: x
    assert get_source(test_function) == 'lambda x: x'

# Generated at 2022-06-23 23:41:08.705186
# Unit test for function get_source
def test_get_source():
    def fn():
        """
        Test
        """
        pass

    assert get_source(fn) == '\n        pass\n        '

# Generated at 2022-06-23 23:41:15.111553
# Unit test for function debug
def test_debug():
    messages._DEBUG_INDENT = 0
    debug(lambda: '123')
    assert messages._DEBUG_INDENT == 1
    debug(lambda: 'qwerty')
    assert messages._DEBUG_INDENT == 2
    debug(lambda: 'qwerty')
    assert messages._DEBUG_INDENT == 3
    messages._DEBUG_INDENT = 0
    debug(lambda: '123')
    assert messages._DEBUG_INDENT == 1
    debug(lambda: 'qwerty')
    assert messages._DEBUG_INDENT == 2
    messages._DEBUG_INDENT = 0

# Generated at 2022-06-23 23:41:18.337021
# Unit test for function eager
def test_eager():
    def iterate_two_times() -> Iterable[int]:
        yield 3
        yield 4

    assert eager(iterate_two_times)() == [3, 4]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:41:20.297367
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
    assert eager(foo)() == [1, 2]


# Generated at 2022-06-23 23:41:22.072275
# Unit test for function eager
def test_eager():

    @eager
    def i():
        for i in range(4):
            yield i

    assert i() == [0, 1, 2, 3]

# Generated at 2022-06-23 23:41:24.127012
# Unit test for function get_source
def test_get_source():
    def func():
        # Inline comment here
        return 1

    # Leading and trailing spaces here
    assert get_source(func) == '# Inline comment here\nreturn 1'

# Generated at 2022-06-23 23:41:29.873018
# Unit test for function debug
def test_debug():
    import io
    old_stream = sys.stderr
    try:
        mock_stream = io.StringIO()
        sys.stderr = mock_stream
        settings.debug = False
        debug(lambda: 'test-message')
        assert mock_stream.getvalue() == ''
        settings.debug = True
        debug(lambda: 'test-message')
        assert mock_stream.getvalue() == messages.debug('test-message') + '\n'
    finally:
        sys.stderr = old_stream
test_debug.test = True
test_debug.__name__ = 'test_debug'
test_debug.__doc__ = messages.tests_disabled
test_debug.__annotations__ = {}

# Generated at 2022-06-23 23:41:30.951535
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-23 23:41:31.814113
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test debug'

    debug(get_message)



# Generated at 2022-06-23 23:41:35.995494
# Unit test for function eager
def test_eager():
    @eager
    def make_range(n: int) -> Iterable[int]:
        i = 0
        while i < n:
            yield i
            i += 1
    assert make_range(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:41:48.399001
# Unit test for function get_source
def test_get_source(): # type: ignore
    assert get_source(test_get_source) == textwrap.dedent('''\
        def test_get_source():
            assert get_source(test_get_source) == textwrap.dedent('''
                        '''
    ''')

# Generated at 2022-06-23 23:41:52.039363
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('test')
                 for _ in range(10)]
    assert len(variables) == len(set(variables))

    variables = [VariablesGenerator.generate('test')
                 for _ in range(10)]
    assert len(variables) == len(set(variables))



# Generated at 2022-06-23 23:41:55.567561
# Unit test for function warn
def test_warn():
    with Capturing() as output:
        warn('test')
    message = '{} test\n'.format(messages.WARN_COLOR)
    assert message == output[0]


if __name__ == '__main__':
    from test.tools import Capturing
    test_warn()

# Generated at 2022-06-23 23:41:56.289167
# Unit test for function debug
def test_debug():
    debug(lambda: 'I am debug message')



# Generated at 2022-06-23 23:41:58.799550
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator()
    v2 = VariablesGenerator()
    if v1 == v2:
        print ("True")
    else:
        print ("False")