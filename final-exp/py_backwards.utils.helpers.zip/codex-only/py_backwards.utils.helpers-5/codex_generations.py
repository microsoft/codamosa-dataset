

# Generated at 2022-06-23 23:32:07.287903
# Unit test for function debug
def test_debug():
    import sys

    def get_message():
        return 'message'

    settings.debug = True
    debug(get_message)
    assert sys.stderr.getvalue() == messages.debug(get_message()) + '\n'

    settings.debug = False
    debug(get_message)
    assert sys.stderr.getvalue() == messages.debug(get_message()) + '\n'



# Generated at 2022-06-23 23:32:11.077731
# Unit test for function debug
def test_debug():
    msg = "foo bar"
    with mock.patch('sys.stderr.write') as write:
        debug(lambda: msg)
        write.assert_called_once_with(messages.debug(msg))



# Generated at 2022-06-23 23:32:18.535196
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from . import messages

    def get_message():
        return 'foo'

    original_stdout = sys.stderr
    sys.stderr = StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == ''

    settings.debug = True
    debug(get_message)
    assert sys.stderr.getvalue() == '{}{}foo{}'.format(messages.BOLD,
                                                       messages.BLUE,
                                                       messages.RESET)
    sys.stderr = original_stdout

# Generated at 2022-06-23 23:32:19.126963
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    pass

# Generated at 2022-06-23 23:32:21.622887
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = []
    for _ in range(100):
        variables.append(VariablesGenerator.generate('test'))
    assert len(variables) == len(set(variables))



# Generated at 2022-06-23 23:32:23.423373
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        # noinspection PyUnusedLocal
        def f(m):
            debug(lambda: m)
        f('test')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:32:25.857397
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            pass
        pass
    assert get_source(f) == 'def f():\n    def g():\n        pass\n    pass'

# Generated at 2022-06-23 23:32:28.277414
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass
    code = get_source(some_function)
    assert code == 'def some_function():\n    pass'

# Generated at 2022-06-23 23:32:31.112778
# Unit test for function get_source
def test_get_source():
    source_code = """def foo(arg1, arg2):
        pass"""
    def foo():
        pass
    assert get_source(foo) == source_code

# Generated at 2022-06-23 23:32:33.960718
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'

# Generated at 2022-06-23 23:32:37.472895
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    b = VariablesGenerator.generate('b')
    c = VariablesGenerator.generate('c')
    d = VariablesGenerator.generate('d')
    assert a != b != c != d

# Generated at 2022-06-23 23:32:42.331913
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == '\ndef func():\n    pass'

    def func_with_args(arg1):
        pass
    assert get_source(func_with_args) == '\ndef func_with_args(arg1):\n    pass'


# Generated at 2022-06-23 23:32:46.438056
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class ExampleClass:
        pass
    assert VariablesGenerator.generate('ExampleClass') == '_py_backwards_ExampleClass_0'
    for i in range(1, 100):
        assert VariablesGenerator.generate('ExampleClass') == '_py_backwards_ExampleClass_' + str(i)

# Generated at 2022-06-23 23:32:48.794569
# Unit test for function eager
def test_eager():
    def test_function() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(test_function)() == [1, 2, 3]

# Generated at 2022-06-23 23:32:52.353073
# Unit test for function get_source
def test_get_source():
    def f():
        raise NotImplementedError

    source_lines = ['def f():', '    raise NotImplementedError']

    assert get_source(f) == '\n'.join(source_lines)
    assert get_source(f) == '\n'.join(source_lines)

# Generated at 2022-06-23 23:32:57.393542
# Unit test for function warn
def test_warn():
    import io
    #Check whether the color red is in the message
    assert '\033[91m' in messages.warn("test")
    #Save the error message in a variable
    output = io.StringIO()
    sys.stderr = output
    #Call the function
    warn("test")
    #Check whether the addded color is also in the output
    assert '\033[91m' in output.getvalue()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:32:58.896047
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        for i in range(3):
            yield i


    assert list(foo()) is not foo()

# Generated at 2022-06-23 23:33:02.250055
# Unit test for function debug
def test_debug():
    debug_messages = []

    def get_message():
        debug_messages.append('foo')

    debug(get_message)
    assert debug_messages == []

    settings.debug = True
    debug(get_message)
    assert debug_messages == ['foo']

# Generated at 2022-06-23 23:33:06.900011
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        a = VariablesGenerator()
        assert len(w) == 0, 'Unexpected warning %s' % w[0]
        b = VariablesGenerator()
        assert a.generate('foo') != b.generate('foo')


# Generated at 2022-06-23 23:33:16.983321
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables_generator = VariablesGenerator()
    assert variables_generator.generate("k") == "_py_backwards_k_0"
    assert variables_generator.generate("k") == "_py_backwards_k_1"
    assert variables_generator.generate("k") == "_py_backwards_k_2"
    assert variables_generator.generate("k") == "_py_backwards_k_3"
    assert variables_generator.generate("k") == "_py_backwards_k_4"
    assert variables_generator.generate("k") == "_py_backwards_k_5"
    assert variables_generator.generate("k") == "_py_backwards_k_6"

# Generated at 2022-06-23 23:33:22.003952
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variableGenerator = VariablesGenerator()

    assert variableGenerator.generate('blah') == '_py_backwards_blah_0'
    assert variableGenerator.generate('blah') == '_py_backwards_blah_1'
    assert variableGenerator.generate('blah') == '_py_backwards_blah_2'

# Generated at 2022-06-23 23:33:31.193830
# Unit test for function eager
def test_eager():
    from .. import signals

    iterable = range(10)
    # Test with different calls
    assert eager(iter)(iterable) == iterable
    assert eager(list)(iterable) == list(iterable)
    assert eager(lambda x: range(100, 110))(iterable) == list(range(100, 110))

    # Test with generator wrapper
    def generator():
        for i in range(100):
            signals.before_return(i)
            yield i

    wrapper = eager(generator)
    assert wrapper() == list(range(100))
    assert signals.total_times_executed == 100

    # Test with generator wrapper with args
    def generator2(arg):
        for x in arg:
            yield x

    wrapper2 = eager(generator2)
    assert wrapper2(iterable) == iterable



# Generated at 2022-06-23 23:33:36.428331
# Unit test for function debug
def test_debug():
    import sys
    import io

    stdout = sys.stdout
    buf = io.StringIO()
    sys.stdout = buf
    try:

        class Settings:
            debug = True

        settings = Settings()
        debug(lambda: 'foo')
        sys.stdout = stdout
        assert buf.getvalue().strip() == '\033[38;5;70;1mDEBUG\033[0m: foo'

    finally:
        sys.stdout = stdout

# Generated at 2022-06-23 23:33:38.629145
# Unit test for function eager
def test_eager():
    def test_func(x: int) -> Iterable[int]:
        return x
    assert eager(test_func)(1) == [1]

# Generated at 2022-06-23 23:33:42.984704
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import unittest
    class Test(unittest.TestCase):
        def test_generate(self):
            variable = VariablesGenerator.generate('variable')
            variable2 = VariablesGenerator.generate('variable')
            assert variable != variable2
    unittest.main(module=__name__, argv=[''], verbosity=2, exit=False)

# Generated at 2022-06-23 23:33:45.205470
# Unit test for function warn
def test_warn():
    with CaptureOutput(relay=False) as capturer:
        warn("Warn message")
    assert capturer.get_text() == "\033[33mWARN: Warn message\033[0m\n"



# Generated at 2022-06-23 23:33:47.805878
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'debug message')

    settings.debug = True
    debug_message = 'debug message'
    debug(lambda: debug_message)

# Generated at 2022-06-23 23:33:49.932596
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass

    assert get_source(test_func) == 'def test_func():\n    pass\n'

# Generated at 2022-06-23 23:33:50.853493
# Unit test for function warn
def test_warn():
    warn('Testing warn function')



# Generated at 2022-06-23 23:33:52.955357
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-23 23:33:55.683371
# Unit test for function eager
def test_eager():
    @eager
    def numbers():
        for i in range(10):
            yield i

    assert numbers() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:34:01.323217
# Unit test for function warn
def test_warn():
    import builtins
    from .test_settings import get_settings
    from .test_messages import get_warn
    from contextlib import contextmanager
    with get_settings(debug=False), get_warn() as messages:
        warn('message')
        assert messages == []
    with get_settings(debug=True), get_warn() as messages:
        warn('message')
        assert messages == ['message']
        assert isinstance(messages, list)



# Generated at 2022-06-23 23:34:03.136829
# Unit test for function get_source
def test_get_source():
    def f() -> None:
        pass

    assert 'def f() -> None:' in get_source(f)


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-23 23:34:04.842737
# Unit test for function warn
def test_warn():
    message = messages.warn('test message')
    assert message == '\033[93mtest message\033[0m'


# Generated at 2022-06-23 23:34:07.743086
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-23 23:34:12.000813
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test2') == '_py_backwards_test2_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'
    assert VariablesGenerator.generate('test2') == '_py_backwards_test2_3'

# Generated at 2022-06-23 23:34:12.630666
# Unit test for function debug
def test_debug():
    return debug(lambda: 'hello')

# Generated at 2022-06-23 23:34:17.870621
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vgenerator = VariablesGenerator()
    assert vgenerator.generate('test') == '_py_backwards_test_0'
    assert vgenerator.generate('test') == '_py_backwards_test_1'
    assert vgenerator.generate('test') == '_py_backwards_test_2'
    assert vgenerator.generate('test') == '_py_backwards_test_3'
    assert vgenerator.generate('test') == '_py_backwards_test_4'
    assert vgenerator.generate('test') == '_py_backwards_test_5'
    assert vgenerator.generate('test') == '_py_backwards_test_6'

# Generated at 2022-06-23 23:34:19.968660
# Unit test for function eager
def test_eager():
    @eager
    def a():
        yield 1
        yield 2
        yield 3
    assert a() == [1,2,3]

# Generated at 2022-06-23 23:34:26.615775
# Unit test for function eager
def test_eager():
    from random import randint

    @eager
    def random_list_generator(n: int) -> Iterable[int]:
        yield from (randint(1, 100) for i in range(n))

    assert random_list_generator(4) == list(random_list_generator(4))
    assert random_list_generator(4) == [94, 67, 75, 77]

# Generated at 2022-06-23 23:34:38.082784
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def foo2():
        def bar():
            pass

    def foo3():
        def bar():
            def baz():
                pass

    foo_source_lines = get_source(foo).split('\n')
    assert foo_source_lines == ["def foo():", "    pass"]
    assert len(re.findall(r'^(\s*)', foo_source_lines[0])[0]) == 0

    foo2_source_lines = get_source(foo2).split('\n')
    assert foo2_source_lines == ["def foo2():",
                                 "    def bar():",
                                 "        pass"]
    assert len(re.findall(r'^(\s*)', foo2_source_lines[0])[0]) == 0

# Generated at 2022-06-23 23:34:41.930747
# Unit test for function warn
def test_warn():
    from .utils import TemporaryStdStreams
    streams = TemporaryStdStreams()
    try:
        warn('test msg')
        assert streams.stderr.getvalue() == messages.warn('test msg') + '\n'
    finally:
        streams.close()



# Generated at 2022-06-23 23:34:44.983736
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('i') == '_py_backwards_i_0'
    assert VariablesGenerator.generate('i') == '_py_backwards_i_1'

# Generated at 2022-06-23 23:34:48.585379
# Unit test for function get_source
def test_get_source():
    def f():
        """dummy_doc"""
        return 3

    assert get_source(f) == 'return 3'

    def g():
        """dummy_doc"""
        return 3

    assert get_source(g) == 'return 3'

# Generated at 2022-06-23 23:34:49.232894
# Unit test for function warn
def test_warn():
    warn("Hello")

# Generated at 2022-06-23 23:34:55.381783
# Unit test for function eager
def test_eager():
    # type: () -> None
    class MyIterable:
        def __init__(self, *args: Any) -> None:
            self._args = args

        def __iter__(self) -> Iterable[Any]:
            return iter(self._args)
    @eager
    def my_func(*args: Any) -> Iterable[Any]:
        return MyIterable(*args)

    assert my_func(1, 2, 3) == [1, 2, 3]
    assert my_func(7, 8, 9) == [7, 8, 9]

# Generated at 2022-06-23 23:35:01.531183
# Unit test for function debug
def test_debug():
    print('Start unit test for function debug.')

    def assert_debug_called(called):
        def get_message():
            nonlocal called
            called += 1
            return 'm'
        debug(get_message)
        assert called == 1

    settings.debug = False
    assert_debug_called(1)
    settings.debug = True
    assert_debug_called(0)

    print('Unit test for function debug passed successfully.')

# Generated at 2022-06-23 23:35:03.281914
# Unit test for function debug
def test_debug():
    def get_message() -> str:
        return 'test_debug'

    debug(get_message)

# Generated at 2022-06-23 23:35:06.780716
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'


# Generated at 2022-06-23 23:35:09.162899
# Unit test for function warn
def test_warn():
    import tempfile
    with tempfile.TemporaryFile() as f:
        warn('test')
        f.seek(0)
        assert f.read().decode() == messages.warn('test') + '\n'



# Generated at 2022-06-23 23:35:15.559603
# Unit test for function eager
def test_eager():
    from typing import List, Callable

    A = List[Callable[[], int]]

    def some_function() -> A:
        def inner() -> int:
            return 2
        return [inner]

    def sum_function(x: int) -> int:
        return x + 1

    def make_sum(numbers: A, f: Callable[[int], int]) -> A:
        return list(map(lambda x: f(x()), numbers))

    assert some_function()[0] == inner
    assert eager(some_function)[0]() == 2

    assert make_sum(some_function(), sum_function) == [3]

# Generated at 2022-06-23 23:35:19.996440
# Unit test for function debug
def test_debug():
    from .test_utils import capture_stderr
    with capture_stderr() as stderr:
        debug(lambda: 'This is a message')

        assert 'This is a message' in stderr.getvalue()

    stderr.close()

# Generated at 2022-06-23 23:35:23.053149
# Unit test for function get_source
def test_get_source():
    @get_source
    def test_fn():
        a = 1
        b = 2
    assert test_fn == 'def test_fn():\n    a = 1\n    b = 2'

# Generated at 2022-06-23 23:35:30.105160
# Unit test for function debug
def test_debug():
    class Result:
        has_been_called = False

    def get_message():
        result.has_been_called = True
        return "debug message"

    result = Result()

    # Not in debug mode, function should not be called
    settings.debug = False
    debug(get_message)
    assert result.has_been_called is False

    # In debug mode, function should be called
    settings.debug = True
    debug(get_message)
    assert result.has_been_called is True

    # Reset debug mode for other tests
    settings.debug = False



# Generated at 2022-06-23 23:35:32.310821
# Unit test for function debug
def test_debug():
    from pytest import raises
    from unittest.mock import Mock

    with raises(ImportError):
        from . import settings

    settings = Mock()
    settings.debug = True

    mock_print = Mock()
    print_ = print
    print = mock_print
    debug(lambda: 'hi')
    print = print_



# Generated at 2022-06-23 23:35:33.319870
# Unit test for function warn
def test_warn():
    import sys
    warn("aaa")



# Generated at 2022-06-23 23:35:35.844079
# Unit test for function eager
def test_eager():
    def generate_eager_list():
        yield 1
    def generate_lazy_list():
        return [1]

    assert eager(generate_eager_list)() == generate_lazy_list()

# Generated at 2022-06-23 23:35:43.780462
# Unit test for function warn
def test_warn():
    old_stderr = sys.stderr
    sys.stderr = open('py_backwards.log', 'w')
    warn('This is warning!')
    sys.stderr.close()
    sys.stderr = old_stderr
    file = open('py_backwards.log', 'r')
    line = file.readline()
    file.close()
    assert line == str('\033[31mThis is warning!\033[0m\n'), \
        'There is no warning!'
    os.remove('py_backwards.log')

# Generated at 2022-06-23 23:35:44.374457
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-23 23:35:46.242255
# Unit test for function get_source
def test_get_source():
    def f(): pass

    assert get_source(f) == 'def f(): pass'

# Generated at 2022-06-23 23:35:47.260744
# Unit test for function debug
def test_debug():
    debug(lambda: 'test message')

# Generated at 2022-06-23 23:35:51.501522
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("variable") == "_py_backwards_variable_0"
    assert VariablesGenerator.generate("variable") == "_py_backwards_variable_1"
    assert VariablesGenerator.generate("variable") == "_py_backwards_variable_2"

# Generated at 2022-06-23 23:35:54.769363
# Unit test for function warn
def test_warn():
    out = StringIO()
    sys.stderr = out

    warn("Test warning")

    sys.stderr = sys.__stderr__
    assert out.getvalue() == messages.warn("Test warning") + "\n"


# Generated at 2022-06-23 23:35:56.594099
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('Something is not right')
    assert sys.stderr.getvalue().strip() == messages.warn('Something is not right')

# Generated at 2022-06-23 23:35:59.332258
# Unit test for function eager
def test_eager():

    @eager
    def _test_func():
        i = 0
        while i < 10:
            i += 1
            yield i
    assert _test_func() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 23:36:01.080475
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(5):
            yield i
    foo = eager(foo)
    assert (foo() == [0, 1, 2, 3, 4])

# Generated at 2022-06-23 23:36:03.038044
# Unit test for function get_source
def test_get_source():
    def foo():
        pass



# Generated at 2022-06-23 23:36:05.305160
# Unit test for function warn
def test_warn():
    result = messages.warn("test message")
    expected = "Warning: test message"
    assert result == expected



# Generated at 2022-06-23 23:36:10.674946
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        with patch('sys.stderr') as mock_stderr:
            debug(lambda: 'foo')
            assert mock_stderr.write.called
            assert 'foo' in mock_stderr.write.call_args[0][0]
            assert mock_stderr.flush.called
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:36:14.238307
# Unit test for function eager
def test_eager():
    def range_function_with_different_value():
        yield 1
        yield 2
        yield 3
        yield 4
        yield 5

    assert eager(range_function_with_different_value)() == [1, 2, 3, 4, 5]

# Generated at 2022-06-23 23:36:16.551189
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-23 23:36:23.084121
# Unit test for function debug
def test_debug():
    class Mock:
        def __init__(self):
            self.calls = []

        @debug
        def call(self, ga) -> str:
            self.calls.append(ga)
            return 'This is a debug message'

    m = Mock()
    m.call(3)
    assert m.calls == [3]

    m.call(8)
    assert m.calls == [3, 8]

    # Actually the output is done to stderr, but there is no way to capture it,
    # so just assert that bool(stdout) == False
    assert not bool(sys.stdout.getvalue())

# Generated at 2022-06-23 23:36:26.692547
# Unit test for function get_source
def test_get_source():
    def foo(a, b=2, *c, **d) -> int:
        return a + b

    fn_src = get_source(foo)
    assert fn_src == 'return a + b'



# Generated at 2022-06-23 23:36:32.030960
# Unit test for function warn
def test_warn():
    # Arrange
    message = 'Message to warn'
    err = sys.stderr
    sys.stderr = open('test_warn.txt', 'w')
    # Act
    warn(message)
    sys.stderr.close()
    sys.stderr = err
    f = open('test_warn.txt')
    res = f.readline()
    f.close()

    # Assert
    assert res[:len(messages.warn(''))] == messages.warn('')
    assert res[len(messages.warn('')):] == message + '\n'

# Generated at 2022-06-23 23:36:34.866695
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var1 = VariablesGenerator.generate('var1')
    var2 = VariablesGenerator.generate('var2')
    assert var1 != var2

# Generated at 2022-06-23 23:36:35.424667
# Unit test for function warn
def test_warn():
    warn('Test')



# Generated at 2022-06-23 23:36:36.806931
# Unit test for function get_source
def test_get_source():
    def func(): pass
    print(get_source(func))



# Generated at 2022-06-23 23:36:39.474234
# Unit test for function eager
def test_eager():
    @eager
    def numbers():
        yield 1
        yield 2
        yield 3

    assert numbers() == [1, 2, 3]



# Generated at 2022-06-23 23:36:41.747307
# Unit test for function eager
def test_eager():
    from pytest import raises

    @eager
    def foo():
        yield 1
        raise Exception()
        yield 1

    assert foo() == [1]
    with raises(Exception):
        foo()

# Generated at 2022-06-23 23:36:45.783834
# Unit test for function warn
def test_warn():
    global messages
    def f():
        global messages
        messages.warn = lambda s: s
        warn('Hello World!')
    with StdoutIO() as s:
        f()
    assert s.getvalue() == 'Hello World!\n'



# Generated at 2022-06-23 23:36:48.085470
# Unit test for function warn
def test_warn():
    import sys
    sys.argv.append('--debug')
    warn('tset')
    sys.argv.remove('--debug')

# Generated at 2022-06-23 23:36:50.903482
# Unit test for function eager
def test_eager():
    from itertools import count
    @eager
    def test_eager(x: int) -> range:
        return range(x)

    assert test_eager(10) == list(range(10))

# Generated at 2022-06-23 23:36:58.346801
# Unit test for function debug
def test_debug():
    assert settings.debug

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

        def __exit__(self, *args) -> None:
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio
            sys.stdout = self._stdout

    with Capturing() as output:
        debug(lambda: "test debug message")
        assert len(output) == 1
        assert output[0] == '  ' + messages.debug("test debug message")
    with Capturing() as output:
        debug(lambda: "test debug message")
        assert len(output) == 0



# Generated at 2022-06-23 23:37:02.118494
# Unit test for function warn
def test_warn():
    with mock.patch('sys.stderr', new_callable=io.StringIO) as captured:
        warn('Message')

        assert captured.getvalue() == messages.warn('Message') + '\n'



# Generated at 2022-06-23 23:37:04.651166
# Unit test for function eager
def test_eager():
    def some_stuff() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert some_stuff() == [1, 2, 3]

# Generated at 2022-06-23 23:37:07.179993
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg1 = VariablesGenerator()
    assert vg1._counter == 1
    vg2 = VariablesGenerator()
    assert vg2._counter == 1

# Generated at 2022-06-23 23:37:11.313322
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('i') == '_py_backwards_i_0'
    assert VariablesGenerator.generate('i') == '_py_backwards_i_1'
    assert VariablesGenerator.generate('j') == '_py_backwards_j_2'


# Generated at 2022-06-23 23:37:13.993416
# Unit test for function warn
def test_warn():
    import io
    buf = io.StringIO()
    sys.stderr = buf
    warn('Test warning')
    sys.stderr = sys.__stderr__
    assert buf.getvalue().strip() == 'Warning: Test warning'



# Generated at 2022-06-23 23:37:16.677347
# Unit test for function warn
def test_warn():
    import io

    output = io.StringIO()
    with redirect_stderr(output):
        warn('test')
    assert output.getvalue() == '\x1b[93m<-- test\x1b[0m\n'



# Generated at 2022-06-23 23:37:26.692953
# Unit test for function warn
def test_warn():
    import math
    from io import StringIO
    from contextlib import contextmanager
    from contextlib import redirect_stderr

    @contextmanager
    def capture():
        out, sys.stderr = sys.stderr, StringIO()
        yield sys.stderr
        sys.stderr = out

    with capture() as f:
        warn("hello")
    output = f.getvalue()
    assert(output.startswith("\x1b[33mWarning"))
    assert(output.endswith("\x1b[0m\n"))

    with capture() as f2:
        math.sqrt(9)
    output = f2.getvalue()
    assert(output == "")

test_warn()

# Generated at 2022-06-23 23:37:28.698858
# Unit test for function get_source
def test_get_source():
    def test(): return ''
    assert get_source(test) == 'def test(): return \'\'\n'


# Generated at 2022-06-23 23:37:31.012192
# Unit test for function eager
def test_eager():
    from random import randint

    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield randint(0, 9)

    assert gen(5) == [randint(0, 9) for _ in range(5)]



# Generated at 2022-06-23 23:37:33.319355
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        return a + b

    assert get_source(func) == dedent('''
        return a + b
    ''')



# Generated at 2022-06-23 23:37:43.852635
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out = StringIO()
        old_out = sys.stdout
        try:
            sys.stdout = new_out
            yield new_out
        finally:
            sys.stdout = old_out

    def test_debug_enabled():
        settings.debug = True
        message = 'Message when debug is enabled'

        with captured_output() as out:
            debug(lambda: message)

        stdout_message = out.getvalue().strip()
        assert stdout_message == messages.debug(message)

    def test_debug_disabled():
        settings.debug = False
        message = 'Message when debug is enabled'


# Generated at 2022-06-23 23:37:46.584322
# Unit test for function eager
def test_eager():
    def no_eager(a, b):
        yield a
        yield b

    def eager_func(a, b):
        return no_eager(a, b)

    assert eager(eager_func)(2, 3) == [2, 3]

# Generated at 2022-06-23 23:37:47.860177
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'pass'

# Generated at 2022-06-23 23:37:49.997331
# Unit test for function get_source
def test_get_source():
    def func():  # @NoCover
        """Function doc."""
        return
    assert get_source(func) == 'def func():\n    """Function doc."""\n    return'



# Generated at 2022-06-23 23:37:52.825031
# Unit test for function get_source
def test_get_source():
    def foo(bar=None):
        def baz():
            pass


    assert get_source(foo) == 'def foo(bar=None):\n    def baz():\n        pass'



# Generated at 2022-06-23 23:38:00.075554
# Unit test for function warn
def test_warn():
    from io import StringIO
    from .conf import Settings

    settings.debug = False

    with StringIO() as buffer:
        sys.stderr = buffer

        warn('warning message')
        assert buffer.getvalue() == '\x1b[33mwarning message\x1b[0m\n'

        buffer.seek(0)
        buffer.truncate(0)

    settings.debug = True
    with StringIO() as buffer:
        sys.stderr = buffer

        warn('warning message')
        assert buffer.getvalue() == '\x1b[33mwarning message\x1b[0m\n'

        buffer.seek(0)
        buffer.truncate(0)



# Generated at 2022-06-23 23:38:03.601446
# Unit test for function get_source
def test_get_source():

    def function():
        if True:
            pass

        if True:
            foo = 'bar'

    assert get_source(function) == "if True:\n    pass\n\nif True:\n    foo = 'bar'"



# Generated at 2022-06-23 23:38:04.691863
# Unit test for function warn
def test_warn():
    messages.warn = lambda x: x
    assert warn('1') is None
    messages.warn = messages._warn

# Generated at 2022-06-23 23:38:07.087917
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    f = StringIO()
    with redirect_stderr(f):
        warn("test")
        assert f.getvalue() == "PyBackwards Warning:  test\n"
        assert f.getvalue() != "test\n"


# Generated at 2022-06-23 23:38:08.554938
# Unit test for function get_source
def test_get_source():
    def f():
        return 1


assert get_source(f) == 'return 1'

# Generated at 2022-06-23 23:38:17.495093
# Unit test for function warn
def test_warn():
    import sys
    from io import StringIO
    from functools import partial

    message = 'message'

    out = StringIO()
    err = StringIO()
    old_stdout = sys.stdout
    sys.stdout = old_stdout
    sys.stderr = err
    try:
        warn(message)
    finally:
        sys.stdout = old_stdout

    assert out.getvalue() == ''
    assert err.getvalue() == messages.warn(message) + '\n'

    # Test that message is printed, even if there is exception in the caller.
    def _test_exception():
        warn(message)
        raise Exception

    out = StringIO()
    err = StringIO()
    old_stdout = sys.stdout
    sys.stdout = old_stdout


# Generated at 2022-06-23 23:38:20.689118
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('a') == '_py_backwards_a_0'
    assert gen.generate('b') == '_py_backwards_b_1'

# Generated at 2022-06-23 23:38:26.824194
# Unit test for function debug
def test_debug():
    warn_output = open('warn.out', 'w')
    try:
        settings.debug = False
        debug(lambda: 'message')
        assert open('warn.out', 'r').read() == ''
        settings.debug = True
        debug(lambda: 'message')
        assert open('warn.out', 'r').read() == messages.debug('message') + '\n'
    finally:
        settings.debug = False
        warn_output.close()

# Generated at 2022-06-23 23:38:28.856606
# Unit test for function eager
def test_eager():
    @eager
    def function():
        yield 1
        yield 2
        yield 3

    assert function() == [1, 2, 3]

# Generated at 2022-06-23 23:38:32.657708
# Unit test for function get_source
def test_get_source():
    def test_fn(a_, _b, __c):
        pass
    assert test_fn.__name__ == 'test_fn'
    expected = 'def test_fn(a_, _b, __c):'
    assert get_source(test_fn).startswith(expected)

# Generated at 2022-06-23 23:38:34.533960
# Unit test for function get_source
def test_get_source():
    def test():
        return 'Test function'
    assert get_source(test) == 'return \'Test function\''

# Generated at 2022-06-23 23:38:43.472397
# Unit test for function get_source
def test_get_source():
    import re
    import sys
    pattern = re.compile(r'\s*return.*\n')

    def some_function():
        # This will be stripped
        a = 1
        return a

    def test_function():
        # This won't
        return 1

    def other():
        # Get me
        return 2

    def some_other_function():
        # This will be stripped too
        a = 1
        return a

    lines = getsource(test_function).split('\n')
    assert len(lines) == 2
    assert not pattern.match(lines[0])
    assert pattern.match(lines[1])

    assert getsource(some_function) == getsource(some_other_function)
    assert get_source(test_function), '\n'.join(lines)

# Generated at 2022-06-23 23:38:47.940394
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'



# Generated at 2022-06-23 23:38:50.090438
# Unit test for function get_source
def test_get_source():
    def test():
        return 1
    assert get_source(test) == 'return 1'


# Unit-test for function eager

# Generated at 2022-06-23 23:38:51.388317
# Unit test for function debug
def test_debug():
    debug(lambda: "DEBUG MESSAGE")


# Generated at 2022-06-23 23:38:53.606913
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        for i in range(1, 5):
            yield i

    assert(list(generator()) == [1, 2, 3, 4])

# Generated at 2022-06-23 23:38:55.054941
# Unit test for function debug
def test_debug():
  def get_message():
    return "A message"
  print("")
  debug(get_message)

# Generated at 2022-06-23 23:38:56.725517
# Unit test for function eager
def test_eager():
    lst = [1, 2, 3]
    assert eager(lambda e: e for e in lst)() == list(e for e in lst)

# Generated at 2022-06-23 23:38:57.718103
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == list(range(10))

# Generated at 2022-06-23 23:39:01.105694
# Unit test for function eager
def test_eager():
    from .. import conf
    from ..utils import eager_eval
    conf.debug = True

    @eager
    def test():
        for i in range(10):
            yield i
        for i in range(10, 0, -1):
            yield i

    print(test())

# Generated at 2022-06-23 23:39:03.693022
# Unit test for function get_source
def test_get_source():
    def fn(a, b=1, *args, **kwargs):
        pass

    expected = 'def fn(a, b=1, *args, **kwargs):\n' \
               '    pass\n'

    result = get_source(fn)

    assert result == expected



# Generated at 2022-06-23 23:39:08.195032
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:39:11.661044
# Unit test for function debug
def test_debug():
    settings.debug = True
    counter = [0]

    def get_message():
        counter[0] += 1
        return str(counter[0])
    debug(get_message)
    assert counter == [1]

# Generated at 2022-06-23 23:39:19.721140
# Unit test for function debug
def test_debug():
    from unittest.mock import call
    from .. import conf

    conf.settings.debug = True
    try:
        import sys
        from unittest.mock import Mock

        mock_sys = Mock(sys)
        sys = mock_sys
        try:
            debug(lambda: 'Hi!')
            assert mock_sys.stderr.write.call_args == call(messages.debug('Hi!'))
        finally:
            sys = mock_sys.__class__.__bases__[0]
            del mock_sys

    finally:
        conf.settings.debug = False



# Generated at 2022-06-23 23:39:21.967503
# Unit test for function get_source
def test_get_source():
    def size(data):
        return len(data)

    def test_function():
        pass

    assert get_source(size) == 'return len(data)'
    assert get_source(test_function) == ''

# Generated at 2022-06-23 23:39:28.967859
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == "def test_function():\n    pass"

    def test_function_with_doc_string():
        '''
        This is a doc string.
        '''
        pass
    assert get_source(test_function_with_doc_string) == \
        "def test_function_with_doc_string():\n    '''\n    This is a doc string.\n    '''\n    pass"

# Generated at 2022-06-23 23:39:35.652128
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    assert a.generate('asd') == '_py_backwards_asd_0'
    assert a.generate('dsa') == '_py_backwards_dsa_1'
    b = VariablesGenerator()
    assert b.generate('asd') == '_py_backwards_asd_2'
    assert b.generate('dsa') == '_py_backwards_dsa_3'

# Generated at 2022-06-23 23:39:45.055546
# Unit test for function get_source
def test_get_source():
    import pytest
    from pytest_backwards.utils import get_source
    fn_1 = lambda x, y: x ** y

    fn_2 = lambda x, y: (x * y * 2) ** 2

    def fn_3(x, y):
        return x ** 2 if y else x + y

    def fn_4(x, y):
        return x ** (y if y else 2)

    def fn_5(x, y, z=10):
        return x if y else z

    def fn_6(x: int, y: int) -> int:
        return x + y

    def fn_7(x, y, z=10):
        """
        Function with information about it.
        """
        return x + y + z


# Generated at 2022-06-23 23:39:48.425237
# Unit test for function get_source
def test_get_source():
    def get_source_test():
        """Returns source code of the function, which is lazy."""
        return get_source(get_source)

    assert get_source_test().startswith("    def get_source_test():")

# Generated at 2022-06-23 23:39:50.168105
# Unit test for function debug
def test_debug():
    def f():
        debug(lambda: 'test')

    assert f.__name__ == 'f'

# Generated at 2022-06-23 23:39:56.281300
# Unit test for function warn
def test_warn():
    warn('It\'s just a test')
    expected_warn = 'py-backwards-warn -- It\'s just a test'
    with open(os.devnull, 'w') as f:
        with redirect_stderr(f):
            print(sys.stderr.read().strip())
    # TODO
    # assert sys.stderr.read().strip() == expected_warn

# Generated at 2022-06-23 23:39:59.234906
# Unit test for function warn
def test_warn():
    captured_output = StringIO()
    sys.stderr = captured_output
    warn('message')
    assert captured_output.getvalue() == 'py-backwards: warning: message\n'


# Generated at 2022-06-23 23:40:05.172459
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == "_py_backwards_x_0"
    assert VariablesGenerator.generate("x") == "_py_backwards_x_1"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_2"
    assert VariablesGenerator.generate("x") == "_py_backwards_x_3"
    assert VariablesGenerator.generate("y") == "_py_backwards_y_4"

test_VariablesGenerator()


# Generated at 2022-06-23 23:40:07.020410
# Unit test for function eager
def test_eager():
    def fn():
        yield 1
        yield 2
    assert eager(fn)() == [1, 2]

# Generated at 2022-06-23 23:40:10.229754
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    b = VariablesGenerator()
    print(a.generate('test1'))
    print(b.generate('test1'))

# Generated at 2022-06-23 23:40:11.355724
# Unit test for function debug
def test_debug():
    debug(lambda: 'message')

# Generated at 2022-06-23 23:40:12.750531
# Unit test for function eager
def test_eager():
    assert eager(lambda: [4, 5, 6])() == [4, 5, 6]

# Generated at 2022-06-23 23:40:14.951784
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(100):
        assert VariablesGenerator.generate('') == '_py_backwards_{}_{}'.format('', i)

# Generated at 2022-06-23 23:40:19.081469
# Unit test for function eager
def test_eager():
    from hamcrest.core import assert_that
    from hamcrest.library.collection.issequence_onlycontaining import contains_inanyorder

    @eager
    def foo(n):
        for i in range(n):
            yield i

    assert_that(foo(5), contains_inanyorder(0, 1, 2, 3, 4))

# Generated at 2022-06-23 23:40:20.332610
# Unit test for function eager
def test_eager():
    assert eager(range(2))() == [0, 1]

# Generated at 2022-06-23 23:40:23.208496
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vars = []
    for i in range(100):
        vars.append(VariablesGenerator.generate('tmp'))
    assert len(set(vars)) == len(vars)

# Generated at 2022-06-23 23:40:32.937371
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from .. import conf
    conf.settings.debug = True
    debug_info = []
    original_debug = debug
    def mock_debug(get_message):
        debug_info.extend(get_message().split('\n'))
    debug = mock_debug
    try:
        assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
        assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
        assert VariablesGenerator.generate('test') == '_py_backwards_test_2'
    finally:
        debug = original_debug
    assert len(debug_info) == 1
    assert 'unit test' in debug_info[0]
    assert 'VariablesGenerator' in debug_info[0]

# Generated at 2022-06-23 23:40:33.518854
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-23 23:40:35.293521
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == "def f():\n    pass"

# Generated at 2022-06-23 23:40:39.259173
# Unit test for function debug
def test_debug():
    _debug_message_log = []
    _debug_message = 'Message'

    settings.debug = False
    debug(lambda: _debug_message)
    assert not _debug_message_log

    settings.debug = True
    debug(lambda: _debug_message)
    assert _debug_message_log and _debug_message_log[0] == messages.debug(_debug_message)

# Generated at 2022-06-23 23:40:41.713429
# Unit test for function eager
def test_eager():
    from collections.abc import Iterable
    @eager
    def a() -> Iterable[int]:
        for i in range(10):
            yield i

    assert type(a()) == list

# Generated at 2022-06-23 23:40:46.893167
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_0'
    assert VariablesGenerator.generate('abc') == '_py_backwards_abc_1'
    assert VariablesGenerator.generate('xyz') == '_py_backwards_xyz_2'


# Generated at 2022-06-23 23:40:49.788210
# Unit test for function eager
def test_eager():
    import pytest

    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-23 23:40:54.726158
# Unit test for function debug
def test_debug():
    assert not settings.debug
    debug(lambda: 'x')
    settings.debug = True
    calls = []
    def get_message():
        calls.append(True)
        return 'x'
    debug(get_message)
    assert len(calls) == 1
    debug(get_message)
    assert len(calls) == 2

# Generated at 2022-06-23 23:40:58.903696
# Unit test for function eager
def test_eager():
    assert eager(sum)([1, 2, 3, 4], 0) == [10]
    assert eager(range)(8) == [0, 1, 2, 3, 4, 5, 6, 7]
    assert eager(range)(3, 8) == [3, 4, 5, 6, 7]

# Generated at 2022-06-23 23:41:07.656179
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    class Settings:
        debug = False

    # When setting is disabled, function do nothing
    stderr = StringIO()
    with redirect_stream(stderr, sys.stderr):
        debug(lambda: 'test')

    assert stderr.getvalue() == ''

    # When setting is enabled, function prints message to stderr
    stderr = StringIO()
    with redirect_stream(stderr, sys.stderr):
        debug(lambda: 'test')

    assert stderr.getvalue() == 'test\n'



# Generated at 2022-06-23 23:41:08.919874
# Unit test for function get_source
def test_get_source():
    def func():
        return [1, 2, 3]


# Generated at 2022-06-23 23:41:14.766323
# Unit test for function debug
def test_debug():
    value = []

    def get_message():
        value.append(1)
        return 'This message should be printed only once'

    old_debug = settings.debug
    settings.debug = True
    debug(get_message)
    assert value == [1]
    debug(get_message)
    assert value == [1]

    settings.debug = False
    debug(get_message)
    assert value == [1]
    debug(get_message)
    assert value == [1]

    settings.debug = old_debug



# Generated at 2022-06-23 23:41:19.068734
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('c') == '_py_backwards_c_0'
    assert generator.generate('c') == '_py_backwards_c_1'
    assert generator.generate('x') == '_py_backwards_x_2'


# Generated at 2022-06-23 23:41:20.533093
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == inspect.getsource(foo)



# Generated at 2022-06-23 23:41:22.785317
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    variables = [generator.generate('name') for _ in range(100)]
    assert len(set(variables)) == 100

# Generated at 2022-06-23 23:41:26.700663
# Unit test for function warn
def test_warn():
    # pylint: disable=protected-access
    original_stderr = sys.stderr
    try:
        f = StringIO()
        sys.stderr = f

        warn("sssss")
        assert f.getvalue() == "INFO:py_backwards:sssss\n"
    finally:
        sys.stderr = original_stderr

# Generated at 2022-06-23 23:41:29.032106
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2

    for x, y in zip(f(), eager(f())):
        assert x == y

# Generated at 2022-06-23 23:41:34.742200
# Unit test for function warn
def test_warn():
    import io
    import sys

    default_stderr = sys.stderr
    sys.stderr = io.StringIO()

    try:
        warn('test_warn')
        assert sys.stderr.getvalue() == '\x1b[33mtest_warn\x1b[0m\n'
    finally:
        sys.stderr = default_stderr

# Generated at 2022-06-23 23:41:37.476812
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(10):
        gen = VariablesGenerator()
        assert gen.generate('foo') == f'_py_backwards_foo_{i}'

# Generated at 2022-06-23 23:41:39.690067
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2

    assert eager(test_fn)() == [1, 2]

# Generated at 2022-06-23 23:41:44.153489
# Unit test for function warn
def test_warn():
    print = MagicMock()
    warn('foo')
    assert_equal(print.call_args[0][0], messages.warn('foo')) # pylint: disable=unsubscriptable-object, no-member



# Generated at 2022-06-23 23:41:47.724702
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate("variable") == '_py_backwards_variable_0'
    assert generator.generate("variable") == '_py_backwards_variable_1'

# Generated at 2022-06-23 23:41:51.726538
# Unit test for function warn
def test_warn():
    with captured_output() as (out, err):
        warn('This is warn')
    output = err.getvalue().strip()
    assert(output == '\x1b[33mThis is warn\x1b[0m')


# Generated at 2022-06-23 23:41:55.864839
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'


# Generated at 2022-06-23 23:41:57.744648
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1

    foo = get_source(foo)

    assert foo == 'return 1\n'



# Generated at 2022-06-23 23:41:59.168264
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-23 23:42:02.046548
# Unit test for function debug
def test_debug():
    for verbose in (True, False):
        settings.debug = verbose
        message = []

        def get_message() -> str:
            message.append(True)
            return 'xxx'

        debug(get_message)
        if verbose:
            assert message != []
        else:
            assert message == []

# Generated at 2022-06-23 23:42:06.264212
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("test") == '_py_backwards_test_0'
    assert VariablesGenerator.generate("test") == '_py_backwards_test_1'
    assert VariablesGenerator.generate("test") == '_py_backwards_test_2'

