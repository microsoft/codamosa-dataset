

# Generated at 2022-06-23 23:32:04.898481
# Unit test for function warn
def test_warn():
    import io
    import sys
    from contextlib import redirect_stderr
    output = io.StringIO()
    with redirect_stderr(output):
        warn('Hello')
    assert output.getvalue().strip() == messages.warn('Hello')


# Generated at 2022-06-23 23:32:07.007311
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate("var") == "_py_backwards_var_0"
    assert gen.generate("var") == "_py_backwards_var_1"


# Generated at 2022-06-23 23:32:14.937618
# Unit test for function warn
def test_warn():
    import io
    out = io.StringIO()
    warn('message')
    assert out.getvalue() == 'PyBackwards: warning: message\n'
    optimize = settings.optimize
    settings.optimize = True
    warn('message')
    assert out.getvalue() == 'PyBackwards: warning: message\n'
    out.seek(0)
    out.truncate()
    settings.optimize = False
    warn('message')
    assert out.getvalue() == 'PyBackwards: warning: message\n'
    settings.optimize = optimize
    del optimize


# Generated at 2022-06-23 23:32:18.214038
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        c = a + b
        return c

    assert get_source(foo) == dedent(
        """
        def foo(a, b):
            c = a + b
            return c
        """
    )

# Generated at 2022-06-23 23:32:20.480371
# Unit test for function eager
def test_eager():
    def partial(x, y, z):
        for i in [x, y, z]:
            yield i
    print(eager(partial)(1, 2, 3))

# Generated at 2022-06-23 23:32:21.802966
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
    assert gen() == [1, 2]


# Generated at 2022-06-23 23:32:23.342959
# Unit test for function get_source
def test_get_source():
    def hello():
        return 'Hello!'
    assert get_source(hello) == "return 'Hello!'"

# Generated at 2022-06-23 23:32:29.394973
# Unit test for function eager
def test_eager():
    from functools import reduce
    from operator import add  # type: ignore

    @eager
    def test(numbers: Iterable[int]) -> Iterable[int]:
        yield from numbers

    result = test(range(10))
    assert result == list(range(10))
    assert isinstance(result, list)
    assert reduce(add, test(range(150)), 0) == reduce(add, range(150), 0)

# Generated at 2022-06-23 23:32:33.144881
# Unit test for function get_source
def test_get_source():
    def test():
        def innertest(a: int, b: int) -> int:
            return a + b
        return innertest
    assert get_source(test()) == 'def innertest(a: int, b: int) -> int:\n    return a + b'

# Generated at 2022-06-23 23:32:34.100118
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello!')

# Generated at 2022-06-23 23:32:36.899622
# Unit test for function eager
def test_eager():
    @eager
    def foo(x: int) -> Iterable[int]:
        for i in range(x):
            yield i
    assert foo(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:32:39.322849
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    for _ in range(1, 1000):
        generator.generate("a")


# Generated at 2022-06-23 23:32:42.634182
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('x') == '_py_backwards_x_0'
    assert gen.generate('x') == '_py_backwards_x_1'

# Generated at 2022-06-23 23:32:51.058520
# Unit test for function get_source
def test_get_source():
    def test_function(a: int, b: float) -> int:
        return int(a + b)

    def test_function_with_decorator(a: int, b: float) -> int:
        return int(a + b)

    source = get_source(test_function)
    source_with_decorator = get_source(test_function_with_decorator)
    test_function_with_decorator = eager(test_function_with_decorator)

    assert(source == source_with_decorator)
    assert(source == 'return int(a + b)')
    assert(test_function(1, 2.0) == test_function_with_decorator(1, 2.0))

# Generated at 2022-06-23 23:32:54.217151
# Unit test for function debug
def test_debug():
    __tracebackhide__ = True
    from . import testcase

    class TestSettings:
        debug = True

    settings = TestSettings()
    with testcase.CaptureStderr() as c:
        debug(lambda: 'test')
    assert c.getvalue() == '\x1b[33m=== DEBUG (test.py) ' \
                           '===\n    test\n' \
                        '=== END ===\x1b[0m\n'



# Generated at 2022-06-23 23:32:55.193917
# Unit test for function warn
def test_warn():
    warn('test warn')
test_warn()


# Generated at 2022-06-23 23:32:57.774780
# Unit test for function get_source
def test_get_source():
    # GIVEN
    def fn(a: int, b: int) -> int:
        return a + b

    # WHEN
    actual_source = get_source(fn)

    # THEN
    expected_source = \
        r"""return a + b"""
    assert actual_source == expected_source

# Generated at 2022-06-23 23:33:01.065022
# Unit test for function get_source
def test_get_source():
    def dummy():
        """This is a dummy function for testing purposes."""
        if True:
            return 'Hello'

    source_lines = get_source(dummy).split('\n')
    assert source_lines[0] == 'if True:'
    assert source_lines[1] == "    return 'Hello'"

# Generated at 2022-06-23 23:33:03.384181
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]

    def f():
        global l
        for i in l:
            yield i

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-23 23:33:08.372644
# Unit test for function warn
def test_warn():
    from io import StringIO

    buf = StringIO()
    sys.stderr = buf

    warn('yay')

    assert buf.getvalue() == '\033[1;33;40m[PyBackwards] \033[0;33;40mWarning: yay\033[0m\n'

    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:33:12.403526
# Unit test for function eager
def test_eager():
    a = {0: False}
    @eager
    def f():
        for i in range(5):
            if a[0]:
                yield i

    assert f() == []
    a[0] = True
    assert f() == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:33:14.414081
# Unit test for function eager
def test_eager():
    def function():
        yield 1
        yield 2
        yield 3

    assert function() == eager(function)()



# Generated at 2022-06-23 23:33:16.873728
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('hello') == '_py_backwards_hello_1'
    assert VariablesGenerator.generate('hello') == '_py_backwards_hello_2'


# Generated at 2022-06-23 23:33:18.723200
# Unit test for function warn
def test_warn():
    assert settings.debug == False
    warn('test')
    assert settings.debug == False


# Generated at 2022-06-23 23:33:20.063466
# Unit test for function get_source
def test_get_source():
    def f(): pass
    assert get_source(f) == 'def f(): pass'

# Generated at 2022-06-23 23:33:26.710978
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg1 = VariablesGenerator()
    assert vg1.generate("a") == "_py_backwards_a_0"
    assert vg1.generate("b") == "_py_backwards_b_1"

    vg2 = VariablesGenerator()
    assert vg2.generate("c") == "_py_backwards_c_2"
    assert vg2.generate("d") == "_py_backwards_d_3"


# Generated at 2022-06-23 23:33:30.734894
# Unit test for function warn
def test_warn():
    import pytest
    captured_messages: List[str] = []
    def capture_prints(text: str, *args: Any) -> None:
        captured_messages.append(text)
    sys.stderr.write = capture_prints
    warn('Test warn')
    assert captured_messages == ['py-backwards WARNING: Test warn']


# Generated at 2022-06-23 23:33:34.754847
# Unit test for function eager
def test_eager():
    def fib(n):
        if n < 2:
            return [n]
        else:
            return fib(n - 1) + fib(n - 2)
    assert eager(fib)(10) == [0, 1, 1, 2, 3, 5, 8]

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:33:38.583254
# Unit test for function warn
def test_warn():
    captured_output = io.StringIO()
    sys.stderr = captured_output
    warn('message')
    assert captured_output.getvalue() == messages.warn('message') + '\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:33:40.319425
# Unit test for function debug
def test_debug():
    """Runs unit tests for function debug."""
    debug(lambda: 'Hello, world!')



# Generated at 2022-06-23 23:33:42.279101
# Unit test for function warn
def test_warn():
    import sys
    import contextlib
    with contextlib.redirect_stderr(sys.stdout):
        warn('Test warn function')

# Generated at 2022-06-23 23:33:45.177153
# Unit test for function warn
def test_warn():
    sys.stderr = open('stderr_test_warn', 'w')
    warn('some message')
    sys.stderr.close()
    assert open('stderr_test_warn').readlines()[0] == '\x1b[31mPyBackwards: some message\x1b[0m\n'



# Generated at 2022-06-23 23:33:48.877792
# Unit test for function debug
def test_debug():
    debug_calls = []
    def get_debug_message():
        debug_calls.append(True)
        return 'test'
    settings.debug = True
    debug(get_debug_message)
    assert len(debug_calls) == 1



# Generated at 2022-06-23 23:33:55.771674
# Unit test for function get_source
def test_get_source():
    @wraps(test_get_source)
    def unit_test_get_source():
        fn = get_source

        def test_fn():
            """
                Function with multiple lines docstring.
            """
            return None

        assert len(fn(test_fn).split('\n')) == 4, 'get_source does not strip multi-line docstring indentation'
        assert len(fn(test_fn).split('\n')) == 4, 'get_source does not strip single-line docstring indentation'

    unit_test_get_source()

# Generated at 2022-06-23 23:33:57.715083
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-23 23:33:58.699155
# Unit test for function debug
def test_debug():
    debug(lambda: 'debug message')


# Generated at 2022-06-23 23:34:03.533942
# Unit test for function debug
def test_debug():
    buffer = []
    def log(message: str) -> None:
        buffer.append(message)

    def test():
        print('123', file=sys.stdout)

    test()

    # Should print nothing
    debug(test)
    assert(buffer == [])

    # Should print the message
    settings.debug = True
    debug(test)
    assert(buffer == [messages.debug('123')])



# Generated at 2022-06-23 23:34:06.566759
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'
    assert VariablesGenerator.generate('z') == '_py_backwards_z_2'



# Generated at 2022-06-23 23:34:08.620196
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():\n    pass\n'



# Generated at 2022-06-23 23:34:10.819878
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'


# Generated at 2022-06-23 23:34:14.530909
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # When
    gen1 = VariablesGenerator.generate('var')
    gen2 = VariablesGenerator.generate('var')
    gen3 = VariablesGenerator.generate('hello')
    # Then
    assert gen1 == '_py_backwards_var_0'
    assert gen2 == '_py_backwards_var_1'
    assert gen3 == '_py_backwards_hello_2'

# Generated at 2022-06-23 23:34:18.882839
# Unit test for function debug
def test_debug():
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        try:
            sys.stderr = io.StringIO()
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    def test_debug_helper():
        settings.debug = False
        with capture_stderr() as out:
            debug(lambda: 'test_message')

        assert out.getvalue() == ''

        settings.debug = True
        with capture_stderr() as out:
            debug(lambda: 'test_message')

        assert out.getvalue().strip() == messages.debug('test_message')

    test_debug_helper()

# Generated at 2022-06-23 23:34:22.283881
# Unit test for function warn
def test_warn():
    def f():
        return 42
    assert warn(f()) == None


if __name__ == '__main__':
    import pytest
    pytest.main(['test_utils.py'])

# Generated at 2022-06-23 23:34:24.107864
# Unit test for function warn
def test_warn():
    import warnings
    warnings.filterwarnings('ignore')
    assert not warn('a')

# Generated at 2022-06-23 23:34:28.224993
# Unit test for function get_source
def test_get_source():
    def test():
        """This is a test function."""
        return 'This is a test!'

    assert get_source(test).strip() == '"""This is a test function."""\nreturn \'This is a test!\''

# Generated at 2022-06-23 23:34:29.295524
# Unit test for function warn
def test_warn():
    assert warn("Hello") is None



# Generated at 2022-06-23 23:34:31.951017
# Unit test for function warn
def test_warn():
    from unittest import mock
    with mock.patch('sys.stderr') as stderr:
        warn('test')
        assert stderr.write.called

# Generated at 2022-06-23 23:34:33.206741
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'


# Generated at 2022-06-23 23:34:43.265484
# Unit test for function debug
def test_debug():
    lines = []

    def fake_print(message: str, file: Any = sys.stderr) -> None:
        if file == sys.stderr:
            lines.append(message)

    def get_message() -> str:
        return 'some debug message'

    _std_debug = sys.modules['backwards.utils.debug']
    _std_print = sys.modules['backwards.utils.print']


# Generated at 2022-06-23 23:34:44.681183
# Unit test for function warn
def test_warn():
    mes = 'mes'
    assert warn(mes) == None


# Generated at 2022-06-23 23:34:47.074216
# Unit test for function eager
def test_eager():
    @eager
    def fn(n):
        yield n
        yield n+1
    assert fn(1) == [1, 2]

# Generated at 2022-06-23 23:34:50.082104
# Unit test for function eager
def test_eager():
    @eager
    def test() -> Iterable[int]:
        i = 0
        while i < 10:
            yield i
            i += 1

    assert list(range(10)) == test()

# Generated at 2022-06-23 23:34:52.452196
# Unit test for function eager
def test_eager():
    def dummy_fn(a, b):
        yield 4
        yield 2
        yield 1

    dummy_fn = eager(dummy_fn)
    assert dummy_fn('a', 'b') == [4, 2, 1]



# Generated at 2022-06-23 23:34:55.742226
# Unit test for function eager
def test_eager():
    @eager
    def increment_first_item(data: List[int]) -> Iterable[None]:
        data[0] += 1
        yield None

    data = [0]
    increment_first_item(data)
    assert data == [1]



# Generated at 2022-06-23 23:35:00.430684
# Unit test for function eager
def test_eager():
    def fibonacci(n):
        a,b = 0,1
        while a < n:
            yield a
            a,b = b,a+b
    fibonacci = eager(fibonacci)
    assert fibonacci(10) == [0,1,1,2,3,5,8]

# Generated at 2022-06-23 23:35:04.113352
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr

    with redirect_stderr(StringIO()) as err:
        warn("this is a test warning")
    assert err.getvalue().strip() == messages.warn("this is a test warning").strip()

# Generated at 2022-06-23 23:35:08.396844
# Unit test for function warn
def test_warn():
    import io
    import contextlib

    def test():
        warn('MESSAGE')

    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        test()

    assert f.getvalue() == '\033[33mWARNING: MESSAGE\033[0m\n'


# Generated at 2022-06-23 23:35:10.180554
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 'a'
        yield 'b'

    assert gen() == ['a', 'b']

# Generated at 2022-06-23 23:35:12.642327
# Unit test for function warn
def test_warn():
    message = 'Hello'
    warn(message)
    assert sys.stderr.getvalue() == '\x1b[93m[WARNING]\x1b[0m {}\n'.format(message)



# Generated at 2022-06-23 23:35:14.078231
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-23 23:35:14.587883
# Unit test for function warn
def test_warn():
    warn("test warn")

# Generated at 2022-06-23 23:35:18.966142
# Unit test for function warn
def test_warn():
    with mock.patch('sys.stderr', autospec=sys.stderr) as mock_stderr:
        warn('foo')
        mock_stderr.write.assert_called_once_with(
            messages.warn('foo') + '\n')

# Generated at 2022-06-23 23:35:29.016266
# Unit test for function get_source

# Generated at 2022-06-23 23:35:31.541311
# Unit test for function warn
def test_warn():
    message = "test message"
    orig_stderr = sys.stderr
    sys.stderr = bytes_io = io.BytesIO()
    warn(message)
    sys.s

# Generated at 2022-06-23 23:35:33.342387
# Unit test for function get_source
def test_get_source():
    def foo(a, b, c):
        return a + b + c

    assert get_source(foo) == 'return a + b + c'

# Generated at 2022-06-23 23:35:43.109366
# Unit test for function get_source

# Generated at 2022-06-23 23:35:47.465641
# Unit test for function warn
def test_warn():
    x = 1

    def warn_test():
        x = 2

    @backwards
    def test_warned(x: int):
        warnings.warn('test warning')

    def test():
        test_warned()

    test()
    assert x == 1

# Generated at 2022-06-23 23:35:53.758959
# Unit test for function warn
def test_warn():
    class TestStream:
        def __init__(self):
            self.buffer = []

        def __getattr__(self, attr):
            return getattr(sys.stderr, attr)

        def write(self, text):
            self.buffer.append(text)

    stream = TestStream()
    with patch('sys.stderr', stream):
        warn('test text')
        assert stream.buffer == [messages.warn('test text')]


# Generated at 2022-06-23 23:35:57.195453
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:36:01.084658
# Unit test for function get_source
def test_get_source():
    import inspect
    import pytest

    @staticmethod
    def function():
        return 1 + 1
    # NOTE: Don't use assert in this function
    # assert produces a runtime error in pytest.
    # I haven't found how to test it yet.
    if not inspect.getsource(function) == get_source(function):
        pytest.fail("get_source function doesn't work properly")

# Generated at 2022-06-23 23:36:03.878808
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-23 23:36:06.840873
# Unit test for function warn
def test_warn():
    sys.stdout.write("test_warn: ")
    try:
        warn("test_warn_message")
        print("OK")
    except:
        print("FAIL")

# Generated at 2022-06-23 23:36:09.737063
# Unit test for function warn
def test_warn():
    with io.StringIO() as buf, redirect_stderr(buf):
        warn('warning')
        assert buf.getvalue() == messages.warn('warning') + '\n'



# Generated at 2022-06-23 23:36:11.824320
# Unit test for function eager
def test_eager():
    def generator():
        yield 1
        yield 2
        yield 3

    assert eager(generator)() == [1, 2, 3]

# Generated at 2022-06-23 23:36:16.315409
# Unit test for function get_source
def test_get_source():
    from .test_util import test_util

    source_code = get_source(test_util)

    def _test():
        pass

    _test.__wrapped__ = _test
    _test.__code__ = test_util.__code__

    assert source_code == get_source(_test)



# Generated at 2022-06-23 23:36:20.159825
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('example') == '_py_backwards_example_0'
    assert VariablesGenerator.generate('example') == '_py_backwards_example_1'
    assert VariablesGenerator.generate('example') == '_py_backwards_example_2'

# Generated at 2022-06-23 23:36:30.305977
# Unit test for function eager
def test_eager():
    def simple_generator():
        for i in range(5):
            yield i

    assert eager(simple_generator)() == [i for i in range(5)]

    def generator_with_args(a, b):
        for i in range(5):
            yield a, b, i
    assert eager(generator_with_args)(1, 2) == [(1, 2, i) for i in range(5)]
    assert eager(generator_with_args)(1, 3) == [(1, 3, i) for i in range(5)]
    assert eager(generator_with_args)(2, 2) == [(2, 2, i) for i in range(5)]
    assert eager(generator_with_args)(2, 3) == [(2, 3, i) for i in range(5)]


# Generated at 2022-06-23 23:36:32.750843
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-23 23:36:35.526925
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('_')
    _ = VariablesGenerator.generate('_')
    assert a != _, "Two variables with similar names created"

# Generated at 2022-06-23 23:36:37.363442
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'

# Generated at 2022-06-23 23:36:40.672535
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('i') == '_py_backwards_i_0'
    assert VariablesGenerator.generate('i') == '_py_backwards_i_1'
    assert VariablesGenerator._counter == 2

# Generated at 2022-06-23 23:36:41.225041
# Unit test for function warn
def test_warn():
    warn('hello')

# Generated at 2022-06-23 23:36:43.280777
# Unit test for function eager
def test_eager():
    @eager
    def iterables():
        yield 1
        yield 2
    one, two = iterables()
    assert one == 1
    assert two == 2

# Generated at 2022-06-23 23:36:49.424405
# Unit test for function debug
def test_debug():
    from tempfile import TemporaryFile

    output = TemporaryFile()
    try:
        with patch('sys.stderr', output):
            settings.debug = True
            debug(lambda: 'message')
            settings.debug = False
            debug(lambda: 'message')
            output.seek(0)
            assert output.readlines() == [messages.debug('message') + '\n']

    finally:
        output.close()

# Generated at 2022-06-23 23:36:50.910315
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-23 23:36:54.910935
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    if VariablesGenerator.generate('string') == '_py_backwards_string_0':
        print('Test for class VariablesGenerator has passed!')
    else:
        print('Test for class VariablesGenerator has failed!')
    if VariablesGenerator.generate('string') == '_py_backwards_string_1':
        print('Test for class VariablesGenerator has passed!')
    else:
        print('Test for class VariablesGenerator has failed!')


# Generated at 2022-06-23 23:36:58.897821
# Unit test for function get_source
def test_get_source():
    def decorator(fn):
        def x():
            pass
    assert get_source(test_get_source) == 'def test_get_source():\n' \
                                          '    def decorator(fn):\n' \
                                          '        def x():\n' \
                                          '            pass'

# Generated at 2022-06-23 23:37:05.670522
# Unit test for function get_source
def test_get_source():
    def test_function(number: int, string: str = 'foobar') -> str:
        """Returns a string."""
        return '{}{}{}'.format(number, string, True)

    source = get_source(test_function)

# Generated at 2022-06-23 23:37:08.459984
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'



# Generated at 2022-06-23 23:37:10.157391
# Unit test for function get_source
def test_get_source():

    def test_function():
        return 1 + 2

    assert get_source(test_function) == 'return 1 + 2'

# Generated at 2022-06-23 23:37:11.398943
# Unit test for function warn
def test_warn():
    warn('Hello')
    assert 'Hello' in open("test_warn.txt").read()

# Generated at 2022-06-23 23:37:13.539573
# Unit test for function eager
def test_eager():
    @eager
    def lazy_list(x: int) -> Iterable[int]:
        yield x
        yield x + 1

    assert lazy_list(42) == [42, 43]

# Generated at 2022-06-23 23:37:14.825362
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2

    assert eager(f)() == [1, 2]

# Generated at 2022-06-23 23:37:16.048441
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello world')
    settings.debug = False

# Generated at 2022-06-23 23:37:17.397576
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    source_code = get_source(f)
    assert source_code == 'def f():\n    pass'

# Generated at 2022-06-23 23:37:28.174777
# Unit test for function debug
def test_debug():
    fake_stderr = io.StringIO()
    with contextlib.redirect_stderr(fake_stderr):
        fake_stderr.seek(0)
        fake_stderr.truncate(0)
        debug(lambda: 'debug')
        assert fake_stderr.getvalue() == ''

        settings.debug = True
        fake_stderr.seek(0)
        fake_stderr.truncate(0)
        debug(lambda: 'debug')
        assert fake_stderr.getvalue() == messages.debug('debug') + '\n'

        fake_stderr.seek(0)
        fake_stderr.truncate(0)
        fake_stderr.close()
        debug(lambda: 'debug')
        assert fake_stderr

# Generated at 2022-06-23 23:37:30.262177
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Test')
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:37:32.373056
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("a") == '_py_backwards_a_1'
    assert VariablesGenerator.generate("b") == '_py_backwards_b_2'


# Generated at 2022-06-23 23:37:34.410888
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'message')
    settings.debug = False
    debug(lambda: 'should not be printed')

# Generated at 2022-06-23 23:37:35.403639
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        pass


# Generated at 2022-06-23 23:37:38.412162
# Unit test for function eager
def test_eager():
    """Tests that function eager returns list."""
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert type(gen()) == list

# Generated at 2022-06-23 23:37:43.003408
# Unit test for function warn
def test_warn():
    import io
    import sys
    out = io.StringIO()
    sys.stderr = out

    warn('message')
    out.seek(0)
    assert out.read() == '\x1b[91mmessage\x1b[0m\n'

if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-23 23:37:48.566436
# Unit test for function debug
def test_debug():
    debug_message = "test message"
    def test_func():
        pass

    def get_message():
        return debug_message

    logger = mock.Mock()
    with mock.patch('sys.stderr', logger):
        settings.debug = True
        debug(get_message)
        logger.write.assert_called_with(f'[DEBUG] {debug_message}\n')
        logger.reset_mock()
        settings.debug = False
        debug(get_message)
        logger.write.assert_not_called()

# Generated at 2022-06-23 23:37:57.627365
# Unit test for function debug
def test_debug():
    class MockPrinter:
        def __init__(self):
            self.message = None
            self.called = False

        def write(self, message: str) -> None:
            self.message = message
            self.called = True

    fake_stderr = MockPrinter()
    old_stderr = sys.stderr
    sys.stderr = fake_stderr
    debug(lambda: 'value: {}'.format(47))

    assert fake_stderr.called
    assert fake_stderr.message == '\x1b[32mdebug: value: 47\x1b[0m'
    fake_stderr.called = False
    settings.debug = False
    debug(lambda: 'value: {}'.format(47))
    assert not fake_stderr.called
   

# Generated at 2022-06-23 23:38:02.495947
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'



# Generated at 2022-06-23 23:38:04.302091
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-23 23:38:05.494538
# Unit test for function warn
def test_warn():
    from pytest import warns
    with warns(None) as capture:
        warn("warn")
    assert any("WARN: pybackwards " in str(warning.message) for warning in capture)

# Generated at 2022-06-23 23:38:10.217816
# Unit test for function warn
def test_warn():
    from random import randint

    try:
        with settings.temp(warn_only=True):
            for i in range(0, 3):
                num = randint(0, 10)
                assert not sys.stderr.getvalue().startswith(messages.warn(str(num)))
                warn(str(num))
                assert sys.stderr.getvalue().startswith(messages.warn(str(num)))
                sys.stderr = StringIO()
    finally:
        settings.warn_only = False

# Generated at 2022-06-23 23:38:16.723635
# Unit test for function debug
def test_debug():
    from contextlib import redirect_stderr
    from io import StringIO

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        debug(lambda: 'test2')
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        with settings.use(debug=True):
            debug(lambda: 'test')
            debug(lambda: 'test2')
            assert stderr.getvalue() == messages.debug('test') + '\n' + messages.debug('test2') + '\n'



# Generated at 2022-06-23 23:38:19.604597
# Unit test for function get_source
def test_get_source():
    def foo(arg1, arg2):
        """Foo function."""
        x = arg1 + arg2
        return x
    return get_source(foo)

# Generated at 2022-06-23 23:38:21.902783
# Unit test for function get_source
def test_get_source():
    def source(x):
        return x * x

    assert get_source(source).strip() == 'return x * x'.strip()



# Generated at 2022-06-23 23:38:25.201452
# Unit test for function eager
def test_eager():
    @eager
    def foo() -> Iterable[int]:
        for i in range(10):
            yield i

    assert foo() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 23:38:29.828975
# Unit test for function warn
def test_warn():
    from . import messages
    from . import testing
    from . import utils
    from .conf import settings
    try:
        settings.colorize = False
        warn('test')
        assert testing.check_output('test\n')
    finally:
        utils.clear_by_lines()
        settings.colorize = messages.COLORIZE

# Generated at 2022-06-23 23:38:31.108208
# Unit test for function debug
def test_debug():
    assert debug(lambda: 'abc') is None


# Generated at 2022-06-23 23:38:31.869044
# Unit test for function warn
def test_warn():
    warn('Message')



# Generated at 2022-06-23 23:38:34.222374
# Unit test for function get_source
def test_get_source():
    def f():
        def g():
            def h():
                return 3

            r = h()
            return r + 1

        return g() + 2

    assert get_source(f) == inspect.getsource(f)

# Generated at 2022-06-23 23:38:35.619995
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == "def f():\n    pass"

# Generated at 2022-06-23 23:38:38.598599
# Unit test for function eager
def test_eager():
    def return_generator():
        yield 1
        yield 2
        yield 3

    @eager
    def return_list():
        yield 1
        yield 2
        yield 3

    assert return_generator() == [1, 2, 3]
    assert return_list() == [1, 2, 3]

# Generated at 2022-06-23 23:38:47.838470
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Save counter to check it
    counter = VariablesGenerator._counter
    # Generate variables
    assert VariablesGenerator.generate("x") == '_py_backwards_x_0'
    assert VariablesGenerator.generate("y") == '_py_backwards_y_1'
    assert VariablesGenerator.generate("z") == '_py_backwards_z_2'
    assert VariablesGenerator._counter == counter + 3
    # Verify that next generation starts from first variable
    assert VariablesGenerator.generate("x") == '_py_backwards_x_3'


# Generated at 2022-06-23 23:38:49.997080
# Unit test for function eager
def test_eager():
    def a():
        for i in range(10):
            yield i
        return
    b = eager(a)
    assert b() == list(a())

# Generated at 2022-06-23 23:38:51.655128
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in [1, 2]))() == [1, 2]

# Generated at 2022-06-23 23:38:54.483555
# Unit test for function get_source
def test_get_source():
    def func(a: int, b: int) -> int:
        c = a + b
        return c
    expected_source_code = 'c = a + b\nreturn c'
    assert get_source(func) == expected_source_code

# Generated at 2022-06-23 23:38:56.169871
# Unit test for function eager
def test_eager():
    x = [1, 2, 3]

    def func():
        for i in x:
            yield i

    assert eager(func)() == x

# Generated at 2022-06-23 23:39:00.575756
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_4'



# Generated at 2022-06-23 23:39:03.028488
# Unit test for function warn
def test_warn():
    import sys
    import contextlib
    with contextlib.redirect_stderr(sys.stdout):
        warn("message")

# Generated at 2022-06-23 23:39:07.974247
# Unit test for function eager
def test_eager():
    from random import shuffle

    @eager
    def fib(n: int) -> Iterable[int]:
        if n <= 2:
            return 1
        else:
            return fib(n - 1) + fib(n - 2)

    for n in range(200, 0, -1):
        assert len(fib(n)) == n

# Generated at 2022-06-23 23:39:14.210840
# Unit test for function get_source
def test_get_source():
    def some_function():
        line_1 = 'line_1'
        line_2 = 'line_2'
        return line_1, line_2

    assert get_source(some_function).split('\n') == [
        'line_1 = \'line_1\'',
        'line_2 = \'line_2\'',
        'return line_1, line_2',
    ]

# Generated at 2022-06-23 23:39:17.634166
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg._counter == 0
    vg.generate("variable")
    assert vg._counter == 1
    vg.generate("variable2")
    assert vg._counter == 2



# Generated at 2022-06-23 23:39:20.484185
# Unit test for function get_source
def test_get_source():

        def f():
            """
            >>> f()
            1
            """
            return 1

        assert get_source(f) == "def f():\n    return 1"



# Generated at 2022-06-23 23:39:21.672330
# Unit test for function eager
def test_eager():
    assert eager(range)(0) == [0]

# Generated at 2022-06-23 23:39:22.697944
# Unit test for function warn
def test_warn():
    warn('Hi')



# Generated at 2022-06-23 23:39:28.774622
# Unit test for function warn
def test_warn():
    import sys
    temp_stdout = sys.stderr
    sys.stderr = open('output.txt', 'w')
    warn("test message")
    with open('output.txt', 'r') as f:
        assert str(f.read()) == "(!) test message\n"
    sys.stderr.close()
    os.remove('output.txt')
    sys.stderr = temp_stdout

# Generated at 2022-06-23 23:39:31.374460
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Should print')
    settings.debug = False
    debug(lambda: 'Should not print')

# Generated at 2022-06-23 23:39:41.766754
# Unit test for function debug
def test_debug():
    debug_message = ''

    def get_message() -> str:
        return 'debug_message'

    try:
        debug(get_message)
    except SystemExit:
        pass
    else:
        assert False, 'Some part of test_debug is skipped.'

    settings.debug = True
    old_stderr = sys.stderr
    try:
        sys.stderr = sys.stdout
        debug(get_message)
        debug_message = sys.stdout.getvalue()
    finally:
        sys.stderr = old_stderr

    assert debug_message.startswith(
        messages.DEBUG_PREFIX,
    ), 'debug() doesn\'t start the message with debug prefix.'


# Generated at 2022-06-23 23:39:43.282853
# Unit test for function eager
def test_eager():
    def fn() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(fn)() == [1, 2, 3]

# Generated at 2022-06-23 23:39:46.465422
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'


# Generated at 2022-06-23 23:39:53.047409
# Unit test for function warn
def test_warn():
    try:
        # noinspection PyShadowingBuiltins
        input, raw_input = input, raw_input
        captured_out = StringIO()
        sys.stdout = captured_out  # type: ignore

        warn('fake warn')
        assert len(captured_out.getvalue()) != 0
        assert captured_out.getvalue() == messages.warn('fake warn')
    finally:
        sys.stdout = sys.__stdout__  # type: ignore


# Generated at 2022-06-23 23:39:57.473111
# Unit test for function warn
def test_warn():
    from contextlib import redirect_stdout
    import io
    import sys
    import warnings

    with redirect_stdout(io.StringIO()) as buffer:
        warnings.filterwarnings('ignore')
        warn('foo bar')
        assert buffer.getvalue() == '⚠️ foo bar\n'



# Generated at 2022-06-23 23:40:04.582442
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_4'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_5'

# Generated at 2022-06-23 23:40:07.277583
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_gen = VariablesGenerator()
    a = var_gen.generate('a')
    b = var_gen.generate('a')
    assert a != b

# Generated at 2022-06-23 23:40:09.869290
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-23 23:40:11.723707
# Unit test for function eager
def test_eager():
    assert eager(range)(3) == [0, 1, 2]

# Generated at 2022-06-23 23:40:13.910749
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == 'def fn():\n    pass'


# Generated at 2022-06-23 23:40:16.057293
# Unit test for function eager
def test_eager():
    def generator():
        for x in range(3):
            yield x

    assert eager(generator)() == [0, 1, 2]

# Generated at 2022-06-23 23:40:18.071268
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-23 23:40:20.406747
# Unit test for function get_source
def test_get_source():
    def dummy_function():
        def nested_function():
            pass

    assert get_source(dummy_function) == "def nested_function():\n    pass"

# Generated at 2022-06-23 23:40:21.189734
# Unit test for function warn
def test_warn():
    warn('test warn')
    assert 'test warn'

# Generated at 2022-06-23 23:40:25.405920
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr

    text = '''\
    hello
    world
    '''

    with StringIO() as buf, redirect_stderr(buf):
        warn(text)
    assert buf.getvalue() == messages.warn(text)



# Generated at 2022-06-23 23:40:27.355674
# Unit test for function get_source
def test_get_source():
    def foo(bar):
        pass
    assert get_source(foo) == 'def foo(bar):\n    pass'

# Generated at 2022-06-23 23:40:36.724839
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from unittest import TestCase
    
    class VariablesGeneratorTestCase(TestCase):
        def setUp(self):
            VariablesGenerator._counter = 0
            self.variable_name = 'var'
            self.expected = '_py_backwards_{}_0'.format(self.variable_name)

        def test_variables_generator(self):
            self.assertEqual(VariablesGenerator.generate(self.variable_name), self.expected)
            self.assertEqual(VariablesGenerator.generate(self.variable_name), '_py_backwards_{}_1'.format(self.variable_name))
            self.assertEqual(VariablesGenerator.generate(self.variable_name), '_py_backwards_{}_2'.format(self.variable_name))



# Generated at 2022-06-23 23:40:39.042326
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: "this line shouldn't appear")
    settings.debug = True
    debug(lambda: "this line should appear")
    settings.debug = False
    test_debug()

# Generated at 2022-06-23 23:40:42.975388
# Unit test for function warn
def test_warn():
    from pytest import raises
    from io import StringIO
    from unittest.mock import patch
    from .. import settings

    with patch('sys.stderr', new=StringIO()), raises(SystemExit):
        settings.debug = True
        warn('test')
        settings.debug = False
        warn('test')

# Generated at 2022-06-23 23:40:48.629016
# Unit test for function warn
def test_warn():
    try:
        sys.stderr.write = MagicMock()
        warn('test')
        sys.stderr.write.assert_called_with(messages.warn('test'))
    finally:
        # Switch it back
        sys.stderr.write = sys.__stderr__.write



# Generated at 2022-06-23 23:40:51.254716
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(10):
        assert VariablesGenerator.generate('i') == '_py_backwards_i_' + str(i)

# Generated at 2022-06-23 23:41:00.441848
# Unit test for function debug
def test_debug():
    debug_output = []

    def assert_output(expected: List[str]) -> None:
        assert debug_output == expected

    def remove_output() -> None:
        del debug_output[:]

    def get_message() -> str:
        debug_message = "Hello, World!"
        debug_output.append(debug_message)
        return debug_message

    settings.debug.set(False)
    debug(get_message)
    assert_output([])

    settings.debug.set(True)
    debug(get_message)
    assert_output(["Hello, World!"])

    remove_output()
    settings.debug.set(False)
    debug(get_message)
    assert_output([])



# Generated at 2022-06-23 23:41:01.773002
# Unit test for function warn
def test_warn():
    assert warn('a') == 'WARNING: a'



# Generated at 2022-06-23 23:41:08.921904
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from pytest import raises

    generator = VariablesGenerator()
    # Verify that the generator returns the same variable names
    # when called with the same arguments
    assert generator.generate('x') == generator.generate('x')
    # Verify that the generator returns different variable names
    # when called with different arguments
    assert generator.generate('x') != generator.generate('y')

    # Verify that the generator raises an error when called without arguments
    with raises(TypeError):
        generator.generate()



# Generated at 2022-06-23 23:41:13.094200
# Unit test for function warn
def test_warn():
    with open('warn.log', 'w') as f:
        with redirect_stdout(f):
            message = 'test message'
            warn(message)
    with open('warn.log', 'r') as f:
        data = f.read()
        assert data == message + '\n', 'Wrong warn message'


# Generated at 2022-06-23 23:41:14.693425
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
    assert gen() == [1, 2]

# Generated at 2022-06-23 23:41:20.133252
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # variables = VariablesGenerator()
    # assert variables.generate('x') == '_py_backwards_x_0'
    # assert variables.generate('y') == '_py_backwards_y_1'
    # assert variables.generate('x') == '_py_backwards_x_2'
    # assert variables.generate('y') == '_py_backwards_y_3'
    pass

# Generated at 2022-06-23 23:41:24.548319
# Unit test for function debug
def test_debug():
    with patch('sys.stderr', new_callable=StringIO) as error_stream:
        settings.debug = True
        try:
            debug(lambda: 'error')
            assert error_stream.getvalue() == messages.debug('error') + '\n'
        finally:
            settings.debug = False

        debug(lambda: 'error')
        assert error_stream.getvalue() == messages.debug('error') + '\n'



# Generated at 2022-06-23 23:41:25.445639
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

# Generated at 2022-06-23 23:41:27.745895
# Unit test for function warn
def test_warn():
    try:
        warn('Debugging message')
    except IOError:
        raise AssertionError('Function warn has wrong effect')

# Generated at 2022-06-23 23:41:32.827817
# Unit test for function debug
def test_debug():
    assert not settings.debug
    message = "Debugging is turned off"

    def get_message():
        return message

    def get_debug():
        debug(get_message)
        return sys.stderr.getvalue()

    assert get_debug == ''
    settings.debug = True
    assert get_debug() == messages.debug(message)
    settings.debug = False

# Generated at 2022-06-23 23:41:36.564771
# Unit test for function get_source
def test_get_source():
    def test(a):
        return a + 1

    assert re.match(r'^def test\(a\):\s*\n\s*return a \+ 1$',
                    get_source(test)) is not None

# Generated at 2022-06-23 23:41:47.158464
# Unit test for function debug
def test_debug():
    if settings.debug:
        import sys

        sys.path.append(r'..')
        sys.path.append(r'D:\Programs\Python\Python37-32\Lib\site-packages')
        import pytest

        sys.path.append(r'D:\Programs\Python\Python37-32\Lib\site-packages\py')
        import core

        test_debug.captured_output = None
        with pytest.capture_stderr() as captured_output:
            core.debug(lambda: 'Hi!')
            test_debug.captured_output = captured_output

        assert 'Hi!' in test_debug.captured_output.value

# Generated at 2022-06-23 23:41:54.934305
# Unit test for function warn
def test_warn():
    from io import StringIO

    class Capturing(list):
        """This class emulates file-like object.

        It is used to catch stdout.
        """

        def __enter__(self) -> None:
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

        def __exit__(self, *args: Any) -> None:
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout

    with Capturing() as output:
        warn('Hello world')

    assert output == ['\x1b[33m[WARN]\x1b[0m Hello world']

# Generated at 2022-06-23 23:41:58.687782
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'


# Generated at 2022-06-23 23:42:00.241166
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2

    assert(foo() == [1, 2])



# Generated at 2022-06-23 23:42:02.676173
# Unit test for function warn
def test_warn():
    import warnings
    with warnings.catch_warnings(record=True) as warning:
        warnings.simplefilter('always')
        warn('message')
        assert len(warning) == 1
        assert str(warning[0]) == messages.warn('message')

