

# Generated at 2022-06-23 23:32:10.278981
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager
    from ..conf import settings
    from . import messages

    @contextmanager
    def _redirect_stderr():
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    def _test_debug_enabled():
        try:
            settings.debug = True
            with _redirect_stderr() as stderr:
                debug(lambda: 'hello')
                assert stderr.getvalue().rstrip() == messages.debug('hello')
        finally:
            settings.debug = False


# Generated at 2022-06-23 23:32:15.214361
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    some = VariablesGenerator()
    # Generate string like '_py_backwards_<number_of_calls_from_class_object>_<variable_name>'
    assert some.generate('some') == '_py_backwards_some_0'
    assert some.generate('some') == '_py_backwards_some_1'

# Generated at 2022-06-23 23:32:20.202494
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'

# Generated at 2022-06-23 23:32:21.099116
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:32:21.847260
# Unit test for function warn
def test_warn():
    warn('test warn')



# Generated at 2022-06-23 23:32:24.573358
# Unit test for function eager
def test_eager():
    eager_list = []
    def test():
        yield 1
        yield 2

    fn = eager(test)
    for i in fn():
        eager_list.append(i)
    assert eager_list == [1,2]


# Generated at 2022-06-23 23:32:29.495402
# Unit test for function get_source
def test_get_source():
    def f():
        """Docstring"""
        return 4

    assert get_source(f) == '"""Docstring"""\nreturn 4'
    assert get_source(test_get_source) == 'assert get_source(f) == """Docstring"""\nreturn 4'



# Generated at 2022-06-23 23:32:35.229199
# Unit test for function get_source
def test_get_source():
    def get_source_test(a, b, **test):
        return a + b

    assert get_source(get_source) == 'return a + b'
    assert get_source(get_source_test) == 'return a + b'

    # Test for another indents
    def get_source_test2():
        return f'{1}'

    assert get_source(get_source_test2) == 'return f\'{1}\''

# Generated at 2022-06-23 23:32:39.010595
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'


# Generated at 2022-06-23 23:32:42.331426
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    debug(lambda: 'bar')
    assert debug.__module__ == 'pybackwards.analysis.utils'



# Generated at 2022-06-23 23:32:48.585997
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('A') == '_py_backwards_A_0'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_1'
    assert VariablesGenerator.generate('A') == '_py_backwards_A_2'
    assert VariablesGenerator.generate('B') == '_py_backwards_B_3'
    assert VariablesGenerator.generate('C') == '_py_backwards_C_4'

# Generated at 2022-06-23 23:32:52.211840
# Unit test for function warn
def test_warn():
    from unittest.mock import patch

    @patch('sys.stderr')
    def test_print(mock_stderr):
        warn('test')
        mock_stderr.write.assert_called_once_with(messages.warn('test') + '\n')
    test_print()


# Generated at 2022-06-23 23:32:54.369799
# Unit test for function eager
def test_eager():
    def test_iterator():
        for i in range(5):
            yield i

    result = eager(test_iterator)()
    assert result == [0, 1, 2, 3, 4]


# Generated at 2022-06-23 23:32:56.566659
# Unit test for function eager
def test_eager():
    @eager
    def return_iterable_of_three_first_letters():
        return (letter for letter in 'abc')

    assert return_iterable_of_three_first_letters() == ['a', 'b', 'c']

# Generated at 2022-06-23 23:32:58.642941
# Unit test for function eager
def test_eager():
    @eager
    def f(n):
        for i in range(n):
            yield i
    assert f(3) == [0, 1, 2]

# Generated at 2022-06-23 23:33:01.164407
# Unit test for function debug
def test_debug():
    global msg
    msg = 'Debug message'

    def assert_debug_msg(message: str) -> None:
        assert message == msg

    debug(lambda: 'Debug message')
    debug(lambda: msg)
    debug(lambda: assert_debug_msg('Debug message'))
    debug(lambda: assert_debug_msg(msg))

# Generated at 2022-06-23 23:33:03.409891
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'



# Generated at 2022-06-23 23:33:05.844553
# Unit test for function get_source
def test_get_source():
    def test():
        """This is a test docstring"""
        pass

    source = get_source(test)
    assert source == 'def test():\n    """This is a test docstring"""\n    pass'

# Generated at 2022-06-23 23:33:08.443999
# Unit test for function debug
def test_debug():
    assert not settings.debug
    message = 'Hello World!'
    debug(lambda: message)
    settings.debug = True
    debug(lambda: message)
    assert sys.stderr.getvalue() == messages.debug(message) + '\n'



# Generated at 2022-06-23 23:33:11.292421
# Unit test for function eager
def test_eager():
    assert eager(list)(range(5)) == [0, 1, 2, 3, 4]
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:33:13.420470
# Unit test for function eager
def test_eager():
    @eager
    def generate_value():
        yield 1
        yield 2
        yield 3

    assert generate_value() == [1, 2, 3]

# Generated at 2022-06-23 23:33:15.993914
# Unit test for function eager
def test_eager():
    """Tests that function eager keeps correct order."""
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-23 23:33:23.133184
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import unittest

    class VariablesGeneratorTest(unittest.TestCase):
        def test_unique_names(self):
            self.assertEqual(VariablesGenerator.generate('a'), '_py_backwards_a_0')
            self.assertEqual(VariablesGenerator.generate('a'), '_py_backwards_a_1')
            self.assertEqual(VariablesGenerator.generate('b'), '_py_backwards_b_2')

    unittest.main()

# Generated at 2022-06-23 23:33:24.110771
# Unit test for function debug
def test_debug():
    debug(lambda: 'message')



# Generated at 2022-06-23 23:33:31.169243
# Unit test for function warn
def test_warn():
    import sys
    import os
    # Redirect stdout to capture output of the function
    old_stdout = sys.stdout
    sys.stdout = captured = sys.stdout.__class__()
    # Run function
    warn('Test')
    sys.stdout = old_stdout
    # Verify that the function printed "warn" message
    assert '\u001b[35m' in captured.getvalue()
    assert 'Test' in captured.getvalue()
    # Verify that the function didn't print to stderr
    assert os.path.getsize(sys.stderr.fileno()) == 0



# Generated at 2022-06-23 23:33:40.365535
# Unit test for function debug
def test_debug():
    import unittest
    import contextlib
    import io
    from .. import conf
    from .. import messages

    @contextlib.contextmanager
    def mock_conf():
        old_settings = conf.settings
        conf.settings = conf.Settings()
        try:
            yield conf
            conf.settings = old_settings
        except Exception:
            conf.settings = old_settings
            raise

    class TestDebug(unittest.TestCase):
        def test(self):
            with mock_conf() as config:
                message = 'This is a test.'
                f = io.StringIO()

# Generated at 2022-06-23 23:33:44.092446
# Unit test for function warn
def test_warn():
    if sys.version_info < (3, 6):
        return
    from io import StringIO
    from contextlib import redirect_stderr
    with redirect_stderr(StringIO()) as f:
        warn("warning")
        text = f.getvalue()
        assert text.startswith("PyBackwards: ".encode())



# Generated at 2022-06-23 23:33:46.828006
# Unit test for function eager
def test_eager():

    def test_generator(a, b):
        for i in range(10):
            yield a + b + i

    assert test_generator(2, 3) is not None
    assert eager(test_generator)(2, 3) == [i + 5 for i in range(10)]

# Generated at 2022-06-23 23:33:51.846203
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_3'

# Generated at 2022-06-23 23:33:55.770954
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("X") == '_py_backwards_X_0'
    assert VariablesGenerator.generate("Y") == '_py_backwards_Y_1'
    assert VariablesGenerator.generate("X") == '_py_backwards_X_2'

# Generated at 2022-06-23 23:33:57.709438
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'foo'

    assert get_source(foo).split('\n')[1] == "return 'foo'"

# Generated at 2022-06-23 23:34:02.214947
# Unit test for function warn
def test_warn():
    messages.warn = lambda message: message
    factory = mock.MagicMock()
    factory.return_value = mock.MagicMock()
    with mock.patch('sys.stderr', factory):
        warn('message')
        factory.assert_called_once_with()
        factory.return_value.write.assert_called_once_with('message\n')



# Generated at 2022-06-23 23:34:05.472047
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_2'



# Generated at 2022-06-23 23:34:08.024487
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        pass

    res = get_source(test_function)
    assert res == "def test_function(a, b):"


# Generated at 2022-06-23 23:34:11.142841
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator._counter == 1
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'


# Generated at 2022-06-23 23:34:13.129528
# Unit test for function eager
def test_eager():
    assert eager(list)([1, 2, 3]) == [1, 2, 3]
    assert eager(iter)([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-23 23:34:16.118587
# Unit test for function warn
def test_warn():
    output = sys.stderr
    captured = io.StringIO()
    sys.stderr = captured
    try:
        warn('test_message')
    finally:
        sys.stderr = output

    sys.stderr.write(captured.getvalue())

    assert captured.getvalue() == messages.warn('test_message') + '\n'



# Generated at 2022-06-23 23:34:23.741280
# Unit test for function warn
def test_warn():
    import sys
    from cStringIO import StringIO
    from py_backwards.fixture import TestCase

    class WarnTest(TestCase):
        def setUp(self):
            self.stderr = sys.stderr
            sys.stderr = StringIO()

        def tearDown(self):
            sys.stderr = self.stderr

        def test_warn(self):
            message = 'Error'
            warn(message)
            self.assertEqual(sys.stderr.getvalue(), '\n' + messages.warn(message) + '\n')

    WarnTest.run_tests()

# Generated at 2022-06-23 23:34:27.835537
# Unit test for function warn
def test_warn():
    print = mock.Mock()
    warn('warn_msg')

    assert print.call_args[0][0] == messages.warn('warn_msg')
    assert print.call_args[1] == {'file': sys.stderr}

# Generated at 2022-06-23 23:34:34.174836
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Global counter is 0
    assert VariablesGenerator._counter == 0
    # Generating the first variable
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    # Global counter is 1
    assert VariablesGenerator._counter == 1
    # Generating the second variable
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    # Global counter is 2
    assert VariablesGenerator._counter == 2
    # Generating the third variable
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'
    # Global counter is 3
    assert VariablesGenerator._counter == 3

# Generated at 2022-06-23 23:34:38.082328
# Unit test for function warn
def test_warn():
    buffer = StringIO()
    with contextlib.redirect_stderr(buffer):
        warn('This is a warning message')
    assert buffer.getvalue() == messages.warn('This is a warning message') + '\n'


# Generated at 2022-06-23 23:34:41.929961
# Unit test for function warn
def test_warn():
    with open("test.txt", "w") as file:
        with redirect_stderr(file):
            warn("hello")
    with open("test.txt", "r") as file:
        assert file.readlines()[0] == messages.warn("hello") + "\n"



# Generated at 2022-06-23 23:34:47.982141
# Unit test for function eager
def test_eager():
    data_returned = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    data_processed = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    @eager
    def fn() -> Iterable[int]:
        for num in data_processed:
            data_processed.pop()
            yield num

    assert fn() == data_returned

# Generated at 2022-06-23 23:34:53.541285
# Unit test for function warn
def test_warn():
    def assert_message_equals(expected: str, got: str) -> None:
        if expected != got:
            raise AssertionError('\nExpected: {}\nGot     : {}'.format(expected, got))

    assert_message_equals('\x1b[33m\x1b[1mWarning:\x1b[21m\x1b[39m this is just a warning',
                          messages.warn('this is just a warning'))



# Generated at 2022-06-23 23:34:55.185960
# Unit test for function eager
def test_eager():
    assert eager(lambda: (x for x in range(3)))(1) == [0, 1, 2]

# Generated at 2022-06-23 23:34:57.784786
# Unit test for function warn
def test_warn():
    message = "This is a message to be warned"
    warn(message)
    assert message in sys.stderr.getvalue()


# Generated at 2022-06-23 23:35:00.777297
# Unit test for function eager
def test_eager():
    def f(a):
        for i in range(a):
            yield i

    assert eager(f)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:35:04.874951
# Unit test for function eager
def test_eager():
    from random import shuffle

    def fn() -> Iterable[int]:
        for i in range(10):
            yield i

    shuffled = eager(fn)()
    assert not isinstance(shuffled, list)
    shuffle(shuffled)
    assert shuffled == list(range(10))



# Generated at 2022-06-23 23:35:11.488759
# Unit test for function get_source
def test_get_source():
    import sys
    import inspect
    import pytest
    from functools import wraps

    def target():
        @wraps(target)
        def inner_function():
            pass
        for i in range(10):
            next(i for i in range(10))
        return inner_function

    def test_function():
        assert get_source(target) == ('\n' * 3
                                      + '        for i in range(10):\n'
                                      + '            next(i for i in range(10))\n'
                                      + '        return inner_function')

    pytest.main([__file__])

# Generated at 2022-06-23 23:35:16.295521
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    t = VariablesGenerator()
    assert t.generate('x') == '_py_backwards_x_0'
    assert t.generate('y') == '_py_backwards_y_1'
    assert t.generate('x') == '_py_backwards_x_2'
    assert t.generate('x') == '_py_backwards_x_3'
    assert t.generate('y') == '_py_backwards_y_4'


# Generated at 2022-06-23 23:35:24.306577
# Unit test for function get_source
def test_get_source():
    from .tests.conf import settings
    from .tests import messages
    from .utils import get_source

    settings.debug = True
    settings.warnings = True
    settings.minify = False

    def some_function(): pass

    # Check formatting function works
    def test_working_function_formatting():
        assert get_source(some_function).strip() == 'pass'

    # Check formatting method works
    def test_working_method_formatting():
        class Class:
            @staticmethod
            def some_method(): pass

        assert get_source(Class.some_method).strip() == 'pass'

# Generated at 2022-06-23 23:35:27.373200
# Unit test for function debug
def test_debug():
    messages.debug = '{}'
    settings.debug = True

    debug(lambda: 'Hello {}'.format('world'))
    debug(lambda: '{} {}'.format('Hello', 'world'))
    assert False

# Generated at 2022-06-23 23:35:30.341121
# Unit test for function eager
def test_eager():
    test_list = []
    @eager
    def test():
        for i in range(10):
            test_list.append(i)
            yield i
    test()
    assert test_list == list(range(10))

# Generated at 2022-06-23 23:35:35.123694
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('s') == '_py_backwards_s_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('s') == '_py_backwards_s_2'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_3'

# Generated at 2022-06-23 23:35:36.296109
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:35:37.174293
# Unit test for function warn
def test_warn():
    warn('test_warn')


# Generated at 2022-06-23 23:35:47.410740
# Unit test for function debug
def test_debug():
    import io
    import sys

    def check(debug_on: bool, check: Callable[[], None]):
        out = io.StringIO()
        sys.stderr = out
        try:
            check()
        finally:
            sys.stderr = sys.__stderr__
        return out.getvalue()

    # Empty case
    assert check(False, lambda: None) == ''
    assert check(True, lambda: None) == ''

    # Case when debug is off
    assert check(False, lambda: debug(lambda: 'value')) == ''

    # Case when debug is on
    output = check(True, lambda: debug(lambda: 'value'))
    assert output == messages.debug('value') + '\n'

# Generated at 2022-06-23 23:35:49.743387
# Unit test for function eager
def test_eager():
    def func():
        for i in range(3):
            yield i

    assert eager(func)() == [0, 1, 2]

# Generated at 2022-06-23 23:35:52.222262
# Unit test for function get_source
def test_get_source():
    def source_function():
        def fn():
            return 1
        return fn
    assert get_source(source_function()) == 'def fn():\n    return 1'

# Generated at 2022-06-23 23:35:56.389322
# Unit test for function warn
def test_warn():
    from warnings import catch_warnings
    from io import StringIO
    with catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        warn("this is the warning message")
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)
        assert "warn" in str(w[-1].message)



# Generated at 2022-06-23 23:35:58.592468
# Unit test for function eager
def test_eager():
    def five_numbers() -> Iterable[int]:
        for n in range(5):
            yield n

    assert eager(five_numbers)() == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:36:01.160702
# Unit test for function get_source
def test_get_source():
    def abc():
        a = 10
        b = True
        c = 'hello'
    assert get_source(abc) == dedent("""
    a = 10
    b = True
    c = 'hello'
    """)



# Generated at 2022-06-23 23:36:07.386900
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('var') == '_py_backwards_var_0'
    assert gen.generate('var') == '_py_backwards_var_1'
    assert gen.generate('var') == '_py_backwards_var_2'
    assert gen.generate('var') == '_py_backwards_var_3'


# Generated at 2022-06-23 23:36:12.725049
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys

    # When
    old_stderr = sys.stderr
    result = StringIO()
    sys.stderr = result
    message = 'Test message'
    warn(message)
    sys.stderr = old_stderr
    actual_result = result.getvalue()

    # Then
    assert actual_result.endswith(message)

# Generated at 2022-06-23 23:36:15.829352
# Unit test for function warn
def test_warn():
    from io import StringIO
    f = StringIO()
    sys.stderr = f
    warn('message')
    assert f.getvalue() == messages.warn('message') + '\n'

# Generated at 2022-06-23 23:36:20.081702
# Unit test for function debug
def test_debug():
    dummy_callable = lambda: 'dummy_message'
    messages.debug = lambda x: 'DEBUG: {}'.format(x)
    settings.debug = True
    debug(dummy_callable)  # Should print debug message
    settings.debug = False
    debug(dummy_callable)  # Should not print debug message



# Generated at 2022-06-23 23:36:21.801648
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print("Testing for VariablesGenerator")
    vg = VariablesGenerator()
    print("passed")


# Generated at 2022-06-23 23:36:28.849122
# Unit test for function debug
def test_debug():
    from io import StringIO
    stream = StringIO()
    sys.stderr = stream
    settings.debug = True
    debug(lambda: 'debug message')
    assert stream.getvalue() == '\033[2mdebug message\033[0m\n'
    settings.debug = False
    stream.truncate(0)
    stream.seek(0)
    debug(lambda: 'debug message')
    assert stream.getvalue() == ''
    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:36:34.963070
# Unit test for function debug
def test_debug():
    from unittest.mock import Mock
    from .conf import Settings

    get_message = Mock(return_value='Message')
    settings.debug = True

    debug(get_message)
    get_message.assert_called_with()

    Settings.debug = False
    debug(get_message)
    get_message.assert_called_with()

# Generated at 2022-06-23 23:36:39.230160
# Unit test for function get_source
def test_get_source():
    def func():
        """
        Here is the docstring
        """
        x = 10
        y = 20
        for i in range(10):
            print(x + y)
        print(x + y)

    assert get_source(func) == """
        Here is the docstring
        """.strip()

# Generated at 2022-06-23 23:36:44.604898
# Unit test for function debug
def test_debug():
    import sys
    import unittest.mock as mock

    with mock.patch.object(sys, 'stderr', new=mock.Mock()):
        with settings.override('debug', True):
            debug(lambda: 'this is a debug message')
            assert sys.stderr.write.called

        sys.stderr.reset_mock()
        with settings.override('debug', False):
            debug(lambda: 'this is a debug message')
            assert not sys.stderr.write.called

# Generated at 2022-06-23 23:36:47.351445
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == 'def fn():\n    pass'
    assert '    ' not in get_source(fn)


# Generated at 2022-06-23 23:36:50.596627
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    def test_function():
        x = VariablesGenerator()
        y = VariablesGenerator()
        z = VariablesGenerator()
        assert x != y
        assert y != z
        assert z != x
    test_function()


# Generated at 2022-06-23 23:36:53.396201
# Unit test for function warn
def test_warn():
    global _out

    out = []
    _out = out

    def _write(message: str) -> None:  # type: ignore
        out.append(message)

    sys.stderr.write = _write

    warn('test')
    assert out == ['test' + messages.warn('test')]

# Generated at 2022-06-23 23:36:59.332680
# Unit test for function debug
def test_debug():
    debug_message = b'hello world'
    output_text = b''
    old_stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        debug(lambda: debug_message)
        output_text = sys.stderr.getvalue()
        assert(output_text == b'DEBUG: ' + debug_message + b'\n')
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-23 23:37:02.694410
# Unit test for function eager
def test_eager():
    from .generators import iota
    assert eager(iota)(3) == [0, 1, 2]
    assert type(eager(iota)(3)) is list

# Generated at 2022-06-23 23:37:04.053582
# Unit test for function debug
def test_debug():
    def fn():
        return 'Hello'
    debug(fn)

# Generated at 2022-06-23 23:37:13.150496
# Unit test for function debug
def test_debug():
    # Create mock object
    class MockStdErr:
        def __init__(self):
            self.messages = []

        def write(self, message: str) -> Any:
            self.messages.append(message)

    # Create mock object
    mock_stderr = MockStdErr()

    # Apply mock
    sys.stderr = mock_stderr

    # Test debug function
    settings.debug = True
    debug(lambda: 'test_debug')
    assert re.match(r'^\[py_backwards\] debug: test_debug$', mock_stderr.messages[-1]) is not None

    # Test not debug mode
    settings.debug = False
    debug(lambda: 'test_debug')

# Generated at 2022-06-23 23:37:15.133162
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def bar():
        return 42

    assert get_source(bar) == 'return 42'



# Generated at 2022-06-23 23:37:17.352305
# Unit test for function eager
def test_eager():
    def us(x: int) -> Iterable[int]:
        yield x
        yield x + 1

    assert eager(us)(5) == [5, 6]



# Generated at 2022-06-23 23:37:22.879166
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_generator = VariablesGenerator()
    assert var_generator.generate('a') == '_py_backwards_a_0'
    assert var_generator.generate('a') == '_py_backwards_a_1'
    assert var_generator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-23 23:37:24.678338
# Unit test for function debug
def test_debug():
    debug(lambda: 'abc')
    settings.debug = False
    debug(lambda: 'abc')



# Generated at 2022-06-23 23:37:31.167818
# Unit test for function debug
def test_debug():
    import io
    import sys

    old_stderr = sys.stderr
    result = io.StringIO()
    sys.stderr = result
    try:
        debug(lambda: 'Some text')
        assert result.getvalue() == ''
        settings.debug = True
        debug(lambda: 'Other text')
        assert result.getvalue().startswith('\033[95mDEBUG\033[0m\n')
        assert 'Other text' in result.getvalue()
    finally:
        sys.stderr = old_stderr
        result.close()



# Generated at 2022-06-23 23:37:35.425486
# Unit test for function debug
def test_debug():
    with patch('builtins.print') as mock_print:
        from .contextmanagers import patch, settings

        with patch.object(settings, 'debug', True):
            debug(lambda: 'test')
        mock_print.assert_called_once_with('[DEBUG] test', file=sys.stderr)

        with patch.object(settings, 'debug', False):
            debug(lambda: 'test')
        mock_print.assert_called_once_with('[DEBUG] test', file=sys.stderr)


# Generated at 2022-06-23 23:37:39.202617
# Unit test for function warn
def test_warn():
    import io

    out = io.StringIO()
    sys.stderr = out
    warn('WARNING')
    assert out.getvalue() == messages.warn('WARNING') + '\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:37:41.881947
# Unit test for function warn
def test_warn():
    from mock import Mock
    from . import messages

    messages.warn = Mock()
    warn('hello')
    messages.warn.assert_called_once_with('hello')

# Generated at 2022-06-23 23:37:44.554786
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'


# Generated at 2022-06-23 23:37:48.154259
# Unit test for function warn
def test_warn():
    # Save stderr to reset it
    stderr = sys.stderr
    sys.stderr = StringIO()

    # Call function warn
    warn("Warning")

    # Get output message
    assert "Warning" in sys.stderr.getvalue()
    sys.stderr = stderr


# Generated at 2022-06-23 23:37:48.589978
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-23 23:37:51.164333
# Unit test for function warn
def test_warn():
    try:
        sys.stderr = StringIO()
        warn('test')
        assert sys.stderr.getvalue() == messages.warn('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:37:56.505406
# Unit test for function get_source

# Generated at 2022-06-23 23:37:58.816265
# Unit test for function eager
def test_eager():
    def func():
        yield 1
        yield 2
        yield 3

    assert eager(func)() == [1, 2, 3]


# Generated at 2022-06-23 23:38:03.600986
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'


# Generated at 2022-06-23 23:38:07.198357
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        warn("Something")
        assert sys.stderr.getvalue() == '\x1b[1m\x1b[91mWarning: Something\x1b[0m\n'
    finally:
        sys.stderr = old_stderr
    print("Couldn't find stderr")

# Generated at 2022-06-23 23:38:09.003557
# Unit test for function eager
def test_eager():
    def foo(x):
        return range(x)
    assert eager(foo)(10) == list(range(10))

# Generated at 2022-06-23 23:38:12.660846
# Unit test for function get_source
def test_get_source():
    def func1():
        return 1

    def func2():
        def func3():
            return 3
        return 2

    # func1
    assert get_source(func1) == "return 1"

    # func2

# Generated at 2022-06-23 23:38:14.420292
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-23 23:38:15.838310
# Unit test for function eager
def test_eager():
    def foo():
        yield 1

    assert [1] == eager(foo)()

# Generated at 2022-06-23 23:38:23.802359
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('testa') == '_py_backwards_testa_0'
    assert gen.generate('testb') == '_py_backwards_testb_1'
    assert gen.generate('testa') == '_py_backwards_testa_2'
    assert gen.generate('testa') == '_py_backwards_testa_3'
    assert gen.generate('test') == '_py_backwards_test_4'
    assert gen.generate('test') == '_py_backwards_test_5'

# Generated at 2022-06-23 23:38:26.349599
# Unit test for function warn
def test_warn():
    warn('Hello world!')
    sys.stderr.seek(0)
    assert sys.stderr.read().startswith('[WARN] ')

# Generated at 2022-06-23 23:38:30.848910
# Unit test for function debug
def test_debug():
    debug('foo')
    settings.debug = False
    debug('bar')
    assert open(sys.stderr.name, 'r').read() == 'foo\n'
    settings.debug = True
    debug('baz')
    assert open(sys.stderr.name, 'r').read() == 'foo\nbaz\n'

# Generated at 2022-06-23 23:38:33.694501
# Unit test for function get_source
def test_get_source():
    def some_func():
        pass

    def some_func2():
        pass

    assert get_source(some_func) == 'def some_func():\n    pass'
    assert get_source(some_func2) == 'def some_func2():\n    pass'

# Generated at 2022-06-23 23:38:35.681397
# Unit test for function eager
def test_eager():
    # Example function
    def gen(n):
        for i in range(n):
            yield i

    assert eager(gen)(3) == [0, 1, 2]

# Generated at 2022-06-23 23:38:40.179749
# Unit test for function get_source
def test_get_source():
    def abc():
        return 'qwe'

    def defg(n: int) -> str:
        """
        Asdasd
        """
        if n:
            return 'rty'
        else:
            return 'uiop'

    assert get_source(abc) == 'return \'qwe\''
    assert get_source(defg) == '"""\n        Asdasd\n        """\n        if n:\n            return \'rty\'\n        else:\n            return \'uiop\''

# Generated at 2022-06-23 23:38:45.332122
# Unit test for function get_source
def test_get_source():
    def test(a, b):
        c = 1
        return a + b

    assert 'def test(a, b):\n    c = 1\n    return a + b' == get_source(test)
    assert 'def test(a, b):\n    c = 1\n    return a + b' == get_source(test)

# Generated at 2022-06-23 23:38:47.236160
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source).endswith('    return a + b\n')

# Generated at 2022-06-23 23:38:50.903381
# Unit test for function eager
def test_eager():
    @eager
    def lazy_sequence() -> Iterable[int]:
        i = 0
        while True:
            yield i
            i += 1

    assert isinstance(lazy_sequence(), List)
    assert isinstance(lazy_sequence()[0], int)



# Generated at 2022-06-23 23:38:52.830507
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-23 23:38:54.633246
# Unit test for function get_source
def test_get_source():
    def func():
        return 1

    assert get_source(func) == 'return 1'


if settings.test:
    test_get_source()

# Generated at 2022-06-23 23:38:58.593847
# Unit test for function warn
def test_warn():
    import io
    import sys
    from contextlib import redirect_stderr

    message = 'Warning'
    expected_message = '\x1b[33mWarning\x1b[0m'

    f = io.StringIO()
    with redirect_stderr(f):
        warn(message)

    err = f.getvalue()
    assert err == expected_message + '\n'



# Generated at 2022-06-23 23:39:00.635882
# Unit test for function warn
def test_warn():
    def test():
        warn('Foo')
    # Should print
    test()
    # Should not print
    settings.debug = False
    test()
    # Restore debug
    settings.debug = True



# Generated at 2022-06-23 23:39:05.501395
# Unit test for function warn
def test_warn():
    import io
    import contextlib
    from unittest.mock import patch

    @contextlib.contextmanager
    def captured_output(name):
        new_out = io.StringIO()
        old_out = getattr(sys, name)
        setattr(sys, name, new_out)
        try:
            yield new_out
        finally:
            setattr(sys, name, old_out)

    with captured_output('stderr') as output:
        warn("test_warn")

# Generated at 2022-06-23 23:39:09.110157
# Unit test for function debug
def test_debug():
    with patch('sys.stderr') as ss:
        debug(lambda: 'example message')
        ss.write.assert_called_once_with('[py-backwards] debug: example message\n')



# Generated at 2022-06-23 23:39:11.052573
# Unit test for function get_source
def test_get_source():
    def example_function():
        return 1
    assert get_source(example_function) == 'return 1'

# Generated at 2022-06-23 23:39:15.736743
# Unit test for function warn
def test_warn():
    import sys
    str_err = sys.stderr
    try:
        sys.stderr = open('C:\\Users\\user\\Desktop\\warn.txt', 'w')
        warn('test_warn')
    finally:
        sys.stderr = str_err



# Generated at 2022-06-23 23:39:23.232426
# Unit test for function debug
def test_debug():
    from unittest.mock import Mock
    from collections import namedtuple

    settings.debug = False

    mock = Mock()
    debug(mock)
    assert not mock.called

    settings.debug = True
    mock.return_value = 'foo'

    debug(mock)
    assert mock.called
    assert 'foo' in sys.stderr.getvalue()
    assert '▶' in sys.stderr.getvalue()

    sys.stderr.truncate(0)
    sys.stderr.seek(0)

    settings.debug = False

    mock.return_value = 'bar'

    debug(mock)
    assert not str(sys.stderr)

# Generated at 2022-06-23 23:39:27.696229
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == "_py_backwards_x_0"
    assert VariablesGenerator.generate('y') == "_py_backwards_y_1"
    assert VariablesGenerator.generate('z') == "_py_backwards_z_2"



# Generated at 2022-06-23 23:39:32.779273
# Unit test for function warn
def test_warn():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        sys.stdout = StringIO()
        yield

    with captured_output() as out:
        warn('test')
    output = out.getvalue().strip()
    return output == messages.warn('test')



# Generated at 2022-06-23 23:39:42.911702
# Unit test for function eager
def test_eager():
    from .backwards import eager
    from tempfile import NamedTemporaryFile
    from contextlib import contextmanager
    from itertools import count

    @eager
    def some_generator():
        for i in count():
            yield i

    result = some_generator()
    assert result == [0, 1, 2, 3, 4]
    assert result == [0, 1, 2, 3, 4]

    @eager
    def another_generator():
        yield 13

    assert another_generator() == [13]

    @contextmanager
    def nested_generator():
        yield 1
        with NamedTemporaryFile() as f:
            yield f.name
        yield 3

    assert list(nested_generator()) == [1, 3]
    assert list(nested_generator()) == [1, 3]

# Generated at 2022-06-23 23:39:45.655913
# Unit test for function debug
def test_debug():
    debug_message = 'test'
    calls = []
    def get_message():
        calls.append(1)
        return debug_message

    debug(get_message)
    assert calls == [1]

    debug(get_message)
    assert calls == [1, 1]

# Generated at 2022-06-23 23:39:48.560160
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'



# Generated at 2022-06-23 23:39:54.323683
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var_gen = VariablesGenerator()
    assert var_gen.generate('var_gen') == '_py_backwards_var_gen_0'
    assert var_gen.generate('var_gen') == '_py_backwards_var_gen_1'
    assert var_gen.generate('var_gen') == '_py_backwards_var_gen_2'


# Generated at 2022-06-23 23:39:55.646315
# Unit test for function warn
def test_warn():
    output = io.StringIO()
    sys.stderr = output
    warn('testmessage')
    output.seek(0)
    assert 'py_backwards' in output.read()

# Generated at 2022-06-23 23:40:00.738156
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class_items = vars(VariablesGenerator)
    assert list(class_items.items()) == [('_counter', 0)]

    assert len(set(VariablesGenerator.generate(str(i)) for i in range(10))) == 10
    assert len(set(
        VariablesGenerator.generate('x') for _ in range(100000))) == 100000

# Generated at 2022-06-23 23:40:02.769369
# Unit test for function get_source
def test_get_source():
    def some_source(a, b):
        return a + b

    assert get_source(some_source) == 'return a + b'

# Generated at 2022-06-23 23:40:04.969637
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'

# Generated at 2022-06-23 23:40:09.772013
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-23 23:40:11.150035
# Unit test for function warn
def test_warn():
    #  pass
    warn('Hello')



# Generated at 2022-06-23 23:40:12.990004
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 23:40:14.393139
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "Message")



# Generated at 2022-06-23 23:40:16.942620
# Unit test for function get_source
def test_get_source():
    result = """def plus(x: int, y: int) -> int:
    return x + y"""
    assert get_source(plus) == result


# Generated at 2022-06-23 23:40:19.479476
# Unit test for function eager
def test_eager():
    @eager
    def test(n):
        i = 0
        while i < n:
            yield i
            i += 1
    assert len(test) == test(4)



# Generated at 2022-06-23 23:40:20.658194
# Unit test for function debug
def test_debug():
    debug(lambda: 1)
    settings.debug = True
    debug(lambda: 1)

# Generated at 2022-06-23 23:40:24.036957
# Unit test for function warn
def test_warn():
    from io import StringIO
    out = StringIO()
    warn('test warn message')
    assert out.getvalue() == '\x1b[33mtest warn message\x1b[0m\n'


# Generated at 2022-06-23 23:40:27.062766
# Unit test for function get_source
def test_get_source():
    """
    >>> def fn():
    ...     return 'something'
    ...
    >>> get_source(fn)
    'def fn():\\n    return \'something\'\\n'
    """
    pass

# Generated at 2022-06-23 23:40:28.906185
# Unit test for function eager
def test_eager():
    from itertools import islice
    assert eager(islice)(range(5), 2) == [0, 1]

# Generated at 2022-06-23 23:40:30.532484
# Unit test for function eager
def test_eager():
    @eager
    def test(x):
        yield x
    assert test(1) == [1]

# Generated at 2022-06-23 23:40:34.354392
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'

# Generated at 2022-06-23 23:40:36.803464
# Unit test for function warn
def test_warn():
    # Given
    message = 'This is a test'

    # When
    warn(message)

    # Then
    assert message in sys.stderr.getvalue()

# Generated at 2022-06-23 23:40:40.443932
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    counter_value = vg._counter
    name1 = vg.generate("s")
    assert name1 == "_py_backwards_s_" + str(counter_value)
    name2 = vg.generate("s")
    assert name2 == "_py_backwards_s_" + str(counter_value+1)

# Generated at 2022-06-23 23:40:42.435606
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(10))() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:40:43.427938
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')



# Generated at 2022-06-23 23:40:52.854975
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

    def bar(x):
        pass

    assert get_source(bar) == 'def bar(x):\n    pass\n'

    def baz(x):
        a = 1
        b = 2
        return a + b

    assert get_source(baz) == 'def baz(x):\n    a = 1\n' \
                              '    b = 2\n    return a + b\n'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-23 23:40:54.774005
# Unit test for function eager
def test_eager():
    assert eager(range)(6) == [0, 1, 2, 3, 4, 5]


# Generated at 2022-06-23 23:41:02.366935
# Unit test for function warn
def test_warn():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def test_1():
        with captured_output() as (out, err):
            warn("test")
            assert "py_backwards: WARNING: test" in err.getvalue()

    def test_2():
        with captured_output() as (out, err):
            warn("test")

# Generated at 2022-06-23 23:41:07.323050
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'



# Generated at 2022-06-23 23:41:10.577237
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var1 = VariablesGenerator.generate('a')
    assert var1 == '_py_backwards_a_0'
    var2 = VariablesGenerator.generate('b')
    assert var2 == '_py_backwards_b_1'



# Generated at 2022-06-23 23:41:12.823804
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for n in range(3):
            yield n
    assert gen() == [0, 1, 2]



# Generated at 2022-06-23 23:41:16.775473
# Unit test for function warn
def test_warn():
    from ..conf import settings
    old_settings = settings.copy()
    settings.debug = False
    try:
        warn('foo')
        assert False, 'Warning should not be shown'
    except SystemExit:
        pass
    settings.debug = True
    warn('foo')
    settings.update(old_settings)



# Generated at 2022-06-23 23:41:22.710587
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vars = ['a', 'b', 'c', 'a', 'b', 'c']
    expected = ['_py_backwards_a_0', '_py_backwards_b_0', '_py_backwards_c_1', '_py_backwards_a_1', '_py_backwards_b_1', '_py_backwards_c_2']
    for var, exp in zip(vars, expected):
        assert(VariablesGenerator.generate(var) == exp)


# Generated at 2022-06-23 23:41:25.974960
# Unit test for function get_source
def test_get_source():
    def foo(a, *b, c, d=1, **e):
        print(a, b, c, d, e)

    source = get_source(foo)
    expected = dedent("""
    print(a, b, c, d, e)
    """)
    assert source == expected

# Generated at 2022-06-23 23:41:37.073117
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    global vg1, vg2, vg3, vg4
    global generate
    import py_backwards
    vg1 = py_backwards.utils.VariablesGenerator
    vg2 = vg1.generate
    vg3 = vg2('x')
    vg4 = vg2('x')
    generate = vg2

    # Test case 1
    assert vg3 != vg4
    assert issubclass(vg2, vg1)
    assert isinstance(vg4, vg1)
    assert isinstance(vg4, vg2)
    assert callable(vg3)
    assert callable(vg4)
    assert callable(vg2)
    assert isinstance(vg3, object)
    assert isinstance(vg4, object)

# Generated at 2022-06-23 23:41:39.744272
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1
        return a
    assert get_source(test) == 'a = 1\nreturn a'

# Generated at 2022-06-23 23:41:40.604206
# Unit test for function warn
def test_warn():
    # Arrange
    # Act
    warn('warning message')

    # Assert



# Generated at 2022-06-23 23:41:49.649219
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys

    # Mark the output stream for restoration
    old_stdout = sys.stderr

    # Temporarily redirect the output stream to a StringIO
    # instance
    try:
        out = StringIO()
        sys.stderr = out
        warn('Out to stderr')

        # Verify the result
        output = out.getvalue().strip()
        assert output == '⚠️  Out to stderr'
    finally:

        # Restore the original output stream
        sys.stderr = old_stdout

# Generated at 2022-06-23 23:41:50.911125
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
    assert f() is not f() # sanity check
    g = eager(f)
    h = eager(f)
    assert g is not h
    assert g() == h() == [1, 2]

# Generated at 2022-06-23 23:41:53.831000
# Unit test for function eager
def test_eager():
    @eager
    def fib():
        a, b = 0, 1
        while True:
            yield b
            a, b = b, a + b

    assert fib(10) == [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]


# Generated at 2022-06-23 23:41:58.914808
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Initial state
    assert VariablesGenerator._counter == 0

    # Generating unique names
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'

    # Final state
    assert VariablesGenerator._counter == 3

# Generated at 2022-06-23 23:42:02.704495
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    if VariablesGenerator.generate('x') != '_py_backwards_x_0':
        raise ValueError('Wrong value')
    if VariablesGenerator.generate('x') != '_py_backwards_x_1':
        raise ValueError('Wrong value')
    if VariablesGenerator.generate('x') != '_py_backwards_x_2':
        raise ValueError('Wrong value')

# Generated at 2022-06-23 23:42:04.511464
# Unit test for function eager
def test_eager():
    it = iter([1, 2, 3])
    assert eager(lambda: it)() == [1, 2, 3]