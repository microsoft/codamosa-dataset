

# Generated at 2022-06-23 23:31:56.321203
# Unit test for function warn
def test_warn():
    warn('hello')


# Generated at 2022-06-23 23:32:04.709096
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys
    import unittest
    from unittest.mock import patch

    from . import messages

    class TestDebug(unittest.TestCase):

        @patch('sys.stderr', new_callable=StringIO)
        def test_debug(self, mock_stderr):
            old = settings.debug

            try:
                settings.debug = False
                debug(lambda: 'Test')
                self.assertEqual(mock_stderr.getvalue(), '')

                settings.debug = True
                debug(lambda: 'Test')
                self.assertEqual(mock_stderr.getvalue(), messages.debug('Test'))
            finally:
                settings.debug = old


# Generated at 2022-06-23 23:32:07.216550
# Unit test for function get_source
def test_get_source():
    assert get_source(lambda: x) == 'return x'
    assert get_source(lambda x, y: x + y) == 'return x + y'
    assert get_source(lambda x: x + 1) == 'return x + 1'

# Generated at 2022-06-23 23:32:08.618397
# Unit test for function get_source
def test_get_source():
    def func():
        return 'my_func'

    assert get_source(func) == 'return \'my_func\''

# Generated at 2022-06-23 23:32:12.423049
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    counter = 0
    while counter < 10:
        variable = generator.generate('variable')
        print(variable)
        counter += 1


# Generated at 2022-06-23 23:32:15.255484
# Unit test for function get_source
def test_get_source():
    def test_function():
        if 1 + 1 == 2:
            print('ok!')

    assert get_source(test_function) == """\
if 1 + 1 == 2:
    print('ok!')\
"""

# Generated at 2022-06-23 23:32:19.590192
# Unit test for function warn
def test_warn():
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    warn('test_warn')
    sys.stderr.seek(0)
    assert sys.stderr.read() == messages.warn('test_warn') + '\n'
    sys.stderr = old_stderr


# Generated at 2022-06-23 23:32:24.668369
# Unit test for function debug
def test_debug():
    import sys
    import os
    import re
    import warnings

    class Capturing(list):
        """Captures stdout.

        It is based on the following resource:
        http://stackoverflow.com/questions/16571150/how-to-capture-stdout-output-from-a-python-function-call
        """

        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().split('\n'))
            del self._stringio  # free up some memory
            sys.stdout = self._stdout


# Generated at 2022-06-23 23:32:28.192080
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]
    assert eager(lambda: (i for i in range(5)))() == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:32:34.131180
# Unit test for function warn
def test_warn():
    import io
    import sys
    output = io.StringIO()
    sys.stderr = output
    warn("warn")
    assert output.getvalue() == "\033[91mwarn\033[0m\n"
    output = io.StringIO()
    sys.stderr = output
    warn("warn")
    assert output.getvalue() == "\033[91mwarn\033[0m\n"


# Generated at 2022-06-23 23:32:36.900279
# Unit test for function eager
def test_eager():
    def gen():
        for i in range(10):
            yield i
    assert(eager(gen)() == [0,1,2,3,4,5,6,7,8,9])

# Generated at 2022-06-23 23:32:38.653115
# Unit test for function get_source
def test_get_source():

    def hello_world():
        return 'Hello world!'

    assert "return 'Hello world!'" == get_source(hello_world)

# Generated at 2022-06-23 23:32:41.045347
# Unit test for function warn
def test_warn():
    # TODO: Remove this function after all messages in this file had been either unified,
    # or completely tested.
    warn('testing warn')



# Generated at 2022-06-23 23:32:45.273077
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO

    output = StringIO()
    sys.stderr = output

    def get_message():
        return 'foo'

    debug(get_message)
    assert output.getvalue() == messages.debug(get_message()) + '\n'
    output.close()

# Generated at 2022-06-23 23:32:47.709476
# Unit test for function get_source
def test_get_source():
    def test_function():
        print('Hello world')

    source = get_source(test_function)
    assert source == 'print(\'Hello world\')'

# Generated at 2022-06-23 23:32:49.075150
# Unit test for function get_source
def test_get_source():
    def testfunc():
        return 'foo'

    assert get_source(testfunc) == 'return \'foo\'\n'

# Generated at 2022-06-23 23:32:50.290090
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == get_source.__doc__

# Generated at 2022-06-23 23:32:53.498465
# Unit test for function warn
def test_warn():
    import mock
    with mock.patch('sys.stderr') as mock_stderr:
        warn('Test')
        mock_stderr.write.assert_called_once_with(messages.warn('Test') + '\n')


# Generated at 2022-06-23 23:32:54.728496
# Unit test for function get_source
def test_get_source():
    def test():
        def test_inner():
            pass



# Generated at 2022-06-23 23:32:58.752238
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        def check(msg):
            with patch('sys.stderr', new_callable=StringIO) as stderr:
                debug(lambda: msg)
                assert stderr.getvalue() == '\x1b[90m{}'.format(msg) + '\x1b[0m\n'

        check("message")

    finally:
        settings.debug = False



# Generated at 2022-06-23 23:33:00.608483
# Unit test for function get_source
def test_get_source():
    def _test_function(a):
        return a

    assert get_source(_test_function) == 'return a'



# Generated at 2022-06-23 23:33:03.291071
# Unit test for function eager
def test_eager():
    def generator():
        yield 1
        yield 2
        yield 3

    list_generator = eager(generator)
    assert list_generator() == [1, 2, 3]



# Generated at 2022-06-23 23:33:07.475081
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    import sys
    saved_stderr = sys.stderr
    try:
        out = StringIO()
        with redirect_stderr(out):
            warn('warning')
        assert out.getvalue().strip() == messages.warn('warning')
    finally:
        sys.stderr = saved_stderr


# Generated at 2022-06-23 23:33:14.479137
# Unit test for function debug
def test_debug():
    class TestSettings:
        debug = True

    with patch('py_backwards.utils.settings', TestSettings):
        with patch('sys.stderr') as stderr:
            debug(lambda: 'test')
            assert stderr.write.call_count == 1

    class TestSettings:
        debug = False

    with patch('py_backwards.utils.settings', TestSettings):
        with patch('sys.stderr') as stderr:
            debug(lambda: 'test')
            assert stderr.write.call_count == 0

# Generated at 2022-06-23 23:33:17.780178
# Unit test for function warn
def test_warn():
    _ = sys.stderr
    sys.stderr  = StringIO()

    warn('test message')
    assert sys.stderr.getvalue() == '[WARNING] test message\n'

    sys.stderr = _



# Generated at 2022-06-23 23:33:26.790824
# Unit test for function debug
def test_debug():
    import io

    captured_output = io.StringIO()
    with contextlib.redirect_stderr(captured_output):
        debug(lambda: 'a')
    output = captured_output.getvalue()

    assert output == ''

    captured_output = io.StringIO()
    settings.debug = True
    with contextlib.redirect_stderr(captured_output):
        debug(lambda: 'b')
    output = captured_output.getvalue()

    assert output == '\x1b[38;5;44m[DEBUG] b\x1b[0m\n'

    settings.debug = False
    return True


# Generated at 2022-06-23 23:33:32.221146
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate("a")
    b = VariablesGenerator.generate("b")
    c = VariablesGenerator.generate("c")
    assert a != b and a != c and b != c
    assert a[:15] == '_py_backwards_a' and b[:15] == '_py_backwards_b' and c[:15] == '_py_backwards_c'
    assert a[-1] == '0' and b[-1] == '1' and c[-1] == '2'

# Generated at 2022-06-23 23:33:35.051493
# Unit test for function get_source
def test_get_source():
    def dummy_func(x):
        if x != 0:
            y = 1
        else:
            y = 2

        return y


# Generated at 2022-06-23 23:33:42.465810
# Unit test for function debug
def test_debug():
    class ByteStream:
        def __init__(self) -> None:
            self.value = ''

        def write(self, value: str) -> None:
            self.value += value

    settings.debug = True
    stream = ByteStream()
    sys.stderr, old_stderr = stream, sys.stderr
    try:
        debug(lambda: 'Hello')
        assert stream.value == '\x1b[34mHello\x1b[0m\n'
    finally:
        sys.stderr = old_stderr
    settings.debug = False

# Generated at 2022-06-23 23:33:47.146276
# Unit test for function debug
def test_debug():
    from io import StringIO
    from . import saved_environment

    saved_environment.push()
    saved_environment.settings.debug = False

    new_stderr = StringIO()
    sys.stderr = new_stderr

    try:
        debug(lambda: 'message')
        debug_message = new_stderr.getvalue()
        assert debug_message == ''

    finally:
        sys.stderr = sys.__stderr__
        saved_environment.pop()


# Generated at 2022-06-23 23:33:48.491622
# Unit test for function warn
def test_warn():
    assert True

# Generated at 2022-06-23 23:33:50.242244
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert len(set(VariablesGenerator.generate('a') for _ in range(1000))) == 1000

# Generated at 2022-06-23 23:33:51.893984
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate(variable='test') == '_py_backwards_test_0'

# Generated at 2022-06-23 23:33:54.726494
# Unit test for function eager
def test_eager():
    def add(x: int, y: int) -> int:
        yield x + y
        yield x * y
        yield x - y
    assert eager(add)(1, 2) == [3, 2, -1]

# Generated at 2022-06-23 23:33:56.026798
# Unit test for function get_source
def test_get_source():
    def function():
        pass


# Generated at 2022-06-23 23:34:01.645740
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('a') == '_py_backwards_a_0'
    assert gen.generate('a') == '_py_backwards_a_1'
    assert gen.generate('a') == '_py_backwards_a_2'
    assert gen.generate('b') == '_py_backwards_b_3'
    assert gen.generate('a') == '_py_backwards_a_4'

# Generated at 2022-06-23 23:34:03.316652
# Unit test for function get_source
def test_get_source():

    def foo(a, b):
        return a + b

    assert get_source(foo) == 'return a + b'


test_get_source()

# Generated at 2022-06-23 23:34:05.720944
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'



# Generated at 2022-06-23 23:34:11.946686
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


    with captured_output() as (out, err):
        warn("Test warn")
        assert out.getvalue() == ''
        assert err.getvalue() ==  messages.warn("Test warn") + "\n"

# Generated at 2022-06-23 23:34:17.472044
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stderr
    from unittest import TestCase

    message = 'Hello!'
    assert not settings.debug

    with redirect_stderr(io.StringIO()) as fh:
        debug(lambda: message)
        assert fh.getvalue() == ''

    with redirect_stderr(io.StringIO()) as fh:
        settings.debug = True
        debug(lambda: message)
        assert fh.getvalue() == messages.debug(message) + '\n'

    settings.debug = False
    fh = io.StringIO()

    def check_debug(message: str) -> None:
        debug(lambda: message)
        assert fh.getvalue() == ''


# Generated at 2022-06-23 23:34:19.645601
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    foo = VariablesGenerator.generate('foo')
    bar = VariablesGenerator.generate('bar')

    assert foo != bar

# Generated at 2022-06-23 23:34:21.686604
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'

    assert debug(get_message) == None

# Generated at 2022-06-23 23:34:29.139451
# Unit test for function eager
def test_eager():
    def lst() -> List[int]:
        return [1, 2, 3]

    assert lst()[0] == 1
    assert lst.__name__ == 'lst'
    assert lst.__doc__ is None

    lst = eager(lst)
    assert not isinstance(lst(), list)
    assert lst()[0] == 1
    assert lst.__name__ == 'lst'
    assert lst.__doc__ is None



# Generated at 2022-06-23 23:34:39.215878
# Unit test for function debug
def test_debug():
    messages.info = messages.warning = messages.error = lambda x: x

    class MockFile:
        def __init__(self, errors) -> None:
            self.errors = errors

        def __call__(self, *args) -> None:
            self.errors.append(args)

    def test():
        def test_inner():
            errors = []
            with patch.object(sys, 'stderr', MockFile(errors)):
                settings.debug = True
                debug(lambda: 'foo')
                settings.debug = False
                debug(lambda: 'foo')

            assert len(errors) == 1
            assert errors[0][0] == 'DEBUG: foo\n'

        test_inner()
    test()

# Generated at 2022-06-23 23:34:43.193824
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source).replace(' ', '').replace('\t', '') == \
        """def test_get_source():
    assert get_source(test_get_source).replace(' ', '').replace('\\t', '')
        == """

# Generated at 2022-06-23 23:34:46.296237
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'



# Generated at 2022-06-23 23:34:47.720785
# Unit test for function debug
def test_debug():

    @debug
    def test():
        return 'Hello world'

    test()



# Generated at 2022-06-23 23:34:50.671673
# Unit test for function warn
def test_warn():
    _message_mock = Mock()
    with patch('backwards.utils.messages.warn', _message_mock):
        warn("Hello!")
    assert _message_mock.called


# Generated at 2022-06-23 23:34:52.331154
# Unit test for function warn
def test_warn():
    assert settings.debug is False
    assert settings.verbose is False
    settings.debug = True
    settings.verbose = True
    warn('test')

# Generated at 2022-06-23 23:34:56.116616
# Unit test for function debug
def test_debug():
    global_settings = settings.debug
    settings.debug = True
    test_text = 'test text'
    message = 'test message'

    def test_func():
        return message

    debug(test_func)
    out, _err = capsys.readouterr()
    assert test_text in out
    assert message in out

    settings.debug = global_settings

# Generated at 2022-06-23 23:34:59.320443
# Unit test for function warn
def test_warn():
    WARN = """
warn('PROBLEM')

Warning: PROBLEM
"""
    assert messages.warn('PROBLEM') == WARN



# Generated at 2022-06-23 23:35:02.947834
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = []
    for i in range(10):
        variables.append(VariablesGenerator.generate("Test"))
    if len(variables) != len(list(dict.fromkeys(variables))):
        raise ValueError("VariablesGenerator returns same variable name!")

# Generated at 2022-06-23 23:35:07.457930
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from io import StringIO
    from contextlib import redirect_stdout
    settings.debug = True
    f = StringIO()
    with redirect_stdout(f):
        debug(lambda: 'debug message')
    assert f.getvalue() == 'Debug: debug message\n'
    settings.debug = False

# Generated at 2022-06-23 23:35:09.031784
# Unit test for function get_source
def test_get_source():
    def foo():
        return 12
    foo_source = get_source(foo)
    assert foo_source == 'return 12'



# Generated at 2022-06-23 23:35:11.137563
# Unit test for function get_source
def test_get_source():
    def func():
        def inner():
            pass


    assert get_source(func) == dedent('''
        def inner():
            pass
        ''').strip()



# Generated at 2022-06-23 23:35:14.553303
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'



# Generated at 2022-06-23 23:35:17.967942
# Unit test for function eager
def test_eager():
    import sys
    import time

    @eager
    def foo(n):
        for i in range(n):
            yield i
            time.sleep(1)

    assert foo(2) == [0, 1]

# Generated at 2022-06-23 23:35:20.693748
# Unit test for function eager
def test_eager():
    @eager
    def squared(x: int) -> Iterable[int]:
        yield x
        yield x ** 2

    assert squared(5) == [5, 25]

# Generated at 2022-06-23 23:35:22.956115
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-23 23:35:25.953849
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        def get_message():
            return 'Some debug message'
        debug(get_message)
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:35:28.556397
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('temp') == '_py_backwards_temp_0'
    assert VariablesGenerator.generate('temp') == '_py_backwards_temp_1'
    assert VariablesGenerator.generate('temp') == '_py_backwards_temp_2'

# Generated at 2022-06-23 23:35:31.096099
# Unit test for function warn
def test_warn():
    from py_backwards.conf import settings
    settings.quiet = False
    warn('Test warn')
    import sys
    assert len(sys.stderr.getvalue()) > 0


# Generated at 2022-06-23 23:35:35.554012
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_2'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_3'


# Generated at 2022-06-23 23:35:37.420782
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-23 23:35:47.702953
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest
    @pytest.fixture(autouse=True)
    def _mutate_class(request):
        original_generate = VariablesGenerator.generate
        VariablesGenerator.generate = lambda c, v: '_py_backwards_{}_0'.format(v)
        def restore():
            VariablesGenerator.generate = original_generate
        request.addfinalizer(restore)

    assert VariablesGenerator.generate('dummy') == '_py_backwards_dummy_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_0'

# Generated at 2022-06-23 23:35:49.078779
# Unit test for function get_source

# Generated at 2022-06-23 23:35:52.175179
# Unit test for function get_source
def test_get_source():
    def foo(a, *b, c=0, **d):
        pass

    assert get_source(foo) == 'def foo(a, *b, c=0, **d):\n    pass'

# Generated at 2022-06-23 23:35:54.686010
# Unit test for function get_source
def test_get_source():
    def my_function(a: int, b: int) -> int:
        """This is the docstring."""
        if a == 1:
            return b


# Generated at 2022-06-23 23:36:01.757518
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from tempfile import TemporaryDirectory
    result = StringIO()

    with redirect_stderr(result):
        def message_callback():
            return 'test message'

        debug(message_callback)
        assert(result.getvalue().strip() == '')

        with TemporaryDirectory() as dirname:
            with open(os.path.join(dirname, 'debug.py'), 'w') as f:
                f.write('DEBUG = True')
            sys.path.append(dirname)
            import debug
            settings.debug = debug.DEBUG
            debug(message_callback)
            assert(result.getvalue().strip() == messages.debug('test message'))
            sys.path.remove(dirname)



# Generated at 2022-06-23 23:36:04.130402
# Unit test for function get_source
def test_get_source():
    def f(x, y):
        return x * y

    assert get_source(f) == 'return x * y'



# Generated at 2022-06-23 23:36:07.824164
# Unit test for function get_source
def test_get_source():
    try:
        def foo():
            pass

        assert get_source(foo) == 'def foo():\n    pass'
    except AssertionError:
        print("Test case failed, " + get_source(foo))



# Generated at 2022-06-23 23:36:09.915449
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass\n'



# Generated at 2022-06-23 23:36:15.494645
# Unit test for function warn
def test_warn():
    import io
    from contextlib import redirect_stderr

    message = "WARNING!!!!"
    new_stderr = io.StringIO()
    with redirect_stderr(new_stderr):
        warn(message)
    output = new_stderr.getvalue().strip()
    assert output == '\x1b[33m' + message + '\x1b[0m'

# Generated at 2022-06-23 23:36:18.794099
# Unit test for function debug
def test_debug():
    print = mock.Mock()

    settings.debug = True
    debug(lambda: 'message')
    assert print.call_count == 1

    settings.debug = False
    debug(lambda: 'message')
    assert print.call_count == 1

# Generated at 2022-06-23 23:36:24.893388
# Unit test for function debug
def test_debug():
    from itertools import count
    from unittest.mock import patch

    debug_message = 'Some debug message'

    def get_message():
        return '{} {}'.format(debug_message, next(c))

    c = count()

    with patch('sys.stderr', new=sys.stdout):
        debug(get_message)
        settings.debug = True
        debug(get_message)
        debug(get_message)

# Generated at 2022-06-23 23:36:26.789274
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'bar'

    assert get_source(foo) == "return 'bar'"

# Generated at 2022-06-23 23:36:28.523156
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'

# Generated at 2022-06-23 23:36:36.761910
# Unit test for function get_source
def test_get_source():
    def hello():
        print('hello')

    def hello_with_args(x, y):
        print(x, y)

    def hello_with_body():
        x = 2
        print('hello')

    expected_source = """
print('hello')
"""
    assert get_source(hello) == expected_source
    assert get_source(hello_with_args) == expected_source

    expected_source = """
x = 2
print('hello')
"""
    assert get_source(hello_with_body) == expected_source

# Generated at 2022-06-23 23:36:40.931916
# Unit test for function eager
def test_eager():
    @eager
    def fib():
        a, b = 0, 1
        while True:
            yield a
            a, b = b, a + b

    assert fib() == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377]

# Generated at 2022-06-23 23:36:43.308988
# Unit test for function get_source
def test_get_source():
    def f():
        """ This is a sample docstring."""
        pass

    assert get_source(f) == 'def f():\n    """ This is a sample docstring."""\n    pass'

# Generated at 2022-06-23 23:36:50.511842
# Unit test for function get_source
def test_get_source():
    def f():
        a = 0
        def g():
            b = 1
            return b
        return g()
    assert get_source(f) == 'a = 0\ndef g():\n    b = 1\n    return b\nreturn g()\n'
    assert get_source(VariablesGenerator.generate) == 'counter = 0\ntry:\n    return \'_py_backwards_{}_{}\'.format(variable, cls.counter)\nfinally:\n    cls.counter += 1\n'

# Generated at 2022-06-23 23:36:53.014905
# Unit test for function get_source
def test_get_source():
    def f(n: int) -> int:
        return n * 2

    actual = get_source(f)
    expected = inspect.getsource(f)
    assert actual == expected

# Generated at 2022-06-23 23:36:57.968598
# Unit test for function debug
def test_debug():
    import io
    sys.stderr = io.StringIO()
    try:
        settings.debug = True
        debug(lambda: 'asdf')
        assert sys.stderr.getvalue() == messages.debug('asdf') + '\n'
        sys.stderr = io.StringIO()
        settings.debug = False
        debug(lambda: 'asdf')
        assert sys.stderr.getvalue() == ''
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:36:58.989545
# Unit test for function warn
def test_warn():
    warn('debug')




# Generated at 2022-06-23 23:37:09.397342
# Unit test for function debug
def test_debug():
    """Tests calling debug function with and without debug mode."""
    import pytest
    import sys

    def test_get_message():
        """Returns test message."""
        return 'test_message'

    def test():
        """Calls debug function and checks if output is correct."""
        old_debug = settings.debug
        settings.debug = True
        try:
            debug(test_get_message)
            assert sys.stderr.getvalue().strip() == '[py-backwards:] test_message'
        finally:
            sys.stderr = sys.stderr.getvalue()[:0]
            settings.debug = old_debug

        settings.debug = False
        try:
            debug(test_get_message)
            assert sys.stderr.getvalue() == ''
        finally:
            sys

# Generated at 2022-06-23 23:37:12.110599
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    test_list = []
    for i in range(50):
        test_list.append(VariablesGenerator.generate('t'))
    assert len(set(test_list)) == 50

# Generated at 2022-06-23 23:37:14.254630
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello World')
    settings.debug = False
    debug(lambda: 'Hello World')
    settings.debug = True
    debug(lambda: 'Hello World')

# Generated at 2022-06-23 23:37:15.706163
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    assert eager(test)() == [1, 2, 3]

# Generated at 2022-06-23 23:37:21.342725
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'

# Generated at 2022-06-23 23:37:24.353801
# Unit test for function debug
def test_debug():
    class Output:
        def __init__(self) -> None:
            self.debug = False

        def debug(self, message: str) -> None:
            self.debug = message

    output = Output()
    debug_ = debug.__globals__

    with patch('sys.stderr', output):
        debug(lambda: 'debug message')

    assert output.debug is False

    with patch('sys.stderr', output):
        try:
            with patch('py_backwards.utils.settings.debug', True):
                debug(lambda: 'debug message')
        finally:
            sys.modules['py_backwards.utils.settings'].debug = False

    assert output.debug == messages.debug('debug message')

# Generated at 2022-06-23 23:37:25.718132
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Hello, debug!'
    debug(get_message)

# Generated at 2022-06-23 23:37:28.821386
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    it = VariablesGenerator()

    assert it.generate('foo') == '_py_backwards_foo_0'
    assert it.generate('bar') == '_py_backwards_bar_1'

# Generated at 2022-06-23 23:37:29.906150
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]

# Generated at 2022-06-23 23:37:31.499339
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert not (VariablesGenerator.generate("A") == VariablesGenerator.generate("B"))
    assert not (VariablesGenerator.generate("A") == VariablesGenerator.generate("A"))


# Generated at 2022-06-23 23:37:37.150207
# Unit test for function debug
def test_debug():
    """Unit test for function debug."""
    import pytest
    from unittest.mock import call, Mock, patch

    debug_mock = Mock()
    with patch('py_backwards.messages.debug', return_value='debug message'), \
            patch('sys.stderr.write', side_effect=debug_mock):
        debug(lambda: 'test message')
        debug(lambda: 'test message')
    assert debug_mock.call_args_list == [
        call('debug message'),
    ]

    debug_mock = Mock()

# Generated at 2022-06-23 23:37:39.695592
# Unit test for function eager
def test_eager():
    @eager
    def func():
        return [i for i in range(10)]

    assert func() == [i for i in range(10)]

# Generated at 2022-06-23 23:37:41.834726
# Unit test for function eager
def test_eager():
    def some_fn():
        for i in range(10):
            yield i

    assert eager(some_fn)() == list(range(10))

# Generated at 2022-06-23 23:37:45.109238
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

    def test_function():
        if True:
            pass

    assert get_source(test_function) == 'if True:\n    pass'



# Generated at 2022-06-23 23:37:48.376404
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert get_source(VariablesGenerator.generate) \
        .startswith("    return '_py_backwards_{}_{}'")
    assert get_source(VariablesGenerator.generate) \
        .endswith("cls._counter += 1")


# Generated at 2022-06-23 23:37:49.963666
# Unit test for function eager
def test_eager():
    def a(i):
        yield i
    @eager
    def b(i):
        yield i
    assert isinstance(b(1), list)

# Generated at 2022-06-23 23:37:52.046327
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1,2,3]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:37:55.138291
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'

# Generated at 2022-06-23 23:38:02.497929
# Unit test for function eager
def test_eager():
    import random
    import time

    @eager
    def foo(i):
        j = 1
        while j <= i:
            yield j
            j += 1

    @eager
    def bar(i):
        yield from range(10)
        yield from range(i)

    for j in [1, 5, 10]:
        print(foo(j))
        print(bar(j))

    print(bar(10))
    bar_eager = bar(10)
    time.sleep(random.random())
    print(bar_eager)

# Generated at 2022-06-23 23:38:03.358160
# Unit test for function get_source
def test_get_source():
    def function(arg):
        return arg
    source = get_source(function)
    assert source == 'function(arg):\n    return arg'

# Generated at 2022-06-23 23:38:07.953395
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_0'
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_1'
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_2'
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_3'
    assert VariablesGenerator.generate('my_variable') == '_py_backwards_my_variable_4'
    assert VariablesGenerator.generate('name') == '_py_backwards_name_5'

# Generated at 2022-06-23 23:38:09.803537
# Unit test for function get_source
def test_get_source():
    @backwards
    def test():
        return 1

    assert get_source(test) == '    return 1'

# Generated at 2022-06-23 23:38:12.281556
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass\n'



# Generated at 2022-06-23 23:38:14.290365
# Unit test for function get_source
def test_get_source():
    def func(x):
        return x

    assert 'def func(x):\n    return x' == get_source(func), get_source(func)

# Generated at 2022-06-23 23:38:18.096438
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    v1 = gen.generate('test')
    v2 = gen.generate('test')
    v3 = gen.generate('test')
    assert v1 != v2
    assert v1 != v3
    assert v2 != v3

# Generated at 2022-06-23 23:38:22.571977
# Unit test for function debug
def test_debug():
    if settings.debug:
        test_result = ['Unit test for function debug']
    else:
        test_result = []
    def test_func():
        test_result.append('Test function called')
    debug(test_func)
    assert test_result == ['Unit test for function debug', 'Test function called']

# Generated at 2022-06-23 23:38:26.258762
# Unit test for function eager
def test_eager():
    def foo(x: int) -> Iterable[int]:
        """Return iterable of x integers."""
        for _ in range(x):
            yield 1

    assert foo(3) == [1, 1, 1]

    assert eager(foo)(3) == [1, 1, 1]

# Generated at 2022-06-23 23:38:31.445430
# Unit test for function debug
def test_debug():
    from .test_runner import settings
    settings.debug = True
    import sys

    captured = sys.stderr

    try:
        sys.stderr = StringIO()
        debug(lambda: 'example')
        assert sys.stderr.getvalue() == messages.debug('example') + '\n'
    finally:
        sys.stderr = captured



# Generated at 2022-06-23 23:38:33.731209
# Unit test for function get_source
def test_get_source():
    def test():
        x = 0
        y = ''
        return x, y

    output = 'x = 0\ny = \'\'\nreturn x, y\n'
    assert output == get_source(test)

# Generated at 2022-06-23 23:38:36.591241
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        assert sys.stderr.write.call_count == 0
        debug(lambda: 'foo')
        assert sys.stderr.write.call_count == 1
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:38:40.607025
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    var1 = VariablesGenerator.generate('x')
    var2 = VariablesGenerator.generate('x')
    assert var1 != var2
    assert var1 == '_py_backwards_x_0'
    assert var2 == '_py_backwards_x_1'

# Generated at 2022-06-23 23:38:43.165620
# Unit test for function get_source
def test_get_source():
    import py_backwards.tests.utils.test_utils as tu
    assert tu.test_source == get_source(tu.test_source)



# Generated at 2022-06-23 23:38:45.533622
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert(test() == [1, 2, 3])

# Generated at 2022-06-23 23:38:49.815496
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'
    assert VariablesGenerator._counter == 2


# Generated at 2022-06-23 23:38:51.824184
# Unit test for function get_source
def test_get_source():
    def dummy_fn():
        pass

    assert get_source(dummy_fn) == 'def dummy_fn():\n    pass'

# Generated at 2022-06-23 23:38:54.127192
# Unit test for function eager
def test_eager():
    fn = lambda: (i for i in range(10))
    assert eager(fn)() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-23 23:38:55.493539
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("variable") == "_py_backwards_variable_0"


# Generated at 2022-06-23 23:38:57.271476
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'

# Generated at 2022-06-23 23:38:59.579337
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        for i in range(5):
            yield i

    assert generator() == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:39:01.591539
# Unit test for function get_source
def test_get_source():
    def f(x: int) -> int:
        return x ** 2
    assert get_source(f) == 'return x ** 2'

# Generated at 2022-06-23 23:39:06.128702
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    f = VariablesGenerator()
    assert f.generate("x") == "_py_backwards_x_0"
    assert f.generate("y") == "_py_backwards_y_1"
    assert f.generate("z") == "_py_backwards_z_2"

# Generated at 2022-06-23 23:39:12.008953
# Unit test for function get_source
def test_get_source():
    source = get_source(test_get_source)

# Generated at 2022-06-23 23:39:15.685769
# Unit test for function warn
def test_warn():
    # Test if warn prints message to stderr
    out = StringIO()
    with redirect_stderr(out):
        warn('Warning message')
    assert out.getvalue().strip() == 'Warning message'



# Generated at 2022-06-23 23:39:23.230455
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    from . import settings

    @contextlib.contextmanager
    def capture_stderr():
        stderr = sys.stderr
        mem_stderr = io.StringIO()
        try:
            sys.stderr = mem_stderr
            yield mem_stderr
        finally:
            sys.stderr = stderr

    with capture_stderr() as stderr:
        settings.debug = False
        debug(lambda: "Should not be printed when debug is off")
        assert mem_stderr.getvalue() == ""

        settings.debug = True
        debug(lambda: "Should be printed")
        assert "Should be printed" in mem_stderr.getvalue()

# Generated at 2022-06-23 23:39:28.178497
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator().generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator().generate("a") == '_py_backwards_a_1'
    assert VariablesGenerator().generate("b") == '_py_backwards_b_2'

# Unit test get_source

# Generated at 2022-06-23 23:39:30.728082
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'

# Unit tests for get_source()

# Generated at 2022-06-23 23:39:33.022172
# Unit test for function eager
def test_eager():
    def f():
        for i in range(3):
            yield i
    assert eager(f)() == [0, 1, 2]

# Generated at 2022-06-23 23:39:36.077404
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('k') == '_py_backwards_k_0'
    assert VariablesGenerator.generate('k') == '_py_backwards_k_1'

# Generated at 2022-06-23 23:39:40.241519
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    #Tests only if the first 10 variables are unique
    from itertools import combinations
    variables = [VariablesGenerator.generate('a') for _ in range(10)]
    for var1, var2 in combinations(variables, 2):
        assert var1 != var2

# Generated at 2022-06-23 23:39:44.962068
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    def IsVariableGenerated(string):
        return re.match(r'^_py_backwards_.+_[0-9]', string)
    assert IsVariableGenerated(VariablesGenerator.generate('arg'))
    assert IsVariableGenerated(VariablesGenerator.generate('arg_1'))
    assert IsVariableGenerated(VariablesGenerator.generate('arg_1_1'))


# Generated at 2022-06-23 23:39:49.070906
# Unit test for function get_source
def test_get_source():
    def foo(a: int, b: str = 'baz') -> int:
        return a * 2

    source = get_source(foo)
    expected_source = 'def foo(a: int, b: str = \'baz\') -> int:\n\treturn a * 2'
    assert source == expected_source

# Generated at 2022-06-23 23:39:54.625056
# Unit test for function warn
def test_warn():
    import sys
    import StringIO
    captured_output = StringIO.StringIO()
    sys.stderr = captured_output
    warn("something")
    sys.stderr = sys.__stderr__
    assert captured_output.getvalue().rstrip() == messages.warn("something")
    assert '\x1b' in messages.warn("something")

# Generated at 2022-06-23 23:39:56.580341
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('') != VariablesGenerator.generate('')

# Generated at 2022-06-23 23:40:04.178734
# Unit test for function debug
def test_debug():
    from . import messages
    import sys
    import builtins

    source_code = ''

    def write(text: str) -> None:
        nonlocal source_code
        source_code += text

    def get_message() -> str:
        return 'message'

    builtins.print = write
    sys.stderr = sys.stdout
    settings.debug = True
    debug(get_message)
    assert source_code == messages.debug(get_message()) + '\n'
    settings.debug = False
    debug(get_message)
    assert source_code == messages.debug(get_message()) + '\n'



# Generated at 2022-06-23 23:40:06.430338
# Unit test for function eager
def test_eager():
    @eager
    def my_eager(n):
        return range(n)

    assert my_eager(10) == list(range(10))

# Generated at 2022-06-23 23:40:10.576897
# Unit test for function eager
def test_eager():
    @eager
    def range_to(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert list(range(5)) == range_to(5)


# Generated at 2022-06-23 23:40:12.845325
# Unit test for function eager
def test_eager():
    def func():
        yield 1
    assert callable(eager(func))
    assert eager(func)() == [1]


# Generated at 2022-06-23 23:40:15.002744
# Unit test for function get_source
def test_get_source():
    def test_fn():
        pass
    assert get_source(test_fn) == 'pass'

# Unit tests for function warn

# Generated at 2022-06-23 23:40:19.791934
# Unit test for function warn
def test_warn():
    import mock
    sys.stderr = open('/dev/null', 'w')
    with mock.patch('sys.stderr') as mock_stderr:
        warn('test message')
        mock_stderr.write.assert_called_with(
            messages.warn('test message') + '\n'
        )
    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:40:25.134689
# Unit test for function debug
def test_debug():
    context = {
        'test_message': ''
    }

    def get_message():
        return 'Test message.'

    def reset_debug():
        settings.debug = True

    def set_debug():
        settings.debug = False
        return context.setdefault('test_message', '')

    def test_debug_on():
        set_debug()
        debug(get_message)
        assert get_message() in context['test_message']

    def test_debug_off():
        reset_debug()
        set_debug()
        debug(get_message)
        assert not context['test_message']

    test_debug_on()
    test_debug_off()

# Generated at 2022-06-23 23:40:27.455406
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        print(a + b)

    assert get_source(foo) == "print(a + b)"

# Generated at 2022-06-23 23:40:35.118912
# Unit test for function debug
def test_debug():
    import io
    import sys

    # Save old stderr
    old_stderr = sys.stderr

    def get_message():
        """Returns message."""
        return 'message text'

    try:
        # Redirect stderr
        sys.stderr = io.StringIO()

        # Call function
        debug(get_message)
        debug.__wrapped__(get_message)

        # Check expected results
        assert sys.stderr.getvalue() == messages.debug(get_message())
    finally:
        # Restore old stderr
        sys.stderr = old_stderr



# Generated at 2022-06-23 23:40:40.206951
# Unit test for function eager
def test_eager():
    from types import GeneratorType
    from py_backwards.code_generator import code_generator

    @code_generator
    def test_gen():
        yield 1
        yield 2
        yield 3

    # test function returns generator
    assert isinstance(test_gen(), GeneratorType)

    # test eager function returns list
    assert isinstance(eager(test_gen)(), list)

    # test eager function returns list with the same content
    assert eager(test_gen()) == [1, 2, 3]



# Generated at 2022-06-23 23:40:41.581727
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello world!')



# Generated at 2022-06-23 23:40:42.804937
# Unit test for function warn
def test_warn():
    result: str = warn("something")
    assert result == None


# Generated at 2022-06-23 23:40:53.046100
# Unit test for function debug
def test_debug():
    # Test whether debug prints anything if the debug flag is True.
    class Test():
        count = 0
        def debug_action(self):
            self.count += 1
            return str(self.count)

    old_debug = settings.debug
    old_debug_action = settings.debug_action
    try:
        settings.debug = True
        settings.debug_action = Test().debug_action

        settings.debug_action()
        settings.debug_action()

        settings.debug = False
        settings.debug_action = None

        assert Test.count == 2, 'The debug action has not been executed twice.'

    finally:
        settings.debug = old_debug
        settings.debug_action = old_debug_action

# Generated at 2022-06-23 23:40:58.559230
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator._counter
    assert a == 0
    c = VariablesGenerator.generate('name')
    assert c == '_py_backwards_name_0'
    d = VariablesGenerator.generate('name')
    assert d == '_py_backwards_name_1'
    b = VariablesGenerator._counter
    assert b == 2


# Generated at 2022-06-23 23:41:01.870339
# Unit test for function eager
def test_eager():
    def _test_eager(i):
        while True:
            yield i
            i += 1
            if i == 5:
                return

    assert eager(_test_eager)(0) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:41:05.146533
# Unit test for function eager
def test_eager():
    def test_fn():
        return range(5)

    result = eager(test_fn)()
    assert result == [0, 1, 2, 3, 4]


# Generated at 2022-06-23 23:41:10.497336
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var2') == '_py_backwards_var2_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'
    assert VariablesGenerator.generate('var3') == '_py_backwards_var3_3'


# Generated at 2022-06-23 23:41:13.816241
# Unit test for function get_source
def test_get_source():
    def fn(a, b, c):
        return a + b + c

    @fn.py_backwards
    def fn_backwards(a, b, c):
        return a + b + c

    assert get_source(fn) == get_source(fn_backwards)

# Generated at 2022-06-23 23:41:16.093107
# Unit test for function eager
def test_eager():
    def gen() -> Iterable[str]:
        yield 'a'
        yield 'b'

    assert eager(gen)() == ['a', 'b']


# Generated at 2022-06-23 23:41:18.383776
# Unit test for function eager
def test_eager():
    def test_function():
        yield 1
        yield 2
        yield 3
    assert eager(test_function)() == [1, 2, 3]


# Generated at 2022-06-23 23:41:20.340713
# Unit test for function get_source
def test_get_source():
    def my_func():
        n = 3

    assert get_source(my_func) == """\
n = 3"""


# Generated at 2022-06-23 23:41:23.165633
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'pass'

    def test_function2():
        if True:
            pass
    assert get_source(test_function2) == 'if True:\n    pass'

# Generated at 2022-06-23 23:41:25.342103
# Unit test for function get_source
def test_get_source():
    def foo():
        if True:
            pass

    assert get_source(foo) == 'if True:\n  pass'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-23 23:41:27.298836
# Unit test for function eager
def test_eager():
    def unit(a):
        while a > 0:
            yield a
            a -= 1

    assert [3, 2, 1] == eager(unit)(3)


# Generated at 2022-06-23 23:41:29.591321
# Unit test for function get_source
def test_get_source():
    def a(b):
        print(b)

    assert get_source(a) == "print(b)"


# Generated at 2022-06-23 23:41:32.632195
# Unit test for function debug
def test_debug():
    settings.debug = True
    buf = StringIO()
    sys.stderr = buf
    debug(lambda: 'sth')
    assert 'sth' in buf.getvalue()
    settings.debug = False

# Generated at 2022-06-23 23:41:35.134815
# Unit test for function eager
def test_eager():
    @eager
    def f():
        for i in range(10000000):
            yield i

    assert(f()[-1] == 9999999)

# Generated at 2022-06-23 23:41:39.850699
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    assert(a.generate('foo') == '_py_backwards_foo_0')
    assert(a.generate('bar') == '_py_backwards_bar_1')
    assert(a.generate('foo') == '_py_backwards_foo_2')

# Generated at 2022-06-23 23:41:41.152725
# Unit test for function warn
def test_warn():
    warn("warning: test")


# Generated at 2022-06-23 23:41:48.776789
# Unit test for function warn
def test_warn():
    from io import StringIO  # type: ignore
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout():
        fake_stdout = StringIO()

        with contextmanager(lambda: (yield fake_stdout)) as fake_stdout:
            yield fake_stdout

    with capture_stdout() as fake_stdout:
        warn('Test')
        assert fake_stdout.getvalue() == '\033[31mTest\033[0m\n'

# Generated at 2022-06-23 23:41:51.404230
# Unit test for function get_source
def test_get_source():
    def get_source2():
        return 5

    assert get_source(get_source2) == 'return 5'



# Generated at 2022-06-23 23:41:53.396824
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    settings.debug = False
    debug(lambda: 'debug message')



# Generated at 2022-06-23 23:41:55.704199
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    def f():
        for i in range(10000):
            VariablesGenerator.generate('foo')
    if settings.debug:
        f()
    pass