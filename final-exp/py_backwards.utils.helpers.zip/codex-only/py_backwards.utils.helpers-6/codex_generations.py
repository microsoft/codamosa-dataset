

# Generated at 2022-06-23 23:32:00.925494
# Unit test for function warn
def test_warn():
    import warnings
    warnings.simplefilter('default')
    with warnings.catch_warnings(record=True) as captured_warnings:
        warn('Warning message')

    assert len(captured_warnings) == 1
    assert 'Warning message' in str(captured_warnings[-1].message)

# Generated at 2022-06-23 23:32:03.295070
# Unit test for function get_source
def test_get_source():
    def test():
        def inner():
            pass

    def inner():
        pass

    assert get_source(test) == 'def inner():\n    pass'
    assert get_source(inner) == 'inner()'

# Generated at 2022-06-23 23:32:05.174491
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen1 = VariablesGenerator.generate('foo')
    gen2 = VariablesGenerator.generate('foo')
    assert gen1 != gen2

# Generated at 2022-06-23 23:32:06.463907
# Unit test for function eager
def test_eager():
    assert eager(lambda : (i for i in range(10)))() == list(range(10))

# Generated at 2022-06-23 23:32:07.490937
# Unit test for function warn
def test_warn():
    assert warn('some_message') is None



# Generated at 2022-06-23 23:32:16.917085
# Unit test for function debug
def test_debug():
    class FakeFile:
        def __init__(self):
            self.content = ''

        def write(self, text: str) -> None:
            self.content += text

    fake_stdout = FakeFile()
    fake_stderr = FakeFile()
    try:
        sys.stdout = fake_stdout
        sys.stderr = fake_stderr
        settings.debug = True
        debug(lambda: 'The message is: {}'.format('foobar'))
        assert fake_stderr.content == messages.debug('The message is: {}'.format('foobar'))
    finally:
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:32:21.618330
# Unit test for function debug
def test_debug():
    old_debug = settings.debug

    settings.debug = False
    output = StringIO()
    sys.stderr = output
    debug(lambda: 'MESSAGE')
    assert output.getvalue() == ''

    settings.debug = True
    output = StringIO()
    sys.stderr = output
    debug(lambda: 'MESSAGE')
    assert output.getvalue() == messages.debug('MESSAGE') + '\n'

    settings.debug = old_debug

# Generated at 2022-06-23 23:32:22.747271
# Unit test for function eager
def test_eager():
    assert eager(range)(0, 10) == list(range(0, 10))

# Generated at 2022-06-23 23:32:25.061849
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_1'



# Generated at 2022-06-23 23:32:29.753809
# Unit test for function warn
def test_warn():
    with warnings.catch_warnings(record=True) as w:
        warn('test warning')
        assert len(w) == 1
        assert str(w[0].message) == 'test warning'


if __name__ == "__main__":
    test_warn()

# Generated at 2022-06-23 23:32:37.474397
# Unit test for function debug
def test_debug():
    from unittest.mock import Mock
    settings.debug = True
    message = 'hello'
    mock_stderr = Mock()
    sys.stderr = mock_stderr
    debug(lambda : message)
    mock_stderr.write.assert_called_once()
    mock_stderr.write.assert_called_once_with('\x1b[36;1m{}\x1b[0m'.format(message))
    settings.debug = False
    warn('something')
    mock_stderr.write.assert_called_with('\x1b[33;1msomething\x1b[0m')

# Generated at 2022-06-23 23:32:40.276704
# Unit test for function debug
def test_debug():
    messages.debug = '[debug]'
    messages.warn = '[warning]'
    assert debug(lambda: 'msg') is None
    debug = lambda: ''
    assert debug() is None

# Generated at 2022-06-23 23:32:43.322111
# Unit test for function eager
def test_eager():
    from inspect import isfunction
    @eager
    def test() -> Iterable[int]:
        yield 1
        yield 2
        yield 3
    
    assert len(test()) == 3
    assert isfunction(test)

# Generated at 2022-06-23 23:32:50.049697
# Unit test for function warn
def test_warn():
    import pytest
    from unittest.mock import patch
    from ..conf import settings
    with patch('sys.stderr') as stderr:
        settings.color = False
        warn('test')
        assert stderr.write.call_args[0][0] == '[py-backwards] test'

        settings.color = True
        warn('test')
        assert stderr.write.call_args[0][0] == '[py-backwards] \x1b[31mtest\x1b[0m\n'



# Generated at 2022-06-23 23:32:53.572055
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    from mockup import patch

    captured = StringIO()

    def f():
        return 'message'

    with patch('sys.stderr', new=captured):
        debug(f)
    assert captured.getvalue() == ''

    with patch('sys.stderr', new=captured):
        with patch('py_backwards.utils.settings.debug', True):
            debug(f)
    assert captured.getvalue() == '{warn} message\n'.format(warn=messages.DEBUG)

# Generated at 2022-06-23 23:32:55.353895
# Unit test for function warn
def test_warn():
    def test() -> None:
        warn('message')

    captured = capsys.readouterr()
    test()
    assert captured.out == messages.warn('message') + '\n'



# Generated at 2022-06-23 23:32:57.226661
# Unit test for function eager
def test_eager():
    import warnings
    warnings.warn = warn
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1,2,3]

# Generated at 2022-06-23 23:32:59.996411
# Unit test for function get_source
def test_get_source():
    test_func = get_source

    def tester() -> str:
        return 'foo: 0'

    assert test_func(tester) == '    return \'foo: 0\''

    assert test_func(get_source) == test_func.__doc__

# Generated at 2022-06-23 23:33:03.378248
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print('testing VariablesGenerator')
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    print('OK!')

# Generated at 2022-06-23 23:33:06.716091
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg=VariablesGenerator()
    unique_name = vg._generate("a")
    assert unique_name == "_py_backwards_0_a"
    unique_name = vg._generate("b")
    assert unique_name =="_py_backwards_0_b"



# Generated at 2022-06-23 23:33:16.911199
# Unit test for function get_source
def test_get_source():
    from py_backwards.utils.utils import get_source, test_get_source
    def test():
        return None

    assert get_source(test) == 'def test():\n    return None'

# Generated at 2022-06-23 23:33:19.156403
# Unit test for function warn
def test_warn():
    with captured_output() as (out, err):
        warn('test')
        assert 'test' in err.getvalue()


# Generated at 2022-06-23 23:33:22.652799
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: 'Message: {}'.format(x)
    debug(lambda: 'Test debug')
    settings.debug = True
    try:
        debug(lambda: 'Test debug')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:33:26.958766
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert not VariablesGenerator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:33:31.166757
# Unit test for function warn
def test_warn():
    import io
    import sys
    old_stderr = sys.stderr
    try:
        # Suppress output
        sys.stderr = io.StringIO()

        warn('message')

        # The warning contains `[WARNING]: `.
        # So the output is at least 10 characters
        assert sys.stderr.getvalue()
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-23 23:33:35.135089
# Unit test for function warn
def test_warn():
    from unittest.mock import patch
    import io

    # pylint: disable=unnecessary-lambda
    with patch('sys.stderr', new=io.StringIO()) as fake_stderr:
        warn('test')
        assert fake_stderr.getvalue().strip() == messages.warn('test')



# Generated at 2022-06-23 23:33:37.852783
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('message')
    assert sys.stderr.getvalue() == messages.warn('message') + '\n'

# Generated at 2022-06-23 23:33:40.714382
# Unit test for function eager
def test_eager():
    from random import randint

    @eager
    def randints(n: int) -> Iterable[int]:
        for i in range(n):
            yield randint(0, 100)

    randints(10)

# Generated at 2022-06-23 23:33:44.342459
# Unit test for function warn
def test_warn():
    from io import StringIO
    captured_output = StringIO()
    sys.stderr = captured_output
    warn('test_warn')
    output = captured_output.getvalue()
    assert output.strip() == messages.warn('test_warn'), "Give warning message"
    sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:33:47.188725
# Unit test for function get_source
def test_get_source():
    def function():
        """Function with padding."""
        print('Content')
        # Second line

    assert get_source(function) == '"""Function with padding."""\nprint(\'Content\')\n', get_source(function)



# Generated at 2022-06-23 23:33:53.739450
# Unit test for function debug
def test_debug():
    """Tests function debug."""
    import sys
    from io import StringIO

    stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        settings.debug = False
        debug(lambda: 'debug message')
        assert sys.stderr.getvalue() == ''
        settings.debug = True
        debug(lambda: 'debug message')
        assert sys.stderr.getvalue() == messages.debug('debug message') + '\n'
    finally:
        sys.stderr = stderr

# Generated at 2022-06-23 23:33:56.448034
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        for i in range(10):
            yield i

    assert foo() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:33:57.323604
# Unit test for function warn
def test_warn():
    warn('Test')  # Really?



# Generated at 2022-06-23 23:34:01.283385
# Unit test for function warn
def test_warn():
    import warnings
    warnings.resetwarnings()
    with warnings.catch_warnings(record=True) as w:
        messages.warn('warn')
        assert len(w) == 1
        assert str(w[0].message) == "warn"
        assert w[0].category == UserWarning


# Generated at 2022-06-23 23:34:03.851249
# Unit test for function get_source
def test_get_source():
    def foo():
        a = 1
        b = 2
        return a + b
    assert (get_source(foo) ==
            'a = 1\n'
            'b = 2\n'
            'return a + b')

# Generated at 2022-06-23 23:34:09.375624
# Unit test for function warn
def test_warn():
    # Save the state of stdout, then redirect it to a temporary file
    _stdout = sys.stdout
    _testout = io.StringIO()
    sys.stdout = _testout
    # run test
    warn('warn message')
    # Reset stdout and collect output
    sys.stdout = _stdout
    output = _testout.getvalue()

    # tests
    assert output == '\x1b[33mwarn message\x1b[0m\n'



# Generated at 2022-06-23 23:34:13.130195
# Unit test for function get_source
def test_get_source():
    def fn(a: int, b: int) -> int:
        return a + b
    assert get_source(fn) == ("def fn(a: int, b: int) -> int:\n"
                              "    return a + b")
    assert get_source(fn) == ("def fn(a: int, b: int) -> int:\n"
                              "    return a + b")
test_get_source()

# Generated at 2022-06-23 23:34:16.520795
# Unit test for function warn
def test_warn():
    import io
    import contextlib
    from .messages import MESSAGES

    stderr = io.StringIO()
    with contextlib.redirect_stderr(stderr):
        warn('test warn')
    assert stderr.getvalue() == MESSAGES['warning'] + ' test warn\n'



# Generated at 2022-06-23 23:34:18.455998
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-23 23:34:20.744806
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == get_source(test_get_source).lstrip()

# Generated at 2022-06-23 23:34:24.544068
# Unit test for function debug
def test_debug():
    global settings
    settings = type('', (), {})()
    settings.debug = True

    with warnings.catch_warnings(record=True) as caught:
        debug(lambda: 'hello')
        assert len(caught) == 1
        assert 'hello' in str(caught[0].message)



# Generated at 2022-06-23 23:34:28.927703
# Unit test for function eager
def test_eager():
    i = 0
    def gen():
        nonlocal i
        while True:
            yield i
            i += 1
    assert eager(gen)() == []
    assert eager(gen)() == [0]
    assert eager(gen)() == [0, 1]


# Generated at 2022-06-23 23:34:33.206283
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stdout

    io = StringIO()
    with redirect_stdout(io):
        debug(lambda: 'Debug message')
    assert io.getvalue() == ''

    settings.debug = True
    io = StringIO()
    with redirect_stdout(io):
        debug(lambda: 'Debug message')
    assert io.getvalue() == messages.debug('Debug message\n')

# Generated at 2022-06-23 23:34:41.179463
# Unit test for function eager
def test_eager():
    import random
    import string
    test_string = ''.join(random.choice(string.ascii_uppercase) for i in range(5))
    @eager
    def test_function(number):
        for i in range(number):
            yield '{}_{}'.format(i, test_string)
    assert test_function(4) == ['0_{}'.format(test_string), '1_{}'.format(test_string), '2_{}'.format(test_string), '3_{}'.format(test_string)]


# Generated at 2022-06-23 23:34:43.094533
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(1000):
        assert VariablesGenerator.generate("test") != 'test'

# Generated at 2022-06-23 23:34:50.594192
# Unit test for function debug
def test_debug():
    def inner(should_print: bool) -> None:
        def get_message() -> str:
            return 'hi'

        settings.update(debug=should_print)
        debug(get_message)

    with mock.patch('sys.stderr.write') as mock_write:
        inner(False)
        assert not mock_write.called
        mock_write.reset_mock()

        inner(True)
        assert mock_write.call_count == 1
        assert mock_write.call_args[0][0].startswith(messages.debug_prefix)



# Generated at 2022-06-23 23:34:52.022157
# Unit test for function get_source
def test_get_source():
    def test_function():
        return 1

    assert get_source(test_function) == 'return 1'

# Generated at 2022-06-23 23:34:57.972163
# Unit test for function warn
def test_warn():
    import sys
    import contextlib
    from inspect import cleandoc
    from io import StringIO

    CLEAN_LAMBDA = cleandoc('''\
        lambda: None
    ''')

    def check_warn(
            message: str,
            function: Callable[[], None] = None):
        with contextlib.redirect_stdout(StringIO()):
            if function is None:
                function = eval(CLEAN_LAMBDA)  # type: ignore
            function()

        assert message in sys.stdout.getvalue()

    check_warn('(py-backwards) Warning - test', lambda: warn('test'))

# Generated at 2022-06-23 23:35:02.092114
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('variable') == '_py_backwards_variable_0'
    assert generator.generate('variable') == '_py_backwards_variable_1'
    assert generator.generate('variable') == '_py_backwards_variable_2'

# Generated at 2022-06-23 23:35:03.876275
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    if get_source(f) != 'pass':
        raise AssertionError

# Generated at 2022-06-23 23:35:06.091226
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello')
    settings.debug = False
    debug(lambda: 'World')

# Generated at 2022-06-23 23:35:08.088078
# Unit test for function get_source
def test_get_source():
    def some_function(a):
        return a*2

    assert get_source(some_function) == '    return a*2\n'

# Generated at 2022-06-23 23:35:09.878422
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2

    assert eager(test)() == [1, 2]


# Generated at 2022-06-23 23:35:11.094954
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(1000))() == list(range(1000))

# Generated at 2022-06-23 23:35:13.592803
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate('qwerty'))
    print(VariablesGenerator.generate('qwerty'))
    print(VariablesGenerator.generate('qwerty'))

# Generated at 2022-06-23 23:35:19.274864
# Unit test for function debug
def test_debug():
    import io

    out = io.StringIO()
    sys.stderr = out
    try:
        global settings
        old_debug = settings.debug
        settings.debug = True
        debug(lambda: 'x')
        assert out.getvalue() == 'DEBUG: x\n'
    finally:
        settings.debug = old_debug
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:35:28.930699
# Unit test for function eager
def test_eager():
    class Iterable:
        def __init__(self, *items):
            self._items = items
            self._calls_counter = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self._calls_counter < len(self._items):
                self._calls_counter += 1
                return self._items[self._calls_counter - 1]
            else:
                raise StopIteration()

    @eager
    def generate(a):
        for x in range(a):
            yield x

    assert generate(3) == [0, 1, 2], "eager generator works incorrectly"
    assert generate(0) == [], "eager generator works incorrectly"
    assert generate(-3) == [], "eager generator works incorrectly"

# Generated at 2022-06-23 23:35:31.544807
# Unit test for function warn
def test_warn():
    from .test_utils import CaptureOutput, captured_output

    with CaptureOutput() as output:
        warn('test_warn')

    assert captured_output(output) == '\x1b[33mtest_warn\x1b[39m\n'



# Generated at 2022-06-23 23:35:32.844298
# Unit test for function eager
def test_eager():
    assert eager(lambda: 1)(0) == [1]
    assert eager(lambda: [])(0) == []


# Generated at 2022-06-23 23:35:37.903706
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import random
    import string

    def tester(f, k):
        for i in range(k):
            assert f()[-1].isdigit()

    random.seed(0)
    k = 100
    VariablesGenerator._counter = 0
    f = lambda: VariablesGenerator.generate(''.join([random.choice(string.ascii_letters) for _ in range(7)]))
    tester(f, k)

# Generated at 2022-06-23 23:35:46.191084
# Unit test for function debug
def test_debug():
    import sys
    import io
    import contextlib
    from ..conf import settings

    old_debug = settings.debug
    old_stderr = sys.stderr
    text_trap = io.StringIO()

    try:
        sys.stderr = text_trap
        settings.debug = True
        debug(lambda: "hi!")
        assert text_trap.getvalue() == "hi!\n"
    finally:
        sys.stderr = old_stderr
        settings.debug = old_debug
        text_trap.close()

# Generated at 2022-06-23 23:35:49.168489
# Unit test for function warn
def test_warn():
    import sys, io
    captured = io.StringIO()
    sys.stderr = captured
    msg = "foo"
    warn(msg)
    assert captured.getvalue() == "{}\n".format(msg)

# Generated at 2022-06-23 23:35:56.512640
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import contextmanager
    from contextlib import redirect_stderr

    message = 'This should be printed on the stderr'

    @contextmanager
    def captured_stderr():
        new_stderr = StringIO()
        with redirect_stderr(new_stderr):
            try:
                yield new_stderr
            finally:
                sys.stderr = sys.__stderr__

    with captured_stderr() as stderr:
        warn(message)

    assert stderr.getvalue().strip() == message

# Generated at 2022-06-23 23:36:01.048800
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == '''\
        def get_source(fn: Callable[..., Any]) -> str:
            \"\"\"Returns source code of the function.\"\"\"
            source_lines = getsource(fn).split('\\n')
            padding = len(re.findall(r'^(\\s*)', source_lines[0])[0])
            return '\\n'.join(line[padding:] for line in source_lines)
    '''

# Generated at 2022-06-23 23:36:03.829535
# Unit test for function eager
def test_eager():
    @eager
    def foo():
         yield from [1, 2, 3]
    assert foo() == [1, 2, 3]

# Generated at 2022-06-23 23:36:06.371387
# Unit test for function eager
def test_eager():
    def gen(x):
        for i in range(x):
            yield i

    assert eager(gen)(10) == list(gen(10))

# Generated at 2022-06-23 23:36:10.102471
# Unit test for function eager
def test_eager():
    test_list = [1,2,3,4]
    def test_iterable():
        for i in test_list:
            yield i
    assert(test_iterable() is not test_iterable())
    assert(test_iterable() == eager(test_iterable)())

# Generated at 2022-06-23 23:36:10.676273
# Unit test for function get_source

# Generated at 2022-06-23 23:36:13.074824
# Unit test for function warn
def test_warn():
    '''
    >>> warn('test text')
    \x1b[1m[WARNING]\x1b[0m test text
    '''

# Generated at 2022-06-23 23:36:16.884972
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')
        assert f.getvalue().startswith(messages.debug(''))



# Generated at 2022-06-23 23:36:20.324598
# Unit test for function eager
def test_eager():
    import itertools

    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen(5) == list(itertools.islice(range(5), 5))



# Generated at 2022-06-23 23:36:24.099300
# Unit test for function get_source
def test_get_source():
    def example(arg1: int, arg2: float) -> bool:
        if arg1 + arg2 > 0:
            return True
        else:
            return False
    assert get_source(example) == ('def example(arg1: int, arg2: float) -> bool:'
                                   '\n    if arg1 + arg2 > 0:'
                                   '\n        return True'
                                   '\n    else:'
                                   '\n        return False')

# Generated at 2022-06-23 23:36:26.537604
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'debug-message')
    settings.debug = True
    debug(lambda: 'debug-message')



# Generated at 2022-06-23 23:36:29.555887
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for _ in range(100):
        new_var = VariablesGenerator.generate('variable_name')
        assert new_var == f'_py_backwards_{{"variable_name"}}_{{"{VariablesGenerator._counter - 1}"}}'

# Generated at 2022-06-23 23:36:37.995726
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest
    vg = VariablesGenerator()
    assert vg._counter == 0
    assert vg.generate('variable1') == '_py_backwards_variable1_0'
    assert vg._counter == 1
    assert vg.generate('variable2') == '_py_backwards_variable2_1'
    assert vg.generate('variable1') == '_py_backwards_variable1_2'
    with pytest.raises(AttributeError):
        vg._counter = 5
    assert vg._counter == 3

# Generated at 2022-06-23 23:36:39.816654
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-23 23:36:42.427534
# Unit test for function get_source
def test_get_source():
    def foo():
        x = 3
        y = 4
        z = x + y
        return z
    assert get_source(foo) == 'y = 4\nz = x + y\nreturn z'

# Generated at 2022-06-23 23:36:48.521950
# Unit test for function debug
def test_debug():
    settings.debug = True

    def get_message():
        return 'test message'

    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        debug(get_message)
        message = mock_stderr.getvalue().strip()
    assert message.startswith('[py-backwards] DEBUG ')
    assert message.endswith('test message')


# Check function debug
test_debug()

# Generated at 2022-06-23 23:36:50.945722
# Unit test for function warn
def test_warn():
    out = io.StringIO()
    with contextlib.redirect_stderr(out):
        warn('foo')
    assert 'foo' in out.getvalue()



# Generated at 2022-06-23 23:36:52.774168
# Unit test for function eager
def test_eager():
    assert eager(lambda x: range(10))(x=3) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:36:55.776835
# Unit test for function debug
def test_debug():
    import unittest.mock

    with unittest.mock.patch.object(messages, 'debug') as mocked_debug:
        debug(lambda: 'Some message')
        mocked_debug.assert_called_once_with('Some message')



# Generated at 2022-06-23 23:36:57.685421
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3
    assert eager(foo)() == [1, 2, 3]



# Generated at 2022-06-23 23:37:03.272588
# Unit test for function get_source
def test_get_source():
    def test_func():
        x = 5
        y = 8
        return x + y

    try:
        assert get_source(test_func) == """\
        x = 5
        y = 8
        return x + y"""
    except AssertionError:
        raise AssertionError('Unit-test for function get_source has failed.')

# Generated at 2022-06-23 23:37:05.290004
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test message')
    settings.debug = False
    debug(lambda: 'test message')

# Generated at 2022-06-23 23:37:09.539926
# Unit test for function eager
def test_eager():
    @eager
    def fibonacci(n):
        if n < 2:
            yield n
        else:
            a, b = 0, 1
            for _ in range(n):
                yield a
                a, b = b, a + b

    assert fibonacci(5) == [0, 1, 1, 2, 3]

# Generated at 2022-06-23 23:37:10.883274
# Unit test for function get_source
def test_get_source():
    def test() -> int: return 3 + 4
    print(get_source(test))

# Generated at 2022-06-23 23:37:13.695613
# Unit test for function warn
def test_warn():
    try:
        sys.stderr = StringIO()
        warn('foo')
        assert sys.stderr.getvalue() == 'foo\n'
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:37:15.065020
# Unit test for function get_source
def test_get_source():
    def foo(a):
        return a

    assert get_source(foo) == 'return a'

# Generated at 2022-06-23 23:37:16.019027
# Unit test for function warn
def test_warn():
    pass



# Generated at 2022-06-23 23:37:18.909874
# Unit test for function eager
def test_eager():
    test_list = [1, 2, 3, 4, 5]
    result = eager(test_list.copy())(0)
    assert all([x == y for x, y in zip(test_list, result)])
    result = eager(lambda: test_list.copy())(0)
    assert all([x == y for x, y in zip(test_list, result)])



# Generated at 2022-06-23 23:37:20.925322
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('_var') != VariablesGenerator.generate('_var')

# Generated at 2022-06-23 23:37:23.118422
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-23 23:37:27.108609
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_2'

# Generated at 2022-06-23 23:37:31.026658
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        called = 0
        def get_message():
            nonlocal called
            called += 1
            return 'test'

        debug(get_message)
        assert called == 1

        settings.debug = False
        called = 0
        debug(get_message)
        assert called == 0
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:37:32.982370
# Unit test for function eager
def test_eager():
    def foo(n):
        for i in range(n):
            yield i

    assert eager(foo)(2) == list(foo(2))

# Generated at 2022-06-23 23:37:35.147556
# Unit test for function get_source
def test_get_source():
    from inspect import getsource

    def foo(a):
        return 'bar'

    print(get_source(foo))
    print(getsource(foo))

# Generated at 2022-06-23 23:37:37.155808
# Unit test for function get_source
def test_get_source():
    def test():
        print('foo')

    assert get_source(test) == '    print(\'foo\')'

# Generated at 2022-06-23 23:37:45.148965
# Unit test for function debug
def test_debug():
    import StringIO
    import sys

    output = StringIO.StringIO()
    saved = sys.stderr
    try:
        sys.stderr = output
        debug(lambda: 'Test')
        settings.debug = True
        debug(lambda: 'Debug')
        settings.debug = False
        debug(lambda: 'Debug')
    finally:
        sys.stderr = saved

    assert output.getvalue() == ('\x1b[1;31mDebug\x1b[0m\n'
                                 '\x1b[1;33m[DEBUG] Debug\x1b[0m\n')

# Generated at 2022-06-23 23:37:47.536391
# Unit test for function eager
def test_eager():
    def func(n):
        for i in range(n):
            yield i

    func_eager = eager(func)
    assert func(10) == func_eager(10)


# Generated at 2022-06-23 23:37:49.467460
# Unit test for function debug
def test_debug():
    with settings.override(debug=True):
        debug(lambda: 'hello world!')
        # TODO: test that string "hello world!" is printed to sys.stderr
    with settings.override(debug=False):
        debug(lambda: 'hello world!')
        # TODO: test that string "hello world!" is not printed to sys.stderr



# Generated at 2022-06-23 23:37:51.639531
# Unit test for function get_source
def test_get_source():

    def foo():
        pass

    assert get_source(foo) == dedent('''\
    def foo():
        pass
    ''')

# Generated at 2022-06-23 23:37:55.092123
# Unit test for function get_source
def test_get_source():
    if not settings.test:
        return
    # This function is just a test function, nothing to test here
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-23 23:37:58.192186
# Unit test for function debug
def test_debug():
    def get_message():
        return "Some debug message"
    debug(get_message)
    # FIXME: Should be mocked, but pytest-mock does not work with Python < 3.7

# Generated at 2022-06-23 23:38:04.648103
# Unit test for function warn
def test_warn():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    def test():
        warn('This is test message')

    old_stderr, sys.stderr = sys.stderr, StringIO()
    try:
        test()
    finally:
        value = sys.stderr.getvalue()
        sys.stderr = old_stderr
    assert 'This is test message' in value



# Generated at 2022-06-23 23:38:05.666802
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-23 23:38:07.443518
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'x')
    settings.debug = False


# Generated at 2022-06-23 23:38:14.563797
# Unit test for function debug
def test_debug():
    messages.debug = lambda msg: msg

    def raise_error():
        raise ValueError('TEST')

    debug(lambda: 'TEST #1')
    assert settings.debug == False
    settings.debug = True
    debug(lambda: 'TEST #2')
    settings.debug = False

    for debug_method in (debug, raise_error):
        debug_method(lambda: 'TEST #3')
        assert settings.debug == True
        try:
            debug_method(lambda: 'TEST #3')
            assert False
        except ValueError:
            pass

# Generated at 2022-06-23 23:38:15.602192
# Unit test for function warn
def test_warn():
    warn('test message')


# Generated at 2022-06-23 23:38:19.938560
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass\n'

__all__ = [
    'eager',
    'VariablesGenerator',
    'get_source',
    'warn',
    'test_get_source',
]

# Generated at 2022-06-23 23:38:27.232615
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    with patch.object(sys, 'stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'foo')
        assert fake_stderr.getvalue() == ''

        settings.debug = True
        debug(lambda: 'foo')
        assert fake_stderr.getvalue() == '[DEBUG] foo\n'

        settings.debug = False
        debug(lambda: 'foo')
        assert fake_stderr.getvalue() == '[DEBUG] foo\n'



# Generated at 2022-06-23 23:38:29.510186
# Unit test for function get_source
def test_get_source():
    """
    >>> @get_source
    ... def test():
    ...     print(1)
    ...     print(2)
    """

# Generated at 2022-06-23 23:38:36.334100
# Unit test for function debug
def test_debug():
    message = 'This is debug message'

    class FakeStdErr:
        def write(self, *args, **kwargs):
            pass

    debug_message = None

    def _debug(get_message: Callable[[], str]) -> None:
        nonlocal debug_message
        debug_message = get_message()

    with patch('sys.stderr', new=FakeStdErr()):
        with patch('py_backwards.utils.settings.debug', new=False):
            debug(_debug)
        assert debug_message is None

        with patch('py_backwards.utils.settings.debug', new=True):
            debug(lambda: message)
        assert debug_message is message



# Generated at 2022-06-23 23:38:38.225225
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
        yield 2
        yield 3

    assert generator() == [1, 2, 3]

# Generated at 2022-06-23 23:38:42.240570
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    assert v.generate("variable") == "_py_backwards_variable_0"
    assert v.generate("variable") == "_py_backwards_variable_1"


# Generated at 2022-06-23 23:38:45.486713
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('foo') == '_py_backwards_foo_0'
    assert VariablesGenerator.generate('bar') == '_py_backwards_bar_1'



# Generated at 2022-06-23 23:38:46.553094
# Unit test for function eager

# Generated at 2022-06-23 23:38:52.350235
# Unit test for function debug
def test_debug():
    output = StringIO()
    sys.stderr = output

    def get_message():
        return 'not changed'

    debug(get_message)
    assert output.getvalue() == ''

    try:
        settings.debug = True
        debug(get_message)
        assert re.match(
            r'^\033\[0;38;5;[0-9]+m\[[0-9]{2}:[0-9]{2}:[0-9]{2}\] DEBUG: not changed\n\033\[0m$',
            output.getvalue()
        )
    finally:
        settings.debug = False
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:38:56.004859
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    with StringIO() as buf, redirect_stdout(buf):
        warn("blablabla")
        res = buf.getvalue()
        assert res[:3] == "⚠️"
        assert res[3] == " "
        assert res[4:] == "blablabla"


# Generated at 2022-06-23 23:39:01.872616
# Unit test for function warn
def test_warn():
    from py_backwards.utils.mock import MockSys  # type: ignore
    import sys
    sys_stdout = sys.stdout
    sys_stderr = sys.stderr

    try:
        sys.stdout = sys.stderr = MockSys()
        warn('test')
        output = sys.stderr.output
        assert output == messages.warn('test') + '\n'
    finally:
        sys.stdout = sys_stdout
        sys.stderr = sys_stderr

# Generated at 2022-06-23 23:39:03.660877
# Unit test for function debug
def test_debug():
    def m():
        return "OK"
    debug(m)

# Generated at 2022-06-23 23:39:06.843138
# Unit test for function debug
def test_debug():
    class Recorder(list):
        def write(self, value):
            self.append(value)
    sys.stderr = Recorder()
    debug(lambda: "message")
    assert 1 == 0

# Generated at 2022-06-23 23:39:12.560687
# Unit test for function get_source
def test_get_source():
    def example_function():
        """This is a docstring"""
        if True:
            print('Hello Backwards')
            print('hello_world')

    assert get_source(example_function) == '''def example_function():
    """This is a docstring"""
    if True:
        print('Hello Backwards')
        print('hello_world')
'''

# Generated at 2022-06-23 23:39:15.404034
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('x') == 'x_0'
    assert generator.generate('y') == 'y_1'

# Generated at 2022-06-23 23:39:23.469181
# Unit test for function debug
def test_debug():
    cases = [
        (lambda: 'a', {'debug': True}, 'a'),
        (lambda: 'a', {'debug': False}, ''),
        (lambda: '\n a', {'debug': True}, '\n a'),
        (lambda: '\n a', {'debug': False}, ''),
    ]
    for i, (get_message, settings, expected) in enumerate(cases):
        with settings.override(**settings):
            sys.stderr = StringIO()
            try:
                debug(get_message)
                assert sys.stderr.getvalue() == expected
            except:
                print('Failed at case {}'.format(i))
                raise
            finally:
                sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:39:25.940111
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate("a")
    b = VariablesGenerator.generate("a")
    assert a != b


# Generated at 2022-06-23 23:39:31.876442
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'

# Generated at 2022-06-23 23:39:36.525786
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('my_var') == '_py_backwards_my_var_0'
    assert VariablesGenerator.generate('my_var') == '_py_backwards_my_var_1'
    assert VariablesGenerator.generate('my_var') == '_py_backwards_my_var_2'

# Generated at 2022-06-23 23:39:39.978519
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    source = re.sub(r' +$', '', get_source(foo), flags=re.MULTILINE)
    assert source == 'def foo():\n    pass'

# Generated at 2022-06-23 23:39:42.910071
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('super_variable') == '_py_backwards_super_variable_0'
    assert VariablesGenerator.generate('super_variable') == '_py_backwards_super_variable_1'



# Generated at 2022-06-23 23:39:53.365268
# Unit test for function debug
def test_debug():
    def test_function(debug_enabled=True):
        settings.debug = debug_enabled
        messages_list = []
        with mock.patch('sys.stdout', new=mock.StringIO()) as fake_stdout:
            def get_message():
                messages_list.append('test message')
                return messages_list[-1]
            debug(get_message)
            assert fake_stdout.getvalue().strip() == ''

        with mock.patch('sys.stderr', new=mock.StringIO()) as fake_stderr:
            debug(get_message)
            assert fake_stderr.getvalue().strip() == messages.debug(messages_list[-1])
        assert len(messages_list) == 2

    test_function()
    test_function(False)

# Generated at 2022-06-23 23:39:55.897801
# Unit test for function get_source
def test_get_source():
    def function():
        def inner_function():
            pass
    assert get_source(function) == 'def inner_function():\n            pass'

# Generated at 2022-06-23 23:40:00.963425
# Unit test for function debug
def test_debug():
    import io
    from ..conf import Settings
    settings.debug = True
    with io.StringIO() as stream:
        sys.stderr = stream
        debug(lambda: 'does something')
        assert stream.getvalue() == '\x1b[34mdebug:\x1b[0m does something\n'
    settings.debug = Settings(debug=False)

# Generated at 2022-06-23 23:40:04.385245
# Unit test for function get_source
def test_get_source():
    def test_func1():
        return 1

    def test_func2():
        """
        Function for test
        """
        return 2

    assert get_source(test_func1) == 'return 1'
    assert get_source(test_func2) == '    return 2'



# Generated at 2022-06-23 23:40:12.317304
# Unit test for function get_source
def test_get_source():
    def get_source(string):
        def fn(string):
            return string
        return getsource(fn)

    # No padding
    assert get_source("some_string") == 'def fn(string):\n    return string\n'

    # With padding
    assert get_source("    some_string") == 'def fn(string):\n    return string\n'

    # With several lines and padding
    assert get_source("    some_string\n    some_string") == 'def fn(string):\n    return string\n'

# Generated at 2022-06-23 23:40:14.862384
# Unit test for function eager
def test_eager():
    def g() -> Iterable[int]:
        for i in range(10):
            yield i

    assert eager(g)() == list(g())


# Generated at 2022-06-23 23:40:17.732142
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('counter') == '_py_backwards_counter_0'
    assert VariablesGenerator.generate('counter') == '_py_backwards_counter_1'

# Generated at 2022-06-23 23:40:20.033661
# Unit test for function eager
def test_eager():
    def f(x: int) -> Iterable[int]:
        yield x
        yield x + 1

    g = eager(f)
    assert g(0) == [0, 1]

# Generated at 2022-06-23 23:40:23.602605
# Unit test for function debug
def test_debug():
    settings.debug = True
    from contextlib import redirect_stderr
    from io import StringIO
    with redirect_stderr(StringIO()) as out:
        debug(lambda: 'test')
    assert 'test' in out.getvalue()



# Generated at 2022-06-23 23:40:28.600968
# Unit test for function eager
def test_eager():
    from random import randrange
    from ..utils import empty

    @eager
    def some_generator():
        for i in range(randrange(5)):
            yield 'hello{}'.format(i)

    res = some_generator()
    assert len(res) in [0, 1, 2, 3, 4]
    assert not empty(res)

# Generated at 2022-06-23 23:40:31.469578
# Unit test for function debug
def test_debug():
    try:
        settings.debug = True
        debug(lambda: 'a')
    except Exception:
        assert False
    else:
        assert True
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:40:35.985256
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Setup
    VariablesGenerator._counter = 0

    # Exercise
    generator_1 = VariablesGenerator()
    generator_2 = VariablesGenerator()

    # Verify
    assert generator_1.generate('var') == '_py_backwards_var_0'
    assert generator_2.generate('var') == '_py_backwards_var_1'

# Generated at 2022-06-23 23:40:37.874098
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator
    assert gen.generate('var') == '_py_backwards_var_0'
    assert gen.generate('var') == '_py_backwards_var_1'

# Generated at 2022-06-23 23:40:41.239919
# Unit test for function warn
def test_warn():
    from .utils import TestCase

    class WarnTest(TestCase):
        def test_warn(self) -> None:
            sys.stderr = self.stringio = StringIO()
            warn('message 1')
            warn('message 2')
            self.assertEquals(
                self.stringio.getvalue(),
                'WARNING: message 1\nWARNING: message 2\n',
            )

    WarnTest().run()



# Generated at 2022-06-23 23:40:43.138360
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    print(vg.generate("a"))
    print(vg.generate("a"))

# Generated at 2022-06-23 23:40:47.414552
# Unit test for function warn
def test_warn():
    import pytest
    from io import StringIO

    with StringIO() as sys.stderr:
        warn('foo')

    assert sys.stderr.getvalue() == messages.warn('foo') + '\n'



# Generated at 2022-06-23 23:40:55.196806
# Unit test for function get_source
def test_get_source():
    def fn(a, b):
        '''
        docstring
        '''
        return a + b

    # Test without docstring
    assert (
        get_source(fn) ==
        "def fn(a, b):\n"
        "    return a + b"
    )

    # with docstring
    assert (
        get_source(fn) ==
        "def fn(a, b):\n"
        "    '''\n"
        "    docstring\n"
        "    '''\n"
        "    return a + b"
    )

# Generated at 2022-06-23 23:40:59.353556
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Something')
        assert False
    except SystemExit:
        pass
    finally:
        settings.debug = True
        import sys; sys.exit = exit

if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:41:01.870809
# Unit test for function eager
def test_eager():
    def some_func():
        for i in range(4):
            yield i
    assert eager(some_func)() == [0, 1, 2, 3]

# Generated at 2022-06-23 23:41:07.217164
# Unit test for function warn
def test_warn():
    settings.debug = False
    import io
    import sys
    output = io.StringIO()
    sys.stderr = output
    warn("warning")
    sys.stderr = sys.__stderr__

    assert output.getvalue() == "\033[93mwarning\033[0m\n"


# Generated at 2022-06-23 23:41:08.834642
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-23 23:41:12.436685
# Unit test for function get_source
def test_get_source():
    def foo():
        """
        This function is used to test the get_source function.
        """
        return 'bar'

    assert get_source(foo) == '''def foo():
    """
    This function is used to test the get_source function.
    """
    return 'bar'
'''



# Generated at 2022-06-23 23:41:14.391368
# Unit test for function eager
def test_eager():
    @eager
    def tr():
        yield 1
        yield 2
        yield 3

    assert tr() == [1, 2, 3]

# Generated at 2022-06-23 23:41:17.505456
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: x
    settings.debug = True
    try:
        debug(lambda: 'testing debug')
        assert sys.stderr.getvalue() == 'testing debug\n'
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:41:20.788861
# Unit test for function eager
def test_eager():
    @eager
    def generate_numbers(x: int, y: int) -> Iterable[int]:
        for y in range(y):
            yield x + y

    assert generate_numbers(1, 2) == [1, 2]


# Generated at 2022-06-23 23:41:23.771599
# Unit test for function eager
def test_eager():
    from inspect import signature
    from typing import Iterable, List

    def fn(arg: int) -> Iterable[int]:
        yield arg

    @eager
    def fn(arg: int) -> List[int]:
        yield arg

    assert list(signature(fn).return_annotation.__args__) == [List[int]]
    assert fn(1) == [1]

# Generated at 2022-06-23 23:41:26.409676
# Unit test for function eager
def test_eager():
    import random
    numbers = [i for i in range(10)]
    random.shuffle(numbers)

    def yielder():
        for i in numbers:
            yield i

    def listy():
        return numbers

    assert eager(yielder)() == eager(listy)()

# Generated at 2022-06-23 23:41:29.132978
# Unit test for function eager
def test_eager():
    import pytest
    from itertools import count

    @eager
    def generator():
        for i in count():
            yield i

    assert generator() == [0, 1, 2]

# Generated at 2022-06-23 23:41:31.780655
# Unit test for function eager
def test_eager():
    @eager
    def numbers() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert numbers() == [1, 2, 3]



# Generated at 2022-06-23 23:41:40.627113
# Unit test for function get_source
def test_get_source():  # pylint: disable=no-self-use
    class Test:
        """Some docstring"""
        def test(self):
            """Some docstring
            Parameters
            ----------
            arg1: int
                Some description
            arg2: str
                Some description
            """
            return 'OK'


# Generated at 2022-06-23 23:41:45.899007
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class FakeVariablesGenerator(VariablesGenerator):
        _counter = 0

    assert FakeVariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert FakeVariablesGenerator.generate('a') == '_py_backwards_a_1'



# Generated at 2022-06-23 23:41:47.097711
# Unit test for function warn
def test_warn():
    warn('warned')



# Generated at 2022-06-23 23:41:49.647795
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'


# Generated at 2022-06-23 23:41:53.040933
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'


# Generated at 2022-06-23 23:41:54.322736
# Unit test for function get_source
def test_get_source():
    def f():
        return 1
    assert get_source(f) == 'return 1'

# Generated at 2022-06-23 23:41:56.237010
# Unit test for function eager
def test_eager():
    @eager
    def test_func():
        yield from range(10)

    assert test_func() == list(range(10))

# Generated at 2022-06-23 23:41:59.003290
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("abc") == '_py_backwards_abc_0'
    assert VariablesGenerator.generate("abc") == '_py_backwards_abc_1'