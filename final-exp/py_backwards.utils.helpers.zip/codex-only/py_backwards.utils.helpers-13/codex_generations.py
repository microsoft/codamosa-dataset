

# Generated at 2022-06-23 23:32:04.669684
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    tester=VariablesGenerator()
    assert tester.generate('test')=='_py_backwards_test_0'

# Generated at 2022-06-23 23:32:10.469603
# Unit test for function eager
def test_eager():
    def fn1(a, b, c):
        for i in a:
            yield i
        for j in b:
            yield j
        for k in c:
            yield k

    from nose.tools import ok_
    from six import next

    a, b, c = (1, 2, 3), (4, 5), (6, 7, 8)
    # Check that iterator is not eagerly evaluated
    ok_(0 == len(fn1(a, b, c)))

    # Check that eager works
    ok_(10 == len(eager(fn1)(a, b, c)))

    # Check that resulting list is not a copy
    ok_(next(iter(a)) == next(iter(eager(fn1)(a, b, c))))

# Generated at 2022-06-23 23:32:18.780376
# Unit test for function eager
def test_eager():
    # Input function
    def take(n: int, iterable: List[int]) -> List[int]:
        return iterable[:n]

    # Eager version of the same function
    eager_take = eager(take)

    # No eager
    assert take(5, range(5)) == [0, 1, 2, 3, 4]
    assert take(5, range(4)) == [0, 1, 2, 3]

    # Eager
    assert eager_take(5, range(5)) == [0, 1, 2, 3, 4]
    assert eager_take(5, range(4)) == [0, 1, 2, 3]
    return

# Generated at 2022-06-23 23:32:24.468285
# Unit test for function debug
def test_debug():
    class FakeStderr:
        def __init__(self) -> None:
            self.text: List[str] = []

        def write(self, text: str) -> None:
            self.text.append(text)

    stderr = sys.stderr
    sys.stderr = FakeStderr()
    try:
        debug(lambda: 'some message')
        assert sys.stderr.text, 'sys.stderr has been written to'
    finally:
        sys.stderr = stderr

# Generated at 2022-06-23 23:32:27.385857
# Unit test for function eager
def test_eager():
    @eager
    def add(a: int, b: int) -> Iterable[int]:
        yield a + b

    assert add(1, 2) == [3]

# Generated at 2022-06-23 23:32:29.176977
# Unit test for function eager
def test_eager():
    assert eager(lambda: (1, 2, 3))() == [1, 2, 3]

# Generated at 2022-06-23 23:32:32.966610
# Unit test for function eager
def test_eager():
    def fib():
        a, b = 1, 1
        while True:
            yield a
            a, b = b, a + b

    assert lazy_fib()[10] == fib()[10]
    assert eager_fib()[10] == fib()[10]

# Generated at 2022-06-23 23:32:36.899604
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('i') == '_py_backwards_i_0'
    assert VariablesGenerator.generate('i') == '_py_backwards_i_1'
    assert VariablesGenerator.generate('j') == '_py_backwards_j_2'

# Generated at 2022-06-23 23:32:41.971138
# Unit test for function debug
def test_debug():
    def get_message():
        return 'This is a debug message'

    sys.stderr, stderr = StringIO(), sys.stderr
    settings.debug = True
    debug(get_message)
    sys.stderr = stderr
    assert 'This is a debug message' == sys.stderr.getvalue().strip()

# Generated at 2022-06-23 23:32:47.213158
# Unit test for function warn
def test_warn():
    try:
        import io
        import sys

        stream = io.StringIO()
        sys.stderr = stream
        from ..conf import settings
        settings.debug = False
        warn("warn_message")
        assert stream.getvalue() == "\033[93mwarn_message\x1b[0m\n"
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:32:50.748186
# Unit test for function debug
def test_debug():
    for case in ('a', 'b'):
        state = []
        debug(lambda: state.append(1))
        if case == 'a':
            assert state == []
            settings.debug = True
        else:
            assert state == [1]
    settings.debug = False



# Generated at 2022-06-23 23:32:54.619469
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('simulation') == '_py_backwards_simulation_0'
    assert VariablesGenerator.generate('simulation') == '_py_backwards_simulation_1'
    assert VariablesGenerator.generate('simulation') == '_py_backwards_simulation_2'



# Generated at 2022-06-23 23:32:55.800657
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:32:58.364694
# Unit test for function warn
def test_warn():
    assert sys.stderr.getvalue() == ''
    warn('foo\nbar')
    assert sys.stderr.getvalue() == '\033[33m*** WARNING: foo\nbar ***\033[0m\n'

# Generated at 2022-06-23 23:33:00.791879
# Unit test for function eager
def test_eager():
    def add(x: int, y: int) -> Iterable[int]:
        yield x + y
    add = eager(add)
    assert add(1, 2) == [3]



# Generated at 2022-06-23 23:33:01.411197
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-23 23:33:05.266150
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    assert re.match(r'_py_backwards_a_\d+', a) == a

    b = VariablesGenerator.generate('b')
    assert re.match(r'_py_backwards_b_\d+', b) == b



# Generated at 2022-06-23 23:33:07.517529
# Unit test for function eager
def test_eager():
    @eager
    def my_range(x: int) -> Iterable[int]:
        for i in range(x):
            yield i

    assert my_range(10) == list(range(10))

# Generated at 2022-06-23 23:33:13.060624
# Unit test for function debug
def test_debug():
    if not settings.debug:
        return
    import io

    saved_stdout = sys.stdout
    sys.stdout = io.StringIO()
    debug(lambda: 'foo')
    res = sys.stdout.getvalue()
    sys.stdout = saved_stdout
    assert res == '\x1b[35mDebug: foo\x1b[0m\n'

# Generated at 2022-06-23 23:33:16.570818
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('a') == '_py_backwards_a_0'
    assert generator.generate('a') == '_py_backwards_a_1'
    assert generator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:33:20.243235
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    obj_1 = VariablesGenerator()
    obj_2 = VariablesGenerator()
    assert obj_1._counter == obj_2._counter
    assert obj_1._counter == 0
    assert obj_1.generate('x') != obj_2.generate('y')

# Generated at 2022-06-23 23:33:30.095995
# Unit test for function eager
def test_eager():
    # A dummy iterator that return numbers from 1 to 3.
    class DummyIterator(Iterable[int]):
        def __init__(self):
            self.current_number = 1

        def __iter__(self):
            return self

        def __next__(self):
            if self.current_number > 3:
                raise StopIteration
            self.current_number += 1
            return self.current_number - 1

    # A wrapper for DummyIterator.
    def dummy_iterator():
        yield from DummyIterator()

    # Should return the same.
    assert type(dummy_iterator()) is type(DummyIterator())
    # Should equal to [1, 2, 3].
    assert eager(dummy_iterator)() == list(dummy_iterator())

if __name__ == '__main__':
    test

# Generated at 2022-06-23 23:33:32.180182
# Unit test for function warn
def test_warn():
    with pytest.raises(SystemExit) as e:
        warn('test message')
    assert e.value.code == 1

# Generated at 2022-06-23 23:33:32.870556
# Unit test for function eager

# Generated at 2022-06-23 23:33:33.972738
# Unit test for function eager
def test_eager():
    assert eager(range)(2) == [0, 1]

# Generated at 2022-06-23 23:33:37.851844
# Unit test for function warn
def test_warn():
    from unittest.mock import patch

    with patch('sys.stderr', new=None) as mock_stderr:
        warn("warning")
        mock_stderr.write.assert_called_once_with("\033[93mwarning\033[0m\n")

# Generated at 2022-06-23 23:33:44.129250
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stdout
    from . import helpers

    output = io.StringIO()
    with redirect_stdout(output):
        helpers.debug(lambda: "hello")

    assert output.getvalue() == ""

    old_debug = settings.debug
    settings.debug = True

    output = io.StringIO()
    with redirect_stdout(output):
        helpers.debug(lambda: "hello")
    assert output.getvalue() == "py-backwards [DEBUG] hello\n"

    settings.debug = old_debug


# Generated at 2022-06-23 23:33:47.895456
# Unit test for function warn
def test_warn():
    from contextlib import redirect_stdout
    from io import StringIO


    def test(message, should_be):
        buffer = StringIO()
        with redirect_stdout(buffer):
            warn(message)
        assert buffer.getvalue() == should_be


    test("Some message", "Warning: Some message\n")



# Generated at 2022-06-23 23:33:51.033616
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('answer') == '_py_backwards_answer_0'
    assert generator.generate('answer') == '_py_backwards_answer_1'



# Generated at 2022-06-23 23:34:00.487192
# Unit test for function eager
def test_eager():
    from operator import add
    from functools import reduce
    from .enumerate_comprehension import get_variables

    @eager
    def sum_of_squares(*numbers: int) -> List[int]:
        for i in numbers:
            yield i * i
    assert sum_of_squares(1, 2, 3) == [1, 4, 9]
    assert sum_of_squares(2, 3, 4) == [4, 9, 16]
    assert sum_of_squares(3, 4, 5) == [9, 16, 25]
    assert sum_of_squares(1, 2, 3, 4) == [1, 4, 9, 16]

# Generated at 2022-06-23 23:34:02.560187
# Unit test for function get_source
def test_get_source():
    message = 'test_get_source'

    def f():
        x = 1
        y = 2
        return x + y

    assert get_source(f) == '    x = 1\n    y = 2\n    return x + y'

# Generated at 2022-06-23 23:34:03.265905
# Unit test for function debug
def test_debug():
    debug(lambda: 'test message')

# Generated at 2022-06-23 23:34:04.545741
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(5))() == [0, 1 ,2, 3, 4]

# Generated at 2022-06-23 23:34:08.661607
# Unit test for function warn
def test_warn():
    temp = sys.stderr
    sys.stderr = StringIO()
    try:
        warn("test")
    finally:
        result = sys.stderr.getvalue()
        sys.stderr = temp
    match = result.strip() == messages.warn("test").strip()
    assert match

# Generated at 2022-06-23 23:34:12.781985
# Unit test for function debug
def test_debug():
    import io
    import sys

    with io.StringIO() as buffer, settings(debug=True):
        sys.stderr = buffer
        debug(lambda: 'test')
        assert buffer.getvalue() == messages.debug('test') + '\n'

    with io.StringIO() as buffer, settings(debug=False):
        sys.stderr = buffer
        debug(lambda: 'test')
        assert buffer.getvalue() == ''



# Generated at 2022-06-23 23:34:14.828507
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen1 = VariablesGenerator()
    gen2 = VariablesGenerator()
    assert gen1.generate('a') != gen2.generate('a')
    assert gen1.generate('a') != gen1.generate('b')

# Generated at 2022-06-23 23:34:16.204843
# Unit test for function warn
def test_warn():
    sys.stderr = StringIO()
    warn('Pupkin')
    assert sys.stderr.getvalue().rstrip() == messages.warn('Pupkin')

# Generated at 2022-06-23 23:34:18.048916
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    assert get_source(function) == "def function():\n    pass"

# Generated at 2022-06-23 23:34:21.519372
# Unit test for function get_source
def test_get_source():
    def func():
        def inner_func(x):
            pass
    assert get_source(func) == 'def inner_func(x):\n    pass'

# Generated at 2022-06-23 23:34:23.782427
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-23 23:34:27.449440
# Unit test for function get_source
def test_get_source():
    def fn():
        a = 1
        b = 2
        return a + b
    assert get_source(fn) == 'a = 1\n    b = 2\n    return a + b'

# Generated at 2022-06-23 23:34:30.241672
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            return 4

        return bar()

    source = get_source(foo)
    assert source == 'def bar():\n    return 4\n'

# Generated at 2022-06-23 23:34:32.052641
# Unit test for function debug
def test_debug():
    def get_message():
        return "message"
    debug(get_message)


# Generated at 2022-06-23 23:34:35.857794
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'


# Generated at 2022-06-23 23:34:39.115690
# Unit test for function warn
def test_warn():
    warn('Mock warning')
    capture_result = capsys.readouterr()
    assert capture_result.out == '\n' + messages.warn('Mock warning') + '\n'


# Generated at 2022-06-23 23:34:41.771170
# Unit test for function get_source
def test_get_source():
    def some_function(one, two, three, four):
        return one * two * three * four


# Generated at 2022-06-23 23:34:47.372327
# Unit test for function eager
def test_eager():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    @eager
    def iterate(max: int) -> Iterable[int]:
        for i in range(max):
            yield i

    result = iterate(5)
    assert isinstance(result, list) and result == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 23:34:49.620086
# Unit test for function warn
def test_warn():
    sys.stderr = sys.stdout
    warn('test')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:34:53.897379
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate('a')) # -> '_py_backwards_a_0'
    print(VariablesGenerator.generate('a')) # -> '_py_backwards_a_1'
    print(VariablesGenerator.generate('a')) # -> '_py_backwards_a_2'


# Generated at 2022-06-23 23:34:55.912845
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3
    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-23 23:34:59.083346
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]



# Generated at 2022-06-23 23:35:01.945682
# Unit test for function debug
def test_debug():
    result = StringIO()
    sys.stderr = result
    settings.debug = True
    debug(lambda: 'hello world')
    assert result.getvalue().startswith('DEBUG')
    settings.debug = False

# Generated at 2022-06-23 23:35:07.958670
# Unit test for function debug
def test_debug():
    global _debug_test_counter
    _debug_test_counter = 0

    settings.debug = True
    debug(lambda: 'test{}'.format(_debug_test_counter))
    assert _debug_test_counter == 1

    settings.debug = False
    debug(lambda: 'test{}'.format(_debug_test_counter))
    assert _debug_test_counter == 1


_debug_test_counter = -1  # type: int

# Generated at 2022-06-23 23:35:11.561218
# Unit test for function warn
def test_warn():
    import io
    import sys

    try:
        sys.stderr = error = io.StringIO()
        warn('Hello World')
        assert error.getvalue() == messages.warn('Hello World') + '\n'
    finally:
        sys.stderr = sys.__stderr__ # type: ignore



# Generated at 2022-06-23 23:35:18.088856
# Unit test for function warn
def test_warn():
    import os
    import sys
    import pytest
    from contextlib import contextmanager

    @contextmanager
    def capture():
        old_stdout = sys.stdout
        try:
            capture_stdout = os.pipe()
            os.dup2(capture_stdout[1], sys.stdout.fileno())

            yield capture_stdout[0]
        finally:
            os.dup2(old_stdout.fileno(), sys.stdout.fileno())
        
    with capture() as stdout:
        warn("Hello, this is a warning")
        # read the stdout file descriptor
        assert os.read(stdout, 1024).decode("utf-8").strip() == "WARNING: Hello, this is a warning"




# Generated at 2022-06-23 23:35:22.810972
# Unit test for function warn
def test_warn():
    messages._warn_color = 'black'

    def test_function():
        warn('warn')
    test_function()

    captured_output = io.StringIO()
    sys.stderr = captured_output

    assert captured_output.getvalue() == messages.TermStyle.black('warn') + '\n'


# Generated at 2022-06-23 23:35:26.948566
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    err = StringIO()
    with redirect_stderr(err):
        warn('something')

    assert '\033[93;1mWARNING!\033[0m something' in err.getvalue()



# Generated at 2022-06-23 23:35:29.329098
# Unit test for function warn
def test_warn():
    with captured_output() as (out, err):
        warn('some warning')
    output = err.getvalue().strip()
    assert output == messages.warn('some warning')



# Generated at 2022-06-23 23:35:31.500657
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    test = eager(test)
    assert test() == [1, 2, 3]



# Generated at 2022-06-23 23:35:33.302683
# Unit test for function warn
def test_warn():
    io = io.StringIO()
    warn('test_warn')
    assert io.getvalue() == "WARNING: test_warn\n"

# Generated at 2022-06-23 23:35:36.342025
# Unit test for function get_source
def test_get_source():                                                                
    
    def test_source(smth: str) -> str:                                                
        return smth                                                                   
                                                                                     
    res = get_source(test_source)                                                     
    assert res == "return smth"                                                       
                                                                                     
    

# Generated at 2022-06-23 23:35:39.431456
# Unit test for function eager
def test_eager():
    def random_gen():
        import random
        while True:
            yield random.randint(1, 100)

    f = eager(random_gen)

    assert(isinstance(f(), list))

# Generated at 2022-06-23 23:35:44.135197
# Unit test for function debug
def test_debug():
    # Make sure debug is set false so that the function is not executed.
    settings.debug = False
    debug(lambda: 'debug')
    # Set debug true and run the function
    settings.debug = True
    debug(lambda: 'debug')


__all__ = ['eager', 'VariablesGenerator', 'get_source', 'warn', 'debug']

# Generated at 2022-06-23 23:35:54.768819
# Unit test for function get_source

# Generated at 2022-06-23 23:35:55.945577
# Unit test for function warn
def test_warn():
    msg = 'Warning message'
    warn(msg)



# Generated at 2022-06-23 23:35:58.420884
# Unit test for function warn
def test_warn():
    sys.stderr = io.StringIO()
    warn("This is a test")
    assert sys.stderr.getvalue() == "warning: This is a test\n"


# Generated at 2022-06-23 23:36:00.035454
# Unit test for function eager
def test_eager():
    def gen(x: int) -> Iterable[int]:
        if x > 0:
            yield x
            yield from gen(x - 1)

    assert gen(10) == eager(gen)(10)



# Generated at 2022-06-23 23:36:07.968407
# Unit test for function debug
def test_debug():
    import unittest
    import contextlib
    from io import StringIO

    class TestDebug(unittest.TestCase):
        def test_debug(self):
            with contextlib.redirect_stderr(StringIO()) as stderr:
                debug(lambda: 'testing')
            self.assertEqual(stderr.getvalue(), '')

            with contextlib.redirect_stderr(StringIO()) as stderr:
                debug(lambda: 'testing')
            self.assertNotEqual(stderr.getvalue(), '')

    unittest.main()

# Generated at 2022-06-23 23:36:10.091226
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test message')
        assert True
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:36:12.823476
# Unit test for function get_source
def test_get_source(): # noqa: D103
    """Tests get_source."""
    import pytest # type: ignore
    from .logic import name_to_function


# Generated at 2022-06-23 23:36:21.514769
# Unit test for function warn
def test_warn():
    import io
    import sys
    import warnings
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        warn("this is a test warning")
        # Verify some things
        assert len(w) == 1
        assert str(w[-1].message) == messages.warn("this is a test warning")

FEATURES = {
    "BASIC": 1,
    "CLASSES": 2,
    "OPTIONAL": 4,
    "DECORATORS": 8,
    "IMPORTS": 16,
    "TESTS": 32,
    "ALL": 0xFFFFFFFF,
}


# Generated at 2022-06-23 23:36:25.164149
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('name') == '_py_backwards_name_0'
    assert VariablesGenerator.generate('name') == '_py_backwards_name_1'

# Generated at 2022-06-23 23:36:31.561575
# Unit test for function get_source
def test_get_source():
    def test_function(x, y):
        """Test.

        :param x: Variable x
        :param y: Variable y
        :return: x + y
        """
        return x + y

    assert get_source(test_function) == 'def test_function(x, y):\n' \
                                        '    """Test.\n\n' \
                                        '    :param x: Variable x\n' \
                                        '    :param y: Variable y\n' \
                                        '    :return: x + y\n' \
                                        '    """\n' \
                                        '    return x + y'

# Generated at 2022-06-23 23:36:35.728898
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass'

    @wraps(lambda: None)
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-23 23:36:39.999257
# Unit test for function warn
def test_warn():

    sys_stderr = sys.stderr
    try:
        from io import StringIO
        sys.stderr = StringIO()

        warn("Hello")
        assert "Hello" in sys.stderr.getvalue()

    finally:
        sys.stderr = sys_stderr

# Generated at 2022-06-23 23:36:45.391692
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as f:
        with redirect_stderr(f):
            debug(lambda: 'a')
            assert f.getvalue() == ''

    with StringIO() as f:
        with redirect_stderr(f):
            settings.debug = True
            debug(lambda: 'a')
            assert f.getvalue() == '\x1b[30m\x1b[43mdebug\x1b[0m\x1b[36m: (a)\x1b[0m\n'

# Generated at 2022-06-23 23:36:50.070754
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'



# Generated at 2022-06-23 23:36:54.786706
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    namespace = {}
    v1 = VariablesGenerator.generate('x')
    namespace[v1] = 1
    v2 = VariablesGenerator.generate('x')
    namespace[v2] = 2
    assert v1 != v2, 'v1 == v2'
    assert namespace[v1] == 1, 'namespace[v1] != 1'
    assert namespace[v2] == 2, 'namespace[v2] != 2'

# Generated at 2022-06-23 23:37:05.379847
# Unit test for function debug
def test_debug():
    class TestThrow:
        def __init__(self):
            self._should_thrown = True

        def __call__(self, get_message: Callable[[], str]) -> None:
            def get_message_wrapped() -> str:
                if self._should_thrown:
                    raise Exception()
                return get_message()

            return get_message_wrapped

    test_throw = TestThrow()

    get_message_1 = test_throw(lambda: 'test')
    get_message_2 = test_throw(lambda: 'test2')
    debug(get_message_1)
    debug(get_message_2)

    test_throw._should_thrown = False
    with pytest.raises(Exception):
        debug(get_message_1)
    debug(get_message_2)

# Generated at 2022-06-23 23:37:13.072306
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate("variable")
    print(a)
    b = VariablesGenerator.generate("variable")
    print(b)
    c = VariablesGenerator.generate("variable")
    print(c)
    d = VariablesGenerator.generate("variable")
    print(d)
    assert a == '_py_backwards_variable_0'
    assert b == '_py_backwards_variable_1'
    assert c == '_py_backwards_variable_2'
    assert d == '_py_backwards_variable_3'
    #assert e == '_py_backwards_variable_4'

# Generated at 2022-06-23 23:37:16.237011
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'


# Generated at 2022-06-23 23:37:19.858792
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
        pass
    assert get_source(foo) == '    def bar():\n        pass'
    assert get_source(foo).strip() == 'def bar():\n    pass'

# Generated at 2022-06-23 23:37:24.206086
# Unit test for function debug
def test_debug():
    from .tools import debug
    import io
    import sys
    out = io.StringIO()
    sys.stderr = out

    def get_message():
        return 'test'

    debug(get_message)
    assert out.getvalue() == ''



# Generated at 2022-06-23 23:37:27.783204
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    if VariablesGenerator.generate('not use') == VariablesGenerator.generate('not use'):
        raise AssertionError()
    if VariablesGenerator.generate('use') != VariablesGenerator.generate('use'):
        raise AssertionError()

# Generated at 2022-06-23 23:37:29.333353
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2

    assert f() == [1, 2]

# Generated at 2022-06-23 23:37:30.084040
# Unit test for function eager
def test_eager():
    assert eager(lambda: [1])() == [1]

# Generated at 2022-06-23 23:37:31.643040
# Unit test for function debug
def test_debug():
    with settings(debug=True):
        debug(lambda: '123')
    with settings(debug=False):
        debug(lambda: '123')

# Generated at 2022-06-23 23:37:34.409817
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'


# Generated at 2022-06-23 23:37:40.024871
# Unit test for function debug
def test_debug():
    settings.debug = False
    assert debug(lambda: 'debug message') is None

    settings.debug = True
    with StringIO() as stream:
        sys.stderr = stream
        debug(lambda: 'debug message')
        sys.stderr = sys.__stderr__
        assert stream.getvalue() == messages.debug('debug message') + '\n'

# Generated at 2022-06-23 23:37:41.738924
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-23 23:37:49.869229
# Unit test for function eager
def test_eager():
    import inspect
    from tempfile import NamedTemporaryFile
    from os import remove

    with NamedTemporaryFile(suffix='.py') as f:
        f.write(b"def gen():\n"
                b"    n = 0\n"
                b"    while n < 3:\n"
                b"        n += 1\n"
                b"        yield n\n")
        f.flush()
        gen = inspect.getsourcelines(inspect.getmodule(f.name))[0]
    assert gen[0] == 'def gen():\n'

    g = gen()
    assert g.__next__() == 1
    assert g.__next__() == 2
    assert g.__next__() == 3
    try:
        g.__next__()
    except StopIteration:
        pass

# Generated at 2022-06-23 23:37:54.249874
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("b") == '_py_backwards_b_1'
    assert VariablesGenerator.generate("c") == '_py_backwards_c_2'

# Generated at 2022-06-23 23:37:57.120126
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg1 = VariablesGenerator()
    var1 = vg1.generate("var")
    var2 = vg1.generate("var")
    assert var1 != var2, "generated variables should be unique"


# Generated at 2022-06-23 23:37:59.108383
# Unit test for function get_source
def test_get_source():
    def fn():
        print(5)

    assert get_source(fn) == 'print(5)'



# Generated at 2022-06-23 23:38:05.802573
# Unit test for function debug
def test_debug():
    import sys
    class FakeFile:
        def __init__(self):
            self.message = None
        def write(self, message):
            self.message = message
    sys.stderr = FakeFile()
    settings.debug = True
    message = 'you are in debug mode'
    debug(lambda: message)
    assert sys.stderr.message == messages.debug(message)
    settings.debug = False
    sys.stderr = sys.__stderr__  # type: ignore

# Generated at 2022-06-23 23:38:07.857722
# Unit test for function eager
def test_eager():
    def x():
        for i in range(10):
            yield i

    assert x() is not eager(x)()

# Generated at 2022-06-23 23:38:10.095923
# Unit test for function get_source
def test_get_source():
    def function_for_testing():
        pass
    assert get_source(function_for_testing) == 'def function_for_testing():\n    pass'

# Generated at 2022-06-23 23:38:12.506023
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest import TestCase, mock

    class Test(TestCase):
        def test_warn(self):
            output = StringIO()
            with mock.patch('sys.stderr', output):
                warn('test')
            self.assertEqual(output.getvalue(), 'test\n')
    return Test



# Generated at 2022-06-23 23:38:16.684065
# Unit test for function warn
def test_warn():
    import sys
    old_stderr = sys.stderr
    try:
        from io import StringIO
        sys.stderr = StringIO()
        warn('test')
        assert sys.stderr.getvalue() == messages.warn('test') + '\n'
    finally:
        sys.stderr = old_stderr



# Generated at 2022-06-23 23:38:26.683715
# Unit test for function debug
def test_debug():
    import io
    import sys

    saved_stdout, saved_stderr = sys.stdout, sys.stderr
    try:
        # Suppress stdout
        sys.stdout = io.StringIO()
        sys.stderr = io.StringIO()

        # When debug is falsy
        settings.debug = False
        debug(lambda: 'should not be printed')
        assert sys.stdout == "" and sys.stderr == ""

        # When debug is truthy
        settings.debug = True
        debug(lambda: 'should be printed')
        assert sys.stdout == "" and sys.stderr == " should be printed"
    finally:
        sys.stdout, sys.stderr = saved_stdout, saved_stderr



# Generated at 2022-06-23 23:38:28.008059
# Unit test for function get_source
def test_get_source():
    def f():
        return 1

    assert get_source(f) == 'return 1'

# Generated at 2022-06-23 23:38:30.260729
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass

    assert get_source(some_function) == 'def some_function():\n    pass'

# Generated at 2022-06-23 23:38:31.866057
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('random')=='_py_backwards_random_0'

# Generated at 2022-06-23 23:38:33.585596
# Unit test for function warn
def test_warn():
    # Arrange
    error = 'This is warn message'
    # Act
    warn(error)
    # Assert
    assert True

# Generated at 2022-06-23 23:38:34.683904
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]

# Generated at 2022-06-23 23:38:36.929718
# Unit test for function eager
def test_eager():
    # type: () -> None
    def generator():
        # type: () -> Iterable[int]
        for i in range(10):
            yield i

    assert eager(generator)() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:38:38.698242
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    assert eager(test)() == [1, 2, 3]

# Generated at 2022-06-23 23:38:43.318619
# Unit test for function get_source
def test_get_source():
    def foo():
        x = 1
        y = 2
        if x < y:
            return 'x < y'

    assert get_source(foo) == '''
x = 1
y = 2
if x < y:
    return 'x < y'
'''.lstrip()

# Generated at 2022-06-23 23:38:45.281904
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-23 23:38:48.390347
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'

# Generated at 2022-06-23 23:38:53.567453
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class T:
        assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
        assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
        assert VariablesGenerator.generate('var') == '_py_backwards_var_2'
        assert VariablesGenerator.generate('var') == '_py_backwards_var_3'



# Generated at 2022-06-23 23:38:55.017027
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass
    assert get_source(test_func) == 'pass'

# Generated at 2022-06-23 23:38:58.160658
# Unit test for function get_source
def test_get_source():

    def foo(x):
        """
        Does nothing.
        """
        a = x

        def bar():
            return a

    assert get_source(foo) == """    def foo(x):
        """

# Generated at 2022-06-23 23:39:00.444781
# Unit test for function get_source
def test_get_source():
    def some_function():
        var = 1
        return var

    assert get_source(some_function) == 'var = 1\nreturn var'



# Generated at 2022-06-23 23:39:05.480789
# Unit test for function debug
def test_debug():
    # Setup
    import io
    buffer = io.StringIO()
    sys.stderr = buffer

    # Exercise
    debug(lambda: 'hello world')

    # Verify
    assert buffer.getvalue().strip() == messages.debug('hello world')

    # Cleanup
    sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:39:09.058691
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'



# Generated at 2022-06-23 23:39:10.997753
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
    assert f() == [1]



# Generated at 2022-06-23 23:39:14.843795
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    with patch('py_backwards.utils.VariablesGenerator') as mock:
        VariablesGenerator.generate('_Y')
        assert mock._counter == 1
        VariablesGenerator.generate('_Y')
        assert mock._counter == 2

# Generated at 2022-06-23 23:39:17.817550
# Unit test for function debug
def test_debug():
    # Check that function sys.stderr.write works in a same way as sys.stderr.write.
    sys.stderr.write = lambda x: x
    debug(lambda: 'aaa')

# Generated at 2022-06-23 23:39:19.039335
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:39:19.862962
# Unit test for function get_source
def test_get_source():
    def fn():
        return 1

    assert get_source(fn) == 'return 1'

# Generated at 2022-06-23 23:39:24.648936
# Unit test for function debug
def test_debug():
    messages.debug = lambda s: s  # type: ignore
    import io
    import sys
    original_stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        assert sys.stderr.getvalue() == ''
        debug(lambda: 'hello')
        assert sys.stderr.getvalue() == ''
        assert settings.debug == False
        settings.debug = True
        assert settings.debug == True
        debug(lambda: 'hello')
        assert sys.stderr.getvalue() == 'hello\n'
    finally:
        sys.stderr = original_stderr

# Generated at 2022-06-23 23:39:27.186287
# Unit test for function eager
def test_eager():
    def sample_function():
        yield 1
        yield 2
        yield 3

    assert eager(sample_function)() == [1, 2, 3]

# Generated at 2022-06-23 23:39:29.452211
# Unit test for function eager
def test_eager():
    generator = (i for i in range(3))
    assert [0, 1, 2] == eager(generator)



# Generated at 2022-06-23 23:39:31.627283
# Unit test for function eager
def test_eager():
    assert eager(range)(5, 0, -1) == [5, 4, 3, 2, 1]

# Generated at 2022-06-23 23:39:32.679520
# Unit test for function warn
def test_warn():
    warn('This is a message')

# Generated at 2022-06-23 23:39:33.648945
# Unit test for function warn
def test_warn():
    warn('Something went wrong')

# Generated at 2022-06-23 23:39:35.933647
# Unit test for function get_source
def test_get_source():
    def func():
        a = 1
        return a
    assert get_source(func) == 'a = 1\nreturn a'



# Generated at 2022-06-23 23:39:42.833568
# Unit test for function debug
def test_debug():

    def test(expected):

        d = {}
        d['expected'] = expected
        def on_message(msg):
            d['message'] = msg

        def get_message():
            return 'message'

        setattr(sys.stderr, 'write', on_message)
        debug(get_message)

        assert d['expected'] == d['message']

    test(None)
    settings.debug = True
    test('\u001b[35mdebug: message\u001b[0m')
    settings.debug = False



# Generated at 2022-06-23 23:39:44.860361
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1
    foo.__qualname__ = 'foo'  # test for issue #16
    assert get_source(foo) == 'return 1'

# Generated at 2022-06-23 23:39:48.976855
# Unit test for function warn
def test_warn():
    try:
        import StringIO
        sys.stderr = StringIO.StringIO()
        warn('test warn')
        assert sys.stderr.getvalue()  == messages.warn('test warn') + '\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:39:54.921210
# Unit test for function debug
def test_debug():
    debug_message = 'hello'

    out = StringIO()

    with patch('{}.print'.format(__name__), side_effect=print) as p, \
            patch('{}.sys.stderr'.format(__name__), out):
        debug(lambda: debug_message)
        p.assert_called_once()
        assert debug_message in p.call_args[0][0]

# Generated at 2022-06-23 23:40:00.600274
# Unit test for function debug
def test_debug():
    def equal(a, b):
        if not a == b:
            raise SystemExit()

    def test():
        settings.debug = True
        try:
            debug(lambda: "Hello")
            equal(True, False)
        except SystemExit:
            settings.debug = False
            raise

    try:
        test()
    finally:
        settings.debug = False



# Generated at 2022-06-23 23:40:03.270129
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    b = VariablesGenerator()
    c = VariablesGenerator()
    assert a.generate('a') != b.generate('a') != c.generate('a')

# Generated at 2022-06-23 23:40:11.098235
# Unit test for function debug
def test_debug():
    message = 42
    output = StringIO()

    with captured_output(out_stream=output, err_stream=output) as (out, err):
        debug(lambda: message)

    assert not out.getvalue()
    assert not err.getvalue()

    with captured_output(out_stream=output, err_stream=output) as (out, err):
        with settings.override(debug=True):
            debug(lambda: message)

    assert not out.getvalue()
    assert err.getvalue().splitlines() == [f'DEBUG: {message}']

# Generated at 2022-06-23 23:40:17.904007
# Unit test for function warn
def test_warn():
    import sys
    import io
    from unittest import TestCase

    test_message = 'test message'
    output = io.StringIO()

    # Capture output into buffer
    sys.stderr = output
    warn(test_message)
    output.seek(0)
    output_string = output.read()

    # Restore output
    output.close()
    sys.stderr = sys.__stderr__

    # Assert that message contains warn suffix
    assert output_string.endswith(messages.warn(test_message))

# Generated at 2022-06-23 23:40:18.400940
# Unit test for function warn
def test_warn():
    warn('test message')

# Generated at 2022-06-23 23:40:19.243865
# Unit test for function warn
def test_warn():
    warn('Hello world!')



# Generated at 2022-06-23 23:40:25.006775
# Unit test for function debug
def test_debug():
    def fake_print(x: Any, file: Any = sys.stderr) -> None:
        print(x)

    def get_message():
        return "test_debug"

    import unittest.mock as mock

    with mock.patch('sys.stderr', sys.stdout):
        with mock.patch('sys.stdout', sys.stdout):
            with mock.patch('py_backwards.io.print', side_effect=fake_print):
                with mock.patch('py_backwards.io.settings.debug', return_value=True):
                    debug(get_message)


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-23 23:40:29.961231
# Unit test for function get_source
def test_get_source():
    def add(a, b):
        return a + b

    assert get_source(add) == 'return a + b'

# Generated at 2022-06-23 23:40:32.768482
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('a')
    b = VariablesGenerator.generate('a')
    assert a != b
    assert 'a' in a
    assert 'a' in b

# Generated at 2022-06-23 23:40:38.746694
# Unit test for function debug
def test_debug():
    output = StringIO()
    with redirect_stdout(output):

        def get_message():
            return 'foo'

        debug(get_message)
        assert output.getvalue() == ''

        settings.debug = True

        debug(get_message)
        assert output.getvalue() == '\x1b[36m[DEBUG] foo\x1b[0m\n'
        output.truncate(0)

        settings.debug = False
        debug(get_message)
        assert output.getvalue() == ''

# Generated at 2022-06-23 23:40:39.751902
# Unit test for function warn
def test_warn():
    warn("Debug test")

# Generated at 2022-06-23 23:40:41.495210
# Unit test for function get_source

# Generated at 2022-06-23 23:40:46.247598
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('name') == '_py_backwards_name_0'
    assert gen.generate('name') == '_py_backwards_name_1'
    assert gen.generate('name') == '_py_backwards_name_2'

# Generated at 2022-06-23 23:40:49.880496
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator.generate('x')
    b = VariablesGenerator.generate('y')
    c = VariablesGenerator.generate('x')
    assert a != b and a != c and b != c

# Generated at 2022-06-23 23:40:55.196345
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=MagicMock()) as mock_sys_stderr:
        warn("Test warning message")
        mock_sys_stderr.assert_has_calls([call.write("\n"),
                                         call.write("\n" + messages.warn("Test warning message") + "\n"),
                                         call.flush()])


# Generated at 2022-06-23 23:41:00.263233
# Unit test for function debug
def test_debug():
    calls = []
    def get_message() -> str:
        calls.append(True)
        return 'lorem'

    with settings(debug=True):
        debug(get_message)

    assert len(calls) == 1
    assert calls[0] is True
    calls.clear()

    with settings(debug=False):
        debug(get_message)

    assert len(calls) == 0

# Generated at 2022-06-23 23:41:05.488492
# Unit test for function debug
def test_debug():
    class Haha:
        def get_message(self):
            return self.message

        def __enter__(self):
            self.message = 'Enter'

        def __exit__(self, *args):
            self.message = 'Exit'

    with Haha() as haha:
        debug(haha.get_message)



# Generated at 2022-06-23 23:41:07.274254
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    settings.debug = False

# Generated at 2022-06-23 23:41:08.797206
# Unit test for function get_source
def test_get_source():
    def function():
        pass
    assert get_source(function) == 'def function():\n    pass\n'

# Generated at 2022-06-23 23:41:17.700689
# Unit test for function debug
def test_debug():
    import unittest

    class TestDebug(unittest.TestCase):
        def test_if_debug_is_enabled_prints_message(self):
            self.last_debug = None

            def print(*args, **kwargs):
                self.last_debug = args[0]

            original_print = __builtins__.print
            __builtins__.print = print

            settings.debug = True
            debug(lambda: 'test if debug is enabled')
            self.assertIsNotNone(self.last_debug)

            settings.debug = False
            debug(lambda: 'test if debug is disabled')
            self.assertIsNone(self.last_debug)

            __builtins__.print = original_print

    return unittest.TestLoader().loadTestsFromTestCase(TestDebug)

# Generated at 2022-06-23 23:41:20.667103
# Unit test for function debug
def test_debug():
    assert settings.debug is True
    result = []
    def get_message():
        result.append(1)
        return "message"

    debug(get_message)
    assert result == [1]
    assert settings.debug is True



# Generated at 2022-06-23 23:41:23.819000
# Unit test for function debug
def test_debug():
    from io import StringIO

    def test_fn() -> None:
        buffer = StringIO()
        sys.stderr = buffer
        debug(lambda: 'foo')
        assert buffer.getvalue() == messages.TEST_DEBUG_MESSAGE

    test_fn()

# Generated at 2022-06-23 23:41:28.673112
# Unit test for function debug
def test_debug():
    import io

    output = io.StringIO()
    sys.stderr = output
    try:
        def test():
            return 'hello'

        debug(test)
        with settings.debug_mode():
            debug(test)
        assert output.getvalue() == '[py_backwards] hello\n[py_backwards] hello\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:41:32.528196
# Unit test for function warn
def test_warn():
    try:
        _stdout = sys.stdout
        sys.stdout = StringIO()
        warn('test')
        assert sys.stdout.getvalue() == messages.warn('test') + '\n'
    finally:
        sys.stdout = _stdout

# Generated at 2022-06-23 23:41:36.307317
# Unit test for function debug
def test_debug():
    calls = []

    def get_message():
        calls.append(True)
        return 'message'

    debug(get_message)
    assert calls == []

    settings.debug = True
    debug(get_message)
    assert calls == [True]

# Generated at 2022-06-23 23:41:37.782956
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == '    pass'

# Generated at 2022-06-23 23:41:43.248267
# Unit test for function warn
def test_warn():
    from io import StringIO
    out = StringIO()
    sys.stderr = out
    try:
        warn('something bad happened')
        assert 'something bad happened' in out.getvalue()
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:41:47.328004
# Unit test for function eager
def test_eager():
    test_list = [1, 2, 3, 4, 5]
    test_generator = iter(test_list)

    @eager
    def generator():
        yield from test_generator

    assert generator() == test_list


# Generated at 2022-06-23 23:41:55.917875
# Unit test for function warn
def test_warn():
    import sys
    import os
    import subprocess
    from io import StringIO
    import warnings

    warnings.filterwarnings("ignore", ".*", UserWarning)

    buff = StringIO()
    sys.stderr = buff
    warn('hello')
    buff.seek(0)
    output = buff.read().strip()
    assert output == 'PyBackwards: warning: hello'
    sys.stderr = sys.__stderr__
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    # compare output of running function from file to string in function

# Generated at 2022-06-23 23:41:58.406586
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]



# Generated at 2022-06-23 23:42:00.271552
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> Iterable[str]:
        for i in range(3):
            yield i
    assert gen() == [0, 1, 2]

# Generated at 2022-06-23 23:42:01.841748
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
        pass
    assert get_source(foo) == 'def bar():\n    pass\npass'

# Generated at 2022-06-23 23:42:06.063921
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('foo') == '_py_backwards_foo_0'
    assert vg.generate('f') == '_py_backwards_f_1'
    assert vg.generate('foo') == '_py_backwards_foo_2'

