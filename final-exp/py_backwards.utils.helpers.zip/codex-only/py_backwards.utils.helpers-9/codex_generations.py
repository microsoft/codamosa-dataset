

# Generated at 2022-06-23 23:31:59.607748
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v1 = VariablesGenerator.generate("int")
    v2 = VariablesGenerator.generate("str")
    assert v1 == "_py_backwards_int_0"
    assert v2 == "_py_backwards_str_1"

# Generated at 2022-06-23 23:32:02.441741
# Unit test for function warn
def test_warn():
    capturedOutput = io.StringIO()      # Create StringIO object
    sys.stdout = capturedOutput            #  and redirect stdout.
    warn('test message')
    assert '***' in capturedOutput.getvalue()

# Generated at 2022-06-23 23:32:05.408687
# Unit test for function eager
def test_eager():
    def function(*args):
        yield 'foo'
        yield 'bar'
    assert eager(function)() == ['foo', 'bar']


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-23 23:32:11.821012
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class Generator(VariablesGenerator):
        pass

    var_a = Generator.generate('a')
    assert var_a == '_py_backwards_a_0'

    var_b = Generator.generate('b')
    assert var_b == '_py_backwards_b_1'

    var_a_c = Generator.generate('a')
    assert var_a_c == '_py_backwards_a_2'
    assert var_a == '_py_backwards_a_0'

# Generated at 2022-06-23 23:32:13.332094
# Unit test for function debug
def test_debug():
    debug(lambda: 'hello')
    # No exception should be raised

# Generated at 2022-06-23 23:32:21.467918
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug(lambda: 'test')
        assert stderr.write.called
        assert stderr.write.call_args[0][0].endswith('test\n')

        stderr.write.reset_mock()
        with patch('py_backwards.helpers.settings.debug', False):
            debug(lambda: 'test')
            assert not stderr.write.called

        stderr.write.reset_mock()
        with patch('py_backwards.helpers.settings.debug', None):
            debug(lambda: 'test')
            assert not stderr.write.called



# Generated at 2022-06-23 23:32:22.623962
# Unit test for function eager
def test_eager():
    def a(): yield 1; yield 2
    assert eager(a)() == [1, 2]


# Generated at 2022-06-23 23:32:25.207432
# Unit test for function warn
def test_warn():
    import io
    import sys
    new_stderr = io.StringIO()
    sys.stderr = new_stderr
    warn('message')
    assert new_stderr.getvalue() == 'message\n'



# Generated at 2022-06-23 23:32:30.348354
# Unit test for function debug
def test_debug():
    assert settings.debug

    try:
        with stdout_redirect(lambda: sys.stdout):
            debug(lambda: 'Hello')
            assert stdout_redirect.string.strip() == messages.debug('Hello')
    finally:
        sys.stdout = stdout_redirect.stringio



# Generated at 2022-06-23 23:32:35.554018
# Unit test for function warn
def test_warn():
    import sys
    import io
    from contextlib import contextmanager, redirect_stderr
    stderr = io.StringIO()
    @contextmanager
    def captured_stderr():
        with redirect_stderr(stderr):
            yield

    with captured_stderr():
        warn('test')

    assert stderr.getvalue() == '\nWarning: test\n\n'

# Generated at 2022-06-23 23:32:37.152370
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1

    assert get_source(test) == 'a = 1'

# Generated at 2022-06-23 23:32:40.054787
# Unit test for function get_source
def test_get_source():
    def my_func(a, b):
        return a, b
    fn_source = get_source(my_func)
    assert fn_source == 'return a, b'

# Generated at 2022-06-23 23:32:48.751507
# Unit test for function debug
def test_debug():
    from io import StringIO

    def my_debug():
        return 'debug'

    # Default value of debug is False
    settings.debug = False
    stream = StringIO()
    sys.stderr = stream
    debug(my_debug)
    assert stream.getvalue() == ''
    sys.stderr = sys.__stderr__

    # Set debug to True
    settings.debug = True
    stream = StringIO()
    sys.stderr = stream
    debug(my_debug)
    assert stream.getvalue() == '\x1b[30m\x1b[43mdebug\x1b[0m\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:32:51.213456
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    for _ in range(10):
        assert vg.generate('bla') == '_py_backwards_bla_0'


# Unit tests for get_source

# Generated at 2022-06-23 23:32:55.067012
# Unit test for function get_source

# Generated at 2022-06-23 23:32:56.530684
# Unit test for function eager
def test_eager():
    @eager
    def fn():
        yield 1
        yield 2
        yield 3

    assert fn() == [1, 2, 3]

# Generated at 2022-06-23 23:32:59.655463
# Unit test for function debug
def test_debug():
    debug_message = ''
    def get_message():
        return debug_message

    debug_message = 'a'
    debug(get_message)
    assert debug_message == 'a'

    debug_message = 'b'
    debug(get_message)
    assert debug_message == 'b'

# Generated at 2022-06-23 23:33:03.770134
# Unit test for function warn
def test_warn():
    import io
    from contextlib import redirect_stderr
    f = io.StringIO()
    with redirect_stderr(f):
        warn('test')
        assert f.getvalue() == '\n...\x1b[32mtest\x1b[0;39m\n\n'


# Generated at 2022-06-23 23:33:10.278291
# Unit test for function debug
def test_debug():
    from unittest import mock
    from test.unit.unmock import unmock
    stderr = mock.Mock()
    try:
        sys.stderr = stderr
        messages.debug = lambda message: message
        debug(lambda: 'Hello')
    finally:
        sys.stderr = unmock(sys.stderr)
    stderr.write.assert_called_once_with(mock.ANY)


# Generated at 2022-06-23 23:33:12.453083
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-23 23:33:14.905397
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    source = 'def f():\n    pass'
    assert source == get_source(f)


# Generated at 2022-06-23 23:33:17.411072
# Unit test for function warn
def test_warn():
    from ..testing import capture

    with capture() as c:
        warn('TEST')

    assert c.out == 'Warning: TEST\n'

# Generated at 2022-06-23 23:33:18.704324
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
        yield 2

    assert generator() == [1, 2]

# Generated at 2022-06-23 23:33:20.017831
# Unit test for function warn
def test_warn():
    print("\n----test_warn----")
    warn("hello")


# Generated at 2022-06-23 23:33:25.968611
# Unit test for function get_source
def test_get_source():
    def dummy_function(a: int, b: int = 2, *args: str, c: int, d: int = 4, **kwargs: str) -> None:
        pass

    expected = 'def dummy_function(a: int, b: int = 2, *args: str, c: int, d: int = 4, **kwargs: str) -> None:'
    assert get_source(dummy_function) == expected

# Generated at 2022-06-23 23:33:30.018328
# Unit test for function warn
def test_warn():
    """This is a test_warn function!"""
    output = sys.stdout
    print("This is a test_warn function!")
    with open('testing.txt', 'w') as f:
        sys.stdout = f
        warn("This is a warning!")
        sys.stdout = output
    f.close()
    assert os.path.getsize('testing.txt') > 0



# Generated at 2022-06-23 23:33:33.722214
# Unit test for function debug
def test_debug():
    ret = []

    def get_message():
        return 'debug message'

    debug(get_message)
    sys.stderr = ret
    debug(get_message)
    sys.stderr = sys.__stderr__
    assert ret == [messages.debug(get_message()) + '\n']

# Generated at 2022-06-23 23:33:40.330824
# Unit test for function debug
def test_debug():
    import io
    import contextlib

    string_io = io.StringIO()

    def get_message():
        return '1234'

    with contextlib.redirect_stderr(string_io):
        debug(get_message)
        assert string_io.getvalue() == ''

    settings.debug = True
    with contextlib.redirect_stderr(string_io):
        debug(get_message)
        assert string_io.getvalue() == '1234\n'



# Generated at 2022-06-23 23:33:44.512560
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:33:48.571791
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    class Tester:
        pass

    if VariablesGenerator.generate('abc') != '_py_backwards_abc_0':
        return False
    if VariablesGenerator.generate('def') != '_py_backwards_def_1':
        return False
    return True

# Unit tests for method get_source

# Generated at 2022-06-23 23:33:52.105045
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
    foo_source = get_source(foo)
    bar_source = get_source(bar)
    if 'def foo():' in foo_source or 'def bar():' in bar_source:
        return False
    return True

# Generated at 2022-06-23 23:33:54.385134
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    x = VariablesGenerator()
    assert x.generate('test_1') == '_py_backwards_test_1_0'
    assert x.generate('test_2') == '_py_backwards_test_2_1'



# Generated at 2022-06-23 23:33:55.645616
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source)



# Generated at 2022-06-23 23:33:56.534901
# Unit test for function debug
def test_debug():
    debug(lambda: 'Test debug')



# Generated at 2022-06-23 23:33:57.074528
# Unit test for function warn
def test_warn():
    warn("test")

# Generated at 2022-06-23 23:34:00.735697
# Unit test for function warn
def test_warn():
    with capture_stderr() as stderr:
        warn('Wrong thing was done!')

    assert stderr.getvalue() == '\x1b[33m[py-backwards] Warning!\x1b[0m Wrong thing was done!\n'



# Generated at 2022-06-23 23:34:02.418283
# Unit test for function eager
def test_eager():
    @eager
    def even(max):
        for i in range(max):
            if i % 2 == 0:
                yield i
    assert even(5) == [0, 2, 4]

# Generated at 2022-06-23 23:34:03.779738
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2

    assert foo() == [1, 2]

# Generated at 2022-06-23 23:34:06.290831
# Unit test for function warn
def test_warn():
    try:
        messages.warn = lambda x: x
        sys.stderr = []
        warn('message')
        assert sys.stderr == ['message']
    finally:
        del messages.warn
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:34:09.414125
# Unit test for function get_source
def test_get_source():
    def test(): pass
    source_lines = (
        'def test(): ',
        '    pass',
        '',
        ''
    )
    assert get_source(test) == '\n'.join(source_lines)

# Generated at 2022-06-23 23:34:11.099587
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'debug: test 1')
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:34:12.913216
# Unit test for function eager
def test_eager():
    @eager
    def foo(n: int) -> Iterable[int]:
        yield from range(n)

    assert foo(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:34:14.010568
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'


# Generated at 2022-06-23 23:34:16.111520
# Unit test for function get_source
def test_get_source():
    def func():
        """Docstring"""
        bla = 1
        bla += 1
        print(bla)
        print()


# Generated at 2022-06-23 23:34:25.388296
# Unit test for function debug
def test_debug():
    from io import StringIO
    from sys import stderr

    try:
        output = StringIO()
        stderr = sys.stderr
        sys.stderr = output

        # The test code
        class FakeSettings:
            debug = False
        settings = FakeSettings()
        def print_test(test_str):
            print(test_str, file=sys.stderr)
        debug(print_test)
        output.seek(0)
        assert output.read() == '' # Shouldn't print anything

        class FakeSettings:
            debug = True
        settings = FakeSettings()
        debug(print_test)
        output.seek(0)
        assert output.read() == 'DEBUG: test\n'
    finally:
        sys.stderr = stderr

# Generated at 2022-06-23 23:34:28.001271
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-23 23:34:29.925982
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Test message'
    assert debug(get_message) is None

# Generated at 2022-06-23 23:34:34.208725
# Unit test for function eager
def test_eager():
    from collections import Sequence
    from operator import add
    from itertools import count

    @eager
    def generator():
        for i in count(0):
            yield i

    assert isinstance(generator(), Sequence)
    assert add(3, generator()[4]) == 7

# Generated at 2022-06-23 23:34:35.442022
# Unit test for function eager
def test_eager():
    # TODO: write
    pass

# Generated at 2022-06-23 23:34:40.303903
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg = VariablesGenerator()
    assert vg.generate('variable') == '_py_backwards_variable_0'
    assert vg.generate('variable') == '_py_backwards_variable_1'
    assert vg.generate('variable') == '_py_backwards_variable_2'


# Generated at 2022-06-23 23:34:42.848230
# Unit test for function eager
def test_eager():
    class TestClass:
        @eager
        def get_iter(self):
            yield 1


    assert type(TestClass().get_iter()) == list

# Generated at 2022-06-23 23:34:48.435116
# Unit test for function debug
def test_debug():
    settings.debug = True
    training_message = "Debugging is active"

    def set_message():
        return training_message

    def test_output():
        debug(set_message)

    from io import StringIO
    output = StringIO()
    sys.stderr = output
    test_output()
    output.seek(0)
    assert training_message in output.getvalue()

# Generated at 2022-06-23 23:34:50.166216
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2

    assert eager(f)() == [1, 2]

# Generated at 2022-06-23 23:34:51.786800
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for i in range(10):
            yield i
    assert gen() == list(range(10))

# Generated at 2022-06-23 23:34:52.432320
# Unit test for function get_source

# Generated at 2022-06-23 23:34:57.728430
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('name') == '_py_backwards_name_0'
    assert VariablesGenerator.generate('name') == '_py_backwards_name_1'
    assert VariablesGenerator.generate('name') == '_py_backwards_name_2'
    assert VariablesGenerator._counter == 3

# Generated at 2022-06-23 23:34:59.948100
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        return a + b
    assert get_source(foo).strip() == 'return a + b'

# Generated at 2022-06-23 23:35:09.454994
# Unit test for function debug
def test_debug():
    """Should print if debug is on, otherwise nothing."""
    messages.debug = lambda x: 'Message: ' + str(x)
    messages.warn = lambda x: 'Warning: ' + str(x)
    def test():
        messages.debug = lambda x: 'Message: ' + str(x)
        settings.debug = False
        debug(lambda: 'The debug message.')
        assert not sys.stderr.buflist
        settings.debug = True
        debug(lambda: 'The debug message.')
        assert sys.stderr.buflist[-1] == 'Message: The debug message.\n'
        settings.debug = 'dummy'
        debug(lambda: 'The debug message.')
        assert sys.stderr.buflist[-1] == 'Message: The debug message.\n'

# Generated at 2022-06-23 23:35:10.570439
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == list(range(5))

# Generated at 2022-06-23 23:35:11.897529
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

# Generated at 2022-06-23 23:35:16.125816
# Unit test for function debug
def test_debug():
    message = 'Hello world!'
    print = lambda *args: sys.stdout.write(''.join(map(str, args)) + '\n')

    settings.debug = False
    debug(lambda: message)
    assert list(sys.stdout.getvalue()) == []

    settings.debug = True
    debug(lambda: message)
    assert list(sys.stdout.getvalue())[0].strip() == messages.debug(message)



# Generated at 2022-06-23 23:35:21.143089
# Unit test for function warn
def test_warn():
    import io
    import sys
    _stdout = sys.stderr
    try:
        out = io.StringIO()
        sys.stderr = out
        warn("Warning")
        output = out.getvalue().strip()
        assert output == "Warning"
    finally:
        sys.stderr = _stdout

# Generated at 2022-06-23 23:35:24.107413
# Unit test for function debug
def test_debug():
    detach_debug = settings._detach('debug')
    detach_debug(True)
    debug(lambda: 'Debug mode is True')
    detach_debug(False)
    debug(lambda: 'Debug mode is False')

# Generated at 2022-06-23 23:35:30.302566
# Unit test for function warn
def test_warn():
    warnings = []

    class TestStderr:
        def write(self, s: str) -> None:
            warnings.append(s)
        def flush(self) -> None:
            pass

    old_stderr = sys.stderr
    sys.stderr = TestStderr()

    warn("test_warn")
    sys.stderr = old_stderr
    assert warnings == ["\x1b[93mtest_warn\x1b[0m\n"]



# Generated at 2022-06-23 23:35:31.550875
# Unit test for function eager
def test_eager():
    @eager
    def get_eager_list() -> List[int]:
        for i in range(10):
            yield i

    assert len(get_eager_list()) == 10

# Generated at 2022-06-23 23:35:32.974272
# Unit test for function eager
def test_eager():
    assert eager(range)(3) == [0, 1, 2]

# Generated at 2022-06-23 23:35:40.353888
# Unit test for function warn
def test_warn():
    import io
    import sys

    out = io.StringIO()
    err = io.StringIO()
    old_stderr = sys.stderr
    old_stdout = sys.stdout

    sys.stderr = err
    sys.stdout = out
    warn('message')
    sys.stderr = old_stderr
    sys.stdout = old_stdout
    out.seek(0)
    err.seek(0)

    assert out.read() == ''
    assert err.read() == messages.warn('message') + '\n'



# Generated at 2022-06-23 23:35:42.649315
# Unit test for function get_source
def test_get_source():
    def my_func():
        a = 0

    assert 'a = 0' in get_source(my_func)


# Generated at 2022-06-23 23:35:50.309034
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest import TestCase

    class TestWarn(TestCase):
        def test_warn(self):
            output = StringIO()
            try:
                old_stderr = sys.stderr
                sys.stderr = output
                warn('Warning Message')
            finally:
                sys.stderr = old_stderr
            self.assertIn('Warning Message', output.getvalue())
            self.assertIn('\x1B', output.getvalue())

    TestWarn().test_warn()

# Generated at 2022-06-23 23:35:51.984812
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("a") != VariablesGenerator.generate("a")


# Generated at 2022-06-23 23:35:53.440988
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'pass'

# Generated at 2022-06-23 23:35:55.378618
# Unit test for function eager
def test_eager():
    @eager
    def get_range():
        yield from range(10)
    assert get_range() == list(range(10))

# Generated at 2022-06-23 23:35:57.371973
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: '1')

    settings.debug = False
    debug(lambda: '2')

# Generated at 2022-06-23 23:36:00.964966
# Unit test for function debug
def test_debug():
    from ..core import Settings

    class FakeStdErr:
        def write(self, msg: str) -> None:
            self.msg = msg

    err = FakeStdErr()

    old_settings = settings
    settings = Settings(debug=True)

    debug(lambda: 'msg')

    assert err.msg == messages.debug('msg')

    settings = old_settings

# Generated at 2022-06-23 23:36:02.157370
# Unit test for function get_source
def test_get_source():
    def fn():
        def inner():
            return 1

        return inner()

    assert get_source(fn) == 'return 1'

# Generated at 2022-06-23 23:36:05.304627
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_0'
    assert VariablesGenerator.generate('variable') == '_py_backwards_variable_1'


# Generated at 2022-06-23 23:36:07.287080
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')

# Generated at 2022-06-23 23:36:11.592462
# Unit test for function warn
def test_warn():
    _out = __import__('sys').stderr = __import__('io').StringIO()
    warn("What a beautiful warning!")
    assert "PyBackwards" in _out.getvalue()
    assert "Warning" in _out.getvalue()
    assert "What a beautiful warning!" in _out.getvalue()



# Generated at 2022-06-23 23:36:19.435984
# Unit test for function warn
def test_warn():
    from .patch import MonkeyPatch

    test = {'x': 0, 'y': 0}
    with MonkeyPatch(sys.stderr, sys.stderr) as output:
        warn('Test message')
        test['out'] = output.getvalue().rsplit('\n')[-2]
    test['x'] = 'Test message' in test['out']
    test['y'] = '\033[' in test['out']
    assert test == {'x': True, 'y': True, 'out': '\033[31mTest message\033[0m'}



# Generated at 2022-06-23 23:36:22.177346
# Unit test for function eager
def test_eager():
    def test_iterable():
        yield 1
        yield 2
        yield 3
        return 4

    assert eager(test_iterable)() == [1, 2, 3]

# Generated at 2022-06-23 23:36:23.220265
# Unit test for function warn
def test_warn():
    warn("Test warn")



# Generated at 2022-06-23 23:36:27.190400
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as fake_stdout:
        warn('message')

    assert fake_stdout.getvalue().strip() == '\x1b[33mWarning: message\x1b[0m'

# Generated at 2022-06-23 23:36:29.724634
# Unit test for function warn
def test_warn():
    assert settings.warn == False
    settings.warn = True

    warn("Warning!")
    settings.warn = False
    warn("Warning!")
    assert settings.warn == False


# Generated at 2022-06-23 23:36:36.666838
# Unit test for function eager
def test_eager():
    class A:
        def __init__(self, a):
            self.a = a

        def __iter__(self):
            yield self.a

    def g():
        a = A(1)
        yield a

    def f():
        a = A(2)
        yield from g()
        yield a
        yield from [3, 4]
        for a in g():
            yield a

    assert eager(f)() == [2, 1, 3, 4, 1]

# Generated at 2022-06-23 23:36:38.619489
# Unit test for function warn
def test_warn():
    messages.warn = lambda x: 'foo'
    assert warn('bar') == None
    


# Generated at 2022-06-23 23:36:40.759904
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    def unique():
        yield from (VariablesGenerator.generate('a') for _ in range(100))

    assert len(list(unique())) == 100

# Generated at 2022-06-23 23:36:44.007417
# Unit test for function eager
def test_eager():
    # Test check if function eager return a list
    assert type(eager(list)([1, 2, 3])) == list

    # Test check if function eager working correctly
    assert eager(range)(3) == [0, 1, 2]

# Generated at 2022-06-23 23:36:46.800891
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]



# Generated at 2022-06-23 23:36:52.136643
# Unit test for function warn
def test_warn():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        warn("This is a warning")
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)
        assert str(w[-1].message) == 'This is a warning'



# Generated at 2022-06-23 23:36:56.323068
# Unit test for function warn
def test_warn():
    warnings.simplefilter("ignore")
    with catch_warnings(record=True) as warn_list:
        warn("test_warn")
    warnings.simplefilter("default")
    return len(warn_list) == 1 and issubclass(warn_list[-1].category, UserWarning)

if __name__ == "__main__":
    if not test_warn():
        sys.exit(1)

# Generated at 2022-06-23 23:36:57.968428
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        for i in range(10):
            yield i

    assert eager(foo)() == list(range(10))

# Generated at 2022-06-23 23:37:00.717378
# Unit test for function get_source
def test_get_source():
    def a():
        pass

    source = get_source(a)
    assert source.startswith('def a():'), 'remove-padding-from-get_source'

# Generated at 2022-06-23 23:37:03.882284
# Unit test for function get_source
def test_get_source():
    def f():
            x=0
            y=x
            return y

    assert get_source(f) == 'x=0\ny=x\nreturn y\n'

# Generated at 2022-06-23 23:37:06.720751
# Unit test for function get_source
def test_get_source():
    def func():
        """Test function."""
        from .. import core
        return core.get_source(func)
    assert func().strip() == '"""Test function."""'



test_get_source()

# Generated at 2022-06-23 23:37:09.750972
# Unit test for function eager
def test_eager():
    @eager
    def iter_fn(args):
        for i in args:
            yield i

    result = iter_fn([1, 2])

    assert result == [1, 2]
    assert isinstance(result, list)

# Generated at 2022-06-23 23:37:10.754954
# Unit test for function warn
def test_warn():
    # TODO: It's better to test such things.
    warn('print me!')

# Generated at 2022-06-23 23:37:14.691919
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert hasattr(VariablesGenerator, 'generate')
    assert callable(VariablesGenerator.generate)
    result = VariablesGenerator.generate('var')
    assert result == '_py_backwards_var_0'
    result = VariablesGenerator.generate('var2')
    assert result == '_py_backwards_var2_1'


# Generated at 2022-06-23 23:37:20.416660
# Unit test for function debug
def test_debug():
    settings.debug = True
    message = 'debug message'

    class CaptureStdout:
        def __enter__(self):
            self.stdout = sys.stdout
            sys.stdout = StringIO()

        def __exit__(self, *args):
            assert sys.stdout.getvalue() == messages.debug(message)

            sys.stdout = self.stdout

    with CaptureStdout():
        debug(lambda: message)

# Generated at 2022-06-23 23:37:27.564922
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    lista = []
    for n in range(0,10):
        lista.append(VariablesGenerator.generate("x"))
    assert(len(lista[0]) == 7)
    assert(lista[0] == "_py_backwards_x_0")
    assert(lista[1] == "_py_backwards_x_1")
    assert(lista[2] == "_py_backwards_x_2")
    assert(lista[9] == "_py_backwards_x_9")


# Generated at 2022-06-23 23:37:30.011981
# Unit test for function get_source
def test_get_source():
    """Testing function get_source"""
    def foo():
        """Something to test"""
        var = 'adv'
        return var
    assert get_source(foo) == '    var = \'adv\'\n    return var'

# Generated at 2022-06-23 23:37:33.597917
# Unit test for function debug
def test_debug():
    with mock.patch('sys.stderr') as mock_stderr:
        settings.debug = True
        debug(lambda: 'some debug message')
        assert mock_stderr.write.call_args[0][0].endswith('some debug message\n')

        settings.debug = False
        debug(lambda: 'other debug message')
        assert mock_stderr.write.call_count == 1

# Generated at 2022-06-23 23:37:35.524458
# Unit test for function warn
def test_warn():
    _stdout = sys.stdout
    output = StringIO()
    sys.stdout = output
    warn('warn')
    assert 'warn' in output.getvalue()
    sys.stdout = _stdout



# Generated at 2022-06-23 23:37:40.264936
# Unit test for function warn
def test_warn():
    import warnings

    stream = warnings.catch_warnings()

    # Enable warnings from py_backwards
    warnings.simplefilter('default')
    messages.warn('This is a testmessage')

    for warning in stream.record:
        assert 'This is a testmessage' in str(warning)


# Generated at 2022-06-23 23:37:42.401135
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass

    assert get_source(flatten) == get_source(some_function)

# Generated at 2022-06-23 23:37:47.166398
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print('Testing VariablesGenerator.generate()')
    assert VariablesGenerator.generate('0') == '_py_backwards_0_0'
    assert VariablesGenerator.generate('0') == '_py_backwards_0_1'
    assert VariablesGenerator.generate('1') == '_py_backwards_1_2'
    print('VariablesGenerator.generate() works correctly')


# Generated at 2022-06-23 23:37:51.227253
# Unit test for function debug
def test_debug():
    verbose = settings.debug
    settings.debug = True
    warning = ''
    try:
        debug(lambda : "Warning")
    except:
        warning = sys.stderr.getvalue()
        sys.stderr.close()
        sys.stderr = sys.__stderr__
    settings.debug = verbose
    return messages.debug("Warning") == warning


# Generated at 2022-06-23 23:37:52.182228
# Unit test for function warn
def test_warn():
    warn('warning')



# Generated at 2022-06-23 23:37:55.430513
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Ensure the generated names are unique
    assert VariablesGenerator.generate('a') == VariablesGenerator.generate('a')
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('b')
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')
    assert VariablesGenerator.generate('b') != VariablesGenerator.generate('a')

# Generated at 2022-06-23 23:37:58.661386
# Unit test for function debug
def test_debug():
    import io
    import sys
    stdout = sys.stderr
    sys.stderr = io.StringIO()
    debug(lambda: 'message')
    sys.stderr = stdout

# Generated at 2022-06-23 23:38:01.304763
# Unit test for function warn
def test_warn():
    from unittest.mock import patch

    # make sure that a warning message is printed
    with patch('sys.stderr') as mocked_stderr:
        mocked_stderr.write = lambda data: None
        warn('test')
        assert len(mocked_stderr.write.mock_calls) > 0

# Generated at 2022-06-23 23:38:03.549886
# Unit test for function debug
def test_debug():

    def get_debug_message():
        return 'hello'
    assert debug(get_debug_message) is None



# Generated at 2022-06-23 23:38:07.244991
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        warn('Hello!')
        assert mock_stderr.getvalue() == '\n\033[93mWarning\033[0m: Hello!\n'



# Generated at 2022-06-23 23:38:09.453682
# Unit test for function eager
def test_eager():
    def lazy_fn(x):
        return range(x)

    assert eager(lazy_fn)(10) == list(range(10))

# Generated at 2022-06-23 23:38:14.517100
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """
    >>> import backward
    >>> from backward._utils import VariablesGenerator
    >>> VariablesGenerator.generate("test")
    '_py_backwards_test_0'
    >>> VariablesGenerator.generate("test")
    '_py_backwards_test_1'
    >>> VariablesGenerator.generate("test")
    '_py_backwards_test_2'
    """

# Generated at 2022-06-23 23:38:17.164703
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    a = VariablesGenerator()
    b = VariablesGenerator()
    assert a.generate("name") != b.generate("name")



# Generated at 2022-06-23 23:38:23.527738
# Unit test for function debug
def test_debug():
    # given
    import io
    from contextlib import redirect_stdout
    original_stderr = sys.stderr
    settings.debug = True

    # when
    with io.StringIO() as buf, redirect_stdout(buf):
        debug(lambda: 'debug message')
    output = buf.getvalue()

    # then
    sys.stderr = original_stderr
    assert output.strip().endswith('debug message') is True

# Generated at 2022-06-23 23:38:29.285885
# Unit test for function warn
def test_warn():
    class MyIO:
        def __init__(self):
            self.value = None

        def write(self, value: str) -> None:
            self.value = value

    io = MyIO()
    old_stderr = sys.stderr
    sys.stderr = io
    try:
        warn('Some warning')
    finally:
        sys.stderr = old_stderr

    assert io.value is not None

# Generated at 2022-06-23 23:38:31.274964
# Unit test for function get_source
def test_get_source():
    def tested_function(lst):
        return lst

    assert get_source(tested_function) == 'return lst'

# Generated at 2022-06-23 23:38:32.465394
# Unit test for function warn
def test_warn():
    mess = 'test warning'
    warn(mess)

# Generated at 2022-06-23 23:38:35.316144
# Unit test for function eager
def test_eager():
    def test_eager_internal(a, b):
        return range(a, b)

    test_eager_internal = eager(test_eager_internal)
    assert test_eager_internal(-1, 3) == [-1, 0, 1, 2]

# Generated at 2022-06-23 23:38:37.944522
# Unit test for function get_source
def test_get_source():
    def function_1():
        def function_2():
            def function_3():
                print('foo')
            function_3()
        function_2()

    assert get_source(function_1) == 'def function_2():\n    def function_3():\n        print(\'foo\')\n    function_3()\nfunction_2()'

# Generated at 2022-06-23 23:38:42.715184
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    source = get_source(function)

    assert source == 'def function():\n    pass'

    def function():
        pass

    function.__name__ = 'foo'

    source = get_source(function)

    assert source == 'def foo():\n    pass'



# Generated at 2022-06-23 23:38:44.195481
# Unit test for function get_source
def test_get_source():
    def test():
        return 3

    assert get_source(test) == 'return 3'

# Generated at 2022-06-23 23:38:53.931522
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator()
    test_list = ['doctest', 'pytest', 'core', 'settings']
    test1 = [v.generate(i) for i in test_list]
    assert test1 == ['_py_backwards_doctest_0', '_py_backwards_pytest_1', '_py_backwards_core_2', '_py_backwards_settings_3']
    test2 = [v.generate(i) for i in test_list]
    assert test2 == ['_py_backwards_doctest_4', '_py_backwards_pytest_5', '_py_backwards_core_6', '_py_backwards_settings_7']
    test3 = [v.generate(i) for i in test_list]
    assert test

# Generated at 2022-06-23 23:39:00.576002
# Unit test for function debug
def test_debug():
    class ArgsMock:
        args = ()
        kwargs = {}

    def get_message_mock(args, kwargs):
        pass

    debug = func_utils.debug

    # Check only message is printed.
    original_print = print
    called = False
    def print(*args, **kwargs):
        nonlocal called
        original_print(args, kwargs)
        called = True
    try:
        func_utils.print = print
        debug(lambda: 'My message')
        assert called
    finally:
        func_utils.print = original_print

    # Check no message is printed.
    original_print = print
    called = False
    def print(*args, **kwargs):
        nonlocal called
        original_print(args, kwargs)
        called = True
   

# Generated at 2022-06-23 23:39:04.747321
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings

    settings.debug = True

    with StringIO() as err:
        sys.stderr = err
        debug(lambda: 'hello')
        assert 'hello' in err.getvalue()

    settings.debug = False

# Generated at 2022-06-23 23:39:05.730336
# Unit test for function warn
def test_warn():
    print(messages.warn("Hello World"))


# Generated at 2022-06-23 23:39:09.321582
# Unit test for function eager
def test_eager():
    @eager
    def foo(a, b, c=3):
        yield a
        yield b
        yield c
        yield c + b

    assert foo(1, 2) == [1, 2, 3, 5]

# Generated at 2022-06-23 23:39:19.985480
# Unit test for function debug
def test_debug():
    collected_messages = []
    msg_counter = 0

    def collector(msg: str) -> None:
        nonlocal msg_counter
        collected_messages.append(msg)
        msg_counter += 1

    # Setup
    old_print = print
    print = collector

    def test_func():
        debug(lambda: 'foo')
        debug(lambda: 'bar')
        debug(lambda: 'baz')

    # Test
    settings.debug = False
    test_func()

    settings.debug = True
    test_func()

    # Teardown
    print = old_print

    assert msg_counter == 3

# Generated at 2022-06-23 23:39:25.315678
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import contextmanager
    from ..conf import set_state

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn('test message')

# Generated at 2022-06-23 23:39:29.204269
# Unit test for function eager
def test_eager():
    @eager
    def test(a: int, b: int) -> Iterable[int]:
        yield a
        yield b
    assert test(1, 2) == [1, 2]
    assert test(3, 4) == [3, 4]



# Generated at 2022-06-23 23:39:34.381734
# Unit test for function get_source
def test_get_source():
    def test_function(a: int, b: float, c: str) -> None:
        print(a)
        print(b)
        if True:
            print(c)
    assert get_source(test_function) == 'print(a)\nprint(b)\nif True:\n    print(c)'

# Generated at 2022-06-23 23:39:39.764431
# Unit test for function eager
def test_eager():
    from random import randint
    from time import sleep

    @eager
    def foo(num: int) -> Iterable[int]:
        for i in range(num):
            sleep(randint(1, 10))
            yield i

    assert foo(3) == [0, 1, 2], 'AssertionError'
    assert foo(0) == [], 'AssertionError'

# Generated at 2022-06-23 23:39:41.385865
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('b')

# Generated at 2022-06-23 23:39:44.205427
# Unit test for function eager
def test_eager():
    def test_function(a, b):
        for x in range(a, b):
            yield x
    result = eager(test_function)(1, 4)
    assert result == [1, 2, 3]


# Generated at 2022-06-23 23:39:46.105098
# Unit test for function get_source
def test_get_source():
    def fn():
        return 1

    assert get_source(fn) == 'return 1'



# Generated at 2022-06-23 23:39:49.392032
# Unit test for function eager
def test_eager():
    def function():
        for i in range(5):
            yield i

    result = eager(function)()
    assert result == [0, 1, 2, 3, 4]


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-23 23:39:54.549160
# Unit test for function eager
def test_eager():
    from collections import Counter

    @eager
    def generate_numbers() -> Counter:
        for i in range(3):
            yield i
        for i in range(3):
            yield i

    generated_numbers = generate_numbers()
    assert generated_numbers == [0, 1, 2, 0, 1, 2]



# Generated at 2022-06-23 23:39:57.653336
# Unit test for function eager
def test_eager():
    from random import shuffle

    @eager
    def test_fn():
        a = [1, 2, 3]
        shuffle(a)
        yield from a

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-23 23:40:04.718822
# Unit test for function warn
def test_warn():
    # assert that output matches the string
    # 'You specified the decorator @backwards, but the function itself
    #  is already running in reverse!'
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        warn('You specified the decorator @backwards, but the function itself '
              'is already running in reverse!')
        assert fake_stderr.getvalue() == messages.warn('You specified the decorator '
                                                       '@backwards, but the function'
                                                       ' itself is already running '
                                                       'in reverse!\n')



# Generated at 2022-06-23 23:40:07.703137
# Unit test for function eager
def test_eager():
    def generator() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(generator)(1) == [1, 2, 3]

# Generated at 2022-06-23 23:40:12.172432
# Unit test for function warn
def test_warn():
    warnings.simplefilter('always')
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream):
        warn('hello')
    assert stream.getvalue() == '\x1b[33mhello\x1b[0m\n'

# Generated at 2022-06-23 23:40:13.949956
# Unit test for function eager
def test_eager():
    def foo():
        return [i for i in range(10)]

    assert foo() == eager(foo)()

# Generated at 2022-06-23 23:40:19.204769
# Unit test for function get_source
def test_get_source():
    def a():
        def aa():
            def aaa():
                bbb()  # noqa: F821
            bbb()  # noqa: F821
        bbb()  # noqa: F821

    # Note that there are 2 spaces of padding.
    assert get_source(a) == '    def aa():\n        def aaa():\n            bbb()\n        bbb()\n    bbb()'

# Generated at 2022-06-23 23:40:23.926350
# Unit test for function debug
def test_debug():
    import io
    import sys

    buffer = io.StringIO()
    sys.stderr = buffer

    settings.debug = True
    debug(lambda: 'abc')
    assert buffer.getvalue() == '\033[1;30;43mPyBackwards[DEBUG]: abc\033[0m\n'
    buffer.truncate(0)

    settings.debug = False
    debug(lambda: 'abc')
    assert buffer.getvalue() == ''

    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:40:31.204896
# Unit test for function debug
def test_debug():
    from .conf import settings
    from . import messages
    from unittest.mock import patch
    from io import StringIO

    debug_message = 'debug message'

    with patch("sys.stderr", new=StringIO()) as mock_err:
        settings.debug = False
        debug(lambda: debug_message)
        assert mock_err.getvalue() == ''

        settings.debug = True
        debug(lambda: debug_message)
        assert mock_err.getvalue() == messages.debug(debug_message)
    debug_message = 'debug message'

# Generated at 2022-06-23 23:40:38.265520
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    vg1 = VariablesGenerator()
    vg2 = VariablesGenerator()
    assert vg1.generate('var1') == '_py_backwards_var1_0'
    assert vg1.generate('var1') != '_py_backwards_var1_0'
    assert vg1.generate('var2') == '_py_backwards_var2_1'
    assert vg2.generate('var1') == '_py_backwards_var1_2'
    assert vg2.generate('var1') == '_py_backwards_var1_3'

# Generated at 2022-06-23 23:40:40.964234
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("x") == '_py_backwards_x_0'
    assert VariablesGenerator.generate("y") == '_py_backwards_y_1'
    assert VariablesGenerator.generate("z") == '_py_backwards_z_2'
test_VariablesGenerator()

# Generated at 2022-06-23 23:40:43.334238
# Unit test for function eager
def test_eager():
    def f(i: int) -> Iterable[int]:
        for j in range(i):
            yield j

    assert eager(f)(3) == [0, 1, 2]

# Generated at 2022-06-23 23:40:45.480769
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert len(VariablesGenerator.generate('')) > 0

# Generated at 2022-06-23 23:40:55.013630
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from unittest.mock import patch

    with patch('backwards.utils.settings', debug=True):
        with redirect_stderr(StringIO()) as out:
            debug(lambda: 'Hello world!')
        assert out.getvalue() == '\x1b[30m\x1b[43m\x1b[1m[DEBUG] Hello world!\x1b[0m\n'

    with patch('backwards.utils.settings', debug=False):
        with redirect_stderr(StringIO()) as out:
            debug(lambda: 'Hello world!')
        assert out.getvalue() == ''

# Generated at 2022-06-23 23:40:59.174245
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('x') == '_py_backwards_x_0'
    assert gen.generate('x') == '_py_backwards_x_1'
    assert gen.generate('y') == '_py_backwards_y_2'

# Generated at 2022-06-23 23:41:09.753054
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_2'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_3'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_4'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_5'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_6'
    assert VariablesGenerator.generate('y') == '_py_backwards_y_7'

# Generated at 2022-06-23 23:41:11.334594
# Unit test for function eager
def test_eager():
    assert eager(range)(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 23:41:16.014047
# Unit test for function warn
def test_warn():
    import io
    from contextlib import redirect_stderr
    f = io.StringIO()
    with redirect_stderr(f):
        warn('this is just a test')
    output = f.getvalue()
    assert output.startswith('\033[33m')
    assert output.endswith('\033[0m')
    assert 'this is just a test' in output



# Generated at 2022-06-23 23:41:18.239197
# Unit test for function get_source
def test_get_source():
    def foo():
        """
        Prints x

        :param x: x
        :type x: int
        """
        print('x')

    assert get_source(foo) == inspect.getsource(foo)

# Generated at 2022-06-23 23:41:23.556889
# Unit test for function get_source
def test_get_source():
    def test_1(a: int, b: int) -> bool:
        a = 2 + 3
        return a


    def test_2(a: int, b: int) -> bool:
        a = 2 + 3
        return a

    def test_3(a: int, b: int) -> bool:
        a = 2 + 3
        return a

    source = get_source(test_2)
    expected = 'a = 2 + 3\nreturn a'
    assert source == expected

# Generated at 2022-06-23 23:41:25.338665
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(3):
        assert VariablesGenerator.generate('variable') == '_py_backwards_variable_{}'.format(i)

# Generated at 2022-06-23 23:41:30.043259
# Unit test for function debug
def test_debug():
    assert not sys.stderr.getvalue()
    debug(lambda: 'a')
    assert not sys.stderr.getvalue()
    settings.debug = True
    debug(lambda: 'a')
    assert sys.stderr.getvalue() == '{}: a\n'.format(messages.DEBUG)
    settings.debug = False

# Generated at 2022-06-23 23:41:37.068374
# Unit test for function warn
def test_warn():
    from ..conf import settings
    from io import StringIO

    # Disable colors for tests
    settings.color = False

    # Capture stderr
    stderr = StringIO()
    sys.stderr = stderr

    # Call function
    warn('Something wrong')

    stderr.seek(0)
    output = stderr.read().strip()
    sys.stderr = sys.__stderr__

    assert output == 'py_backwards: --warn-- Something wrong'



# Generated at 2022-06-23 23:41:40.333979
# Unit test for function debug
def test_debug():
    messages.debug = lambda m: 'test {}'.format(m)
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')



# Generated at 2022-06-23 23:41:41.569430
# Unit test for function warn
def test_warn():
    import sys
    try:
        sys.stderr.write = lambda m: None
        warn('this is a warning')
    finally:
        del sys.stderr.write

# Generated at 2022-06-23 23:41:43.983068
# Unit test for function get_source
def test_get_source():
    name = 'something_else'

    def something():
        pass

    assert name in get_source(something)

# Generated at 2022-06-23 23:41:50.914363
# Unit test for function get_source
def test_get_source():
    def dummy():
        a = 1
        b = 2
        c = 3
        return dummy()
    def dummy2():
      def dummy3(a):
        return a
      return dummy3

    source_dumy = get_source(dummy)
    source_dumy2 = get_source(dummy2)
    assert 'return dummy()' in source_dumy
    assert 'return dummy2' not in source_dumy2

# Generated at 2022-06-23 23:41:54.251482
# Unit test for function get_source
def test_get_source():
    def test():
        '''
        def test():
            def test1():
                pass
            def test2():
                pass
        '''
        def test1():
            pass
        def test2():
            pass

    assert get_source(test) == '''
        def test1():
            pass
        def test2():
            pass
    '''

# Generated at 2022-06-23 23:41:56.790802
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
