

# Generated at 2022-06-23 23:32:05.191837
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'
    assert VariablesGenerator.generate('f') == '_py_backwards_f_2'

# Generated at 2022-06-23 23:32:07.286349
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    v = VariablesGenerator.generate('7')
    assert v == '_py_backwards_7_0' and VariablesGenerator._counter == 1

# Unit tests for get_source()

# Generated at 2022-06-23 23:32:07.779046
# Unit test for function warn
def test_warn():
    warn("test warn")

# Generated at 2022-06-23 23:32:14.894097
# Unit test for function debug
def test_debug():
    assert settings.debug is True
    class MockStdErr:
        def __init__(self) -> None:
            self.message = ''

        def write(self, message: str) -> None:
            self.message = message

    std_err = MockStdErr()
    with patch.object(sys, 'stderr', std_err):
        debug(lambda: 'foo')
        assert std_err.message.endswith('foo\n')
    assert settings.debug is True



# Generated at 2022-06-23 23:32:16.838679
# Unit test for function get_source
def test_get_source():
    def my_func():
      pass

    assert get_source(my_func) == 'def my_func():\n  pass'

# Generated at 2022-06-23 23:32:19.036602
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-23 23:32:24.100011
# Unit test for function warn
def test_warn():
    new_log_file = tempfile.NamedTemporaryFile()
    old_log_file = sys.stderr
    sys.stderr = new_log_file

    try:
        warn('test message')
        new_log_file.seek(0)
        message = new_log_file.read()
        assert message == messages.warn('test message') + '\n'

    finally:
        sys.stderr = old_log_file

# Generated at 2022-06-23 23:32:28.869453
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1
    assert get_source(foo) == 'return 1'

    def foo():
        if True:
            return 1
        else:
            return 2
    assert get_source(foo) == 'if True:\n    return 1\nelse:\n    return 2'

# Generated at 2022-06-23 23:32:30.744684
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("num") == "_py_backwards_num_0"


# Generated at 2022-06-23 23:32:33.633087
# Unit test for function warn
def test_warn():
    try:
        warn('warn')
    except Exception:
        pass

    try:
        with settings.debug_api(True):
            debug(lambda: 'debug')
    except Exception:
        pass

# Generated at 2022-06-23 23:32:38.726956
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # call "generate" function three times
    variables_generator = VariablesGenerator.generate('test_')
    variables_generator1 = VariablesGenerator.generate('test_')
    variables_generator2 = VariablesGenerator.generate('test_')

    # get the value of the "_counter" variable
    counter_value = VariablesGenerator._counter
    # if value is not 3 test fails
    assert counter_value == 3

# Generated at 2022-06-23 23:32:40.322142
# Unit test for function warn
def test_warn():
    assert len(warn.__wrapped__.__doc__) != 0

# Generated at 2022-06-23 23:32:43.821147
# Unit test for function eager
def test_eager():
    # type: () -> None
    def f():
        yield 1

    x = eager(f)()
    assert isinstance(x, list)
    assert list(x) == [1]
    assert get_source(f) == get_source(x)

# Generated at 2022-06-23 23:32:45.183288
# Unit test for function warn
def test_warn():
    sys.stderr = sys.stdout
    warn('test')



# Generated at 2022-06-23 23:32:53.541518
# Unit test for function debug
def test_debug():
    from .stream import Stream
    from .diff import Diff

    import unittest
    import sys
    import io

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.new_out = io.StringIO()
            sys.stdout = self.new_out
            settings.debug = True

        def test_debug(self):

            def get_message():
                return "hello"

            debug(get_message)
            self.assertEqual(f"{messages.debug('hello')}\n", self.new_out.getvalue())

        def test_debug_different_value(self):
            def get_message():
                return "hello"

            settings.debug = False
            debug(get_message)
            self.assertEqual("", self.new_out.getvalue())

# Generated at 2022-06-23 23:32:54.297788
# Unit test for function debug
def test_debug():
    debug(lambda: 'message')



# Generated at 2022-06-23 23:32:56.209985
# Unit test for function warn
def test_warn():
    output = StringIO()
    sys.stderr = output

    warn('message')
    assert output.getvalue() == '\x1b[93mmessage\x1b[0m\n'


# Generated at 2022-06-23 23:32:59.083073
# Unit test for function warn
def test_warn():
    message = 'hello world'

    with mock.patch('sys.stderr') as stderr:
        warn(message)
        stderr.write.assert_called_once_with(messages.warn(message) + '\n')



# Generated at 2022-06-23 23:33:01.015254
# Unit test for function eager
def test_eager():
    def gen():
        yield 1
        yield 2
        yield 3
    assert eager(gen)() == [1, 2, 3]

# Generated at 2022-06-23 23:33:02.665464
# Unit test for function get_source
def test_get_source():
    source = get_source(lambda x: x + 1)
    assert source == "return x + 1"



# Generated at 2022-06-23 23:33:06.378566
# Unit test for function debug
def test_debug():
    from io import StringIO
    f = StringIO()
    sys.stderr = f

    def message():
        return 'hello'

    debug(message)
    assert f.getvalue() == '\x1b[2mhello\x1b[0m\n'

    sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:33:14.977298
# Unit test for function debug
def test_debug():
    debug_messages = []
    if sys.version_info >= (3, 5):
        from contextlib import suppress
    else:
        from contextlib2 import suppress
    with suppress(AttributeError):  # in case of doctest
        settings.debug = True
        try:
            def get_message() -> str:
                debug_messages.append('debug message')
                return 'debug message'
            debug(get_message)
            assert debug_messages == ['debug message']
        finally:
            settings.debug = False
            debug_messages.clear()
    debug(get_message)
    assert debug_messages == []

# Generated at 2022-06-23 23:33:21.650793
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    msg = 'Test message'
    with patch('sys.stderr') as stderr, patch('sys.stdout') as stdout:
        debug(lambda: msg)
        if settings.debug:
            assert stderr.write.call_args[0][0].startswith('[Debug]')
        else:
            assert stderr.write.call_count == 0

        assert stdout.write.call_count == 0

# Generated at 2022-06-23 23:33:24.062954
# Unit test for function get_source
def test_get_source():
    source_code = "def main():\n    return 1 \n"
    assert source_code == get_source(test_get_source)

# Generated at 2022-06-23 23:33:28.797836
# Unit test for function get_source
def test_get_source():
    def example():
        def hello():
            pass
        return hello

    actual_source = get_source(example())
    expected_source = '''def hello():
    pass
return hello'''

    assert actual_source == expected_source, '''
Expected:

{}

Got:

{}
    '''.format(expected_source, actual_source)

# Generated at 2022-06-23 23:33:30.488357
# Unit test for function eager
def test_eager():
    @eager
    def get_iterable():
        yield 0
        yield 1

    assert get_iterable() == [0, 1]

# Generated at 2022-06-23 23:33:32.895765
# Unit test for function get_source
def test_get_source():
    def foo():
        for i in range(10):
            print(i)

    assert get_source(foo) == 'for i in range(10):\n    print(i)'

# Generated at 2022-06-23 23:33:36.833516
# Unit test for function debug
def test_debug():
    """Verify that debug prints message when debug is enabled."""
    def test():
        return 'Test message'
    settings.debug = True
    # TODO: find a way to test debug
    # assert debug(test) == messages.debug(test())
    settings.debug = False

# Generated at 2022-06-23 23:33:43.164668
# Unit test for function warn
def test_warn():
    import io
    import sys
    import unittest

    class Test(unittest.TestCase):
        @unittest.mock.patch.dict(sys.modules, {'sys': unittest.mock.Mock()})
        def test(self):
            stderr = io.StringIO()
            sys.stderr = stderr

            warn('message')

            self.assertEqual(stderr.getvalue(), "py_backwards: warning: message\n")

    unittest.main()

# Generated at 2022-06-23 23:33:45.380965
# Unit test for function get_source
def test_get_source():
    def test() -> None:
        """Test function."""
        pass

    assert get_source(test) == 'def test() -> None:\n    """Test function."""\n    pass\n'

# Generated at 2022-06-23 23:33:46.458829
# Unit test for function warn
def test_warn():
    assert True


# Generated at 2022-06-23 23:33:48.489641
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(get_message = lambda: 'test message')
    assert 'test message' in sys.stderr.getvalue()

# Generated at 2022-06-23 23:33:49.538637
# Unit test for function debug
def test_debug():
    debug(lambda: 'test message')



# Generated at 2022-06-23 23:33:51.894302
# Unit test for function eager
def test_eager():
    @eager  # type: ignore
    def get_stuff() -> Iterable[int]:
        yield 1
        yield 2

    assert get_stuff() == [1, 2]

# Generated at 2022-06-23 23:33:54.716396
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert (VariablesGenerator.generate("x") == '_py_backwards_x_0')
    assert (VariablesGenerator.generate("y") == '_py_backwards_y_1')

# Generated at 2022-06-23 23:34:00.486777
# Unit test for function debug
def test_debug():
    import sys
    from contextlib import redirect_stderr
    from io import StringIO
    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'Test')
        assert 'Test' not in f.getvalue()
        debug(lambda: 'Test2')
        assert 'Test2' not in f.getvalue()
        settings.debug = True
        debug(lambda: 'Test')
        assert 'Test' in f.getvalue()

# Generated at 2022-06-23 23:34:04.774878
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest
    generator = VariablesGenerator()
    assert generator.generate('a') == '_py_backwards_a_0'
    assert generator.generate('b') == '_py_backwards_b_1'
    assert generator.generate('a') == '_py_backwards_a_2'
    assert generator.generate('a') == '_py_backwards_a_3'



# Generated at 2022-06-23 23:34:08.816970
# Unit test for function warn
def test_warn():
    from io import StringIO
    try:
        import sys
        saved_stderr = sys.stderr
        my_stderr = StringIO()
        sys.stderr = my_stderr
        warn('test')
    finally:
        sys.stderr = saved_stderr
    m = my_stderr.getvalue()
    assert re.match(r'^\x1b\[(\d)mtest\x1b\[0m$', m)



# Generated at 2022-06-23 23:34:11.028904
# Unit test for function warn
def test_warn():
    import io
    import sys
    out = io.StringIO()
    sys.stderr = out
    warn("test warn")
    assert "WARNING" in out.getvalue()



# Generated at 2022-06-23 23:34:14.263597
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator._counter == 1
    assert VariablesGenerator.generate('y') == '_py_backwards_y_1'
    assert VariablesGenerator._counter == 2

# Generated at 2022-06-23 23:34:19.604494
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """VariablesGenerator generates unique names"""
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'

# Generated at 2022-06-23 23:34:26.097787
# Unit test for function warn
def test_warn():
    import builtins
    assert 'print' in dir(builtins)
    real_print = builtins.print

    import io
    out = io.StringIO()

    try:
        builtins.print = out.write
        warn('test warn')
    finally:
        builtins.print = real_print

    assert out.getvalue() == 'pybackwards:warn: test warn\n'



# Generated at 2022-06-23 23:34:37.701177
# Unit test for function debug
def test_debug():
    debug_messages = []
    def fake_debug(message: str) -> None:
        debug_messages.append(message)

    debug_patcher = mock.patch('py_backwards.utils.debug', fake_debug)

    with debug_patcher:
        settings.debug = True
        debug(lambda: 'test_message')
        assert debug_messages == ['test_message']
        settings.debug = 0
        debug(lambda: 'test_message')
        assert debug_messages == ['test_message']
        debug(lambda: 'test_message')
        assert debug_messages == ['test_message']
        settings.debug = 1
        debug(lambda: 'test_message')
        assert debug_messages == ['test_message', 'test_message']
        settings.debug = True

# Generated at 2022-06-23 23:34:41.018170
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variables = [VariablesGenerator.generate('a') for i in range(100)]
    assert len(variables) == len(list(set(variables))), "Checking for equality. Generated names should be unique."


# Generated at 2022-06-23 23:34:42.995754
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-23 23:34:44.381987
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == list(range(10))

# Generated at 2022-06-23 23:34:53.066760
# Unit test for function debug
def test_debug():
    from unittest import mock

    debug_message = mock.Mock()

    with mock.patch('sys.stderr') as mock_stderr:
        with settings(debug=False):
            debug(debug_message)
        debug_message.assert_not_called()
        mock_stderr.write.assert_not_called()

    with mock.patch('sys.stderr') as mock_stderr:
        debug_message.return_value = 'message'
        with settings(debug=True):
            debug(debug_message)
        debug_message.assert_called_once_with()
        mock_stderr.write.assert_called_once_with('[DEBUG] message\n')

# Generated at 2022-06-23 23:34:54.032669
# Unit test for function warn
def test_warn():
    warn("test case1")



# Generated at 2022-06-23 23:34:57.290073
# Unit test for function eager
def test_eager():
    @eager
    def get_range(stop: int) -> Iterable[int]:
        for i in range(stop):
            yield i

    assert get_range(2) == [0, 1]

# Generated at 2022-06-23 23:34:59.178146
# Unit test for function get_source
def test_get_source():
    def foo(): pass
    assert get_source(foo) == 'def foo(): pass'



# Generated at 2022-06-23 23:35:00.528680
# Unit test for function eager
def test_eager():
    assert list(eager(range)(2)) == list(range(2))

# Generated at 2022-06-23 23:35:04.638830
# Unit test for function get_source
def test_get_source():
    # this is a valid python identifier
    variable = 'x'
    def fn():
        return variable
    assert get_source(fn) == 'return variable'

    # this is an invalid python identifier
    variable = '1'
    def fn():
        return variable
    assert get_source(fn) == 'return variable'

# Generated at 2022-06-23 23:35:06.443572
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Doesn't raise error
    assert VariablesGenerator.generate('test') != VariablesGenerator.generate('test')

# Generated at 2022-06-23 23:35:13.928304
# Unit test for function debug
def test_debug():
    if sys.version_info < (3, 5):
        return

    from unittest import TestCase, mock

    from ..conf import reset_settings
    settings.debug = True
    reset_settings()

    class TestDebug(TestCase):
        def test_debug(self):
            with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
                debug(lambda: 'foo')
                mock_stderr.write.assert_called_once_with("\x1b[0;36mfoo\x1b[0m\n")
                mock_stderr.reset_mock()
                settings.debug = False
                debug(lambda: 'foo')
                self.assertFalse(mock_stderr.write.called)


# Generated at 2022-06-23 23:35:14.471771
# Unit test for function warn
def test_warn():
    assert warn('message')

# Generated at 2022-06-23 23:35:15.438973
# Unit test for function warn
def test_warn():
    assert warn('hello') == None



# Generated at 2022-06-23 23:35:17.740824
# Unit test for function eager
def test_eager():
    @eager
    def f():
        return range(5)
    assert f() == list(range(5))

# Generated at 2022-06-23 23:35:21.402156
# Unit test for function warn
def test_warn():
    from io import StringIO
    from contextlib import redirect_stderr
    f = StringIO()
    with redirect_stderr(f):
        warn("Hello")
    assert 'Hello' in f.getvalue()


# Generated at 2022-06-23 23:35:27.559087
# Unit test for function eager
def test_eager():
    def foo(a, b):
        for i in range(a):
            yield i
        for i in range(b):
            yield i

    assert foo(1, 2) == [0, 0, 1]
    assert foo(2, 0) == [0, 1]

    eager_foo = eager(foo)
    assert eager_foo(1, 2) == [0, 0, 1]
    assert eager_foo(2, 0) == [0, 1]



# Generated at 2022-06-23 23:35:28.800632
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda : 'hello')

# Generated at 2022-06-23 23:35:35.317256
# Unit test for function eager
def test_eager():
    def some_generator():
        yield 1
        yield 2

    def some_generator_with_values(a, b):
        yield a
        yield b

    # Simple case
    assert eager(some_generator)() == [1, 2]

    # With parameters
    assert eager(some_generator_with_values)(1, 2) == [1, 2]

    # With parameters and keyword arguments
    assert eager(some_generator_with_values)(1, b=2) == [1, 2]


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 23:35:37.175037
# Unit test for function eager
def test_eager():
    def f() -> Iterable[int]:
        yield 1
        yield 2
    assert eager(f)() == [1, 2]

# Generated at 2022-06-23 23:35:41.419954
# Unit test for function warn
def test_warn():
    # Given
    message = 'This is a test message'

    # When
    warn(message)

    # Then
    assert(sys.stderr.getvalue() == '\033[33mThis is a test message\033[0m\n')


# Generated at 2022-06-23 23:35:48.794581
# Unit test for function debug
def test_debug():
    from io import StringIO
    from sys import stderr
    saved_stderr = sys.stderr
    sys.stderr = StringIO()

    settings.debug = True
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == messages.debug('test') + '\n'

    sys.stderr = saved_stderr

# Generated at 2022-06-23 23:35:51.889231
# Unit test for function eager
def test_eager():
    @eager
    def iterate_over_range():
        for i in range(10):
            yield i

    assert iterate_over_range() == list(range(10))



# Generated at 2022-06-23 23:35:54.769186
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'

# Generated at 2022-06-23 23:35:55.796722
# Unit test for function eager
def test_eager():
    def test_iterator():
        yield 1
        yield 2
        yield 3
    assert eager(test_iterator)() == [1, 2, 3]

# Generated at 2022-06-23 23:35:58.692113
# Unit test for function debug
def test_debug():
    original_debug = settings.debug
    try:
        settings.debug = True
        debug(lambda: 'debug')

        settings.debug = False
        debug(lambda: 'debug')
    finally:
        settings.debug = original_debug

# Generated at 2022-06-23 23:36:03.039608
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen1 = VariablesGenerator()
    gen2 = VariablesGenerator()
    assert gen1.generate('x') != gen2.generate('x')
    assert gen1.generate('x') == gen1.generate('x')
    assert gen2.generate('x') == gen2.generate('x')

# Generated at 2022-06-23 23:36:07.968737
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # We need to generate two names, each must be unique
    assert VariablesGenerator.generate('var') != VariablesGenerator.generate('var')
    # Class tracks its state between each call, so both may be identical
    assert VariablesGenerator.generate('var') == VariablesGenerator.generate('var')

# Generated at 2022-06-23 23:36:13.319483
# Unit test for function get_source
def test_get_source():
    def fn(): pass
    assert get_source(fn) == 'pass'

    @nested
    def fn(): pass
    assert get_source(fn) == 'pass'

    @nested
    def fn():
        pass
    assert get_source(fn) == '    pass'

    @nested
    def fn():
        pass

    assert get_source(fn) == '    pass'



# Generated at 2022-06-23 23:36:15.589161
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-23 23:36:17.674081
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'G')
    settings.debug = True
    debug(lambda: 'H')



# Generated at 2022-06-23 23:36:21.589110
# Unit test for function debug
def test_debug():
    from py_backwards.core.conf import settings
    settings.debug = True
    x = 0
    def get_message():
        nonlocal x
        return 'original x: {}'.format(x)

    debug(get_message)
    assert x == 0
    x = 1
    debug(get_message)
    assert x == 1

# Generated at 2022-06-23 23:36:27.682647
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    stderr = io.StringIO()
    with contextlib.redirect_stderr(stderr):
        with contextlib.ExitStack() as stack:
            stack.enter_context(settings.using({'debug': True}))
            debug(lambda: 'Test')
        assert stderr.getvalue().strip() == 'Debug: Test'


# Generated at 2022-06-23 23:36:30.049835
# Unit test for function debug
def test_debug():
    from .logger import LoggedOutput

    with LoggedOutput() as output:
        debug(lambda: 'message')
    assert output.stdout == [
        messages.debug('message')
    ]



# Generated at 2022-06-23 23:36:37.363517
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_3'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_4'

# Generated at 2022-06-23 23:36:39.955353
# Unit test for function debug
def test_debug():
    from ..types import Settings
    from ..conf import settings

    settings.set(Settings(debug=True))
    debug(lambda: 'test')
    settings.reset()



# Generated at 2022-06-23 23:36:41.568017
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(3))() == [0, 1, 2]



# Generated at 2022-06-23 23:36:43.850471
# Unit test for function get_source
def test_get_source():
    def test_func():
        return 'test'

    assert get_source(test_func) == 'return \'test\'\n'



# Generated at 2022-06-23 23:36:51.532546
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        counter = 0
        def get_message():
            nonlocal counter
            counter += 1
            return 'Some message'
        debug(get_message)
        assert counter == 1
    except:
        raise
    finally:
        settings.debug = False
    settings.debug = False
    try:
        counter = 0
        def get_message():
            nonlocal counter
            counter += 1
            return 'Some message'
        debug(get_message)
        assert counter == 0
    except:
        raise
    finally:
        settings.debug = True
    settings.debug = True

# Generated at 2022-06-23 23:36:52.795214
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2

    assert gen() == [1, 2]

# Generated at 2022-06-23 23:36:56.026076
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    """Test if the VariablesGenerator class generates variables with the correct names."""
    for i in range(0, 10):
        assert VariablesGenerator.generate('test') == '_py_backwards_test_{}'.format(i)



# Generated at 2022-06-23 23:37:00.149323
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    x = VariablesGenerator.generate('x')
    y = VariablesGenerator.generate('x')
    assert x == '_py_backwards_x_0'
    assert y == '_py_backwards_x_1'
    assert x is not y


# Generated at 2022-06-23 23:37:03.558847
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate("var"))
    print(VariablesGenerator.generate("var"))
    print(VariablesGenerator.generate("var"))


# Generated at 2022-06-23 23:37:05.509144
# Unit test for function get_source
def test_get_source():
    """Test the function get_source."""
    def hello():
        """Hello world."""
        pass

    assert get_source(hello) == 'def hello():\n    """Hello world."""\n    pass'

# Generated at 2022-06-23 23:37:11.187089
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    names = [VariablesGenerator.generate(variable) for variable in ["qwerty", "qwerty", "asdf", "qwerty", "zxcv"]]
    assert names == ['_py_backwards_qwerty_0', '_py_backwards_qwerty_1', '_py_backwards_asdf_2', '_py_backwards_qwerty_3', '_py_backwards_zxcv_4']



# Generated at 2022-06-23 23:37:13.033442
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2

    assert eager(foo)() == [1, 2]
    assert foo() == iter([1, 2])

# Generated at 2022-06-23 23:37:16.898585
# Unit test for function warn
def test_warn():
    import io
    import sys
    import pytest
    test_string = "test_warn_message"
    sys.stderr = io.StringIO()
    warn(test_string)
    stderr = sys.stderr.getvalue()
    assert "⚠ " in stderr
    assert test_string in stderr
    sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:37:22.727702
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar_func():
            pass

        def baz_func():
            pass

    assert re.match(
        r'(def bar_func\(\):\n\s*pass\n\s*\n)+'
        r'(def baz_func\(\):\n\s*pass\n)',
        get_source(foo),
    )

# Generated at 2022-06-23 23:37:25.670724
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    for i in range(100):
        unique_value = VariablesGenerator.generate("testing")
        assert unique_value == "_py_backwards_testing_{}".format(i)


# Generated at 2022-06-23 23:37:27.344438
# Unit test for function eager
def test_eager():
    def fn():
        yield 1
        yield 2
    assert eager(fn)() == [1, 2]

# Generated at 2022-06-23 23:37:29.065707
# Unit test for function eager
def test_eager():
    @eager
    def fn():
        yield from range(10)
    assert fn() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 23:37:31.775296
# Unit test for function warn
def test_warn():
    with patch('sys.stderr', new=StringIO()) as stderr:
        msg = 'Test warn message'
        warn(msg)
        print(stderr.getvalue())
        assert stderr.getvalue() == messages.warn(msg) + '\n'

# Generated at 2022-06-23 23:37:36.911604
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('a') == '_py_backwards_a_0'
    assert gen.generate('a') == '_py_backwards_a_1'
    assert gen.generate('a') == '_py_backwards_a_2'
    assert gen.generate('a') == '_py_backwards_a_3'

# Generated at 2022-06-23 23:37:40.026065
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert type(VariablesGenerator.generate('foo')) == str
    assert type(VariablesGenerator.generate('bar')) == str


# Generated at 2022-06-23 23:37:42.189504
# Unit test for function warn
def test_warn():
    import StringIO
    import sys

    old_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()

    try:
        messages.warn('test')
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-23 23:37:44.278763
# Unit test for function eager
def test_eager():
    def throw_http_error(code: int) -> None:
        yield code

    def get_http_errors() -> Iterable[int]:
        for code in [404, 403, 405]:
            yield from throw_http_error(code)

    assert eager(get_http_errors)() == [404, 403, 405]

# Generated at 2022-06-23 23:37:46.784711
# Unit test for function debug
def test_debug():
    import sys
    sys.stderr = sys.stdout
    class Test:
        def __init__(self, message):
            self.message = message
        def __repr__(self):
            return self.message
    try:
        settings.debug = True
        debug(lambda: Test("Test"))
        settings.debug = False
        debug(lambda: Test("Test"))
    finally:
        settings.debug = False


# Generated at 2022-06-23 23:37:49.583059
# Unit test for function eager
def test_eager():
    def test_func():
        for i in range(10):
            yield i + 1
    func = eager(test_func)
    assert func() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-23 23:37:54.613074
# Unit test for function debug
def test_debug():
    message = '"debug" function test'
    with open('/dev/null', 'w') as null:
        backup_stderr = sys.stderr
        try:
            sys.stderr = null
            debug(lambda: message)

            class Settings:
                debug = True

            old_settings = sys.modules['py_backwards.conf'].settings
            try:
                sys.modules['py_backwards.conf'].settings = Settings()
                debug(lambda: message)
            finally:
                sys.modules['py_backwards.conf'].settings = old_settings
        finally:
            sys.stderr = backup_stderr

# Generated at 2022-06-23 23:37:58.798684
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stderr

    def check_if_message_is_print(message):
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: message)
            out = f.getvalue()

        if out:
            assert 'debug' in out
            assert message in out
        else:
            assert False

    check_if_message_is_print('test')



# Generated at 2022-06-23 23:37:59.878430
# Unit test for function warn
def test_warn():
    warn('message')



# Generated at 2022-06-23 23:38:04.599078
# Unit test for function eager
def test_eager():
    result = []

    @eager
    def add_to_result(x: int) -> None:
        result.append(x)

    add_to_result(1)
    add_to_result(2)
    add_to_result(3)

    assert result == [1, 2, 3]



# Generated at 2022-06-23 23:38:08.697184
# Unit test for function get_source
def test_get_source():
    def fn():
        "Hello"
        pass
    assert get_source(fn) == "    \"Hello\"\n    pass", get_source(fn)
    assert get_source(get_source) == get_source.__doc__, get_source(get_source)


# Generated at 2022-06-23 23:38:12.377849
# Unit test for function eager
def test_eager():
    def squares():
        for i in range(10):
            yield i ** 2

    @eager
    def squares_eager():
        for i in range(10):
            yield i ** 2

    assert squares_eager() == squares()


# Generated at 2022-06-23 23:38:14.420948
# Unit test for function warn
def test_warn():
    with settings(warner=warn):
        warn('message')

warn = warn if settings.warn else lambda *args: None



# Generated at 2022-06-23 23:38:16.158212
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'

# Generated at 2022-06-23 23:38:20.967804
# Unit test for function debug
def test_debug():
    class A:
        n = 0

        @debug
        def get_message(self):
            self.n += 1
            return 'test'

    a = A()
    a.get_message()
    assert a.n == 1

    settings.debug = True
    a.get_message()
    assert a.n == 2

# Generated at 2022-06-23 23:38:22.351841
# Unit test for function warn
def test_warn():
    def index():
        warn("This is just a test")

    index()

# Generated at 2022-06-23 23:38:25.201674
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    for i in range(100):
        assert VariablesGenerator.generate('test') == '_py_backwards_test_%d' % i


# Generated at 2022-06-23 23:38:27.778751
# Unit test for function get_source
def test_get_source():
    def add(x, y):
        return x + y

    expected = 'return x + y'
    actual = get_source(add)
    assert expected == actual

# Generated at 2022-06-23 23:38:30.757628
# Unit test for function debug
def test_debug():
    result = []
    debug(lambda: 'aaa')
    debug(lambda: 'bbb')
    settings.debug = True
    debug(lambda: 'ccc')
    debug(lambda: 'ddd')

# Generated at 2022-06-23 23:38:37.630365
# Unit test for function debug
def test_debug():
    import os
    import sys
    import tempfile
    import io
    import pytest

    old_debug = settings.debug
    settings.debug = True

    def make_debugger(expected_message: str) -> Callable[[], None]:
        def debugger() -> None:
            f = tempfile.TemporaryFile()
            sys.stderr = io.TextIOWrapper(f)
            debug(lambda: expected_message)
            sys.stderr.flush()
            f.seek(0)
            actual_message = f.readline()
            sys.stderr = sys.__stderr__  # restore the default stderr
            f.close()
            assert expected_message == actual_message.replace('\n', '')
        return debugger


# Generated at 2022-06-23 23:38:42.297438
# Unit test for function warn
def test_warn():
    # mock stderr
    string_io = io.StringIO()
    with contextlib.redirect_stderr(string_io):
        warn('some message')
    # compare with stdout
    assert string_io.getvalue() == messages.warn('some message') + '\n'

# Generated at 2022-06-23 23:38:44.596381
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    source = get_source(func)
    assert source == 'def func():\n    pass\n'

# Generated at 2022-06-23 23:38:46.985674
# Unit test for function eager
def test_eager():
    def return_generator():
        yield 1
        yield 2
    assert eager(return_generator)() == [1, 2]


# Generated at 2022-06-23 23:38:49.563227
# Unit test for function eager
def test_eager():
    def func():
        return [1, 2, 3]

    assert func() == [1, 2, 3]
    assert eager(func)() == [1, 2, 3]

# Generated at 2022-06-23 23:38:54.208486
# Unit test for function get_source
def test_get_source():
    def foo(x, y):
        def bar(z):
            return x + y + z

        return bar

    assert get_source(foo) == 'def foo(x, y):\n' \
                              '    def bar(z):\n' \
                              '        return x + y + z\n' \
                              '\n' \
                              '    return bar\n'

# Generated at 2022-06-23 23:38:56.641076
# Unit test for function warn
def test_warn():
    import tempfile

    with tempfile.TemporaryFile() as f:
        message = 'TEST MESSAGE'
        warn(message)
        f.seek(0)
        assert f.read().decode().strip() == message

# Generated at 2022-06-23 23:39:01.265725
# Unit test for function get_source
def test_get_source():
    # pylint: disable=unused-variable
    def fn():
        """Function

        To test

        The get_source

        Function."""
        var = 1    # noqa


# Generated at 2022-06-23 23:39:05.480606
# Unit test for function eager
def test_eager():
    @eager
    def f(x: int) -> Iterable[int]:
        for i in range(x):
            yield i
    assert f(0) == []
    assert f(1) == [0]
    assert f(10) == list(range(10))

# Generated at 2022-06-23 23:39:12.207383
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()
    debug(lambda: 'hi')
    assert sys.stderr.getvalue() == '\n'
    settings.debug = True
    debug(lambda: 'hi')
    assert sys.stderr.getvalue() == '\n\n\x1b[1;30mDEBUG:\x1b[0m hi\n'
    settings.debug = False

# Generated at 2022-06-23 23:39:17.444454
# Unit test for function warn
def test_warn():
    messages.warning = True
    x = []
    def f():
        x.append('f')
    def g(m):
        x.append('g')
    saved = messages.get_warn_message
    messages.get_warn_message = g
    
    warn('test')
    assert x == ['g', 'f']
    messages.get_warn_message = saved

# Generated at 2022-06-23 23:39:21.234206
# Unit test for function eager
def test_eager():
    a = []

    @eager
    def test(i: int) -> Iterable[int]:
        for j in range(i):
            a.append(j)
            yield j
    test(10)
    assert a == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:39:26.513373
# Unit test for function debug
def test_debug():
    messages.reset()
    settings.debug = True
    debug(lambda: 'hello world')
    assert messages.debug_output == ['\x1b[37m[DEBUG] hello world\x1b[39m']

    messages.reset()
    settings.debug = False
    debug(lambda: 'hello world')
    assert messages.debug_output == []

# Generated at 2022-06-23 23:39:30.454328
# Unit test for function get_source
def test_get_source():
    fn = lambda: None
    assert get_source(fn) == 'fn = lambda: None'

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-23 23:39:35.982833
# Unit test for function eager
def test_eager():
    import inspect

    fn = lambda a: (i for i in range(a))
    eager_fn = eager(fn)
    assert not inspect.isgeneratorfunction(fn)
    assert not inspect.isgeneratorfunction(eager_fn)
    assert fn(3) == [0, 1, 2]
    assert eager_fn(3) == [0, 1, 2]



# Generated at 2022-06-23 23:39:38.003146
# Unit test for function warn
def test_warn():
    assert warn.__doc__ == 'Prints warning message with prefix "Warning: "'



# Generated at 2022-06-23 23:39:42.349907
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == "def test_get_source():\n    assert get_source(test_get_source) == 'def test_get_source():\\n    assert get_source(test_get_source) == 'def test_get_source():\\n    assert get_source(test_get_source) == \''"

# Generated at 2022-06-23 23:39:46.598942
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == 'def get_source(fn: Callable[..., Any]) -> str:\n    """Returns source code of the function."""\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)'


# Generated at 2022-06-23 23:39:51.061756
# Unit test for function eager
def test_eager():
    def integers_up_to(n: int) -> Iterable[int]:
        for i in range(n):
            yield i
    assert eager(integers_up_to)(100) == range(100)
    assert eager(integers_up_to)(10) == range(10)



# Generated at 2022-06-23 23:39:52.895926
# Unit test for function get_source
def test_get_source():
    def func():
        pass
    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-23 23:39:57.657174
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug(lambda: 'test')
    assert True

    settings.debug = True
    captured = capsys.readouterr()
    debug(lambda: 'test')
    captured = capsys.readouterr()
    assert len(captured.out) > 0

    settings.debug = False



# Generated at 2022-06-23 23:39:59.470611
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(1))() == [0]
    assert eager(lambda: [1])() == [1]

# Generated at 2022-06-23 23:40:01.072532
# Unit test for function get_source
def test_get_source():
    def hello():
        x = 1
        return x


# Generated at 2022-06-23 23:40:02.388945
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello world')



# Generated at 2022-06-23 23:40:12.703059
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    from ie_pandas.__init__ import VariablesGenerator
    from pytest import approx

    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_3'
    # Unit test for constructor of class get_source
    def get_source(fn: Callable[..., Any]) -> str:
        """Returns source code of the function."""

    def some_function():
        a = 1

    def another_function():
        b = 1


# Generated at 2022-06-23 23:40:13.761817
# Unit test for function get_source

# Generated at 2022-06-23 23:40:20.657952
# Unit test for function debug
def test_debug():
    messages.DEBUG = 'DEBUG'
    settings.debug = True

    import io
    import sys
    stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'Hello World')
        assert sys.stderr.getvalue() == 'DEBUG: Hello World\n'

        sys.stderr = io.StringIO()
        settings.debug = False
        debug(lambda: 'Hello World')
        assert sys.stderr.getvalue() == ''
    finally:
        sys.stderr = stderr



# Generated at 2022-06-23 23:40:26.815022
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('test') == '_py_backwards_test_0'
    assert generator.generate('test') == '_py_backwards_test_1'
    assert generator.generate('test') == '_py_backwards_test_2'
    assert generator.generate('test') == '_py_backwards_test_3'
    assert generator.generate('test') == '_py_backwards_test_4'

# Generated at 2022-06-23 23:40:28.998487
# Unit test for function eager
def test_eager():
    def fn():
        yield 1
        yield 2

    assert eager(fn)() == [1, 2]



# Generated at 2022-06-23 23:40:32.186306
# Unit test for function get_source
def test_get_source():
    def foo():
        """Some docstring
        """
        print('just a line')
    assert get_source(foo) == '"""Some docstring\n"""\nprint(\'just a line\')'



# Generated at 2022-06-23 23:40:33.766207
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') != VariablesGenerator.generate('x')

# Generated at 2022-06-23 23:40:40.107026
# Unit test for function debug
def test_debug():
    debug_function = debug

    from py_backwards import collect_returns
    from unittest.mock import Mock

    warn = Mock()
    settings.debug = True
    debug_function(lambda: 'hello world')
    assert warn.call_args[0] == (messages.debug('hello world'),)
    assert warn.call_args[1] == {'file': sys.stderr}

    with collect_returns(warn):
        settings.debug = False

    warn.reset_mock()
    debug_function(lambda: 'hello world')
    assert not warn.called



# Generated at 2022-06-23 23:40:43.635196
# Unit test for function debug
def test_debug():
    messages.debug = 'DEBUG: {}'
    settings.debug = True

    try:
        debug(lambda: "something")
    except Exception as e:
        assert False, "Calling debug failed with message: {}".format(e)
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:40:47.414433
# Unit test for function warn
def test_warn():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    @warn('always!')
    def f(a, b):
        return a + b



# Generated at 2022-06-23 23:40:56.885796
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # We can't use normal unittest.TestCase despite pylint's warnings, because
    # unittest.TestCase is not a class, but a function-decorator
    # (see https://docs.python.org/3/library/unittest.html#unittest-test-cases)
    vg = VariablesGenerator()
    assert vg.generate(variable="test_1") == '_py_backwards_test_1_0'
    assert vg.generate(variable="test_2") == '_py_backwards_test_2_1'
    assert vg.generate(variable="test_3") == '_py_backwards_test_3_2'



# Generated at 2022-06-23 23:41:02.704558
# Unit test for function debug
def test_debug():
    from unittest import TestCase
    from io import StringIO

    def mock_settings_debug():
        settings.debug = True

    def mock_settings_no_debug():
        settings.debug = False

    def mock_print(message: str) -> None:
        print(message, file=StringIO())

    class TestDebug(TestCase):
        def test_debug(self):
            mock_settings_debug()
            debug(lambda: 'TEST')

        def test_no_debug(self):
            mock_settings_no_debug()
            debug(lambda: 'TEST')

    testcase = TestDebug()

    testcase.test_debug()
    testcase.test_no_debug()

# Generated at 2022-06-23 23:41:12.779766
# Unit test for function get_source

# Generated at 2022-06-23 23:41:16.732248
# Unit test for function get_source
def test_get_source():
    def f(a):
        return a

    def g(a):
        if a > 0:
            return 1
        return 0

    assert get_source(f) == """
return a""".lstrip()

    assert get_source(g) == """
if a > 0:
    return 1
return 0""".lstrip()

# Generated at 2022-06-23 23:41:24.935423
# Unit test for function get_source

# Generated at 2022-06-23 23:41:27.643606
# Unit test for function eager
def test_eager():
    @eager
    def get_numbers() -> Iterable[int]:
        for x in range(3):
            yield x

    assert get_numbers() == [0, 1, 2]



# Generated at 2022-06-23 23:41:30.302325
# Unit test for function get_source
def test_get_source():
    def fn():
        if 1 == 2:
            pass
    assert get_source(fn) == ("if 1 == 2:\n"
                              "    pass")



# Generated at 2022-06-23 23:41:39.744539
# Unit test for function get_source
def test_get_source():
    source_code = ("@py_backwards.decorators\n"
                   "def test():\n"
                   "    def test2():\n"
                   "        pass")
    fn = lambda: None
    fn.__module__ = ''
    fn.__name__ = 'test'
    fn.__qualname__ = 'test'
    fn.__doc__ = None
    fn.__annotations__ = {}
    fn.__defaults__ = None
    fn.__kwdefaults__ = {}
    fn.__code__ = compile(source_code, '<string>', 'exec')
    assert(get_source(fn) == source_code)

# Generated at 2022-06-23 23:41:46.140624
# Unit test for function eager
def test_eager():
    x=[1,2,3,4,5]
    y='hello'
    @eager
    def test_function(x,y):
        return x + y

    assert test_function(x,y) == [1,2,3,4,5,'hello']

if __name__ == "__main__":
    test_eager()

# Generated at 2022-06-23 23:41:46.977859
# Unit test for function debug
def test_debug():
    debug(lambda: 'debug')

# Generated at 2022-06-23 23:41:54.612736
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Initial states.
    assert VariablesGenerator._counter == 0
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator._counter == 1
    # Parameter `variable` should be a string.
    with pytest.raises(TypeError):
        VariablesGenerator.generate(3)
    # Parameter `variable` should be a string.
    with pytest.raises(TypeError):
        VariablesGenerator.generate(True)


# Generated at 2022-06-23 23:41:58.262218
# Unit test for function warn
def test_warn():
    msg = "This is a test"
    expect = "This is a test"
    out = []
    sys.stderr.write = lambda text: out.append(text)
    warn(msg)
    sys.stderr.write = sys.__stderr__.write
    assert out[0] == expect


# Generated at 2022-06-23 23:42:01.778861
# Unit test for function get_source
def test_get_source():
    def f(a, b, c):
        x=a+b
        y=b+c
        z=a+c
        return x+y+z

    source=get_source(f)
    assert source=='''x=a+b
y=b+c
z=a+c
return x+y+z'''


# Generated at 2022-06-23 23:42:03.698524
# Unit test for function warn
def test_warn():
    with redirect_stderr(StringIO()):
        warn('test')
    assert messages.warn('test') in sys.stderr.getvalue()