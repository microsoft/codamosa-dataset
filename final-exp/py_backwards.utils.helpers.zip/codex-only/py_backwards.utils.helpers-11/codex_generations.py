

# Generated at 2022-06-23 23:31:56.658931
# Unit test for function get_source
def test_get_source():
    def source_code():
        return 4

    # Returns source code of the function
    result = get_source(source_code)

    # Remove extra spaces to avoid whitespace inconsistencies in tests
    result = result.replace(' ' * 4, ' ')
    assert result == 'return 4'

# Generated at 2022-06-23 23:31:58.980543
# Unit test for function get_source
def test_get_source():
    # Should not work due to function no longer exists
    # But should still have source code
    source = get_source(dir)
    assert source is not None
    assert 'for name in dir(object):' in source



# Generated at 2022-06-23 23:32:06.355859
# Unit test for function warn
def test_warn():
    warnings = []
    with patch('sys.stderr', new=StringIO()) as stderr:
        def warn(message):
            print(message, file=stderr)
            warnings.append(message)
        with patch('py_backwards.utils.warn', new=warn):
            utils.warn('hello')
            utils.warn('world')
    assert stderr.getvalue() == '\x1b[93mhello\x1b[0m\n\x1b[93mworld\x1b[0m\n'
    assert warnings == ['hello', 'world']


# Generated at 2022-06-23 23:32:12.900121
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    # Test increment
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'

    # Test prefix
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

    # Test suffix
    assert VariablesGenerator.generate('c') == '_py_backwards_c_3'


# Generated at 2022-06-23 23:32:15.027323
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'message')
    settings.debug = False
    debug(lambda: 'message')

# Generated at 2022-06-23 23:32:16.915394
# Unit test for function eager
def test_eager():
    def create_generator():
        for i in range(10):
            yield i

    assert eager(create_generator)() == list(range(10))

# Generated at 2022-06-23 23:32:23.332831
# Unit test for function debug
def test_debug():
    with patch('sys.stderr.write') as stderr_write:
        debug(lambda: 'TEST')
        assert stderr_write.call_count == 0
    with patch('sys.stderr.write') as stderr_write:
        with patch.dict('py_backwards.conf.settings.__dict__',
                        {'debug': True}):
            debug(lambda: 'TEST')
        stderr_write.assert_called_with(messages.debug('TEST'))

# Generated at 2022-06-23 23:32:28.565070
# Unit test for function debug
def test_debug():
    orig = settings.debug
    try:
        settings.debug = True
        called = False
        def get_message():
            nonlocal called
            called = True
            return "test"
        debug(get_message)
        assert called

        called = False
        settings.debug = False
        debug(get_message)
        assert not called
    finally:
        settings.debug = orig

# Generated at 2022-06-23 23:32:38.166951
# Unit test for function debug
def test_debug():
    import io
    import unittest
    import sys

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.original_stderr = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.original_stderr

        def test_no_debug(self):
            debug(lambda: 'message')

            self.assertEqual(
                sys.stderr.getvalue(),
                ''
            )

        def test_debug(self):
            settings.debug = True
            debug(lambda: 'message')


# Generated at 2022-06-23 23:32:40.165481
# Unit test for function eager
def test_eager():
    assert eager(lambda: range(5))() == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:32:49.811261
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    import sys

    def test_function():
        debug(lambda: 'some debug')

    output = StringIO()
    sys.stderr = output
    test_function()
    sys.stderr = sys.__stderr__
    result = output.getvalue()
    assert result == '\033[0;34m[DEBUG]\033[0m: some debug\n'

    output = StringIO()
    sys.stderr = output
    settings.debug = True
    test_function()
    sys.stderr = sys.__stderr__
    result = output.getvalue()
    assert result == '\033[0;34m[DEBUG]\033[0m: some debug\n'
    settings.debug = False

# Generated at 2022-06-23 23:32:53.577424
# Unit test for function debug
def test_debug():
    from . import strings

    settings.debug = True
    try:
        debug(lambda: 'message')
        assert strings.keep_between(sys.stderr.getvalue(), '<stderr>',
                                    '</stderr>').strip() == 'DEBUG: message'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-23 23:32:55.649220
# Unit test for function eager
def test_eager():
    def test_function():
        for i in range(4):
            yield i
    decorated_function = eager(test_function)
    assert test_function() != list(test_function())
    assert decorated_function() == list(test_function())

# Generated at 2022-06-23 23:32:57.896436
# Unit test for function eager
def test_eager():
    x = [1,2,3]
    @eager
    def f():
        for i in x:
            yield i
    y = f()
    assert y == [1,2,3]



# Generated at 2022-06-23 23:33:00.836962
# Unit test for function debug
def test_debug():
    settings.debug = True
    x = []
    def message():
        x.append(1)
        return 'foo'
    debug(message)
    assert x

    settings.debug = False
    debug(message)
    assert not x

# Tests for function get_source

# Generated at 2022-06-23 23:33:08.672234
# Unit test for function get_source

# Generated at 2022-06-23 23:33:11.116804
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1

    bar = eager(foo)
    assert bar() == [1]

# Generated at 2022-06-23 23:33:13.291138
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-23 23:33:17.704187
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'


if __name__ == '__main__':
    test_VariablesGenerator()

# Generated at 2022-06-23 23:33:22.458168
# Unit test for function debug
def test_debug():
    with patch('sys.stderr') as stderr:
        with settings_override(debug=True):
            debug(lambda: 'hello')
            stderr.write.assert_called()

        with settings_override(debug=False):
            debug(lambda: 'hello')
            stderr.write.assert_not_called()



# Generated at 2022-06-23 23:33:25.495462
# Unit test for function eager
def test_eager():
    @eager
    def range_fn(n: int) -> Iterable[int]:
        return range(n)

    assert range_fn(1) == [0]

# Generated at 2022-06-23 23:33:27.455401
# Unit test for function get_source
def test_get_source():
    def test():
        a = 1
        b = 2
    assert get_source(test) == 'a = 1\nb = 2'



# Generated at 2022-06-23 23:33:30.770462
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('var') == '_py_backwards_var_0'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_1'
    assert VariablesGenerator.generate('var') == '_py_backwards_var_2'

# Generated at 2022-06-23 23:33:33.865523
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    names = []
    for i in range(1000):
        names.append(VariablesGenerator.generate('a'))
    assert len(set(names)) == 1000
    assert len(set([name[0] for name in names])) == 1

# Generated at 2022-06-23 23:33:37.806953
# Unit test for function debug
def test_debug():
    class A:
        def __init__(self, val):
            self.val = val

    a = A('one')

    debug(lambda: len(a.val))

    settings.debug = True

    debug(lambda: len(a.val))

    settings.debug = False

# Generated at 2022-06-23 23:33:41.418424
# Unit test for function debug
def test_debug():
    class Test:
        def func(self):
            return 1

    test_object = Test()
    debug(lambda: 'test')
    settings.debug = True
    debug(lambda: 'test1')
    settings.debug = False
    assert test_object.func() == 1

# Generated at 2022-06-23 23:33:43.970542
# Unit test for function eager
def test_eager():
    def add(x: int, y: int) -> Iterable[int]:
        yield x + y

    x = add(1, 2)
    assert x is not None, "Function eager test failed"



# Generated at 2022-06-23 23:33:48.399394
# Unit test for function debug
def test_debug():
    # show debug messages
    settings.debug = True
    counter = [0]
    def get_message():
        counter[0] += 1
        return 'message'
    debug(get_message)
    assert counter[0] == 1
    # don't show debug messages
    settings.debug = False
    counter[0] = 0
    debug(get_message)
    assert counter[0] == 0

# Generated at 2022-06-23 23:33:53.102117
# Unit test for function debug
def test_debug():
    call_count = 0
    def get_message():
        nonlocal call_count
        call_count += 1
        return 'debug message'
    debug(get_message)
    assert call_count == 0
    old_settings = settings.debug
    settings.debug = True
    debug(get_message)
    assert call_count == 1
    settings.debug = old_settings

# Generated at 2022-06-23 23:34:01.918358
# Unit test for function warn
def test_warn():
    from contextlib import redirect_stderr
    from os import path
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    with TemporaryDirectory() as dir_name:
        file_name = path.join(dir_name, 'test')
        with open(file_name, 'w') as f:
            with redirect_stderr(f):
                warn('test')

        with open(file_name) as f:
            assert f.read() == dedent('''
                # WARNING: test
                # To emit no warnings, run the program with:
                #         PY_BACKWARDS_NO_WARNINGS=yes
                #         python -m py_backwards.transformer my_code.py
            ''').lstrip()


# Generated at 2022-06-23 23:34:08.462858
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys
    buffer = StringIO()
    sys.stderr = buffer
    try:
        # Debug messages should be printed
        with settings.override(debug=True):
            debug(lambda: 'test_debug')
        assert 'test_debug' in buffer.getvalue()

        # Debug messages should not be printed
        buffer.truncate(0)
        with settings.override(debug=False):
            debug(lambda: 'test_debug')
        assert 'test_debug' not in buffer.getvalue()

    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-23 23:34:14.280589
# Unit test for function get_source
def test_get_source():
    def one_line_function(x, y, z): pass
    assert get_source(one_line_function) == "pass"

    def one_line_with_padding(x, y, z): pass
    assert get_source(one_line_with_padding) == "pass"

    def multi_line_function(x, y, z):
        body = f'multiplication of {x} and {y} is {x * y}'
        return body

    assert get_source(multi_line_function) == \
        "body = f'multiplication of {x} and {y} is {x * y}'\n" + \
        "return body"

# Generated at 2022-06-23 23:34:17.697347
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]
    m = map(lambda x: x * x, l)
    assert eager(map)(lambda x: x * x, l) == [1, 4, 9]
    assert list(m) == []



# Generated at 2022-06-23 23:34:26.038950
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar(x):
        pass

    def baz(x=2, y=3):
        pass

    def qux():
        with open(__file__) as fd:
            print(fd.read())

    assert get_source(foo) == 'def foo():\n    pass\n'
    assert get_source(bar) == 'def bar(x):\n    pass\n'
    assert get_source(baz) == 'def baz(x=2, y=3):\n    pass\n'
    assert get_source(qux) == 'def qux():\n    with open(__file__) as fd:\n        print(fd.read())\n'



# Generated at 2022-06-23 23:34:31.124597
# Unit test for function debug
def test_debug():
    debug_flag = False

    def get_message():
        nonlocal debug_flag
        debug_flag = True
        return 'some message'

    debug(get_message)
    assert debug_flag

    settings.debug = True
    debug_flag = False
    debug(get_message)
    assert debug_flag



# Generated at 2022-06-23 23:34:34.984296
# Unit test for function debug
def test_debug():
    debug_logs = []
    def _print(*args, **kwargs):
        debug_logs.append(args)
    sys.stderr.write = _print
    def get_message():
        return 'Test message'
    debug(get_message)
    assert debug_logs == [('[DEBUG] Test message\n',)]
    debug_logs.clear()
    settings.debug = False
    debug(get_message)
    assert debug_logs == []

# Generated at 2022-06-23 23:34:40.666619
# Unit test for function warn
def test_warn():
    import tempfile
    with tempfile.TemporaryFile() as tmp:
        _stdout = sys.stdout
        sys.stdout = sys.stderr = tmp
        try:
            warn('test')
            tmp.seek(0)
            tmp.readline()
        finally:
            sys.stdout, sys.stderr = _stdout, _stdout



# Generated at 2022-06-23 23:34:45.523872
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    first_variable = VariablesGenerator.generate('first_variable')
    first_variable_again = VariablesGenerator.generate('first_variable')
    second_variable = VariablesGenerator.generate('second_variable')
    assert first_variable != first_variable_again
    assert first_variable != second_variable

# Generated at 2022-06-23 23:34:46.672683
# Unit test for function warn
def test_warn():
    warn("hello!")



# Generated at 2022-06-23 23:34:49.719719
# Unit test for function warn
def test_warn():
    f = io.StringIO()
    with redirect_stderr(f):
        warn("Hello world!")

    output = f.getvalue()
    assert "Hello world!" in output



# Generated at 2022-06-23 23:34:51.787070
# Unit test for function eager
def test_eager():
    @eager
    def test_fn(int_list: List[int]) -> List[int]:
        yield from int_list

    assert test_fn([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 23:34:53.680524
# Unit test for function warn
def test_warn():
    assert messages.warn('test') == '\x1b[1m\x1b[31mWarning:\x1b[0m test'


# Generated at 2022-06-23 23:34:56.002584
# Unit test for function warn
def test_warn():
    from . import mock
    mock.Mock.register()

    warn('Warning')
    assert mock.Mock.get_output().strip() == messages.warn('Warning')



# Generated at 2022-06-23 23:35:05.875062
# Unit test for function get_source
def test_get_source():
    def fun1(a, b=2, *c, d=3, **kwargs):
        return a + b + d
    # source_lines = getsource(fun1).split('\n')
    # padding = len(re.findall(r'^\s*', source_lines[0])[0])
    # print(padding)
    # print(source_lines)
    # print('\n'.join(line[padding:] for line in source_lines))
    # print(get_source(fun1))
    assert get_source(fun1) == 'def fun1(a, b=2, *c, d=3, **kwargs):\n    return a + b + d'

test_get_source()

# Generated at 2022-06-23 23:35:09.801658
# Unit test for function warn
def test_warn():
    from unittest import mock
    import sys
    stderr = sys.stderr
    sys.stderr = mock.Mock()
    warn('message')
    sys.stderr.assert_called_with(messages.warn('message'))
    sys.stderr = stderr


# Generated at 2022-06-23 23:35:13.058533
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    cond1 = VariablesGenerator.generate('x')
    cond2 = VariablesGenerator.generate('x')
    assert cond1 != cond2, 'failed to generate unique names'
    assert cond1 == '_py_backwards_x_0'
    assert cond2 == '_py_backwards_x_1'

# Generated at 2022-06-23 23:35:14.469184
# Unit test for function eager
def test_eager():
    # type: () -> None
    assert eager(lambda: (yield 1))() == [1]

# Generated at 2022-06-23 23:35:19.225018
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("variable") == '_py_backwards_variable_0'
    assert VariablesGenerator.generate("variable") == '_py_backwards_variable_1'
    assert VariablesGenerator.generate("variable") == '_py_backwards_variable_2'


# Generated at 2022-06-23 23:35:23.486209
# Unit test for function warn
def test_warn():
    from io import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        warn("This is a warning")
        assert "This is a warning" in sys.stderr.getvalue()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-23 23:35:24.837947
# Unit test for function eager
def test_eager():
    assert eager(list)(range(10)) == list(range(10))

# Generated at 2022-06-23 23:35:28.193500
# Unit test for function eager
def test_eager():
    @eager
    def get_numbers(n: int=1) -> Iterable[int]:
        for i in range(n):
            yield i * i

    assert(get_numbers(10) == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81])
    assert(get_numbers(0) == [])
    assert(get_numbers() == [0])

# Generated at 2022-06-23 23:35:29.526597
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    print(VariablesGenerator.generate('a'))
    assert VariablesGenerator.generate('a') != VariablesGenerator.generate('a')


# Generated at 2022-06-23 23:35:32.301568
# Unit test for function eager
def test_eager():
    @eager
    def return_me_a_generator(*args):
        for i in range(*args):
            yield i

    assert return_me_a_generator(1, 5) == [1, 2, 3, 4]

# Generated at 2022-06-23 23:35:42.138683
# Unit test for function debug
def test_debug():
    import sys
    import unittest
    import unittest.mock
    from unittest.mock import MagicMock

    class MockFile(MagicMock):
        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    class TestDebug(unittest.TestCase):

        @staticmethod
        def test_debug_disabled():
            with unittest.mock.patch('builtins.print', side_effect=lambda s, file=None: s), \
                    unittest.mock.patch('backwards.utils.settings', debug=False):
                debug(lambda: 'Hello')

            print.assert_not_called()


# Generated at 2022-06-23 23:35:47.606527
# Unit test for function get_source
def test_get_source():
    def decorator(fn):
        def wrapped(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapped
    def test():
        def nested():
            pass
    assert get_source(test) == 'def nested():\n    pass\n'
    assert get_source(decorator(test)) == 'def nested():\n    pass\n'

# Generated at 2022-06-23 23:35:49.958531
# Unit test for function get_source
def test_get_source():
    def fn(x: int) -> str:
        return str(x)
    assert get_source(fn) == 'return str(x)'

# Generated at 2022-06-23 23:35:53.297850
# Unit test for function warn
def test_warn():
    def test_warn_output(capsys):
        warn('test')
        captured = capsys.readouterr()
        assert captured.err == messages.warn('test') + '\n'

    test_warn_output(capsys)

# Generated at 2022-06-23 23:35:55.906534
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'



# Generated at 2022-06-23 23:36:00.802822
# Unit test for function warn
def test_warn():
    from io import StringIO
    import sys
    import pytest

    @pytest.yield_fixture
    def capture():
        old_stdout = sys.stdout
        capturer = StringIO()
        try:
            sys.stdout = capturer
            yield capturer
        finally:
            sys.stdout = old_stdout

    with capture() as capturer:
        warn('test')

    assert capturer.getvalue() == messages.warn('test') + '\n'

# Generated at 2022-06-23 23:36:03.930668
# Unit test for function eager
def test_eager():
    def fn(x: int) -> Iterable[int]:
        return (x for _ in range(x))
    assert eager(fn)(3) == [3, 3, 3]

# Generated at 2022-06-23 23:36:07.239617
# Unit test for function eager
def test_eager():
    @eager
    def lazy() -> List[int]:
        return range(10)
    assert lazy() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:36:12.574390
# Unit test for function get_source
def test_get_source():
    assert get_source(test_get_source) == '    assert get_source(test_get_source) == """\n        assert get_source(test_get_source) == """\\\n"""\\\n    assert get_source(test_get_source) == """\n        assert get_source(test_get_source) == """\\\n"""\n    """\n    """\n'

# Generated at 2022-06-23 23:36:20.402399
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        from io import StringIO

        message = StringIO()

        class RedirectStdout:
            def __enter__(self) -> None:
                self.stdout = sys.stdout
                sys.stdout = message

            def __exit__(self, *args: Any) -> None:
                sys.stdout = self.stdout

        with RedirectStdout():
            debug(lambda: 'Hello')

        assert message.getvalue() == 'py_backwards.messages.debug(\'Hello\')\n'
    finally:
        settings.debug = False


# Generated at 2022-06-23 23:36:24.395541
# Unit test for function eager
def test_eager():
    @eager
    def test() -> Iterable[int]:
        for i in range(3):
            yield i

    values = test()

    assert len(values) == 3
    assert values == [0, 1, 2]

# Generated at 2022-06-23 23:36:28.654403
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    gen = VariablesGenerator()
    assert gen.generate('_py_backwards_') == '_py_backwards__py_backwards_0_0'
    assert gen.generate('_py_backwards_') == '_py_backwards__py_backwards_1_0'

# Generated at 2022-06-23 23:36:32.418491
# Unit test for function get_source
def test_get_source():
    def xpto(y):
        if True:
            x = False
            return x

# Generated at 2022-06-23 23:36:36.024523
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variable = 'var'

    for i in range(1, 10000):
        assert VariablesGenerator.generate(variable) == \
               '_py_backwards_{}_{}'.format(variable, i)



# Generated at 2022-06-23 23:36:38.710765
# Unit test for function eager
def test_eager():
    @eager
    def foo(a):
        for i in range(a):
            yield i
    assert foo(3) == [0, 1, 2]

# Generated at 2022-06-23 23:36:41.480818
# Unit test for function get_source
def test_get_source():
    def func(a, b):
        return a + b
    assert get_source(func) == dedent("""
        def func(a, b):
            return a + b
    """)



# Generated at 2022-06-23 23:36:42.289425
# Unit test for function debug
def test_debug():
    debug(lambda: 'debugging')


# Generated at 2022-06-23 23:36:46.498429
# Unit test for function get_source
def test_get_source():
    def some_function():
        pass
    assert get_source(some_function) == 'pass'

    def another_function():
        if True:
            pass
    assert get_source(another_function).split('\n')[1] == 'if True:'

# Generated at 2022-06-23 23:36:49.076513
# Unit test for function warn
def test_warn():
    with capture_output() as (out, _):
        warn("Testing warn")
    expected = "Warning: Testing warn\n"
    assert out.getvalue() == expected


# Generated at 2022-06-23 23:36:50.025145
# Unit test for function warn
def test_warn():
    assert warn("no_warn")

# Generated at 2022-06-23 23:36:54.747722
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest.mock import patch

    try:
        from unittest.mock import mock_open
    except ImportError:
        from mock import mock_open

    message = 'Hello world!'

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        warn(message)
        assert stderr.getvalue() == messages.warn(message) + '\n'

# Generated at 2022-06-23 23:36:58.130156
# Unit test for function eager
def test_eager():
    from unittest.mock import create_autospec

    fn = create_autospec(lambda: None, return_value=[1, 2, 3])
    wrapper = eager(fn)
    assert fn.called is False
    assert wrapper() == [1, 2, 3]
    assert fn.called is True



# Generated at 2022-06-23 23:37:08.728979
# Unit test for function get_source

# Generated at 2022-06-23 23:37:12.747870
# Unit test for function warn
def test_warn():
    from mock import patch
    from ..conf import settings
    with patch('sys.stderr') as mock_stderr:
        warn('This is a test')
        assert mock_stderr.write.called_once_with(messages.warn('This is a test').encode('utf-8'))


# Generated at 2022-06-23 23:37:15.487406
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert '_py_backwards_foo_0' == generator.generate('foo')
    assert '_py_backwards_foo_1' == generator.generate('foo')
    assert '_py_backwards_bar_2' == generator.generate('bar')

# Generated at 2022-06-23 23:37:26.235916
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    sys.modules['__main__'].__dict__ = {}
    import py_backwards
    __file__ = '__main__'
    for i in range(3):
        assert py_backwards.VariablesGenerator.generate('i') == '_py_backwards_i_' + str(i), \
               "Error in VariablesGenerator.generate('i')"
    assert py_backwards.VariablesGenerator._counter == 3, \
           "Error in VariablesGenerator._counter"
    for i in range(3):
        assert py_backwards.VariablesGenerator.generate('j') == '_py_backwards_j_' + str(i), \
               "Error in VariablesGenerator.generate('j')"
    assert py_backwards.VariablesGenerator._counter == 6

# Generated at 2022-06-23 23:37:29.835455
# Unit test for function eager
def test_eager():
    assert eager(list)(range(5)) == [0, 1, 2, 3, 4]
    assert eager(set)(range(5)) == [0, 1, 2, 3, 4]
    assert eager(lambda x: x)(range(5)) == [0, 1, 2, 3, 4]


# Generated at 2022-06-23 23:37:30.612217
# Unit test for function warn
def test_warn():
    assert warn('test') is None


# Generated at 2022-06-23 23:37:33.656837
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert(VariablesGenerator().generate('a') == '_py_backwards_a_0')
    assert(VariablesGenerator().generate('a') == '_py_backwards_a_1')
    assert(VariablesGenerator().generate('b') == '_py_backwards_b_2')

# Generated at 2022-06-23 23:37:36.781866
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate("X") == "_py_backwards_X_0"
    assert VariablesGenerator.generate("X") == "_py_backwards_X_1"

# Generated at 2022-06-23 23:37:41.171475
# Unit test for function debug
def test_debug():
    seen_debug_message = False

    def _fake_print(*args, file=sys.stderr, **kwargs) -> None:
        assert kwargs == {}
        assert args == (messages.debug('Message'),)
        nonlocal seen_debug_message
        

# Generated at 2022-06-23 23:37:44.593120
# Unit test for function eager
def test_eager():
    import pytest
    def generator_function():
        yield 1
        yield 2
        yield 4
    assert eager(generator_function)() == [1,2,4]
    with pytest.raises(TypeError):
        eager(lambda: (1,2,4))()

# Generated at 2022-06-23 23:37:47.585539
# Unit test for function get_source
def test_get_source():
    def my_function():
        print('my_function')

    print(get_source(my_function))
    assert get_source(my_function) == 'print(\'my_function\')\n'


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-23 23:37:53.239419
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def foo():
        if True:
            pass

    assert get_source(foo) == 'if True:\n    pass'

    def foo():
        if True:
            pass

    assert get_source(foo) == 'if True:\n    pass'

    def foo():
        if True:
            pass
        else:
            pass

    assert get_source(foo) == 'if True:\n    pass\nelse:\n    pass'

# Generated at 2022-06-23 23:37:54.152279
# Unit test for function warn
def test_warn():
    warn('message')

# Generated at 2022-06-23 23:37:57.843972
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test2') == '_py_backwards_test2_1'
    assert VariablesGenerator.generate('test3') == '_py_backwards_test3_2'



# Generated at 2022-06-23 23:38:00.197266
# Unit test for function eager
def test_eager():
    def func():
        yield 0
        yield 1
        yield 2
    assert eager(func)() == [0, 1, 2]

# Generated at 2022-06-23 23:38:02.496004
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1


    import sys


    print(sys.path)

    assert get_source(foo) == 'return 1'

# Generated at 2022-06-23 23:38:05.487435
# Unit test for function eager
def test_eager():
    from hypothesis import given
    from hypothesis.strategies import lists, integers

    @eager
    def integers_from_generator():
        return (int(x) for x in range(10))

    @given(lists(integers()))
    def test_eager_works(l):
        assert integers_from_generator() == list(range(10))
    test_eager_works()

# Generated at 2022-06-23 23:38:06.849369
# Unit test for function eager
def test_eager():
    from .utils import assert_equal

    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert_equal(gen(), [1, 2, 3])

# Generated at 2022-06-23 23:38:12.145615
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    variable = 'test_variable'
    assert VariablesGenerator.generate(variable) == '_py_backwards_{}_0'.format(variable)
    assert VariablesGenerator.generate(variable) == '_py_backwards_{}_1'.format(variable)
    assert VariablesGenerator.generate(variable) == '_py_backwards_{}_2'.format(variable)


# Generated at 2022-06-23 23:38:16.460314
# Unit test for function warn
def test_warn():
    from io import StringIO
    buffer = StringIO()
    sys.stderr = buffer

    warn("blah")

    assert buffer.getvalue() == '\x1b[33m[PY-BACKWARDS]\x1b[0m \x1b[33mWARNING\x1b[0m: blah\n'
    buffer.close()


# Generated at 2022-06-23 23:38:19.226943
# Unit test for function eager
def test_eager():
    class Test:
        @eager
        def func(self):
            yield 1
            yield 2
            yield 3

    t = Test()
    print(t.func())

# Generated at 2022-06-23 23:38:20.776953
# Unit test for function get_source
def test_get_source():
    assert get_source(map).startswith('def map')

# Generated at 2022-06-23 23:38:25.692587
# Unit test for function debug
def test_debug():
    from .test_utils import capture_stdout

    with capture_stdout() as log:
        debug(lambda: 'Hello, world!')

    assert not log.getvalue()

    settings.debug = True
    with capture_stdout() as log:
        debug(lambda: 'Hello, world!')
    settings.debug = False

    assert 'Hello, world!' in log.getvalue()

# Generated at 2022-06-23 23:38:28.143715
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('foo') != generator.generate('bar') != generator.generate('foo')


# Generated at 2022-06-23 23:38:34.614128
# Unit test for function debug
def test_debug():
    class OutStream:
        def __init__(self):
            self.content = ""

        def write(self, string):
            self.content += string

        def flush(self):
            pass

    outStream = OutStream()
    sys.stderr = outStream

    settings.debug = True
    debug(lambda: "debug message")
    assert outStream.content == "%s\n" % messages.debug("debug message")

    outStream.content = ""
    settings.debug = False
    debug(lambda: "debug message")
    assert outStream.content == ""

# Generated at 2022-06-23 23:38:36.840148
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    firstVariable = VariablesGenerator.generate('x')
    secondVariable = VariablesGenerator.generate('x')
    assert(firstVariable != secondVariable)



# tests for eager decorator

# Generated at 2022-06-23 23:38:39.972174
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'  # first variable test
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'  # second variable test
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'  # next variable test



# Generated at 2022-06-23 23:38:42.137754
# Unit test for function warn
def test_warn():
    warn('testing')
    warn('testing2')
    warn('testing3')


# Generated at 2022-06-23 23:38:44.985243
# Unit test for function eager
def test_eager():
    def my_generator():
        for i in range(10):
            yield i

    assert eager(my_generator)() == list(range(10))



# Generated at 2022-06-23 23:38:52.830441
# Unit test for function debug
def test_debug():
    # Patch sys.stderr
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    def get_message():
        return 'test'

    debug(get_message)
    assert sys.stderr.getvalue() == '\x1b[1m\x1b[4m\x1b[30mDEBUG\x1b[0m: \x1b[35mtest\x1b[0m\n'
    settings.debug = False
    debug(get_message)

    # Restore sys.stderr
    sys.stderr = old_stderr



# Generated at 2022-06-23 23:38:53.688518
# Unit test for function warn
def test_warn():
    warn("test")
    del sys.stderr

# Generated at 2022-06-23 23:38:55.001288
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-23 23:39:00.729063
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('a') == '_py_backwards_a_0'
    assert generator.generate('a') == '_py_backwards_a_1'
    assert generator.generate('b') == '_py_backwards_b_2'
    assert generator.generate('c') == '_py_backwards_c_3'
    assert generator.generate('d') == '_py_backwards_d_4'
    assert generator.generate('a') == '_py_backwards_a_5'
    assert generator.generate('a') == '_py_backwards_a_6'


# Generated at 2022-06-23 23:39:03.710264
# Unit test for function get_source
def test_get_source():
    def test():
        x = 1
        y = 2
        return x + y

    assert get_source(test) == "x = 1\ny = 2\nreturn x + y"

# Generated at 2022-06-23 23:39:09.692163
# Unit test for function warn
def test_warn():
    from contextlib import redirect_stdout
    from io import StringIO

    f = StringIO()
    with redirect_stdout(f):
        warn('test')

    # outputs '\x1b[33mtest\x1b[0m\n'
    assert f.getvalue() == '\x1b[33mtest\x1b[0m\n'



# Generated at 2022-06-23 23:39:16.474502
# Unit test for function debug
def test_debug():
    with mock.patch('sys.stderr') as mock_stderr:
        settings.debug = True
        debug(lambda: 'Example message 1')
        mock_stderr.write.assert_called_with(messages.debug('Example message 1') + '\n')
        mock_stderr.write.reset_mock()
        settings.debug = False
        debug(lambda: 'Example message 2')
        assert not mock_stderr.write.called

# Generated at 2022-06-23 23:39:18.322423
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'


# Generated at 2022-06-23 23:39:21.303919
# Unit test for function eager
def test_eager():
    from backwards import decorators
    def foo(number):
        for i in range(number):
            yield i
    assert decorators.eager(foo)(10) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 23:39:27.939089
# Unit test for function warn
def test_warn():
    stdout_backup = sys.stdout
    stderr_backup = sys.stderr

    sys.stdout = open('/dev/tty', 'w')
    sys.stderr = open('/dev/tty', 'w')

    # None
    warn('None')

    sys.stdout = stdout_backup
    sys.stderr = stderr_backup


if __name__ == '__main__':
    test_warn()

# Generated at 2022-06-23 23:39:29.760593
# Unit test for function eager
def test_eager():
    a = [1, 2, 3]
    gen = (i for i in a)
    assert eager(gen) == a

# Generated at 2022-06-23 23:39:33.927179
# Unit test for function debug
def test_debug():
    called = False
    def get_message():
        nonlocal called
        called = True
        return "Hello"

    debug(get_message)
    assert called == False
    settings.debug = True
    debug(get_message)
    assert called == True


# Generated at 2022-06-23 23:39:36.125011
# Unit test for function eager
def test_eager():
    l = [1, 2, 3]
    @eager
    def gen() -> Iterable[int]:
        yield from l
    assert gen() == l

# Generated at 2022-06-23 23:39:40.631533
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_2'

# Generated at 2022-06-23 23:39:41.556744
# Unit test for function warn
def test_warn():
    assert warn('Test message') == None

# Generated at 2022-06-23 23:39:48.092375
# Unit test for function debug
def test_debug():
    text = []
    settings.debug = True
    try:
        debug(lambda: 'Hello!')
        assert text == []
    finally:
        sys.stderr.write = lambda data: text.append(data)
        sys.stderr.flush = lambda: None
    assert text == ['\r\033[36m[DBG]\033[0m Hello!\n']
    settings.debug = False
    debug(lambda: '!'*1000)
    assert text == ['\r\033[36m[DBG]\033[0m Hello!\n']
    settings.debug = True
    debug(lambda: '!'*1000)

# Generated at 2022-06-23 23:39:49.795072
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: "Test")
    finally:
        settings.debug = False

# Generated at 2022-06-23 23:39:57.787343
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    generator = VariablesGenerator()
    assert generator.generate('name') == '_py_backwards_name_0'
    assert generator.generate('name') == '_py_backwards_name_1'
    assert generator.generate('name') == '_py_backwards_name_2'
    assert generator.generate('name') == '_py_backwards_name_3'
    assert generator.generate('name') == '_py_backwards_name_4'

# Generated at 2022-06-23 23:40:00.962655
# Unit test for function get_source
def test_get_source():
    def foo():
        bar = 1  # this line will be removed
        print('hello backwards')  # as well as this

    assert get_source(foo) == \
"""def foo():
    print('hello backwards')
"""

# Generated at 2022-06-23 23:40:05.121302
# Unit test for function warn
def test_warn():
    message = 'warn'
    old_stderr = sys.stderr
    try:
        from io import StringIO
        sys.stderr = temp = StringIO()
        warn(message)
        assert temp.getvalue()[0 : len(messages.warn(message))] == messages.warn(message)
    finally:
        sys.stderr = old_stderr



# Generated at 2022-06-23 23:40:08.315575
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator().generate('temp') == '_py_backwards_temp_0'
    assert VariablesGenerator().generate('temp') == '_py_backwards_temp_1'


# Generated at 2022-06-23 23:40:15.047951
# Unit test for function get_source
def test_get_source():
    def f():
        print('hehe')

    def g(a):
        print(a)

    def h(a, b):
        if a > b:
            return 'yes'
        else:
            return 'no'

    assert get_source(f) == "print('hehe')"
    assert get_source(g) == "print(a)"
    assert get_source(h).startswith("if a > b:\n    return 'yes'\nelse:")

# Generated at 2022-06-23 23:40:17.517490
# Unit test for function eager
def test_eager():
    def f():
        for x in range(1, 4):
            yield x

    test_value = eager(f)()
    assert test_value == [1, 2, 3]

# Generated at 2022-06-23 23:40:19.675011
# Unit test for function eager
def test_eager():
    import types

    @eager
    def x():
        yield 1
        yield 2

    assert isinstance(x(), types.GeneratorType)
    assert x() == [1, 2]

# Generated at 2022-06-23 23:40:25.046928
# Unit test for function debug
def test_debug():
    captured_args = []
    sys.stderr.write = lambda msg: captured_args.append(msg)
    settings.set('debug', True)
    debug(lambda: 'some message')
    assert captured_args == [messages.debug('some message')]
    settings.set('debug', False)
    captured_args.clear()
    debug(lambda: 'some message')
    assert captured_args == []



# Generated at 2022-06-23 23:40:29.659989
# Unit test for function warn
def test_warn():
    try:
        sys.stderr = open('stderr', 'w')
        warn(messages.creature())
        # In case of to many tests
        # sys.stderr.truncate()
    finally:
        sys.stderr.close()
        sys.stderr = sys.__stderr__



# Generated at 2022-06-23 23:40:36.107808
# Unit test for function debug
def test_debug():
    from io import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        debug(lambda: "bar")
        debug(lambda: "bar")
        assert sys.stderr.getvalue() == "bar\n\n"

        sys.stderr.truncate()
        settings.debug = False
        debug(lambda: "bar")
        assert sys.stderr.getvalue() == ""
    finally:
        sys.stderr = stderr

# Generated at 2022-06-23 23:40:38.308603
# Unit test for function eager
def test_eager():
    @eager
    def times_two(it: Iterable[int]) -> Iterable[int]:
        for n in it:
            yield n * 2

    assert times_two([1, 2, 3]) == [2, 4, 6]

# Generated at 2022-06-23 23:40:42.475971
# Unit test for function get_source
def test_get_source():
    def test_fn():
        return 1

    assert get_source(test_fn) == 'return 1'

    def test_fn_not_full():
        a = 1
        # this is multi-line comment
        # for get_source
        return a

    assert get_source(test_fn_not_full) == 'return a'



# Generated at 2022-06-23 23:40:46.199761
# Unit test for function eager
def test_eager():
    def test_generator():
        yield 1
        yield 2
        yield 3

    assert eager(test_generator)() == [1, 2, 3]


# Unit tests for class VariablesGenerator

# Generated at 2022-06-23 23:40:51.076350
# Unit test for function get_source
def test_get_source():
    """Test for correct stripping of leading whitespace."""
    def function():
        if True:
            # comments
            print('hello')
        count = 1 + 2
        return count
    assert get_source(function) == """
if True:
    # comments
    print('hello')
count = 1 + 2
return count""".strip()

# Generated at 2022-06-23 23:40:56.841619
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    import pytest
    from .variables_generator import VariablesGenerator
    vg1 = VariablesGenerator()
    vg2 = VariablesGenerator()
    assert vg1.generate('a') == '_py_backwards_a_0'
    assert vg2.generate('a') == '_py_backwards_a_1'

test_VariablesGenerator()

# Generated at 2022-06-23 23:41:00.950364
# Unit test for function warn
def test_warn():
    try:
        prefix = '\x1b[1;31;40m'
        suffix = '\x1b[0m'
        print(prefix + 'fuck' + suffix)
        result = sys.stderr.getvalue()
        print(result)
        assert result == 'fuck\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-23 23:41:03.101631
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        for i in range(2):
            yield i

    assert foo() == [0, 1]

# Generated at 2022-06-23 23:41:08.011468
# Unit test for function get_source
def test_get_source():
    def foo(x: int) -> str:
        '''Foo:
    def foo(x: int) -> str:
        ...
    '''
        return 'foo'

    assert get_source(foo) == '''def foo(x: int) -> str:
    'Foo:'
    ...'''

# Generated at 2022-06-23 23:41:16.092870
# Unit test for function debug
def test_debug():
    import io
    import sys
    import traceback
    from contextlib import redirect_stdout
    buffer = io.StringIO()

    with redirect_stdout(buffer):
        debug(lambda: 'a')
        debug(lambda: 'b')
        debug(lambda: 'c')
    std_error = buffer.getvalue()
    assert std_error.find('b') != -1

    try:
        with redirect_stdout(buffer):
            settings.debug = False
            debug(lambda: 'a')
            debug(lambda: 'b')
            debug(lambda: 'c')
    except Exception:
        traceback.print_exc()
    finally:
        settings.debug = True

    assert std_error == buffer.getvalue()



# Generated at 2022-06-23 23:41:20.134189
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('test') == '_py_backwards_test_0'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_1'
    assert VariablesGenerator.generate('test') == '_py_backwards_test_2'


# Generated at 2022-06-23 23:41:22.638989
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('x') == '_py_backwards_x_0'
    assert VariablesGenerator.generate('x') == '_py_backwards_x_1'



# Generated at 2022-06-23 23:41:26.554793
# Unit test for function debug
def test_debug():
    assert settings.debug
    try:
        import sys, io
        captured_out = io.StringIO()
        sys.stdout = captured_out
        debug(lambda: "testing debug function")
        assert captured_out.getvalue().endswith("[debug] testing debug function\n")
    finally:
        sys.stdout = sys.__stdout__

# Generated at 2022-06-23 23:41:30.952299
# Unit test for function get_source
def test_get_source():
    def a():
        def b():
            return 1

        c = 2
        return b() + c

    assert get_source(b) == 'return 1'
    assert get_source(a) == 'def b():\n    return 1\n\nc = 2\nreturn b() + c'
# end

# Generated at 2022-06-23 23:41:32.206787
# Unit test for function eager
def test_eager():
    @eager
    def x():
        yield 1
        yield 2
        yield 3
    assert x() == [1, 2, 3]

# Generated at 2022-06-23 23:41:36.001509
# Unit test for function eager
def test_eager():
    import random
    nums = random.sample(list(range(100)), 10)
    assert eager(lambda: (n%10 for n in nums))() == [n%10 for n in nums]
    assert eager(lambda: [])() == []

# Generated at 2022-06-23 23:41:37.794860
# Unit test for function warn
def test_warn():
    out = io.StringIO()
    with redirect_stderr(out):
        warn("test message")
    assert out.getvalue() == "{}\n".format(messages.warn("test message"))


# Generated at 2022-06-23 23:41:43.247737
# Unit test for constructor of class VariablesGenerator
def test_VariablesGenerator():
    assert VariablesGenerator.generate('a') == '_py_backwards_a_0'
    assert VariablesGenerator.generate('a') == '_py_backwards_a_1'
    assert VariablesGenerator.generate('b') == '_py_backwards_b_2'

# Generated at 2022-06-23 23:41:44.454926
# Unit test for function debug
def test_debug():
    debug(lambda: 'foo')


# Generated at 2022-06-23 23:41:47.555845
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    if get_source(foo) == 'pass\n':
        print('test passed')
    else:
        print('test failed')

# Generated at 2022-06-23 23:41:50.694651
# Unit test for function eager
def test_eager():
    def test_fn():
        for i in range(5):
            yield i

    assert eager(test_fn)() == [0, 1, 2, 3, 4]

# Generated at 2022-06-23 23:41:52.199565
# Unit test for function warn
def test_warn():
    """Unit test for function warn."""
    warn('test')

# Generated at 2022-06-23 23:41:54.281150
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]