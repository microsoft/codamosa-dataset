

# Generated at 2022-06-18 01:03:28.312103
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
        settings.debug = False

    test_debug_helper()

# Generated at 2022-06-18 01:03:30.795854
# Unit test for function get_source
def test_get_source():
    def function():
        pass

    assert get_source(function) == 'def function():\n    pass'

# Generated at 2022-06-18 01:03:32.906683
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:34.742510
# Unit test for function get_source
def test_get_source():
    def foo():
        return 'bar'

    assert get_source(foo) == 'return \'bar\''

# Generated at 2022-06-18 01:03:37.374880
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:38.889763
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:03:48.267801
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_debug_inner():
        with redirect_stderr(StringIO()) as stderr:
            debug(lambda: 'test')
            assert stderr.getvalue() == ''

        with redirect_stderr(StringIO()) as stderr:
            settings.debug = True
            debug(lambda: 'test')
            assert stderr.getvalue() == messages.debug('test') + '\n'
            settings.debug = False

    test_debug_inner()

# Generated at 2022-06-18 01:03:49.806014
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

# Generated at 2022-06-18 01:03:51.421191
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:57.680971
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:01.300671
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:04:06.887075
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')

    assert stderr.getvalue().strip() == '\x1b[2mHello\x1b[0m'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')

    assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:04:09.317531
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:15.971231
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as mock_stderr:
        settings.debug = True
        debug(lambda: 'test')
        mock_stderr.write.assert_called_once_with(messages.debug('test') + '\n')
        settings.debug = False
        debug(lambda: 'test')
        mock_stderr.write.assert_called_once()

# Generated at 2022-06-18 01:04:19.898242
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:23.018664
# Unit test for function eager
def test_eager():
    @eager
    def test_fn(x: int) -> Iterable[int]:
        for i in range(x):
            yield i

    assert test_fn(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-18 01:04:25.736242
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:33.660515
# Unit test for function debug
def test_debug():
    import io
    import sys
    from unittest import TestCase
    from unittest.mock import patch

    class TestDebug(TestCase):
        def test_debug(self):
            with patch('sys.stderr', new=io.StringIO()) as fake_stderr:
                debug(lambda: 'test')
                self.assertEqual(fake_stderr.getvalue(), '')

                settings.debug = True
                debug(lambda: 'test')
                self.assertEqual(fake_stderr.getvalue(), '\x1b[33mtest\x1b[0m\n')

    test_debug = TestDebug()
    test_debug.test_debug()

# Generated at 2022-06-18 01:04:36.021648
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:38.527954
# Unit test for function eager
def test_eager():
    @eager
    def test_function(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert test_function(10) == list(range(10))

# Generated at 2022-06-18 01:04:43.508560
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:45.533574
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:47.480147
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:56.169334
# Unit test for function debug
def test_debug():
    import io
    import sys
    from unittest import TestCase
    from ..conf import settings

    class TestDebug(TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            sys.stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout

        def test_debug(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stdout.getvalue(), messages.debug('test') + '\n')
            settings.debug = False
            debug(lambda: 'test')
            self.assertEqual(sys.stdout.getvalue(), messages.debug('test') + '\n')

    test_debug = TestDebug()
    test_debug.test_debug()

# Generated at 2022-06-18 01:05:00.762591
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:01.394849
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:03.851999
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:05.904555
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:05:08.383738
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:10.469677
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:20.433276
# Unit test for function debug
def test_debug():
    import io
    import sys
    from unittest import TestCase

    class Test(TestCase):
        def test_debug(self):
            stream = io.StringIO()
            sys.stderr = stream
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(stream.getvalue(), '\x1b[34m[DEBUG] test\x1b[0m\n')
            stream.close()

    Test().test_debug()

# Generated at 2022-06-18 01:05:22.084162
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:05:27.474170
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:05:29.808222
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:31.563159
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'



# Generated at 2022-06-18 01:05:33.791581
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:05:40.134544
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:46.389686
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == messages.debug('test') + '\n'



# Generated at 2022-06-18 01:05:48.286972
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:50.430273
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:09.308113
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:11.873488
# Unit test for function eager
def test_eager():
    @eager
    def test_generator():
        yield 1
        yield 2
        yield 3

    assert test_generator() == [1, 2, 3]

# Generated at 2022-06-18 01:06:14.001520
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:16.021747
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:18.528914
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'



# Generated at 2022-06-18 01:06:21.426909
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:23.399126
# Unit test for function eager
def test_eager():
    def test_function():
        yield 1
        yield 2
        yield 3

    assert eager(test_function)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:26.445610
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        pass

    assert get_source(bar) == 'def bar():\n    pass'



# Generated at 2022-06-18 01:06:27.977477
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:06:39.132061
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase
    from unittest.mock import patch

    class TestDebug(TestCase):
        def test_debug_enabled(self):
            with patch('sys.stderr', new=StringIO()) as fake_stderr:
                settings.debug = True
                debug(lambda: 'test message')
                self.assertEqual(fake_stderr.getvalue(), '\x1b[34m[DEBUG] test message\x1b[0m\n')

        def test_debug_disabled(self):
            with patch('sys.stderr', new=StringIO()) as fake_stderr:
                settings.debug = False
                debug(lambda: 'test message')
                self.assertEqual(fake_stderr.getvalue(), '')

    test

# Generated at 2022-06-18 01:07:20.121575
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:22.090601
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'debug message')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:07:27.083024
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:07:30.089043
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:32.085171
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:07:37.306720
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with io.StringIO() as buf, redirect_stderr(buf):
        test_function()
        assert buf.getvalue() == '\x1b[1;30mDEBUG: test\x1b[0m\n'



# Generated at 2022-06-18 01:07:39.638586
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:41.160677
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3
    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:07:44.327414
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:45.944421
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:28.824286
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:31.711698
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:08:33.005287
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'
    debug(get_message)

# Generated at 2022-06-18 01:08:34.886673
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:37.375020
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:08:39.836518
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:42.935727
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:45.216097
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:47.790004
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:49.730283
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:10:24.820299
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:10:30.996099
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
        assert buf.getvalue() == ''

    with StringIO() as buf, redirect_stderr(buf):
        settings.debug = True
        debug(lambda: 'test')
        assert buf.getvalue() == '\x1b[2m\x1b[36mDEBUG: test\x1b[0m\n'
        settings.debug = False



# Generated at 2022-06-18 01:10:32.733390
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:10:35.757140
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:10:36.909407
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'message')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:10:38.160123
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:40.661351
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:10:42.350086
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:44.226864
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass\n'

# Generated at 2022-06-18 01:10:49.561040
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
    settings.debug = False

