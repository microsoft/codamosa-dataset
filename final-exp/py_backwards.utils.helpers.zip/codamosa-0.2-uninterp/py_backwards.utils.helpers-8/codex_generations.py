

# Generated at 2022-06-18 01:03:29.057495
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:03:31.717349
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:34.082619
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:03:36.716773
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:38.564966
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:40.894059
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-18 01:03:49.710342
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[33mtest\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:03:51.616566
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass\n'

# Generated at 2022-06-18 01:03:58.624501
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test():
        settings.debug = True
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test()
    assert f.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    f = io.StringIO()
    with redirect_stderr(f):
        settings.debug = False
        test()
    assert f.getvalue() == ''

# Generated at 2022-06-18 01:04:00.688534
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:04.153070
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:06.348230
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'

    debug(get_message)

# Generated at 2022-06-18 01:04:17.151781
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase

    class TestDebug(TestCase):
        def setUp(self):
            self.output = StringIO()
            sys.stderr = self.output

        def tearDown(self):
            sys.stderr = sys.__stderr__

        def test_debug_enabled(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(self.output.getvalue(), '\x1b[2mtest\x1b[0m\n')

        def test_debug_disabled(self):
            settings.debug = False
            debug(lambda: 'test')
            self.assertEqual(self.output.getvalue(), '')

    test_debug.__test__ = False
    TestDebug().test_debug

# Generated at 2022-06-18 01:04:20.175902
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:04:21.327126
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:24.893409
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:31.078944
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stdout

    def get_message():
        return 'test'

    f = io.StringIO()
    with redirect_stdout(f):
        debug(get_message)
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stdout(f):
        debug(get_message)
    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:33.023768
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:35.411673
# Unit test for function eager
def test_eager():
    def test_function(a, b):
        yield a
        yield b

    assert eager(test_function)(1, 2) == [1, 2]



# Generated at 2022-06-18 01:04:37.507013
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:44.887748
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'Hello')
        assert sys.stderr.getvalue() == messages.debug('Hello') + '\n'
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:04:46.862830
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:53.619450
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    def get_message():
        return 'test'

    # Test debug is not printed when debug is False
    settings.debug = False
    sys.stderr = StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == ''

    # Test debug is printed when debug is True
    settings.debug = True
    sys.stderr = StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == '\033[1;30m[DEBUG] test\033[0m\n'

# Generated at 2022-06-18 01:04:55.451413
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:57.198064
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:04:58.544503
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass\n'

# Generated at 2022-06-18 01:05:03.670247
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def baz():
            pass

    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

# Generated at 2022-06-18 01:05:05.310917
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:07.500108
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass

    assert get_source(test_func) == 'def test_func():\n    pass'

# Generated at 2022-06-18 01:05:09.453222
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:20.682720
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:22.723975
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:30.328014
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import contextmanager

    @contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    def get_message():
        return 'test'

    with capture_stderr() as stderr:
        debug(get_message)
        assert stderr.getvalue() == ''

    settings.debug = True
    with capture_stderr() as stderr:
        debug(get_message)
        assert stderr.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:05:37.061898
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def baz():
            pass
    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

    def qux():
        def quux():
            def corge():
                pass
    assert get_source(qux) == 'def qux():\n    def quux():\n        def corge():\n            pass'

# Generated at 2022-06-18 01:05:38.773709
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'



# Generated at 2022-06-18 01:05:47.969042
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings

    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:49.727244
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:51.743251
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:53.732587
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:55.884201
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:17.693150
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:06:20.395626
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:22.040916
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:06:24.024975
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:25.695305
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass\n'

# Generated at 2022-06-18 01:06:31.027923
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:39.681734
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == '\x1b[2m\x1b[1mDEBUG:\x1b[0m test\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:41.734954
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:44.303838
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:46.273049
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:08.069141
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:10.193535
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:12.276874
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:15.284923
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:17.638447
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:07:19.648840
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:21.670787
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:07:23.541295
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:25.290490
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:07:26.575070
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:09.918401
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:12.087687
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:14.095535
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:08:16.435502
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:19.119206
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:23.926215
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True

    def get_message():
        return 'test'

    with io.StringIO() as buf, redirect_stdout(buf):
        debug(get_message)
        assert buf.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    settings.debug = False



# Generated at 2022-06-18 01:08:24.697444
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:26.408835
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:32.886059
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_inner():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        return f.getvalue()

    assert test_debug_inner() == ''

    settings.debug = True
    assert test_debug_inner() == messages.debug('test') + '\n'
    settings.debug = False

# Generated at 2022-06-18 01:08:34.757508
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:07.650961
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def bar():
        if True:
            pass

    assert get_source(bar) == 'if True:\n    pass'

    def baz():
        if True:
            pass
        else:
            pass

    assert get_source(baz) == 'if True:\n    pass\nelse:\n    pass'

# Generated at 2022-06-18 01:10:10.031313
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:10:12.723732
# Unit test for function debug
def test_debug():
    def get_message():
        return 'message'

    with patch('sys.stderr') as stderr:
        debug(get_message)
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == messages.debug(get_message())



# Generated at 2022-06-18 01:10:15.166357
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:10:17.141908
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:19.190806
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:24.777363
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test():
        settings.debug = True
        debug(lambda: 'test')
        settings.debug = False
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test()
    assert f.getvalue() == messages.debug('test') + '\n'



# Generated at 2022-06-18 01:10:26.978717
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:28.841735
# Unit test for function get_source
def test_get_source():
    def foo(a, b, c):
        return a + b + c

    assert get_source(foo) == 'return a + b + c'

# Generated at 2022-06-18 01:10:36.474694
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[2mDEBUG: test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:12:18.426976
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:12:24.830975
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')
        assert stderr.getvalue().strip() == '\x1b[33m[DEBUG]\x1b[0m Hello'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')
        assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:12:29.824297
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:31.687557
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:33.100063
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:34.624689
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:12:44.239907
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stderr = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.stderr

        def test_debug(self):
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '')
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '\x1b[34mtest\x1b[0m\n')
            settings.debug = False

    unittest.main()

# Generated at 2022-06-18 01:12:45.913152
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i

    assert gen(3) == [0, 1, 2]

# Generated at 2022-06-18 01:12:49.638616
# Unit test for function debug
def test_debug():
    from . import messages
    from .conf import settings
    from io import StringIO
    from contextlib import redirect_stderr

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:12:54.323736
# Unit test for function debug
def test_debug():
    import io
    import sys

    def get_message():
        return 'test'

    settings.debug = True
    sys.stderr = io.StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == '\x1b[1m\x1b[36m[py_backwards]\x1b[0m test\n'

    settings.debug = False
    sys.stderr = io.StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == ''