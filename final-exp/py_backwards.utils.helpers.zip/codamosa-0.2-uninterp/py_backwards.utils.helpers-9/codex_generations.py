

# Generated at 2022-06-18 01:03:32.471677
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:03:34.617589
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:36.926909
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass\n'

# Generated at 2022-06-18 01:03:38.455269
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:42.308266
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
    assert buf.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
    assert buf.getvalue() == ''

# Generated at 2022-06-18 01:03:46.139693
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:47.924017
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:03:50.165464
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:52.663010
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:55.387166
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:04.107033
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def get_message():
        return 'foo'

    f = io.StringIO()
    with redirect_stderr(f):
        debug(get_message)
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(get_message)
    assert f.getvalue() == '\x1b[1m\x1b[33m[DEBUG] foo\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:06.814250
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:09.270669
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:12.420080
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:14.520209
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:04:16.342689
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:20.032215
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:04:21.368942
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'

# Generated at 2022-06-18 01:04:29.924753
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[1m\x1b[34mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:31.911170
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    debug(lambda: 'foo')

# Generated at 2022-06-18 01:04:35.511881
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:04:37.629954
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:39.458577
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:41.252493
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:04:42.830084
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:04:44.887883
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:46.493355
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:04:48.421140
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:04:50.423782
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:04:51.963184
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:59.339841
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:05:03.343832
# Unit test for function eager
def test_eager():
    def foo(x):
        yield x
        yield x + 1
        yield x + 2

    assert eager(foo)(1) == [1, 2, 3]

# Generated at 2022-06-18 01:05:04.986850
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:06.630942
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:10.418871
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    stderr = io.StringIO()
    with redirect_stderr(stderr):
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

    settings.debug = True
    stderr = io.StringIO()
    with redirect_stderr(stderr):
        debug(lambda: 'test')
    assert stderr.getvalue() == '\x1b[1;30m[DEBUG] test\x1b[0m\n'
    settings.debug = False



# Generated at 2022-06-18 01:05:17.242594
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def get_message():
        return 'test message'

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(get_message)
        assert stderr.getvalue() == '\x1b[1;30m[DEBUG] test message\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:05:23.207596
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[2mtest\x1b[0m\n'
    settings.debug = False



# Generated at 2022-06-18 01:05:24.293302
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:05:28.877782
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:31.658188
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:35.766880
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:38.728375
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'

    def g():
        def h():
            pass

    assert get_source(g) == 'def h():\n    pass'

# Generated at 2022-06-18 01:05:41.141493
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:44.068149
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:50.130009
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')
        assert buffer.getvalue() == ''

    with StringIO() as buffer, redirect_stderr(buffer):
        settings.debug = True
        debug(lambda: 'test')
        assert buffer.getvalue() == messages.debug('test') + '\n'
        settings.debug = False



# Generated at 2022-06-18 01:05:55.681354
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == '\x1b[33m[DEBUG] test\x1b[0m'
    settings.debug = False

# Generated at 2022-06-18 01:05:57.434295
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:59.505512
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:01.797226
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:04.088840
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:15.089190
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[36mDEBUG: test message\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:06:22.450898
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'foo')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'foo')
    assert f.getvalue() == '\x1b[34m[DEBUG] foo\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:24.403166
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:26.403351
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:28.264941
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:30.391691
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:37.112804
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'debug message')
    assert stderr.getvalue() == messages.debug('debug message') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'debug message')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:41.070335
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'message')
        mock_stderr.write.assert_called_once_with('\x1b[33mmessage\x1b[0m\n')



# Generated at 2022-06-18 01:06:44.109187
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:46.110284
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')



# Generated at 2022-06-18 01:06:51.639380
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:53.448752
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:55.455027
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:57.192036
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:58.450775
# Unit test for function eager
def test_eager():
    @eager
    def test():
        for i in range(10):
            yield i
    assert test() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-18 01:07:00.291740
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:01.749253
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:12.059496
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import contextmanager
    from ..conf import settings
    from ..utils import debug

    @contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        stderr = io.StringIO()
        sys.stderr = stderr
        try:
            yield stderr
        finally:
            sys.stderr = old_stderr

    def test_debug_disabled():
        with capture_stderr() as stderr:
            debug(lambda: 'debug message')
        assert stderr.getvalue() == ''

    def test_debug_enabled():
        settings.debug = True
        with capture_stderr() as stderr:
            debug(lambda: 'debug message')
        assert stderr.getvalue

# Generated at 2022-06-18 01:07:14.988901
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:17.037418
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:23.079151
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:25.822737
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:28.000045
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:30.440022
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:07:32.310286
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:38.746207
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'debug message')
    assert stderr.getvalue().strip() == messages.debug('debug message')

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'debug message')
    assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:07:41.014204
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:44.148273
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:07:46.148088
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:51.283216
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:58.821374
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:01.142655
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:08:08.047055
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[2m\x1b[1mDEBUG\x1b[0m: test\n'

    settings.debug = False

# Generated at 2022-06-18 01:08:10.136858
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:17.101134
# Unit test for function debug
def test_debug():
    import io
    import sys

    def get_message():
        return 'message'

    settings.debug = True
    sys.stderr = io.StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == messages.debug(get_message()) + '\n'

    settings.debug = False
    sys.stderr = io.StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == ''



# Generated at 2022-06-18 01:08:17.942503
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:20.015884
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:21.781922
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'Hello')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:08:23.922737
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:08:25.719342
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:08:37.933435
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:40.325421
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:42.976257
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:46.303611
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:47.816700
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:50.142657
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:56.939116
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[1;33m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:08:58.845736
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:09:02.407813
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:09:03.352260
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:20.646779
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:09:24.027486
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:09:26.091360
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:09:28.029732
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:09:29.589741
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:09:35.880030
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == ''

# Generated at 2022-06-18 01:09:42.251160
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[2m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:09:43.949836
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:46.317723
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:53.285613
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[2m\x1b[36mDEBUG: test\x1b[0m\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''



# Generated at 2022-06-18 01:10:19.977136
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:21.729766
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:31.644117
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.old_stdout = sys.stdout
            self.old_debug = settings.debug
            self.stdout = io.StringIO()
            sys.stdout = self.stdout

        def tearDown(self):
            sys.stdout = self.old_stdout
            settings.debug = self.old_debug

        def test_debug_enabled(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(self.stdout.getvalue(), messages.debug('test') + '\n')

        def test_debug_disabled(self):
            settings.debug = False
            debug(lambda: 'test')

# Generated at 2022-06-18 01:10:33.104462
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:10:36.109699
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:10:37.552815
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:40.297830
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:42.353259
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:43.835228
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:45.136757
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:15.445887
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == messages.debug('test') + '\n'
    finally:
        settings.debug = False
        sys.stderr = sys.__stderr__



# Generated at 2022-06-18 01:11:16.689656
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:18.430536
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:11:22.241324
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:11:24.504253
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:11:30.750440
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
        settings.debug = False

    test_debug_helper()

# Generated at 2022-06-18 01:11:34.568253
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr', new=open('/dev/null', 'w')):
        settings.debug = True
        debug(lambda: 'test')
        settings.debug = False
        debug(lambda: 'test')

# Generated at 2022-06-18 01:11:40.240814
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')

    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')

    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False



# Generated at 2022-06-18 01:11:42.021619
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:11:43.588541
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:37.420424
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:39.672276
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:12:42.687848
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-18 01:12:44.513728
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:12:46.223170
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:12:47.917767
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:53.982531
# Unit test for function debug
def test_debug():
    import sys
    import io
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout
            sys.stderr = self.stderr

        def test_debug_enabled(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '\x1b[34mDEBUG: test\x1b[0m\n')

        def test_debug_disabled(self):
            settings.debug = False


# Generated at 2022-06-18 01:12:55.457744
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:12:56.735771
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:12:59.834817
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]