

# Generated at 2022-06-18 01:03:34.407063
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'pass'

    def g():
        if True:
            pass
    assert get_source(g) == 'if True:\n    pass'

    def h():
        if True:
            pass
        else:
            pass
    assert get_source(h) == 'if True:\n    pass\nelse:\n    pass'

# Generated at 2022-06-18 01:03:37.048692
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:03:38.606267
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in range(3)))() == [0, 1, 2]

# Generated at 2022-06-18 01:03:42.138252
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:03:46.547127
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:03:48.802505
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:55.546114
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:03:57.827863
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:04.674670
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[1m\x1b[34m[DEBUG]\x1b[0m test\n'

    settings.debug = False

# Generated at 2022-06-18 01:04:07.175550
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:18.429843
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings

    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
    assert mock_stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
    assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:20.554107
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:22.231798
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:25.319511
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-18 01:04:26.652300
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:32.327179
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'



# Generated at 2022-06-18 01:04:34.204556
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:36.547839
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')

    assert 'Hello' in stderr.getvalue()

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')

    assert 'Hello' not in stderr.getvalue()

# Generated at 2022-06-18 01:04:38.409407
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:39.875596
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:49.851191
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''
    settings.debug = True
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[33mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:51.384556
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:53.222376
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:56.360133
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        debug(lambda: 'test')
        stderr.write.assert_called_once_with(messages.debug('test') + '\n')

# Generated at 2022-06-18 01:04:58.041858
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:59.588146
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:00.764268
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:05:04.026597
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'
    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:05.016037
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:11.596204
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    import sys
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'
    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:27.711111
# Unit test for function debug
def test_debug():
    import io
    import sys

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio
            sys.stdout = self._stdout

    with Capturing() as output:
        debug(lambda: 'foo')
        debug(lambda: 'bar')

    assert output == []

    with Capturing() as output:
        settings.debug = True
        debug(lambda: 'foo')
        debug(lambda: 'bar')

    assert output == ['[DEBUG] foo', '[DEBUG] bar']

# Generated at 2022-06-18 01:05:35.760032
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:05:37.993550
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:39.573960
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:41.766932
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:49.840373
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    import sys

    def test_function():
        debug(lambda: 'test message')

    saved_stderr = sys.stderr
    try:
        out = StringIO()
        with redirect_stderr(out):
            test_function()
        output = out.getvalue().strip()
    finally:
        sys.stderr = saved_stderr

    assert output == '\x1b[36mDEBUG: test message\x1b[0m'

# Generated at 2022-06-18 01:05:51.882567
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:58.647149
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')
        assert buffer.getvalue() == ''

    with StringIO() as buffer, redirect_stderr(buffer):
        settings.debug = True
        debug(lambda: 'test')
        assert buffer.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
        settings.debug = False



# Generated at 2022-06-18 01:06:01.149893
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:02.697975
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:06:21.561515
# Unit test for function eager
def test_eager():
    @eager
    def test_func():
        yield 1
        yield 2
        yield 3
    assert test_func() == [1, 2, 3]

# Generated at 2022-06-18 01:06:24.570941
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:06:26.570716
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:06:34.791502
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(io.StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(io.StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:06:40.319104
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[2mtest\x1b[0m\n'
    settings.debug = False



# Generated at 2022-06-18 01:06:46.799659
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys
    from ..conf import settings

    settings.debug = True
    try:
        sys.stderr = StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    finally:
        settings.debug = False
        sys.stderr = sys.__stderr__



# Generated at 2022-06-18 01:06:49.429828
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:51.435536
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:54.273889
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:01.361332
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:20.779513
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:07:21.913887
# Unit test for function eager
def test_eager():
    def gen():
        yield 1
        yield 2
        yield 3

    assert eager(gen)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:24.334997
# Unit test for function eager
def test_eager():
    @eager
    def get_numbers() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert get_numbers() == [1, 2, 3]



# Generated at 2022-06-18 01:07:26.142498
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:07:28.165533
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:35.956666
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[38;5;8m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:07:38.102612
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:39.777273
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:07:47.653210
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[2mtest message\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:07:50.240491
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True

    def get_message():
        return 'message'

    with io.StringIO() as buf, redirect_stdout(buf):
        debug(get_message)
        assert buf.getvalue() == messages.debug(get_message()) + '\n'

    settings.debug = False



# Generated at 2022-06-18 01:08:13.024981
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:14.606146
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:17.182950
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-18 01:08:18.272418
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:08:20.281078
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:08:21.998448
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:24.129726
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:08:25.608822
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:36.231904
# Unit test for function debug
def test_debug():
    import io
    import sys

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout

    with Capturing() as output:
        debug(lambda: 'test')
        assert not output

    with Capturing() as output:
        settings.debug = True
        debug(lambda: 'test')
        assert output == ['[DEBUG] test']
        settings.debug = False



# Generated at 2022-06-18 01:08:38.299611
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:09:03.296697
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    pass'

# Generated at 2022-06-18 01:09:07.309165
# Unit test for function debug
def test_debug():
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    try:
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 01:09:08.769139
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:10.422191
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:18.090396
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == 'test\n'
        settings.debug = False

    test_debug_helper()

# Generated at 2022-06-18 01:09:19.762579
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:22.289989
# Unit test for function eager
def test_eager():
    def generator():
        yield 1
        yield 2
        yield 3
    assert eager(generator)() == [1, 2, 3]

# Generated at 2022-06-18 01:09:28.915340
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:09:31.801301
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:09:33.230615
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:10:24.283442
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:10:26.820100
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:28.696468
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:10:30.384079
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:10:32.311395
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')



# Generated at 2022-06-18 01:10:35.085139
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:36.509500
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-18 01:10:41.210053
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:10:43.082029
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:44.912254
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:11:36.732062
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        for i in range(10):
            yield i

    assert test_fn() == list(range(10))

# Generated at 2022-06-18 01:11:38.620377
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:11:41.302460
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:11:47.133526
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        return f.getvalue()

    assert test_debug_helper() == ''

    settings.debug = True
    assert test_debug_helper() == messages.debug('test') + '\n'
    settings.debug = False

# Generated at 2022-06-18 01:11:49.326812
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:11:55.345104
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'



# Generated at 2022-06-18 01:11:56.902932
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:58.536828
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:12:01.597870
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:04.521120
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''