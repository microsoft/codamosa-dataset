

# Generated at 2022-06-18 01:03:27.606100
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:29.467075
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:32.153400
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-18 01:03:34.287850
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:40.263417
# Unit test for function debug
def test_debug():
    from ..conf import settings
    from io import StringIO
    import sys
    settings.debug = True
    sys.stderr = StringIO()
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == '\x1b[36m[DEBUG] test\x1b[0m\n'
    settings.debug = False
    sys.stderr = StringIO()
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == ''

# Generated at 2022-06-18 01:03:42.747044
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:46.547387
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:03:54.987917
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout
            sys.stderr = self.stderr

        def test_debug_enabled(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '\x1b[34mDEBUG: test\x1b[0m\n')

        def test_debug_disabled(self):
            settings.debug = False


# Generated at 2022-06-18 01:03:59.455701
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.write.called
        assert mock_stderr.write.call_args[0][0] == messages.debug('test')



# Generated at 2022-06-18 01:04:01.040981
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:12.969247
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'foo')
        assert fake_stderr.getvalue() == ''
        settings.debug = True
        debug(lambda: 'foo')
        assert fake_stderr.getvalue() == '\x1b[33m[DEBUG] foo\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:04:14.969528
# Unit test for function eager
def test_eager():
    @eager
    def test_func():
        yield 1
        yield 2
        yield 3
    assert test_func() == [1, 2, 3]

# Generated at 2022-06-18 01:04:18.453417
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:24.316419
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == ''

# Generated at 2022-06-18 01:04:25.605760
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:04:27.550758
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:33.346806
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert 'test' in stderr.getvalue()

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:04:35.411864
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:38.819061
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        if True:
            pass

    assert get_source(bar) == 'def bar():\n    if True:\n        pass'

# Generated at 2022-06-18 01:04:40.631916
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:04:47.094374
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:49.098809
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:50.713056
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:04:52.241545
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:57.786379
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[2mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:59.106390
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:09.046044
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_inner():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[2m\x1b[1m\x1b[34mDEBUG: test\x1b[0m\n'
        settings.debug = False

    test_debug_inner()



# Generated at 2022-06-18 01:05:11.179094
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:05:13.067107
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:14.248103
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:05:22.212913
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def baz():
            pass

    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

# Generated at 2022-06-18 01:05:28.081130
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_debug_function():
        with redirect_stderr(StringIO()) as f:
            debug(lambda: 'test')
            assert f.getvalue() == ''

        with redirect_stderr(StringIO()) as f:
            settings.debug = True
            debug(lambda: 'test')
            assert f.getvalue() == '\x1b[33mDEBUG: test\x1b[0m\n'
            settings.debug = False

    test_debug_function()

# Generated at 2022-06-18 01:05:30.849021
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:37.953365
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    def get_message():
        return 'test'

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)
        assert stderr.getvalue() == messages.debug(get_message())

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:44.973827
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager
    from ..conf import settings

    @contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    def test_debug_enabled():
        with capture_stderr() as stderr:
            debug(lambda: 'test')
            assert stderr.getvalue() == messages.debug('test') + '\n'

    def test_debug_disabled():
        with capture_stderr() as stderr:
            settings.debug = False
            debug(lambda: 'test')
            assert stderr.getvalue() == ''

    test_debug_

# Generated at 2022-06-18 01:05:47.066163
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:48.884048
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:51.068934
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:57.311105
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'
        settings.debug = False

# Generated at 2022-06-18 01:06:02.500713
# Unit test for function debug
def test_debug():
    import io
    import sys

    def get_message():
        return 'message'

    # Test debug off
    settings.debug = False
    sys.stderr = io.StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == ''

    # Test debug on
    settings.debug = True
    sys.stderr = io.StringIO()
    debug(get_message)
    assert sys.stderr.getvalue() == messages.debug('message') + '\n'



# Generated at 2022-06-18 01:06:14.088001
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:16.112051
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:06:18.337894
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')
    settings.debug = True
    debug(lambda: 'test')



# Generated at 2022-06-18 01:06:21.067767
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:22.689437
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:24.618900
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:06:26.270639
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:28.136687
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:29.993363
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:31.134496
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'

# Generated at 2022-06-18 01:06:49.436822
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[33mDEBUG: test message\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:06:51.431717
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'Hello')
    settings.debug = False
    debug(lambda: 'Hello')

# Generated at 2022-06-18 01:06:53.256039
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:00.415571
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue().strip() == 'DEBUG: test'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert not stderr.getvalue()

# Generated at 2022-06-18 01:07:01.210167
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:02.654313
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:05.716308
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:11.796673
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:07:19.485608
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_inner():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
            assert f.getvalue() == ''
            settings.debug = True
            debug(lambda: 'test')
            assert f.getvalue() == '\x1b[33mDEBUG: test\x1b[0m\n'
            settings.debug = False
        f.close()

    test_debug_inner()

# Generated at 2022-06-18 01:07:21.124220
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:42.910257
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:07:45.600102
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:47.094798
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:48.434749
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:49.668976
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:57.658228
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:08:00.818762
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        debug(lambda: 'test')
        assert stderr.write.called



# Generated at 2022-06-18 01:08:08.089257
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[1m\x1b[33m[DEBUG] test\x1b[0m\n'
        settings.debug = False

    test_debug_helper()

# Generated at 2022-06-18 01:08:10.176618
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:12.337237
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:08:34.052883
# Unit test for function get_source
def test_get_source():
    def test_function():
        """
        This is a test function.
        """
        pass


# Generated at 2022-06-18 01:08:41.095686
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
    assert buf.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
    assert buf.getvalue() == ''


# Generated at 2022-06-18 01:08:43.480850
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i
    assert gen(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-18 01:08:46.433173
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:08:48.345558
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:50.626410
# Unit test for function eager
def test_eager():
    def test_fn():
        for i in range(10):
            yield i

    assert eager(test_fn)() == list(test_fn())

# Generated at 2022-06-18 01:08:52.556542
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:09:01.541767
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch
    from ..conf import settings

    settings.debug = True

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'foo')

    assert fake_stderr.getvalue() == '\x1b[2m\x1b[1mfoo\x1b[0m\n'

    settings.debug = False

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'foo')

    assert fake_stderr.getvalue() == ''

# Generated at 2022-06-18 01:09:02.546325
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:04.439365
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:09:51.006353
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert 'test' in stderr.getvalue()

    settings.debug = False

# Generated at 2022-06-18 01:09:56.263847
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper(debug_enabled: bool) -> str:
        with io.StringIO() as f, redirect_stderr(f):
            settings.debug = debug_enabled
            debug(lambda: 'test message')
            return f.getvalue().strip()

    assert test_debug_helper(True) == 'DEBUG: test message'
    assert test_debug_helper(False) == ''

# Generated at 2022-06-18 01:10:03.040641
# Unit test for function debug
def test_debug():
    import io
    import sys

    def test_debug_helper(debug_enabled: bool) -> None:
        settings.debug = debug_enabled
        captured_output = io.StringIO()
        sys.stderr = captured_output
        debug(lambda: 'debug message')
        sys.stderr = sys.__stderr__
        assert captured_output.getvalue() == (
            messages.debug('debug message') + '\n'
        ) if debug_enabled else ''

    test_debug_helper(True)
    test_debug_helper(False)

# Generated at 2022-06-18 01:10:05.409009
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:07.947795
# Unit test for function eager
def test_eager():
    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen(3) == [0, 1, 2]

# Generated at 2022-06-18 01:10:10.554043
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:21.592123
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from unittest import TestCase

    class TestDebug(TestCase):
        def test_debug(self):
            f = io.StringIO()
            with redirect_stderr(f):
                debug(lambda: 'test')
            self.assertEqual(f.getvalue(), '')

            settings.debug = True
            with redirect_stderr(f):
                debug(lambda: 'test')
            self.assertEqual(f.getvalue(), '\x1b[34mDEBUG: test\x1b[0m\n')

            settings.debug = False
            with redirect_stderr(f):
                debug(lambda: 'test')

# Generated at 2022-06-18 01:10:24.462900
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:10:26.898760
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:10:28.447938
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:12:05.980414
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:12:07.968265
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:09.543846
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:11.199189
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:12:12.841923
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:12:15.526971
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'

# Generated at 2022-06-18 01:12:21.194467
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
        assert buf.getvalue() == ''

    with io.StringIO() as buf, redirect_stderr(buf):
        settings.debug = True
        debug(lambda: 'test')
        assert buf.getvalue() == 'DEBUG: test\n'
        settings.debug = False



# Generated at 2022-06-18 01:12:22.375319
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'pass'



# Generated at 2022-06-18 01:12:23.507019
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:12:29.711157
# Unit test for function eager
def test_eager():
    from random import randint
    from time import sleep

    @eager
    def gen():
        for i in range(10):
            sleep(randint(0, 10) / 100)
            yield i

    assert gen() == list(range(10))