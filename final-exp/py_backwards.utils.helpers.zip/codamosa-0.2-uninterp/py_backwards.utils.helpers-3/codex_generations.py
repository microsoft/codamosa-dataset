

# Generated at 2022-06-18 01:03:32.625159
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:34.781344
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:37.417170
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:39.518025
# Unit test for function eager
def test_eager():
    @eager
    def gen() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:03:42.336743
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:03:44.291836
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:47.242641
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:49.566019
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:03:51.502650
# Unit test for function eager
def test_eager():
    @eager
    def get_list():
        yield 1
        yield 2
        yield 3

    assert get_list() == [1, 2, 3]

# Generated at 2022-06-18 01:03:53.953192
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:01.562068
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test():
        settings.debug = True
        debug(lambda: 'test')
        settings.debug = False
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test()
    assert f.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'



# Generated at 2022-06-18 01:04:03.628298
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:04:06.597861
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:04:09.083464
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:11.483686
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:14.353973
# Unit test for function eager
def test_eager():
    def test_function():
        yield 1
        yield 2
        yield 3

    assert eager(test_function)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:16.089761
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:19.209690
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False

# Generated at 2022-06-18 01:04:21.271282
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:26.536249
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as f:
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as f:
        test_function()
    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:35.550523
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from unittest import TestCase

    class Test(TestCase):
        def test_debug(self):
            with redirect_stderr(StringIO()) as stderr:
                debug(lambda: 'test')
                self.assertEqual(stderr.getvalue(), '')

                settings.debug = True
                debug(lambda: 'test')
                self.assertEqual(stderr.getvalue(), '\x1b[33mDEBUG: test\x1b[0m\n')

    Test().test_debug()

# Generated at 2022-06-18 01:04:37.349346
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:04:39.189165
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:40.672769
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:42.480729
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:44.592969
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:46.540470
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:04:47.558344
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-18 01:04:49.235311
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:53.869226
# Unit test for function debug
def test_debug():
    import sys
    import io
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')

    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:05:01.439407
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:02.427212
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:04.163940
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:06.223438
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:08.384087
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:09.335878
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:15.840041
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[36mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:05:23.802073
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from ..conf import settings
    settings.debug = True
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'message')
        mock_stderr.write.assert_called_once_with('\x1b[2mmessage\x1b[0m\n')
        mock_stderr.write.reset_mock()
    settings.debug = False
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'message')
        mock_stderr.write.assert_not_called()

# Generated at 2022-06-18 01:05:25.659009
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:05:30.270762
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:39.977474
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-18 01:05:48.285285
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:57.006283
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[2m\x1b[1m\x1b[34mDEBUG\x1b[0m\x1b[2m: test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:05:59.040123
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:07.219316
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[2m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:09.217930
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:11.429183
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:16.064338
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        out = io.StringIO()
        sys.stderr = out
        debug(lambda: 'test')
        assert out.getvalue() == messages.debug('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False



# Generated at 2022-06-18 01:06:24.205326
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.old_stderr = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.old_stderr

        def test_debug(self):
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '')

            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '\x1b[35mtest\x1b[0m\n')

    unittest.main()

# Generated at 2022-06-18 01:06:26.181663
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:06:48.416577
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:54.368542
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[0;36m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:56.083061
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:59.039499
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:00.612289
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:02.030635
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:07:04.962806
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:11.232925
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'
    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:14.005892
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:16.540541
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:58.696590
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:08.045314
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def get_message():
        return 'test'

    f = io.StringIO()
    with redirect_stderr(f):
        debug(get_message)
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(get_message)

# Generated at 2022-06-18 01:08:10.136879
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:19.029961
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:08:20.870050
# Unit test for function get_source
def test_get_source():
    def fn():
        pass

    assert get_source(fn) == 'def fn():\n    pass'

# Generated at 2022-06-18 01:08:22.610125
# Unit test for function eager
def test_eager():
    assert eager(lambda: (i for i in range(10)))() == list(range(10))

# Generated at 2022-06-18 01:08:24.257083
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:26.016766
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass\n'

# Generated at 2022-06-18 01:08:28.552533
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:08:36.141084
# Unit test for function debug
def test_debug():
    import pytest
    from io import StringIO
    from contextlib import redirect_stderr

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:10:04.614514
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:10:11.067615
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[33mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:10:14.287569
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:16.019366
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:20.068344
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

# Generated at 2022-06-18 01:10:21.896864
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:10:25.664794
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:32.373507
# Unit test for function debug
def test_debug():
    import io
    import sys

    def test_function():
        debug(lambda: 'test message')

    # Capture stderr
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    # Test debug disabled
    settings.debug = False
    test_function()
    assert sys.stderr.getvalue() == ''

    # Test debug enabled
    settings.debug = True
    test_function()
    assert sys.stderr.getvalue() == '\x1b[2m\x1b[36mDEBUG: test message\x1b[0m\n'

    # Restore stderr
    sys.stderr = old_stderr

# Generated at 2022-06-18 01:10:34.709137
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:10:36.554228
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'