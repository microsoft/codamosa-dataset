

# Generated at 2022-06-18 01:03:29.628589
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'



# Generated at 2022-06-18 01:03:37.336261
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:03:39.159113
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:42.237102
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:03:44.290667
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:47.242661
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:48.826925
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:51.830336
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:53.903271
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'

    debug(get_message)

# Generated at 2022-06-18 01:03:56.268790
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:03:59.773671
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:01.697234
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:06.917649
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from . import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:09.362906
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:04:12.917844
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    settings.debug = False
    debug(lambda: 'debug message')

# Generated at 2022-06-18 01:04:18.756292
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def baz():
            pass

    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

    def qux():
        def quux():
            def quuz():
                pass

    assert get_source(qux) == 'def qux():\n    def quux():\n        def quuz():\n            pass'

# Generated at 2022-06-18 01:04:20.505823
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:22.540243
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:25.663973
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:04:31.911295
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_debug_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_debug_function()
        assert stderr.getvalue() == messages.debug('test') + '\n'
    settings.debug = False

# Generated at 2022-06-18 01:04:36.358568
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:41.796949
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:04:43.733268
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:45.153799
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:04:47.094742
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:04:48.773388
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:50.422389
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:04:51.963546
# Unit test for function get_source
def test_get_source():
    def foo(a, b):
        return a + b

    assert get_source(foo) == 'return a + b'

# Generated at 2022-06-18 01:04:53.870821
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:55.695182
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:59.253388
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:02.854149
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:04.895080
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:06.583358
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:07.967536
# Unit test for function get_source
def test_get_source():
    def test():
        pass
    assert get_source(test) == 'pass'



# Generated at 2022-06-18 01:05:09.679353
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:11.367405
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
    assert f() == [1, 2]

# Generated at 2022-06-18 01:05:13.253602
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:15.199104
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:18.194260
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:23.593154
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:25.459381
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:27.125730
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:29.806915
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:05:31.566163
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:33.790701
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3
    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:05:36.068189
# Unit test for function eager
def test_eager():
    @eager
    def get_list():
        yield 1
        yield 2
        yield 3

    assert get_list() == [1, 2, 3]

# Generated at 2022-06-18 01:05:37.950358
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:05:42.064400
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'test debug')

    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == '\x1b[34m[DEBUG] test debug\x1b[0m\n'



# Generated at 2022-06-18 01:05:45.405271
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:05:51.482898
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:53.981137
# Unit test for function eager
def test_eager():
    @eager
    def test_func():
        yield 1
        yield 2
        yield 3

    assert test_func() == [1, 2, 3]

# Generated at 2022-06-18 01:05:55.679586
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:06:02.223805
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:04.771993
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:07.659505
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:08.988828
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:06:11.556908
# Unit test for function eager
def test_eager():
    def test_fn():
        for i in range(5):
            yield i

    assert eager(test_fn)() == [0, 1, 2, 3, 4]

# Generated at 2022-06-18 01:06:13.659229
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:15.586156
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:26.358531
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:06:28.580259
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]



# Generated at 2022-06-18 01:06:30.035313
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:36.199504
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:39.209301
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:06:40.538154
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:43.434423
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:45.442015
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:47.871170
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:50.157103
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:11.389520
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:07:14.165516
# Unit test for function eager
def test_eager():
    def fn():
        yield 1
        yield 2
        yield 3

    assert eager(fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:16.722173
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:19.095700
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:07:20.289476
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

# Generated at 2022-06-18 01:07:25.682335
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:27.767626
# Unit test for function eager
def test_eager():
    def test_function():
        yield 1
        yield 2
        yield 3

    assert eager(test_function)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:30.216908
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:32.127581
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'



# Generated at 2022-06-18 01:07:36.717178
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'

# Generated at 2022-06-18 01:08:23.457533
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
        assert buf.getvalue() == ''

    with StringIO() as buf, redirect_stderr(buf):
        settings.debug = True
        debug(lambda: 'test')
        assert buf.getvalue() == 'DEBUG: test\n'
        settings.debug = False



# Generated at 2022-06-18 01:08:25.293185
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:27.340404
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:36.316475
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    def get_message():
        return 'test'

    with StringIO() as stream:
        sys.stderr = stream
        debug(get_message)
        assert stream.getvalue() == ''

        settings.debug = True
        debug(get_message)
        assert stream.getvalue() == '\x1b[1;30m[DEBUG] test\x1b[0m\n'

        settings.debug = False
        debug(get_message)
        assert stream.getvalue() == '\x1b[1;30m[DEBUG] test\x1b[0m\n'

# Generated at 2022-06-18 01:08:38.390152
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:40.553689
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:08:41.915161
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')


# Generated at 2022-06-18 01:08:43.415591
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:46.774923
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:53.184679
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')

    assert f.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')

    assert f.getvalue() == ''

# Generated at 2022-06-18 01:10:30.766580
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

# Generated at 2022-06-18 01:10:32.539670
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:10:35.524410
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:10:37.468119
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:40.202931
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:10:46.081206
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'message')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == messages.debug('message') + '\n'
    settings.debug = False

# Generated at 2022-06-18 01:10:51.333569
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue().strip() == '\x1b[34m[DEBUG] test\x1b[0m'
    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:10:52.506983
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:56.223763
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:11:00.578702
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'