

# Generated at 2022-06-18 01:03:31.122347
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]


# Generated at 2022-06-18 01:03:33.185512
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:36.014235
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:03:39.197759
# Unit test for function get_source
def test_get_source():
    def test_function():
        """
        This is a test function.
        """
        pass

    assert get_source(test_function) == 'def test_function():\n    """\n    This is a test function.\n    """\n    pass'

# Generated at 2022-06-18 01:03:41.434090
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Hello'

    debug(get_message)

# Generated at 2022-06-18 01:03:44.062909
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:03:47.045334
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:49.391411
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:03:56.285046
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:03:58.225763
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:01.885203
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:07.032715
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from . import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:09.458716
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:13.020585
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:19.029332
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    message = 'test'

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: message)
        assert stderr.getvalue().strip() == messages.debug(message)

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: message)
        assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:04:21.125466
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:26.901716
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'test')

    with io.StringIO() as buf, redirect_stderr(buf):
        test_debug_function()

    assert buf.getvalue() == ''

    settings.debug = True
    with io.StringIO() as buf, redirect_stderr(buf):
        test_debug_function()

    assert buf.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:04:29.177845
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:32.534503
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        if True:
            pass
    assert get_source(bar) == 'def bar():\n    if True:\n        pass'

# Generated at 2022-06-18 01:04:34.404978
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:40.290650
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]



# Generated at 2022-06-18 01:04:41.796423
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:43.379750
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:49.270832
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == ''

# Generated at 2022-06-18 01:04:51.221950
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:52.720499
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:58.618246
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[2mtest message\x1b[0m\n'

    settings.debug = False
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''



# Generated at 2022-06-18 01:05:02.198722
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:04.299905
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:05:06.000307
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:15.044534
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:17.867929
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:19.822079
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:05:25.659991
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == '[DEBUG] test'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == ''



# Generated at 2022-06-18 01:05:27.844612
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:30.616454
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'foo')
    settings.debug = False
    debug(lambda: 'foo')

# Generated at 2022-06-18 01:05:38.190912
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def get_message():
        return 'test'

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(get_message)
        assert stderr.getvalue() == '\x1b[1;32mDEBUG: test\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:05:39.772393
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:48.152552
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings

    settings.debug = True
    captured_output = StringIO()
    sys.stderr = captured_output
    debug(lambda: 'test')
    assert captured_output.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    captured_output = StringIO()
    sys.stderr = captured_output
    debug(lambda: 'test')
    assert captured_output.getvalue() == ''



# Generated at 2022-06-18 01:05:50.951054
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:07.532844
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:09.432430
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:17.115901
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_impl():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'debug message')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'debug message')
        assert f.getvalue() == '\x1b[34m[DEBUG] debug message\x1b[0m\n'
        settings.debug = False

    test_debug_impl()

# Generated at 2022-06-18 01:06:20.118718
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:06:21.825345
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:23.440506
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:06:26.137728
# Unit test for function eager
def test_eager():
    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen(3) == [0, 1, 2]

# Generated at 2022-06-18 01:06:31.622005
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == messages.debug('test message') + '\n'
    settings.debug = False



# Generated at 2022-06-18 01:06:38.984598
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:40.462418
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:00.371573
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:07:02.101674
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:05.433451
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:07:07.543136
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:09.737096
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:17.009315
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper(debug_enabled: bool) -> str:
        with io.StringIO() as f, redirect_stderr(f):
            settings.debug = debug_enabled
            debug(lambda: 'test')
            return f.getvalue()

    assert test_debug_helper(True) == messages.debug('test') + '\n'
    assert test_debug_helper(False) == ''

# Generated at 2022-06-18 01:07:19.357256
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:20.992411
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:22.870368
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:24.598158
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    settings.debug = False
    debug(lambda: 'debug message')

# Generated at 2022-06-18 01:07:46.147831
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:51.280589
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')
        assert stderr.getvalue() == messages.debug('Hello') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:54.245973
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:55.153959
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:07:55.893598
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:02.476974
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:08:03.400640
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:04.683495
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    assert eager(test)() == [1, 2, 3]

# Generated at 2022-06-18 01:08:06.004218
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:08.662988
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:49.240710
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:51.275747
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:08:53.184925
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:55.567760
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:08:57.062467
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:58.991964
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:09:02.518882
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:04.409196
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:09:09.856285
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == messages.debug('test')

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:09:11.991521
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:09:59.096802
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:01.467431
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:03.001067
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:05.315595
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:07.277211
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:10:10.212630
# Unit test for function eager
def test_eager():
    @eager
    def gen(n):
        for i in range(n):
            yield i

    assert gen(3) == [0, 1, 2]

# Generated at 2022-06-18 01:10:19.268708
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'message')
        assert mock_stderr.getvalue() == messages.debug('message') + '\n'
    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'message')
        assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:10:26.938550
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(io.StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(io.StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:10:32.533778
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'debug message')

    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == '\x1b[35mDEBUG: debug message\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:10:35.523725
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:12:12.534221
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'



# Generated at 2022-06-18 01:12:14.407474
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:16.847315
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:18.983467
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')
    settings.debug = True
    debug(lambda: 'test')

# Generated at 2022-06-18 01:12:20.752723
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:12:22.264828
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:12:23.991855
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:12:33.012179
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    f = StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[34mDEBUG: test message\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:12:34.263146
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:36.512844
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def bar():
        if True:
            pass

    assert get_source(bar) == 'if True:\n    pass'