

# Generated at 2022-06-18 01:03:24.635268
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:29.850866
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

# Generated at 2022-06-18 01:03:32.311972
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:34.490735
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:37.130503
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug')
    settings.debug = False
    debug(lambda: 'debug')

# Generated at 2022-06-18 01:03:38.972950
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:42.186393
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:44.471995
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    settings.debug = False
    debug(lambda: 'debug message')

# Generated at 2022-06-18 01:03:45.697620
# Unit test for function eager
def test_eager():
    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen(10) == list(range(10))

# Generated at 2022-06-18 01:03:47.923909
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:03:51.658153
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'hello')
    settings.debug = False
    debug(lambda: 'hello')

# Generated at 2022-06-18 01:03:57.861110
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
        assert buf.getvalue() == ''

    with StringIO() as buf, redirect_stderr(buf):
        settings.debug = True
        debug(lambda: 'test')
        assert buf.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:04:04.057181
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:04:07.174815
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:15.128896
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:18.966480
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:20.169900
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:04:21.326799
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:04:30.106010
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from .. import conf

    conf.settings.debug = True
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == '\x1b[34m[py-backwards] test\x1b[0m\n'

    conf.settings.debug = False
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:31.727970
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:37.506501
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:39.026389
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:04:44.322133
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == ''

# Generated at 2022-06-18 01:04:45.874949
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:52.003209
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')

    assert f.getvalue() == '\x1b[2m\x1b[34m[DEBUG]\x1b[0m test\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as f:
        debug(lambda: 'test')

    assert f.getvalue() == ''

# Generated at 2022-06-18 01:04:53.912807
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:59.022389
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:00.240288
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:01.523833
# Unit test for function eager
def test_eager():
    def foo():
        for i in range(5):
            yield i

    assert eager(foo)() == [0, 1, 2, 3, 4]

# Generated at 2022-06-18 01:05:02.531592
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:11.688793
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:14.677877
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass

    assert get_source(foo) == 'def foo():\n    pass'
    assert get_source(bar) == 'def bar():\n    pass'

# Generated at 2022-06-18 01:05:22.811224
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''
        settings.debug = True
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
        settings.debug = False

    test_debug_helper()

# Generated at 2022-06-18 01:05:27.961270
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'Hello')
        assert buf.getvalue() == ''

    with io.StringIO() as buf, redirect_stderr(buf):
        settings.debug = True
        debug(lambda: 'Hello')
        assert buf.getvalue() == '\x1b[90m[DEBUG] Hello\x1b[0m\n'

# Generated at 2022-06-18 01:05:30.753393
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:33.265709
# Unit test for function eager
def test_eager():
    def foo(n):
        for i in range(n):
            yield i
    assert eager(foo)(5) == [0, 1, 2, 3, 4]

# Generated at 2022-06-18 01:05:35.369910
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:37.564379
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:05:39.201468
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:41.324614
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:58.564995
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3
    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:06:01.021939
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:06:08.594183
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:10.492019
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:16.866903
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from ..conf import settings

    settings.debug = True
    with patch('sys.stderr') as stderr:
        debug(lambda: 'test')
        stderr.write.assert_called_once_with(messages.debug('test') + '\n')

    settings.debug = False
    with patch('sys.stderr') as stderr:
        debug(lambda: 'test')
        stderr.write.assert_not_called()

# Generated at 2022-06-18 01:06:18.748311
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:24.623527
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == '\x1b[35mtest\x1b[0m\n'
        settings.debug = False



# Generated at 2022-06-18 01:06:30.745121
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == messages.debug('test') + '\n'
    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:33.900988
# Unit test for function eager
def test_eager():
    def test_fn(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert eager(test_fn)(10) == list(range(10))

# Generated at 2022-06-18 01:06:35.833394
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:08.405811
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:14.685366
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_impl():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
        settings.debug = False

    test_debug_impl()

# Generated at 2022-06-18 01:07:16.858125
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:19.190745
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:07:24.672316
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stdout
    from ..conf import settings
    settings.debug = True
    with redirect_stdout(StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[33mDEBUG: test\x1b[0m\n'
    settings.debug = False
    with redirect_stdout(StringIO()) as f:
        debug(lambda: 'test')
    assert f.getvalue() == ''

# Generated at 2022-06-18 01:07:26.416918
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug message')
    settings.debug = False
    debug(lambda: 'debug message')

# Generated at 2022-06-18 01:07:28.160329
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1

    assert get_source(foo) == 'return 1'

# Generated at 2022-06-18 01:07:30.930571
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:32.987040
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:07:35.147785
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:08:14.224191
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:21.696033
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert 'test' in stderr.getvalue()

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert 'test' not in stderr.getvalue()

# Generated at 2022-06-18 01:08:23.837607
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:25.643548
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:27.786661
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:34.713088
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:08:36.866003
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:39.054361
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:40.815971
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass\n'

# Generated at 2022-06-18 01:08:42.617098
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:14.977109
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:10:16.937224
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:10:20.647500
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == messages.debug('test') + '\n'
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:10:28.406933
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from ..conf import settings

    settings.debug = True

    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'test')
        mock_stderr.write.assert_called_once_with(messages.debug('test') + '\n')

    settings.debug = False

    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'test')
        mock_stderr.write.assert_not_called()

# Generated at 2022-06-18 01:10:30.138649
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:31.879283
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:34.395596
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:10:36.670418
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:38.160484
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:41.024352
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

