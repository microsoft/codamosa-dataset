

# Generated at 2022-06-18 01:03:32.666673
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:34.490734
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:37.130325
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:03:38.645478
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:47.781090
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from . import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:03:49.710390
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:51.302719
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:54.096503
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass\n'

# Generated at 2022-06-18 01:03:54.889699
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')



# Generated at 2022-06-18 01:03:57.377100
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:01.343476
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:03.409654
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:06.975476
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:04:15.289407
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def get_message():
        return 'test'

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(get_message)
        assert stderr.getvalue() == messages.debug('test') + '\n'
        settings.debug = False

# Generated at 2022-06-18 01:04:18.966813
# Unit test for function eager
def test_eager():
    @eager
    def test_function():
        yield 1
        yield 2
        yield 3

    assert test_function() == [1, 2, 3]

# Generated at 2022-06-18 01:04:20.170112
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:21.898893
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:04:25.280359
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:04:26.872481
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:30.495689
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def baz():
            pass
    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

# Generated at 2022-06-18 01:04:33.994300
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:36.319975
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:38.159732
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:40.023205
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:45.707128
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:47.311850
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-18 01:04:50.716533
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as mock_stderr:
        debug(lambda: 'test')
        mock_stderr.write.assert_called_once_with(messages.debug('test') + '\n')



# Generated at 2022-06-18 01:04:55.840597
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_message():
        return 'test message'

    f = io.StringIO()
    with redirect_stderr(f):
        debug(test_message)
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(test_message)
    assert f.getvalue() == '{} {}\n'.format(messages.DEBUG_PREFIX, test_message())
    settings.debug = False

# Generated at 2022-06-18 01:04:57.272481
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:58.879186
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:03.437155
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:07.453255
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert 'test' in stderr.getvalue()

    settings.debug = False

# Generated at 2022-06-18 01:05:09.771409
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:05:15.879205
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:18.028232
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:05:20.020100
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:05:22.040990
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:23.717662
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:25.255577
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:05:26.947841
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:32.772272
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:34.822388
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:36.464719
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
    assert test() == [1, 2]

# Generated at 2022-06-18 01:05:38.228666
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:40.085759
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:05:42.347278
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:45.026320
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:05:50.760574
# Unit test for function debug
def test_debug():
    import io
    import sys
    from ..conf import settings

    settings.debug = True
    try:
        stderr = sys.stderr
        sys.stderr = io.StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    finally:
        sys.stderr = stderr
        settings.debug = False



# Generated at 2022-06-18 01:05:52.647206
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:55.336945
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:04.250833
# Unit test for function debug
def test_debug():
    import io
    import sys
    from unittest import mock

    settings.debug = True

    with mock.patch('sys.stderr', new=io.StringIO()) as mock_stderr:
        debug(lambda: 'message')
        assert mock_stderr.getvalue() == messages.debug('message') + '\n'

    settings.debug = False

    with mock.patch('sys.stderr', new=io.StringIO()) as mock_stderr:
        debug(lambda: 'message')
        assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:06:06.290997
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:13.376396
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper(debug_enabled: bool) -> None:
        settings.debug = debug_enabled
        with io.StringIO() as buf, redirect_stderr(buf):
            debug(lambda: 'foo')
            assert buf.getvalue() == messages.debug('foo') + '\n'

    test_debug_helper(True)
    test_debug_helper(False)



# Generated at 2022-06-18 01:06:19.021353
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys
    from ..conf import settings
    settings.debug = True
    try:
        sys.stderr = StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == messages.debug('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False


# Generated at 2022-06-18 01:06:28.504158
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stderr = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.stderr

        def test_debug_output(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '\x1b[2mtest\x1b[0m\n')

        def test_no_debug_output(self):
            settings.debug = False
            debug(lambda: 'test')
            self.assertEqual(sys.stderr.getvalue(), '')

    unittest.main

# Generated at 2022-06-18 01:06:30.390222
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:31.876689
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:06:34.440467
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:06:41.262896
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[1m\x1b[34mDEBUG\x1b[0m: test\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:44.244520
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:49.830694
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-18 01:06:52.434828
# Unit test for function debug
def test_debug():
    from unittest.mock import patch

    with patch('sys.stderr') as stderr:
        debug(lambda: 'test')
        assert stderr.write.called



# Generated at 2022-06-18 01:06:55.273629
# Unit test for function eager
def test_eager():
    from pytest import raises

    @eager
    def test_generator():
        yield 1
        yield 2
        yield 3

    assert test_generator() == [1, 2, 3]

    with raises(TypeError):
        test_generator(1)



# Generated at 2022-06-18 01:06:58.275400
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        for i in range(5):
            yield i
    assert gen() == [0, 1, 2, 3, 4]

# Generated at 2022-06-18 01:07:00.292390
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:02.031402
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:05.338669
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:07.114362
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:09.655407
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:11.981766
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:07:21.775889
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:07:22.891105
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:07:25.247617
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:07:26.491802
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:28.664213
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:31.268505
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:33.281831
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:35.741105
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:37.927627
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:40.795663
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:08:07.292594
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == ''

# Generated at 2022-06-18 01:08:09.352806
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:10.937541
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:08:18.462309
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:08:20.143502
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:22.253432
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:24.256389
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:26.016779
# Unit test for function get_source
def test_get_source():
    def test_func():
        pass

    assert get_source(test_func) == 'def test_func():\n    pass'

# Generated at 2022-06-18 01:08:27.950042
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:30.685261
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:09:13.235164
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:09:20.582469
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[1;30m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:09:23.982412
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:09:25.058121
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Generated at 2022-06-18 01:09:26.708477
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:28.180299
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
    assert eager(test_fn)() == [1, 2]

# Generated at 2022-06-18 01:09:30.645309
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:32.562825
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:34.805154
# Unit test for function eager
def test_eager():
    @eager
    def get_iterable():
        yield 1
        yield 2
        yield 3

    assert get_iterable() == [1, 2, 3]

# Generated at 2022-06-18 01:09:41.771163
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    captured_output = StringIO()
    sys.stderr = captured_output
    debug(lambda: 'test')
    assert captured_output.getvalue() == '\x1b[2mtest\x1b[0m\n'
    settings.debug = False
    captured_output = StringIO()
    sys.stderr = captured_output
    debug(lambda: 'test')
    assert captured_output.getvalue() == ''
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 01:11:16.690176
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:11:18.430722
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:11:19.722692
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'def test():\n    pass'

# Generated at 2022-06-18 01:11:23.133469
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:11:25.120941
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:30.717843
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:11:39.841415
# Unit test for function debug
def test_debug():
    import io
    from contextlib import redirect_stderr
    from unittest import TestCase

    class TestDebug(TestCase):
        def test_debug(self):
            with redirect_stderr(io.StringIO()) as stderr:
                debug(lambda: 'test')
                self.assertEqual(stderr.getvalue(), '')

            with redirect_stderr(io.StringIO()) as stderr:
                settings.debug = True
                debug(lambda: 'test')
                self.assertEqual(stderr.getvalue(), '\x1b[2mtest\x1b[0m\n')

            with redirect_stderr(io.StringIO()) as stderr:
                settings.debug = False
                debug(lambda: 'test')

# Generated at 2022-06-18 01:11:42.096117
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:44.125726
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:11:51.915316
# Unit test for function debug
def test_debug():
    from unittest import mock
    from ..conf import settings

    settings.debug = True
    with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
        debug(lambda: 'test')
    assert mock_stderr.write.call_args[0][0] == messages.debug('test')

    settings.debug = False
    with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
        debug(lambda: 'test')
    assert mock_stderr.write.call_args is None