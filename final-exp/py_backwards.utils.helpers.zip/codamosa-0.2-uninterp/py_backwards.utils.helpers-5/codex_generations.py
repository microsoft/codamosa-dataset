

# Generated at 2022-06-18 01:03:27.606014
# Unit test for function debug
def test_debug():
    from ..conf import settings
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:03:29.198711
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:32.195096
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:03:34.005821
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:36.628772
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:38.484486
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:42.137654
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:03:51.949649
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == ''

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        test_function()
        assert stderr.getvalue() == '\x1b[1m\x1b[33mDEBUG: test message\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:03:58.624293
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def get_message():
        return 'Hello, world!'

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)

    assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(get_message)

    assert stderr.getvalue() == messages.debug(get_message()) + '\n'

    settings.debug = False

# Generated at 2022-06-18 01:04:00.221739
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:04.144426
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:07.225630
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:10.033565
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]



# Generated at 2022-06-18 01:04:13.226149
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:14.851502
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:18.443538
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:04:21.321166
# Unit test for function eager
def test_eager():
    @eager
    def gen(n: int) -> Iterable[int]:
        for i in range(n):
            yield i

    assert gen(3) == [0, 1, 2]

# Generated at 2022-06-18 01:04:23.219200
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:25.735747
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:04:27.712722
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:36.065652
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:04:44.687819
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            sys.stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout

        def test_debug_enabled(self):
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(sys.stdout.getvalue(), '\x1b[33m[DEBUG] test\x1b[0m\n')

        def test_debug_disabled(self):
            settings.debug = False
            debug(lambda: 'test')
            self.assertEqual(sys.stdout.getvalue(), '')

    unittest.main()

# Generated at 2022-06-18 01:04:46.274387
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:04:47.843126
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:04:51.222170
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        debug(lambda: 'hello')
        stderr.write.assert_called_once_with(messages.debug('hello') + '\n')



# Generated at 2022-06-18 01:04:52.970092
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'



# Generated at 2022-06-18 01:04:54.841183
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:56.322773
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:57.715918
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:59.306094
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:04.986594
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:05:06.630165
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:13.388975
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:14.545600
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:17.991715
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:19.543783
# Unit test for function get_source
def test_get_source():
    def test_func():
        return 1

    assert get_source(test_func) == 'return 1'

# Generated at 2022-06-18 01:05:21.692711
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:29.224709
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest

    class TestDebug(unittest.TestCase):
        def setUp(self):
            self.stderr = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.stderr

        def test_debug_is_not_called_when_debug_is_false(self):
            settings.debug = False
            debug(lambda: 'debug')
            self.assertEqual(sys.stderr.getvalue(), '')

        def test_debug_is_called_when_debug_is_true(self):
            settings.debug = True
            debug(lambda: 'debug')

# Generated at 2022-06-18 01:05:31.705239
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:05:38.727357
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')
        assert buffer.getvalue() == ''

    with StringIO() as buffer, redirect_stderr(buffer):
        settings.debug = True
        debug(lambda: 'test')
        assert buffer.getvalue() == '\x1b[90m[py_backwards] test\x1b[0m\n'
        settings.debug = False



# Generated at 2022-06-18 01:05:50.129801
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:05:52.151416
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:05:54.839164
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:56.461611
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:58.565390
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:01.022592
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:03.221754
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:12.581660
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from unittest import TestCase

    class TestDebug(TestCase):
        def test_debug(self):
            with redirect_stderr(StringIO()) as stderr:
                debug(lambda: 'test')
                self.assertEqual(stderr.getvalue(), '')
                settings.debug = True
                debug(lambda: 'test')
                self.assertEqual(stderr.getvalue(), '\x1b[36m[DEBUG] test\x1b[0m\n')
                settings.debug = False

    test_debug = TestDebug()
    test_debug.test_debug()

# Generated at 2022-06-18 01:06:14.654686
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:18.338281
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug(lambda: 'test')
        assert fake_stderr.getvalue() == messages.debug('test') + '\n'



# Generated at 2022-06-18 01:06:29.075458
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:35.198461
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')
        assert buffer.getvalue() == ''

    with StringIO() as buffer, redirect_stderr(buffer):
        settings.debug = True
        debug(lambda: 'test')
        assert buffer.getvalue() == messages.debug('test') + '\n'
        settings.debug = False



# Generated at 2022-06-18 01:06:43.934726
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager
    from ..conf import settings

    @contextmanager
    def capture_output():
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    with capture_output() as output:
        debug(lambda: 'test')
    assert output.getvalue() == ''

    settings.debug = True
    with capture_output() as output:
        debug(lambda: 'test')
    assert output.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'

# Generated at 2022-06-18 01:06:45.923905
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:52.859090
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == messages.debug('test')

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:06:55.304987
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:07:02.102378
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')

    assert stderr.getvalue() == messages.debug('Hello') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')

    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:05.433390
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:11.598493
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:20.501111
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings

    settings.debug = True

    captured_output = StringIO()
    sys.stderr = captured_output

    debug(lambda: 'test')

    sys.stderr = sys.__stderr__
    assert captured_output.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    captured_output = StringIO()
    sys.stderr = captured_output

    debug(lambda: 'test')

    sys.stderr = sys.__stderr__
    assert captured_output.getvalue() == ''

# Generated at 2022-06-18 01:07:41.831623
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:45.015183
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:50.518866
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:53.810251
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == ''

        settings.debug = True
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'test')
        assert f.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
        settings.debug = False

    test_debug_helper()

# Generated at 2022-06-18 01:08:03.014669
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest import TestCase

    class TestDebug(TestCase):
        def setUp(self):
            self.old_debug = settings.debug
            settings.debug = True
            self.old_stderr = sys.stderr
            sys.stderr = self.stderr = StringIO()

        def tearDown(self):
            settings.debug = self.old_debug
            sys.stderr = self.old_stderr

        def test_debug(self):
            debug(lambda: 'test')
            self.assertEqual(self.stderr.getvalue(), messages.debug('test') + '\n')

    return TestDebug

# Generated at 2022-06-18 01:08:04.337773
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:08:05.633560
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:08:08.004129
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:18.050705
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_helper():
        f = io.StringIO()
        with redirect_stderr(f):
            debug(lambda: 'debug message')
        assert f.getvalue() == '\x1b[2m\x1b[34m[DEBUG]\x1b[0m debug message\n'

    def test_debug_helper_disabled():
        f = io.StringIO()
        with redirect_stderr(f):
            settings.debug = False
            debug(lambda: 'debug message')
        assert f.getvalue() == ''

    test_debug_helper()
    test_debug_helper_disabled()

# Generated at 2022-06-18 01:08:24.262148
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with StringIO() as buffer, redirect_stderr(buffer):
        debug(lambda: 'test')

    assert buffer.getvalue() == ''

# Generated at 2022-06-18 01:09:10.931632
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == messages.debug('test')

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue().strip() == ''

# Generated at 2022-06-18 01:09:17.827433
# Unit test for function debug
def test_debug():
    import io
    import sys
    from ..conf import settings
    settings.debug = True
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    finally:
        settings.debug = False
        sys.stderr = sys.__stderr__

# Generated at 2022-06-18 01:09:25.177940
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def test():
        with redirect_stderr(StringIO()) as stderr:
            debug(lambda: 'test')
            assert stderr.getvalue() == ''

        with redirect_stderr(StringIO()) as stderr:
            settings.debug = True
            debug(lambda: 'test')
            assert stderr.getvalue() == messages.debug('test') + '\n'
            settings.debug = False

    test()

# Generated at 2022-06-18 01:09:27.150314
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:09:33.218962
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest
    from unittest.mock import patch

    class TestDebug(unittest.TestCase):
        @patch('sys.stderr', new_callable=io.StringIO)
        def test_debug_enabled(self, mock_stderr: io.StringIO) -> None:
            settings.debug = True
            debug(lambda: 'test')
            self.assertEqual(mock_stderr.getvalue(), '\x1b[34mDEBUG: test\x1b[0m\n')

        @patch('sys.stderr', new_callable=io.StringIO)
        def test_debug_disabled(self, mock_stderr: io.StringIO) -> None:
            settings.debug = False

# Generated at 2022-06-18 01:09:35.234513
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:09:37.054417
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:38.451199
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:40.264630
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:09:42.886994
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:32.040150
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:34.647331
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:41.909508
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    with io.StringIO() as buf, redirect_stderr(buf):
        test_function()
        assert buf.getvalue() == ''

    settings.debug = True
    with io.StringIO() as buf, redirect_stderr(buf):
        test_function()
        assert buf.getvalue() == messages.debug('test') + '\n'
    settings.debug = False



# Generated at 2022-06-18 01:10:43.757202
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:10:45.558712
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:10:47.087980
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:48.197671
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:10:49.135846
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:50.384658
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:10:54.555611
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    captured_output = StringIO()
    sys.stderr = captured_output
    debug(lambda: 'test')
    assert captured_output.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False
    captured_output = StringIO()
    sys.stderr = captured_output
    debug(lambda: 'test')
    assert captured_output.getvalue() == ''

# Generated at 2022-06-18 01:12:38.736311
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:12:40.042433
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-18 01:12:42.687910
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:12:43.828302
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:12:47.862315
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    with redirect_stderr(io.StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with redirect_stderr(io.StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
        settings.debug = False

# Generated at 2022-06-18 01:12:52.477513
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_debug_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_debug_function()
    assert f.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:12:53.868827
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:13:01.445085
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings

    settings.debug = True

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == ''

# Generated at 2022-06-18 01:13:06.740967
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    from ..conf import settings

    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''



# Generated at 2022-06-18 01:13:08.334971
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')