

# Generated at 2022-06-18 01:03:32.548204
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:34.364752
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:03:36.320921
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test'

    debug(get_message)

# Generated at 2022-06-18 01:03:38.200916
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:03:48.169773
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO

    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(lambda: 'test message')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test message')
        assert stderr.getvalue() == '\x1b[34mDEBUG: test message\x1b[0m\n'



# Generated at 2022-06-18 01:03:52.121456
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'test')
        assert sys.stderr.getvalue() == messages.debug('test') + '\n'
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:03:59.098583
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'Hello')
        assert buf.getvalue() == '\x1b[32m[DEBUG] Hello\x1b[0m\n'

    settings.debug = False
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'Hello')
        assert buf.getvalue() == ''

# Generated at 2022-06-18 01:04:01.041112
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:04:03.103337
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:06.476850
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'



# Generated at 2022-06-18 01:04:16.584281
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'hello')
    assert stderr.getvalue() == '\x1b[2m\x1b[36mDEBUG: hello\x1b[0m\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'hello')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:20.077202
# Unit test for function get_source
def test_get_source():
    def test_fn():
        pass

    assert get_source(test_fn) == 'def test_fn():\n    pass'

# Generated at 2022-06-18 01:04:22.150397
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:23.916063
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:04:25.280096
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False

# Generated at 2022-06-18 01:04:26.872447
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:04:29.068405
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:31.038449
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:39.071198
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with StringIO() as stderr:
        with redirect_stderr(stderr):
            debug(lambda: 'foo')
            assert stderr.getvalue() == ''

        with redirect_stderr(stderr):
            settings.debug = True
            debug(lambda: 'foo')
            assert stderr.getvalue() == '\x1b[2m\x1b[32mfoo\x1b[0m\n'

        with redirect_stderr(stderr):
            settings.debug = False
            debug(lambda: 'foo')
            assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:04:43.956772
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    stdout = sys.stderr
    sys.stderr = StringIO()
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    sys.stderr = stdout
    settings.debug = False

# Generated at 2022-06-18 01:04:47.312842
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:49.315309
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:04:50.927216
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:56.086300
# Unit test for function debug
def test_debug():
    import io
    import sys

    sys.stderr = io.StringIO()
    settings.debug = True
    debug(lambda: 'foo')
    assert sys.stderr.getvalue() == messages.debug('foo') + '\n'
    settings.debug = False
    debug(lambda: 'foo')
    assert sys.stderr.getvalue() == messages.debug('foo') + '\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 01:05:01.365672
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_message():
        return 'test message'

    f = io.StringIO()
    with redirect_stderr(f):
        debug(test_message)
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(test_message)
    assert f.getvalue() == '{} {}\n'.format(messages.DEBUG_PREFIX, test_message())
    settings.debug = False

# Generated at 2022-06-18 01:05:03.853410
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:05.904166
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:08.383701
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:10.469476
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:05:16.719522
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:22.298603
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:05:24.225013
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:05:29.250344
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:05:31.704915
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:35.748596
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')
        assert stderr.getvalue() == messages.debug('Hello') + '\n'
    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'Hello')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:05:37.947107
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:39.856237
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:42.736750
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3

    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:05:45.680479
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:47.969144
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:06:02.194693
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def get_message():
        return 'test'

    f = io.StringIO()
    with redirect_stderr(f):
        debug(get_message)
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(get_message)
    assert f.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:06:04.132365
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:07.127141
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:09.483962
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:11.028462
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:12.873743
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:14.954884
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:20.500155
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        out = io.StringIO()
        sys.stderr = out
        debug(lambda: 'test')
        assert out.getvalue() == messages.debug('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False



# Generated at 2022-06-18 01:06:22.173140
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:06:23.784805
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:06:35.236515
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:37.761150
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:39.656720
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:41.021216
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:44.028953
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:46.015621
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:49.105920
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:06:51.171173
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:54.076971
# Unit test for function eager
def test_eager():
    def test_fn():
        for i in range(10):
            yield i

    assert eager(test_fn)() == list(range(10))

# Generated at 2022-06-18 01:06:55.766851
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-18 01:07:17.084646
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:07:19.935023
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:07:21.875671
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:27.179156
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == messages.debug('test') + '\n'
        settings.debug = False

# Generated at 2022-06-18 01:07:30.132067
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:32.432530
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:40.067185
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test')

    # Redirect stderr to string
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

    # Redirect stderr to string
    f = io.StringIO()
    with redirect_stderr(f):
        settings.debug = False
        test_function()
    assert f.getvalue() == ''

# Generated at 2022-06-18 01:07:47.246095
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:07:48.377183
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:51.572647
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'
        settings.debug = False

# Generated at 2022-06-18 01:08:38.208719
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:08:40.515742
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:08:42.512818
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:08:44.214969
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:08:47.101971
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2

    assert test() == [1, 2]

# Generated at 2022-06-18 01:08:51.481711
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings
    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

# Generated at 2022-06-18 01:08:57.447947
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == messages.debug('test') + '\n'

    settings.debug = False

    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')

    assert stderr.getvalue() == ''

# Generated at 2022-06-18 01:08:59.544754
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:01.830228
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False

# Generated at 2022-06-18 01:09:03.965721
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:10:36.393277
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:10:37.583418
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:10:45.709154
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == messages.debug('test') + '\n'
        settings.debug = False
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == messages.debug('test') + '\n'
        settings.debug = True
        debug(lambda: 'test')
        assert mock_stderr.getvalue() == messages.debug('test') + '\n' + messages.debug('test') + '\n'

# Generated at 2022-06-18 01:10:47.096471
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:10:48.218908
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:10:49.332534
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:10:50.221481
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:10:55.372791
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test():
        with redirect_stderr(io.StringIO()) as stderr:
            debug(lambda: 'test')
            assert stderr.getvalue() == ''

        with redirect_stderr(io.StringIO()) as stderr:
            settings.debug = True
            debug(lambda: 'test')
            assert stderr.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'
            settings.debug = False

    test()

# Generated at 2022-06-18 01:10:57.493374
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:00.703674
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'