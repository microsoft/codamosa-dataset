

# Generated at 2022-06-18 01:03:24.763824
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:27.353354
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:03:29.467124
# Unit test for function eager
def test_eager():
    @eager
    def gen():
        yield 1
        yield 2
        yield 3
    assert gen() == [1, 2, 3]

# Generated at 2022-06-18 01:03:32.144962
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:03:34.288902
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:03:40.502649
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    def get_message():
        return 'Hello'

    with redirect_stderr(StringIO()) as stderr:
        debug(get_message)
        assert stderr.getvalue() == ''

    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(get_message)
        assert stderr.getvalue() == messages.debug('Hello') + '\n'
        settings.debug = False



# Generated at 2022-06-18 01:03:42.876711
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:03:46.547282
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3

    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:03:54.672038
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from unittest import TestCase

    class TestDebug(TestCase):
        def test_debug(self):
            with redirect_stderr(io.StringIO()) as stderr:
                debug(lambda: 'Hello world!')
                self.assertEqual(stderr.getvalue(), '')

            with redirect_stderr(io.StringIO()) as stderr:
                settings.debug = True
                debug(lambda: 'Hello world!')
                self.assertEqual(stderr.getvalue(), '\x1b[33m[DEBUG] Hello world!\x1b[0m\n')

    test_debug = TestDebug()
    test_debug.test_debug()

# Generated at 2022-06-18 01:03:57.173798
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'



# Generated at 2022-06-18 01:04:03.584714
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = True
    try:
        out = io.StringIO()
        sys.stderr = out
        debug(lambda: 'test')
        assert out.getvalue() == messages.debug('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 01:04:15.482581
# Unit test for function debug
def test_debug():
    import io
    import sys

    class FakeStdErr:
        def __init__(self):
            self.content = io.StringIO()

        def write(self, s: str) -> None:
            self.content.write(s)

        def flush(self) -> None:
            pass

    fake_stderr = FakeStdErr()
    old_stderr = sys.stderr
    sys.stderr = fake_stderr

    try:
        settings.debug = True
        debug(lambda: 'test')
        assert fake_stderr.content.getvalue() == messages.debug('test') + '\n'
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-18 01:04:19.261482
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:26.442317
# Unit test for function debug
def test_debug():
    import io
    import sys
    import unittest
    from contextlib import redirect_stderr

    class TestDebug(unittest.TestCase):
        def test_debug(self):
            f = io.StringIO()
            with redirect_stderr(f):
                debug(lambda: 'test')
                self.assertEqual(f.getvalue(), '')
                settings.debug = True
                debug(lambda: 'test')
                self.assertEqual(f.getvalue(), '\x1b[2mtest\x1b[0m\n')
                settings.debug = False
            sys.stderr = sys.__stderr__

    unittest.main()



# Generated at 2022-06-18 01:04:31.418381
# Unit test for function debug
def test_debug():
    from io import StringIO
    from ..conf import settings
    settings.debug = True
    try:
        out = StringIO()
        sys.stderr = out
        debug(lambda: 'test')
        assert out.getvalue() == messages.debug('test') + '\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False


# Generated at 2022-06-18 01:04:33.307790
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:35.046567
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:37.191991
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:04:38.698754
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:04:40.519214
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:50.669330
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'test message')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[34mDEBUG: test message\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:04:52.838069
# Unit test for function eager
def test_eager():
    @eager
    def test_generator():
        yield 1
        yield 2
        yield 3

    assert test_generator() == [1, 2, 3]

# Generated at 2022-06-18 01:04:54.758801
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:04:59.974041
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'debug')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'debug')
    assert f.getvalue() == '\x1b[34mDEBUG: debug\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:05:05.450522
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == messages.debug('test') + '\n'



# Generated at 2022-06-18 01:05:12.406994
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr
    with redirect_stderr(StringIO()) as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''
    with redirect_stderr(StringIO()) as stderr:
        settings.debug = True
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'
        settings.debug = False


# Generated at 2022-06-18 01:05:14.342668
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:05:17.495574
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:05:18.998181
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:20.730133
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass'

# Generated at 2022-06-18 01:05:27.008187
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:29.709951
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:05:31.896749
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:05:34.046490
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:36.336055
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:05:38.180276
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'pass'

# Generated at 2022-06-18 01:05:40.048154
# Unit test for function eager
def test_eager():
    def foo():
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:42.874048
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    assert eager(test)() == [1, 2, 3]

# Generated at 2022-06-18 01:05:45.724771
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:05:51.789783
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    def test_function():
        debug(lambda: 'debug message')

    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        test_function()
    assert f.getvalue() == '\x1b[2mdebug message\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:06:03.635776
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'test')
    settings.debug = False
    debug(lambda: 'test')

# Generated at 2022-06-18 01:06:06.068333
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:06:08.690566
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(lambda: 'test')
    finally:
        settings.debug = False

# Generated at 2022-06-18 01:06:17.737713
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import contextmanager
    from ..conf import settings

    @contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    with capture_stderr() as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == ''

    settings.debug = True
    with capture_stderr() as stderr:
        debug(lambda: 'test')
        assert stderr.getvalue() == '\x1b[36m[DEBUG] test\x1b[0m\n'

# Generated at 2022-06-18 01:06:20.451763
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:23.138782
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'pass'

    def bar():
        if True:
            pass

    assert get_source(bar) == 'if True:\n    pass'

# Generated at 2022-06-18 01:06:25.116634
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    assert eager(f)() == [1, 2, 3]

# Generated at 2022-06-18 01:06:30.534551
# Unit test for function debug
def test_debug():
    from io import StringIO
    from contextlib import redirect_stderr

    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == ''

    settings.debug = True
    f = StringIO()
    with redirect_stderr(f):
        debug(lambda: 'test')
    assert f.getvalue() == '\x1b[34mDEBUG: test\x1b[0m\n'

    settings.debug = False

# Generated at 2022-06-18 01:06:32.042005
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:34.197195
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:06:55.855247
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-18 01:06:59.127365
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:01.014552
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        return a + b

    assert get_source(test_function) == 'return a + b'

# Generated at 2022-06-18 01:07:02.102622
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:05.434264
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:07.204406
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:09.741595
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:07:11.981933
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:07:14.085759
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:07:16.270930
# Unit test for function get_source
def test_get_source():
    def test():
        pass

    assert get_source(test) == 'pass'



# Generated at 2022-06-18 01:07:58.009385
# Unit test for function get_source
def test_get_source():
    def foo():
        return 1

    assert get_source(foo) == 'return 1'

# Generated at 2022-06-18 01:08:00.342688
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:02.254576
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:08.170590
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()
    settings.debug = True
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'
    settings.debug = False
    debug(lambda: 'test')
    assert sys.stderr.getvalue() == '\x1b[33m[DEBUG] test\x1b[0m\n'

# Generated at 2022-06-18 01:08:10.339424
# Unit test for function eager
def test_eager():
    @eager
    def test_func():
        yield 1
        yield 2
        yield 3
    assert test_func() == [1, 2, 3]

# Generated at 2022-06-18 01:08:13.978615
# Unit test for function get_source
def test_get_source():
    def foo():
        pass
    assert get_source(foo) == 'def foo():\n    pass'

    def bar():
        def baz():
            pass
    assert get_source(bar) == 'def bar():\n    def baz():\n        pass'

# Generated at 2022-06-18 01:08:16.648889
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:08:19.248781
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: 'debug')
    settings.debug = False
    debug(lambda: 'debug')

# Generated at 2022-06-18 01:08:21.430952
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:08:23.584422
# Unit test for function eager
def test_eager():
    def foo() -> Iterable[int]:
        yield 1
        yield 2
        yield 3

    assert eager(foo)() == [1, 2, 3]

# Generated at 2022-06-18 01:09:06.690896
# Unit test for function eager
def test_eager():
    @eager
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert test_fn() == [1, 2, 3]

# Generated at 2022-06-18 01:09:08.522291
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:09:10.507616
# Unit test for function eager
def test_eager():
    def test_fn():
        yield 1
        yield 2
        yield 3

    assert eager(test_fn)() == [1, 2, 3]

# Generated at 2022-06-18 01:09:12.416589
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3
    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:09:14.666920
# Unit test for function eager
def test_eager():
    @eager
    def test():
        yield 1
        yield 2
        yield 3
    assert test() == [1, 2, 3]

# Generated at 2022-06-18 01:09:21.402505
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr
    from ..conf import settings

    settings.debug = True
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
    assert buf.getvalue() == '\x1b[36m[DEBUG] test\x1b[0m\n'

    settings.debug = False
    with io.StringIO() as buf, redirect_stderr(buf):
        debug(lambda: 'test')
    assert buf.getvalue() == ''

# Generated at 2022-06-18 01:09:28.740880
# Unit test for function debug
def test_debug():
    import io
    import sys
    from contextlib import redirect_stderr

    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'Hello')
    assert f.getvalue() == ''

    settings.debug = True
    f = io.StringIO()
    with redirect_stderr(f):
        debug(lambda: 'Hello')
    assert f.getvalue() == '\x1b[2m\x1b[1m\x1b[36mHello\x1b[0m\n'
    settings.debug = False

# Generated at 2022-06-18 01:09:31.248176
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:32.799901
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:09:34.730396
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-18 01:11:11.554541
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:11:13.071848
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:11:15.519517
# Unit test for function eager
def test_eager():
    @eager
    def foo():
        yield 1
        yield 2
        yield 3

    assert foo() == [1, 2, 3]

# Generated at 2022-06-18 01:11:17.004816
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:18.495886
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass\n'

# Generated at 2022-06-18 01:11:21.805833
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:11:24.664260
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'



# Generated at 2022-06-18 01:11:26.164048
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:11:28.062164
# Unit test for function eager
def test_eager():
    @eager
    def f():
        yield 1
        yield 2
        yield 3
    assert f() == [1, 2, 3]

# Generated at 2022-06-18 01:11:29.790484
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n    pass'

