

# Generated at 2022-06-25 23:03:39.457371
# Unit test for function debug
def test_debug():
    def test() -> None:
        messages = []
        def get_message() -> str:
            return 'Hello world!'
        with patch('sys.stderr', new_callable=StringIO) as stderr:
            debug(get_message)
        assert messages == [], messages
        assert stderr.getvalue() == f'{messages.debug("Hello world!")}\n'

        with patch('sys.stderr', new_callable=StringIO) as stderr:
            settings.debug = False
            debug(get_message)
        assert stderr.getvalue() == ''

    test_case_0()
    test()


# Generated at 2022-06-25 23:03:41.747979
# Unit test for function get_source
def test_get_source():
    # Test case 0
    yield test_case_0


if __name__ == '__main__':
    for test_case in test_get_source():
        pass

# Generated at 2022-06-25 23:03:45.766911
# Unit test for function eager
def test_eager():
    from backwards import eager

    @eager
    def xrange(start, end):
        i = start
        while i < end:
            yield i
            i += 1

    assert xrange(1, 10000) == list(range(1, 10000))


# Generated at 2022-06-25 23:03:49.216485
# Unit test for function eager
def test_eager():
    import builtins
    builtins.list = lambda x: 'list({})'.format(x)
    builtins.__ = eager(builtins.list)
    generated_code = __(range(5))
    assert generated_code == 'list(range(5))', generated_code


# Generated at 2022-06-25 23:03:52.644242
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """    int_0 = -1976
    str_0 = get_source(int_0)
"""



# Generated at 2022-06-25 23:03:56.333496
# Unit test for function get_source
def test_get_source():
    test_case_0()
    try:
        int_1 = 1 / 0
        str_1 = get_source(int_1)
    except ZeroDivisionError:
        print('ZeroDivisionError')


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:03:58.313304
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == inspect.getsource(test_case_0)


# Generated at 2022-06-25 23:04:00.748414
# Unit test for function get_source
def test_get_source():
    d = {'i_0': -1976}
    d_0 = get_source(d)
    assert d_0 == '{i_0: -1976}'
    
    

# Generated at 2022-06-25 23:04:03.736524
# Unit test for function get_source
def test_get_source():
    for i in range(10000):
        test_case_0()
    print(settings.keyword_value_sep, 'get_source', settings.keyword_value_sep, 'PASSED')

# End of unit test


# Generated at 2022-06-25 23:04:05.532772
# Unit test for function eager
def test_eager():
    test_list = [10, 3, 6, 90, -3]
    assert test_list == eager(sorted)(test_list)

# Generated at 2022-06-25 23:04:10.841050
# Unit test for function get_source
def test_get_source():
    def test_case_0():
        def function_0():
            local_0 = 1
        expected_0 = 'def function_0():\n' \
                     '    local_0 = 1'
        actual_0 = get_source(function_0)
        assert expected_0 == actual_0



# Generated at 2022-06-25 23:04:12.050599
# Unit test for function get_source
def test_get_source():
    try:
        get_source(test_case_0)
    except NotImplementedError:
        return

# Generated at 2022-06-25 23:04:14.272122
# Unit test for function debug
def test_debug():
    func_debug = debug
    t = lambda: 'hello'
    func_debug(t)



# Generated at 2022-06-25 23:04:19.220605
# Unit test for function get_source
def test_get_source():
    from inspect import getsource
    from functools import wraps
    @wraps(test_get_source)
    def wrapper():
        pass
    test_get_source_source = """\
    from inspect import getsource
    from functools import wraps
    @wraps(test_get_source)
    def wrapper():
        pass"""
    assert(test_get_source_source == getsource(test_get_source))


# Generated at 2022-06-25 23:04:22.898314
# Unit test for function debug
def test_debug():
    list_0 = None
    callable_0 = eager(list_0)
    str_0 = get_source(callable_0)
    debug(lambda :"Generating debug info for wrapper function 'eager':\n{}".format(str_0))


# Generated at 2022-06-25 23:04:24.425683
# Unit test for function get_source
def test_get_source():
    assert getattr(test_case_0, 'source') == 'test_case_0()'



# Generated at 2022-06-25 23:04:27.057819
# Unit test for function debug
def test_debug():
    def _test():
        def test_function():
            pass
        function_0 = debug(test_function)
        function_0()

    _test()



# Generated at 2022-06-25 23:04:28.915388
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'list_0 = None\ncallable_0 = eager(list_0)'



# Generated at 2022-06-25 23:04:29.530411
# Unit test for function debug
def test_debug():
    debug(lambda : 'Function called')
    warn('Function called')

# Generated at 2022-06-25 23:04:30.661267
# Unit test for function debug
def test_debug():
    var_0 = get_source(test_case_0)
    debug(lambda: var_0)
    debug(lambda: get_source(test_case_0))


# Generated at 2022-06-25 23:04:38.695526
# Unit test for function get_source
def test_get_source():
    # Get source of decorated list_0
    source = get_source(list_0)

    # Test if the source is equal to expected
    assert source == '@eager\n    def list_0(*args: Any, **kwargs: Any) -> List[T]:\n        return list(list_0(*args, **kwargs))'


# Generated at 2022-06-25 23:04:43.444345
# Unit test for function debug
def test_debug():
    import pytest
    import sys
    import io

    error_message = io.StringIO()
    sys.stderr = error_message

    def some_source():
        return 'test'

    debug(some_source)

    assert 'test' in error_message.getvalue()
    assert settings.debug == True

    error_message.close()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-25 23:04:49.355477
# Unit test for function get_source
def test_get_source():
  with pytest.raises(TypeError):
    get_source(test_get_source)


# Generated at 2022-06-25 23:04:52.947335
# Unit test for function debug
def test_debug():
    msg = 'test_msg'
    
    try:
        debug(lambda : msg)
        raise AssertionError('Expected AssertionError')
    except AssertionError:
        pass
    
    debug(lambda : msg)



# Generated at 2022-06-25 23:04:56.928732
# Unit test for function debug
def test_debug():
    var = 0

    def get_message():
        nonlocal var
        var += 1
        return str(var)

    assert settings.debug is False
    debug(get_message)
    settings.debug = True
    debug(get_message)
    settings.debug = False
    debug(get_message)
    assert var == 2


# Generated at 2022-06-25 23:04:58.216906
# Unit test for function get_source
def test_get_source():
    assert get_source(eager)


# Generated at 2022-06-25 23:05:00.705355
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    code = get_source(test_function)
    assert code == 'test_function():\n    pass'


# Generated at 2022-06-25 23:05:04.375988
# Unit test for function debug
def test_debug():
    from ..conf import settings
    old_value = settings.debug
    try:
        settings.debug = True
        debug_function_0 = debug(print)
        settings.debug = False
        debug_function_1 = debug(print)
    finally:
        settings.debug = old_value



# Generated at 2022-06-25 23:05:09.055786
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '    list_0 = None\n    callable_0 = eager(list_0)'


# Generated at 2022-06-25 23:05:12.890567
# Unit test for function debug
def test_debug():
    assert(settings.debug)

    # Unit test for function debug
    def test_debug_0():
        debug(lambda: 'test_string_0')

    test_debug_0()


# Generated at 2022-06-25 23:05:17.374058
# Unit test for function debug
def test_debug():
    debug(None)

# Generated at 2022-06-25 23:05:24.937836
# Unit test for function get_source
def test_get_source():
    assert get_source(get_source) == 'def get_source(fn: Callable[..., Any]) -> str:\n    """Returns source code of the function."""\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)\n'

# Generated at 2022-06-25 23:05:30.180479
# Unit test for function get_source
def test_get_source():
    def test_0():
        list_0 = _py_backwards_list_0
        assert len(list_0) == 0
    assert get_source(test_0) == 'list_0 = _py_backwards_list_0\nassert len(list_0) == 0\n'


if __name__ == '__main__':
    test_case_0()
# test_get_source()

# Generated at 2022-06-25 23:05:31.346688
# Unit test for function debug
def test_debug():
    callable_1 = get_message()
    debug(callable_1)



# Generated at 2022-06-25 23:05:35.869623
# Unit test for function debug
def test_debug():
    callable_0 = debug
    def def0():
        try:
            def def1():
                return def0
            def def2():
                return def1
            callable_1 = def2
            callable_0(callable_1)
        except Exception:
            pass
        else:
            pass
    callable_0(def0)

# Generated at 2022-06-25 23:05:37.116804
# Unit test for function debug
def test_debug():
    with pytest.raises(AttributeError):
        debug(test_case_0)

# Generated at 2022-06-25 23:05:44.722385
# Unit test for function debug
def test_debug():
    from io import StringIO
    from sys import stderr
    from .contextmanagers import redirect_stderr

    message = '0'

    # Setup
    debug(lambda: message)

    # Test
    assert_result = ''
    with redirect_stderr(StringIO()) as redirected_stderr:
        assert_result = stderr.write(message)
        assert 'Debug: {}\n'.format(message) == assert_result

    # Teardown
    debug(lambda: message)



# Generated at 2022-06-25 23:05:50.582607
# Unit test for function eager
def test_eager():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'object is not callable' in str(excinfo.value)

# Generated at 2022-06-25 23:05:53.196705
# Unit test for function debug
def test_debug():
    try:
        debug("message")
    except NameError:
        try:
            print("debug function definition incorrect")
        except NameError:
            print("debug function defintion incorrect")



# Generated at 2022-06-25 23:05:57.044775
# Unit test for function debug
def test_debug():
    # No exception should be raised
    try:
        debug((lambda : 'test_debug'))
    except Exception as e:
        print(e.message)
    result = 'result'
    assert result is not None


# Generated at 2022-06-25 23:06:04.047483
# Unit test for function eager
def test_eager():
    callable_0 = list
    callable_0 = eager(callable_0)
    assert callable_0 == [], \
        'Expected [], but got: %s' % (callable_0,)


# Generated at 2022-06-25 23:06:09.722345
# Unit test for function get_source
def test_get_source():
    assert test_case_0.__code__.co_firstlineno + 1 == get_source(test_case_0).find('test_case_0()')
    assert test_case_0.__code__.co_firstlineno + 3 == get_source(test_case_0).find('list_0 = None')
    assert test_case_0.__code__.co_firstlineno + 4 == get_source(test_case_0).find('callable_0 = eager(list_0)')

# Generated at 2022-06-25 23:06:11.505245
# Unit test for function eager
def test_eager():
    func = eager(list)
    result = func([1, 2, 3])
    assert isinstance(result, list)
    assert all(isinstance(v, int) for v in result)
    assert list(result) == [1, 2, 3]



# Generated at 2022-06-25 23:06:12.400968
# Unit test for function eager
def test_eager():
    from .test_eager import test_eager
    test_eager()
    return


# Generated at 2022-06-25 23:06:17.202285
# Unit test for function debug
def test_debug():
    from . import _debug
    from ..conf import _settings

    status_0 = _settings.debug
    _settings.debug = True
    try:
        _debug.debug(lambda: 'message_0')
        _debug.debug(lambda: None)
        _settings.debug = False
        _debug.debug(lambda: 'message_1')
    finally:
        _settings.debug = status_0


# Generated at 2022-06-25 23:06:22.212418
# Unit test for function debug
def test_debug():
    import sys
    import io
    stderr = sys.stderr
    sys.stderr = io.StringIO()
    debug(messages.debug('debug message'))
    assert sys.stderr.getvalue() == '\x1b[1m\x1b[34mdebug message\x1b[39;49;00m\n'
    sys.stderr = stderr


# Generated at 2022-06-25 23:06:26.331771
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''
@wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> List[T]:
        return list(fn(*args, **kwargs))

    return wrapped
'''


# Generated at 2022-06-25 23:06:28.006305
# Unit test for function eager
def test_eager():
    import pytest
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-25 23:06:28.519263
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:06:30.566218
# Unit test for function debug
def test_debug():
    import sys
    import os
    def foo():
            return 'hello'
    buf = sys.stderr
    sys.stderr = open(os.devnull, 'w+')
    try:
        debug(foo)
    finally:
        sys.stderr.close()
        sys.stderr = buf


# Generated at 2022-06-25 23:06:45.877798
# Unit test for function debug
def test_debug():
    old_debug = settings.debug
    old_sys_stderr = sys.stderr
    settings.debug = True
    try:
        import io
        sys.stderr = io.StringIO('', 'w')
        # Calling debug
        debug(lambda: 'test')
        assert sys.stderr.getvalue().strip() == 'DEBUG: test'
    finally:
        sys.stderr = old_sys_stderr
        settings.debug = old_debug


# Generated at 2022-06-25 23:06:48.085066
# Unit test for function eager
def test_eager():
    message = 'empty'
    try:
        test_case_0()
    except Exception as e:
        message = str(e)
    finally:
        assert message == 'empty', message

# Generated at 2022-06-25 23:06:49.175500
# Unit test for function eager
def test_eager():
    test_case_0()


# Compilation Check of function eager

# Generated at 2022-06-25 23:06:50.805960
# Unit test for function debug
def test_debug():
    try:
        debug(lambda: str())
        assert False, 'Failed to catch exception'
    except TypeError:
        pass


# Generated at 2022-06-25 23:06:52.591719
# Unit test for function debug
def test_debug():
    if '_py_backwards_debug' in globals().keys():
        get_message = lambda: 'Test debug'
        debug(get_message)


# Generated at 2022-06-25 23:06:53.533600
# Unit test for function debug
def test_debug():
    assert debug(lambda: "test") == None

# Generated at 2022-06-25 23:06:55.695399
# Unit test for function debug
def test_debug():
    variable_0 = 5
    debug(lambda: variable_0)

    # Unit test for function get_source
    def lambda_0() -> str:
        variable_1 = 'test'
        return variable_1



# Generated at 2022-06-25 23:06:59.247081
# Unit test for function eager
def test_eager():
    """
    Checks that eager will return a list if given list
    """
    test_case_0()


if __name__ == '__main__':
    import pytest
    errno = pytest.main(['-x', __file__])
    sys.exit(errno)

# Generated at 2022-06-25 23:07:01.028714
# Unit test for function eager
def test_eager():
    list_0 = None
    callable_0 = eager(list_0)
    int_0 = callable_0


# Generated at 2022-06-25 23:07:01.825960
# Unit test for function eager
def test_eager():
    test_case_0()



# Generated at 2022-06-25 23:07:28.590706
# Unit test for function get_source
def test_get_source():
    import inspect

    def test_function(a: int, b: int = 2) -> str:
        return '{}_{}'.format(a, b)


# Generated at 2022-06-25 23:07:32.499449
# Unit test for function debug
def test_debug():
    try:
        import re
        import sys
        def get_message():
            return 'test'
        debug(get_message)
    except AssertionError:
        print("AssertionError raised when sys.stderr is None")


# Generated at 2022-06-25 23:07:36.052045
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "    list_0 = None\n    callable_0 = eager(list_0)\n"

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 23:07:38.442455
# Unit test for function get_source
def test_get_source():
    if get_source(test_case_0) == '\n'.join([
        'eager(list_0)',
    ]):
        return 0
    else:
        return 1


# Generated at 2022-06-25 23:07:42.505355
# Unit test for function get_source
def test_get_source():
    def func_0():
        var_0 = 0
        var_1 = 1
        print((var_0, var_1))
    expected = 'var_0 = 0\nvar_1 = 1\nprint((var_0, var_1))'
    result = get_source(func_0)
    assert result == expected


# Generated at 2022-06-25 23:07:46.894797
# Unit test for function debug
def test_debug():
    test_case_0()


if __name__ == '__main__':
    print(test_debug())

# Generated at 2022-06-25 23:07:52.014125
# Unit test for function get_source
def test_get_source():
    def fn_0() -> int:
        return 0
    def fn_1():
        return 1
    def fn_2(arg_0, arg_1='a', *args, kwarg_0, kwarg_1=1, **kwargs):
        pass

    assert(get_source(fn_0) == 'return 0')
    assert(get_source(fn_1) == 'return 1')
    assert(get_source(fn_2) == "pass")

    def fn_3():
        if 1:
            return 1
        elif 2:
            return 2
        else:
            return 3


# Generated at 2022-06-25 23:08:01.092332
# Unit test for function get_source
def test_get_source():
    import ast
    import builtins
    import inspect
    import sys
    import _ast

    def compare(actual: object, expected: object) -> None:
        assert actual == expected, '{} != {}'.format(actual, expected)

    with open(sys.argv[1], 'r') as tests_file:
        tests_code = tests_file.read()

    tests = {}

    def save_test(test: Callable[[], None], name: str) -> Callable[[], None]:
        tests[name] = test
        return test

    exec(tests_code, {
        'compare': compare,
        'save_test': save_test,
        'get_source': get_source
    })


# Generated at 2022-06-25 23:08:06.403395
# Unit test for function debug
def test_debug():
    msg = 'Test message'
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import sys
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stderr = StringIO()
    debug(lambda: msg)
    res = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stdout = stdout
    sys.stderr = stderr
    assert msg in res


# Generated at 2022-06-25 23:08:08.967262
# Unit test for function get_source
def test_get_source():
    expected_value = '\n'.join([
        "def test_case_0():",
        "    list_0 = None",
        "    callable_0 = eager(list_0)"
    ])
    assert get_source(test_case_0) == expected_value

# Generated at 2022-06-25 23:08:40.137578
# Unit test for function get_source
def test_get_source():
    def function_0():

        def function_1():
            return 3

        return function_1()

    source_0 = get_source(function_0)
    source_1 = ' ' * 4 + 'def function_1():'
    source_2 = ' ' * 8 + 'return 3'
    assert source_0.split('\n')[-3] == source_1
    assert source_0.split('\n')[-2] == source_2


# Generated at 2022-06-25 23:08:40.849342
# Unit test for function debug
def test_debug():
    debug("test")


# Generated at 2022-06-25 23:08:45.825462
# Unit test for function get_source
def test_get_source():
    import os
    from . import test_utils
    from .test_utils import get_test_source
    from .test_utils import test_dir
    test_dir = os.path.dirname(os.path.abspath(__file__))

    def function_0():
        pass

    expected_source = get_test_source('test_utils.py', 'function_0')
    actual_source = test_utils.get_source(function_0)
    assert expected_source == actual_source

# Generated at 2022-06-25 23:08:47.597647
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'list_0 = None\ncallable_0 = eager(list_0)'

# Generated at 2022-06-25 23:08:50.165673
# Unit test for function eager
def test_eager():
    list_0 = [2, 3, -1, 5]
    callable_0 = eager(list_0)
    assert callable_0 == [2, 3, -1, 5], 'Assertion failed'



# Generated at 2022-06-25 23:08:56.308374
# Unit test for function eager
def test_eager():
    # Call eager
    list_1 = [1, 2, 3]
    try:
        callable_1 = eager(list_1)
    except UnboundLocalError as e:
        pytest.fail('Function eager raised UnboundLocalError "' + str(e) + '"')
    else:
        assert callable_1 == [1, 2, 3]

    list_2 = None
    try:
        callable_2 = eager(list_2)
    except UnboundLocalError as e:
        pytest.fail('Function eager raised UnboundLocalError "' + str(e) + '"')
    else:
        assert callable_2 == list_2



# Generated at 2022-06-25 23:08:58.214886
# Unit test for function eager
def test_eager():
    try:
        callable_0 = eager(list_0)
    except NameError:
        print('Error raised in function eager_0')


# Generated at 2022-06-25 23:09:00.001380
# Unit test for function debug
def test_debug():
    settings.debug = True
    get_message = lambda: 'test_debug message'
    debug(get_message)
    assert settings.debug is True
    assert True


# Generated at 2022-06-25 23:09:02.542502
# Unit test for function debug
def test_debug():
    expected_arg_1: Callable[[], str] = lambda : 'a'
    actual_result: None = debug(expected_arg_1)
    expected_result: None = None
    assert actual_result == expected_result

# Generated at 2022-06-25 23:09:03.548939
# Unit test for function debug
def test_debug():
    callable_0 = debug
    callable_0()


# Generated at 2022-06-25 23:09:30.233904
# Unit test for function debug
def test_debug():
    # Call the function
    debug(lambda : 'debug info')
    # Check if the returned result is correct
    assert True



# Generated at 2022-06-25 23:09:31.952437
# Unit test for function eager
def test_eager():
    try:
        list_0 = None
        callable_0 = eager(list_0)

        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 23:09:36.029363
# Unit test for function eager
def test_eager():
    try:
        import pytest
        from ..types import FunctionType
        assert isinstance(eager, FunctionType)
        assert eager(list_0) == list_0
    except NameError:
        try:
            assert list_0 is None
            test_case_0()
        except NameError:
            pytest.skip('Unable to run test, please report as bug.')

# Generated at 2022-06-25 23:09:37.612106
# Unit test for function eager
def test_eager():
    list_0 = [1, 2, 3]
    callable_0 = eager(list_0)
    assert(list_0 == callable_0)


# Generated at 2022-06-25 23:09:39.122089
# Unit test for function eager
def test_eager():
    # No exception is expected
    try:
        test_case_0()
    except Exception as e:
        raise(e)

# Generated at 2022-06-25 23:09:40.191968
# Unit test for function debug
def test_debug():
    debug(lambda: 'Unreachable code')



# Generated at 2022-06-25 23:09:47.771080
# Unit test for function eager
def test_eager():
    # Create an instance of the class 'VariablesGenerator'
    var_generator_0 = VariablesGenerator()
    # Call function 'generate' from class 'VariablesGenerator'
    
    callable_0 = var_generator_0.generate('list_0')
    # Save the source code of the function
    source_code_eager = get_source(eager)
    # Call function 'generate' from class 'VariablesGenerator'
    
    list_0 = var_generator_0.generate('callable_1')
    # Call function 'eager'
    eager(callable_0)
    # Assert that the function return the expected value
    assert callable_0 == list_0, 'AssertionError'


# Generated at 2022-06-25 23:09:48.363947
# Unit test for function debug
def test_debug():
    # Call function
    debug(test_case_0)

# Generated at 2022-06-25 23:09:50.453639
# Unit test for function eager
def test_eager():
    try:
        try:
            # Statement(s) under test
            test_case_0()
        except Exception as e:
            print(e)
    finally:
        VariablesGenerator._counter = 0

# Generated at 2022-06-25 23:09:53.011535
# Unit test for function eager
def test_eager():
    try:
        # Call function get_source
        get_source(eager)
        test_case_0()
    except Exception as e:
        warn(getattr(e, 'message', str(e)))

# Generated at 2022-06-25 23:10:54.520639
# Unit test for function debug
def test_debug():
    assert(debug(messages.debug('Debug Test')) is None)



# Generated at 2022-06-25 23:10:55.180421
# Unit test for function debug
def test_debug():
    debug(lambda: 'This is a debug message')

# Generated at 2022-06-25 23:11:05.328823
# Unit test for function debug
def test_debug():
    messages_warn = messages.warn
    messages_debug = messages.debug
    try:
        messages.warn = mocked_warn = MagicMock()
        messages.debug = mocked_debug = MagicMock()
        settings.debug = True
        debug(lambda: 'xyz')
        mocked_debug.assert_called_once_with('xyz')
        mocked_debug.reset_mock()
        settings.debug = False
        debug(lambda: 'xyz')
        mocked_debug.assert_not_called()
    finally:
        messages.warn = messages_warn
        messages.debug = messages_debug



# Generated at 2022-06-25 23:11:09.461716
# Unit test for function get_source
def test_get_source():
    # Calling get_source
    fn = message = eager = get_source = max = None
    actual = get_source(fn)
    # Testing if message is equal to variable message
    fn = message = eager = get_source = max = None
    expected = message
    assert expected == actual
    # Testing if max is equal to variable max
    fn = message = eager = get_source = max = None
    expected = max
    assert expected == actual


# Generated at 2022-06-25 23:11:11.088527
# Unit test for function eager
def test_eager():
    # local variable 'list_0' is assigned but never used
    # local variable 'callable_0' is assigned but never used
    pass

# Generated at 2022-06-25 23:11:13.648194
# Unit test for function debug
def test_debug():
    messages.debug = '{}'
    debug(lambda: 'x')
    print()
    messages.debug = '{}'
    settings.debug = True
    debug(lambda: 'x')


# Generated at 2022-06-25 23:11:17.042653
# Unit test for function get_source
def test_get_source():
    def fn():
        return 'abc'

    def fn_0():
        return 'abc'

    def fn_1():
        return 'abc'

    assert get_source(fn) == "return 'abc'"
    assert get_source(fn_0) == "return 'abc'"
    assert get_source(fn_1) == "return 'abc'"


# Generated at 2022-06-25 23:11:18.833363
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda: "debug message")
    settings.debug = False
    debug(lambda: "debug message")


# Generated at 2022-06-25 23:11:20.930411
# Unit test for function eager
def test_eager():
    for _ in range(100):
        try:
            test_case_0()
        except TypeError:
            pass
    else:
        raise AssertionError('Wrong function behaviour')



# Generated at 2022-06-25 23:11:27.493485
# Unit test for function get_source
def test_get_source():
    def fn():
        pass
    assert get_source(fn) == 'pass'
    assert get_source(test_get_source) == 'def fn():' \
                                          '\n    pass\n' \
                                          '\n\n' \
                                          'assert get_source(fn) == \'pass\'' \
                                          '\nassert get_source(test_get_source) == \'def fn():' \
                                          '\n    pass\n' \
                                          '\n\n\'\n'

# Testing methods

# Generated at 2022-06-25 23:12:34.581838
# Unit test for function eager
def test_eager():
    print("\n# Unit test for function eager")
    # exception case
    if settings.load_test_cases:
        execute_test_case(test_case_0, 'eager')
    else:
        print("\n# Test cases loaded : {}".format(settings.load_test_cases))



# Generated at 2022-06-25 23:12:35.190767
# Unit test for function debug
def test_debug():
    debug(lambda: 'abc')


# Generated at 2022-06-25 23:12:36.728221
# Unit test for function debug
def test_debug():
    @debug
    def get_message():
        return 'message for test'

    assert get_message() == 'message for test'


# Generated at 2022-06-25 23:12:42.644377
# Unit test for function eager
def test_eager():
    """ Tests eager function with examples from docstrings"""

    from .collection import if_
    from .number import add
    from .string import sha256

    list_1 = [1, 2, 3, 4]
    list_2 = [1, 2, 3, 4]
    list_3 = [5, 6, 7, 8]
    fn_callable = list.__getitem__
    fn_eager = eager(fn_callable)

    assert list_1 == fn_eager(list_1, 0)
    assert list_1 == fn_eager(list_2, 0)
    assert list_3 == fn_eager(list_3, 0)

    fn = add
    assert list(fn(list_1, list_1)) == fn_eager(list_1, list_1)
    assert list

# Generated at 2022-06-25 23:12:45.538030
# Unit test for function get_source
def test_get_source():
    func_0 = int
    expected_0 = getsource(int)
    actual_0 = get_source(func_0)
    if expected_0 != actual_0:
        raise AssertionError(
            'expected: {!r}; got: {!r}'
            .format(expected_0, actual_0)
        )



# Generated at 2022-06-25 23:12:51.768525
# Unit test for function get_source
def test_get_source():
    import os
    import tempfile
    from importlib import import_module, reload
    from inspect import getsource
    from sys import stdout

    def test_emitter(message: str) -> str:
        """Just prints the message."""
        print(message, file=stdout)

    def test_get_source(module_name: str) -> bool:
        """Returns True if the function get_source can process module_name."""
        return getsource(import_module(module_name).test_emitter) == 'def test_emitter(message):\n' \
                                                                    '    """Just prints the message."""\n' \
                                                                    '    print(message, file=stdout)\n'


# Generated at 2022-06-25 23:12:55.046239
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        return a + b

    assert get_source(test_function) == textwrap.dedent('''
    def test_function(a, b):
        return a + b
    ''').strip()

# Generated at 2022-06-25 23:13:00.423936
# Unit test for function get_source

# Generated at 2022-06-25 23:13:00.993979
# Unit test for function get_source
def test_get_source():
    test_case_0()


# Generated at 2022-06-25 23:13:02.775694
# Unit test for function get_source
def test_get_source():
    source_code = '"""Returns source code of the function."""'
    code = get_source(test_case_0)
    if source_code in code:
        assert True
    else:
        assert False
