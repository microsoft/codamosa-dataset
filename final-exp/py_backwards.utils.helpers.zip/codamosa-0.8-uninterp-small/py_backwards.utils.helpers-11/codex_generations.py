

# Generated at 2022-06-25 23:03:41.874930
# Unit test for function eager
def test_eager():
    def test_eager_1():
        @eager
        def test_eager_1_0() -> List[None]:
            if False:
                yield None
            elif False:
                yield None
            elif False:
                yield None
            elif False:
                yield None
            else:
                yield None

        return test_eager_1_0()

    test_eager_1()


# Generated at 2022-06-25 23:03:47.820266
# Unit test for function get_source
def test_get_source():
    variables_generator_0 = VariablesGenerator()
    # get_source(fn: Callable[..., Any]) -> str
    def get_source(fn: Callable[..., Any]) -> str:
        source_lines = getsource(fn).split('\n')
        padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
        return '\n'.join(line[padding:] for line in source_lines)



# Generated at 2022-06-25 23:03:56.417752
# Unit test for function eager
def test_eager():
    def test_eager_0(fn_0: Callable[..., Iterable[T]]) -> Callable[..., List[T]]:
        @wraps(fn_0)
        def fn_0(*args_0: Any, **kwargs_0: Any) -> List[T]:
            return list(fn_0(*args_0, **kwargs_0))
     
    def test_eager_1(fn_0: Callable[..., Iterable[T]]) -> Callable[..., List[T]]:
        @wraps(fn_0)
        def fn_0(*args_0: Any, **kwargs_0: Any) -> List[T]:
            return list(fn_0(*args_0, **kwargs_0))
     

# Generated at 2022-06-25 23:03:59.346909
# Unit test for function get_source
def test_get_source():
    def test_function(a):
        return a + 1

    assert get_source(test_function) == 'def test_function(a):\n    return a + 1'


# Generated at 2022-06-25 23:04:01.339747
# Unit test for function get_source
def test_get_source():
    def f():
        pass
    assert get_source(f) == 'def f():\n    pass'


# Generated at 2022-06-25 23:04:03.185517
# Unit test for function get_source
def test_get_source():
    s = get_source(test_case_0)
    assert s == """    variables_generator_0 = VariablesGenerator()""", s


# Generated at 2022-06-25 23:04:11.140377
# Unit test for function get_source
def test_get_source():
    if settings.debug:
        print(messages.debug('Start testing function get_source'))
    if settings.debug:
        print('  Testing normal case')
    assert get_source(test_case_0) == 'variables_generator_0 = VariablesGenerator()'
    if settings.debug:
        print('  Testing abnormal case')
    try:
        get_source(None)
    except TypeError:
        pass
    except:
        raise AssertionError('Error #1\nExpected TypeError\nReceived {}'.format(sys.exc_info()[0].__name__))
    else:
        raise AssertionError('Error #2\nExpected TypeError\nReceived {}'.format('Nothing'))



# Generated at 2022-06-25 23:04:12.661813
# Unit test for function eager
def test_eager():
    assert eager(list)([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-25 23:04:22.334441
# Unit test for function debug
def test_debug():
    def test_function_0(argument_0):
        print(argument_0)
    print_tuple = print
    print_tuple_0 = print
    print_tuple_1 = print
    print_tuple_2 = print
    print_tuple_3 = print
    print_tuple_4 = print
    print_tuple_6 = print
    print_tuple_7 = print
    print_tuple_8 = print
    print_tuple_9 = print
    def test_function_1(argument_0):
        print(argument_0)
    def test_function_3(argument_0):
        print(argument_0)
    def test_function_4(argument_0):
        print(argument_0)
    print_tuple_5 = print
    print_tuple_10

# Generated at 2022-06-25 23:04:24.585705
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "def test_case_0():\n    variables_generator_0 = VariablesGenerator()\n"

# Generated at 2022-06-25 23:04:28.188804
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == "complex_0 = None"


# Main function

# Generated at 2022-06-25 23:04:32.058204
# Unit test for function debug
def test_debug():
    test_message = "test message"
    output = StringIO()
    def get_message():
        return test_message
    with contextlib.redirect_stderr(output):
        debug(get_message)
    assert test_message in output.getvalue()

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 23:04:33.561671
# Unit test for function debug
def test_debug():
    message = 'test_message'

    def get_message():
        return message

    debug(get_message)


# Generated at 2022-06-25 23:04:35.616658
# Unit test for function get_source
def test_get_source():
    fn = test_case_0
    assert get_source(fn) == """    complex_0 = None
    str_0 = get_source(complex_0)"""



# Generated at 2022-06-25 23:04:38.037384
# Unit test for function eager
def test_eager():
    str_0 = eager(test_case_0)()
test_eager()



# Generated at 2022-06-25 23:04:38.989381
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == None



# Generated at 2022-06-25 23:04:39.839295
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:04:40.367544
# Unit test for function debug
def test_debug():
    assert True

# Generated at 2022-06-25 23:04:42.146024
# Unit test for function get_source
def test_get_source():
    print('Testing get_source')
    test_case_0()

# Run the test cases
#test_get_source()

# Generated at 2022-06-25 23:04:43.320721
# Unit test for function eager
def test_eager():
    test_case_0()

test_eager()

# Generated at 2022-06-25 23:04:51.051268
# Unit test for function get_source
def test_get_source():
    # Prepare
    def dummy_function():
        pass
    # Execute
    actual = get_source(dummy_function)
    # Verify
    assert(actual) == 'def dummy_function():\n    pass'


# Generated at 2022-06-25 23:04:52.791574
# Unit test for function debug
def test_debug():
    try:
        messages.debug("aa")
    except:
        fail("Expected no exception")



# Generated at 2022-06-25 23:04:55.543929
# Unit test for function get_source
def test_get_source():
    source_code_0 = get_source(test_case_0)
    assert source_code_0 is not None


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:05:03.910853
# Unit test for function debug
def test_debug():
    try:
        _ = debug
    except NameError:
        print("NameError: global name 'debug' is not defined")
    else:
        try:
            assert False
        except AssertionError:
            print("AssertionError: False is not true")
        else:
            try:
                debug(get_source)
            except NameError:
                print("NameError: global name 'get_source' is not defined")
            except TypeError:
                print("TypeError: argument of type 'function' is not iterable")
            else:
                print("Passed")


# Generated at 2022-06-25 23:05:04.947983
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == 'None'

# Generated at 2022-06-25 23:05:07.999187
# Unit test for function eager
def test_eager():
    assert callable(eager)


# Generated at 2022-06-25 23:05:09.401334
# Unit test for function eager
def test_eager():
    assert callable(eager)

# Generated at 2022-06-25 23:05:14.738621
# Unit test for function get_source
def test_get_source():
    _get_source_test_cases = [
        (test_case_0, "None"),
    ]
    for test_case, str_1 in _get_source_test_cases:
        test_case()
        assert str_0 == str_1, \
            "Function returned wrong result for function '{}'.".format(test_case.__name__)

# Generated at 2022-06-25 23:05:17.144003
# Unit test for function eager
def test_eager():
    def f_0():
        for i in range(10):
            yield i
    list_0 = eager(f_0)()


# Generated at 2022-06-25 23:05:18.840003
# Unit test for function get_source
def test_get_source():
    test_case_0()


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:05:26.403449
# Unit test for function get_source
def test_get_source():
    expected = """
    complex_0 = None
    str_0 = get_source(complex_0)
    """
    assert test_case_0() == expected

# Generated at 2022-06-25 23:05:27.312184
# Unit test for function get_source
def test_get_source():
    test_case_0()


# Generated at 2022-06-25 23:05:29.460315
# Unit test for function get_source
def test_get_source():
    # The simplest case with two variables
    assert test_case_0() == "complex_0 = None\
    \nstr_0 = get_source(complex_0)"

# Generated at 2022-06-25 23:05:30.927268
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')
    t = test_case_0()
    assert t is None



# Generated at 2022-06-25 23:05:32.398447
# Unit test for function debug
def test_debug():
    debug(lambda: 'test')

# Test for function test_case_0

# Generated at 2022-06-25 23:05:33.763793
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == "complex_0 = None\n"

# Generated at 2022-06-25 23:05:36.439505
# Unit test for function eager
def test_eager():
    @eager
    def gen(i: int) -> Iterable[int]:
        for j in range(i):
            yield j + 1

    assert gen(3) == [1, 2, 3]

# Generated at 2022-06-25 23:05:40.112592
# Unit test for function debug
def test_debug():
    print('Start to test debug')
    context = {}
    context['debug'] = True
    messages._context.update(context)
    test_debug_0()
    test_debug_1()
    context = {}
    context['debug'] = False
    messages._context.update(context)

# Generated at 2022-06-25 23:05:40.945568
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == 'None'

# Generated at 2022-06-25 23:05:42.120927
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == None


# Generated at 2022-06-25 23:05:50.991307
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:05:53.235064
# Unit test for function get_source
def test_get_source():
    # test for case: complex_0
    complex_0 = None
    str_0 = get_source(complex_0)
    assert(str_0 == '')

# Generated at 2022-06-25 23:06:02.671836
# Unit test for function eager
def test_eager():
    def test_eager_0():
        def test_eager_0_0(a, b):
            yield a
            yield 2
            yield b

        eager_0 = eager(test_eager_0_0)
        eager_1_args = (1, 2)
        eager_1_kwargs = {}
        eager_1_result = eager_0(*eager_1_args, **eager_1_kwargs)
        assert len(eager_1_result) == 3
        assert eager_1_result[0] == 1
        assert eager_1_result[1] == 2
        assert eager_1_result[2] == 2
        assert eager_1_result == [1, 2, 2]


# Generated at 2022-06-25 23:06:06.280493
# Unit test for function debug
def test_debug():
    called = [False]

    def get_message() -> str:
        called[0] = True
        return 'test_debug_0'

    debug(get_message)
    assert called[0] == False

    settings.debug = True

    debug(get_message)
    assert called[0] == True



# Generated at 2022-06-25 23:06:07.220829
# Unit test for function eager
def test_eager():
    assert eager(test_case_0) == None

# Generated at 2022-06-25 23:06:15.693689
# Unit test for function debug
def test_debug():
    print_stderr_0 = open('stderr_0', 'w')
    print_stderr_0.truncate()
    print_stderr_0.close()
    print_stderr_0 = open('stderr_0', 'r')

    settings.debug = True
    debug_0 = "Debug message"
    debug_1 = lambda: debug_0

    sys.stderr = print_stderr_0
    debug(debug_1)
    print_stderr_0.seek(0)
    assert print_stderr_0.readline() == 'py-backwards: Debug: Debug message\n'
    settings.debug = False
    print_stderr_0.close()


# Generated at 2022-06-25 23:06:16.734827
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == 'None'



# Generated at 2022-06-25 23:06:18.102416
# Unit test for function debug
def test_debug():
    # Make sure that the following code should not throw error.
    debug(lambda: get_source(complex))

# Generated at 2022-06-25 23:06:20.010091
# Unit test for function eager
def test_eager():
    assert eager(eager)(range(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-25 23:06:20.853190
# Unit test for function get_source
def test_get_source():
    assert str_0 == "multiplicand = 3"

# Generated at 2022-06-25 23:06:31.097882
# Unit test for function eager
def test_eager():
    test_eager_0()
    test_eager_1()
    test_eager_2()


# Generated at 2022-06-25 23:06:32.892234
# Unit test for function debug
def test_debug():
    message = 'Hello, World!'
    debug(lambda: message)
    debug(lambda: 'Hello, World!')
    debug(lambda: 'Hello, {}!'.format('World'))



# Generated at 2022-06-25 23:06:34.732458
# Unit test for function debug
def test_debug():
    get_message = lambda : 'testing'
    debug.result = debug(get_message)


# Generated at 2022-06-25 23:06:35.810236
# Unit test for function get_source
def test_get_source():
    try:
        assert False
    except:
        assert True


# Generated at 2022-06-25 23:06:37.948697
# Unit test for function eager
def test_eager():
    assert eager([1,2,3]) == [1,2,3]


# Generated at 2022-06-25 23:06:39.506118
# Unit test for function debug
def test_debug():
    assert len(repr(tuple())) == 2
    assert True


# Generated at 2022-06-25 23:06:40.357918
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:06:41.262905
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == "None"

# Generated at 2022-06-25 23:06:43.003637
# Unit test for function get_source
def test_get_source():
    assert str_0 == 'def complex_0():\n    # Comment\n    if True:\n        return True'



# Generated at 2022-06-25 23:06:45.849185
# Unit test for function eager
def test_eager():
    assert eager(list)(range(20)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

# Generated at 2022-06-25 23:07:06.327448
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:07:09.602778
# Unit test for function get_source
def test_get_source():
    str_0 = get_source(test_case_0)
    str_1 = 'def test_case_0():\n    complex_0 = None\n    str_0 = get_source(complex_0)\n'
    assert (str_0 == str_1)

# Generated at 2022-06-25 23:07:11.688959
# Unit test for function eager
def test_eager():
    @eager
    def complex(a):
        yield from range(a)
        yield from range(2)
    assert complex(3) == [0, 1, 2, 0, 1]

# Generated at 2022-06-25 23:07:12.448029
# Unit test for function debug
def test_debug():
    assert True


# Generated at 2022-06-25 23:07:13.169724
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))

# Generated at 2022-06-25 23:07:21.403400
# Unit test for function eager
def test_eager():
    """Test for eager
    """
    try:
        complex_0 = None
        str_0 = get_source(complex_0)
    except TypeError:
        pass

    try:
        complex_1 = None
        str_1 = get_source(complex_1)
    except TypeError:
        pass

    try:
        complex_2 = None
        str_2 = get_source(complex_2)
    except TypeError:
        pass


if __name__ == '__main__':
    import io

    output = io.StringIO()
    list_ = [1, 2, 3]
    for num in eager(list_.__iter__)():
      output.write(f'{num}\n')
    assert output.getvalue() == '1\n2\n3\n'

# Generated at 2022-06-25 23:07:24.197088
# Unit test for function get_source
def test_get_source():
    assert (
        get_source(test_case_0) ==
        'complex_0 = None\n'
        'str_0 = get_source(complex_0)\n'
    )

# Generated at 2022-06-25 23:07:24.933912
# Unit test for function get_source
def test_get_source():
    test_case_0()



# Generated at 2022-06-25 23:07:29.763412
# Unit test for function get_source
def test_get_source():
    """
    test get_source
    """
    str_0 = """
    complex_0 = None
    str_0 = get_source(complex_0)
    """
    assert get_source(test_case_0) == str_0

# Generated at 2022-06-25 23:07:32.759773
# Unit test for function get_source
def test_get_source():
    str_1 = get_source(test_case_0)
    str_2 = "    complex_0 = None\n    str_0 = get_source(complex_0)\n"
    assert str_1 == str_2


# Generated at 2022-06-25 23:08:16.565161
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == 'complex_0 = None\n'

if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__, '-v', '-s'])

# Generated at 2022-06-25 23:08:18.306340
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == "complex_0 = None"



# Generated at 2022-06-25 23:08:25.731158
# Unit test for function eager
def test_eager():
    def test_eager_0():
        def gen():
            yield 0
            yield 1

        generator = gen()
        eager_0 = eager(gen)
        eager_1 = eager_0()
        eager_2 = list(generator)
        str_0 = repr(eager_1)
        str_1 = repr(eager_2)
        str_2 = get_source(gen)
        debug(lambda: '\n'.join((str_0, str_1, '---', str_2)))

    test_eager_0()


# Generated at 2022-06-25 23:08:26.586411
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == True

# Generated at 2022-06-25 23:08:33.327565
# Unit test for function eager
def test_eager():
    def test_case_0():
        value_0 = None
        value_1 = get_source(value_0)
        value_2 = [1, 2, 3]
        value_3 = get_source(value_2)
        value_4 = map(str, value_2)
        value_5 = get_source(value_4)
        value_6 = eager(map)(str, value_2)
        value_7 = get_source(value_6)
        value_8 = len(list(map(str, value_2)))
        value_9 = get_source(value_8)
        value_10 = len(eager(map)(str, value_2))
        value_11 = get_source(value_10)

    def test_case_1():
        value_0 = None
        value_

# Generated at 2022-06-25 23:08:35.650228
# Unit test for function eager
def test_eager():
    from inspect import getsourcelines
    e = eager
    assert (getsourcelines(e(int))[0][-1] == 'return list(fn(*args, **kwargs))')



# Generated at 2022-06-25 23:08:41.495132
# Unit test for function debug
def test_debug():
    from py_backwards.utils import debug

    class CustomIO(io.StringIO):
        def __init__(self) -> None:
            super().__init__()

        def __str__(self) -> str:
            return self.getvalue()

        def __contains__(self, item: str) -> bool:
            return item in str(self)

    strio = CustomIO()
    with redirect_stdout(strio):
        debug(lambda: "never printed")

        settings.debug = True
        debug(lambda: "printed when debug is set")
    assert "printed when debug is set" in strio

# Generated at 2022-06-25 23:08:43.564208
# Unit test for function debug
def test_debug():
    i = 0
    def get_message():
        nonlocal i
        i += 1
        return str(i)
    debug(get_message)
    debug(get_message)
# End unit test


# Generated at 2022-06-25 23:08:47.697496
# Unit test for function debug
def test_debug():
    def test_function_0():
        complex_2 = None
        complex_0 = None
        class Class_0(object):
            def __init__(self):
                self.complex_0 = None;
        complex_3 = None
        complex_1 = None
        complex_4 = None
        complex_0 = None
    debug(lambda: get_source(test_function_0))




# Generated at 2022-06-25 23:08:49.761704
# Unit test for function get_source
def test_get_source():
    f = get_source(test_case_0)
    expected = '''complex_0 = None
str_0 = get_source(complex_0)'''
    assert f == expected



# Generated at 2022-06-25 23:10:41.309864
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:10:46.435065
# Unit test for function debug
def test_debug():
    def named_fn():
        name = 'called'
        return name
    assert named_fn() == 'called'
    debug(named_fn)



# Generated at 2022-06-25 23:10:50.022750
# Unit test for function eager
def test_eager():
    # Test for function eager
    def rlist(i: int) -> List[int]:
        if i > 0:
            return [i] + rlist(i - 1)
        else:
            return []

    assert eager(rlist)(1) == [1]
    assert eager(rlist)(3) == [3, 2, 1]
    assert eager(rlist)(0) == []

    # Test for function eager
    def rlist(i: int) -> List[int]:
        if i > 0:
            return [i] + rlist(i - 1)
        else:
            return []

    assert eager(rlist)(1) == [1]
    assert eager(rlist)(3) == [3, 2, 1]
    assert eager(rlist)(0) == []

    # Test for function eager

# Generated at 2022-06-25 23:10:51.718770
# Unit test for function get_source
def test_get_source():
    variables_0 = [test_case_0()]
    assert_equal(variables_0[0], 'complex_0 = None')

# Generated at 2022-06-25 23:10:53.544071
# Unit test for function debug
def test_debug():
    str_0 = messages.debug(get_source(test_case_0))
    print(str_0)


# Generated at 2022-06-25 23:10:57.809939
# Unit test for function eager
def test_eager():
    def test_1(x: int, y: int) -> Iterable[int]:
        yield x + y

    def test_2(x: int, y: int) -> Iterable[int]:
        yield x + y

    eager_1 = eager(test_1)
    eager_2 = eager(test_2)
    eager_2(2, 2)



# Generated at 2022-06-25 23:11:03.111030
# Unit test for function get_source
def test_get_source():
    assert str_0 == 'None'

if __name__ == '__main__':
    test_case_0()
    test_get_source()

# Generated at 2022-06-25 23:11:07.645911
# Unit test for function eager
def test_eager():
    import functools
    import pprint
    import unittest
    @eager
    def range_eager(start, stop):
        yield from range(start, stop)
    class TestEager(unittest.TestCase):
        def test_range_eager(self):
            check = range(1, 7)
            self.assertEqual(range_eager(1, 7), check)
    test_case.TestEager = TestEager

# Generated at 2022-06-25 23:11:09.472893
# Unit test for function eager
def test_eager():
    f0 = lambda: [1, 2, 3, 4]
    f1 = eager(f0)
    assert f1() == [1, 2, 3, 4]


# Generated at 2022-06-25 23:11:11.387693
# Unit test for function debug
def test_debug():
    msg = 'abc'
    # assert debug(lambda: msg) == print(messages.debug(lambda: msg), file=sys.stderr)
