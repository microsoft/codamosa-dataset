

# Generated at 2022-06-25 23:03:38.590250
# Unit test for function get_source
def test_get_source():
    def test_function(a, b):
        c = a * b
        return c

    __result = get_source(test_function)
    assert __result == """def test_function(a, b):
    c = a * b
    return c"""


# Generated at 2022-06-25 23:03:41.502135
# Unit test for function get_source
def test_get_source():
    def f(): pass
    def g(): pass

    assert get_source(f).strip() == 'def f(): pass'
    assert get_source(g).strip() == 'def g(): pass'

# Generated at 2022-06-25 23:03:44.732602
# Unit test for function get_source
def test_get_source():
    test_case_0()

    # Test case 0
    variables_generator_0 = VariablesGenerator()
    assert len(get_source(test_case_0)) > 0



# Generated at 2022-06-25 23:03:51.259416
# Unit test for function debug
def test_debug():
    variables_generator_0 = VariablesGenerator()
    class_0 = type(variables_generator_0)
    function_0 = class_0.debug
    # Test debug without debug mode
    settings_0 = settings._replace(debug=False)
    def get_source_0() -> str:
        return get_source(function_0)
    try:
        settings.debug = settings_0.debug
        expected_0 = None
        actual_0 = function_0(get_source_0)

        assert actual_0 == expected_0
    finally:
        settings.debug = None


# Generated at 2022-06-25 23:03:54.666880
# Unit test for function get_source
def test_get_source():
    # Assert that the generated source code for a function is equal to the
    # source code for the function.
    assert get_source(test_case_0) == '''\
    def test_case_0():
        variables_generator_0 = VariablesGenerator()
    '''


# Generated at 2022-06-25 23:03:58.558768
# Unit test for function get_source
def test_get_source():
    test_case = get_source(test_case_0)
    if '    variables_generator_0 = VariablesGenerator()' in test_case:
        print(messages.success())
    else:
        print(messages.fail('get_source'))

# Generated at 2022-06-25 23:04:07.286100
# Unit test for function debug
def test_debug():
    class TestClass0:
        def __init__(self) -> None:
            self._output = []
        
        def write(self, input0: str) -> None:
            self._output.append(input0)
        
        def output(self) -> str:
            return ''.join(self._output)
        
        def clear_output(self) -> None:
            self._output.clear()
    
    old_output = sys.stderr

# Generated at 2022-06-25 23:04:09.828026
# Unit test for function get_source
def test_get_source():
    # No arguments
    assert get_source(test_case_0) == 'def test_case_0():\n    variables_generator_0 = VariablesGenerator()\n'



# Generated at 2022-06-25 23:04:12.247338
# Unit test for function eager
def test_eager():
    from py_backwards.utils.functions import eager
    import pytest

    def test_case_0():
        a = [1, 2, 3]
        b = eager(range(3))
        assert b == list(a)


# Generated at 2022-06-25 23:04:18.706200
# Unit test for function eager
def test_eager():
    source = get_source(test_case_0)
    globals_ = {}
    locals_ = {'test_case_0': test_case_0}
    eval(source, globals_, locals_)
    test_case_0 = locals_['test_case_0']
    assert callable(test_case_0)
    test_case_0()
    assert locals_['variables_generator_0'] is not None
    assert variables_generator_0 == locals_['variables_generator_0']

# Generated at 2022-06-25 23:04:31.373513
# Unit test for function get_source
def test_get_source():
    def test_function_0():
        """
        Some docstring
        """
        # ...
        x = 1
        y = 2
        z = 3 + 4

# Generated at 2022-06-25 23:04:33.126059
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """def test_case_0():
    variables_generator_0 = VariablesGenerator()"""


# Generated at 2022-06-25 23:04:38.650003
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    out = StringIO()
    sys.stderr = out
    debug(lambda: "k")
    assert out.getvalue() == ""
    settings.debug = True
    try:
        sys.stderr = out
        debug(lambda: "k")
        assert out.getvalue() == ">>> k\n"
    finally:
        settings.debug = False


# Generated at 2022-06-25 23:04:48.689518
# Unit test for function get_source
def test_get_source():
    def inner():
        def func_0():
            def hello_0():
                pass
            hello_0()
        func_0()
        return func_0, hello_0
    func_0, hello_0 = inner()
    assert get_source(func_0) == 'def func_0():\n    def hello_0():\n        pass\n    hello_0()'
    assert get_source(hello_0) == 'def hello_0():\n    pass'


# python -m pytest --cov-report= --cov=py_backwards py_backwards/tests/test_utils.py
if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 23:04:50.539201
# Unit test for function debug
def test_debug():
    result = debug(lambda: 'foo')
    expected = None
    assert result == expected


# Generated at 2022-06-25 23:04:55.141936
# Unit test for function get_source
def test_get_source():
    import unittest
    from . import test_utils

    def example_0(): pass

    def _test(expected: str) -> None:
        actual = get_source(example_0)
        test_utils.assert_equal(actual, expected)

    # @test
    def test_0():
        _test('def example_0(): pass')


# Generated at 2022-06-25 23:04:59.025711
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    output = "    variables_generator_0 = VariablesGenerator()\n"
    assert source == output


# Generated at 2022-06-25 23:05:02.241724
# Unit test for function eager
def test_eager():
    assert eager(lambda x: (yield x))(1) == [1]
    assert eager(lambda x: (i for i in x))([1]) == [1]
    assert eager(lambda x: (yield from x))([1]) == [1]


# Generated at 2022-06-25 23:05:10.163713
# Unit test for function get_source
def test_get_source():
    nested_dict = {'a': 'b'}
    def fn(nested_dict, bar = 'baz'):
        def inner(a = 2):
            return nested_dict['a']

        inner()
        return nested_dict

    assert get_source(fn) == """    def fn(nested_dict, bar = 'baz'):
        def inner(a = 2):
            return nested_dict['a']

        inner()
        return nested_dict"""[1:]



# Generated at 2022-06-25 23:05:14.074889
# Unit test for function debug
def test_debug():
    def test_debug_0():
        test_case_0()

if __name__ == '__main__':
    for name, fn in globals().copy().items():
        if name.startswith('test_'):
            fn()

# Generated at 2022-06-25 23:05:20.405483
# Unit test for function get_source
def test_get_source():
    from .variables import get_source
    assert get_source(test_case_0) == 'variables_generator_0 = VariablesGenerator()'


# Generated at 2022-06-25 23:05:31.270298
# Unit test for function debug
def test_debug():
    def expected_outputs(s: str) -> Iterable[Callable[[Any], None]]:
        yield lambda: print(messages.debug(s), file=sys.stderr)
        yield lambda: print(messages.debug(s), file=sys.stderr, end='')

    from ..conf import settings
    from unittest.mock import Mock, patch

    patch('sys.stderr', Mock(write=Mock())).start()
    expected_outputs_0 = expected_outputs('test_debug')
    settings.debug = True
    patch('sys.stderr', Mock(write=Mock())).start()
    debug(lambda: 'test_debug')
    current_output_0 = sys.stderr.write
    assert (callable(current_output_0))

# Generated at 2022-06-25 23:05:33.224984
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:05:36.660246
# Unit test for function debug
def test_debug():
    test_debug_0 = ['']
    def test_debug_1():
        test_debug_0[0] = 'test debug'

    debug(test_debug_1)
    assert test_debug_0[0] == 'test debug'


# Generated at 2022-06-25 23:05:42.676585
# Unit test for function get_source
def test_get_source():
    def do_some_job():
        pass

    def test(a, b=1, *c, k1, k2=2, **kwargs):
        pass

    tests = [
        ('def do_some_job():\n    pass', get_source(do_some_job)),
        ('def test(a, b=1, *c, k1, k2=2, **kwargs):\n    pass', get_source(test))
    ]

    for expected, result in tests:
        assert expected == result



# Generated at 2022-06-25 23:05:47.862592
# Unit test for function debug
def test_debug():
    pass


# Generated at 2022-06-25 23:05:51.757799
# Unit test for function debug
def test_debug():
    print("test_debug")
    for _ in range(10):
        debug(lambda: variables_generator_0.generate("variable"))
    print("passed")

test_debug()

# Generated at 2022-06-25 23:05:53.582575
# Unit test for function eager
def test_eager():
    def fn():
        for i in range(3):
            yield i
    assert eager(fn)() == [0, 1, 2]


# Generated at 2022-06-25 23:05:55.729448
# Unit test for function debug
def test_debug():
    # zero argument function
    assert debug(lambda: "") == None


# Generated at 2022-06-25 23:05:56.555060
# Unit test for function debug
def test_debug():
    assert True


# Generated at 2022-06-25 23:06:02.709119
# Unit test for function eager
def test_eager():
    get_message = lambda: "Testing function eager"
    debug(get_message)
    assert list(eager(test_case_0)) == []


# Generated at 2022-06-25 23:06:05.070112
# Unit test for function eager
def test_eager():
    from string import digits
    from string import ascii_uppercase

    map_0 = map(digits, digits)
    list_0 = list(map_0)


# Generated at 2022-06-25 23:06:07.656190
# Unit test for function debug
def test_debug():
    get_message: Callable[[], str] = test_case_0
    settings.debug = True
    debug(get_message)
    settings.debug = False
    debug(get_message)


# Generated at 2022-06-25 23:06:13.031560
# Unit test for function get_source
def test_get_source():
    variables_generator_0 = VariablesGenerator()
    str_0 = 'D(v~BHf4Q<.F&4_'
    str_1 = variables_generator_0.generate(str_0)
    str_2 = 'function'
    str_3 = get_source(test_case_0)
    str_4 = str_2 + ' ' + str_1
    assert str_4 == str_3


# Generated at 2022-06-25 23:06:14.701202
# Unit test for function debug
def test_debug():
    "Test function debug"

    def test():
        return 'test'

    debug(test)



# Generated at 2022-06-25 23:06:22.981420
# Unit test for function debug
def test_debug():
    test_var_0 = VariablesGenerator.generate('test_var_0')
    test_var_1 = 'Kjn8o_P|X9r\n:~.W'
    test_var_2 = VariablesGenerator.generate('test_var_2')
    test_var_3 = generate_random_string(5)
    test_var_4 = VariablesGenerator.generate('test_var_4')
    test_var_5 = generate_random_string(5)
    test_var_6 = VariablesGenerator.generate('test_var_6')
    test_var_7 = generate_random_string(5)
    test_var_8 = 'Vk-?Pu[H<D$x1\n7)'
    test_var_9 = VariablesGener

# Generated at 2022-06-25 23:06:28.347118
# Unit test for function debug
def test_debug():
    str_0 = 'xN_dye\r;E{kL6"=Upid'
    callable_0 = eager(str_0)
    assert get_source(test_case_0) == """
str_0 = 'xN_dye\\r;E{kL6"=Upid'
callable_0 = eager(str_0)
"""



# Generated at 2022-06-25 23:06:31.289603
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    str_0 = ' \
                                     '\'xN_dye\\r;E{kL6"=Upid\'\n    ' \
                                     'callable_0 = eager(str_0)\n'



# Generated at 2022-06-25 23:06:32.632271
# Unit test for function debug
def test_debug():
    string_0 = '8QcW\x1e\n9Z|H\n'
    debug(string_0)


# Generated at 2022-06-25 23:06:41.222373
# Unit test for function debug
def test_debug():
    import unittest
    from unittest.mock import Mock
    from . import messages

    class TestDebug(unittest.TestCase):
        def test(self) -> None:
            get_message = Mock(return_value='test')
            with messages.Debug(True):
                debug(get_message)
            self.assertEqual(get_message.call_count, 1)

            # Check that debug message is not printed with debug disabled
            with messages.Debug(False):
                debug(get_message)
            self.assertEqual(get_message.call_count, 1)

    test = TestDebug()
    test.test()


# Generated at 2022-06-25 23:06:51.856375
# Unit test for function debug
def test_debug():
    import pytest

    from contextlib import redirect_stderr
    from io import StringIO
    from . import messages

    # Basic test
    stderr = StringIO()
    with redirect_stderr(stderr):
        debug(lambda: 'test')

    assert 'DEBUG' in stderr.getvalue()
    assert 'test' in stderr.getvalue()

    # Debug disabled
    settings.debug = False
    stderr = StringIO()
    with redirect_stderr(stderr):
        debug(lambda: 'test')

    assert stderr.getvalue() == ''

    # Reset
    settings.debug = True


# Generated at 2022-06-25 23:06:56.129319
# Unit test for function get_source
def test_get_source():
    import io
    import sys
    # Capturing the output
    capturedOutput = io.StringIO()                  # Create StringIO object
    sys.stdout = capturedOutput                     #  and redirect stdout.
    test_case_0()
    sys.stdout = sys.__stdout__                     # Reset redirect.
    assert(capturedOutput.getvalue() == 'xN_dye\r;E{kL6"=Upid\n') # for comparing output.


# Generated at 2022-06-25 23:07:00.408424
# Unit test for function get_source
def test_get_source():
    def add(x, y):
        return x + y

    source = [
        'def add(x, y):',
        '    return x + y',
        '',
        '',
    ]
    assert get_source(add) == '\n'.join(source)
    print('Test function get_source success')



# Generated at 2022-06-25 23:07:01.493367
# Unit test for function debug
def test_debug():
    # Write your test code here
    pass


# Generated at 2022-06-25 23:07:05.075169
# Unit test for function debug
def test_debug():
    callable_0 = test_case_0()
    try:
        callable_0()
    except Exception as inst:
        if str(inst) != "global name 'str_0' is not defined":
            raise

# Generated at 2022-06-25 23:07:06.187008
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)

# Generated at 2022-06-25 23:07:08.676893
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'str_0 = \'xN_dye\r;E{kL6"=Upid\'\ncallable_0 = eager(str_0)\n'

# Generated at 2022-06-25 23:07:11.794413
# Unit test for function get_source
def test_get_source():
    test_case_0()
    try:
        assert callable_0.__code__.co_filename == '<ipython-input-1-26e150e24284>'
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 23:07:13.948094
# Unit test for function get_source
def test_get_source():
    test_case_0()
    assert get_source(test_case_0) == '    str_0 = \'xN_dye\r;E{kL6"=Upid\'\n'


# Generated at 2022-06-25 23:07:14.940792
# Unit test for function get_source
def test_get_source():
    assert len(get_source(test_case_0)) == 61


# Generated at 2022-06-25 23:07:32.881096
# Unit test for function debug
def test_debug():
    str_0 = 'i;'
    str_1 = '\x0e\x0e\x00\x19\t\x0e\x0e\x0e\x0e\x19\x00\x0e\x0e\x0e\x0e\x00'
    str_2 = ''
    str_2 += '\x0e\x0e\x00\x19\t\x0e\x0e\x0e\x0e\x19\x00\x0e\x0e\x0e\x0e\x00'

# Generated at 2022-06-25 23:07:35.752781
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:07:39.285927
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'str_0 = \'xN_dye\r;E{kL6"=Upid\'\n'
    assert get_source(test_case_1) == 'print(\"V5Q5[zL&x\")\n'


# Generated at 2022-06-25 23:07:41.011712
# Unit test for function debug
def test_debug():
    assert False
    #### get_source(int)
    #### debug(lambda: str_0)


# Generated at 2022-06-25 23:07:46.172590
# Unit test for function debug
def test_debug():
    print('unit test for debug')

    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    callable_0 = debug(str_0)


# Generated at 2022-06-25 23:07:49.134482
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    str_0 = \'xN_dye\r;E{kL6"=Upid\'\n    callable_0 = eager(str_0)\n'



# Generated at 2022-06-25 23:07:57.741330
# Unit test for function debug
def test_debug():
    callable_0 = VariablesGenerator.generate
    str_0 = "python-backwards"
    Attributes = get_source(VariablesGenerator.generate)
    str_1 = Attributes
    Attributes = "Generates unique name for variable.\n    "
    callable_1 = str_1.index(Attributes)
    callable_2 = callable_0(str_0)
    str_2 = callable_2
    callable_3 = str_1.index(str_2)
    callable_4 = callable_3 - callable_1
    Attributes = "Generates unique name for variable.\n    "
    str_3 = str_1[callable_1 + len(Attributes):callable_3]

# Generated at 2022-06-25 23:07:59.363518
# Unit test for function eager
def test_eager():
    try:
        test_case_0()
    except:
        raise AssertionError()



# Generated at 2022-06-25 23:08:03.950729
# Unit test for function get_source
def test_get_source():
    from cStringIO import StringIO
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        test_case_0()
        test_output = out.getvalue().strip()
        assert test_output == "xN_dye\r;E{kL6\"=Upid"
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-25 23:08:07.070632
# Unit test for function get_source
def test_get_source():
    def expected():
        str_0 = 'xN_dye\r;E{kL6"=Upid'
        callable_0 = eager(str_0)

    expect = get_source(expected)
    actual = get_source(test_case_0)
    assert expect == actual

# Generated at 2022-06-25 23:08:35.882681
# Unit test for function get_source
def test_get_source():
    str_0 = 'xN_dye\r;E{kL6"=Upid'
    callable_0 = get_source(str_0)


# Generated at 2022-06-25 23:08:38.497752
# Unit test for function get_source
def test_get_source():
    result = get_source(test_case_0)
    expected_result = \
"""str_0 = 'xN_dye\r;E{kL6"=Upid'
callable_0 = eager(str_0)"""
    assert result == expected_result



# Generated at 2022-06-25 23:08:40.618075
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))
    assert get_source(test_case_0) == 'test_case_0()'

# Generated at 2022-06-25 23:08:42.449457
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).strip() == 'callable_0 = eager(str_0)'


# Generated at 2022-06-25 23:08:45.276904
# Unit test for function debug
def test_debug():
    # WARNING: This test is for debugging purposes only
    # It checks if the main function doesn't crash and prints debug messages
    logger = logging.getLogger()
    logger.disabled = True
    try:
        test_case_0()
    except:
        pass
    logger.disabled = False

# Generated at 2022-06-25 23:08:46.559109
# Unit test for function eager
def test_eager():
    # Tests whether the given python code raise the SyntaxError exception.
    assertSyntaxError(test_case_0)

# Generated at 2022-06-25 23:08:52.826686
# Unit test for function debug
def test_debug():
    # Test when settings.debug is off
    settings.debug = False

    captured = Capsys.readouterr()
    assert captured.out == ''
    debug(lambda: 'This should not be printed to stdout.')
    captured = Capsys.readouterr()
    assert captured.out == ''

    # Test when settings.debug is on
    settings.debug = True

    captured = Capsys.readouterr()
    assert captured.out == ''
    debug(lambda: 'This should be printed to stdout.')
    captured = Capsys.readouterr()
    assert captured.out == messages.debug('This should be printed to stdout.') + '\n'



# Generated at 2022-06-25 23:08:58.581084
# Unit test for function get_source
def test_get_source():
    str_0 = '\x1a\x7fef\x1f\x1e2\x1c\xeb\x83\xa6d\xfe\x05\xad\x0c\x8e\xe9\x1f\xcd\r\xb8\xfb\xffKw\x03\x15\xa7\xdc\x9f\x1f'
    callable_0 = VariablesGenerator.generate
    # Function call
    str_1 = get_source(callable_0)
    assert str_1 == str_0


# Generated at 2022-06-25 23:09:00.340998
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == 'LpRdR\x0b;E{kL6"=Uxid'


# Generated at 2022-06-25 23:09:04.493617
# Unit test for function debug
def test_debug():
    class UnitTestMessage:

        def __init__(self) -> None:
            self._message: str = ''

        def __str__(self) -> str:
            return self._message

    message = UnitTestMessage()

    @eager
    def str_0() -> Iterable[int]:
        debug(lambda: message.__str__())

    str_0()
    assert message._message == 'py_backwards:debug: "message"'

# Generated at 2022-06-25 23:10:02.245913
# Unit test for function get_source
def test_get_source():
    str_0 = 'xN_dye\r;E{kL6"=Upid'
    callable_0 = eager(str_0)
    expected = """
    str_0 = 'xN_dye\r;E{kL6"=Upid'
    callable_0 = eager(str_0)
    """
    assert get_source(test_case_0) == expected


# Generated at 2022-06-25 23:10:04.141244
# Unit test for function get_source
def test_get_source():
    str_0 = 'C@t'
    callable_0 = get_source(str_0)


# Generated at 2022-06-25 23:10:07.128504
# Unit test for function debug
def test_debug():
    # Make sure it works as expected
    get_message = lambda: 'test debug'
    debug(get_message)
    known_output = 'test debug'

    # Cleanup - make sure other tests won't fail
    settings.debug = True

    # Assert
    assert known_output == get_message()



# Generated at 2022-06-25 23:10:08.411948
# Unit test for function get_source
def test_get_source():
    def test_function_0():
        pass

    assert get_source(test_function_0).strip() == 'pass'


# Generated at 2022-06-25 23:10:10.165864
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0)[:9] == 'str_0 = \''
    assert get_source(test_case_0)[-7:] == 'pid\', \n'


# Generated at 2022-06-25 23:10:10.946386
# Unit test for function debug
def test_debug():
    debug(lambda: 'Test debug')



# Generated at 2022-06-25 23:10:13.815322
# Unit test for function get_source
def test_get_source():
    caller = sys._getframe().f_back
    function = caller.f_code.co_name
    line_no = caller.f_lineno

    def test_case_0():
        pass

    assert get_source(test_case_0) == 'def test_case_0():\n    pass\n'



# Generated at 2022-06-25 23:10:17.759869
# Unit test for function eager
def test_eager():
    # assert test_case_0() == eager(test_case_0())
    assert eager(test_case_0)() == ['x', 'N', '_', 'd', 'y', 'e', '\r', ';', 'E', '{', 'k', 'L', '6', '"', '=', 'U', 'p', 'i', 'd']


# Generated at 2022-06-25 23:10:18.394996
# Unit test for function debug
def test_debug():
    test_case_0()


# Generated at 2022-06-25 23:10:25.729888
# Unit test for function get_source
def test_get_source():
    str_0 = ''.join(map(chr, range(97, 123)))
    str_1 = ''.join(map(chr, range(65, 91)))
    str_2 = get_source(test_case_0)

    for char in str_0 + str_1:
        assert char not in str_2

    str_3 = ''.join(map(chr, range(48, 58)))
    str_4 = ''.join(map(chr, [92, 93, 91, 123, 125, 58, 59]))

    for char in str_4 + str_3:
        assert char not in str_2

    str_5 = ''.join(map(chr, range(97, 123)))
    str_6 = ''.join(map(chr, range(65, 91)))


# Generated at 2022-06-25 23:12:25.494821
# Unit test for function get_source
def test_get_source():
    test_case_0()


# Generated at 2022-06-25 23:12:27.650799
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "def test_case_0():\n    str_0 = 'xN_dye\\r;E{kL6\"=Upid'\n    " \
                                     "callable_0 = eager(str_0)\n"


# Generated at 2022-06-25 23:12:28.825818
# Unit test for function debug
def test_debug():
    assert callable(debug)
    assert debug(test_case_0.__name__)
    assert not debug(test_case_0.__name__)


# Generated at 2022-06-25 23:12:30.281436
# Unit test for function get_source
def test_get_source():
    str_0 = 'C4[c$zTFCo}&'
    callable_0 = eager(str_0)
    str_1 = get_sourc

# Generated at 2022-06-25 23:12:31.572325
# Unit test for function get_source
def test_get_source():
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 23:12:35.373033
# Unit test for function eager
def test_eager():
    print('Beginning function eager unit testing...')
    str_0 = 'xN_dye\r;E{kL6"=Upid'
    callable_0 = eager(str_0)
    func_callable_0 = call_eager(callable_0)
    assert func_callable_0 == str_0
    print('Finished function eager unit testing...')

# Utility for testing eager

# Generated at 2022-06-25 23:12:36.474801
# Unit test for function get_source

# Generated at 2022-06-25 23:12:38.410339
# Unit test for function get_source

# Generated at 2022-06-25 23:12:39.687266
# Unit test for function debug
def test_debug():
    str_0 = 'v4#W4:8)u0\t>h'
    test_0 = debug(str_0)


# Generated at 2022-06-25 23:12:41.029388
# Unit test for function eager
def test_eager():
    str_0 = 'ei@G!0Fq}'
    callable_0 = eager(str_0)

