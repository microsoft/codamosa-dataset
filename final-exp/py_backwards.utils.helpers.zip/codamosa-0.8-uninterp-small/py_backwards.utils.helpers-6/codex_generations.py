

# Generated at 2022-06-25 23:03:38.499666
# Unit test for function get_source

# Generated at 2022-06-25 23:03:41.748056
# Unit test for function debug
def test_debug():
    @debug
    def fn_0():
        return 'foo'
    test_case_0()

    assert get_source(fn_0) == '''\
    @debug
    def fn_0():
        return 'foo'
'''



# Generated at 2022-06-25 23:03:46.414859
# Unit test for function debug
def test_debug():
    expected_result = 'unit_test'
    def test_debug_0() ->  str:
        return expected_result
    
    actual_result = test_debug_0()
    assert actual_result == expected_result, 'Expected: %s, Actual: %s' % (expected_result, actual_result)
    
    

# Generated at 2022-06-25 23:03:50.531087
# Unit test for function get_source
def test_get_source():
    get_source_0 = get_source
    get_source_1 = getsource
    get_source_2 = print
    get_source_3 = sys.stderr

    assert (
        get_source(test_case_0) ==
        'test_case_0():\n    variables_generator_0 = VariablesGenerator()\n'
    )



# Generated at 2022-06-25 23:03:59.575152
# Unit test for function debug
def test_debug():
    print('test_debug')
    test_case_0()
    test_method_name = 'test_debug'
    test_method_results = {}
    def debug_0():
        test_method_results['debug_0'] = 'Hello world!'
        print('Hello world!')
    debug(debug_0)
    test_method_results['debug_1'] = 'Hello world!'
    print('Hello world!')
    test_method_results['debug_2'] = 'Hello world!'
    print('Hello world!')
    test_method_results['debug_3'] = 'Hello world!'
    print('Hello world!')
    test_method_results['debug_4'] = 'Hello world!'
    print('Hello world!')
    test_method_results['debug_5'] = 'Hello world!'

# Generated at 2022-06-25 23:04:01.876989
# Unit test for function debug
def test_debug():
    test_case_0()
    pickle.loads(pickle.dumps(debug))
    debug(lambda: variables_generator_0.generate('debug'))


# Generated at 2022-06-25 23:04:04.323693
# Unit test for function get_source
def test_get_source():
    def test_function_0(x):
        return x
    assert get_source(test_function_0) == 'def test_function_0(x):\n    return x'


# Generated at 2022-06-25 23:04:07.695714
# Unit test for function get_source
def test_get_source():
    test_case_0()
    result = get_source(test_case_0)
    assert isinstance(result, str)
    assert result == "def test_case_0():\n    variables_generator_0 = VariablesGenerator()"


# Generated at 2022-06-25 23:04:14.147913
# Unit test for function eager
def test_eager():
    def test_case_1():
        eager_0 = eager
        eager_1 = eager_0
        eager_2 = eager_1
        eager_3 = eager_2
        eager_4 = eager_3
        eager_5 = eager_4
        eager_6 = eager_5

    # Unit test for function get_source
    def test_get_source():
        def test_case_1():
            get_source_0 = get_source
            def test_case_2():
                get_source_0
                get_source_1
                get_source_2
                get_source_3
                get_source_4
                get_source_5
                get_source_6
                get_source_7
                get_source_8
                get_source_9
        get_source_0 = get_source



# Generated at 2022-06-25 23:04:21.860214
# Unit test for function get_source
def test_get_source():
    variables_generator_0 = VariablesGenerator()
    assert get_source(test_get_source) == 'test_get_source()'
    assert get_source(test_case_0) == 'test_case_0()'
    assert get_source(eager) == 'def wrapped(*args, **kwargs):\n    return list(fn(*args, **kwargs))'
    assert get_source(variables_generator_0.generate) == 'def wrapped(variable):\n    try:\n        return \'_py_backwards_{}_{}\'.format(variable, cls._counter)\n    finally:\n        cls._counter += 1'


# Generated at 2022-06-25 23:04:27.180547
# Unit test for function debug
def test_debug():
    yes = [False]
    def get_message():
        yes[0] = True
        return 'XXX'
    debug(get_message)
    assert not yes[0]
    settings.debug = True
    debug(get_message)
    assert yes[0]


# Generated at 2022-06-25 23:04:29.034649
# Unit test for function debug
def test_debug():
    try:
        call_0 = test_case_0()
    except:
        fail('test case failed', 2)


# Generated at 2022-06-25 23:04:29.513064
# Unit test for function debug
def test_debug():
    debug(lambda:'')



# Generated at 2022-06-25 23:04:31.232105
# Unit test for function debug
def test_debug():
    def test_case_0():
        def func_0():
            return 'hi'

        debug(func_0)



# Generated at 2022-06-25 23:04:32.544421
# Unit test for function eager
def test_eager():
# Setup
    list_0 = []

# Asserts
    assert eager(list_0)


# Generated at 2022-06-25 23:04:38.821094
# Unit test for function debug
def test_debug():
    def test_case_debug_0():
        debug_0 = debug
        str_0 = get_source(debug_0)
        str_1 = settings.debug
        bool_0 = False
        if (str_1):
            if (str_1):
                if (str_1):
                    if (str_1):
                        if (str_1):
                            bool_0 = True
        if (not bool_0):
            raise Exception
    debug_0 = debug
    str_0 = get_source(debug_0)


# Generated at 2022-06-25 23:04:49.094852
# Unit test for function debug
def test_debug():
    global test_arg_debug_0
    test_arg_debug_0 = 42
    def get_test_arg(arg_name):
        return locals()[arg_name]
    def mock_print(*args):
        pass
    def mock_getsource(fn):
        return 'def func():\n    pass'
    try:
        old_print = globals()['print']
        globals()['print'] = mock_print
        old_getsource = globals()['getsource']
        globals()['getsource'] = mock_getsource
        debug(lambda: get_test_arg('test_arg_debug_0'))
    finally:
        globals()['print'] = old_print
        globals()['getsource'] = old_getsource


# Generated at 2022-06-25 23:04:51.228289
# Unit test for function debug
def test_debug():
    if not settings.debug:
        return
    print('TEST: py_backwards.tools.debug()')
    test_case_0()



# Generated at 2022-06-25 23:04:53.137167
# Unit test for function debug
def test_debug():
    variables_generator_0 = VariablesGenerator()
    debug(lambda: get_source(variables_generator_0))


# Generated at 2022-06-25 23:04:55.636607
# Unit test for function eager
def test_eager():
    assert eager(None) == (
        'def wrapped(*args, **kwargs):\n'
        '    return list(None(*args, **kwargs))\n')


# Generated at 2022-06-25 23:05:00.906754
# Unit test for function eager
def test_eager():
    def test_0():
        for i in eager(range(3)):
            print(i)
    test_0()


# Generated at 2022-06-25 23:05:03.953766
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello') # DEBUG: Hello
    print(settings.debug) # True
    settings.debug = False
    debug(lambda: 'World') # None
    print(settings.debug) # False


# Generated at 2022-06-25 23:05:08.155516
# Unit test for function debug
def test_debug():
    str_0 = "test"
    def func_0():
        return str_0
    debug(func_0)



# Generated at 2022-06-25 23:05:14.701724
# Unit test for function debug
def test_debug():
    str_0 = 'zzmjkk'
    str_1 = 'cafjzk'
    def function_0(str_0, str_1):
        def function_1(str_0, str_1):
            assert str_0 != str_1
            str_1 = str_0
        function_1(str_0, str_1)

    # A must be true, otherwise there is bug in PyBackwards
    assert True

# Generated at 2022-06-25 23:05:17.100460
# Unit test for function eager
def test_eager():
    @eager
    def test_func(*args, **kwargs):
        yield

    assert isinstance(test_func(), list)


# Generated at 2022-06-25 23:05:18.102839
# Unit test for function debug
def test_debug():
    debug(lambda: 'Test debug')
    assert True

# Generated at 2022-06-25 23:05:22.351211
# Unit test for function debug
def test_debug():
    test_message = 'Test debug message.'
    if settings.debug:
        with open(os.devnull, 'w') as devnull:
            with redirect_stdout(devnull):
                debug(lambda: test_message)
    else:
        with redirect_stdout(sys.__stdout__):
            debug(lambda: test_message)

# Generated at 2022-06-25 23:05:27.748418
# Unit test for function eager
def test_eager():
    def f():
        yield 1
        yield 2
        yield 3

    def doubled(x):
        return x * 2

    lazy_result = list(map(doubled, f()))
    eager_result = list(map(doubled, eager(f)()))
    assert lazy_result == eager_result


# Generated at 2022-06-25 23:05:32.862019
# Unit test for function eager
def test_eager():
    variables_generator_0 = VariablesGenerator()
    list_0 = [1, 2, 3]
    print(variables_generator_0)
    print(list_0)
    function_0 = eager
    function_1 = function_0(lambda: range(3))
    list_1 = function_1()
    print(function_0)
    print(function_1)
    print(list_1)


# Generated at 2022-06-25 23:05:34.507858
# Unit test for function debug
def test_debug():
    str_0 = '_py_backwards_0_0'
    debug(str_0)


# Generated at 2022-06-25 23:05:39.230477
# Unit test for function eager
def test_eager():
    assert isinstance(eager, Callable)


# Generated at 2022-06-25 23:05:40.154319
# Unit test for function debug
def test_debug():
    if settings.debug:
        pass



# Generated at 2022-06-25 23:05:46.874526
# Unit test for function eager
def test_eager():
    # Function to test
    def dummy_fn(l: Iterable[int]) -> Iterable[int]:
        return l

    assert eager(dummy_fn)(range(10)) == list(range(10))
    assert eager(dummy_fn)(dummy_fn(range(10))) == list(range(10))
    assert eager(dummy_fn)(dummy_fn(dummy_fn(range(10)))) == list(range(10))


# Generated at 2022-06-25 23:05:52.153112
# Unit test for function eager
def test_eager():
    def eager_0() -> List[int]:
        return eager(lambda: [1, 2, 3])
    assert eager_0() == [1, 2, 3]

    def eager_1() -> List[str]:
        return eager(lambda: [])
    assert eager_1() == []


# Generated at 2022-06-25 23:05:56.003690
# Unit test for function debug
def test_debug():
    print("Test #0 for function debug")
    try:
        debug_0 = debug(test_case_0)
        print("PASSED: debug")
    except AssertionError:
        print("FAILED: debug")


# Generated at 2022-06-25 23:05:59.653970
# Unit test for function eager
def test_eager():
    # Making sure that the decorator does not alter the source
    assert get_source(eager(test_case_0)) == get_source(test_case_0)

    # Making sure that the function is converted to a list
    assert eager(range)(5) == [0, 1, 2, 3, 4]



# Generated at 2022-06-25 23:06:01.887921
# Unit test for function debug
def test_debug():
    if settings.debug:
        assert read_print(sys.stderr) == ['message']
    else:
        assert read_print(sys.stderr) == []



# Generated at 2022-06-25 23:06:05.616225
# Unit test for function debug
def test_debug():
    message_0 = 'test'
    def get_message():
        return message_0

    settings.debug = True

    try:
        debug(get_message)
    except SystemExit as exc:
        assert not exc
    else:
        raise AssertionError('SystemExit not raised')

    settings.debug = False


# Generated at 2022-06-25 23:06:09.449356
# Unit test for function debug
def test_debug():
    _list_0 = []
    _list_0.append(str_0)
    str_1 = construct_message(_list_0)
    debug(str_1)


if __name__ == '__main__':
    debug(str_0)
    test_debug()
    test_case_0()

# Generated at 2022-06-25 23:06:10.523805
# Unit test for function debug
def test_debug():
    assert True, "Unit test for function debug failed"


# Generated at 2022-06-25 23:06:18.999671
# Unit test for function debug
def test_debug():
    test_case_0()

# Generated at 2022-06-25 23:06:20.489319
# Unit test for function eager
def test_eager():
    var_0 = get_source(eager)


# Generated at 2022-06-25 23:06:26.820919
# Unit test for function debug
def test_debug():
    warnings = []
    def mock_print(message, file=sys.stderr):
        warnings.append(message)

    old_print = print
    print = mock_print

    settings.debug = False
    debug(lambda: 'debug message')
    assert warnings == []

    settings.debug = True
    debug(lambda: 'debug message')
    assert warnings == ['\x1b[2mdebug message\x1b[0m']

    settings.debug = False
    print = old_print



# Generated at 2022-06-25 23:06:28.582615
# Unit test for function eager
def test_eager():
    def square(n):
        def inner_square(x):
            return x * x
        return map(inner_square, range(n))
    # list
    assert eager(square)(1) == [0]
    assert eager(square)(2) == [0, 1]



# Generated at 2022-06-25 23:06:29.917866
# Unit test for function debug
def test_debug():
    test_case_0()


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-25 23:06:35.450550
# Unit test for function eager
def test_eager():
    from functools import wraps
    from typing import Any, Callable, Iterable, List, TypeVar
    T = TypeVar('T')
    eager_ = eager
    def eager__(fn: Callable[..., Iterable[T]]) -> Callable[..., List[T]]:
        @wraps(fn)
        def wrapped(*args: Any, **kwargs: Any) -> List[T]:
            return list(fn(*args, **kwargs))
        return wrapped
    assert eager_ == eager__


# Generated at 2022-06-25 23:06:37.824011
# Unit test for function debug
def test_debug():
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 23:06:41.061405
# Unit test for function debug
def test_debug():
    str_0 = "Some test string"
    def fn_0():
        return str_0
    debug(fn_0)

if __name__ == "__main__":
    test_case_0()
    test_debug()

# Generated at 2022-06-25 23:06:46.678455
# Unit test for function debug
def test_debug():
    test_case_0()

    class TestVariablesGenerator:
        _counter = 0
    test_variables_generator_0 = TestVariablesGenerator()
    str_0 = get_source(test_variables_generator_0)

    def test_case_0_debug():
        variables_generator_0 = VariablesGenerator()
        str_0 = get_source(variables_generator_0)
    debug(test_case_0_debug)


# Generated at 2022-06-25 23:06:49.433010
# Unit test for function eager
def test_eager():
    def func_0(arg_0):
        return range(arg_0)
    assert eager(func_0)(10)==[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-25 23:07:05.931583
# Unit test for function debug
def test_debug():
    debug(settings.debug)


# Generated at 2022-06-25 23:07:13.878431
# Unit test for function debug
def test_debug():
    def test_case_0():
        settings_0 = settings
    # creating a global object 'settings'
    test_case_0()

    test_case_1 = settings_0
    # Assigning global object 'settings' to 'test_case_1'

    def test_case_2():
        debug_0 = debug
        # Assigning function 'debug' to 'debug_0'
        warnings_0 = warnings
        # Assigning module 'warnings' to 'warnings_0'
        test_case_1_1 = test_case_1
        # Assigning 'test_case_1' to 'test_case_1_1'

        def test_case_3():
            messages_0 = messages
            # Assigning module 'messages' to 'messages_0'
            sys_0 = sys
            # Assigning

# Generated at 2022-06-25 23:07:17.635977
# Unit test for function eager
def test_eager():
    test_eager_0 = 0
    def test_eager_1(test_eager_2=[1, 2, 3], test_eager_3 = 4):
        test_eager_0 = test_eager_2
        test_eager_0 = test_eager_3
    test_eager_1 = eager(test_eager_1)
    test_eager_1()

# Generated at 2022-06-25 23:07:18.612625
# Unit test for function eager
def test_eager():
    assert eager(range)(2) == [0, 1]



# Generated at 2022-06-25 23:07:19.326764
# Unit test for function debug
def test_debug():
    debug(lambda: '1')


# Generated at 2022-06-25 23:07:23.898438
# Unit test for function debug
def test_debug():
    def get_message_0() -> str:
        int_1 = 0
        if 0:
            str_0 = 'asdf'
        else:
            str_0 = 'asdfg'
        return str_0
    debug(get_message_0)


# Generated at 2022-06-25 23:07:29.824364
# Unit test for function eager
def test_eager():
    def function_under_test(param0: int) -> Iterable[float]:
        return (yield)

    # Call function as normal
    result = function_under_test(42)

    # Call it wrapped with eager
    wrapped_result = eager(function_under_test)(42)

    print('eager: {}'.format((result, wrapped_result)))




# Generated at 2022-06-25 23:07:30.875375
# Unit test for function debug
def test_debug():
    debug(lambda: '1')

# Generated at 2022-06-25 23:07:31.722075
# Unit test for function debug
def test_debug():
    debug(lambda: "debug")


# Generated at 2022-06-25 23:07:40.676449
# Unit test for function eager
def test_eager():
    import pytest
    import sys
    test_case_0()
    test_eager_0(list)
    test_eager_0(sys.modules[__name__])
    test_eager_0(sys.modules[__name__])
    test_eager_0('a')
    test_eager_0(1)
    test_eager_0(lambda x: None)
    test_eager_0(lambda x, y: None)
    test_eager_0(lambda x, y, z: None)
    test_eager_0(1)
    test_eager_0('b')
    test_eager_0(1)
    test_eager_0('')
    test_eager_0('')
    test_eager_0('f')
   

# Generated at 2022-06-25 23:08:16.301836
# Unit test for function eager
def test_eager():
    import random

    def my_randint_generator_5():
        for x in range(10):
            yield random.randint(100)
    list_0 = eager(my_randint_generator_5)()
    assert len(list_0) == 10


# Generated at 2022-06-25 23:08:19.108784
# Unit test for function debug
def test_debug():
    try:
        settings.debug = True
        test_case_0()
    except AssertionError as e:
        warn(str(e))
        return False
    return True

# Generated at 2022-06-25 23:08:22.829671
# Unit test for function eager
def test_eager():
    def _eager(a):
        for i in a:
            yield i
    result_0 = eager(_eager)(range(10))
    assert len(result_0) == 10


# Generated at 2022-06-25 23:08:25.630437
# Unit test for function eager
def test_eager():

    @eager
    def case(a: int, b: str) -> Iterable[int]:
        yield a
        yield b

    assert case(1, "2") == [1, "2"]

# Generated at 2022-06-25 23:08:28.307004
# Unit test for function eager
def test_eager():
    def assert_equal(expected, fn, *args, **kwargs):
        result = fn(*args, **kwargs)
        assert result == expected

    assert_equal([1, 2, 3], eager, range(1, 4))



# Generated at 2022-06-25 23:08:32.745681
# Unit test for function debug
def test_debug():
    warnings = []

    def get_message():
        return 'foo'

    class FakeStdErr:
        def write(self, message: str) -> None:
            warnings.append(message)

    original_stderr = sys.stderr
    try:
        sys.stderr = FakeStdErr()
        settings.debug = True
        debug(get_message)
        assert len(warnings) == 1
        assert warnings[0] == 'foo\n'
    finally:
        sys.stderr = original_stderr

# Generated at 2022-06-25 23:08:36.980080
# Unit test for function debug
def test_debug():
    def test_0() -> None:
        print(messages.debug('foo'), file=sys.stderr)
    def test_1() -> None:
        print(messages.debug('bar'), file=sys.stderr)

    func_0 = test_0()
    test_1()
    debug(test_0)
    func_1 = test_1()
    print(func_1, file=sys.stderr)


# Generated at 2022-06-25 23:08:37.992746
# Unit test for function debug
def test_debug():
    assert debug(lambda: 'string_0') == None


# Generated at 2022-06-25 23:08:43.631746
# Unit test for function debug
def test_debug():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    debug('test message')
    with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
        debug('test message')
    mock_stderr.write.assert_called_with('\x1b[1m\x1b[43m\x1b[30m⚠ debug:\x1b[0m test message \n')
    mock_stderr.flush.assert_called_with()


# Generated at 2022-06-25 23:08:46.462205
# Unit test for function debug
def test_debug():
    try:
        messages.message = messages.debug
        sys.stdout = io.StringIO()
        settings.debug = True
        test_case_0()
    finally:
        sys.stdout = sys.__stdout__
        settings.debug = False



# Generated at 2022-06-25 23:09:29.951169
# Unit test for function eager
def test_eager():
    def test_0():
        def fn_0():
            it_0 = iter(range(2))
            yield next(it_0)
            yield next(it_0)

        iterable_0 = eager(fn_0)
        list_0 = list(iterable_0())
    test_0()


# Generated at 2022-06-25 23:09:35.324036
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO

    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        debug(lambda: 'test message')
        output = out.getvalue().strip()
        assert output.startswith('[py-backwards] DEBUG:')
        assert output == '\x1b[34m[py-backwards] DEBUG: test message\x1b[0m', output
    finally:
        sys.stderr = saved_stderr



# Generated at 2022-06-25 23:09:40.354755
# Unit test for function debug
def test_debug():
    # Line 1: def test_debug():
    # Line 2:     # Line 1: def test_debug():
    str_1 = '# Line 1: def test_debug():'
    # Line 3:     # Line 2:     # Line 1: def test_debug():
    str_2 = '# Line 2:     # Line 1: def test_debug():'
    # Line 5:     assert False
    # Line 7:     assert True
    # Line 9:     assert False
    str_3 = 'assert False'
    # Line 10:     assert False
    # Line 11:     assert False


# Generated at 2022-06-25 23:09:42.722689
# Unit test for function debug
def test_debug():
    test_debug.count += 1
    if test_debug.count == 1:
        debug(lambda: 'I am a lambda')
    else:
        debug(lambda: 'I am another lambda')

test_debug.count = 0

# Generated at 2022-06-25 23:09:44.475664
# Unit test for function eager
def test_eager():
    global variables_generator_0
    global str_0
    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)


# Generated at 2022-06-25 23:09:45.506140
# Unit test for function debug
def test_debug():
    test_case_0()

# Generated at 2022-06-25 23:09:48.658325
# Unit test for function debug
def test_debug():
    str_0 = 'hello world'
    _debug = debug

    def debug(get_message: Callable[[], str]) -> None:
        _debug(lambda: str_0)

    test_case_0()
    assert str_0 == 'hello world'



# Generated at 2022-06-25 23:09:49.257249
# Unit test for function debug
def test_debug():
   assert debug(test_case_0) == None

# Generated at 2022-06-25 23:09:51.222590
# Unit test for function debug
def test_debug():
    assert(VariablesGenerator._counter == 0)
    debug(lambda: VariablesGenerator._counter)
    assert(VariablesGenerator._counter == 1)


# Generated at 2022-06-25 23:09:59.121532
# Unit test for function debug
def test_debug():
    warn_messages = []
    def mock_warn(message: str) -> None:
        warn_messages.append(message)

    current_warn = messages.warn
    messages.warn = mock_warn


# Generated at 2022-06-25 23:11:28.221892
# Unit test for function debug
def test_debug():
    assert debug(lambda: 1) == None


# Generated at 2022-06-25 23:11:35.532499
# Unit test for function debug
def test_debug():
    try:
        sys.stderr = StringIO()
        variables_generator_0 = VariablesGenerator()
        str_0 = get_source(variables_generator_0)
        settings_0 = settings(debug=True)
        def get_message_0() -> str:
            return str_0
        debug(get_message_0)
        assert sys.stderr.getvalue() == messages.debug(str_0) + '\n'
        settings_0.debug = False
        def get_message_1() -> str:
            return str_0
        debug(get_message_1)
        assert sys.stderr.getvalue() == messages.debug(str_0) + '\n'
    finally:
        sys.stderr = sys.__stderr__

# Unit test

# Generated at 2022-06-25 23:11:38.118427
# Unit test for function debug
def test_debug():
    messages_0 = messages

    def get_message_0() -> str:
        return 'test_message'

    debug(get_message_0)
    settings_0 = settings.copy()
    settings_0['debug'] = False
    with settings_0:
        debug(get_message_0)

# Generated at 2022-06-25 23:11:39.056365
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:11:40.736291
# Unit test for function debug
def test_debug():
    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)
    debug(lambda: str_0)



# Generated at 2022-06-25 23:11:42.501541
# Unit test for function debug
def test_debug():
    messages.debug = lambda x: x
    debug(lambda: 'a')
    settings.debug = True
    debug(lambda: 'a')
    assert messages.debug('a') == 'a'

# Generated at 2022-06-25 23:11:45.108523
# Unit test for function eager
def test_eager():
    @eager
    def eager_0():
        return range(10)

    for i in eager_0:
        assert isinstance(i, int)


# Generated at 2022-06-25 23:11:46.814936
# Unit test for function debug
def test_debug():
    # Arguments
    get_message = lambda: 'Hello, World!'

    # Test
    debug(get_message)

    # Assertions
    assert False


# Generated at 2022-06-25 23:11:53.395189
# Unit test for function eager
def test_eager():
    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)
    variables_generator_1 = VariablesGenerator()
    str_1 = get_source(variables_generator_1)
    variables_generator_2 = VariablesGenerator()
    str_2 = get_source(variables_generator_2)
    variables_generator_3 = VariablesGenerator()
    str_3 = get_source(variables_generator_3)
    variables_generator_4 = VariablesGenerator()
    str_4 = get_source(variables_generator_4)
    variables_generator_5 = VariablesGenerator()
    str_5 = get_source(variables_generator_5)
    variables_generator_6

# Generated at 2022-06-25 23:11:57.734194
# Unit test for function eager
def test_eager():
    def test_eager_case_1():
        def eager_case_1_0():
            def eager_case_1_0_0():
                int_0 = 0
                while True:
                    yield int_0
                    int_0 += 1
            return eager(eager_case_1_0_0)()
        list_0 = eager_case_1_0()
        list_1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        assert list_0 == list_1, 'AssertionError'
    test_eager_case_1()