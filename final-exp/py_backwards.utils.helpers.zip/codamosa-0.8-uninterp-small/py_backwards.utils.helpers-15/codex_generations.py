

# Generated at 2022-06-25 23:03:38.342839
# Unit test for function get_source
def test_get_source():
    """Returns source code of the function."""
    source_0 = 'def func_0(a, b):\n' \
               '    c = a + b\n' \
               '    return c'
    import inspect
    import py_backwards.utils
    func_0 = inspect.getsource(test_case_0)
    assert func_0 == source_0

# Generated at 2022-06-25 23:03:42.574481
# Unit test for function debug
def test_debug():
    class MyClass:
        def __init__(self):
            self.arg = 0
        
        def foo(self, arg: int) -> int:
            debug(lambda : 'inside the method foo, arg = %d' % arg)
            return 1

    klass = MyClass()
    klass.foo(1)



# Generated at 2022-06-25 23:03:44.821155
# Unit test for function debug
def test_debug():
    def get_message():
        return 'debug message'

    debug(get_message)



# Generated at 2022-06-25 23:03:47.740483
# Unit test for function get_source
def test_get_source():
    import ast

    node = ast.parse(get_source(test_case_0))
    assert len(node.body) == 1
    assert isinstance(node.body[0].value, ast.Name)



# Generated at 2022-06-25 23:03:48.940324
# Unit test for function eager
def test_eager():
    messages.clear()
    test_case_0()
    assert messages.get() == ""

# Generated at 2022-06-25 23:03:52.921261
# Unit test for function get_source
def test_get_source():
    source_original = inspect.getsource(test_case_0)
    source_backup = get_source(test_case_0)
    assert source_backup in source_original


# Generated at 2022-06-25 23:03:54.361856
# Unit test for function eager
def test_eager():
    callable_0 = None
    callable_1 = eager(callable_0)


# Generated at 2022-06-25 23:04:03.624817
# Unit test for function debug
def test_debug():
    import sys
    import tempfile
    import contextlib

    @contextlib.contextmanager
    def capture():
        old = sys.stderr
        try:
            fd, path = tempfile.mkstemp()
            sys.stderr = open(path, 'w')
            yield path
        finally:
            sys.stderr = old

    try:
        with capture() as f:
            debug(lambda: 'test')
        assert open(f).read() == ''
    finally:
        import os
        os.remove(f)


# Generated at 2022-06-25 23:04:05.772094
# Unit test for function eager
def test_eager():
    def test(a):
        yield a

    assert list(test(1)) == [1]
    assert eager(test)(1) == [1]



# Generated at 2022-06-25 23:04:13.345099
# Unit test for function get_source
def test_get_source():
    def test_func_0(arg_0: int, arg_1: str, arg_2: float = 42.0,
                    arg_3: int = 1, kwarg_0: str = 'kwarg_0') -> Any:
        pass

    def test_func_1(arg_0, arg_1, arg_2=42.0, arg_3=1, kwarg_0='kwarg_0'):
        pass

    def test_func_2(arg_0, arg_1, *args, arg_2=42.0, arg_3=1, **kwargs):
        pass

    def test_func_3(arg_0, arg_1, *args, arg_2=42.0, arg_3=1, **kwargs) -> Any:
        pass
    
    assert get_source

# Generated at 2022-06-25 23:04:21.010447
# Unit test for function get_source
def test_get_source():
    code = "def foo():\n    print(1)\n"
    def get_source_0():
        pass
    def get_source_1():
        i = 2
        j = 4
        k = 6
        return i + j + k
    assert(get_source(test_case_0) == code)
    assert(get_source(get_source_0) == code)
    assert(get_source(get_source_1) == code)



# Generated at 2022-06-25 23:04:29.944805
# Unit test for function eager
def test_eager():
    def test(a):
        pass
    test(0)
    def f():
        for i in range(0, 10):
            yield i
    def g():
        g_var = list()
        for i in f():
            g_var.append(i)

    # Check if it is a function
    assert callable(test)
    # Check if it is a function
    assert callable(f)
    # Check if it is a function
    assert callable(g)
    # Check if it is a function
    assert callable(eager)
    # Check if it is a function
    assert callable(test_case_0)
    # Check if it is a function
    assert callable(test_eager)
    # Check the callable function call

# Generated at 2022-06-25 23:04:30.804796
# Unit test for function get_source
def test_get_source():
    func_0 = None
    assert get_source(func_0) == "pass"


# Generated at 2022-06-25 23:04:32.662930
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_0 = None\ncallable_1 = eager(callable_0)\n'


# Generated at 2022-06-25 23:04:33.786053
# Unit test for function eager
def test_eager():
    callable_0 = None
    callable_1 = eager(callable_0)



# Generated at 2022-06-25 23:04:39.082457
# Unit test for function get_source
def test_get_source():
    if __name__ == '__main__':
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        import backward_lib.utils as module

        assert(module.get_source(test_get_source) == get_source(test_get_source))
        print('Test get_source ok')


# Generated at 2022-06-25 23:04:48.195824
# Unit test for function get_source
def test_get_source():
    """
    Checks get_source function
    """
    source_py_backwards = getsource(py_backwards.instrument.get_source)

    def test_func():
        '''
        Test func
        '''
        pass
    test_func.__wrapped__ = None
    source_test = getsource(test_func).split('\n')
    padding = len(re.findall(r'^(\s*)', source_test[0])[0])
    source_test = '\n'.join(line[padding:] for line in source_test)

    assert source_py_backwards == source_test



# Generated at 2022-06-25 23:04:55.308548
# Unit test for function debug
def test_debug():
    def test_debug_0():
        test_debug_0.call_counter = getattr(test_debug_0, 'call_counter', 0) + 1
        return test_debug_0.call_counter

    test_debug_0.call_counter = 0
    debug(lambda: test_debug_0())
    debug(lambda: test_debug_0())
    debug(lambda: test_debug_0())
    # Asserts that function test_debug_0 has been called exactly three times.
    assert getattr(test_debug_0, 'call_counter', 0) == 3

# Generated at 2022-06-25 23:04:59.180412
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == (
        'callable_0 = None\n'
        'callable_1 = eager(callable_0)'
    )

# Generated at 2022-06-25 23:05:00.743517
# Unit test for function eager
def test_eager():
    from .test import Case
    Case(callable_0=lambda: range(5)).run(test_case_0)

# Generated at 2022-06-25 23:05:11.685903
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    # Make sure get_source works for functions with a body
    assert get_source(foo) == "def foo():\n\tpass"

    # Make sure get_source works for functions without a body
    assert get_source(bar) == "def bar():\n\tpass"

    # Make sure get_source works for functions with multiline definitions
    assert get_source(baz) == "def baz():\n\tpass"


# Generated at 2022-06-25 23:05:21.887283
# Unit test for function debug
def test_debug():
    callable_0 = settings.debug
    callable_1 = sys.stderr
    callable_2 = settings.debug
    callable_3 = print
    callable_4 = get_source(test_debug)
    callable_5 = test_debug
    callable_6 = None
    callable_7 = settings.debug
    callable_8 = sys.stderr
    callable_9 = settings.debug
    callable_10 = print
    callable_11 = get_source(test_debug)
    callable_12 = test_debug
    callable_13 = None
    callable_14 = settings.debug
    callable_15 = sys.stderr
    callable_16 = settings.debug
    callable_17 = print

# Generated at 2022-06-25 23:05:29.389809
# Unit test for function debug
def test_debug():
    expected_output_0 = "-- Debug --\n\tsomething something..."
    actual_output_0 = sys.stderr.getvalue()
    expected_output_1 = "\x1b[31m-- Debug --\x1b[0m\n\t\x1b[31msomething something...\x1b[0m"
    actual_output_1 = sys.stderr.getvalue()
    assert expected_output_0 == actual_output_0
    assert expected_output_1 == actual_output_1


# Generated at 2022-06-25 23:05:31.462540
# Unit test for function debug
def test_debug():
    # We expect that this function prints nothing
    debug(lambda: '')
    
    # We expect that this function prints something
    settings.debug = True
    debug(lambda: 'test')

# Generated at 2022-06-25 23:05:34.177664
# Unit test for function eager
def test_eager():
    test_param_0 = callable_0
    test_return_0 = eager(test_param_0)
    assert test_return_0 == []



# Generated at 2022-06-25 23:05:44.580520
# Unit test for function debug
def test_debug():
    callable_0 = messages.debug
    callable_1 = print
    callable_1(callable_0(callable_1))
    callable_1('')
    callable_1(callable_0(callable_0))
    callable_1(callable_0(callable_0(callable_1)))
    callable_1()
    callable_1(callable_0(callable_0(callable_0)))
    callable_1(callable_0(callable_0(callable_0(callable_1))))
    callable_1()
    callable_1(callable_0(callable_0(callable_0(callable_0))))

# Generated at 2022-06-25 23:05:50.960065
# Unit test for function get_source
def test_get_source():
    def dummy_func():
        pass

    # Comparing source of the function to its parsed variant
    assert get_source(dummy_func) == indent(getsource(dummy_func), amount=4)


# Generated at 2022-06-25 23:05:52.881297
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == "def func():\n    pass\n"



# Generated at 2022-06-25 23:05:55.767939
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '    callable_0 = None\n    callable_1 = eager(callable_0)'

# Generated at 2022-06-25 23:05:57.531407
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_1 = eager(callable_0)'


# Generated at 2022-06-25 23:06:08.574638
# Unit test for function get_source
def test_get_source():
    def get_source_test():
        return 'return "test 0"'

    assert get_source(get_source_test) == 'return "test 0"'



# Generated at 2022-06-25 23:06:09.722077
# Unit test for function get_source

# Generated at 2022-06-25 23:06:10.794054
# Unit test for function get_source
def test_get_source():
    def foo():
        bar = 0
    assert get_source(foo).strip() == 'bar = 0'



# Generated at 2022-06-25 23:06:18.670264
# Unit test for function debug
def test_debug():
    from py_backwards.utils.general import debug
    from unittest import mock
    mock_print = mock.MagicMock()

    # testing `debug` with debug disabled
    debug(lambda: "message")
    mock_print.assert_not_called()

    # testing `debug` with debug enabled
    settings.debug = True
    with mock.patch("sys.stderr", mock_print):
        debug(lambda: "message")
    mock_print.assert_called_once()

    # after calls `debug` debug should be disabled again
    settings.debug = False
    mock_print.reset_mock()
    debug(lambda: "message")
    mock_print.assert_not_called()



# Generated at 2022-06-25 23:06:21.394920
# Unit test for function debug
def test_debug():
    args = []
    def get_message():
        args.append(1)
        return 'Hello World'
    debug(get_message)
    assert args == [1]


# Generated at 2022-06-25 23:06:24.628580
# Unit test for function debug
def test_debug():
    import pytest  # type: ignore
    def test_function(message: str):
        debug(lambda: message)
    with pytest.raises(TypeError):
        test_function()


# Generated at 2022-06-25 23:06:27.235879
# Unit test for function eager
def test_eager():
    callable_0 = None
    callable_1 = eager(callable_0)
    assert_true(isinstance(callable_1, Callable))



# Generated at 2022-06-25 23:06:29.283233
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert source == 'callable_0 = None\ncallable_1 = eager(callable_0)', source


# Generated at 2022-06-25 23:06:30.863080
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_0 = None\ncallable_1 = eager(callable_0)'



# Generated at 2022-06-25 23:06:32.830011
# Unit test for function eager
def test_eager():
    assert callable_1 is not None
    assert callable_1(3) == []
    #  Function eager returned unexpected result


# Generated at 2022-06-25 23:06:54.021196
# Unit test for function eager
def test_eager():
    try:
        func = eager(__fake_function_0)
        func_args, func_kwargs = (), {}
        with pytest.raises(TypeError):
            func(*func_args, **func_kwargs)
    except NameError:
        pass


# Generated at 2022-06-25 23:06:56.229701
# Unit test for function get_source
def test_get_source():
    callable_0 = lambda: 1
    expected = ('def callable_0():\n'
                '    return 1')
    actual = get_source(callable_0)
    assert actual == expected


# Generated at 2022-06-25 23:06:59.246827
# Unit test for function eager
def test_eager():
    callable_0 = 1
    callable_1 = eager(callable_0)
    assert callable_1(1, 2, 3) == [1, 2, 3]



# Generated at 2022-06-25 23:07:00.748981
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "callable_0 = None"



# Generated at 2022-06-25 23:07:01.826823
# Unit test for function debug
def test_debug():
    foo = "bar"
    debug(lambda: foo)



# Generated at 2022-06-25 23:07:10.957473
# Unit test for function debug
def test_debug():
    from .. import messages
    from ..conf import settings
    from . import debug, get_source

    message = 'message'

    fake_stderr = []
    debug_source = get_source(debug)
    exec(debug_source, locals(), {
        'settings': {'debug': True},
        'messages': {'debug': lambda message: message},
        'print': lambda *args, **kwargs: fake_stderr.append(args),
        'get_source': get_source,
        'warn': lambda *args, **kwargs: None,
    })
    get_message = lambda: message
    callable_0 = debug(get_message)
    callable_0()
    assert fake_stderr == [['message', '\n']]

    fake_stderr = []

# Generated at 2022-06-25 23:07:12.566273
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == test_case_0.__code__.co_code \
        .decode('utf-8')

# Generated at 2022-06-25 23:07:15.842996
# Unit test for function get_source
def test_get_source():
    def test(x):
        pass
    source_lines = getsource(test).split('\n')
    padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
    correct = '\n'.join(line[padding:] for line in source_lines)
    assert correct == get_source(test)

# Generated at 2022-06-25 23:07:17.378084
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_1 = eager(callable_0)'


# Generated at 2022-06-25 23:07:20.648724
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '\n'.join([
        'def test_case_0():',
        '    callable_0 = None',
        '    callable_1 = eager(callable_0)'
    ])


# Generated at 2022-06-25 23:08:03.096799
# Unit test for function get_source
def test_get_source():
    def function_0():
        function_3 = None
        function_4 = eager(function_3)

    assert get_source(function_0) == '\n    function_3 = None\n\
    function_4 = eager(function_3)'.replace(' ', '')



# Generated at 2022-06-25 23:08:04.701677
# Unit test for function get_source
def test_get_source():
    def function_0(parameter_0):
        return 42

    assert get_source(function_0) == 'return 42'



# Generated at 2022-06-25 23:08:07.001490
# Unit test for function get_source
def test_get_source():
    def test_func(arg_0, arg_1):
        return arg_0 + arg_1
    source = get_source(test_func)
    assert source == '    return arg_0 + arg_1'

# Generated at 2022-06-25 23:08:08.514262
# Unit test for function eager
def test_eager():
    from py_backwards.utils import eager
    callable_0 = None
    callable_1 = eager(callable_0)


# Generated at 2022-06-25 23:08:10.385413
# Unit test for function debug
def test_debug():
    DEBUG = False
    settings.debug = DEBUG
    def get_message():
        return 'debug message'
    debug(get_message)
    assert settings.debug == DEBUG


# Generated at 2022-06-25 23:08:13.004175
# Unit test for function get_source
def test_get_source():
    def fun_x():
        pass

    def fun_y(x, y, z=1):
        pass

    assert get_source(fun_x) == 'pass'
    assert get_source(fun_y) == 'pass'

# Generated at 2022-06-25 23:08:15.351201
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """    callable_0 = None
    callable_1 = eager(callable_0)"""

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:08:20.018149
# Unit test for function debug
def test_debug():
    callable_2 = None
    callable_3 = messages.debug('hello')
    callable_4 = print
    callable_5 = sys.stderr
    callable_4(callable_3, file=callable_5)
    callable_4(messages.debug('hello'), file=sys.stderr)
    debug(callable_2)


# Generated at 2022-06-25 23:08:21.252322
# Unit test for function debug
def test_debug():
    assert isinstance(messages.debug('Hi!'), str) is True


# Generated at 2022-06-25 23:08:24.038524
# Unit test for function get_source
def test_get_source():
    code = get_source(test_case_0)
    assert code == 'None\n'


# Generated at 2022-06-25 23:09:20.080618
# Unit test for function eager
def test_eager():
    callable_0 = mock.Mock()
    callable_0.return_value = (1, 2, 3)
    callable_1 = eager(callable_0)
    assert callable_1() == [1, 2, 3]
    assert callable_0.call_count == 1
    assert callable_0.call_args == mock.call()


# Generated at 2022-06-25 23:09:21.435754
# Unit test for function debug
def test_debug():
    callable_0 = None
    callable_1 = debug(callable_0)


# Generated at 2022-06-25 23:09:24.094007
# Unit test for function get_source
def test_get_source():
    def foo():
        def bar():
            pass
    actual = get_source(foo)
    expected = '    def foo():\n' \
               '        def bar():\n' \
               '            pass'
    assert actual == expected

# Generated at 2022-06-25 23:09:27.318444
# Unit test for function get_source
def test_get_source():
    def function():
        callable_0 = None
        callable_1 = eager(callable_0)

    assert get_source(function) == 'def function():\n'\
        '    callable_0 = None\n'\
        '    callable_1 = eager(callable_0)\n'

# Generated at 2022-06-25 23:09:31.824205
# Unit test for function debug
def test_debug():
    global captured_stdout
    # Replace stdout so that we can assert against it
    captured_stdout = StringIO()
    sys.stdout = captured_stdout

    try:
        debug(lambda: 'Hello world')
        output = captured_stdout.getvalue().strip()

        assert 'Hello world' in output
        assert 'DEBUG' in output
    finally:
        # Reset stdout
        captured_stdout = sys.stdout


# Generated at 2022-06-25 23:09:39.122308
# Unit test for function eager
def test_eager():
    import tempfile
    import os
    import sys
    import inspect

    # SUT
    from ..utils import eager

    with tempfile.NamedTemporaryFile() as f:
        # save original stdout
        stdout = sys.stdout
        # replace stdout with temporary file
        sys.stdout = f
        # run test case
        test_case_0()
        # get stdout from temporary file
        f.seek(0)
        out = f.read()
        # restore stdout
        sys.stdout = stdout

    # Assert that there are no errors
    assert out == b'', 'There are errors'

    # Assert that there are no diffs
    assert not os.system('python -m pytest --capture=no tests/utils_test.py'), 'There are diffs'


#

# Generated at 2022-06-25 23:09:40.952758
# Unit test for function eager
def test_eager():
    import pytest
    test_case_0()
    with pytest.raises(TypeError, match=r'.+ is not callable$'):
        callable_1()

# Generated at 2022-06-25 23:09:42.854293
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == \
"""    callable_0 = None
    callable_1 = eager(callable_0)
"""

# Generated at 2022-06-25 23:09:43.697335
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == test_case_0



# Generated at 2022-06-25 23:09:46.536187
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        message = 'testing'
        debug(lambda: message)
    finally:
        settings.debug = False



# Generated at 2022-06-25 23:11:41.888363
# Unit test for function get_source
def test_get_source():
    def function_0(): pass
    assert get_source(function_0) == 'def function_0(): pass'


# Generated at 2022-06-25 23:11:42.773657
# Unit test for function get_source
def test_get_source():
    assert get_source(1) == "1"


# Generated at 2022-06-25 23:11:45.203348
# Unit test for function eager
def test_eager():
    callable_0 = None
    callable_1 = eager(callable_0)
    assert callable_1 is not None


# Generated at 2022-06-25 23:11:46.684211
# Unit test for function debug
def test_debug():
    try:
        settings.debug = True
        debug(lambda: 'test debug')
    finally:
        settings.debug = False


# Generated at 2022-06-25 23:11:49.376677
# Unit test for function eager
def test_eager():
    def f(n):
        i = 0
        while i < n:
            yield i
            i += 1
    assert eager(f)(3) == [0, 1, 2]
    assert eager(f)(1) == [0]
    assert eager(f)(0) == []

# Generated at 2022-06-25 23:11:54.045681
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    lines_of_test_function = '\n'.join('{}'.format(line) for line in getsource(test_function).split('\n'))

    def test_function_return_get_source():
        return get_source(test_function)

    lines_of_test_function_return_get_source = '\n'.join('{}'.format(line) for line in getsource(test_function_return_get_source).split('\n'))

    assert test_function_return_get_source == lines_of_test_function



# Generated at 2022-06-25 23:11:55.172748
# Unit test for function get_source
def test_get_source():
    def get_callable():
        def callable():
            pass
        return callable

# Generated at 2022-06-25 23:11:56.621968
# Unit test for function get_source
def test_get_source():
    def callable_0():
        pass
    assert get_source(callable_0) == '    pass'


# Generated at 2022-06-25 23:12:02.285105
# Unit test for function debug
def test_debug():
    def test():
        def test(message):
            warnings = []
            old_print = print
            def print(message):
                warnings.append(message)
            debug(lambda: message)
            print = old_print
            return warnings
        test_cases = {
            'test': [messages.DEBUG + 'test'],
            'test test': [messages.DEBUG + 'test test'],
            'test test test': [messages.DEBUG + 'test test test'],
        }
        for test_case, expected in test_cases.items():
            yield test, test_case, expected
    test_list = list(test())
    for parameters in test_list:
        test, test_case, expected = parameters
        assert test(test_case) == expected


# Generated at 2022-06-25 23:12:04.046992
# Unit test for function get_source
def test_get_source():
    def callable_0(): pass
    assert get_source(test_case_0) == """callable_0 = None
callable_1 = eager(callable_0)
"""

