

# Generated at 2022-06-25 23:03:35.968410
# Unit test for function get_source
def test_get_source():
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 23:03:37.780271
# Unit test for function get_source
def test_get_source():
    from .functional import get_source
    from .messages import warn
    actual = get_source(warn)

# Generated at 2022-06-25 23:03:39.914849
# Unit test for function get_source
def test_get_source():
    assert 'str_0 = \'tvPTu"g?e~t!+\'' in get_source(test_case_0)


# Generated at 2022-06-25 23:03:41.205415
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:03:46.213957
# Unit test for function eager
def test_eager():
    def func_0(a: List) -> Iterable[int]:
        var_0 = 0
        var_1 = 0
        var_2 = 0
        while var_2 < var_1:
            test_case_0()
            var_0 += 1
            var_2 += 1
        return var_0
    var_0 = eager(func_0)
    assert var_0

# Generated at 2022-06-25 23:03:49.025082
# Unit test for function get_source
def test_get_source():
    str_0 = ('def silly_function():\n'
             '    do_something_silly()\n'
             '    return "SILLY"')
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:03:53.860392
# Unit test for function get_source
def test_get_source():
    # Tests for get_source
    if get_source(test_case_0) == 'str_0 = \'tvPTu"g?e~t!+\'\nwarn(str_0)\n':
        print('test0 passed')
    else:
        print('test0 failed')



# Generated at 2022-06-25 23:03:56.945705
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '\n'.join(['def test_case_0():', '    str_0 = "tvPTu"g?e~t!+"', '    warn(str_0)'])


# Generated at 2022-06-25 23:03:59.192779
# Unit test for function get_source
def test_get_source():
    test_case_0()


if __name__ == '__main__':
    test_get_source()
    print('OK')

# Generated at 2022-06-25 23:04:00.993328
# Unit test for function debug
def test_debug():
    str_0 = 'tvPTu"g?e~t!+'
    debug(lambda : str_0)


# Generated at 2022-06-25 23:04:04.102989
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0

# Generated at 2022-06-25 23:04:05.875208
# Unit test for function get_source
def test_get_source():
    # Testing empty function
    function_empty = eval(str_0)
    assert get_source(function_empty) == str_0


# Generated at 2022-06-25 23:04:11.780544
# Unit test for function debug
def test_debug():
    test_str = 'test_str'
    test_func = lambda: test_str
    # Check that the debug func prints to stderr
    with patch('sys.stderr') as stderr:
        debug(test_func)
        assert stderr.write.called
    # Check that the debug func capturess the message
    with patch('py_backwards.utils.messages.debug') as messages_debug:
        debug(test_func)
        messages_debug.assert_called_with(test_func())


# Generated at 2022-06-25 23:04:13.070412
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:04:15.116235
# Unit test for function get_source
def test_get_source():
    test_case_0()
    return get_source(silly_function) == str_0


# Generated at 2022-06-25 23:04:24.147406
# Unit test for function eager
def test_eager():
    from six import assertCountEqual
    from . import eager
    from . import generator
    from . import inspect
    from . import messages
    from . import settings
    from . import transform
    from . import utils
    from . import variable

    assert settings.debug is False
    assert settings.trace is False
    assert settings.history is False
    assert settings.debug_history is False
    assert settings.forward is True

    local_0 = 'this'
    local_1 = None
    local_0 = 'is'
    local_1 = None
    local_0 = 'a'
    local_1 = None
    local_0 = 'test'
    local_1 = None


# Generated at 2022-06-25 23:04:26.761927
# Unit test for function get_source
def test_get_source():
    try:
        assert get_source(test_case_0) == str_0
    except AssertionError:
        return False
    return True
        

# Generated at 2022-06-25 23:04:27.980505
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:04:32.715676
# Unit test for function eager
def test_eager():
    # Test with input arg of type string
    try:
        assert eager(str_0) == 'def silly_function():\n    do_something_silly()\n    return "SILLY"'
    except:
        print("Function eager is failing on input arg of type string")

    # Test with input arg of type function
    try:
        assert eager(test_case_0) == ''
    except:
        print("Function eager is failing on input arg of type function")



# Generated at 2022-06-25 23:04:33.830484
# Unit test for function get_source
def test_get_source():
    my_source = get_source(test_case_0)
    assert (my_source == str_0)



# Generated at 2022-06-25 23:04:40.175772
# Unit test for function get_source
def test_get_source():
    # Test 0
    def silly_function():
        do_something_silly()
        return "SILLY"
    str_0 = get_source(silly_function)
    assert str_0 == 'def silly_function():\n    do_something_silly()\n    return "SILLY"'


# Generated at 2022-06-25 23:04:41.402585
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:04:43.152507
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:04:46.647114
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:04:55.769937
# Unit test for function eager
def test_eager():
    import pytest
    from inspect import getsource
    from copy import copy
    from itertools import cycle, zip_longest
    def silly_function():
        do_something_silly()
        yield "SIL"
        yield "LY"
    silly_function_list = eager(silly_function)
    assert isinstance(silly_function_list, type(lambda: None))
    assert getsource(silly_function_list) == str_0
    assert silly_function_list() == ["SILLY"]
    assert silly_function_list() == ["SILLY"]

    assert silly_function_list() == ["SILLY"]


# Generated at 2022-06-25 23:04:58.276424
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == ["SILLY"]



# Generated at 2022-06-25 23:05:00.112204
# Unit test for function debug
def test_debug():
    if settings.debug:
        print(messages.debug('SILLY'), file=sys.stderr)


# Generated at 2022-06-25 23:05:01.335933
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:05:03.672189
# Unit test for function debug
def test_debug():
    try:
        debug_0 = debug(test_case_0)
        print("test_case_0")
    except:
        pass


# Generated at 2022-06-25 23:05:04.985934
# Unit test for function eager
def test_eager():
    assert eager(range)(10) == list(range(10))


# Generated at 2022-06-25 23:05:18.886071
# Unit test for function eager
def test_eager():
  class TestClass:
    def test_eager_fn(self):
        def silly_function():
            return "SILLY"
        lst_0 = list(silly_function())
        ass_0 = list(silly_function())
        str_0 = str(lst_0)
        str_1 = str(ass_0)
        assert(str_0 == str_1)

if __name__ == '__main__':
    # Unit test for function eager
    test_eager()

    # Unit test for class VariablesGenerator
    def test_generate():
        class TestClass:
            def test_generate(self):
                assert(VariablesGenerator.generate("_py_backwards_variable") == "_py_backwards_variable_0")
        test_class_0 = TestClass

# Generated at 2022-06-25 23:05:20.688589
# Unit test for function debug
def test_debug():
    args0 = (str_0)
    debug(get_message=lambda: ''.join(args0))



# Generated at 2022-06-25 23:05:25.378026
# Unit test for function eager
def test_eager():

    @eager
    def silly_function():
        for i in range(10):
            yield i
    assert silly_function == [0,1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-25 23:05:26.949817
# Unit test for function debug
def test_debug():
    print(str(debug(test_case_0)))


# Generated at 2022-06-25 23:05:29.769070
# Unit test for function get_source
def test_get_source():
    str_0 = 'def silly_function():\n    do_something_silly()\n    return "SILLY"'
    str_1 = get_source(test_case_0)
    assert str_0 == str_1


# Generated at 2022-06-25 23:05:35.450321
# Unit test for function get_source
def test_get_source():
    # Case 0
    str_0 = get_source(test_case_0)
    assert str_0 == 'str_0 = \'def silly_function():\\n    do_something_silly()\\n    return "SILLY"\'', 'Expected value: \'str_0 = \'def silly_function():\\n    do_something_silly()\\n    return "SILLY"\'\', Actual value: ' + str_0
    print('Success')


# Generated at 2022-06-25 23:05:38.055323
# Unit test for function debug
def test_debug():
    settings.debug = False
    messages.debug = '{}'
    debug(lambda : 'This is a debug message')
    settings.debug = True
    debug(lambda : 'This is a debug message')


# Generated at 2022-06-25 23:05:39.377672
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == str_0


# Generated at 2022-06-25 23:05:46.502584
# Unit test for function get_source
def test_get_source():
    str_0 = 'def silly_function():\n    do_something_silly()\n    return "SILLY"'
    lines_0 = str_0.split('\n')
    padding_0 = len(re.findall(r'^(\s*)', lines_0[0])[0])
    out_0 = '\n'.join(line[padding_0:] for line in lines_0)
    assert get_source(test_case_0) == out_0

print(test_get_source())

# Generated at 2022-06-25 23:05:50.173425
# Unit test for function get_source
def test_get_source():
    fn = eval(str_0)
    if get_source(fn) != str_0:
        raise AssertionError()


# Generated at 2022-06-25 23:05:56.357411
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'#\\x8c\\x9e,\\xecJ\\x93\\xbc\\x1eAd\\x90\'\n\ncallable_0 = eager(bytes_0)'

# Generated at 2022-06-25 23:05:59.066062
# Unit test for function eager
def test_eager():
    """Test eager function."""
    warnings.simplefilter('ignore', ResourceWarning)

    test_case_0()

    print('All tests passed successfully')

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-25 23:06:00.965151
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == test_case_0.__code__.co_code.decode().strip()

# Generated at 2022-06-25 23:06:02.135210
# Unit test for function get_source

# Generated at 2022-06-25 23:06:07.940327
# Unit test for function debug
def test_debug():
    nop = lambda: None
    with patch("builtins.print") as mock_print:
        debug(nop)
        assert mock_print.call_count == 0
    with patch("builtins.print") as mock_print:
        settings.debug = True
        debug(nop)
        assert mock_print.call_count == 1
    with patch("builtins.print") as mock_print:
        debug("message")
        assert mock_print.call_count == 1
    settings.debug = False


# Generated at 2022-06-25 23:06:09.251725
# Unit test for function get_source

# Generated at 2022-06-25 23:06:11.855190
# Unit test for function get_source
def test_get_source():
    test = 'def foo(x, y):\n'\
           '    return x + y\n'
    test2 = 'def goo\n'\
            '    return x + y\n'
    test3 = 'def goo():\n'\
            '    return x + y\n'

    assert get_source(foo) == test
    assert get_source(goo) == test2



# Generated at 2022-06-25 23:06:20.820523
# Unit test for function get_source
def test_get_source():
    bytes_0 = b'\xf1\x1a\xab\x1f\x9c\xa2\xee\x11\xc0\xfcC\xfe\xfc\xab\xf9-'
    str_0 = '\x00'
    str_1 = '\n'
    str_2 = '\x1a'
    str_3 = '~'
    str_4 = '\x0c'
    str_5 = '\x1a'
    str_6 = '\x1a'
    str_7 = '\x1a'
    str_8 = '\x1a'
    str_9 = '\x1a'
    str_10 = '\x1a'
    str_11 = '\x1a'

# Generated at 2022-06-25 23:06:30.059094
# Unit test for function get_source
def test_get_source():
    debug(lambda: get_source(test_case_0))

# Generated at 2022-06-25 23:06:31.323697
# Unit test for function debug
def test_debug():
    @debug
    def set_debug():
        return 'something'
    set_debug()



# Generated at 2022-06-25 23:06:40.290456
# Unit test for function get_source
def test_get_source():
    def function_0():
        return None
    actual_value = get_source(function_0)
    expected_value = 'def function_0():\n        return None'
    assert actual_value == expected_value


# Generated at 2022-06-25 23:06:48.884057
# Unit test for function eager
def test_eager():
    # Test with lambda function
    function_0 = lambda: True
    equality_0 = eager(function_0) == [True]
    # Test with the bytes type

# Generated at 2022-06-25 23:06:53.787194
# Unit test for function debug
def test_debug():
    with patch('py_backwards.utils.settings.debug', True) as mock_debug:
        mock_get_message = Mock(return_value='mock message')
        debug(mock_get_message)
        mock_get_message.assert_called_once_with()
    with patch('py_backwards.utils.settings.debug', False) as mock_debug:
        mock_get_message = Mock(return_value='mock message')
        debug(mock_get_message)
        mock_get_message.assert_not_called()


# Generated at 2022-06-25 23:06:54.568672
# Unit test for function debug
def test_debug():
    debug(lambda: 'Hello World')


# Generated at 2022-06-25 23:06:55.590656
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0)


# Generated at 2022-06-25 23:06:56.088916
# Unit test for function debug
def test_debug():
    assert False

# Generated at 2022-06-25 23:06:59.655305
# Unit test for function get_source
def test_get_source():
    assert """bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
    callable_0 = eager(bytes_0)""" == get_source(test_case_0)

# Generated at 2022-06-25 23:07:01.137572
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_0 = eager(bytes_0)'


# Generated at 2022-06-25 23:07:03.481185
# Unit test for function eager
def test_eager():
    """
    Function to test the eager decorator
    """
    test_case_0()



# Generated at 2022-06-25 23:07:08.640741
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert source == '''def test_case_0():
    bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
    callable_0 = eager(bytes_0)
'''
    assert getsource(test_case_0) == source
    print('test_get_source ok')


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:07:22.038311
# Unit test for function debug
def test_debug():
    assert __name__ == '__main__'



# Generated at 2022-06-25 23:07:28.462204
# Unit test for function get_source
def test_get_source():
    func_name = "test_case_0"
    expected_output = "bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'\ncallable_0 = eager(bytes_0)"
    output = get_source(test_case_0)
    assert output == expected_output
    print(output)


# Generated at 2022-06-25 23:07:33.651865
# Unit test for function eager
def test_eager():
    function_0 = VariablesGenerator.generate
    bytes_0 = b'\xcc'
    str_0 = '_py_backwards_variable_0'
    callable_0 = eager(bytes_0)
    if (function_0('variable') != str_0):
        return False
    return callable_0[0] == bytes_0[0]


# Generated at 2022-06-25 23:07:36.339569
# Unit test for function debug
def test_debug():
    bool_0 = settings.DEBUG_MODE
    settings.DEBUG_MODE = False
    bool_1 = settings.DEBUG_MODE
    settings.DEBUG_MODE = bool_0


# Generated at 2022-06-25 23:07:37.492337
# Unit test for function debug
def test_debug():
    assert debug(get_source(test_case_0)) == None
	

# Generated at 2022-06-25 23:07:40.636044
# Unit test for function debug
def test_debug():
    settings.debug = True

    debug(lambda: 'hello world')
    debug(lambda: '')

    settings.debug = False

    with pytest.raises(AssertionError):
        debug(lambda: 'hello world')



# Generated at 2022-06-25 23:07:47.994416
# Unit test for function get_source
def test_get_source():
    source_lines = test_case_0.__code__.co_code.__str__().split('\n')
    padding = len(re.findall(r'^(\s*)', source_lines[0])[0])
    expected = '\n'.join(line[padding:] for line in source_lines)
    assert get_source(test_case_0) == expected


# Generated at 2022-06-25 23:07:48.824738
# Unit test for function debug
def test_debug():
    pass



# Generated at 2022-06-25 23:07:49.826393
# Unit test for function debug
def test_debug():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 23:07:51.182078
# Unit test for function debug
def test_debug():
    test_debug_0()
    test_debug_1()
    test_debug_2()


# Generated at 2022-06-25 23:08:15.410602
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'\ncallable_0 = eager(bytes_0)"

# Generated at 2022-06-25 23:08:20.554891
# Unit test for function debug
def test_debug():
    assert sys.stdout.getvalue() == ''
    debug(lambda: 'test')
    assert sys.stdout.getvalue() == ''
    settings.debug = True
    debug(lambda: 'test')
    assert sys.stdout.getvalue() == '\x1b[33m(DEBUG) test\x1b[0m\n'
    assert sys.stderr.getvalue() == ''


# Generated at 2022-06-25 23:08:30.029390
# Unit test for function debug
def test_debug():
    import sys
    import subprocess
    from io import StringIO
    from unittest import TestCase

    from .utils import get_source
    from .conf import settings

    def test_func():
        pass


# Generated at 2022-06-25 23:08:32.603024
# Unit test for function debug
def test_debug():
    variable_0 = VariablesGenerator.generate('var')
    variable_1 = VariablesGenerator.generate('var')

    def function_0():
        return variable_0

    def function_1():
        return variable_1

    debug(function_0)
    debug(function_1)

# Generated at 2022-06-25 23:08:33.229039
# Unit test for function eager
def test_eager():
    test_case_0()



# Generated at 2022-06-25 23:08:34.495441
# Unit test for function get_source

# Generated at 2022-06-25 23:08:37.080184
# Unit test for function debug
def test_debug():
    global bytes_0
    global callable_0

    may_fail = True
    if may_fail:
        return

    test_case_0()

    debug(lambda : b'bytes_0')
    debug(lambda : callable_0)


# Generated at 2022-06-25 23:08:39.719432
# Unit test for function eager
def test_eager():
    import unittest
    
    class TestEager(unittest.TestCase):
        def test_eager(self):
            self.assertEqual(test_case_0(), None)

    unittest.main()

# Generated at 2022-06-25 23:08:47.368032
# Unit test for function debug
def test_debug():
    with settings.debug as debug:
        debug = debug
    try:
        test_case_0()
        assert callable_0(x=x, y=y) == eager(bytes_0)(x=x, y=y)
    except (ValueError, TypeError, ZeroDivisionError):
        assert debug is not None
    else:
        assert debug is None
    finally:
        try:
            assert debug is None
            assert get_source(callable_0) == 'def callable_0(*args, **kwargs)\n    return list(bytes_0(*args, **kwargs))'
        finally:
            assert get_source(callable_0) == 'def callable_0(*args, **kwargs)\n    return list(bytes_0(*args, **kwargs))'
            assert debug is not None
           

# Generated at 2022-06-25 23:08:50.188601
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''    bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
    callable_0 = eager(bytes_0)'''

# Generated at 2022-06-25 23:09:19.979814
# Unit test for function get_source
def test_get_source():
    source_0 = get_source(test_case_0)
    assert source_0 == "test_case_0():\n    bytes_0 = b'#\\x8c\\x9e,\\xecJ\\x93\\xbc\\x1eAd\\x90'\n    callable_0 = eager(bytes_0)"


# Generated at 2022-06-25 23:09:20.721639
# Unit test for function debug
def test_debug():
    debug(lambda: 'hello')


# Generated at 2022-06-25 23:09:23.312470
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'#\\x8c\\x9e,\\xecJ\\x93\\xbc\\x1eAd\\x90\'\ncallable_0 = eager(bytes_0)'

# Generated at 2022-06-25 23:09:24.804219
# Unit test for function debug
def test_debug():
    assert 1 == 1
    debug(lambda: 'Running the test case.')


# Generated at 2022-06-25 23:09:25.626753
# Unit test for function eager
def test_eager():
    test_case_0()



# Generated at 2022-06-25 23:09:32.502118
# Unit test for function get_source
def test_get_source():
    import pytest               # type: ignore

    from py_backwards.analysis.source import get_source

    def f1(a: str, b: int) -> int:
        return len(a) + b
    assert get_source(f1).startswith('def f1(a:str, b:int) -> int:')

    class F2:
        def __call__(self, a: str) -> int:
            return len(a)
    assert get_source(F2).startswith('class F2:')

    def f3():
        return

    with pytest.raises(TypeError):
        get_source(f3)

    assert get_source(int.__add__).startswith('def __add__(self, other) -> int:')

# Generated at 2022-06-25 23:09:36.116510
# Unit test for function get_source
def test_get_source():
    cases = (
        (test_case_0, '    callable_0 = eager(bytes_0)'),
    )
    for (fn, expected_result) in cases:
        assert get_source(fn) == expected_result
    return 'test_get_source done'


# Generated at 2022-06-25 23:09:36.780480
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:09:43.482531
# Unit test for function debug
def test_debug():
    messages.debug('\x1f<\xed\xae\xbb\xb5\x11\x9c\x80')
    bytes_6 = b'\xae`\xba\xa2\x1f<\xed\xae\xbb\xb5\x11\x9c\x80'
    callable_0 = debug
    bytes_1 = b'\xae`\xba\xa2\x1f<\xed\xae\xbb\xb5\x11\x9c\x80'
    debug(bytes_1)
    bytes_2 = b'\xae`\xba\xa2\x1f<\xed\xae\xbb\xb5\x11\x9c\x80'
    callable_0()
    # DEBUG


# Generated at 2022-06-25 23:09:45.468194
# Unit test for function debug
def test_debug():
    callable_0 = VariablesGenerator.generate
    int_0 = 0
    while int_0 < 2:
        int_0 += 1


# Generated at 2022-06-25 23:10:49.897475
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "bytes_0 = b'#\\x8c\\x9e,\\xecJ\\x93\\xbc\\x1eAd\\x90'\ncallable_0 = eager(bytes_0)"


# Generated at 2022-06-25 23:10:52.557650
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == (
        'bytes_0 = b\'#\\x8c\\x9e,\\xecJ\\x93\\xbc\\x1eAd\\x90\'\n'
        'callable_0 = eager(bytes_0)'
    )

# Generated at 2022-06-25 23:10:53.149121
# Unit test for function debug
def test_debug():
    debug(lambda: 'test_message')

# Generated at 2022-06-25 23:10:55.364246
# Unit test for function debug
def test_debug():
    bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
    callable_0 = eager(bytes_0)


# Generated at 2022-06-25 23:11:02.909908
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "bytes_0 = b'#\\x8c\\x9e,\\xecJ\\x93\\xbc\\x1eAd\\x90'\n" + \
                                      'callable_0 = eager(bytes_0)'


# Generated at 2022-06-25 23:11:05.653754
# Unit test for function eager
def test_eager():
    from nose.tools import istest
    from .. import test_all

    with istest.assert_raises_regexp(TypeError, r"object is not callable"):
        test_all.setup_function(test_case_0)
        eager(None)


# Generated at 2022-06-25 23:11:06.920857
# Unit test for function eager
def test_eager():
    assert test_case_0() == None

test_eager()

# Generated at 2022-06-25 23:11:07.644969
# Unit test for function debug
def test_debug():
    pass


# Generated at 2022-06-25 23:11:10.955101
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
callable_0 = eager(bytes_0)"""

# Generated at 2022-06-25 23:11:16.977353
# Unit test for function debug
def test_debug():
    if settings.debug:
        from io import StringIO
        from unittest.mock import patch

        with patch('sys.stderr', new=StringIO()) as mock_stderr:
            debug(lambda: 'test')
        assert mock_stderr.getvalue() == '\x1b[34m[DEBUG] test\x1b[0m\n'

    else:
        from unittest.mock import patch

        with patch('sys.stdout', new=StringIO()) as mock_stdout:
            debug(lambda: 'test')
        assert not mock_stdout.getvalue()



# Generated at 2022-06-25 23:13:26.813019
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """\
bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
callable_0 = eager(bytes_0)\
"""

# Generated at 2022-06-25 23:13:27.952771
# Unit test for function debug
def test_debug():
    # Initialize args
    get_message = test_case_0
    # Call the function
    debug(get_message)



# Generated at 2022-06-25 23:13:28.840707
# Unit test for function debug
def test_debug():
    debug(test_case_0)


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-25 23:13:35.452216
# Unit test for function get_source
def test_get_source():
    bytes_0 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
    callable_0 = eager(bytes_0)
    int_0 = 0
    list_0 = []
    bytes_1 = b'#\x8c\x9e,\xecJ\x93\xbc\x1eAd\x90'
    bytes_2 = b'\x98\xe7\xd5\x9f\t\x05\xac\x8c\x99\xa5\x86\xaa\xd2\xad\x9d\xbe\xf5\x8b\x08'
    list_1 = [bytes_0, bytes_1, bytes_2]
    