

# Generated at 2022-06-25 23:03:35.348458
# Unit test for function debug
def test_debug():
    variables_generator_0 = VariablesGenerator()
    def get_message():
        return variables_generator_0.generate('test_case')
    debug(get_message)


# Generated at 2022-06-25 23:03:37.123144
# Unit test for function get_source
def test_get_source():
    def func():
        pass

    assert get_source(func) == 'def func():\n    pass\n'



# Generated at 2022-06-25 23:03:39.586226
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    variables_generator_0 = VariablesGenerator()\n'

# Generated at 2022-06-25 23:03:43.864333
# Unit test for function eager
def test_eager():
    def eager_fn_0(arg0: int) -> Iterable[int]:
        yield arg0

    def eager_fn_1(arg0: int) -> Iterable[int]:
        yield arg0

    eager_fn_2 = eager(eager_fn_0)

    assert eager_fn_2(3) == [3]

# Generated at 2022-06-25 23:03:46.415093
# Unit test for function debug
def test_debug():
    settings.debug = True
    messages.debug_prefix = 'DEBUG'
    test_case_0()
    test_case_1()
    settings.debug = False
    

# Generated at 2022-06-25 23:03:54.701522
# Unit test for function eager
def test_eager():
    # Set testing parameters
    eager_0 = eager(list)

    @eager_0
    def eager_1():
        yield '_py_backwards_0_0'

    # Unit test body
    # Test 1: ...
    assert eager_1() == ['_py_backwards_0_0']
    # Test 2: ...
    assert eager_1() == ['_py_backwards_0_0']
    # Test 3: ...
    assert eager_1() == ['_py_backwards_0_0']
    # Test 4: ...
    assert eager_1() == ['_py_backwards_0_0']
    # Test 5: ...
    assert eager_1() == ['_py_backwards_0_0']
    # Test 6: ...

# Generated at 2022-06-25 23:03:57.929699
# Unit test for function get_source
def test_get_source():
    # Test for an arbitrary function
    def foo():
        pass
    test_case_0()
    assert get_source(foo) == "def foo():\n    pass"


# Generated at 2022-06-25 23:04:00.710133
# Unit test for function get_source
def test_get_source():
    # The function to be tested
    def function_1():
        return 'value_0'

    # Make assertions about the function
    assert get_source(function_1) == "def function_1():\n    return 'value_0'"



# Generated at 2022-06-25 23:04:05.608726
# Unit test for function get_source
def test_get_source():
    test_case_0()

    # Test 1
    get_source_arg_1 = (lambda: print(10))
    get_source_expected_1 = r'''(lambda: print(10))'''
    get_source_returned_1 = get_source(get_source_arg_1)
    assert re.fullmatch(get_source_expected_1, get_source_returned_1) is not None


# Generated at 2022-06-25 23:04:11.028243
# Unit test for function eager
def test_eager():
    # No error should raise
    assert hasattr(eager, 'f_code')

    # Check whether the code blocks are correctly extracted from VariablesGenerator
    # Check whether the code blocks are correctly replaced
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()

if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-25 23:04:15.692825
# Unit test for function get_source
def test_get_source():
    def test_fn():
        pass
    assert get_source(test_fn) == dedent('''
        def test_fn():
            pass
    ''').strip()

# Generated at 2022-06-25 23:04:17.495863
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '    variables_generator_0 = VariablesGenerator()'


# Generated at 2022-06-25 23:04:22.526662
# Unit test for function get_source
def test_get_source():
    variables_generator_0 = VariablesGenerator()
    def func_tuple(a, b):
        c = a + b
        return c
    test_case_0()
    assert 'def func_tuple(a, b):' in get_source(func_tuple)
    # Currently does not pass
    # assert 'return c' in get_source(func_tuple)



# Generated at 2022-06-25 23:04:24.465883
# Unit test for function get_source
def test_get_source():
    def f1():
        def f2():
            pass
    assert get_source(f2) == 'pass'



# Generated at 2022-06-25 23:04:26.761914
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'



# Generated at 2022-06-25 23:04:29.906578
# Unit test for function get_source
def test_get_source():
    test_source_0 = get_source(test_case_0)
    assert test_source_0 == dedent('''
       def test_case_0():
           variables_generator_0 = VariablesGenerator()
       ''').strip()


# Generated at 2022-06-25 23:04:30.617538
# Unit test for function get_source

# Generated at 2022-06-25 23:04:34.736644
# Unit test for function debug
def test_debug():
    global _test_counter_0
    _test_counter_0 = 0

    def get_message_0() -> str:
        global _test_counter_0
        _test_counter_0 += 1
        return 'print'

    debug(get_message_0)
    assert _test_counter_0 == 1, 'debug calls function that makes message'
    settings.debug = False
    debug(get_message_0)
    assert _test_counter_0 == 1, 'debug does not call function when debug mode is disabled'


# Generated at 2022-06-25 23:04:40.801988
# Unit test for function debug
def test_debug():
    DEBUG = ["DEBUG: test_debug",
             "test_debug",
             "DEBUG: test_debug"]
    PREFIX = "DEBUG: "
    import io
    from contextlib import redirect_stdout
    f = io.StringIO()
    with redirect_stdout(f):
        debug(lambda : "test_debug")
    out = f.getvalue()
    assert out == PREFIX + DEBUG[-1] + '\n'


# Generated at 2022-06-25 23:04:45.682110
# Unit test for function eager
def test_eager():
    def my_function():
        for i in range(3):
            yield i

    my_function_0 = eager(my_function)
    assert my_function_0() == [0, 1, 2]



# Generated at 2022-06-25 23:04:57.035005
# Unit test for function get_source
def test_get_source():
    try:
        variables_generator_0 = VariablesGenerator()
    except:
        variables_generator_0 = VariablesGenerator()
    variables_generator_1 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)
    variables_generator_3 = VariablesGenerator()
    assert(variables_generator_1.generate('_py_backwards_variable') == '_py_backwards_variable_1')
    variables_generator_5 = VariablesGenerator()
    assert(variables_generator_1.generate('_py_backwards_variable') == '_py_backwards_variable_2')
    variables_generator_7 = VariablesGenerator()

# Generated at 2022-06-25 23:05:03.160433
# Unit test for function eager
def test_eager():
    import unittest

    @eager
    def eager_0() -> Iterable[Any]:
        yield from range(5)

    class TestEager(unittest.TestCase):
        def test_eager(self):
            self.assertEqual([item for item in eager_0()], [0, 1, 2, 3, 4])

    test_eager = TestEager()
    test_eager.test_eager()


# Generated at 2022-06-25 23:05:03.987872
# Unit test for function get_source
def test_get_source():
    _test_get_source_0()



# Generated at 2022-06-25 23:05:09.321212
# Unit test for function get_source
def test_get_source():
    source_0 = get_source(test_case_0)
    assert source_0 == """    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)
"""



# Generated at 2022-06-25 23:05:11.118134
# Unit test for function debug
def test_debug():
    # None test
    try:
        debug(None)
    except:
        None


# Generated at 2022-06-25 23:05:21.542437
# Unit test for function get_source
def test_get_source():
    print("Testing get_source")

    # ensure that the source code of function test_case_0 is
    # the same as the function definition
    assert get_source(test_case_0) == "variables_generator_0 = VariablesGenerator()\nstr_0 = get_source(variables_generator_0)"

    # ensure that the source code of function is returned as
    # a single string
    assert "\n" not in get_source(test_case_0)

    # ensure that the source code of function test_case_0 is
    # the same as the function definition
    assert get_source(test_case_0) == "variables_generator_0 = VariablesGenerator()\nstr_0 = get_source(variables_generator_0)"

    # ensure that the source code of function is returned

# Generated at 2022-06-25 23:05:23.666344
# Unit test for function debug
def test_debug():
    if settings.debug:
        print('Unit test for function debug called.')



# Generated at 2022-06-25 23:05:26.633704
# Unit test for function debug
def test_debug():
    variables_generator_1 = VariablesGenerator()
    str_1 = get_source(variables_generator_1)


# Generated at 2022-06-25 23:05:35.631671
# Unit test for function debug
def test_debug():
    class FakeStderr:
        def __init__(self) -> None:
            self.value = None

        def write(self, value: str) -> None:
            self.value = value

    fake_stderr = FakeStderr()
    settings.debug = True
    with mock.patch.object(sys, 'stderr', fake_stderr):
        debug(lambda: 'some message')

    assert fake_stderr.value.strip() == '\x1b[0;37m\x1b[41m\x1b[37mDEBUG\x1b[0m: \x1b[0msome message'
    settings.debug = False
    with mock.patch.object(sys, 'stderr', fake_stderr):
        debug(lambda: 'some message')

    assert fake

# Generated at 2022-06-25 23:05:39.711039
# Unit test for function get_source
def test_get_source():
    source_lines = VariablesGenerator.generate.__code__.co_code

    generated_code = test_case_0.__code__.co_code
    if generated_code != source_lines:
        raise AssertionError(__name__)

if __name__ == "__main__":
    test_get_source()

# Generated at 2022-06-25 23:05:47.808871
# Unit test for function get_source
def test_get_source():
    warn('Test for get_source')
    assert get_source(test_case_0) == '''\
    class VariablesGenerator:
        _counter = 0

        @classmethod
        def generate(cls, variable: str) -> str:
            """Generates unique name for variable."""
            try:
                return '_py_backwards_{}_{}'.format(variable, cls._counter)
            finally:
                cls._counter += 1
'''



# Generated at 2022-06-25 23:05:52.733568
# Unit test for function debug
def test_debug():
    if settings.debug:
        # Initialize test variables
        str_0 = 'test_variable'
        str_1 = 'str_2' + 'str_3'

        # Call function
        debug(lambda: str_0)
        debug(lambda: str_1)



# Generated at 2022-06-25 23:05:53.249522
# Unit test for function get_source
def test_get_source():
    assert True == True

# Generated at 2022-06-25 23:05:56.745701
# Unit test for function eager
def test_eager():
    def some_fn():
        yield 1
        yield 2
        yield 3

    some_fn = eager(some_fn)

    assert some_fn() == [1, 2, 3]


# Generated at 2022-06-25 23:05:57.859435
# Unit test for function get_source

# Generated at 2022-06-25 23:06:02.004297
# Unit test for function debug
def test_debug():
    pass
    # TODO: It is not possible to unit test print() / sys
    # messages.debug = lambda m: 'debug: ' + m
    # debug(lambda: 'foo')
    # assert sys.stderr.getvalue() == 'debug: foo\n'
    # sys.stderr.truncate(0)
    # assert _ == None

# Generated at 2022-06-25 23:06:03.594457
# Unit test for function debug
def test_debug():
    def get_message(): return 'message'
    debug(get_message)


# Generated at 2022-06-25 23:06:07.374293
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    variables_generator_0 = VariablesGenerator()\n    str_0 = get_source(variables_generator_0)\n'

if __name__ == '__main__':
    test_get_source()
    print('All tests passed!')

# Generated at 2022-06-25 23:06:08.490170
# Unit test for function eager
def test_eager():
    assert 1 == 1

test_eager()

# Generated at 2022-06-25 23:06:10.235738
# Unit test for function get_source
def test_get_source():
    variables_generator_1 = VariablesGenerator()
    assert get_source(variables_generator_1) != ''


# Generated at 2022-06-25 23:06:22.177389
# Unit test for function get_source
def test_get_source():
    _test_cases = [
        # test case #0
        (
            (test_case_0,),
            [
                'def generate(cls, variable):',
                '    """Generates unique name for variable."""',
                '    try:',
                '        return "_py_backwards_{}_{}".format(variable, cls._counter)',
                '    finally:',
                '        cls._counter += 1',
            ]
        ),
    ]
    for params, expected_result in _test_cases:
        actual_result = get_source(*params)
        try:
            assert actual_result == expected_result
        except AssertionError:
            print(messages.failed_test(
                'get_source', params, expected_result, actual_result))

# Generated at 2022-06-25 23:06:22.980910
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:06:25.900226
# Unit test for function debug
def test_debug():
    variables_generator_0 = VariablesGenerator()
    debug(lambda: get_source(variables_generator_0))


# Generated at 2022-06-25 23:06:30.264622
# Unit test for function eager
def test_eager():
    list_0 = []
    def func_0(arg_1, arg_2):
        str_0 = get_source(func_0)
        list_0.append(arg_1 + arg_2)
    func_1 = eager(func_0)
    func_1(1, 2)
    func_1(2, 3)
    list_1 = list(list_0)


# Generated at 2022-06-25 23:06:32.012466
# Unit test for function debug
def test_debug():
    if hasattr(print, '__call__'):
        def get_message_0() -> str:
            return 'test'
        debug(get_message_0)


# Generated at 2022-06-25 23:06:35.557247
# Unit test for function eager
def test_eager():
    import unittest

    class TestEager(unittest.TestCase):
        def test_eager_0(self):
            @eager
            def f():
                yield 1

            self.assertEqual([1], f())

    unittest.main()

# Generated at 2022-06-25 23:06:44.474019
# Unit test for function debug
def test_debug():
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''

    def test_0() -> None:
        nonlocal str_4
        def test_1() -> str:
            nonlocal str_5
            str_5 = 'Hello'
            return str_5
        str_4 = get_message()
        debug(test_1)
        return None
    test_0()
    assert str_4 == 'Hello'
    assert str_5 == 'Hello'
    assert str_6 == ''
    assert str_7 == ''
    assert str_8 == ''
    assert str_9 == ''


# Generated at 2022-06-25 23:06:46.519392
# Unit test for function eager
def test_eager():
    def f():
        for i in range(3):
            yield i
    assert eagerly(f) == [0, 1, 2]


# Generated at 2022-06-25 23:06:48.698312
# Unit test for function get_source
def test_get_source():
    variables_generator_0 = VariablesGenerator()
    assert "def generate(cls, variable):\n" in get_source(variables_generator_0)



# Generated at 2022-06-25 23:06:54.208602
# Unit test for function debug
def test_debug():
    # Put all arguments as strings to test if printing works correctly
    # First, test `debug=true` setting
    settings.debug = True
    test_var = 42
    try:
        debug(lambda: 'debugging variable: {}'.format(test_var))
    except Exception as e:
        print('Function debug raised an exception: {}'.format(e))
    # Then test `debug=false` setting
    settings.debug = False
    try:
        debug(lambda: 'debugging variable: {}'.format(test_var))
    except Exception as e:
        print('Function debug raised an exception: {}'.format(e))

test_case_0()

test_debug()

# Generated at 2022-06-25 23:06:58.559523
# Unit test for function get_source
def test_get_source():
    assert test_case_0() is None

# Generated at 2022-06-25 23:07:02.802095
# Unit test for function get_source
def test_get_source():
    # assert_equals(actual, expected)
    assert_equals(get_source(test_case_0), 'def generate(variable):\n    try:\n        return \'_py_backwards_{}_{}\'.format(variable, cls._counter)\n    finally:\n        cls._counter += 1\n')



# Generated at 2022-06-25 23:07:03.860084
# Unit test for function get_source
def test_get_source():
    pass


# Generated at 2022-06-25 23:07:04.670122
# Unit test for function get_source
def test_get_source():
    test_case_0()
    # ...

# Generated at 2022-06-25 23:07:07.574379
# Unit test for function debug
def test_debug():
    captured_output = StringIO()
    sys.stdout = captured_output
    debug(settings.debug)
    sys.stdout = sys.__stdout__
    assert captured_output.getvalue() == '\033[33mDEBUG\033[0m: True\n'


# Generated at 2022-06-25 23:07:13.947925
# Unit test for function debug
def test_debug():
    test_res_set_0 = []
    def test_func_0(_arg_0: Any) -> str:
        return str(_arg_0)
    try:
        debug(test_func_0)('_py_backwards_counter_0')
    except Exception as e:
        test_res_set_0.append(e)
    try:
        settings.debug = True
        debug(test_func_0)('_py_backwards_counter_0')
    except Exception as e:
        test_res_set_0.append(e)
    settings.debug = False
    return test_res_set_0


# Generated at 2022-06-25 23:07:14.397247
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:07:16.015164
# Unit test for function debug
def test_debug():
    global counter
    counter = 0
    def get_debug_message():
        x = counter
        counter += 1
        return 'debug ' + str(x)

    print('--- test_debug ---')
    debug(get_debug_message)
    debug(get_debug_message)
    debug(get_debug_message)


# Generated at 2022-06-25 23:07:17.796113
# Unit test for function eager
def test_eager():
    # Test argument types and missing arguments
    print(eager(
        lambda a, b: [],
        a=None,
        b=None
    ))


# Generated at 2022-06-25 23:07:23.754823
# Unit test for function get_source
def test_get_source():
    funcs_to_test = [test_case_0]
    for func in funcs_to_test:
        try:
            func()
        except Exception:
            print("Error: " + func.__name__)
            print("\t" + str(sys.exc_info()[1]))
            raise
            
if __name__ == "__main__":
    test_case_0()
    test_get_source()

# Generated at 2022-06-25 23:07:31.757858
# Unit test for function debug
def test_debug():
    debug(test_case_0)

# Generated at 2022-06-25 23:07:36.806708
# Unit test for function debug
def test_debug():
    def test_case_1():
        variables_generator_1 = VariablesGenerator()
        str_1 = get_source(variables_generator_1)
        debug(lambda:get_source(variables_generator_1))
        debug(lambda:get_source(variables_generator_1))
        debug(lambda:get_source(variables_generator_1))
    test_case_1()



# Generated at 2022-06-25 23:07:48.292698
# Unit test for function debug
def test_debug():
    global debug
    debug_0 = debug
    @wraps(debug)
    def wrapped(*args):
        args[0](args[1])
    debug = wrapped
    warn_0 = warn
    @wraps(warn)
    def wrapped(*args):
        args[0](args[1])
    warn = wrapped
    @wraps(settings.debug)
    def wrapped(_):
        return True
    settings.debug = wrapped
    def get_message(_):
        return 'test'
    debug(get_message)
    settings.debug = wrapped
    @wraps(settings.debug)
    def wrapped(_):
        return False
    settings.debug = wrapped
    debug(get_message)
    warn = warn_0
    debug = debug_0
# /Unit test for function debug


# Generated at 2022-06-25 23:07:52.597638
# Unit test for function get_source
def test_get_source():
    case_0 = test_case_0()
    assert case_0 == \
r'''class VariablesGenerator:
    _counter = 0

    @classmethod
    def generate(cls, variable: str) -> str:
        """Generates unique name for variable."""
        try:
            return '_py_backwards_{}_{}'.format(variable, cls._counter)
        finally:
            cls._counter += 1
'''

# Generated at 2022-06-25 23:07:53.464183
# Unit test for function eager
def test_eager():
    test_case_0()

# Generated at 2022-06-25 23:08:01.196317
# Unit test for function eager
def test_eager():
    inputs = [
        [
            [1, 2, 3],
            [4, 5, 6]
        ],
        [
            [7, 8, 9]
        ]
    ]

    def foo(*args: Any) -> List[T]:
        return list(sum(args, ()))

    expected = [
        [1, 2, 3, 4, 5, 6],
        [7, 8, 9]
    ]

    actual = eager(foo)(inputs[0], inputs[1])

    assert expected == actual

if __name__ == '__main__':
    print(messages.no_test_function_msg)
    exit(0)

# Generated at 2022-06-25 23:08:03.813934
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).rstrip() == 'def test_case_0():\n    variables_generator_0 = VariablesGenerator()\n    str_0 = get_source(variables_generator_0)\n'

# Generated at 2022-06-25 23:08:11.150879
# Unit test for function get_source
def test_get_source():
    class TestVariablesGenerator:
        _counter = 0

        @classmethod
        def generate(cls, variable: str) -> str:
            """Generates unique name for variable."""
            try:
                return '_py_backwards_{}_{}'.format(variable, cls._counter)
            finally:
                cls._counter += 1

    class_source = get_source(TestVariablesGenerator)

# Generated at 2022-06-25 23:08:19.012834
# Unit test for function eager
def test_eager():
    from collections import Counter
    from inspect import isgenerator
    from pybackwards.consts import PY36
    from types import GeneratorType

    def some_generator():
        yield 1
        yield 2
        yield 3

    @eager
    def lazy_generator():
        yield 1
        yield 2
        yield 3

    @eager
    def some_iterable():
        yield 1
        yield 2
        yield 3

    @eager
    def some_list():
        return [1, 2, 3]

    def some_counter():
        return Counter([1, 2, 3])

    def some_generator():
        return (i for i in range(3))

    def some_generator_fn():
        return some_generator


# Generated at 2022-06-25 23:08:23.054787
# Unit test for function eager
def test_eager():
    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)
    eager_0 = eager(test_case_0)
    eager_0()
    


# Generated at 2022-06-25 23:08:36.708553
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == '''\
    class VariablesGenerator:
        _counter = 0
    
        @classmethod
        def generate(cls, variable: str) -> str:
            """Generates unique name for variable."""
            try:
                return '_py_backwards_{}_{}'.format(variable, cls._counter)
            finally:
                cls._counter += 1'''

# Generated at 2022-06-25 23:08:38.530846
# Unit test for function eager
def test_eager():
    import numpy as np
    n = np.array([1, 2, 3])
    assert eager(sum)(range(long(n))) == [0, 1, 3]

# Generated at 2022-06-25 23:08:39.790101
# Unit test for function debug
def test_debug():
    debug_0 = debug
    debug_0(lambda: 'DEBUG')


# Generated at 2022-06-25 23:08:46.656301
# Unit test for function eager
def test_eager():

    def variables_generator_eager():
        variables_generator_eager_fn_0 = VariablesGenerator()
        str_0 = get_source(variables_generator_eager_fn_0)
        variables_generator_eager_fn_1 = VariablesGenerator()
        str_1 = get_source(variables_generator_eager_fn_1)
        values = (str_0, str_1)
        return values
    
    results = eager(variables_generator_eager)
    assert results == ['_py_backwards_variable_0 {}'.format(results[0]), '_py_backwards_variable_1 {}'.format(results[1])]


# Generated at 2022-06-25 23:08:51.539402
# Unit test for function debug
def test_debug():
    class TestClass:
        def test_method(self):
            test_variable = 'test_variable'
            debug(lambda: f'{test_variable}')
    try:
        test_case_0()
    except:
        print('Expected exception: {}'.format(sys.exc_info()[1]))
    try:
        TestClass().test_method()
    except:
        print('Expected exception: {}'.format(sys.exc_info()[1]))


# Generated at 2022-06-25 23:08:58.948538
# Unit test for function get_source
def test_get_source():
    import unittest
    from pybackwards.utils import get_source
    # test case 1
    @get_source
    def test_case_1():
        str_1 = get_source(test_case_1)
    unittest.assertTrue(test_case_1() == "def test_case_1():\n    str_1 = get_source(test_case_1)")

    # test case 2
    @get_source
    def test_case_2(name):
        str_2 = get_source(test_case_2)
    unittest.assertTrue(test_case_2() == "def test_case_2(name):\n    str_2 = get_source(test_case_2)")

    # test case 3

# Generated at 2022-06-25 23:09:01.221910
# Unit test for function get_source
def test_get_source():
    # Test that get_source does not raise any exceptions.
    try:
        test_case_0()
    except Exception:
        pytest.fail("Unexpected error: {}".format(sys.exc_info()[1]))


# Generated at 2022-06-25 23:09:04.340345
# Unit test for function eager
def test_eager():
    # go to test at line 14
    assert getsource(eager(test_eager)).strip() == '@wraps(fn)\ndef wrapped(*args: Any, **kwargs: Any) -> List[T]:\n    return list(fn(*args, **kwargs))\n'



# Generated at 2022-06-25 23:09:06.797778
# Unit test for function debug
def test_debug():
    settings.debug = True

    if settings.debug:
        print(messages.debug(1))
        assert settings.debug == True
    else:
        print(messages.debug(0))
        assert settings.debug == False


# Generated at 2022-06-25 23:09:08.641006
# Unit test for function get_source
def test_get_source():
    if test_case_0() is None:
        print('test_get_source result: OK')
    else:
        print('test_get_source result: FAILED')

# Generated at 2022-06-25 23:09:40.411406
# Unit test for function eager
def test_eager():
    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)
    def func_0():
        # assert str_0 == 'def generate(cls, variable) -> str:\n    """Generates unique name for variable."""\n    try:\n        return \'_py_backwards_{}_{}\'.format(variable, cls._counter)\n    finally:\n        cls._counter += 1\n'
        return str_0 == 'def generate(cls, variable) -> str:\n    """Generates unique name for variable."""\n    try:\n        return \'_py_backwards_{}_{}\'.format(variable, cls._counter)\n    finally:\n        cls._counter += 1\n'

# Generated at 2022-06-25 23:09:42.199596
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).split('\n')[0] == '@classmethod'

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:09:43.425764
# Unit test for function get_source
def test_get_source():
    test_case_0()


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:09:44.535038
# Unit test for function debug
def test_debug():
    def get_message():
        return 'Hi there!'

    debug(get_message)


# Generated at 2022-06-25 23:09:46.562024
# Unit test for function get_source

# Generated at 2022-06-25 23:09:48.439611
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == None

# Test for PEP8 conformance
# pep8.readthedocs.io/en/latest/intro.html#error-codes

# Generated at 2022-06-25 23:09:55.696329
# Unit test for function debug
def test_debug():
    re_0 = re.compile('^\\s*(global\\s|def\\s|class\\s|import\\s)', re.MULTILINE | re.UNICODE)
    str_0 = (test_case_0.__code__ if PY_VERSION >= (3, 6) else test_case_0.func_code).co_name
    str_1 = (test_case_0.__code__ if PY_VERSION >= (3, 6) else test_case_0.func_code).co_filename
    int_0 = (test_case_0.__code__ if PY_VERSION >= (3, 6) else test_case_0.func_code).co_firstlineno
    str_2 = get_source(test_case_0)
    debug_0 = debug(lambda: 'ok')

# Generated at 2022-06-25 23:09:59.789516
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """\
    _counter = 0

    @classmethod
    def generate(cls, variable):
        \"\"\"Generates unique name for variable.\"\"\"
        try:
            return '_py_backwards_{}_{}'.format(variable, cls._counter)
        finally:
            cls._counter += 1
    """

# Generated at 2022-06-25 23:10:01.209915
# Unit test for function debug
def test_debug():
    def get_message(function):
        return function.__name__
    debug(lambda: get_message(debug))


# Generated at 2022-06-25 23:10:02.548781
# Unit test for function eager
def test_eager():
    """Test for eager"""
    eager_0 = eager(test_case_0)
    eager_0()


# Generated at 2022-06-25 23:11:07.547122
# Unit test for function get_source
def test_get_source():
    # Expected result of the unit test
    expected = """def generate(cls, variable):
    \"\"\"Generates unique name for variable.\"\"\"
    try:
        return '_py_backwards_{}_{}'.format(variable, cls._counter)
    finally:
        cls._counter += 1
"""
    # Unit test
    actual = get_source(VariablesGenerator.generate)
    # Assertion
    assert(expected == actual)

# Generated at 2022-06-25 23:11:10.268436
# Unit test for function eager
def test_eager():
    # This is the "nested" decorator
    # @eager is a wrapper of itself
    @eager
    @eager
    def nested_decorator(arg):
        yield arg

    assert nested_decorator(1) == [1]



# Generated at 2022-06-25 23:11:13.681155
# Unit test for function debug
def test_debug():
    def get_message():
        return 'message'
    def expected():
        print(messages.debug(get_message()), file=sys.stderr)
    debug(get_message)
    assert True, f'Expected: {expected()}\nActual: {debug(get_message)}'


# Generated at 2022-06-25 23:11:14.151620
# Unit test for function debug
def test_debug():
    assert True

# Generated at 2022-06-25 23:11:15.690873
# Unit test for function eager
def test_eager():
    def test():
        yield 1
        yield 2
        yield 3

    assert eager(test)() == [1, 2, 3]


# Generated at 2022-06-25 23:11:18.799858
# Unit test for function get_source
def test_get_source():
    # Test 0
    test_case_0()



if __name__ == '__main__':
    variables_generator_0 = VariablesGenerator()
    str_0 = get_source(variables_generator_0)


    # UNIT TESTING
    test_get_source()

# Generated at 2022-06-25 23:11:19.541888
# Unit test for function debug
def test_debug():
    debug(test_case_0)


# Generated at 2022-06-25 23:11:21.397860
# Unit test for function eager
def test_eager():
    def add(a, b):
        yield a + b
        yield a
        yield b

    assert eager(add)(1, 2) == [3, 1, 2]


# Generated at 2022-06-25 23:11:23.988208
# Unit test for function debug
def test_debug():
    eprint = sys.stderr.write
    try:
        sys.stderr.write = lambda x: None
        debug(lambda: "debug_0")
    finally:
        sys.stderr.write = eprint



# Generated at 2022-06-25 23:11:29.221283
# Unit test for function debug
def test_debug():
    str_0 = get_source(warn)
    def function_0(str_1):
        debug(str_1)
    function_0(str_0)
    variables_generator_0 = VariablesGenerator()
    str_2 = get_source(variables_generator_0)
    def function_1(str_3):
        debug(str_3)
    function_1(str_2)
