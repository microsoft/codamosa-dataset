

# Generated at 2022-06-25 23:03:33.994100
# Unit test for function eager
def test_eager():
    def f1(x):
        yield x
    def f2(x):
        return [x]
    assert eager(f1)(1) == [1]
    assert eager(f2)(1) == [1]


# Generated at 2022-06-25 23:03:35.103622
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)

# Generated at 2022-06-25 23:03:37.215422
# Unit test for function get_source
def test_get_source():
    test_get_source_0 = 42
    assert get_source(test_get_source) == 'test_get_source_0 = 42'


# Generated at 2022-06-25 23:03:46.862614
# Unit test for function debug
def test_debug():
    import pytest
    import sys
    import contextlib

    @contextlib.contextmanager
    def capture_stderr():
        import sys
        old_stderr = sys.stderr
        try:
            sys.stderr = f = StringIO()
            yield f
        finally:
            sys.stderr = old_stderr

    @contextlib.contextmanager
    def capture_stdout():
        import sys
        old_stdout = sys.stdout
        try:
            sys.stdout = f = StringIO()
            yield f
        finally:
            sys.stdout = old_stdout

    def test_debug_0():
        import tempfile
        temp_dir_0 = tempfile.TemporaryDirectory()
        settings_0 = settings
        settings.debug = True

# Generated at 2022-06-25 23:03:53.241467
# Unit test for function get_source
def test_get_source():
    func_0 = get_source
    assert get_source(func_0) == 'def get_source(fn: Callable[..., Any]) -> str:\n    """Returns source code of the function."""\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)'
    assert id(func_0) == id(get_source)

# Test for function generate in VariablesGenerator

# Generated at 2022-06-25 23:03:54.054899
# Unit test for function debug
def test_debug():
    debug(lambda: 'a')


# Generated at 2022-06-25 23:03:59.231290
# Unit test for function eager
def test_eager():

    # Global variables for the eager function
    global test_eager_list_0
    global test_eager_list_1

    def test_eager_eager_0():
        return test_eager_list_0

    # Make sure the function returns the expected value
    assert eager(test_eager_eager_0)() == test_eager_list_1


# Generated at 2022-06-25 23:04:08.003999
# Unit test for function eager
def test_eager():
    # Arguments for the decorator
    def decorator_args(fn):
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapper

    # Real decorator
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapper

    # Input arguments
    arg0 = None
    arg1 = 2
    arg2 = None
    arg3 = 2

    # Context (environment)
    context = {}

    # Tested function
    # Use of decorators

# Generated at 2022-06-25 23:04:09.870353
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo) == 'def foo():\n' \
                              '    pass'



# Generated at 2022-06-25 23:04:10.384190
# Unit test for function debug
def test_debug():
    assert True

# Generated at 2022-06-25 23:04:16.363265
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'
callable_0 = eager(bytes_0)'''



# Generated at 2022-06-25 23:04:19.334929
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == [113, 206, 36, 201, 72, 111, 119, 13, 43, 186, 181, 84, 227, 103, 79, 198, 59, 180, 154, 189]


# Generated at 2022-06-25 23:04:26.721749
# Unit test for function get_source
def test_get_source():
    def func_0():
        bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
        callable_0 = eager(bytes_0)
    code = get_source(func_0)
    assert code == "bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'\ncallable_0 = eager(bytes_0)"


# Generated at 2022-06-25 23:04:29.557891
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'"

# Generated at 2022-06-25 23:04:36.655426
# Unit test for function debug
def test_debug():
    from py.io import StringIO
    from py.path import local
    from .. import monkey

    monkey.patch_io()

    settings.debug = True

    stdout = open(local.make_numbered_dir(prefix='stdout-') / 'stdout', 'w+')
    stderr = open(local.make_numbered_dir(prefix='stderr-') / 'stderr', 'w+')
    monkey.set_stdout(stdout)
    monkey.set_stderr(stderr)

    debug(lambda: 'test')

    debug(lambda: 'test\n')

    settings.debug = False

    debug(lambda: 'test')

    settings.debug = True

    assert stdout.read() == ''

# Generated at 2022-06-25 23:04:38.417429
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).startswith("def test_case_0():")


# Generated at 2022-06-25 23:04:39.324234
# Unit test for function debug
def test_debug():
    pass


# Generated at 2022-06-25 23:04:43.407743
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\ncallable_0 = eager(bytes_0)'
test_get_source.py_backwards_ignore = True



# Generated at 2022-06-25 23:04:48.449396
# Unit test for function debug
def test_debug():
    callable_0 = debug


# Generated at 2022-06-25 23:04:51.096160
# Unit test for function eager
def test_eager():
    try:
        test_case_0()
    except Exception as e:
        print('FAIL: %s' % (e,))
        sys.exit(1)



# Generated at 2022-06-25 23:04:54.525458
# Unit test for function get_source
def test_get_source():
    from inspect import getsource
    assert getsource(test_case_0) == get_source(test_case_0)

# Generated at 2022-06-25 23:05:00.795253
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """def test_case_0():
    bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'
    callable_0 = eager(bytes_0)

"""



# Generated at 2022-06-25 23:05:03.515589
# Unit test for function eager
def test_eager():
    try:
        test_case_0()
    except AssertionError:
        print(messages.failure())
    else:
        print(messages.success())


# Generated at 2022-06-25 23:05:04.829607
# Unit test for function get_source

# Generated at 2022-06-25 23:05:07.839661
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:05:09.845701
# Unit test for function debug
def test_debug():
    assert callable(debug)
    assert callable(debug)


# Generated at 2022-06-25 23:05:14.120128
# Unit test for function get_source
def test_get_source():
    """Test get_source function."""
    test_source = 'def test_source():\n    pass\n'
    def test_source():
        pass
    source = get_source(test_source)
    assert source == test_source


# Generated at 2022-06-25 23:05:14.930286
# Unit test for function debug
def test_debug():
    debug(lambda: 'debugging')



# Generated at 2022-06-25 23:05:16.187740
# Unit test for function debug
def test_debug():
    result = debug('String')
    assert result is None



# Generated at 2022-06-25 23:05:18.699854
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0)[-15:] == 'callable_0 = eager(bytes_0)'


# Generated at 2022-06-25 23:05:22.650859
# Unit test for function debug
def test_debug():
    callable_0 = lambda : debug(test_case_0)


# Generated at 2022-06-25 23:05:32.861205
# Unit test for function eager
def test_eager():
    # Prepare test data
    bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
    callable_0 = eager(bytes_0)

# Generated at 2022-06-25 23:05:35.902698
# Unit test for function debug
def test_debug():
    if settings.debug:
        def func():
            return 'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
        pass



# Generated at 2022-06-25 23:05:39.911560
# Unit test for function debug
def test_debug():
    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    if settings.debug:
        print('output')
    capturedOutput.seek(0)
    out = capturedOutput.read().strip()
    assert print(messages.debug('debug message')) == out


test_case_0()
#test_debug()

# Generated at 2022-06-25 23:05:45.460230
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """    bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'
    callable_0 = eager(bytes_0)
"""



# Generated at 2022-06-25 23:05:53.993790
# Unit test for function eager
def test_eager():
    _ = test_case_0()
    print('Testing eager() with an array of random bytes ...')

    # Asserting a list is returned
    assert isinstance(_, list)

    # Asserting the returned list length is equal to the original one
    assert len(_) == len(bytes_0) == 19

    # Asserting contents of returned list are equal to the original one
    assert _ == list(bytes_0)

    print('Eager() test passed!')


# Generated at 2022-06-25 23:05:55.450404
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:05:59.729486
# Unit test for function get_source
def test_get_source():
    def callable_0():
        bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
        callable_1 = eager(bytes_0)
    assert get_source(test_case_0) == get_source(callable_0)



# Generated at 2022-06-25 23:06:00.666215
# Unit test for function get_source
def test_get_source():
    pass



# Generated at 2022-06-25 23:06:02.162045
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo).strip() == "def foo():"



# Generated at 2022-06-25 23:06:12.005150
# Unit test for function get_source
def test_get_source():
    source_code = get_source(test_case_0)
    source_bytes_0 = source_code[:47]
    assert source_bytes_0 == "bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO'"
    source_bytes_1 = source_code[47:]
    assert source_bytes_1 == "\\xc6;\\xb4\\x9a\\xbd'\ncallable_0 = eager(bytes_0)"


# Generated at 2022-06-25 23:06:13.171268
# Unit test for function debug
def test_debug():
    messages.debug('1')

# Generated at 2022-06-25 23:06:14.953905
# Unit test for function debug
def test_debug():
    debug(lambda: 'Cannot find module `{}`'.format(str))


# Generated at 2022-06-25 23:06:18.780661
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\n    callable_0 = eager(bytes_0)\n'


# Generated at 2022-06-25 23:06:20.613201
# Unit test for function debug
def test_debug():
    def func():
        return "TEST_DEBUG"
    debug(func)
    
    

# Generated at 2022-06-25 23:06:22.060806
# Unit test for function debug
def test_debug():
    get_message = lambda message: 'Hello'
    assert debug(get_message) == None


# Generated at 2022-06-25 23:06:24.960088
# Unit test for function debug
def test_debug():
    warn('This is a warning')
    debug(lambda: 'This is a debug message')
    debug(lambda: 'This is another debug message')


# Generated at 2022-06-25 23:06:32.682793
# Unit test for function get_source
def test_get_source():
    import ast
    import astor
    from test_unit.test_increase_coverage_test import test_case_0
    import inspect
    import tokenize
    def fn_0() -> None:
        bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
        callable_0 = eager(bytes_0)
    source = get_source(fn_0)
    def fn_1() -> None:
        bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
        callable_0 = eager(bytes_0)

# Generated at 2022-06-25 23:06:34.819783
# Unit test for function debug
def test_debug():
    def fn_0(arg_0):
        return arg_0
    debug(lambda: fn_0(b'byte_0'))


# Generated at 2022-06-25 23:06:41.186470
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """
    bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'
    callable_0 = eager(bytes_0)"""
    assert get_source(test_case_1) == """
    int_0 = 6
    callable_0 = eager(int_0)"""



# Generated at 2022-06-25 23:06:49.552131
# Unit test for function debug
def test_debug():
    print('    Running test function debug...', end='')
    global_variable_0 = 0
    def get_message_0():
        global global_variable_0
        global_variable_0 += 1
        return 'Message {}'.format(global_variable_0)
    debug(get_message_0)
    print(' OK')


# Generated at 2022-06-25 23:06:51.159921
# Unit test for function get_source
def test_get_source():
    assert get_source(eager) == 'def wrapped(*args, **kwargs):\n    return list(fn(*args, **kwargs))'



# Generated at 2022-06-25 23:06:54.024767
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "    bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'\n    callable_0 = eager(bytes_0)\n"

# Generated at 2022-06-25 23:06:56.242557
# Unit test for function get_source
def test_get_source():
    test_case_0()
    source = get_source(test_case_0)
    assert source != '', 'The source code is empty'

# Generated at 2022-06-25 23:07:01.435635
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd\'\n'

try:
    # Unit test for function get_source
    test_get_source()
except AssertionError as e:
    print(e)
    print('Test failed!')

# Generated at 2022-06-25 23:07:06.183872
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\n    callable_0 = eager(bytes_0)\n'


# Generated at 2022-06-25 23:07:09.197058
# Unit test for function debug
def test_debug():
    debug(lambda: 'Something')
    from py_backwards import messages
    import mock
    mock.patch.object(messages, 'debug')
    py_backwards.messages.debug.assert_called_once()


# Generated at 2022-06-25 23:07:12.688415
# Unit test for function debug
def test_debug():
    class TestClass:
        @staticmethod
        def test_method():
            pass

    settings.debug = True
    try:
        debug(lambda: '0x0')
    except AssertionError as e:
        assert e.args[0] == messages.debug('0x0')
    finally:
        settings.debug = False


# Generated at 2022-06-25 23:07:15.997088
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'\n" + \
    "callable_0 = eager(bytes_0)"


# Generated at 2022-06-25 23:07:17.508224
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass

    assert get_source(test_function) == 'def test_function():\n    pass'

# Generated at 2022-06-25 23:07:38.060007
# Unit test for function debug
def test_debug():
    import tempfile
    import sys
    import contextlib
    from io import StringIO
    from .. import messages


    def test_case_0():
        # normal
        with tempfile.TemporaryFile(mode='w+') as out:
            with contextlib.redirect_stdout(out):
                debug(lambda: 'foo')
            out.seek(0)
            assert out.read().strip() == messages.debug('foo')

        # verbosity
        orig = settings.verbosity
        try:
            settings.verbosity = 2
            with tempfile.TemporaryFile(mode='w+') as out:
                with contextlib.redirect_stdout(out):
                    debug(lambda: 'foo')
                out.seek(0)
                assert out.read().strip() == ''
        finally:
            settings.verb

# Generated at 2022-06-25 23:07:42.133218
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """    bytes_0 = b'q\xce$\xc9How\\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
    callable_0 = eager(bytes_0)"""


# Generated at 2022-06-25 23:07:48.687118
# Unit test for function get_source
def test_get_source():
    partial_0 = partial(test_case_0)
    assert get_source(partial_0) == 'bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\ncallable_0 = eager(bytes_0)'

# Generated at 2022-06-25 23:07:53.745872
# Unit test for function eager
def test_eager():
    callable_0 = eager(lambda: 0)
    list_0 = callable_0()
    assert isinstance(list_0, list)
    assert list_0 == []

    callable_0 = eager(lambda: 0)
    assert callable_0(42) == [42]

    eager_0 = eager(b'10')
    list_0 = eager_0()
    assert isinstance(list_0, list)
    assert list_0[0] == 49


# Generated at 2022-06-25 23:07:58.313858
# Unit test for function debug
def test_debug():
    from .unittests_support import with_captured_output

    def test_inner(captured_output: str) -> None:
        debug(get_message)
        assert not captured_output
        settings.debug = True
        debug(get_message)
        assert captured_output
        settings.debug = False

    with_captured_output(test_inner)


# Generated at 2022-06-25 23:07:59.667824
# Unit test for function debug
def test_debug():
    if settings.debug:
        debug(lambda : 'test string')


# Generated at 2022-06-25 23:08:00.691779
# Unit test for function eager
def test_eager():
    test_case_0()

# Generated at 2022-06-25 23:08:01.506341
# Unit test for function eager
def test_eager():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 23:08:06.473486
# Unit test for function get_source
def test_get_source():
    print('function get_source ...', end = '')
    def test_function_0(a, b, c, d, e):
        a += b + c + d
        a -= e

    # Since the code has been changed, the type of test_function_0 is changed from Callable[..., None] to Callable[..., Any]
    assert(get_source(test_function_0) == "a += b + c + d\na -= e")
    print(' done')


# Generated at 2022-06-25 23:08:08.777568
# Unit test for function debug
def test_debug():
    # Set up context
    get_message = lambda: "hello"
    # Invalid return values
    assert get_message() == "hello"
    assert settings.debug == False
    # Invalid return values
    assert settings.debug == False

# Generated at 2022-06-25 23:08:38.567762
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd\'\ncallable_0 = eager(bytes_0)'

# Generated at 2022-06-25 23:08:40.920405
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "args: Any, kwargs: Any) -> List[T]:\n    return list(fn(*args, **kwargs))"


# Generated at 2022-06-25 23:08:44.032793
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))
    with open('tests/test_get_source.py', 'r') as file:
        _test_get_source = file.read()
    assert get_source(test_case_0) == _test_get_source


# Generated at 2022-06-25 23:08:47.630158
# Unit test for function eager
def test_eager():
    from random import random
    from functools import partial

    random_lines = partial(open, mode='rb', buffering=-1)

    for _, line in zip(range(5000), eager(random_lines('random_data'))):
        assert len(line.strip()) == 16
        if random() > 0.99:
            break



# Generated at 2022-06-25 23:08:54.668474
# Unit test for function debug
def test_debug():
    bytes_0 = b'Y\x8d\xc2\xcf\xf1\xb9\x9b\xef\x04s\x0f\xe2\xc3x\x91\r\xbf\x9a\x90'
    int_0 = 5
    def get_message() -> str:
        bytes_0 = b'\x84\x83\xe5\xce\xd1\xbc\n\x93b\x1b\xe5\x9c\x0f\x14\xa2\xa6\xd7\x11\xce\xc6\x89\x0b\xbd\xf3\xcf\xd4'
        int_1 = 5
        return f'{bytes_0} {int_1}'
    debug(get_message)


# Generated at 2022-06-25 23:08:58.077150
# Unit test for function debug
def test_debug():
    try:
        str_0 = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        debug(lambda: str_0)
    except:
        raise AssertionError


# Generated at 2022-06-25 23:09:00.897093
# Unit test for function debug
def test_debug():
    counter = 0
    def get_message():
        nonlocal counter
        counter += 1
        return str(counter)

    debug(get_message)
    assert not settings.debug
    settings.debug = True
    debug(get_message)
    assert counter == 2
    settings.debug = False


# Generated at 2022-06-25 23:09:04.527271
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert source == ("        bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'\n"
                      "        callable_0 = eager(bytes_0)")


# Generated at 2022-06-25 23:09:05.757561
# Unit test for function eager
def test_eager():
    callable_0 = test_case_0()
    print(callable_0())

test_eager()

# Generated at 2022-06-25 23:09:07.128042
# Unit test for function debug
def test_debug():
    assert debug(lambda: 'test') is None


# Generated at 2022-06-25 23:09:36.953803
# Unit test for function eager
def test_eager():
    bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
    callable_0 = eager(bytes_0)
    try:
        assert callable_0 == list(bytes_0)
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-25 23:09:38.954628
# Unit test for function get_source
def test_get_source():
    assert b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd' == bytes_0



# Generated at 2022-06-25 23:09:41.253573
# Unit test for function get_source
def test_get_source():
    def func_0():
        callable_0 = eager(bytes_0)

    result = get_source(func_0)
    assert result == (
        "callable_0 = eager(bytes_0)")



# Generated at 2022-06-25 23:09:45.244710
# Unit test for function get_source
def test_get_source():
    message_0 = 'Test for function get_source failed. Your function'
    expected_return_type_0 = '<class \'str\'>'
    returned_value_0 = str(type(get_source(test_case_0)))
    assert returned_value_0 == expected_return_type_0, \
        message_0 + ' should return ' + expected_return_type_0 + ', but returned ' + returned_value_0


# Generated at 2022-06-25 23:09:48.921865
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '    bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\n    callable_0 = eager(bytes_0)\n'


# Generated at 2022-06-25 23:09:49.717375
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:09:51.886596
# Unit test for function debug
def test_debug():
    log = []
    def get_message():
        log.append(1)
        return 'Hello, world!'
    debug(get_message)
    assert log == [1]

# Generated at 2022-06-25 23:09:54.190812
# Unit test for function debug
def test_debug():
    try:
        assert settings.debug == True
        debug(test_case_0)
        assert True
    except AssertionError:
        warn("One unit test failed!")
        raise


# Generated at 2022-06-25 23:10:01.357351
# Unit test for function eager
def test_eager():
    callable_0 = eager(b'I\xcck\x9d\xdc\xa2\x02\x90\x1d\xc6\x1b\xdf\x9c9\x93\x85\xa8\xf6')
    callable_1 = eager(b'\x92\x9d\xec\xf90\xb6\xd6\xde\xba\x1f\xfb\x1b\x9d\x01\xa2\x11\x8e\xd1')
    assert callable_0(b'\x9c\x9d\x8a\x8e\xa5\x84\xbd*\xac\x10\x16\xdd\x1e\x03\xd3\xdf\xf2\xd2')

# Generated at 2022-06-25 23:10:02.021134
# Unit test for function debug
def test_debug():
    warn('test_debug')

# Generated at 2022-06-25 23:11:06.192480
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == \
        """bytes_0 = b'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd'
callable_0 = eager(bytes_0)"""

# Generated at 2022-06-25 23:11:10.563031
# Unit test for function eager
def test_eager():
    bytes_0 = b'(&\xccp\x89$o\xaeWY\xdb\x15\x1e\x9b\x8a\x12'
    list_0 = eager(bytes_0)
    assert list_0 == [40, 38, 92, 204, 112, 137, 36, 111, 174, 87, 89, 219, 21, 30, 155, 138, 18], 'AssertionError'


# Generated at 2022-06-25 23:11:14.472125
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '\nbytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\ncallable_0 = eager(bytes_0)'

if __name__ == "__main__":
    test_get_source()

# Generated at 2022-06-25 23:11:17.569897
# Unit test for function get_source
def test_get_source():
    num_0 = 5
    num_1 = 6
    num_2 = 7
    def function_0():
        num_0 = 8
        num_1 = 9
        num_2 = 10

    assert get_source(function_0) == 'num_0 = 8\nnum_1 = 9\nnum_2 = 10'


# Generated at 2022-06-25 23:11:19.103026
# Unit test for function eager
def test_eager():
    print('Unit test for function eager')
    test_case_0()
    print('OK')


# Generated at 2022-06-25 23:11:20.125910
# Unit test for function debug
def test_debug():
    debug(lambda: 'test_debug')



# Generated at 2022-06-25 23:11:22.764729
# Unit test for function eager
def test_eager():
    assert callable_0 == [113, 206, 36, 201, 72, 111, 119, 13, 43, 186, 181,
    84, 227, 103, 79, 198, 59, 180, 154, 189]


# Generated at 2022-06-25 23:11:23.519073
# Unit test for function debug
def test_debug():
    debug(lambda: 'hello')


# Generated at 2022-06-25 23:11:26.391762
# Unit test for function eager
def test_eager():
    try:
        test_case_0()
    except Exception:
        return False
    return True


# Generated at 2022-06-25 23:11:28.840461
# Unit test for function debug
def test_debug():
    globals_0 = globals()
    function_0 = globals_0['get_source'](test_case_0)
    print(function_0)
    print(type(function_0))
    debug(lambda: function_0)


# Generated at 2022-06-25 23:12:35.797455
# Unit test for function eager
def test_eager():
    assert callable_0() == [113, 206, 36, 201, 72, 111, 119, 13, 43, 186, 181, 84, 227, 103, 79, 198, 59, 180, 154, 189]


# Generated at 2022-06-25 23:12:38.359390
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\ncallable_0 = eager(bytes_0)'


# Generated at 2022-06-25 23:12:42.129282
# Unit test for function get_source
def test_get_source():
    test_case_0()
    test_sources = get_source(test_case_0)
    assert re.match(r"def test_case_0\(\):\n    bytes_0 = b'q\xce\$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'\n    callable_0 = eager\(bytes_0\)", test_sources)

# Generated at 2022-06-25 23:12:43.099638
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))


# Generated at 2022-06-25 23:12:45.880587
# Unit test for function eager
def test_eager():
    class TestClass:
        def __init__(self):
            self.src_fn = eager(bytes)
            self.fn_ref = TestClass.__init__
    
    class TestClass:
        def __init__(self):
            self.src_fn = eager(bytes)
            self.fn_ref = TestClass.__init__



# Generated at 2022-06-25 23:12:48.567036
# Unit test for function get_source
def test_get_source():
    bytes_0 = b'q\xce$\xc9How\r+\xba\xb5T\xe3gO\xc6;\xb4\x9a\xbd'
    print("Function definition:")
    print(get_source(bytes_0))


# Generated at 2022-06-25 23:12:49.216643
# Unit test for function debug
def test_debug():
    debug(callable_0)

# Generated at 2022-06-25 23:12:56.343143
# Unit test for function eager

# Generated at 2022-06-25 23:12:58.124269
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bytes_0 = b\'q\\xce$\\xc9How\\r+\\xba\\xb5T\\xe3gO\\xc6;\\xb4\\x9a\\xbd\'\ncallable_0 = eager(bytes_0)'


# Generated at 2022-06-25 23:12:59.726541
# Unit test for function eager
def test_eager():
    try:
        test_case_0()

    except Exception as e:
        print(messages.fail(e))
    else:
        print(messages.success())

if __name__ == '__main__':
    debug(test_eager)