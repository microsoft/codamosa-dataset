

# Generated at 2022-06-25 23:03:35.044547
# Unit test for function get_source
def test_get_source():
    local_test_case_0()

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:03:37.123734
# Unit test for function debug
def test_debug():
    print("Test debug")
    warnings.filterwarnings("ignore", message="Backwards is in debug mode")
    debug(lambda: "output")



# Generated at 2022-06-25 23:03:38.669204
# Unit test for function get_source
def test_get_source():
    callable_0 = None
    str_0 = get_source(callable_0)



# Generated at 2022-06-25 23:03:41.914093
# Unit test for function debug
def test_debug():
    callable_0 = None
    str_0 = get_source(callable_0)
    def func_0():
        return get_source(callable_0)
    func_0 = debug(func_0)



# Generated at 2022-06-25 23:03:43.415637
# Unit test for function debug
def test_debug():
    import pdb
    pdb.set_trace()
    debug(lambda : None)

# Generated at 2022-06-25 23:03:45.269332
# Unit test for function get_source
def test_get_source():
    assert test_case_0() == None
test_get_source()



# Generated at 2022-06-25 23:03:47.223940
# Unit test for function get_source
def test_get_source():
    sample = 'a = 1'
    def sample_func():
        return sample

    assert get_source(sample_func) == sample


# Generated at 2022-06-25 23:03:51.972880
# Unit test for function debug
def test_debug():
    print = mock.Mock()
    settings.debug = True
    debug(lambda: 'test')
    print.assert_called_once_with(messages.debug('test'), file=sys.stderr)
    # Default block
    settings.debug = False
    debug(lambda: 'test')
    # AssertionError: Expected call: mock(debug_message)
    # Not called: mock(debug_message)


# Generated at 2022-06-25 23:03:54.092281
# Unit test for function get_source
def test_get_source():
    assert callable_0 is None
    assert str_0 == '\n    callable_0 = None\n    str_0 = get_source(callable_0)\n'


# Generated at 2022-06-25 23:03:54.942897
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0)

# Generated at 2022-06-25 23:04:05.800943
# Unit test for function get_source

# Generated at 2022-06-25 23:04:07.963754
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == """bool_0 = False
    callable_0 = eager(bool_0)
    """

# Generated at 2022-06-25 23:04:10.463539
# Unit test for function eager
def test_eager():
    # Argument: fn: Callable[..., Iterable[T]]
    # Expected output: Callable[..., List[T]]
    print(eager(test_case_0))


# Generated at 2022-06-25 23:04:11.157430
# Unit test for function eager
def test_eager():
    callable_0 = test_case_0()
    print(callable_0(0))

# Generated at 2022-06-25 23:04:14.770010
# Unit test for function debug
def test_debug():
    settings.debug = True
    called = []
    def get_message():
        called.append(True)
        return 'test_debug'

    debug(get_message)

    assert called == [True]


# Generated at 2022-06-25 23:04:16.280599
# Unit test for function debug
def test_debug():
    assert settings.debug == True
    assert settings.debug == True
    assert settings.debug == True


# Generated at 2022-06-25 23:04:17.457828
# Unit test for function debug
def test_debug():
    debug(lambda: 'Almost there...')


# Generated at 2022-06-25 23:04:19.451899
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''
bool_0 = False
callable_0 = eager(bool_0)'''.strip()

# Generated at 2022-06-25 23:04:22.608935
# Unit test for function debug
def test_debug():
    messages = []
    def wrapped(message):
        messages.append(message)
        def func():
            return message
        return func
    global print
    print = wrapped
    test_case_0()
    assert messages == [messages.debug('')]

# Generated at 2022-06-25 23:04:25.200780
# Unit test for function get_source
def test_get_source():
    expected_0 = 'bool_0 = False\ncallable_0 = eager(bool_0)\n'
    assert get_source(test_case_0) == expected_0


# Generated at 2022-06-25 23:04:30.136439
# Unit test for function eager
def test_eager():
    # Input parameters
    test_case_0()

test_eager()

# Generated at 2022-06-25 23:04:32.919070
# Unit test for function get_source
def test_get_source():
    callable_0 = test_case_0()
    str_0 = get_source(callable_0)
    assert str_0 == "@wraps(fn)\n\ndef wrapped(*args: Any, **kwargs: Any) -> List[T]:\n    return list(fn(*args, **kwargs))"

# Generated at 2022-06-25 23:04:35.161024
# Unit test for function eager
def test_eager():
    """
    Check if eager function works fine
    """
    callable_0 = test_case_0()
    function_0 = test_case_0()
    assert function_0 == callable_0


# Generated at 2022-06-25 23:04:46.834145
# Unit test for function eager
def test_eager():
    # No wrapper test
    variable_0 = VariablesGenerator.generate('variable')
    variable_1 = VariablesGenerator.generate('variable')
    test_case_0()
    locals_ = locals()
    exec(get_source(eager), globals(), locals_)
    expect_variable_0 = False
    try:
        assert locals_[variable_0] == expect_variable_0
        assert locals_[variable_1] == expect_variable_0
    except:
        warn(messages.failed('test_eager'))
        return

    # Wrapper test
    variable_1 = VariablesGenerator.generate('variable')
    test_case_0()
    locals_ = locals()
    exec(get_source(eager), globals(), locals_)

# Generated at 2022-06-25 23:04:55.405647
# Unit test for function debug
def test_debug():
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate
    func_0 = VariablesGenerator.generate

# Generated at 2022-06-25 23:05:03.160377
# Unit test for function debug
def test_debug():
    try:
        import traceback
        import io
        message = 'test'
        expected_output = '{}{}{}'.format(messages.debug_header, message, messages.debug_footer)
        sys.stderr = io.StringIO()
        debug(lambda: message)
        sys.stderr.seek(0)
        actual_output = sys.stderr.read()
        assert actual_output == expected_output
    except AssertionError:
        traceback.print_exc()

# Generated at 2022-06-25 23:05:07.497944
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    bool_0 = False\n    callable_0 = eager(bool_0)'

# Generated at 2022-06-25 23:05:10.536787
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False\ncallable_0 = eager(bool_0)'



# Generated at 2022-06-25 23:05:15.276187
# Unit test for function debug
def test_debug():
    # Setting up
    import logging
    handler = logging.StreamHandler()
    logger = logging.getLogger()
    logger.addHandler(handler)

    # Calling the tested function
    debug(lambda: 'error')
    assert handler.stream.getvalue().strip() == '   DEBUG: error'
    # Cleaning up
    logger.removeHandler(handler)

# Generated at 2022-06-25 23:05:18.561316
# Unit test for function eager
def test_eager():
    global bool_0, callable_0

    reload(backwards)
    test_case_0()
    # Assert: callable_0 == callable_0
    assert callable_0 == callable_0

# Generated at 2022-06-25 23:05:27.452707
# Unit test for function eager
def test_eager():
    # Test with 0 parameters
    test_case_0()
    # Test with 1 parameters
    test_case_1(bool_arg_0 = False)
    # Test with 2 parameters
    test_case_2(bool_arg_0 = False, bool_arg_1 = False)


# Generated at 2022-06-25 23:05:29.282365
# Unit test for function eager
def test_eager():
    bool_0 = False
    callable_0 = eager(bool_0)

# Generated at 2022-06-25 23:05:30.372332
# Unit test for function debug
def test_debug():
    for _ in range(1):
        debug(lambda: 'test')


# Generated at 2022-06-25 23:05:33.268840
# Unit test for function debug
def test_debug():
    args = [settings.debug]
    debug(lambda : 'Entering debug.')
    debug(lambda : 'Exiting debug. Args: {}'.format(args))
    assert True == settings.debug

# Generated at 2022-06-25 23:05:36.349321
# Unit test for function get_source
def test_get_source():
    try:
        assert (get_source(test_case_0) == 'bool_0 = False\ncallable_0 = eager(bool_0)')
    except:
        print ("Wrong return for test_get_source")


# Generated at 2022-06-25 23:05:38.707192
# Unit test for function get_source
def test_get_source():
    try:
        get_source(test_case_0)
    except Exception as e:
        print('Error in get_source. %s' % e)


# Generated at 2022-06-25 23:05:39.911475
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == INDENTATION


# Generated at 2022-06-25 23:05:41.345687
# Unit test for function eager
def test_eager():
    assert get_source(test_case_0).strip() == 'callable_0 = list(bool_0)'

# Generated at 2022-06-25 23:05:45.330679
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == ('bool_0 = False\n'
                                       'callable_0 = eager(bool_0)'
                                       )



# Generated at 2022-06-25 23:05:50.119997
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False\ncallable_0 = eager(bool_0)'

# Generated at 2022-06-25 23:05:59.920994
# Unit test for function get_source
def test_get_source():
    a = test_case_0
    assert 'bool_0 = False' in get_source(a)



# Generated at 2022-06-25 23:06:06.317414
# Unit test for function eager
def test_eager():
    import tempfile
    from types import FunctionType
    import inspect

    # Prepare test data
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write(inspect.getsource(test_case_0))
        filename = f.name

    g: FunctionType = globals().copy()
    l: dict = locals()
    exec(compile(open(filename, "rb").read(), filename, 'exec'), g, l)
    test_case_0()

    assert bool_0 == bool_0
    assert callable_0 == callable_0




# Generated at 2022-06-25 23:06:09.722284
# Unit test for function get_source
def test_get_source():
    test_case_0()
    assert get_source(eager) == '@wraps(fn)\ndef wrapped(*args: Any, **kwargs: Any) -> List[T]:\n    return list(fn(*args, **kwargs))'


# Generated at 2022-06-25 23:06:11.933276
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == (
        'bool_0 = False\n'
        'callable_0 = eager(bool_0)\n'
    )


# Generated at 2022-06-25 23:06:15.624255
# Unit test for function get_source
def test_get_source():
    test_case_0()
    test_string = 'def test_case_0():\n    bool_0 = False\n    callable_0 = eager(bool_0)\n'
    assert get_source(test_case_0) == test_string


# Generated at 2022-06-25 23:06:17.524408
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''bool_0 = False
callable_0 = eager(bool_0)'''


# Generated at 2022-06-25 23:06:18.284734
# Unit test for function get_source

# Generated at 2022-06-25 23:06:20.212294
# Unit test for function eager
def test_eager():
    test_case_0()


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-25 23:06:21.985632
# Unit test for function get_source
def test_get_source():
    code = get_source(test_case_0)
    assert code.startswith('bool_0 = False')


# Generated at 2022-06-25 23:06:27.894925
# Unit test for function debug
def test_debug():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    import sys
    stderr = sys.stderr
    sys.stderr = StringIO()
    str_0 = 'abc'
    debug(str_0)
    assert sys.stderr.getvalue() == '\x1b[34m[DEBUG] abc\n\x1b[0m'


# Generated at 2022-06-25 23:06:41.449595
# Unit test for function get_source
def test_get_source():
    try:
        test_case_0()
    except NameError:
        bool_0 = bool
        test_case_0()
    assert get_source(test_case_0) == '''\
bool_0 = False
callable_0 = eager(bool_0)
'''

# Generated at 2022-06-25 23:06:43.466486
# Unit test for function debug
def test_debug():
    print(messages.debug(""))
    print(messages.debug(1))
    print(messages.debug(None))
    print(messages.debug("Normal message"))

# Generated at 2022-06-25 23:06:45.151167
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False'


# Generated at 2022-06-25 23:06:46.519568
# Unit test for function eager
def test_eager():
    print("Testing function eager")
    test_case_0()



# Generated at 2022-06-25 23:06:48.084324
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).strip() == """eager(bool_0)"""

# Generated at 2022-06-25 23:06:50.059844
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False\ncallable_0 = eager(bool_0)\n'


# Generated at 2022-06-25 23:06:52.194246
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    bool_0 = False\n    callable_0 = eager(bool_0)'


# Generated at 2022-06-25 23:06:53.667849
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False\ncallable_0 = eager(bool_0)'


# Generated at 2022-06-25 23:06:55.556345
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False\n' + \
                                     'callable_0 = eager(bool_0)'


# Generated at 2022-06-25 23:07:04.968864
# Unit test for function eager
def test_eager():
# Code of the generated stub for eager
    import typing
    import builtins

    def wrapped(*args: typing.Any, **kwargs: typing.Any) -> typing.List[typing.Any]:
        return builtins.list(bool_0(*args, **kwargs))

    _stub_0_0 = builtins.globals()
    _stub_0_1 = builtins.type(_stub_0_0).__getitem__
    callable_0 = _stub_0_1(_stub_0_0, 'wrapped')
    _stub_0_0 = callable_0
    _stub_0_1 = builtins.bool(_stub_0_0)

# Generated at 2022-06-25 23:07:29.988030
# Unit test for function eager
def test_eager():
    test_case_0()


# Generated at 2022-06-25 23:07:32.916109
# Unit test for function debug
def test_debug():
    # Enable debug mode
    settings.debug = True

    callable_0 = debug(test_case_0)
    callable_0()

    # Disable debug mode
    settings.debug = False

    callable_0()


# Generated at 2022-06-25 23:07:41.884883
# Unit test for function debug
def test_debug():
    tests = [
        ('logger.debug("")', 'debug\t', 'DEBUG'),
        ('logger.debug("")', '', 'INFO'),
        ('assert False', 'assert False', 'DEBUG'),
        ('assert False', 'import pudb; pudb.set_trace()', 'DEBUG'),
        ('assert False', 'import pdb; pdb.set_trace()', 'DEBUG'),
    ]

    for _test in tests:
        source, settings.debug_statement, settings.log_level = _test
        source = get_source(test_case_0).replace('bool_0', source)
        settings.debug_statement_sym = settings.debug_statement
        settings.debug = True

        # Check that `logging.debug` works as expected
        debug(lambda: source)



# Generated at 2022-06-25 23:07:49.189491
# Unit test for function eager
def test_eager():
    # Check that eager generates a new name each time
    if VariablesGenerator.generate('variable') != '_py_backwards_variable_0':
        return False
    if VariablesGenerator.generate('variable') != '_py_backwards_variable_1':
        return False
    # Check that eager returns a list
    if type(eager(test_case_0)) != type([]):
        return False
    return True


# Generated at 2022-06-25 23:07:50.770324
# Unit test for function debug
def test_debug():
    global message
    message = 'my_message'
    debug_0 = debug(lambda: message)
    return message



# Generated at 2022-06-25 23:07:51.890845
# Unit test for function debug
def test_debug():
    assert debug(lambda: 'test_debug') == None



# Generated at 2022-06-25 23:07:54.199542
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''bool_0 = False
callable_0 = eager(bool_0)'''


# Generated at 2022-06-25 23:07:56.993663
# Unit test for function get_source
def test_get_source():
    src_0 = test_case_0.__code__.co_code
    src_1 = get_source(test_case_0)
    assert src_0 == src_1

# Generated at 2022-06-25 23:07:59.122353
# Unit test for function get_source
def test_get_source():
    def foo():
        return 42
    assert re.sub(r'\s+', ' ', get_source(foo)) == "def foo():\n return 42"

# Generated at 2022-06-25 23:08:01.054636
# Unit test for function eager
def test_eager():
    assert callable_0.__name__ == 'bool_0', 'Actually {}'.format(callable_0.__name__)



# Generated at 2022-06-25 23:08:29.292486
# Unit test for function get_source
def test_get_source():
    if get_source(test_case_0) == 'bool_0 = False\ncallable_0 = eager(bool_0)\n':
        print('Function get_source work as expected')
    else:
        print('Function get_source doesnt work as expected')



# Generated at 2022-06-25 23:08:30.194001
# Unit test for function eager
def test_eager():
    test_case_0()


# Main entry point

# Generated at 2022-06-25 23:08:30.866679
# Unit test for function get_source

# Generated at 2022-06-25 23:08:32.280386
# Unit test for function get_source
def test_get_source():
    source_code = get_source(test_case_0)
    assert source_code == 'bool_0 = False\n'



# Generated at 2022-06-25 23:08:36.153788
# Unit test for function get_source
def test_get_source():
    # Test for condition (if True), defined in func 'test_case_0'
    # Expected result True
    _test_get_source_checked_True = True
    if(get_source(test_case_0) != "def test_case_0():\n    bool_0 = False\n    callable_0 = eager(bool_0)"):
        # Result should be '_test_get_source_checked_True = True', but True is not.
        # The value of got_result is '_test_get_source_checked_True = False'.
        # Please check whether the value of got_result is True or not.
        _test_get_source_checked_True = False

    assert(_test_get_source_checked_True)



# Generated at 2022-06-25 23:08:39.582621
# Unit test for function debug
def test_debug():
    test_case_0()
    print(
        debug(
            get_message=lambda:
            f'Debug message. Variables:\n' +
            f'bool_0: {bool_0}\n' +
            f'callable_0: {callable_0}'
        )
    )



# Generated at 2022-06-25 23:08:41.390701
# Unit test for function debug
def test_debug():
    if settings.debug:
        try:
            debug(lambda: 'Unit test for function debug')
        except:
            pass


# Generated at 2022-06-25 23:08:42.962600
# Unit test for function eager
def test_eager():
    try:
        test_case_0()
    except:
        print("Error raised during testing")
        raise

# Generated at 2022-06-25 23:08:45.795175
# Unit test for function eager
def test_eager():

    from . import test_case_0

    try:
        assert set(test_case_0.callable_0()) == {False}
        print(messages.passed())
    except AssertionError:
        print(messages.failed())



# Generated at 2022-06-25 23:08:47.827981
# Unit test for function get_source
def test_get_source():
    test_case_0()
    assert get_source(test_case_0) == 'bool_0 = False\n    callable_0 = eager(bool_0)'


# Generated at 2022-06-25 23:09:39.826008
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '\n    bool_0 = False\n    callable_0 = eager(bool_0)\n    '


# Unit tests for the VariablesGenerator class

# Generated at 2022-06-25 23:09:41.254652
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '    bool_0 = False\n    callable_0 = eager(bool_0)'

# Generated at 2022-06-25 23:09:43.949722
# Unit test for function debug
def test_debug():
    warn_message_0 = 'function: l1'
    bool_0 = bool
    callable_0 = debug(bool_0)
    bool_0 = bool
    callable_0 = debug(bool_0)
    bool_0 = bool
    callable_0 = debug(bool_0)


# Generated at 2022-06-25 23:09:45.516717
# Unit test for function eager
def test_eager():
    test_case_0()


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-25 23:09:48.260680
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'bool_0 = False'
    assert get_source(test_case_0).count('\n') == 2
    assert settings.debug == True


# Generated at 2022-06-25 23:09:54.594391
# Unit test for function debug
def test_debug():
    # Outer code
    foo = 1
    bar = 2
    callable_0 = eager(bar)
    # End outer code
    # Test
    settings.debug = True
    def is_outer_code_running():
        if foo != 1:
            raise Exception('foo is not 1')
        if bar != 2:
            raise Exception('bar is not 2')

        def is_inner_code_running():
            if foo != 1:
                raise Exception('foo is not 1')
            if bar != 2:
                raise Exception('bar is not 2')

        return locals()

    debug(is_outer_code_running)
    settings.debug = False


# Generated at 2022-06-25 23:09:55.963464
# Unit test for function eager
def test_eager():
    try:
        test_case_0()
    except (UnboundLocalError, AssertionError) as error:
        return error
    return False

# Generated at 2022-06-25 23:10:02.190621
# Unit test for function debug
def test_debug():
    class _Message:
        message: str
        def __init__(self, message: str) -> None:
            self.message = message
    _called_with: List[_Message] = []
    def _get_message() -> str:
        _called_with.append(_Message(message=''))
        return _called_with[-1].message
    def _set_message(message: str) -> None:
        getattr(_called_with[-1], 'message', '')
        _called_with[-1].message = message
    debug(_get_message)
    _set_message('{}')
    debug(_get_message)


# Generated at 2022-06-25 23:10:04.794761
# Unit test for function eager
def test_eager():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 23:10:06.022620
# Unit test for function debug
def test_debug():
    callable_0 = eager(debug)
    str_0 = 'test'
    callable_0(str_0)

# Generated at 2022-06-25 23:12:02.445695
# Unit test for function eager
def test_eager():
    expected = list([False])
    actual = test_case_0()
    assert expected == actual


# Generated at 2022-06-25 23:12:03.482925
# Unit test for function eager
def test_eager():
    # assert_equals(eager(T), list(T))
    test_case_0()


# Generated at 2022-06-25 23:12:07.000709
# Unit test for function eager
def test_eager():
    eager_0 = eager(test_case_0)
    eager_2 = eager(test_case_0)
    assert eager_0.__annotations__ == eager_2.__annotations__
    assert eager_0.__name__ == eager_2.__name__
    eager_1 = eager(eager_2)
    assert eager_0.__annotations__ == eager_1.__annotations__
    assert eager_0.__name__ == eager_1.__name__


# Generated at 2022-06-25 23:12:09.362249
# Unit test for function get_source
def test_get_source():
    test_case_0()

# Generated at 2022-06-25 23:12:11.283135
# Unit test for function get_source
def test_get_source():
    assert(get_source(test_case_0) == 'def test_case_0():\n    bool_0 = False\n    callable_0 = eager(bool_0)')


# Generated at 2022-06-25 23:12:12.067218
# Unit test for function eager
def test_eager():
    func_1 = eager(test_case_0)
    assert func_1 == [False]


# Generated at 2022-06-25 23:12:12.718828
# Unit test for function get_source
def test_get_source():
    x: int = 0
    get_source(test_case_0)

# Generated at 2022-06-25 23:12:14.246148
# Unit test for function debug
def test_debug():
    assert get_source(test_case_0) == '    bool_0 = False\n    callable_0 = eager(bool_0)\n'


# Generated at 2022-06-25 23:12:15.488674
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '''
bool_0 = False
callable_0 = eager(bool_0)
'''


# Generated at 2022-06-25 23:12:19.882489
# Unit test for function debug