

# Generated at 2022-06-25 23:03:38.711246
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    if (source != """str_0 = "NeCO[DmV':"
    warn(str_0)"""):
        raise RuntimeError("test_get_source failed")


# Generated at 2022-06-25 23:03:41.622947
# Unit test for function debug
def test_debug():
    str_0 = "NeCO[DmV':z)"
    def get_message():
        return str_0
    debug(get_message)

test_case_0()
test_debug()

# Generated at 2022-06-25 23:03:44.513162
# Unit test for function eager
def test_eager():
    @eager
    def generator():
        yield 1
        yield 2
        yield 3

    assert generator() == [1, 2, 3]



# Generated at 2022-06-25 23:03:45.384309
# Unit test for function debug
def test_debug():
    test_case_0()


# Generated at 2022-06-25 23:03:50.858038
# Unit test for function debug
def test_debug():
    # We are going to print "Message {0}" in debug mode
    message = "Message {0}"
    # Now let us print message in debug mode
    debug(lambda : message.format(0))
    # Now let us not print message in debug mode and reset the debug mode
    settings.debug = False
    debug(lambda : message.format(1))
    # Now let us print message in debug mode again
    settings.debug = True
    debug(lambda : message.format(2))



# Generated at 2022-06-25 23:03:52.357825
# Unit test for function debug
def test_debug():
    var_0 = "I_&.Uv~"
    debug(lambda : var_0)

# Generated at 2022-06-25 23:03:54.452251
# Unit test for function get_source
def test_get_source():
    def test_fn(a: int, b: int) -> int:
        return a + b
    assert get_source(test_fn) == "return a + b"


# Generated at 2022-06-25 23:03:56.906117
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':\"\nwarn(str_0)\n"

# Generated at 2022-06-25 23:03:59.483492
# Unit test for function debug
def test_debug():
    def get_message() -> str:

        str_0 = "NeCO[DmV':"
        return str_0

    debug(get_message)


# Generated at 2022-06-25 23:04:02.142523
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    str_0 = "NeCO[DmV\':\n    warn(str_0)\n'


# Generated at 2022-06-25 23:04:05.032554
# Unit test for function debug
def test_debug():
    assert debug(test_case_0) == test_case_0()


# Generated at 2022-06-25 23:04:06.869980
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':z)\""


# Generated at 2022-06-25 23:04:09.224709
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    str_0 = "NeCO[DmV\':z)"\n'

# Generated at 2022-06-25 23:04:14.791437
# Unit test for function eager

# Generated at 2022-06-25 23:04:17.577449
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n    str_0 = "NeCO[DmV\':z)"'
if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:04:21.332428
# Unit test for function get_source
def test_get_source():
    # No arguments
    get_source(test_case_0)

if __name__ == '__main__':
    import pytest

    pytest.main('-k {}'.format(__file__), testsdir=settings.ROOT_PATH, plugins=[TestRunner()])

# Generated at 2022-06-25 23:04:23.257220
# Unit test for function get_source
def test_get_source():
    print("Test case 0")
    test_case_0()


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:04:25.396777
# Unit test for function debug
def test_debug():
    settings.debug = True
    str_0 = "NeCO[DmV':z)"
    debug(lambda: get_source(test_case_0))


# Generated at 2022-06-25 23:04:28.059629
# Unit test for function get_source
def test_get_source():
    # Check if function is returning correct value
    assert get_source(test_case_0) == '    str_0 = "NeCO[DmV\':z)"'


# Generated at 2022-06-25 23:04:29.866384
# Unit test for function eager
def test_eager():
    function_0 = eager(test_case_0())
    assert (function_0 == "NeCO[DmV':z)")


# Generated at 2022-06-25 23:04:33.485124
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':z)\""

if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:04:35.540908
# Unit test for function get_source
def test_get_source():
    result = get_source(test_case_0)
    expected = "str_0 = \"NeCO[DmV':z)\""
    assert result == expected


# Generated at 2022-06-25 23:04:37.125115
# Unit test for function debug
def test_debug():
    test_case_0()


# Generated at 2022-06-25 23:04:38.556372
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == []


# Generated at 2022-06-25 23:04:40.801164
# Unit test for function debug
def test_debug():
    print('Starting function test_debug...')
    debug(lambda : 'NeCO[DmV\':z)')
    print('Finished function test_debug.')



# Generated at 2022-06-25 23:04:42.261487
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':z)\""

# Generated at 2022-06-25 23:04:43.407572
# Unit test for function debug
def test_debug():
    assert debug(test_case_0) == None


# Generated at 2022-06-25 23:04:55.335730
# Unit test for function get_source
def test_get_source():
    """Test for function get_source"""
    import re

    # extract the source code from get_source and check the result using the
    # regex

    source_code = get_source(test_get_source)
    # we remove the first and last lines that contains '"""Test for function get_source"""'
    # and '# Unit test for function get_source'
    source_code = '\n'.join(source_code.split('\n')[1:-1])
    assert re.search(r'''^\s*#\s*extract the source code from get_source\s*$''', source_code, re.MULTILINE)

# Generated at 2022-06-25 23:05:00.587735
# Unit test for function debug
def test_debug():
    expected_str = "str_0 = 'NeCO[DmV':z)'"
    debug(lambda: "str_0 = '{}'".format(str_0))
    assert getattr(sys.stderr, 'getvalue')() == messages.debug(expected_str)


# Generated at 2022-06-25 23:05:03.632621
# Unit test for function get_source
def test_get_source():
    assert "def test_case_0():" in get_source(test_case_0)
    assert "str_0 = \"NeCO[DmV':z)\"" in get_source(test_case_0)


# Generated at 2022-06-25 23:05:08.357594
# Unit test for function eager
def test_eager():
    test_case_0()

test_eager()

# Generated at 2022-06-25 23:05:18.147617
# Unit test for function eager
def test_eager():
    # function to be tested
    @eager
    def non_eager_generator():
        yield 1
        yield 2
    
    # test case
    @eager
    def test_case():
        yield 1
        yield 2
    try:
        result = test_case()
    except Exception as e:
        print('FAILED: test_case()')
        print(e)
    
    # test case
    @eager
    def test_case_0():
        pass
    try:
        result = test_case_0()
    except Exception as e:
        print('FAILED: test_case_0()')
        print(e)
    


# Generated at 2022-06-25 23:05:20.306705
# Unit test for function get_source
def test_get_source():
    assert 'str_0 = "NeCO[DmV\':z)"' in get_source(test_case_0)


# Generated at 2022-06-25 23:05:22.648898
# Unit test for function debug
def test_debug():
    test_case_0()
    debug(str_0)


# Generated at 2022-06-25 23:05:32.861096
# Unit test for function get_source
def test_get_source():
    function_0 = test_case_0
    function_1 = function_0
    function_2 = function_1
    function_3 = function_2
    function_4 = function_3
    function_5 = function_4
    function_6 = function_5
    function_7 = function_6
    function_8 = function_7
    function_9 = function_8
    function_10 = function_9
    function_11 = function_10
    function_12 = function_11
    function_13 = function_12
    function_14 = function_13
    function_15 = function_14
    function_16 = function_15
    function_17 = function_16
    function_18 = function_17
    function_19 = function_18
    function_20 = function_19
    function_21 = function_20

# Generated at 2022-06-25 23:05:34.467408
# Unit test for function get_source

# Generated at 2022-06-25 23:05:38.938602
# Unit test for function get_source
def test_get_source():
  str1 = get_source(test_case_0)
  str2 = "def test_case_0():\n    str_0 = \"NeCO[DmV':z)\"\n"
  if str1 == str2:
    print("get_source test passed!")
  else:
    print("get_source test failed!")


# Generated at 2022-06-25 23:05:40.481469
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'str_0 = "NeCO[DmV\':z)"'

# Generated at 2022-06-25 23:05:44.639393
# Unit test for function get_source
def test_get_source():
    func = test_case_0
    source = "str_0 = \"NeCO[DmV':z)\""
    src = get_source(func)
    assert src == source



# Generated at 2022-06-25 23:05:50.582081
# Unit test for function eager
def test_eager():
    p = eager(test_case_0)
    print("input: " + str(p))
    print("output: " + get_source(p))


# Generated at 2022-06-25 23:05:53.427398
# Unit test for function debug
def test_debug():
    msg = 'Generated variables: x, y'
    debug(lambda: msg)

# Generated at 2022-06-25 23:05:55.356811
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)()


# Generated at 2022-06-25 23:05:56.823795
# Unit test for function get_source
def test_get_source():
    source_code = get_source(test_case_0)
    assert len(source_code) > 0



# Generated at 2022-06-25 23:05:59.195603
# Unit test for function eager
def test_eager():
    def ret():
        yield 1
        yield 2
        yield 3
    
    ret_eager = eager(ret)
    assert ret_eager() == [1, 2, 3]


# Generated at 2022-06-25 23:06:01.409911
# Unit test for function get_source
def test_get_source():
    print("Unit test for get_source")
    print("Passed" if get_source(test_case_0) == "NeCO[DmV':" else "Failed")

# Generated at 2022-06-25 23:06:09.411857
# Unit test for function eager
def test_eager():
    # Tests get_source
    test_source = getsource(test_case_0).split('\n')
    padding = len(re.findall(r'^(\s*)', test_source[0])[0])
    test_source = '\n'.join(line[padding:] for line in test_source)
    assert test_source == get_source(test_case_0)

    # Tests variables_generator
    assert VariablesGenerator.generate("a") == '_py_backwards_a_0'
    assert VariablesGenerator.generate("b") == '_py_backwards_b_1'
    assert VariablesGenerator.generate("a") == '_py_backwards_a_2'

# Generated at 2022-06-25 23:06:10.774109
# Unit test for function get_source
def test_get_source():
    from inspect import getsource
    assert getsource(test_get_source) == get_source(test_get_source)

# Generated at 2022-06-25 23:06:11.927210
# Unit test for function debug
def test_debug():
    try:
        debug(lambda : "E'8WLV|6Uz")
    except:
        pass


# Generated at 2022-06-25 23:06:14.588461
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':\"\nwarn(str_0)\n"


# Generated at 2022-06-25 23:06:15.801024
# Unit test for function get_source
def test_get_source():
    get_source(test_case_0)


# Generated at 2022-06-25 23:06:20.251245
# Unit test for function get_source
def test_get_source():
    from inspect import getsource as orig_getsource
    assert orig_getsource(test_case_0) == get_source(test_case_0)


# Generated at 2022-06-25 23:06:22.062517
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':\"\nwarn(str_0)\n"

# Generated at 2022-06-25 23:06:24.322811
# Unit test for function debug
def test_debug():
    division_by_zero = 0
    debug(lambda: division_by_zero)


# Generated at 2022-06-25 23:06:26.739326
# Unit test for function debug
def test_debug():
    if settings.debug:
        debug_0 = settings.debug
    try:
        pass
    finally:
        settings.debug = debug_0


# Generated at 2022-06-25 23:06:29.319580
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "    str_0 = \"NeCO[DmV':\"\n    " \
                                     "warn(str_0)\n"


# Generated at 2022-06-25 23:06:30.699847
# Unit test for function get_source
def test_get_source():
    str_0 = "NeCO[DmV':"
    print(get_source(test_case_0))
    assert "warn(str_0)" in get_source(test_case_0)



# Generated at 2022-06-25 23:06:33.479575
# Unit test for function eager
def test_eager():
    def test_func():
        yield 1
        yield 2
        yield 3
    num_list = [1, 2, 3]

    assert eager(test_func)() == num_list


# Generated at 2022-06-25 23:06:35.448105
# Unit test for function debug
def test_debug():
    str_0 = "[DgN>2sE4"
    debug(lambda: '[{}]'.format(str_0))


# Generated at 2022-06-25 23:06:37.833205
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    assert get_source(foo).strip() == 'def foo():'

# Generated at 2022-06-25 23:06:40.687373
# Unit test for function eager
def test_eager():
    # Set up test data
    lst = [0, 1, 2]
    fn = lambda: lst
    # Run test
    assert(eager(fn)() == lst)


# Generated at 2022-06-25 23:06:45.837102
# Unit test for function debug
def test_debug():
    fn = debug
    assert True


# Generated at 2022-06-25 23:06:49.839332
# Unit test for function get_source
def test_get_source():
    try:
        assert get_source(test_case_0) == '\n        str_0 = "NeCO[DmV\':"\n        warn(str_0)\n    '
    except AssertionError:
        raise AssertionError('Function fails on case: {}'.format(test_case_0.__name__))

test_get_source()

# Generated at 2022-06-25 23:06:51.718946
# Unit test for function debug
def test_debug():
    dict_0 = { }
    dict_0["debug"] = 25
    settings.debug = dict_0["debug"]
    warn("debug")


# Generated at 2022-06-25 23:06:52.446760
# Unit test for function debug
def test_debug():
    test_case_0()

# Generated at 2022-06-25 23:06:53.146181
# Unit test for function debug
def test_debug():
    warn("t_1")


# Generated at 2022-06-25 23:06:55.268475
# Unit test for function get_source
def test_get_source():
    str_1 = "NeCO[DmV'"
    str_2 = "NeCO[DmV':"
    str_3 = "NeCO[DmV':"
    test_case_0()

# Generated at 2022-06-25 23:06:56.725688
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0)[:7] == 'str_0 ='



# Generated at 2022-06-25 23:06:58.672485
# Unit test for function debug
def test_debug():
    def print_msg():
        return "abc"

    debug(print_msg)


# Generated at 2022-06-25 23:07:01.318402
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert source == r'def test_case_0():\n    str_0 = "NeCO[DmV\':"\n    warn(str_0)'


# Generated at 2022-06-25 23:07:05.465604
# Unit test for function get_source
def test_get_source():
    # Test get_source
    warn('{} is a test case'.format(get_source(test_case_0).strip()))
    print('Test case 0:')
    test_case_0()
    warn('Test finished')


if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:07:17.896734
# Unit test for function debug
def test_debug():
    str_0 = "NeCO[DmV':"
    debug(lambda: str_0)

# Generated at 2022-06-25 23:07:21.804704
# Unit test for function eager
def test_eager():
    fn = (lambda i: (i for i in range(i)))
    if list(fn(10)) != eager(fn)(10):
        raise Exception
    if list(fn(10)) == eager(fn)(10):
        pass

# Generated at 2022-06-25 23:07:23.415856
# Unit test for function get_source
def test_get_source():
    expected = 'warn(str_0)'
    assert get_source(test_case_0) == expected


# Generated at 2022-06-25 23:07:24.764272
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).strip() == 'warn(str_0)'


# Generated at 2022-06-25 23:07:29.084316
# Unit test for function debug
def test_debug():
    debug(lambda : "y5nB}=Nb'A")
    debug(lambda : " $9X]_m|2Y")


# Generated at 2022-06-25 23:07:33.754781
# Unit test for function get_source
def test_get_source():
    _PY_BACKWARDS_TEST_GET_SOURCE_0 = ('def test_case_0():\n'
        "    str_0 = 'NeCO[DmV':\n"
        '    warn(str_0)\n')

    assert get_source(test_case_0) == _PY_BACKWARDS_TEST_GET_SOURCE_0


# Generated at 2022-06-25 23:07:35.844516
# Unit test for function debug
def test_debug():
    str_0 = "DUzl_g[V'"
    debug(str_0)


# Generated at 2022-06-25 23:07:36.687076
# Unit test for function debug
def test_debug():
    debug(test_case_0)



# Generated at 2022-06-25 23:07:39.932133
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))


test_case_1 = """\
        
        def test_case_2():
            str_2 = "NeCO[DmV':"
            warn(str_2)
        """.strip()



# Generated at 2022-06-25 23:07:41.879165
# Unit test for function debug
def test_debug():
    str_0 = '{}:{}:{}'.format('a', 'b', 'c')
    debug(lambda: str_0)


# Generated at 2022-06-25 23:07:52.917968
# Unit test for function debug
def test_debug():
    debug(lambda: "X8IaC0o")


# Generated at 2022-06-25 23:07:54.122524
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))


# Generated at 2022-06-25 23:07:56.934451
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == warn(chr(82) + "eCO[" + chr(79) + "mV':")


# Generated at 2022-06-25 23:07:57.989798
# Unit test for function debug
def test_debug():
    print("test_debug")
    test_case_0()


# Generated at 2022-06-25 23:08:00.226758
# Unit test for function debug
def test_debug():
    @debug
    def get_message():
        return "0i.2xWK@Nf%2k"
    get_message()


# Generated at 2022-06-25 23:08:01.690112
# Unit test for function debug
def test_debug():
    str_0 = "NeCO[DmV':"
    debug(str_0)


# Generated at 2022-06-25 23:08:02.156493
# Unit test for function debug
def test_debug():
    assert False

# Generated at 2022-06-25 23:08:03.885232
# Unit test for function debug
def test_debug():
    assert settings.debug is False
    debug(lambda: 'hello')
    settings.debug = True
    debug(lambda: 'hello')


# Generated at 2022-06-25 23:08:05.312270
# Unit test for function debug
def test_debug():
    str_1 = "NeCO[DmV':"
    debug(str_1)



# Generated at 2022-06-25 23:08:07.960273
# Unit test for function debug
def test_debug():
    warn('isso é um teste de debug')
    debug(lambda: 'isso é um teste de debug')
    settings.debug = False
    debug(lambda: 'isso é um teste de debug')


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-25 23:08:24.820678
# Unit test for function debug
def test_debug():
    with pytest.raises(TypeError) as excinfo:
        debug(1)
    assert 'Callback' in str(excinfo.value)



# Generated at 2022-06-25 23:08:27.492009
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == ('def test_case_0():\n'
                                       '    str_0 = "NeCO[DmV\':"\n'
                                       '    warn(str_0)')

# Generated at 2022-06-25 23:08:29.025365
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == ['N', 'e', 'C', 'O']


# Generated at 2022-06-25 23:08:30.895341
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "def test_case_0():\n    str_0 = \"NeCO[DmV':\"\n    warn(str_0)"


# Generated at 2022-06-25 23:08:32.977034
# Unit test for function get_source
def test_get_source():
    str_0 = "NeCO[DmV':"
    expected_value = """'NeCO[DmV\':\\n'"""
    actual_value = get_source(test_case_0)
    assert(expected_value == actual_value)

# Generated at 2022-06-25 23:08:34.131050
# Unit test for function get_source
def test_get_source():
    warn(get_source(test_case_0))


# Generated at 2022-06-25 23:08:36.980940
# Unit test for function get_source
def test_get_source():
    if get_source(test_case_0) != 'str_0 = "NeCO[DmV\':"\nwarn(str_0)':
        raise RuntimeError('Function get_source failed the test.')


# Execute unit test
if __name__ == '__main__':
    test_get_source()

# Generated at 2022-06-25 23:08:38.542127
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert 'print(messages.warn(' in source


# Generated at 2022-06-25 23:08:40.654588
# Unit test for function get_source
def test_get_source():
    try:
        assert get_source(test_case_0) == "warn(str_0)"
    except:
        print("Function get_source is not working")

# Generated at 2022-06-25 23:08:42.177495
# Unit test for function get_source
def test_get_source():
    str_0 = "NeCO[DmV':"
    debug(test_case_0)

# Generated at 2022-06-25 23:09:13.436265
# Unit test for function eager
def test_eager():
    from unittest import TestCase

    class TestEager(TestCase):
        def test_default(self):  # type: () -> None
            @eager
            def get_values():
                yield 1
                yield 2
                yield 3

            self.assertEqual(get_values(), [1, 2, 3])

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    unittest.main(module=__name__, exit=False)


# Generated at 2022-06-25 23:09:16.189249
# Unit test for function debug
def test_debug():
    def m():
        # Test if debugging is enabled
        if settings.debug:
            # Print debug message and exit
            print(messages.debug("There was a problem"), file=sys.stderr)
            sys.exit(1)
    # Call function debug
    debug(m)



# Generated at 2022-06-25 23:09:21.158614
# Unit test for function get_source
def test_get_source():
    str_0 = get_source(test_case_0)
    warn(str_0)
    str_1 = "warn(str_0)"
    str_2 = str_0.splitlines()[-1]
    if str_2 != str_1:
        warn("Error: Expected " + str_1)
        warn("Got: " + str_2)
        warn("Source: " + str_0)



# Generated at 2022-06-25 23:09:26.330219
# Unit test for function debug
def test_debug():
    import backward

    backward.debug(lambda: "wDO:c%")
    backward.debug(lambda: "v)T*h/")
    backward.debug(lambda: "wDO:c%")
    backward.debug(lambda: "v)T*h/")
    backward.debug(lambda: "wDO:c%")
    backward.debug(lambda: "v)T*h/")


if __name__ == '__main__':
    test_case_0()
    test_debug()

# Generated at 2022-06-25 23:09:27.088578
# Unit test for function debug
def test_debug():
  debug(test_case_0)


# Generated at 2022-06-25 23:09:30.326943
# Unit test for function debug
def test_debug():
    try:
        assert(True)
    except:
        print("Test case 0 failed")
        return
    global _get_message
    _get_message = lambda x: "NeCO[DmV':"
    debug(_get_message)
    print("Test passed")


# Generated at 2022-06-25 23:09:31.791112
# Unit test for function get_source
def test_get_source():
    # Check that the function returns a string
    assert isinstance(get_source(test_case_0), str)


# Generated at 2022-06-25 23:09:34.354914
# Unit test for function get_source
def test_get_source():
    source_code = get_source(test_case_0)
    assert source_code == 'str_0 = "NeCO[DmV\':"\nwarn(str_0)'

# Generated at 2022-06-25 23:09:35.049815
# Unit test for function eager
def test_eager():
    test_case_0()

# Generated at 2022-06-25 23:09:37.126395
# Unit test for function get_source
def test_get_source():
    str_0 = get_source(test_case_0)
    str_1 = "    str_0 = 'NeCO[DmV\':'\n"
    assert str_0 == str_1


# Generated at 2022-06-25 23:10:37.258039
# Unit test for function eager
def test_eager():
    assert eager(test_case_0()) == test_case_0()


# Generated at 2022-06-25 23:10:38.735392
# Unit test for function eager
def test_eager():
    str_0 = "NeCO[DmV':"
    call_0 = eager(test_case_0)
    call_0()


if __name__ == '__main__':
    test_eager()

# Generated at 2022-06-25 23:10:41.608672
# Unit test for function eager
def test_eager():
    List_0 = eager(test_case_0)
    str_0 = "NeCO[DmV':"
    warn(str_0)


# Generated at 2022-06-25 23:10:42.587111
# Unit test for function eager
def test_eager():
    func_eager = eager(test_case_0)
    func_eager()


# Generated at 2022-06-25 23:10:49.106821
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == "str_0 = \"NeCO[DmV':\"\nwarn(str_0)"

# Generated at 2022-06-25 23:10:50.144538
# Unit test for function debug
def test_debug():
    debug(lambda: "hNdR=nHx}4")
    pass


# Generated at 2022-06-25 23:10:52.233848
# Unit test for function get_source
def test_get_source():
    # Test with test_case_0
    source = get_source(test_case_0)
    assert source == "str_0 = 'NeCO[DmV\':'\nwarn(str_0)\n"

# Generated at 2022-06-25 23:10:54.141187
# Unit test for function get_source
def test_get_source():
    # Check if the function returns a string
    get_source_0 = get_source(test_case_0)

    assert isinstance(get_source_0, str)


# Generated at 2022-06-25 23:10:55.777513
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    #print(source)
    assert source == 'warn(str_0)'



# Generated at 2022-06-25 23:11:02.437150
# Unit test for function debug
def test_debug():
    def test_case_1_get_message():
        str_0 = "py_backwards[debug]:"
        return str_0
    debug(test_case_1_get_message)


# Generated at 2022-06-25 23:13:05.904433
# Unit test for function debug
def test_debug():
    def get_message():
        return '2.2'
    warn(None)
    debug(get_message)



# Generated at 2022-06-25 23:13:09.289989
# Unit test for function debug
def test_debug():
    from . import messages
    import io
    import sys
    from . import settings
    old_stderr = sys.stderr
    settings.debug = True
    try:
        sys.stderr = io.StringIO()
        debug(lambda: 'f')
        assert sys.stderr.getvalue() == messages.debug('f')
    finally:
        sys.stderr = old_stderr
        settings.debug = False



# Generated at 2022-06-25 23:13:10.157540
# Unit test for function debug
def test_debug():
    assert settings.debug
    debug(lambda: "ElNU!7WL+w")


# Generated at 2022-06-25 23:13:10.992507
# Unit test for function eager
def test_eager():
    @eager
    def range_10():
        return range(10)
    range_10()


# Generated at 2022-06-25 23:13:11.917435
# Unit test for function get_source
def test_get_source():
    print(get_source(test_case_0))


# Generated at 2022-06-25 23:13:13.668423
# Unit test for function get_source
def test_get_source():
    # Assert: the function get_source should return the source code of the function
    assert get_source(test_case_0) == "str_0 = 'NeCO[DmV\':'\nwarn(str_0)"


# Generated at 2022-06-25 23:13:15.391114
# Unit test for function get_source
def test_get_source():
    source_code = get_source(test_case_0)
    assert source_code == '''def test_case_0():
    str_0 = "NeCO[DmV':"
    warn(str_0)
'''



# Generated at 2022-06-25 23:13:21.675179
# Unit test for function eager
def test_eager():
    import pydoc
    str_0 = "NeCO[DmV':"
    str_1 = "NeCO[DmV':"
    str_2 = "NeCO[DmV':"
    str_3 = "NeCO[DmV':"
    str_4 = "NeCO[DmV':"
    str_5 = "NeCO[DmV':"
    str_6 = "NeCO[DmV':"
    str_7 = "NeCO[DmV':"
    str_8 = "NeCO[DmV':"
    str_9 = "NeCO[DmV':"
    str_10 = "NeCO[DmV':"
    str_11 = "NeCO[DmV':"

# Generated at 2022-06-25 23:13:22.932580
# Unit test for function eager
def test_eager():
    temp_fun_eager_1 = eager(test_case_0)
    print(temp_fun_eager_1)


# Generated at 2022-06-25 23:13:27.915616
# Unit test for function debug
def test_debug():
    """Test function debug"""
    output_callable = create_mock_print("")
    sys.stderr = output_callable
    # Call function to test
    debug("\x14\x0e\x10\x01\x11\x14\x13\n\t\x10\x13\n\x01\x7f")
    # Assert function returns correct value
    expected = messages.debug("\x14\x0e\x10\x01\x11\x14\x13\n\t\x10\x13\n\x01\x7f")
    assert output_callable.output == expected
