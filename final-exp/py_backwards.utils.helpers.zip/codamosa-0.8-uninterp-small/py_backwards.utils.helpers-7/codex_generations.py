

# Generated at 2022-06-25 23:03:34.573768
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == \
"""variables_generator_0 = VariablesGenerator()"""



# Generated at 2022-06-25 23:03:36.603768
# Unit test for function eager
def test_eager():
    res_0 = eager(list)(range(10))
    assert res_0 == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-25 23:03:44.821574
# Unit test for function debug
def test_debug():
    variables_0 = dict()
    try:
        test_case_0()
        # Test case 0
        variables_0['settings_0'] = settings
        variables_0['get_message_0'] = lambda : 'Just a debug message'
        debug(get_message=(lambda : 'Just a debug message' if settings.debug else None))
        # Test case 1
        variables_0['settings_0'] = settings
        variables_0['get_message_1'] = lambda : 'Just a debug message'
        debug(get_message=(lambda : 'Just a debug message' if settings.debug else None))
    finally:
        teardown(variables_0)


# Generated at 2022-06-25 23:03:46.452979
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert source == inspect.getsource(test_case_0)

# Generated at 2022-06-25 23:03:48.269061
# Unit test for function get_source
def test_get_source():
    assert get_source(warn) == 'def warn(message):\n    print(messages.warn(message), file=sys.stderr)\n'

# Generated at 2022-06-25 23:03:50.777868
# Unit test for function get_source
def test_get_source():
    test_case_0()
    assert get_source(test_case_0) == 'def test_case_0():\n    variables_generator_0 = VariablesGenerator()\n'



# Generated at 2022-06-25 23:03:53.556019
# Unit test for function get_source
def test_get_source():
    assert get_source('t') == 't'
    assert get_source(print) == 'print(*objects, sep=\' \', end=\'\\n\', file=sys.stdout, flush=False)'


# Generated at 2022-06-25 23:03:56.952731
# Unit test for function eager
def test_eager():
    def eager_test(a, b):
        while True:
            yield a + b

    eager_wrapper = eager(eager_test)
    assert eager_wrapper(1, 3), [4]
    assert eager_wrapper(2, 3), [5]

# Generated at 2022-06-25 23:03:59.856368
# Unit test for function debug
def test_debug():
    # This function should print to stderr with debug enabled
    debug(lambda : 'Hello')
    settings.debug = True
    debug(lambda : 'Hello')
    settings.debug = False


# Generated at 2022-06-25 23:04:02.517620
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'def test_case_0():\n' \
                                      '\tvariables_generator_0 = VariablesGenerator()'


# Generated at 2022-06-25 23:04:08.355498
# Unit test for function get_source
def test_get_source():
    test_cases_0 = [
        # [fn, expected]
        (test_case_0, '''variables_generator_0 = VariablesGenerator()\n''')
    ]
    for fn, expected in test_cases_0:
        assert get_source(fn) == expected

# Generated at 2022-06-25 23:04:12.351726
# Unit test for function get_source
def test_get_source():
    # Input parameters for function
    fn_input = test_case_0

    # Expected output of function
    expected_out = ['    variables_generator_0 = VariablesGenerator()']

    # Actual output of function
    actual_out = get_source(fn_input).split('\n')

    # Compare expected output against actual output
    assert expected_out == actual_out


# Generated at 2022-06-25 23:04:14.271953
# Unit test for function get_source

# Generated at 2022-06-25 23:04:16.438530
# Unit test for function eager
def test_eager():
    import pytest

    @eager
    def test():
        yield 1
        yield 2
        yield 3

    assert test() == [1, 2, 3]


# Generated at 2022-06-25 23:04:18.299429
# Unit test for function get_source
def test_get_source():
    f = get_source
    source = 'print(1)'
    assert f(lambda: exec(source)) == source


# Generated at 2022-06-25 23:04:19.962476
# Unit test for function get_source
def test_get_source():
    assert '    ("foo",)' == get_source(test_case_0)

# Generated at 2022-06-25 23:04:21.619441
# Unit test for function eager
def test_eager():
    for _ in range(10):
        assert eager(range)(10) == list(range(10))


# Generated at 2022-06-25 23:04:24.505598
# Unit test for function get_source
def test_get_source():
    import inspect
    from functools import partial
    from decorators import get_source
    assert get_source(partial(get_source,lambda x: None)) == inspect.getsource(partial(get_source,lambda x: None))

# Generated at 2022-06-25 23:04:32.950552
# Unit test for function get_source
def test_get_source():
    import ast
    import builtins
    assert ast.parse(get_source(get_source)) != None
    assert callable(get_source(get_source))
    assert get_source(get_source).startswith('def')
    assert get_source(get_source).endswith(': pass')
    assert get_source(get_source) == 'def get_source(fn: Callable[..., Any]) -> str:\n    """"Returns source code of the function."""\n    source_lines = getsource(fn).split(\'\\n\')\n    padding = len(re.findall(r\'^(\\s*)\', source_lines[0])[0])\n    return \'\\n\'.join(line[padding:] for line in source_lines)\n'

# Generated at 2022-06-25 23:04:42.070028
# Unit test for function debug
def test_debug():
    # 1. Function debug doesn't print anything to stderr
    # 2. Function debug with enabled setting.debug prints message to stderr

    # 1. Function debug doesn't print anything to stderr
    with patch('sys.stderr', new_callable=io.StringIO) as mock_stderr:
        with CaptureOutput(relay=False, capture_stderr=True):
            debug(lambda: 'message')

    assert mock_stderr.getvalue() == ''

    # 2. Function debug with enabled setting.debug prints message to stderr
    settings.debug = True

    with patch('sys.stderr', new_callable=io.StringIO) as mock_stderr:
        with CaptureOutput(relay=False, capture_stderr=True):
            debug(lambda: 'message')



# Generated at 2022-06-25 23:04:56.930785
# Unit test for function debug
def test_debug():
    import unittest

    class TestDebug(unittest.TestCase):
        def test_debug(self):
            settings.debug = True
            try:
                expected = 'py_backwards: this is test'
                mock_output = []
                expect_output = [expected]
                mock_print = 'print'
                sys.modules[mock_print] = print
                def mock_print(message: str, file: Any = None) -> None:
                    mock_output.append(message)
                sys.modules['print'] = mock_print
        
                def get_message() -> str:
                    return 'this is test'
                import sys
                debug(get_message)
                self.assertEqual(mock_output, expect_output)
            finally:
                settings.debug = False

    unittest.main

# Generated at 2022-06-25 23:04:59.126792
# Unit test for function debug
def test_debug():
    with pytest.raises(SystemExit) as e:
        debug(lambda: "debug")


# Generated at 2022-06-25 23:05:10.069848
# Unit test for function eager
def test_eager():
    variables_generator_0 = VariablesGenerator()
    def test0():
        def my_generator():
            return range(3)
        def my_list():
            return [i for i in range(3)]
        test0 = eager(my_generator)
        assert test0 == my_list
    test0()
    def test1():
        def my_generator(a):
            return range(a)
        def my_list(a):
            return [i for i in range(a)]
        test1 = eager(my_generator)
        assert test1(3) == my_list(3)
    test1()
    def test2():
        def my_generator(a, b):
            return range(a, b)

# Generated at 2022-06-25 23:05:14.929778
# Unit test for function get_source
def test_get_source():
    try:
        get_source_0 = get_source
        test_case_0()
        assert get_source_0(test_case_0) == '    variables_generator_0 = VariablesGenerator()'
    finally:
        test_case_0 = None
        get_source_0 = None


# Generated at 2022-06-25 23:05:21.889278
# Unit test for function get_source
def test_get_source():
    def add(a, b):
        return a + b
    get_source_0 = get_source(add)
    def add_0(a, b):
        return a + b
    assert add_0.__name__ == add.__name__
    assert add_0.__doc__ == add.__doc__
    assert add_0.__dict__ == add.__dict__
    assert add_0.__closure__ == add.__closure__
    assert add_0.__code__ == add.__code__


# Generated at 2022-06-25 23:05:23.935224
# Unit test for function get_source
def test_get_source():
    fn = test_case_0
    assert get_source(fn) == inspect.getsource(fn)


# Generated at 2022-06-25 23:05:33.887841
# Unit test for function debug
def test_debug():
    def assert_equals(x, y):
        try:
            assert x == y
        except:
            return False
        else:
            return True

    assert_equals(get_source(debug), """def debug(get_message: Callable[[], str]) -> None:
    if settings.debug:
        print(messages.debug(get_message()), file=sys.stderr)
""")

    def reverse(x):
        return x[::-1]

    def assert_equals(x, y):
        try:
            assert x == y
        except:
            return False
        else:
            return True


# Generated at 2022-06-25 23:05:37.563859
# Unit test for function debug
def test_debug():
    messages_debug_0 = messages.debug
    messages_debug_1 = messages_debug_0('debug_message')
    sys_stderr_write_0 = sys.stderr.write
    sys_stderr_write_1 = sys_stderr_write_0(messages_debug_1)

# Generated at 2022-06-25 23:05:47.507839
# Unit test for function get_source

# Generated at 2022-06-25 23:05:51.856425
# Unit test for function eager
def test_eager():
    assert eager([1, 5, 3, 8, 6, 5, 4])([1, 5, 3, 8, 6, 5, 4]) == [1, 5, 3, 8, 6, 5, 4]


# Generated at 2022-06-25 23:05:59.194767
# Unit test for function debug
def test_debug():
    debug_log = []
    def log(msg: str) -> None:
        debug_log.append(msg)

    settings.debug = True
    try:
        debug(lambda: 'Test message #1')
        debug(lambda: 'Test message #2')
    finally:
        settings.debug = False

    assert debug_log == [
        messages.debug('Test message #1'),
        messages.debug('Test message #2')
    ]

# Generated at 2022-06-25 23:06:07.656033
# Unit test for function eager
def test_eager():
    from . import backwards
    from inspect import signature, Parameter
    assert signature(backwards.eager) == signature(backwards.eager)
    assert signature(backwards.eager) == signature(lambda fn: None)
    assert signature(backwards.eager) == signature(lambda fn: None)
    assert backwards.eager.__annotations__['fn'] == Callable[..., Iterable[T]]
    assert backwards.eager.__annotations__['wrapped'] == Callable[..., List[T]]
    assert backwards.eager.__annotations__['args'] == Any
    assert backwards.eager.__annotations__['kwargs'] == Any
    assert backwards.eager.__annotations__['return'] == List[T]
    assert backwards.eager.__annotations__['return'] == List[T]

# Generated at 2022-06-25 23:06:09.094851
# Unit test for function debug
def test_debug():
    variables_generator_0 = test_case_0()



# Generated at 2022-06-25 23:06:12.245228
# Unit test for function get_source
def test_get_source():
    def test_function(test_parameter):
        return test_parameter + 'test_additional_value'

    assert get_source(test_function) == '''    def test_function(test_parameter):
        return test_parameter + 'test_additional_value'''


# Generated at 2022-06-25 23:06:15.029837
# Unit test for function eager
def test_eager():
    result = eager(test_case_0)
    assert type(result) == list
    assert len(result) == 0

# Test for function get_source

# Generated at 2022-06-25 23:06:23.247928
# Unit test for function debug
def test_debug():
    debug_file = sys.stderr
    warn_file = sys.stderr
    
    def f():
        return "hi"

    settings.debug = 1

    messages.debug = lambda x: "--debug: " + repr(x)[1:-1]
    messages.warn = lambda x: "--warn: " + repr(x)[1:-1]

    msg = "debug test"
    debug(lambda: msg)
    assert debug_file.getvalue().strip() == "--debug: debug test"

    warn_file.truncate(0); debug_file.truncate(0); settings.debug = 0
    msg = "debug test"
    debug(lambda: msg)
    assert debug_file.getvalue().strip() == ""

    warn_file.truncate(0); debug_file.truncate

# Generated at 2022-06-25 23:06:27.629966
# Unit test for function eager
def test_eager():
    def _fn0(a: int, b: str) -> Iterable[bool]:
        return (True for _ in range(a))

    _fn0_wrapped = eager(_fn0)

    assert _fn0_wrapped(1, 'foo') == [True]



# Generated at 2022-06-25 23:06:32.453818
# Unit test for function eager
def test_eager():
    def fn_0(x: int, y: int) -> Iterable[int]:
        for i in range(x, y):
            yield i
    x_0 = 0
    y_0 = 10
    fn_0_eager = eager(fn_0)
    fn_0_result = fn_0(x_0, y_0)
    fn_0_eager_result = fn_0_eager(x_0, y_0)
    assert (fn_0_result == fn_0_eager_result)


# Generated at 2022-06-25 23:06:34.845709
# Unit test for function debug
def test_debug():
    debug_0 = debug
    def get_message_0():
        return 'foo'
    debug_0(get_message_0=get_message_0)


# Generated at 2022-06-25 23:06:44.230709
# Unit test for function eager
def test_eager():
    from .. import messages
    from .. import state

    from .. import contras
    from .. import misra
    from .. import relations

    from . import test_cases

    from ..conf import settings
    from .gen_utils import AssertionMessage, AssertionMessageCall
    from .gen_utils import tracked, setup_trackers, get_tracked, reset_trackers
    from .gen_utils import get_args, get_kwargs, get_function_name, get_function_names
    from .gen_utils import get_all_functions, get_all_invocations, get_invocations, get_functions
    from .gen_utils import get_call_chain, get_called_functions, get_calling_functions
    from .gen_utils import get_caller_stack, get_called_stack, get_all_

# Generated at 2022-06-25 23:06:53.636364
# Unit test for function eager
def test_eager():
    from py_backwards.utils import eager
    from py_backwards.transformers.tests.transformer_test_helpers import func_to_source
    from py_backwards.conf import settings

    args = (1, 2)
    kwargs = dict(kwarg_1=1, kwarg_2=2)
    values = [1, 2, 3]

    def generator(*args, **kwargs) -> Iterable[int]:
        yield from values

    def eager_v0(fn) -> Callable[..., List[int]]:
        def wrapped(*args, **kwargs) -> List[int]:
            return list(fn(*args, **kwargs))
        return wrapped


# Generated at 2022-06-25 23:06:56.088118
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert 'callable_0' in source
    assert 'callable_1' in source
    assert 'return' in source
    assert 'yield' not in source


# Generated at 2022-06-25 23:07:00.333537
# Unit test for function get_source
def test_get_source():
    if settings.verbose:
        print('Testing function "get_source"')
    assert get_source(test_case_0) == '@wraps(fn)\ndef wrapped(*args: Any, **kwargs: Any) -> List[T]:\n    return list(fn(*args, **kwargs))\n'

# Generated at 2022-06-25 23:07:04.482275
# Unit test for function debug
def test_debug():
    expected = "message\n"
    try:
        debug(lambda: "message")
        result = sys.stderr.getvalue()
    finally:
        sys.stderr.seek(0)
        sys.stderr.truncate(0)
    assert result == expected


# Generated at 2022-06-25 23:07:06.116918
# Unit test for function debug
def test_debug():
    try:
        debug(lambda: "This is a debug message")
    except NameError:
        assert False



# Generated at 2022-06-25 23:07:08.928490
# Unit test for function eager
def test_eager():
    callable_0 = int
    callable_1 = eager(callable_0)
    assert callable_0 == callable_1
    assert callable_0.__name__ == callable_1.__name__        


# Generated at 2022-06-25 23:07:10.100000
# Unit test for function debug
def test_debug():
    debug(lambda: 'test_debug: 4 + 5 = {}'.format(4 + 5))

# Generated at 2022-06-25 23:07:11.858853
# Unit test for function debug
def test_debug():
    global debug_0
    def debug_0():
        return "debug_0"
    debug(debug_0)


# Generated at 2022-06-25 23:07:14.262146
# Unit test for function eager
def test_eager():
    callable_0 = None

    try:
        callable_1 = eager(callable_0)
    except:
        print('eager failed!')
        return
    assert callable_1 is not None


# Generated at 2022-06-25 23:07:16.147418
# Unit test for function get_source
def test_get_source():
    code = get_source(test_case_0)
    assert code == 'callable_0 = None\ncallable_1 = eager(callable_0)'



# Generated at 2022-06-25 23:07:24.049349
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_0\ncallable_1 = eager(callable_0)'

# Generated at 2022-06-25 23:07:28.210577
# Unit test for function debug
def test_debug():
    debug_value = False
    def get_message():
        return "Test debug"
    debug(get_message)
    assert not debug_value


# Generated at 2022-06-25 23:07:30.439761
# Unit test for function debug
def test_debug():
    assert debug(lambda: 'test') is None


# Generated at 2022-06-25 23:07:38.783087
# Unit test for function get_source
def test_get_source():
    # Generate a bunch of test cases
    for i in range(100):
        callable_0 = lambda: None
        callable_1 = eager(callable_0)
        source_0 = get_source(callable_0)
        source_1 = get_source(callable_1)

        # Assert that the function is fully decorated
        assert source_1 == ('@wraps(fn)\n'
                            'def wrapped(*args, **kwargs) -> List[T]:\n'
                            '    return list(fn(*args, **kwargs))')

        # Assert that the structure of the original function is preserved
        assert source_0 in source_1


# Assert that get_source doesn't raise any exceptions on some samples
test_get_source()

# Generated at 2022-06-25 23:07:41.313446
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    parts = source.splitlines()
    assert parts[1] == '    callable_0 = None'

# Generated at 2022-06-25 23:07:48.029613
# Unit test for function debug
def test_debug():
    global settings

    original_value = settings.debug
    settings.debug = False
    try:
        debug(lambda: 'hello world')
    finally:
        settings.debug = original_value

    settings.debug = True
    try:
        debug(lambda: 'hello world')
    finally:
        settings.debug = original_value

# Generated at 2022-06-25 23:07:48.825444
# Unit test for function debug
def test_debug():
    pass


# Generated at 2022-06-25 23:07:57.385973
# Unit test for function get_source
def test_get_source():
    assert callable_1.__name__ == 'callable_0'
    assert get_source(callable_1) == 'return list(callable_0(*args, **kwargs))'
    callable_2 = eager(lambda: x)
    assert callable_2.__name__ == '<lambda>'
    assert get_source(callable_2) == 'return list(lambda: x)'
    callable_3 = eager(
        lambda x: x,
        lambda x: x
    )
    assert callable_3.__name__ == '<lambda>'
    assert get_source(callable_3) == 'return list(lambda x: x,\nlambda x: x)'

# Generated at 2022-06-25 23:08:02.469415
# Unit test for function debug
def test_debug():
    local_variable = 'local variable'
    def get_message():
        nonlocal local_variable
        return local_variable
    try:
        del local_variable
    except NameError:
        pass
    debug(get_message)
    del get_message
# --- End: Unit test for function debug


if __name__ == '__main__':
    import pytest
    pytest.main(str(__file__.replace('\\', '/')) + ' -v')

# Generated at 2022-06-25 23:08:04.218868
# Unit test for function eager
def test_eager():
    callable_0 = None
    callable_1 = eager(callable_0)
    assert callable_1 is not None



# Generated at 2022-06-25 23:08:18.944338
# Unit test for function debug
def test_debug():
    def get_message():
        return 'test_debug'
    debug(get_message)



# Generated at 2022-06-25 23:08:20.831463
# Unit test for function debug
def test_debug():
    callable_0 = None
    callable_1 = debug(callable_0)
    assert callable_1 is None


# Generated at 2022-06-25 23:08:25.730305
# Unit test for function debug
def test_debug():
    result = []
    def get_message():
        result.append('Expected message')
        return 'Expected message'

    def additional():
        debug(get_message)

    settings.debug = True
    additional()
    settings.debug = False

    assert result == ['Expected message']


# Generated at 2022-06-25 23:08:27.855556
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_0 = None\ncallable_1 = eager(callable_0)'


# Generated at 2022-06-25 23:08:30.310775
# Unit test for function get_source
def test_get_source():
    source = get_source(test_case_0)
    assert('callable_0 = None' in source)
    assert(re.match(r'^\s+callable_1 = eager', source))


# Generated at 2022-06-25 23:08:31.734272
# Unit test for function get_source
def test_get_source():
    def test_function():
        pass
    assert get_source(test_function) == "def test_function():\n    pass"



# Generated at 2022-06-25 23:08:33.849422
# Unit test for function get_source
def test_get_source():
    def test1(x):
        return x + 1

    def test2(x):
        return x + 1

    assert get_source(test1) == get_source(test2)
    assert get_source(test1) == '    return x + 1\n'


# Generated at 2022-06-25 23:08:35.131992
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == '"""Returns source code of the function."""\n'

# Generated at 2022-06-25 23:08:36.375169
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    def bar():
        pass


# Generated at 2022-06-25 23:08:41.705059
# Unit test for function get_source
def test_get_source():
    pass
    # input_fn = '''
    # def foo(arg1, arg2):
    #     bar(arg1, arg2)
    #     x = arg1 + arg2
    #     return x'''
    # correct_source = '''
    # def foo(arg1, arg2):
    #     bar(arg1, arg2)
    #     x = arg1 + arg2
    #     return x'''
    # assert get_source(input_fn) == correct_source


# Generated at 2022-06-25 23:09:09.205767
# Unit test for function get_source
def test_get_source():
    assert(get_source(test_case_0) == 'callable_1 = eager(callable_0)')


# Generated at 2022-06-25 23:09:10.715097
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(lambda : 'test_debug')
    settings.debug = False
    debug(lambda : 'test_debug')

# Generated at 2022-06-25 23:09:11.422201
# Unit test for function debug
def test_debug():
    debug(lambda: "Hello, World!")

# Generated at 2022-06-25 23:09:13.310733
# Unit test for function get_source
def test_get_source():
    def func():
        return None

    res = get_source(func)
    ans = '''def func():
    return None'''
    assert res == ans



# Generated at 2022-06-25 23:09:15.284180
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == \
        'callable_0 = None\n' + \
        'callable_1 = eager(callable_0)\n'



# Generated at 2022-06-25 23:09:23.409717
# Unit test for function debug
def test_debug():
    message = 'a'
    check_status = 0
    if check_status != 0:
        check_status += 1
    if check_status != 1:
        check_status += 2
    if check_status != 3:
        check_status += 4
    if check_status != 7:
        check_status += 8
    if check_status != 15:
        check_status += 16
    if check_status != 31:
        check_status += 32
    if check_status != 63:
        check_status += 64
    if check_status != 127:
        check_status += 128
    if check_status != 255:
        check_status += 256
    if check_status != 511:
        check_status += 512
    if check_status != 1023:
        check_status += 1024

# Generated at 2022-06-25 23:09:26.428772
# Unit test for function eager
def test_eager():
    my_list = [1, 2, 3, 4, 5]
    assert eager(my_list) == [1, 2, 3, 4, 5]

if __name__ == '__main__':
    test_case_0()
    test_eager()

# Generated at 2022-06-25 23:09:27.967103
# Unit test for function debug
def test_debug():
    # Type warning
    def test_case_0():
        get_message = None
        debug(get_message)



# Generated at 2022-06-25 23:09:29.654426
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0).strip() == 'callable_0 = None'

# Generated at 2022-06-25 23:09:30.362724
# Unit test for function eager
def test_eager():
    test_case_0()

# Generated at 2022-06-25 23:09:59.840540
# Unit test for function eager
def test_eager():
    test_case_0()


# Usage of function get_source

# Generated at 2022-06-25 23:10:06.022914
# Unit test for function eager
def test_eager():
    from unittest import mock
    from unittest.mock import call
    from typing import Any, Iterator


    class CallableMock(mock.MagicMock):
        def __call__(self, *args: Any, **kwargs: Any) -> Iterator[Any]:
            return super().__call__(*args, **kwargs)

    callable_0 = CallableMock()
    callable_0.return_value = iter([1, 2, 3])
    callable_1 = eager(callable_0)
    callable_1()
    callable_0.assert_has_calls([
        call(),
    ])



# Generated at 2022-06-25 23:10:07.379597
# Unit test for function get_source
def test_get_source():
    try:
        get_source(test_case_0)
    except Exception:
        return False
    return True


# Generated at 2022-06-25 23:10:09.080354
# Unit test for function debug
def test_debug():
    test_string = "test"
    if settings.debug:
        assert debug(lambda: test_string) is None
    else:
        assert debug(lambda: test_string) is None


# Generated at 2022-06-25 23:10:10.383663
# Unit test for function get_source
def test_get_source():
    def test():
        return

    assert get_source(test) == 'def test():\n    return\n'


# Generated at 2022-06-25 23:10:11.718051
# Unit test for function get_source
def test_get_source():
    def f():
        pass

    assert get_source(f) == 'def f():\n    pass'



# Generated at 2022-06-25 23:10:13.112074
# Unit test for function get_source
def test_get_source():
    def foo():
        pass

    expected = 'def foo():\n    pass'
    assert get_source(foo) == expected



# Generated at 2022-06-25 23:10:14.426497
# Unit test for function debug
def test_debug():
    try:
        test_debug_0()
    except:
        pass


# Generated at 2022-06-25 23:10:15.805681
# Unit test for function eager
def test_eager():
    test_case_0()
    test_case_1()
# Test function eagerly



# Generated at 2022-06-25 23:10:17.469644
# Unit test for function eager
def test_eager():
    assert eager(test_case_0)() == []
    return 'For `eager` function, there are no exceptions.'

# Generated at 2022-06-25 23:11:19.990478
# Unit test for function debug
def test_debug():
    call_count = 0

    def get_message():
        nonlocal call_count
        call_count += 1
        return 'Hello World'

    debug(get_message)
    assert call_count == 1
    assert settings.debug_call_count == 1


# Generated at 2022-06-25 23:11:21.295448
# Unit test for function get_source
def test_get_source():
    assert get_source(eager) == get_source(test_case_0)



# Generated at 2022-06-25 23:11:23.056075
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'if settings.debug:\n    print("abc")'


# Generated at 2022-06-25 23:11:27.202977
# Unit test for function get_source
def test_get_source():
    source_code = get_source(test_case_0)
    assert source_code == '@wraps(fn)\n' \
        'def wrapped(*args: Any, **kwargs: Any) -> List[T]:\n' \
        '    return list(fn(*args, **kwargs))\n'

# Generated at 2022-06-25 23:11:29.097711
# Unit test for function get_source
def test_get_source():
    callable_0 = get_source
    assert callable_0(test_case_0) == 'callable_1 = eager(callable_0)'


# Generated at 2022-06-25 23:11:30.728037
# Unit test for function debug
def test_debug():
    a = 1

    def get_a():
        return a

    debug(get_a)

# Generated at 2022-06-25 23:11:31.972858
# Unit test for function eager
def test_eager():
    callable_0 = None
    callable_1 = eager(callable_0)


# Generated at 2022-06-25 23:11:38.316029
# Unit test for function get_source
def test_get_source():
    def a():
        pass

    def b():
        pass

    def c():
        pass

    def d():
        pass

    source = get_source(test_case_0)
    assert source[:20] == 'test_case_0():\n'
    assert source[-53:] == '    callable_1 = eager(callable_0)\n\n'
    assert get_source(a) == 'a():\n    pass\n\n'
    assert get_source(b) == 'b():\n    pass\n\n'
    assert get_source(c) == 'c():\n    pass\n\n'
    assert get_source(d) == 'd():\n    pass\n\n'



# Generated at 2022-06-25 23:11:39.853356
# Unit test for function get_source

# Generated at 2022-06-25 23:11:41.158770
# Unit test for function get_source
def test_get_source():
    assert get_source(test_case_0) == 'callable_1 = eager(callable_0)'
