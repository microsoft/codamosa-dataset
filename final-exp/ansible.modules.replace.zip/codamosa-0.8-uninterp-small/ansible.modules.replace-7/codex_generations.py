

# Generated at 2022-06-25 03:06:50.828325
# Unit test for function write_changes

# Generated at 2022-06-25 03:06:54.668744
# Unit test for function write_changes
def test_write_changes():
    # Initialize object
    module = AnsibleModule({}, complex_args=[])
    module.atomic_move = lambda src, dest, unsafe_writes=True: True
    # Module arguments
    contents = '''
foo
bar
baz
'''
    path = '/etc/foo'
    # Return value
    # Module execution
    write_changes(module, contents, path)

    # assertion
    assert True


# Generated at 2022-06-25 03:07:06.094227
# Unit test for function write_changes
def test_write_changes():
    var_1 = 'AnsibleModule'

# Generated at 2022-06-25 03:07:08.691739
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Write test cases here
    var_0 = check_file_attrs(module, changed, message)
    print(var_0)



# Generated at 2022-06-25 03:07:10.479514
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == None, 'var_1 is not None.'


# Generated at 2022-06-25 03:07:14.871153
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    try:
        write_changes(module, '', 'c:\\temp\\ansible-tmp-1516093674.75-269867927716097\\ansible')
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 03:07:17.356204
# Unit test for function main
def test_main():
    try:
        var_1 = main()
    except:
        assert False
        
# unit tests
test_main()

# Generated at 2022-06-25 03:07:18.367402
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = main()


# Generated at 2022-06-25 03:07:20.543041
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = check_file_attrs(
        None,
        None,
        'Test string'
    )


# Generated at 2022-06-25 03:07:21.871343
# Unit test for function check_file_attrs
def test_check_file_attrs():
    result_0 = test_case_0()
    assert result_0 == True



# Generated at 2022-06-25 03:07:37.946500
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'validate': {'Required': False, 'Type': 'str'}, 'check': {'Required': False, 'Type': 'bool'}})

    contents = os.urandom(16)
    path = tempfile.gettempdir()

    write_changes(module, contents, path)
    
    test_case_0()

test_write_changes()

# Generated at 2022-06-25 03:07:42.938613
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_1 = AnsibleModule
    var_1 = var_1()
    var_1 = var_1.params
    var_1 = var_1['path']
    var_2 = True
    var_3 = 'regexp exists and has changed'
    var_3, var_2 = check_file_attrs(var_1, var_2, var_3)
    assert var_3 == 'regexp exists and has changed'
    assert var_2 == True



# Generated at 2022-06-25 03:07:44.898019
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:07:48.139539
# Unit test for function main
def test_main():
    try:
        main()
    except:
        print("Error running main()")
        raise

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:07:53.568567
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print("Testcase 0 failed.")
        print(e.message)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:07:58.144104
# Unit test for function write_changes
def test_write_changes():
    var_1 = AnsibleModule()

    var_2 = var_1.params
    var_2["test_key"] = "test_value"

    var_3 = var_1.atomic_move
    var_3("/tmp/test_src_file", "/tmp/test_dst_file")

if __name__ == '__main__':
    test_case_0()
    test_write_changes()

# Generated at 2022-06-25 03:08:01.852947
# Unit test for function main
def test_main():
    params = {
        'backup': False,
        'path': '/etc/hosts',
        'regexp': '(\s+)old\.host\.name(\s+.*)?$'
    }
    with pytest.raises(AnsibleExitJson) as context:
        main()
    assert context.value.args[0]['msg'] == '0 replacements made'
    assert context.value.args[0]['changed'] == False


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:08:11.293599
# Unit test for function write_changes
def test_write_changes():
    # Get current directory path
    curr_dir_path = os.path.dirname(os.path.realpath(__file__))
    # Get test data path
    test_data_path = os.path.join(curr_dir_path, 'test_data')
    # Get test directory path
    test_dir_path = os.path.join(test_data_path, 'test_dir')
    # Get test file path
    test_file_path = os.path.join(test_dir_path, 'lines.txt')
    # Get test file path
    test_file_path_out = os.path.join(test_dir_path, 'lines_out.txt')
    # Assert module object was created
    assert module != None
    # Assert test file path is valid
    assert test_file_path

# Generated at 2022-06-25 03:08:13.684372
# Unit test for function main
def test_main():
    var_1 = main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:08:14.590120
# Unit test for function write_changes
def test_write_changes():
    assert main() == None


# Generated at 2022-06-25 03:08:36.309996
# Unit test for function write_changes

# Generated at 2022-06-25 03:08:36.957651
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:08:40.338723
# Unit test for function write_changes
def test_write_changes():
    try:
        contents = module, contents, path
        write_changes(module, contents, path)
        return 0
    except Exception:
        return 1


# Generated at 2022-06-25 03:08:45.513480
# Unit test for function write_changes
def test_write_changes():
    tmp_file_contents = tempfile.NamedTemporaryFile()
    tmp_file_contents.write("contents")
    tmp_file_contents.seek(0)
    tmp_file_contents_content = tmp_file_contents.read(contents)
    tmp_file_contents.close()
    tmp_file_path = tempfile.NamedTemporaryFile()
    tmp_file_path.write("path")
    tmp_file_path.seek(0)
    tmp_file_path_content = tmp_file_path.read(path)
    tmp_file_path.close()
    test_case0 = write_changes(tmp_file_contents_content, tmp_file_path_content)
    assert test_case0 == True
    tmp_file_contents.close()
   

# Generated at 2022-06-25 03:08:48.695473
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    try:
        check_file_attrs(module, True, "hello")
    except SystemExit as exception:
        exception_status = exception.code
    assert exception_status == 0


# Generated at 2022-06-25 03:08:49.206723
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-25 03:08:58.240053
# Unit test for function write_changes
def test_write_changes():
    var_1 = tempfile.mkdtemp()
    var_2 = 'unit test write_changes'
    var_3 = os.path.join(var_1, 'test.txt')
    var_4 = open(var_3, 'w')
    var_4.write('abc')
    var_4.close()
    var_5 = to_text(os.linesep)
    var_6 = to_text(os.linesep)


# Generated at 2022-06-25 03:08:59.756535
# Unit test for function write_changes
def test_write_changes():
    try:
        main()
    except:
        print('Exception: %s' % (format_exc()))


# Generated at 2022-06-25 03:09:00.313255
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 03:09:05.894466
# Unit test for function check_file_attrs
def test_check_file_attrs():
    print("test for check_file_attrs: ")
    var_0 = True
    var_1 = "the file has changed"
    print("type(var_0)=", type(var_0), "var_0=", var_0)
    print("type(var_1)=", type(var_1), "var_1=", var_1)
    var_2 = check_file_attrs(var_0, var_1)
    print("type(var_2)=", type(var_2), "var_2=", var_2)
    if type(var_2) is str:
        print(var_2)
    else:
        print(repr(var_2))
    print("test case 0 passed")




# Generated at 2022-06-25 03:09:34.289215
# Unit test for function main
def test_main():
    assert var_0 == None


# Generated at 2022-06-25 03:09:39.219562
# Unit test for function write_changes
def test_write_changes():
    path = "test.txt"
    contents = "this is the content"
    module.atomic_move(tmpfile, path, unsafe_writes=module.params['unsafe_writes'])


# Generated at 2022-06-25 03:09:40.028291
# Unit test for function main
def test_main():
    assert var_0 == None


# Generated at 2022-06-25 03:09:47.746408
# Unit test for function write_changes
def test_write_changes():
    var_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
        mutually_exclusive = [],
        required_together = [],
        required_one_of = [
            [
                [
                    u'path'
                ],
                [
                    u'dest'
                ]
            ]
        ],
        add_file_common_args = True,
        supports_diff = False
    )
    var_1 = []
    var_2 = to_text(var_1, errors = u'strict', nonstring = u'passthru')
    var_3 = to_bytes(var_2, errors = u'strict', nonstring = u'passthru')
    var_4 = tempfile.mkstemp(dir=var_0.tmpdir)
    var

# Generated at 2022-06-25 03:09:48.883965
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:09:55.721571
# Unit test for function main
def test_main():
    input = {
  'after': '',
  'path': '/etc/hosts',
  'regexp': '\\b(localhost)(\\d*)\\b',
  'before': '',
  'replace': '\\1\\2.localdomain\\2 \\1\\2',
    }
    retval = main(input)
    if type(retval) is not bool:
        raise Exception("Unexpected return type: {}".format(type(retval)))
    if not retval:
        raise Exception("Main function returned false")


# Generated at 2022-06-25 03:10:02.593338
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Case 0
    param0 = 'data/replace.py'
    param1 = False
    param2 = 'regexp changed'
    retval = check_file_attrs(param0, param1, param2)
    #assert False, (retval)
    

# Generated at 2022-06-25 03:10:03.225730
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:10:09.285467
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create dict with test data
    var_0 = dict()

    # Create dict with test data
    var_1 = dict()

    # Create dict with test data
    var_2 = dict()

    # Create dict with test data
    var_3 = dict()

    # Create dict with test data
    var_4 = dict()

    # Create dict with test data
    var_5 = dict()

    # Create dict with test data
    var_6 = dict()

    # Create dict with test data
    var_7 = dict()

    # Create dict with test data
    var_8 = dict()

    # Create dict with test data
    var_9 = dict()

    # Create dict with test data
    var_10 = dict()

    # Create dict with test data
    var_11 = dict()

    # Create dict with test data

# Generated at 2022-06-25 03:10:18.822968
# Unit test for function check_file_attrs
def test_check_file_attrs():
    f = open("tests/test_check_file_attrs.txt", "r")
    for line in f:
        if line.index("#")==0:
            continue
        else:
            line = line[:-1]
            l_0 = line.split(" ")
            if l_0[2]!="None":
                l_0[2]=int(l_0[2])
            else:
                l_0[2]=None
            if l_0[3]!="None":
                l_0[3]=int(l_0[3])
            else:
                l_0[3]=None
            if l_0[4]!="None":
                l_0[4]=int(l_0[4])
            else:
                l_0[4]=None

# Generated at 2022-06-25 03:11:18.847718
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test with these parameters:
    test_check_file_attrs.modu = AnsibleModule(argument_spec={})
    test_check_file_attrs.changed = True
    test_check_file_attrs.message = "Starting message"

    # Call the function
    check_file_attrs(test_check_file_attrs.modu, test_check_file_attrs.changed, test_check_file_attrs.message)



# Generated at 2022-06-25 03:11:30.138173
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import imp

    test_src_dir = "test_ansible_module"
    test_tmp_dir = tempfile.mkdtemp()

    shutil.copytree(test_src_dir, test_tmp_dir)

    test_lib_dir = os.path.join(test_tmp_dir, "library")
    test_module = imp.load_source("ansible.builtin.replace", os.path.join(test_lib_dir, "ansible/builtin/replace.py"))

    test_file_src_dir = os.path.join(test_tmp_dir, "test_ansible_module")
    test_file_dest_dir = os.path.join(test_src_dir, "test_file_dest")


# Generated at 2022-06-25 03:11:33.839382
# Unit test for function write_changes
def test_write_changes():
    contents = "test contents"
    path = "test_path"

    def write_changes_mock(module, contents, path):
        test_contents = contents
        test_path = path
        assert test_contents == contents
        assert test_path == path
    test_case_0()



# Generated at 2022-06-25 03:11:37.954718
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec = dict(path = dict(required = True)))
    contents = 'contents'
    path = '/usr/local/etc/ansible/module_utils/ansible.module_utils.basic.py'
    write_changes(module, contents, path)


# Generated at 2022-06-25 03:11:47.903201
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(default=False, type='bool'),
            owner=dict(default=None),
            group=dict(default=None),
            mode=dict(default='0644'),
            validate=dict(type='str'),
            encoding=dict(default='utf-8'),
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    module.atomic_move = fake_atomic_move
    contents = 'a\x00b\x00c'

# Generated at 2022-06-25 03:11:55.938325
# Unit test for function write_changes
def test_write_changes():
    # Use this as the 'module' parameter for main() as well as for other
    # functions that main() calls:
    aModule = AnsibleModule({
        'path':'path.txt',
        'check_mode':False,
        'regexp':'(python)',
        'replace':'\1 \1 \1',
        'diff_mode':False,
        '_ansible_check_mode':False,
        '_ansible_diff':False
    })
    #Should write the following string to path.txt:
    # python python python
    write_changes(aModule, to_bytes('python python python'), aModule.params['path'])
    #Now 'path.txt' should contain 'python python python'
    assert open('path.txt').read() == 'python python python'
    #Let's wipe our

# Generated at 2022-06-25 03:12:03.776142
# Unit test for function write_changes
def test_write_changes():
    try:
        assert write_changes(AnsibleModule(argument_spec={'content': {'type': 'str'}, 'dest': {'type': 'path'}, 'path': {'type': 'path'}, 'backup': {'type': 'bool'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}}), 'test_value_2', '/home/vagrant/.ansible/tmp/ansible-tmp-1563196216.58-187780876031224/source',)
    except AssertionError as e:
        print('AssertionError: %s' % e)
        assert e
        return
    except Exception as e:
        print('Exception: %s' % e)
        assert False
    finally:
        pass



# Generated at 2022-06-25 03:12:13.936718
# Unit test for function write_changes
def test_write_changes():
    import sys
    import os
    import types
    import tempfile
    import subprocess
    try:
        abs = os.path.abspath
        norm = os.path.normpath
        module_path = norm(abs(os.path.dirname(__file__)))
    except:
        module_path = None
    module_path = os.path.join(module_path,'..')
    module_path = os.path.join(module_path,'..')
    module_path = os.path.join(module_path,'..')
    module_path = os.path.join(module_path,'..')
    module_path = os.path.join(module_path,'..')
    module_path = os.path.join(module_path,'..')

# Generated at 2022-06-25 03:12:14.481821
# Unit test for function main
def test_main():
    assert False


# Generated at 2022-06-25 03:12:19.364126
# Unit test for function write_changes
def test_write_changes():
    # Replace the value in path with a given one
    path = "/etc/hosts"
    contents = "0.0.0.0 newnew.host.name"
    write_changes(main(), contents, path)

    # Check whether the value in path is replaced with new one
    f = open(path, 'r')
    line = f.readline()
    f.close()
    if line != contents:
        print("the value in path is not replaced with new one!")


# Generated at 2022-06-25 03:14:56.710302
# Unit test for function write_changes
def test_write_changes():
    var_0 = AnsibleModule()
    var_0.params = {u'unsafe_writes': True}
    var_0.tmpdir = u'/var/tmp'
    var_1 = b'contents'
    var_2 = u'/path'

    var_0.atomic_move = lambda var_1: {
        var_1: lambda var_1: {
            var_2: lambda var_2: None
        }}

    write_changes(var_0, var_1, var_2)


# Generated at 2022-06-25 03:14:58.851832
# Unit test for function write_changes
def test_write_changes():
    var_1 = write_changes(AnsibleModule(
        argument_spec=dict(tmpdir=dict(type='path'))
    ), 'contents', 'path')
    print(var_1)


# Generated at 2022-06-25 03:15:08.983319
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule()
    contents = b'a' * 10
    path = '/tmp/foo'
    validate = module.params.get('validate', None)
    valid = not validate
    if validate:
        if "%s" not in validate:
            module.fail_json(msg="validate must contain %%s: %s" % (validate))
        (rc, out, err) = module.run_command(validate % tmpfile)
        valid = rc == 0
        if rc != 0:
            module.fail_json(msg='failed to validate: '
                                 'rc:%s error:%s' % (rc, err))

    # test the failure case
    rc = 1

# Generated at 2022-06-25 03:15:13.982172
# Unit test for function main
def test_main():
    # Program main
    # Unit:test_main
    # Unit:main
    set_module_args(dict(path='/path/to/file', regexp='string', others_param='others_value',))
    main()

if __name__ == '__main__':
    import pytest
    pytest.main(['test_0.py'])

# Generated at 2022-06-25 03:15:20.930970
# Unit test for function main
def test_main():
    import argparse
    var_0 = argparse.ArgumentParser(description="Replace all instances of a particular string in a file using a back-referenced regular expression  Common file attributes such as permissions, ownership and selinux context are not preserved.  This module is also supported for Windows targets.")
    var_1 = var_0.add_argument("-a", "--after", dest="after", help="If specified, only content after this match will be replaced/removed. Can be used in combination with C(before). Uses Python regular expressions; see U(https://docs.python.org/3/library/re.html).  Uses DOTALL, which means the C(.) special character I(can match newlines).")

# Generated at 2022-06-25 03:15:28.566289
# Unit test for function check_file_attrs

# Generated at 2022-06-25 03:15:34.435210
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    changed = test_case_0
    message = test_case_0
    try:
        out1 = check_file_attrs(module, changed, message)
        print(out1)
    except Exception as e:
        print('Failed with:', e)
    finally:
        os.remove(tmpfile)



# Generated at 2022-06-25 03:15:41.187581
# Unit test for function write_changes
def test_write_changes():
    var_0 = 'test'
    var_1 = AnsiModule(var_0)
    try:
        val_0 = write_changes()
    except Exception as e:
        val_1 = e

# Generated at 2022-06-25 03:15:46.748374
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        raise AssertionError('Unexpected system exit', e)


# Generated at 2022-06-25 03:15:51.427877
# Unit test for function write_changes
def test_write_changes():
    d = {'dest': './test_file', 'contents': '1234'}
    m = AnsibleModule(argument_spec=d)
    write_changes(m, to_bytes(d['contents']), d['dest'])
    out = open(d['dest']).read()
    assert(out == '1234')
    #os.remove(dest)
