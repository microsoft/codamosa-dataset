

# Generated at 2022-06-25 03:06:52.037600
# Unit test for function write_changes
def test_write_changes():
    class AnsibleModuleMock():
        def __init__(self, arg, arg1):
            self.params = arg
            self.tmpdir = arg1
        def fail_json(self, arg):
            print("fail_json print: ", arg)
        def run_command(self, arg):
            print("run_command print: ", arg)
            return (0, "out", "err")
        def atomic_move(self, arg, arg1):
            print("atomic_move print: ", arg, arg1)

    module = AnsibleModuleMock("arg", "arg1")

    try:
        write_changes(module, "contents", "path")
    except Exception as e:
        print("write_changes throws error: ", e)


# Generated at 2022-06-25 03:06:53.334696
# Unit test for function write_changes
def test_write_changes():
    # assert all([input_0, input_1, input_2])
    assert True


# Generated at 2022-06-25 03:06:53.857986
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 03:07:01.740501
# Unit test for function write_changes
def test_write_changes():
    ansible_module = AnsibleModule(
        argument_spec={
            'path': dict(type='path', required=True),
            'contents': dict(type='str', required=True),
            'validate': dict(type='str', required=False, default=None),
            'unsafe_writes': dict(type='bool', required=False, default=False),
        },
        supports_check_mode=False,
        add_file_common_args=False,
    )
    write_changes(ansible_module, None, None)


# Generated at 2022-06-25 03:07:03.258024
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = check_file_attrs()


# Generated at 2022-06-25 03:07:09.003784
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Run this function without the arguments it is expecting, to see what error it raises.
    try:
        var_1 = check_file_attrs()
    except TypeError as e:
        print(e)
    else:
        # If the code above doesn't raise an error, this line will run.
        # This means the function ran succesfully.
        assert False


# Generated at 2022-06-25 03:07:12.922112
# Unit test for function check_file_attrs
def test_check_file_attrs():
    tmp_msg = ""
    t_changed = False
    tmp_msg, t_changed = check_file_attrs(tmp_msg, t_changed)
    assert tmp_msg == "ownership, perms or SE linux context changed"
    assert t_changed == 1


# Generated at 2022-06-25 03:07:17.838108
# Unit test for function write_changes
def test_write_changes():
    var_1 = main()
    # Put your test input parameters here
    module = var_1
    contents = 'test_contents'
    path = 'test_path'
    var_2 = write_changes(module, contents, path)
    result = var_2
    # Put your test assertions here


# Generated at 2022-06-25 03:07:19.230015
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0


# Generated at 2022-06-25 03:07:27.811375
# Unit test for function main
def test_main():
    import ansible_playbook_paychecks
    from ansible_playbook_paychecks.module_utils.module_common import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-25 03:07:49.810061
# Unit test for function main
def test_main():
    path = os.path.dirname(os.path.abspath(__file__))
    path = path + "/main-pytest.txt"
    params = {
        'path': path,
        'regexp': 'hello',
        'replace': 'nope',
        'backup': False,
        'validate': None,
        'encoding': 'utf-8',
    }
    try:
        os.remove(path)
    except OSError:
        pass
    with open(path, 'w+') as file:
        file.write('hello')
    main(params)


if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:07:59.921063
# Unit test for function main
def test_main():

    # Setup mock arguments
    class MockArgs:
        path = None
        after = None
        before = None
        backup = None
        encoding = None
        regexp = None
        replace = None
        validate = None

    class MockParams:
        path = None
        after = None
        before = None
        backup = None
        encoding = None
        regexp = None
        replace = None
        validate = None

    class MockModule:
        params = MockParams()

        def fail_json(self, *args, **kwargs):
            self.exit_json(failed=True, *args, **kwargs)

        def exit_json(self, *args, **kwargs):
            if 'changed' not in kwargs:
                exit_json.changed = False
            else:
                exit_json.changed = k

# Generated at 2022-06-25 03:08:01.306044
# Unit test for function write_changes
def test_write_changes():
    var_1 = write_changes(module, contents, path)


# Generated at 2022-06-25 03:08:08.640618
# Unit test for function write_changes
def test_write_changes():
    module_0 = AnsibleModule(argument_spec=dict(path=dict(type='path', required=True),
                                                regexp=dict(type='str', required=True),
                                                replace=dict(type='str', required=False),
                                                after=dict(type='str', required=False),
                                                before=dict(type='str', required=False),
                                                backup=dict(type='bool', default=False),
                                                validate=dict(type='str', required=False),
                                                encoding=dict(type='str', default='utf-8', required=False),
                                                others=dict(type='str', required=False)))

    # Set up mock
    tmpfile = tempfile.mkstemp()
    with open(tmpfile, 'w') as handle:
        handle.write

# Generated at 2022-06-25 03:08:16.574173
# Unit test for function check_file_attrs

# Generated at 2022-06-25 03:08:17.360544
# Unit test for function write_changes
def test_write_changes():
    assert var_0 == None


# Generated at 2022-06-25 03:08:19.601190
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('test_main failed')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:08:21.046004
# Unit test for function write_changes
def test_write_changes():
    print('Testing var_0 = write_changes(...)\n')
    assert main() == 'write_changes(...)'



# Generated at 2022-06-25 03:08:22.517509
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        assert False, 'An error occurred..'



# Generated at 2022-06-25 03:08:23.032267
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:08:49.976042
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Expecting error for line 29
    with pytest.raises(UnboundLocalError) as excinfo:
        test_case_0()


# Generated at 2022-06-25 03:08:59.178702
# Unit test for function main
def test_main():
    var_10 = {}
    var_10['_ansible_parsed'] = False
    var_10['_ansible_no_log'] = False
    var_10['destfile'] = 'file'
    var_10['regexp'] = '^(.+)$'
    var_10['_ansible_version'] = 2.9
    var_10['after'] = ''
    var_10['_ansible_check_mode'] = False
    var_10['dest'] = 'file'
    var_10['backup_file'] = 'file'
    var_10['replace'] = ''
    var_10['before'] = ''
    var_10['_ansible_search_path'] = None
    var_10['_ansible_diff'] = True
    var_10['backup'] = False

# Generated at 2022-06-25 03:09:02.248499
# Unit test for function check_file_attrs
def test_check_file_attrs():
    log.info("Testing check_file_attrs for case 0")
    var_0 = main()
    assert check_file_attrs(var_0, False, '') == ('ownership, perms or SE linux context changed', True), "Test case 0 failed"
    log.info("Test case 0 passed")



# Generated at 2022-06-25 03:09:08.217134
# Unit test for function main
def test_main():
    import cStringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = cStringIO.StringIO()
        sys.stdout = out
        var_0 = main()
        sys.stdout.seek(0)
        out = sys.stdout.read()[:-1]
        return out
    finally:
        sys.stdout = saved_stdout

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:09:09.791162
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:09:11.542651
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = check_file_attrs({}, False, "")
    return var_0


# Generated at 2022-06-25 03:09:15.022132
# Unit test for function check_file_attrs
def test_check_file_attrs():
    with mock.patch.object(AnsibleModule, 'set_file_attributes'):
        AnsibleModule.set_file_attributes_if_different = MagicMock()
        test_case_0()


# Generated at 2022-06-25 03:09:16.002694
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 03:09:16.693068
# Unit test for function write_changes
def test_write_changes():
    write_changes(module, contents, path)


# Generated at 2022-06-25 03:09:18.252167
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule()
    write_changes(module, '', 'ansible.builtin')



# Generated at 2022-06-25 03:10:08.060060
# Unit test for function write_changes
def test_write_changes():
    args = []
    # first argument is self
    args.append(None)
    args.append("test_contents")
    args.append("test_path")
    if test_write_changes.__doc__:
        print(test_write_changes.__doc__)
    write_changes(*args)
    test_case_0()



# Generated at 2022-06-25 03:10:08.755261
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:10:09.920889
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_1 = False
    var_2 = ""
    
    return var_2, var_1


# Generated at 2022-06-25 03:10:11.797298
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:10:16.478269
# Unit test for function write_changes
def test_write_changes():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        print(format_exc())
        print("Closing Ansible module")
        return False
    else:
        print("Closing Ansible module")
        return True



# Generated at 2022-06-25 03:10:24.116632
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_1 = AnsibleModule(
        argument_spec = dict(
            unsafe_writes = dict(type='bool', default=False),
            backup         = dict(type='bool', default=False)
        )
    )
    var_1.tmpdir = '/tmp/ansible-tmp-1579890777.1601649-2759-46958434681869'
    var_1.fail_json.mock_returns = None
    var_1.run_command.mock_returns = (0, '', '')
    var_1.load_file_common_arguments.mock_returns = dict()
    var_1.set_file_attributes_if_different.mock_returns = False
    # Set up function parameters and autospec

# Generated at 2022-06-25 03:10:32.321149
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec={
            'path':{'type':'str', 'required':True},
            'contents':{'type':'str', 'required':True},
            'validate':{'type':'str', 'required':True},
            'unsafe_writes':{'type':'str', 'required':True}
        },
    )

    assert write_changes(module, contents="", path="") == True, "Something went wrong"


# Generated at 2022-06-25 03:10:34.168447
# Unit test for function write_changes
def test_write_changes():
    var_0 = AnsibleModule('test', 'test', 'test')
    var_1 = main(var_0)



# Generated at 2022-06-25 03:10:34.633783
# Unit test for function write_changes
def test_write_changes():
    assert False


# Generated at 2022-06-25 03:10:37.790817
# Unit test for function check_file_attrs

# Generated at 2022-06-25 03:12:23.859549
# Unit test for function main
def test_main():
    assert(main())


if __name__ == '__main__':
    # for coverage
    to_bytes = to_bytes
    to_text = to_text
    main()

# Generated at 2022-06-25 03:12:25.580621
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as err:
        print("Exception in test case 0 : " + str(err))
        raise err

# Test suite for the module

# Generated at 2022-06-25 03:12:30.972052
# Unit test for function main
def test_main():
    # Replace all instances of 'foo' in file.txt with 'bar'
    tst_file = 'file.txt'
    tst_oldfile = 'backup_' + tst_file
    with open(tst_file, 'w+') as f:
        f.write('foo')
    assert os.path.exists(tst_file)
    main(["'foo'", "'bar'", tst_file, '0'])
    with open(tst_file, 'r') as f:
        tst_data = f.read()
        assert tst_data == 'bar'
    # cleanup temp files
    os.remove(tst_file)
    if os.path.exists(tst_oldfile):
        os.remove(tst_oldfile)


# Generated at 2022-06-25 03:12:33.236117
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:12:44.156157
# Unit test for function write_changes
def test_write_changes():
    """
    Unit test function write_changes(module, contents, path)
    """
    # Get function parameters
    module = AnsibleModule(argument_spec={'path': {'required': True, 'type': 'path'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'required': False, 'type': 'bool', 'default': False}})
    contents = module.params.get('contents', None)
    path = module.params.get('path', None)
    try:
        write_changes(module, contents, path)
        return True
    except:
        print(format_exc())
        return False
    

# Generated at 2022-06-25 03:12:48.393983
# Unit test for function main
def test_main():
    var_1 = dict()
    var_1['path'] = './file.txt'
    var_1['regexp'] = '\\b(localhost)(\\d*)\\b'
    var_1['replace'] = '\\1\\2.localdomain\\2 \\1\\2'
    main(var_1)


# Generated at 2022-06-25 03:12:50.432293
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule()
    var_0 = check_file_attrs(module, False, 'string')
    assert var_0 == ('string',False)


# Generated at 2022-06-25 03:12:53.512435
# Unit test for function main
def test_main():
  # check the return value
  assert var_0 == None


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:12:56.680176
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 03:12:57.386113
# Unit test for function main
def test_main():
    assert True