

# Generated at 2022-06-20 22:25:00.621678
# Unit test for function main

# Generated at 2022-06-20 22:25:05.047108
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/path', 'unsafe_writes': True}
    changed, message = check_file_attrs(module, False, "")
    assert (message == "ownership, perms or SE linux context changed")



# Generated at 2022-06-20 22:25:05.560092
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True


# Generated at 2022-06-20 22:25:06.644997
# Unit test for function write_changes
def test_write_changes():
    pass

# Generated at 2022-06-20 22:25:11.434702
# Unit test for function main
def test_main():
    test_module_args = dict(
        path="/path/to/file",
        regexp="(^a$)",
        replace="",
        after="",
        before="",
        backup=False,
        validate="",
    )

# Generated at 2022-06-20 22:25:18.009068
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    DEST_PATH = '/tmp/hello'
    REGEXP = 'Hello+'
    REPLACE = 'world'
    CONTENTS = 'Hello'

# Generated at 2022-06-20 22:25:27.234863
# Unit test for function check_file_attrs
def test_check_file_attrs():
  test_module = AnsibleModule(
    argument_spec=dict(
      path=dict(type='path', required=True),
      regexp=dict(type='str', required=True),
      replace=dict(type='str'),
      after=dict(type='str'),
      before=dict(type='str'),
      backup=dict(type='bool', default=False),
      encoding=dict(type='str', default='utf-8'),
      follow=dict(type='bool', removed_in_version='2.5'),
      unsafe_writes=dict(type='bool', default=False),
      others=dict(type='str'),
      validate=dict(type='str')
    ),
    add_file_common_args=True,
    supports_check_mode=True
  )
  test_module.check_mode

# Generated at 2022-06-20 22:25:34.607994
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    orig_class = AnsibleModule
    AnsibleModule = MockAnsibleModule
    try:
        assert check_file_attrs(module, False, "") == ('ownership, perms or SE linux context changed', True)
    except:
        AnsibleModule = orig_class
        raise
    AnsibleModule = orig_class
# end of unit test for function check_file_attrs


# Generated at 2022-06-20 22:25:46.031523
# Unit test for function main

# Generated at 2022-06-20 22:25:52.702264
# Unit test for function main
def test_main():
  args = dict(
    path = "/etc/hosts",
    regexp = "^(?P<dctv>ListenAddress[ ]+)(?P<host>[^\n]+)$",
    replace = "#\g<dctv>\g<host>\n\g<dctv>0.0.0.0" 
  )
  _m = AnsibleModule(argument_spec=args)
  main()
# test call
test_main()

# Generated at 2022-06-20 22:26:13.605603
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class fake_module(object):

        class Parameters(object):
            pass

        class file_common_args(object):
            pass

        def set_file_attributes_if_different(self, file_args, False_):
            pass

        def load_file_common_arguments(self, params):
            pass

    module = fake_module()
    changed = True
    message = "ownership, perms or SE linux context changed"
    m1 = "ownership, perms or SE linux context changed and "
    m2 = "ownership, perms or SE linux context changed"
    message, changed = check_file_attrs(module, changed, m1)
    assert message == m2
    assert changed == True



# Generated at 2022-06-20 22:26:26.947062
# Unit test for function main
def test_main():
    path = ''
    encoding = ''
    res_args = {}
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    assert os.path.isdir(path)

# Generated at 2022-06-20 22:26:36.658901
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import collections
    import json
    module = AnsibleModule(argument_spec=dict(path=dict(type='path', required=True)))
    module.params['path'] = "/tmp/foo"
    changed = False
    message = ""
    module_args = collections.namedtuple('module_args', ['path', 'owner', 'group', 'mode', 'seuser', 'serole', 'setype', 'selevel', 'unsafe_writes'])
    file_args = module.load_file_common_arguments(module_args)
    file_args.path = '/tmp/foo'
    file_args.owner = 'root'
    file_args.group = 'root'
    file_args.mode = '0444'
    file_args.seuser = 'unconfined_u'

# Generated at 2022-06-20 22:26:40.579306
# Unit test for function main
def test_main():
    path = 'test/'
    contents = '127.0.0.1 localhost\n'
    mre = re.compile('^(.:${1)$')
    result = re.subn(mre, '\1test\2', contents, 0)
    print (result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:42.872992
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    message = "test"
    assert tuple(check_file_attrs(module, False, message)) == (message, False)



# Generated at 2022-06-20 22:26:49.938092
# Unit test for function main
def test_main():

    # This test is not meant to be run, it's just to get coverage going
    path = "/path/to/fake_file"
    encoding = 'utf-8'

# Generated at 2022-06-20 22:26:51.005230
# Unit test for function write_changes
def test_write_changes():
    assert True
# Unit test ends



# Generated at 2022-06-20 22:26:53.357364
# Unit test for function main
def test_main():
    with pytest.raises(FailJsonException) as excinfo:
        main()
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:58.342483
# Unit test for function write_changes
def test_write_changes():

    class FileException(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class MockAnsibleModule(object):

        def __init__(self):
            self.tmpdir = tempfile.gettempdir()
            self.params = {
                'path': '/path/to/file',
                'unsafe_writes': True
            }

        def fail_json(self, *args, **kwargs):
            raise FileException(args, kwargs)

        def atomic_move(self, src, dest, unsafe_writes):
            if unsafe_writes:
                os.rename(src, dest)
            else:
                raise Exception('Cannot write to file: %s' % dest)


# Generated at 2022-06-20 22:27:10.337948
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import os
    import tempfile
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    try:
        from __main__ import display
        display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
    def fail_json(self, msg):
        return msg
    setattr(AnsibleModule, 'fail_json', fail_json)
    setattr(AnsibleModule, 'atomic_move', lambda self, src, dest, unsafe_writes=False: None)
    setattr(AnsibleModule, 'set_file_attributes_if_different',
            lambda self, file_args, changed: True)

# Generated at 2022-06-20 22:27:37.868708
# Unit test for function write_changes
def test_write_changes():
    """ test_write_changes function
    """
    module = AnsibleModule({})
    contents = 'this is a test'
    path = '/tmp/test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)


# ===========================================
# Main control flow


# Generated at 2022-06-20 22:27:49.273230
# Unit test for function main
def test_main():
    import os
    import tempfile
    import json
    import shutil
    from ansible.module_utils._text import to_text
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:27:55.949362
# Unit test for function check_file_attrs
def test_check_file_attrs():
    mock = MagicMock(return_value=AnsibleModule(
        argument_spec=dict(
        path=dict(type='path'),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str', default=''),
        before=dict(type='str', default=''),
        backup=dict(type='bool', default=False),
        validate=dict(type='str')
        ),
        supports_check_mode=True
    ))
    mock.atomic_move = MagicMock()

# Generated at 2022-06-20 22:28:08.719240
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    m._tmpdir = tempfile.mkdtemp()
    f = open(os.path.join(m._tmpdir, "test.txt"), "w")
    f.write("testing\n")
    f.flush()
    f.close()
    try:
        write_changes(m, "testing new\n", os.path.join(m._tmpdir, "test.txt"))
        f = open(os.path.join(m._tmpdir, "test.txt"), "r")
        l = f.read()
        f.close()
        assert l == "testing new\n"
    finally:
        os.unlink(os.path.join(m._tmpdir, "test.txt"))

# Generated at 2022-06-20 22:28:19.977442
# Unit test for function write_changes
def test_write_changes():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(required=True),
            replace=dict(default=''),
            validate=dict(default=None),
            unsafe_writes=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    path = "/home/local/user/path/ansible_replace_test"
    with open(path, "w") as f:
        f.write("1234567")
    regexp = "(\d+)"
    replace = "\g<1>\g<1>"
    (rc, out, err) = module.run_command("cat {}".format(path))
    assert out == "1234567"

# Generated at 2022-06-20 22:28:33.763340
# Unit test for function main
def test_main():
    args = dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    )
    AnsibleModule.argument_spec = args
    AnsibleModule.__dict__ = {'params': args}
    o = AnsibleModule()
    o.check_mode = False

# Generated at 2022-06-20 22:28:38.425862
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule({
        'src': None,
        'path': '/etc/hosts',
        'line': '',
        'regexp': None,
        'replace': '',
        'validate': None,
        'unsafe_writes': False,
    })
    write_changes(m, '', '/etc/hosts')


# Generated at 2022-06-20 22:28:50.253980
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-20 22:28:57.771700
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class TestModule(object):
        def __init__(self):
            self.params = {}

    module = TestModule()
    module.params = {'validate': None, 'unsafe_writes': True}
    changed = False
    message = 'Initial message'

    file_args = module.load_file_common_arguments(module.params)
    if module.set_file_attributes_if_different(file_args, False):
        changed = True
        message = 'ownership, perms or SE linux context changed'

    return message, changed



# Generated at 2022-06-20 22:29:03.589821
# Unit test for function check_file_attrs
def test_check_file_attrs():
    contents = "a\nb\nc\nd\ne\nf\n"
    from ansible.modules.files.test.test_file import _module  # noqa
    from ansible.modules.files.test.test_file import _mock_module  # noqa
    from ansible.modules.files.test.test_file import set_module_args  # noqa
    from ansible.modules.files.test.test_file import tmp_path_factory  # noqa

    tmpdir = tmp_path_factory.mktemp('replace')
    filename = tmpdir.join('test')
    filename.write(contents)
    module = _mock_module(tmpdir)
    module.params['path'] = os.path.join(str(tmpdir), 'test')

# Generated at 2022-06-20 22:29:49.305648
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:29:58.978017
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class Args:
        follow = True
        path = '/tmp/test'
        unsafe_writes = False
    module = type('Args', (), Args)
    module.check_mode = False
    module.no_log = False
    module.params = {}
    module.params['unsafe_writes'] = True
    module.load_file_common_arguments = lambda x: {}
    module.set_file_attributes_if_different = lambda x, y: False
    changed, msg = False, ""
    return check_file_attrs(module, changed, msg) == (msg, changed)


# Generated at 2022-06-20 22:30:08.555634
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from sys import version_info
    from os import geteuid
    # If you change the path attribute below, modify it in the unit tests as well
    if version_info[0] < 3:
        test_module = AnsibleModule({'path': '/tmp/test.file', 'backup': 'no', 'unsafe_writes': False})
    else:
        test_module = AnsibleModule({'path': '/tmp/test.file', 'backup': False, 'unsafe_writes': False})
    test_module.tmpdir = '/tmp'
    test_module.run_command = lambda args: (0, '', '')
    test_module.atomic_

# Generated at 2022-06-20 22:30:12.553822
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True)
        )
    )
    message = 'Unit test'
    changed = False
    message, changed = check_file_attrs(module, changed, message)



# Generated at 2022-06-20 22:30:18.956470
# Unit test for function write_changes
def test_write_changes():

    from ansible.module_utils import basic_common
    module_class = basic_common.AnsibleModule
    class TestModule(module_class):
        def run_command(self, cmd):
            return 0, 'exit_code', 'stderr'
        def fail_json(self, **kwargs):
            raise Exception('failed!')
    m = TestModule({})
    m.no_log_values.update({"replacement": "omitted due to no_log", "regexp": "omitted due to no_log"})
    m.unsafe_writes = True
    with tempfile.NamedTemporaryFile(mode="wb") as tf:
        with open(tf.name, "w") as f:
            f.write(b'original')

# Generated at 2022-06-20 22:30:29.187818
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    test_params = test_module.params
    test_path = test_params['path']
    test_encoding = test_params['encoding']


# Generated at 2022-06-20 22:30:30.876197
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-20 22:30:37.767919
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as mock_module:
        mock_module.side_effect = lambda x, **kw: x
        result = main()
        assert result['path'] == '/etc/hosts'
        assert result['regexp'] == '\b(localhost)(\d*)\b'
        assert result['replace'] == '\1\2.localdomain\2 \1\2'


# Generated at 2022-06-20 22:30:44.941461
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class FakeModule:

        def __init__(self, debug=False):
            self.debug = debug

        def fail_json(self, message):
            raise Exception(message)

        def run_command(self, command):
            return 1, "", "error"

        def load_file_common_arguments(self, params):
            return dict(path="/tmp/f", mode=None)

        def set_file_attributes_if_different(self, file_args, changed):
            return True

    module = FakeModule()
    changed, message = check_file_attrs(module, False, "")
    assert "ownership, perms or SE linux context changed" in message
    assert changed



# Generated at 2022-06-20 22:30:54.282286
# Unit test for function write_changes
def test_write_changes():
  """
  Tests the write_changes function.
  """
  # Add simple test code that uses the function and does a simple assert on
  # the results. This will exercise the code you wrote and provide basic
  # coverage.
  tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
  f = os.fdopen(tmpfd, 'wb')
  f.write(contents)
  f.close()
  assert os.path.exists(tmpfile)
  if os.path.exists(tmpfile):
    os.unlink(tmpfile)
  assert not os.path.exists(tmpfile)



# Generated at 2022-06-20 22:32:40.128364
# Unit test for function write_changes
def test_write_changes():
    import ansible.module_utils
    import ansible.module_utils._text
    import tempfile
    import os
    import shutil
    import time
    import re
    import json
    import sys
    import difflib
    def mock_exit_json(path,**kwargs):
        return
    def mock_fail_json(path,**kwargs):
        raise Exception(kwargs['msg'])
    def get_content(p):
        f = open(p)
        content = f.read()
        f.close()
        return content
    def validate_newline(path):
        newline = ['\n','\r\n']
        f = open(path,'rb')
        content = f.read()
        f.close()
        return content[-1:] in newline

# Generated at 2022-06-20 22:32:48.793631
# Unit test for function write_changes
def test_write_changes():
    """
    Test write_changes()
    """
    module = AnsibleModule(argument_spec={
        'path': {"type": 'path', "required": True},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    contents = "test contents"
    path = "/tmp/test_write_changes"
    tmpfd, tmpfile = tempfile.mkstemp(dir="/tmp")
    expected_tmpfile = tmpfile
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()
    module_write_changes = module.atomic_move
    module.atomic_move = None
    write_changes(module, contents, path)
    assert open(path).read() == contents
    module.atomic_move = module_write

# Generated at 2022-06-20 22:32:50.211060
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:32:57.784050
# Unit test for function main
def test_main():
    from ansible.modules.files.replace import main
    dummy_args = {
        'path' : '/etc/hosts',
        'regexp': '(\s+)old\.host\.name(\s+.*)?$',
        'replace': '\1new.host.name\2',
        'backup': 'yes',
        'validate': '/usr/sbin/apache2ctl -f %s -t',
        'encoding': 'utf-8',
        'after': '<VirtualHost [*]>',
        'before': '</VirtualHost>',
        'unsafe_writes': False,
        'follow': False,
        'check_mode': True
    }

    dummy_main = main(dummy_args)
    assert dummy_main == True


# Generated at 2022-06-20 22:33:07.982806
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            content = dict(type='str'),
            backup = dict(type='bool', default=False),
            validate = dict(type='str'),
            follow = dict(type='bool', default=False, removed_in_version='2.5'),
            unsafe_writes = dict(type='bool', default=False, removed_in_version='2.5'),
        ),
        supports_check_mode=True
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    changed = True
    message = "ok"
    message, changed = check_file_attrs(module, changed, message)

# Generated at 2022-06-20 22:33:17.784512
# Unit test for function check_file_attrs
def test_check_file_attrs():

    mock_module = MockModule()

    # Check with no change
    mock_module.params = dict(path='/foo/bar', regexp='', replace='',
                              owner='foo', group='bar', mode='0755', seuser='')
    changed = False
    message = ''

    message, changed = check_file_attrs(mock_module, changed, message)

    assert not changed
    assert message == ''

    # Check with change
    mock_module.params = dict(path='/foo/bar', regexp='', replace='',
                              owner='foo', group='bar', mode='0644', seuser='bar')
    changed = False
    message = ''

    message, changed = check_file_attrs(mock_module, changed, message)

    assert changed

# Generated at 2022-06-20 22:33:27.805819
# Unit test for function main
def test_main():
    import os
    import shutil
    import subprocess
    import sys
    import time

    filename = 'ansibleModulesReplaceUnitTest'

    # If anyone wants to run this test on Windows, go ahead, but you're on your
    # own.  I have no idea how the module will operate on Windows.
    if sys.platform.startswith('win'):
        return

    def make_test_file(content):
        f = open(filename, "w")
        f.write(content)
        f.close()

    def replace_test(regexp, replace, before, after):
        before_time = os.path.getmtime(filename)

# Generated at 2022-06-20 22:33:34.121450
# Unit test for function check_file_attrs
def test_check_file_attrs():
    lines = [
            '# foo',
            'bar',
            '# test',
            'old content',
            '# test2',
            'old content2'
    ]
    tmpdir = '/tmp'
    tempcopy = os.path.join(tmpdir, 'testfile')
    fd = open(tempcopy, 'w')
    fd.write('\n'.join(lines))
    fd.close()
    class module_params(object):
        owner = 'root'
        group = 'root'
        seuser = 'system_u'
        serole = 'object_r'
        selevel = 's0'
        setype = 'tmp_t'
        path = tempcopy
        unsafe_writes = False
    m = AnsibleModule(argument_spec={})
    m

# Generated at 2022-06-20 22:33:41.296400
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'choices': ['preserve', '0644', '0640', '0444']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
    })
    module.params['path'] = '/test/file/here'
    module.params['owner'] = 'root'
    module.params['group'] = 'bin'
    module.params['mode'] = '0644'

# Generated at 2022-06-20 22:33:52.304094
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.tmpdir = 'tmp'
    module.atomic_move = lambda x, y: None