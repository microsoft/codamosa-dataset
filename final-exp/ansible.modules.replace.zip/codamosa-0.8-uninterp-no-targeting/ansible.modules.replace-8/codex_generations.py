

# Generated at 2022-06-20 22:25:02.075526
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'unsafe_writes': {'type': 'bool', 'required': False, 'default': True}})
    module.params = {
        'unsafe_writes': True
    }
    changed = False
    message = "Test"
    module.atomic_move = lambda a, b, **kwargs: True
    # Test no changes
    module.set_file_attributes_if_different = lambda a, b: True
    message, changed = check_file_attrs(module, changed, message)
    assert changed == False
    assert message == "Test"
    # Test changes
    module.set_file_attributes_if_different = lambda a, b: False
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
   

# Generated at 2022-06-20 22:25:07.210256
# Unit test for function write_changes
def test_write_changes():
    contents = 'Mocked contents'
    path = '/test/test'
    module = AnsibleModule(argument_spec={'dest': {'required': True}})
    module.params['unsafe_writes'] = False
    try:
        write_changes(module, contents, path)
    except Exception as e:
        assert False, 'Unhandled exception: %s' % e



# Generated at 2022-06-20 22:25:12.584472
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            _diff_peek=dict(type='str')
        )
    )
    module.exit_json(changed=False)


# Generated at 2022-06-20 22:25:13.392495
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:25:24.981224
# Unit test for function write_changes
def test_write_changes():
  from ansible.modules.files import replace
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager

  class TestModule(AnsibleModule):
    def __init__(self, *args, **kwargs):
      super(TestModule, self).__init__(*args, **kwargs)
      self.params = {}

    def fail_json(self, *args, **kwargs):
      self.exit_args = args
      self.exit_kwargs = kwargs
      raise Exception('FAIL')

    def exit_json(self, *args, **kwargs):
      self.exit_args = args
      self.exit_kwargs = kwargs

    def run_command(self, cmd):
      return (0, '', '')


# Generated at 2022-06-20 22:25:29.597843
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'state': {'type': 'str'},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str'},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'}
    })
    changed = True
    message = "ownership, perms or SE linux context changed"
    message, changed = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed is True



# Generated at 2022-06-20 22:25:42.008313
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # Fix for unsupported path in windows
    path = r'c:\test\test.txt'
    regexp = 'test'
    replace = 'test'

    # Mock class for atomic move
    class MockAtomicMove(object):
        def __init__(self):
            self.new = None
            self.old = None
            self.unsafe = None
    
    mock_atomic_move = MockAtomicMove()

    # Mock class for run_command
    class MockRunCommand(object):
        def __init__(self):
            self.command = None
            self.rc = 0
            self.stdout = 'MOCK'
            self.stderr = 'MOCK'

        def __call__(self, command):
            self.command = command

# Generated at 2022-06-20 22:25:49.956606
# Unit test for function check_file_attrs
def test_check_file_attrs():

    my_module = AnsibleModule(argument_spec={})
    my_module.set_file_attributes_if_different = lambda a, b: b
    assert check_file_attrs(my_module, 0, "test") == ('test and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(my_module, 1, "test") == ('test and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-20 22:26:00.319682
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            follow=dict(type='bool', removed_in_version='2.5'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params

# Generated at 2022-06-20 22:26:05.879499
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    msg, changed = check_file_attrs(module, False, "foo")
    assert msg == "ownership, perms or SE linux context changed"
    assert changed is True
    assert not module.check_mode



# Generated at 2022-06-20 22:26:29.935901
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # Test with the parameters given in the example

# Generated at 2022-06-20 22:26:38.832614
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MockModule({})
    changed, message = False, ""
    file_args = {'path':'/a_path', 'owner':'owner', 'group':'group',
                 'mode':'mode', 'seuser':'seuser', 'serole':'serole',
                 'setype':'setype', 'selevel':'selevel', '_original_basename':'/a_path',
                 'unsafe_writes':False}
    module.set_file_attributes_if_different = Mock(return_value=True)
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)
    module.set_file_attributes_if_different = Mock(return_value=False)

# Generated at 2022-06-20 22:26:46.587357
# Unit test for function main
def test_main():
    # mock the module so that we can specify our args
    # and side effects
    from ansible.modules.files import replace
    import ansible.module_utils.basic
    orig_import = __import__

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)


# Generated at 2022-06-20 22:26:56.711222
# Unit test for function write_changes
def test_write_changes():
    tmpfd, tmpfile = tempfile.mkstemp(dir="/tmp")
    f = os.fdopen(tmpfd, 'wb')
    f.write("file contents")
    f.close()
    path = "/tmp/test_write_changes"
    contents = "test"
    m_atomic_move = Mock(return_value=True)
    m_params = {"unsafe_writes": True}
    # create a module
    module = Mock(params=m_params,
                  atomic_move=m_atomic_move)
    # run function
    write_changes(module=module, contents=contents, path=path)
    # check function results
    assert os.path.isfile("/tmp/test_write_changes")

# Generated at 2022-06-20 22:26:59.623935
# Unit test for function check_file_attrs
def test_check_file_attrs():
    check_file_attrs(AnsibleModule({'path': 'tmp/foo', 'foo': 'bar'},
                                   check_invalid_arguments=False),
                     True,
                     'bar')



# Generated at 2022-06-20 22:27:11.894352
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
          path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
          regexp=dict(type='str', required=True),
          replace=dict(type='str', default=''),
          after=dict(type='str'),
          before=dict(type='str'),
          backup=dict(type='bool', default=False),
          validate=dict(type='str'),
          encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    assert module.check_mode is True, 'ansible.builtin.replace should have check_mode = True'

    # Mock module.exists

# Generated at 2022-06-20 22:27:17.357701
# Unit test for function write_changes
def test_write_changes():
    import os
    import sys
    import tempfile
    import time
    import unittest

    module_path = os.path.join(os.path.dirname(__file__), '..', '..')
    sys.path.insert(0, module_path)

    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.basic import AnsibleModule

    # create fake module
    module = AnsibleModule({'validate': r'grep "HelloFoo"'})
    module.exit_json = lambda x: x
    module.fail_json = lambda msg, **kwargs: sys.exit(1)
    module.tmpdir = tempfile.gettempdir()

    # create fake file
    tmpfd, path = tempfile.mkstemp()

# Generated at 2022-06-20 22:27:31.099314
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:27:33.477597
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None,True, "Test") == ("Test and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-20 22:27:34.785001
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:28:08.508770
# Unit test for function main
def test_main():
    path = '/path/to/a/hosts'
    module = AnsibleModule({
        'path': path,
        'regexp': r'\b(localhost)(\d*)\b',
        'replace': r'\1\2.localdomain\2 \1\2',
        'backup': False
    })
    with open(path, 'w') as f:
        f.write('127.0.0.1 localhost')
    main()
    with open(path, 'r') as f:
        assert f.read() == '127.0.0.1 localhost\n127.0.0.1 localhost.localdomain localhost'


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:28:18.454686
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:28:32.706759
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils import sandbox

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-20 22:28:33.330628
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-20 22:28:39.077680
# Unit test for function main
def test_main():
    args = dict(
        path = '/path/file.txt',
        regexp = '(\\s+)old\\.host\\.name(\\s+.*)?$',
        replace = '\\1new.host.name\\2',
        backup = 'no',
        encoding = 'utf-8',
    )
    module = AnsibleModule(argument_spec=args)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:28:39.978168
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert 1 == 1



# Generated at 2022-06-20 22:28:53.344542
# Unit test for function main
def test_main():
    a = dict(path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),regexp=dict(type='str', required=True),replace=dict(type='str', default=''),after=dict(type='str'),before=dict(type='str'),backup=dict(type='bool', default=False),validate=dict(type='str'),encoding=dict(type='str', default='utf-8'),)

# Generated at 2022-06-20 22:29:01.936044
# Unit test for function write_changes
def test_write_changes():
  f = tempfile.NamedTemporaryFile()
  path = f.name 
  f.write(b'old')
  f.close()
  module = AnsibleModule({})
  write_changes(module, to_bytes(u'new'), path)
  f = open(path, 'rb')
  assert f.read() == to_bytes(u'new')
  f.close()
  class FakeModule():
     def __init__(self):
       self.params = {'validate': None}
  module = FakeModule()

# Generated at 2022-06-20 22:29:09.388403
# Unit test for function write_changes
def test_write_changes():
    assert os.path.isfile('/tmp/file-change') == False
    module = AnsibleModule(argument_spec={'name': dict(type='str')})
    contents = to_bytes('{"key" : "value"}')
    mktempfd, tmpfile = tempfile.mkstemp(dir='/tmp')
    f = os.fdopen(mktempfd, 'wb')
    f.write(contents)
    f.close()
    path = "/tmp/file-change"
    module.tmpdir = "/tmp"
    module.atomic_move(tmpfile, path, unsafe_writes=True)
    assert os.path.isfile('/tmp/file-change') == True
    # remove test file
    os.remove('/tmp/file-change')

# Generated at 2022-06-20 22:29:18.553126
# Unit test for function write_changes
def test_write_changes():
    """ Test function for write_changes"""
    path = 'test.txt'
    contents = 'This is a test for write_changes'
    open(path, 'wb').write(contents.encode('utf-8'))
    # Instanciate module
    module = AnsibleModule({'path': path}, check_mode=False)
    # Call funtion
    write_changes(module, contents.encode('utf-8'), path)
    # Delete file
    os.remove(path)


# Generated at 2022-06-20 22:30:08.386735
# Unit test for function main
def test_main():
    module = AnsibleModule({ "path": "/abc"})
    assert module.params.get('path') == "/abc"


# Generated at 2022-06-20 22:30:15.170535
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:30:27.529625
# Unit test for function write_changes
def test_write_changes():
    tmp_path = os.path.join(tempfile.mkdtemp(), 'test_file.txt')
    tmp_dir = os.path.dirname(tmp_path)
    tmp_fd, tmp_file = tempfile.mkstemp(dir=tmp_dir)
    os.close(tmp_fd)
    open(tmp_path, 'w').close()


    def fail(module, msg):
        module.fail_json(msg=msg)

    def run_command(module, command):
        if command == 'test -f %s' % tmp_path:
            return (True, '', '')

    module = AnsibleModule()
    module.params['path'] = tmp_path
    module.params['unsafe_writes'] = False

    module.run_command = run_command
    module.fail_

# Generated at 2022-06-20 22:30:36.542618
# Unit test for function write_changes
def test_write_changes():
    module = FakeAnsibleModule(
        dict(
            path='/etc/hosts',
            regexp='\b(localhost)(\d*)\b',
            replace='\1\2.localdomain\2 \1\2',
            validate=None
        )
    )
    contents = '127.0.0.127\tlocalhost\n::1\tlocalhost\n'
    write_changes(module, contents, '/etc/hosts')
    # Currently just a stub until more functionality is added

# ===========================================
# Main control flow


# Generated at 2022-06-20 22:30:40.805654
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    m = module.check_file_attrs(module, False, "")
    assert(m[0] == "ownership, perms or SE linux context changed")
    assert(m[1])


# Generated at 2022-06-20 22:30:50.517764
# Unit test for function write_changes
def test_write_changes():
    ansible_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
        ),
    )
    ansible_module.atomic_move = lambda *args: None
    ansible_module.params = {'path': 'rofl'}
    ret = write_changes(
        ansible_module,
        to_bytes('hi'),
        'rofl',
    )
    assert ret is None



# Generated at 2022-06-20 22:31:02.423067
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec={
            'path': {'type': 'path', 'required': True},
            'validate': {},
            'unsafe_writes': {'type': 'bool', 'default': True, 'aliases': ['unsafe']}
        },
        supports_check_mode=True
    )

    module.tmpdir = tempfile.mkdtemp()

    # write test data to a file
    contents = to_bytes(u"# test\nfoo = bar\nbaz = qux\n")
    path = os.path.join(module.tmpdir, u'test.yml')
    validate = to_bytes(u"/bin/true")
    write_changes(module, contents, path)

    # use file module to check that the data was written
    module_args

# Generated at 2022-06-20 22:31:10.086347
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create a test module
    test = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'mode': {'type': 'str'},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    test.params['unsafe_writes'] = True
    test.params['owner'] = 'root'

# Generated at 2022-06-20 22:31:23.358979
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
      path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
      regexp=dict(type='str', required=True),
      replace=dict(type='str', default=''),
      after=dict(type='str'),
      before=dict(type='str'),
      backup=dict(type='bool', default=False),
      validate=dict(type='str'),
      encoding=dict(type='str', default='utf-8'),
    ),
    add_file_common_args=True,
    supports_check_mode=True,
  )

  module.params['path'] = '/etc/hosts'
  module.params['regexp'] = '^127\\.0\\.0\\.1'


# Generated at 2022-06-20 22:31:24.727185
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:33:33.158371
# Unit test for function main
def test_main():
    from ansible.modules.remote_management.network.nxos import cli
    from ansible.modules.remote_management.network.nxos import replace
    from ansible.module_utils.common.process import get_bin_path
    import os

    test_cases = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                              'unit_tests', 'test_cases.yaml')
    test_case = [x for x in parse_yaml_file(test_cases)['test_cases']
                 if x.get('id') == '_test_decode_and_encode'][0]
    module = DummyModule(**test_case.get('inputs')['replace'])
    nxos_replace = replace.NxosModule(module)


# Generated at 2022-06-20 22:33:39.529360
# Unit test for function write_changes
def test_write_changes():
    mock_module=AnsibleModule({}, supports_check_mode=False)
    mock_module._remote_tmp=tempfile.mkdtemp()
    file_name_path=os.path.join(mock_module._remote_tmp,'file_name')
    file_contents = b'bar\n'
    write_changes(
        mock_module,
        file_contents,
        file_name_path,
    )
    with open(file_name_path, 'r') as file_content:
        read_content = file_content.read()
        assert read_content == to_text(file_contents)


# Generated at 2022-06-20 22:33:51.422725
# Unit test for function main
def test_main():
    path = './test.txt'
    regexp = 'test'
    replace = 'fake'
    after = 'test'
    before = 'fake'
    backup = False
    validate = None
    encoding = 'utf-8'


# Generated at 2022-06-20 22:34:01.672331
# Unit test for function write_changes
def test_write_changes():
    tmpfd, testfile = tempfile.mkstemp()
    f = os.fdopen(tmpfd, 'wb')
    f.write(to_bytes("Hello world\n"))
    f.close()

    import shutil
    tmpdir = tempfile.mkdtemp()
    # Create a shallow copy of the module to fake the module args
    mod = AnsibleModule({
        'params': {
            'validate': None,
            'unsafe_writes': True,
            'backup': False
        },
        'tmpdir': tmpdir,
        '_ansible_tmpdir': tmpdir,
        'validate': None
    })
    for x in range(1,5):
        fnew = to_bytes("Hello world\n%d" % x)

# Generated at 2022-06-20 22:34:09.969594
# Unit test for function write_changes
def test_write_changes():
    import os
    import sys
    import base64
    from subprocess import Popen, PIPE, STDOUT

    # NOTE: this modules passes ansible arguments, it must be use with ansible-test
    # ansible-test units --python 3.5 -vvv -t test/units/modules/files/test_replace.py

    dirname, pathname = os.path.split(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(dirname)

    # load the test content
    f = open(pathname + '/test_replace.txt', 'r')
    input_content = f.read()
    f.close()

    f = open(pathname + '/test_replace_validate.sh', 'r')
    validate_script = f.read()
   

# Generated at 2022-06-20 22:34:15.179538
# Unit test for function write_changes
def test_write_changes():
    import shutil
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    tmpdir = tempfile.mkdtemp()
    test_filename = 'test_write_changes_file'
    path = tmpdir + '/' + test_filename
    f = open(path, 'w')
    f.close()

    contents = """line1
line2
line3
line4
line5
line6
line7
line8
line9
line10
"""

    # Test with valid contents
    m = AnsibleModule({'tmpdir': tmpdir, 'path': path, 'validate': None, 'unsafe_writes': True}, check_invalid_arguments=False)
    write_changes(m, contents, path)

    # Test with invalid contents

# Generated at 2022-06-20 22:34:24.718625
# Unit test for function write_changes
def test_write_changes():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params.update({
        'validate': None,
        'unsafe_writes': False
    })
    module_path = os.path.dirname(os.path.abspath(__file__))
    _module_path = module_path.replace('ansible/module_utils', 'ansible/modules')
    module.base_tmpdir = os.path.join(tempfile.gettempdir(), 'ansible-tmp-%s' % os.getpid())
    os.makedirs(module.base_tmpdir)

# Generated at 2022-06-20 22:34:34.125247
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(argument_spec=dict(path=dict(required=True, type='str'),
                      mode=dict(required=True, type='str'),
                      owner=dict(required=True, type='str'),
                      group=dict(required=True, type='str')),
                      check_invalid_arguments=False)
    setattr(m, 'check_mode', True)
    setattr(m, 'set_file_attributes_if_different',
            lambda args, changed: (True, 'changed'))
    ans, message = check_file_attrs(m, False, '')
    assert message == 'changed'
    ans, message = check_file_attrs(m, True, 'some message')
    assert message == 'some message and changed'
test_check_file_attrs()



# Generated at 2022-06-20 22:34:40.737340
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    module.tmpdir = '/tmp'
    module.atomic_move = AtomicMove
    module.run_command = RunCommand
    b = to_bytes('A\nB', errors='surrogate_then_replace')
    write_changes(module, b, to_bytes('/tmp/write_changes', errors='surrogate_then_replace'))
