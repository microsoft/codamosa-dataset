

# Generated at 2022-06-20 22:25:10.882661
# Unit test for function write_changes

# Generated at 2022-06-20 22:25:21.746602
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(required=True, type='path'),
            dest = dict(required=True, type='path'),
            mode = dict(default='0600', type='raw'),
            owner = dict(default='root', type='raw'),
            group = dict(default='root', type='raw'),
            unsafe_writes = dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    module.run_command = lambda *a, **kw: (0, '', '')
    module.exit_json = lambda **kw: None
    module.set_file_attributes_if_different = lambda a, b: True
    changed, message = False, ''


# Generated at 2022-06-20 22:25:27.875003
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule
    contents = "\n"
    path = "/tmp/test"
    write_changes(contents, path)
    assert os.path.exists(path)

# Generated at 2022-06-20 22:25:40.688062
# Unit test for function write_changes
def test_write_changes():
    module = mock_module()
    module.run_command = mock_run_command()
    module.check_mode = False
    module.atomic_move = mock_atomic_move()
    module.params = {'validate': 'validatecommand %s'}
    module.tmpdir = '/tmp/ansible'

    # Create the test file
    f = open('/tmp/ansible/testfile', 'w')
    f.write('One two three\nfour five six\n')
    f.close()

    # Create the test contents
    contents = 'one two three\nfour five six\n'

    # Test that validation fails when validatecommand exits on 1
    rc = 1
    write_changes(module, contents, '/tmp/ansible/testfile')

# Generated at 2022-06-20 22:25:49.630738
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

# Generated at 2022-06-20 22:25:58.588963
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    import os
    import tempfile
    global path
    global contents
    path = tempfile.mkstemp()[1]

# Generated at 2022-06-20 22:26:09.282149
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'_ansible_tmpdir': '/some/tmpdir', 'path': 'some_path', 'tmpdir': '/tmpdir'}
    module.tmpdir = '/tmpdir'
    changed = False
    message = 'test message'

    def _curr_file_attrs():
        return {'seuser': 'foo'}

    module.get_file_attributes = _curr_file_attrs

    # First test
    # Returns changed as True
    def _set_file_attrs_if_different(file_args, changed):
        return True

    module.set_file_attributes_if_different = _set_file_attrs_if_different
    message, changed = check_file_attrs(module, changed, message)

# Generated at 2022-06-20 22:26:15.689092
# Unit test for function main
def test_main():
    # Test object
    test_object = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    # Test code
    # Create a file if it does not exist.

# Generated at 2022-06-20 22:26:29.065338
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'mode': {'type': 'str', 'required': True},
                                          'path': {'type': 'str', 'aliases': ['dest', 'destfile'], 'required': True}})

    changed = True
    message = 'test'

    ret_msg, ret_changed = check_file_attrs(module, changed, message)
    assert ret_msg == 'test and ownership, perms or SE linux context changed'
    assert ret_changed == True

    ret_msg, ret_changed = check_file_attrs(module, False, message)
    assert ret_msg == 'test'
    assert ret_changed == False


# Generated at 2022-06-20 22:26:35.617121
# Unit test for function write_changes
def test_write_changes():

    # Arrange
    module_args = {}
    module_args['path'] = '/path/to/file'
    module_args['regexp'] = 'some_regex'
    module_args['unsafe_writes'] = False

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    
    # Act
    write_changes(module,'some test contents','tmpfile')
    # Assert
    assert os.path.exists('tmpfile')



# Generated at 2022-06-20 22:26:56.329288
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(argument_spec=dict(
        path=dict(type='str', required=True),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
    )
    )
    m.params.update(dict(
        path="test.txt",
        regexp="",
        replace="",
        owner="root",
        group="root",
        mode="644",
        seuser="system_u",
        serole="object_r",
        selevel="s0",
    ))
    assert type(check_file_attrs(m, True, "message")) == tuple
# /Unit test for function check_file_attrs



# Generated at 2022-06-20 22:27:07.771847
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
            'path': {'type': 'path', 'required': True},
            'regexp': {'type': 'str', 'required': True},
            'replace': {'type': 'str', 'default': ''},
            'after': {'type': 'str'},
            'before': {'type': 'str'},
            'backup': {'type': 'bool', 'default': False},
            'validate': {'type': 'str'},
            'encoding': {'type': 'str', 'default': 'utf-8'},
        })
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.atomic_move = MagicMock()
    module.fail_json = MagicMock()
    module.exit_

# Generated at 2022-06-20 22:27:17.281217
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.common.text.converters import to_bytes
    from .test_validate_contains import TestModule
    test_module = TestModule()
    test_module.params = {'unsafe_writes': False}
    test_module.params.update({'path': '/path/to/file/being/changed', 'changed': True, 'expand': False})
    test_module.params.update({'mode': '0644', 'owner': 'apache', 'group': 'root'})
    test_module.params.update({'contains': '12345'})
    test_module.params.update({'backup': False, 'follow': False})
    test_module.run_command = lambda x: (0, 'Changed file attributes', '')
    test_module.set_file_

# Generated at 2022-06-20 22:27:30.988998
# Unit test for function write_changes
def test_write_changes():
  data = b'''\xe2\x80\x9cfirst\xe2\x80\x9d\r\n\xe2\x80\x9csecond\xe2\x80\x9d\r\n\xe2\x80\x9cthird\xe2\x80\x9d'''
  module = AnsibleModule(argument_spec={'unsafe_writes': {'type': 'bool', 'default': True}})

  tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
  os.write(tmpfd, data)
  os.close(tmpfd)
  path = tmpfile + '.path'
  os.rename(tmpfile, path)
  module.params.update({'path': path})


# Generated at 2022-06-20 22:27:39.518302
# Unit test for function check_file_attrs
def test_check_file_attrs():
    contents = 'The quick brown fox jumps over the lazy dog.'


# Generated at 2022-06-20 22:27:48.191058
# Unit test for function write_changes
def test_write_changes():

    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        encoding=dict(type='str', default='utf-8'),
    ))


# Generated at 2022-06-20 22:27:55.574081
# Unit test for function main
def test_main():
    print("Starting")
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

# Generated at 2022-06-20 22:28:01.088682
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MockModule()
    changed = False
    message = ""
    result = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-20 22:28:13.547121
# Unit test for function main
def test_main():
    from ansible.modules.files import replace as mod
    import os
    import sys
    import tempfile
    import shutil
    import re
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible_collections

# Generated at 2022-06-20 22:28:22.102189
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.six.moves import StringIO
    module = DummyModule()
    tmp_fd, tmp_file = tempfile.mkstemp()
    os.close(tmp_fd)
    module.atomic_move = lambda tmpfile, path, unsafe_writes: True
    module.fail_json = lambda msg: 'fail'
    module.params['unsafe_writes'] = 'False'
    module.run_command = lambda validate: (0, '', '')
    rc = write_changes(module, 'original', tmp_file)
    assert rc == True
    rc = write_changes(module, 'original', tmp_file)
    assert rc == True
    os.unlink(tmp_file)


# Generated at 2022-06-20 22:28:56.365233
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.modules.files.file import FileModule
    assert check_file_attrs(FileModule(
        {'_ansible_module_name': 'file', '_ansible_check_mode': False,
         '_ansible_version': '2.8.0', '_ansible_no_log': False,
         'dest': '/root/test.txt', 'src': None,
         'state': 'present', 'Follow': None, 'mode': None, 'selevel': None,
         'serole': None, 'setype': None, 'seuser': None, 'unsafe_writes': None,
         'owner': 'root', 'group': 'wheel', 'mode': '0664'}),
         False, "ownership, perms or SE linux context changed")



# Generated at 2022-06-20 22:28:59.021526
# Unit test for function write_changes
def test_write_changes():
    tmpfile = tempfile.mkstemp(dir='/usr/tmp')
    path = tmpfile[1]
    content = ''
    write_changes(path, content)
    with open(path, "r") as file:
        new_content = file.read()
    assert content == new_content


# Generated at 2022-06-20 22:29:13.060478
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-20 22:29:25.081551
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    Test: check_file_attrs
    Given:
        - a module
        - initial changed status (False)
        - initial message ("")
    When:
        - file attributes change
        - original changed was False
    Then:
        - message contains string "ownership, perms or SE linux context changed"
        - changed is True
    """
    import sys
    import io
    import unittest
    import mock

    ansible_module = mock.Mock()

    ansible_module.load_file_common_arguments.return_value = mock.Mock()

    ansible_module.set_file_attributes_if_different.return_value = True

    oc = False
    message = ""
    result = check_file_attrs(ansible_module, oc, message)

    assert result

# Generated at 2022-06-20 22:29:32.538537
# Unit test for function check_file_attrs
def test_check_file_attrs():
    fargs = dict(path='/path/to/my/file', owner='root', group='wheel', mode=0o0777)
    from ansible.module_utils.six import PY3
    if not PY3:
        from ansible.module_utils import basic
        from ansible.module_utils.common._collections_compat import Mapping
        m = Mapping()
        for k, v in fargs.items():
            m[k] = v
        setattr(basic, 'AnsibleModule', type('FakeAnsibleModule', (), dict(
            params=m,
            fail_json=lambda this, msg: msg,
            load_file_common_arguments=lambda this: fargs,
            set_file_attributes_if_different=lambda this, arg, arg2: True,
        )))

# Generated at 2022-06-20 22:29:37.533704
# Unit test for function main
def test_main():
    create_file('tests/files/test', 'foo')
    with open('tests/files/test', 'r', encoding='utf-8') as f:
        contents = f.read()
    assert contents == 'foo'
    os.remove('tests/files/test')

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:29:47.751577
# Unit test for function main
def test_main():
    module_args = {
        "path": "/home/test",
        "regexp": "test",
        "replace": "test",
        "after": "test",
        "before": "test",
        "backup": "True",
        "validate": "test",
        "encoding": "test"
    }
    result = dict(
        msg="test",
        changed="test"
    )
    print(result['msg'])

# Generated at 2022-06-20 22:29:58.068939
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'test_param': 'test'})
    module.params = {}

    file_args = {'path': '/test/path'}
    module.set_file_attributes_if_different = MagicMock()
    module.set_file_attributes_if_different.return_value = False

    message = "some message"
    changed = False
    result = check_file_attrs(module, changed, message)
    assert result == (message, changed)

    changed = True
    result = check_file_attrs(module, changed, message)
    assert result == ("some message and ownership, perms or SE linux context changed", changed)



# Generated at 2022-06-20 22:30:03.423437
# Unit test for function write_changes
def test_write_changes():
    """
    Replace all instances of a particular string in a
    file using a back-referenced regular expression
    """

    contents = """
    # This is a changing file
    # This is a changing file
    # This is a changing file
    """
    return contents.replace('changing', 'replaced')


# Generated at 2022-06-20 22:30:04.720811
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:31:01.572201
# Unit test for function main
def test_main():
    # open_mock = mock.mock_open()
    # open_mock.return_value.__iter__ = lambda self: self
    # open_mock.return_value.__next__ = lambda self: next(iter(self.value))
    # with mock.patch('io.open', open_mock):
    #     main()
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:31:09.700854
# Unit test for function write_changes
def test_write_changes():
    print("Unit test for write_changes")
    module = AnsibleModule(
        argument_spec=dict(
            backup=dict(default=False, type='bool'),
            content=dict(no_log=True),
            # defaults changed in Ansible 2.3
            dest=dict(type='path', aliases=['name', 'destfile']),
            path=dict(),
            regexp=dict(required=True),
            replace=dict(),
            after=dict(),
            before=dict(),
            unsafe_writes=dict(default=False, type='bool', aliases=['unsafe']),
            validate=dict()
        )
    )

    tmpdir = tempfile.mkdtemp()
    module.atomic_move = lambda src, dest, unsafe: os.rename(src, dest)
    module.params['tmpdir']

# Generated at 2022-06-20 22:31:19.077374
# Unit test for function write_changes
def test_write_changes():
  module = AnsibleModule()
  tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
  f = os.fdopen(tmpfd, 'wb')
  f.write('hello world')
  f.close()
  path = '/tmp/a'
  module.atomic_move(tmpfile, path, unsafe_writes=module.params['unsafe_writes'])
  if 'hello world' not in open(path).read():
    raise AssertionError()



# Generated at 2022-06-20 22:31:30.268575
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(
        path=dict(required=True, type='path'),
        regexp=dict(required=True, type='str'),
        replace=dict(type='str'),
        backup=dict(type='bool', default=False),
        after=dict(type='str'),
        before=dict(type='str'),
        follow=dict(type='bool', removed_in_version='2.5'),
        unsafe_writes=dict(type='bool', default=True),
        encoding=dict(type='str', default='utf-8'),
    ))

    changed = False
    message = ""
    checked_message, checked_changed = check_file_attrs(module, changed, message)

    assert changed == checked_changed
    assert message == checked_message


# Generated at 2022-06-20 22:31:37.008165
# Unit test for function main
def test_main():
  context = AnsibleRunner(
      '.%s/test_runner' % os.path.dirname(os.path.realpath(__file__))
  ).get_context()
 
  result = AnsibleRunner(
      '.%s/test_runner' % os.path.dirname(os.path.realpath(__file__))
  ).run(main, context)

  # Ensure no diff was made
  #assert result['diff']['before'] == result['diff']['after'], 'no diff was expected'
 
  # Ensure no backup file was made
  assert result['backup_file'] == '', 'no backup file was expected'
 
  # Ensure no change was made
  assert result['changed'] == False, 'no change was expected'
 
  # Ensure path was changed

# Generated at 2022-06-20 22:31:45.461586
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.pycompat24 import get_exception
    import os
    import tempfile

    # Manually create a test file
    tmpfd, path = tempfile.mkstemp(dir='/tmp')
    os.close(tmpfd)
    testfile = open(path, 'wb')
    testfile.write(to_bytes('# Ansible managed:\n'))
    testfile.write(to_bytes('old.host.name\n'))
    testfile.close()

    # Create the module object
    api = basic.Ansible

# Generated at 2022-06-20 22:31:46.398082
# Unit test for function main
def test_main():
    assert True is True

# Generated at 2022-06-20 22:31:53.743943
# Unit test for function write_changes
def test_write_changes():
    # Test not OS specific - we just need to validate the file has been written correctly
    # and no exception has been raised
    module = AnsibleModule({'tmpdir': 'temp_tests'})
    path = 'temp_tests/test.tmp'
    open(path, 'w').close()
    contents = b'this is a test'
    write_changes(module, contents, path)
    with open(path) as f:
        assert f.read() == 'this is a test'



# Generated at 2022-06-20 22:31:59.385968
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:32:04.586358
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            owner=dict(required=False, type='str'),
            group=dict(required=False, type='str'),
            mode=dict(required=False, type='str'),
            seuser=dict(required=False, type='str'),
            serole=dict(required=False, type='str'),
            selevel=dict(required=False, type='str'),
            setype=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, default=False, type='bool'),
        ),
    )

# Generated at 2022-06-20 22:34:22.094817
# Unit test for function write_changes
def test_write_changes():
    import io
    import pytest
    from ansible.module_utils._text import to_bytes, to_text

    class Modules(object):
        def __init__(self, module_name, params, tmpdir):
            self.params = params
            self.module_name = module_name
            self.tmpdir = tmpdir

        class _io(object):
            class _io(object):
                class _io(object):
                    class _io(object):
                        class _io(object):
                            def __init__(self, stdout):
                                self.stdout = stdout

                    class check_output(object):
                        def __init__(self, stdout):
                            self._io(stdout)


# Generated at 2022-06-20 22:34:23.701203
# Unit test for function check_file_attrs
def test_check_file_attrs():
    return check_file_attrs(module, True, "message")



# Generated at 2022-06-20 22:34:33.423399
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Unit test setup
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
        )
    )
    test_path = module.params['path']
    message = "message"
    changed = False

    # Common return for this test
    return_value = (message, changed)

    try:
        # Notify if file is changed
        module.set_file_attributes_if_different = lambda *args,**kwargs: True
        message += " and ownership, perms or SE linux context changed"
        changed = True
    except:
        pass

    try:
        # Do not notify if file is not changed
        module.set_file_attributes_if_different = lambda *args,**kwargs: False
    except:
        pass


# Generated at 2022-06-20 22:34:39.923251
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
        )
    )

    # Test writing file
    contents = b"#This is a test"
    path = module.params['path']
    tmpfile = write_changes(module, contents, path)

    # Test reading file
    file = open(path, 'rb')
    assert file.read() == contents

    # Test cleanup
    os.remove(path)


# Generated at 2022-06-20 22:34:49.586432
# Unit test for function write_changes
def test_write_changes():
    failed = False
    try:
        x=write_changes
    except NameError:
        failed = True
    assert not failed, 'Function write_changes does not exist'

test_write_changes()

# import module snippets
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_text, to_bytes
from ansible.module_utils.common.dict_transformations import dict_merge
from ansible.module_utils.parsing.convert_bool import BOOLEANS
from ansible.module_utils.six.moves.urllib.parse import urlsplit
from ansible.module_utils.six import iteritems
from ansible.module_utils.six.moves import shlex_quote
from ansible.module_utils.urls import fetch_url