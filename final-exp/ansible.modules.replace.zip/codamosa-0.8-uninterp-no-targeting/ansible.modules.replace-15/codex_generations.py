

# Generated at 2022-06-20 22:25:01.916243
# Unit test for function write_changes
def test_write_changes():
    """Unit test function to mock the write_changes function

    @param module: ansible module_args with basic parameters
    @param contents: file contents
    @param path: path to the file
    """


# Generated at 2022-06-20 22:25:12.591365
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='str', required=True, aliases=['name', 'dest', 'destfile']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        before=dict(type='str'),
        after=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
        validate=dict(type='str'),
        unsafe_writes=dict(type='bool', default=False),
    ))

    text = b'old text\nnew text\n'
    regexp = b'.*'
    replace = b'replaced text'

    tmpfd, tmpfile = tempfile.mkstemp(dir=tempfile.gettempdir())
    f = os.fd

# Generated at 2022-06-20 22:25:23.667512
# Unit test for function write_changes
def test_write_changes():
    result = {}
    result['path'] = 'test_file'
    result['content'] = 'test_content'
    class TestModule:
        def __init__(self, result):
            self.params = {}
            self.params['unsafe_writes'] = True
            self.tmpdir = ''
            self.result = result
            self.fail_json = False
            self.methods = {'atomic_move': atomic_move}

        def run_command(self, path):
            return (0, '', '')

        def atomic_move(self, tmpfile, path, unsafe_writes):
            try:
                f = open(result['path'], 'w')
                f.write(result['content'])
                f.close()
            except Exception as e:
                print(format_exc())
               

# Generated at 2022-06-20 22:25:34.165223
# Unit test for function main
def test_main():
  path = "test-path"

# Generated at 2022-06-20 22:25:42.462190
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(
        argument_spec=dict(
            validate=dict(type='str', required=False),
            contents=dict(type='str', required=True),
            path=dict(type='str', required=True),
        ),
        supports_check_mode=True,
    )
    m.run_command = lambda x: (0, '', '')
    m.tmpdir = '.'
    m.atomic_move = lambda src, dest: None
    write_changes(m, b'contents', 'path')



# Generated at 2022-06-20 22:25:55.185739
# Unit test for function write_changes
def test_write_changes():
    contents = b'foo'
    path = '/tmp/test_write_changes'
    module = AnsibleModule(argument_spec={
                                          'path': {'required': True, 'type': 'str'},
                                          'unsafe_writes': {'default': True, 'type': 'bool'},
                                          }, supports_check_mode=True)
    f = open(path, 'wb')
    f.write(contents)
    f.close()
    # Check initial state is as expected
    assert (open(path, 'rb').read() == contents)
    new_contents = contents + b'bar'
    write_changes(module, new_contents, path)
    assert (open(path, 'rb').read() == new_contents)
    os.remove(path)


# Generated at 2022-06-20 22:25:57.728338
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed, message = check_file_attrs(module, False, '')
    assert message == ''
    assert changed == False



# Generated at 2022-06-20 22:26:03.861545
# Unit test for function main

# Generated at 2022-06-20 22:26:13.044664
# Unit test for function check_file_attrs
def test_check_file_attrs():

    m_module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(required=True),
            replace=dict()
        )
    )

    m_module.params['owner'] = 'root'
    m_module.params['group'] = 'root'
    m_module.params['mode'] = '0644'
    m_module.set_file_attributes_if_different = MagicMock(return_value=True)

    changed = False
    message, changed = check_file_attrs(m_module, changed, 'changed')

    assert message == 'changed and ownership, perms or SE linux context changed'
    assert changed is True



# Generated at 2022-06-20 22:26:18.799483
# Unit test for function write_changes
def test_write_changes():
  contents_path = "/tmp/test_write_changes"
  contents = "Hello world!\n"
  path = "/tmp/test_write_changes_file"
  with open(path, 'w') as f:
    f.write(contents)
  

# Generated at 2022-06-20 22:26:41.525218
# Unit test for function write_changes
def test_write_changes():
    import json
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule
    tmpfd, tmpfile = tempfile.mkstemp(dir=tempfile.gettempdir())
    os.close(tmpfd)
    if os.path.isfile(tmpfile):
        os.remove(tmpfile)
    content = b'This is the new content'
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str'),
            contents = dict(required=True, type='str'),
            validate = dict(required=True, type='str'),
            unsafe_writes = dict(required=True, type='str')
        )
    )
    # Test with valid validate

# Generated at 2022-06-20 22:26:44.639423
# Unit test for function main
def test_main():
    res_args = {}
    res_args = module.exit_json(**res_args)
    return(res_args)


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:56.288033
# Unit test for function check_file_attrs
def test_check_file_attrs():
    changed = False
    message = "some message"

# Generated at 2022-06-20 22:27:06.838021
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:27:16.630511
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        "path": "/etc/passwd",
        "validate": "grep -q '^root' %s",
        "backup": "yes",
    })
    module.tmpdir = tempfile.mkdtemp()

    try:
        write_changes(module, b"root:x:0:0:root:/root:/bin/bash", "/etc/passwd")
        assert False, "should fail due to validate"
    except SystemExit:
        pass

    # sucessfull write
    write_changes(module, b"root:x:0:0:root:/root:/bin/bash\nnewuser:x:100:100:newuser:/home/newuser:/bin/bash", "/etc/passwd")

# Generated at 2022-06-20 22:27:22.368587
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import os
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible_collections.ansible.builtin.plugins.module_utils.replace import check_file_attrs
    from unittest import TestCase

    attrs = dict(
        path='/a/b',
        owner='nobody',
        group='nogroup',
        mode='0777',
        seuser='system_u',
        serole='system_r',
        selevel='s0',
        setype='etc_t',
    )

    class MockExit(Exception):
        def __init__(self, msg):
            self.msg = msg


# Generated at 2022-06-20 22:27:32.539633
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())
    message = ''
    changed = True
    params = dict(
        path='/test/path',
        owner='test_owner',
        group='test_group',
        mode='0644',
        seuser='test_seuser',
        serole='test_serole',
        setype='test_setype',
        selevel='test_selevel',
    )
    module.params = params
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-20 22:27:36.561584
# Unit test for function write_changes
def test_write_changes():
    assert write_changes(module, contents, path)


# Generated at 2022-06-20 22:27:37.166862
# Unit test for function write_changes
def test_write_changes():
    assert True


# Generated at 2022-06-20 22:27:38.986230
# Unit test for function main
def test_main():
    #print("Testing function main")
    main()
    #print("End testing function main")


# Generated at 2022-06-20 22:28:06.596905
# Unit test for function main
def test_main():
    import sys,os
    from ansible.module_utils import basic

    # prepend (MOCK) ansible.module_utils directory to module search path
    module_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    if module_dir not in sys.path:
        sys.path.insert(1, module_dir)


# Generated at 2022-06-20 22:28:16.831749
# Unit test for function main
def test_main():
    # Test with required param 'path' alone
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    with open('/etc/ansible/ansible.cfg', 'rb') as f:
        contents = to_text(f.read(), 'utf-8')
        result = (contents, 0)


# Generated at 2022-06-20 22:28:18.896941
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, True, "Test") == ("Test and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:28:23.312012
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, False, "file changed")


# Generated at 2022-06-20 22:28:31.687696
# Unit test for function write_changes
def test_write_changes():
    mock_module = AnsibleModule({'argument_spec': {'backup': {'type': 'bool', 'default': False}}})
    mock_module.atomic_move = lambda source, target: source
    mock_module.run_command = lambda *args, **kwargs: (True, 'out', '')
    mock_module.fail_json = lambda *args, **kwargs: None
    contents = 'Some contents'
    path = '/some/path'
    write_changes(mock_module, contents, path)



# Generated at 2022-06-20 22:28:39.687466
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # No change
    module = AnsibleModule({
        "path": "/usr/bin/yum",
        "seuser": "system_u",
        "serole": "object_r",
        "setype": "bin_t",
        "setype": "bin_t",
        "selevel": "s0",
        "owner": "root",
        "group": "root",
        "mode": "0755",
    })
    changed, message = check_file_attrs(module, False, "")
    assert not changed
    assert message == ""


# Generated at 2022-06-20 22:28:51.916258
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp = dict(type='str', required=True),
            replace = dict(type='str', default=''),
            after = dict(type='str'),
            before = dict(type='str'),
            backup = dict(type='bool', default=False),
            validate = dict(type='str'),
            encoding = dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    assert check_file_attrs(module, True, 'test message') == ('test message and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-20 22:29:02.061853
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:29:02.714324
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-20 22:29:14.607292
# Unit test for function main
def test_main():
    res_args = {
        'msg': "",
        'changed': False
    }
    module = AnsibleModule(argument_spec=dict(path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']), regexp=dict(type='str', required=True), replace=dict(type='str', default=''), after=dict(type='str'), before=dict(type='str'), backup=dict(type='bool', default=False), validate=dict(type='str'), encoding=dict(type='str', default='utf-8')), add_file_common_args=True, supports_check_mode=True,)
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

# Generated at 2022-06-20 22:29:46.596214
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule

    test_dict = dict(
        path = '/etc/hosts',
        regexp = '(\s+)old\.host\.name(\s+.*)?$',
        replace = '\\1new.host.name\\2',
    )
    module = AnsibleModule(argument_spec=test_dict)
    main()

# Generated at 2022-06-20 22:29:48.850139
# Unit test for function main
def test_main():
    from ansible.modules.extras.cloud.oracle.oci_os_instance import main

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:29:59.954205
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(unsafe_writes=dict(type='bool', default=False)))
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    os.close(tmpfd)
    module.atomic_move = lambda tmpfile, dest, unsafe_writes=False: None
    contents = to_bytes("test content")
    try:
        write_changes(module, contents, tmpfile)
    except SystemExit as e:
        if e.code != 0:
            raise SystemExit(format_exc())
        else:
            try:
                with open(tmpfile, 'rb') as f:
                    if f.read() != contents:
                        raise SystemExit("write_changes failed to write contents to file")
            finally:
                os.remove(tmpfile)


# Generated at 2022-06-20 22:30:08.386823
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()
# Test function

# Generated at 2022-06-20 22:30:12.258767
# Unit test for function write_changes

# Generated at 2022-06-20 22:30:12.792810
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-20 22:30:13.321643
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-20 22:30:19.332853
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create module object with default args
    set_module_args()
    module = AnsibleModule(
        argument_spec=dict(
            regexp=dict(required=True),
            backup=dict(default=False, type='bool'),
            unsafe_writes=dict(default=True, type='bool'),
            validate=dict(),
            # added in 2.4
            encoding=dict(default='utf-8', type='str'),
        ),
        supports_check_mode=True
    )
    # Set file_args with common file arguments
    file_args = module.load_file_common_arguments(module.params)
    # Set mocks
    module.run_command = mock_run_command
    module.atomic_move = mock_atomic_move
    module.set_file_attributes_if_different = mock

# Generated at 2022-06-20 22:30:29.402422
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            dest=dict(type='path', required=True),
            follow=dict(type='bool', default=False),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        )
    )


# Generated at 2022-06-20 22:30:41.750346
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    # This is the return value from the function
    res_args = {}      # function output
    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module._ansible_no_log = True
    

# Generated at 2022-06-20 22:31:43.925223
# Unit test for function main
def test_main():
    testpath = '/path/to/file'
    testregex = '(\s+)old\.host\.name(\s+.*)?$'
    testreplace = '\1new.host.name\2'
    testbackup = False
    testvalidate = None

    test_args = {
        'path': testpath,
        'regexp': testregex,
        'replace': testreplace,
        'backup': testbackup,
        'validate': testvalidate
    }

    with pytest.raises(AnsibleExitJson) as excinfo:
        main()
    assert excinfo.value.args[0]['changed'] is False


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:31:46.050289
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(1, 2, 3) == (3, 2)



# Generated at 2022-06-20 22:31:56.385409
# Unit test for function write_changes
def test_write_changes():
    import datetime
    import time
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    import traceback
    # set up the module
    argv = ['fake_path', 'fake_regex', 'fake_replace', 'fake_dest']

# Generated at 2022-06-20 22:32:01.900741
# Unit test for function write_changes
def test_write_changes():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode = True)

    (tmpfd, tmpfile) = tempfile.mkstemp(dir=module.tmpdir)
    os.close(tmpfd)
    try:
        f = open(tmpfile,"wb")
        f.write(b"Incoming")
        f.close()

        test_string = to_bytes("Outgoing")
        write_changes(module, test_string, tmpfile)
        f = open(tmpfile,"rb")
        result_string = f.read()
        f.close()
        assert result_string == test_string
    finally:
        # Remove the temporary test file
        os.remove(tmpfile)


# Generated at 2022-06-20 22:32:13.253688
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.main()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:32:22.957984
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True, aliases=['dest', 'destfile']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False, default=False),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True
    )


# Generated at 2022-06-20 22:32:30.206639
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "path": {"type": "path", "required": True, "aliases": ["dest", "destfile", "name"]},
        "regexp": {"type": "str", "required": True},
        "replace": {"type": "str", "default": ""},
        "after": {"type": "str"},
        "before": {"type": "str"},
        "backup": {"type": "bool", "default": False},
        "validate": {"type": "str"},
        "encoding": {"type": "str", "default": "utf-8"}})
    test_module.set_ansible_module_kwargs()
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.atomic_move = MagicM

# Generated at 2022-06-20 22:32:37.991439
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import ansible.module_utils.ansible_modlib.basic

# Generated at 2022-06-20 22:32:41.600571
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule
    class MockModule(object):
        def atomic_move(self, path1, path2, unsafe_writes=False):
            pass
        def fail_json(self, msg=''):
            pass
        def run_command(self, cmd=''):
            pass
        def load_file_common_arguments(self,params):
            return dict()
        def set_file_attributes_if_different(self, file_args, changed):
            return True
    module = MockModule()
    assert True == check_file_attrs(module, False, "")[1]



# Generated at 2022-06-20 22:32:51.017736
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = {
            'seuser': {'type': 'str', 'default': 'system_u:object_r:admin_home_t:s0'},
            'serole': {'type': 'str'},
            'setype': {'type': 'str'},
            'selevel': {'type': 'str'},
            'owner': {'type': 'str'},
            'group': {'type': 'str'},
            'mode': {'type': 'str', 'default': None}
        }
    )

    file_args = module.load_file_common_arguments(module.params)
    assert file_args['seuser'] == 'system_u:object_r:admin_home_t:s0'