

# Generated at 2022-06-20 22:24:59.352456
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-20 22:25:03.970014
# Unit test for function main
def test_main():
    from ansible.modules.files.replace import main
    import tempfile
    import filecmp
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes
    import shutil
    import os
    import pytest
    import sys
    import pexpect
    import re
    if not os.path.exists("/usr/bin/python2"):
        pytest.skip("No python2 on this system. Skipping")
    # This is set to python2 but needs to be python2 for this test
    pexpect.spawn.DEFAULT_INTERPRETER = "/usr/bin/python2"


# Generated at 2022-06-20 22:25:14.610563
# Unit test for function write_changes
def test_write_changes():
  module = mock_modules.MockModule({
    'validate': None,
    'atomic_move': mocked_atomic_move,
    'run_command': mocked_run_command,
    'fail_json': mocked_fail_json,
    'tmpdir': '',
    'params': {'unsafe_writes': True},
  })

  stream = "sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf"
  write_changes(module, stream, "foo")
  assert mocked_run_command.called == False
  assert mocked_fail_json.called == False
  assert mocked_atomic_move.called == True
  args, kwargs = mocked_atomic_move.call_args
  assert args[0] == stream

# Generated at 2022-06-20 22:25:22.361769
# Unit test for function main
def test_main():
    ansible_stub = {
        'backup': False,
        'check_mode': True,
        'encoding': 'utf-8',
        'dest': '/etc/hosts',
        'follow': None,
        'before': '',
        'path': '/etc/hosts',
        'regexp': '(\\s+)old\\.host\\.name(\\s+.*)?$',
        'replace': '\\1new.host.name\\2',
        'validate': None,
        'after': ''
    }
    module = AnsibleModule(ansible_stub)
    assert main() == None

# Generated at 2022-06-20 22:25:33.594552
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeModule(object):
        pass
    module = FakeModule()
    module.tmpdir = tempfile.mkdtemp()
    module.params = {
        "path": module.tmpdir,
        "owner": "jane",
        "group": "jane",
        "mode": "0770",
        "unsafe_writes": False
    }
    module.atomic_move = lambda a, b, unsafe_writes=None: True
    module.load_file_common_arguments = lambda params: params
    module.set_file_attributes_if_different = lambda args, changed: True
    module.fail_json = lambda **kwargs: kwargs
    module.fail_json.exception = None
    message, changed = check_file_attrs(module, False, '')

# Generated at 2022-06-20 22:25:38.339154
# Unit test for function write_changes
def test_write_changes():
    # Unit test to test module without AnsibleModule.
    write_changes(None,to_bytes('test','utf-8'),"/tmp/test.txt")
    assert(open("/tmp/test.txt").read()=='test')
    os.remove("/tmp/test.txt")



# Generated at 2022-06-20 22:25:48.256798
# Unit test for function main
def test_main():
	module = AnsibleModule(
		argument_spec=dict(
			path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
			regexp=dict(type='str', required=True),
			replace=dict(type='str', default=''),
			after=dict(type='str'),
			before=dict(type='str'),
			backup=dict(type='bool', default=False),
			validate=dict(type='str'),
			encoding=dict(type='str', default='utf-8'),
		),
		add_file_common_args=True,
		supports_check_mode=True,
	)

	path = './somefile'
	contents=''

# Generated at 2022-06-20 22:25:57.117026
# Unit test for function main
def test_main():
    import tempfile
    import ansible.module_utils.basic

    test_file_name = "test_file"
    file_contents = """
# This is a test file used by unit tests
    [defaults]
    pager=less
inventory      = /etc/ansible/hosts
log_path=/var/log/ansible.log
    """

    with open(test_file_name, "w") as test_file:
        test_file.write(file_contents)

    ansible.module_utils.basic._ANSIBLE_ARGS = [
        'test',
        '-vvvvv',
        '--ignore-plugins',
        'to_nice_json',
        '--runner-connection-plugin',
        'local',
        '-i',
        test_file_name,
        ]

# Generated at 2022-06-20 22:26:08.179976
# Unit test for function main
def test_main():
    class module:
        class args:
            path = None
            encoding = "utf-8"
            regexp = None
            replace = None
            after = None
            before = None
            backup = False
            validate = None
        class params:
            path = None
            encoding = "utf-8"
            regexp = None
            replace = None
            after = None
            before = None
            backup = False
            validate = None

# Generated at 2022-06-20 22:26:10.061913
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    assert write_changes(module, None, None) == None



# Generated at 2022-06-20 22:26:32.176693
# Unit test for function write_changes
def test_write_changes():
    class test_write_changes_module:
        # pylint: disable=too-few-public-methods
        def __init__(self, params, tmpdir):
            self.params = params
            self.tmpdir = tmpdir

        def fail_json(self, msg):
            raise AssertionError("Fail: %s" % msg)

        def run_command(self, cmd):
            raise AssertionError("Unexpected call to run_command: %s" % cmd)

        def atomic_move(self, src, dest, unsafe_writes):
            if unsafe_writes:
                raise AssertionError("Unexpected call with unsafe_writes")

            if src != "mytmpfile":
                raise AssertionError("Unexpected src path: %s" % src)


# Generated at 2022-06-20 22:26:34.696393
# Unit test for function check_file_attrs
def test_check_file_attrs():
    file_args = module.load_file_common_arguments(module.params)
    message = ""
    assert check_file_attrs(file_args) == message


# Generated at 2022-06-20 22:26:44.162101
# Unit test for function main
def test_main():
    from ansible.utils.path import unfrackpath
    import ansible.utils.template as template

    test_file = '%s/%s' % (unfrackpath('${TMP}', False), 'test_file_replace')
    with open(test_file, 'w') as f:
        f.write('replace_me\nreplace_me\nreplace_me\nreplace_me\n')
    test_replacement = 'replaced'
    regexp_multi='(\breplace_me\b)'
    regexp_simple='(\breplace_me\b\n)'
    regexp_with_escape='(\btest_file_replace\b\n)'
    replacement_with_groups='\\1\n\\2\n\\3\n\\4\n'

# Generated at 2022-06-20 22:26:50.398746
# Unit test for function main
def test_main():
    import os
    import io
    import tempfile
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:27:00.457336
# Unit test for function main
def test_main():

    class TestModule(object):
        def __init__(self):
            self.params = dict(
                path='/path/to/file',
                regexp='(\\s+)old\\.host\\.name(\\s+.*)?$',
                replace='\\1new.host.name\\2',
                after='',
                before='',
                backup=False,
                validate='',
                encoding='utf-8',
            )
            self.check_mode = False
            self.tmpdir = ''
            self.atomic_move = lambda x1,x2,x3: False
            self.run_command = lambda x: (0, '', '')
            self.set_file_attributes_if_different = lambda x1,x2: False
            self.fail_json = lambda x, **kwargs: False


# Generated at 2022-06-20 22:27:08.449854
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # This module is not a standalone module and it does not produce any log
    # So, we can not use module_utils.basic.AnsibleModule with fail_json
    module = AnsibleModule({'path': '/test', 'dest': '/test', 'mode': '0700'})
    changed, message = check_file_attrs(module, False, "")
    assert changed is True and message == "ownership, perms or SE linux context changed"
    return



# Generated at 2022-06-20 22:27:17.779388
# Unit test for function write_changes
def test_write_changes():
    import pytest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Python 2 and 3 use different methods for capturing stdout output
    stdout_module = PY3 and 'io' or 'StringIO'

    class AtomicMock(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.moved = False

        def atomic_move(self, tmpfile, dest, unsafe_writes):
            assert self.tmpdir == dest
            assert open(tmpfile, 'rb').read() == to_bytes('changed text')
            self.moved = True

    # We

# Generated at 2022-06-20 22:27:19.952201
# Unit test for function write_changes
def test_write_changes():
    '''
    Unit test for function write_changes
    '''
    assert False



# Generated at 2022-06-20 22:27:33.572559
# Unit test for function main
def test_main():
    args = {
        'path': {
            'type': 'path',
            'required': True,
            'aliases': ['dest', 'destfile', 'name']
        },
        'regexp': {
            'type': 'str',
            'required': True
        },
        'replace': {
            'type': 'str',
            'default': ''
        },
        'after': {
            'type': 'str'
        },
        'before': {
            'type': 'str'
        },
        'backup': {
            'type': 'bool',
            'default': False
        },
        'validate': {
            'type': 'str'
        },
        'encoding': {
            'type': 'str',
            'default': 'utf-8'
        }
    }

# Generated at 2022-06-20 22:27:36.726995
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs() == "hello and world"


# Generated at 2022-06-20 22:27:59.566204
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:28:11.488310
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict()
            self.tmpdir = "/tmp"
        def fail_json(self, msg):
            return msg
        def run_command(self, validate):
            rc = 0
            out = "0"
            err = None
            return (rc, out, err)
        def atomic_move(self, tmpfile, path, unsafe_writes):
            return True
        def load_file_common_arguments(self, params):
            file_args = dict(
                force=params.get('force', False),
                follow=params.get('follow', False),
                path=params.get('path', False),
                state=params.get('state', 'file'),
            )
            file_args['path'] = params.get

# Generated at 2022-06-20 22:28:21.621381
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    tempdir = tempfile.mkdtemp()
    srcf = os.path.join(tempdir, 'src')
    with open(srcf, 'w') as fd:
        fd.write("""
before
text1
text2
after
""")

# Generated at 2022-06-20 22:28:27.560240
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': "/home/user/file-to-write-to.txt", 'unsafe_writes': True})
    write_changes(module, b"Hello World.", b"/home/user/file-to-write-to.txt")
    f = open("/home/user/file-to-write-to.txt", 'rb')
    assert f.read() == b"Hello World."
    os.remove("/home/user/file-to-write-to.txt")


# Generated at 2022-06-20 22:28:37.940323
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    import ansible.module_utils.basic
    class MockModule(object):
        def __init__(self, module):
            self.params = {'unsafe_writes': module.params['unsafe_writes']}
    module = ansible.module_utils.basic.AnsibleModule({})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe: False
    module.run_command = lambda command, check_rc=None, close_fds=True: (1, '', '')
    module.fail_json = lambda **kwargs: None
    module.params = {'unsafe_writes': False}
    write_changes(MockModule(module), 'test', 'test')


# Generated at 2022-06-20 22:28:39.599875
# Unit test for function main
def test_main():
    print("Testing main()")
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:28:51.344310
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule([{"src": "foo"}, {"dst": "/usr/local/bin/foo"}], 'foo')
    module.fail_json = lambda self, rc, msg: None
    module.run_command = lambda self, cmd: (0, '', '')

    attributes = dict(
        path = "/usr/local/bin/foo",
        owner = "root",
        group = "root",
        mode = "0755",
    )
    module.params = attributes
    msg, changed = check_file_attrs(module, False, "")
    assert msg != ""
    assert changed == True

    module.params = attributes
    msg, changed = check_file_attrs(module, True, "")
    assert msg != ""
    assert changed == True




# Generated at 2022-06-20 22:29:01.342940
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    old_module_params = module.params
    old_module_args = module.params
    old_check_mode = module.check_mode

# Generated at 2022-06-20 22:29:05.087738
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({
        "path": "/tmp/test_file",
        "owner": "root",
        "group": "root",
        "mode": "0660",
    })
    changed = False
    message = "TEST_MESSAGE"
    ret_message, ret_changed = check_file_attrs(test_module, changed, message)
    assert ret_message == message + " and ownership, perms or SE linux context changed"
    assert ret_changed is True



# Generated at 2022-06-20 22:29:05.852849
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True



# Generated at 2022-06-20 22:30:01.087785
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})

    # Catch the failure if it is returned by the function
    try:
        write_changes(module, "Test file", "/path/to/nowhere")
    except SystemExit as e:
        if e.args[0] == 1:
            # Expected failure
            pass
        else:
            raise
    except:
        raise
    else:
        raise

    # Create a temporary file to use as a test
    tmpfd, tmpfile = tempfile.mkstemp()

    # Write "Test file" to the temporary file
    f = os.fdopen(tmpfd, 'wb')
    f.write("Test file")
    f.close()

    # If no validation is required, the output should be written to the temporary file
    write_changes(module, "New test file", tmpfile)


# Generated at 2022-06-20 22:30:05.245314
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec = dict(),
    )
    check_file_attrs(module, False, "Original message")
    check_file_attrs(module, True, "Original message")
    check_file_attrs(module, None, "Original message")



# Generated at 2022-06-20 22:30:13.089042
# Unit test for function write_changes
def test_write_changes():
    contents = "This is a simple test"
    module = AnsibleModule({'tmpdir':'/tmp'})
    module.atomic_move = lambda tmpfile, path: True
    module.params = {'unsafe_writes':True}
    module.run_command = lambda command: (0,'','')
    module.params['validate'] = None
    assert write_changes(module, contents, None) == None
    module.params['validate'] = "echo %s"
    assert write_changes(module, contents, None) == None



# Generated at 2022-06-20 22:30:17.124512
# Unit test for function write_changes
def test_write_changes():
    module_args = dict(
        path='/tests/testfile',
        regexp=r'(\w+)',
        replace=r'\1\1'
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    changed, diff = write_changes(module, contents=b"blah blah blah", path='/tests/testfile')
    assert changed



# Generated at 2022-06-20 22:30:21.722511
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path': '/tmp/test'})
    message, changed = check_file_attrs(module, False, "")
    assert changed


# Generated at 2022-06-20 22:30:30.373239
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-20 22:30:38.183953
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    setattr(module, 'tmpdir', '/tmp')
    setattr(module, 'atomic_move', lambda x1, x2, x3: None)
    setattr(module, 'run_command', lambda x: (0, '', ''))
    setattr(module, 'fail_json', lambda x: None)
    write_changes(module, 'contents', 'path')



# Generated at 2022-06-20 22:30:49.850823
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_local_utils as utils
    from ansible.module_utils.ansible_local import AnsibleModule
    from ansible.module_utils.ansible_local._text import to_bytes
    from ansible.module_utils.ansible_local.common.utils import module_params_get
    from ansible.module_utils.ansible_local.common.ansible_module import get_module_path
    import ansible.module_utils.ansible_local.ansible_module_generated as generated_module
    import tempfile
    import os
    import pytest
    if not os.path.exists(generated_module.__file__):
        pytest.skip("ansible_local is not installed")

# Generated at 2022-06-20 22:30:57.368056
# Unit test for function main
def test_main():
    test_dir = os.path.dirname(__file__)
    m = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:31:07.504898
# Unit test for function check_file_attrs
def test_check_file_attrs():
    if __name__ != "__main__":
        import os
        import sys
        import difflib
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_text

        # Simulate testing single module
        module = AnsibleModule(
            argument_spec={
                'path': {'required': True},
                'after': {'required': False},
                'before': {'required': False},
                'regexp': {'required': True},
                'replace': {'required': False},
                'encoding': {'default': 'utf-8'},
                'others': {'required': False},
                'backup': {'default': False, 'type': 'bool'},
            },
            supports_check_mode=True
        )

        test_

# Generated at 2022-06-20 22:32:56.965115
# Unit test for function check_file_attrs
def test_check_file_attrs():
    changed = False
    message = ''
    x = check_file_attrs(module, changed, message)
    assert(x[0] == 'ownership, perms or SE linux context changed')
    assert(x[1] == True)



# Generated at 2022-06-20 22:33:01.769503
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule(argument_spec = dict())
    file_contents = b'Test\nLine 1\nLine 2'
    tempdir = tempfile.mkdtemp()
    path = os.path.join(tempdir, 'test_write_changes')
    test_module.params['validate'] = None
    test_module.params['unsafe_writes'] = False
    test_module.tmpdir = tempdir
    test_module.atomic_move = os.rename
    write_changes(test_module, file_contents, path)
    f = open(path, 'rb')
    assert f.read() == file_contents
    f.close()
    os.unlink(path)
    os.rmdir(tempdir)


# Generated at 2022-06-20 22:33:10.146671
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import mock
    M = mock.mock_open()
    M.contents = "test"
    m = mock.mock_open(M)
    m.return_value.read.return_value.rstrip.return_value = "test"
    m.return_value.read.return_value.lstrip.return_value = "test"

    mod_path = 'ansible.builtin.replace'
    M.reset_mock()
    with mock.patch("ansible.builtin.replace.open", m, create=True):
        with mock.patch.object(m, "read") as mock_read:
            mock_read.side_effect = ["test", "test"]

# Generated at 2022-06-20 22:33:15.188839
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())
    import tempfile
    tmpfd, tmpfile = tempfile.mkstemp(prefix='ansible_test_file_attrs')
    os.close(tmpfd)
    module.params['path'] = tmpfile

# Generated at 2022-06-20 22:33:25.174905
# Unit test for function check_file_attrs
def test_check_file_attrs():
    strings = [ 'ownership, perms or SE linux context changed',
                'ownership or perms changed',
                'ownership changed' ]
    class TestModule:
        pass
    test_m = TestModule()
    test_m.params = dict()
    test_m.params['unsafe_writes'] = True
    test_m.params['owner'] = 'jdoe'
    test_m.params['group'] = 'jdoe'
    test_m.params['mode'] = '0644'
    for s in strings:
        class TempModule:
            pass
        m = TempModule()
        m.params = dict()
        m.params['unsafe_writes'] = True
        m.params['owner'] = 'jdoe'
        m.params['group'] = 'jdoe'


# Generated at 2022-06-20 22:33:28.200231
# Unit test for function main
def test_main():
  args = dict(
        path="/etc/tzfile",
        regexp='\bEST\b',
        replace='Eastern',
  )
  result = main(args)
  assert result.get('changed')


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:33:29.206009
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Noop
    return True



# Generated at 2022-06-20 22:33:29.943349
# Unit test for function write_changes
def test_write_changes():
  assert True == True


# Generated at 2022-06-20 22:33:37.998370
# Unit test for function main
def test_main():
    contents = '''# this is a test file
    ae56b53c0ac
    41123444444
    6d12a7de669
    '''
    replace = '''# this is a test file
    ae56b53c0ac
    41123444444
    '''
    pattern = '^(.+)$'
    replace = '# \1'
    contents = re.subn(pattern, replace, contents, flags=re.MULTILINE)
    assert contents[1] == 3
    #assert contents[0] == replace

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:33:43.558619
# Unit test for function check_file_attrs