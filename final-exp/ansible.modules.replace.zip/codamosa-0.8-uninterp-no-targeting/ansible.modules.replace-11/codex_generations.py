

# Generated at 2022-06-20 22:25:10.249202
# Unit test for function check_file_attrs
def test_check_file_attrs():
    arg_spec = dict(
        path=dict(type='str', required=True),
        regexp=dict(type='str', required=True),
        replace=dict(type='str'),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        others=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    )
    module = AnsibleModule(argument_spec=arg_spec)
    changed = True
    message = 'Test message'
    message, changed = check_file_attrs(module, changed, message)
    print("check_file_attrs: " + message)
    print("check_file_attrs: " + str(changed))


# Generated at 2022-06-20 22:25:15.171031
# Unit test for function main

# Generated at 2022-06-20 22:25:23.145372
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(argument_spec=dict(
        path=dict(type='path', aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str'),
        replace=dict(type='str', default=''),
        after=dict(type='raw', default=''),
        before=dict(type='raw', default=''),
        unsafe_writes=dict(type='bool', default=False),
        backup=dict(type='bool', default=False),
        encoding=dict(type='str', default='utf-8'),
    ))
    assert m
    check_file_attrs(m, False, "")


# Generated at 2022-06-20 22:25:33.631002
# Unit test for function check_file_attrs
def test_check_file_attrs():
    in_path = "/path/to/file"

    class MyModule(object):
        class Result(object):
            def __init__(self):
                self._result = dict(changed=False, msg=[])

            def get(self, v, d=""):
                return self._result.get(v, d)

        def __init__(self):
            self.result = self.Result()

        def load_file_common_arguments(self, params):
            return dict((k, v) for k, v in params.items() if k in ("mode", "owner", "group", "seuser", "serole", "setype", "attributes", "selevel", "unsafe_writes"))


# Generated at 2022-06-20 22:25:44.845332
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            after=dict(type='str'),
            before=dict(type='str'),
    ),
    supports_check_mode=True,
    )
    input = "abcd efgh ijkl mnop qrst uvwxyz"
    output = "abcd efgh 12345qrst uvwxyz"
    params = module.params
    path = params['path']
    params['after'] = to_text(params['after'], errors='surrogate_or_strict', nonstring='passthru')

# Generated at 2022-06-20 22:25:53.362234
# Unit test for function check_file_attrs
def test_check_file_attrs():
    path = "/etc/ansible/foo/bar"

    try:
        os.makedirs("/etc/ansible/foo", 0o755)
    except:
        pass

    try:
        os.remove(path)
    except OSError:
        pass

    with open(path, "w") as f:
        pass


# Generated at 2022-06-20 22:26:03.678212
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            regexp=dict(required=True),
            replace=dict(),
            path=dict(required=True, aliases=['dest', 'name']),
            validate=dict(),
            backup=dict(default=False, type='bool'),
            unsafe_writes=dict(default=False, type='bool')
            )
        )

    contents = b"unicode stuff, this is a test\n"
    path = '/tmp/replace_test'
    f = open(path, 'wb')
    f.write(contents)
    f.close()
    f = open(path, 'r')
    module.params['backup'] = False
    module.params['regexp'] = r'^unicode'
    module.params['replace'] = ''
   

# Generated at 2022-06-20 22:26:14.002448
# Unit test for function write_changes
def test_write_changes():
    contents = to_bytes(u'old content\n')
    path = u'file1.txt'
    validate = 'test -f %s'
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path'),
        pattern=dict(type='str', default=''),
        dest=dict(type='path', default=''),
        replace=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
        unsafe_writes=dict(type='bool', default=False),
        validate=dict(type='str', default=True)
    ))
    RC_OK = 0
    module.run_command = Mock(
        return_value=(RC_OK, '', '')
    )

# Generated at 2022-06-20 22:26:20.319727
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()


# Generated at 2022-06-20 22:26:31.292929
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {
                'path': '/etc/foo',
                'mode': '0644',
            }
            self.tmpdir = '/tmp'

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, src, dest, unsafe_writes=False):
            pass

        def load_file_common_arguments(self, params):
            return params

        def set_file_attributes_if_different(self, file_args, changed):
            return True

    m = AnsibleModuleMock()
    changed, msg = check_file_attrs(m, False, '')
    assert changed == True
    assert msg == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-20 22:26:50.796974
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import System
    from ansible.module_utils.facts.system.system import System
    from ansible.module_utils.facts.hardware.dmi import DMI
    from ansible.module_utils.facts.hardware.dmi import Hardware
    from ansible.module_utils.facts.network.interfaces import Interfaces
    from ansible.module_utils.facts.network.interfaces import Network
    from ansible.module_utils.facts.network.default import Default
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBox


if __name__ == '__main__':
    main

# Generated at 2022-06-20 22:26:56.349167
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    def mocked_set_file_attributes_if_different(args, changed):
        return True

    module.set_file_attributes_if_different = mocked_set_file_attributes_if_different
    message = "test"
    assert check_file_attrs(module, False, message) == ("test and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-20 22:27:00.201923
# Unit test for function check_file_attrs
def test_check_file_attrs():
    args = {'path': '/path/to/file', 'owner': 'bob', 'mode': '0644'}
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True),
        owner=dict(type='str'),
        group=dict(type='str'),
        seuser=dict(type='str'),
        serole=dict(type='str'),
        setype=dict(type='str'),
        selevel=dict(type='str'),
        mode=dict(type='str'),
    ), check_invalid_arguments=False, supports_check_mode=True)
    module.run_command = lambda x, y: (0, '', '')
    module.atomic_move = lambda x, y: None
    module.set_file_attributes_if_

# Generated at 2022-06-20 22:27:00.857388
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:27:03.052940
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(path, regexp, replace) == those



# Generated at 2022-06-20 22:27:14.247558
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import MutableMapping

    module = AnsibleModule(argument_spec=dict())
    module.set_params(**{'path': '/tmp', 'unsafe_writes': False, 'owner': 'root', 'group': 'root', 'mode': '0644'})
    module.set_params(**{'path': '/tmp/test1', 'unsafe_writes': False, 'owner': 'root', 'group': 'root', 'mode': '0666'})
    result = check_file_attrs(module, False, "")
    assert result == ('ownership, perms or SE linux context changed', True)

    module = AnsibleModule(argument_spec=dict())
    module.set_

# Generated at 2022-06-20 22:27:20.943595
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class AnsibleFailJson(object):
        def __init__(self):
            self.value = False
        def fail_json(self, msg):
            self.value = True
    class AnsibleModuleUtils(object):
        def load_file_common_arguments(self, params):
            self.params = params
            return params
        def set_file_attributes_if_different(self, file_args, test):
            if self.params['changed'] == True:
                self.params['changed'] = False
                return True
            else:
                return False
    class AnsibleModule(object):
        def __init__(self):
            self.ansible_fail_json = AnsibleFailJson()
            self.tmpdir = '/tmp'
            self.atomic_move = self.atomic_move_dummy

# Generated at 2022-06-20 22:27:25.828950
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=False, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=False),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:27:36.724049
# Unit test for function write_changes
def test_write_changes():
    contents = "test contents"
    path = "/path/to/test.txt"

    class MockModule:
        def __init__(self):
            self.tmpdir = "/tmp"
            self.params = {
                'validate': None,
                'unsafe_writes': False,
            }

        def atomic_move(self, tmpfile, path, unsafe_writes):
            assert path == "/path/to/test.txt"
            assert unsafe_writes == False
            with open(path, "w") as f:
                f.write(contents)

        def fail_json(self, msg):
            assert False, msg

        def run_command(self, validate):
            assert False

    module = MockModule()
    
    write_changes(module, contents, path)

# Generated at 2022-06-20 22:27:48.101148
# Unit test for function main
def test_main():
    test_args = dict(
        path="/etc/ansible/ansible.cfg",
        regexp="^#callback_whitelist = timer, mail$",
        replace="callback_whitelist = timer",
    )

# Generated at 2022-06-20 22:28:14.859147
# Unit test for function main
def test_main():
  contents = '''- name: Before Ansible 2.3, option 'dest', 'destfile' or 'name' was used instead of 'path'
  ansible.builtin.replace:
    path: /etc/hosts
    regexp: '(\\s+)old\\.host\\.name(\\s+.*)?$'
    replace: '\\1new.host.name\\2'
  '''
  path = 'file1.yml'
  params = {'path': 'file1.yml', 'regexp': '', 'replace': '', 'backup': False, 'encoding': 'utf-8'}
  res_args = {}
  module = MockModule(params)
  write_changes(module, contents, path)
  check_file_attrs(module,   True, ' ')
  main()

# Generated at 2022-06-20 22:28:20.866444
# Unit test for function main
def test_main():
  module_args = {
    "path": "ansible_test_file",
    "regexp": "^(ListenAddress[ ]+)[^\n]+$",
    "replace": "\\g<1>0.0.0.0"
  }
  module = AnsibleModule(
      argument_spec=module_args,
      supports_check_mode=True
  )
  main()
  
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:28:22.464772
# Unit test for function write_changes
def test_write_changes():
    assert 1


# Generated at 2022-06-20 22:28:30.411017
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    (tmpfd, tmpfile) = tempfile.mkstemp(dir="/tmp")
    os.write(tmpfd,"test")
    os.close(tmpfd)
    module.params["validate"] = "cat %s"
    module.atomic_move = lambda x,y,z: x  # do nothing
    module.tmpdir="/tmp"
    data="test"
    write_changes(module,data,tmpfile)
    os.remove(tmpfile)



# Generated at 2022-06-20 22:28:41.030942
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    def run_ansible(dict_args):
        module = AnsibleModule(
            argument_spec=dict_args['argument_spec'],
            supports_check_mode=True)

        real_stdout = module._display.out
        module._display.out = StringIO()
        check_file_attrs(module, dict_args['changed'], dict_args['message'])
        assert module._display.out.getvalue() == ''

        module._display.out = real_stdout

        return module.params['changed']


# Generated at 2022-06-20 22:28:46.073244
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, True, "a") == ("a and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(None, False, "a") == ("ownership, perms or SE linux context changed", True)
    return True



# Generated at 2022-06-20 22:28:56.785097
# Unit test for function write_changes
def test_write_changes():
    class MockModule:
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.params = {
                'validate': None
            }

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, tmpfile, path, unsafe_writes=False):
            return

    tmpfd, tmpfile = tempfile.mkstemp(dir='/tmp')
    os.close(tmpfd)
    os.unlink(tmpfile)

    m = MockModule(tmpdir='/tmp')

    def test_run_command(cmd, *args, **kwargs):
        return (0, '', '')
    m.run_command = test_run_command


# Generated at 2022-06-20 22:28:59.247028
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test return values.
    assert check_file_attrs("A","B","C") == ("C and ownership, perms or SE linux context changed",True)


# Generated at 2022-06-20 22:29:06.709142
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.__init__ import text
    import pytest
    import tempfile
    import os

    test_content = "This is the test content."
    test_file_name = "replace_module_test_file"
    test_file_path = os.path.join(tempfile.gettempdir(), test_file_name)

    with open(test_file_path, "w") as f:
        f.write(test_content)


# Generated at 2022-06-20 22:29:20.059769
# Unit test for function main
def test_main():
  from ansible.module_utils import basic
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils._text import to_text
  contents = u"""
  [grafana]
  name=grafana
  baseurl=https://packages.grafana.com/oss/rpm
  repo_gpgcheck=1
  enabled=1
  gpgcheck=1
  gpgkey=https://packages.grafana.com/gpg.key
  sslverify=1
  sslcacert=/etc/pki/tls/certs/ca-bundle.crt
  module = basic
  """
  path = u"""/etc/yum.repos.d/grafana.repo"""

# Generated at 2022-06-20 22:29:54.034979
# Unit test for function main
def test_main():
    test_fixtures = [
        {
            'path': '/etc/hosts',
            'regexp': '(\s+)old\.host\.name(\s+.*)?$',
            'replace': '\1new.host.name\2',
            'after': 'asdf',
            'before': 'asdf',
            'backup': False,
            'validate': '/usr/sbin/apache2ctl -f %s -t',
            'encoding': 'utf-8'
        }
    ]

# Generated at 2022-06-20 22:30:01.839731
# Unit test for function main
def test_main():
    import tempfile
    import os
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    tmpdir = tempfile.mkdtemp()
    module.tmpdir = tmpdir

# Generated at 2022-06-20 22:30:10.482308
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:30:16.098159
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:30:20.520246
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, False, 'msg') == ('msg and ownership, perms or SE linux context changed', True)


# Generated at 2022-06-20 22:30:29.809414
# Unit test for function main
def test_main():
    # Use the above function, so we need to remove that from ours
    del main
    import os
    import shutil
    import tempfile
    import re
    import filecmp

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock

    # Create a temp path to use so we don't write to real files
    td = tempfile.mkdtemp()
    testfile_path = os.path.join(td, "test.txt")

# Generated at 2022-06-20 22:30:41.826510
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    test_args = dict(
        path=dict(type='path', required=True, aliases=[u'dest', u'destfile', u'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=u''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default=u'utf-8'),
    )
    test_args.update(basic.ansible_module_kwargs())

# Generated at 2022-06-20 22:30:54.216097
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import AtomicAction
    import sys
    import os
    try:
        from __main__ import display

        display = display.Display()
    except (ImportError, AttributeError):
        display = None

    def setUpModule():
        basic._ANSIBLE_ARGS = to_bytes('')
        if os.path.exists('../lib/ansible/module_utils/basic.py'):
            sys.path.insert(0, '../lib/ansible')
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:30:54.881037
# Unit test for function write_changes
def test_write_changes():
    assert False


# Generated at 2022-06-20 22:31:03.556961
# Unit test for function main
def test_main():
    """
    Test module with the given yaml data
    """

# Generated at 2022-06-20 22:32:04.730467
# Unit test for function main
def test_main():
    import json
    import os, sys
    import tempfile

    from ansible.module_utils import basic
    from ansible.module_utils import file_common

    f, path = tempfile.mkstemp()
    os.close(f)

    def read(path):
        with open(path, 'rb') as f:
            return to_text(f.read(), errors='surrogate_or_strict', encoding='utf-8')

    def write(path, content):
        with open(path, 'wb') as f:
            f.write(to_bytes(content, errors='surrogate_or_strict'))


# Generated at 2022-06-20 22:32:13.601372
# Unit test for function write_changes
def test_write_changes():
  # This is necessary because the function uses module.atomic_move
  class MockModule(object):
    pass

  module = MockModule()
  module.atomic_move = lambda *args: None
  module.params = {'unsafe_writes': True}
  module.tmpdir = '/tmp'

  _, path = tempfile.mkstemp(dir=module.tmpdir)
  with open(path, 'w') as f:
    f.write("Before\n")

  write_changes(module, "After\n", path)

  with open(path, 'r') as f:
    assert f.readline() == "After\n"


# Generated at 2022-06-20 22:32:23.139450
# Unit test for function write_changes
def test_write_changes():
    """ test: write_changes() returns expected values
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        )
    module.params = {'unsafe_writes': False}
    module.fail_json = lambda kwargs: kwargs
    module.run_command = lambda x: (0, '', '')
    hold_tmpdir, module.tmpdir = module.tmpdir, '/non/existent/dir/'
    assert module.fail_json({'msg': "Invalid tmpdir option: %s" % module.tmpdir}) == {'msg': "Invalid tmpdir option: %s" % module.tmpdir}
    module.tmpdir = hold_tmpdir
    module.atomic_move = lambda src, dest, unsafe_writes: None
    assert write

# Generated at 2022-06-20 22:32:28.784374
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'unsafe_writes': dict(type='bool', required=False, default=False)})
    module.fail_json = lambda **kw: setattr(module, 'failed', True)
    test_path = '/tmp/testfile'
    with open(test_path, 'w') as f:
            f.write('oldcontent')
    write_changes(module, to_bytes('newcontent'), test_path)
    assert not hasattr(module, 'failed')
    with open(test_path) as f:
            assert f.read() == 'newcontent'



# Generated at 2022-06-20 22:32:36.811455
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    with tempfile.NamedTemporaryFile() as tmp:
        tmp.close()
        module = AnsibleModule({
            'path': tmp.name,
            'owner': 0,
            'group': 0,
            'mode': '0600',
            'unsafe_writes': True
        })
        import stat
        orig_mode = os.stat(tmp.name)[stat.ST_MODE]
        changed = False
        message = ""

        module.set_file_attributes_if_different = lambda a, b: True
        message, changed_ = check_file_attrs(module, changed, message)
        assert message == "ownership, perms or SE linux context changed"
        assert changed

# Generated at 2022-06-20 22:32:42.102788
# Unit test for function write_changes

# Generated at 2022-06-20 22:32:51.520368
# Unit test for function check_file_attrs
def test_check_file_attrs():
    def get_file_attributes(path):
        return os.stat(path)
    def fail_json(msg):
        print("fail_json called: " + msg)
    def atomic_move(src, dest, unsafe_writes=False):
        assert(src == "/tmp/testfile" and dest == "/tmp/testfile2")
    class AnsibleModuleMock:
        def __init__(self):
            self.check_mode = False
            self.params = { 'path': "/tmp", 'unsafe_writes': False }
        def load_file_common_arguments(self, params):
            return { 'path': params['path'], 'mode': '0600' }
        def set_file_attributes_if_different(self, file_args, changed):
            statinfo = get_file_att

# Generated at 2022-06-20 22:32:58.962161
# Unit test for function check_file_attrs
def test_check_file_attrs():

    check_dir = tempfile.mkdtemp()
    check_file = os.path.join(check_dir, "test_file")

    module_args = dict(
        path=check_file,
        regexp='replace_me',
        replace='replaced',
        unsafe_writes=True,
        backup=False,
        owner='nobody',
        group='nobody',
        mode='0755',
        seuser=None,
        serole=None,
        setype=None,
        attributes=None,
        selevel=None,
    )

    with open(check_file, 'w') as f:
        f.write('replace_me!\n')

    a = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    a.params = module_args

   

# Generated at 2022-06-20 22:33:06.190450
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(default='/file', type='str')
        ),
    )
    module.tmpdir = tempfile.mkdtemp()
    contents = u'foo\nbar\n1\n2\n3\n4\n5\n6\n7\n8\n9\n10'
    write_changes(module, contents, module.params.get('path'))
    f = open('/file', 'r')
    content = f.read()
    assert content == contents
    f.close()



# Generated at 2022-06-20 22:33:12.825766
# Unit test for function main
def test_main():

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = self.params['check_mode']
            self.params['encoding'] = 'utf-8'
            self.tmpdir = tempfile.mkdtemp()

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            raise Exception(kwargs['msg'])

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False
