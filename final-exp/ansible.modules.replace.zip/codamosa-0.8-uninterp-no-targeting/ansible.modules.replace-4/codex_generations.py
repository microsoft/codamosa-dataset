

# Generated at 2022-06-20 22:24:59.790999
# Unit test for function main
def test_main():
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:25:04.306032
# Unit test for function main
def test_main():
    for fixture_file in ['test_regexp_for_pattern.txt', 'test_regexp_for_pattern_with_unicode.txt']:
        with open(os.path.join(os.path.dirname(__file__), 'regexp_fixtures', fixture_file), 'rb') as f:
            contents_before_run = to_text(f.read(), errors='surrogate_or_strict', encoding='utf-8')

        pattern = u'^(?P<dctv>ListenAddress[ ]+)(?P<host>[^\n]+)$'
        regexp = u'(?P<dctv>ListenAddress[ ]+)(?P<host>[^\n]+)'
        replace = u'\g<dctv>0.0.0.0'
       

# Generated at 2022-06-20 22:25:15.751780
# Unit test for function write_changes
def test_write_changes():
    (module, path) = build_module_mock()

    path = '/tmp/test_file'
    contents = b'some contents'

    def mock_atomic_move(src, dest, unsafe_writes=False):
        assert src == '/tmp/test_file.tmp'
        assert dest == path
        assert not unsafe_writes
    module.atomic_move = mock_atomic_move

    def mock_mkstemp(dir=None, prefix=None, text=None):
        assert dir == module.tmpdir
        assert not prefix
        assert text is None
        return 5, '/tmp/test_file.tmp'
    module.mkstemp = mock_mkstemp

    def mock_fdopen(fd, mode):
        assert fd == 5
        assert mode == 'wb'

# Generated at 2022-06-20 22:25:18.291868
# Unit test for function main
def test_main():
    path = ''
    pattern = ''
    replace = ''
    after = ''
    before = ''
    assert main(path, pattern, replace, after, before) is None


# Generated at 2022-06-20 22:25:27.634189
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeModule:
        def __init__(self):
            self.changed = False

        def fail_json(self, **kwargs):
            pass

        def load_file_common_arguments(self, params):
            return params

        def set_file_attributes_if_different(self, file_args, changed):
            self.changed = True
            return True

    fake = FakeModule()
    msg = ""
    result = check_file_attrs(fake, True, msg)
    assert result == ("ownership, perms or SE linux context changed", True)
    result = check_file_attrs(fake, False, msg)
    assert result == ("ownership, perms or SE linux context changed", True)
    msg = "patterns"
    result = check_file_attrs(fake, True, msg)

# Generated at 2022-06-20 22:25:40.468867
# Unit test for function main
def test_main():
    open_name = 'ansible.builtin.open'
    replace_name = 'ansible.builtin.replace'
    file_name = 'ansible.builtin.file'

# Generated at 2022-06-20 22:25:48.256931
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(argument_spec=dict(unsafe_writes = dict(default = False, type = 'bool'),
                                         validate = dict(required = True, type = 'str'),
                                         path = dict(required = True, type = 'str'),
                                         contents = dict(required = True, type = 'str'),
                                         tmpdir = dict(required = True, type = 'str')))
    write_changes(m, to_bytes('HELLO WORLD\n', 'utf-8'), '/tmp/hello')
    assert open('/tmp/hello', 'rb').read() == to_bytes('HELLO WORLD\n', 'utf-8')



# Generated at 2022-06-20 22:25:53.649282
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.builtin.plugins.modules.files import replace
    from ansible_collections.ansible.builtin.tests.unit.modules.utils import set_module_args
    import os.path 
    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    module.check_mode = False
    module.params = {'path': '/etc/foo', 'regexp': 'old', 'replace': 'new'}
    x = os.path.exists.return_value
    module.exit_json.return_value = {'msg': '', 'changed': True}
    set_module_args(module.params)

# Generated at 2022-06-20 22:26:04.322237
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']


# Generated at 2022-06-20 22:26:10.653572
# Unit test for function check_file_attrs
def test_check_file_attrs():
    result, changed = check_file_attrs(module, True, 'foo')
    assert result == "ownership, perms or SE linux context changed"
    assert changed == True
    result, changed = check_file_attrs(module, False, 'foo')
    assert result == "ownership, perms or SE linux context changed"
    assert changed == True
    result, changed = check_file_attrs(module, True, None)
    assert result == "ownership, perms or SE linux context changed"
    assert changed == True
    result, changed = check_file_attrs(module, False, None)
    assert result == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-20 22:26:28.373520
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str'),
            contents=dict(type='str'),
            validate=dict(type='str')
        )
    )
    contents = 'test_string'
    path = tempfile.mkstemp()
    result = write_changes(module, contents, path)
    module.exit_json(changed=True)


# Generated at 2022-06-20 22:26:37.648014
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.action import ActionBase
    m = AnsibleModule(argument_spec = dict(
        owner = dict(type = 'str'),
        group = dict(type = 'str'),
        mode = dict(type = 'str', choices = ['valid']),
        seuser = dict(type = 'str'),
        serole = dict(type = 'str'),
        setype = dict(type = 'str'),
        selevel = dict(type = 'str'),
        path = dict(type = 'str'),
    ))
    m._ansible_tmpdir = '/tmp'
    m.fail_json = lambda x: None
    b = ActionBase(m, '/tmp', False)
    b.atomic_move = lambda a, b, c: None


# Generated at 2022-06-20 22:26:46.068582
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='raw'),
        ),
        supports_check_mode=True,
    )
    # missing file, should always change
    assert ' changed' == check_file_attrs(module, False, ' ')[0]

    # create a temp file to work on
    (tmpfd, tmpfile) = tempfile.mkstemp(dir='/tmp')
    os.close(tmpfd)
    os.chmod(tmpfile, 0o600)
    module.params['path'] = tmpfile

    # owner change only
    module.params['owner'] = 'root'

# Generated at 2022-06-20 22:26:56.705638
# Unit test for function main
def test_main():
    module_args = dict(
        path='/home/jeff/group_vars/group1.yml',
        regexp='^(.*)($)',
        replace='\g<1>\g<2>',
        after='ALL',
        before='HOSTS',
        backup=False,
        validate='/bin/true %s',
        encoding='utf-8',
        unsafe_writes=False
    )

# Generated at 2022-06-20 22:27:08.152170
# Unit test for function main
def test_main():
    from ansible.modules.files.file import main
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        def to_bytes(value, encoding='utf-8'):
            return str.encode(value, encoding)
    else:
        def to_bytes(value, encoding='utf-8'):
            return value

    import os
    import re
    import tempfile
    import shutil
    # template for creating temporary file

# Generated at 2022-06-20 22:27:17.539891
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    Check that function check_file_attrs is working
    """
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule({'path': '/tmp/test',
                                 'owner': 'root',
                                 'group': 'root',
                                 'mode': '0755',
                                 'unsafe_writes': True})
    test_file_args = {'path': '/tmp/test',
                      'owner': 'root',
                      'group': 'root',
                      'mode': '0755',
                      'attributes': None,
                      'selevel': None,
                      'serole': None,
                      'setype': None,
                      'seuser': None}
    test_changed = False
    test_message = 'test'


# Generated at 2022-06-20 22:27:26.331980
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            unsafe_writes=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    path='/foo'
    contents='bar'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path).read() == contents



# Generated at 2022-06-20 22:27:37.869055
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params

# Generated at 2022-06-20 22:27:41.156751
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:27:51.830122
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    module=AnsibleModule(argument_spec=dict(validate=dict(default=None),
        unsafe_writes=dict(default=False),
        tmpdir=dict(default='/var/tmp/ansible')),
    )
    module.run_command = lambda *args: (0, 'test_run_command', None)
    module.atomic_move = lambda *args: True
    path = tempfile.mkstemp(dir='/var/tmp/ansible')[1]
    write_changes(module, b'contents', path)
    tmpfile = os.path.join('/var/tmp/ansible', os.path.basename(path))
    assert os.path.exists(tmpfile)


# Generated at 2022-06-20 22:28:23.866717
# Unit test for function check_file_attrs
def test_check_file_attrs():
    fake_module = AnsibleModule(
        argument_spec={
            'path': {'type': 'path'},
        },
        supports_check_mode=True
    )
    fake_module.atomic_move = lambda x, y, z: None

    fake_module.params.update({'path': 'test_file',
                               'owner': 'root',
                               'group': 'root',
                               'mode': '0600',
                               'seuser': 'unconfined_u',
                               'serole': 'object_r',
                               'setype': 'test_t',
                               'selevel': 's0'})

    def fake_set_file_attriubtes_if_different(file_args, changed):
        return True
    fake_module.set_file_attributes_if

# Generated at 2022-06-20 22:28:33.437653
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = DummyModule(params=dict(
        path='/path/to/file',
        owner='user',
        group='group',
        mode='0440',
        seuser='seuser',
        serole='serole',
        selevel='selevel',
        setype='setype'
        ))
    module.atomic_move = lambda x, y, **kw: x
    module.set_file_attributes_if_different = lambda x, y: x
    module.load_file_common_arguments = lambda x: x
    message, changed = check_file_attrs(module, False, '')
    assert changed



# Generated at 2022-06-20 22:28:42.625993
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            others=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        )
    )
    path = module.params.get('path', None)
    changed = False
    message = 'Message'
    value = ['value1']
    module.params.update({'diff_mode': True, 'follow': False})
    module.set_file_attributes_if_different(module, changed, message)

# Generated at 2022-06-20 22:28:48.007030
# Unit test for function write_changes
def test_write_changes():
    # don't even try to run on Windows
    from nose.plugins.skip import SkipTest
    raise SkipTest

    # (possible) TODO: test that when a file is moved, the permissions are kept,
    # this requires a lot of mocking
    # test that the file is validated properly, this requires mocking



# Generated at 2022-06-20 22:28:58.094345
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    ),
    add_file_common_args=True,
    supports_check_mode=True
    )
    class AttributeDict(object):
        _data = dict()
        def __getattr__(self, name):
            return self._data.get(name)

# Generated at 2022-06-20 22:29:03.910661
# Unit test for function main
def test_main():
    """ Test the module main """
    # Test case 1 - successful execution
    # The AnsibleModule class is the base class that all Ansible modules inherit from.
    # This class provides lots of base methods and attributes that subclasses can use
    # to process Ansible parameters and respond to Ansible module calls.

# Generated at 2022-06-20 22:29:09.688956
# Unit test for function write_changes
def test_write_changes():
    contents = b'\nTest line\n'
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()


    validate = module.params.get('validate', None)
    valid = not validate


# Generated at 2022-06-20 22:29:23.348342
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'path': dict(type='path'),
        'encoding': dict(type='str', default='utf-8'),
        'backup': dict(type='bool', default=False),
        'regexp': dict(type='str'),
        'replace': dict(type='str'),
        'after': dict(type='str'),
        'before': dict(type='str'),
        'validate': dict(type='str'),
    })
    params = dict(
        path='/root/testdata',
        regexp='^(.+)$',
        replace='Hello \1',
        after='^NameVirtualHost [*]',
        before='^</VirtualHost>',
    )
    module.params = params
    result = main()
    assert(result)



# Generated at 2022-06-20 22:29:24.553196
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:29:30.557739
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
        )
    )
    import tempfile
    tmpfd, tmpfile = tempfile.mkstemp(dir=m.tmpdir)

    write_changes(m, b"test", tmpfile)
    assert m.md5(tmpfile) == "098f6bcd4621d373cade4e832627b4f6"
    m.atomic_move(tmpfile, '/dev/null')


# Generated at 2022-06-20 22:30:26.610570
# Unit test for function write_changes
def test_write_changes():
    module=AnsibleModule(argument_spec={'path':dict(type='str'), 'regexp':dict(type='str'), 'replace':dict(type='str'), 'after':dict(type='str'), 'before':dict(type='str'), 'backup':dict(type='bool'), 'others':dict(type='str'), 'validate':dict(type='str')})
    # module.run_command()
    # os.remove()
    assert module.run_command() == 0


# Generated at 2022-06-20 22:30:27.154573
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:30:39.251279
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.params['after'] = to_text(module.params['after'], errors='surrogate_or_strict', nonstring='passthru')
   

# Generated at 2022-06-20 22:30:46.320973
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock, NO_MOCK, NO_MOCK_REASON
    # ansible-test needs to be able to use the module to test it, so we are going to have to add
    # the module's code to sys.modules as if it were installed from a package. This is only
    # going to work if the module is packaged as a shared module since that is the only way it
    # can be installed in some other directory than a role or playbook.
    import sys
    import os
    __dir__ = os.path.dirname(__file__)
    # For now we are hardcoding the path to the module based on the tests being located

# Generated at 2022-06-20 22:30:56.375740
# Unit test for function write_changes
def test_write_changes():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.removed import removed_module

    module = removed_module
    path = tempfile.mkstemp(dir=tempfile.gettempdir())
    assert os.path.isfile(path[1])

    contents = b'This will fail'
    assert len(contents) > 0

    module.run_command = lambda a: (255, ' ', ' ')
    old_exists = os.path.exists
    os.path.exists = lambda x: False
    module.atomic_move = lambda a, b, c: True
    write_changes(module, contents, path[1])
    os.path.exists = old_exists

# Generated at 2022-06-20 22:31:07.031706
# Unit test for function main
def test_main():
    import os, tempfile, shutil
    from ansible.module_utils._text import to_bytes
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, 'foo')
    open(path, 'w').write('bar')
    open(path, 'ab').write(to_bytes('\u0600'))
    module = AnsibleModule(argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            contents=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ), supports_check_mode=True)

    set_module_args(dict(path=path, contents='foo', encoding='utf-8'))
    result = main()

# Generated at 2022-06-20 22:31:19.839293
# Unit test for function main
def test_main():
    tmpdir = 'C:\\Users\\mahongxin\\AppData\\Local\\Temp'
    path = 'C:\\Users\\mahongxin\\AppData\\Local\\Temp\\ansible_replace_payload_xnzt_Sl'
    regexp = '\\b(localhost)(\\d*\\b'
    replace = '\\1\\2.localdomain\\2 \\1\\2'
    encoding = 'utf-8'
    for i in range(3):
        if i == 0 or i == 1:
            os.makedirs(path)
        else:
            with open(path, 'wb') as f:
                f.write(to_bytes('C:\\Users\\mahongxin\\AppData\\Local\\Temp', encoding='utf-8'))

# Generated at 2022-06-20 22:31:22.993982
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule({})
    assert check_file_attrs(m, False, "") == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-20 22:31:32.341492
# Unit test for function write_changes
def test_write_changes():
    # Check that the contents are written
    m = AnsibleModule(argument_spec=dict(
        path=dict(required=True, type='path'),
        regexp=dict(required=True, type='str'),
        replace=dict(required=True, type='str'),
        validate=dict(required=False, default=None, type='str'),
        unsafe_writes=dict(required=False, default=False, type='bool')
    ))
    m.params['path'] = '/tmp/ansible-test-replace'
    m.params['unsafe_writes'] = True
    f = open(m.params['path'], 'w')
    f.write('test\n')
    f.close()
    write_changes(m, to_bytes('test\n'), m.params['path'])

# Generated at 2022-06-20 22:31:41.074149
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec={
            'path': {'type': 'str', 'required': True},
            'owner': {'type': 'str'},
            'group': {'type': 'str'},
            'mode': {'type': 'raw'},
            'unsafe_writes': {'type': 'bool', 'default': True},
        }
    )

    module.atomic_move = lambda src, dest, unsafe_writes: 0

    CHANGED_MSG = "ownership, perms or SE linux context changed"

    # Change mode
    module.params['path'] = '/tmp/test'

# Generated at 2022-06-20 22:33:48.655159
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.check_mode = True

# Generated at 2022-06-20 22:33:58.139863
# Unit test for function main
def test_main():
    import os
    import sys
    import subprocess
    import pytest
    import tempfile
    try:
        from testfixtures import tempdir
    except ImportError:
        print('pip install testfixtures')
        sys.exit(2)
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic._AnsibleModule()

# Generated at 2022-06-20 22:34:08.230069
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_text, to_bytes
    post_validate_params={
        "path": "/tmp/test_file",
        "regexp": "foo",
        "after": "",
        "before": "",
        "backup": False,
        "validate": None,
        "encoding": "utf-8",
        "_ansible_check_mode": False,
        "_ansible_debug": True,
        "_ansible_diff": False,
        "follow": False,
        "unsafe_writes": False
    }

# Generated at 2022-06-20 22:34:20.312326
# Unit test for function main
def test_main():
    from ansible.utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:34:29.614961
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            contents=dict(type='str'),
            path=dict(type='str'),
        )
    )
    module.params.update(dict(
        contents = b'A',
        path = '/tmp/a.txt'
    ))
    write_changes(module, module.params['contents'], module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.read() == b'A'
    os.unlink(module.params['path'])



# Generated at 2022-06-20 22:34:32.707608
# Unit test for function write_changes
def test_write_changes():
    assert to_text('test_write_changes') == 'test_write_changes'


# Generated at 2022-06-20 22:34:34.087229
# Unit test for function write_changes
def test_write_changes():
    '''test_write_changes()'''
    assert True



# Generated at 2022-06-20 22:34:43.492650
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Set up mock module
    results = {}
    results['changed'] = False
    results['msg'] = ''

    module = AnsibleModule(
        argument_spec={
            'path': {'type': 'path', 'required': True},
            'owner': {'type': 'str'},
            'group': {'type': 'str'},
            'mode': {'type': 'str', 'choices': ['a-w', 'u+x', 'u+w', 'u+r']}
        }
    )

    module.run_command = lambda *_, **kwargs: (0, '', '')
    module.atomic_move = lambda *_: True

    # Run function and check results
    changed, msg = check_file_attrs(module, results['changed'], results['msg'])