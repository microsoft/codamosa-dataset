

# Generated at 2022-06-20 22:25:03.901020
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'tmpdir':'/tmp'}, check_invalid_arguments=False)
    write_changes(module, b"This is a test", "/tmp/test")
    f = open("/tmp/test", "rb")
    assert f.read() == b"This is a test"
    f.close()
    os.unlink("/tmp/test")


# Generated at 2022-06-20 22:25:07.854770
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, True, "changed") == ("changed and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, False, "changed") == ("ownership, perms or SE linux context changed", True)

# Unit tests for function write_changes

# Generated at 2022-06-20 22:25:08.427202
# Unit test for function write_changes
def test_write_changes():
    assert False



# Generated at 2022-06-20 22:25:20.760610
# Unit test for function check_file_attrs
def test_check_file_attrs():
    '''
    check_file_attrs tests
    '''
    class FakeModule(object):
        def __init__(self):
            self.exit_args = ()
            self.exit_val = None
            self.params = {}

        def fail_json(self, *args):
            self.exit_args = args
            self.exit_val = False
        def exit_json(self, *args):
            self.exit_args = args
            self.exit_val = True
        def set_file_attributes_if_different(self, file_args, changed):
            return changed
        def load_file_common_arguments(self, params):
            return {'mode': params['mode']}

    module = FakeModule()

    # test changed
    module.params['mode'] = '0644'
   

# Generated at 2022-06-20 22:25:25.697879
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Initial state
    module = MagicMock()

# Generated at 2022-06-20 22:25:34.312919
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'unsafe_writes': dict(),
        'path': dict(),
        'seuser': dict(),
        'serole': dict(),
        'setype': dict(),
        'selevel': dict(),
        'owner': dict(),
        'group': dict(),
        'mode': dict()
    })
    message = ""
    changed = True
    message, changed = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-20 22:25:44.337139
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(),
            backup=dict(default=False, type='bool'),
            unsafe_writes=dict(default=False, type='bool', aliases=['dangerous']),
            content=dict(type='str', aliases=['value']),
            src=dict(type='path', aliases=['source']),
            encoding=dict(type='str', default='utf-8'),
            validate=dict(type='str', default=None),
            mode=dict(default='0644', type='raw'),
        ),
        supports_check_mode=True
    )
    write_changes(module, "backup", "/tmp/backup")


# Generated at 2022-06-20 22:25:47.957456
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs('module', True, 'message') == (True, 'message and ownership, perms or SE linux context changed')



# Generated at 2022-06-20 22:25:53.410121
# Unit test for function main
def test_main():
    field_name = "ansible_module"
    if field_name not in globals():
        ansible_module = AnsibleModule(argument_spec={
            'file': { 'type': 'str' }
        })
        globals()[field_name] = ansible_module

    assert main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:02.947905
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:27.759518
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  import tests.support.tmpdir_factory
  import os
  import tempfile
  from ansible.module_utils._text import to_text
  from ansible.module_utils.six import PY2


# Generated at 2022-06-20 22:26:37.932096
# Unit test for function write_changes
def test_write_changes():
    # Test write_changes() with a non-existing file
    module = AnsibleModule(argument_spec={
        'path': {'required': True},
        'validate': {'default': None},
        'unsafe_writes': {'default': True, 'type': 'bool'},
    })
    write_changes(module, "test content".encode('utf-8'), "/test/test_path")
    assert os.path.exists("/test/test_path")
    with open("/test/test_path") as f:
        assert f.readline() == "test content"

    # Test write_changes() with a existing file
    write_changes(module, "test content2".encode('utf-8'), "/test/test_path")

# Generated at 2022-06-20 22:26:45.776748
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'validate': {'type': 'str'}
    })
    class TestAnsibleModule(object):

        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp/test_ansible_module'
            self.fail_json = None
            self.atomic_move = None

        def run_command(self, args):
            return (0, '', '')

    class TestModuleFailJson(object):

        def __init__(self):
            pass

        def __call__(self, msg=None):
            pass

    class TestAtomicMove(object):

        def __init__(self):
            pass


# Generated at 2022-06-20 22:26:56.566713
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    check_file_attrs function test
    """
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'name']),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            selevel=dict(type='str'),
            setype=dict(type='str'),
        ),
    )
    test_module.params['path'] = '/etc/test'
    test_module.params['owner'] = 'test'
    test_module.params['group'] = 'test'
    test_module.params['mode'] = '000'
    test_module

# Generated at 2022-06-20 22:27:08.281644
# Unit test for function main
def test_main():
    path = 'foo.bar'
    regexp = '\b(localhost)(\d*)\b'
    replace = '\1\2.localdomain\2 \1\2'
    backup = False

# Generated at 2022-06-20 22:27:12.463081
# Unit test for function write_changes
def test_write_changes():
    contents = 'test replace'
    module = AnsibleModule(argument_spec={})
    path = os.getcwd() + '/test'
    module.atomic_move = lambda a,b,c:None
    module.params = {'unsafe_writes': False}
    module.run_command = lambda x: (0, '', '')
    write_changes(module, to_bytes(contents), path)
    f = open(path, 'r')
    assert f.read() == contents
    f.close()
    os.remove(path)


# Generated at 2022-06-20 22:27:16.152504
# Unit test for function main
def test_main():

    path = '/path/to/file'

    # Should return False when not given a dictionary
    assert False == main(None)

    # Should return False when the path does not exist
    assert False == main({'path':path})

    # Should return True when the path exists
    assert True == main({'path':path})

    # Should return True when the path exists
    assert True == main({'path':path, 'regexp':'^.+$', 'replace':'# \1'})


# Generated at 2022-06-20 22:27:28.743524
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils import common
    import os
    import tempfile
    import ansible.module_utils.ansible_release as AR

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:27:38.442841
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test with perms changes
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/etc/hosts'
    module.params['mode'] = '0644'
    changed = False
    message = "test"
    expect_message = "test and ownership, perms or SE linux context changed"
    expect_changed = True
    message, changed = check_file_attrs(module, changed, message)
    assert changed == expect_changed
    assert message == expect_message
    # Test with owner/group changes
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/etc/hosts'
    module.params['owner'] = 'root'
    module.params['group'] = 'wheel'
    changed = False
    message = "test"
    expect_message

# Generated at 2022-06-20 22:27:48.088504
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import file
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.module_utils import replace

    module_mock = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(required=True),
            replace=dict(default=''),
            after=dict(),
            before=dict(),
            backup=dict(default=False),
            validate=dict(),
            encoding=dict(default='utf-8'),
        )
    )

    module_mock.load_file_common_arguments = file.AnsibleModule.load_file_common_arguments
    module_mock.set_file_

# Generated at 2022-06-20 22:28:20.061486
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params["owner"] = "root"
    module.params["group"] = "root"
    module.params["mode"] = "0644"
    module.params["seuser"] = "system_u"
    module.params["serole"] = "object_r"
    module.params["setype"] = "file_t"
    changed = True
    message = "regexp changed"
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True


# Generated at 2022-06-20 22:28:33.768877
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:28:41.827775
# Unit test for function check_file_attrs
def test_check_file_attrs():
    TEST_CHECK_FILE_ATTRS_SPEC = dict(
        path = dict(type='str', required=True),
        owner = dict(type='str'),
        group = dict(type='str'),
        mode = dict(type='raw'),
        seuser = dict(type='str'),
        serole = dict(type='str'),
        setype = dict(type='str')
    )
    m = AnsibleModule(argument_spec=TEST_CHECK_FILE_ATTRS_SPEC)
    changed = False
    message = ""
    message, changed = check_file_attrs(m, changed, message)
    assert message == ""
    assert not changed


# Generated at 2022-06-20 22:28:49.567570
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'path': '/tmp/test_file'})

    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}

    message, changed = check_file_attrs(module, False, "")
    assert changed
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-20 22:28:59.339814
# Unit test for function main
def test_main():
    args = dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    )
    module = AnsibleModule(
        argument_spec=args,
        add_file_common_args=True,
        supports_check_mode=True,
    )
    assert module is not None
    module.exit_json = lambda **kwargs: kwargs

# Generated at 2022-06-20 22:29:00.625041
# Unit test for function main
def test_main():
    pass


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:29:01.224622
# Unit test for function write_changes
def test_write_changes():
    pass
    # TODO



# Generated at 2022-06-20 22:29:07.735351
# Unit test for function write_changes
def test_write_changes():

    contents='This is a test'
    module=object
    module.params={}
    module.params['validate']=None
    module.tmpdir=tempfile.mkdtemp()
    path=module.tmpdir+'/tmpfile.txt'
    
    write_changes(module, contents, path)
    
    f=open(path, 'r')
    assert f.read()==contents



# Generated at 2022-06-20 22:29:21.063016
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'src':{'type':'path'},
                                          'dest':{'type':'path'},
                                          'validate':{'type':'str'}})
    setattr(module, 'run_command', dummy_run_command)
    setattr(module, 'atomic_move', dummy_atomic_move)
    setattr(module, 'tmpdir', '/tmp')
    srcfile = '/tmp/ansible_replace_src'
    destfile = '/tmp/ansible_replace_dest'
    contents = 'REPLACEMEFAIL'
    f = open(srcfile, 'w')
    f.write(contents)
    f.close()
    assert write_changes(module, contents, destfile) == None

# Generated at 2022-06-20 22:29:27.892837
# Unit test for function main
def test_main():
    test_args = {'path' : '/etc/hosts', 'regexp' : '(\s+)old\.host\.name(\s+.*)?$', 'replace' : '\1new.host.name\2'}
    with pytest.raises(AnsibleExitJson):
        main()


# Generated at 2022-06-20 22:30:28.997335
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import sys
    import tempfile
    import types
    import os
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import b
    from ansible.module_utils.six import string_types

    # save the builtin open function (we'll mock this out later)
    REAL_OPEN = builtins.open

    # create a temporary directory to use as our cwd
    tmpdir = tempfile.mkdtemp()

    # create a temporary module to use

# Generated at 2022-06-20 22:30:41.509191
# Unit test for function check_file_attrs
def test_check_file_attrs():
    x = AnsibleModule({})
    content = to_bytes('hello')
    (rc, out, err) = x.run_command('whoami')
    call_whoami = out.decode()+ ":" + err.decode()
    x.atomic_move = lambda tmpfile, path: None
    x.set_file_attributes_if_different = lambda file_args, changed: True

    x.params = {'mode': '0644', 'owner': '1', 'group': '2', 'path': '3'}
    x.params['unsafe_writes'] = True
    assert check_file_attrs(x, True, "message") == ("message and ownership, perms or SE linux context changed", True)
    x.params['unsafe_writes'] = False
    assert check_file_attrs

# Generated at 2022-06-20 22:30:54.182893
# Unit test for function write_changes
def test_write_changes():
    '''
    This is a test function to unit test the write_changes function
    '''
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.tmpdir = tempfile.mkdtemp()
    path = module.tmpdir + '/test.txt'
    contents = 'hello world'
    with open(path, 'w') as f:
        f.write(contents)
    assert write_changes(module, contents, path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)
    assert write_changes(module, contents, path)

# Generated at 2022-06-20 22:31:05.423567
# Unit test for function write_changes
def test_write_changes():
    from ansible import context
    from ansible.module_utils.common.file import is_executable
    # ansible.config.DEFAULT_MODULE_PATH is not properly hacked into the module-specific context
    # so this test will fail if it is run in an environment that is running
    # in a directory that doesn't contain a 'library' dir (like tox)
    context.CLIARGS = {}

    if is_executable('/usr/bin/python'):
        validate_cmd = '/usr/bin/python -c "import sys; sys.exit(0 if open(sys.argv[1]).read().count(\'doc\') == 2 else 1)"'
    else:
        validate_cmd = '/bin/grep -c doc'


# Generated at 2022-06-20 22:31:06.208534
# Unit test for function write_changes
def test_write_changes():
  assert 1 == 1


# Generated at 2022-06-20 22:31:18.796887
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import muse_utils
    from ansible.module_utils.muse_utils import get_module_params

    path = "/tmp/muse_test_f9e2c54bd4023fefaf332404e8695435"
    regexp = "b"
    replace = "d"
    after = "a"
    before = "c"
    back = False

    args = dict(path=path,regexp=regexp,replace=replace,after=after,before=before,backup=back)

    module = AnsibleModule(argument_spec=args,supports_check_mode=True)
    module.exit_json = muse_utils.mock_ansible_module.exit_json

# Generated at 2022-06-20 22:31:28.485335
# Unit test for function check_file_attrs
def test_check_file_attrs():
    x = AnsibleModule(argument_spec=dict())
    x.params = dict(path='/etc/hosts', owner='root', group='root', mode='0644')
    x.run_command = lambda cmd: (0, 'pass', '')
    x.set_file_attributes_if_different = lambda a, b: True
    assert True is check_file_attrs(x, False, 'message')[1]
    x.set_file_attributes_if_different = lambda a, b: False
    assert False is check_file_attrs(x, False, 'message')[1]




# Generated at 2022-06-20 22:31:32.528357
# Unit test for function write_changes
def test_write_changes():

    module = AnsibleModule({'src': 'foo', 'dest': 'bar', 'validate': 'echo %s'}, 'foo', check_invalid_arguments=False)
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    write_changes(module, 'foo', 'bar')



# Generated at 2022-06-20 22:31:37.885240
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-20 22:31:46.903046
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'validate':{'type':'str'}})
    contents = 'old contents'
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.write(contents)
    f.close()
    class test_class(object):
        def __init__(self):
            self.tmpdir = tempfile.gettempdir()
            self.params = {'unsafe_writes': True}
        def atomic_move(self, source, dest, unsafe_writes):
            os.rename(source, dest)
            return True
    module.run_command = lambda x, y=None, z=None: ()
    module.atomic_move = test_class().atomic_move
    module.tmpdir = temp

# Generated at 2022-06-20 22:34:09.657449
# Unit test for function check_file_attrs
def test_check_file_attrs():
    func_for_test = check_file_attrs
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=None, type='bool'),
            encoding=dict(type='str', default='utf-8'),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = "message"

    # module is a `dict` type.
    # setting `wi_attributes`
    wi_attributes = dict(
        path=module['params']['path'],
        content=module['path'],
        encoding=module['params']['encoding'],
        follow=False,
    )
   

# Generated at 2022-06-20 22:34:15.024449
# Unit test for function write_changes
def test_write_changes():
    oldfile = open('/tmp/ansible-test-oldfile', 'w')
    oldfile.write('[test]\nfoo = bar\n')
    oldfile.close()
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False, default=''),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
        ),
        supports_check_mode=True
    )
    module.params['path'] = '/tmp/ansible-test-oldfile'
    module.params['regexp'] = '\[.+?\]'

# Generated at 2022-06-20 22:34:18.142714
# Unit test for function check_file_attrs
def test_check_file_attrs():
  assert check_file_attrs('test','test') == 'test and ownership, perms or SE linux context changed'

# Generated at 2022-06-20 22:34:26.865400
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({}, {}, {}, {})
    module.tmpdir = tempfile.gettempdir()
    module.params['unsafe_writes'] = False
    path = module.tmpdir + '/testfile'
    contents = 'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path) as f:
        assert f.read() == 'foo'
    os.unlink(path)



# Generated at 2022-06-20 22:34:34.831997
# Unit test for function write_changes
def test_write_changes():
    contents = "hello\nworld\n"
    path = '/tmp/write_changes_unit_test'
    def test_validate(command):
        if command == '/bin/cat /tmp/write_changes_unit_test':
            return (0, 'hello\nworld\n', '')
        return (-1, '', 'Unexpected command: %s' % command)

    module = AnsibleModule(
        argument_spec = dict(
            validate = dict(type='str'),
            unsafe_writes = dict(type='bool')
        ),
    )
    module.run_command = test_validate
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dst, uw: True
    assert write_changes(module, contents, path) is True


# Generated at 2022-06-20 22:34:41.804294
# Unit test for function check_file_attrs
def test_check_file_attrs():
    changed=False
    message=""
    file_args = dict(path='/tmp/test', diff_peek=None, diff_match=None, diff_ignore_lines=None, diff_replace=None, owner=None, group=None, mode='0600', seuser=None, serole=None, setype=None, selevel=None)
    module = DummyModule()
    module.params = file_args
    message, changed = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True
