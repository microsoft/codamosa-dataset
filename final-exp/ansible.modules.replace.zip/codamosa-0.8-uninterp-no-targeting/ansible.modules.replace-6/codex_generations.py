

# Generated at 2022-06-20 22:25:01.770870
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Place unit tests here.
    pass



# Generated at 2022-06-20 22:25:08.304642
# Unit test for function write_changes
def test_write_changes():
    fd, path = tempfile.mkstemp()
    os.write(fd, to_bytes(''))
    os.close(fd)
    m = AnsibleModule({'path': path, 'validate': 'true', 'content': '[defaults]\nroles_path = ../'})
    x = write_changes(m, to_bytes('[defaults]\nroles_path = mirror/'), path)
    assert not x
    os.remove(path)


# Generated at 2022-06-20 22:25:13.079748
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  import ansible.modules.file.replace as replace
  import os
  import shutil
  import tempfile
  import pytest
  import doctest

  def setup_module(module):
      module.tmpdir = tempfile.mkdtemp()
      module.file_to_change = os.path.join(module.tmpdir, 'file_to_change')
      module.file_to_leave_alone = os.path.join(module.tmpdir, 'file_to_leave_alone')

# Generated at 2022-06-20 22:25:20.493164
# Unit test for function write_changes
def test_write_changes():
    """Unit test for function write_changes"""
    tmpfd, tmpfile = tempfile.mkstemp()
    f = os.fdopen(tmpfd, 'r+b')
    f.close()
    os.remove(tmpfile)
    data = "Unit test for function write_changes"
    write_changes(data, tmpfile)
    file = open(tmpfile, "rb")
    tmp_data = file.read()
    file.close()
    os.remove(tmpfile)
    assert tmp_data == data



# Generated at 2022-06-20 22:25:24.792060
# Unit test for function main
def test_main():
    from ansible.modules.files.ansible.builtin.replace import main
    import pytest
    with pytest.raises(SystemExit) as cm:
        main()
    assert cm.value.code == 256
    assert isinstance(cm.value, SystemExit)
# end unit test for function main


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:25:34.708798
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.common.collections import ImmutableDict
    module = AnsibleModule(
        argument_spec=dict(
            content=dict(type='str'),
            path=dict(type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
            validate=dict(required=False, type='str'),
        ),
        supports_check_mode=False
    )
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dst, unsafe_writes: True
    module.run_command = lambda cmd: (0, 'out', 'err')
    text = 'foo\nbar\n'
    write_changes(module, to_bytes(text), '/tmp/file')



# Generated at 2022-06-20 22:25:36.025255
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-20 22:25:36.683449
# Unit test for function write_changes
def test_write_changes():
    return



# Generated at 2022-06-20 22:25:38.196959
# Unit test for function write_changes
def test_write_changes():
    assert True==True

# Generated at 2022-06-20 22:25:48.177734
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.modules.files.file import check_file_attrs

    module = AnsibleModule(
        argument_spec = dict(
            unsafe_writes = dict(type='bool', default=False),
        ),
    )
    module.params['seuser'] = 'user_u'
    module.params['serole'] = 'role_r'
    module.params['setype'] = 'type_t'
    module.params['selevel'] = 's0'
    module.params['owner'] = 'root'
    module.params['group'] = 'wheel'
    module.params['mode'] = '0644'
    changed, message = check_file_attrs(module, False, "")
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-20 22:26:01.388761
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:26:08.225730
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params['path'] = '/test'
    module.params['mode'] = '0644'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert not changed
    assert message == ''



# Generated at 2022-06-20 22:26:08.915781
# Unit test for function main
def test_main():
  main()



if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:13.009713
# Unit test for function main
def test_main():
    import os
    import tempfile
    import textwrap

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    
    path = '/tmp/ansible_test_file'

# Generated at 2022-06-20 22:26:19.644524
# Unit test for function write_changes
def test_write_changes():
    #mocking function
    def fake_atomic_move(tmpfile, path, unsafe_writes=False):
        print(tmpfile, path, unsafe_writes)
        return True
    #mocking module class

# Generated at 2022-06-20 22:26:25.687779
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = None
    file_args = {'path':'/etc/hosts', 'owner':'root', 'group':'root', 'mode':'0644'}
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:26:26.796567
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-20 22:26:36.617827
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    return module.exit_json(**main())

###################################################################################
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:26:45.246616
# Unit test for function main
def test_main():
    import os

    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common import AnsibleModule as MockAnsibleModule
    # load the function module
    replace = replace_module.__dict__['main']

    # Path of the test fixtures
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')

    # Mock the AnsibleModule
    m = MockAnsibleModule()
    m.fail_json = lambda **k: pytest.fail(k)
    setattr(m, '_diff', True)

# Generated at 2022-06-20 22:26:51.122606
# Unit test for function main
def test_main():
  path = '/etc/hosts'
  encoding = 'utf-8'
  params = dict(path = path, regexp = '\\b(localhost)(\\d*)\\b', replace = '\\1\\2.localdomain\\2 \\1\\2', backup = False)

# Generated at 2022-06-20 22:27:20.733828
# Unit test for function write_changes
def test_write_changes():
    # try to change a file in /
    file = '/test_write_changes'
    with open(file, 'w') as test:
        test.write('test')
    with open(file, 'r') as test_read:
        cur_content = test_read.read()
    assert cur_content == 'test'
    module = AnsibleModule(argument_spec={
        'path': {'required': True, 'type': 'str'},
        'backup': {'required': False, 'default': False, 'type': 'bool'},
        'unsafe_writes': {'required': False, 'default': False, 'type': 'bool'}
    }, supports_check_mode=True)
    module.params['path'] = file
    write_changes(module, 'toto', module.params['path'])

# Generated at 2022-06-20 22:27:33.757368
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class MockModule(object):
        def __init__(self):
            self.params = {'path':'/tmp/test_check_file_attrs',
                           'owner':'root',
                           'group':'root',
                           'mode':'0644'}
            self.tmpdir = os.path.dirname(self.params['path'])
        def fail_json(self, **kwargs):
            assert False, kwargs
        def run_command(self, **kwargs):
            pass
        def load_file_common_arguments(self, args):
            return {'follow': True, 'path': args['path'], 'mode': args['mode'], 'owner': args['owner'], 'group': args['group']}

# Generated at 2022-06-20 22:27:40.097662
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:27:45.865870
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeModule:
        def __init__(self):
            self.set_file_attributes_if_different = None
            self.params = None
            self.tmpdir = None
            self.run_command = None
            self.atomic_move = None
        def load_file_common_arguments(self, params):
            return params
    module = FakeModule()
    module.params = dict(path='/tmp', mode=None, owner=None, group=None)
    module.set_file_attributes_if_different = lambda a, b: True
    changed = True
    message = "foo"
    assert ['and ', 'ownership, perms or SE linux context changed'], check_file_attrs(module, changed, message)

# Generated at 2022-06-20 22:27:53.589816
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule, ModuleFailException
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-20 22:28:06.508730
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:28:16.485971
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.fail_json = lambda **kwargs: kwargs.get('msg')
    module.run_command = lambda cmd: (0, '', '')
    module.tmpdir = '/tmp'
    module.params['tmpdir'] = '/tmp'
    module.params['unsafe_writes'] = False
    module.atomic_move = lambda src, dst: True
    
    contents = '''
host1
host2
host3
host4
host5
host6
'''

    path = '/tmp/hosts'
    module.params['validate'] = 'grep -- "0.0.0.0" %s'
    result = write_changes(module, contents, path)
    assert result is None    



# Generated at 2022-06-20 22:28:24.378080
# Unit test for function main
def test_main():
    import tempfile
    fd, path = tempfile.mkstemp()
    file = os.fdopen(fd, 'w')
    file.writelines(['foo\n', 'bar\n', 'baz\n'])
    file.close()
    module = AnsibleModule({'path': path, 'regexp': 'o', 'replace': 'a'}, check_mode=True)
    result = main()
    assert result == {'changed': True, 'msg': '1 replacements made'}
    os.unlink(path)
    try:
        open(path)
    except IOError as e:
        if e.errno != 2:
            raise

# Generated at 2022-06-20 22:28:36.203419
# Unit test for function write_changes
def test_write_changes():
    # Make sure we are in a safe location to write a file
    test_path = os.path.join('/tmp', '.ansible_unittest_tmp_%s' % os.getpid())
    test_validate = "%s/validate" % test_path
    test_contents = "hello\nworld"

    assert (not os.path.isdir(test_path))
    os.mkdir(test_path)


# Generated at 2022-06-20 22:28:44.025150
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class TestModule(object):
        def fail_json(self, *args, **kwargs):
            pass
    module = TestModule()
    module.atomic_move = lambda *args: None
    module.params = {'unsafe_writes': False}
    class TestModuleParams(object):
        def __init__(self):
            self.path = '/tmp/test'

    module.params = TestModuleParams()
    module.set_file_attributes_if_different = lambda *args: True

    message = 'Attach metadata to resulting file'
    changed = False
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'Attach metadata to resulting file and ownership, perms or SE linux context changed'


# Generated at 2022-06-20 22:29:30.162838
# Unit test for function main
def test_main():
    # we don't run these tests because they rely on the shell
    pass

# import module snippets
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.six import iteritems
from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-20 22:29:36.277315
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import file_common
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from io import StringIO
    import sys
    import os

    real_open = open
    real_getattr = getattr
    real_isfile = os.path.isfile
    real_isdir = os.path.isdir

    real_exit_json = basic.AnsibleModule.exit_json
    real_fail_json = basic.AnsibleModule.fail_json
    real_atomic_move = file_common.atomic_move


# Generated at 2022-06-20 22:29:46.981387
# Unit test for function write_changes

# Generated at 2022-06-20 22:29:58.263184
# Unit test for function check_file_attrs
def test_check_file_attrs():
  print("Testing changed")
  no_change_file_attrs = {}
  yes_change_file_attrs = {'owner': 'root', 'group': 'wheel', 'mode': '600', 'seuser': 'unconfined_r', 'serole': 'object_r', 'setype': 'ssh_home_t', 'selevel': ''}
  no_change_message = "No changes"
  no_change_changed = False
  yes_change_message = "No changes"
  yes_change_changed = False
  (no_change_message, no_change_changed) = check_file_attrs(no_change_file_attrs, no_change_changed, no_change_message)

# Generated at 2022-06-20 22:30:08.026362
# Unit test for function main
def test_main():
    argv = ["/bin/ansible-connection", "/tmp/ansible_replace_payload_NGdRZs/ansible_module_ansible.builtin.replace.py",
            "--diff", "--after", "foo", "--before", "bar", "--name", "foo", "--regexp", "^(.+)$", "--replace", "\\1"]
    kwargs = dict()
    kwargs['regexp'] = u'^(.+)$'
    kwargs['after'] = u'foo'
    kwargs['before'] = u'bar'
    kwargs['name'] = u'foo'
    kwargs['replace'] = u'\\1'
    kwargs['diff'] = True
    main(argv, **kwargs)

