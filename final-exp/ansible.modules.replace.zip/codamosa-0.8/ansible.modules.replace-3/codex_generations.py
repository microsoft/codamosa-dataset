

# Generated at 2022-06-11 07:46:50.242816
# Unit test for function write_changes
def test_write_changes():
    # AnsibleModule mock
    class AnsibleModuleFake(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = None
            self.tmpdir = '/tmp/'
        def atomic_move(self, src, dest, unsafe_writes=None):
            # print "move %s %s" % (src, dest)
            return 0
        def fail_json(self, **kwargs):
            raise Exception(kwargs)
        def run_command(self, cmd):
            # print 'run_command: %s' % cmd
            return 0, "", ""

    # Initialize
    module = AnsibleModuleFake()

    # Test
    write_changes(module, "foobar", "baz")




# Generated at 2022-06-11 07:47:02.104722
# Unit test for function write_changes
def test_write_changes():
    mod = AnsibleModule({}, check_invalid_arguments=False)
    real_write_changes = mod.atomic_move
    mod.atomic_move = lambda src, dest, unsafe: real_write_changes(src, dest, unsafe)
    try:
        contents = 'This is written to test write_changes'
        tmpdir = tempfile.mkdtemp()
        (fd, fname) = tempfile.mkstemp(dir=tmpdir)
        os.write(fd, to_bytes(contents))
        os.close(fd)
        write_changes(mod, to_bytes(contents), fname)
        with open(fname, 'rb') as f:
            new_contents = f.read()
        assert new_contents == to_bytes(contents)
    finally:
        os.remove

# Generated at 2022-06-11 07:47:12.869860
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            validate=dict()
            )
        )
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.atomic_move = atomic_move
    module.tmpdir = '/tmp'

    write_changes(module, b"teststring", "/tmp/test.txt")
    assert os.path.exists("/tmp/test.txt") == True
    assert open("/tmp/test.txt").read() == "teststring"

    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-11 07:47:13.397976
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-11 07:47:14.046525
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert False



# Generated at 2022-06-11 07:47:21.300534
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'unsafe_writes': dict(type='bool', default=False)
    })
    dest = tempfile.mkdtemp(dir='/tmp/')
    contents = to_bytes('test')
    path = os.path.join(dest, 'test')
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents



# Generated at 2022-06-11 07:47:27.005576
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module_helper = AnsibleModule(argument_spec=dict(path=dict(type='path')))
    class MockModule(object):
        def __init__(self):
            self.set_file_attributes_if_different = True
            self.params = {'path': '/tmp/test'}
            self.fail_json = True
            self.changed = True
        def load_file_common_arguments(self, params):
            return params
    module_helper.atomic_move = True
    module_helper.tmpdir = '/tmp/'
    module_helper.run_command = True
    mock_module = MockModule()
    assert check_file_attrs(mock_module, True, "foo") == ("foo and ownership, perms or SE linux context changed", True)
    assert check_file

# Generated at 2022-06-11 07:47:37.417396
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import open_url, fetch_url, url_argument_spec
    from ansible.module_utils.six.moves import builtins

    m = removed_module
    m.params = dict()
    m.tmpdir = '/tmp'
    m.atomic_move = AtomicFile
    m.run_command = lambda x: (0, '', '')
    m.url_argument_spec = dict()
    m.fail_json = lambda **kwargs: 'fail_json'
    m.__dict__ = dict()
    m.__dict__.update(url_argument_spec())

# Generated at 2022-06-11 07:47:47.448090
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    Test function check_file_attrs
    """
    def my_set_file_attributes_if_different(a, b):
        return True

    module = AnsibleModule(
    {
    "set_file_attributes_if_different": my_set_file_attributes_if_different,
    "load_file_common_arguments": lambda x: ()
    }
    )

    assert check_file_attrs(module, True, "") == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, False, "") == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, "Hello") == ("Hello and ownership, perms or SE linux context changed", True)
    assert check_

# Generated at 2022-06-11 07:47:58.613132
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text, to_bytes
    from tempfile import mkdtemp

    tmpdir = mkdtemp()
    path = '/etc/hosts'
    contents = '127.0.0.1 localhost'
    module = AnsibleModule(
        argument_spec=dict(
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True,
    )
    module.tmpdir = tmpdir
    module.atomic_move = lambda src, dst: None

    # validate command always return 0
    module.params['validate'] = 'true'
    write_changes(module, contents, path)

# Generated at 2022-06-11 07:48:22.925662
# Unit test for function write_changes
def test_write_changes():
    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.params['validate'] = None
        def fail_json(self,msg):
            print("failed with message %s" % msg)
        def run_command(self, cmd):
           print("run command %s" % cmd)
           return 0,"success","error"
        def atomic_move(self,file1,file2,unsafe_writes=False):
            print("moving %s to %s" %(file1,file2))

    mod = TestModule()
    test_file = "/tmp/testfile"
    with open("/tmp/testfile","w") as f:
        f.write("hello world")

# Generated at 2022-06-11 07:48:31.917024
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = build_fake_module()
    module.check_file_attrs = check_file_attrs
    # check if changed
    changed = True
    msg = "ownership, perms or SE linux context changed"
    new_msg, changed = check_file_attrs(module, changed, msg)
    assert new_msg == msg
    assert changed == True
    # check if not changed
    changed = False
    msg = "ownership, perms or SE linux context changed"
    new_msg, changed = check_file_attrs(module, changed, msg)
    assert new_msg == msg
    assert changed == False



# Generated at 2022-06-11 07:48:33.940252
# Unit test for function main
def test_main():
    res_args = dict()
    res_args['msg'] = ''
    res_args['changed'] = False
    assert res_args == dict()

# Generated at 2022-06-11 07:48:42.319093
# Unit test for function write_changes
def test_write_changes():
    mock = AnsibleModule({
        "argument_spec": {
            "unsafe_writes": {"type": "bool", "default": False, "required": False},
            "tmpdir": {"type": "str", "required": True},
            "validate": {"type": "str", "default": None, "required": False},
        },
        "params": {
            "unsafe_writes": False,
            "tmpdir": tempfile.gettempdir(),
            "validate": None,
        }
    })
    import mock
    mock.mock_open()
    write_changes(mock, 'test_write_changes', 'tmp_file')
    assert True



# Generated at 2022-06-11 07:48:53.970436
# Unit test for function write_changes
def test_write_changes():
    class Temp(object):
        params = {}
    class TestModule(object):
        params = {'unsafe_writes': True}
        tmpdir = os.getcwd()
        def fail_json(self, msg):
            raise AssertionError(msg)
        def atomic_move(self, src, dest, unsafe_writes):
            os.rename(src, dest)
        def run_command(self, cmd):
            return (0, '', '')
    module = AnsibleModule(argument_spec={})
    module.tmpdir = to_bytes(os.getcwd())
    module.run_command = Temp().run_command
# end unit test

    module = TestModule()
    write_changes(module, contents='', path='touched')
    assert os.path.exists('touched')

# Generated at 2022-06-11 07:49:04.057298
# Unit test for function main
def test_main():
    import shutil
    import tempfile
    import filecmp
    path = tempfile.mkdtemp()
    filename = os.path.join(path, 'test_replace')
    open(filename, 'w').close()
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str'),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module

# Generated at 2022-06-11 07:49:16.012428
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common_koji
    from ansible.module_utils.common_koji import _sysname_to_platform
    from ansible.module_utils.common_koji import TO_UNLOAD_LIBRARIES
    from ansible.module_utils.common_koji import _parse_argspec

    koji_libdir = '/usr/lib/koji-hub/plugins/scmdrunner'
    koji_cmd = '/usr/bin/koji'
    koji_args = [koji_cmd, 'scmd', 'list-tagged', 'rhos-rhel-7.3-candidate']
    koji_plat = _sysname_to_platform(os.uname()[0])
    koji_sig = _

# Generated at 2022-06-11 07:49:27.432971
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import json
    class FakeAnsibleModule():
        def __init__(self):
            self.params = {'path': '/tmp/fakefile'}
        def load_file_common_arguments(self, params):
            return params
        def set_file_attributes_if_different(self, params, changed):
            return changed
    module = FakeAnsibleModule()
    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert not message
    assert not changed
    class FakeAnsibleModule():
        def __init__(self):
            self.params = {'path': '/tmp/fakefile'}
            self.json_output = {'changed': True, 'msg': ''}

# Generated at 2022-06-11 07:49:32.147511
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'tmpdir':'/tmp'})
    path = '/tmp/test_file.txt'
    contents = 'test_content'
    try:
        write_changes(module, contents, path)
        f = open(path, 'r')
        assert f.read() == contents
    finally:
        if os.path.exists(path):
            os.unlink(path)


# Generated at 2022-06-11 07:49:42.824393
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.common.file import atomic_move

    m = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            content=dict(type='str'),
            validate=dict(type='str'),
        )
    )
    # Create the temp file
    m.tmpdir = tempfile.gettempdir()
    tmpfd, tmpfile = tempfile.mkstemp(dir=m.tmpdir)
    os.close(tmpfd)
    # Create the new content
    content = b'abc'
    # Create the file
    f = open(tmpfile, 'wb')
    f.write(content)

# Generated at 2022-06-11 07:50:18.047960
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import sys
    import random

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = sys.exit
            self.set_file_attributes_if_different = lambda *args, **kwargs: True
            self.load_file_common_arguments = lambda *args, **kwargs: {'path': '/tmp/check_file_attrs'}
            self.atomic_move = lambda *args, **kwargs: None

    testmodule = TestModule()
    testmodule.changed = False
    testmodule.msg = random.choice(['test message\n', ''])
    testmodule.check_file_attrs = lambda *args, **kwargs: check_file_attrs(testmodule, args[0], args[1])
    testmodule.check_

# Generated at 2022-06-11 07:50:23.778105
# Unit test for function write_changes
def test_write_changes():
  # module = AnsibleModule(
  #     argument_spec = dict(
  #         path = dict(required=True, type='str'),
  #         regexp = dict(required=True, type='str'),
  #         replace = dict(required=True, type='str'),
  #         validate = dict(required=False, type='str')
  #     ),
  #     supports_check_mode=True
  # )
  module = AnsibleModule(
      argument_spec = dict(
          path = dict(required=True),
          regexp = dict(required=True),
          replace = dict(required=True),
          validate = dict(required=False)
      ),
      supports_check_mode=True
  )
  contents = """
test1
test2
test3
"""

# Generated at 2022-06-11 07:50:36.301217
# Unit test for function main
def test_main():
    # Mock for function main
    def main__mock(module_arguments={'path': '/etc/hosts', 'regexp': 'ATLAS', 'replace': 'HADES', 'backup': False, 'validate': None, 'follow': True, 'encoding': 'utf-8', 'unsafe_writes': False}):
        # Save original modules for later restoration
        orig_os_path_exists = os.path.exists
        orig_os_path_isdir = os.path.isdir
        orig_ansible_module___init__ = AnsibleModule.__init__
        orig_open = open
        # Set up mock environment
        class AnsibleModule:
            def __init__(self, argument_spec, supports_check_mode=False):
                pass

# Generated at 2022-06-11 07:50:42.915950
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MockAnsibleModule()
    module.set_file_attributes_changed = True
    result = 'some message', False
    assert check_file_attrs(module, result[1], result[0]) == ('ownership, perms or SE linux context changed', True)
    module.set_file_attributes_changed = False
    assert check_file_attrs(module, result[1], result[0]) == ('some message', False)



# Generated at 2022-06-11 07:50:51.042332
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/path/to/file',
        'owner': 'user',
        'group': 'group',
        'mode': '0644'
    }
    changed = False
    message = 'initial message'
    result = check_file_attrs(module, changed, message)
    assert result[0] == 'initial message and ownership, perms or SE linux context changed'
    assert result[1] is True



# Generated at 2022-06-11 07:51:03.244799
# Unit test for function write_changes
def test_write_changes():
    "Test function write_changes"
    # no error if destination file already exists
    src = """# This is a comment

# Another comment
"""
    dst = """# This is a test file
# A second line
"""

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            regexp=dict(required=True, type='str'),
            replace=dict(),
            backup=dict(type='bool', default=False),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(type='bool', default=True),
        )
    )
    module.run_command = MagicMock(return_value=(0, None, None))
    module.atomic_move = MagicMock(return_value=True)

    write_

# Generated at 2022-06-11 07:51:10.871520
# Unit test for function write_changes
def test_write_changes():

    tmp_subdir = tempfile.mkdtemp(prefix="ansible_test_")

    test_path = os.path.join(tmp_subdir, "test.txt")
    test_contents = to_bytes("test contents")

    module = AnsibleModule(
        argument_spec={'validate': {'type': 'str', 'default': None},
                       'unsafe_writes': {'type': 'bool', 'default': False, 'required': False},
                       'tmpdir': {'type': 'path', 'default': tmp_subdir, 'required': True}},
        supports_check_mode=False
    )

    write_changes(module, test_contents, test_path)
    with open(test_path, 'rb') as fh:
        result = fh.read()

# Generated at 2022-06-11 07:51:22.987522
# Unit test for function write_changes
def test_write_changes():
    ''' This function will test the function write_changes in replace.py, which
        is used to write changes to a file.
    '''

# Generated at 2022-06-11 07:51:29.474944
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    message = "ohai"
    changed = True

    file_args = module.load_file_common_arguments({'owner': 'root', 'group': 'root', 'mode': 0o644})

    assert module.set_file_attributes_if_different(file_args, False)
    message, changed = check_file_attrs(module, changed, message)

    assert changed == True and message == "ohai and ownership, perms or SE linux context changed"



# Generated at 2022-06-11 07:51:39.405451
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import shutil
    import tempfile
    import shlex
    import ansible.modules.files.replace as replace

    with tempfile.NamedTemporaryFile(mode='w') as tmp_file:
        tmp_file.write('This is a test. It is only a test. Beep boop.')
        tmp_file.flush()

        tmp_dir = tempfile.mkdtemp()

        # Simulate playbook args
        basic._ANSIBLE_ARGS = shlex.split('test -m replace -a "path=%s regexp=test replace=nottest"' % tmp_file.name)
        replace.main()

        with open(tmp_file.name, 'rb') as f:
            file

# Generated at 2022-06-11 07:52:39.711813
# Unit test for function main
def test_main():
    # Test that an exception is raised when the regexp param is required but not provided
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:52:47.591338
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'_ansible_tmpdir': 'tmp'})
    module.run_command = lambda x: (0, '', '')
    import shutil
    try:
        contents = 'example_contents'
        path = '/tmp/ansible.test'
        tmpfile = '/tmp/ansible.test.bak'
        write_changes(module, contents, path)
        assert os.path.isfile(path)
        assert path == open(path, 'r').read()
        os.remove(path)
    except:
        shutil.rmtree(path)
        raise



# Generated at 2022-06-11 07:52:56.874517
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test 1: no change of file attrs
    module = AnsibleModule({'path': '/some/file'})
    changed, message = check_file_attrs(module, False, '')
    assert not changed
    assert message == ''

    # Test 2: change of file attrs, message is empty
    module = AnsibleModule({'path': '/some/file'})
    changed, message = check_file_attrs(module, False, '')
    assert changed
    assert message == 'ownership, perms or SE linux context changed'

    # Test 3: change of file attrs, message is not empty
    module = AnsibleModule({'path': '/some/file'})
    changed, message = check_file_attrs(module, True, 'custom message')
    assert changed

# Generated at 2022-06-11 07:53:08.774859
# Unit test for function write_changes
def test_write_changes():
    # mock module
    class MockModule(object):
        def __init__(self):
            self.tmpdir = None
            self.params = dict()
            self.params['unsafe_writes'] = True
        def fail_json(self, *args, **kwargs):
            raise AssertionError("failed_json")
        def atomic_move(self, *args, **kwargs):
            pass
        def run_command(self, *args, **kwargs):
            return 0, "", ""
    # mock tempfile.mkstemp
    class MockTempfile(object):
        def __init__(self):
            self.fd = None
            self.file = None
        def mkstemp(self, *args, **kwargs):
            self.fd = 1
            self.file = "mock file"


# Generated at 2022-06-11 07:53:16.753562
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'unsafe_writes': {'type': 'bool', 'default': 'no'}})
    module.params.update(
        {
            'dest': '/etc/foo',
            'owner': 'root',
            'group': 'root',
            'mode': '0644',
        }
    )
    changed = False
    message = ''

    return check_file_attrs(module, changed, message)


# -----------------------------------------------------------------------------


# Generated at 2022-06-11 07:53:25.956698
# Unit test for function write_changes
def test_write_changes():
    '''This function tests writing changes'''
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, aliases=['dest', 'destfile', 'name'], type='path'),
            regexp=dict(required=True, aliases=['pattern'], type='str'),
            replace=dict(required=False, type='str'),
            backup=dict(default=False, type='bool'),
            follow=dict(default=False, type='bool', removed_in_version="2.5"),
            unsafe_writes=dict(default=False, type='bool', removed_in_version="2.10"),
            others=dict(required=False, type='str'),
            encoding=dict(default="utf-8", type='str', removed_in_version="2.10"),
        ),
    )

# Generated at 2022-06-11 07:53:35.375398
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(unsafe_writes=dict(type='bool', default=False), validate=dict(type='str', default=None), tmpdir=dict(type='str', default=None)))
    module.run_command = lambda x, check_rc=True: (0, '', '')
    contents = to_bytes("This is a test")
    path = module.tmpdir + os.sep + "test_write_changes.txt"
    file = open(path, "wb")
    file.write(contents)
    file.close()


# Generated at 2022-06-11 07:53:46.192686
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:53:54.818006
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        )
    )
    m, c = check_file_attrs(module, False, "")
    assert c == False


# Generated at 2022-06-11 07:54:03.174525
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule.exit_json') as exit_json:
        with patch('ansible.module_utils.basic.AnsibleModule.fail_json') as fail_json:
            with patch('ansible.module_utils.basic.AnsibleModule.run_command') as run_command:
                run_command.return_value = 0, '', ''
                main()
                print(run_command.call_args_list)
                print(exit_json.call_args_list)
            # assert exit_json(msg='Unable to read the contents of %s: %s' % (path, e)) == exit_json(msg='Unable to read the contents of {}: {}'.format(path, e))
            # assert exit_json(msg='Unable to read the contents