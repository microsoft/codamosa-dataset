

# Generated at 2022-06-11 07:46:48.814668
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'validate': {'type': 'str'},
        'tmpdir': {'type': 'path'},
    })
    test_file = '/tmp/ansible-test-file'
    test_text = to_bytes("Test text written at %d" % int(time.time()))
    write_changes(module, test_text, test_file)
    assert os.path.exists(test_file)
    with open(test_file, 'rb') as f:
        assert f.read() == test_text
    os.remove(test_file)



# Generated at 2022-06-11 07:47:00.313991
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path':'/home/test'})
    tmpfd, tmpfile = tempfile.mkstemp(dir='/tmp')
    assert tmpfile.startswith('/tmp/')
    tmpfd1, tmpfile1 = tempfile.mkstemp(dir='/tmp')
    assert tmpfile.startswith('/tmp/')
    module.tmpdir='/tmp'
    try:
        write_changes(module, 'test', tmpfile)
    except:
        print(format_exc())
    with open(tmpfile) as f:
        assert 'test' == f.read()
    with open(tmpfile1) as f:
        assert '' == f.read()
    os.remove(tmpfile)
    os.remove(tmpfile1)


# Generated at 2022-06-11 07:47:11.464906
# Unit test for function main
def test_main():
  module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True
    )

# Generated at 2022-06-11 07:47:12.209854
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:47:23.331410
# Unit test for function write_changes
def test_write_changes():
    data_path = os.path.join(os.path.dirname(__file__), 'data', 'regexp')
    dest_path = os.path.join(os.path.dirname(__file__), 'data', 'regexp_test_write_changes.txt')
    if os.path.isfile(dest_path):
        os.remove(dest_path)

    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', default=dest_path),
            regexp=dict(type='str'),
            replace=dict(type='str'),
            backup=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=False),
        )
    )

    # The test text

# Generated at 2022-06-11 07:47:34.546098
# Unit test for function main
def test_main():
    import os
    import shutil
    contents = """
    #1
    #2
    """
    filename = "test_replace.txt"
    with open(filename, "wb") as f:
        f.write(to_bytes(contents))


# Generated at 2022-06-11 07:47:39.860989
# Unit test for function main
def test_main():
    results = {'msg': 'Safe Mode is not enabled', 'changed': False}
    module = AnsibleModule({'path': r'/test/path/testpath', 'unsafe_writes': True, '_ansible_check_mode': True}, check_invalid_arguments=False)
    main()
    assert results == {'msg': 'Safe Mode is not enabled', 'changed': False, '_ansible_check_mode': True}

# Generated at 2022-06-11 07:47:45.973378
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'owner': 'root', 'path': '/tmp/foo', 'follow': False}
    changed = True
    message = 'foo'
    res_message, res_changed = check_file_attrs(module, changed, message)
    assert res_message == 'foo and ownership, perms or SE linux context changed'
    assert res_changed is True



# Generated at 2022-06-11 07:47:56.962113
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:48:05.050379
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_modlib_replace as amar
    import os.path
    import tempfile
    import shutil

    from ansible.module_utils import basic

    with tempfile.NamedTemporaryFile() as tf:
        tf.write(b"a\n"
                 b"b\n"
                 b"c\n")
        tf.flush()


# Generated at 2022-06-11 07:48:22.138616
# Unit test for function write_changes
def test_write_changes():
    """
    I know this is a module and not a function for testing but I just wanted to
    be sure.
    """
    assert 1 == 1




# Generated at 2022-06-11 07:48:29.241805
# Unit test for function write_changes
def test_write_changes():
    path = '/path/to/file'
    contents = 'some text'
    module = AnsibleModuleArgumentSpec()
    module.params = dict()
    module.run_command = lambda cmd: (0, '', '')
    module.tmpdir = '/tmp'
    module.atomic_move = lambda tmp_path, dest, unsafe_writes: None
    module.params['unsafe_writes'] = False
    write_changes(module, contents.encode(), path)



# Generated at 2022-06-11 07:48:41.629268
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:48:43.475097
# Unit test for function main
def test_main():
    raise NotImplementedError()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:48:55.220821
# Unit test for function check_file_attrs
def test_check_file_attrs():

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)


# Generated at 2022-06-11 07:49:04.875457
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Mock module
    class MockModule():
        def __init__(self):
            self.params = {
                'mode': '0777',
                'owner': 'user',
                'group': 'group',
            }
        def fail_json(self, *args, **kwargs):
            pass
        def load_file_common_arguments(self, params):
            return params
        def set_file_attributes_if_different(self, file_args, check_mode):
            for k in file_args.keys():
                if k in self.params:
                    if file_args[k] != self.params[k]:
                        return True
            return False

    changed = False
    message = ""
    module = MockModule()
    message, changed = check_file_attrs(module, changed, message)
   

# Generated at 2022-06-11 07:49:16.651858
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.params['path']='/tmp/test_replace'
    module.params['regexp']='test1'

# Generated at 2022-06-11 07:49:28.011546
# Unit test for function main
def test_main():
  from ansible.module_utils import basic
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils._text import to_text
  import os
  import shutil
  import tempfile

  class AnsibleExitJson(Exception):
    pass

  import sys

  class AnsibleFailJson(Exception):
    pass


# Generated at 2022-06-11 07:49:35.148716
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # Create the module object.
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            contents=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    # Create a temporary Directory
    module._tmpdir = tempfile.mkdtemp()

    # Create a empty file in that directory
    filename = module.params.get('path')
    fakefile = '%s/%s' % (module._tmpdir, filename)
    fd = os.open(fakefile, os.O_CREAT)
    os.close(fd)

    # Fill the file with contents
    contents

# Generated at 2022-06-11 07:49:36.718836
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:49:57.523239
# Unit test for function write_changes
def test_write_changes():
   print("test_write_changes")
   module = None
   contents = "test contents"
   path = "test.txt"
   open (path,"w").write(contents)
   write_changes(module, contents, path)
   assert open(path,"r").read() == contents



# Generated at 2022-06-11 07:50:07.679615
# Unit test for function main
def test_main():
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    fixture_data = {}

    for filename in os.listdir(fixtures_path):
        path = os.path.join(fixtures_path, filename)
        with open(path) as f:
            fixture_data[filename] = f.read()


# Generated at 2022-06-11 07:50:16.816316
# Unit test for function main
def test_main():
    rec = {
        dict(path='/etc/hosts', regexp='.*', replace='', after='', before='', backup=False, validate=None, encoding='utf-8'):
            dict(msg='', changed=False),
        dict(path='/etc/hosts', regexp='', replace='', after='', before='', backup=False, validate=None, encoding='utf-8'):
            dict(msg='', changed=False),
        dict(path='/etc/hosts', regexp='', replace='', after='', before='', backup=False, validate=None, encoding='utf-8'):
            dict(msg='', changed=False),
    }
    def custom_method(*args, **kwargs):
        pass

    def custom_check_file_attrs(*args, **kwargs):
        pass

# Generated at 2022-06-11 07:50:28.945929
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    module.params['module_name'] = 'ansible_test'
    module.params['module_args'] = 'test=test'
    module.params['module_name'] = 'ansible_test'
    module.params['module_args'] = 'test=test'
    module.params['path'] = 'filename'
    module.params['owner'] = 'nobody'
    module.params['group'] = 'nogroup'

    rc = None
    out = StringIO()
    err = StringIO()

# Generated at 2022-06-11 07:50:31.825970
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(ansible.module, changed, message) == ("", True)
    assert check_file_attrs(ansible.module, changed, message) == ("", False)
    assert check_file_attrs(ansible.module, changed, message) == ("and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-11 07:50:40.877168
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()


# Generated at 2022-06-11 07:50:53.488548
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    def load_fixture(name):
        path = os.path.join(os.path.dirname(__file__), 'fixtures', name)
        with open(path, 'rb') as f:
            return to_bytes(f.read())

    def run_module(module, arguments):

        set_module_args(arguments)
        basic._ANSIBLE_ARGS = to_bytes(json.dumps({'ANSIBLE_MODULE_ARGS': arguments}))


# Generated at 2022-06-11 07:50:54.223861
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-11 07:51:05.707165
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-11 07:51:17.002999
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO
    import sys

    def mock_module(run_command=None, atomic_move=None, noop_val=None):
        params = {
            'path': '/path/to/file',
            'validate': '/usr/sbin/apache2ctl -f %s -t',
            'unsafe_writes': True
        }
        checkmode = False
        if noop_val is not None:
            checkmode = True
            params['CHECKMODE'] = noop_val
        mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
        mod.params = params
        mod.check_mode = lambda: checkmode
        mod.run_command = lambda *args, **kwargs: run_command
       

# Generated at 2022-06-11 07:51:54.689083
# Unit test for function main
def test_main():
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-11 07:52:01.863210
# Unit test for function check_file_attrs
def test_check_file_attrs():
    '''Test check_file_attrs'''
    module = AnsibleModule({})
    module.run_command = lambda a: (0, '', '')
    module.atomic_move = lambda a, b: None
    module.set_file_attributes_if_different = lambda a, b: False
    message, changed =  check_file_attrs(module, False, '')
    assert message == ''
    assert not changed

    module.set_file_attributes_if_different = lambda a, b: True
    message, changed =  check_file_attrs(module, False, '')
    assert message == 'ownership, perms or SE linux context changed'
    assert changed



# Generated at 2022-06-11 07:52:02.647791
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-11 07:52:04.462660
# Unit test for function write_changes
def test_write_changes():
    assert to_text(write_changes('/test')) == to_text('test')



# Generated at 2022-06-11 07:52:13.187174
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.basic import AnsibleModule


    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'), #, aliases=['dest', 'destfile', 'name']),
            regexp=dict(required=True, type='str'),
            replace=dict(required=True, type='str'),
            def_file_attrs_mode=dict(required=False, type='str')
        ),
        # required_one_of=[['path', 'dest', 'destfile', 'name']],
        mutually_exclusive=[['path', 'dest', 'destfile', 'name']],
        no_log=True,
    )

    contents = b'This is a test'
    tmpfd, tmp

# Generated at 2022-06-11 07:52:23.501976
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args

# Generated at 2022-06-11 07:52:34.344998
# Unit test for function write_changes
def test_write_changes():
    mp = mock.mock_module.params
    mp['validate'] = '%s'
    mrcc = mock.mock_run_command
    mrcc.side_effect = [
        [(0, '', '')],
        [(0, '', '')],
    ]
    am = mock.mock_atomic_move
    module = mock

    # Should pass the first time (valid = True)
    write_changes(module, 'foo', 'path')
    module.assert_has_calls([
        mock.call.run_command('%s %s' % ('%s', 'path')),
        mock.call.atomic_move('tmpfile', 'path', unsafe_writes=False),
    ])
    # Should fail the second time (valid = False)

# Generated at 2022-06-11 07:52:43.564370
# Unit test for function write_changes
def test_write_changes():
    file_path = 'test/data/file'

    # create copy of file
    (rc, out, err) = module.run_command('cp %s %s.bak' % (file_path, file_path))

    # read contents and convert to text
    with open(file_path, 'rb') as file_contents:
        test_contents = to_text(file_contents.read(), errors='surrogate_or_strict')

    # call write_changes
    write_changes(module, test_contents, file_path)

    # diff files
    (rc, out, err) = module.run_command('diff %s %s' % (file_path, '%s.bak' % file_path))
    assert rc == 0, 'Write_changes did not create correct file'


# Generated at 2022-06-11 07:52:44.896142
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:52:55.366985
# Unit test for function main
def test_main():
    class AnsibleModuleMock(object):
        def __init__(self, params, result, changed):
            self.params = params
            self.result = result
            self.changed = changed
            self._diff=False
            
        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json was called")
    
        def exit_json(self, **kwargs):
            if kwargs != self.result:
                raise Exception("Unexpected result: %s, Expected: %s" % (str(kwargs), str(self.result)))
            if self.changed != kwargs['changed']:
                raise Exception("Unexpected change state: %s, Expected: %s" % (str(kwargs['changed']), str(self.changed)))
        

# Generated at 2022-06-11 07:53:53.081469
# Unit test for function check_file_attrs
def test_check_file_attrs():
    failed = True

# Generated at 2022-06-11 07:54:00.903530
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(argument_spec={'path': {'type': 'path',
                                                         'required': True},
                                               'owner': {'type': 'str'},
                                               'group': {'type': 'str'},
                                               'mode': {'type': 'str'},
                                               'seuser': {'type': 'str'},
                                               'serole': {'type': 'str'},
                                               'setype': {'type': 'str'},
                                               'selevel': {'type': 'str'},
                                               'unsafe_writes': {'type': 'bool'}})
    test_module.set_file_attributes_if_different = lambda x, y, z: True

# Generated at 2022-06-11 07:54:02.095414
# Unit test for function write_changes
def test_write_changes():
    pytest.fail('unimplemented')



# Generated at 2022-06-11 07:54:02.623550
# Unit test for function write_changes
def test_write_changes():
  pass


# Generated at 2022-06-11 07:54:10.371789
# Unit test for function write_changes
def test_write_changes():
    import os
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            contents=dict(required=True, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
            validate=dict(required=False, type='str')
        ),
        supports_check_mode=True
    )
    # create a temp file
    sample_file = 'tmp_sample.txt'
    sample_file_path = os.path.join(module.params['path'], sample_file)
    f = open(sample_file_path,'w')
    f.write(module.params['contents'])
    f.close()
    # change the contents of the file

# Generated at 2022-06-11 07:54:14.006480
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson) as exc:
        main()
    assert exc.value.args[0]['msg'] == "Path %s does not exist !"

# Test for AnsibleModule type

# Generated at 2022-06-11 07:54:15.897204
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs('a','b','c') == ('c and ownership, perms or SE linux context changed','b')


# Generated at 2022-06-11 07:54:23.046070
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import os
    import shutil
    import tempfile

    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            validate=dict(type='str'),
            others=dict(type='str'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    module.params['dest'] = os.path.join(tempfile.gettempdir(), 'test.txt')

# Generated at 2022-06-11 07:54:26.748116
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/test', 'validate': 'echo %s'})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: x
    contents = ''
    assert module.atomic_move(module.tmpdir + '/tmp', '/test', True) == '/test'


# Generated at 2022-06-11 07:54:36.275556
# Unit test for function write_changes
def test_write_changes():
    # Create a test directory
    import os
    import shutil
    import tempfile
    tmpdir = os.path.abspath(tempfile.mkdtemp())
    # Create a temp file
    tmpfd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write("Hello world")
    f.close()
    # Test function write_changes
    import sys
    import contextlib
    @contextlib.contextmanager
    def captured():
        from io import StringIO
        new_out = StringIO()
        old_out = sys.stdout
        try:
            sys.stdout = new_out
            yield sys.stdout
        finally:
            sys.stdout = old_out
    with captured() as s:
        test