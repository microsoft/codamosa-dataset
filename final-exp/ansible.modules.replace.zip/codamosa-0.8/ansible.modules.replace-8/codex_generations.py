

# Generated at 2022-06-11 07:46:48.175066
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'src': 'foo', 'dest': 'bar'})
    module.atomic_move = lambda src, dest: (src, dest)
    assert ('foo', 'bar') == write_changes(module, '', 'bar')


# Generated at 2022-06-11 07:46:56.340441
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            contents=dict(required=True, type='str'),
            validate=dict(required=False, type='str'),
        )
    )
    m.run_command = lambda cmd: (0, '', '')
    m.tmpdir = lambda: '/tmp'
    m.atomic_move = lambda src, dst, unsafe_writes=False: True
    write_changes(m, 'foobar', '/tmp/test')
    assert m.called


# Generated at 2022-06-11 07:47:08.244825
# Unit test for function main
def test_main():
    import mock
    import tempfile
    test_file_contents = b'''
# This is a comment
Hello world
foo=bar
'''
    expected_results = b'''
# This is a comment
Hello world
foo=Foo
'''
    test_file_name = tempfile.NamedTemporaryFile(mode='w').name
    test_file = open(test_file_name, 'wb+')
    test_file.write(test_file_contents)
    test_file.seek(0)
    test_file.close()
    m = mock.mock_open(read_data=test_file_contents)
    m.return_value.readlines.return_value = test_file_contents.splitlines()

# Generated at 2022-06-11 07:47:13.466781
# Unit test for function main
def test_main():
    import os
    import tempfile

    global module

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    module.exit_json(changed=False)


if __name__ == '__main__':
    main

# Generated at 2022-06-11 07:47:25.257329
# Unit test for function write_changes
def test_write_changes():
    import ansible.modules.files
    import random
    import os.path
    import shutil
    import tempfile
    import time

    dir_temp = tempfile.mkdtemp(prefix='ansible-tmp-')
    module = ansible.modules.files.Replace()

    random_bytes = os.urandom(random.randrange(1, 4096))
    fd, tmp_file = tempfile.mkstemp(dir=dir_temp)
    tmp_file_fd = os.fdopen(fd, 'wb')
    tmp_file_fd.write(random_bytes)
    tmp_file_fd.close()
    module.params['path'] = tmp_file
    module.params['_diff_peek'] = {'_ansible_no_log': True}  # Hack to keep diff mode working
    module

# Generated at 2022-06-11 07:47:30.808713
# Unit test for function write_changes
def test_write_changes():
    check_file = ''
    tmpfd, tmpfile = tempfile.mkstemp()
    f = os.fdopen(tmpfd, 'wb')
    f.write(check_file)
    f.close()

    validate = "%s"
    (rc, out, err) = module.run_command(validate % tmpfile)
    valid = rc == 0



# Generated at 2022-06-11 07:47:33.223600
# Unit test for function main
def test_main():
    # note that the following is not a complete test of main, but
    # just a sample of the logic in main.
    assert True


# Generated at 2022-06-11 07:47:36.226141
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    changed = True
    message = "Test message"
    assert check_file_attrs(module, changed, message) == ('Test message and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-11 07:47:46.332013
# Unit test for function write_changes
def test_write_changes():
    #############################################
    # patch module
    def fail_json(self, **args):
        return args

    def atomic_move(self, src, dest, **args):
        return src, dest

    def run_command(self, cmd):
        return 0, cmd, ''

    tmpdir = '/tmp'
    module = type('AnsibleModule',(),dict(
        fail_json=fail_json,
        atomic_move=atomic_move,
        run_command=run_command,
        tmpdir=tmpdir,
        params=dict(
            validate=None,
            unsafe_writes=False,
        ),
    ))()
    #############################################
    path = '/file'
    contents = 'content'

    expected = True, contents, path
    actual = write_changes(module, contents, path)


# Generated at 2022-06-11 07:47:58.424404
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec={
            'validate': {'type': 'str'},
            'path': {'type': 'str'},
            'unsafe_writes': {'type': 'bool', 'default': False},
        }
    )
    module.tmpdir = tempfile.mkdtemp()
    path = module.params.get('path', None)
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write("Some test text\n")
    f.close()
    module.atomic_move(tmpfile, path, unsafe_writes=True)
    test_contents = "Some text to replace the old contents"

# Generated at 2022-06-11 07:48:22.403941
# Unit test for function main
def test_main():
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    tmpdir = mkdtemp()
    path = tmpdir + '/testfile'
    open(path, 'w').write('bar')
    m = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    def test_with_params(params):
        m.params = params

# Generated at 2022-06-11 07:48:23.556405
# Unit test for function write_changes
def test_write_changes():
    #TODO: Add tests
    pass


# Generated at 2022-06-11 07:48:28.852474
# Unit test for function main
def test_main():
    path = os.path.dirname(os.path.realpath(__file__)) + '/testfile'
    module_args = {}

    my_m = AnsibleModule(
        argument_spec = module_args,
        supports_check_mode = True
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:48:37.683512
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    
    path = "/home/vinay/ansible/playbooks/tmp/test1.txt"
    encoding = module.params['encoding']
    res_

# Generated at 2022-06-11 07:48:40.477748
# Unit test for function main
def test_main():
    stdout_invoke, stderr_invoke, invoke_returncode = module_invoke('main()')

    assert_equals(stdout_invoke[0]["rc"], 0)



# Generated at 2022-06-11 07:48:41.804402
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:48:53.411328
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.basic
    # Load the module you want to test
    module = AnsibleModule(
        argument_spec=dict(
            # Arguments supported by set_file_attributes_if_different
            owner=dict(),
            group=dict(),
            mode=dict(),
            seuser=dict(),
            serole=dict(),
            selevel=dict(),
            setype=dict(),
            path=dict(),
            unsafe_writes=dict(type='bool', default=False),
            unsafe_writes_templates=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    ansible.module_utils.basic._ANSIBLE

# Generated at 2022-06-11 07:49:03.654034
# Unit test for function write_changes
def test_write_changes():
    class test_module:
        def __init__(self, params, tmpdir):
            self.params = params
            self.tmpdir = tmpdir
            self.fail_json_called = False
            self.fail_json_msg = ''
        def fail_json(self, msg):
            self.fail_json_called = True
            self.fail_json_msg = msg
    test_data = "Test test TEST"
    test_path = "/tmp/test_file.txt"
    test_module.atomic_move = lambda s, d, u: open(d, "wb").write(open(s).read())
    m = test_module({'unsafe_writes': True}, "/tmp/")
    write_changes(m, test_data, test_path)

# Generated at 2022-06-11 07:49:15.551225
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.params['path']='/etc/hosts'

# Generated at 2022-06-11 07:49:27.017060
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import datetime
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, src, dest, unsafe_writes):
            pass

        def load_file_common_arguments(self, params):
            return params

        def set_file_attributes_if_different(self, file_args, changed):
            return file_args['mode'] == 0o600

    params = dict(mode=0o600)
    t = TestModule(params)
    m, c = check_file_attrs(t, False, 'changed')
    assert c == True

# Generated at 2022-06-11 07:49:55.659303
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Note: function can not be tested, as module.set_file_attributes_if_different always
    # throws an error.
    pass



# Generated at 2022-06-11 07:50:01.734805
# Unit test for function write_changes
def test_write_changes():
    before = b'foo\nbar\nbaz\n'
    after = b'foo\nbar\nbaz\nquux\n'
    write_changes(b"quux", AnsibleModule(
        argument_spec={
            'dest': {'type': 'path', 'required': True},
        },
        supports_check_mode=True,
    ), b"/tmp/foobar")
    # TODO: Assert it worked



# Generated at 2022-06-11 07:50:05.800107
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'tmpdir':tempfile.gettempdir()})
    contents = b'test'
    path = tempfile.mkstemp()[1]
    write_changes(module, contents, path)
    assert to_text(contents) == to_text(open(path).read())



# Generated at 2022-06-11 07:50:08.818261
# Unit test for function main
def test_main():
  with pytest.raises(AnsibleFailJson):
    main()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 07:50:13.379114
# Unit test for function write_changes
def test_write_changes():
    module_arguments = dict(
        path="/test_path",
        contents="test contents",
        validate="/bin/true"
    )
    module = AnsibleModule(
        argument_spec=module_arguments,
        supports_check_mode=True
    )
    write_changes(module, "test contents", "/test_path")



# Generated at 2022-06-11 07:50:24.181197
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Check that when everything has changed, we catch it
    class FileModuleMock(object):
        def set_file_attributes_if_different(self, params, changed):
            return True

    module = FileModuleMock()
    message = ""
    changed = False
    module.params = test_parameters

    # Test that failure is caught
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"

    # Test that no change is caught
    message = ""
    changed = False
    module.params = test_parameters

    def set_file_attributes_if_different(params, changed):
        return False

    module.set_file_attributes_if_different = set_file_attributes_if

# Generated at 2022-06-11 07:50:36.611131
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.plugins.module_utils.common._collections_compat import Mock
    from ansible_collections.ansible.builtin.plugins.module_utils.common.text.converters import to_text

    input_file = "/opt/ansible/test"
    regexp = '^(#?)(ListenAddress[ ]+)[^\n]+$'
    replace = '#\g<1>\g<2>0.0.0.0'

    module = Mock(params={'path':input_file, 'regexp':regexp, 'replace':replace, 'backup':True})
    module.set_fs_attributes_if_different = Mock(return_value=True)
    module.check_mode = False


# Generated at 2022-06-11 07:50:43.298061
# Unit test for function write_changes
def test_write_changes():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic

    class TestModule(basic.AnsibleModule):
        pass

    module = TestModule()
    module.tmpdir = '/tmp'
    module.params = {}
    result = write_changes(module, b'test_string', '/tmp/write_changes')
    assert result == True


# Generated at 2022-06-11 07:50:50.437932
# Unit test for function write_changes
def test_write_changes():
    # Code to setup required module object
    m = AnsibleModule(
        argument_spec = dict(
            validate = dict(required=False, default=None),
            unsafe_writes = dict(required=False, default=False, type='bool'),
            tmpdir = dict(required=False, default=None)
        )
    )
    # Code to call function write_changes
    write_changes(m, 'hello world', '/tmp/test')



# Generated at 2022-06-11 07:50:55.030196
# Unit test for function write_changes
def test_write_changes():
  contents = "123456789a"
  tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
  f = os.fdopen(tmpfd, 'wb')
  f.write(contents)
  f.close()
  return tmpfile


# Generated at 2022-06-11 07:51:51.038682
# Unit test for function check_file_attrs
def test_check_file_attrs():

    import tempfile
    tmpfd, tmpfile = tempfile.mkstemp()
    f = os.fdopen(tmpfd, 'wb')
    f.write(b"test file data")
    f.close()

    set_result = True

# Generated at 2022-06-11 07:51:59.142028
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())
    message = 'hello world'

# Generated at 2022-06-11 07:52:07.579068
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path':dict(required=True)})
    module.params['owner'] = 'alice'
    module.params['group'] = 'alice'
    attrs = {
        'st_uid': 0,
        'st_gid': 0,
        'st_mode': 0o755,
        'secontext': 'unconfined_u:object_r:user_home_t:s0'
    }
    changed = False
    message = ''

    message, changed = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed is True
# end of Unit test for function check_file_attrs


# Generated at 2022-06-11 07:52:15.265495
# Unit test for function write_changes
def test_write_changes():
    new_file = "test_temporary_file"
    new_file_content = "test content"

# Generated at 2022-06-11 07:52:23.407586
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    path = '/tmp/file.txt'
    prev_state = 'default'
    file_args = {
        'path': path,
        'owner': 'root',
        'group': 'root',
        'mode': '0440',
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'var_log_t',
        'selevel': 's0',
    }
    valid, diffs = module.set_file_attributes_if_different(file_args, False, prev_state)
    assert valid



# Generated at 2022-06-11 07:52:34.255557
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:52:42.768079
# Unit test for function main
def test_main():
    path = os.path.realpath(__file__)
    content = open(path, 'rb').read()
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    assert main(module) == 'done'


# Generated at 2022-06-11 07:52:48.999031
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.tmpdir = tempfile.mkdtemp()
    obj = {}
    message = "ownership, perms or SE linux context changed"
    assert message == check_file_attrs(module, False, "ownership, perms or SE linux context changed")[0]
    obj.update({'changed': True})
    obj.update({'msg': message})
    module.exit_json(**obj)


# Generated at 2022-06-11 07:52:57.433595
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path', 'required': True},
        'follow': {'type': 'bool', 'required': False, 'default': False},
        'unsafe_writes': {'type': 'bool', 'required': False, 'default': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str'},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
        'validate': {'type': 'str'}
    })

    changed = False

# Generated at 2022-06-11 07:53:00.012882
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    write_changes(module, 'contents', '/tmp/test.txt')


# Generated at 2022-06-11 07:54:55.886433
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.tmpdir = 'tmp/ansible-tmp-1500555972.52-215006315714388'
    module.exit_json = lambda x:x
    module.set_file_attributes_if_different = lambda x, y:True
    changed_message, changed = check_file_attrs(module, '', '')
    assert changed == True
    assert changed_message == 'ownership, perms or SE linux context changed'
# End of unit test for function check_file_attrs


# Generated at 2022-06-11 07:55:03.375523
# Unit test for function write_changes
def test_write_changes():
    module=AnsibleModule(argument_spec={})
    path='tests/file'
    contents='# content of file'
    f=open(path,'w')
    f.write(contents)
    f.close()
    validate="grep content %s/file"
    write_changes(module, contents, path)
    f=open(path,'r')
    res=f.read()
    f.close()
    if res != contents:
        print("unit-test failed: write_changes: res:%s != contents:%s" % (res,contents))
    else:
        print("unit-test OK: write_changes")
    os.unlink(path)


# Generated at 2022-06-11 07:55:12.371754
# Unit test for function main
def test_main():
    ###################
    # Test fixture data
    ###################

    md = module_data()
    # Test parameters
    p = dict(
        path='/etc/sssd/sssd.conf',
        regexp='^(services\s*=\s*.*?\s*,\s*)(.*?)(\s*$)',
        replace='\g<1>fake_service\g<3>',
        validate='/bin/true',
        backup=0,
        encoding='utf-8',
    )
    # Test data

# Generated at 2022-06-11 07:55:20.069849
# Unit test for function main
def test_main():
    """Test case for function main"""
    # load_fixture should return a list of bytes
    from ansible.modules.files import replace as replace_module

    mock_module = MagicMock(spec=replace_module)
    mock_module.params = {'path': '/fake', 'regexp': 'lastname', 'replace': 'Smith', 'backup': False, 'follow': True}
    mock_module.check_mode = False
    mock_module.tmpdir = None
    mock_module.load_file_common_arguments = MagicMock(return_value={})
    mock_module.set_file_attributes_if_different = MagicMock(return_value=False)
    mock_module.backup_local = MagicMock(return_value="/fake.backup")
    mock_module.fail_json

# Generated at 2022-06-11 07:55:28.427634
# Unit test for function write_changes
def test_write_changes():
    # Get the dir with the real tmp files
    # Needed for Python 3.5 since it removes the file immediately after the fd is closed
    module = AnsibleModule(argument_spec={'check_mode': {'type': 'bool', 'default': False, 'required': False}, 'validate': {'type': 'str', 'default': None, 'required': False}, 'unsafe_writes': {'type': 'bool', 'default': False, 'required': False}})
    module.tmpdir = tempfile.mkdtemp()
    # Create tmp file
    fd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(fd, 'w')
    # Write something to it
    f.write('Hello World')
    f.close()
    # Create the backup directory
   

# Generated at 2022-06-11 07:55:37.524443
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    name = os.path.join(tmpdir, 'testfile')

    with open(name, 'wb') as f:
        f.write(b'#!/bin/sh\necho hello\n')

    os.chmod(name, 0o750)

    module = basic._AnsibleModule()
    module.fail_json = lambda self, **args: None
    module.set_file_attributes_if_different = lambda self, file_args, is_special: True

# Generated at 2022-06-11 07:55:46.076586
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            contents = dict(required=True),
        ),
        supports_check_mode=True,
    )
    tmpdir = tempfile.mkdtemp(prefix='ansible')
    module.tmpdir = tmpdir
    path = os.path.join(tmpdir, 'contents')
    contents = 'Hello, world!'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path) as f:
        assert f.read() == contents
    with open(path) as f:
        assert f.read() == contents
    os.unlink(path)
    os.rmdir(tmpdir)
    module.exit_json(changed=True)



# Generated at 2022-06-11 07:55:52.938981
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass
    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""

# Generated at 2022-06-11 07:56:00.285625
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            check_mode=dict(default=False, type='bool'),
            unsafe_writes=dict(default=False, type='bool', aliases=['unsafe'])
        )
    )
    module.run_command = lambda *args: (0, '')
    contents = 'xxxxx'
    path='/tmp/test'
    write_changes(module, contents, path)
    assert 'test' in os.listdir('/tmp/')



# Generated at 2022-06-11 07:56:09.454343
# Unit test for function check_file_attrs
def test_check_file_attrs():
    global AnsibleModule
    class FakeModule(object):
        params = {
            'backup': False,
            'unsafe_writes': False,
            'mode': None,
            'owner': None,
            'group': None,
            'seuser': None,
            'serole': None,
            'setype': None,
            'selevel': None,
        }

        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.fail_json = None
            self.set_file_attributes = None
            self.loads_file_common_arguments = None
