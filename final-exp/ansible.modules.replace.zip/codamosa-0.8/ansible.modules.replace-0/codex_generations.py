

# Generated at 2022-06-11 07:46:45.218527
# Unit test for function main
def test_main():
    # This code will be executed if this module is called directly
    # or the -m switch is given while running ansible-playbook
    print("Hello world")

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:46:54.544522
# Unit test for function main
def test_main():
    contents = '''LINE1
line2
Line3
Line4
Line5
Line6
Line7
Line8
Line9'''

    b_path = '/tmp/test_ansible.module_util.basic.ansible_test_file'
    b_path_bak = '/tmp/test_ansible.module_util.basic.ansible_test_file.%s.bak' % b_path
    f = open(b_path, 'w')
    try:
        f.write(contents)
    finally:
        f.close()
    # Uncomment the following line, if you want to test.

# Generated at 2022-06-11 07:47:01.939881
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({}, [])
    module.params['validate'] = None
    file = "/path/to/file"
    contents = to_bytes(u'''
        {
            "foo": "bar",
            "something": "different"
        }
        ''')
    write_changes(module, contents, file)
    with open(file, 'r') as f:
        assert f.read() == to_text(contents)



# Generated at 2022-06-11 07:47:06.306419
# Unit test for function main
def test_main():

    # This is a basic test for the main function
    # The test will ensure that the argument_spec is valid
    # and the main function will exit with proper arguments

    main()

# import module snippets
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:47:06.985567
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-11 07:47:16.111539
# Unit test for function main
def test_main():
    # Get a basic ansible module from ansible/test/lib
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:47:27.649940
# Unit test for function main
def test_main():
    arg_spec = dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    )
    mock_module = AnsibleModule(
        argument_spec=arg_spec,
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:47:29.599682
# Unit test for function write_changes
def test_write_changes():
    return None
test_write_changes.__doc__ = write_changes.__doc__


# Generated at 2022-06-11 07:47:38.519958
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.tmpdir = '/tmp'
            self.atomic_move = lambda x, y, z: None
        def fail_json(self, msg):
            raise Exception(msg)
        def load_file_common_arguments(self, params):
            return dict()
        def set_file_attributes_if_different(self, file_args, changed):
            return changed
    module = TestModule()
    assert check_file_attrs(module, False, "") == ('', False)
    assert check_file_attrs(module, True, "foo") == ('foo and ownership, perms or SE linux context changed', True)


# Generated at 2022-06-11 07:47:48.409051
# Unit test for function check_file_attrs

# Generated at 2022-06-11 07:48:05.746217
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.set_file_attributes_if_different = lambda x, y: True
            self.tmpdir = ''
            self.atomic_move = lambda x, y, z: True
            self.run_command = lambda x: [0, '', '']
        def fail_json(self, **kwargs):
            raise Exception
        def load_file_common_arguments(self, params):
            return params

    fake = FakeModule()
    assert 'changed' in check_file_attrs(fake, False, 'some message')



# Generated at 2022-06-11 07:48:07.794123
# Unit test for function check_file_attrs
def test_check_file_attrs():
    changed = False
    message = "Original message"
    return check_file_attrs(None, changed, message)


# Generated at 2022-06-11 07:48:09.087074
# Unit test for function check_file_attrs
def test_check_file_attrs():
    check_file_attrs(module, False, "Test")



# Generated at 2022-06-11 07:48:19.829284
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = dict(
        unsafe_writes=True,
        owner='root',
        group='root',
        mode='0600',
        path='/etc/hosts',
        seuser='system_u',
        serole='object_r',
        selevel='s0',
        setype='etc_t',
    )
    test_message = 'ownership, perms or SE linux context changed'
    assert check_file_attrs(test_module, False, '') == (test_message, True)
    test_message = 'ownership, perms or SE linux context changed'
    assert check_file_attrs(test_module, True, 'File changed') == (test_message, True)


# Generated at 2022-06-11 07:48:25.487467
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    message = "Test"
    changed = False
    message, changed = check_file_attrs(module, changed, message)
    changed == False
    module.exit_json(changed=changed, msg=message)
    module.fail_json(msg="Test failed")


# Generated at 2022-06-11 07:48:35.652337
# Unit test for function main
def test_main():
    import platform
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    if not get_bin_path('cp'):
        pytest.skip("cp not found")
    if not get_bin_path('grep'):
        pytest.skip("grep not found")
    if not get_bin_path('sed'):
        pytest.skip("sed not found")
    if not get_bin_path('command'):
        pytest.skip("command not found")
    if platform.system() == 'Windows':
        pytest.skip("Not applicable on Windows")
    if platform.system() == 'Solaris':
        pytest.skip("Not applicable on Solaris")

# Generated at 2022-06-11 07:48:44.239477
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    os.mkdir(module.params['path'])
    try:
        main()
    except:
        assert True
    finally:
        os.rmd

# Generated at 2022-06-11 07:48:55.668856
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.params = {}
    test_module.exit_json = lambda a: False
    test_module.fail_json = lambda a, b: True
    test_module.set_file_attributes_if_different = lambda a, b: False
    test_module.load_file_common_arguments = lambda a: {'owner': 'root', 'group': 'root', 'mode': '00600', 'selevel': None,
                                                        'serole': None, 'setype': None, 'seuser': None}
    returned_msg, a = check_file_attrs(test_module, False, "Test message")
    assert a is False and returned_msg == "Test message"
    test_module.set_file

# Generated at 2022-06-11 07:49:05.115600
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    module.run_command = MagicMock(return_value=(0,'','',''))
    module.atomic_move = MagicMock()
    module.exit_

# Generated at 2022-06-11 07:49:07.429959
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()
# [END OF FILE]

# Generated at 2022-06-11 07:49:41.223964
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    x = AnsibleModule( {'validate': "/usr/bin/test" } )
    fd, tmpf = tempfile.mkstemp()
    os.close(fd)
    fd, tmpm = tempfile.mkstemp()
    os.close(fd)
    fd, tmpp = tempfile.mkstemp()
    os.close(fd)
    open(tmpf,"w").write("plain text file\n")
    open(tmpm,"w").write("#!/bin/sh\nexit 1\n")
    open(tmpp,"w").write("#!/usr/bin/python\nprint(True)\n")
    os.rename(tmpp, tmpm)
    os.chmod(tmpm, 0o755)

# Generated at 2022-06-11 07:49:50.801114
# Unit test for function write_changes
def test_write_changes():
    from os.path import dirname, exists, isfile
    from os import listdir
    from tempfile import gettempdir

    import ansible.module_utils.basic

    # Create the test file
    filename = dirname(__file__) + "/tmp/testfile"
    fileobj = open(filename, "w")
    fileobj.write("This is the original content.")
    fileobj.close()

    # Create the module instance
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            contents = dict(default="", required=True)
        ),
        supports_check_mode=True,
    )

    # Force test module's tmpdir to point to test directory

# Generated at 2022-06-11 07:49:56.998043
# Unit test for function main
def test_main():
    a = None

    open('/tmp/test_main', 'w').write("""abc
abc
abc
abc
abc
abc
""")

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:50:07.085108
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            validate=dict(required=True)
        )
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    try:
        write_changes(test_module, b"test", "path")
    except Exception as ex:
        print(ex)
        if not isinstance(ex, AnsibleFailJson):
            raise
        assert ex.kwargs["msg"] == "validate must contain %s: %s" % ("%s", "validate")
    test_module.run_command = MagicMock(return_value=(1, '', ''))

# Generated at 2022-06-11 07:50:15.332608
# Unit test for function check_file_attrs
def test_check_file_attrs():
    a=False
    b=""
    file_args = {}
    file_args['path'] = '/tmp/mock'
    file_args['owner'] = 'mock'
    file_args['group'] = 'mock'
    file_args['mode'] = '0777'
    file_args['seuser'] = 'mock'
    file_args['serole'] = 'mock'
    file_args['setype'] = 'mock'
    file_args['selevel'] = 'mock'
    b, a = check_file_attrs(file_args, a, b)
    print(a)
    print(b)


# Generated at 2022-06-11 07:50:27.797179
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    res = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        supports_check_mode=True,
    )
    assert main() == (ansible.module_utils.basic.AnsibleModule.exit_json, {})



# Generated at 2022-06-11 07:50:33.033376
# Unit test for function write_changes
def test_write_changes():
  testmodule = AnsibleModule({
    'path': None,
    'tmpdir': None,
    'validate': None,
    'unsafe_writes': False,
    'backup': True
  }, check_invalid_arguments=False)
  testmodule.atomic_move = lambda path1, path2, unsafe_writes=False: None
  testmodule.run_command = lambda cmd: (0, '', '')
  test_content = "test content"
  test_path = "/test/path/test.file"
  write_changes(testmodule, test_content, test_path)
  assert testmodule.path == test_path


# Generated at 2022-06-11 07:50:41.518804
# Unit test for function check_file_attrs
def test_check_file_attrs():

    changed, message = False, "Initial message"
    module = AnsibleModule(argument_spec=dict(
        path=dict(required=True, type='path'),
        owner=dict(required=False),
        group=dict(required=False),
        mode=dict(required=False),
        seuser=dict(required=False),
        serole=dict(required=False),
        selevel=dict(required=False),
        setype=dict(required=False),
        unsafe_writes=dict(default=False, type='bool'),
    )
    )

# Generated at 2022-06-11 07:50:43.424565
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:50:51.508036
# Unit test for function write_changes
def test_write_changes():
    print('write_changes test')
    module = AnsibleModule({})
    test_path = 'test.txt'
    test_contents = 'test'
    write_changes(module, test_contents.encode(), test_path)
    assert os.path.exists(test_path)
    with open(test_path, 'r') as f:
        read_contents = f.read()
    assert read_contents == test_contents
    os.remove(test_path)


# Generated at 2022-06-11 07:51:48.125858
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import shutil
    import tempfile
    import os
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.response

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-11 07:51:53.303666
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(argument_spec = {'a' : dict()})

    def set_file_attributes_if_different(file_args, changed):
        return True

    module.set_file_attributes_if_different = set_file_attributes_if_different

    message, changed = check_file_attrs(module, changed=True, message="test")
    assert message == "test and ownership, perms or SE linux context changed"
    assert changed is True

# Generated at 2022-06-11 07:51:53.837469
# Unit test for function check_file_attrs
def test_check_file_attrs():
    return True



# Generated at 2022-06-11 07:52:02.043972
# Unit test for function main
def test_main():
    a = os.path.exists("temp")
    if a == True :
        shutil.rmtree("temp")
    os.mkdir("temp")
    f=open("temp/test.txt", "w+")
    f.write("test")
    f.close()
    p = dict(
        path='/root/temp/test.txt',
        regexp='^(.+)$',
        replace='1\1',
        backup=False,
        validate=None,
        encoding='utf-8',
    )

# Generated at 2022-06-11 07:52:10.962515
# Unit test for function check_file_attrs

# Generated at 2022-06-11 07:52:17.325255
# Unit test for function main
def test_main():
    os.mkdir('/etc/ansible')
    # Test case1
    play_source = dict(
        path='/etc/ansible/hosts',
        regexp='(\s+)old\.host\.name(\s+.*)?$',
        replace='\1new.host.name\2'
    )
    play = dict(
        path='/etc/ansible/hosts',
        regexp='(\s+)old\.host\.name(\s+.*)?$',
        replace='\1new.host.name\2',
        after='',
        before='',
        backup=False,
        validate='',
        encoding='utf-8'
    )
    set_module_args(play)
    module = AnsibleModule(argument_spec=play_source)

# Generated at 2022-06-11 07:52:28.190283
# Unit test for function main
def test_main():
    from ansible.modules.files.ansible_module_file import main
    from ansible.module_utils.basic import AnsibleModule

    path = '/home/jdoe/.ssh/known_hosts'
    regexp = '^old\.host\.name[^\n]*\n'
    contents = """127.0.0.1\tlocalhost
::1\tlocalhost ip6-localhost ip6-loopback
fe00::0\tip6-localnet
ff00::0\tip6-mcastprefix
ff02::1\tip6-allnodes
ff02::2\tip6-allrouters
ff02::3\tip6-allhosts
0:0:0:0:0:0:0:1\tlocalhost
localhost.localdomain"""
    replacements = 0
    changed = True

   

# Generated at 2022-06-11 07:52:38.163726
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str', choices=['a+rX', 'u+rw', 'u+rw,g+rX', 'u+rw,g-wx,o-rwx']),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            selevel=dict(type='str'),
            setype=dict(type='str'),
        )
    )

    module.run_command = MagicMock(return_value=0)
    tmpfd,

# Generated at 2022-06-11 07:52:47.286298
# Unit test for function check_file_attrs
def test_check_file_attrs():
    darwin_module = type('module', (object,), dict(params=dict(
        unsafe_writes=False,
        path='/tmp/foo',
        owner='root',
        group='wheel',
        mode='0755',
        seuser='_',
        serole='_',
        setype='_',
        selvl='_'),
        fail_json=lambda self, msg: self._fail_json(msg),
        set_file_attributes_if_different=lambda *args: True))
    changed = False
    message = ''

    message, changed = check_file_attrs(
        darwin_module,
        changed,
        message)

    assert message == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-11 07:52:53.532093
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            contents=dict(type='str')
        )
    )

    path = module.params.get('path')
    contents = module.params.get('contents')

    write_changes(module, contents, path)

    with open(path) as f:
        out = f.read()
    assert out == contents



# Generated at 2022-06-11 07:54:51.490007
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(argument_spec={
        'setype': dict(type='str', required=False, default=None),
    })
    m.params = dict(
        path='/test/testfile',
        seuser='test_user',
        serole='test_role',
        setype='test_type',
        selevel='test_level'
    )
    import os
    m.run_command = lambda x: (0, '', '')
    m.set_file_attributes_if_different = lambda x, y: (True, ['test_set_file_attributes_if_different'])
    m.get_bin_path = lambda x: '/bin/' + x
    m.file_exists = os.path.lexists

# Generated at 2022-06-11 07:55:00.143425
# Unit test for function main

# Generated at 2022-06-11 07:55:08.668923
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create test module and check_file_attr function
    module = AnsibleModule(argument_spec={})
    check_file_attr = globals()['check_file_attrs']

    # Create test params
    params = {
        "unsafe_writes": True,
        "owner": "root",
        "path": "/root/.ssh/id_rsa",
        "group": "root",
        "selevel": "s0",
        "serole": "object_r",
        "setype": "ssh_home_t",
        "seuser": "root",
        "mode": "0644"
    }
    module.params = params

    # Create test file attributes

# Generated at 2022-06-11 07:55:11.713980
# Unit test for function main
def test_main():
  path = 'path'
  encoding = 'encoding'
  pattern = 'pattern'
  replace = 'replace'
  with pytest.raises(Exception):
    main(path=path,encoding=encoding,pattern=pattern,replace=replace)

# Generated at 2022-06-11 07:55:19.389606
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import ansible_module_tmpdir
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import BytesIO


# Generated at 2022-06-11 07:55:22.587633
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, False, "") == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, "") == (" and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-11 07:55:26.091799
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.atomic_move = lambda tmpfile, path, unsafe_writes=True: (module.run_command("echo 1"))
    write_changes(module, 'test_write_changes', '/')
    assert(module.run_command("echo 1") == 0)


# Generated at 2022-06-11 07:55:30.270620
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'tmpdir': tempfile.gettempdir(),'unsafe_writes':False},check_invalid_arguments=False)
    module.atomic_move = lambda x, y, xxx: True
    contents = b'foo'
    path = b'/tmp/foo'
    write_changes(module, contents, path)


# Generated at 2022-06-11 07:55:39.276494
# Unit test for function check_file_attrs
def test_check_file_attrs():
  class module():
    def __init__(self):
      self.params = {'dest': '/tmp/test', 'owner': 'root', 'mode': '755'}
      self.fail_json = lambda err: False
      self.atomic_move = lambda src, dest, unsafe_writes: False
      self.run_command = lambda err: (0, 'test', '')
    def load_file_common_arguments(self, params):
      return params

# Generated at 2022-06-11 07:55:47.729624
# Unit test for function main
def test_main():
    contents = 'hello world\ngoodbye world'

    def _diff_lines(before_lines, after_lines):
        return str(before_lines) + '\n' + str(after_lines)

    def _diff_results(before, after):
        return _diff_lines(before.splitlines(1), after.splitlines(1))

    # State-less task test