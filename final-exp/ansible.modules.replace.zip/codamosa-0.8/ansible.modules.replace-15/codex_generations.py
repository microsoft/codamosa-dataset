

# Generated at 2022-06-11 07:46:53.350339
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']


# Generated at 2022-06-11 07:47:05.221102
# Unit test for function check_file_attrs
def test_check_file_attrs():
    def run(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary=False):
        if args[1] == '-i':
            return 0, '', ''
        else:
            return 0, '', ''

    def get_bin_path(self, arg, required=False, opt_dirs=[]):
        return arg

    def set_file_attributes_if_different(self, file_args, changed):
        return True

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module.run_command = run
    module.get_bin_path = get_bin_path
    module.set_file_attributes_if_different = set_file_attributes_if_different

    changed

# Generated at 2022-06-11 07:47:15.117519
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import pytest

    class AnsibleModuleStub:
        def __init__(self, *args, **kwargs):
            self.params = kwargs.copy()
            self.args = []
            self.res_args = dict()
            self._diff = False
            self.check_mode = False
            self.atomic_move = os.rename

        @property
        def unbuffered(self):
            return True

        def run_command(self, cmd):
            return (0, '', '')

        def exit_json(self, **kwargs):
            self.res_args = kwargs.copy()

        def fail_json(self, msg, **kwargs):
            raise pytest.fail


# Generated at 2022-06-11 07:47:16.818849
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-11 07:47:28.297568
# Unit test for function write_changes
def test_write_changes():
    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp'
            self.run_command = run_command
        def fail_json(self,msg):
            print(msg)
            raise AssertionError()
        def atomic_move(self,tmpfile,path,unsafe_writes):
            with open(path,'wb') as file:
                with open(tmpfile,'rb') as tmp:
                    file.write(tmp.read())
            return
    def run_command(cmd):
        return 0,'',''
    # Test a valid command
    module = MockAnsibleModule()
    module.params['validate'] = '/bin/true %s'
    module.params['unsafe_writes'] = None

# Generated at 2022-06-11 07:47:35.462399
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:47:36.033961
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-11 07:47:46.067469
# Unit test for function write_changes
def test_write_changes():
    class Module(object):
        def __init__(self, params):
            self.params = params
            self.tmpdir = os.path.join(os.getcwd(), 'tmp')

    module = Module({'validate':None, 'unsafe_writes':False})

    # create a file
    path = 'test_write_changes.tmp'
    contents = 'test_write_changes'
    tmpfile = open(os.path.join(module.tmpdir, path), 'w')
    tmpfile.write(contents)
    tmpfile.close()

    # change the contents of that file
    contents = 'something different'
    write_changes(module, contents, path)

    # read the file back and make sure the contents match what we changed to

# Generated at 2022-06-11 07:47:52.846159
# Unit test for function write_changes
def test_write_changes():
    test_path = "/tmp/test"
    contents = "Hello world"
    validate = "echo %s"
    file = open(test_path, "w")
    file.write(contents)
    file.close()
    fd, path = tempfile.mkstemp()
    test_module = AnsibleModule(add_file_common_args=True)
    test_module.params['validate'] = validate
    test_module.params['path'] = path
    test_module.params['unsafe_writes'] = True
    test_module.atomic_move = mock_atomic_move
    test_module.run_command = mock_run_command
    write_changes(test_module, contents, test_path)
    file = open(path, 'r')
    assert file.read() == contents
    file

# Generated at 2022-06-11 07:47:55.078626
# Unit test for function main
def test_main():
    code, output = testmod(subprocess_mock, ignore=['test_duplicate_keys'])
    print(output)
    assert code == 0

# Generated at 2022-06-11 07:48:17.420810
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params['regexp'] = 'old'
    module.params['replace'] = 'new'
    module.params['backup'] = False
    module.params['path'] = os.path.join(tempfile.gettempdir(), 'replace_test.txt')
    module.params['mode'] = '0600'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['unsafe_writes'] = False
    module.params['follow'] = False
    module.tmpdir = tempfile.gettempdir()

    contents = b'hello, world!'
    fh = open(module.params['path'], 'wb')
    fh.write(contents)


# Generated at 2022-06-11 07:48:29.241490
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.six import assertCountEqual

    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module = {
        "changed": True,
        "params": {"a": 1, "b": 2, "unsafe_writes": False},
        "set_file_attributes_if_different": lambda a, b : (a == {"a": 1, "b": 2})
    }

    # Test with 'changed' set
    message, changed = check_file_attrs(module, True, "")
    assert message == "ownership, perms or SE linux context changed"
    assert changed

    # Test with 'changed' unset
    message, changed = check_file_attrs(module, False, "")

# Generated at 2022-06-11 07:48:37.888271
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    m.params['after'] = to_

# Generated at 2022-06-11 07:48:38.484510
# Unit test for function write_changes
def test_write_changes():
  assert True


# Generated at 2022-06-11 07:48:49.229458
# Unit test for function main
def test_main():
    def mock_AnsibleModule(*args, **kwargs):
        params = kwargs.get('argument_spec', None)
        args = {
            'path': '/tmp/test',
            'regexp': '^foo$',
            'replace': 'bar',
            'after': '',
            'before': '',
            'backup': False,
            'encoding': 'utf-8',
        }

        for k, v in args.items():
            params[k]['default'] = v

        return AnsibleModule(*args, **kwargs)

    original_AnsibleModule = AnsibleModule

    f = open('/tmp/test', 'w')
    f.write('foo\n')
    f.close()
    module = mock_AnsibleModule()
    main()
    assert module._

# Generated at 2022-06-11 07:48:55.322730
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = "Test check_file_attrs"
    expected = "Test check_file_attrs and ownership, perms or SE linux context changed"
    module.set_file_attributes_if_different = lambda x: True
    result = check_file_attrs(module, changed, message)
    assert result == (expected, True)



# Generated at 2022-06-11 07:49:04.907189
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """Test function check_file_attrs"""
    from ansible_collections.ansible.builtin.plugins.module_utils import basic
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule

    mod = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    res = check_file_attrs(mod, True, "test message")
    assert res == ('test message and ownership, perms or SE linux context changed', True), res
    res = check_file_attrs(mod, False, "test message")
    assert res == ('test message and ownership, perms or SE linux context changed', True), res
    mod.params['unsafe_writes'] = True
    res = check_file_attrs(mod, False, "test message")
   

# Generated at 2022-06-11 07:49:11.685736
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'unsafe_writes': dict(required=False, type='bool', default=False)})
    path = '/path/to/file.conf'
    contents = '#foo\nbar'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert os.path.isfile(path)
    assert open(path, 'r').read() == contents



# Generated at 2022-06-11 07:49:23.400917
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import os.path
    import json
    import ansible.module_replace
    import ansible.module_utils.basic
    import ansible.module_utils.replace
    import ansible.module_utils.six
    import traceback
    tmpdir = tempfile.mkdtemp(prefix="ansible_tmpdir_")
    os.chdir(tmpdir)
    print("file name :" , tmpdir )
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes, to_text

# Generated at 2022-06-11 07:49:32.901776
# Unit test for function write_changes
def test_write_changes():
    # just test that the write method exists,
    # it's too difficult to test behavior that
    # is specific to the os
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.write_changes = write_changes
    path = '/tmp/test_write_changes'
    contents = b'hello world'
    module.tmpdir = '/tmp'

    class SubAnsibleModule(AnsibleModule):
        def atomic_move(self, *args, **kwargs):
            self.atomic_move_called = True
            self.atomic_move_args = args
            self.atomic_move_kwargs = kwargs

        def run_command(self, *args, **kwargs):
            self.run_command_called = True
            self.run_command_args = args
           

# Generated at 2022-06-11 07:50:10.491583
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(argument_spec={'path': dict(type='str', required=True),
                                     'owner': dict(type='str'),
                                     'group': dict(type='str'),
                                     'mode': dict(type='str'),
                                     'follow': dict(type='bool'),
                                     'selevel': dict(type='str'),
                                     'serole': dict(type='str'),
                                     'setype': dict(type='str'),
                                     'seuser': dict(type='str')})
    m.run_command = MagicMock(return_value=(0, '', ''))
    m.set_file_attributes_if_different = MagicMock(return_value=True)

# Generated at 2022-06-11 07:50:18.113244
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """This is the test for check_file_attrs."""

    # Create a mock module and check the file attributes
    _test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            state=dict(default='present', choices=['directory', 'absent', 'present'])
        ),
        supports_check_mode=True
    )
    some_file = "/etc/hosts"
    _message = "Changed file attributes"
    _changed = True
    _message, _changed = check_file_attrs(_test_module, _changed, _message)

    assert (_message == "Changed file attributes and ownership, perms or SE linux context changed") and (_changed is True)


# Generated at 2022-06-11 07:50:18.833158
# Unit test for function write_changes
def test_write_changes():
    assert False

# Generated at 2022-06-11 07:50:31.169914
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import inspect
    import os
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.tmpdir = mkdtemp(dir=os.getcwd(), prefix="test-test")

        def set_file_attributes_if_different(self, file_args, changed):
            return True

        def atomic_move(self, src, dest, unsafe_writes=False):
            pass


# Generated at 2022-06-11 07:50:32.688572
# Unit test for function write_changes
def test_write_changes():
    module = None
    write_changes(module, "contents", "test")



# Generated at 2022-06-11 07:50:41.351626
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-11 07:50:49.553343
# Unit test for function write_changes
def test_write_changes():

    from ansible.modules.files.replace import write_changes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text, to_bytes

    module = AnsibleModule({
        'path': '/tmp/some.file',
        'content': 'this is a test'
    })

    path = '/tmp/some.file'
    contents = b'this is a test\n'
    write_changes(module, contents, path)



# Generated at 2022-06-11 07:51:01.584854
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(
        src=dict(type='path'),
        dest=dict(type='path'),
        unsafe_writes=dict(type='bool', default=False),
    ))
    module.set_default_fs_attributes_if_unset = Mock()
    module.set_file_attributes_if_different = Mock(return_value=True)
    module.load_file_common_arguments = Mock(return_value=True)
    changed = False
    message = ''
    check_file_attrs(module, changed, message)
    assert module.set_file_attributes_if_different.call_count == 1
    assert message == "ownership, perms or SE linux context changed"
    assert changed



# Generated at 2022-06-11 07:51:08.188081
# Unit test for function write_changes
def test_write_changes():
  contents = b"test file contents"
  path = "/tmp/test_write_changes"
  f = open(path, "wb")
  f.write(contents)
  f.close()
  module = type('', (), {})()
  module.tmpdir = "/tmp"
  module.params = {'unsafe_writes': True}
  module.atomic_move = atomic_move
  module.run_command = lambda validate: (0, None, None)
  write_changes(module, contents, path)


# Generated at 2022-06-11 07:51:20.016445
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec = dict(path=dict(type='str', required=True), regexp=dict(type='str', required=True), replace=dict(type='str', required=True)))
    module.set_params(unsafe_writes=True)
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'ssh_home_t'
    module.params['selevel'] = 's0'
    module.params['dest'] = '/root/.ssh/known_hosts'

# Generated at 2022-06-11 07:52:27.864516
# Unit test for function write_changes
def test_write_changes():
    import os
    import pytest
    from ansible.module_utils._text import to_bytes
    tmpfd, tmpfile = tempfile.mkstemp(dir=os.getcwd())
    f = os.fdopen(tmpfd, 'wb')
    f.write(to_bytes('content'))
    f.close()
    assert os.path.exists(tmpfile)
    os.unlink(tmpfile)
    return True

# ===========================================
# Main control flow


# Generated at 2022-06-11 07:52:37.912377
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """Unit test for function check_file_attrs"""
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest

    from ansible.compat.tests.mock import MagicMock, patch

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
            by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
            by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an
            exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False

# Generated at 2022-06-11 07:52:44.415723
# Unit test for function main
def test_main():
    module_args = {}

    module_args.update(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
     )
    module_args.update(
        regexp=dict(type='str', required=True),
     )
    module_args.update(
        replace=dict(type='str', default=''),
     )
    module_args.update(
        after=dict(type='str'),
     )
    module_args.update(
        before=dict(type='str'),
     )
    module_args.update(
        backup=dict(type='bool', default=False),
     )
    module_args.update(
        validate=dict(type='str'),
     )

# Generated at 2022-06-11 07:52:52.656049
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
            argument_spec = dict(path=dict(),
                                 group=dict(),
                                 owner=dict(),
                                 mode=dict(),
                                 selevel=dict(),
                                 serole=dict(),
                                 setype=dict(),
                                 seuser=dict(),
                                 unsafe_writes=dict(type='bool', default=False)),
            supports_check_mode=True)
    changed, message = check_file_attrs(module, False, "")
    assert changed == False
    assert message == ""
# END Unit test


# Generated at 2022-06-11 07:52:59.425822
# Unit test for function write_changes
def test_write_changes():
  module=dict()
  module['tmpdir']='/tmp'
  module['run_command']=run_command_stub
  module['atomic_move']=atomic_move_stub
  module['params']=dict()
  module['params']['unsafe_writes']=False
  module['params']['validate']=None
  module['fail_json']=fail_json_stub
  write_changes(module, 'test', '/tmp/test')
# Unit test stubs

# Generated at 2022-06-11 07:53:09.639763
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
          regexp=dict(type='str', required=True),
          replace=dict(type='str', default=''),
          after=dict(type='str'),
          before=dict(type='str'),
          backup=dict(type='bool', default=False),
          validate=dict(type='str'),
          encoding=dict(type='str', default='utf-8'),
      ),
      add_file_common_args=True,
      supports_check_mode=True,
  )
  if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:53:20.458695
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-11 07:53:30.817985
# Unit test for function check_file_attrs
def test_check_file_attrs():
    msg = "ownership, perms or SE linux context changed"
    result = check_file_attrs(AnsibleModule(
        argument_spec={
            'path': {'type': 'path', 'required': True},
            'owner': {'type': 'str'},
            'group': {'type': 'str'},
            'mode': {'type': 'str'},
            'seuser': {'type': 'str'},
            'serole': {'type': 'str'},
            'setype': {'type': 'str'},
            'selevel': {'type': 'str'},
        },
        mutually_exclusive=[],
        required_together=[],
        supports_check_mode=False,
    ), True, "")
    assert result == (msg, True)



# Generated at 2022-06-11 07:53:40.630515
# Unit test for function write_changes
def test_write_changes():
    import pytest

    module = pytest.Mock()
    module.tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(module.tmpdir, 'foo')
    contents = b'bar'
    path = '/foo/bar'

    module.atomic_move = pytest.Mock(return_value=True)
    module.fail_json = pytest.Mock()
    module.run_command = pytest.Mock(return_value=(0, b'no error', ''))

    # Test with a validating command.
    module.params = {
        'validate': '/usr/bin/validate %s',
        'unsafe_writes': False,
    }

    write_changes(module, contents, path)


# Generated at 2022-06-11 07:53:43.591833
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, changed, message) == ("ownership, perms or SE linux context changed", True)#



# Generated at 2022-06-11 07:56:07.975704
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    assert check_file_attrs(module, False, "message")[0] == "message and ownership, perms or SE linux context changed"
    class TestModule2:
        def set_file_attributes_if_different(self, args, unsafe):
            return False
    module2 = TestModule2()
    assert check_file_attrs(module2, False, "message")[0] == "message"


# Generated at 2022-06-11 07:56:17.314618
# Unit test for function main
def test_main():
    # Check module arguments
    argument_spec = dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
    )
    # AnsibleModule class is required for unit test.
    module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)
    # Load module arguments.
    params = module.params
    # This is a sample code to unit test function main().
    # You can remove all codes below and start to write your own unit test.
    # Put test code here.



# Generated at 2022-06-11 07:56:27.240216
# Unit test for function write_changes
def test_write_changes():
  module = AnsibleModule(argument_spec=dict(
    tmpdir=dict(type='path'),
    validate=dict(type='str')
  ))
  module.tmpdir = '/tmp'
  module.validate = 'python -c'