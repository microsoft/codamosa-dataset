

# Generated at 2022-06-11 07:46:50.661948
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common_koji
    from ansible.module_utils import file_common
    from ansible.module_utils import basic
    from ansible.module_utils import file_common


# Generated at 2022-06-11 07:46:57.982063
# Unit test for function write_changes
def test_write_changes():
  module = AnsibleModule(
  argument_spec = dict(
    path = dict(type='str', required=True),
    contents = dict(type='str', required=True),
    backup = dict(type='bool', default=True),
    unsafe_writes = dict(type='bool', default=False)
  )
  )
  contents = u"hello world"
  path = u"temp.txt"
  write_changes(module, contents, path)
  return


# Generated at 2022-06-11 07:47:09.513919
# Unit test for function main

# Generated at 2022-06-11 07:47:10.197012
# Unit test for function main
def test_main():
    # Test normal condition
    assert 1 == 1 # test condition


# Generated at 2022-06-11 07:47:15.082441
# Unit test for function main
def test_main():
    request_mock = MagicMock(
        argspec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module_mock = MagicMock()

# Generated at 2022-06-11 07:47:27.143149
# Unit test for function write_changes
def test_write_changes():
    testcontents = "test"
    tmpfd, tmpfile = tempfile.mkstemp(dir="tmp")
    f = os.fdopen(tmpfd, 'wb')
    f.write(testcontents)
    f.close()

    # Test validation
    testfile = "%s"
    valid = "cat %s"
    invalid = "cat qwerty"
    contents = "test"
    module = AnsibleModule(
        argument_spec={
            'validate': dict(type='str', default=None),
            'path': dict(type='str', default=tmpfile),
            'unsafe_writes': dict(type='bool', default=False)
        },
        supports_check_mode=True
    )
    os.remove(tmpfile)

# Generated at 2022-06-11 07:47:31.772458
# Unit test for function write_changes
def test_write_changes():
  dummy_module = AnsibleModule(
      argument_spec=dict(
      )
    )
  contents = 'yes\nno\nmaybe\n'
  try:
    write_changes(dummy_module, contents, "xyz")
  except:
    assert False
  assert True



# Generated at 2022-06-11 07:47:36.026878
# Unit test for function write_changes
def test_write_changes():
    test_dict = dict(
        name='test_modulef',
        path='/tmp/test_modulef_tmpfile',
        tmpdir='/tmp'
    )
    test_module = AnsibleModule(argument_spec=test_dict, check_invalid_arguments=False)
    write_changes(test_module, b'', '/tmp/test_modulef_tmpfile')


# Generated at 2022-06-11 07:47:41.030281
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'path': '/tmp/foo',
        'unsafe_writes': False,
    }, supports_check_mode=False)
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    write_changes(module, b'abc', '/tmp/foo')



# Generated at 2022-06-11 07:47:50.035570
# Unit test for function check_file_attrs
def test_check_file_attrs():
    global f
    module = AnsibleModule(argument_spec={'path':dict()})
    test_dir = os.path.dirname(__file__) + '/tests/test_check_file_attrs/'
    tmpdir = os.path.dirname(__file__) + '/tests/tmp_check_file_attrs/'
    module.tmpdir = tmpdir
    os.makedirs(tmpdir)
    shutil.copyfile(test_dir + 'test_file', tmpdir + 'test_file')
    shutil.copyfile(test_dir + 'test_file', tmpdir + 'test_file2')
    os.chmod(tmpdir + 'test_file2', 0o644)
    # check ownership
    message = ""
    changed = False
    file_args = module.load_file

# Generated at 2022-06-11 07:48:11.673616
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {
                'path': '/path/to/file',
                'unsafe_writes': False,
                'owner': 'jdoe',
                'group': 'jdoe',
                'mode': '0600',
            }

        def fail_json(self, msg):
            raise(msg)

        def load_file_common_arguments(self, params):
            return {
                'path': params['path'],
                'follow': False,
                'mode': params['mode'],
                'owner': params['owner'],
                'group': params['group']
            }

        def set_file_attributes_if_different(self, file_args, changed):
            return changed

    module = TestAn

# Generated at 2022-06-11 07:48:17.318234
# Unit test for function write_changes
def test_write_changes():
    contents = "test string"
    tmpfile = "/tmp/test_file"

    module = AnsibleModule(argument_spec=dict())
    module.params = dict(validate=None)
    module.run_command = lambda validate:"/bin/true"
    module.atomic_move = lambda tmpfile, path, unsafe_writes: None

    write_changes(module, contents, tmpfile)



# Generated at 2022-06-11 07:48:29.188622
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Setup
    contents = b'foobar'
    after = b'bar'
    replace = b'baz'
    b_path = '/tmp/foo'
    path = to_text(b_path, errors='surrogate_or_strict')

    # Mock
    m_module = mock.MagicMock()
    m_module.fail_json.side_effect = AssertionError
    m_module.params = dict()
    m_module.params['path']=path

    m_module.check_mode = True
    m_module.no_log = False
    changed = False
    message = 'changed'

    def m_run_command(cmd):
        return 0, '', ''

    def m_atomic_move(a, b, *args, **kwargs):
        return


# Generated at 2022-06-11 07:48:31.734430
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, True, 'msg') == ('msg and ownership, perms or SE linux context changed', True)
test_check_file_attrs()



# Generated at 2022-06-11 07:48:40.075475
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['unsafe_writes'] = None
            self.tmpdir = None
        def fail_json(self, **kwargs): pass
        def atomic_move(self, src, dst, unsafe_writes=None): pass
        def load_file_common_arguments(self, params):
            return dict()
        def set_file_attributes_if_different(self, file_args, changed):
            return changed
    cm = MockModule()
    assert check_file_attrs(cm, False, '') == ('ownership, perms or SE linux context changed', True)

# Generated at 2022-06-11 07:48:40.598550
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-11 07:48:46.660856
# Unit test for function main
def test_main():
    with tempfile.TemporaryDirectory() as directory:
        path = os.path.join(directory, 'test')
        write_changes(path, "Hello world", "Hello universe")
        assert os.path.exists(path)
        with open(path, 'r') as myfile:
            assert myfile.read() == 'Hello universe'
            assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:48:58.228399
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path', 'required': True},
        'contents': {'type': 'str'},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': 'no'},
    })
    module.tmpdir = '/tmp/'
    if not module.params['path']:
        module.exit_json(changed=False, rc=0, stdout='', stderr='')
    rc = 0
    out = 'File successfully replaced'
    err = ''
    if module.params['validate']:
        (rc, out, err) = module.run_command('/bin/true', check_rc=True)

# Generated at 2022-06-11 07:48:59.479606
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())
    message = "Hello"
    check_file_attrs(module,True,message)


# Generated at 2022-06-11 07:49:02.438399
# Unit test for function write_changes
def test_write_changes():
    write_changes('/tmp/test', 'hi', '/tmp/test')
    assert open('/tmp/test', 'r').read() == 'hi'
    os.remove('/tmp/test')

# Generated at 2022-06-11 07:49:33.684778
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            regexp=dict(required=True, type='str'),
            replace=dict(default='', type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(default=False, type='bool'),
            validate=dict(type='str'),
            encoding=dict(default='utf-8', type='str'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    try:
        main()
    except SystemExit as exc:
        exception_message = str(exc)
        if exception_message != str(0):
            module.fail_json(msg=exception_message)
           

# Generated at 2022-06-11 07:49:44.403339
# Unit test for function write_changes
def test_write_changes():
    """
    Mock basic module to test write_changes
    """
    #
    # Globals
    #
    #
    # Test variables
    #
    CMD_RUN_SUCCESS = (0, 'stdout', 'stderr')
    CMD_RUN_FAILURE = (1, 'stdout', 'stderr')
    MODULE_FAIL_JSON = dict(failed=True, msg='failure message')
    PATH = '/path/to/file'
    EXISTING_FILE = 'existing file'
    NEW_FILE = 'new file'
    VALIDATE = 'validate %s'

    #
    # Mocks
    #
    class MockModule:
        """
        MockModule - generic mock for AnsibleModule
        """

# Generated at 2022-06-11 07:49:49.148822
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    contents = 'test string'
    path = '/tmp/test'
    write_changes(module, contents, path)
    f = open(path)
    new_contents = f.read()
    f.close()
    os.remove(path)
    assert new_contents == 'test string'


# Generated at 2022-06-11 07:49:52.219890
# Unit test for function write_changes
def test_write_changes():
    _write_changes = write_changes
    def write_changes(module, contents, path):
        print("WRITE: {0}".format(contents))
        print("FILE: {0}".format(path))
    globals()['write_changes'] = write_changes


# Generated at 2022-06-11 07:50:03.363379
# Unit test for function main
def test_main():
    test_file_contents = b"function testTestRegexp(){testRegexp 'this is a test' 't.*st';}"
    test_file = 'test_replace_file.sh'
    with open(test_file,'wb') as fh:
        fh.write(test_file_contents)
        fh.flush()
        os.fsync(fh.fileno())

    # add test to remove temporary file
    # Now load up the module and run it

# Generated at 2022-06-11 07:50:13.421578
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.run_command = lambda command: (0, None, None)
    contents = to_bytes(
        '127.0.0.1       localhost.localdomain localhost\n'
        '127.0.0.1       localhost4.localdomain4 localhost4\n'
        '::1             localhost.localdomain localhost\n'
        '::1             localhost6.localdomain6 localhost6\n'
    )
    path = '/etc/hosts'
    write_changes(module, contents, path)
    with open(path, 'r') as new_file:
        result = new_file.read()
    assert result == to_text(contents)

# Generated at 2022-06-11 07:50:20.598287
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-11 07:50:30.341272
# Unit test for function write_changes
def test_write_changes():
    class TestModule(object):
        tmpdir = '/tmp'
        params = {'validate': None, 'unsafe_writes': True}

        def run_command(self, cmd):
            print('run_command called')
            return (0, 'out', 'err')

        def atomic_move(self, src, dst):
            print('atomic_move called')
            return True

        def fail_json(self, msg):
            print('fail_json called')
            return True
    return write_changes(TestModule(), 'contents', 'path')

# =========================================
# main


# Generated at 2022-06-11 07:50:33.181528
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert 'ownership, perms or SE linux context changed' in check_file_attrs(AnsibleModule({'path': '/tmp/foo'}), False, "")



# Generated at 2022-06-11 07:50:41.592178
# Unit test for function write_changes
def test_write_changes():
    try:
        # Load the module
        from ansible.modules.files import replace as replace_module
        from ansible.module_utils.common._collections_compat import Mapping
        from ansible.module_utils._text import to_text
        from ansible.parsing.vault import VaultLib
    except ImportError:
        return

    # Create the module instance
    module = replace_module()
    # Create an empty arguments dict
    args = dict()
    # Create an expected text string
    expected = 'this is a test\n'

    # Create a temporary file
    (fd, path) = tempfile.mkstemp(dir=os.getcwd())
    # Write the expected file to disk
    os.write(fd, to_bytes(expected))
    # Close the tempfile

# Generated at 2022-06-11 07:51:25.816762
# Unit test for function write_changes

# Generated at 2022-06-11 07:51:28.516588
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, '') == ('ownership, perms or SE linux context changed', True)
    assert check_file_attrs(None, True, 'msg') == ('msg and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-11 07:51:32.483678
# Unit test for function write_changes
def test_write_changes():
    tmpfile = "/tmp/tmp-file"
    tmpdir = "/tmp"
    data = "asd"
    path = "/etc/test"
    module = AnsibleModule({'validate':None})
    module.tmpdir = tmpdir
    write_changes(module, data, path)
    f = open(path, "r")
    assert data == f.read()
    f.close()
    os.remove(path)



# Generated at 2022-06-11 07:51:42.413815
# Unit test for function main
def test_main():
    import ansible.module_replace
    contents = 'a'
    path = 'b'
    regexp = 'c'
    replace = 'd'
    after = 'e'
    before = 'f'
    backup = True
    validate = 'g'
    encoding = 'h'
    res_args = {}
    res_args['msg'] = 'a replacements made'
    res_args['diff'] = {}
    res_args['backup_file'] = 'b'
    res_args['changed'] = True
    backup_file_path = '/tmp/ansible-tmp-1540927707.42-26915733985343/backup/b'

# Generated at 2022-06-11 07:51:50.812714
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.plugins.modules import replace
    import sys
    import os
    import shutil
    import tempfile
    import filecmp

    sys.path.append(os.path.dirname(__file__))
    from test_utils import *

    testpath = '/tmp/fixme'
    testdirpath = '/tmp'
    testhomedir = '/tmp/home'
    testcontent = 'this is test content'
    testcontent_before = 'this is test content before'
    testcontent_after = 'this is test content after'
    testcontent_updated = 'updated test content'
    testcontent_updated2 = 'updated test content 2'
    testcontent_wrong = 'wrong test content'
    testcontent_backup = 'backup test content'
    testpattern

# Generated at 2022-06-11 07:51:55.712375
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            dest=dict(type='str', required=True),
            contents=dict(type='str', required=True),
            replace=dict(type='str', required=True),
        )
    )
    write_changes(module, module.params['contents'], module.params['path'])



# Generated at 2022-06-11 07:52:04.120246
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.dict_transformations import dict_merge
    from ansible.module_utils.common.collections import ImmutableDict
    class MyAnsibleModule(AnsibleModule):
        pass
    my_module = MyAnsibleModule(argument_spec={})

# Generated at 2022-06-11 07:52:12.812495
# Unit test for function write_changes

# Generated at 2022-06-11 07:52:18.167793
# Unit test for function check_file_attrs
def test_check_file_attrs():
    #test when attrs are different
    file_args = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644'
    }
    state_args = {'dest': '/tmp/test'}

    class FakeModule(object):
        params = {'unsafe_writes': True}
        no_log = False
        check_mode = False

        def fail_json(self, *args, **kwargs):
            pass

        def set_file_attributes_if_different(self, file_args, changed_when_different):
            return True

        def load_file_common_arguments(self, params, state_args=state_args):
            return file_args

    m = FakeModule()
    changed = True
    message

# Generated at 2022-06-11 07:52:29.203446
# Unit test for function main
def test_main():
    e1 = Exception("Test Error")
    with patch.object(AnsibleModule, "__init__", return_value=None) as am_mock:
        am = AnsibleModule(argument_spec=dict())
        am.fail_json = Mock(side_effect=e1)
        with patch.object(os.path, "exists", return_value=True):
            with patch.object(os, "path", new=dict(islink=Mock(return_value=False))):
                with patch.object(os, "path", new=dict(isdir=Mock(return_value=False))):
                    with patch.object(re, "compile", side_effect=Exception("Test Error")):
                        try:
                            main()
                        except Exception as e:
                            assert e == e1

# Generated at 2022-06-11 07:53:55.968414
# Unit test for function write_changes
def test_write_changes():
    write_changes(None, '','')


# Generated at 2022-06-11 07:54:01.737465
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='str', required=True),
        unsafe_writes=dict(type='bool', default=False),
        validate=dict(type='str', default='')))
    (fd,filename) = tempfile.mkstemp(dir='/tmp')
    f = os.fdopen(fd, 'w')
    f.write('testchanges')
    f.close()
    rc = module.run_command(['/bin/cat', filename])
    module.fail_json(msg='failed to validate: '
                         'rc:%s error:%s' % (rc, err))



# Generated at 2022-06-11 07:54:09.743381
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.module_utils.ansible_release
    import os.path
    import tempfile

    path = tempfile.mktemp()
    f = open(path, 'w')
    f.write('Example content')
    f.close()
    f = open(path, 'rb')
    f.read()
    f.close()


# Generated at 2022-06-11 07:54:18.884618
# Unit test for function main
def test_main():

#	print 'Unit test for function main is not implemented'
	module = AnsibleModule(
		argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
	)
	path =  module.params['path']

# Generated at 2022-06-11 07:54:25.070313
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    import json
    with open('test.json') as data_file:
        test_data = json.load(data_file)
        assert main() == test_

# Generated at 2022-06-11 07:54:32.228079
# Unit test for function check_file_attrs
def test_check_file_attrs():
    ''' mock class for AnsibleModule '''
    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.tmpdir = None

        def set_file_attributes_if_different(self, file_args, unsafe_writes):
            return True

        def load_file_common_arguments(self, params):
            return None

    module = AnsibleModule()
    assert isinstance(module, AnsibleModule)
    assert check_file_attrs(module, False, 'test') == ('test and ownership, perms or SE linux context changed', True)


# Generated at 2022-06-11 07:54:37.606558
# Unit test for function main
def test_main():
    argv = ["/etc/hosts","(\s+)old\.host\.name(\s+.*)?$","\1new.host.name\2","/home/jdoe/.ssh/known_hosts","^old\.host\.name[^\n]*\n","jdoe","jdoe","0644","/usr/sbin/apache2ctl -f %s -t","utf-8"]
    result = main(argv)



# Generated at 2022-06-11 07:54:43.073275
# Unit test for function write_changes
def test_write_changes():
    import ansible
    test_module = AnsibleModule(
    argument_spec={
        'path':{'required': True},
        'replace':{'required': True}
    }
    )
    test_module.path = '/home/nguyen/Desktop/ansible/test/test1'
    test_module.replace = '    '
    write_changes(test_module, contents=b'    ', path=test_module.path)


# Generated at 2022-06-11 07:54:46.249987
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.atomic_move = lambda x, y, z: None
    module.run_command = lambda x: (0, "", "")
    write_changes(module, b"abcde", "/tmp/abcde")


# Generated at 2022-06-11 07:54:53.390880
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            contents=dict(type='str', required=True),
            path=dict(type='str', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', default=False)
        ),
        supports_check_mode=False
    )
    module.atomic_move = lambda source, dest: None
    with tempfile.NamedTemporaryFile() as f:
        path = f.name
        write_changes(module, 'foo', path)
        with open(path) as f2:
            assert f2.read() == 'foo'

