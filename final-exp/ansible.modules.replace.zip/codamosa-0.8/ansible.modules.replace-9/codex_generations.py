

# Generated at 2022-06-11 07:46:51.085902
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.facts.system.selinux import get_selinux_current_context

# Generated at 2022-06-11 07:47:00.828237
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Importing modules locally inside the function,
    # so that they are not installed already
    import sys

    sys.modules['ansible'] = type('FakeAnsibleModule', (object,), {'__file__': __file__})
    sys.modules['ansible.module_utils.basic'] = type('FakeBasic', (object,), {'AnsibleModule': AnsibleModule})

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == ''



# Generated at 2022-06-11 07:47:11.902061
# Unit test for function check_file_attrs
def test_check_file_attrs():
    testmodule = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    testmodule.params = {
        'path': '/tmp/replace_module_test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'root',
        'serole': 'root',
        'setype': 'file',
        'backup': False
    }

    # Test that we don't change anything
    testmodule.set_file_attributes_if_different = lambda args, changed : False
    result = check_file_attrs(testmodule, False, "testing")
    assert result[1] == False
    assert result[0] == "testing"

    # Test that we change something
    testmodule.set_file_

# Generated at 2022-06-11 07:47:16.792459
# Unit test for function main
def test_main():
  path = 'test'
  regexp = 'test'
  replace = 'test'
  after = 'test'
  before = 'test'
  backup = 'test'
  validate = 'test'
  encoding = 'test'
  ansible_module = AnsibleModule(argument_spec=dict(path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']), regexp=dict(type='str', required=True), replace=dict(type='str', default=''), after=dict(type='str'), before=dict(type='str'), backup=dict(type='bool', default=False), validate=dict(type='str'), encoding=dict(type='str', default='utf-8')), add_file_common_args=True, supports_check_mode=True)
  res_args = dict

# Generated at 2022-06-11 07:47:28.297462
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module_args = dict(
        path="/tmp/test_file",
        regexp="test regexp",
        replace="test replace",
        owner="user1",
        group="group1",
        mode="644",
        seuser="sysadm_r",
        serole="object_r",
        selevel="s0:c0,c1",
        setype="port_type",
        unsafe_writes=False,
        backup=False
    )
    mock_module = AnsibleModule(
        argument_spec=module_args,
    )
    contents = b"test contents"
    mock_module.tmpdir = os.path.dirname(mock_module.params['path'])
    mock_module.atomic_move = lambda temp, path, unsafe_writes: None
    mock_module.params

# Generated at 2022-06-11 07:47:36.713310
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            contents=dict(required=True, type='str'),
            path=dict(required=True, type='str')))
    tempdir = os.path.join(tempfile.gettempdir(), module.params['path'])
    module.tmpdir = os.path.dirname(tempdir)
    contents = to_bytes(module.params['contents'])
    write_changes(module, contents, tempdir)
    assert contents == open(tempdir, 'rb').read()
    os.unlink(tempdir)



# Generated at 2022-06-11 07:47:46.767013
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import file
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.pycompat24 import unittest
    import shutil
    import sys
    import tempfile
    import traceback

    class NewModule(basic.AnsibleModule):
        """
        Override AnsibleModule to use the test_json utility
        """

        def __init__(self, *args, **kwargs):
            super(NewModule, self).__init__(*args, **kwargs)
            self.tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-11 07:47:53.250248
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    # Unit test for function write_changes
    contents = "test-content"
    path = "test-path"
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()
    module.atomic_move = mock_atomic_move = Mock()
    module.run_command = mock_run_command = Mock()
    module.fail_json = mock_fail_json = Mock()
    module.params = {'validate': None}
    # 1. No validate
    write_changes(module, contents, path)
    mock_atomic_move.assert_called_once_with(tmpfile, path, unsafe_writes=False)
    mock

# Generated at 2022-06-11 07:48:00.299567
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.modules.files import file

    module = file
    module.load_file_common_arguments = lambda args: args
    module.set_file_attributes_if_different = lambda args, check: args
    changed = False
    args = dict(
        owner="owner",
        group="group",
        mode="mode"
    )

    (message, changed) = check_file_attrs(module, changed, message)
    assert changed
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-11 07:48:03.290078
# Unit test for function write_changes
def test_write_changes():
    # Test setup
    import tempfile
    tmpfd, tmpfile = tempfile.mkstemp(dir='')
    # Test function
    write_changes(tmpfile, '')
    # Test cleanup
    # Does not work:
    # os.unlink(tmpfile)



# Generated at 2022-06-11 07:48:19.136200
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-11 07:48:30.604812
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(
        {
            'path': '/tmp/a.txt',
            'contents': 'abcd\n',
            'validate': '/bin/true',
        },
        check_invalid_arguments=False,
    )
    write_changes(m, b'abcd', '/tmp/a.txt')
    m = AnsibleModule(
        {
            'path': '/tmp/a.txt',
            'validate': '/bin/true',
        },
        check_invalid_arguments=False,
    )
    m.params['unsafe_writes'] = True
    m.tmpdir = '/tmp'
    write_changes(m, b'abcd', '/tmp/a.txt')

# Generated at 2022-06-11 07:48:38.992344
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'aliases': ['permissions']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
    })
    module.params.update({
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0666',
    })
    changed = False
    message = 'test_message'

# Generated at 2022-06-11 07:48:49.884424
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import json
    import pytest
    # Capture arguments for AnsibleModule 
    my_args = dict(path='/home/ansible/test_replace.txt',
                   regexp='some\\w+',
                   replace='test',
                   backup=False,
                   validate=None,
                   encoding='utf-8',)
    if os.path.exists('/home/ansible/test_replace.txt'):
        os.remove('/home/ansible/test_replace.txt')
    f= open('/home/ansible/test_replace.txt', 'w')
    f.write("some_word")
    f.close()
    my_args['_ansible_check_mode']=False

# Generated at 2022-06-11 07:48:57.733072
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.params = {
        'validate': '/usr/bin/grep "%s"',
        'unsafe_writes': False,
    }
    module.tmpdir = os.getcwd()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda src, dest, unsafe: True
    contents = ''
    path = '/tmp/no-such-file'
    write_changes(module, contents, path)



# Generated at 2022-06-11 07:49:05.193567
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec = {"path": {"type": "path"}, "owner": {"type": "str"},"group": {"type": "str"},"mode": {"type": "str"},"unsafe_writes": {"type": "bool"},"seuser": {"type": "str"},"serole": {"type": "str"},"setype": {"type": "str"},"selevel": {"type": "str"}})
    module.set_file_attributes_if_different = lambda x: True
    changed, message = check_file_attrs(module, True, "test")
    assert changed == True and message == "test and ownership, perms or SE linux context changed"


# Generated at 2022-06-11 07:49:17.003963
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Mock module
    module = AnsibleModule(
        argument_spec = dict(
            content = dict(type='str'),
            path = dict(type='path'),
            mode = dict(type='str'),
            owner = dict(type='str'),
            group = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            selevel = dict(type='str'),
            setype = dict(type='str'),
            unsafe_writes = dict(type='bool', default=False),
        )
    )
    # Mock module call
    changed = True
    message = "ownership, perms or SE linux context changed"
    msg, changed = check_file_attrs(module, changed, message)
    # Assertions

# Generated at 2022-06-11 07:49:28.242280
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'path': dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        'regexp': dict(type='str', required=True),
        'replace': dict(type='str', default=''),
        'after': dict(type='str'),
        'before': dict(type='str'),
        'backup': dict(type='bool', default=False),
        'validate': dict(type='str'),
        'encoding': dict(type='str', default='utf-8'),
    }, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, 'stdout', 'stderr'))

# Generated at 2022-06-11 07:49:38.217724
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    
    params = module.params
    path = params

# Generated at 2022-06-11 07:49:48.189622
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.check_mode = False
    module.tmpdir = temp

# Generated at 2022-06-11 07:50:27.462285
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.params = {'dest': '/root/testfile'}
    file_args = module.load_file_common_arguments(module.params)

    # Test with ownership, mode and selinux type change
    module.set_file_attributes_if_different(file_args, False)
    test_message, test_changed = check_file_attrs(module, True, "ownership, perms or SE linux context changed")
    assert test_message == 'ownership, perms or SE linux context changed and ownership, perms or SE linux context changed'
    assert test_changed

    # Test with no changes
    module.set_file_attributes_if_different(file_args, False)

# Generated at 2022-06-11 07:50:28.126742
# Unit test for function write_changes
def test_write_changes():
    return 0


# Generated at 2022-06-11 07:50:28.937602
# Unit test for function main
def test_main():
    replace = Replace()
    replace.main()

# Generated at 2022-06-11 07:50:32.218662
# Unit test for function main
def test_main():
    data = dict(
            path='/home/jdoe/.ssh/known_hosts',
            regexp='^old\\.host\\.name[^\n]*\n',
            owner='jdoe',
            group='jdoe',
            mode='0644',
                )
    check_file_attrs(data)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:50:41.117481
# Unit test for function write_changes
def test_write_changes():
    class fake_module:
        class fake_params:
            unsafe_writes= True
        tmpdir = ''
        params = fake_params()
        def atomic_move(self, tmpfile, path, unsafe_writes):
            if not os.path.exists(path):
                raise IOError('Error! File does not exist: %s' % path)

    def run_command(self, tmpfile):
        return (0, 'foo bar', 'error:baz')

    contents = 'foo bar baz'

    module = fake_module()
    path = '/foo'
    with tempfile.NamedTemporaryFile(dir=module.tmpdir) as tf:
        tf.write(to_bytes(contents))
        tf.flush()
        path = tf.name
    m = fake_module()
    setattr

# Generated at 2022-06-11 07:50:49.719495
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, "") == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(None, True, "") == ("and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(None, False, "test") == ("test ownership, perms or SE linux context changed", True)
    assert check_file_attrs(None, True, "test") == ("and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-11 07:50:57.181974
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({
            "path": "/tmp/foo",
            "mode": "0644",
        })
    # Changed
    message, changed = check_file_attrs(module, False, "")
    assert changed
    assert message == "ownership, perms or SE linux context changed"
    # Unchanged
    message, changed = check_file_attrs(module, False, "")
    assert not changed
    assert message == ""



# Generated at 2022-06-11 07:51:07.948103
# Unit test for function main
def test_main():
  from ansible.module_utils import basic
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.path import unfrackpath

  import mock

  m_module = mock.Mock(spec_set=basic.AnsibleModule)


  # Mock params
  m_module.params = {
    'replace': 'replace',
    'before': 'before',
    'path': '/path/to/file',
    'encoding': None,
    'unsafe_writes': True,
    'backup': False,
    'after': 'after',
    'regexp': 'regexp'
  }

  m_exists = mock.Mock(return_value=True)
  m_isfile = mock.Mock(return_value=False)
  m_

# Generated at 2022-06-11 07:51:19.721616
# Unit test for function main
def test_main():
    # Mock the module class to avoid exit_json to exit the script
    class AnsibleModuleMock(object):
        pass

    ansibleModuleMock = AnsibleModuleMock()
    ansibleModuleMock.path = "/tmp/ansible_test_file"
    ansibleModuleMock.after = ""
    ansibleModuleMock.before = ""
    ansibleModuleMock.regexp = "ec2-user"
    ansibleModuleMock.replace = "ansible"
    ansibleModuleMock.check_mode = False
    ansibleModuleMock.backup = False
    ansibleModuleMock.debug = False

    # Write test file
    open(ansibleModuleMock.path, "w").write("This file is for testing purposes.\n")

    # Subn returns the number of substitutions
   

# Generated at 2022-06-11 07:51:29.856734
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeModule(object):
        def __init__(self, *args):
            self.changed = False
            self.params = FakeParams(owner='jdoe', group='jdoe', mode=0o644)
            self.tmpdir = '/tmp'

        def fail_json(self, msg):
            raise AssertionError(msg)

        def atomic_move(self, source, dest, unsafe_writes):
            pass

        def set_file_attributes_if_different(self, file_args, changed):
            if file_args['owner'] == 'jdoe' and \
               file_args['group'] == 'jdoe' and \
               file_args['mode'] == '0644':
                return False
            else:
                return True


# Generated at 2022-06-11 07:52:39.148965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )





# Generated at 2022-06-11 07:52:48.359996
# Unit test for function main
def test_main():
    
    path = "/etc/hosts"
    params = dict(
        destfile=path,
        regexp='(\\s+)old\\.host\\.name(\\s+.*)?$',
        replace='\\1new.host.name\\2',
        validate=None,
        encoding=None,
    )
    with open(path, "r") as f:
        contents = f.read()
    mre = re.compile(params['regexp'])
    result = re.subn(mre, params['replace'], contents, 0)
    
    assert result[1] > 0
    assert contents != result[0]
    
test_main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:52:57.133414
# Unit test for function write_changes
def test_write_changes():
    raw_str = '#This is a test string\n#This is another test string\n'
    filename = 'testfile.txt'
    m = AnsibleModule(argument_spec=dict(path=dict(required=True),
                                         regexp=dict(required=True),
                                         replace=dict(required=False),
                                         backup=dict(required=False, default=False, type='bool'),
                                         after=dict(required=False, type='str'),
                                         before=dict(required=False, type='str'),
                                         unsafe_writes=dict(required=False, default=False, type='bool'),
                                         validate=dict(required=False)))

# Generated at 2022-06-11 07:53:08.277642
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:53:12.070528
# Unit test for function write_changes
def test_write_changes():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    m = AnsibleModule({})
    write_changes(m, 'foo'.encode(), 'bar')



# Generated at 2022-06-11 07:53:12.773605
# Unit test for function main
def test_main():
    assert 0 == 0

# Generated at 2022-06-11 07:53:22.376977
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes
    import os
    import shutil
    import tempfile

    fixture_file = 'fixtures/basic/sshd_config'
    fixture_data = None
    with open(fixture_file, 'rb') as f:
        fixture_data = to_bytes(f.read())

    (tmpfd, tmpfile) = tempfile.mkstemp(dir='/tmp')
    with os.fdopen(tmpfd, 'wb') as f:
        f.write(fixture_data)


# Generated at 2022-06-11 07:53:27.753752
# Unit test for function main
def test_main():
  module = AnsibleModule(argument_spec=dict(path=dict(required=True), regexp=dict(required=True), replace=dict()), supports_check_mode=True, mutually_exclusive=[], required_together=[])
  main()

# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:53:36.413230
# Unit test for function main
def test_main():
    open_name = 'ansible.module_utils.basic.AnsibleModule.open_set'
    os_path_isdir_name = 'os.path.isdir'
    os_path_exists_name = 'os.path.exists'
    f_write_name = 'ansible.module_utils.basic.AnsibleModule.atomic_move'
    module_fail_json_name = 'ansible.module_utils.basic.AnsibleModule.fail_json'

# Generated at 2022-06-11 07:53:43.272050
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            contents=dict(required=True)
        )
    )
    module.run_command = lambda *_, **__: (0, "", "")
    module.atomic_move = lambda *_, **__: None
    valid = write_changes(module, "{ 'key': 'value' }", "./dest_file")
    assert valid
    assert True



# Generated at 2022-06-11 07:55:55.986054
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = []
    message = []

    file_args = module.load_file_common_arguments(module.params)
    if module.set_file_attributes_if_different(file_args, False):

        if changed:
            message += " and "
        changed = True
        message += "ownership, perms or SE linux context changed"

    return message, changed



# Generated at 2022-06-11 07:56:06.217713
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(
        {'set_file_attributes_if_different': lambda x, y: True},
        True,
        'Foo'
        ) == ('Foo and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(
        {'set_file_attributes_if_different': lambda x, y: False},
        True,
        'Foo'
        ) == ('Foo', True)
    assert check_file_attrs(
        {'set_file_attributes_if_different': lambda x, y: True},
        False,
        'Foo'
        ) == ('ownership, perms or SE linux context changed', True)

# Generated at 2022-06-11 07:56:13.252507
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
    )
    path = '/tmp/testfile'
    tmpfile = '%s.%s' % (path, module.uuid)
    with open(tmpfile, 'wb') as f:
        f.write(b'\x1b')
    try:
        write_changes(module, b'\x1b', path)
        with open(path, 'rb') as f:
            assert f.read() == b'\x1b'
    finally:
        os.remove(tmpfile)
        os.remove(path)



# Generated at 2022-06-11 07:56:14.064753
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-11 07:56:23.812784
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.tmpdir = '/tmp'
    # check if file attributes are same and not changed
    changed = False
    message = ''
    file_args = {'dest':'/tmp/a',
                 'owner':'root',
                 'group':'root',
                 'mode':'0644'}
    module.set_file_attributes_if_different = lambda arg1,arg2: arg1 == file_args
    message, changed = check_file_attrs(module, changed, message)
    assert changed == False
    assert message == ''
    # check if file attributes are not same and changed
    message = ''
    changed = False