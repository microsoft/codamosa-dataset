

# Generated at 2022-06-23 04:08:45.698838
# Unit test for function main
def test_main():
    import tempfile
    res_args = dict()
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:08:54.652756
# Unit test for function main
def test_main():
    import os, sys, re
    sys.path.append(os.path.dirname(os.getcwd()))
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 04:08:56.179817
# Unit test for function main
def test_main():
  assert main() is None

if __name__ == '__main__':
  main()

# Generated at 2022-06-23 04:09:06.247431
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._collections_compat import OrderedDict
    import datetime
    import module_utils.basic


# Generated at 2022-06-23 04:09:16.000919
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'unsafe_writes': False})

    params = {'path': '/tmp/test.txt',
              'owner': 'root',
              'group': 'root',
              'mode': '0666'}

    message = "test"
    changed = False

    assert message == 'test'
    assert not changed
    r = check_file_attrs(module, changed, message)
    assert r[0] == 'test and ownership, perms or SE linux context changed'
    assert r[1] is True


# Generated at 2022-06-23 04:09:26.745791
# Unit test for function write_changes
def test_write_changes():
    flist = []
    m = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path', aliases=['dest', 'destfile', 'name']),
            encoding = dict(default='utf-8'),
            unsafe_writes = dict(type='bool', default=False),
            validate = dict(type='str'),
            backup = dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    class mock_stat:
        st_mode = 0o666
    m.stat = mock_stat
    m.tmpdir = '/tmp/test_replace'
    try:
        os.mkdir(m.tmpdir)
    except:
        pass
    m.run_command = lambda cmd: [0, '', '']
    path

# Generated at 2022-06-23 04:09:30.404527
# Unit test for function main
def test_main():
    pytest.main(['-vv',
                 '-s',
                 '--color=yes',
                 '--cov=ansible',
                 '--cov-report=term-missing',
                 'test/unittests_modules/test_ansible_builtin_replace.py::test_main'])


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:09:35.126709
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(1,1,'msg')==('msg and ownership, perms or SE linux context changed',True)
    assert check_file_attrs(None,None,'msg')==('msg',False)


# Generated at 2022-06-23 04:09:47.001394
# Unit test for function check_file_attrs
def test_check_file_attrs():
    fake_module = AnsibleModule(argument_spec=dict())
    fake_module.fail_json = lambda: None 
    fake_module.set_file_attributes_if_different = lambda foo, bar: True 
    fake_module.params = {
        "unsafe_writes": False,
        "dest": "fake_file",
        "path": "fake_file",
        "owner": "fake_owner",
        "group": "fake_group",
        "mode": "fake_mode",
        "selevel": "fake_selevel",
        "serole": "fake_serole",
        "setype": "fake_setype",
        "seuser": "fake_seuser" 
    }
    fake_module.load_file_common_arguments = lambda foo: fake_module.params


# Generated at 2022-06-23 04:09:58.975383
# Unit test for function main
def test_main():
    import os
    import pwd
    import grp
    import tempfile
    import shutil

    class AnsibleModule:
        def __init__(self, argument_spec=dict(), supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}
            self.check_mode = False
            self.tmpdir = tempfile.mkdtemp()

        def fail_json(self, rc=None, msg=None, **kwargs):
            self._rc = rc
            self._msg = msg if msg else 'Failed'
            self.exit_args = kwargs
            self.exit_args['failed'] = True

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

# Generated at 2022-06-23 04:10:13.733053
# Unit test for function check_file_attrs
def test_check_file_attrs():

    def test_check_file_attrs_args(module_args):
        module = DummyModule(module_args)
        changed = False
        message = "Replaced"

        changed, message = check_file_attrs(module, changed, message)

        assert module.params['owner'] == 'root'
        assert module.params['group'] == 'root'
        assert module.params['mode'] == '0755'
        assert module.params['seuser'] == 'system_u'
        assert module.params['serole'] == 'object_r'
        assert module.params['setype'] == 'ssh_home_t'
        assert module.params['selevel'] == 's0'
        assert changed
        assert message == "Replaced and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:10:18.613623
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-23 04:10:31.521768
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class MyModule():
        def __init__(self, params, tmpdir):
            self.params = params
            self.tmpdir = tmpdir
            self._changed = False
            self._diff = False

        def set_file_attributes_if_different(self, file_args, diff):
            self._changed = True
            self._diff = diff
            return True

        def load_file_common_arguments(self, module_parameters):
            return file_args
        def fail_json(self, **kwargs):
            print('FAIL: %s' % kwargs)
            exit(1)

    f = tempfile.NamedTemporaryFile(mode='w+b', bufsize=0, suffix='', prefix='test_replace_', dir='/tmp', delete=True)

# Generated at 2022-06-23 04:10:40.099344
# Unit test for function write_changes
def test_write_changes():
    """
    Unit tests for function write_changes
    """
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf8'),
        ),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )

    # Test that if the validate command exits non-zero, then the file is not
    # modified.
    module.params['validate'] = 'exit 0'
    module.tmpdir = '/tmp/ansible-test'

# Generated at 2022-06-23 04:10:52.782340
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    assert module
    #
    #  TODO
    #

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:10:54.835420
# Unit test for function main
def test_main():
    # Unit test for function main
    assert True


# Generated at 2022-06-23 04:11:05.035981
# Unit test for function write_changes
def test_write_changes():
    test_function = lambda a: a
    module_obj = MagicMock(
        run_command=MagicMock(
            return_value=(0, '', '')
        ),
        atomic_move=MagicMock(
            return_value=True
        ),
        fail_json=test_function,
    )
    args = dict( module=module_obj, contents=b'', path='/test/path/' )
    assert True is write_changes(**args)
    args = dict( module=module_obj, contents=b'', path='/test/path/', validate='success' )
    assert True is write_changes(**args)
    args = dict( module=module_obj, contents=b'', path='/test/path/', validate='failure', unsafe_writes=False )
    test_function

# Generated at 2022-06-23 04:11:17.781349
# Unit test for function write_changes
def test_write_changes():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import tempfile

    tmpfd, tmpfile = tempfile.mkstemp()
    f = os.fdopen(tmpfd, 'wb')
    f.close()

    contents = b"test contents"
    def do_write(path, contents):
        with open(path, 'wb') as f:
            f.write(contents)
    def fail_validate(path):
        return 1, "ERROR", ""

    class TestWriteChanges(unittest.TestCase):

        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    unsafe_writes=dict(type='bool', default=False),
                ),
            )

# Generated at 2022-06-23 04:11:21.361709
# Unit test for function main
def test_main():
    test_argv = ['replace','/etc/hosts','localhost','Nanlocalhost']
    test_result = main()
    print(test_result)

# Generated at 2022-06-23 04:11:31.041867
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path': '/path/to/file', 'changed': True, '_ansible_tmpdir': '/path/to/tmpdir'})
    module.set_file_common_attributes_if_different = Mock(return_value=True)
    assert check_file_attrs(module, True, "some message") == ("some message and ownership, perms or SE linux context changed", True)

    module.set_file_common_attributes_if_different = Mock(return_value=False)
    assert check_file_attrs(module, True, "some message") == ("some message", True)



# Generated at 2022-06-23 04:11:42.996166
# Unit test for function write_changes
def test_write_changes():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    class Test():
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
            self.fail_json = lambda x: self.err(x)
            self.run_command = lambda x: (0,'','')
            self.atomic_move = lambda x,y,z: shutil.move(x,y)
            self.exit_json = lambda *args, **kwargs: self.log("exit_json",args, kwargs)
            self.log = lambda *args, **kwargs: self.log("log",args, kwargs)
            self.err = lambda *args, **kwargs: self.log("err",args, kwargs)
            self

# Generated at 2022-06-23 04:11:53.210809
# Unit test for function main
def test_main():
    test_path = '/tmp/ansible_replace_dest_file'
    test_regex = 'START(.*)END'
    test_replace = 'STARTREPLACEMENTEND'
    test_contents = 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST\nSTARTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTENDTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST\nTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST\n'

# Generated at 2022-06-23 04:12:03.634840
# Unit test for function main
def test_main():
    obj = AnsibleModule([],{})
    obj.exit_json = exit_json
    obj.fail_json = fail_json
    exit_args = None
    fail_args = None
    atomic_move_args = None
    set_file_attributes_if_different_args = None

# Generated at 2022-06-23 04:12:07.817521
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert ('ownership changed', True) == check_file_attrs(None, False, 'ownership changed')
    assert ('ownership, perms or SE linux context changed', True) == check_file_attrs(None, True, 'ownership, perms or SE linux context changed')

# Generated at 2022-06-23 04:12:12.368038
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/etc/hosts', 'regexp': None}, supports_check_mode=True)
    module.run_command = lambda cmd: (0, '', '')
    module.atomic_move = lambda src, dest: None
    module.params['validate'] = None
    contents = to_bytes(u'foo')
    path = to_text(module.params['path'])
    write_changes(module, contents, path)


# Generated at 2022-06-23 04:12:16.784197
# Unit test for function main
def test_main():
	class module_Dummy:
		params = {}
		check_mode = True
		_diff = True
		def fail_json(self):
			print('This is a fail_json from mock module')

		def atomic_move(self):
			print('This is a atomic_move from mock module')

		def run_command(self):
			print('This is a run_command from mock module')
		
		def exit_json(self, **args):
			print('This is an exit_json from mock module')
	
		def backup_local(self):
			print('This is a backup_local from mock module')
	

# Generated at 2022-06-23 04:12:25.749756
# Unit test for function write_changes
def test_write_changes():
    contents=b"""some data here
some more data here
"""
    tmpfd, tmpfile = tempfile.mkstemp()
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()
    module = AnsibleModule(argument_spec=dict())
    module.atomic_move=lambda source, dest, unsafe_writes: True
    valid = module.run_command(validate % tmpfile)
    write_changes(module, contents, tmpfile)


# Generated at 2022-06-23 04:12:33.856392
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    test_params = dict(
        path=dict(type='str', required=True),
        owner=dict(type='str', required=False),
        group=dict(type='str', required=False),
        mode=dict(type='str', required=False),
        seuser=dict(type='str', default=None, aliases=['se_context_system']),
        serole=dict(type='str', default=None, aliases=['se_context_role']),
        selevel=dict(type='str', default=None, aliases=['se_context_level']),
        setype=dict(type='str', default=None, aliases=['se_context_type']),
    )


# Generated at 2022-06-23 04:12:39.201781
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert (check_file_attrs(AnsibleModule, True, '')) == ('ownership, perms or SE linux context changed', True)
    assert (check_file_attrs(AnsibleModule, False, '')) == ('ownership, perms or SE linux context changed', True)



# Generated at 2022-06-23 04:12:48.403868
# Unit test for function write_changes
def test_write_changes():
    '''
    Replace module function to write changes
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text, to_bytes
    module = AnsibleModule({"test": False})
    if not module.params['unsafe_writes']:
        module.modules_importers = [os]
    path = tempfile.mkstemp()
    testfile = os.fdopen(path[0], 'w')
    testfile.write(u"test file content")
    testfile.close()
    dummy_content = to_bytes("dummy_content")
    write_changes(module, dummy_content, path[1])
    f = open(path[1], 'r')
    read_content = f.read()
    f.close()


# Generated at 2022-06-23 04:12:55.122142
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.file import file_common_argument_spec
    import os
    import tempfile
    import json
    import pytest
    import shutil
    import sys

    with tempfile.NamedTemporaryFile() as f:
        os.chmod(f.name, 0o600)
        os.chown(f.name, os.geteuid(), os.getegid())

        data = to_bytes(u'\nafter=foo\nbar\nbefore=baz\n\n')
        f.write(data)
        f.flush()


# Generated at 2022-06-23 04:12:58.729250
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:13:06.162236
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            regexp = dict(required=True, type='str'),
        )
    )
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    message = "ownership, perms or SE linux context changed"
    assert message == check_file_attrs(module, True, "")[0]



# Generated at 2022-06-23 04:13:16.744574
# Unit test for function check_file_attrs
def test_check_file_attrs():
    path = './test'
    mode = 0o600
    module = AnsibleModule(argument_spec={})
    module.params['tmpdir']='/tmp/'
    module.params['unsafe_writes']=True
    module._handle_aliases()
    module.params['path'] = path
    module.params['owner'] = 'root'
    module.params['group'] = 'wheel'
    module.params['mode'] = mode
    changed = True
    message = ''
    msg, changed = check_file_attrs(module, changed, message)
    assert changed == True
    os.remove(path)


# Generated at 2022-06-23 04:13:25.528331
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(
        argument_spec = dict(
            path = dict(type='str'),
            contents = dict(type='str')
        )
    )

    t = AnsibleModule(
        argument_spec = dict(
            mode = dict(type='str')
        )
    )
    t.params.update({'mode' : '0644'})

    path = "/tmp/test_write_changes"
    try:
        os.remove(path)
    except OSError:
        pass

    m.params.update({
        'path' : path,
        'contents' : '{test}'
    })

    m.atomic_move = t.atomic_move
    m.tmpdir = '/tmp'

# Generated at 2022-06-23 04:13:36.755154
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    with open('/tmp/ansible_test_file', 'wb') as f:
        f.write(b"test1")

    params = module.params


# Generated at 2022-06-23 04:13:40.536309
# Unit test for function main
def test_main():
    params = {"replace":"replace_value","after":"after_value","path":"path_value","backup":"backup_value","before":"before_value","encoding":"encoding_value","regexp":{}}
    module_mock = AnsibleModule(params)
    assert False == module_main(module_mock)

# Generated at 2022-06-23 04:13:53.734783
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = DummyModule()

    module.params = {'path': os.path.join(os.path.dirname(__file__), 'test_files', 'change_attrs.txt')}

    assert not module.set_file_attributes_if_different({'path': module.params['path'], 'owner': 'test1', 'group': 'test1', 'mode': '0644'}, False)
    assert module.set_file_attributes_if_different({'path': module.params['path'], 'owner': 'test2', 'group': 'test2', 'mode': '0777'}, False)

    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == "ownership, perms or SE linux context changed"

# Generated at 2022-06-23 04:14:05.747084
# Unit test for function main
def test_main():

    # Test arguments and return values
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    assert module.params['path'] == '/etc/hosts'


# Generated at 2022-06-23 04:14:18.718428
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.atomic_move = True

# Generated at 2022-06-23 04:14:29.478204
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 04:14:34.575575
# Unit test for function main
def test_main():
    data = {
  "msg": "",
  "changed": True,
  "module_args": {
    "backup": False,
    "path": "/tmp/tempfile",
    "validate": "",
    "regexp": "test",
    "replace": "test"
  }
}
    from ansible.module_utils.basic import AnsibleModule

    #load the module

# Generated at 2022-06-23 04:14:43.972005
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path=dict(type='path')
        ),
    )

    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(b"Hello World!")
    f.close()

    write_changes(module, contents=b"Hello World!", path=tmpfile)
    with open(tmpfile, 'rb') as f:
        assert f.read() == b"Hello World!"



# Generated at 2022-06-23 04:14:55.751055
# Unit test for function main

# Generated at 2022-06-23 04:14:56.429619
# Unit test for function write_changes
def test_write_changes():
    return



# Generated at 2022-06-23 04:14:57.251842
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-23 04:15:02.999053
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='str'),
            contents = dict(type='str'),
        )
    )
    contents = b'asdf'
    path = module.params['path']
    write_changes(module, contents, path)
    with open(path, 'rb') as f:
        assert f.read() == b'asdf'
    os.remove(path)


# Generated at 2022-06-23 04:15:13.246520
# Unit test for function write_changes
def test_write_changes():
    diff = []

    def run_command_mock(command):
        return (0, 'success', '')

    def fail_json_mock(msg):
        diff.append(msg)

    def atomic_move_mock(tmpfile, path, unsafe_writes=None):
        dest = '/tmp/dest'
        if unsafe_writes:
            diff.append("mv %s %s" % (tmpfile, dest))
        else:
            diff.append("cp %s %s; rm %s" % (tmpfile, dest, tmpfile))

    module_args = dict(
        validate='/bin/ls %s'
    )


# Generated at 2022-06-23 04:15:25.624666
# Unit test for function write_changes
def test_write_changes():
    # create the module object with test params
    module = AnsibleModule({
        'path': '/tmp/test.txt',
        'content': 'testline1\ntestline2',
        'unsafe_writes': True,
        'validate': None
    })
    # create test file
    f = open(module.params['path'], "w")
    f.write(module.params['content'])
    f.close()
    # write_changes will overwrite the test file with a real replace module
    write_changes(module, b'replacewiththis', module.params['path'])
    # open file and read its contents to confirm the above wrote correctly
    f = open(module.params['path'], 'rb')
    assert f.read().decode('utf-8') == 'replacewiththis'


# Generated at 2022-06-23 04:15:40.689769
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())

    class FakeModule(object):
        def __init__(self):
            self.changed = False
            self.params = dict()
        def fail_json(self, **kwargs): pass
        def exit_json(self, **kwargs): pass
        def set_file_attributes_if_different(self,file_args,is_diff):
            return True
        def load_file_common_arguments(self, params):
            return dict()
    module = FakeModule()
    changed = True
    message = "foo"
    ret = check_file_attrs(module,changed,message)
    assert "ownership, perms or SE linux context changed" in ret[0]
    assert changed
    assert message not in ret[0]


# Generated at 2022-06-23 04:15:41.981847
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:15:55.195334
# Unit test for function main
def test_main():
    # Attempt to work from a temporary directory. If it fails, then just
    # don't run these tests, as they require some additional test setup.
    try:
        tmp_dir_name = tempfile.mkdtemp()
        tmp_file_name = os.path.join(tmp_dir_name, 'test.txt')
        with open(tmp_file_name, 'w') as tmp_file:
            tmp_file.write('Hello, world!')
    except:
        return


# Generated at 2022-06-23 04:16:07.829191
# Unit test for function main
def test_main():
    path = '/etc/hosts'
    regexp = '(\s+)old\.host\.name(\s+.*)?$'
    replace = '\1'
    after = '\1new.host.name\2'
    before = '\1new.host.name\2'
    backup = False
    validate = '/usr/sbin/apache2ctl -f %s -t'
    encoding = 'utf-8'

# Generated at 2022-06-23 04:16:12.696828
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule({}, check_mode=True)
    changed = False
    message = ""
    test_message, test_changed = check_file_attrs(module, changed, message)
    assert test_changed == False
    assert test_message == ""



# Generated at 2022-06-23 04:16:15.495477
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:16:27.239249
# Unit test for function main
def test_main():

    class MockRegex(object):
        def __init__(self):
            self.group = 'subsection'
            self.groups = ['subsection']
            self.start = lambda x: (0,0)
            self.end = lambda x: (0,0)

    class MockPattern(object):
        def __init__(self, pattern):
            self.pattern = pattern

        def search(self, contents):
            match = MockRegex()
            if self.pattern == 'name':
                return match
            else:
                return False

    class MockContents(object):
        def __init__(self, replace, section):
            self.replace = replace
            self.section = section

        def subn(self, regex, replace, section, count):
            if replace:
                return (replace, 0)

# Generated at 2022-06-23 04:16:38.948248
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
                'path': dict(required=True),
                'validate': dict(),
                'unsafe_writes': dict(default=False, type='bool')
            })
    import shutil
    # Create a temporary directory to hold the temporary files and
    # ensure it is automatically removed upon exit
    test_dir = tempfile.mkdtemp()
    module.tmpdir = test_dir
    atexit.register(shutil.rmtree, test_dir)
    # Create a file for testing.
    test_path = os.path.join(test_dir, 'ansible-test')
    with open(test_path, 'w') as output:
        output.write('Test string is here.\n')
        output.write('And another one.\n')
    # Storing

# Generated at 2022-06-23 04:16:39.613696
# Unit test for function write_changes
def test_write_changes():
    assert True


# Generated at 2022-06-23 04:16:52.688716
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.fail_json = lambda a: a
    # Set some attributes
    module.params['owner'] = 'foo'
    module.params['mode'] = '0755'
    module.params['seuser'] = 'fooseuser'
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert 'ownership, perms or SE linux context changed' in message
    changed = False
    message = ''
    # Now reset the attributes
    module.params['owner'] = None
    module.params['mode'] = None
    module.params['seuser'] = None
    message, changed = check_file_attrs(module, changed, message)
   

# Generated at 2022-06-23 04:17:00.996193
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    import os
    import tempfile

# Generated at 2022-06-23 04:17:03.215095
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(0,0) == (0,0)


# Generated at 2022-06-23 04:17:10.854276
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils import tmp_path
    module = AnsibleModule({'path': '/tmp/path'})
    module.tmpdir = tmp_path()
    path = '/tmp/path'
    contents = b'This is a text'
    write_changes(module, contents, path)
    f = open(path, 'r')
    assert f.read() == 'This is a text'
    os.remove(path)


# Generated at 2022-06-23 04:17:24.326293
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import io
    import sys
    import pytest
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import StringIO
    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'testfile')
    f = open(path, 'wb')
    f.write(to_bytes(u"word:word:word\nword:word:THISISATEST\nword:word:word"))
    f.close()
    f = open(path, 'r')
    contents = f.read()
    f.close()
    _umask = os.umask(0)

# Generated at 2022-06-23 04:17:34.998981
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            validate=dict(type='str'),
        )
    )
    fd, path = tempfile.mkstemp(dir=module.tmpdir)
    os.close(fd)
    f = open(path, 'w')
    f.write('# before\n')
    f.write('before\n')
    f.write('# after\n')
    f.write('after\n')
    f.write('# before\n')
    f.write('before\n')
    f.write('# after\n')
    f.close()

    # Just to test if tmpfile is created, opened and written
    contents = 'New contents'

# Generated at 2022-06-23 04:17:46.924766
# Unit test for function main

# Generated at 2022-06-23 04:17:54.468508
# Unit test for function write_changes
def test_write_changes():
    module = FakeModule()
    assert module.params['unsafe_writes'] == True
    path = '/tmp/test_replace_module'
    test_data = b"This is test data"
    contents = b"This is test data"
    write_changes(module, contents, path)
    with open(path, 'rb') as f:
        assert test_data == f.read()
    os.remove(path)



# Generated at 2022-06-23 04:18:06.610168
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule

  module = AnsibleModule(
      argument_spec=dict(
          path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
          regexp=dict(type='str', required=True),
          replace=dict(type='str', default=''),
          after=dict(type='str'),
          before=dict(type='str'),
          backup=dict(type='bool', default=False),
          validate=dict(type='str'),
          encoding=dict(type='str', default='utf-8'),
      ),
      supports_check_mode=True,
  )
  try:
    main()
  except:
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:18:17.058916
# Unit test for function write_changes
def test_write_changes():

    module = AnsibleModule(
        argument_spec=dict(
            valid=dict(type='bool'),
            contents=dict(type='str', default='foo'),
            path=dict(type='path')
        ),
        supports_check_mode=True
    )

    # Expected call.
    write_changes(module, to_bytes(module.params['contents']), module.params['path'])
    # Expected to fail.
    module.params['valid'] = True
    module.params['contents'] = 'foobar'
    res = write_changes(module, to_bytes(module.params['contents']), module.params['path'])
    assert res is None

# ===========================================
# Module execution.
#



# Generated at 2022-06-23 04:18:19.056211
# Unit test for function write_changes
def test_write_changes():
    #TODO: Test this when someone figures out how to test this
    return


# Generated at 2022-06-23 04:18:28.731360
# Unit test for function main
def test_main():
  with patch.dict(platform.__dict__, {'system':Mock(return_value='Darwin'), 'machine':Mock(return_value='x86_64')}):
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule.run_command = Mock(return_value=(0, '', ''))
    AnsibleModule.atomic_move = Mock(return_value=None)
    AnsibleModule.load_file_common_arguments = Mock(return_value={})
    AnsibleModule.set_file_attributes_if_different = Mock(return_value=None)
    AnsibleModule.backup_local = Mock(return_value=None)
    main()

if __name__ == '__main__':
  main()

# Generated at 2022-06-23 04:18:32.149143
# Unit test for function main
def test_main():
  print("TESTING: function main")
  try:
    main()
  except SystemExit as e:
    print("ERROR: raised an exception: {}".format(e))
    assert False


# Generated at 2022-06-23 04:18:45.102045
# Unit test for function write_changes
def test_write_changes():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = None

        def fail_json(self, **kwargs):
            pass

        def atomic_move(self, src, dest, **kwargs):
            pass

        def run_command(self, cmd):
            return [0, '', '']


    class tmpfile(object):
        def __init__(self, name):
            self.name = name

        def close(self):
            pass

    m = TestModule()

    def mkstemp(dir):
        return tmpfile(dir)

    m.tmpdir = 'tmpdir'
    setattr(tempfile, 'mkstemp', mkstemp)
    write_changes(m, 'Hello', 'path')

