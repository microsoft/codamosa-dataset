

# Generated at 2022-06-23 04:08:45.842363
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    
    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after']

# Generated at 2022-06-23 04:08:52.213920
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule({})
    tmpfd, tmpfile = tempfile.mkstemp()
    contents = b"Hello World"
    os.write(tmpfd, contents)
    os.close(tmpfd)
    valid = not False
    write_changes(test_module, b"Hello World", tmpfile)
    with open(tmpfile, 'r') as f:
        assert f.read() == "Hello World"
    os.unlink(tmpfile)


# Generated at 2022-06-23 04:09:03.888510
# Unit test for function write_changes
def test_write_changes():
    class MyModule:
        def __init__(self):
            self.params = {}
        def run_command(self, *args, **kwargs):
            self.rc = kwargs.get("rc", 0)
            self.out = kwargs.get("out", b"")
            self.err = kwargs.get("err", b"")
            return (self.rc, self.out, self.err)
        def fail_json(self, **kwargs):
            self.msg = kwargs.get("msg", None)
            self.failed = True
    # writing to a file should succeed
    contents = b"test"
    tmpfd, tmpfile = tempfile.mkstemp(dir=".")
    path = tmpfile + "-dest"

# Generated at 2022-06-23 04:09:10.689982
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    ansible_spec = basic._ANSIBLE_ARGS
    content = b'192.168.1.1\thostname\n192.168.1.12\tmyhostname\n192.168.1.2\thostname2\n'
    expected = b'192.168.1.1\thostname\n192.168.1.12\tnew.hostname\n192.168.1.2\thostname2\n'
    regexp = r'(\s+)hostname(\s+.*)?$'
    replace = r'\1new.hostname\2'
    file_args = dict(path='/hosts', regexp=regexp, replace=replace)

# Generated at 2022-06-23 04:09:22.427486
# Unit test for function main
def test_main():
    path = '/path/to/file'
    after = 'After expression'
    before = 'Before expression'
    replace = ''
    regexp = 'regexp'
    valid = True
    content = 'invalid content'


# Generated at 2022-06-23 04:09:30.976814
# Unit test for function main
def test_main():
    import ansible.utils.template as template
    import ansible.utils.data as data
    import os
    import sys

    test_spec = dict(
        path=dict(type='path', required=True),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
    )


# Generated at 2022-06-23 04:09:36.916484
# Unit test for function check_file_attrs
def test_check_file_attrs():
   assert check_file_attrs(module, False, "")[0] == "ownership, perms or SE linux context changed"
   assert check_file_attrs(module, True, "")[0] == " and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:09:47.548241
# Unit test for function write_changes
def test_write_changes():
    def test_open(filename, flags):
        print(filename)
        print(flags)
        return "test"
    def test_close(handle):
        print(handle)
    def test_write(handle, content):
        print(handle)
        print(content)
    def test_run_command(command):
        print(command)
        return ("0", "test", "test")
    def test_atomic_move(filename, destination, unsafe_writes):
        print(filename)
        print(destination)
        print(unsafe_writes)
    module = AnsibleModule(argument_spec = dict())
    module.open = test_open
    module.close = test_close
    module.write = test_write
    module.run_command = test_run_command
    module.atomic_move = test

# Generated at 2022-06-23 04:09:57.189371
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'path': '/path/to/file',
        'contents': 'line1\nline2\n',
        'validate': None
    })
    module._debug = False
    module.atomic_move = lambda a, b, **kwargs: None
    module.tmpdir = os.path.realpath(os.path.curdir)
    module.params['unsafe_writes'] = True
    write_changes(module, b'newcontents', '/path/to/file')
    assert module.params['contents'] == b'newcontents'



# Generated at 2022-06-23 04:10:03.860719
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='str',required=True),
            dest=dict(type='str',required=True),
            b_content=dict(type='str',required=True),
            r_content=dict(type='str',required=True),
            validate=dict(type='str',required=True),
            backup=dict(type='bool',required=False),
            tmpdir=dict(type='str',required=True),
            unsafe_writes=dict(type='bool',required=False),
        ),
        supports_check_mode=False,
        no_log=False
    )
    try:
        write_changes(module,'there are comments in this file','comment.txt')
    except:
        assert True

# Generated at 2022-06-23 04:10:18.256097
# Unit test for function check_file_attrs
def test_check_file_attrs():

    import ansible.module_utils.common.collections
    import ansible.module_utils.common.async_wrapper

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            selevel = dict(type='str'),
        ),
        supports_check_mode=True,
    )

    ansible_module_list = ['ansible.module_utils.common.collections',
                           'ansible.module_utils.common.async_wrapper']


# Generated at 2022-06-23 04:10:31.313099
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    if not basic.HAS_RE:
        return

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    path = 'test/files/replace_test_files/replace_test_file'
    tmp_path = path + '.tmp'

    # Get original file content

# Generated at 2022-06-23 04:10:33.846875
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs("a", "b", "c") == ("c and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 04:10:41.200877
# Unit test for function check_file_attrs
def test_check_file_attrs():
    inform = dict()
    inform['path'] = '/etc/ansible/test_file'
    inform['changed'] = True
    inform['msg'] = 'test message'
    module = AnsibleModule(argument_spec=dict())
    inform['file_args'] = module.load_file_common_arguments(inform)
    inform['file_args']['path'] = inform['path']
    inform['file_args']['attributes'] = {'size': 42}
    module.set_file_attributes_if_different = Mock(return_value=True)
    inform['msg'], inform['changed'] = check_file_attrs(module, inform['changed'], inform['msg'])

# Generated at 2022-06-23 04:10:49.297022
# Unit test for function main

# Generated at 2022-06-23 04:11:01.602792
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    import tempfile
    import shutil
    dirpath = tempfile.mkdtemp()
    filepath = os.path.join(dirpath, 'testfile')
    open(filepath, 'a').close()
    contents = 'Hello world'
    def atomic_move(src, dest, unsafe_writes=False):
        new_file = open(dest, 'w')
        new_file.write(contents)
        new_file.close()

# Generated at 2022-06-23 04:11:14.986835
# Unit test for function main
def test_main():
    import sys, os, shutil, tempfile
    from ansible.module_utils._text import to_bytes
    os.environ['ANSIBLE_REPLACECONTENT_REMOTE_TMP'] = u''
    ansible_module_args = {}
    ansible_module_args['path'] = tempfile.mktemp()
    ansible_module_args['regexp'] = u'^[^#]*NULL'
    ansible_module_args['replace'] = u''
    ansible_module_args['backup'] = False
    ansible_module_args['validate'] = u''
    ansible_module = AnsibleModule(ansible_module_args)

# Generated at 2022-06-23 04:11:20.728908
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    rval = check_file_attrs(module, True, "Failed!")
    assert rval[0] == "Failed! and ownership, perms or SE linux context changed"
    assert rval[1] is True


# Generated at 2022-06-23 04:11:29.937799
# Unit test for function check_file_attrs
def test_check_file_attrs():
    mod_params = dict(
        path='/path/to/file'
    )
    mod = AnsibleModule(argument_spec=mod_params)

    set_file_attributes_if_different = lambda x: True
    mod.set_file_attributes_if_different = set_file_attributes_if_different
    mod_params['unsafe_writes'] = False

    msg, changed = check_file_attrs(mod, False, '')
    assert changed
    assert msg == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-23 04:11:41.091032
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import BytesIO
    module = AnsibleModule(argument_spec={'backup': {'type': 'bool', 'default': False},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})

    b_path = to_bytes('/tmp/test')
    b_contents = to_bytes('replacement')
    b_validate = to_bytes(None)

    class AtomicMove:
        def __init__(self):
            self.move_src = None
            self.move_dest = None
            self.unsafe_writes = None


# Generated at 2022-06-23 04:11:48.644065
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.parsing import from_yaml
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import urllib_error
    from ansible.module_utils.urls import urllib_parse
    from ansible.module_utils.urls import urllib_request
    from ansible.module_utils.urls import urllib_response
    from ansible.module_utils.urls import urllib_robotparser
    from ansible.module_utils.urls import ur

# Generated at 2022-06-23 04:12:01.144470
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            selevel=dict(type='str'),
            setype=dict(type='str'),
            unsafe_writes=dict(type='bool', default='no'),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 04:12:07.843935
# Unit test for function main
def test_main():
    # setup
    import sys
    import inspect
    import tempfile
    import shutil
    import os
    argv = sys.argv
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    if PY2:
        MODULE = 'ansible.module_utils.basic'
    else:
        MODULE = 'ansible.module_utils.basic3'

    module_args = dict(
        path=tempfile.mktemp(dir='/tmp'),
        regexp='^(.+)$',
    )

# Generated at 2022-06-23 04:12:19.607062
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class MockModule(object):
        pass
    module = MockModule()
    module.set_file_attributes_if_different = lambda x, y=False: True
    module.load_file_common_arguments = lambda self: {'src': 'src', 'dest': 'dest'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-23 04:12:29.993997
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['owner'] = 'foo'
    module.params['group'] = 'bar'
    module.params['mode'] = '0755'
    module.params['seuser'] = 'foobar_user'
    module.params['serole'] = 'foobar_role'
    module.params['setype'] = 'foobar_type'

    (rc, stdout, stderr) = module.run_command(["getfacl","-R","/home/foobar/test_file"])
    assert rc == 0
    assert "user:foo" in stdout
    assert "role:foobar_role" in stdout
    assert "type:foobar_type" in stdout


# Generated at 2022-06-23 04:12:36.415014
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path=dict(required=True, type='str'),
            contents=dict(required=True, type='str'),
        ),
    )

    # This module is mostly  just a wrapper around a
    # python module. Difficult to test
    # TODO: Add unit tests
    pass



# Generated at 2022-06-23 04:12:46.612162
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    args = dict(
        path="/tmp/foo.txt",
        owner="root",
        group="root"
        )
    module = AnsibleModule(
        argument_spec = args,
        supports_check_mode = True
        )
    try:
        os.remove("/tmp/foo.txt")
    except:
        pass
    module.atomic_move("/etc/hosts", "/tmp/foo.txt")
    changed, message = False, ""
    message, changed = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True
    try:
        os.remove("/tmp/foo.txt")
    except:
        pass


# Generated at 2022-06-23 04:12:56.131684
# Unit test for function main
def test_main():
    module = AnsibleModule(
    argument_spec=dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    ),
    add_file_common_args=True,
    supports_check_mode=True,
)
    file_path = module.params['path']
    encoding = module.params['encoding']
    res_args = dict()

    params['after'] = to_text

# Generated at 2022-06-23 04:13:06.963665
# Unit test for function write_changes
def test_write_changes():
    DATA = "This is the test data"
    module = AnsibleModule(
        argument_spec=dict(
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    path = os.path.join(module.tmpdir, 'test_write')
    with open(path, 'w') as uninit:
        uninit.write(DATA)

    write_changes(module, b'This has changed', path)
    assert os.path.getsize(path) == 18
    with open(path, 'r') as f:
        test_data = to_text(f.read())

    assert test_data == 'This has changed'



# Generated at 2022-06-23 04:13:20.306780
# Unit test for function check_file_attrs

# Generated at 2022-06-23 04:13:24.593435
# Unit test for function main
def test_main():
    req_args = {
      "path": "/etc/ansible/ansible.cfg",
      "regexp": "\b(localhost)(\d*)\b",
      "replace": "\1\2.localdomain\2 \1\2"
    }
    module = AnsibleModule(argument_spec={})
    module.params = req_args
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:13:38.071142
# Unit test for function main
def test_main():
    o = Replace()
    o.module.params = {
        'after': '',
        'backup': False,
        'before': '',
        'dest': '/etc/hosts',
        'replace': '',
        'path': '/etc/hosts',
        'regexp': ''
    }
    with pytest.raises(AnsibleFailJson) as exception:
       o.main()
    assert exception.value.args[0]['msg'] == "regexp is required"
    o.module.params = {
        'after': '',
        'backup': False,
        'before': '',
        'dest': '/etc/hosts',
        'replace': '',
        'path': '',
        'regexp': 'string'
    }

# Generated at 2022-06-23 04:13:46.350109
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    #Unit test for reference
    class module_ret():
        rc = None
        stdout = None
        stderr = None


# Generated at 2022-06-23 04:13:57.618847
# Unit test for function main
def test_main():
    is_darwin = False
    # Test the base case with all default values

# Generated at 2022-06-23 04:14:08.228508
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # we need a module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert module

    # the default return is changed is 0
    assert check_file_attrs(module, None, None) == ('ownership, perms or SE linux context changed', True)

    # if we pass it changed, it remains unchanged
    assert check_file_attrs(module, True, None) == ('ownership, perms or SE linux context changed', True)
    assert check_file_attrs(module, False, None) == ('ownership, perms or SE linux context changed', True)
    assert check_file_attrs(module, False, "some message") == ('some message and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(module, True, "some message")

# Generated at 2022-06-23 04:14:09.220521
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert 0 == 0


# Generated at 2022-06-23 04:14:13.627561
# Unit test for function write_changes
def test_write_changes():
    # Test to make sure that the function fails when validation fails
    assert(False == True)  # include a failed test
    assert (True == False)  # include a passing test


# Generated at 2022-06-23 04:14:24.117716
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:14:24.753447
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:14:37.465424
# Unit test for function main
def test_main():
    # Create a mock module object
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        supports_check_mode=True,
    )

    # Mock module inputs

# Generated at 2022-06-23 04:14:44.676648
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    changed = False
    message = "foo changed"
    module.params['path'] = '/tmp/foo'
    try:
        message, changed = check_file_attrs(module, changed, message)
    except SystemExit:
        pass
    assert changed == True and message == "foo changed and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:14:49.927516
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None,"No changes","No changes") == ("No changes",False)
    assert check_file_attrs(None,"Changed","Changed") == ("Changed and ownership, perms or SE linux context changed",True)


# Generated at 2022-06-23 04:14:55.446424
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = {}
    module.params = {
        'path': '/some/file',
        'mode': '0444',
    }
    module.set_file_attributes_if_different = lambda a, b: b
    changed, message = check_file_attrs(module, True, 'the file changed')
    assert changed
    assert message == 'the file changed and ownership, perms or SE linux context changed'

# Execute the main program

# Generated at 2022-06-23 04:15:06.780829
# Unit test for function main
def test_main():
  from ansible.module_utils import basic
  from ansible.module_utils._text import to_bytes
  from ansible.compat.tests import unittest
  import os
  from ansible.module_utils._text import to_text
  import json

  class AnsibleExitJson(Exception):
    pass

  class AnsibleFailJson(Exception):
    pass

  def exit_json(*args, **kwargs):
      if 'changed' not in kwargs:
          kwargs['changed'] = False
      raise AnsibleExitJson(kwargs)

  def fail_json(*args, **kwargs):
      kwargs['failed'] = True
      raise AnsibleFailJson(kwargs)


# Generated at 2022-06-23 04:15:10.241989
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    message = 'Odd'
    ret = check_file_attrs(module, False, message)
    assert ret == (message, False)
    assert type(ret) is tuple


# Generated at 2022-06-23 04:15:21.057158
# Unit test for function main
def test_main():
    path = '/tmp'
    encoding = 'utf-8'
    res_args = dict()
    res_args['msg'] = 'Unable to read the contents of %s: ' % path
    res_args['exception'] = ''
    res_args['changed'] = False
    res_args['backup_file'] = '/tmp/hosts2019-07-14@12:13~'
    res_args['diff'] = {
                'before_header': path,
                'before': contents,
                'after_header': path,
                'after': result[0],
    }

    assert main(path,encoding,res_args) == 'Test Pass'

# Generated at 2022-06-23 04:15:34.953562
# Unit test for function main
def test_main():
    class UnitTestArgs(object):
        def __init__(self,path=None,regexp=None,replace=None,after=None,before=None,backup=False,validate=None,encoding='utf-8'):
            self.path=path
            self.regexp=regexp
            self.replace=replace
            self.after=after
            self.before=before
            self.backup=backup
            self.validate=validate
            self.encoding=encoding
    path=r'C:\Windows\Temp\ansible.txt'
    regexp='\[users\]\r\n[^\r\n]+'
    replace='[users]\r\n100=root'

# Generated at 2022-06-23 04:15:46.391985
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    global path
    global contents
    global result
    global params
    global res_args
    global changed
    path = module.params['path']

# Generated at 2022-06-23 04:15:48.703709
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:15:55.044747
# Unit test for function write_changes
def test_write_changes():
    (tmpfd, tmpfile) = tempfile.mkstemp(dir=os.path.sep)
    f = os.fdopen(tmpfd, 'wb')
    f.write("test123".encode("utf-8"))
    f.close()
    write_changes(tmpfile, "test123", tmpfile)
    os.remove(tmpfile)


# Generated at 2022-06-23 04:16:07.685173
# Unit test for function main
def test_main():
    module=AnsibleModule({}, {
        'path': {
            'type': 'str',
            'required': True
        },
        'regexp': {
            'type': 'str',
            'required': True
        },
        'replace': {
            'type': 'str',
            'default': ''
        },
        'after': {
            'type': 'str'
        },
        'before': {
            'type': 'str'
        },
        'backup': {
            'type': 'bool',
            'default': False
        },
        'validate': {
            'type': 'str'
        }
    }, check_invalid_arguments=False)
    assert module.fail_json.__defaults__ == (dict(msg=None),)
    #'msg': '

# Generated at 2022-06-23 04:16:17.529240
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path'},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.fail_json = lambda x: None
    module.exit_json = lambda x: None
    module.run_command = lambda x: [0, '', '']
    module.atomic_move = lambda x, y, z: True
    write_changes(module, b("test"), "/dev/null")


# Generated at 2022-06-23 04:16:29.015628
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    mock_module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    mock_module.atomic_move

# Generated at 2022-06-23 04:16:37.616661
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class T(object): pass
    module = T()
    module.params = dict()
    module.module_builtin = T()
    module.module_builtin.atomic_move = lambda x,y,z: None
    module.set_file_attributes_if_different = lambda x,y: True
    module.load_file_common_arguments = lambda x: dict()
    message = "message"
    res = check_file_attrs(module, False, message)
    assert res[0] == "message and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:16:49.834364
# Unit test for function main
def test_main():
    path = '/etc/hosts'
    regexp = '\\b(localhost)(\\d*)\\b'
    replace = '\\1\\2.localdomain\\2 \\1\\2'
    after = 0
    before = 0
    backup = 0
    validate = 0
    encoding = 'utf-8'

# Generated at 2022-06-23 04:17:01.804916
# Unit test for function check_file_attrs

# Generated at 2022-06-23 04:17:14.779579
# Unit test for function write_changes
def test_write_changes():
    class Module(object):
        def __init__(self, changed=False, failed=False, tmpdir='/tmp'):
            self.changed = changed
            self.failed = failed
            self.tmpdir = tmpdir

        def atomic_move(self, path1, path2, **kwargs):
            with open(path1, 'rb') as f1, open(path2, 'wb') as f2:
                f2.write(f1.read())

        def run_command(self, cmd):
            if '/true' in cmd:
                return (0, None, None)
            else:
                return (1, None, None)

    contents = b'This is a file containg some contents'
    path = '/tmp/test'
    module = Module()
    write_changes(module, contents, path)


# Generated at 2022-06-23 04:17:28.176016
# Unit test for function check_file_attrs

# Generated at 2022-06-23 04:17:37.513667
# Unit test for function main
def test_main():
    oldstr='\nslave1.redhat.com'
    newstr='\nslave2.redhat.com'
    module_args={'path':'testfile','regexp':'(master.redhat.com)'+oldstr+'$','replace':'\\1'+newstr+'\n'}
    def mock_open(self, mode, encoding=None):
        return f


# Generated at 2022-06-23 04:17:49.581060
# Unit test for function write_changes
def test_write_changes():
    import mock

    m = mock.Mock()
    m.params = {
        'validate': 'foo %s',
        'unsafe_writes': True,
    }
    tf = tempfile.NamedTemporaryFile(dir=tempfile.gettempdir())
    m.tmpdir = os.path.dirname(tf.name)
    m.run_command = mock.Mock()
    m.run_command.return_value = (1, 'baz', 'quux')
    m.fail_json = mock.Mock()
    m.atomic_move = mock.Mock()

    write_changes(m, b'foo', tf.name)
    m.fail_json.assert_called_with(msg='failed to validate: '
                                       'rc:1 error:quux')

# Generated at 2022-06-23 04:18:01.841766
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_dict_args = dict(path='/test/path',
                          mode=123,
                          owner='test_owner',
                          group='test_group',
                          seuser='test_user',
                          serole='test_role',
                          setype='test_type',
                          selevel='test_level')
    test_module = AnsibleModule(argument_spec=test_dict_args, supports_check_mode=True)
    test_changed = True
    test_message = 'test_message'
    test_message, test_changed = check_file_attrs(test_module, test_changed, test_message)
    assert (test_message == 'test_message and ownership, perms or SE linux context changed' and
            test_changed == True)



# Generated at 2022-06-23 04:18:10.030804
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict())
    setattr(module, 'tmpdir', '/tmp')
    setattr(module, '_atomic_move_fallback', True)
    setattr(module, 'atomic_move', lambda *args: None)
    module.run_command = lambda *args: (0, '', '')
    module.fai_json = lambda *args: None
    path = '/tmp/foo'
    contents = b'abcd'
    write_changes(module, contents, path)



# Generated at 2022-06-23 04:18:10.716241
# Unit test for function write_changes
def test_write_changes():
    assert False



# Generated at 2022-06-23 04:18:18.052705
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(argument_spec={})
    v = m.load_file_common_arguments({"owner":"root","mode":"0755"})
    message = ""
    changed = True
    message_expected = ""
    changed_expected = True
    m.set_file_attributes_if_different(v, True)
    message, changed = check_file_attrs(m, changed, message)
    if message == message_expected and changed == changed_expected:
        print ("ok")
    else:
        print ("error")



# Generated at 2022-06-23 04:18:28.494981
# Unit test for function write_changes
def test_write_changes():
    import os
    import shutil
    import tempfile
    import ansible.module_utils

    fh, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write(u'foo\n')
        f.write(u'bar\n')
    assert os.path.isfile(path)
    fake_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            validate=dict(default=None, type='str'),
            unsafe_writes=dict(default=False, type='bool')))
    fake_module.params['validate'] = None
    fake_module.params['unsafe_writes'] = False
    fake_module.run_command = lambda *args, **kwargs : (0, '', '')

# Generated at 2022-06-23 04:18:41.584113
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    module.params['path'] = '/etc/ssh/sshd_config'