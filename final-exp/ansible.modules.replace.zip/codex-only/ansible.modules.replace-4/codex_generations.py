

# Generated at 2022-06-23 04:08:42.591294
# Unit test for function main
def test_main():
    # these tests really don't do anything, but are being kept as long
    # as we have a basic python interpreter for testing
    assert(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:08:47.137983
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    message = "test"
    changed = False
    changed_test, message_test = check_file_attrs(module, changed, message)
    assert changed_test == False
    assert message_test == "test"
# end unit test


# Generated at 2022-06-23 04:08:54.870235
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class MockModule(object):
        def __init__(self):
            self.params = dict(seuser=None, serole=None, setype=None, path='/path/to/file')
        def load_file_common_arguments(self, params):
            return dict(path=params['path'], seuser=params['seuser'], serole=params['serole'], setype=params['setype'])
        def set_file_attributes_if_different(self, file_args, changed):
            return True
    test_module = MockModule()

    changed = False
    message = ""
    message, changed = check_file_attrs(test_module, changed, message)
    assert changed
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-23 04:08:57.175424
# Unit test for function main
def test_main():
    assert main([]) == (0,0)

if __name__ == '__main__':
    main(sys.argv[1:])

# Generated at 2022-06-23 04:09:06.852080
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    module = AnsibleModule(
    argument_spec = dict(
        path = dict(type='path', default='/tmp/test'),
        owner = dict(type='str', default='root'),
        group = dict(type='str', default='root'),
        mode = dict(type='str', default='0644'),
        seuser = dict(type='str', default='root'),
        serole = dict(type='str'),
        setype = dict(type='str', default='file'),
        selevel = dict(type='str', default='s0'),
        unsafe_writes= dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    )

# Generated at 2022-06-23 04:09:09.151608
# Unit test for function main
def test_main():
    assert 8 == main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:09:17.776833
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str'),
            validate=dict(type='str'),
        )
    )
    mock_path='/tmp/test_file'
    mock_contents='Hello World\n'
    write_changes(module, mock_contents, mock_path)
    f = open(mock_path, 'r')
    assert f.read() == mock_contents
    f.close()



# Generated at 2022-06-23 04:09:18.536939
# Unit test for function write_changes
def test_write_changes():
    assert True



# Generated at 2022-06-23 04:09:27.924199
# Unit test for function main
def test_main():
  # pylint: disable=undefined-variable
  # Test name
  test_name = 'test'
  # Initialize module_args
  module_args = dict()
  module_args.update(path="/etc/hosts")
  module_args.update(regexp='(\\\\s+)old\\\\.host\\\\.name(\\\\s+.*)?$')
  module_args.update(replace='\\\\1new.host.name\\\\2')
  # Initialize AnsibleModule
  module_object = AnsibleModule(
    argument_spec=module_args,
    supports_check_mode=True
  )
  # Run main()
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:09:28.502440
# Unit test for function write_changes
def test_write_changes():
    assert(False)



# Generated at 2022-06-23 04:09:28.908142
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-23 04:09:33.945429
# Unit test for function check_file_attrs

# Generated at 2022-06-23 04:09:46.498490
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(),
            content = dict(),
            replace = dict(),
            after = dict(),
            before = dict(),
            state = dict(default='present', choices=['present', 'absent']),
            backup = dict(default=False, type='bool')
        )
    )
    setattr(module, 'set_file_attributes_if_different', mock_set_file_attributes_if_different)
    setattr(module, '_diff_lookup', mock_diff_lookup)

    module.params['validate'] = None
    module.params['unsafe_writes'] = None
    module.params['check_mode'] = False
    module.params['path'] = '/tmp/testfile'

# Generated at 2022-06-23 04:09:49.508205
# Unit test for function main
def test_main():
    assert True == True
# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-23 04:10:00.290459
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({
            'path': '/path/file',
            'contents': 'contents',
            'validate': None,
            'unsafe-writes': True,
        }, check_invalid_arguments=False)

    tmppath = tempfile.mkdtemp()
    module.params.update({'tmpdir': tmppath})

    module.atomic_move = lambda a, b, c: None
    module.fail_json = lambda a: None
    module.run_command = lambda *a, **k: (0, '', '')

    write_changes(module, to_bytes('contents'), '/path/file')
    assert os.path.exists(os.path.join(tmppath, 'file'))

# Generated at 2022-06-23 04:10:14.786873
# Unit test for function write_changes
def test_write_changes():
    lines = '''a
b
c
'''
    lines2 = '''x
y
z
'''
    fd, path = mkstemp()
    with open(path, 'w') as f:
        f.write(lines)
    f = open(path)
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type = 'str', required = True),
            validate = dict(type = 'str'),
            unsafe_writes = dict(type = 'bool', required = True),
            atomic = dict(type = 'bool', required = True),
            no_log = dict(type = 'bool', required = True)
        )
    )
    module.tmpdir = os.path.dirname(path)
    module.run_command = run_command
    module.atomic_

# Generated at 2022-06-23 04:10:29.025580
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    path = "/tmp/ansible_test_file"
    # test empty file
    contents = ''
    write_changes(module, contents, path)
    f = open(path, 'rb')
    contents_from_file = f.read()
    f.close()
    assert contents == contents_from_file
    os.remove(path)
    # test one line
    contents = b'one line'
    write_changes(module, contents, path)
    f = open(path, 'rb')
    contents_from_file = f.read()
    f.close()
    assert contents == contents_from_file
    os.remove(path)
    # test mutliple lines
    contents = b'multiple lines\nof file\n'
    write_changes

# Generated at 2022-06-23 04:10:42.438145
# Unit test for function write_changes
def test_write_changes():
    import tempfile
    import shutil
    import subprocess

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            backup=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=False),
            contents=dict(type='str'),
            validate=dict(type='str'),
        )
    )

    tmpdir = tempfile.mkdtemp()
    module.params['path'] = tmpdir + '/foo'


# Generated at 2022-06-23 04:10:55.763832
# Unit test for function check_file_attrs
def test_check_file_attrs():
    changed = False
    message = 'This is a test message'
    params = {
            'owner': 'root',
            'group': 'root',
            'mode': '644',
            'seuser': None,
            'serole': None,
            'setype': None,
            'selevel': None,
    }


# Generated at 2022-06-23 04:11:05.703509
# Unit test for function main
def test_main():

    from ansible import utils
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import StringIO
    import collections

    class TestModule(object):

        def __init__(self, exit_json_args, atomic_move_args):
            self.exit_json_args = exit_json_args
            self.atomic_move_args = atomic_move_args

        def fail_json(self, *args, **kwargs):
            return False

        def exit_json(self, *args, **kwargs):
            if self.exit_json_args:
                return self.exit_json_args.pop(0)
            else:
                return False


# Generated at 2022-06-23 04:11:18.510851
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestModule(object):
        def __init__(self, params):
            self.params = params
    module = TestModule({})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.set_file_attributes_if_different = MagicMock(return_value=True)
    module.get_bin_path = MagicMock(return_value='/usr/bin/chmod')

    class TestException(Exception):
        pass


# Generated at 2022-06-23 04:11:20.231766
# Unit test for function write_changes
def test_write_changes():
    write_changes(module=None,contents=contents,path=path)


# Generated at 2022-06-23 04:11:29.524458
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test module is not yet imported
    import sys

    # Mock module
    module_mock = type('module_mock')()
    module_mock.params = {}
    module_mock.set_file_attributes_if_different = lambda file_args, changed: True
    module_mock.load_file_common_arguments = lambda params: {}

    # Test function
    changed, message = check_file_attrs(module_mock, False, "")

    assert changed == True
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-23 04:11:33.808067
# Unit test for function main
def test_main():
    # Read in test vars
    source = 'test/integration/targets/files/replace.yml'
    if not os.path.exists(source):
        raise Exception('File not found: %s' % source)
    import yaml
    with open(source) as f:
        test_vars = yaml.load(f)

    # Mock module args

# Generated at 2022-06-23 04:11:43.254153
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import sys
    module = sys.modules['ansible.module_utils.basic']
    file_args = {'path': '/tmp/file.txt', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'root', 'serole': 'root', 'setype': 'root'}
    ret = check_file_attrs(module, False, "message")
    assert ret[0] == "ownership, perms or SE linux context changed"
    assert ret[1] == True


# Generated at 2022-06-23 04:11:46.229352
# Unit test for function write_changes
def test_write_changes():
    assert write_changes == open(os.path.join(os.path.dirname(__file__), 'replace_write_changes.py')).read()



# Generated at 2022-06-23 04:11:54.338402
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path':{'type':'str', 'required':True},
        'validate':{'type':'str', 'required':False},
        'unsafe_writes':{'type':'bool', 'required':False},
        })
    var1 = 'tmpfile'
    var2 = 'path'
    old = 'tmp'
    new = 'new'
    module.atomic_move = lambda a, b, unsafe_writes: module.exit_json(**{'msg':'success', 'changed':True, 'rc':0, 'out':a, 'src':a, 'dest':b})
    write_changes(module, new, old)
    assert module.params[var1] == new
    assert module.params[var2] == old



# Generated at 2022-06-23 04:11:55.657228
# Unit test for function main
def test_main():
    os.path.realpath(path)

main()

# Generated at 2022-06-23 04:12:04.732462
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Make sure we are in the right situation
    assert os.path.exists('/etc/passwd')

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
        ),
        supports_check_mode=True
    )
    file_args = module.load_file_common_arguments(module.params)
    file_args['path'] = '/etc/passwd'
    file_args['owner'] = 'root'
    file_args['group'] = 'root'
    file_args['mode'] = '0644'
    # Create a dummy module object to pass to check_file_attrs

# Generated at 2022-06-23 04:12:17.415402
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec = dict())
    module.params = dict(
        path = "/dev/null",
        owner = "root",
        group = "root",
        mode = "0777"
    )
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: dict()
    changed, message = False, ""
    changed, message = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-23 04:12:28.749249
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = DummyAnsibleModule()
    changed  = True
    message = "test"
    message, changed = check_file_attrs(module, changed, message)
    assert not changed
    assert message == 'test'
    class DummyFileModuleParams():
        def __init__(self):
            self.path = '/tmp/test_file'
            self.owner = 'root'
            self.group = 'root'
            self.mode = '0644'
            self.seuser = None
            self.serole = None
            self.setype = None
            self.selevel = None
        def __getitem__(self, key):
            return self.__dict__[key]
        def __setitem__(self, key, value):
            self.__dict__[key] = value
    module

# Generated at 2022-06-23 04:12:29.423700
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-23 04:12:42.228427
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/test'
    module.params['mode'] = '0644'
    module.params.update(dict(
        path='/tmp/test',
        mode='0644',
        owner='root',
        group='root',
        seuser='unconfined_u',
        serole='object_r',
        selevel='s0'
    ))
    module.params = {"path": "/tmp/test", "mode": "0644", "owner": "root", "group": "root", "seuser": "unconfined_u", "serole": "object_r", "selevel": "s0"}
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 04:12:53.805191
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']), regexp=dict(type='str', required=True), replace=dict(type='str', default=''), after=dict(type='str'), before=dict(type='str'), backup=dict(type='bool', default=False), validate=dict(type='str'), encoding=dict(type='str', default='utf-8')))
    assert module.check_mode
    assert module.no_log
    assert module.params['path'] == '/etc/hosts'
    assert module.params['regexp'] == '(\s+)old\.host\.name(\s+.*)?$'


# Generated at 2022-06-23 04:13:06.423543
# Unit test for function main
def test_main():
    import uuid
    import datetime
    from ansible.module_utils import basic
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock, call
    from ansible.compat.six import StringIO
    from io import StringIO

# Generated at 2022-06-23 04:13:19.761743
# Unit test for function main
def test_main():
    name = "test"
    regexp = '''(?P<dctv>ListenAddress[ ]+)(?P<host>[^\n]+)'''
    path = "/etc/ssh/sshd_config"

# Generated at 2022-06-23 04:13:31.012632
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
                                            'path': dict(required=True),
                                            'tmpdir': dict(required=True),
                                            'validate': dict(required=False)
                                        }
    )
    contents = b"test file\n"
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.params['tmpdir'])
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()
    path, _ = os.path.split(tmpfile)
    validate = module.params.get('validate', None)
    if validate:
        (rc, out, err) = module.run_command(validate % tmpfile)
        valid = rc == 0
        assert(valid)

# Generated at 2022-06-23 04:13:40.709773
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': 'test_file', 'validate': 'echo %s', 'unsafe_writes': False})
    assert module != None
    module.run_command = lambda cmd, check_rc=None, close_fds=None, executable=None, data=None, binary_data=False: (0, cmd, '')
    module.atomic_move = lambda src, dest, unsafe_writes=None: None
    write_changes(module, b'123', 'test_file')
    assert module.params['path'] == 'test_file'
    assert module.params['validate'] == 'echo %s'
    assert module.params['unsafe_writes'] == False



# Generated at 2022-06-23 04:13:53.918284
# Unit test for function write_changes

# Generated at 2022-06-23 04:13:55.710323
# Unit test for function main
def test_main():
    # check for valid pc address
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:14:06.315150
# Unit test for function main
def test_main():
    path = "test.txt"
    with open(path, 'w') as f:
        f.write("hello world\n")
    
    import os.path
    try:
        tmp = os.environ['HOME']
    except:
        import pwd
        tmp = pwd.getpwuid( os.getuid() ).pw_dir
    
    tmp = os.path.join(tmp, "tmp")
    if not os.path.exists(tmp):
        os.makedirs(tmp)
    #os.environ["HOME"] = tmp
    

# Generated at 2022-06-23 04:14:19.247609
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class Temp(object):
        def __init__(self):
            self.params = { 'owner': 'abc',
                            'group': 'abc',
                            'mode': '777',
                            'seuser': 'abc',
                            'serole': 'abc',
                            'setype': 'abc',
                            'selevel': 'abc',
                            'unsafe_writes': True }
        def set_file_attributes_if_different(self, file_args, changed= False):
            return True
        def load_file_common_arguments(self, file_args):
            return file_args
    t = Temp()
    changed = False
    message = ""
    message, changed = check_file_attrs(t, changed, message)
    assert changed == True

# Generated at 2022-06-23 04:14:30.323983
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import shutil
    ansible_module = sys.modules['ansible.module_utils.ansible_freeipa_module']
    ansible_module._ANSIBLE_ARGS = [str(i) for i in sys.argv[1:]]
    tmpdir = ansible_module.HAS_JINJA2.tmpdir
    print(tmpdir)
    cwd = os.getcwd()
    os.chdir(tmpdir)

# Generated at 2022-06-23 04:14:41.473763
# Unit test for function main
def test_main():
    arg_spec = dict(
        path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
        regexp=dict(type='str', required=True),
        replace=dict(type='str', default=''),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        encoding=dict(type='str', default='utf-8'),
    )
    module = AnsibleModule(argument_spec=arg_spec)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:14:52.113348
# Unit test for function write_changes
def test_write_changes():
    x = test.AnsibleModule()
    x.params = x.params({
        'validate': None
    })
    x.tmpdir = '/tmp'
    x.atomic_move = lambda source, dest, unsafe_writes: None
    x.run_command = lambda cmd: (0, None, None)

    buffer = 'A' * 512
    write_changes(x, buffer, '/test/path')

    x.params['validate'] = 'echo "validate %%s"'
    write_changes(x, buffer, '/test/path')

    x.params['validate'] = 'echo "validate %s"'
    write_changes(x, buffer, '/test/path')


# Generated at 2022-06-23 04:14:59.601871
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MockModule()
    module.params = {'path': '/tmp/myfile', 'owner': 'root', 'group': 'wheel'}
    module.load_file_common_arguments = lambda a: a
    module.set_file_attributes_if_different = lambda a,b: True
    changed, message = check_file_attrs(module, False, "")
    assert changed
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-23 04:15:10.552464
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class args:
        unsafe_writes = True
    class params:
        path = "/bin/false"
        owner = "root"
        group = "root"
        mode = 0o755
    class tmp:
        name = "/tmp/test_check_file_attrs"
    class atomic_move_mock:
        def __init__(self, source, dest, unsafe_writes):
            return

    module = AnsibleModule(
        argument_spec = dict(
            mode = dict(type='raw'),
            owner = dict(type='raw'),
            group = dict(type='raw'),
            unsafe_writes = dict(type='bool', default=args.unsafe_writes),
        ),
        supports_check_mode=True
    )
    module.params = params

# Generated at 2022-06-23 04:15:12.474475
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    write_changes(module, '{contents}', '{path}')


# Generated at 2022-06-23 04:15:20.064007
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: False
    module.warn = lambda **kwargs: False
    module.set_file_attributes_if_different = lambda a, b: True
    changed, message = False, ""
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:15:26.585111
# Unit test for function write_changes
def test_write_changes():
    try:
        module = AnsibleModule(argument_spec={})
        contents = "This is a test"
        path = "testme.txt"
        module.atomic_move = lambda x, y, unsafe_writes : print("moved")
        write_changes(module, contents, path)
        print ("OK: Function 'write_changes' is working")
    except:
        print("ERROR: Function 'write_changes' doesn't work")
        print(format_exc())



# Generated at 2022-06-23 04:15:41.112487
# Unit test for function write_changes
def test_write_changes():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--validate', action='store')
    parser.add_argument('--unsafe-writes', action='store')
    parser.add_argument('--path', action='store')

    args = parser.parse_args(sys.argv[1:])
    test_module = AnsibleModule(argument_spec={})
    test_module.params['path'] = args.path
    test_module.params['validate'] = args.validate
    test_module.params['unsafe_writes'] = args.unsafe_writes

    write_changes(test_module, """
first line
second line
third line
""", args.path)


# Generated at 2022-06-23 04:15:49.559292
# Unit test for function write_changes
def test_write_changes():
  module = AnsibleModule(argument_spec=dict(
    validate=dict(type='str',required=True),
    unsafe_writes=dict(type='bool',required=True),
    tmpdir=dict(type='str',required=True)
  ))
  write_changes(module, to_bytes("test"), to_bytes("/tmp/tmp"))
  write_changes(module, to_bytes("test"), to_bytes("/tmp/tmp"))


# Generated at 2022-06-23 04:15:59.762079
# Unit test for function write_changes
def test_write_changes():
    m = AnsibleModule(
        argument_spec=dict(
            _ansible_tmpdir = dict(required=False),
        ),
    )
    path = None
    contents = None

    # 1st unit test: Create a file
    path = "/tmp/test_write_changes"
    contents = "test_write_changes"
    write_changes(m, contents, path)
    f = open(path,'r')
    assert(f.read() == contents)
    f.close()
    os.remove(path)

    # 2nd unit test: Update a file
    path = "/tmp/test_write_changes"
    contents = "test_write_changes"
    f = open(path,'w')
    f.write("blah blah blah")
    f.close()

# Generated at 2022-06-23 04:16:11.868454
# Unit test for function write_changes
def test_write_changes():
    module_args = {
        "path": "/tmp/test_write_changes",
        "validate": "cat %s && rm %s"
    }
    test_module = AnsibleModule(
        argument_spec = dict(
            path=dict(required=True),
            validate=dict()
        ),
        supports_check_mode=True,
        module_args=module_args
    )
    # Test writing the file
    test_module.run_command = TestRunCommand(True)
    test_module.atomic_move = TestAtomicMove()
    write_changes(test_module, b'Test', test_module.params['path'])
    assert(not os.path.exists("/tmp/test_write_changes"))

# Generated at 2022-06-23 04:16:15.437027
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:16:16.199419
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:16:26.840838
# Unit test for function main
def test_main():

    s = r"""
this is a
line of text
to test regexp
substitution with,
and this is the
last line.
"""
    f = open("/tmp/testfile", "w")
    f.write(s)
    f.close()
    f = open("/tmp/replace.yml", "w")
    f.write("""
---
#
- name: Unit test for function main
  hosts: localhost
  connection: local
  tasks:
    - name: Test regexp substitution
      ansible.builtin.replace:
        path: /tmp/testfile
        regexp: "^(.*)text\n"
        replace: "\1substituted text\n"
""")
    f.close()

# Generated at 2022-06-23 04:16:33.608948
# Unit test for function main
def test_main():
  import tempfile
  res_args={'changed': False, 'msg': ''}
  res=main(path='/etc/ansible/ansible.cfg', regexp='^#remote_tmp     =.*')
  assert res['changed'] == False
  assert os.path.exists(res['backup_file'])
  os.remove(res['backup_file'])

if __name__ == '__main__':
  test_main()

# Generated at 2022-06-23 04:16:45.353391
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    # The docs are in docs/docsite/rst/dev_guide/testing.rst
    import tempfile
    tmpfile = tempfile.NamedTemporary

# Generated at 2022-06-23 04:16:57.422564
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            validate = dict(default=None, required=False),
            unsafe_writes = dict(default=False, type='bool'),
        ),
    )
    fake_contents = "fake contents"
    tmpdir = "/tmp/ansible-unittest"
    path = os.path.join(tmpdir, "path")

    def run_command(cmd, *args, **kwargs):
        assert cmd == "validate %s" % (path)
        return 0, "", ""

    module.run_command = run_command
    module.atomic_move = lambda src, dest, *args, **kwargs: shutil.move(src, dest)
    module.tmpdir = tmpdir

    write_changes(module, fake_contents, path)




# Generated at 2022-06-23 04:17:02.777153
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({ "param1": "value1", "param2": "value2" })
    write_changes(module, "testing", module.tmpdir + "/orig.txt")
    file = open(module.tmpdir + "/orig.txt", "r")
    assert file.read() == "testing"



# Generated at 2022-06-23 04:17:06.316665
# Unit test for function main
def test_main():
    from ansible.modules.files.replace import main

# Post conditions for function main
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:17:11.779763
# Unit test for function main
def test_main():
   with pytest.raises(AnsibleFailJson) as excinfo:
      assert main()
   assert 'msg: Pattern for before/after params did not match the given file: %s' in str(excinfo.value)
# AnsibleModuleTestCase Unit test for AnsibleModuleTestCase

# Generated at 2022-06-23 04:17:22.099278
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Dummy module for testing

    class DummyModule(object):
        def __init__(self, changed=False):
            self.changed = changed

        def set_file_attributes_if_different(self, src, dest):
            self.changed = True
            return True

        def load_file_common_arguments(self, params):
            return {}

    module = DummyModule()
    message_out, changed_out = check_file_attrs(module, False, '')
    assert changed_out is True, "Changed expected to be True"
    assert message_out == "ownership, perms or SE linux context changed"



# Generated at 2022-06-23 04:17:29.797182
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={ 'path': {'required': True}, 'mode': {}, 'owner': {}, 'group': {}, 'seuser': {}, 'serole': {}, 'setype': {} })
    message = 'file is absent'
    changed = True

    test_message, test_changed = check_file_attrs(module, changed, message)
    assert test_message != message
    assert test_changed != changed
# End unit test



# Generated at 2022-06-23 04:17:37.480658
# Unit test for function write_changes
def test_write_changes():
    import pytest
    module = AnsibleModule(argument_spec={'path': {'type': 'str'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool'}})
    module.tmpdir = tempfile.mkdtemp()
    module.run_command = lambda x, check_rc=False: (0, '', '')
    module.atomic_move = lambda x, y: True
    module.fail_json = lambda x: pytest.fail(repr(x))
    write_changes(module, 'test_contents', module.params.get('path'))



# Generated at 2022-06-23 04:17:40.444507
# Unit test for function check_file_attrs
def test_check_file_attrs():
    check_file_attrs(module, changed, message)


# Generated at 2022-06-23 04:17:52.607000
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    write_changes(module, 'temp', 'test')
    check_file_attrs(module, 'test')


# Generated at 2022-06-23 04:18:04.033783
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil


# Generated at 2022-06-23 04:18:14.753509
# Unit test for function main
def test_main():
    module_args = dict(
        path='/etc/hosts',
        regexp="(^127\\.0\\.0\\.1[ \\t]+localhost[ \\t]*$)",
        replace="",
        backup=False,
        validate=None,
        encoding='utf-8',
    )

    result = dict(
        changed=False,
        msg='0 replacements made'
    )

    # This is in the dict called main
    #module = AnsibleModule(argument_spec=module_args)
    main()


# This can be a pathed to ansible/modules/core/files/
# when run as a unit test.
if __name__ == '__main__':
    import subprocess


# Generated at 2022-06-23 04:18:22.567912
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # we need to mock the module otherwise the params won't exist
    module = AnsibleModule({})
    module.set_file_attributes_if_different = lambda a, b: True
    module.load_file_common_arguments = lambda a: []
    assert ('ownership, perms or SE linux context changed', True) == check_file_attrs(module, False, "")



# Generated at 2022-06-23 04:18:36.674099
# Unit test for function main
def test_main():
    # This function will run tests on the main function
    # Testing the path=None and regexp=None case
    # First we create mock data to pass to the module
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )


# Generated at 2022-06-23 04:18:45.006250
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Arrange
    module = AnsibleModule(argument_spec={})
    changed, message = False, ''

    path = './test/path'
    module.params['path'] = path
    module.params['unsafe_writes'] = True
    module.params['owner'] = 'something'

    # Act
    message, changed = check_file_attrs(module, changed, message)

    assert changed
    assert message == "ownership, perms or SE linux context changed"

