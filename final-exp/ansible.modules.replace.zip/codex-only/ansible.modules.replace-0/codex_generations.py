

# Generated at 2022-06-23 04:08:48.404810
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Test module load
    # Test file attributes set
    # Test no file attributes set
    # Test file attributes set with changed = True and msg = msg
    # Test file attributes set with changed = True and msg = blank
    # Test file attributes set with changed = False and msg = msg

    module = AnsibleModule(
        argument_spec = dict(
            name = dict(type='path'),
            owner = dict(default=None),
            group = dict(default=None),
            mode = dict(default=None),
            seuser = dict(default=None),
            serole = dict(default=None),
            setype = dict(default=None),
            selevel = dict(default=None)
        )
    )
    class Args:
        def __init__(self):
            self.unsafe_writes = False

   

# Generated at 2022-06-23 04:08:50.742920
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, None) == (None, False)



# Generated at 2022-06-23 04:08:59.422472
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule()
    assert check_file_attrs(module, True, "") == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, False, "") == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, "some other message") == ("some other message and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 04:09:07.782834
# Unit test for function check_file_attrs

# Generated at 2022-06-23 04:09:20.535120
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    x = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    x.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:09:22.428247
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:09:30.977797
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'tmpdir': {},
        'validate': {},
        'unsafe_writes': {}
    }, supports_check_mode=True)
    path = '/tmp/test_write'
    contents = b'contents'

    try:
        if os.path.exists(path):
            os.unlink(path)
        write_changes(module, contents, path)
        assert(os.path.exists(path))
        assert(len(contents) == os.path.getsize(path))
        with open(path, 'rb') as f:
            assert(contents == f.read())
        os.unlink(path)
    except:
        raise AssertionError(format_exc())



# Generated at 2022-06-23 04:09:44.797661
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    class TestModule(object):
        def __init__(self):
            self.params = None
            self.atomic_move = lambda src, dest, unsafe_writes: None
            self.run_command = lambda cmd: (0, '', '')
            self.fail_json = lambda msg: None
            self.tmpdir = '/tmp'
    module = TestModule()
    contents = b'abcdefg'
    path = '/tmp/destfile'
    write_changes(module, contents, path)
    validate = module.params.get('validate', None)
    valid = not validate
    if validate:
        if "%s" not in validate:
            module.fail_json(msg="validate must contain %%s: %s" % (validate))
       

# Generated at 2022-06-23 04:09:57.704984
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'path': './test/test.txt',
        'tmpdir': './test/',
        'validate': None,
        'unsafe_writes': False})
    module.run_command = lambda cmd, check_rc=False: (0, 'success')
    module.atomic_move = lambda src, dest, unsafe_writes: os.rename(src, dest)
    test_string = "This is a test string"
    test_file = open('./test/test.txt', 'wb')
    test_file.write(test_string)
    test_file.close()
    write_changes(module, test_string, module.params['path'])
    compare_file = open('./test/test.txt', 'rb')

# Generated at 2022-06-23 04:10:03.321210
# Unit test for function write_changes
def test_write_changes():
    # check that input string is returned/no change made
    contents = b"## This is a test\n##\n##\n## Note that this does not cover the regex option\n##"
    path = "/tmp/test.tmp"
    m = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            content = dict(required=True),
        )
    )
    write_changes(m, contents, path)
    assert os.path.exists(path)
    assert m.params['content'] in open(path).read().split('\n')[0]
    os.remove(path)


# Generated at 2022-06-23 04:10:17.864988
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    input_file = os.path.join(os.path.dirname(__file__), "test_input_file.txt")
    module.params["path"]

# Generated at 2022-06-23 04:10:26.749368
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='str', required=True),
            regexp = dict(type='str', required=True),
            replace = dict(type='str', required=True)
        )
    )
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)

    assert changed is False
    assert message == ''



# Generated at 2022-06-23 04:10:39.931123
# Unit test for function write_changes
def test_write_changes():
    import tempfile
    import os
    import os.path
    import shutil

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()
    # Create a file in the temp directory
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, dir=temp_dir)
    temp_file.write("123456789")
    temp_file.close()

    test_module = AnsibleModule({'path': temp_file.name,
                                 'unsafe_writes': True,
                                 'tmpdir': temp_dir},
                                check_invalid_arguments=False)

    write_changes(test_module, "abcdefg", temp_file.name)

    with open(temp_file.name, 'r') as f:
        assert f.read()

# Generated at 2022-06-23 04:10:47.115196
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path':{'type': 'str', 'required': True}})
    module.params["path"] = "foo.bar"
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = check_file_attrs(module, True, "baz")
    assert changed == True
    assert message == "baz and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:10:57.204785
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, '','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')


# Generated at 2022-06-23 04:11:06.659084
# Unit test for function write_changes
def test_write_changes():

    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()

    validate = module.params.get('validate', None)
    valid = not validate
    if validate:
        if "%s" not in validate:
            module.fail_json(msg="validate must contain %%s: %s" % (validate))
        (rc, out, err) = module.run_command(validate % tmpfile)
        valid = rc == 0
        if rc != 0:
            module.fail_json(msg='failed to validate: '
                                 'rc:%s error:%s' % (rc, err))

# Generated at 2022-06-23 04:11:11.290566
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict(
        owner=dict(type='str', required=False),
        group=dict(type='str', required=False),
        mode=dict(type='str', required=False),
        seuser=dict(type='str', required=False),
        serole=dict(type='str', required=False),
        selevel=dict(type='str', required=False),
        setype=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )


# Generated at 2022-06-23 04:11:11.888058
# Unit test for function write_changes
def test_write_changes():
    write_changes(module, contents, path)



# Generated at 2022-06-23 04:11:16.596655
# Unit test for function main
def test_main():
    import inspect
    import os
    import sys
    import unittest
    module_name = 'ansible.builtin.replace'
    module_path = os.path.realpath(os.path.dirname(inspect.getfile(inspect.currentframe())))
    module_path = module_path.replace('/tests/units/modules/files/ansible/builtin', '')
    sys.path.insert(0, module_path)
    f, filename, descr = imp.find_module(module_name, [module_path])
    module = imp.load_module(module_name, f, filename, descr)

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass


# Generated at 2022-06-23 04:11:27.022121
# Unit test for function main
def test_main():
    class AnsibleArgs(object):
        def __init__(self, args):
            for k, v in args.items():
                setattr(self, k, v)

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = AnsibleArgs({'path': '/etc/fstab', 'regexp': '^/tmp', 'replace': '', 'backup': False, 'validate': None, 'encoding': 'utf-8'})

    # Call function main
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:11:38.782774
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule(
        argument_spec={
            'path': {'type': 'str'},
            'validate': {'type': 'str'}
        }
    )
    test_module.tmpdir = 'file_replace_tmpdir'
    if not os.path.exists(test_module.tmpdir):
        os.makedirs(test_module.tmpdir)
    contents = b"this is the contents"
    path = 'file_replace_tmpdir/test_write_changes'
    write_changes(test_module, contents, path)
    with open(path, 'rb') as f:
        assert(f.read() == contents)
    os.unlink(path)
    os.rmdir(test_module.tmpdir)



# Generated at 2022-06-23 04:11:50.603335
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    path = '/etc/hosts'
    contents = '''
127.0.0.1 localhost
127.0.0.1 localhost.localdomain
127.0.0.1 test
::1 localhost
::1 localhost
::1 localhost.localdomain
'''
    write_changes(module, to_bytes(contents, errors='surrogate_or_strict'), to_bytes(path, errors='surrogate_or_strict'))

    assert os.path.exists(path), "'%s' was not created" % path

    with open(path, 'r') as f:
        new_content = f.read()

    assert contents == new_content, "content doesn't match"

    #Clean up for unit test

# Generated at 2022-06-23 04:11:52.418926
# Unit test for function write_changes
def test_write_changes():
    """Function has no return value and modifies tmpdir"""
    pass



# Generated at 2022-06-23 04:12:02.802999
# Unit test for function check_file_attrs
def test_check_file_attrs():
    set_module_args(dict(
        path='/tmp/file',
        owner='foo',
        group='bar',
        mode='0666',
    ))
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.atomic_move = MagicMock(return_value=True)
    module.get_bin_path = MagicMock(return_value='/bin/chmod')
    module.selinux_mls_enabled = MagicMock(return_value='s0',)
    module.fail_json = MagicMock()

    result = {'changed': False, 'diff': None}

# Generated at 2022-06-23 04:12:08.878657
# Unit test for function main
def test_main():
    test_data = dict(
        path='/etc/hosts',
        regexp='(\s+)old\.host\.name(\s+.*)?$',
        replace='\1new.host.name\2',
        after=r'</VirtualHost>',
        before=r'<VirtualHost [*]>',
        backup=True,
        validate=r'/usr/sbin/apache2ctl -f %s -t',
        encoding='utf-8'
    )

    path = test_data['path']
    regexp = test_data['regexp']
    replace = test_data['replace']
    after = test_data['after']
    before = test_data['before']
    backup = test_data['backup']
    validate = test_data['validate']
    encoding = test_data['encoding']


# Generated at 2022-06-23 04:12:11.293370
# Unit test for function main
def test_main():
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:12:24.925197
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, ModuleFailException
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    import os
    import stat
    import shutil
    import tempfile

    orig_path = os.getcwdu()
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'testfile')

    # Create test file
    makedirs_safe(os.path.dirname(test_file))
    open(test_file, 'wb').write(to_bytes('foo\nbar\nbaz\n'))

    orig_en

# Generated at 2022-06-23 04:12:25.943257
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:12:33.724025
# Unit test for function write_changes
def test_write_changes():

    m = AnsibleModule(
        argument_spec={
            'path': {'type': 'str', 'required': True},
            'unsafe_writes': {'type': 'bool', 'default': False},
            'validate': {'type': 'str'}
        },
        supports_check_mode=True
    )
    sunc = m.params['unsafe_writes']
    path = m.params['path']
    validate = m.params['validate']
    contents = b'#!/bin/sh\n'
    write_changes(m, contents, path)
    with open(path, 'rb') as f:
        r = f.read()
    assert r == contents
    os.unlink(path)

#========================================


# Generated at 2022-06-23 04:12:38.518898
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(path=dict(type='path', required=True)))
    message, changed = check_file_attrs(module, True, 'dummy message')
    assert isinstance(changed, bool)
    assert isinstance(message, str)



# Generated at 2022-06-23 04:12:49.445013
# Unit test for function main
def test_main():
    params = {
        'path': '/etc/hosts',
        'regexp': '^\\s*\\(\\s*\\)\\s*$',
        'replace': '\\1',
        'backup': 'no',
        'validate': '',
        'encoding': 'utf-8',
    }
    class AnsibleModule:
        def __init__(self):
            self.params = params
            self.check_mode = False
            self.atomic_move = None
        def fail_json(self, rc=None, msg=None, **kwargs):
            raise AssertionError
            assert rc is None
            assert msg is None
    module = AnsibleModule()
    try:
        main()
    except AssertionError:
        pass
# Unit test end


# Generated at 2022-06-23 04:12:57.794012
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    reload(sys)
    sys.setdefaultencoding('utf8')
    my_args = dict({
        'path': '/home/foo/hosts',
        'regexp': '[a-z]+',
        'replace': 'bar',
        'backup': False,
        'follow': False,
        'unsafe_writes': False,
    })
    # Create a dummy module to pass into the execution module.
    basic._ANSIBLE_ARGS = to_bytes(basic._ANSIBLE_ARGS)

# Generated at 2022-06-23 04:13:06.599889
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        {'some_arg': {'required': False, 'type': 'str'}},
        check_invalid_arguments=False,
        supports_check_mode=True
    )
    module.params = {'some_arg': 'some_arg_value'}
    setattr(module, 'set_file_attributes_if_different', Mock(return_value=True))

    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True and message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-23 04:13:19.816871
# Unit test for function main
def test_main():
    import json
    import ansible.module_utils.ansible_modlib.basic
    #
    module = ansible.module_utils.ansible_modlib.basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

# Generated at 2022-06-23 04:13:31.263797
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()


# Generated at 2022-06-23 04:13:37.792918
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(1,1,1) == (1, True)
    assert check_file_attrs(1,0,1) == (1, True)
    assert check_file_attrs(0,1,1) == (1, True)
    assert check_file_attrs(0,0,1) == (1, False)



# Generated at 2022-06-23 04:13:50.792484
# Unit test for function write_changes
def test_write_changes():
    import os
    import json
    import sys
    import unittest

    module_path = os.path.realpath(__file__)
    data_path = os.path.join(os.path.dirname(module_path), "data")

    mock_module = AnsibleModule({'ANSIBILE_MODULE_ARGS': {}}, check_invalid_arguments=False)
    mock_module.tmpdir = data_path
    mock_module.run_command = test_run_command
    mock_module.atomic_move = test_atomic_move

    # No validation
    mock_module.params = {'validate': None, 'path': '/tmp/test', 'unsafe_writes': False}
    write_changes(mock_module, 'Hello\nWorld\n', '/tmp/test')

   

# Generated at 2022-06-23 04:14:01.402696
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import file_common
    import tempfile
    import os
    import stat

    temp_dir = tempfile.gettempdir()
    tmp_file = tempfile.NamedTemporaryFile(mode="w+t", dir=temp_dir, delete=False)
    tmp_file.write("""Hello

I am a test file!

kind regards,

Test File""")
    tmp_file.close()
    backup_path = tmp_file.name + ".bak"

    # Unit test using the real open method
    # pylint: disable=unexpected-keyword-arg,unused-argument

# Generated at 2022-06-23 04:14:08.683541
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class ReturnModule():
        def __init__(self):
            self.set_file_attributes_if_different = True
            self.params = dict(
                owner = self,
                group = self,
                mode = self,
                seuser = self,
                serole = self,
                selevel = self,
                setype = self,
            )

        def fail_json(self, msg):
            raise Exception(msg)
    rm = ReturnModule()
    message, changed = check_file_attrs(rm, False, "")
    return changed

# Generated at 2022-06-23 04:14:09.264222
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True


# Generated at 2022-06-23 04:14:16.946875
# Unit test for function main
def test_main():
    from ansible.modules.source_control import ansible_builtin_replace
    args = dict(
        path='~/.ssh/known_hosts',
        regexp='^old\.host\.name[^\n]*\n',
        replace='',
    )
    assert ansible_builtin_replace.main() == exit_json(ansible_builtin_replace, args)


# Generated at 2022-06-23 04:14:28.156532
# Unit test for function main
def test_main():
    source_file_args = dict(
        path='/etc/ansible/path',
        regexp='regexp',
        replace='replace',
        after='after',
        before='before',
        backup=False,
        validate='validate',
        encoding='encoding'
    )
    z_path = 'path/z'
    z_encoding = 'encoding/z'
    z_backup = True
    z_before = 'before/z'
    z_after = 'after/z'
    z_regexp = 'regexp/z'
    z_replace = 'replace/z'
    z_validate = 'validate/z'
    z_path_realpath = 'path/realpath/z'
    file_contents = 'file contents'
    file_contents_

# Generated at 2022-06-23 04:14:38.414591
# Unit test for function write_changes
def test_write_changes():
    class FakeModule(object):
        def __init__(self):
            self.fail_json = None
            self.params = dict()
            self.tmpdir = None
            self.run_command = None
            self.atomic_move = None

        def set_fail_json(self, fail_json):
            self.fail_json = fail_json

        def set_params(self, params):
            self.params = dict(params)

        def set_tmpdir(self, tmpdir):
            self.tmpdir = tmpdir

        def set_run_command(self, run_command):
            self.run_command = run_command

        def set_atomic_move(self, atomic_move):
            self.atomic_move = atomic_move


# Generated at 2022-06-23 04:14:47.552705
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str'),
            contents = dict(required=True, type='str')
        )
    )
    try:
        assert(False)
    except AssertionError:
        assert(True)
    finally:
        pass
    contents = 'This is temporary content.'
    path = '/tmp/test_write_changes'
    write_changes(module, contents, path)
    f = open(path, 'w')
    f.seek(0)
    assert('This is temporary content.' == f.readline())
    pass



# Generated at 2022-06-23 04:14:48.467535
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-23 04:14:49.734756
# Unit test for function check_file_attrs
def test_check_file_attrs():
    return True



# Generated at 2022-06-23 04:15:00.624835
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path       = dict(type='path', required=True),
            tmpdir     = dict(type='path', required=True),
            validate   = dict(type='str', default=None)
        )
    )
    contents = b'TEST'
    path = module.params['path']
    with tempfile.NamedTemporaryFile(dir=module.params['tmpdir'], delete=False) as tmpfile:
        tmpfile.write(contents)
        tmpfile.flush()
        tmpfile.close()

        write_changes(module, contents, path)

        with open(path, 'r') as file:
            assert file.read() == 'TEST'
        os.remove(tmpfile.name)


# Generated at 2022-06-23 04:15:11.527329
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = to_bytes(json.dumps({'ANSIBLE_MODULE_ARGS': dict(path='string',match='string',regexp='string',backup='boolean',dest='string',destfile='string',replace='string',name='string',unsafe_writes='boolean')}))
    with pytest.raises(SystemExit):
        main()

# Unit test if function main is called directly
if __name__ == '__main__':
    from ansible.module_utils import basic

# Generated at 2022-06-23 04:15:23.930902
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    import os
    import re
    import tempfile
    from traceback import format_exc

    from ansible.module_utils._text import to_text, to_

# Generated at 2022-06-23 04:15:31.762398
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
            argument_spec=dict(
                path=dict(default=None, required=True),
                contents=dict(default=None, required=True),
                unsafe_writes=dict(default=False, type='bool'),
                validate=dict(default=None, required=False),
            ),
            supports_check_mode=False,
        )
    path = module.params['path']
    contents = module.params['contents']
    rc = 0
    out = ""
    err = ""
    validate = module.params['validate']
    class FakeMod:
        def atomic_move(self, tmpfile, path, unsafe_writes):
            rc = 0
            out = ""
            err = ""

        def fail_json(self, msg):
            rc = 1
            out = ""


# Generated at 2022-06-23 04:15:39.810488
# Unit test for function check_file_attrs
def test_check_file_attrs():
    mock_module = type('MockModule', (), {})()
    mock_module.set_file_attributes_if_different = lambda a,b: True
    mock_module.load_file_common_arguments = lambda a: {}

    changed, msg = check_file_attrs(mock_module, False, 'foo changed')
    assert changed
    assert msg == 'foo changed and ownership, perms or SE linux context changed'



# Generated at 2022-06-23 04:15:52.950659
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'validate':'/bin/true',
        'params':{'unsafe_writes':False,'path':'path'},
        'tmpdir':'/tmp/',
        'run_command':lambda command, check_rc=False, close_fds=False, executable=None, data=None: [0, '', ''],
        'atomic_move':lambda src, dest, unsafe_writes=False: ''
    })
    # test with valid command
    contents = to_bytes('test')
    assert write_changes(module, contents, module.params['path']) is None
    # test with invalid command
    module.run_command = lambda command, check_rc=False, close_fds=False, executable=None, data=None: [1, '', '']
    assert write_changes

# Generated at 2022-06-23 04:16:05.860700
# Unit test for function main
def test_main():
    # set up
    dummy_path = ['/tmp/test_file']
    dummy_regexp = ['^search']
    dummy_replace = ['replace']
    dummy_after = ['']
    dummy_before = ['']
    dummy_backup = [True]
    dummy_validate = ['']
    dummy_encoding = ['utf-8']
    support_check_mode = True

# Generated at 2022-06-23 04:16:13.965933
# Unit test for function write_changes
def test_write_changes():
    class TestModule:
        pass
    module = TestModule()
    module.tmpdir = '/tmp'
    module.params = { 'validate' : None }
    setattr(module, 'atomic_move', lambda x,y,z: None)
    # This is a very low level test
    # We only test if write changes works without validate option
    # The validate option is run against the file and can be very complex
    # Classes, functions and valid options are tested separately
    write_changes(module, b'', '/tmp/test')


# Generated at 2022-06-23 04:16:20.007539
# Unit test for function write_changes
def test_write_changes():
  global module
  global contents
  global path
  write_changes(module, contents, path)

  assert os.path.exists(path)

  with open(path, "rb") as f:
    file_contents = f.read()

  assert contents == file_contents

  os.remove(path)


# Generated at 2022-06-23 04:16:28.967487
# Unit test for function write_changes

# Generated at 2022-06-23 04:16:32.577348
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    contents = bytearray("Hello content", 'utf-8')
    path = "/tmp/path"
    assert write_changes(module, contents, path) is None


# Generated at 2022-06-23 04:16:37.348820
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    changed = False
    message = "A change occured"
    changed_message, changed = check_file_attrs(module, changed, message)
    assert changed == False
    assert changed_message == "A change occured"



# Generated at 2022-06-23 04:16:49.559626
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(argument_spec=dict(
        path = dict(required=True),
        regexp = dict(required=True),
        replace = dict(required=False, default=None),
        after = dict(required=False, default=None),
        before = dict(required=False, default=None),
        backup = dict(required=False, type='bool', default=False),
        others = dict(required=False, default=None),
        encoding = dict(required=False, default='utf-8'),
        foo = dict(required=True, type='bool'),
        bar = dict(required=True, default='baz'),
    ))
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == ''
    assert changed == False
#

# Generated at 2022-06-23 04:16:54.904507
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    changed = True
    message = 'test message'
    result = check_file_attrs(module, changed, message)
    assert result == ('test message and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-23 04:17:02.627586
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    # just pass through to AnsibleModule.fail_json

# Generated at 2022-06-23 04:17:15.644997
# Unit test for function main
def test_main():
    current = os.path.dirname(os.path.realpath(__file__))
    parent = os.path.join(current, '..')
    src_path = os.path.join(parent, 'atomic_move.py')
    test_module = os.path.join(current, 'test_atomic_move.py')
    tmp_path = '/tmp/test_atomic_move.py'
    module_args = {}
    module_args.update({"backup": False})
    module_args.update({"dest": test_module})
    module_args.update({"src": src_path})
    module_args.update({"unsafe_writes": True})
    set_module_args(module_args)

# Generated at 2022-06-23 04:17:22.888746
# Unit test for function main
def test_main():
    # Preparing Mock test environment
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    # Preparing Mock test environment
    # This test is same as above no changes were made
    params = module.params

# Generated at 2022-06-23 04:17:33.882329
# Unit test for function write_changes
def test_write_changes():
    path = '~/tmp/test_ansible_write_changes'
    #module = type('module', (), {})()
    #module.tmpdir = os.path.dirname(path)
    #module.fail_json = lambda msg: sys.stderr.write(msg+'\n')
    #module.run_command = lambda cmd: (0,cmd,'')
    #module.atomic_move = lambda src,dest: os.rename(src,dest)
    #module.params = dict()
    #module.params['validate'] = "echo %s"
    #module.params['unsafe_writes'] = False
    #write_changes(module, 'coucou', path)
    #assert os.path.exists(path)
    #with open(path, 'r') as f:


# Generated at 2022-06-23 04:17:46.210486
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        path='/tmp/test.txt',
        owner='root',
        group='bin',
        mode=0o644,
        seuser='root',
        serole=None,
        setype='usr_t',
        selevel='s0'
    )
    module.atomic_move = None
    module.run_command = lambda * args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    changed = False
    message = ''
    returned = check_file_attrs(module, changed, message)
    assert len(returned) == 2
    assert returned[0] == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-23 04:17:52.501767
# Unit test for function main
def test_main():
    test_dict = {
        "path": "path",
        "regexp": "regexp",
        "replace": "replace",
        "backup": False,
        "validate": "validate",
        "encoding": "utf-8"
    }


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:18:03.921931
# Unit test for function main
def test_main():

    def stub_module_run_command(m, cmd):
        return (0, '', '')

    def stub_module_fail_json(m, msg, **kwargs):
        raise Exception(msg)

    real_module_run_command = AnsibleModule.run_command
    AnsibleModule.run_command = stub_module_run_command

    real_module_fail_json = AnsibleModule.fail_json
    AnsibleModule.fail_json = stub_module_fail_json


# Generated at 2022-06-23 04:18:06.220816
# Unit test for function check_file_attrs
def test_check_file_attrs():
    '''
    Test
    '''
    pass



# Generated at 2022-06-23 04:18:15.711963
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'path': '/etc/hosts',
        'backup': True,
        'regexp': r'\[(.*?)\]',
        'replace': r'{\1}',
    }, check_mode=True)

    # Mock functions
    class MockFailJson(object):
        def __init__(self):
            self.msg = ''
            self.exception = ''
        def __call__(self, msg, **kwargs):
            self.msg = msg
            if 'exception' in kwargs:
                self.exception = kwargs['exception']
            raise Exception(msg)
    class MockExitJson(object):
        def __init__(self):
            self.args = {}
            self.changed = False

# Generated at 2022-06-23 04:18:27.118513
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(required=True),
            replace=dict(required=False),
            after=dict(required=False),
            before=dict(required=False),
            backup=dict(default=False, type='bool'),
            validate=dict(required=False),
            encoding=dict(default='utf-8'),
        ),
        supports_check_mode=True
    )
    module.params['state'] = 'file'
    module.params['path'] = '/tmp/foobar'
    module.params['regexp'] = 'foo'
    module.params['replace'] = 'bar'
    module.params['backup'] = True
    module.params['validate'] = '/bin/true'
    module

# Generated at 2022-06-23 04:18:28.691918
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:18:36.436398
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({}, check_invalid_arguments=False)
    module.atomic_move = lambda x, y, z: y
    module.params = {'unsafe_writes': True}
    module.tmpdir = tempfile.gettempdir()
    write_changes(module, 'test123', os.path.join(module.tmpdir, 'test'))
    assert os.path.exists(os.path.join(module.tmpdir, 'test'))
    os.remove(os.path.join(module.tmpdir, 'test'))



# Generated at 2022-06-23 04:18:48.126074
# Unit test for function check_file_attrs