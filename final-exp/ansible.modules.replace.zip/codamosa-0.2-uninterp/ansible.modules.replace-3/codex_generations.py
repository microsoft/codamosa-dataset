

# Generated at 2022-06-17 05:07:52.316925
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:04.171094
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True
    }
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.atomic_move = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {}

    # Create a mock file
    with open('/tmp/test_file', 'w') as f:
        f.write('test')

    # Test

# Generated at 2022-06-17 05:08:18.362836
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']

# Generated at 2022-06-17 05:08:25.388586
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str', 'required': False},
        'unsafe_writes': {'type': 'bool', 'default': True, 'required': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'', '/tmp/test')
    assert True



# Generated at 2022-06-17 05:08:30.570256
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:08:38.005684
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, 'test', '/tmp/test')
    assert os.path.exists('/tmp/test')
    os.remove('/tmp/test')



# Generated at 2022-06-17 05:08:45.832311
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: None
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:08:55.225912
# Unit test for function main
def test_main():
    path = '/etc/hosts'
    regexp = '^(.+)$'
    replace = '# \1'
    after = '<VirtualHost [*]>'
    before = '</VirtualHost>'
    backup = False
    validate = '/usr/sbin/apache2ctl -f %s -t'
    encoding = 'utf-8'

# Generated at 2022-06-17 05:09:00.389594
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.params = {'validate': None, 'unsafe_writes': False}
    contents = to_bytes('test')
    path = '/tmp/test'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path).read() == 'test'
    os.remove(path)



# Generated at 2022-06-17 05:09:08.022289
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.params = {'path': '/etc/hosts', 'validate': 'test %s', 'unsafe_writes': False}
    contents = 'test'
    write_changes(module, contents, module.params['path'])


# Generated at 2022-06-17 05:09:36.495449
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = to_bytes('test_write_changes')
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 05:09:38.216096
# Unit test for function write_changes
def test_write_changes():
    # TODO: write unit test for function write_changes
    pass


# Generated at 2022-06-17 05:09:40.668687
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:09:50.657062
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:55.700161
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            contents=dict(type='str', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
    )
    path = module.params['path']
    contents = module.params['contents']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']

    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.write(contents)
    f.close()

    valid = not validate

# Generated at 2022-06-17 05:10:02.435811
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:10:17.380550
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

# Generated at 2022-06-17 05:10:27.587015
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-17 05:10:36.534247
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    module.tmpdir = '/tmp'
   

# Generated at 2022-06-17 05:10:47.643038
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.urls import open_url

    # Load the module source file
    module_path = os.path.join(os.path.dirname(__file__), '../library/replace.py')

# Generated at 2022-06-17 05:11:22.425951
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {}
    message = ''
    changed = False
    message, changed = check_file_attrs(module, changed, message)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 05:11:33.974902
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
   

# Generated at 2022-06-17 05:11:44.157517
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:11:49.444233
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:11:56.481530
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:12:06.965045
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['validate'] = '/bin/true'
    module.params['unsafe_writes'] = True
    write_changes(module, 'test', '/tmp/test_write_changes')
    assert os.path.exists('/tmp/test_write_changes')
    os.remove('/tmp/test_write_changes')


# Generated at 2022-06-17 05:12:14.317767
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:12:27.269915
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': False}
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
   

# Generated at 2022-06-17 05:12:36.799832
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False, default=False),
            validate=dict(type='str', required=False),
            encoding=dict(type='str', required=False, default='utf-8'),
            unsafe_writes=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
   

# Generated at 2022-06-17 05:12:46.399907
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.fail_json = lambda x: None
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')

# Generated at 2022-06-17 05:13:45.171174
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    write_changes(module, b'', '/tmp/test')
    assert module.run_command.call_count == 1
    assert module.atomic_move.call_count == 1
    module.run_command = lambda *args, **kwargs: (1, '', '')
    write_changes(module, b'', '/tmp/test')
    assert module

# Generated at 2022-06-17 05:13:59.061540
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:05.204131
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:16.447739
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    message = ''
    changed = False
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed



# Generated at 2022-06-17 05:14:28.681378
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:34.679375
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/tmp/test_file', 'unsafe_writes': True})
    contents = b'hello world'
    path = '/tmp/test_file'
    write_changes(module, contents, path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.remove(path)



# Generated at 2022-06-17 05:14:45.051841
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 05:14:55.053074
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, 'rb') as f:
        assert f.read() == contents
    os.unlink(path)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 05:15:01.773260
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path).read() == contents
    os.unlink(path)


# Generated at 2022-06-17 05:15:08.426388
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_check_file_attrs',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:17:22.855241
# Unit test for function main

# Generated at 2022-06-17 05:17:27.984862
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    path = '/tmp/test_write_changes'
    contents = 'test_write_changes'
    write_changes(module, contents, path)
    with open(path, 'r') as f:
        assert f.read() == contents
    os.remove(path)
