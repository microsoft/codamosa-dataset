

# Generated at 2022-06-17 05:07:57.345496
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.set_file_attributes_if_different = lambda *args, **kwargs: True
    module.load_file_common_arguments = lambda *args, **kwargs: {'path': '/tmp/test_check_file_attrs', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.atomic_move = lambda *args, **kwargs: True
    changed, message = False, ''

# Generated at 2022-06-17 05:08:04.591398
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:18.389042
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True),
        regexp=dict(type='str', required=True),
        replace=dict(type='str'),
        after=dict(type='str'),
        before=dict(type='str'),
        backup=dict(type='bool', default=False),
        validate=dict(type='str'),
        unsafe_writes=dict(type='bool', default=False),
        encoding=dict(type='str', default='utf-8'),
    ))
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    module.tmpdir = '/tmp'

# Generated at 2022-06-17 05:08:25.527009
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import AtomicFile
    from ansible.module_utils.common.file import Filesystem
    from ansible.module_utils.common.file import TemporaryDirectory
    from ansible.module_utils.common.file import TemporaryFile
    from ansible.module_utils.common.file import TemporaryFileContext
    from ansible.module_utils.common.file import TemporaryWorkingDirectory
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import atomic_move_safe

# Generated at 2022-06-17 05:08:37.247347
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:08:45.092119
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed is True


# Generated at 2022-06-17 05:08:52.234807
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test.txt',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:09:02.475175
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=False),
            validate=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']
    replace = module.params['replace']
    after = module.params['after']
    before = module.params['before']
    backup = module.params['backup']
    unsafe_

# Generated at 2022-06-17 05:09:11.542851
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.parameters import check_file_attributes
    from ansible.module_utils.common.parameters import check_file_attributes_if_different
    from ansible.module_utils.common.parameters import load_file_common_arguments

# Generated at 2022-06-17 05:09:16.148215
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:09:39.717595
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}})
    module.params['path'] = '/tmp/test_write_changes'
    module.params['unsafe_writes'] = True
    contents = b'contents'
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.read() == contents
    os.remove(module.params['path'])



# Generated at 2022-06-17 05:09:44.694296
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    contents = to_bytes("test")
    path = "/tmp/test"
    write_changes(module, contents, path)
    assert os.path.exists(path)
    with open(path, "rb") as f:
        assert f.read() == contents
    os.remove(path)


# Generated at 2022-06-17 05:09:54.953353
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', required=False, default=False),
            validate=dict(type='str', required=False),
            encoding=dict(type='str', default='utf-8'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    path = module.params['path']
    regexp = module.params['regexp']

# Generated at 2022-06-17 05:10:02.382877
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.tmpdir = tempfile.mkdtemp()
    path = os.path.join(module.tmpdir, 'test_write_changes')
    contents = b'foo'
    write_changes(module, contents, path)
    assert os.path.exists(path)
    assert open(path, 'rb').read() == contents



# Generated at 2022-06-17 05:10:11.855410
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.params['validate'] = None
    module.params['unsafe_writes'] = True
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: True
    module.run_command = lambda x: (0, '', '')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:10:21.457680
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.tmpdir = '/tmp'
    module.params['validate'] = 'echo %s'
    module.params['path'] = '/tmp/test_write_changes'
    contents = to_bytes('test_write_changes')
    write_changes(module, contents, module.params['path'])
    assert os.path.exists(module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.read() == contents
    os.remove(module.params['path'])


# Generated at 2022-06-17 05:10:26.677390
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    module.params = {'validate': None, 'unsafe_writes': True}
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.tmpdir = '/tmp'
    write_changes(module, '', '/tmp/test')


# Generated at 2022-06-17 05:10:36.440465
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test_file',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'unconfined_u',
        'serole': 'object_r',
        'setype': 'tmp_t',
        'selevel': 's0',
        'unsafe_writes': False,
    }
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: params
    changed = False
    message = ''

# Generated at 2022-06-17 05:10:44.515330
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:10:50.912245
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    module.fail_json = lambda x: None
    write_changes(module, 'test', '/tmp/test')
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:11:24.194419
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y: True
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, b'', '/tmp/test')
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, b'', '/tmp/test')
    module.params = {'path': '/tmp/test', 'validate': 'echo %s'}
    write_changes(module, b'', '/tmp/test')

# Generated at 2022-06-17 05:11:33.883892
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str'),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    contents = '''# This is a comment
# This is another comment
# This is a third comment
# This is a fourth comment
# This is a fifth comment
'''
    path = '/tmp/test_replace'

# Generated at 2022-06-17 05:11:45.900311
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
            contents=dict(required=True, type='str'),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    write_changes(module, 'test', '/tmp/test')
    assert True


# Generated at 2022-06-17 05:11:51.510303
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': 'test_path', 'validate': 'test_validate', 'unsafe_writes': True})
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: True
    module.tmpdir = 'test_tmpdir'
    assert write_changes(module, 'test_contents', 'test_path') == True


# Generated at 2022-06-17 05:11:58.400543
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params = {'path': '/tmp/test_write_changes', 'validate': None, 'unsafe_writes': False}
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, b'', '/tmp/test_write_changes')
    assert os.path.exists('/tmp/test_write_changes')
    os.remove('/tmp/test_write_changes')



# Generated at 2022-06-17 05:12:08.963534
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import json
    import re
    import subprocess
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    with open(path, 'w') as f:
        f.write("[defaults]\n")
        f.write("roles_path = %s\n" % tmpdir)
        f.write("host_key_checking = False\n")

# Generated at 2022-06-17 05:12:14.357794
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool'}})
    module.tmpdir = '/tmp'
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    write_changes(module, 'test', '/tmp/test')


# Generated at 2022-06-17 05:12:24.661433
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', required=False),
            after=dict(type='str', required=False),
            before=dict(type='str', required=False),
            backup=dict(type='bool', default=False),
            encoding=dict(type='str', default='utf-8'),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    contents = to_bytes(u'This is a test file')
    path = '/tmp/test_write_changes'

# Generated at 2022-06-17 05:12:35.306367
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'root', 'serole': 'root', 'setype': 'root', 'selevel': 'root'}
    module.atomic_move = lambda src, dest, unsafe_writes: None
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: {'path': '/tmp/test_file', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'root', 'serole': 'root', 'setype': 'root', 'selevel': 'root'}
    changed, message

# Generated at 2022-06-17 05:12:43.868182
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': False,
    }
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 05:13:43.438719
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves.urllib.parse import quote

# Generated at 2022-06-17 05:13:55.035755
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:03.066156
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test.txt', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.tmpdir = '/tmp'
    module.atomic_move = lambda src, dest, unsafe_writes: True
    module.set_file_attributes_if_different = lambda file_args, changed: True
    module.load_file_common_arguments = lambda params: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 05:14:17.139391
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test

# Generated at 2022-06-17 05:14:28.720633
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True),
            replace=dict(type='str', default=''),
            after=dict(type='str'),
            before=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            encoding=dict(type='str', default='utf-8'),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params
    path = params['path']
    encoding = params['encoding']
    res_args = dict()

    params['after'] = to

# Generated at 2022-06-17 05:14:33.025402
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_file_attributes_if_different = lambda x, y: True
    module.load_file_common_arguments = lambda x: x
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 05:14:44.937334
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
   

# Generated at 2022-06-17 05:14:54.688576
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_content = '''
    # This is a test file
    # It has some content
    # And some more content
    '''
    with open(test_file, 'w') as f:
        f.write(test_file_content)


# Generated at 2022-06-17 05:15:07.294111
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
   

# Generated at 2022-06-17 05:15:14.363275
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.common.file import set_file_attributes_if_different
    from ansible.module_utils.common.file import load_file_common_arguments
    from ansible.module_utils.common.file import backup_local
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 05:17:34.013852
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    module.params = {
        'path': '/path/to/file',
        'validate': 'echo %s',
    }
    write_changes(module, b'contents', module.params['path'])
    assert module.run_command.call_count == 1
    assert module.atomic_move.call_count == 1
   